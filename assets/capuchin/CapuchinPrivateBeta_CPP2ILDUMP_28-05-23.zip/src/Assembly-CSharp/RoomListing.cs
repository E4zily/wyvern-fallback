﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000040 RID: 64
[Token(Token = "0x2000040")]
public class RoomListing : MonoBehaviourPunCallbacks
{
	// Token: 0x06000891 RID: 2193 RVA: 0x0002F1A8 File Offset: 0x0002D3A8
	[Token(Token = "0x6000891")]
	[Address(RVA = "0x2B5FA80", Offset = "0x2B5FA80", VA = "0x2B5FA80")]
	public void \u0898Հؿؿ()
	{
		string name = this.<ه\u07BB\u089Fݚ>k__BackingField.name;
		if ("\ud9c0\udc00" == null)
		{
		}
	}

	// Token: 0x06000892 RID: 2194 RVA: 0x0002F1D0 File Offset: 0x0002D3D0
	[Token(Token = "0x6000892")]
	[Address(RVA = "0x2B5FAF8", Offset = "0x2B5FAF8", VA = "0x2B5FAF8")]
	public void ޡࢴԻ\u0744()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x06000893 RID: 2195 RVA: 0x0002F1F4 File Offset: 0x0002D3F4
	[Token(Token = "0x6000893")]
	[Address(RVA = "0x2B5FB70", Offset = "0x2B5FB70", VA = "0x2B5FB70")]
	public void \u05AEࢷӠࡡ(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] values = new string[4];
		if (", " != null)
		{
			if (", " != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				if ("ChangeToRegular" != null)
				{
					if ("ChangeToRegular" != null)
					{
						return;
					}
				}
				else
				{
					byte maxPlayers = Ԇ\u05EB\u0608\u0598.maxPlayers;
					string text2;
					if (text2 == null || text2 != null)
					{
						if ("Player" != null)
						{
							if ("Player" != null)
							{
								return;
							}
						}
						else
						{
							string name = Ԇ\u05EB\u0608\u0598.name;
							if (name == null || name != null)
							{
								string text3 = string.Concat(values);
								return;
							}
						}
					}
				}
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000894 RID: 2196 RVA: 0x0002F290 File Offset: 0x0002D490
	[Token(Token = "0x6000894")]
	[Address(RVA = "0x2B5FE04", Offset = "0x2B5FE04", VA = "0x2B5FE04")]
	public void \u05BCߕڊݙ()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x06000895 RID: 2197 RVA: 0x0002F2B4 File Offset: 0x0002D4B4
	[Token(Token = "0x6000895")]
	[Address(RVA = "0x2B5FE7C", Offset = "0x2B5FE7C", VA = "0x2B5FE7C")]
	public RoomInfo ր\u0837\u073B\u059B()
	{
		return this.<ه\u07BB\u089Fݚ>k__BackingField;
	}

	// Token: 0x06000896 RID: 2198 RVA: 0x0002F2C8 File Offset: 0x0002D4C8
	[Token(Token = "0x6000896")]
	[Address(RVA = "0x2B5FE84", Offset = "0x2B5FE84", VA = "0x2B5FE84")]
	public RoomInfo ܗݬߚ\u0747()
	{
		return this.<ه\u07BB\u089Fݚ>k__BackingField;
	}

	// Token: 0x06000897 RID: 2199 RVA: 0x0002F2DC File Offset: 0x0002D4DC
	[Token(Token = "0x6000897")]
	[Address(RVA = "0x2B5FE8C", Offset = "0x2B5FE8C", VA = "0x2B5FE8C")]
	public void ࠅࢩקշ(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] values = new string[6];
		if ("Players: " != null)
		{
			if ("Players: " != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				if ("/" != null)
				{
					if ("/" != null)
					{
						return;
					}
				}
				else
				{
					byte maxPlayers = Ԇ\u05EB\u0608\u0598.maxPlayers;
					string text2;
					if (text2 == null || text2 != null)
					{
						if (", " != null)
						{
							if (", " != null)
							{
								return;
							}
						}
						else
						{
							string name = Ԇ\u05EB\u0608\u0598.name;
							if (name == null || name != null)
							{
								string text3 = string.Concat(values);
								return;
							}
						}
					}
				}
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000898 RID: 2200 RVA: 0x0002F378 File Offset: 0x0002D578
	[Token(Token = "0x6000898")]
	[Address(RVA = "0x2B60118", Offset = "0x2B60118", VA = "0x2B60118")]
	public RoomInfo וԁࡢࠐ()
	{
		return this.<ه\u07BB\u089Fݚ>k__BackingField;
	}

	// Token: 0x06000899 RID: 2201 RVA: 0x0002F38C File Offset: 0x0002D58C
	[Token(Token = "0x6000899")]
	[Address(RVA = "0x2B60120", Offset = "0x2B60120", VA = "0x2B60120")]
	private void ࡈ\u058C\u0883ࢣ(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x0600089A RID: 2202 RVA: 0x0002F3A0 File Offset: 0x0002D5A0
	[Token(Token = "0x600089A")]
	[Address(RVA = "0x2B60128", Offset = "0x2B60128", VA = "0x2B60128")]
	public void ٳ٦ݯԝ(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] array = new string[1];
		if (array != null)
		{
			if (array != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				if ("username" != null)
				{
					if ("username" != null)
					{
						return;
					}
				}
				else
				{
					byte maxPlayers = Ԇ\u05EB\u0608\u0598.maxPlayers;
					string text2;
					if (text2 == null || text2 != null)
					{
						if ("User has been reported for: " != null)
						{
							if ("User has been reported for: " != null)
							{
								return;
							}
						}
						else
						{
							string name = Ԇ\u05EB\u0608\u0598.name;
							if (name == null || name != null)
							{
								string text3 = string.Concat(array);
								return;
							}
						}
					}
				}
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600089B RID: 2203 RVA: 0x0002F434 File Offset: 0x0002D634
	[Token(Token = "0x600089B")]
	[Address(RVA = "0x2B603C4", Offset = "0x2B603C4", VA = "0x2B603C4")]
	public void ࢡعյԹ(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] values = new string[6];
		if ("username" != null)
		{
			if ("username" != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				if ("Toxicity" != null)
				{
					if ("Toxicity" != null)
					{
						return;
					}
				}
				else
				{
					byte maxPlayers = Ԇ\u05EB\u0608\u0598.maxPlayers;
					string text2;
					if (text2 == null || text2 != null)
					{
						if ("false" != null)
						{
							if ("false" != null)
							{
								return;
							}
						}
						else
						{
							string name = Ԇ\u05EB\u0608\u0598.name;
							if (name == null || name != null)
							{
								string text3 = string.Concat(values);
								return;
							}
						}
					}
				}
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600089C RID: 2204 RVA: 0x0002F4D0 File Offset: 0x0002D6D0
	[Token(Token = "0x600089C")]
	[Address(RVA = "0x2B60654", Offset = "0x2B60654", VA = "0x2B60654")]
	public void ԗ\u05F9ҿ\u0834(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.\u05BCߕڊݙ();
	}

	// Token: 0x0600089D RID: 2205 RVA: 0x0002F508 File Offset: 0x0002D708
	[Token(Token = "0x600089D")]
	[Address(RVA = "0x2B60748", Offset = "0x2B60748", VA = "0x2B60748")]
	public RoomInfo \u061A\u0598\u05A8۹()
	{
		return this.<ه\u07BB\u089Fݚ>k__BackingField;
	}

	// Token: 0x0600089E RID: 2206 RVA: 0x0002F51C File Offset: 0x0002D71C
	[Token(Token = "0x600089E")]
	[Address(RVA = "0x2B60750", Offset = "0x2B60750", VA = "0x2B60750")]
	public void Ӊ\u055Fࡋڂ()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x0600089F RID: 2207 RVA: 0x0002F540 File Offset: 0x0002D740
	[Token(Token = "0x600089F")]
	[Address(RVA = "0x2B607C8", Offset = "0x2B607C8", VA = "0x2B607C8")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.ޡࢴԻ\u0744();
	}

	// Token: 0x060008A0 RID: 2208 RVA: 0x0002F578 File Offset: 0x0002D778
	[Token(Token = "0x60008A0")]
	[Address(RVA = "0x2B608BC", Offset = "0x2B608BC", VA = "0x2B608BC")]
	private void պז\u070Eݘ(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008A1 RID: 2209 RVA: 0x0002F58C File Offset: 0x0002D78C
	[Token(Token = "0x60008A1")]
	[Address(RVA = "0x2B608C4", Offset = "0x2B608C4", VA = "0x2B608C4")]
	private void ܧࡔ\u073D\u0738(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008A2 RID: 2210 RVA: 0x0002F5A0 File Offset: 0x0002D7A0
	[Token(Token = "0x60008A2")]
	[Address(RVA = "0x2B608CC", Offset = "0x2B608CC", VA = "0x2B608CC")]
	public RoomInfo ٽݱߢړ()
	{
		return this.<ه\u07BB\u089Fݚ>k__BackingField;
	}

	// Token: 0x060008A3 RID: 2211 RVA: 0x0002F5B4 File Offset: 0x0002D7B4
	[Token(Token = "0x60008A3")]
	[Address(RVA = "0x2B608D4", Offset = "0x2B608D4", VA = "0x2B608D4")]
	private void \u07A9\u05CE\u064D\u07BF(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008A4 RID: 2212 RVA: 0x0002F5C8 File Offset: 0x0002D7C8
	[Token(Token = "0x60008A4")]
	[Address(RVA = "0x2B608DC", Offset = "0x2B608DC", VA = "0x2B608DC")]
	public void \u081FԘں\u07B2(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.Ցݢݢө();
	}

	// Token: 0x060008A5 RID: 2213 RVA: 0x0002F600 File Offset: 0x0002D800
	[Token(Token = "0x60008A5")]
	[Address(RVA = "0x2B60A48", Offset = "0x2B60A48", VA = "0x2B60A48")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.Ցݢݢө();
	}

	// Token: 0x060008A6 RID: 2214 RVA: 0x0002F638 File Offset: 0x0002D838
	[Token(Token = "0x60008A6")]
	[Address(RVA = "0x2B60B3C", Offset = "0x2B60B3C", VA = "0x2B60B3C")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.Ԗ\u060Eߠ\u0872();
	}

	// Token: 0x060008A7 RID: 2215 RVA: 0x0002F670 File Offset: 0x0002D870
	[Token(Token = "0x60008A7")]
	[Address(RVA = "0x2B60CA8", Offset = "0x2B60CA8", VA = "0x2B60CA8")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.\u07AAԲװؽ();
	}

	// Token: 0x060008A8 RID: 2216 RVA: 0x0002F6A8 File Offset: 0x0002D8A8
	[Token(Token = "0x60008A8")]
	[Address(RVA = "0x2B60E14", Offset = "0x2B60E14", VA = "0x2B60E14")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.\u05BCߕڊݙ();
	}

	// Token: 0x060008A9 RID: 2217 RVA: 0x0002F6E0 File Offset: 0x0002D8E0
	[Token(Token = "0x60008A9")]
	[Address(RVA = "0x2B60F08", Offset = "0x2B60F08", VA = "0x2B60F08")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.\u088EࡃӴ\u05AE();
	}

	// Token: 0x060008AA RID: 2218 RVA: 0x0002F718 File Offset: 0x0002D918
	[Token(Token = "0x60008AA")]
	[Address(RVA = "0x2B61074", Offset = "0x2B61074", VA = "0x2B61074")]
	public RoomInfo \u06DFӢ\u086F\u0821()
	{
		return this.<ه\u07BB\u089Fݚ>k__BackingField;
	}

	// Token: 0x060008AB RID: 2219 RVA: 0x0002F72C File Offset: 0x0002D92C
	[Token(Token = "0x60008AB")]
	[Address(RVA = "0x2B6107C", Offset = "0x2B6107C", VA = "0x2B6107C", Slot = "34")]
	public override void OnJoinRoomFailed(short ۅ\u05A4ڊ\u06D7, string \u0656\u0898ر\u0896)
	{
		base.OnJoinRoomFailed(ۅ\u05A4ڊ\u06D7, \u0656\u0898ر\u0896);
		Debug.Log("Failed To Join Public Room Successfully. The error is: " + \u0656\u0898ر\u0896);
	}

	// Token: 0x060008AC RID: 2220 RVA: 0x0002F754 File Offset: 0x0002D954
	[Token(Token = "0x60008AC")]
	[Address(RVA = "0x2B61130", Offset = "0x2B61130", VA = "0x2B61130")]
	public void ڑ\u081Aڬࡉ(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] array = new string[4];
		if (array != null)
		{
			if (array != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				if ("clickLol" != null)
				{
					if ("clickLol" != null)
					{
						return;
					}
				}
				else
				{
					byte maxPlayers = Ԇ\u05EB\u0608\u0598.maxPlayers;
					string text2;
					if (text2 == null || text2 != null)
					{
						if ("Toxicity" != null)
						{
							if ("Toxicity" != null)
							{
								return;
							}
						}
						else
						{
							string name = Ԇ\u05EB\u0608\u0598.name;
							if (name == null || name != null)
							{
								return;
							}
						}
					}
				}
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060008AD RID: 2221 RVA: 0x0002F7D4 File Offset: 0x0002D9D4
	[Token(Token = "0x60008AD")]
	[Address(RVA = "0x2B613BC", Offset = "0x2B613BC", VA = "0x2B613BC")]
	private void ӎ\u06E6\u05CA\u088C(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008AE RID: 2222 RVA: 0x0002F7E8 File Offset: 0x0002D9E8
	[Token(Token = "0x60008AE")]
	[Address(RVA = "0x2B613C4", Offset = "0x2B613C4", VA = "0x2B613C4")]
	private void ܪօࡐ\u073A(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008AF RID: 2223 RVA: 0x0002F7FC File Offset: 0x0002D9FC
	[Token(Token = "0x60008AF")]
	[Address(RVA = "0x2B613CC", Offset = "0x2B613CC", VA = "0x2B613CC")]
	public void \u07EDה\u0600ގ()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x060008B0 RID: 2224 RVA: 0x0002F820 File Offset: 0x0002DA20
	[Token(Token = "0x60008B0")]
	[Address(RVA = "0x2B61444", Offset = "0x2B61444", VA = "0x2B61444")]
	private void ࡋ\u05C4\u081Eڣ(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008B1 RID: 2225 RVA: 0x0002F834 File Offset: 0x0002DA34
	[Token(Token = "0x60008B1")]
	[Address(RVA = "0x2B6144C", Offset = "0x2B6144C", VA = "0x2B6144C")]
	public void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.Ԗ\u060Eߠ\u0872();
	}

	// Token: 0x060008B2 RID: 2226 RVA: 0x0002F86C File Offset: 0x0002DA6C
	[Token(Token = "0x60008B2")]
	[Address(RVA = "0x2B61540", Offset = "0x2B61540", VA = "0x2B61540")]
	private void ܓٵٺߩ(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008B3 RID: 2227 RVA: 0x0002F880 File Offset: 0x0002DA80
	[Token(Token = "0x60008B3")]
	[Address(RVA = "0x2B609D0", Offset = "0x2B609D0", VA = "0x2B609D0")]
	public void Ցݢݢө()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x060008B4 RID: 2228 RVA: 0x0002F8A4 File Offset: 0x0002DAA4
	[Token(Token = "0x60008B4")]
	[Address(RVA = "0x2B61548", Offset = "0x2B61548", VA = "0x2B61548")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.ޡࢴԻ\u0744();
	}

	// Token: 0x060008B5 RID: 2229 RVA: 0x0002F8DC File Offset: 0x0002DADC
	[Token(Token = "0x60008B5")]
	[Address(RVA = "0x2B60FFC", Offset = "0x2B60FFC", VA = "0x2B60FFC")]
	public void \u088EࡃӴ\u05AE()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x060008B6 RID: 2230 RVA: 0x0002F900 File Offset: 0x0002DB00
	[Token(Token = "0x60008B6")]
	[Address(RVA = "0x2B6163C", Offset = "0x2B6163C", VA = "0x2B6163C")]
	private void ڋ\u058Bࡨ\u05C8(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008B7 RID: 2231 RVA: 0x0002F914 File Offset: 0x0002DB14
	[Token(Token = "0x60008B7")]
	[Address(RVA = "0x2B61644", Offset = "0x2B61644", VA = "0x2B61644")]
	public void ؽՀ\u074C\u070A(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] values = new string[2];
		if ("hand 2" != null)
		{
			if ("hand 2" != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				if ("NoseAttachPoint" != null)
				{
					if ("NoseAttachPoint" != null)
					{
						return;
					}
				}
				else
				{
					byte maxPlayers = Ԇ\u05EB\u0608\u0598.maxPlayers;
					string text2;
					if (text2 == null || text2 != null)
					{
						if ("You are not the master of the server, you cannot start the game." != null)
						{
							if ("You are not the master of the server, you cannot start the game." != null)
							{
								return;
							}
						}
						else
						{
							string name = Ԇ\u05EB\u0608\u0598.name;
							if (name == null || name != null)
							{
								string text3 = string.Concat(values);
								return;
							}
						}
					}
				}
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060008B8 RID: 2232 RVA: 0x0002F9B0 File Offset: 0x0002DBB0
	[Token(Token = "0x60008B8")]
	[Address(RVA = "0x2B618D4", Offset = "0x2B618D4", VA = "0x2B618D4")]
	private void \u0882\u060Fݿ\u0834(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008B9 RID: 2233 RVA: 0x0002F9C4 File Offset: 0x0002DBC4
	[Token(Token = "0x60008B9")]
	[Address(RVA = "0x2B618DC", Offset = "0x2B618DC", VA = "0x2B618DC")]
	private void \u058DӧӋ\u06EB(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008BA RID: 2234 RVA: 0x0002F9D8 File Offset: 0x0002DBD8
	[Token(Token = "0x60008BA")]
	[Address(RVA = "0x2B618E4", Offset = "0x2B618E4", VA = "0x2B618E4")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.\u05BCߕڊݙ();
	}

	// Token: 0x060008BB RID: 2235 RVA: 0x0002FA10 File Offset: 0x0002DC10
	[Token(Token = "0x60008BB")]
	[Address(RVA = "0x2B619D8", Offset = "0x2B619D8", VA = "0x2B619D8", Slot = "41")]
	public override void OnJoinedRoom()
	{
		base.OnJoinedRoom();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Joined Public Room Successfully");
	}

	// Token: 0x060008BC RID: 2236 RVA: 0x0002FA34 File Offset: 0x0002DC34
	[Token(Token = "0x60008BC")]
	[Address(RVA = "0x2B61A5C", Offset = "0x2B61A5C", VA = "0x2B61A5C")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.\u05BCߕڊݙ();
	}

	// Token: 0x060008BD RID: 2237 RVA: 0x0002FA6C File Offset: 0x0002DC6C
	[Token(Token = "0x60008BD")]
	[Address(RVA = "0x2B61B50", Offset = "0x2B61B50", VA = "0x2B61B50")]
	public void ק\u0592Կ\u0870(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] array = new string[6];
		if ("_BumpMap" != null)
		{
			if ("_BumpMap" != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060008BE RID: 2238 RVA: 0x0002FAF8 File Offset: 0x0002DCF8
	[Token(Token = "0x60008BE")]
	[Address(RVA = "0x2B61DDC", Offset = "0x2B61DDC", VA = "0x2B61DDC")]
	private void ޟӸ\u0746ݲ(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008BF RID: 2239 RVA: 0x0002FB0C File Offset: 0x0002DD0C
	[Token(Token = "0x60008BF")]
	[Address(RVA = "0x2B61DE4", Offset = "0x2B61DE4", VA = "0x2B61DE4")]
	private void ࢷ\u085F\u07AB\u085F(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008C0 RID: 2240 RVA: 0x0002FB20 File Offset: 0x0002DD20
	[Token(Token = "0x60008C0")]
	[Address(RVA = "0x2B61DEC", Offset = "0x2B61DEC", VA = "0x2B61DEC")]
	public RoomInfo ݡ\u0557\u082Dܭ()
	{
		return this.<ه\u07BB\u089Fݚ>k__BackingField;
	}

	// Token: 0x060008C1 RID: 2241 RVA: 0x0002FB34 File Offset: 0x0002DD34
	[Token(Token = "0x60008C1")]
	[Address(RVA = "0x2B61DF4", Offset = "0x2B61DF4", VA = "0x2B61DF4")]
	public void ٻ\u087A\u07FBࡓ()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x060008C2 RID: 2242 RVA: 0x0002FB58 File Offset: 0x0002DD58
	[Token(Token = "0x60008C2")]
	[Address(RVA = "0x2B61E6C", Offset = "0x2B61E6C", VA = "0x2B61E6C")]
	public void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.\u07EDה\u0600ގ();
	}

	// Token: 0x060008C3 RID: 2243 RVA: 0x0002FB90 File Offset: 0x0002DD90
	[Token(Token = "0x60008C3")]
	[Address(RVA = "0x2B61F60", Offset = "0x2B61F60", VA = "0x2B61F60")]
	private void ӹ\u0640ӆܥ(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008C4 RID: 2244 RVA: 0x0002FBA4 File Offset: 0x0002DDA4
	[Token(Token = "0x60008C4")]
	[Address(RVA = "0x2B61F68", Offset = "0x2B61F68", VA = "0x2B61F68")]
	private void \u0654ӯӥ\u059B(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008C5 RID: 2245 RVA: 0x0002FBB8 File Offset: 0x0002DDB8
	[Token(Token = "0x60008C5")]
	[Address(RVA = "0x2B61F70", Offset = "0x2B61F70", VA = "0x2B61F70")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.ޡࢴԻ\u0744();
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x060008CA RID: 2250 RVA: 0x0002FC88 File Offset: 0x0002DE88
	// (set) Token: 0x060008C6 RID: 2246 RVA: 0x0002FBF0 File Offset: 0x0002DDF0
	[Token(Token = "0x17000017")]
	public RoomInfo Ӧݾ\u089Cގ { [Token(Token = "0x60008CA")] [Address(RVA = "0x2B6225C", Offset = "0x2B6225C", VA = "0x2B6225C")] get; [Token(Token = "0x60008C6")] [Address(RVA = "0x2B62064", Offset = "0x2B62064", VA = "0x2B62064")] private set; }

	// Token: 0x060008C7 RID: 2247 RVA: 0x0002FC04 File Offset: 0x0002DE04
	[Token(Token = "0x60008C7")]
	[Address(RVA = "0x2B6206C", Offset = "0x2B6206C", VA = "0x2B6206C")]
	public RoomInfo \u07FFӉ\u05ADܝ()
	{
		return this.<ه\u07BB\u089Fݚ>k__BackingField;
	}

	// Token: 0x060008C8 RID: 2248 RVA: 0x0002FC18 File Offset: 0x0002DE18
	[Token(Token = "0x60008C8")]
	[Address(RVA = "0x2B62074", Offset = "0x2B62074", VA = "0x2B62074")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.ٻ\u087A\u07FBࡓ();
	}

	// Token: 0x060008C9 RID: 2249 RVA: 0x0002FC50 File Offset: 0x0002DE50
	[Token(Token = "0x60008C9")]
	[Address(RVA = "0x2B62168", Offset = "0x2B62168", VA = "0x2B62168")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.\u07AAԲװؽ();
	}

	// Token: 0x060008CB RID: 2251 RVA: 0x0002FC9C File Offset: 0x0002DE9C
	[Token(Token = "0x60008CB")]
	[Address(RVA = "0x2B62264", Offset = "0x2B62264", VA = "0x2B62264")]
	private void \u0707ߨ\u05A4ؿ(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008CC RID: 2252 RVA: 0x0002FCB0 File Offset: 0x0002DEB0
	[Token(Token = "0x60008CC")]
	[Address(RVA = "0x2B6226C", Offset = "0x2B6226C", VA = "0x2B6226C")]
	public void \u05C1ؽԜࡥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.\u088EࡃӴ\u05AE();
	}

	// Token: 0x060008CD RID: 2253 RVA: 0x0002FCE8 File Offset: 0x0002DEE8
	[Token(Token = "0x60008CD")]
	[Address(RVA = "0x2B62360", Offset = "0x2B62360", VA = "0x2B62360")]
	public void \u061Bݤ\u06DFࠓ(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] values = new string[2];
		if ("FingerTip" != null)
		{
			if ("FingerTip" != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				if ("FingerTip" != null)
				{
					if ("FingerTip" != null)
					{
						return;
					}
				}
				else
				{
					byte maxPlayers = Ԇ\u05EB\u0608\u0598.maxPlayers;
					string text2;
					if (text2 == null || text2 != null)
					{
						if ("You have been banned for " != null)
						{
							if ("You have been banned for " != null)
							{
								return;
							}
						}
						else
						{
							string name = Ԇ\u05EB\u0608\u0598.name;
							if (name == null || name != null)
							{
								string text3 = string.Concat(values);
								return;
							}
						}
					}
				}
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060008CE RID: 2254 RVA: 0x0002FD84 File Offset: 0x0002DF84
	[Token(Token = "0x60008CE")]
	[Address(RVA = "0x2B625E4", Offset = "0x2B625E4", VA = "0x2B625E4")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.Ӊ\u055Fࡋڂ();
	}

	// Token: 0x060008CF RID: 2255 RVA: 0x0002FDBC File Offset: 0x0002DFBC
	[Token(Token = "0x60008CF")]
	[Address(RVA = "0x2B626D8", Offset = "0x2B626D8", VA = "0x2B626D8")]
	public RoomInfo \u07F8Ԁ\u064B٢()
	{
		return this.<ه\u07BB\u089Fݚ>k__BackingField;
	}

	// Token: 0x060008D0 RID: 2256 RVA: 0x0002FDD0 File Offset: 0x0002DFD0
	[Token(Token = "0x60008D0")]
	[Address(RVA = "0x2B626E0", Offset = "0x2B626E0", VA = "0x2B626E0")]
	public void \u065Cն\u05FD\u0745(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] values = new string[1];
		if ("This is the 1000 Bananas button, and it was just clicked" != null)
		{
			if ("This is the 1000 Bananas button, and it was just clicked" != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				if ("This is the 1000 Bananas button, and it was just clicked" != null)
				{
					if ("This is the 1000 Bananas button, and it was just clicked" != null)
					{
						return;
					}
				}
				else
				{
					byte maxPlayers = Ԇ\u05EB\u0608\u0598.maxPlayers;
					string text2;
					if (text2 == null || text2 != null)
					{
						if ("FingerTip" != null)
						{
							if ("FingerTip" != null)
							{
								return;
							}
						}
						else
						{
							string name = Ԇ\u05EB\u0608\u0598.name;
							if (name == null || name != null)
							{
								string text3 = string.Concat(values);
								return;
							}
						}
					}
				}
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060008D1 RID: 2257 RVA: 0x0002FE6C File Offset: 0x0002E06C
	[Token(Token = "0x60008D1")]
	[Address(RVA = "0x2B62964", Offset = "0x2B62964", VA = "0x2B62964")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.\u088EࡃӴ\u05AE();
	}

	// Token: 0x060008D2 RID: 2258 RVA: 0x0002FEA4 File Offset: 0x0002E0A4
	[Token(Token = "0x60008D2")]
	[Address(RVA = "0x2B62A58", Offset = "0x2B62A58", VA = "0x2B62A58")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		this.ٻ\u087A\u07FBࡓ();
	}

	// Token: 0x060008D3 RID: 2259 RVA: 0x0002FEDC File Offset: 0x0002E0DC
	[Token(Token = "0x60008D3")]
	[Address(RVA = "0x2B62B4C", Offset = "0x2B62B4C", VA = "0x2B62B4C")]
	private void ٴ\u082C\u0824ޱ(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008D4 RID: 2260 RVA: 0x0002FEF0 File Offset: 0x0002E0F0
	[Token(Token = "0x60008D4")]
	[Address(RVA = "0x2B62B54", Offset = "0x2B62B54", VA = "0x2B62B54")]
	public void Ծә\u05F7\u06DD(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] values = new string[8];
		if ("This is the 1000 Bananas button, and it was just clicked" != null)
		{
			if ("This is the 1000 Bananas button, and it was just clicked" != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				if ("Player" != null)
				{
					if ("Player" != null)
					{
						return;
					}
				}
				else
				{
					byte maxPlayers = Ԇ\u05EB\u0608\u0598.maxPlayers;
					string text2;
					if (text2 == null || text2 != null)
					{
						if ("NetworkGunShoot" != null)
						{
							if ("NetworkGunShoot" != null)
							{
								return;
							}
						}
						else
						{
							string name = Ԇ\u05EB\u0608\u0598.name;
							if (name == null || name != null)
							{
								string text3 = string.Concat(values);
								return;
							}
						}
					}
				}
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060008D5 RID: 2261 RVA: 0x0002FF8C File Offset: 0x0002E18C
	[Token(Token = "0x60008D5")]
	[Address(RVA = "0x2B62DE4", Offset = "0x2B62DE4", VA = "0x2B62DE4")]
	private void Ӊӈ\u0589\u061D(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008D6 RID: 2262 RVA: 0x0002FFA0 File Offset: 0x0002E1A0
	[Token(Token = "0x60008D6")]
	[Address(RVA = "0x2B62DEC", Offset = "0x2B62DEC", VA = "0x2B62DEC")]
	public void մݩ\u05CA\u07A8(RoomInfo Ԇ\u05EB\u0608\u0598)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = Ԇ\u05EB\u0608\u0598;
		string[] values = new string[7];
		if ("goDownRPC" != null)
		{
			if ("goDownRPC" != null)
			{
				return;
			}
		}
		else
		{
			int <PlayerCount>k__BackingField = Ԇ\u05EB\u0608\u0598.<PlayerCount>k__BackingField;
			string text;
			if (text == null || text != null)
			{
				if ("Vector1_d371bd24217449349bd747533d51af6b" != null)
				{
					if ("Vector1_d371bd24217449349bd747533d51af6b" != null)
					{
						return;
					}
				}
				else
				{
					byte maxPlayers = Ԇ\u05EB\u0608\u0598.maxPlayers;
					string text2;
					if (text2 == null || text2 != null)
					{
						if ("TurnAmount" != null)
						{
							if ("TurnAmount" != null)
							{
								return;
							}
						}
						else
						{
							string name = Ԇ\u05EB\u0608\u0598.name;
							if (name == null || name != null)
							{
								string text3 = string.Concat(values);
								return;
							}
						}
					}
				}
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060008D7 RID: 2263 RVA: 0x0003003C File Offset: 0x0002E23C
	[Token(Token = "0x60008D7")]
	[Address(RVA = "0x2B6307C", Offset = "0x2B6307C", VA = "0x2B6307C")]
	public RoomInfo Շࡋݏܮ()
	{
		return this.<ه\u07BB\u089Fݚ>k__BackingField;
	}

	// Token: 0x060008D8 RID: 2264 RVA: 0x00030050 File Offset: 0x0002E250
	[Token(Token = "0x60008D8")]
	[Address(RVA = "0x2B63084", Offset = "0x2B63084", VA = "0x2B63084")]
	public void Ղ\u055Eշࡋ()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x060008D9 RID: 2265 RVA: 0x00030074 File Offset: 0x0002E274
	[Token(Token = "0x60008D9")]
	[Address(RVA = "0x2B60C30", Offset = "0x2B60C30", VA = "0x2B60C30")]
	public void Ԗ\u060Eߠ\u0872()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x060008DA RID: 2266 RVA: 0x00030098 File Offset: 0x0002E298
	[Token(Token = "0x60008DA")]
	[Address(RVA = "0x2B60D9C", Offset = "0x2B60D9C", VA = "0x2B60D9C")]
	public void \u07AAԲװؽ()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x060008DB RID: 2267 RVA: 0x000300BC File Offset: 0x0002E2BC
	[Token(Token = "0x60008DB")]
	[Address(RVA = "0x2B630FC", Offset = "0x2B630FC", VA = "0x2B630FC")]
	public void ڶ\u06E4\u083Aӿ()
	{
		RoomInfo <ه_u07BB_u089Fݚ>k__BackingField = this.<ه\u07BB\u089Fݚ>k__BackingField;
		string name = <ه_u07BB_u089Fݚ>k__BackingField.name;
		if (<ه_u07BB_u089Fݚ>k__BackingField == null)
		{
		}
	}

	// Token: 0x060008DC RID: 2268 RVA: 0x000300E0 File Offset: 0x0002E2E0
	[Token(Token = "0x60008DC")]
	[Address(RVA = "0x2B63174", Offset = "0x2B63174", VA = "0x2B63174")]
	private void ө\u0734ࢶ\u05F4(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
		this.<ه\u07BB\u089Fݚ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x060008DD RID: 2269 RVA: 0x000300F4 File Offset: 0x0002E2F4
	[Token(Token = "0x60008DD")]
	[Address(RVA = "0x2B6317C", Offset = "0x2B6317C", VA = "0x2B6317C")]
	private void \u05C9Ԗԅډ(RoomInfo \u05FB\u05AB\u0739ڑ)
	{
	}

	// Token: 0x060008DE RID: 2270 RVA: 0x00030104 File Offset: 0x0002E304
	[Token(Token = "0x60008DE")]
	[Address(RVA = "0x2B63184", Offset = "0x2B63184", VA = "0x2B63184")]
	public RoomListing()
	{
	}

	// Token: 0x04000120 RID: 288
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000120")]
	public Text يو\u0709ۃ;
}
