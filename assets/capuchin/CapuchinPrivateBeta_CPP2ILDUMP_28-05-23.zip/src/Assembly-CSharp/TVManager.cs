﻿using System;
using System.Collections;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;
using UnityEngine.Video;

// Token: 0x020000E9 RID: 233
[Token(Token = "0x20000E9")]
public class TVManager : MonoBehaviour
{
	// Token: 0x060023E8 RID: 9192 RVA: 0x000BCD88 File Offset: 0x000BAF88
	[Token(Token = "0x60023E8")]
	[Address(RVA = "0x285EBD8", Offset = "0x285EBD8", VA = "0x285EBD8")]
	public IEnumerator \u05FAٻܚ\u0654()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023E9 RID: 9193 RVA: 0x000BCDAC File Offset: 0x000BAFAC
	[Token(Token = "0x60023E9")]
	[Address(RVA = "0x285EC50", Offset = "0x285EC50", VA = "0x285EC50")]
	public void \u0654ޛ\u07FAذ()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.\u0830ࡌ\u081A\u0593();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "DisableCosmetic" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x060023EA RID: 9194 RVA: 0x000BCE74 File Offset: 0x000BB074
	[Token(Token = "0x60023EA")]
	[Address(RVA = "0x285EEA4", Offset = "0x285EEA4", VA = "0x285EEA4")]
	public IEnumerator \u06EBࡃՄؽ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023EB RID: 9195 RVA: 0x000BCE98 File Offset: 0x000BB098
	[Token(Token = "0x60023EB")]
	[Address(RVA = "0x285EF1C", Offset = "0x285EF1C", VA = "0x285EF1C")]
	public void \u05F7ԝߠӱ()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.\u06E4ࢧߗ\u085A();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "Tagging" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x060023EC RID: 9196 RVA: 0x000BCF60 File Offset: 0x000BB160
	[Token(Token = "0x60023EC")]
	[Address(RVA = "0x285F0F8", Offset = "0x285F0F8", VA = "0x285F0F8")]
	public void ԣԭՋࠏ()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.\u083Cԃڇݾ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "Display Name Changed!" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x060023ED RID: 9197 RVA: 0x000BD028 File Offset: 0x000BB228
	[Token(Token = "0x60023ED")]
	[Address(RVA = "0x285F2D4", Offset = "0x285F2D4", VA = "0x285F2D4")]
	public IEnumerator ӏӼڹܞ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x060023EE RID: 9198 RVA: 0x000BD044 File Offset: 0x000BB244
	[Token(Token = "0x60023EE")]
	[Address(RVA = "0x285F34C", Offset = "0x285F34C", VA = "0x285F34C")]
	public void \u055Cࢯܯ\u0898()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.\u0895\u081Aܩ\u0823();
			Coroutine coroutine = base.StartCoroutine(routine);
			long u0870Զ_u0657ܣ = 1L;
			this.\u0870Զ\u0657ܣ = (u0870Զ_u0657ܣ != 0L);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "Holdable" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x060023EF RID: 9199 RVA: 0x000BD118 File Offset: 0x000BB318
	[Token(Token = "0x60023EF")]
	[Address(RVA = "0x285F5A4", Offset = "0x285F5A4", VA = "0x285F5A4")]
	public void ݱ\u0832ݥ\u08B5()
	{
		IEnumerator enumerator = this.\u05FAٻܚ\u0654();
	}

	// Token: 0x060023F0 RID: 9200 RVA: 0x000BD12C File Offset: 0x000BB32C
	[Token(Token = "0x60023F0")]
	[Address(RVA = "0x285F5D0", Offset = "0x285F5D0", VA = "0x285F5D0")]
	public void \u0652\u058Bک\u061C()
	{
		IEnumerator routine = this.ܞӈټ\u0890();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060023F1 RID: 9201 RVA: 0x000BD148 File Offset: 0x000BB348
	[Token(Token = "0x60023F1")]
	[Address(RVA = "0x285F674", Offset = "0x285F674", VA = "0x285F674")]
	public IEnumerator ئړڇ\u05B8()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023F2 RID: 9202 RVA: 0x000BD16C File Offset: 0x000BB36C
	[Token(Token = "0x60023F2")]
	[Address(RVA = "0x285F6EC", Offset = "0x285F6EC", VA = "0x285F6EC")]
	public void طӏܙࢺ()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.ޤࡋ\u0608ף();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string text = num2.ToString();
		string text3;
		string text2 = text3 + "Room Name: " + text3;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x060023F3 RID: 9203 RVA: 0x000BD238 File Offset: 0x000BB438
	[Token(Token = "0x60023F3")]
	[Address(RVA = "0x285F940", Offset = "0x285F940", VA = "0x285F940")]
	public void \u0886Ҽ\u058Dߛ()
	{
		if (true)
		{
		}
		int num;
		string text = num.ToString();
	}

	// Token: 0x060023F4 RID: 9204 RVA: 0x000BD268 File Offset: 0x000BB468
	[Token(Token = "0x60023F4")]
	[Address(RVA = "0x285FB1C", Offset = "0x285FB1C", VA = "0x285FB1C")]
	public IEnumerator ߉Ԝժࢮ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023F5 RID: 9205 RVA: 0x000BD28C File Offset: 0x000BB48C
	[Token(Token = "0x60023F5")]
	[Address(RVA = "0x285FB94", Offset = "0x285FB94", VA = "0x285FB94")]
	public void הԥ\u05B5ݴ()
	{
		IEnumerator routine = this.Ӳࠔڝ߁();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060023F6 RID: 9206 RVA: 0x000BD2A8 File Offset: 0x000BB4A8
	[Token(Token = "0x60023F6")]
	[Address(RVA = "0x285FC38", Offset = "0x285FC38", VA = "0x285FC38")]
	public IEnumerator Ԧւׯ\u073A()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x060023F7 RID: 9207 RVA: 0x000BD2C4 File Offset: 0x000BB4C4
	[Token(Token = "0x60023F7")]
	[Address(RVA = "0x285FCB0", Offset = "0x285FCB0", VA = "0x285FCB0")]
	public IEnumerator ࡦ\u074B\u086Dܫ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023F8 RID: 9208 RVA: 0x000BD2E8 File Offset: 0x000BB4E8
	[Token(Token = "0x60023F8")]
	[Address(RVA = "0x285FD28", Offset = "0x285FD28", VA = "0x285FD28")]
	public IEnumerator \u07F7ޜߨٽ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023F9 RID: 9209 RVA: 0x000BD30C File Offset: 0x000BB50C
	[Token(Token = "0x60023F9")]
	[Address(RVA = "0x285FDA0", Offset = "0x285FDA0", VA = "0x285FDA0")]
	public void Update()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.\u05FAٻܚ\u0654();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "/" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x060023FA RID: 9210 RVA: 0x000BD3D4 File Offset: 0x000BB5D4
	[Token(Token = "0x60023FA")]
	[Address(RVA = "0x285FF04", Offset = "0x285FF04", VA = "0x285FF04")]
	public void ࡊ\u0592\u07AB\u05B2()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.\u06EBࡃՄؽ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "clickLol" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x060023FB RID: 9211 RVA: 0x000BD49C File Offset: 0x000BB69C
	[Token(Token = "0x60023FB")]
	[Address(RVA = "0x285F4B4", Offset = "0x285F4B4", VA = "0x285F4B4")]
	public IEnumerator \u0895\u081Aܩ\u0823()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023FC RID: 9212 RVA: 0x000BD4C0 File Offset: 0x000BB6C0
	[Token(Token = "0x60023FC")]
	[Address(RVA = "0x285F080", Offset = "0x285F080", VA = "0x285F080")]
	public IEnumerator \u06E4ࢧߗ\u085A()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023FD RID: 9213 RVA: 0x000BD4E4 File Offset: 0x000BB6E4
	[Token(Token = "0x60023FD")]
	[Address(RVA = "0x2860068", Offset = "0x2860068", VA = "0x2860068")]
	public void ٴݵۃ\u05AF()
	{
		if (true)
		{
			IEnumerator routine = this.\u05FAٻܚ\u0654();
			Coroutine coroutine = base.StartCoroutine(routine);
			long u0870Զ_u0657ܣ = 1L;
			this.\u0870Զ\u0657ܣ = (u0870Զ_u0657ܣ != 0L);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "Player" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x060023FE RID: 9214 RVA: 0x000BD5B4 File Offset: 0x000BB7B4
	[Token(Token = "0x60023FE")]
	[Address(RVA = "0x28601D0", Offset = "0x28601D0", VA = "0x28601D0")]
	public void \u05C8\u05BFࠁف()
	{
		IEnumerator routine = this.Ծߜ۱ԉ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060023FF RID: 9215 RVA: 0x000BD5D0 File Offset: 0x000BB7D0
	[Token(Token = "0x60023FF")]
	[Address(RVA = "0x2860274", Offset = "0x2860274", VA = "0x2860274")]
	public void ࡅݐ\u082Dք()
	{
		IEnumerator routine = this.ڑ\u0885\u06E0א();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002400 RID: 9216 RVA: 0x000BD5EC File Offset: 0x000BB7EC
	[Token(Token = "0x6002400")]
	[Address(RVA = "0x2860318", Offset = "0x2860318", VA = "0x2860318")]
	public void \u060B\u0614\u0821ע()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.٩۰ࠄڎ();
			Coroutine coroutine = base.StartCoroutine(routine);
			long u0870Զ_u0657ܣ = 1L;
			this.\u0870Զ\u0657ܣ = (u0870Զ_u0657ܣ != 0L);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "True" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x06002401 RID: 9217 RVA: 0x000BD6C0 File Offset: 0x000BB8C0
	[Token(Token = "0x6002401")]
	[Address(RVA = "0x2860480", Offset = "0x2860480", VA = "0x2860480")]
	public void ى߁ٱՏ()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.߉Ԝժࢮ();
			Coroutine coroutine = base.StartCoroutine(routine);
			long u0870Զ_u0657ܣ = 1L;
			this.\u0870Զ\u0657ܣ = (u0870Զ_u0657ܣ != 0L);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "Is Colliding" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x06002402 RID: 9218 RVA: 0x000BD794 File Offset: 0x000BB994
	[Token(Token = "0x6002402")]
	[Address(RVA = "0x285F52C", Offset = "0x285F52C", VA = "0x285F52C")]
	public IEnumerator \u07ACࢯ\u0618\u065A()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002403 RID: 9219 RVA: 0x000BD7B8 File Offset: 0x000BB9B8
	[Token(Token = "0x6002403")]
	[Address(RVA = "0x2860660", Offset = "0x2860660", VA = "0x2860660")]
	public void \u06EDٵ۶\u06DB()
	{
		IEnumerator enumerator = this.ࠑݙ\u0837נ();
	}

	// Token: 0x06002404 RID: 9220 RVA: 0x000BD7CC File Offset: 0x000BB9CC
	[Token(Token = "0x6002404")]
	[Address(RVA = "0x2860704", Offset = "0x2860704", VA = "0x2860704")]
	public void \u07A8Ӥթݠ()
	{
		IEnumerator routine = this.ݡ\u086D\u070E߈();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002405 RID: 9221 RVA: 0x000BD7E8 File Offset: 0x000BB9E8
	[Token(Token = "0x6002405")]
	[Address(RVA = "0x28607A8", Offset = "0x28607A8", VA = "0x28607A8")]
	public void Գӿېչ()
	{
		IEnumerator routine = this.ܜ\u0731\u0831\u0746();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002406 RID: 9222 RVA: 0x000BD804 File Offset: 0x000BBA04
	[Token(Token = "0x6002406")]
	[Address(RVA = "0x286084C", Offset = "0x286084C", VA = "0x286084C")]
	public void \u05F6\u05A6ӓ\u06DC()
	{
		IEnumerator routine = this.\u083Cԃڇݾ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002407 RID: 9223 RVA: 0x000BD820 File Offset: 0x000BBA20
	[Token(Token = "0x6002407")]
	[Address(RVA = "0x2860878", Offset = "0x2860878", VA = "0x2860878")]
	public void ࡎ\u05C2սࠇ()
	{
		IEnumerator routine = this.چ\u07B8հߌ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002408 RID: 9224 RVA: 0x000BD83C File Offset: 0x000BBA3C
	[Token(Token = "0x6002408")]
	[Address(RVA = "0x28605E8", Offset = "0x28605E8", VA = "0x28605E8")]
	public IEnumerator ءըށ\u08B5()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002409 RID: 9225 RVA: 0x000BD860 File Offset: 0x000BBA60
	[Token(Token = "0x6002409")]
	[Address(RVA = "0x286091C", Offset = "0x286091C", VA = "0x286091C")]
	public void ןٮ\u061FԺ()
	{
		IEnumerator routine = this.ӏӼڹܞ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600240A RID: 9226 RVA: 0x000BD87C File Offset: 0x000BBA7C
	[Token(Token = "0x600240A")]
	[Address(RVA = "0x2860948", Offset = "0x2860948", VA = "0x2860948")]
	public IEnumerator Ճ\u088B\u0839ܭ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600240B RID: 9227 RVA: 0x000BD8A0 File Offset: 0x000BBAA0
	[Token(Token = "0x600240B")]
	[Address(RVA = "0x28609C0", Offset = "0x28609C0", VA = "0x28609C0")]
	public void \u0881ݗӟ\u07BD()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.ߨ\u05F7ࡊԶ();
			Coroutine coroutine = base.StartCoroutine(routine);
			long u0870Զ_u0657ܣ = 1L;
			this.\u0870Զ\u0657ܣ = (u0870Զ_u0657ܣ != 0L);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "Wear Hoodie" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x0600240C RID: 9228 RVA: 0x000BD974 File Offset: 0x000BBB74
	[Token(Token = "0x600240C")]
	[Address(RVA = "0x2860BA0", Offset = "0x2860BA0", VA = "0x2860BA0")]
	public void Ҿࢹؼס()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.Ԧւׯ\u073A();
			Coroutine coroutine = base.StartCoroutine(routine);
			long u0870Զ_u0657ܣ = 1L;
			this.\u0870Զ\u0657ܣ = (u0870Զ_u0657ܣ != 0L);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "FingerTip" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x0600240D RID: 9229 RVA: 0x000BDA40 File Offset: 0x000BBC40
	[Token(Token = "0x600240D")]
	[Address(RVA = "0x2860D08", Offset = "0x2860D08", VA = "0x2860D08")]
	public IEnumerator ܗ\u07B8\u0640۹()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600240E RID: 9230 RVA: 0x000BDA64 File Offset: 0x000BBC64
	[Token(Token = "0x600240E")]
	[Address(RVA = "0x28602A0", Offset = "0x28602A0", VA = "0x28602A0")]
	public IEnumerator ڑ\u0885\u06E0א()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600240F RID: 9231 RVA: 0x000BDA88 File Offset: 0x000BBC88
	[Token(Token = "0x600240F")]
	[Address(RVA = "0x2860D80", Offset = "0x2860D80", VA = "0x2860D80")]
	public void Ҽ\u08B5ځ\u0658()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.\u083Cԃڇݾ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "gamemode" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x06002410 RID: 9232 RVA: 0x000BDB50 File Offset: 0x000BBD50
	[Token(Token = "0x6002410")]
	[Address(RVA = "0x2860730", Offset = "0x2860730", VA = "0x2860730")]
	public IEnumerator ݡ\u086D\u070E߈()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002411 RID: 9233 RVA: 0x000BDB74 File Offset: 0x000BBD74
	[Token(Token = "0x6002411")]
	[Address(RVA = "0x2860EE4", Offset = "0x2860EE4", VA = "0x2860EE4")]
	public void \u0599ږࠆ\u065F()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.ܜ\u0731\u0831\u0746();
			Coroutine coroutine = base.StartCoroutine(routine);
			long u0870Զ_u0657ܣ = 1L;
			this.\u0870Զ\u0657ܣ = (u0870Զ_u0657ܣ != 0L);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "Diffuse" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x06002412 RID: 9234 RVA: 0x000BDC48 File Offset: 0x000BBE48
	[Token(Token = "0x6002412")]
	[Address(RVA = "0x285FBC0", Offset = "0x285FBC0", VA = "0x285FBC0")]
	public IEnumerator Ӳࠔڝ߁()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002413 RID: 9235 RVA: 0x000BDC6C File Offset: 0x000BBE6C
	[Token(Token = "0x6002413")]
	[Address(RVA = "0x286104C", Offset = "0x286104C", VA = "0x286104C")]
	public void ދ\u05A3\u06DCہ()
	{
		IEnumerator routine = this.שނۇޤ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002414 RID: 9236 RVA: 0x000BDC88 File Offset: 0x000BBE88
	[Token(Token = "0x6002414")]
	[Address(RVA = "0x2860B28", Offset = "0x2860B28", VA = "0x2860B28")]
	public IEnumerator ߨ\u05F7ࡊԶ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002415 RID: 9237 RVA: 0x000BDCAC File Offset: 0x000BBEAC
	[Token(Token = "0x6002415")]
	[Address(RVA = "0x28610F0", Offset = "0x28610F0", VA = "0x28610F0")]
	public void \u05ABࡡ\u07ABݾ()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.߉Ԝժࢮ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		string str;
		string text = Mathf.RoundToInt((float)u07ADދ_u061AӒ).ToString() + "Vector1_d371bd24217449349bd747533d51af6b" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x06002416 RID: 9238 RVA: 0x000BDD68 File Offset: 0x000BBF68
	[Token(Token = "0x6002416")]
	[Address(RVA = "0x2861254", Offset = "0x2861254", VA = "0x2861254")]
	public void Start()
	{
		IEnumerator routine = this.\u05FAٻܚ\u0654();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002417 RID: 9239 RVA: 0x000BDD84 File Offset: 0x000BBF84
	[Token(Token = "0x6002417")]
	[Address(RVA = "0x2861280", Offset = "0x2861280", VA = "0x2861280")]
	public void گ\u085E\u073Dڊ()
	{
		IEnumerator routine = this.\u0895\u081Aܩ\u0823();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002418 RID: 9240 RVA: 0x000BDDA0 File Offset: 0x000BBFA0
	[Token(Token = "0x6002418")]
	[Address(RVA = "0x286068C", Offset = "0x286068C", VA = "0x286068C")]
	public IEnumerator ࠑݙ\u0837נ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002419 RID: 9241 RVA: 0x000BDDC4 File Offset: 0x000BBFC4
	[Token(Token = "0x6002419")]
	[Address(RVA = "0x2861078", Offset = "0x2861078", VA = "0x2861078")]
	public IEnumerator שނۇޤ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600241A RID: 9242 RVA: 0x000BDDE8 File Offset: 0x000BBFE8
	[Token(Token = "0x600241A")]
	[Address(RVA = "0x28612AC", Offset = "0x28612AC", VA = "0x28612AC")]
	public IEnumerator \u0640ߦաԲ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600241B RID: 9243 RVA: 0x000BDE0C File Offset: 0x000BC00C
	[Token(Token = "0x600241B")]
	[Address(RVA = "0x2861324", Offset = "0x2861324", VA = "0x2861324")]
	public void \u086Bԍࡊڭ()
	{
		IEnumerator routine = this.ԛޤב٣();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600241C RID: 9244 RVA: 0x000BDE28 File Offset: 0x000BC028
	[Token(Token = "0x600241C")]
	[Address(RVA = "0x28613C8", Offset = "0x28613C8", VA = "0x28613C8")]
	public IEnumerator \u0605\u0746٣ݾ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600241D RID: 9245 RVA: 0x000BDE4C File Offset: 0x000BC04C
	[Token(Token = "0x600241D")]
	[Address(RVA = "0x2861440", Offset = "0x2861440", VA = "0x2861440")]
	public void \u0872މࢮՃ()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.ݮֆ\u07B2ڢ();
			Coroutine coroutine = base.StartCoroutine(routine);
			long u0870Զ_u0657ܣ = 1L;
			this.\u0870Զ\u0657ܣ = (u0870Զ_u0657ܣ != 0L);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "Count of rooms " + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x0600241E RID: 9246 RVA: 0x000BDF14 File Offset: 0x000BC114
	[Token(Token = "0x600241E")]
	[Address(RVA = "0x28615A8", Offset = "0x28615A8", VA = "0x28615A8")]
	public void ޙߍ\u081A\u0651()
	{
		IEnumerator routine = this.ءըށ\u08B5();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600241F RID: 9247 RVA: 0x000BDF30 File Offset: 0x000BC130
	[Token(Token = "0x600241F")]
	[Address(RVA = "0x28615D4", Offset = "0x28615D4", VA = "0x28615D4")]
	public void \u0836\u089Dی\u0735()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.ܞӈټ\u0890();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		int num2 = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "1BN" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x06002420 RID: 9248 RVA: 0x000BDFF0 File Offset: 0x000BC1F0
	[Token(Token = "0x6002420")]
	[Address(RVA = "0x2861738", Offset = "0x2861738", VA = "0x2861738")]
	public void \u066A\u059Eټ\u085A()
	{
		IEnumerator routine = this.\u06EBࡃՄؽ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002421 RID: 9249 RVA: 0x000BE00C File Offset: 0x000BC20C
	[Token(Token = "0x6002421")]
	[Address(RVA = "0x28607D4", Offset = "0x28607D4", VA = "0x28607D4")]
	public IEnumerator ܜ\u0731\u0831\u0746()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002422 RID: 9250 RVA: 0x000BE030 File Offset: 0x000BC230
	[Token(Token = "0x6002422")]
	[Address(RVA = "0x2861764", Offset = "0x2861764", VA = "0x2861764")]
	public void ո\u07AA\u05BDࠕ()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.\u06EBࡃՄؽ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "hh:mmtt" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x06002423 RID: 9251 RVA: 0x000BE0F8 File Offset: 0x000BC2F8
	[Token(Token = "0x6002423")]
	[Address(RVA = "0x285F850", Offset = "0x285F850", VA = "0x285F850")]
	public IEnumerator ޤࡋ\u0608ף()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002424 RID: 9252 RVA: 0x000BE11C File Offset: 0x000BC31C
	[Token(Token = "0x6002424")]
	[Address(RVA = "0x285FAA4", Offset = "0x285FAA4", VA = "0x285FAA4")]
	public IEnumerator پٵ\u07FBӀ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002425 RID: 9253 RVA: 0x000BE140 File Offset: 0x000BC340
	[Token(Token = "0x6002425")]
	[Address(RVA = "0x28618C8", Offset = "0x28618C8", VA = "0x28618C8")]
	public void \u058EԸس\u0819()
	{
		IEnumerator routine = this.پٵ\u07FBӀ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002426 RID: 9254 RVA: 0x000BE15C File Offset: 0x000BC35C
	[Token(Token = "0x6002426")]
	[Address(RVA = "0x285EDB4", Offset = "0x285EDB4", VA = "0x285EDB4")]
	public IEnumerator \u0830ࡌ\u081A\u0593()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002427 RID: 9255 RVA: 0x000BE180 File Offset: 0x000BC380
	[Token(Token = "0x6002427")]
	[Address(RVA = "0x28601FC", Offset = "0x28601FC", VA = "0x28601FC")]
	public IEnumerator Ծߜ۱ԉ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002428 RID: 9256 RVA: 0x000BE1A4 File Offset: 0x000BC3A4
	[Token(Token = "0x6002428")]
	[Address(RVA = "0x285F8C8", Offset = "0x285F8C8", VA = "0x285F8C8")]
	public IEnumerator ٩۰ࠄڎ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002429 RID: 9257 RVA: 0x000BE1C8 File Offset: 0x000BC3C8
	[Token(Token = "0x6002429")]
	[Address(RVA = "0x28618F4", Offset = "0x28618F4", VA = "0x28618F4")]
	public void Ջއٵյ()
	{
		IEnumerator routine = this.\u0895\u081Aܩ\u0823();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600242A RID: 9258 RVA: 0x000BE1E4 File Offset: 0x000BC3E4
	[Token(Token = "0x600242A")]
	[Address(RVA = "0x285F25C", Offset = "0x285F25C", VA = "0x285F25C")]
	public IEnumerator \u083Cԃڇݾ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600242B RID: 9259 RVA: 0x000BE208 File Offset: 0x000BC408
	[Token(Token = "0x600242B")]
	[Address(RVA = "0x2861920", Offset = "0x2861920", VA = "0x2861920")]
	public void \u0832ࢳޤ\u07B5()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.ڑ\u0885\u06E0א();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "trol" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x0600242C RID: 9260 RVA: 0x000BE2D0 File Offset: 0x000BC4D0
	[Token(Token = "0x600242C")]
	[Address(RVA = "0x2861A84", Offset = "0x2861A84", VA = "0x2861A84")]
	public void ࢭ\u0589\u0892\u058A()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.Ԧւׯ\u073A();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num.ToString() + "ChangeToRegular" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x0600242D RID: 9261 RVA: 0x000BE38C File Offset: 0x000BC58C
	[Token(Token = "0x600242D")]
	[Address(RVA = "0x2861BE8", Offset = "0x2861BE8", VA = "0x2861BE8")]
	public IEnumerator ࡂࡂ\u06E4ݗ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600242E RID: 9262 RVA: 0x000BE3B0 File Offset: 0x000BC5B0
	[Token(Token = "0x600242E")]
	[Address(RVA = "0x2861C60", Offset = "0x2861C60", VA = "0x2861C60")]
	public TVManager()
	{
	}

	// Token: 0x0600242F RID: 9263 RVA: 0x000BE3C4 File Offset: 0x000BC5C4
	[Token(Token = "0x600242F")]
	[Address(RVA = "0x2861C68", Offset = "0x2861C68", VA = "0x2861C68")]
	public void ࢶ٠\u086D\u0708()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.٩۰ࠄڎ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "Connected to Server." + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x06002430 RID: 9264 RVA: 0x000BE48C File Offset: 0x000BC68C
	[Token(Token = "0x6002430")]
	[Address(RVA = "0x2861350", Offset = "0x2861350", VA = "0x2861350")]
	public IEnumerator ԛޤב٣()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002431 RID: 9265 RVA: 0x000BE4B0 File Offset: 0x000BC6B0
	[Token(Token = "0x6002431")]
	[Address(RVA = "0x285EE2C", Offset = "0x285EE2C", VA = "0x285EE2C")]
	public IEnumerator ݮֆ\u07B2ڢ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002432 RID: 9266 RVA: 0x000BE4D4 File Offset: 0x000BC6D4
	[Token(Token = "0x6002432")]
	[Address(RVA = "0x28608A4", Offset = "0x28608A4", VA = "0x28608A4")]
	public IEnumerator چ\u07B8հߌ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002433 RID: 9267 RVA: 0x000BE4F8 File Offset: 0x000BC6F8
	[Token(Token = "0x6002433")]
	[Address(RVA = "0x2861DCC", Offset = "0x2861DCC", VA = "0x2861DCC")]
	public IEnumerator \u07BBפ\u05F7ժ()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002434 RID: 9268 RVA: 0x000BE51C File Offset: 0x000BC71C
	[Token(Token = "0x6002434")]
	[Address(RVA = "0x2861E44", Offset = "0x2861E44", VA = "0x2861E44")]
	public IEnumerator \u06DFۑࡋף()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002435 RID: 9269 RVA: 0x000BE540 File Offset: 0x000BC740
	[Token(Token = "0x6002435")]
	[Address(RVA = "0x285F5FC", Offset = "0x285F5FC", VA = "0x285F5FC")]
	public IEnumerator ܞӈټ\u0890()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 0L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002436 RID: 9270 RVA: 0x000BE564 File Offset: 0x000BC764
	[Token(Token = "0x6002436")]
	[Address(RVA = "0x2861EBC", Offset = "0x2861EBC", VA = "0x2861EBC")]
	public IEnumerator \u05CCӤߍ\u055F()
	{
		long <>1__state;
		TVManager.ݧյؿࠍ ݧյؿࠍ = new TVManager.ݧյؿࠍ((int)<>1__state);
		<>1__state = 1L;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002437 RID: 9271 RVA: 0x000BE588 File Offset: 0x000BC788
	[Token(Token = "0x6002437")]
	[Address(RVA = "0x2861F34", Offset = "0x2861F34", VA = "0x2861F34")]
	public void ԅ\u073Fڥ\u0839()
	{
		if (this.\u0870Զ\u0657ܣ)
		{
			IEnumerator routine = this.\u06EBࡃՄؽ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
		double u083D_u055C_u05C0_u06EB = this.\u083D\u055C\u05C0\u06EB;
		int num = Mathf.RoundToInt((float)u083D_u055C_u05C0_u06EB);
		double u07ADދ_u061AӒ = this.\u07ADދ\u061AӒ;
		int num2 = Mathf.RoundToInt((float)u07ADދ_u061AӒ);
		TextMeshPro ҿڑ_u07FC_u = this.ҿڑ\u07FC\u0613;
		string str;
		string text = num2.ToString() + "False" + str;
		bool u05A3Ԃ_u064Cآ = this.\u05A3Ԃ\u064Cآ;
		VideoPlayer ࡘ_u07AF_u0597Դ = this.ࡘ\u07AF\u0597Դ;
		if (u05A3Ԃ_u064Cآ)
		{
			VideoClip u086BԪ_u0557ڿ = this.\u086BԪ\u0557ڿ;
			ࡘ_u07AF_u0597Դ.clip = u086BԪ_u0557ڿ;
			return;
		}
		bool isPlaying = ࡘ_u07AF_u0597Դ.isPlaying;
		double u083D_u055C_u05C0_u06EB2 = this.\u083D\u055C\u05C0\u06EB;
		float deltaTime = Time.deltaTime;
		this.\u083D\u055C\u05C0\u06EB = (double)deltaTime;
	}

	// Token: 0x06002438 RID: 9272 RVA: 0x000BE650 File Offset: 0x000BC850
	[Token(Token = "0x6002438")]
	[Address(RVA = "0x2862098", Offset = "0x2862098", VA = "0x2862098")]
	public void \u07EBࠎיࡂ()
	{
		IEnumerator routine = this.Ճ\u088B\u0839ܭ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002439 RID: 9273 RVA: 0x000BE66C File Offset: 0x000BC86C
	[Token(Token = "0x6002439")]
	[Address(RVA = "0x28620C4", Offset = "0x28620C4", VA = "0x28620C4")]
	public void ࠏޤݳ\u06DD()
	{
		IEnumerator routine = this.ԛޤב٣();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600243A RID: 9274 RVA: 0x000BE688 File Offset: 0x000BC888
	[Token(Token = "0x600243A")]
	[Address(RVA = "0x28620F0", Offset = "0x28620F0", VA = "0x28620F0")]
	public IEnumerator ݱߩ\u05ECژ()
	{
		TVManager.ݧյؿࠍ ݧյؿࠍ;
		ݧյؿࠍ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x04000480 RID: 1152
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000480")]
	public VideoPlayer ࡘ\u07AF\u0597Դ;

	// Token: 0x04000481 RID: 1153
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000481")]
	public VideoClip[] ࡐޒԹߧ;

	// Token: 0x04000482 RID: 1154
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000482")]
	public VideoClip \u086BԪ\u0557ڿ;

	// Token: 0x04000483 RID: 1155
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000483")]
	public bool \u05A3Ԃ\u064Cآ;

	// Token: 0x04000484 RID: 1156
	[FieldOffset(Offset = "0x31")]
	[Token(Token = "0x4000484")]
	public bool \u0870Զ\u0657ܣ;

	// Token: 0x04000485 RID: 1157
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000485")]
	public double \u07ADދ\u061AӒ;

	// Token: 0x04000486 RID: 1158
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000486")]
	public double \u083D\u055C\u05C0\u06EB;

	// Token: 0x04000487 RID: 1159
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000487")]
	public TextMeshPro ҿڑ\u07FC\u0613;
}
