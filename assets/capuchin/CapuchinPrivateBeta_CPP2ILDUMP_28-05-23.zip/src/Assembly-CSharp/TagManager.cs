﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Locomotion;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000010 RID: 16
[Token(Token = "0x2000010")]
public class TagManager : MonoBehaviourPun
{
	// Token: 0x0600020D RID: 525 RVA: 0x00010794 File Offset: 0x0000E994
	[Token(Token = "0x600020D")]
	[Address(RVA = "0x28692C0", Offset = "0x28692C0", VA = "0x28692C0")]
	private void څࡣڐ\u0657()
	{
		if (this.ٮ\u086B\u073Fۃ)
		{
			if (!this.\u06E6\u085F\u083C\u05CB)
			{
				AudioSource ֆ_u0616ߑն = this.Ֆ\u0616ߑն;
				AudioClip u05FD_u07AFٯ߃ = this.\u05FD\u07AFٯ߃;
				ֆ_u0616ߑն.PlayOneShot(u05FD_u07AFٯ߃);
				IEnumerator routine = Player.كݕ\u05F3\u0589.\u07AE\u073F\u07B7ݵ();
				Coroutine coroutine = base.StartCoroutine(routine);
				long u06E6_u085F_u083C_u05CB = 1L;
				this.\u06E6\u085F\u083C\u05CB = (u06E6_u085F_u083C_u05CB != 0L);
			}
			ParticleSystem[] u05B4ٲࢭԞ = this.\u05B4ٲࢭԞ;
			return;
		}
		ParticleSystem[] u05B4ٲࢭԞ2 = this.\u05B4ٲࢭԞ;
		if (this.\u06E6\u085F\u083C\u05CB)
		{
		}
	}

	// Token: 0x0600020E RID: 526 RVA: 0x0001080C File Offset: 0x0000EA0C
	[Token(Token = "0x600020E")]
	[Address(RVA = "0x28693BC", Offset = "0x28693BC", VA = "0x28693BC")]
	public void \u086CܝՍ\u0884(bool \u07A7Հ\u06E4ք)
	{
		do
		{
			base.gameObject.tag = "True";
			Renderer[] bodyParts = this.BodyParts;
			TeamSettings teamSettings = this.ࢣԝՎڲ;
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600020F RID: 527 RVA: 0x00010858 File Offset: 0x0000EA58
	[Token(Token = "0x600020F")]
	[Address(RVA = "0x28694CC", Offset = "0x28694CC", VA = "0x28694CC")]
	private void \u070Aәޣے()
	{
		if (this.ٮ\u086B\u073Fۃ)
		{
			if (!this.\u06E6\u085F\u083C\u05CB)
			{
				AudioSource ֆ_u0616ߑն = this.Ֆ\u0616ߑն;
				AudioClip u05FD_u07AFٯ߃ = this.\u05FD\u07AFٯ߃;
				ֆ_u0616ߑն.PlayOneShot(u05FD_u07AFٯ߃);
				IEnumerator routine = Player.كݕ\u05F3\u0589.\u07B7וզӖ();
				Coroutine coroutine = base.StartCoroutine(routine);
			}
			ParticleSystem[] u05B4ٲࢭԞ = this.\u05B4ٲࢭԞ;
			return;
		}
		ParticleSystem[] u05B4ٲࢭԞ2 = this.\u05B4ٲࢭԞ;
		if (this.\u06E6\u085F\u083C\u05CB)
		{
			long u06E6_u085F_u083C_u05CB = 1L;
			this.\u06E6\u085F\u083C\u05CB = (u06E6_u085F_u083C_u05CB != 0L);
		}
	}

	// Token: 0x06000210 RID: 528 RVA: 0x000108D0 File Offset: 0x0000EAD0
	[Token(Token = "0x6000210")]
	[Address(RVA = "0x28695CC", Offset = "0x28695CC", VA = "0x28695CC")]
	[PunRPC]
	public void ChangeToRegular()
	{
		do
		{
			base.gameObject.tag = "Regular";
			Renderer[] bodyParts = this.BodyParts;
			Material reg = this.ࢣԝՎڲ.Reg;
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000211 RID: 529 RVA: 0x00010924 File Offset: 0x0000EB24
	[Token(Token = "0x6000211")]
	[Address(RVA = "0x28696DC", Offset = "0x28696DC", VA = "0x28696DC")]
	private void \u05EDց\u081Cت()
	{
		if (this.ٮ\u086B\u073Fۃ)
		{
			if (!this.\u06E6\u085F\u083C\u05CB)
			{
				AudioSource ֆ_u0616ߑն = this.Ֆ\u0616ߑն;
				AudioClip u05FD_u07AFٯ߃ = this.\u05FD\u07AFٯ߃;
				ֆ_u0616ߑն.PlayOneShot(u05FD_u07AFٯ߃);
				IEnumerator routine = Player.كݕ\u05F3\u0589.ޥӜՕ\u0558();
				Coroutine coroutine = base.StartCoroutine(routine);
				long u06E6_u085F_u083C_u05CB = 1L;
				this.\u06E6\u085F\u083C\u05CB = (u06E6_u085F_u083C_u05CB != 0L);
			}
			ParticleSystem[] u05B4ٲࢭԞ = this.\u05B4ٲࢭԞ;
			return;
		}
		ParticleSystem[] u05B4ٲࢭԞ2 = this.\u05B4ٲࢭԞ;
		if (this.\u06E6\u085F\u083C\u05CB)
		{
			long u06E6_u085F_u083C_u05CB2 = 1L;
			this.\u06E6\u085F\u083C\u05CB = (u06E6_u085F_u083C_u05CB2 != 0L);
		}
	}

	// Token: 0x06000212 RID: 530 RVA: 0x000109A4 File Offset: 0x0000EBA4
	[Token(Token = "0x6000212")]
	[Address(RVA = "0x28697E0", Offset = "0x28697E0", VA = "0x28697E0")]
	public void ױ\u058Dݽ\u055D()
	{
		GameObject gameObject = base.gameObject;
	}

	// Token: 0x06000213 RID: 531 RVA: 0x000109EC File Offset: 0x0000EBEC
	[Token(Token = "0x6000213")]
	[Address(RVA = "0x28698D0", Offset = "0x28698D0", VA = "0x28698D0")]
	public void ڴՅ\u087Cھ(bool \u07A7Հ\u06E4ք)
	{
		do
		{
			base.gameObject.tag = "DisableCosmetic";
			Renderer[] bodyParts = this.BodyParts;
			TeamSettings teamSettings = this.ࢣԝՎڲ;
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000214 RID: 532 RVA: 0x00010A3C File Offset: 0x0000EC3C
	[Token(Token = "0x6000214")]
	[Address(RVA = "0x28699E0", Offset = "0x28699E0", VA = "0x28699E0")]
	[PunRPC]
	public void ChangeToTagged(bool \u07A7Հ\u06E4ք)
	{
		do
		{
			base.gameObject.tag = "Tagged";
			Renderer[] bodyParts = this.BodyParts;
			TeamSettings teamSettings = this.ࢣԝՎڲ;
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000215 RID: 533 RVA: 0x00010A94 File Offset: 0x0000EC94
	[Token(Token = "0x6000215")]
	[Address(RVA = "0x2869AF4", Offset = "0x2869AF4", VA = "0x2869AF4")]
	public void ڃࡓ\u058Cߝ(bool \u07A7Հ\u06E4ք)
	{
		do
		{
			base.gameObject.tag = "Right Hand";
			Renderer[] bodyParts = this.BodyParts;
			TeamSettings teamSettings = this.ࢣԝՎڲ;
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000216 RID: 534 RVA: 0x00010AEC File Offset: 0x0000ECEC
	[Token(Token = "0x6000216")]
	[Address(RVA = "0x2869C08", Offset = "0x2869C08", VA = "0x2869C08")]
	private void Update()
	{
		if (this.ٮ\u086B\u073Fۃ)
		{
			if (!this.\u06E6\u085F\u083C\u05CB)
			{
				AudioSource ֆ_u0616ߑն = this.Ֆ\u0616ߑն;
				AudioClip u05FD_u07AFٯ߃ = this.\u05FD\u07AFٯ߃;
				ֆ_u0616ߑն.PlayOneShot(u05FD_u07AFٯ߃);
				IEnumerator routine = Player.كݕ\u05F3\u0589.\u07B7וզӖ();
				Coroutine coroutine = base.StartCoroutine(routine);
				long u06E6_u085F_u083C_u05CB = 1L;
				this.\u06E6\u085F\u083C\u05CB = (u06E6_u085F_u083C_u05CB != 0L);
			}
			ParticleSystem[] u05B4ٲࢭԞ = this.\u05B4ٲࢭԞ;
			return;
		}
		ParticleSystem[] u05B4ٲࢭԞ2 = this.\u05B4ٲࢭԞ;
		if (this.\u06E6\u085F\u083C\u05CB)
		{
		}
	}

	// Token: 0x06000217 RID: 535 RVA: 0x00010B64 File Offset: 0x0000ED64
	[Token(Token = "0x6000217")]
	[Address(RVA = "0x2869D04", Offset = "0x2869D04", VA = "0x2869D04")]
	private void \u05F7ԝߠӱ()
	{
		if (this.ٮ\u086B\u073Fۃ)
		{
			if (!this.\u06E6\u085F\u083C\u05CB)
			{
				AudioSource ֆ_u0616ߑն = this.Ֆ\u0616ߑն;
				AudioClip u05FD_u07AFٯ߃ = this.\u05FD\u07AFٯ߃;
				ֆ_u0616ߑն.PlayOneShot(u05FD_u07AFٯ߃);
				IEnumerator routine;
				Coroutine coroutine = base.StartCoroutine(routine);
			}
			ParticleSystem[] u05B4ٲࢭԞ = this.\u05B4ٲࢭԞ;
			return;
		}
		ParticleSystem[] u05B4ٲࢭԞ2 = this.\u05B4ٲࢭԞ;
		if (this.\u06E6\u085F\u083C\u05CB)
		{
			long u06E6_u085F_u083C_u05CB = 1L;
			this.\u06E6\u085F\u083C\u05CB = (u06E6_u085F_u083C_u05CB != 0L);
		}
	}

	// Token: 0x06000218 RID: 536 RVA: 0x00010BD0 File Offset: 0x0000EDD0
	[Token(Token = "0x6000218")]
	[Address(RVA = "0x2869E00", Offset = "0x2869E00", VA = "0x2869E00")]
	private void \u0654ޛ\u07FAذ()
	{
		bool ٮ_u086B_u073Fۃ = this.ٮ\u086B\u073Fۃ;
		if (ٮ_u086B_u073Fۃ)
		{
			if (!ٮ_u086B_u073Fۃ)
			{
				AudioClip u05FD_u07AFٯ߃ = this.\u05FD\u07AFٯ߃;
				IEnumerator routine = Player.كݕ\u05F3\u0589.ݺݛޱؼ();
				Coroutine coroutine = base.StartCoroutine(routine);
				long u06E6_u085F_u083C_u05CB = 1L;
				this.\u06E6\u085F\u083C\u05CB = (u06E6_u085F_u083C_u05CB != 0L);
			}
			ParticleSystem[] u05B4ٲࢭԞ = this.\u05B4ٲࢭԞ;
			return;
		}
		ParticleSystem[] u05B4ٲࢭԞ2 = this.\u05B4ٲࢭԞ;
		if (this.\u06E6\u085F\u083C\u05CB)
		{
			long u06E6_u085F_u083C_u05CB2 = 1L;
			this.\u06E6\u085F\u083C\u05CB = (u06E6_u085F_u083C_u05CB2 != 0L);
		}
	}

	// Token: 0x06000219 RID: 537 RVA: 0x00010C40 File Offset: 0x0000EE40
	[Token(Token = "0x6000219")]
	[Address(RVA = "0x2869F04", Offset = "0x2869F04", VA = "0x2869F04")]
	public void \u066Bܫ\u05AC٤(bool \u07A7Հ\u06E4ք)
	{
		do
		{
			base.gameObject.tag = "Not connected to room";
			Renderer[] bodyParts = this.BodyParts;
			TeamSettings teamSettings = this.ࢣԝՎڲ;
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600021A RID: 538 RVA: 0x00010C8C File Offset: 0x0000EE8C
	[Token(Token = "0x600021A")]
	[Address(RVA = "0x286A014", Offset = "0x286A014", VA = "0x286A014")]
	public void ܦ\u0614թף(bool \u07A7Հ\u06E4ք)
	{
		do
		{
			base.gameObject.tag = "HOLY MOLY THE STICK IS ON FIRE!!!!!!";
			Renderer[] bodyParts = this.BodyParts;
			TeamSettings teamSettings = this.ࢣԝՎڲ;
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600021B RID: 539 RVA: 0x00010CD8 File Offset: 0x0000EED8
	[Token(Token = "0x600021B")]
	[Address(RVA = "0x286A124", Offset = "0x286A124", VA = "0x286A124")]
	public void Ձ\u07ED۰\u0873(bool \u07A7Հ\u06E4ք)
	{
		do
		{
			base.gameObject.tag = "Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
			Renderer[] bodyParts = this.BodyParts;
			TeamSettings teamSettings = this.ࢣԝՎڲ;
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600021C RID: 540 RVA: 0x00010D24 File Offset: 0x0000EF24
	[Token(Token = "0x600021C")]
	[Address(RVA = "0x286A234", Offset = "0x286A234", VA = "0x286A234")]
	public TagManager()
	{
	}

	// Token: 0x0600021D RID: 541 RVA: 0x00010D38 File Offset: 0x0000EF38
	[Token(Token = "0x600021D")]
	[Address(RVA = "0x286A23C", Offset = "0x286A23C", VA = "0x286A23C")]
	public void \u088Fࡦߖ\u064C()
	{
		base.gameObject.tag = "FingerTip";
	}

	// Token: 0x0600021E RID: 542 RVA: 0x00010D88 File Offset: 0x0000EF88
	[Token(Token = "0x600021E")]
	[Address(RVA = "0x286A32C", Offset = "0x286A32C", VA = "0x286A32C")]
	private void \u0881ݗӟ\u07BD()
	{
		if (this.ٮ\u086B\u073Fۃ)
		{
			if (!this.\u06E6\u085F\u083C\u05CB)
			{
				AudioClip u05FD_u07AFٯ߃ = this.\u05FD\u07AFٯ߃;
				IEnumerator routine = Player.كݕ\u05F3\u0589.س۳ݳ\u05B1();
				Coroutine coroutine = base.StartCoroutine(routine);
			}
			ParticleSystem[] u05B4ٲࢭԞ = this.\u05B4ٲࢭԞ;
			return;
		}
		ParticleSystem[] u05B4ٲࢭԞ2 = this.\u05B4ٲࢭԞ;
		if (this.\u06E6\u085F\u083C\u05CB)
		{
		}
	}

	// Token: 0x0600021F RID: 543 RVA: 0x00010DE4 File Offset: 0x0000EFE4
	[Token(Token = "0x600021F")]
	[Address(RVA = "0x286A42C", Offset = "0x286A42C", VA = "0x286A42C")]
	public void ݝԻ\u05C9ࢦ(bool \u07A7Հ\u06E4ք)
	{
		base.gameObject.tag = "On";
	}

	// Token: 0x04000042 RID: 66
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000042")]
	[SerializeField]
	[Header("Player Info")]
	private Renderer[] BodyParts;

	// Token: 0x04000043 RID: 67
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000043")]
	public bool ٮ\u086B\u073Fۃ;

	// Token: 0x04000044 RID: 68
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000044")]
	public TeamSettings ࢣԝՎڲ;

	// Token: 0x04000045 RID: 69
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000045")]
	public AudioSource Ֆ\u0616ߑն;

	// Token: 0x04000046 RID: 70
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000046")]
	public AudioClip \u05FD\u07AFٯ߃;

	// Token: 0x04000047 RID: 71
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000047")]
	public ParticleSystem[] \u05B4ٲࢭԞ;

	// Token: 0x04000048 RID: 72
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000048")]
	private bool \u06E6\u085F\u083C\u05CB;
}
