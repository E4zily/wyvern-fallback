﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

// Token: 0x020000CB RID: 203
[Token(Token = "0x20000CB")]
public class MusicManager : MonoBehaviour
{
	// Token: 0x06001F02 RID: 7938 RVA: 0x000A10D8 File Offset: 0x0009F2D8
	[Token(Token = "0x6001F02")]
	[Address(RVA = "0x23B88E4", Offset = "0x23B88E4", VA = "0x23B88E4")]
	public void \u066D\u05BDې߃()
	{
		AudioClip.PCMReaderCallback pcmreaderCallback = this.ࡖࡓԺ\u0870.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F03 RID: 7939 RVA: 0x000A1128 File Offset: 0x0009F328
	[Token(Token = "0x6001F03")]
	[Address(RVA = "0x23B897C", Offset = "0x23B897C", VA = "0x23B897C")]
	public void ݤۅࢦӃ()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		if (ࡖࡓԺ_u.m_PCMReaderCallback != null)
		{
			AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
			AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
			AudioSource u0617_u087Fտߎ2 = this.\u0617\u087Fտߎ;
			long u0654_u05B6_u05A2_u = 1L;
			this.\u0654\u05B6\u05A2\u0823 = (byte)u0654_u05B6_u05A2_u;
			u0617_u087Fտߎ2.Play();
			string[] u085Dߓۋذ = this.\u085Dߓۋذ;
			byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
			TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
			return;
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x06001F04 RID: 7940 RVA: 0x000A1190 File Offset: 0x0009F390
	[Token(Token = "0x6001F04")]
	[Address(RVA = "0x23B8A14", Offset = "0x23B8A14", VA = "0x23B8A14")]
	public void \u0749ӭ۳\u0612()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		byte ݸ_u07F9ࠓࡈ = this.ݸ\u07F9ࠓࡈ;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.LogWarning("back");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001F05 RID: 7941 RVA: 0x000A11CC File Offset: 0x0009F3CC
	[Token(Token = "0x6001F05")]
	[Address(RVA = "0x23B8B74", Offset = "0x23B8B74", VA = "0x23B8B74")]
	public void ژ\u073F\u0594փ()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F06 RID: 7942 RVA: 0x000A122C File Offset: 0x0009F42C
	[Token(Token = "0x6001F06")]
	[Address(RVA = "0x23B8C10", Offset = "0x23B8C10", VA = "0x23B8C10")]
	[PunRPC]
	public void StartLastSong()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F07 RID: 7943 RVA: 0x000A1294 File Offset: 0x0009F494
	[Token(Token = "0x6001F07")]
	[Address(RVA = "0x23B8CB8", Offset = "0x23B8CB8", VA = "0x23B8CB8")]
	public void ڜիࠂԈ()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F08 RID: 7944 RVA: 0x000A12F4 File Offset: 0x0009F4F4
	[Token(Token = "0x6001F08")]
	[Address(RVA = "0x23B8D54", Offset = "0x23B8D54", VA = "0x23B8D54")]
	public void Ԅ\u06D8ԧۻ()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F09 RID: 7945 RVA: 0x000A1354 File Offset: 0x0009F554
	[Token(Token = "0x6001F09")]
	[Address(RVA = "0x23B8DFC", Offset = "0x23B8DFC", VA = "0x23B8DFC")]
	public void \u0838ӆڛӑ()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "Starting to bake textures on frame " + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.\u0749ӭ۳\u0612();
			long u0734_u064EԷࡆ = 1L;
			this.\u0734\u064EԷࡆ = (u0734_u064EԷࡆ != 0L);
		}
	}

	// Token: 0x06001F0A RID: 7946 RVA: 0x000A1394 File Offset: 0x0009F594
	[Token(Token = "0x6001F0A")]
	[Address(RVA = "0x23B8E9C", Offset = "0x23B8E9C", VA = "0x23B8E9C")]
	public void \u0732ڙԒࢺ()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "StartSong" + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.ԯ\u061Bە\u05FB();
			long u0734_u064EԷࡆ = 1L;
			this.\u0734\u064EԷࡆ = (u0734_u064EԷࡆ != 0L);
		}
	}

	// Token: 0x06001F0B RID: 7947 RVA: 0x000A13D4 File Offset: 0x0009F5D4
	[Token(Token = "0x6001F0B")]
	[Address(RVA = "0x23B90A0", Offset = "0x23B90A0", VA = "0x23B90A0")]
	public void ޞࠊޚڌ()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F0C RID: 7948 RVA: 0x000A1434 File Offset: 0x0009F634
	[Token(Token = "0x6001F0C")]
	[Address(RVA = "0x23B913C", Offset = "0x23B913C", VA = "0x23B913C")]
	public void ߒ\u065EՎࡖ()
	{
		AudioClip.PCMReaderCallback pcmreaderCallback = this.ࡖࡓԺ\u0870.m_PCMReaderCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F0D RID: 7949 RVA: 0x000A147C File Offset: 0x0009F67C
	[Token(Token = "0x6001F0D")]
	[Address(RVA = "0x23B91D4", Offset = "0x23B91D4", VA = "0x23B91D4")]
	public void נݿࡤ\u0884()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F0E RID: 7950 RVA: 0x000A14E4 File Offset: 0x0009F6E4
	[Token(Token = "0x6001F0E")]
	[Address(RVA = "0x23B927C", Offset = "0x23B927C", VA = "0x23B927C")]
	public void \u066B\u0607ڻ\u0703()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		byte ݸ_u07F9ࠓࡈ = this.ݸ\u07F9ࠓࡈ;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.LogWarning("isLava");
		long u0654_u05B6_u05A2_u2 = 1L;
		this.\u0654\u05B6\u05A2\u0823 = (byte)u0654_u05B6_u05A2_u2;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001F0F RID: 7951 RVA: 0x000A1528 File Offset: 0x0009F728
	[Token(Token = "0x6001F0F")]
	[Address(RVA = "0x23B93E0", Offset = "0x23B93E0", VA = "0x23B93E0")]
	public void ݫ\u0658ӥ\u0598()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F10 RID: 7952 RVA: 0x000A1588 File Offset: 0x0009F788
	[Token(Token = "0x6001F10")]
	[Address(RVA = "0x23B947C", Offset = "0x23B947C", VA = "0x23B947C")]
	public void Փشߦխ()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F11 RID: 7953 RVA: 0x000A15E8 File Offset: 0x0009F7E8
	[Token(Token = "0x6001F11")]
	[Address(RVA = "0x23B9518", Offset = "0x23B9518", VA = "0x23B9518")]
	public void ۰Շ\u05EB۱()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		byte ݸ_u07F9ࠓࡈ = this.ݸ\u07F9ࠓࡈ;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.LogWarning("Round end");
		long u0654_u05B6_u05A2_u2 = 1L;
		this.\u0654\u05B6\u05A2\u0823 = (byte)u0654_u05B6_u05A2_u2;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001F12 RID: 7954 RVA: 0x000A162C File Offset: 0x0009F82C
	[Token(Token = "0x6001F12")]
	[Address(RVA = "0x23B967C", Offset = "0x23B967C", VA = "0x23B967C")]
	[PunRPC]
	public void StartSong()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F13 RID: 7955 RVA: 0x000A1694 File Offset: 0x0009F894
	[Token(Token = "0x6001F13")]
	[Address(RVA = "0x23B9724", Offset = "0x23B9724", VA = "0x23B9724")]
	public void \u087BӦןݩ()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "DisableCosmetic" + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.ޛݡ\u0859ٶ();
		}
	}

	// Token: 0x06001F14 RID: 7956 RVA: 0x000A16C8 File Offset: 0x0009F8C8
	[Token(Token = "0x6001F14")]
	[Address(RVA = "0x23B9924", Offset = "0x23B9924", VA = "0x23B9924")]
	public void ݸԲ\u0616Ԫ()
	{
		AudioClip.PCMReaderCallback pcmreaderCallback = this.ࡖࡓԺ\u0870.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioSource u0617_u087Fտߎ2 = this.\u0617\u087Fտߎ;
		long u0654_u05B6_u05A2_u = 1L;
		this.\u0654\u05B6\u05A2\u0823 = (byte)u0654_u05B6_u05A2_u;
		u0617_u087Fտߎ2.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F15 RID: 7957 RVA: 0x000A1724 File Offset: 0x0009F924
	[Token(Token = "0x6001F15")]
	[Address(RVA = "0x23B99C0", Offset = "0x23B99C0", VA = "0x23B99C0")]
	public void ޅ\u0825פ\u05AA()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F16 RID: 7958 RVA: 0x000A178C File Offset: 0x0009F98C
	[Token(Token = "0x6001F16")]
	[Address(RVA = "0x23B9A68", Offset = "0x23B9A68", VA = "0x23B9A68")]
	public void كҼ\u05F7گ()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F17 RID: 7959 RVA: 0x000A17EC File Offset: 0x0009F9EC
	[Token(Token = "0x6001F17")]
	[Address(RVA = "0x23B9B04", Offset = "0x23B9B04", VA = "0x23B9B04")]
	public void Ҿࢹؼס()
	{
		string str;
		string text = "Players: " + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.\u07F0וک\u073D();
			long u0734_u064EԷࡆ = 1L;
			this.\u0734\u064EԷࡆ = (u0734_u064EԷࡆ != 0L);
		}
	}

	// Token: 0x06001F18 RID: 7960 RVA: 0x000A1824 File Offset: 0x0009FA24
	[Token(Token = "0x6001F18")]
	[Address(RVA = "0x23B9D08", Offset = "0x23B9D08", VA = "0x23B9D08")]
	public void ࠒ\u088Bԥ\u0838()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F19 RID: 7961 RVA: 0x000A188C File Offset: 0x0009FA8C
	[Token(Token = "0x6001F19")]
	[Address(RVA = "0x23B9DB0", Offset = "0x23B9DB0", VA = "0x23B9DB0")]
	public void \u06DFհӈސ()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F1A RID: 7962 RVA: 0x000A18F4 File Offset: 0x0009FAF4
	[Token(Token = "0x6001F1A")]
	[Address(RVA = "0x23B9E58", Offset = "0x23B9E58", VA = "0x23B9E58")]
	public void \u05C4ݳ\u05BCࡂ()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "Tagged" + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.ץ٩Ո\u064C();
			long u0734_u064EԷࡆ = 1L;
			this.\u0734\u064EԷࡆ = (u0734_u064EԷࡆ != 0L);
		}
	}

	// Token: 0x06001F1B RID: 7963 RVA: 0x000A1934 File Offset: 0x0009FB34
	[Token(Token = "0x6001F1B")]
	[Address(RVA = "0x23BA058", Offset = "0x23BA058", VA = "0x23BA058")]
	public void طӏܙࢺ()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "{0} ({1})" + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.۰Շ\u05EB۱();
			long u0734_u064EԷࡆ = 1L;
			this.\u0734\u064EԷࡆ = (u0734_u064EԷࡆ != 0L);
		}
	}

	// Token: 0x06001F1C RID: 7964 RVA: 0x000A1974 File Offset: 0x0009FB74
	[Token(Token = "0x6001F1C")]
	[Address(RVA = "0x23BA0F8", Offset = "0x23BA0F8", VA = "0x23BA0F8")]
	public void ո\u07AA\u05BDࠕ()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "TurnAmount" + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.\u0749ӭ۳\u0612();
			long u0734_u064EԷࡆ = 1L;
			this.\u0734\u064EԷࡆ = (u0734_u064EԷࡆ != 0L);
		}
	}

	// Token: 0x06001F1D RID: 7965 RVA: 0x000A19B4 File Offset: 0x0009FBB4
	[Token(Token = "0x6001F1D")]
	[Address(RVA = "0x23BA198", Offset = "0x23BA198", VA = "0x23BA198")]
	public void \u05C9\u0558\u058Eڭ()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F1E RID: 7966 RVA: 0x000A1A1C File Offset: 0x0009FC1C
	[Token(Token = "0x6001F1E")]
	[Address(RVA = "0x23BA240", Offset = "0x23BA240", VA = "0x23BA240")]
	public void \u0706ݥקࢹ()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F1F RID: 7967 RVA: 0x000A1A84 File Offset: 0x0009FC84
	[Token(Token = "0x6001F1F")]
	[Address(RVA = "0x23BA2E8", Offset = "0x23BA2E8", VA = "0x23BA2E8")]
	public void \u061Fࡆ\u086F\u07B0()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "NGNNoSound" + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.\u07F0וک\u073D();
			long u0734_u064EԷࡆ = 1L;
			this.\u0734\u064EԷࡆ = (u0734_u064EԷࡆ != 0L);
		}
	}

	// Token: 0x06001F20 RID: 7968 RVA: 0x000A1AC4 File Offset: 0x0009FCC4
	[Token(Token = "0x6001F20")]
	[Address(RVA = "0x23BA388", Offset = "0x23BA388", VA = "0x23BA388")]
	public void \u0881ݗӟ\u07BD()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "Player" + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.\u066B\u0607ڻ\u0703();
			long u0734_u064EԷࡆ = 1L;
			this.\u0734\u064EԷࡆ = (u0734_u064EԷࡆ != 0L);
		}
	}

	// Token: 0x06001F21 RID: 7969 RVA: 0x000A1B04 File Offset: 0x0009FD04
	[Token(Token = "0x6001F21")]
	[Address(RVA = "0x23BA428", Offset = "0x23BA428", VA = "0x23BA428")]
	public MusicManager()
	{
	}

	// Token: 0x06001F22 RID: 7970 RVA: 0x000A1B18 File Offset: 0x0009FD18
	[Token(Token = "0x6001F22")]
	[Address(RVA = "0x23BA430", Offset = "0x23BA430", VA = "0x23BA430")]
	public void Start()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		if (ࡖࡓԺ_u.m_PCMReaderCallback != null)
		{
			AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
			AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
			this.\u0617\u087Fտߎ.Play();
			string[] u085Dߓۋذ = this.\u085Dߓۋذ;
			byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
			TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
			return;
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x06001F23 RID: 7971 RVA: 0x000A1B70 File Offset: 0x0009FD70
	[Token(Token = "0x6001F23")]
	[Address(RVA = "0x23BA4C4", Offset = "0x23BA4C4", VA = "0x23BA4C4")]
	public void ձ\u0749ࡥތ()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F24 RID: 7972 RVA: 0x000A1BD8 File Offset: 0x0009FDD8
	[Token(Token = "0x6001F24")]
	[Address(RVA = "0x23B8F3C", Offset = "0x23B8F3C", VA = "0x23B8F3C")]
	public void ԯ\u061Bە\u05FB()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		byte ݸ_u07F9ࠓࡈ = this.ݸ\u07F9ࠓࡈ;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.LogWarning("FingerTip");
		long u0654_u05B6_u05A2_u2 = 1L;
		this.\u0654\u05B6\u05A2\u0823 = (byte)u0654_u05B6_u05A2_u2;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001F25 RID: 7973 RVA: 0x000A1C1C File Offset: 0x0009FE1C
	[Token(Token = "0x6001F25")]
	[Address(RVA = "0x23BA56C", Offset = "0x23BA56C", VA = "0x23BA56C")]
	public void չւت\u061E()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "On" + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.ԯ\u061Bە\u05FB();
		}
	}

	// Token: 0x06001F26 RID: 7974 RVA: 0x000A1C50 File Offset: 0x0009FE50
	[Token(Token = "0x6001F26")]
	[Address(RVA = "0x23BA608", Offset = "0x23BA608", VA = "0x23BA608")]
	public void \u0559ג۴\u06E7()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F27 RID: 7975 RVA: 0x000A1CB0 File Offset: 0x0009FEB0
	[Token(Token = "0x6001F27")]
	[Address(RVA = "0x23B9EF8", Offset = "0x23B9EF8", VA = "0x23B9EF8")]
	public void ץ٩Ո\u064C()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		byte ݸ_u07F9ࠓࡈ = this.ݸ\u07F9ࠓࡈ;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.LogWarning("All audio clips have been played.");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001F28 RID: 7976 RVA: 0x000A1CEC File Offset: 0x0009FEEC
	[Token(Token = "0x6001F28")]
	[Address(RVA = "0x23BA6A4", Offset = "0x23BA6A4", VA = "0x23BA6A4")]
	public void \u073C۰\u07F2\u0744()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F29 RID: 7977 RVA: 0x000A1D4C File Offset: 0x0009FF4C
	[Token(Token = "0x6001F29")]
	[Address(RVA = "0x23BA740", Offset = "0x23BA740", VA = "0x23BA740")]
	public void ܩחݵޔ()
	{
		AudioClip.PCMReaderCallback pcmreaderCallback = this.ࡖࡓԺ\u0870.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioSource u0617_u087Fտߎ2 = this.\u0617\u087Fտߎ;
		long u0654_u05B6_u05A2_u = 1L;
		this.\u0654\u05B6\u05A2\u0823 = (byte)u0654_u05B6_u05A2_u;
		u0617_u087Fտߎ2.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F2A RID: 7978 RVA: 0x000A1DA8 File Offset: 0x0009FFA8
	[Token(Token = "0x6001F2A")]
	[Address(RVA = "0x23BA7DC", Offset = "0x23BA7DC", VA = "0x23BA7DC")]
	public void ژךՈ\u0597()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "amongus" + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.\u066B\u0607ڻ\u0703();
			long u0734_u064EԷࡆ = 1L;
			this.\u0734\u064EԷࡆ = (u0734_u064EԷࡆ != 0L);
		}
	}

	// Token: 0x06001F2B RID: 7979 RVA: 0x000A1DE8 File Offset: 0x0009FFE8
	[Token(Token = "0x6001F2B")]
	[Address(RVA = "0x23BA87C", Offset = "0x23BA87C", VA = "0x23BA87C")]
	public void ԛԉԵل()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F2C RID: 7980 RVA: 0x000A1E50 File Offset: 0x000A0050
	[Token(Token = "0x6001F2C")]
	[Address(RVA = "0x23BA924", Offset = "0x23BA924", VA = "0x23BA924")]
	public void \u066B\u0883څߩ()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F2D RID: 7981 RVA: 0x000A1EB8 File Offset: 0x000A00B8
	[Token(Token = "0x6001F2D")]
	[Address(RVA = "0x23BA9CC", Offset = "0x23BA9CC", VA = "0x23BA9CC")]
	public void \u073BօӁ\u059A()
	{
		AudioClip.PCMReaderCallback pcmreaderCallback = this.ࡖࡓԺ\u0870.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F2E RID: 7982 RVA: 0x000A1F08 File Offset: 0x000A0108
	[Token(Token = "0x6001F2E")]
	[Address(RVA = "0x23BAA64", Offset = "0x23BAA64", VA = "0x23BAA64")]
	public void چ\u05AEךڰ()
	{
		AudioClip.PCMReaderCallback pcmreaderCallback = this.ࡖࡓԺ\u0870.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioSource u0617_u087Fտߎ2 = this.\u0617\u087Fտߎ;
		long u0654_u05B6_u05A2_u = 1L;
		this.\u0654\u05B6\u05A2\u0823 = (byte)u0654_u05B6_u05A2_u;
		u0617_u087Fտߎ2.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F2F RID: 7983 RVA: 0x000A1F64 File Offset: 0x000A0164
	[Token(Token = "0x6001F2F")]
	[Address(RVA = "0x23BAB00", Offset = "0x23BAB00", VA = "0x23BAB00")]
	public void Update()
	{
		TextMeshPro u07ADӇށӺ = this.\u07ADӇށӺ;
		string str;
		string text = "Song Index: " + str;
		if (this.\u0734\u064EԷࡆ)
		{
			this.ץ٩Ո\u064C();
		}
	}

	// Token: 0x06001F30 RID: 7984 RVA: 0x000A1F98 File Offset: 0x000A0198
	[Token(Token = "0x6001F30")]
	[Address(RVA = "0x23BAB9C", Offset = "0x23BAB9C", VA = "0x23BAB9C")]
	public void \u0654ޛ\u07FAذ()
	{
		string str;
		string text = "Joined Public Room Successfully" + str;
	}

	// Token: 0x06001F31 RID: 7985 RVA: 0x000A1FB8 File Offset: 0x000A01B8
	[Token(Token = "0x6001F31")]
	[Address(RVA = "0x23B97C0", Offset = "0x23B97C0", VA = "0x23B97C0")]
	public void ޛݡ\u0859ٶ()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		byte ݸ_u07F9ࠓࡈ = this.ݸ\u07F9ࠓࡈ;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.LogWarning("Player");
		long u0654_u05B6_u05A2_u2 = 1L;
		this.\u0654\u05B6\u05A2\u0823 = (byte)u0654_u05B6_u05A2_u2;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001F32 RID: 7986 RVA: 0x000A1FFC File Offset: 0x000A01FC
	[Token(Token = "0x6001F32")]
	[Address(RVA = "0x23BAC3C", Offset = "0x23BAC3C", VA = "0x23BAC3C")]
	public void \u0884ݾࠅࢠ()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		byte ݸ_u07F9ࠓࡈ = this.ݸ\u07F9ࠓࡈ;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.LogWarning("_BumpScale");
		long u0654_u05B6_u05A2_u2 = 1L;
		this.\u0654\u05B6\u05A2\u0823 = (byte)u0654_u05B6_u05A2_u2;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001F33 RID: 7987 RVA: 0x000A2040 File Offset: 0x000A0240
	[Token(Token = "0x6001F33")]
	[Address(RVA = "0x23BADA0", Offset = "0x23BADA0", VA = "0x23BADA0")]
	public void \u07BE\u05CEӔر()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		this.\u0654\u05B6\u05A2\u0823 = u0654_u05B6_u05A2_u;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x06001F34 RID: 7988 RVA: 0x000A20A8 File Offset: 0x000A02A8
	[Token(Token = "0x6001F34")]
	[Address(RVA = "0x23B9BA4", Offset = "0x23B9BA4", VA = "0x23B9BA4")]
	public void \u07F0וک\u073D()
	{
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		byte ݸ_u07F9ࠓࡈ = this.ݸ\u07F9ࠓࡈ;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.LogWarning("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
		long u0654_u05B6_u05A2_u2 = 1L;
		this.\u0654\u05B6\u05A2\u0823 = (byte)u0654_u05B6_u05A2_u2;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001F35 RID: 7989 RVA: 0x000A20EC File Offset: 0x000A02EC
	[Token(Token = "0x6001F35")]
	[Address(RVA = "0x23BAE48", Offset = "0x23BAE48", VA = "0x23BAE48")]
	public void ݦ\u0883\u07A8\u082B()
	{
		AudioClip[] ࡖࡓԺ_u = this.ࡖࡓԺ\u0870;
		byte u0654_u05B6_u05A2_u = this.\u0654\u05B6\u05A2\u0823;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡖࡓԺ_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMSetPositionCallback pcmsetPositionCallback = ࡖࡓԺ_u.m_PCMSetPositionCallback;
		this.\u0617\u087Fտߎ.Play();
		string[] u085Dߓۋذ = this.\u085Dߓۋذ;
		byte u0654_u05B6_u05A2_u2 = this.\u0654\u05B6\u05A2\u0823;
		TextMeshPro ۏԍ_u07B7_u = this.ۏԍ\u07B7\u0618;
	}

	// Token: 0x040003FB RID: 1019
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003FB")]
	public AudioSource \u0617\u087Fտߎ;

	// Token: 0x040003FC RID: 1020
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003FC")]
	public AudioClip[] ࡖࡓԺ\u0870;

	// Token: 0x040003FD RID: 1021
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003FD")]
	public string[] \u085Dߓۋذ;

	// Token: 0x040003FE RID: 1022
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003FE")]
	private byte \u0654\u05B6\u05A2\u0823;

	// Token: 0x040003FF RID: 1023
	[FieldOffset(Offset = "0x31")]
	[Token(Token = "0x40003FF")]
	public byte ݸ\u07F9ࠓࡈ;

	// Token: 0x04000400 RID: 1024
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000400")]
	public PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x04000401 RID: 1025
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000401")]
	public TextMeshPro ۏԍ\u07B7\u0618;

	// Token: 0x04000402 RID: 1026
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000402")]
	public TextMeshPro \u07ADӇށӺ;

	// Token: 0x04000403 RID: 1027
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000403")]
	public bool \u0734\u064EԷࡆ;

	// Token: 0x04000404 RID: 1028
	[FieldOffset(Offset = "0x51")]
	[Token(Token = "0x4000404")]
	public bool ߥݵԒւ;
}
