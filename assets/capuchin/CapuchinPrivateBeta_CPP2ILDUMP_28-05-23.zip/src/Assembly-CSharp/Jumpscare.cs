﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Locomotion;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200006D RID: 109
[Token(Token = "0x200006D")]
public class Jumpscare : MonoBehaviour
{
	// Token: 0x06000FDC RID: 4060 RVA: 0x0005AF94 File Offset: 0x00059194
	[Token(Token = "0x6000FDC")]
	[Address(RVA = "0x275DF44", Offset = "0x275DF44", VA = "0x275DF44")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("_WobbleZ");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		long active2 = 0L;
		this.Ӥ\u087Bݜ\u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("On");
	}

	// Token: 0x06000FDD RID: 4061 RVA: 0x0005B088 File Offset: 0x00059288
	[Token(Token = "0x6000FDD")]
	[Address(RVA = "0x275E1F0", Offset = "0x275E1F0", VA = "0x275E1F0")]
	public void פ\u0749Ԇ\u05A0()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Adding ");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("TurnAmount");
		Debug.Log("You Already Own This Item");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("CapuchinStore");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("\n");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("Player");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
	}

	// Token: 0x06000FDE RID: 4062 RVA: 0x0005B170 File Offset: 0x00059370
	[Token(Token = "0x6000FDE")]
	[Address(RVA = "0x275E400", Offset = "0x275E400", VA = "0x275E400")]
	public void ӗࡄ\u07B0ݪ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Count of rooms ");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("BN");
		Debug.Log("HorrorAgreement");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("HandL");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Stopped Colliding");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Debug.Log("typesOfTalk");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("ScoreCounter");
	}

	// Token: 0x06000FDF RID: 4063 RVA: 0x0005B264 File Offset: 0x00059464
	[Token(Token = "0x6000FDF")]
	[Address(RVA = "0x275E610", Offset = "0x275E610", VA = "0x275E610")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PURCHASED";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Round end");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("User is on an outdated version of Capuchin. Your version is ");
	}

	// Token: 0x06000FE0 RID: 4064 RVA: 0x0005B35C File Offset: 0x0005955C
	[Token(Token = "0x6000FE0")]
	[Address(RVA = "0x275E8E4", Offset = "0x275E8E4", VA = "0x275E8E4")]
	public void \u07FEӔԬߤ()
	{
		Debug.Log("DisableCosmetic");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Name Changing Error. Error: ");
		Debug.Log("PlayerHead");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("Joined a Room.");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("PlayerHead");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("got funky mone");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("On");
	}

	// Token: 0x06000FE1 RID: 4065 RVA: 0x0005B448 File Offset: 0x00059648
	[Token(Token = "0x6000FE1")]
	[Address(RVA = "0x275EAE0", Offset = "0x275EAE0", VA = "0x275EAE0")]
	public void \u0609ی\u055C\u0748()
	{
		if (!true)
		{
		}
		Debug.Log("HandL");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("_BaseMap");
		Debug.Log("Right Hand");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("Player");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Debug.Log("A new Player joined a Room.");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("ChangeToTagged");
	}

	// Token: 0x06000FE2 RID: 4066 RVA: 0x0005B538 File Offset: 0x00059738
	[Token(Token = "0x6000FE2")]
	[Address(RVA = "0x275ECF0", Offset = "0x275ECF0", VA = "0x275ECF0")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "\n Time: ";
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Count of rooms ");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Vector3 position3 = this.\u0704\u061D\u0824\u05F4.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("You have been banned for ");
	}

	// Token: 0x06000FE3 RID: 4067 RVA: 0x0005B610 File Offset: 0x00059810
	[Token(Token = "0x6000FE3")]
	[Address(RVA = "0x275EFC4", Offset = "0x275EFC4", VA = "0x275EFC4")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Calling success callback. baking meshes";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		long active = 1L;
		GameObject gameObject;
		gameObject.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log(". Please update you game to the latest version");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("CASUAL");
	}

	// Token: 0x06000FE4 RID: 4068 RVA: 0x0005B700 File Offset: 0x00059900
	[Token(Token = "0x6000FE4")]
	[Address(RVA = "0x275F298", Offset = "0x275F298", VA = "0x275F298")]
	public void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "trol";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("True");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("RightHandAttachPoint");
	}

	// Token: 0x06000FE5 RID: 4069 RVA: 0x0005B7F8 File Offset: 0x000599F8
	[Token(Token = "0x6000FE5")]
	[Address(RVA = "0x275F56C", Offset = "0x275F56C", VA = "0x275F56C")]
	public void Ԇݎ\u0614\u05C1()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("On");
		Debug.Log("1BN");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("Diffuse");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Is Colliding");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("goDownRPC");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("NetworkPlayer");
	}

	// Token: 0x06000FE6 RID: 4070 RVA: 0x0005B8EC File Offset: 0x00059AEC
	[Token(Token = "0x6000FE6")]
	[Address(RVA = "0x275F77C", Offset = "0x275F77C", VA = "0x275F77C")]
	public void ٶ\u0734ܙࡒ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("EnableCosmetic");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("CapuchinStore");
		Debug.Log("Joined a Room.");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log(". Please update you game to the latest version");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("FingerTip");
		Debug.Log("_Tint");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("BN");
	}

	// Token: 0x06000FE7 RID: 4071 RVA: 0x0005B9D4 File Offset: 0x00059BD4
	[Token(Token = "0x6000FE7")]
	[Address(RVA = "0x275F98C", Offset = "0x275F98C", VA = "0x275F98C")]
	public void ӈٹ\u074Bײ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("2BN");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Trigger");
		Debug.Log("Player");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("HDRP/Lit");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("ErrorScreen");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Debug.Log("Start Gamemode");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("");
	}

	// Token: 0x06000FE8 RID: 4072 RVA: 0x0005BAC8 File Offset: 0x00059CC8
	[Token(Token = "0x6000FE8")]
	[Address(RVA = "0x275FB9C", Offset = "0x275FB9C", VA = "0x275FB9C")]
	public void \u0612ܙ\u07AEڵ()
	{
		if (!true)
		{
		}
		Debug.Log("ErrorScreen");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("username");
		Debug.Log("EnableCosmetic");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("INSIGNIFICANT CURRENCY");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Body");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("isLava");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("True");
	}

	// Token: 0x06000FE9 RID: 4073 RVA: 0x0005BBB8 File Offset: 0x00059DB8
	[Token(Token = "0x6000FE9")]
	[Address(RVA = "0x275FDAC", Offset = "0x275FDAC", VA = "0x275FDAC")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FLSPTLT";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("hh:mm:sstt");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active2 = 1L;
		ܙߙ_u089Aػ.SetActive(active2 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("ORGPORT");
	}

	// Token: 0x06000FEA RID: 4074 RVA: 0x0005BC98 File Offset: 0x00059E98
	[Token(Token = "0x6000FEA")]
	[Address(RVA = "0x2760080", Offset = "0x2760080", VA = "0x2760080")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == ". Please update you game to the latest version";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("waited for your bullshit unity grrr");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("Open");
	}

	// Token: 0x06000FEB RID: 4075 RVA: 0x0005BD90 File Offset: 0x00059F90
	[Token(Token = "0x6000FEB")]
	[Address(RVA = "0x2760354", Offset = "0x2760354", VA = "0x2760354")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "This is the 5000 Bananas button, and it was just clicked";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("goDownRPC");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("Player");
	}

	// Token: 0x06000FEC RID: 4076 RVA: 0x0005BE88 File Offset: 0x0005A088
	[Token(Token = "0x6000FEC")]
	[Address(RVA = "0x2760628", Offset = "0x2760628", VA = "0x2760628")]
	public void \u05B2ڹܐ\u07F2()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("CapuchinRemade");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("\n");
		Debug.Log("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("Joined Public Room Successfully");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log(" hour. You were banned because of ");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("username");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		long isKinematic = 0L;
		this.ࢣ\u0822Ӹ\u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Hate Speech");
	}

	// Token: 0x06000FED RID: 4077 RVA: 0x0005BF78 File Offset: 0x0005A178
	[Token(Token = "0x6000FED")]
	[Address(RVA = "0x2760838", Offset = "0x2760838", VA = "0x2760838")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Room1";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("username");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("_WobbleX");
	}

	// Token: 0x06000FEE RID: 4078 RVA: 0x0005C070 File Offset: 0x0005A270
	[Token(Token = "0x6000FEE")]
	[Address(RVA = "0x2760B0C", Offset = "0x2760B0C", VA = "0x2760B0C")]
	public void ݙۋӃߌ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("isLava");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("tp 2");
		Debug.Log("_Tint");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("Count of rooms ");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Player");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Debug.Log("\tExpires: ");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Trigger");
	}

	// Token: 0x06000FEF RID: 4079 RVA: 0x0005C164 File Offset: 0x0005A364
	[Token(Token = "0x6000FEF")]
	[Address(RVA = "0x2760D1C", Offset = "0x2760D1C", VA = "0x2760D1C")]
	public void Ԃ\u058Aܫջ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "User has been reported for: ";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("CASUAL");
	}

	// Token: 0x06000FF0 RID: 4080 RVA: 0x0005C250 File Offset: 0x0005A450
	[Token(Token = "0x6000FF0")]
	[Address(RVA = "0x2760FDC", Offset = "0x2760FDC", VA = "0x2760FDC")]
	public void ٶՃܐࡕ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("token");
		long active2 = 0L;
		Debug.Log("hh:mm:sstt");
		this.Ӥ\u087Bݜ\u065F.SetActive(active2 != 0L);
		Debug.Log("monke screamed");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("A Player has left the Room.");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("gravThing");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("You Look Like Butt");
	}

	// Token: 0x06000FF1 RID: 4081 RVA: 0x0005C334 File Offset: 0x0005A534
	[Token(Token = "0x6000FF1")]
	[Address(RVA = "0x27611EC", Offset = "0x27611EC", VA = "0x27611EC")]
	public void ࢺճ\u05A0ڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Grip";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("_Tint");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("goUpRPC");
	}

	// Token: 0x06000FF2 RID: 4082 RVA: 0x0005C42C File Offset: 0x0005A62C
	[Token(Token = "0x6000FF2")]
	[Address(RVA = "0x27614C0", Offset = "0x27614C0", VA = "0x27614C0")]
	public void \u059B\u081F\u05FEڂ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Version";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if ("Version" == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Purchased: ");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("2BN");
	}

	// Token: 0x06000FF3 RID: 4083 RVA: 0x0005C524 File Offset: 0x0005A724
	[Token(Token = "0x6000FF3")]
	[Address(RVA = "0x2761794", Offset = "0x2761794", VA = "0x2761794")]
	public void \u0816ࠂՑࢴ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("ENABLE");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("FingerTip");
		Debug.Log("/");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("MetaId");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Not connected to room");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("Right Hand");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("procedural animation script required on ");
	}

	// Token: 0x06000FF4 RID: 4084 RVA: 0x0005C618 File Offset: 0x0005A818
	[Token(Token = "0x6000FF4")]
	[Address(RVA = "0x27619A4", Offset = "0x27619A4", VA = "0x27619A4")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Name Changing Error. Error: ";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("containsStaff");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("M/d/yyyy");
	}

	// Token: 0x06000FF5 RID: 4085 RVA: 0x0005C710 File Offset: 0x0005A910
	[Token(Token = "0x6000FF5")]
	[Address(RVA = "0x2761C78", Offset = "0x2761C78", VA = "0x2761C78")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "button";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("ORGPORT");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("User has been reported for: ");
	}

	// Token: 0x06000FF6 RID: 4086 RVA: 0x0005C7FC File Offset: 0x0005A9FC
	[Token(Token = "0x6000FF6")]
	[Address(RVA = "0x2761F4C", Offset = "0x2761F4C", VA = "0x2761F4C")]
	public void ۺ\u05FBߥ\u05F8()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		throw new MissingMethodException();
	}

	// Token: 0x06000FF7 RID: 4087 RVA: 0x0005C8D0 File Offset: 0x0005AAD0
	[Token(Token = "0x6000FF7")]
	[Address(RVA = "0x276215C", Offset = "0x276215C", VA = "0x276215C")]
	public void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Display Name Changed!";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("gamemode");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("gamemode");
	}

	// Token: 0x06000FF8 RID: 4088 RVA: 0x0005C9C8 File Offset: 0x0005ABC8
	[Token(Token = "0x6000FF8")]
	[Address(RVA = "0x2762430", Offset = "0x2762430", VA = "0x2762430")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Joined Public Room Successfully";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Round end");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		this.ܙߙ\u089Aػ.SetActive(active2 != 0L);
		Debug.Log("ChangeToTagged");
	}

	// Token: 0x06000FF9 RID: 4089 RVA: 0x0005CAB0 File Offset: 0x0005ACB0
	[Token(Token = "0x6000FF9")]
	[Address(RVA = "0x2762704", Offset = "0x2762704", VA = "0x2762704")]
	public void ӹڼ\u070Eԭ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("ENABLE");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Count of rooms ");
		Debug.Log("2BN");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("TurnAmount");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Player");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("HorrorAgreement");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = transform.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("hh:mmtt");
	}

	// Token: 0x06000FFA RID: 4090 RVA: 0x0005CB9C File Offset: 0x0005AD9C
	[Token(Token = "0x6000FFA")]
	[Address(RVA = "0x2762914", Offset = "0x2762914", VA = "0x2762914")]
	public void \u055Fسࢳҿ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("monke is not my monke");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Add/Remove Hat");
		Debug.Log("Add/Remove Hat");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("sound play stopped");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("CapuchinRemade");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Debug.Log("PURCHASED");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Vector3 position2 = this.ݼ\u05B5\u06E1\u0593.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Player");
	}

	// Token: 0x06000FFB RID: 4091 RVA: 0x0005CC84 File Offset: 0x0005AE84
	[Token(Token = "0x6000FFB")]
	[Address(RVA = "0x2762B24", Offset = "0x2762B24", VA = "0x2762B24")]
	public void \u0599\u05C5\u0831ݩ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("You Already Own This Item");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("INSIGNIFICANT CURRENCY");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("typesOfTalk");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("sound play stopped");
	}

	// Token: 0x06000FFC RID: 4092 RVA: 0x0005CD6C File Offset: 0x0005AF6C
	[Token(Token = "0x6000FFC")]
	[Address(RVA = "0x2762D34", Offset = "0x2762D34", VA = "0x2762D34")]
	public void ܗնسࡓ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("TurnAmount");
		Debug.Log("Regular");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("Universal Render Pipeline/Lit");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Error");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Debug.Log("false");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Player");
	}

	// Token: 0x06000FFD RID: 4093 RVA: 0x0005CE54 File Offset: 0x0005B054
	[Token(Token = "0x6000FFD")]
	[Address(RVA = "0x2762F44", Offset = "0x2762F44", VA = "0x2762F44")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		throw new MissingMethodException();
	}

	// Token: 0x06000FFE RID: 4094 RVA: 0x0005CF34 File Offset: 0x0005B134
	[Token(Token = "0x6000FFE")]
	[Address(RVA = "0x2763218", Offset = "0x2763218", VA = "0x2763218")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Right Hand";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Photon token acquired!");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("On");
	}

	// Token: 0x06000FFF RID: 4095 RVA: 0x0005D024 File Offset: 0x0005B224
	[Token(Token = "0x6000FFF")]
	[Address(RVA = "0x27634EC", Offset = "0x27634EC", VA = "0x27634EC")]
	public void يօӇ\u070D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "This is the 2500 Bananas button, and it was just clicked";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("KeyPos");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("\tExpires: ");
	}

	// Token: 0x06001000 RID: 4096 RVA: 0x0005D11C File Offset: 0x0005B31C
	[Token(Token = "0x6001000")]
	[Address(RVA = "0x27637C0", Offset = "0x27637C0", VA = "0x27637C0")]
	public void ࡩӼݯո()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Add/Remove Hat");
		Debug.Log("Player");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("amongus");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log(" and for the price of ");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("FingerTip");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("{0} ({1})");
	}

	// Token: 0x06001001 RID: 4097 RVA: 0x0005D204 File Offset: 0x0005B404
	[Token(Token = "0x6001001")]
	[Address(RVA = "0x27639D0", Offset = "0x27639D0", VA = "0x27639D0")]
	public void \u0611\u0883یࢦ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("EnableCosmetic");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("A Player has left the Room.");
		Debug.Log("FingerTip");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("clickLol");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("username");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Debug.Log("containsStaff");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("TurnAmount");
	}

	// Token: 0x06001002 RID: 4098 RVA: 0x0005D2F8 File Offset: 0x0005B4F8
	[Token(Token = "0x6001002")]
	[Address(RVA = "0x2763BE0", Offset = "0x2763BE0", VA = "0x2763BE0")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You are on an outdated version of Capuchin. Your version is ";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("ChangeToRegular");
	}

	// Token: 0x06001003 RID: 4099 RVA: 0x0005D3F0 File Offset: 0x0005B5F0
	[Token(Token = "0x6001003")]
	[Address(RVA = "0x2763EA0", Offset = "0x2763EA0", VA = "0x2763EA0")]
	public void ݕ\u0741ږԍ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("waited for your bullshit unity grrr");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("sound play stopped");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("spooky guy true");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("jump char false");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("hand 2");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Vector3 position2 = this.ݼ\u05B5\u06E1\u0593.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("tp 2");
	}

	// Token: 0x06001004 RID: 4100 RVA: 0x0005D4CC File Offset: 0x0005B6CC
	[Token(Token = "0x6001004")]
	[Address(RVA = "0x27640B0", Offset = "0x27640B0", VA = "0x27640B0")]
	public void ڷ\u0826ӹڥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("A Player has left the Room.");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("You are not the master of the server, you cannot start the game.");
	}

	// Token: 0x06001005 RID: 4101 RVA: 0x0005D5C4 File Offset: 0x0005B7C4
	[Token(Token = "0x6001005")]
	[Address(RVA = "0x2764384", Offset = "0x2764384", VA = "0x2764384")]
	public void \u05A6Ӌ۴\u073D()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("username");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("HorrorAgreement");
		Debug.Log("RainAndThunderWeather");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("HOLY MOLY THE STICK IS ON FIRE!!!!!!");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("SetColor");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Debug.Log("Open");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("This is the 1000 Bananas button, and it was just clicked");
	}

	// Token: 0x06001006 RID: 4102 RVA: 0x0005D6B8 File Offset: 0x0005B8B8
	[Token(Token = "0x6001006")]
	[Address(RVA = "0x2764594", Offset = "0x2764594", VA = "0x2764594")]
	public void \u07EEҼپܒ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("TurnAmount");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("hh:mm:sstt");
		Debug.Log("monkeScream");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("PRESS AGAIN TO CONFIRM");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("TurnAmount");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Debug.Log("PlayerHead");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log(". Please update you game to the latest version");
	}

	// Token: 0x06001007 RID: 4103 RVA: 0x0005D7AC File Offset: 0x0005B9AC
	[Token(Token = "0x6001007")]
	[Address(RVA = "0x2764790", Offset = "0x2764790", VA = "0x2764790")]
	public void ӣ\u0745ݥڂ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("hand 1");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("DisableCosmetic");
		Debug.Log("Player");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("Players: ");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Trying Getting Entilement...");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("sound play stopped");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("gravThing");
	}

	// Token: 0x06001008 RID: 4104 RVA: 0x0005D8A0 File Offset: 0x0005BAA0
	[Token(Token = "0x6001008")]
	[Address(RVA = "0x27649A0", Offset = "0x27649A0", VA = "0x27649A0")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Open";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("SetColor");
	}

	// Token: 0x06001009 RID: 4105 RVA: 0x0005D998 File Offset: 0x0005BB98
	[Token(Token = "0x6001009")]
	[Address(RVA = "0x2764C74", Offset = "0x2764C74", VA = "0x2764C74")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HDRP/Lit";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Holdable");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("_Tint");
	}

	// Token: 0x0600100A RID: 4106 RVA: 0x0005DA90 File Offset: 0x0005BC90
	[Token(Token = "0x600100A")]
	[Address(RVA = "0x2764F48", Offset = "0x2764F48", VA = "0x2764F48")]
	public void ԯ\u061C\u07FBߓ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		throw new MissingMethodException();
	}

	// Token: 0x0600100B RID: 4107 RVA: 0x0005DB80 File Offset: 0x0005BD80
	[Token(Token = "0x600100B")]
	[Address(RVA = "0x2765158", Offset = "0x2765158", VA = "0x2765158")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("closeToObject");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("_Tint");
	}

	// Token: 0x0600100C RID: 4108 RVA: 0x0005DC78 File Offset: 0x0005BE78
	[Token(Token = "0x600100C")]
	[Address(RVA = "0x276542C", Offset = "0x276542C", VA = "0x276542C")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "Horizontal";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Song Index: ");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = transform.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("EnableCosmetic");
	}

	// Token: 0x0600100D RID: 4109 RVA: 0x0005DD64 File Offset: 0x0005BF64
	[Token(Token = "0x600100D")]
	[Address(RVA = "0x2765700", Offset = "0x2765700", VA = "0x2765700")]
	public void Ԇܥډݑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Completed baking textures on frame ";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("monke screamed");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("Joined Public Room Successfully");
	}

	// Token: 0x0600100E RID: 4110 RVA: 0x0005DE5C File Offset: 0x0005C05C
	[Token(Token = "0x600100E")]
	[Address(RVA = "0x27659D4", Offset = "0x27659D4", VA = "0x27659D4")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("NetworkPlayer");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("EnableCosmetic");
	}

	// Token: 0x0600100F RID: 4111 RVA: 0x0005DF54 File Offset: 0x0005C154
	[Token(Token = "0x600100F")]
	[Address(RVA = "0x2765CA8", Offset = "0x2765CA8", VA = "0x2765CA8")]
	public void ԉՔӸ\u06DC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("FingerTip");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("gamemode");
	}

	// Token: 0x06001010 RID: 4112 RVA: 0x0005E04C File Offset: 0x0005C24C
	[Token(Token = "0x6001010")]
	[Address(RVA = "0x2765F7C", Offset = "0x2765F7C", VA = "0x2765F7C")]
	public void \u058AӉդ\u0589()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Calling success callback. baking meshes");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("_WobbleZ");
		Debug.Log("Vertical");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("typesOfTalk");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Debug.Log("_Tint");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("tutorialCheck");
	}

	// Token: 0x06001011 RID: 4113 RVA: 0x0005E140 File Offset: 0x0005C340
	[Token(Token = "0x6001011")]
	[Address(RVA = "0x276618C", Offset = "0x276618C", VA = "0x276618C")]
	public void \u07ECԙ\u05C9\u0610()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Regular");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("\tExpires: ");
		Debug.Log("MetaId");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("FingerTip");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Meta Platform entitlement error: ");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Debug.Log("Version");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Players: ");
	}

	// Token: 0x06001012 RID: 4114 RVA: 0x0005E234 File Offset: 0x0005C434
	[Token(Token = "0x6001012")]
	[Address(RVA = "0x276639C", Offset = "0x276639C", VA = "0x276639C")]
	public void צࡖթ\u0747()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		long active = 0L;
		Debug.Log(" hour. You were banned because of ");
		this.\u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("waited for your bullshit unity grrr");
		Debug.Log("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("TurnAmount");
		Debug.Log("PlayNoise");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Debug.Log("typesOfTalk");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Tagged");
	}

	// Token: 0x06001013 RID: 4115 RVA: 0x0005E314 File Offset: 0x0005C514
	[Token(Token = "0x6001013")]
	[Address(RVA = "0x27665AC", Offset = "0x27665AC", VA = "0x27665AC")]
	public void ߛݬ\u07F6ڭ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("M/d/yyyy");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("DisableCosmetic");
		Debug.Log("FingerTip");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Hats");
	}

	// Token: 0x06001014 RID: 4116 RVA: 0x0005E3C8 File Offset: 0x0005C5C8
	[Token(Token = "0x6001014")]
	[Address(RVA = "0x27667A8", Offset = "0x27667A8", VA = "0x27667A8")]
	public void ճ\u0828Ԓհ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("closeToObject");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("Add/Remove Sword");
	}

	// Token: 0x06001015 RID: 4117 RVA: 0x0005E4C0 File Offset: 0x0005C6C0
	[Token(Token = "0x6001015")]
	[Address(RVA = "0x2766A7C", Offset = "0x2766A7C", VA = "0x2766A7C")]
	public void \u07FA\u0878ӡԗ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("_Tint");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Toxicity");
		Debug.Log("isLava");
		Debug.Log("PlayerDeath");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active2 = 0L;
		ܙߙ_u089Aػ.SetActive(active2 != 0L);
		Debug.Log("FingerTip");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("deathScream");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("FingerTip");
	}

	// Token: 0x06001016 RID: 4118 RVA: 0x0005E5A4 File Offset: 0x0005C7A4
	[Token(Token = "0x6001016")]
	[Address(RVA = "0x2766C80", Offset = "0x2766C80", VA = "0x2766C80")]
	public void \u0838\u07ECٶ\u0659()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("isLava");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Diffuse");
		Debug.Log("Failed To Join Public Room Successfully. The error is: ");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("You have been banned for ");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Failed To Join Public Room Successfully. The error is: ");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("gravThing");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("duration done");
	}

	// Token: 0x06001017 RID: 4119 RVA: 0x0005E698 File Offset: 0x0005C898
	[Token(Token = "0x6001017")]
	[Address(RVA = "0x2766E7C", Offset = "0x2766E7C", VA = "0x2766E7C")]
	public void ەԌ\u05C7\u085D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Muted";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("hh:mmtt");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Vector3 position3 = this.\u0704\u061D\u0824\u05F4.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("hand 2");
	}

	// Token: 0x06001018 RID: 4120 RVA: 0x0005E784 File Offset: 0x0005C984
	[Token(Token = "0x6001018")]
	[Address(RVA = "0x2767150", Offset = "0x2767150", VA = "0x2767150")]
	public void մ\u058Bࢨއ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Players: ");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("make more points bobo");
		Debug.Log("You are on an outdated version of Capuchin. Your version is ");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log(" and for the price of ");
		Debug.Log("HandL");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log(". Please update you game to the latest version");
	}

	// Token: 0x06001019 RID: 4121 RVA: 0x0005E860 File Offset: 0x0005CA60
	[Token(Token = "0x6001019")]
	[Address(RVA = "0x2767360", Offset = "0x2767360", VA = "0x2767360")]
	public Jumpscare()
	{
	}

	// Token: 0x0600101A RID: 4122 RVA: 0x0005E874 File Offset: 0x0005CA74
	[Token(Token = "0x600101A")]
	[Address(RVA = "0x2767368", Offset = "0x2767368", VA = "0x2767368")]
	public void ӡը\u06DD\u06E6()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("\tExpires: ");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Purchased: ");
		Debug.Log("Tagged");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("CapuchinStore");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("ChangeMaterialToNormal");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("Player");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log(", ");
	}

	// Token: 0x0600101B RID: 4123 RVA: 0x0005E968 File Offset: 0x0005CB68
	[Token(Token = "0x600101B")]
	[Address(RVA = "0x2767578", Offset = "0x2767578", VA = "0x2767578")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayerHead";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log(".Please press the button if you would like to play alone");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("Not enough amount of currency");
	}

	// Token: 0x0600101C RID: 4124 RVA: 0x0005EA60 File Offset: 0x0005CC60
	[Token(Token = "0x600101C")]
	[Address(RVA = "0x276784C", Offset = "0x276784C", VA = "0x276784C")]
	public void ש\u0651ճ\u0656()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Right Hand");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("username");
		Debug.Log("Combine textures & build combined mesh using coroutine");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("FingerTip");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("HorrorAgreement");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Debug.Log("hand 1");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
	}

	// Token: 0x0600101D RID: 4125 RVA: 0x0005EB54 File Offset: 0x0005CD54
	[Token(Token = "0x600101D")]
	[Address(RVA = "0x2767A5C", Offset = "0x2767A5C", VA = "0x2767A5C")]
	public void \u07B4\u0594ԁڇ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Name Changing Error. Error: ";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("FLSPTLT");
	}

	// Token: 0x0600101E RID: 4126 RVA: 0x0005EC38 File Offset: 0x0005CE38
	[Token(Token = "0x600101E")]
	[Address(RVA = "0x2767D1C", Offset = "0x2767D1C", VA = "0x2767D1C")]
	public void \u0604\u065Dވڟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Game Started");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("Muted");
	}

	// Token: 0x0600101F RID: 4127 RVA: 0x0005ED30 File Offset: 0x0005CF30
	[Token(Token = "0x600101F")]
	[Address(RVA = "0x2767FF0", Offset = "0x2767FF0", VA = "0x2767FF0")]
	public void \u05AD\u0881ࡆݡ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "username";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = ࢣ_u0822Ӹ_u07BC.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("gamemode");
	}

	// Token: 0x06001020 RID: 4128 RVA: 0x0005EE24 File Offset: 0x0005D024
	[Token(Token = "0x6001020")]
	[Address(RVA = "0x27682C4", Offset = "0x27682C4", VA = "0x27682C4")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "tp 2";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Reason: ");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
	}

	// Token: 0x06001021 RID: 4129 RVA: 0x0005EF0C File Offset: 0x0005D10C
	[Token(Token = "0x6001021")]
	[Address(RVA = "0x2768598", Offset = "0x2768598", VA = "0x2768598")]
	public void \u065A\u05CDޙޗ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("PRESS AGAIN TO CONFIRM");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("FingerTip");
		long active2 = 0L;
		Debug.Log("Body");
		this.Ӥ\u087Bݜ\u065F.SetActive(active2 != 0L);
		Debug.Log("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Charging...");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Debug.Log("EnableCosmetic");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("/");
	}

	// Token: 0x06001022 RID: 4130 RVA: 0x0005EFFC File Offset: 0x0005D1FC
	[Token(Token = "0x6001022")]
	[Address(RVA = "0x27687A8", Offset = "0x27687A8", VA = "0x27687A8")]
	public void Ӳ\u081Cך\u0896()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Stopped Colliding");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("ChangeToTagged");
		Debug.Log("clickLol");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("NoseAttachPoint");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("RainAndThunderWeather");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Debug.Log("_BaseMap");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("_WobbleX");
	}

	// Token: 0x06001023 RID: 4131 RVA: 0x0005F0F0 File Offset: 0x0005D2F0
	[Token(Token = "0x6001023")]
	[Address(RVA = "0x27689B8", Offset = "0x27689B8", VA = "0x27689B8")]
	public void \u0872ۋ\u05B9ڥ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("typesOfTalk");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("typesOfTalk");
		Debug.Log("TurnAmount");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("true");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Connected to Server.");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Debug.Log("Name Changing Error. Error: ");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("FingerTip");
	}

	// Token: 0x06001024 RID: 4132 RVA: 0x0005F1E4 File Offset: 0x0005D3E4
	[Token(Token = "0x6001024")]
	[Address(RVA = "0x2768BC8", Offset = "0x2768BC8", VA = "0x2768BC8")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("HandL");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		long active3 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("BLUTARG");
	}

	// Token: 0x06001025 RID: 4133 RVA: 0x0005F2D4 File Offset: 0x0005D4D4
	[Token(Token = "0x6001025")]
	[Address(RVA = "0x2768E9C", Offset = "0x2768E9C", VA = "0x2768E9C")]
	public void \u05CD\u07EFݕӍ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("back");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("containsStaff");
		Debug.Log("A Player has left the Room.");
		Debug.Log("A Player has left the Room.");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active2 = 1L;
		ܙߙ_u089Aػ.SetActive(active2 != 0L);
		Debug.Log("PlayerHead");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("Player");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("containsStaff");
	}

	// Token: 0x06001026 RID: 4134 RVA: 0x0005F3B8 File Offset: 0x0005D5B8
	[Token(Token = "0x6001026")]
	[Address(RVA = "0x27690A0", Offset = "0x27690A0", VA = "0x27690A0")]
	public void \u06D6\u05C8\u089B\u0749()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Player");
		Debug.Log("Body");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("You are not the master of the server, you cannot start the game.");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Toxicity");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("username");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
	}

	// Token: 0x06001027 RID: 4135 RVA: 0x0005F4A0 File Offset: 0x0005D6A0
	[Token(Token = "0x6001027")]
	[Address(RVA = "0x27692B0", Offset = "0x27692B0", VA = "0x27692B0")]
	public void \u073Dڽثݢ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Tagged");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("FingerTip");
		Debug.Log("");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("duration done");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("A new Player joined a Room.");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log(" and the correct version is ");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Calling success callback. baking meshes");
	}

	// Token: 0x06001028 RID: 4136 RVA: 0x0005F594 File Offset: 0x0005D794
	[Token(Token = "0x6001028")]
	[Address(RVA = "0x27694C0", Offset = "0x27694C0", VA = "0x27694C0")]
	public void ە\u060Dߓٹ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("BloodKill");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("True");
		Debug.Log("True");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("NetworkPlayer");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("PlayWave");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Debug.Log("Joined Public Room Successfully");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("procedural animation script required on ");
	}

	// Token: 0x06001029 RID: 4137 RVA: 0x0005F688 File Offset: 0x0005D888
	[Token(Token = "0x6001029")]
	[Address(RVA = "0x27696D0", Offset = "0x27696D0", VA = "0x27696D0")]
	public void \u081Eڷ\u0839\u0875()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("PlayerHead");
		long active2 = 0L;
		Debug.Log("On");
		this.Ӥ\u087Bݜ\u065F.SetActive(active2 != 0L);
		Debug.Log("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("typesOfTalk");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Debug.Log("Player");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Body");
	}

	// Token: 0x0600102A RID: 4138 RVA: 0x0005F778 File Offset: 0x0005D978
	[Token(Token = "0x600102A")]
	[Address(RVA = "0x27698CC", Offset = "0x27698CC", VA = "0x27698CC")]
	public void ԗ\u05F9ҿ\u0834(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Joined Public Room Successfully";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("StartGamemode");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("Calling success callback. baking meshes");
	}

	// Token: 0x0600102B RID: 4139 RVA: 0x0005F870 File Offset: 0x0005DA70
	[Token(Token = "0x600102B")]
	[Address(RVA = "0x2769BA0", Offset = "0x2769BA0", VA = "0x2769BA0")]
	public void \u083Cࢡ\u086B\u0834()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("isLava");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Not connected to room");
		Debug.Log("Player");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("Player");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Calling success callback. baking meshes");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Debug.Log("containsStaff");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("Player");
	}

	// Token: 0x0600102C RID: 4140 RVA: 0x0005F964 File Offset: 0x0005DB64
	[Token(Token = "0x600102C")]
	[Address(RVA = "0x2769D90", Offset = "0x2769D90", VA = "0x2769D90")]
	public void ղڠӚ\u0657()
	{
		if (!true)
		{
		}
		Debug.Log("ORGTARG");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Tagged");
		Debug.Log("DisableCosmetic");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Player");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Debug.Log("MetaAuth");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("5BN");
	}

	// Token: 0x0600102D RID: 4141 RVA: 0x0005FA54 File Offset: 0x0005DC54
	[Token(Token = "0x600102D")]
	[Address(RVA = "0x2769FA0", Offset = "0x2769FA0", VA = "0x2769FA0")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "EnableCosmetic";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("PlayWave");
	}

	// Token: 0x0600102E RID: 4142 RVA: 0x0005FB4C File Offset: 0x0005DD4C
	[Token(Token = "0x600102E")]
	[Address(RVA = "0x276A260", Offset = "0x276A260", VA = "0x276A260")]
	public void ؠ\u06FEޒ٠()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("Name Changing Error. Error: ");
		Debug.Log("_Tint");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("Completed baking textures on frame ");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("NoseAttachPoint");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Debug.Log("Body");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("HorrorAgreement");
	}

	// Token: 0x0600102F RID: 4143 RVA: 0x0005FC40 File Offset: 0x0005DE40
	[Token(Token = "0x600102F")]
	[Address(RVA = "0x276A470", Offset = "0x276A470", VA = "0x276A470")]
	public void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Diffuse";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if ("\ud9c0\udc00" == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Target");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("Not enough amount of currency");
	}

	// Token: 0x06001030 RID: 4144 RVA: 0x0005FD38 File Offset: 0x0005DF38
	[Token(Token = "0x6001030")]
	[Address(RVA = "0x276A744", Offset = "0x276A744", VA = "0x276A744")]
	public void \u0887ة\u0616ࡩ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("run");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("HorrorAgreement");
		Debug.Log("Display Name Changed!");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("gameMode");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("Left Hand");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Debug.Log("Agreed");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("username");
	}

	// Token: 0x06001031 RID: 4145 RVA: 0x0005FE2C File Offset: 0x0005E02C
	[Token(Token = "0x6001031")]
	[Address(RVA = "0x276A954", Offset = "0x276A954", VA = "0x276A954")]
	public void Ҽݧבࡧ()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Tagged");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		this.Ֆݣࠈ\u066B.Stop();
		Debug.Log("HDRP/Lit");
		Debug.Log("Skelechin");
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		Debug.Log("FingerTip");
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 0L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		Debug.Log("FingerTip");
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Debug.Log("Connected to Server.");
		Transform ݼ_u05B5_u06E1_u = this.ݼ\u05B5\u06E1\u0593;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = ݼ_u05B5_u06E1_u.position;
		Transform ݼ_u05B5_u06E1_u2 = this.ݼ\u05B5\u06E1\u0593;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position2 = ݼ_u05B5_u06E1_u2.position;
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Debug.Log("got funky mone");
	}

	// Token: 0x06001032 RID: 4146 RVA: 0x0005FF20 File Offset: 0x0005E120
	[Token(Token = "0x6001032")]
	[Address(RVA = "0x276AB50", Offset = "0x276AB50", VA = "0x276AB50")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		Transform transform;
		Vector3 position = transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		long active = 0L;
		GameObject gameObject;
		gameObject.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("tutorialCheck");
		Debug.Log("Vertical");
	}

	// Token: 0x06001033 RID: 4147 RVA: 0x0005FFA0 File Offset: 0x0005E1A0
	[Token(Token = "0x6001033")]
	[Address(RVA = "0x276AE10", Offset = "0x276AE10", VA = "0x276AE10")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 1L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("hand 1");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 0L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("sound play play");
	}

	// Token: 0x06001034 RID: 4148 RVA: 0x00060098 File Offset: 0x0005E298
	[Token(Token = "0x6001034")]
	[Address(RVA = "0x276B0E0", Offset = "0x276B0E0", VA = "0x276B0E0")]
	public void ݍ\u05F4ߓ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		Rigidbody ࢣ_u0822Ӹ_u07BC = this.ࢣ\u0822Ӹ\u07BC;
		long isKinematic = 0L;
		ࢣ_u0822Ӹ_u07BC.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("HorrorAgreement");
		Transform u0704_u061D_u0824_u05F = this.\u0704\u061D\u0824\u05F4;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position2 = u0704_u061D_u0824_u05F.position;
		Transform u0704_u061D_u0824_u05F2 = this.\u0704\u061D\u0824\u05F4;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position3 = u0704_u061D_u0824_u05F2.position;
		GameObject ӥ_u087Bݜ_u065F = this.Ӥ\u087Bݜ\u065F;
		long active2 = 1L;
		ӥ_u087Bݜ_u065F.SetActive(active2 != 0L);
		GameObject ܙߙ_u089Aػ = this.ܙߙ\u089Aػ;
		long active3 = 1L;
		ܙߙ_u089Aػ.SetActive(active3 != 0L);
		this.Ֆݣࠈ\u066B.Play();
		Debug.Log("Not enough amount of currency");
	}

	// Token: 0x04000228 RID: 552
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000228")]
	public float \u05B4ࢻ\u0600\u06EB;

	// Token: 0x04000229 RID: 553
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000229")]
	public GameObject ܙߙ\u089Aػ;

	// Token: 0x0400022A RID: 554
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400022A")]
	public GameObject \u06E6ޝݥӻ;

	// Token: 0x0400022B RID: 555
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400022B")]
	public AudioSource Ֆݣࠈ\u066B;

	// Token: 0x0400022C RID: 556
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400022C")]
	public GameObject Ӥ\u087Bݜ\u065F;

	// Token: 0x0400022D RID: 557
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400022D")]
	public Transform \u0704\u061D\u0824\u05F4;

	// Token: 0x0400022E RID: 558
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400022E")]
	public Transform ݼ\u05B5\u06E1\u0593;

	// Token: 0x0400022F RID: 559
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400022F")]
	public Transform \u081B\u070Aߢࡁ;

	// Token: 0x04000230 RID: 560
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000230")]
	public Transform ڿӣԛӾ;

	// Token: 0x04000231 RID: 561
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000231")]
	public Rigidbody ࢣ\u0822Ӹ\u07BC;
}
