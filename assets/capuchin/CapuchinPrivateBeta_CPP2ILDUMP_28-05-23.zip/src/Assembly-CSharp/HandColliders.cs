﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000CF RID: 207
[Token(Token = "0x20000CF")]
public class HandColliders : MonoBehaviour
{
	// Token: 0x06001F9C RID: 8092 RVA: 0x000A60E8 File Offset: 0x000A42E8
	[Token(Token = "0x6001F9C")]
	[Address(RVA = "0x274D530", Offset = "0x274D530", VA = "0x274D530")]
	public HandColliders()
	{
	}

	// Token: 0x04000416 RID: 1046
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000416")]
	public bool \u089Bݼۄ\u0875;
}
