﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000068 RID: 104
[Token(Token = "0x2000068")]
public class InputFocus : MonoBehaviour
{
	// Token: 0x06000F59 RID: 3929 RVA: 0x00058C78 File Offset: 0x00056E78
	[Token(Token = "0x6000F59")]
	[Address(RVA = "0x2754450", Offset = "0x2754450", VA = "0x2754450")]
	private void ژךՈ\u0597()
	{
	}

	// Token: 0x06000F5A RID: 3930 RVA: 0x00058C88 File Offset: 0x00056E88
	[Token(Token = "0x6000F5A")]
	[Address(RVA = "0x2754454", Offset = "0x2754454", VA = "0x2754454")]
	private void ڑߒجވ()
	{
	}

	// Token: 0x06000F5B RID: 3931 RVA: 0x00058C98 File Offset: 0x00056E98
	[Token(Token = "0x6000F5B")]
	[Address(RVA = "0x2754458", Offset = "0x2754458", VA = "0x2754458")]
	private void \u0599ږࠆ\u065F()
	{
	}

	// Token: 0x06000F5C RID: 3932 RVA: 0x00058CA8 File Offset: 0x00056EA8
	[Token(Token = "0x6000F5C")]
	[Address(RVA = "0x275445C", Offset = "0x275445C", VA = "0x275445C")]
	private void \u05EDց\u081Cت()
	{
	}

	// Token: 0x06000F5D RID: 3933 RVA: 0x00058CB8 File Offset: 0x00056EB8
	[Token(Token = "0x6000F5D")]
	[Address(RVA = "0x2754460", Offset = "0x2754460", VA = "0x2754460")]
	private void ԣԭՋࠏ()
	{
	}

	// Token: 0x06000F5E RID: 3934 RVA: 0x00058CC8 File Offset: 0x00056EC8
	[Token(Token = "0x6000F5E")]
	[Address(RVA = "0x2754464", Offset = "0x2754464", VA = "0x2754464")]
	public InputFocus()
	{
	}

	// Token: 0x06000F5F RID: 3935 RVA: 0x00058CDC File Offset: 0x00056EDC
	[Token(Token = "0x6000F5F")]
	[Address(RVA = "0x275446C", Offset = "0x275446C", VA = "0x275446C")]
	private void ܣ\u086E\u05CF\u06D8()
	{
	}

	// Token: 0x06000F60 RID: 3936 RVA: 0x00058CEC File Offset: 0x00056EEC
	[Token(Token = "0x6000F60")]
	[Address(RVA = "0x2754470", Offset = "0x2754470", VA = "0x2754470")]
	private void \u061B\u05EEوۈ()
	{
	}

	// Token: 0x06000F61 RID: 3937 RVA: 0x00058CFC File Offset: 0x00056EFC
	[Token(Token = "0x6000F61")]
	[Address(RVA = "0x2754474", Offset = "0x2754474", VA = "0x2754474")]
	private void ں٢ࡡ\u05EC()
	{
	}

	// Token: 0x06000F62 RID: 3938 RVA: 0x00058D0C File Offset: 0x00056F0C
	[Token(Token = "0x6000F62")]
	[Address(RVA = "0x2754478", Offset = "0x2754478", VA = "0x2754478")]
	private void \u0732ڙԒࢺ()
	{
	}

	// Token: 0x06000F63 RID: 3939 RVA: 0x00058D1C File Offset: 0x00056F1C
	[Token(Token = "0x6000F63")]
	[Address(RVA = "0x275447C", Offset = "0x275447C", VA = "0x275447C")]
	private void \u0654ޛ\u07FAذ()
	{
	}

	// Token: 0x06000F64 RID: 3940 RVA: 0x00058D2C File Offset: 0x00056F2C
	[Token(Token = "0x6000F64")]
	[Address(RVA = "0x2754480", Offset = "0x2754480", VA = "0x2754480")]
	private void Ӣ\u0592ߨׯ()
	{
	}

	// Token: 0x06000F65 RID: 3941 RVA: 0x00058D3C File Offset: 0x00056F3C
	[Token(Token = "0x6000F65")]
	[Address(RVA = "0x2754484", Offset = "0x2754484", VA = "0x2754484")]
	private void \u0886Ҽ\u058Dߛ()
	{
	}

	// Token: 0x06000F66 RID: 3942 RVA: 0x00058D4C File Offset: 0x00056F4C
	[Token(Token = "0x6000F66")]
	[Address(RVA = "0x2754488", Offset = "0x2754488", VA = "0x2754488")]
	private void Ҽ\u08B5ځ\u0658()
	{
	}

	// Token: 0x06000F67 RID: 3943 RVA: 0x00058D5C File Offset: 0x00056F5C
	[Token(Token = "0x6000F67")]
	[Address(RVA = "0x275448C", Offset = "0x275448C", VA = "0x275448C")]
	private void \u0614ࢥӴ\u086C()
	{
	}

	// Token: 0x06000F68 RID: 3944 RVA: 0x00058D6C File Offset: 0x00056F6C
	[Token(Token = "0x6000F68")]
	[Address(RVA = "0x2754490", Offset = "0x2754490", VA = "0x2754490")]
	private void \u070Aәޣے()
	{
	}

	// Token: 0x06000F69 RID: 3945 RVA: 0x00058D7C File Offset: 0x00056F7C
	[Token(Token = "0x6000F69")]
	[Address(RVA = "0x2754494", Offset = "0x2754494", VA = "0x2754494")]
	private void ڃրӢԖ()
	{
	}

	// Token: 0x06000F6A RID: 3946 RVA: 0x00058D8C File Offset: 0x00056F8C
	[Token(Token = "0x6000F6A")]
	[Address(RVA = "0x2754498", Offset = "0x2754498", VA = "0x2754498")]
	private void \u0881ݗӟ\u07BD()
	{
	}

	// Token: 0x06000F6B RID: 3947 RVA: 0x00058D9C File Offset: 0x00056F9C
	[Token(Token = "0x6000F6B")]
	[Address(RVA = "0x275449C", Offset = "0x275449C", VA = "0x275449C")]
	private void ԟ\u086Cޣ\u055E()
	{
	}

	// Token: 0x06000F6C RID: 3948 RVA: 0x00058DAC File Offset: 0x00056FAC
	[Token(Token = "0x6000F6C")]
	[Address(RVA = "0x27544A0", Offset = "0x27544A0", VA = "0x27544A0")]
	private void \u0821\u059Fӕ\u0607()
	{
	}

	// Token: 0x06000F6D RID: 3949 RVA: 0x00058DBC File Offset: 0x00056FBC
	[Token(Token = "0x6000F6D")]
	[Address(RVA = "0x27544A4", Offset = "0x27544A4", VA = "0x27544A4")]
	private void צ\u0874ڵ\u059A()
	{
	}

	// Token: 0x06000F6E RID: 3950 RVA: 0x00058DCC File Offset: 0x00056FCC
	[Token(Token = "0x6000F6E")]
	[Address(RVA = "0x27544A8", Offset = "0x27544A8", VA = "0x27544A8")]
	private void څࡣڐ\u0657()
	{
	}

	// Token: 0x06000F6F RID: 3951 RVA: 0x00058DDC File Offset: 0x00056FDC
	[Token(Token = "0x6000F6F")]
	[Address(RVA = "0x27544AC", Offset = "0x27544AC", VA = "0x27544AC")]
	private void ٴݵۃ\u05AF()
	{
	}

	// Token: 0x06000F70 RID: 3952 RVA: 0x00058DEC File Offset: 0x00056FEC
	[Token(Token = "0x6000F70")]
	[Address(RVA = "0x27544B0", Offset = "0x27544B0", VA = "0x27544B0")]
	private void ފՖߢ\u059B()
	{
	}

	// Token: 0x06000F71 RID: 3953 RVA: 0x00058DFC File Offset: 0x00056FFC
	[Token(Token = "0x6000F71")]
	[Address(RVA = "0x27544B4", Offset = "0x27544B4", VA = "0x27544B4")]
	private void ւࡂ\u0883\u0872()
	{
	}

	// Token: 0x06000F72 RID: 3954 RVA: 0x00058E0C File Offset: 0x0005700C
	[Token(Token = "0x6000F72")]
	[Address(RVA = "0x27544B8", Offset = "0x27544B8", VA = "0x27544B8")]
	private void Ҿࢹؼס()
	{
	}

	// Token: 0x06000F73 RID: 3955 RVA: 0x00058E1C File Offset: 0x0005701C
	[Token(Token = "0x6000F73")]
	[Address(RVA = "0x27544BC", Offset = "0x27544BC", VA = "0x27544BC")]
	private void \u07FE\u0882Զ\u066D()
	{
	}

	// Token: 0x06000F74 RID: 3956 RVA: 0x00058E2C File Offset: 0x0005702C
	[Token(Token = "0x6000F74")]
	[Address(RVA = "0x27544C0", Offset = "0x27544C0", VA = "0x27544C0")]
	private void \u061Fࡆ\u086F\u07B0()
	{
	}

	// Token: 0x06000F75 RID: 3957 RVA: 0x00058E3C File Offset: 0x0005703C
	[Token(Token = "0x6000F75")]
	[Address(RVA = "0x27544C4", Offset = "0x27544C4", VA = "0x27544C4")]
	private void Update()
	{
	}

	// Token: 0x06000F76 RID: 3958 RVA: 0x00058E4C File Offset: 0x0005704C
	[Token(Token = "0x6000F76")]
	[Address(RVA = "0x27544C8", Offset = "0x27544C8", VA = "0x27544C8")]
	private void ࢫ\u0876չՍ()
	{
	}

	// Token: 0x06000F77 RID: 3959 RVA: 0x00058E5C File Offset: 0x0005705C
	[Token(Token = "0x6000F77")]
	[Address(RVA = "0x27544CC", Offset = "0x27544CC", VA = "0x27544CC")]
	private void ւ\u06E9\u06DA\u06EB()
	{
	}

	// Token: 0x06000F78 RID: 3960 RVA: 0x00058E6C File Offset: 0x0005706C
	[Token(Token = "0x6000F78")]
	[Address(RVA = "0x27544D0", Offset = "0x27544D0", VA = "0x27544D0")]
	private void ժ\u065Dԯࡘ()
	{
	}

	// Token: 0x06000F79 RID: 3961 RVA: 0x00058E7C File Offset: 0x0005707C
	[Token(Token = "0x6000F79")]
	[Address(RVA = "0x27544D4", Offset = "0x27544D4", VA = "0x27544D4")]
	private void \u087BӦןݩ()
	{
	}

	// Token: 0x06000F7A RID: 3962 RVA: 0x00058E8C File Offset: 0x0005708C
	[Token(Token = "0x6000F7A")]
	[Address(RVA = "0x27544D8", Offset = "0x27544D8", VA = "0x27544D8")]
	private void ӻӒݝ߃()
	{
	}

	// Token: 0x06000F7B RID: 3963 RVA: 0x00058E9C File Offset: 0x0005709C
	[Token(Token = "0x6000F7B")]
	[Address(RVA = "0x27544DC", Offset = "0x27544DC", VA = "0x27544DC")]
	private void \u05F7ԝߠӱ()
	{
	}

	// Token: 0x06000F7C RID: 3964 RVA: 0x00058EAC File Offset: 0x000570AC
	[Token(Token = "0x6000F7C")]
	[Address(RVA = "0x27544E0", Offset = "0x27544E0", VA = "0x27544E0")]
	private void \u0838ӆڛӑ()
	{
	}
}
