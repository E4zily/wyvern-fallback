﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200008E RID: 142
[Token(Token = "0x200008E")]
public class grabPhysics : MonoBehaviour
{
	// Token: 0x06001587 RID: 5511 RVA: 0x00078F48 File Offset: 0x00077148
	[Token(Token = "0x6001587")]
	[Address(RVA = "0x2FA95AC", Offset = "0x2FA95AC", VA = "0x2FA95AC")]
	private void \u089Fکߦݭ()
	{
		bool u058F_u083Dۀڃ = this.\u058F\u083Dۀڃ;
		if (!u058F_u083Dۀڃ || !u058F_u083Dۀڃ)
		{
		}
		bool ӄגࠇ٦ = this.Ӄגࠇ٦;
		if (ӄגࠇ٦)
		{
			if (!ӄגࠇ٦)
			{
			}
			return;
		}
		bool u0700ݤڑޡ = this.\u0700ݤڑޡ;
		bool u0876կࢹջ = this.\u0876կࢹջ;
		if (u0700ݤڑޡ)
		{
			if (!u0876կࢹջ)
			{
				Vector3 position = base.transform.position;
				LayerMask u0733ڰ_u0737ݿ = this.\u0733ڰ\u0737ݿ;
				float num = this.ٸյՈڙ;
				int num2 = u0733ڰ_u0737ݿ;
				if (u0700ݤڑޡ)
				{
					if (u0700ݤڑޡ)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint ٹ_u05C3_u0736۱ = base.gameObject.AddComponent<FixedJoint>();
						this.ٹ\u05C3\u0736۱ = ٹ_u05C3_u0736۱;
						if (typeof(UnityEngine.Object).TypeHandle == null)
						{
						}
						bool flag = attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.ߠނࢤࢹ;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						long num3 = 1L;
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long u0876կࢹջ2 = 1L;
					this.\u0876կࢹջ = (u0876կࢹջ2 != 0L);
				}
			}
		}
		else if (u0876կࢹջ)
		{
			FixedJoint ٹ_u05C3_u0736۱2 = this.ٹ\u05C3\u0736۱;
			long num3;
			if (num3 == 0L)
			{
			}
			bool flag2 = ٹ_u05C3_u0736۱2;
			FixedJoint ٹ_u05C3_u0736۱3 = this.ٹ\u05C3\u0736۱;
			if (num3 == 0L)
			{
			}
			UnityEngine.Object.Destroy(ٹ_u05C3_u0736۱3);
			Transform transform4 = this.ߠނࢤࢹ;
			Transform u0835_u070Dࡂ_u070B = this.\u0835\u070Dࡂ\u070B;
			transform4.SetParent(u0835_u070Dࡂ_u070B);
			return;
		}
	}

	// Token: 0x06001588 RID: 5512 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001588")]
	[Address(RVA = "0x2FA9974", Offset = "0x2FA9974", VA = "0x2FA9974")]
	public void ߆۰\u05BFߍ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001589 RID: 5513 RVA: 0x000790B4 File Offset: 0x000772B4
	[Token(Token = "0x6001589")]
	[Address(RVA = "0x2FA9A7C", Offset = "0x2FA9A7C", VA = "0x2FA9A7C")]
	private void \u05C3Ձ\u0705\u0707()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x0600158A RID: 5514 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600158A")]
	[Address(RVA = "0x2FA9AB8", Offset = "0x2FA9AB8", VA = "0x2FA9AB8")]
	public void \u0613\u05CBݠۇ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600158B RID: 5515 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600158B")]
	[Address(RVA = "0x2FA9BC0", Offset = "0x2FA9BC0", VA = "0x2FA9BC0")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600158C RID: 5516 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600158C")]
	[Address(RVA = "0x2FA9CBC", Offset = "0x2FA9CBC", VA = "0x2FA9CBC")]
	public void \u0559\u05FEפ\u05CD()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600158D RID: 5517 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600158D")]
	[Address(RVA = "0x2FA9DB8", Offset = "0x2FA9DB8", VA = "0x2FA9DB8")]
	public void ݠ\u07EBӁ\u0652()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600158E RID: 5518 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600158E")]
	[Address(RVA = "0x2FA9EC0", Offset = "0x2FA9EC0", VA = "0x2FA9EC0")]
	public void ԛ\u07EFӶ\u065A()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600158F RID: 5519 RVA: 0x000790DC File Offset: 0x000772DC
	[Token(Token = "0x600158F")]
	[Address(RVA = "0x2FA9FBC", Offset = "0x2FA9FBC", VA = "0x2FA9FBC")]
	private void ոӴٻԎ()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x06001590 RID: 5520 RVA: 0x00079104 File Offset: 0x00077304
	[Token(Token = "0x6001590")]
	[Address(RVA = "0x2FA9FF8", Offset = "0x2FA9FF8", VA = "0x2FA9FF8")]
	private void ݱ\u087AՃך()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x06001591 RID: 5521 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001591")]
	[Address(RVA = "0x2FAA034", Offset = "0x2FAA034", VA = "0x2FAA034")]
	public void Ԁ\u05EB\u085Eՠ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001592 RID: 5522 RVA: 0x0007912C File Offset: 0x0007732C
	[Token(Token = "0x6001592")]
	[Address(RVA = "0x2FAA130", Offset = "0x2FAA130", VA = "0x2FAA130")]
	private void ݏރߣࢮ()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x06001593 RID: 5523 RVA: 0x00079154 File Offset: 0x00077354
	[Token(Token = "0x6001593")]
	[Address(RVA = "0x2FAA16C", Offset = "0x2FAA16C", VA = "0x2FAA16C")]
	private void ފؾכࠉ()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x06001594 RID: 5524 RVA: 0x0007917C File Offset: 0x0007737C
	[Token(Token = "0x6001594")]
	[Address(RVA = "0x2FAA1A8", Offset = "0x2FAA1A8", VA = "0x2FAA1A8")]
	public grabPhysics()
	{
	}

	// Token: 0x06001595 RID: 5525 RVA: 0x0007919C File Offset: 0x0007739C
	[Token(Token = "0x6001595")]
	[Address(RVA = "0x2FAA1BC", Offset = "0x2FAA1BC", VA = "0x2FAA1BC")]
	private void \u07FCիӛӒ()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x06001596 RID: 5526 RVA: 0x000791C4 File Offset: 0x000773C4
	[Token(Token = "0x6001596")]
	[Address(RVA = "0x2FAA1F8", Offset = "0x2FAA1F8", VA = "0x2FAA1F8")]
	private void FixedUpdate()
	{
		bool u058F_u083Dۀڃ = this.\u058F\u083Dۀڃ;
		if (!u058F_u083Dۀڃ || !u058F_u083Dۀڃ)
		{
		}
		bool ӄגࠇ٦ = this.Ӄגࠇ٦;
		if (ӄגࠇ٦)
		{
			if (!ӄגࠇ٦)
			{
			}
			return;
		}
		bool u0700ݤڑޡ = this.\u0700ݤڑޡ;
		bool u0876կࢹջ = this.\u0876կࢹջ;
		if (u0700ݤڑޡ)
		{
			if (!u0876կࢹջ)
			{
				Vector3 position = base.transform.position;
				LayerMask u0733ڰ_u0737ݿ = this.\u0733ڰ\u0737ݿ;
				float num = this.ٸյՈڙ;
				int num2 = u0733ڰ_u0737ݿ;
				if (u0700ݤڑޡ)
				{
					if (u0700ݤڑޡ)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint ٹ_u05C3_u0736۱ = base.gameObject.AddComponent<FixedJoint>();
						this.ٹ\u05C3\u0736۱ = ٹ_u05C3_u0736۱;
						if (typeof(UnityEngine.Object).TypeHandle == null)
						{
						}
						bool flag = attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.ߠނࢤࢹ;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long u0876կࢹջ2 = 1L;
					this.\u0876կࢹջ = (u0876կࢹջ2 != 0L);
				}
			}
		}
		else if (u0876կࢹջ)
		{
			FixedJoint ٹ_u05C3_u0736۱2 = this.ٹ\u05C3\u0736۱;
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			bool flag2 = ٹ_u05C3_u0736۱2;
			FixedJoint ٹ_u05C3_u0736۱3 = this.ٹ\u05C3\u0736۱;
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			UnityEngine.Object.Destroy(ٹ_u05C3_u0736۱3);
			Transform transform4 = this.ߠނࢤࢹ;
			Transform u0835_u070Dࡂ_u070B = this.\u0835\u070Dࡂ\u070B;
			transform4.SetParent(u0835_u070Dࡂ_u070B);
			return;
		}
	}

	// Token: 0x06001597 RID: 5527 RVA: 0x00079340 File Offset: 0x00077540
	[Token(Token = "0x6001597")]
	[Address(RVA = "0x2FAA5C0", Offset = "0x2FAA5C0", VA = "0x2FAA5C0")]
	private void \u081E١Ӕࢦ()
	{
		bool u058F_u083Dۀڃ = this.\u058F\u083Dۀڃ;
		if (!u058F_u083Dۀڃ || !u058F_u083Dۀڃ)
		{
		}
		bool ӄגࠇ٦ = this.Ӄגࠇ٦;
		if (ӄגࠇ٦)
		{
			if (!ӄגࠇ٦)
			{
			}
			return;
		}
		bool u0700ݤڑޡ = this.\u0700ݤڑޡ;
		bool u0876կࢹջ = this.\u0876կࢹջ;
		if (u0700ݤڑޡ)
		{
			if (!u0876կࢹջ)
			{
				Vector3 position = base.transform.position;
				LayerMask u0733ڰ_u0737ݿ = this.\u0733ڰ\u0737ݿ;
				float num = this.ٸյՈڙ;
				int num2 = u0733ڰ_u0737ݿ;
				if (u0700ݤڑޡ)
				{
					if (u0700ݤڑޡ)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint ٹ_u05C3_u0736۱ = base.gameObject.AddComponent<FixedJoint>();
						this.ٹ\u05C3\u0736۱ = ٹ_u05C3_u0736۱;
						if (typeof(UnityEngine.Object).TypeHandle == null)
						{
						}
						bool flag = attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.ߠނࢤࢹ;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long u0876կࢹջ2 = 1L;
					this.\u0876կࢹջ = (u0876կࢹջ2 != 0L);
				}
			}
		}
		else if (u0876կࢹջ)
		{
			long num3 = 1L;
			this.\u0876կࢹջ = (num3 != 0L);
			FixedJoint ٹ_u05C3_u0736۱2 = this.ٹ\u05C3\u0736۱;
			if (num3 == 0L)
			{
			}
			bool flag2 = ٹ_u05C3_u0736۱2;
			FixedJoint ٹ_u05C3_u0736۱3 = this.ٹ\u05C3\u0736۱;
			if (num3 == 0L)
			{
			}
			UnityEngine.Object.Destroy(ٹ_u05C3_u0736۱3);
			Transform transform4 = this.ߠނࢤࢹ;
			Transform u0835_u070Dࡂ_u070B = this.\u0835\u070Dࡂ\u070B;
			transform4.SetParent(u0835_u070Dࡂ_u070B);
			return;
		}
	}

	// Token: 0x06001598 RID: 5528 RVA: 0x000794A4 File Offset: 0x000776A4
	[Token(Token = "0x6001598")]
	[Address(RVA = "0x2FAA984", Offset = "0x2FAA984", VA = "0x2FAA984")]
	private void רشڃ\u05A7()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x06001599 RID: 5529 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001599")]
	[Address(RVA = "0x2FAA9C0", Offset = "0x2FAA9C0", VA = "0x2FAA9C0")]
	public void ҽגٻ\u05B7()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600159A RID: 5530 RVA: 0x000794CC File Offset: 0x000776CC
	[Token(Token = "0x600159A")]
	[Address(RVA = "0x2FAAABC", Offset = "0x2FAAABC", VA = "0x2FAAABC")]
	private void ޛөࠎ\u059F()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x0600159B RID: 5531 RVA: 0x000794F4 File Offset: 0x000776F4
	[Token(Token = "0x600159B")]
	[Address(RVA = "0x2FAAAF8", Offset = "0x2FAAAF8", VA = "0x2FAAAF8")]
	private void \u0892\u061B\u0606\u06D8()
	{
		bool u058F_u083Dۀڃ = this.\u058F\u083Dۀڃ;
		if (!u058F_u083Dۀڃ || !u058F_u083Dۀڃ)
		{
		}
		bool ӄגࠇ٦ = this.Ӄגࠇ٦;
		if (ӄגࠇ٦)
		{
			if (!ӄגࠇ٦)
			{
			}
			return;
		}
		bool u0700ݤڑޡ = this.\u0700ݤڑޡ;
		bool u0876կࢹջ = this.\u0876կࢹջ;
		if (u0700ݤڑޡ)
		{
			if (!u0876կࢹջ)
			{
				Vector3 position = base.transform.position;
				LayerMask u0733ڰ_u0737ݿ = this.\u0733ڰ\u0737ݿ;
				float num = this.ٸյՈڙ;
				int num2 = u0733ڰ_u0737ݿ;
				if (u0700ݤڑޡ)
				{
					if (u0700ݤڑޡ)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint ٹ_u05C3_u0736۱ = base.gameObject.AddComponent<FixedJoint>();
						this.ٹ\u05C3\u0736۱ = ٹ_u05C3_u0736۱;
						if (typeof(UnityEngine.Object).TypeHandle == null)
						{
						}
						bool flag = attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.ߠނࢤࢹ;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long u0876կࢹջ2 = 1L;
					this.\u0876կࢹջ = (u0876կࢹջ2 != 0L);
				}
			}
		}
		else if (u0876կࢹջ)
		{
			long num3 = 1L;
			this.\u0876կࢹջ = (num3 != 0L);
			FixedJoint ٹ_u05C3_u0736۱2 = this.ٹ\u05C3\u0736۱;
			if (num3 == 0L)
			{
			}
			bool flag2 = ٹ_u05C3_u0736۱2;
			FixedJoint ٹ_u05C3_u0736۱3 = this.ٹ\u05C3\u0736۱;
			if (num3 == 0L)
			{
			}
			UnityEngine.Object.Destroy(ٹ_u05C3_u0736۱3);
			Transform transform4 = this.ߠނࢤࢹ;
			Transform u0835_u070Dࡂ_u070B = this.\u0835\u070Dࡂ\u070B;
			transform4.SetParent(u0835_u070Dࡂ_u070B);
			return;
		}
	}

	// Token: 0x0600159C RID: 5532 RVA: 0x00079674 File Offset: 0x00077874
	[Token(Token = "0x600159C")]
	[Address(RVA = "0x2FAAEC8", Offset = "0x2FAAEC8", VA = "0x2FAAEC8")]
	private void \u07F9\u07B5Ԃࡥ()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x0600159D RID: 5533 RVA: 0x0007969C File Offset: 0x0007789C
	[Token(Token = "0x600159D")]
	[Address(RVA = "0x2FAAF04", Offset = "0x2FAAF04", VA = "0x2FAAF04")]
	private void Ӌ\u06DC\u073Cױ()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x0600159E RID: 5534 RVA: 0x000796C4 File Offset: 0x000778C4
	[Token(Token = "0x600159E")]
	[Address(RVA = "0x2FAAF40", Offset = "0x2FAAF40", VA = "0x2FAAF40")]
	private void OnDrawGizmos()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x0600159F RID: 5535 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600159F")]
	[Address(RVA = "0x2FAAF7C", Offset = "0x2FAAF7C", VA = "0x2FAAF7C")]
	public void րࢢ\u0830Ӥ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060015A0 RID: 5536 RVA: 0x000796EC File Offset: 0x000778EC
	[Token(Token = "0x60015A0")]
	[Address(RVA = "0x2FAB078", Offset = "0x2FAB078", VA = "0x2FAB078")]
	private void ࠉد\u087Cӭ()
	{
		Vector3 position = base.transform.position;
		float num = this.ٸյՈڙ;
	}

	// Token: 0x040002AC RID: 684
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002AC")]
	public float ٸյՈڙ = (float)52429;

	// Token: 0x040002AD RID: 685
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40002AD")]
	public LayerMask \u0733ڰ\u0737ݿ;

	// Token: 0x040002AE RID: 686
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002AE")]
	private InputDevice ࠊފ\u064FӪ;

	// Token: 0x040002AF RID: 687
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40002AF")]
	private InputDevice ߌԙՏޚ;

	// Token: 0x040002B0 RID: 688
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40002B0")]
	public bool \u0700ݤڑޡ;

	// Token: 0x040002B1 RID: 689
	[FieldOffset(Offset = "0x41")]
	[Token(Token = "0x40002B1")]
	public bool \u058F\u083Dۀڃ;

	// Token: 0x040002B2 RID: 690
	[FieldOffset(Offset = "0x42")]
	[Token(Token = "0x40002B2")]
	public bool Ӄגࠇ٦;

	// Token: 0x040002B3 RID: 691
	[FieldOffset(Offset = "0x43")]
	[Token(Token = "0x40002B3")]
	private bool \u0876կࢹջ;

	// Token: 0x040002B4 RID: 692
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40002B4")]
	private FixedJoint ٹ\u05C3\u0736۱;

	// Token: 0x040002B5 RID: 693
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40002B5")]
	private FixedJoint ࡃ\u05C1\u066B\u060A;

	// Token: 0x040002B6 RID: 694
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40002B6")]
	public Transform ߠނࢤࢹ;

	// Token: 0x040002B7 RID: 695
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x40002B7")]
	public Transform \u0835\u070Dࡂ\u070B;
}
