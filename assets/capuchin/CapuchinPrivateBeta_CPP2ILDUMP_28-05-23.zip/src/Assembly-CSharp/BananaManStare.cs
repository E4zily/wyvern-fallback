﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000097 RID: 151
[Token(Token = "0x2000097")]
public class BananaManStare : MonoBehaviour
{
	// Token: 0x060016A7 RID: 5799 RVA: 0x000805EC File Offset: 0x0007E7EC
	[Token(Token = "0x60016A7")]
	[Address(RVA = "0x2C0EAAC", Offset = "0x2C0EAAC", VA = "0x2C0EAAC")]
	public void \u0872יԁӦ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 0L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Transform ӹղ_u0599ޓ = this.ӹղ\u0599ޓ;
		float x = this.ڒӲٵٴ.x;
		float y = this.ڒӲٵٴ.y;
		float z = this.ڒӲٵٴ.z;
		float w = this.ڒӲٵٴ.w;
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 0L;
		u0890_u0704_u074AԪ.SetBool("make more points bobo", value != 0L);
	}

	// Token: 0x060016A8 RID: 5800 RVA: 0x0008067C File Offset: 0x0007E87C
	[Token(Token = "0x60016A8")]
	[Address(RVA = "0x2C0EB90", Offset = "0x2C0EB90", VA = "0x2C0EB90")]
	private IEnumerator ࠐ\u06E8ؾ\u0745()
	{
		long <>1__state;
		BananaManStare.Ӿߖ\u088Eۀ ӿߖ_u088Eۀ = new BananaManStare.Ӿߖ\u088Eۀ((int)<>1__state);
		<>1__state = 0L;
		ӿߖ_u088Eۀ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060016A9 RID: 5801 RVA: 0x000806A0 File Offset: 0x0007E8A0
	[Token(Token = "0x60016A9")]
	[Address(RVA = "0x2C0EC08", Offset = "0x2C0EC08", VA = "0x2C0EC08")]
	private IEnumerator \u05FD߀ڕ\u06EB()
	{
		long <>1__state;
		BananaManStare.Ӿߖ\u088Eۀ ӿߖ_u088Eۀ = new BananaManStare.Ӿߖ\u088Eۀ((int)<>1__state);
		<>1__state = 0L;
		ӿߖ_u088Eۀ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060016AA RID: 5802 RVA: 0x000806C4 File Offset: 0x0007E8C4
	[Token(Token = "0x60016AA")]
	[Address(RVA = "0x2C0EC80", Offset = "0x2C0EC80", VA = "0x2C0EC80")]
	public void ࢲ\u061C\u0817ݽ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 1L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Transform ӹղ_u0599ޓ = this.ӹղ\u0599ޓ;
		float x = this.ڒӲٵٴ.x;
		float y = this.ڒӲٵٴ.y;
		float z = this.ڒӲٵٴ.z;
		float w = this.ڒӲٵٴ.w;
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.", value != 0L);
	}

	// Token: 0x060016AB RID: 5803 RVA: 0x00080754 File Offset: 0x0007E954
	[Token(Token = "0x60016AB")]
	[Address(RVA = "0x2C0ED64", Offset = "0x2C0ED64", VA = "0x2C0ED64")]
	private IEnumerator ԝ\u07B7\u087EӤ()
	{
		long <>1__state;
		BananaManStare.Ӿߖ\u088Eۀ ӿߖ_u088Eۀ = new BananaManStare.Ӿߖ\u088Eۀ((int)<>1__state);
		<>1__state = 0L;
		ӿߖ_u088Eۀ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060016AC RID: 5804 RVA: 0x00080778 File Offset: 0x0007E978
	[Token(Token = "0x60016AC")]
	[Address(RVA = "0x2C0EDDC", Offset = "0x2C0EDDC", VA = "0x2C0EDDC")]
	private IEnumerator \u0615ڛԐݾ()
	{
		long <>1__state;
		BananaManStare.Ӿߖ\u088Eۀ ӿߖ_u088Eۀ = new BananaManStare.Ӿߖ\u088Eۀ((int)<>1__state);
		<>1__state = 1L;
		ӿߖ_u088Eۀ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060016AD RID: 5805 RVA: 0x0008079C File Offset: 0x0007E99C
	[Token(Token = "0x60016AD")]
	[Address(RVA = "0x2C0EE54", Offset = "0x2C0EE54", VA = "0x2C0EE54")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Name Changing Error. Error: ";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 0L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("Player", value != 0L);
		IEnumerator routine = this.\u05FD߀ڕ\u06EB();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060016AE RID: 5806 RVA: 0x00080800 File Offset: 0x0007EA00
	[Token(Token = "0x60016AE")]
	[Address(RVA = "0x2C0EF38", Offset = "0x2C0EF38", VA = "0x2C0EF38")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 1L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("PlayWave", value != 0L);
		IEnumerator routine = this.\u05FD߀ڕ\u06EB();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060016AF RID: 5807 RVA: 0x00080864 File Offset: 0x0007EA64
	[Token(Token = "0x60016AF")]
	[Address(RVA = "0x2C0F01C", Offset = "0x2C0F01C", VA = "0x2C0F01C")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 0L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("FLSPTLT", value != 0L);
		IEnumerator routine = this.ԝ\u07B7\u087EӤ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060016B0 RID: 5808 RVA: 0x000808C8 File Offset: 0x0007EAC8
	[Token(Token = "0x60016B0")]
	[Address(RVA = "0x2C0F100", Offset = "0x2C0F100", VA = "0x2C0F100")]
	public void \u085Cݯژ\u05FA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 1L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Transform ӹղ_u0599ޓ = this.ӹղ\u0599ޓ;
		float x = this.ڒӲٵٴ.x;
		float y = this.ڒӲٵٴ.y;
		float z = this.ڒӲٵٴ.z;
		float w = this.ڒӲٵٴ.w;
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("Reason: ", value != 0L);
	}

	// Token: 0x060016B1 RID: 5809 RVA: 0x00080958 File Offset: 0x0007EB58
	[Token(Token = "0x60016B1")]
	[Address(RVA = "0x2C0F1E4", Offset = "0x2C0F1E4", VA = "0x2C0F1E4")]
	public void \u0589\u0740\u05C6ӧ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Try Connect To Server...";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 1L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Transform ӹղ_u0599ޓ = this.ӹղ\u0599ޓ;
		float x = this.ڒӲٵٴ.x;
		float y = this.ڒӲٵٴ.y;
		float z = this.ڒӲٵٴ.z;
		float w = this.ڒӲٵٴ.w;
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 0L;
		u0890_u0704_u074AԪ.SetBool("2BN", value != 0L);
	}

	// Token: 0x060016B2 RID: 5810 RVA: 0x000809E8 File Offset: 0x0007EBE8
	[Token(Token = "0x60016B2")]
	[Address(RVA = "0x2C0F2C8", Offset = "0x2C0F2C8", VA = "0x2C0F2C8")]
	public BananaManStare()
	{
	}

	// Token: 0x060016B3 RID: 5811 RVA: 0x000809FC File Offset: 0x0007EBFC
	[Token(Token = "0x60016B3")]
	[Address(RVA = "0x2C0F2D0", Offset = "0x2C0F2D0", VA = "0x2C0F2D0")]
	public void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Combine textures & build combined mesh all at once";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 1L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Transform ӹղ_u0599ޓ = this.ӹղ\u0599ޓ;
		float x = this.ڒӲٵٴ.x;
		float y = this.ڒӲٵٴ.y;
		float z = this.ڒӲٵٴ.z;
		float w = this.ڒӲٵٴ.w;
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 0L;
		u0890_u0704_u074AԪ.SetBool("monke screamed", value != 0L);
	}

	// Token: 0x060016B4 RID: 5812 RVA: 0x00080A8C File Offset: 0x0007EC8C
	[Token(Token = "0x60016B4")]
	[Address(RVA = "0x2C0F3B4", Offset = "0x2C0F3B4", VA = "0x2C0F3B4")]
	public void ࢳ\u06D8Ԙ\u05FD(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "monke screamed";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 1L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Transform ӹղ_u0599ޓ = this.ӹղ\u0599ޓ;
		float x = this.ڒӲٵٴ.x;
		float y = this.ڒӲٵٴ.y;
		float z = this.ڒӲٵٴ.z;
		float w = this.ڒӲٵٴ.w;
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("\n", value != 0L);
	}

	// Token: 0x060016B5 RID: 5813 RVA: 0x00080B18 File Offset: 0x0007ED18
	[Token(Token = "0x60016B5")]
	[Address(RVA = "0x2C0F498", Offset = "0x2C0F498", VA = "0x2C0F498")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 0L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("A Player has left the Room.", value != 0L);
		IEnumerator routine = this.ԝ\u07B7\u087EӤ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060016B6 RID: 5814 RVA: 0x00080B7C File Offset: 0x0007ED7C
	[Token(Token = "0x60016B6")]
	[Address(RVA = "0x2C0F57C", Offset = "0x2C0F57C", VA = "0x2C0F57C")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Joined a Room.";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 0L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("PRESS AGAIN TO CONFIRM", value != 0L);
		IEnumerator routine = this.\u0615ڛԐݾ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060016B7 RID: 5815 RVA: 0x00080BE0 File Offset: 0x0007EDE0
	[Token(Token = "0x60016B7")]
	[Address(RVA = "0x2C0F660", Offset = "0x2C0F660", VA = "0x2C0F660")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "true";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 0L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("ErrorScreen", value != 0L);
		IEnumerator routine = this.\u05FD߀ڕ\u06EB();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060016B8 RID: 5816 RVA: 0x00080C44 File Offset: 0x0007EE44
	[Token(Token = "0x60016B8")]
	[Address(RVA = "0x2C0F744", Offset = "0x2C0F744", VA = "0x2C0F744")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 0L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Transform ӹղ_u0599ޓ = this.ӹղ\u0599ޓ;
		float x = this.ڒӲٵٴ.x;
		float y = this.ڒӲٵٴ.y;
		float z = this.ڒӲٵٴ.z;
		float w = this.ڒӲٵٴ.w;
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 0L;
		u0890_u0704_u074AԪ.SetBool("PlayWave", value != 0L);
	}

	// Token: 0x060016B9 RID: 5817 RVA: 0x00080CD4 File Offset: 0x0007EED4
	[Token(Token = "0x60016B9")]
	[Address(RVA = "0x2C0F828", Offset = "0x2C0F828", VA = "0x2C0F828")]
	public void Ԍߊٱݩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Game Started";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 1L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Transform ӹղ_u0599ޓ = this.ӹղ\u0599ޓ;
		float x = this.ڒӲٵٴ.x;
		float y = this.ڒӲٵٴ.y;
		float z = this.ڒӲٵٴ.z;
		float w = this.ڒӲٵٴ.w;
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("SetColor", value != 0L);
	}

	// Token: 0x060016BA RID: 5818 RVA: 0x00080D64 File Offset: 0x0007EF64
	[Token(Token = "0x60016BA")]
	[Address(RVA = "0x2C0F90C", Offset = "0x2C0F90C", VA = "0x2C0F90C")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 0L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 0L;
		u0890_u0704_u074AԪ.SetBool("PushToTalk", value != 0L);
		IEnumerator routine = this.\u05FD߀ڕ\u06EB();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060016BB RID: 5819 RVA: 0x00080DC8 File Offset: 0x0007EFC8
	[Token(Token = "0x60016BB")]
	[Address(RVA = "0x2C0F9F0", Offset = "0x2C0F9F0", VA = "0x2C0F9F0")]
	public void \u0872\u0610ۅ\u06E1(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u089Eսࢣ_u = this.\u089Eսࢣ\u0615;
		long active = 1L;
		u089Eսࢣ_u.SetActive(active != 0L);
		Transform ӹղ_u0599ޓ = this.ӹղ\u0599ޓ;
		float x = this.ڒӲٵٴ.x;
		float y = this.ڒӲٵٴ.y;
		float z = this.ڒӲٵٴ.z;
		float w = this.ڒӲٵٴ.w;
		Animator u0890_u0704_u074AԪ = this.\u0890\u0704\u074AԪ;
		long value = 1L;
		u0890_u0704_u074AԪ.SetBool("tutorialCheck", value != 0L);
	}

	// Token: 0x040002D1 RID: 721
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002D1")]
	public GameObject \u089Eսࢣ\u0615;

	// Token: 0x040002D2 RID: 722
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002D2")]
	public Transform ӹղ\u0599ޓ;

	// Token: 0x040002D3 RID: 723
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40002D3")]
	public Quaternion ڒӲٵٴ;

	// Token: 0x040002D4 RID: 724
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40002D4")]
	public Animator \u0890\u0704\u074AԪ;
}
