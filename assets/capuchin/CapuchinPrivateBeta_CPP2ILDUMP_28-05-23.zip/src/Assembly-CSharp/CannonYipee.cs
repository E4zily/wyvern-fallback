﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000031 RID: 49
[Token(Token = "0x2000031")]
public class CannonYipee : MonoBehaviour
{
	// Token: 0x06000589 RID: 1417 RVA: 0x0001F91C File Offset: 0x0001DB1C
	[Token(Token = "0x6000589")]
	[Address(RVA = "0x2723708", Offset = "0x2723708", VA = "0x2723708")]
	private void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "isLava";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x0600058A RID: 1418 RVA: 0x0001F950 File Offset: 0x0001DB50
	[Token(Token = "0x600058A")]
	[Address(RVA = "0x2723790", Offset = "0x2723790", VA = "0x2723790")]
	public IEnumerator ࡪצԴࡣ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600058B RID: 1419 RVA: 0x0001F974 File Offset: 0x0001DB74
	[Token(Token = "0x600058B")]
	[Address(RVA = "0x2723808", Offset = "0x2723808", VA = "0x2723808")]
	private void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "amongus";
	}

	// Token: 0x0600058C RID: 1420 RVA: 0x0001F9A0 File Offset: 0x0001DBA0
	[Token(Token = "0x600058C")]
	[Address(RVA = "0x272388C", Offset = "0x272388C", VA = "0x272388C")]
	public IEnumerator ӿԴۄ\u05B9()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600058D RID: 1421 RVA: 0x0001F9C4 File Offset: 0x0001DBC4
	[Token(Token = "0x600058D")]
	[Address(RVA = "0x2723904", Offset = "0x2723904", VA = "0x2723904")]
	public IEnumerator ӑԭوՇ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600058E RID: 1422 RVA: 0x0001F9E8 File Offset: 0x0001DBE8
	[Token(Token = "0x600058E")]
	[Address(RVA = "0x272397C", Offset = "0x272397C", VA = "0x272397C")]
	private void \u0892ܒܬޓ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position2 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position3 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x0600058F RID: 1423 RVA: 0x0001FB64 File Offset: 0x0001DD64
	[Token(Token = "0x600058F")]
	[Address(RVA = "0x2723D8C", Offset = "0x2723D8C", VA = "0x2723D8C")]
	private void ݍ\u05F4ߓ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Failed to login, please restart";
	}

	// Token: 0x06000590 RID: 1424 RVA: 0x0001FB90 File Offset: 0x0001DD90
	[Token(Token = "0x6000590")]
	[Address(RVA = "0x2723E10", Offset = "0x2723E10", VA = "0x2723E10")]
	public IEnumerator \u0739ڮӰ\u086D()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000591 RID: 1425 RVA: 0x0001FBB4 File Offset: 0x0001DDB4
	[Token(Token = "0x6000591")]
	[Address(RVA = "0x2723E88", Offset = "0x2723E88", VA = "0x2723E88")]
	public IEnumerator חݦՂݯ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000592 RID: 1426 RVA: 0x0001FBD8 File Offset: 0x0001DDD8
	[Token(Token = "0x6000592")]
	[Address(RVA = "0x2723F00", Offset = "0x2723F00", VA = "0x2723F00")]
	private void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Players In Room: ";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x06000593 RID: 1427 RVA: 0x0001FC0C File Offset: 0x0001DE0C
	[Token(Token = "0x6000593")]
	[Address(RVA = "0x2723F88", Offset = "0x2723F88", VA = "0x2723F88")]
	public IEnumerator \u0870\u06E1ߒࡂ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000594 RID: 1428 RVA: 0x0001FC30 File Offset: 0x0001DE30
	[Token(Token = "0x6000594")]
	[Address(RVA = "0x2724000", Offset = "0x2724000", VA = "0x2724000")]
	public IEnumerator ە\u05B3\u0651\u0602()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000595 RID: 1429 RVA: 0x0001FC54 File Offset: 0x0001DE54
	[Token(Token = "0x6000595")]
	[Address(RVA = "0x2724078", Offset = "0x2724078", VA = "0x2724078")]
	private void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "FLSPTLT";
	}

	// Token: 0x06000596 RID: 1430 RVA: 0x0001FC80 File Offset: 0x0001DE80
	[Token(Token = "0x6000596")]
	[Address(RVA = "0x27240FC", Offset = "0x27240FC", VA = "0x27240FC")]
	private void ؤ\u05C8ԛ\u083F()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x06000597 RID: 1431 RVA: 0x0001FE14 File Offset: 0x0001E014
	[Token(Token = "0x6000597")]
	[Address(RVA = "0x2724498", Offset = "0x2724498", VA = "0x2724498")]
	public IEnumerator \u06DAӞࠌ\u065A()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x06000598 RID: 1432 RVA: 0x0001FE30 File Offset: 0x0001E030
	[Token(Token = "0x6000598")]
	[Address(RVA = "0x2724510", Offset = "0x2724510", VA = "0x2724510")]
	private void Փ\u06DF\u0839ԟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Not enough amount of currency";
	}

	// Token: 0x06000599 RID: 1433 RVA: 0x0001FE5C File Offset: 0x0001E05C
	[Token(Token = "0x6000599")]
	[Address(RVA = "0x2724594", Offset = "0x2724594", VA = "0x2724594")]
	private void \u0654ޛ\u07FAذ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x0600059A RID: 1434 RVA: 0x0001FFE0 File Offset: 0x0001E1E0
	[Token(Token = "0x600059A")]
	[Address(RVA = "0x2724910", Offset = "0x2724910", VA = "0x2724910")]
	private void \u05B3ࢹߧ\u07AA()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x0600059B RID: 1435 RVA: 0x00020170 File Offset: 0x0001E370
	[Token(Token = "0x600059B")]
	[Address(RVA = "0x2724D14", Offset = "0x2724D14", VA = "0x2724D14")]
	public IEnumerator ݵԔ\u06EBԂ()
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600059C RID: 1436 RVA: 0x00020184 File Offset: 0x0001E384
	[Token(Token = "0x600059C")]
	[Address(RVA = "0x2724D8C", Offset = "0x2724D8C", VA = "0x2724D8C")]
	private void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "ChangePlayerSize";
	}

	// Token: 0x0600059D RID: 1437 RVA: 0x000201B0 File Offset: 0x0001E3B0
	[Token(Token = "0x600059D")]
	[Address(RVA = "0x2724E10", Offset = "0x2724E10", VA = "0x2724E10")]
	public IEnumerator \u05AFڻ\u07FE\u05F5()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600059E RID: 1438 RVA: 0x000201D4 File Offset: 0x0001E3D4
	[Token(Token = "0x600059E")]
	[Address(RVA = "0x2724C9C", Offset = "0x2724C9C", VA = "0x2724C9C")]
	public IEnumerator ࠍ\u06ED\u07F9ٯ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600059F RID: 1439 RVA: 0x000201F8 File Offset: 0x0001E3F8
	[Token(Token = "0x600059F")]
	[Address(RVA = "0x2724E88", Offset = "0x2724E88", VA = "0x2724E88")]
	private void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "_BumpScale";
	}

	// Token: 0x060005A0 RID: 1440 RVA: 0x00020224 File Offset: 0x0001E424
	[Token(Token = "0x60005A0")]
	[Address(RVA = "0x2724F0C", Offset = "0x2724F0C", VA = "0x2724F0C")]
	private void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "A new Player joined a Room.";
	}

	// Token: 0x060005A1 RID: 1441 RVA: 0x00020250 File Offset: 0x0001E450
	[Token(Token = "0x60005A1")]
	[Address(RVA = "0x2724F90", Offset = "0x2724F90", VA = "0x2724F90")]
	private void צ\u0874ڵ\u059A()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005A2 RID: 1442 RVA: 0x000203E4 File Offset: 0x0001E5E4
	[Token(Token = "0x60005A2")]
	[Address(RVA = "0x27253A8", Offset = "0x27253A8", VA = "0x27253A8")]
	private void ػԚԃڻ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "PRESS AGAIN TO CONFIRM";
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x00020410 File Offset: 0x0001E610
	[Token(Token = "0x60005A3")]
	[Address(RVA = "0x272542C", Offset = "0x272542C", VA = "0x272542C")]
	private void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "username";
	}

	// Token: 0x060005A4 RID: 1444 RVA: 0x0002043C File Offset: 0x0001E63C
	[Token(Token = "0x60005A4")]
	[Address(RVA = "0x27254B0", Offset = "0x27254B0", VA = "0x27254B0")]
	public IEnumerator ל\u0654\u05AB߈()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005A5 RID: 1445 RVA: 0x00020460 File Offset: 0x0001E660
	[Token(Token = "0x60005A5")]
	[Address(RVA = "0x2725528", Offset = "0x2725528", VA = "0x2725528")]
	private void \u0832ࢳޤ\u07B5()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
				Vector3 position = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position2 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position3 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005A6 RID: 1446 RVA: 0x00020604 File Offset: 0x0001E804
	[Token(Token = "0x60005A6")]
	[Address(RVA = "0x27258CC", Offset = "0x27258CC", VA = "0x27258CC")]
	private void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Time to bake textures: ";
	}

	// Token: 0x060005A7 RID: 1447 RVA: 0x00020630 File Offset: 0x0001E830
	[Token(Token = "0x60005A7")]
	[Address(RVA = "0x2725950", Offset = "0x2725950", VA = "0x2725950")]
	private void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Name Changing Error. Error: ";
	}

	// Token: 0x060005A8 RID: 1448 RVA: 0x0002065C File Offset: 0x0001E85C
	[Token(Token = "0x60005A8")]
	[Address(RVA = "0x27259D4", Offset = "0x27259D4", VA = "0x27259D4")]
	public IEnumerator Հؼ\u0608Շ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005A9 RID: 1449 RVA: 0x00020680 File Offset: 0x0001E880
	[Token(Token = "0x60005A9")]
	[Address(RVA = "0x2725A4C", Offset = "0x2725A4C", VA = "0x2725A4C")]
	public IEnumerator ࠏߩף\u085F()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005AA RID: 1450 RVA: 0x000206A4 File Offset: 0x0001E8A4
	[Token(Token = "0x60005AA")]
	[Address(RVA = "0x2725AC4", Offset = "0x2725AC4", VA = "0x2725AC4")]
	public IEnumerator \u070Aר\u07FA\u06E5()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005AB RID: 1451 RVA: 0x000206C8 File Offset: 0x0001E8C8
	[Token(Token = "0x60005AB")]
	[Address(RVA = "0x2725B3C", Offset = "0x2725B3C", VA = "0x2725B3C")]
	private void \u0614ࢥӴ\u086C()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005AC RID: 1452 RVA: 0x0002085C File Offset: 0x0001EA5C
	[Token(Token = "0x60005AC")]
	[Address(RVA = "0x2725F38", Offset = "0x2725F38", VA = "0x2725F38")]
	public IEnumerator \u0606ߒ\u07F6\u05BC()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005AD RID: 1453 RVA: 0x00020880 File Offset: 0x0001EA80
	[Token(Token = "0x60005AD")]
	[Address(RVA = "0x2725FB0", Offset = "0x2725FB0", VA = "0x2725FB0")]
	private void Ԡݘעࠀ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
				Vector3 position = u081B_u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005AE RID: 1454 RVA: 0x00020A18 File Offset: 0x0001EC18
	[Token(Token = "0x60005AE")]
	[Address(RVA = "0x2726340", Offset = "0x2726340", VA = "0x2726340")]
	private void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "false";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x060005AF RID: 1455 RVA: 0x00020A4C File Offset: 0x0001EC4C
	[Token(Token = "0x60005AF")]
	[Address(RVA = "0x27263C8", Offset = "0x27263C8", VA = "0x27263C8")]
	private void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "isLava";
	}

	// Token: 0x060005B0 RID: 1456 RVA: 0x00020A78 File Offset: 0x0001EC78
	[Token(Token = "0x60005B0")]
	[Address(RVA = "0x272644C", Offset = "0x272644C", VA = "0x272644C")]
	private void ד\u073C\u0613چ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005B1 RID: 1457 RVA: 0x00020C04 File Offset: 0x0001EE04
	[Token(Token = "0x60005B1")]
	[Address(RVA = "0x27267C8", Offset = "0x27267C8", VA = "0x27267C8")]
	public IEnumerator Ӎե\u06E5\u05F7()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005B2 RID: 1458 RVA: 0x00020C28 File Offset: 0x0001EE28
	[Token(Token = "0x60005B2")]
	[Address(RVA = "0x2726840", Offset = "0x2726840", VA = "0x2726840")]
	private void ճ\u0828Ԓհ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Starting to bake textures on frame ";
	}

	// Token: 0x060005B3 RID: 1459 RVA: 0x00020C54 File Offset: 0x0001EE54
	[Token(Token = "0x60005B3")]
	[Address(RVA = "0x27268C4", Offset = "0x27268C4", VA = "0x27268C4")]
	private void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Network Player";
	}

	// Token: 0x060005B4 RID: 1460 RVA: 0x00020C80 File Offset: 0x0001EE80
	[Token(Token = "0x60005B4")]
	[Address(RVA = "0x2726948", Offset = "0x2726948", VA = "0x2726948")]
	public IEnumerator ލג߃ݢ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005B5 RID: 1461 RVA: 0x00020CA4 File Offset: 0x0001EEA4
	[Token(Token = "0x60005B5")]
	[Address(RVA = "0x27269C0", Offset = "0x27269C0", VA = "0x27269C0")]
	private void Ӣ\u0592ߨׯ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x00020E4C File Offset: 0x0001F04C
	[Token(Token = "0x60005B6")]
	[Address(RVA = "0x2726D4C", Offset = "0x2726D4C", VA = "0x2726D4C")]
	public IEnumerator ڙڠԣ\u06E3()
	{
		throw new NullReferenceException();
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x00020E60 File Offset: 0x0001F060
	[Token(Token = "0x60005B7")]
	[Address(RVA = "0x2726DC4", Offset = "0x2726DC4", VA = "0x2726DC4")]
	public CannonYipee()
	{
	}

	// Token: 0x060005B8 RID: 1464 RVA: 0x00020E74 File Offset: 0x0001F074
	[Token(Token = "0x60005B8")]
	[Address(RVA = "0x2726DCC", Offset = "0x2726DCC", VA = "0x2726DCC")]
	private void Ԉ۴ࡉࢬ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005B9 RID: 1465 RVA: 0x00021004 File Offset: 0x0001F204
	[Token(Token = "0x60005B9")]
	[Address(RVA = "0x27271C0", Offset = "0x27271C0", VA = "0x27271C0")]
	private void ڷ\u0826ӹڥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Player";
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x00021030 File Offset: 0x0001F230
	[Token(Token = "0x60005BA")]
	[Address(RVA = "0x2727244", Offset = "0x2727244", VA = "0x2727244")]
	private void \u0705\u0816\u0739դ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x000211D8 File Offset: 0x0001F3D8
	[Token(Token = "0x60005BB")]
	[Address(RVA = "0x27275E8", Offset = "0x27275E8", VA = "0x27275E8")]
	private void ߑ\u0885\u05BBߕ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005BC RID: 1468 RVA: 0x0002138C File Offset: 0x0001F58C
	[Token(Token = "0x60005BC")]
	[Address(RVA = "0x2727990", Offset = "0x2727990", VA = "0x2727990")]
	public IEnumerator ۸\u086B\u06ED\u05EB()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005BD RID: 1469 RVA: 0x000213B0 File Offset: 0x0001F5B0
	[Token(Token = "0x60005BD")]
	[Address(RVA = "0x2727A08", Offset = "0x2727A08", VA = "0x2727A08")]
	private void \u070Aәޣے()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005BE RID: 1470 RVA: 0x00021558 File Offset: 0x0001F758
	[Token(Token = "0x60005BE")]
	[Address(RVA = "0x2727DAC", Offset = "0x2727DAC", VA = "0x2727DAC")]
	public IEnumerator ڄڰڑդ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x0002157C File Offset: 0x0001F77C
	[Token(Token = "0x60005BF")]
	[Address(RVA = "0x2727E24", Offset = "0x2727E24", VA = "0x2727E24")]
	private void \u07F5\u0657\u055Aߍ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x00021728 File Offset: 0x0001F928
	[Token(Token = "0x60005C0")]
	[Address(RVA = "0x27281C4", Offset = "0x27281C4", VA = "0x27281C4")]
	private void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Player";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x060005C1 RID: 1473 RVA: 0x0002175C File Offset: 0x0001F95C
	[Token(Token = "0x60005C1")]
	[Address(RVA = "0x272824C", Offset = "0x272824C", VA = "0x272824C")]
	public IEnumerator \u05C9ࢱԄ\u05C7()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005C2 RID: 1474 RVA: 0x00021780 File Offset: 0x0001F980
	[Token(Token = "0x60005C2")]
	[Address(RVA = "0x27282C4", Offset = "0x27282C4", VA = "0x27282C4")]
	private void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "ErrorScreen";
	}

	// Token: 0x060005C3 RID: 1475 RVA: 0x000217AC File Offset: 0x0001F9AC
	[Token(Token = "0x60005C3")]
	[Address(RVA = "0x2723D14", Offset = "0x2723D14", VA = "0x2723D14")]
	public IEnumerator \u05C9ࢫ\u089B\u0835()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005C4 RID: 1476 RVA: 0x000217D0 File Offset: 0x0001F9D0
	[Token(Token = "0x60005C4")]
	[Address(RVA = "0x2728348", Offset = "0x2728348", VA = "0x2728348")]
	private void ފՖߢ\u059B()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005C5 RID: 1477 RVA: 0x0002197C File Offset: 0x0001FB7C
	[Token(Token = "0x60005C5")]
	[Address(RVA = "0x27286EC", Offset = "0x27286EC", VA = "0x27286EC")]
	public IEnumerator \u0898٩\u0889\u0881()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005C6 RID: 1478 RVA: 0x000219A0 File Offset: 0x0001FBA0
	[Token(Token = "0x60005C6")]
	[Address(RVA = "0x2728764", Offset = "0x2728764", VA = "0x2728764")]
	private void \u087BӦןݩ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005C7 RID: 1479 RVA: 0x00021B48 File Offset: 0x0001FD48
	[Token(Token = "0x60005C7")]
	[Address(RVA = "0x2728B80", Offset = "0x2728B80", VA = "0x2728B80")]
	public IEnumerator כӇܚ\u085D()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005C8 RID: 1480 RVA: 0x00021B6C File Offset: 0x0001FD6C
	[Token(Token = "0x60005C8")]
	[Address(RVA = "0x2728BF8", Offset = "0x2728BF8", VA = "0x2728BF8")]
	private void ݫࢷࠃ\u0820()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005C9 RID: 1481 RVA: 0x00021CFC File Offset: 0x0001FEFC
	[Token(Token = "0x60005C9")]
	[Address(RVA = "0x2728F88", Offset = "0x2728F88", VA = "0x2728F88")]
	private void ݛ\u0599\u05C2ڒ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005CA RID: 1482 RVA: 0x00021EA8 File Offset: 0x000200A8
	[Token(Token = "0x60005CA")]
	[Address(RVA = "0x2725EC0", Offset = "0x2725EC0", VA = "0x2725EC0")]
	public IEnumerator \u06E2\u0748\u05BF\u06DB()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005CB RID: 1483 RVA: 0x00021ECC File Offset: 0x000200CC
	[Token(Token = "0x60005CB")]
	[Address(RVA = "0x272932C", Offset = "0x272932C", VA = "0x272932C")]
	private void ٠ӄ\u087Cٸ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005CC RID: 1484 RVA: 0x0002205C File Offset: 0x0002025C
	[Token(Token = "0x60005CC")]
	[Address(RVA = "0x27296B4", Offset = "0x27296B4", VA = "0x27296B4")]
	private void \u0886Ҽ\u058Dߛ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005CD RID: 1485 RVA: 0x000221F0 File Offset: 0x000203F0
	[Token(Token = "0x60005CD")]
	[Address(RVA = "0x2729AA8", Offset = "0x2729AA8", VA = "0x2729AA8")]
	private void \u0870\u05B3Ց\u066A()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x00022384 File Offset: 0x00020584
	[Token(Token = "0x60005CE")]
	[Address(RVA = "0x2729E44", Offset = "0x2729E44", VA = "0x2729E44")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "PlayerHead";
	}

	// Token: 0x060005CF RID: 1487 RVA: 0x000223B0 File Offset: 0x000205B0
	[Token(Token = "0x60005CF")]
	[Address(RVA = "0x2729ECC", Offset = "0x2729ECC", VA = "0x2729ECC")]
	private void \u07FE\u0882Զ\u066D()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005D0 RID: 1488 RVA: 0x00022554 File Offset: 0x00020754
	[Token(Token = "0x60005D0")]
	[Address(RVA = "0x2725330", Offset = "0x2725330", VA = "0x2725330")]
	public IEnumerator \u05A9ސק\u06E9()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005D1 RID: 1489 RVA: 0x00022578 File Offset: 0x00020778
	[Token(Token = "0x60005D1")]
	[Address(RVA = "0x272A270", Offset = "0x272A270", VA = "0x272A270")]
	private void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "true";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x060005D2 RID: 1490 RVA: 0x000225AC File Offset: 0x000207AC
	[Token(Token = "0x60005D2")]
	[Address(RVA = "0x272A2F8", Offset = "0x272A2F8", VA = "0x272A2F8")]
	private void ޛװہװ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.name == "True";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x060005D3 RID: 1491 RVA: 0x000225DC File Offset: 0x000207DC
	[Token(Token = "0x60005D3")]
	[Address(RVA = "0x272A380", Offset = "0x272A380", VA = "0x272A380")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005D4 RID: 1492 RVA: 0x0002276C File Offset: 0x0002096C
	[Token(Token = "0x60005D4")]
	[Address(RVA = "0x272A71C", Offset = "0x272A71C", VA = "0x272A71C")]
	private void ں٢ࡡ\u05EC()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005D5 RID: 1493 RVA: 0x00022920 File Offset: 0x00020B20
	[Token(Token = "0x60005D5")]
	[Address(RVA = "0x2727148", Offset = "0x2727148", VA = "0x2727148")]
	public IEnumerator ٻࡑ\u065BՄ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x00022944 File Offset: 0x00020B44
	[Token(Token = "0x60005D6")]
	[Address(RVA = "0x272AB38", Offset = "0x272AB38", VA = "0x272AB38")]
	private void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "hand 2";
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x00022970 File Offset: 0x00020B70
	[Token(Token = "0x60005D7")]
	[Address(RVA = "0x272AAC0", Offset = "0x272AAC0", VA = "0x272AAC0")]
	public IEnumerator ݗԻԡ\u059A()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x00022994 File Offset: 0x00020B94
	[Token(Token = "0x60005D8")]
	[Address(RVA = "0x272ABBC", Offset = "0x272ABBC", VA = "0x272ABBC")]
	private void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "True";
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x000229C0 File Offset: 0x00020BC0
	[Token(Token = "0x60005D9")]
	[Address(RVA = "0x2728B08", Offset = "0x2728B08", VA = "0x2728B08")]
	public IEnumerator ހޑݩש()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005DA RID: 1498 RVA: 0x000229E4 File Offset: 0x00020BE4
	[Token(Token = "0x60005DA")]
	[Address(RVA = "0x272AC40", Offset = "0x272AC40", VA = "0x272AC40")]
	private void ԙضփӌ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005DB RID: 1499 RVA: 0x00022B98 File Offset: 0x00020D98
	[Token(Token = "0x60005DB")]
	[Address(RVA = "0x272AFE8", Offset = "0x272AFE8", VA = "0x272AFE8")]
	private void Update()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005DC RID: 1500 RVA: 0x00022D34 File Offset: 0x00020F34
	[Token(Token = "0x60005DC")]
	[Address(RVA = "0x272B370", Offset = "0x272B370", VA = "0x272B370")]
	public IEnumerator \u059EމԹټ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005DD RID: 1501 RVA: 0x00022D58 File Offset: 0x00020F58
	[Token(Token = "0x60005DD")]
	[Address(RVA = "0x272B3E8", Offset = "0x272B3E8", VA = "0x272B3E8")]
	private void ل\u0732ߍӒ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
	}

	// Token: 0x060005DE RID: 1502 RVA: 0x00022D84 File Offset: 0x00020F84
	[Token(Token = "0x60005DE")]
	[Address(RVA = "0x272B46C", Offset = "0x272B46C", VA = "0x272B46C")]
	private void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Open";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x060005DF RID: 1503 RVA: 0x00022DB8 File Offset: 0x00020FB8
	[Token(Token = "0x60005DF")]
	[Address(RVA = "0x272B4F4", Offset = "0x272B4F4", VA = "0x272B4F4")]
	private void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Purchased: ";
	}

	// Token: 0x060005E0 RID: 1504 RVA: 0x00022DE4 File Offset: 0x00020FE4
	[Token(Token = "0x60005E0")]
	[Address(RVA = "0x272B578", Offset = "0x272B578", VA = "0x272B578")]
	private void \u059Cݝ\u058E۳(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "username";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x060005E1 RID: 1505 RVA: 0x00022E18 File Offset: 0x00021018
	[Token(Token = "0x60005E1")]
	[Address(RVA = "0x272B600", Offset = "0x272B600", VA = "0x272B600")]
	private void طӏܙࢺ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005E2 RID: 1506 RVA: 0x00022FC4 File Offset: 0x000211C4
	[Token(Token = "0x60005E2")]
	[Address(RVA = "0x272B9A4", Offset = "0x272B9A4", VA = "0x272B9A4")]
	private void ۅ\u05A6\u05A4ӵ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "FingerTip";
	}

	// Token: 0x060005E3 RID: 1507 RVA: 0x00022FF0 File Offset: 0x000211F0
	[Token(Token = "0x60005E3")]
	[Address(RVA = "0x272BA28", Offset = "0x272BA28", VA = "0x272BA28")]
	private void \u089F\u085Fէ\u059A()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005E4 RID: 1508 RVA: 0x00023170 File Offset: 0x00021370
	[Token(Token = "0x60005E4")]
	[Address(RVA = "0x272BDA0", Offset = "0x272BDA0", VA = "0x272BDA0")]
	public IEnumerator ԓՋ٤ޝ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005E5 RID: 1509 RVA: 0x00023194 File Offset: 0x00021394
	[Token(Token = "0x60005E5")]
	[Address(RVA = "0x272BE18", Offset = "0x272BE18", VA = "0x272BE18")]
	private void ڑߒجވ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005E6 RID: 1510 RVA: 0x0002332C File Offset: 0x0002152C
	[Token(Token = "0x60005E6")]
	[Address(RVA = "0x272C1A8", Offset = "0x272C1A8", VA = "0x272C1A8")]
	private void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Player";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x060005E7 RID: 1511 RVA: 0x00023360 File Offset: 0x00021560
	[Token(Token = "0x60005E7")]
	[Address(RVA = "0x2729A30", Offset = "0x2729A30", VA = "0x2729A30")]
	public IEnumerator ڍ\u0656ݪށ()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 1L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060005E8 RID: 1512 RVA: 0x00023384 File Offset: 0x00021584
	[Token(Token = "0x60005E8")]
	[Address(RVA = "0x272C230", Offset = "0x272C230", VA = "0x272C230")]
	private void \u087DىԳܚ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "CapuchinRemade";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x060005E9 RID: 1513 RVA: 0x000233B8 File Offset: 0x000215B8
	[Token(Token = "0x60005E9")]
	[Address(RVA = "0x272C2B8", Offset = "0x272C2B8", VA = "0x272C2B8")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		if (this.߅ۊ\u066Aӆ)
		{
			Rigidbody rigidbody = this.نڻӷڃ;
			long u0746ࠇڛه = 1L;
			this.\u0746ࠇڛه = (u0746ࠇڛه != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.\u073C\u07B7۹Ӱ)
			{
				Vector3 position = this.\u081B\u070Aߢࡁ.position;
				Vector3 position2 = this.ӽ\u060Aݐ\u0655.position;
				float deltaTime = Time.deltaTime;
				float ӗ_u070A_u082Eڕ = this.ӗ\u070A\u082Eڕ;
				float num = Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.\u081B\u070Aߢࡁ.position;
			Vector3 position4 = this.ӽ\u060Aݐ\u0655.position;
			long u073C_u07B7۹Ӱ = 1L;
			this.\u073C\u07B7۹Ӱ = (u073C_u07B7۹Ӱ != 0L);
			return;
		}
		if (this.\u0746ࠇڛه)
		{
			Quaternion rotation = this.\u081B\u070Aߢࡁ.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x060005EA RID: 1514 RVA: 0x0002356C File Offset: 0x0002176C
	[Token(Token = "0x60005EA")]
	[Address(RVA = "0x272C660", Offset = "0x272C660", VA = "0x272C660")]
	private void ەԌ\u05C7\u085D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "NetworkPlayer";
		long ߅ۊ_u066Aӆ = 1L;
		this.߅ۊ\u066Aӆ = (߅ۊ_u066Aӆ != 0L);
	}

	// Token: 0x060005EB RID: 1515 RVA: 0x000235A0 File Offset: 0x000217A0
	[Token(Token = "0x60005EB")]
	[Address(RVA = "0x272C6E8", Offset = "0x272C6E8", VA = "0x272C6E8")]
	public IEnumerator ӑԓ\u0659\u07F3()
	{
		long <>1__state;
		CannonYipee.\u0618۸\u0703\u087B u0618۸_u0703_u087B = new CannonYipee.\u0618۸\u0703\u087B((int)<>1__state);
		<>1__state = 0L;
		u0618۸_u0703_u087B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x040000E1 RID: 225
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000E1")]
	public Transform \u081B\u070Aߢࡁ;

	// Token: 0x040000E2 RID: 226
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000E2")]
	public Rigidbody نڻӷڃ;

	// Token: 0x040000E3 RID: 227
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40000E3")]
	public Transform ࠔؼࡏݥ;

	// Token: 0x040000E4 RID: 228
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40000E4")]
	public GravityBody ٥ۻخ\u05C3;

	// Token: 0x040000E5 RID: 229
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40000E5")]
	public float \u05B9ߎܩ\u0613;

	// Token: 0x040000E6 RID: 230
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x40000E6")]
	public float ӗ\u070A\u082Eڕ;

	// Token: 0x040000E7 RID: 231
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40000E7")]
	public Transform ӽ\u060Aݐ\u0655;

	// Token: 0x040000E8 RID: 232
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40000E8")]
	public bool ߅ۊ\u066Aӆ;

	// Token: 0x040000E9 RID: 233
	[FieldOffset(Offset = "0x49")]
	[Token(Token = "0x40000E9")]
	private bool \u073C\u07B7۹Ӱ;

	// Token: 0x040000EA RID: 234
	[FieldOffset(Offset = "0x4A")]
	[Token(Token = "0x40000EA")]
	private bool \u0746ࠇڛه;

	// Token: 0x040000EB RID: 235
	[FieldOffset(Offset = "0x4B")]
	[Token(Token = "0x40000EB")]
	public bool ע\u0736\u06E2ފ;
}
