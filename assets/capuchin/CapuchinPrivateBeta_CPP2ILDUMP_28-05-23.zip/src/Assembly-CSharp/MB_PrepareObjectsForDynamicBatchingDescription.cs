﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000077 RID: 119
[Token(Token = "0x2000077")]
public class MB_PrepareObjectsForDynamicBatchingDescription : MonoBehaviour
{
	// Token: 0x06001207 RID: 4615 RVA: 0x00069830 File Offset: 0x00067A30
	[Token(Token = "0x6001207")]
	[Address(RVA = "0x2C5B36C", Offset = "0x2C5B36C", VA = "0x2C5B36C")]
	private void و߂\u06DBڅ()
	{
	}

	// Token: 0x06001208 RID: 4616 RVA: 0x00069840 File Offset: 0x00067A40
	[Token(Token = "0x6001208")]
	[Address(RVA = "0x2C5B44C", Offset = "0x2C5B44C", VA = "0x2C5B44C")]
	private void ࡂڴ\u05C1\u064E()
	{
	}

	// Token: 0x06001209 RID: 4617 RVA: 0x00069850 File Offset: 0x00067A50
	[Token(Token = "0x6001209")]
	[Address(RVA = "0x2C5B52C", Offset = "0x2C5B52C", VA = "0x2C5B52C")]
	private void Ԩ\u058Eۉ\u0607()
	{
	}

	// Token: 0x0600120A RID: 4618 RVA: 0x00069860 File Offset: 0x00067A60
	[Token(Token = "0x600120A")]
	[Address(RVA = "0x2C5B60C", Offset = "0x2C5B60C", VA = "0x2C5B60C")]
	private void Ӯޱ\u0703ࢪ()
	{
	}

	// Token: 0x0600120B RID: 4619 RVA: 0x00069870 File Offset: 0x00067A70
	[Token(Token = "0x600120B")]
	[Address(RVA = "0x2C5B6EC", Offset = "0x2C5B6EC", VA = "0x2C5B6EC")]
	public MB_PrepareObjectsForDynamicBatchingDescription()
	{
	}

	// Token: 0x0600120C RID: 4620 RVA: 0x00069884 File Offset: 0x00067A84
	[Token(Token = "0x600120C")]
	[Address(RVA = "0x2C5B6F4", Offset = "0x2C5B6F4", VA = "0x2C5B6F4")]
	private void \u05BA\u0893ހՎ()
	{
	}

	// Token: 0x0600120D RID: 4621 RVA: 0x00069894 File Offset: 0x00067A94
	[Token(Token = "0x600120D")]
	[Address(RVA = "0x2C5B7D4", Offset = "0x2C5B7D4", VA = "0x2C5B7D4")]
	private void Ӄۇރࡑ()
	{
	}

	// Token: 0x0600120E RID: 4622 RVA: 0x000698A4 File Offset: 0x00067AA4
	[Token(Token = "0x600120E")]
	[Address(RVA = "0x2C5B8B4", Offset = "0x2C5B8B4", VA = "0x2C5B8B4")]
	private void ߐ߁\u05CE\u0733()
	{
	}

	// Token: 0x0600120F RID: 4623 RVA: 0x000698B4 File Offset: 0x00067AB4
	[Token(Token = "0x600120F")]
	[Address(RVA = "0x2C5B994", Offset = "0x2C5B994", VA = "0x2C5B994")]
	private void \u0594ٺԏ\u05CA()
	{
	}

	// Token: 0x06001210 RID: 4624 RVA: 0x000698C4 File Offset: 0x00067AC4
	[Token(Token = "0x6001210")]
	[Address(RVA = "0x2C5BA74", Offset = "0x2C5BA74", VA = "0x2C5BA74")]
	private void Ԅڌ\u0659߀()
	{
	}

	// Token: 0x06001211 RID: 4625 RVA: 0x000698D4 File Offset: 0x00067AD4
	[Token(Token = "0x6001211")]
	[Address(RVA = "0x2C5BB54", Offset = "0x2C5BB54", VA = "0x2C5BB54")]
	private void ۰\u0615ԛ\u086B()
	{
	}

	// Token: 0x06001212 RID: 4626 RVA: 0x000698E4 File Offset: 0x00067AE4
	[Token(Token = "0x6001212")]
	[Address(RVA = "0x2C5BC34", Offset = "0x2C5BC34", VA = "0x2C5BC34")]
	private void \u07EB\u0597ࢳڪ()
	{
	}

	// Token: 0x06001213 RID: 4627 RVA: 0x000698F4 File Offset: 0x00067AF4
	[Token(Token = "0x6001213")]
	[Address(RVA = "0x2C5BD14", Offset = "0x2C5BD14", VA = "0x2C5BD14")]
	private void \u05CAө\u0872\u058F()
	{
	}

	// Token: 0x06001214 RID: 4628 RVA: 0x00069904 File Offset: 0x00067B04
	[Token(Token = "0x6001214")]
	[Address(RVA = "0x2C5BDF4", Offset = "0x2C5BDF4", VA = "0x2C5BDF4")]
	private void \u064Bࢮ\u0589\u05FF()
	{
	}

	// Token: 0x06001215 RID: 4629 RVA: 0x00069914 File Offset: 0x00067B14
	[Token(Token = "0x6001215")]
	[Address(RVA = "0x2C5BED4", Offset = "0x2C5BED4", VA = "0x2C5BED4")]
	private void ܡӯ\u06E8\u07B0()
	{
	}

	// Token: 0x06001216 RID: 4630 RVA: 0x00069924 File Offset: 0x00067B24
	[Token(Token = "0x6001216")]
	[Address(RVA = "0x2C5BFB4", Offset = "0x2C5BFB4", VA = "0x2C5BFB4")]
	private void ܩ\u06E2߈ջ()
	{
	}

	// Token: 0x06001217 RID: 4631 RVA: 0x00069934 File Offset: 0x00067B34
	[Token(Token = "0x6001217")]
	[Address(RVA = "0x2C5C094", Offset = "0x2C5C094", VA = "0x2C5C094")]
	private void ڄ\u0734ԛ\u05C8()
	{
	}

	// Token: 0x06001218 RID: 4632 RVA: 0x00069944 File Offset: 0x00067B44
	[Token(Token = "0x6001218")]
	[Address(RVA = "0x2C5C174", Offset = "0x2C5C174", VA = "0x2C5C174")]
	private void ޒӠۅߐ()
	{
	}

	// Token: 0x06001219 RID: 4633 RVA: 0x00069954 File Offset: 0x00067B54
	[Token(Token = "0x6001219")]
	[Address(RVA = "0x2C5C254", Offset = "0x2C5C254", VA = "0x2C5C254")]
	private void Ԁߚޘٴ()
	{
	}

	// Token: 0x0600121A RID: 4634 RVA: 0x00069964 File Offset: 0x00067B64
	[Token(Token = "0x600121A")]
	[Address(RVA = "0x2C5C334", Offset = "0x2C5C334", VA = "0x2C5C334")]
	private void \u0880ݚވԿ()
	{
	}

	// Token: 0x0600121B RID: 4635 RVA: 0x00069974 File Offset: 0x00067B74
	[Token(Token = "0x600121B")]
	[Address(RVA = "0x2C5C414", Offset = "0x2C5C414", VA = "0x2C5C414")]
	private void \u055E\u064E\u073Dࢷ()
	{
	}

	// Token: 0x0600121C RID: 4636 RVA: 0x00069984 File Offset: 0x00067B84
	[Token(Token = "0x600121C")]
	[Address(RVA = "0x2C5C4F4", Offset = "0x2C5C4F4", VA = "0x2C5C4F4")]
	private void ߅\u070Fޑ\u0876()
	{
	}

	// Token: 0x0600121D RID: 4637 RVA: 0x00069994 File Offset: 0x00067B94
	[Token(Token = "0x600121D")]
	[Address(RVA = "0x2C5C5D4", Offset = "0x2C5C5D4", VA = "0x2C5C5D4")]
	private void \u0859\u0895ӇԚ()
	{
	}

	// Token: 0x0600121E RID: 4638 RVA: 0x000699A4 File Offset: 0x00067BA4
	[Token(Token = "0x600121E")]
	[Address(RVA = "0x2C5C6B4", Offset = "0x2C5C6B4", VA = "0x2C5C6B4")]
	private void \u07F7ե\u081Fܗ()
	{
	}

	// Token: 0x0600121F RID: 4639 RVA: 0x000699B4 File Offset: 0x00067BB4
	[Token(Token = "0x600121F")]
	[Address(RVA = "0x2C5C794", Offset = "0x2C5C794", VA = "0x2C5C794")]
	private void \u07FBع߉ٶ()
	{
	}

	// Token: 0x06001220 RID: 4640 RVA: 0x000699C4 File Offset: 0x00067BC4
	[Token(Token = "0x6001220")]
	[Address(RVA = "0x2C5C874", Offset = "0x2C5C874", VA = "0x2C5C874")]
	private void OnGUI()
	{
	}

	// Token: 0x06001221 RID: 4641 RVA: 0x000699D4 File Offset: 0x00067BD4
	[Token(Token = "0x6001221")]
	[Address(RVA = "0x2C5C954", Offset = "0x2C5C954", VA = "0x2C5C954")]
	private void ޤչ߉\u0702()
	{
		if (!true)
		{
		}
	}

	// Token: 0x06001222 RID: 4642 RVA: 0x000699E4 File Offset: 0x00067BE4
	[Token(Token = "0x6001222")]
	[Address(RVA = "0x2C5CA34", Offset = "0x2C5CA34", VA = "0x2C5CA34")]
	private void ۃ\u087EڴՊ()
	{
	}

	// Token: 0x06001223 RID: 4643 RVA: 0x000699F4 File Offset: 0x00067BF4
	[Token(Token = "0x6001223")]
	[Address(RVA = "0x2C5CB14", Offset = "0x2C5CB14", VA = "0x2C5CB14")]
	private void \u0589٣ޖԀ()
	{
	}

	// Token: 0x06001224 RID: 4644 RVA: 0x00069A04 File Offset: 0x00067C04
	[Token(Token = "0x6001224")]
	[Address(RVA = "0x2C5CBF4", Offset = "0x2C5CBF4", VA = "0x2C5CBF4")]
	private void ԗӣ\u07BAߩ()
	{
	}

	// Token: 0x06001225 RID: 4645 RVA: 0x00069A14 File Offset: 0x00067C14
	[Token(Token = "0x6001225")]
	[Address(RVA = "0x2C5CCD4", Offset = "0x2C5CCD4", VA = "0x2C5CCD4")]
	private void چאӣک()
	{
		if (!true)
		{
		}
	}

	// Token: 0x06001226 RID: 4646 RVA: 0x00069A24 File Offset: 0x00067C24
	[Token(Token = "0x6001226")]
	[Address(RVA = "0x2C5CDB4", Offset = "0x2C5CDB4", VA = "0x2C5CDB4")]
	private void \u0859ؤԗԧ()
	{
	}

	// Token: 0x06001227 RID: 4647 RVA: 0x00069A34 File Offset: 0x00067C34
	[Token(Token = "0x6001227")]
	[Address(RVA = "0x2C5CE94", Offset = "0x2C5CE94", VA = "0x2C5CE94")]
	private void ܞݗ\u0743Ӽ()
	{
	}

	// Token: 0x06001228 RID: 4648 RVA: 0x00069A44 File Offset: 0x00067C44
	[Token(Token = "0x6001228")]
	[Address(RVA = "0x2C5CF74", Offset = "0x2C5CF74", VA = "0x2C5CF74")]
	private void ٧ص\u073FӜ()
	{
	}

	// Token: 0x06001229 RID: 4649 RVA: 0x00069A54 File Offset: 0x00067C54
	[Token(Token = "0x6001229")]
	[Address(RVA = "0x2C5D054", Offset = "0x2C5D054", VA = "0x2C5D054")]
	private void ۵\u05EEߑچ()
	{
	}

	// Token: 0x0600122A RID: 4650 RVA: 0x00069A64 File Offset: 0x00067C64
	[Token(Token = "0x600122A")]
	[Address(RVA = "0x2C5D134", Offset = "0x2C5D134", VA = "0x2C5D134")]
	private void \u0598ڂ\u088AՋ()
	{
	}

	// Token: 0x0600122B RID: 4651 RVA: 0x00069A74 File Offset: 0x00067C74
	[Token(Token = "0x600122B")]
	[Address(RVA = "0x2C5D214", Offset = "0x2C5D214", VA = "0x2C5D214")]
	private void גԛכ\u0887()
	{
	}

	// Token: 0x0600122C RID: 4652 RVA: 0x00069A84 File Offset: 0x00067C84
	[Token(Token = "0x600122C")]
	[Address(RVA = "0x2C5D2F4", Offset = "0x2C5D2F4", VA = "0x2C5D2F4")]
	private void ٺ\u0898ޛޟ()
	{
	}

	// Token: 0x0600122D RID: 4653 RVA: 0x00069A94 File Offset: 0x00067C94
	[Token(Token = "0x600122D")]
	[Address(RVA = "0x2C5D3D4", Offset = "0x2C5D3D4", VA = "0x2C5D3D4")]
	private void \u0614\u055A\u0895۷()
	{
	}

	// Token: 0x0600122E RID: 4654 RVA: 0x00069AA4 File Offset: 0x00067CA4
	[Token(Token = "0x600122E")]
	[Address(RVA = "0x2C5D4B4", Offset = "0x2C5D4B4", VA = "0x2C5D4B4")]
	private void \u06E4\u0656ڰۻ()
	{
	}

	// Token: 0x0600122F RID: 4655 RVA: 0x00069AB4 File Offset: 0x00067CB4
	[Token(Token = "0x600122F")]
	[Address(RVA = "0x2C5D594", Offset = "0x2C5D594", VA = "0x2C5D594")]
	private void \u07AFࡓݣ\u06E9()
	{
	}

	// Token: 0x06001230 RID: 4656 RVA: 0x00069AC4 File Offset: 0x00067CC4
	[Token(Token = "0x6001230")]
	[Address(RVA = "0x2C5D674", Offset = "0x2C5D674", VA = "0x2C5D674")]
	private void \u0821Պ\u085BՒ()
	{
	}

	// Token: 0x06001231 RID: 4657 RVA: 0x00069AD4 File Offset: 0x00067CD4
	[Token(Token = "0x6001231")]
	[Address(RVA = "0x2C5D754", Offset = "0x2C5D754", VA = "0x2C5D754")]
	private void \u0741\u07A7\u0749ݧ()
	{
	}

	// Token: 0x06001232 RID: 4658 RVA: 0x00069AE4 File Offset: 0x00067CE4
	[Token(Token = "0x6001232")]
	[Address(RVA = "0x2C5D834", Offset = "0x2C5D834", VA = "0x2C5D834")]
	private void ҿ\u07BBҽ\u0599()
	{
	}

	// Token: 0x06001233 RID: 4659 RVA: 0x00069AF4 File Offset: 0x00067CF4
	[Token(Token = "0x6001233")]
	[Address(RVA = "0x2C5D914", Offset = "0x2C5D914", VA = "0x2C5D914")]
	private void ء\u074C\u0825Ӂ()
	{
	}

	// Token: 0x06001234 RID: 4660 RVA: 0x00069B04 File Offset: 0x00067D04
	[Token(Token = "0x6001234")]
	[Address(RVA = "0x2C5D9F4", Offset = "0x2C5D9F4", VA = "0x2C5D9F4")]
	private void ࢷ\u089C\u0821\u05CF()
	{
	}

	// Token: 0x06001235 RID: 4661 RVA: 0x00069B14 File Offset: 0x00067D14
	[Token(Token = "0x6001235")]
	[Address(RVA = "0x2C5DAD4", Offset = "0x2C5DAD4", VA = "0x2C5DAD4")]
	private void ٯب٧\u05FC()
	{
	}

	// Token: 0x06001236 RID: 4662 RVA: 0x00069B24 File Offset: 0x00067D24
	[Token(Token = "0x6001236")]
	[Address(RVA = "0x2C5DBB4", Offset = "0x2C5DBB4", VA = "0x2C5DBB4")]
	private void \u05AE\u05B6\u055A\u05B1()
	{
	}

	// Token: 0x06001237 RID: 4663 RVA: 0x00069B34 File Offset: 0x00067D34
	[Token(Token = "0x6001237")]
	[Address(RVA = "0x2C5DC94", Offset = "0x2C5DC94", VA = "0x2C5DC94")]
	private void \u05B5\u0837Ԯݢ()
	{
	}

	// Token: 0x06001238 RID: 4664 RVA: 0x00069B44 File Offset: 0x00067D44
	[Token(Token = "0x6001238")]
	[Address(RVA = "0x2C5DD74", Offset = "0x2C5DD74", VA = "0x2C5DD74")]
	private void \u060Eװ\u085Cࢶ()
	{
	}

	// Token: 0x06001239 RID: 4665 RVA: 0x00069B54 File Offset: 0x00067D54
	[Token(Token = "0x6001239")]
	[Address(RVA = "0x2C5DE54", Offset = "0x2C5DE54", VA = "0x2C5DE54")]
	private void ہډࠉӥ()
	{
	}

	// Token: 0x0600123A RID: 4666 RVA: 0x00069B64 File Offset: 0x00067D64
	[Token(Token = "0x600123A")]
	[Address(RVA = "0x2C5DF34", Offset = "0x2C5DF34", VA = "0x2C5DF34")]
	private void ࡉࡡܡߕ()
	{
	}

	// Token: 0x0600123B RID: 4667 RVA: 0x00069B74 File Offset: 0x00067D74
	[Token(Token = "0x600123B")]
	[Address(RVA = "0x2C5E014", Offset = "0x2C5E014", VA = "0x2C5E014")]
	private void ߌڟ\u07EEҼ()
	{
	}

	// Token: 0x0600123C RID: 4668 RVA: 0x00069B84 File Offset: 0x00067D84
	[Token(Token = "0x600123C")]
	[Address(RVA = "0x2C5E0F4", Offset = "0x2C5E0F4", VA = "0x2C5E0F4")]
	private void \u05C4עڻ\u0732()
	{
	}

	// Token: 0x0600123D RID: 4669 RVA: 0x00069B94 File Offset: 0x00067D94
	[Token(Token = "0x600123D")]
	[Address(RVA = "0x2C5E1D4", Offset = "0x2C5E1D4", VA = "0x2C5E1D4")]
	private void ޥل\u0605Ԅ()
	{
	}

	// Token: 0x0600123E RID: 4670 RVA: 0x00069BA4 File Offset: 0x00067DA4
	[Token(Token = "0x600123E")]
	[Address(RVA = "0x2C5E2B4", Offset = "0x2C5E2B4", VA = "0x2C5E2B4")]
	private void ى\u05F4ڷ߉()
	{
	}
}
