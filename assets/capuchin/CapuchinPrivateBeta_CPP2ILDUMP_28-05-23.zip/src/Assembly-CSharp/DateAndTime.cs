﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x02000026 RID: 38
[Token(Token = "0x2000026")]
public class DateAndTime : MonoBehaviour
{
	// Token: 0x06000454 RID: 1108 RVA: 0x00018E80 File Offset: 0x00017080
	[Token(Token = "0x6000454")]
	[Address(RVA = "0x28985F0", Offset = "0x28985F0", VA = "0x28985F0")]
	private void څࡣڐ\u0657()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string str = DateTime.UtcNow.ToLocalTime().ToString("ChangePlayerSize");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Add/Remove Sword");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			string text = "True" + str2 + "Not connected to room" + str;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("FingerTip");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("NGNNoSound");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
		string text2 = "Name Changing Error. Error: " + str4 + "Name Changing Error. Error: " + str3;
	}

	// Token: 0x06000455 RID: 1109 RVA: 0x00018F4C File Offset: 0x0001714C
	[Token(Token = "0x6000455")]
	[Address(RVA = "0x2898844", Offset = "0x2898844", VA = "0x2898844")]
	private void \u05F7ԝߠӱ()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string str = DateTime.UtcNow.ToLocalTime().ToString("TurnAmount");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			string text = "Room1" + str2 + "Player" + str;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("Players In Room: ");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("A new Player joined a Room.");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
		string text2 = "Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:" + str4 + "Name Changing Error. Error: " + str3;
	}

	// Token: 0x06000456 RID: 1110 RVA: 0x00019018 File Offset: 0x00017218
	[Token(Token = "0x6000456")]
	[Address(RVA = "0x2898AB0", Offset = "0x2898AB0", VA = "0x2898AB0")]
	private void ڑߒجވ()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string str = DateTime.UtcNow.ToLocalTime().ToString("Display Name Changed!");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Player");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			string text = "EnableCosmetic" + str2 + "Player" + str;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string text2 = DateTime.UtcNow.ToLocalTime().ToString("Player");
		string text3 = DateTime.UtcNow.ToLocalTime().ToString("Combine textures & build combined mesh using coroutine");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
	}

	// Token: 0x06000457 RID: 1111 RVA: 0x000190CC File Offset: 0x000172CC
	[Token(Token = "0x6000457")]
	[Address(RVA = "0x2898CF0", Offset = "0x2898CF0", VA = "0x2898CF0")]
	private void Ӣ\u0592ߨׯ()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string str = DateTime.UtcNow.ToLocalTime().ToString("back");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Player");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			string text = "StartSong" + str2 + "ORGTARG" + str;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string text2 = DateTime.UtcNow.ToLocalTime().ToString("FingerTip");
		string text3 = DateTime.UtcNow.ToLocalTime().ToString("hh:mmtt");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
	}

	// Token: 0x06000458 RID: 1112 RVA: 0x00019180 File Offset: 0x00017380
	[Token(Token = "0x6000458")]
	[Address(RVA = "0x2898F5C", Offset = "0x2898F5C", VA = "0x2898F5C")]
	private void ފՖߢ\u059B()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			return;
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string text = DateTime.UtcNow.ToLocalTime().ToString("ChangeToTagged");
		string text2 = DateTime.UtcNow.ToLocalTime().ToString("Regular");
		TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
	}

	// Token: 0x06000459 RID: 1113 RVA: 0x00019230 File Offset: 0x00017430
	[Token(Token = "0x6000459")]
	[Address(RVA = "0x28991C8", Offset = "0x28991C8", VA = "0x28991C8")]
	public DateAndTime()
	{
	}

	// Token: 0x0600045A RID: 1114 RVA: 0x00019244 File Offset: 0x00017444
	[Token(Token = "0x600045A")]
	[Address(RVA = "0x28991D0", Offset = "0x28991D0", VA = "0x28991D0")]
	private void \u061B\u05EEوۈ()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string str = DateTime.UtcNow.ToLocalTime().ToString("containsStaff");
			DateTime dateTime = DateTime.UtcNow.ToLocalTime();
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			string str2;
			string text = "containsStaff" + str2 + "false" + str;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("Display Name Changed!");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("Thumb");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
		string text2 = "DisableCosmetic" + str4 + "Joined a Room." + str3;
	}

	// Token: 0x0600045B RID: 1115 RVA: 0x00019304 File Offset: 0x00017504
	[Token(Token = "0x600045B")]
	[Address(RVA = "0x2899430", Offset = "0x2899430", VA = "0x2899430")]
	private void \u05EDց\u081Cت()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string text = DateTime.UtcNow.ToLocalTime().ToString("waited for your bullshit unity grrr");
			string text2 = DateTime.UtcNow.ToLocalTime().ToString("sound play stopped");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string str = DateTime.UtcNow.ToLocalTime().ToString("True");
		string str2 = DateTime.UtcNow.ToLocalTime().ToString("You are not the master of the server, you cannot start the game.");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
		string text3 = "You are not the master of the server, you cannot start the game." + str2 + "_Tint" + str;
	}

	// Token: 0x0600045C RID: 1116 RVA: 0x000193BC File Offset: 0x000175BC
	[Token(Token = "0x600045C")]
	[Address(RVA = "0x2899688", Offset = "0x2899688", VA = "0x2899688")]
	private void \u0732ڙԒࢺ()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string text = DateTime.UtcNow.ToLocalTime().ToString("Faild To Add Winner Money: ");
			string text2 = DateTime.UtcNow.ToLocalTime().ToString("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if ("_platform" == null)
		{
		}
		string str = DateTime.UtcNow.ToLocalTime().ToString("PlayerHead");
		string str2 = DateTime.UtcNow.ToLocalTime().ToString("CapuchinRemade");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
		string text3 = "Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example." + str2 + "username" + str;
	}

	// Token: 0x0600045D RID: 1117 RVA: 0x00019474 File Offset: 0x00017674
	[Token(Token = "0x600045D")]
	[Address(RVA = "0x28998F4", Offset = "0x28998F4", VA = "0x28998F4")]
	private void Ҿࢹؼס()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string str = DateTime.UtcNow.ToLocalTime().ToString("Add/Remove Sword");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Game Started");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			string text = "Not connected to room" + str2 + "INSIGNIFICANT CURRENCY" + str;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("Player");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("User is on an outdated version of Capuchin. Your version is ");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
		string text2 = "Player" + str4 + "Completed baking textures on frame " + str3;
	}

	// Token: 0x0600045E RID: 1118 RVA: 0x00019540 File Offset: 0x00017740
	[Token(Token = "0x600045E")]
	[Address(RVA = "0x2899B4C", Offset = "0x2899B4C", VA = "0x2899B4C")]
	private void Update()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string str = DateTime.UtcNow.ToLocalTime().ToString("hh:mmtt");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("M/d/yyyy");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			string text = "Date: " + str2 + "\n Time: " + str;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("hh:mm:sstt");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("M/d/yyyy");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
		string text2 = "Date: " + str4 + "\n Time: " + str3;
	}

	// Token: 0x0600045F RID: 1119 RVA: 0x0001960C File Offset: 0x0001780C
	[Token(Token = "0x600045F")]
	[Address(RVA = "0x2899D94", Offset = "0x2899D94", VA = "0x2899D94")]
	private void \u0654ޛ\u07FAذ()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string str = DateTime.UtcNow.ToLocalTime().ToString("Head");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Not connected to room");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			string text = "Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe." + str2 + "CapuchinRemade" + str;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("duration done");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
		string text2 = "_Tint" + str4 + "Vector1_d371bd24217449349bd747533d51af6b" + str3;
	}

	// Token: 0x06000460 RID: 1120 RVA: 0x000196D8 File Offset: 0x000178D8
	[Token(Token = "0x6000460")]
	[Address(RVA = "0x289A000", Offset = "0x289A000", VA = "0x289A000")]
	private void ԟ\u086Cޣ\u055E()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string str = DateTime.UtcNow.ToLocalTime().ToString("NetworkGunShoot");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString(" and the correct version is ");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			string text = "A Player has left the Room." + str2 + "Cheating" + str;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("SetColor");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("BN");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
		string text2 = "\n" + str4 + "isLava" + str3;
	}

	// Token: 0x06000461 RID: 1121 RVA: 0x000197A4 File Offset: 0x000179A4
	[Token(Token = "0x6000461")]
	[Address(RVA = "0x289A26C", Offset = "0x289A26C", VA = "0x289A26C")]
	private void ւࡂ\u0883\u0872()
	{
		if (!this.ڑࡅޠ\u05F9)
		{
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			string str = DateTime.UtcNow.ToLocalTime().ToString("Add/Remove Sword");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("isLava");
			TextMeshPro לݐࡦ_u05CD = this.לݐࡦ\u05CD;
			string text = "Player" + str2 + "Open" + str;
			if (!this.ڑࡅޠ\u05F9)
			{
				return;
			}
		}
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("goDownRPC");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("False");
		TextMeshPro לݐࡦ_u05CD2 = this.לݐࡦ\u05CD;
		string text2 = "PlayerHead" + str4 + "ChangeToTagged" + str3;
	}

	// Token: 0x040000B9 RID: 185
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000B9")]
	public TextMeshPro לݐࡦ\u05CD;

	// Token: 0x040000BA RID: 186
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000BA")]
	public bool ڑࡅޠ\u05F9;
}
