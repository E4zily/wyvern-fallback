﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000100 RID: 256
[Token(Token = "0x2000100")]
public class ԛԈ۵\u0743 : PropertyAttribute
{
	// Token: 0x060027EE RID: 10222 RVA: 0x000EAA28 File Offset: 0x000E8C28
	[Token(Token = "0x60027EE")]
	[Address(RVA = "0x21239A0", Offset = "0x21239A0", VA = "0x21239A0")]
	public ԛԈ۵\u0743(Type ࢢߣܩݰ)
	{
		this.ܫԐ\u0838ށ = ࢢߣܩݰ;
	}

	// Token: 0x0400050B RID: 1291
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400050B")]
	public readonly Type ܫԐ\u0838ށ;
}
