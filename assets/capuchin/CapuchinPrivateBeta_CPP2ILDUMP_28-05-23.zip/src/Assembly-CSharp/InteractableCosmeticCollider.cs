﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200006B RID: 107
[Token(Token = "0x200006B")]
public class InteractableCosmeticCollider : MonoBehaviour
{
	// Token: 0x06000F8D RID: 3981 RVA: 0x00059410 File Offset: 0x00057610
	[Token(Token = "0x6000F8D")]
	[Address(RVA = "0x27556F8", Offset = "0x27556F8", VA = "0x27556F8")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("HOLY MOLY THE STICK IS ON FIRE!!!!!!");
	}

	// Token: 0x06000F8E RID: 3982 RVA: 0x00059448 File Offset: 0x00057648
	[Token(Token = "0x6000F8E")]
	[Address(RVA = "0x27557F4", Offset = "0x27557F4", VA = "0x27557F4")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("ENABLE");
	}

	// Token: 0x06000F8F RID: 3983 RVA: 0x00059480 File Offset: 0x00057680
	[Token(Token = "0x6000F8F")]
	[Address(RVA = "0x27558F0", Offset = "0x27558F0", VA = "0x27558F0")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Charged!");
	}

	// Token: 0x06000F90 RID: 3984 RVA: 0x000594B8 File Offset: 0x000576B8
	[Token(Token = "0x6000F90")]
	[Address(RVA = "0x27559EC", Offset = "0x27559EC", VA = "0x27559EC")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("HandL");
	}

	// Token: 0x06000F91 RID: 3985 RVA: 0x000594F0 File Offset: 0x000576F0
	[Token(Token = "0x6000F91")]
	[Address(RVA = "0x2755AE8", Offset = "0x2755AE8", VA = "0x2755AE8")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Head");
	}

	// Token: 0x06000F92 RID: 3986 RVA: 0x00059528 File Offset: 0x00057728
	[Token(Token = "0x6000F92")]
	[Address(RVA = "0x2755BE4", Offset = "0x2755BE4", VA = "0x2755BE4")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Reason: ");
	}

	// Token: 0x06000F93 RID: 3987 RVA: 0x00059560 File Offset: 0x00057760
	[Token(Token = "0x6000F93")]
	[Address(RVA = "0x2755CE0", Offset = "0x2755CE0", VA = "0x2755CE0")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("FingerTip");
	}

	// Token: 0x06000F94 RID: 3988 RVA: 0x00059598 File Offset: 0x00057798
	[Token(Token = "0x6000F94")]
	[Address(RVA = "0x2755DDC", Offset = "0x2755DDC", VA = "0x2755DDC")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("\n");
	}

	// Token: 0x06000F95 RID: 3989 RVA: 0x000595D0 File Offset: 0x000577D0
	[Token(Token = "0x6000F95")]
	[Address(RVA = "0x2755ED8", Offset = "0x2755ED8", VA = "0x2755ED8")]
	public InteractableCosmeticCollider()
	{
	}

	// Token: 0x06000F96 RID: 3990 RVA: 0x000595E4 File Offset: 0x000577E4
	[Token(Token = "0x6000F96")]
	[Address(RVA = "0x2755EE0", Offset = "0x2755EE0", VA = "0x2755EE0")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("FingerTip");
	}

	// Token: 0x06000F97 RID: 3991 RVA: 0x0005961C File Offset: 0x0005781C
	[Token(Token = "0x6000F97")]
	[Address(RVA = "0x2755FDC", Offset = "0x2755FDC", VA = "0x2755FDC")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("_Tint");
	}

	// Token: 0x06000F98 RID: 3992 RVA: 0x00059654 File Offset: 0x00057854
	[Token(Token = "0x6000F98")]
	[Address(RVA = "0x27560D8", Offset = "0x27560D8", VA = "0x27560D8")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("BN");
	}

	// Token: 0x06000F99 RID: 3993 RVA: 0x0005968C File Offset: 0x0005788C
	[Token(Token = "0x6000F99")]
	[Address(RVA = "0x27561D4", Offset = "0x27561D4", VA = "0x27561D4")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("gravThing");
	}

	// Token: 0x06000F9A RID: 3994 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000F9A")]
	[Address(RVA = "0x27562D0", Offset = "0x27562D0", VA = "0x27562D0")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000F9B RID: 3995 RVA: 0x000596C4 File Offset: 0x000578C4
	[Token(Token = "0x6000F9B")]
	[Address(RVA = "0x27563CC", Offset = "0x27563CC", VA = "0x27563CC")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Holdable");
	}

	// Token: 0x06000F9C RID: 3996 RVA: 0x000596FC File Offset: 0x000578FC
	[Token(Token = "0x6000F9C")]
	[Address(RVA = "0x27564C8", Offset = "0x27564C8", VA = "0x27564C8")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("A Player has left the Room.");
	}

	// Token: 0x06000F9D RID: 3997 RVA: 0x00059734 File Offset: 0x00057934
	[Token(Token = "0x6000F9D")]
	[Address(RVA = "0x27565C4", Offset = "0x27565C4", VA = "0x27565C4")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		InteractableCosmetic component = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		bool flag = \u07FEל\u05AC\u0877;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Players In Room: ");
	}

	// Token: 0x06000F9E RID: 3998 RVA: 0x0005976C File Offset: 0x0005796C
	[Token(Token = "0x6000F9E")]
	[Address(RVA = "0x27566C0", Offset = "0x27566C0", VA = "0x27566C0")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("NGNNoSound");
	}

	// Token: 0x06000F9F RID: 3999 RVA: 0x000597A4 File Offset: 0x000579A4
	[Token(Token = "0x6000F9F")]
	[Address(RVA = "0x27567BC", Offset = "0x27567BC", VA = "0x27567BC")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000FA0 RID: 4000 RVA: 0x000597D0 File Offset: 0x000579D0
	[Token(Token = "0x6000FA0")]
	[Address(RVA = "0x27568B8", Offset = "0x27568B8", VA = "0x27568B8")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Debug.Log("CapuchinStore");
	}

	// Token: 0x06000FA1 RID: 4001 RVA: 0x00059808 File Offset: 0x00057A08
	[Token(Token = "0x6000FA1")]
	[Address(RVA = "0x27569B4", Offset = "0x27569B4", VA = "0x27569B4")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("\n Time: ");
	}

	// Token: 0x06000FA2 RID: 4002 RVA: 0x00059840 File Offset: 0x00057A40
	[Token(Token = "0x6000FA2")]
	[Address(RVA = "0x2756AB0", Offset = "0x2756AB0", VA = "0x2756AB0")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("FingerTip");
	}

	// Token: 0x06000FA3 RID: 4003 RVA: 0x00059878 File Offset: 0x00057A78
	[Token(Token = "0x6000FA3")]
	[Address(RVA = "0x2756BAC", Offset = "0x2756BAC", VA = "0x2756BAC")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("On");
	}

	// Token: 0x06000FA4 RID: 4004 RVA: 0x000598B0 File Offset: 0x00057AB0
	[Token(Token = "0x6000FA4")]
	[Address(RVA = "0x2756CA8", Offset = "0x2756CA8", VA = "0x2756CA8")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Failed to login, please restart");
	}

	// Token: 0x06000FA5 RID: 4005 RVA: 0x000598E8 File Offset: 0x00057AE8
	[Token(Token = "0x6000FA5")]
	[Address(RVA = "0x2756DA4", Offset = "0x2756DA4", VA = "0x2756DA4")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("waited for your bullshit unity grrr");
	}

	// Token: 0x06000FA6 RID: 4006 RVA: 0x00059920 File Offset: 0x00057B20
	[Token(Token = "0x6000FA6")]
	[Address(RVA = "0x2756EA0", Offset = "0x2756EA0", VA = "0x2756EA0")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Reason: ");
	}

	// Token: 0x06000FA7 RID: 4007 RVA: 0x00059958 File Offset: 0x00057B58
	[Token(Token = "0x6000FA7")]
	[Address(RVA = "0x2756F9C", Offset = "0x2756F9C", VA = "0x2756F9C")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Fire Stick Is Lighting...");
	}

	// Token: 0x06000FA8 RID: 4008 RVA: 0x00059990 File Offset: 0x00057B90
	[Token(Token = "0x6000FA8")]
	[Address(RVA = "0x2757098", Offset = "0x2757098", VA = "0x2757098")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("FingerTip");
	}

	// Token: 0x06000FA9 RID: 4009 RVA: 0x000599C8 File Offset: 0x00057BC8
	[Token(Token = "0x6000FA9")]
	[Address(RVA = "0x2757194", Offset = "0x2757194", VA = "0x2757194")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Debug.Log("Name Changing Error. Error: ");
	}

	// Token: 0x06000FAA RID: 4010 RVA: 0x00059A00 File Offset: 0x00057C00
	[Token(Token = "0x6000FAA")]
	[Address(RVA = "0x2757290", Offset = "0x2757290", VA = "0x2757290")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("gamemode");
	}

	// Token: 0x06000FAB RID: 4011 RVA: 0x00059A38 File Offset: 0x00057C38
	[Token(Token = "0x6000FAB")]
	[Address(RVA = "0x275738C", Offset = "0x275738C", VA = "0x275738C")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("A new Player joined a Room.");
	}

	// Token: 0x06000FAC RID: 4012 RVA: 0x00059A70 File Offset: 0x00057C70
	[Token(Token = "0x6000FAC")]
	[Address(RVA = "0x2757488", Offset = "0x2757488", VA = "0x2757488")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
	}

	// Token: 0x06000FAD RID: 4013 RVA: 0x00059AA8 File Offset: 0x00057CA8
	[Token(Token = "0x6000FAD")]
	[Address(RVA = "0x2757584", Offset = "0x2757584", VA = "0x2757584")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("/");
	}

	// Token: 0x06000FAE RID: 4014 RVA: 0x00059AE0 File Offset: 0x00057CE0
	[Token(Token = "0x6000FAE")]
	[Address(RVA = "0x2757680", Offset = "0x2757680", VA = "0x2757680")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("M/d/yyyy");
	}

	// Token: 0x06000FAF RID: 4015 RVA: 0x00059B18 File Offset: 0x00057D18
	[Token(Token = "0x6000FAF")]
	[Address(RVA = "0x275777C", Offset = "0x275777C", VA = "0x275777C")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmetic>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("BN");
	}
}
