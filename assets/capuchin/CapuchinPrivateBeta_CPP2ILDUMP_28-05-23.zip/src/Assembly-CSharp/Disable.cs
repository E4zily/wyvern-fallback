﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000AB RID: 171
[Token(Token = "0x20000AB")]
public class Disable : MonoBehaviour
{
	// Token: 0x0600197C RID: 6524 RVA: 0x00089F70 File Offset: 0x00088170
	[Token(Token = "0x600197C")]
	[Address(RVA = "0x28A594C", Offset = "0x28A594C", VA = "0x28A594C")]
	public void ڗࢭ\u058D\u0733(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("goUpRPC");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600197D RID: 6525 RVA: 0x00089FA8 File Offset: 0x000881A8
	[Token(Token = "0x600197D")]
	[Address(RVA = "0x28A59E4", Offset = "0x28A59E4", VA = "0x28A59E4")]
	public void \u05F8ڛߠ\u05BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("DISABLE");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600197E RID: 6526 RVA: 0x00089FE0 File Offset: 0x000881E0
	[Token(Token = "0x600197E")]
	[Address(RVA = "0x28A5A7C", Offset = "0x28A5A7C", VA = "0x28A5A7C")]
	public void \u0885ےܝ\u05BA(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("Purchased: ");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600197F RID: 6527 RVA: 0x0008A010 File Offset: 0x00088210
	[Token(Token = "0x600197F")]
	[Address(RVA = "0x28A5B14", Offset = "0x28A5B14", VA = "0x28A5B14")]
	public void ߂ӹ\u05C6\u07F9(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Display Name Changed!");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001980 RID: 6528 RVA: 0x0008A048 File Offset: 0x00088248
	[Token(Token = "0x6001980")]
	[Address(RVA = "0x28A5BAC", Offset = "0x28A5BAC", VA = "0x28A5BAC")]
	public void ت\u05F9ޅ\u059A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("clickLol");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001981 RID: 6529 RVA: 0x0008A080 File Offset: 0x00088280
	[Token(Token = "0x6001981")]
	[Address(RVA = "0x28A5C44", Offset = "0x28A5C44", VA = "0x28A5C44")]
	public void \u0836Չװߟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("INSIGNIFICANT CURRENCY");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001982 RID: 6530 RVA: 0x0008A0B8 File Offset: 0x000882B8
	[Token(Token = "0x6001982")]
	[Address(RVA = "0x28A5CDC", Offset = "0x28A5CDC", VA = "0x28A5CDC")]
	public void \u0872יԁӦ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Tagging");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001983 RID: 6531 RVA: 0x0008A0F0 File Offset: 0x000882F0
	[Token(Token = "0x6001983")]
	[Address(RVA = "0x28A5D74", Offset = "0x28A5D74", VA = "0x28A5D74")]
	public void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("tutorialCheck");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001984 RID: 6532 RVA: 0x0008A128 File Offset: 0x00088328
	[Token(Token = "0x6001984")]
	[Address(RVA = "0x28A5E0C", Offset = "0x28A5E0C", VA = "0x28A5E0C")]
	public Disable()
	{
	}

	// Token: 0x06001985 RID: 6533 RVA: 0x0008A13C File Offset: 0x0008833C
	[Token(Token = "0x6001985")]
	[Address(RVA = "0x28A5E14", Offset = "0x28A5E14", VA = "0x28A5E14")]
	public void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("typesOfTalk");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001986 RID: 6534 RVA: 0x0008A174 File Offset: 0x00088374
	[Token(Token = "0x6001986")]
	[Address(RVA = "0x28A5EAC", Offset = "0x28A5EAC", VA = "0x28A5EAC")]
	public void \u0748\u05F4Նۏ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001987 RID: 6535 RVA: 0x0008A1AC File Offset: 0x000883AC
	[Token(Token = "0x6001987")]
	[Address(RVA = "0x28A5F44", Offset = "0x28A5F44", VA = "0x28A5F44")]
	public void \u0609ۯ\u05B4ؼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("On");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001988 RID: 6536 RVA: 0x0008A1E4 File Offset: 0x000883E4
	[Token(Token = "0x6001988")]
	[Address(RVA = "0x28A5FDC", Offset = "0x28A5FDC", VA = "0x28A5FDC")]
	public void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Bare Torso");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001989 RID: 6537 RVA: 0x0008A21C File Offset: 0x0008841C
	[Token(Token = "0x6001989")]
	[Address(RVA = "0x28A6074", Offset = "0x28A6074", VA = "0x28A6074")]
	public void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("User has been reported for: ");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600198A RID: 6538 RVA: 0x0008A254 File Offset: 0x00088454
	[Token(Token = "0x600198A")]
	[Address(RVA = "0x28A610C", Offset = "0x28A610C", VA = "0x28A610C")]
	public void ࢳ\u06D8Ԙ\u05FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("isLava");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600198B RID: 6539 RVA: 0x0008A28C File Offset: 0x0008848C
	[Token(Token = "0x600198B")]
	[Address(RVA = "0x28A61A4", Offset = "0x28A61A4", VA = "0x28A61A4")]
	public void Ԍߊٱݩ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600198C RID: 6540 RVA: 0x0008A2B8 File Offset: 0x000884B8
	[Token(Token = "0x600198C")]
	[Address(RVA = "0x28A623C", Offset = "0x28A623C", VA = "0x28A623C")]
	public void \u07B3\u07BD\u05FF\u0859(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Hate Speech");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600198D RID: 6541 RVA: 0x0008A2F0 File Offset: 0x000884F0
	[Token(Token = "0x600198D")]
	[Address(RVA = "0x28A62D4", Offset = "0x28A62D4", VA = "0x28A62D4")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600198E RID: 6542 RVA: 0x0008A328 File Offset: 0x00088528
	[Token(Token = "0x600198E")]
	[Address(RVA = "0x28A636C", Offset = "0x28A636C", VA = "0x28A636C")]
	public void ܮݫ߅ࡃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("BLUTARG");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600198F RID: 6543 RVA: 0x0008A360 File Offset: 0x00088560
	[Token(Token = "0x600198F")]
	[Address(RVA = "0x28A6404", Offset = "0x28A6404", VA = "0x28A6404")]
	public void ؽܗӊә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("gravThing");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001990 RID: 6544 RVA: 0x0008A398 File Offset: 0x00088598
	[Token(Token = "0x6001990")]
	[Address(RVA = "0x28A649C", Offset = "0x28A649C", VA = "0x28A649C")]
	public void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeToRegular");
	}

	// Token: 0x06001991 RID: 6545 RVA: 0x0008A3C0 File Offset: 0x000885C0
	[Token(Token = "0x6001991")]
	[Address(RVA = "0x28A6534", Offset = "0x28A6534", VA = "0x28A6534")]
	public void ٽ߆ࡑՄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("CapuchinStore");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001992 RID: 6546 RVA: 0x0008A3F8 File Offset: 0x000885F8
	[Token(Token = "0x6001992")]
	[Address(RVA = "0x28A65CC", Offset = "0x28A65CC", VA = "0x28A65CC")]
	public void \u07BF\u0705\u0824ڮ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(" ");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001993 RID: 6547 RVA: 0x0008A430 File Offset: 0x00088630
	[Token(Token = "0x6001993")]
	[Address(RVA = "0x28A6664", Offset = "0x28A6664", VA = "0x28A6664")]
	public void ݼڔ\u05CE\u0899(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Display Name Changed!");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001994 RID: 6548 RVA: 0x0008A468 File Offset: 0x00088668
	[Token(Token = "0x6001994")]
	[Address(RVA = "0x28A66FC", Offset = "0x28A66FC", VA = "0x28A66FC")]
	public void ߃\u0602\u0891߇(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Name Changing Error. Error: ");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001995 RID: 6549 RVA: 0x0008A4A0 File Offset: 0x000886A0
	[Token(Token = "0x6001995")]
	[Address(RVA = "0x28A6794", Offset = "0x28A6794", VA = "0x28A6794")]
	public void \u0872\u0610ۅ\u06E1(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001996 RID: 6550 RVA: 0x0008A4D8 File Offset: 0x000886D8
	[Token(Token = "0x6001996")]
	[Address(RVA = "0x28A682C", Offset = "0x28A682C", VA = "0x28A682C")]
	public void \u0589\u0740\u05C6ӧ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayerHead");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001997 RID: 6551 RVA: 0x0008A510 File Offset: 0x00088710
	[Token(Token = "0x6001997")]
	[Address(RVA = "0x28A68C4", Offset = "0x28A68C4", VA = "0x28A68C4")]
	public void \u085Cݯژ\u05FA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("isLava");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001998 RID: 6552 RVA: 0x0008A548 File Offset: 0x00088748
	[Token(Token = "0x6001998")]
	[Address(RVA = "0x28A695C", Offset = "0x28A695C", VA = "0x28A695C")]
	public void ࢲ\u061C\u0817ݽ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PRESS AGAIN TO CONFIRM");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x06001999 RID: 6553 RVA: 0x0008A580 File Offset: 0x00088780
	[Token(Token = "0x6001999")]
	[Address(RVA = "0x28A69F4", Offset = "0x28A69F4", VA = "0x28A69F4")]
	public void \u0879\u0748ߙݥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600199A RID: 6554 RVA: 0x0008A5B8 File Offset: 0x000887B8
	[Token(Token = "0x600199A")]
	[Address(RVA = "0x28A6A8C", Offset = "0x28A6A8C", VA = "0x28A6A8C")]
	public void \u083Eܙ\u07FD\u0706(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("/");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 0L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x0600199B RID: 6555 RVA: 0x0008A5F0 File Offset: 0x000887F0
	[Token(Token = "0x600199B")]
	[Address(RVA = "0x28A6B24", Offset = "0x28A6B24", VA = "0x28A6B24")]
	public void ىރ\u0704ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		GameObject u055FӯԴԻ = this.\u055FӯԴԻ;
		long active = 1L;
		u055FӯԴԻ.SetActive(active != 0L);
	}

	// Token: 0x04000323 RID: 803
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000323")]
	public GameObject \u055FӯԴԻ;
}
