﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;

// Token: 0x0200003A RID: 58
[Token(Token = "0x200003A")]
public class PlayerName : MonoBehaviour
{
	// Token: 0x060007B5 RID: 1973 RVA: 0x0002A850 File Offset: 0x00028A50
	[Token(Token = "0x60007B5")]
	[Address(RVA = "0x29A2210", Offset = "0x29A2210", VA = "0x29A2210")]
	public PlayerName()
	{
	}

	// Token: 0x060007B6 RID: 1974 RVA: 0x0002A864 File Offset: 0x00028A64
	[Token(Token = "0x60007B6")]
	[Address(RVA = "0x29A2218", Offset = "0x29A2218", VA = "0x29A2218")]
	private void ݖܟ\u0704բ()
	{
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
	}

	// Token: 0x060007B7 RID: 1975 RVA: 0x0002A888 File Offset: 0x00028A88
	[Token(Token = "0x60007B7")]
	[Address(RVA = "0x29A2254", Offset = "0x29A2254", VA = "0x29A2254")]
	private void ۆڛߟ\u05A0()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("Meta Platform entitlement error: ");
			return;
		}
		this.ݛࡒܦ\u0609();
	}

	// Token: 0x060007B8 RID: 1976 RVA: 0x0002A92C File Offset: 0x00028B2C
	[Token(Token = "0x60007B8")]
	[Address(RVA = "0x29A2440", Offset = "0x29A2440", VA = "0x29A2440")]
	private void ߄Ӄ\u0613ھ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("Failed to login, please restart");
			return;
		}
		this.ӣޢ\u085E\u0748();
	}

	// Token: 0x060007B9 RID: 1977 RVA: 0x0002A9B4 File Offset: 0x00028BB4
	[Token(Token = "0x60007B9")]
	[Address(RVA = "0x29A263C", Offset = "0x29A263C", VA = "0x29A263C")]
	private void ٢\u06FDؼա()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007BA RID: 1978 RVA: 0x0002A9E4 File Offset: 0x00028BE4
	[Token(Token = "0x60007BA")]
	[Address(RVA = "0x29A2678", Offset = "0x29A2678", VA = "0x29A2678")]
	private void յ\u070E\u05AE\u0604()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007BB RID: 1979 RVA: 0x0002AA14 File Offset: 0x00028C14
	[Token(Token = "0x60007BB")]
	[Address(RVA = "0x29A26B4", Offset = "0x29A26B4", VA = "0x29A26B4")]
	private void ى߁ٱՏ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.յ\u070E\u05AE\u0604();
	}

	// Token: 0x060007BC RID: 1980 RVA: 0x0002AA48 File Offset: 0x00028C48
	[Token(Token = "0x60007BC")]
	[Address(RVA = "0x29A271C", Offset = "0x29A271C", VA = "0x29A271C")]
	private void \u07EBࠎיࡂ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("");
			return;
		}
		this.ࡃ\u0882\u06E9ߏ();
	}

	// Token: 0x060007BD RID: 1981 RVA: 0x0002AAF4 File Offset: 0x00028CF4
	[Token(Token = "0x60007BD")]
	[Address(RVA = "0x29A2918", Offset = "0x29A2918", VA = "0x29A2918")]
	private void کӝۏ\u060A()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007BE RID: 1982 RVA: 0x0002AB24 File Offset: 0x00028D24
	[Token(Token = "0x60007BE")]
	[Address(RVA = "0x29A2954", Offset = "0x29A2954", VA = "0x29A2954")]
	private void Ԁוև\u065B()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("monke screamed");
			return;
		}
		this.\u05CDݔڈԎ();
	}

	// Token: 0x060007BF RID: 1983 RVA: 0x0002ABC8 File Offset: 0x00028DC8
	[Token(Token = "0x60007BF")]
	[Address(RVA = "0x29A2B50", Offset = "0x29A2B50", VA = "0x29A2B50")]
	private void Start()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			long maxExclusive = 0L;
			bool flag = PlayerPrefs.HasKey("username");
			string[] ۂԪ_u0701պ = this.ۂԪ\u0701պ;
			int num = UnityEngine.Random.Range(0, (int)maxExclusive);
			long maxExclusive2 = 0L;
			string str = num.ToString();
			string[] ݕ_u0833ժӉ = this.ݕ\u0833ժӉ;
			string str2 = UnityEngine.Random.Range(0, (int)maxExclusive2).ToString();
			string str3 = UnityEngine.Random.Range(0, 1000).ToString();
			string value = str + " " + str2 + str3;
			PlayerPrefs.SetString("username", value);
			PhotonNetwork.NickName = PlayerPrefs.GetString("username");
		}
		this.շۍ\u0879\u0749();
	}

	// Token: 0x060007C0 RID: 1984 RVA: 0x0002AC6C File Offset: 0x00028E6C
	[Token(Token = "0x60007C0")]
	[Address(RVA = "0x29A2D14", Offset = "0x29A2D14", VA = "0x29A2D14")]
	private void Ԯ\u0883\u0591\u066C()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("CapuchinStore");
			return;
		}
		this.ࡡ\u0884ۆ\u0708();
	}

	// Token: 0x060007C1 RID: 1985 RVA: 0x0002ACF0 File Offset: 0x00028EF0
	[Token(Token = "0x60007C1")]
	[Address(RVA = "0x29A2F10", Offset = "0x29A2F10", VA = "0x29A2F10")]
	private void ہ\u0877\u07F2\u061E()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007C2 RID: 1986 RVA: 0x0002AD20 File Offset: 0x00028F20
	[Token(Token = "0x60007C2")]
	[Address(RVA = "0x29A2F4C", Offset = "0x29A2F4C", VA = "0x29A2F4C")]
	private void ԓࡠݙޗ()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007C3 RID: 1987 RVA: 0x0002AD50 File Offset: 0x00028F50
	[Token(Token = "0x60007C3")]
	[Address(RVA = "0x29A2F88", Offset = "0x29A2F88", VA = "0x29A2F88")]
	private void Ҿࢹؼס()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ՖيӲࡩ();
	}

	// Token: 0x060007C4 RID: 1988 RVA: 0x0002AD84 File Offset: 0x00028F84
	[Token(Token = "0x60007C4")]
	[Address(RVA = "0x29A302C", Offset = "0x29A302C", VA = "0x29A302C")]
	private void \u05ABݿࡋ\u06E9()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("got funky mone");
			return;
		}
		this.ՖيӲࡩ();
	}

	// Token: 0x060007C5 RID: 1989 RVA: 0x0002AE24 File Offset: 0x00029024
	[Token(Token = "0x60007C5")]
	[Address(RVA = "0x29A31EC", Offset = "0x29A31EC", VA = "0x29A31EC")]
	private void ߁\u0829\u073E\u081A()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("Right Hand");
			return;
		}
		this.Ջك\u0602ӝ();
	}

	// Token: 0x060007C6 RID: 1990 RVA: 0x0002AEC0 File Offset: 0x000290C0
	[Token(Token = "0x60007C6")]
	[Address(RVA = "0x29A33E8", Offset = "0x29A33E8", VA = "0x29A33E8")]
	private void \u0652\u058Bک\u061C()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("\tExpires: ");
			return;
		}
	}

	// Token: 0x060007C7 RID: 1991 RVA: 0x0002AF68 File Offset: 0x00029168
	[Token(Token = "0x60007C7")]
	[Address(RVA = "0x29A35E4", Offset = "0x29A35E4", VA = "0x29A35E4")]
	private void צ\u0874ڵ\u059A()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.کӝۏ\u060A();
	}

	// Token: 0x060007C8 RID: 1992 RVA: 0x0002AF9C File Offset: 0x0002919C
	[Token(Token = "0x60007C8")]
	[Address(RVA = "0x29A33AC", Offset = "0x29A33AC", VA = "0x29A33AC")]
	private void Ջك\u0602ӝ()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007C9 RID: 1993 RVA: 0x0002AFCC File Offset: 0x000291CC
	[Token(Token = "0x60007C9")]
	[Address(RVA = "0x29A364C", Offset = "0x29A364C", VA = "0x29A364C")]
	private void Update()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
	}

	// Token: 0x060007CA RID: 1994 RVA: 0x0002AFF8 File Offset: 0x000291F8
	[Token(Token = "0x60007CA")]
	[Address(RVA = "0x29A36B4", Offset = "0x29A36B4", VA = "0x29A36B4")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ࡡ\u0884ۆ\u0708();
	}

	// Token: 0x060007CB RID: 1995 RVA: 0x0002B02C File Offset: 0x0002922C
	[Token(Token = "0x60007CB")]
	[Address(RVA = "0x29A371C", Offset = "0x29A371C", VA = "0x29A371C")]
	private void ޡࠅ\u089Aߔ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("SetColor");
			return;
		}
		this.\u05CDݔڈԎ();
	}

	// Token: 0x060007CC RID: 1996 RVA: 0x0002B0D8 File Offset: 0x000292D8
	[Token(Token = "0x60007CC")]
	[Address(RVA = "0x29A38DC", Offset = "0x29A38DC", VA = "0x29A38DC")]
	private void Ӌ\u089C\u0700ܧ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ݖܟ\u0704բ();
	}

	// Token: 0x060007CD RID: 1997 RVA: 0x0002B10C File Offset: 0x0002930C
	[Token(Token = "0x60007CD")]
	[Address(RVA = "0x29A3944", Offset = "0x29A3944", VA = "0x29A3944")]
	private void ࠏޤݳ\u06DD()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("Player");
			return;
		}
		this.ࡃ\u0882\u06E9ߏ();
	}

	// Token: 0x060007CE RID: 1998 RVA: 0x0002B1B0 File Offset: 0x000293B0
	[Token(Token = "0x60007CE")]
	[Address(RVA = "0x29A3B04", Offset = "0x29A3B04", VA = "0x29A3B04")]
	private void \u05F8ݑ\u06ECߞ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.کӝۏ\u060A();
	}

	// Token: 0x060007CF RID: 1999 RVA: 0x0002B1E4 File Offset: 0x000293E4
	[Token(Token = "0x60007CF")]
	[Address(RVA = "0x29A3B6C", Offset = "0x29A3B6C", VA = "0x29A3B6C")]
	private void ګࠆ\u087Fכ()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007D0 RID: 2000 RVA: 0x0002B214 File Offset: 0x00029414
	[Token(Token = "0x60007D0")]
	[Address(RVA = "0x29A3BA8", Offset = "0x29A3BA8", VA = "0x29A3BA8")]
	private void \u0614ࢥӴ\u086C()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ګࠆ\u087Fכ();
	}

	// Token: 0x060007D1 RID: 2001 RVA: 0x0002B248 File Offset: 0x00029448
	[Token(Token = "0x60007D1")]
	[Address(RVA = "0x29A3C10", Offset = "0x29A3C10", VA = "0x29A3C10")]
	private void \u0590\u0882\u0883ࡦ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ՖيӲࡩ();
	}

	// Token: 0x060007D2 RID: 2002 RVA: 0x0002B27C File Offset: 0x0002947C
	[Token(Token = "0x60007D2")]
	[Address(RVA = "0x29A3C78", Offset = "0x29A3C78", VA = "0x29A3C78")]
	private void \u0705\u0816\u0739դ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.շۍ\u0879\u0749();
	}

	// Token: 0x060007D3 RID: 2003 RVA: 0x0002B2B0 File Offset: 0x000294B0
	[Token(Token = "0x60007D3")]
	[Address(RVA = "0x29A3CE0", Offset = "0x29A3CE0", VA = "0x29A3CE0")]
	private void \u070Aәޣے()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.\u06E6ۮ\u060C\u0878();
	}

	// Token: 0x060007D4 RID: 2004 RVA: 0x0002B2E4 File Offset: 0x000294E4
	[Token(Token = "0x60007D4")]
	[Address(RVA = "0x29A3D84", Offset = "0x29A3D84", VA = "0x29A3D84")]
	private void ӄځ\u083C\u086B()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007D5 RID: 2005 RVA: 0x0002B314 File Offset: 0x00029514
	[Token(Token = "0x60007D5")]
	[Address(RVA = "0x29A3DC0", Offset = "0x29A3DC0", VA = "0x29A3DC0")]
	private void \u0872މࢮՃ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ڣ\u055EڿԷ();
	}

	// Token: 0x060007D6 RID: 2006 RVA: 0x0002B348 File Offset: 0x00029548
	[Token(Token = "0x60007D6")]
	[Address(RVA = "0x29A3E28", Offset = "0x29A3E28", VA = "0x29A3E28")]
	private void ޙߍ\u081A\u0651()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("Not connected to room");
			return;
		}
		this.յ\u070E\u05AE\u0604();
	}

	// Token: 0x060007D7 RID: 2007 RVA: 0x0002B3EC File Offset: 0x000295EC
	[Token(Token = "0x60007D7")]
	[Address(RVA = "0x29A2FF0", Offset = "0x29A2FF0", VA = "0x29A2FF0")]
	private void ՖيӲࡩ()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007D8 RID: 2008 RVA: 0x0002B41C File Offset: 0x0002961C
	[Token(Token = "0x60007D8")]
	[Address(RVA = "0x29A3FE8", Offset = "0x29A3FE8", VA = "0x29A3FE8")]
	private void ں٢ࡡ\u05EC()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.کӝۏ\u060A();
	}

	// Token: 0x060007D9 RID: 2009 RVA: 0x0002B450 File Offset: 0x00029650
	[Token(Token = "0x60007D9")]
	[Address(RVA = "0x29A2B14", Offset = "0x29A2B14", VA = "0x29A2B14")]
	private void \u05CDݔڈԎ()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
	}

	// Token: 0x060007DA RID: 2010 RVA: 0x0002B478 File Offset: 0x00029678
	[Token(Token = "0x60007DA")]
	[Address(RVA = "0x29A4050", Offset = "0x29A4050", VA = "0x29A4050")]
	private void ۊո\u0612\u0595()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("TurnAmount");
			return;
		}
		this.ہ\u0877\u07F2\u061E();
	}

	// Token: 0x060007DB RID: 2011 RVA: 0x0002B524 File Offset: 0x00029724
	[Token(Token = "0x60007DB")]
	[Address(RVA = "0x29A4210", Offset = "0x29A4210", VA = "0x29A4210")]
	private void \u061DԎڕڌ()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007DC RID: 2012 RVA: 0x0002B554 File Offset: 0x00029754
	[Token(Token = "0x60007DC")]
	[Address(RVA = "0x29A424C", Offset = "0x29A424C", VA = "0x29A424C")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ڣ\u055EڿԷ();
	}

	// Token: 0x060007DD RID: 2013 RVA: 0x0002B588 File Offset: 0x00029788
	[Token(Token = "0x60007DD")]
	[Address(RVA = "0x29A2CD8", Offset = "0x29A2CD8", VA = "0x29A2CD8")]
	private void շۍ\u0879\u0749()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007DE RID: 2014 RVA: 0x0002B5B8 File Offset: 0x000297B8
	[Token(Token = "0x60007DE")]
	[Address(RVA = "0x29A42B4", Offset = "0x29A42B4", VA = "0x29A42B4")]
	private void Ҽ\u08B5ځ\u0658()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ԓࡠݙޗ();
	}

	// Token: 0x060007DF RID: 2015 RVA: 0x0002B5EC File Offset: 0x000297EC
	[Token(Token = "0x60007DF")]
	[Address(RVA = "0x29A431C", Offset = "0x29A431C", VA = "0x29A431C")]
	private void ڑߒجވ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ӄځ\u083C\u086B();
	}

	// Token: 0x060007E0 RID: 2016 RVA: 0x0002B620 File Offset: 0x00029820
	[Token(Token = "0x60007E0")]
	[Address(RVA = "0x29A2404", Offset = "0x29A2404", VA = "0x29A2404")]
	private void ݛࡒܦ\u0609()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007E1 RID: 2017 RVA: 0x0002B650 File Offset: 0x00029850
	[Token(Token = "0x60007E1")]
	[Address(RVA = "0x29A4384", Offset = "0x29A4384", VA = "0x29A4384")]
	private void \u07BDއڸ\u0834()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ࡡ\u0884ۆ\u0708();
	}

	// Token: 0x060007E2 RID: 2018 RVA: 0x0002B684 File Offset: 0x00029884
	[Token(Token = "0x60007E2")]
	[Address(RVA = "0x29A43EC", Offset = "0x29A43EC", VA = "0x29A43EC")]
	private void Վכ\u085B\u06E6()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007E3 RID: 2019 RVA: 0x0002B6B4 File Offset: 0x000298B4
	[Token(Token = "0x60007E3")]
	[Address(RVA = "0x29A4428", Offset = "0x29A4428", VA = "0x29A4428")]
	private void ԞԌ\u086FՇ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("PlayerDeath");
			return;
		}
		this.յ\u070E\u05AE\u0604();
	}

	// Token: 0x060007E4 RID: 2020 RVA: 0x0002B754 File Offset: 0x00029954
	[Token(Token = "0x60007E4")]
	[Address(RVA = "0x29A45DC", Offset = "0x29A45DC", VA = "0x29A45DC")]
	private void ݤۅࢦӃ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			long maxExclusive = 0L;
			bool flag = PlayerPrefs.HasKey("EnableCosmetic");
			string[] ۂԪ_u0701պ = this.ۂԪ\u0701պ;
			int num = UnityEngine.Random.Range(1, (int)maxExclusive);
			long maxExclusive2 = 0L;
			string str = num.ToString();
			string[] ݕ_u0833ժӉ = this.ݕ\u0833ժӉ;
			string str2 = UnityEngine.Random.Range(0, (int)maxExclusive2).ToString();
			string str3 = UnityEngine.Random.Range(0, 168).ToString();
			string value = str + "SetColor" + str2 + str3;
			PlayerPrefs.SetString("HeadAttachPoint", value);
			PhotonNetwork.NickName = PlayerPrefs.GetString("Player");
		}
		this.ڿ\u0887זԭ();
	}

	// Token: 0x060007E5 RID: 2021 RVA: 0x0002B7F8 File Offset: 0x000299F8
	[Token(Token = "0x60007E5")]
	[Address(RVA = "0x29A47C0", Offset = "0x29A47C0", VA = "0x29A47C0")]
	private void \u0886Ҽ\u058Dߛ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ګࠆ\u087Fכ();
	}

	// Token: 0x060007E6 RID: 2022 RVA: 0x0002B82C File Offset: 0x00029A2C
	[Token(Token = "0x60007E6")]
	[Address(RVA = "0x29A4828", Offset = "0x29A4828", VA = "0x29A4828")]
	private void ࢫ\u0876չՍ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ڿ\u0887זԭ();
	}

	// Token: 0x060007E7 RID: 2023 RVA: 0x0002B860 File Offset: 0x00029A60
	[Token(Token = "0x60007E7")]
	[Address(RVA = "0x29A2ED4", Offset = "0x29A2ED4", VA = "0x29A2ED4")]
	private void ࡡ\u0884ۆ\u0708()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007E8 RID: 2024 RVA: 0x0002B890 File Offset: 0x00029A90
	[Token(Token = "0x60007E8")]
	[Address(RVA = "0x29A4890", Offset = "0x29A4890", VA = "0x29A4890")]
	private void ١ۏ\u05C4ӝ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("FingerTip");
			return;
		}
		this.ݛࡒܦ\u0609();
	}

	// Token: 0x060007E9 RID: 2025 RVA: 0x0002B934 File Offset: 0x00029B34
	[Token(Token = "0x60007E9")]
	[Address(RVA = "0x29A4A50", Offset = "0x29A4A50", VA = "0x29A4A50")]
	private void ո\u07AA\u05BDࠕ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.շۍ\u0879\u0749();
	}

	// Token: 0x060007EA RID: 2026 RVA: 0x0002B968 File Offset: 0x00029B68
	[Token(Token = "0x60007EA")]
	[Address(RVA = "0x29A4AB8", Offset = "0x29A4AB8", VA = "0x29A4AB8")]
	private void הԥ\u05B5ݴ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("Completed baking textures on frame ");
			return;
		}
		this.շۍ\u0879\u0749();
	}

	// Token: 0x060007EB RID: 2027 RVA: 0x0002BA14 File Offset: 0x00029C14
	[Token(Token = "0x60007EB")]
	[Address(RVA = "0x29A4C78", Offset = "0x29A4C78", VA = "0x29A4C78")]
	private void ژךՈ\u0597()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ہ\u0877\u07F2\u061E();
	}

	// Token: 0x060007EC RID: 2028 RVA: 0x0002BA48 File Offset: 0x00029C48
	[Token(Token = "0x60007EC")]
	[Address(RVA = "0x29A2600", Offset = "0x29A2600", VA = "0x29A2600")]
	private void ӣޢ\u085E\u0748()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007ED RID: 2029 RVA: 0x0002BA78 File Offset: 0x00029C78
	[Token(Token = "0x60007ED")]
	[Address(RVA = "0x29A4CE0", Offset = "0x29A4CE0", VA = "0x29A4CE0")]
	private void ࡅݐ\u082Dք()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("Add/Remove Hat");
			return;
		}
		this.ࡃ\u0882\u06E9ߏ();
	}

	// Token: 0x060007EE RID: 2030 RVA: 0x0002BB28 File Offset: 0x00029D28
	[Token(Token = "0x60007EE")]
	[Address(RVA = "0x29A3D48", Offset = "0x29A3D48", VA = "0x29A3D48")]
	private void \u06E6ۮ\u060C\u0878()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007EF RID: 2031 RVA: 0x0002BB58 File Offset: 0x00029D58
	[Token(Token = "0x60007EF")]
	[Address(RVA = "0x29A4EA0", Offset = "0x29A4EA0", VA = "0x29A4EA0")]
	private void יԠ\u07EDԺ()
	{
		string nickName = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField.nickName;
		this.ݛࡒܦ\u0609();
	}

	// Token: 0x060007F0 RID: 2032 RVA: 0x0002BB84 File Offset: 0x00029D84
	[Token(Token = "0x60007F0")]
	[Address(RVA = "0x29A28DC", Offset = "0x29A28DC", VA = "0x29A28DC")]
	private void ࡃ\u0882\u06E9ߏ()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007F1 RID: 2033 RVA: 0x0002BBB4 File Offset: 0x00029DB4
	[Token(Token = "0x60007F1")]
	[Address(RVA = "0x29A4F08", Offset = "0x29A4F08", VA = "0x29A4F08")]
	private void ժ\u065Dԯࡘ()
	{
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		this.ࡃ\u0882\u06E9ߏ();
	}

	// Token: 0x060007F2 RID: 2034 RVA: 0x0002BBE4 File Offset: 0x00029DE4
	[Token(Token = "0x60007F2")]
	[Address(RVA = "0x29A4784", Offset = "0x29A4784", VA = "0x29A4784")]
	private void ڿ\u0887זԭ()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x060007F3 RID: 2035 RVA: 0x0002BC14 File Offset: 0x00029E14
	[Token(Token = "0x60007F3")]
	[Address(RVA = "0x29A4F70", Offset = "0x29A4F70", VA = "0x29A4F70")]
	private void \u0656ӺմՁ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			bool flag = PlayerPrefs.HasKey("Combine textures & build combined mesh all at once");
			return;
		}
		this.ڣ\u055EڿԷ();
	}

	// Token: 0x060007F4 RID: 2036 RVA: 0x0002BCB8 File Offset: 0x00029EB8
	[Token(Token = "0x60007F4")]
	[Address(RVA = "0x29A35A8", Offset = "0x29A35A8", VA = "0x29A35A8")]
	private void ڣ\u055EڿԷ()
	{
		Player <Owner>k__BackingField = this.\u07AE\u05AF\u064FԖ.<Owner>k__BackingField;
		TextMeshPro textMeshPro = this.٩ט٢ԩ;
		string nickName = <Owner>k__BackingField.nickName;
	}

	// Token: 0x0400010A RID: 266
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400010A")]
	public PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x0400010B RID: 267
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400010B")]
	public TextMeshPro ٩ט٢ԩ;

	// Token: 0x0400010C RID: 268
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400010C")]
	public string[] ۂԪ\u0701պ;

	// Token: 0x0400010D RID: 269
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400010D")]
	public string[] ݕ\u0833ժӉ;
}
