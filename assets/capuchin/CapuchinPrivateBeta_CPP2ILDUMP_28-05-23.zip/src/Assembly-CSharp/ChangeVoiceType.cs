﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x02000049 RID: 73
[Token(Token = "0x2000049")]
public class ChangeVoiceType : MonoBehaviour
{
	// Token: 0x06000A12 RID: 2578 RVA: 0x00037094 File Offset: 0x00035294
	[Token(Token = "0x6000A12")]
	[Address(RVA = "0x29426BC", Offset = "0x29426BC", VA = "0x29426BC")]
	public void ڣֆ\u07F4ڌ()
	{
		this.\u085Dܮݑխ();
	}

	// Token: 0x06000A13 RID: 2579 RVA: 0x000370A8 File Offset: 0x000352A8
	[Token(Token = "0x6000A13")]
	[Address(RVA = "0x29428BC", Offset = "0x29428BC", VA = "0x29428BC")]
	public void ӛ\u082Eؿڕ()
	{
		this.\u0876ط\u06FEݺ();
	}

	// Token: 0x06000A14 RID: 2580 RVA: 0x000370BC File Offset: 0x000352BC
	[Token(Token = "0x6000A14")]
	[Address(RVA = "0x2942AD0", Offset = "0x2942AD0", VA = "0x2942AD0")]
	public void Ւښәࠐ()
	{
		bool flag = PlayerPrefs.GetString("Purchased: ") == "2BN";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 0L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		this.ٷ\u0608ӯՉ.SetActive(active != 0L);
		bool flag2 = PlayerPrefs.GetString("button") == "typesOfTalk";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active2 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active2 != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active3 = 0L;
		ٷ_u0608ӯՉ.SetActive(active3 != 0L);
		string a;
		bool flag3 = a == "Connected to Server.";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active4 = 0L;
		u0530_u0883Ի_u083E3.SetActive(active4 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active5 = 1L;
		ٷ_u0608ӯՉ2.SetActive(active5 != 0L);
	}

	// Token: 0x06000A15 RID: 2581 RVA: 0x0003718C File Offset: 0x0003538C
	[Token(Token = "0x6000A15")]
	[Address(RVA = "0x2942CE0", Offset = "0x2942CE0", VA = "0x2942CE0")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 0L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 1L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Room Name: ", "On");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A16 RID: 2582 RVA: 0x00037270 File Offset: 0x00035470
	[Token(Token = "0x6000A16")]
	[Address(RVA = "0x2942F44", Offset = "0x2942F44", VA = "0x2942F44")]
	public void چ\u05AEךڰ()
	{
		this.ݲײنࡣ();
	}

	// Token: 0x06000A17 RID: 2583 RVA: 0x00037284 File Offset: 0x00035484
	[Token(Token = "0x6000A17")]
	[Address(RVA = "0x2943144", Offset = "0x2943144", VA = "0x2943144")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 0L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 0L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			return;
		}
	}

	// Token: 0x06000A18 RID: 2584 RVA: 0x0003734C File Offset: 0x0003554C
	[Token(Token = "0x6000A18")]
	[Address(RVA = "0x2943378", Offset = "0x2943378", VA = "0x2943378")]
	public void \u0706\u06DEӸ\u081C()
	{
		bool flag = PlayerPrefs.GetString("") == "ChangeToRegular";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("Player") == "sound play stopped";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 1L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("username") == "Updating Material to: ";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 1L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 1L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A19 RID: 2585 RVA: 0x0003742C File Offset: 0x0003562C
	[Token(Token = "0x6000A19")]
	[Address(RVA = "0x2943574", Offset = "0x2943574", VA = "0x2943574")]
	public void ࢺճ\u05A0ڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 0L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 1L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("CapuchinStore", "username");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A1A RID: 2586 RVA: 0x00037510 File Offset: 0x00035710
	[Token(Token = "0x6000A1A")]
	[Address(RVA = "0x29437CC", Offset = "0x29437CC", VA = "0x29437CC")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 0L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 0L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("closeToObject", "Bruh i cannot go here you stupid L bozo");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A1B RID: 2587 RVA: 0x000375F4 File Offset: 0x000357F4
	[Token(Token = "0x6000A1B")]
	[Address(RVA = "0x2943A30", Offset = "0x2943A30", VA = "0x2943A30")]
	public void نո\u0599\u0589()
	{
		this.\u085Dܮݑխ();
	}

	// Token: 0x06000A1C RID: 2588 RVA: 0x00037608 File Offset: 0x00035808
	[Token(Token = "0x6000A1C")]
	[Address(RVA = "0x2943A34", Offset = "0x2943A34", VA = "0x2943A34")]
	public void ӭࡖݲ\u05BD()
	{
		this.ӺԴߐ\u088E();
	}

	// Token: 0x06000A1D RID: 2589 RVA: 0x0003761C File Offset: 0x0003581C
	[Token(Token = "0x6000A1D")]
	[Address(RVA = "0x2943C48", Offset = "0x2943C48", VA = "0x2943C48")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		bool flag = \u07FEל\u05AC\u0877;
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 0L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 1L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("typesOfTalk", "next");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A1E RID: 2590 RVA: 0x00037704 File Offset: 0x00035904
	[Token(Token = "0x6000A1E")]
	[Address(RVA = "0x2943EAC", Offset = "0x2943EAC", VA = "0x2943EAC")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active = 0L;
			ٷ_u0608ӯՉ.SetActive(active != 0L);
			PlayerPrefs.SetString("Player", "isLava");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A1F RID: 2591 RVA: 0x000377D8 File Offset: 0x000359D8
	[Token(Token = "0x6000A1F")]
	[Address(RVA = "0x2944104", Offset = "0x2944104", VA = "0x2944104")]
	public void \u0892ࡋ\u0896ݩ()
	{
		bool flag = PlayerPrefs.GetString("Add/Remove Sword") == "True";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 0L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.") == "FingerTip";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 1L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		string a;
		bool flag3 = a == "Meta Platform entitlement error: ";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 0L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 1L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A20 RID: 2592 RVA: 0x000378B0 File Offset: 0x00035AB0
	[Token(Token = "0x6000A20")]
	[Address(RVA = "0x2944314", Offset = "0x2944314", VA = "0x2944314")]
	public void ߖհݣ߀()
	{
		this.ӭӴӽގ();
	}

	// Token: 0x06000A21 RID: 2593 RVA: 0x000378C4 File Offset: 0x00035AC4
	[Token(Token = "0x6000A21")]
	[Address(RVA = "0x2944528", Offset = "0x2944528", VA = "0x2944528")]
	public void Ԁוև\u065B()
	{
		this.ر\u0670\u05B6ժ();
	}

	// Token: 0x06000A22 RID: 2594 RVA: 0x000378D8 File Offset: 0x00035AD8
	[Token(Token = "0x6000A22")]
	[Address(RVA = "0x2944318", Offset = "0x2944318", VA = "0x2944318")]
	public void ӭӴӽގ()
	{
		bool flag = PlayerPrefs.GetString("EnableCosmetic") == " and for the price of ";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 0L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("\n") == "Not connected to room";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 1L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		string @string = PlayerPrefs.GetString("Player");
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 0L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 0L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A23 RID: 2595 RVA: 0x000379B0 File Offset: 0x00035BB0
	[Token(Token = "0x6000A23")]
	[Address(RVA = "0x29446E0", Offset = "0x29446E0", VA = "0x29446E0")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 0L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 0L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Version", "Calling success callback. baking meshes");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A24 RID: 2596 RVA: 0x00037A80 File Offset: 0x00035C80
	[Token(Token = "0x6000A24")]
	[Address(RVA = "0x2944938", Offset = "0x2944938", VA = "0x2944938")]
	public void Start()
	{
		this.ر\u0670\u05B6ժ();
	}

	// Token: 0x06000A25 RID: 2597 RVA: 0x00037A94 File Offset: 0x00035C94
	[Token(Token = "0x6000A25")]
	[Address(RVA = "0x294493C", Offset = "0x294493C", VA = "0x294493C")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 1L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 0L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Player", "_Tint");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A26 RID: 2598 RVA: 0x00037B78 File Offset: 0x00035D78
	[Token(Token = "0x6000A26")]
	[Address(RVA = "0x2944B90", Offset = "0x2944B90", VA = "0x2944B90")]
	public ChangeVoiceType()
	{
	}

	// Token: 0x06000A27 RID: 2599 RVA: 0x00037B8C File Offset: 0x00035D8C
	[Token(Token = "0x6000A27")]
	[Address(RVA = "0x2944B98", Offset = "0x2944B98", VA = "0x2944B98")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 0L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 0L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("typesOfTalk", "HorrorAgreement");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A28 RID: 2600 RVA: 0x00037C70 File Offset: 0x00035E70
	[Token(Token = "0x6000A28")]
	[Address(RVA = "0x2944DF0", Offset = "0x2944DF0", VA = "0x2944DF0")]
	public void ࢧӾڈց()
	{
		this.\u085A\u070Dԡڮ();
	}

	// Token: 0x06000A29 RID: 2601 RVA: 0x00037C84 File Offset: 0x00035E84
	[Token(Token = "0x6000A29")]
	[Address(RVA = "0x2944DF4", Offset = "0x2944DF4", VA = "0x2944DF4")]
	public void \u085A\u070Dԡڮ()
	{
		bool flag = PlayerPrefs.GetString("clickLol") == "character limit reached";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("EnableCosmetic") == "Failed to get catalog, cosmetic name, and price. Exact error details is: ";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("false") == "Left Hand";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 1L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 1L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A2A RID: 2602 RVA: 0x00037D64 File Offset: 0x00035F64
	[Token(Token = "0x6000A2A")]
	[Address(RVA = "0x2945004", Offset = "0x2945004", VA = "0x2945004")]
	public void \u058EԸس\u0819()
	{
		this.\u085A\u070Dԡڮ();
	}

	// Token: 0x06000A2B RID: 2603 RVA: 0x00037D78 File Offset: 0x00035F78
	[Token(Token = "0x6000A2B")]
	[Address(RVA = "0x2945008", Offset = "0x2945008", VA = "0x2945008")]
	public void ڕ\u061C\u0897ת()
	{
		bool flag = PlayerPrefs.GetString("Player") == "Head";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 0L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("FingerTip") == "typesOfTalk";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 1L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 1L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("FingerTip") == "PlayNoise";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 0L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 0L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A2C RID: 2604 RVA: 0x00037E58 File Offset: 0x00036058
	[Token(Token = "0x6000A2C")]
	[Address(RVA = "0x29451FC", Offset = "0x29451FC", VA = "0x29451FC")]
	public void ҿ\u064Cܪ۳()
	{
		bool flag = PlayerPrefs.GetString("META") == "username";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 0L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 0L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("DisableCosmetic") == "PlayerHead";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 1L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 1L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("DisableCosmetic") == "Player";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 0L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 0L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A2D RID: 2605 RVA: 0x00037F38 File Offset: 0x00036138
	[Token(Token = "0x6000A2D")]
	[Address(RVA = "0x29453F8", Offset = "0x29453F8", VA = "0x29453F8")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = this.ڰܢ\u07F6ل;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 0L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		PlayerPrefs.SetString("PlayerHead", "Player");
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
	}

	// Token: 0x06000A2E RID: 2606 RVA: 0x0003801C File Offset: 0x0003621C
	[Token(Token = "0x6000A2E")]
	[Address(RVA = "0x294565C", Offset = "0x294565C", VA = "0x294565C")]
	public void ܩחݵޔ()
	{
		this.\u0876ط\u06FEݺ();
	}

	// Token: 0x06000A2F RID: 2607 RVA: 0x00038030 File Offset: 0x00036230
	[Token(Token = "0x6000A2F")]
	[Address(RVA = "0x2945660", Offset = "0x2945660", VA = "0x2945660")]
	public void ןٮ\u061FԺ()
	{
		this.\u0706\u06DEӸ\u081C();
	}

	// Token: 0x06000A30 RID: 2608 RVA: 0x00038044 File Offset: 0x00036244
	[Token(Token = "0x6000A30")]
	[Address(RVA = "0x2942F48", Offset = "0x2942F48", VA = "0x2942F48")]
	public void ݲײنࡣ()
	{
		bool flag = PlayerPrefs.GetString("username") == "ChangeToTagged";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("Time to bake textures: ") == "Date: ";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 1L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("hh:mm:sstt") == ".Please press the button if you would like to play alone";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 1L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 1L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A31 RID: 2609 RVA: 0x00038124 File Offset: 0x00036324
	[Token(Token = "0x6000A31")]
	[Address(RVA = "0x29428C0", Offset = "0x29428C0", VA = "0x29428C0")]
	public void \u0876ط\u06FEݺ()
	{
		bool flag = PlayerPrefs.GetString("TurnAmount") == "We don't need this electrical box";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString(".Please press the button if you would like to play alone") == "Player";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("NetworkPlayer") == "monke is not my monke";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 0L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 0L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A32 RID: 2610 RVA: 0x00038204 File Offset: 0x00036404
	[Token(Token = "0x6000A32")]
	[Address(RVA = "0x2945664", Offset = "0x2945664", VA = "0x2945664")]
	public void וࠋ٨ؿ()
	{
		bool flag = PlayerPrefs.GetString("typesOfTalk") == "Error";
		bool flag2 = PlayerPrefs.GetString("A new Player joined a Room.") == "FingerTip";
		bool flag3 = PlayerPrefs.GetString(". Please update you game to the latest version") == "Tagged";
	}

	// Token: 0x06000A33 RID: 2611 RVA: 0x00038268 File Offset: 0x00036468
	[Token(Token = "0x6000A33")]
	[Address(RVA = "0x2945874", Offset = "0x2945874", VA = "0x2945874")]
	public void ۊո\u0612\u0595()
	{
		this.\u07A6վ\u06D7\u0702();
	}

	// Token: 0x06000A34 RID: 2612 RVA: 0x0003827C File Offset: 0x0003647C
	[Token(Token = "0x6000A34")]
	[Address(RVA = "0x2945A88", Offset = "0x2945A88", VA = "0x2945A88")]
	public void ۆڛߟ\u05A0()
	{
		this.\u0605Ӟޙߥ();
	}

	// Token: 0x06000A35 RID: 2613 RVA: 0x00038290 File Offset: 0x00036490
	[Token(Token = "0x6000A35")]
	[Address(RVA = "0x2945C54", Offset = "0x2945C54", VA = "0x2945C54")]
	public void \u0743ݹۏޅ()
	{
		bool flag = PlayerPrefs.GetString("A new Player joined a Room.") == "You Already Own This Item";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active = 1L;
		ٷ_u0608ӯՉ.SetActive(active != 0L);
		bool flag2 = PlayerPrefs.GetString("HandL") == "TurnAmount";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active2 = 1L;
		u0530_u0883Ի_u083E2.SetActive(active2 != 0L);
		this.ٷ\u0608ӯՉ.SetActive(active2 != 0L);
		bool flag3 = PlayerPrefs.GetString("Not connected to room") == "PlayerHead";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active3 = 1L;
		u0530_u0883Ի_u083E3.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 1L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
	}

	// Token: 0x06000A36 RID: 2614 RVA: 0x00038360 File Offset: 0x00036560
	[Token(Token = "0x6000A36")]
	[Address(RVA = "0x2945E64", Offset = "0x2945E64", VA = "0x2945E64")]
	public void ۮ۶ބ۱()
	{
		bool flag = PlayerPrefs.GetString("Player") == "You Already Own This Item";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 0L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 0L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("A new Player joined a Room.") == "FingerTip";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 1L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		string @string = PlayerPrefs.GetString("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n");
	}

	// Token: 0x06000A37 RID: 2615 RVA: 0x00038438 File Offset: 0x00036638
	[Token(Token = "0x6000A37")]
	[Address(RVA = "0x294452C", Offset = "0x294452C", VA = "0x294452C")]
	public void ر\u0670\u05B6ժ()
	{
		bool flag = PlayerPrefs.GetString("typesOfTalk") == "True";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 0L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("typesOfTalk") == "True";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("typesOfTalk") == "True";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 0L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 1L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A38 RID: 2616 RVA: 0x00038518 File Offset: 0x00036718
	[Token(Token = "0x6000A38")]
	[Address(RVA = "0x2946074", Offset = "0x2946074", VA = "0x2946074")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 1L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			long active2 = 1L;
			u0530_u0883Ի_u083E.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Player", "User has been reported for: ");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A39 RID: 2617 RVA: 0x000385F0 File Offset: 0x000367F0
	[Token(Token = "0x6000A39")]
	[Address(RVA = "0x29462D8", Offset = "0x29462D8", VA = "0x29462D8")]
	public void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 1L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 1L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Failed To Join Public Room Successfully. The error is: ", "containsStaff");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A3A RID: 2618 RVA: 0x000386D4 File Offset: 0x000368D4
	[Token(Token = "0x6000A3A")]
	[Address(RVA = "0x29426C0", Offset = "0x29426C0", VA = "0x29426C0")]
	public void \u085Dܮݑխ()
	{
		bool flag = PlayerPrefs.GetString("A new Player joined a Room.") == "FingerTip";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("Joined Public Room Successfully") == "DisableCosmetic";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("Is Colliding") == "Name Changing Error. Error: ";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 1L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 0L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A3B RID: 2619 RVA: 0x000387B4 File Offset: 0x000369B4
	[Token(Token = "0x6000A3B")]
	[Address(RVA = "0x294653C", Offset = "0x294653C", VA = "0x294653C")]
	public void ۮߝڪڐ()
	{
		this.\u05F3\u06E3\u05C8վ();
	}

	// Token: 0x06000A3C RID: 2620 RVA: 0x000387C8 File Offset: 0x000369C8
	[Token(Token = "0x6000A3C")]
	[Address(RVA = "0x294673C", Offset = "0x294673C", VA = "0x294673C")]
	public void ߒ\u065EՎࡖ()
	{
		this.ݲײنࡣ();
	}

	// Token: 0x06000A3D RID: 2621 RVA: 0x000387DC File Offset: 0x000369DC
	[Token(Token = "0x6000A3D")]
	[Address(RVA = "0x2946740", Offset = "0x2946740", VA = "0x2946740")]
	public void \u07FCࡧد\u05B9()
	{
		bool flag = PlayerPrefs.GetString("You Already Own This Item") == "TurnAmount";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("_Tint") == "StartGamemode";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("Start Gamemode") == "5BN";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 1L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 1L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A3E RID: 2622 RVA: 0x000388BC File Offset: 0x00036ABC
	[Token(Token = "0x6000A3E")]
	[Address(RVA = "0x2946950", Offset = "0x2946950", VA = "0x2946950")]
	public void ۋ\u064BՋ\u0640()
	{
		bool flag = PlayerPrefs.GetString("_WobbleX") == "Network Player";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		string @string = PlayerPrefs.GetString("Did Hit");
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active3 = 1L;
		ٷ_u0608ӯՉ2.SetActive(active3 != 0L);
		bool flag2 = PlayerPrefs.GetString("Did Hit") == "FingerTip";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active4 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active4 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active5 = 0L;
		ٷ_u0608ӯՉ3.SetActive(active5 != 0L);
	}

	// Token: 0x06000A3F RID: 2623 RVA: 0x00038984 File Offset: 0x00036B84
	[Token(Token = "0x6000A3F")]
	[Address(RVA = "0x2946B4C", Offset = "0x2946B4C", VA = "0x2946B4C")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 0L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 1L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("TurnAmount", "");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A40 RID: 2624 RVA: 0x00038A68 File Offset: 0x00036C68
	[Token(Token = "0x6000A40")]
	[Address(RVA = "0x2946DB0", Offset = "0x2946DB0", VA = "0x2946DB0")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 0L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 0L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.", "Purchased: ");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A41 RID: 2625 RVA: 0x00038B4C File Offset: 0x00036D4C
	[Token(Token = "0x6000A41")]
	[Address(RVA = "0x2947014", Offset = "0x2947014", VA = "0x2947014")]
	public void ޠۋ\u0530\u073E()
	{
		this.حهەӒ();
	}

	// Token: 0x06000A42 RID: 2626 RVA: 0x00038B60 File Offset: 0x00036D60
	[Token(Token = "0x6000A42")]
	[Address(RVA = "0x2947228", Offset = "0x2947228", VA = "0x2947228")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ڰܢ\u07F6ل == ChangeVoiceType.\u05C4٤\u061Eݿ.ܒࢢࢱݙ)
		{
			GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
			long active = 1L;
			u0530_u0883Ի_u083E.SetActive(active != 0L);
			GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
			long active2 = 0L;
			ٷ_u0608ӯՉ.SetActive(active2 != 0L);
			PlayerPrefs.SetString("typesOfTalk", "True");
			TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
			return;
		}
	}

	// Token: 0x06000A43 RID: 2627 RVA: 0x00038C30 File Offset: 0x00036E30
	[Token(Token = "0x6000A43")]
	[Address(RVA = "0x2947474", Offset = "0x2947474", VA = "0x2947474")]
	public void ߁\u0829\u073E\u081A()
	{
		this.וࠋ٨ؿ();
	}

	// Token: 0x06000A44 RID: 2628 RVA: 0x00038C44 File Offset: 0x00036E44
	[Token(Token = "0x6000A44")]
	[Address(RVA = "0x2947478", Offset = "0x2947478", VA = "0x2947478")]
	public void ڦ\u0656\u0742Խ()
	{
		bool flag = PlayerPrefs.GetString("Purchase For ") == "NGNNoSound";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 0L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("2BN") == "Display Name Changed!";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("_Smoothness") == "next";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 1L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 0L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A45 RID: 2629 RVA: 0x00038D24 File Offset: 0x00036F24
	[Token(Token = "0x6000A45")]
	[Address(RVA = "0x2947688", Offset = "0x2947688", VA = "0x2947688")]
	public void \u05ABݿࡋ\u06E9()
	{
		this.\u0892ࡋ\u0896ݩ();
	}

	// Token: 0x06000A46 RID: 2630 RVA: 0x00038D38 File Offset: 0x00036F38
	[Token(Token = "0x6000A46")]
	[Address(RVA = "0x2947018", Offset = "0x2947018", VA = "0x2947018")]
	public void حهەӒ()
	{
		bool flag = PlayerPrefs.GetString("Network Player") == "FingerTip";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 0L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("Platform failed to initialize due to exception.") == "\n Time: ";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("PURCHASED") == "Player";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 0L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 1L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A47 RID: 2631 RVA: 0x00038E18 File Offset: 0x00037018
	[Token(Token = "0x6000A47")]
	[Address(RVA = "0x294768C", Offset = "0x294768C", VA = "0x294768C")]
	public void \u0829\u0828ݪۇ()
	{
		bool flag = PlayerPrefs.GetString("Fire Stick Is Lighting...") == "tp 2";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 0L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("typesOfTalk") == "ENABLE";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 1L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 1L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("BN") == "BN";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 1L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 0L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A48 RID: 2632 RVA: 0x00038EF8 File Offset: 0x000370F8
	[Token(Token = "0x6000A48")]
	[Address(RVA = "0x2945A8C", Offset = "0x2945A8C", VA = "0x2945A8C")]
	public void \u0605Ӟޙߥ()
	{
		string a;
		bool flag = a == "false";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 0L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 0L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("false") == "Player";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 1L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("Meta Platform entitlement error: ") == "Player";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 1L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 1L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A49 RID: 2633 RVA: 0x00038FD4 File Offset: 0x000371D4
	[Token(Token = "0x6000A49")]
	[Address(RVA = "0x2947888", Offset = "0x2947888", VA = "0x2947888")]
	public void \u082E\u06EBݼڏ()
	{
		this.\u085A\u070Dԡڮ();
	}

	// Token: 0x06000A4A RID: 2634 RVA: 0x00038FE8 File Offset: 0x000371E8
	[Token(Token = "0x6000A4A")]
	[Address(RVA = "0x2946540", Offset = "0x2946540", VA = "0x2946540")]
	public void \u05F3\u06E3\u05C8վ()
	{
		bool flag = PlayerPrefs.GetString("FingerTip") == "M/d/yyyy";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 0L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 0L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("_Tint") == "EnableCosmetic";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("FingerTip") == "Player";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 0L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 1L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A4B RID: 2635 RVA: 0x000390C8 File Offset: 0x000372C8
	[Token(Token = "0x6000A4B")]
	[Address(RVA = "0x294788C", Offset = "0x294788C", VA = "0x294788C")]
	public void \u0834\u0817ރࡔ()
	{
		this.\u0876ط\u06FEݺ();
	}

	// Token: 0x06000A4C RID: 2636 RVA: 0x000390DC File Offset: 0x000372DC
	[Token(Token = "0x6000A4C")]
	[Address(RVA = "0x2943A38", Offset = "0x2943A38", VA = "0x2943A38")]
	public void ӺԴߐ\u088E()
	{
		bool flag = PlayerPrefs.GetString("PRESS AGAIN TO CONFIRM") == "Add/Remove Sword";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active = 0L;
		ٷ_u0608ӯՉ.SetActive(active != 0L);
		bool flag2 = PlayerPrefs.GetString("Push To Talk") == "5BN";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active2 = 0L;
		u0530_u0883Ի_u083E.SetActive(active2 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active3 = 0L;
		ٷ_u0608ӯՉ2.SetActive(active3 != 0L);
		bool flag3 = PlayerPrefs.GetString("\tExpires: ") == "containsStaff";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active4 = 1L;
		u0530_u0883Ի_u083E2.SetActive(active4 != 0L);
		long active5 = 0L;
		u0530_u0883Ի_u083E2.SetActive(active5 != 0L);
	}

	// Token: 0x06000A4D RID: 2637 RVA: 0x000391A4 File Offset: 0x000373A4
	[Token(Token = "0x6000A4D")]
	[Address(RVA = "0x2945878", Offset = "0x2945878", VA = "0x2945878")]
	public void \u07A6վ\u06D7\u0702()
	{
		bool flag = PlayerPrefs.GetString("hand 2") == "Player was caught cheating";
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 0L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 1L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		bool flag2 = PlayerPrefs.GetString("procedural animation script required on ") == "HandL";
		TextMeshPro u05A3_u07B4_u0705_u2 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E2 = this.\u0530\u0883Ի\u083E;
		long active3 = 1L;
		u0530_u0883Ի_u083E2.SetActive(active3 != 0L);
		GameObject ٷ_u0608ӯՉ2 = this.ٷ\u0608ӯՉ;
		long active4 = 1L;
		ٷ_u0608ӯՉ2.SetActive(active4 != 0L);
		bool flag3 = PlayerPrefs.GetString("hh:mmtt") == "FingerTip";
		TextMeshPro u05A3_u07B4_u0705_u3 = this.\u05A3\u07B4\u0705\u0871;
		GameObject u0530_u0883Ի_u083E3 = this.\u0530\u0883Ի\u083E;
		long active5 = 0L;
		u0530_u0883Ի_u083E3.SetActive(active5 != 0L);
		GameObject ٷ_u0608ӯՉ3 = this.ٷ\u0608ӯՉ;
		long active6 = 0L;
		ٷ_u0608ӯՉ3.SetActive(active6 != 0L);
	}

	// Token: 0x06000A4E RID: 2638 RVA: 0x00039284 File Offset: 0x00037484
	[Token(Token = "0x6000A4E")]
	[Address(RVA = "0x2947890", Offset = "0x2947890", VA = "0x2947890")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = this.ڰܢ\u07F6ل;
		GameObject u0530_u0883Ի_u083E = this.\u0530\u0883Ի\u083E;
		long active = 1L;
		u0530_u0883Ի_u083E.SetActive(active != 0L);
		GameObject ٷ_u0608ӯՉ = this.ٷ\u0608ӯՉ;
		long active2 = 0L;
		ٷ_u0608ӯՉ.SetActive(active2 != 0L);
		PlayerPrefs.SetString("NetworkPlayer", "_BumpScale");
		TextMeshPro u05A3_u07B4_u0705_u = this.\u05A3\u07B4\u0705\u0871;
	}

	// Token: 0x06000A4F RID: 2639 RVA: 0x00039368 File Offset: 0x00037568
	[Token(Token = "0x6000A4F")]
	[Address(RVA = "0x2947AF4", Offset = "0x2947AF4", VA = "0x2947AF4")]
	public void \u0739߉ڵݞ()
	{
		this.\u05F3\u06E3\u05C8վ();
	}

	// Token: 0x0400017F RID: 383
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400017F")]
	public ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ\u07F6ل;

	// Token: 0x04000180 RID: 384
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000180")]
	public GameObject \u0530\u0883Ի\u083E;

	// Token: 0x04000181 RID: 385
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000181")]
	public GameObject ٷ\u0608ӯՉ;

	// Token: 0x04000182 RID: 386
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000182")]
	public TextMeshPro \u05A3\u07B4\u0705\u0871;

	// Token: 0x0200004A RID: 74
	[Token(Token = "0x200004A")]
	public enum \u05C4٤\u061Eݿ
	{
		// Token: 0x04000184 RID: 388
		[Token(Token = "0x4000184")]
		ܒࢢࢱݙ,
		// Token: 0x04000185 RID: 389
		[Token(Token = "0x4000185")]
		\u065Aߙ\u06E4\u05B8,
		// Token: 0x04000186 RID: 390
		[Token(Token = "0x4000186")]
		Ջࢥ\u0835\u06E2
	}
}
