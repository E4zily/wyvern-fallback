﻿using System;
using System.Collections;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000078 RID: 120
[Token(Token = "0x2000078")]
public class MB_DynamicAddDeleteExample : MonoBehaviour
{
	// Token: 0x0600123F RID: 4671 RVA: 0x00069BB4 File Offset: 0x00067DB4
	[Token(Token = "0x600123F")]
	[Address(RVA = "0x24D2390", Offset = "0x24D2390", VA = "0x24D2390")]
	private float \u059F\u05CF\u0827Ә()
	{
	}

	// Token: 0x06001240 RID: 4672 RVA: 0x00069BC4 File Offset: 0x00067DC4
	[Token(Token = "0x6001240")]
	[Address(RVA = "0x24D2490", Offset = "0x24D2490", VA = "0x24D2490")]
	private float \u088B۹ۻ\u07BB()
	{
	}

	// Token: 0x06001241 RID: 4673 RVA: 0x00069BD4 File Offset: 0x00067DD4
	[Token(Token = "0x6001241")]
	[Address(RVA = "0x24D2590", Offset = "0x24D2590", VA = "0x24D2590")]
	private void ޡࠅ\u089Aߔ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[2209];
		MB3_MultiMeshBaker խ_u07F6ݎ_u082A = this.խ\u07F6ݎ\u082A;
		List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
		this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ;
		IEnumerator routine = this.߁ݻ٧ߓ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001242 RID: 4674 RVA: 0x00069C28 File Offset: 0x00067E28
	[Token(Token = "0x6001242")]
	[Address(RVA = "0x24D2834", Offset = "0x24D2834", VA = "0x24D2834")]
	private IEnumerator ԥݽ\u05B5ࢴ()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 0L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001243 RID: 4675 RVA: 0x00069C4C File Offset: 0x00067E4C
	[Token(Token = "0x6001243")]
	[Address(RVA = "0x24D28AC", Offset = "0x24D28AC", VA = "0x24D28AC")]
	private void \u05C4עڻ\u0732()
	{
	}

	// Token: 0x06001244 RID: 4676 RVA: 0x00069C5C File Offset: 0x00067E5C
	[Token(Token = "0x6001244")]
	[Address(RVA = "0x24D26D4", Offset = "0x24D26D4", VA = "0x24D26D4")]
	private float \u05A5\u065Fݼ\u07ED()
	{
	}

	// Token: 0x06001245 RID: 4677 RVA: 0x00069C6C File Offset: 0x00067E6C
	[Token(Token = "0x6001245")]
	[Address(RVA = "0x24D298C", Offset = "0x24D298C", VA = "0x24D298C")]
	public MB_DynamicAddDeleteExample()
	{
		List<GameObject> u0739_u083Dࡉߩ = new List();
		this.\u0739\u083Dࡉߩ = u0739_u083Dࡉߩ;
		base..ctor();
	}

	// Token: 0x06001246 RID: 4678 RVA: 0x00069C8C File Offset: 0x00067E8C
	[Token(Token = "0x6001246")]
	[Address(RVA = "0x24D2A10", Offset = "0x24D2A10", VA = "0x24D2A10")]
	private void ԞԌ\u086FՇ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[324];
		MB3_MultiMeshBaker խ_u07F6ݎ_u082A = this.խ\u07F6ݎ\u082A;
		List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
		this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ;
		IEnumerator routine = this.ӌߒࡆࠈ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001247 RID: 4679 RVA: 0x00069CE0 File Offset: 0x00067EE0
	[Token(Token = "0x6001247")]
	[Address(RVA = "0x24D2CCC", Offset = "0x24D2CCC", VA = "0x24D2CCC")]
	private void Ԩ\u058Eۉ\u0607()
	{
	}

	// Token: 0x06001248 RID: 4680 RVA: 0x00069CF0 File Offset: 0x00067EF0
	[Token(Token = "0x6001248")]
	[Address(RVA = "0x24D2DAC", Offset = "0x24D2DAC", VA = "0x24D2DAC")]
	private void ࢰחڵࡓ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[841];
		GameObject ټߎ_u0589ߛ = this.ټߎ\u0589ߛ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject == null || gameObject != null)
		{
			Transform transform = gameObject2.transform;
			long maxExclusive = 7L;
			int num = UnityEngine.Random.Range(0, (int)maxExclusive);
			Transform transform2 = gameObject2.transform;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			Transform transform3 = gameObject2.transform;
			List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
			List<GameObject> u0739_u083Dࡉߩ2 = this.\u0739\u083Dࡉߩ;
			this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ2;
			IEnumerator routine = this.ԥݽ\u05B5ࢴ();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001249 RID: 4681 RVA: 0x00069DB8 File Offset: 0x00067FB8
	[Token(Token = "0x6001249")]
	[Address(RVA = "0x24D31F0", Offset = "0x24D31F0", VA = "0x24D31F0")]
	private void \u0880ݚވԿ()
	{
	}

	// Token: 0x0600124A RID: 4682 RVA: 0x00069DC8 File Offset: 0x00067FC8
	[Token(Token = "0x600124A")]
	[Address(RVA = "0x24D32D0", Offset = "0x24D32D0", VA = "0x24D32D0")]
	private IEnumerator \u0836յݮա()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 1L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600124B RID: 4683 RVA: 0x00069DEC File Offset: 0x00067FEC
	[Token(Token = "0x600124B")]
	[Address(RVA = "0x24D3348", Offset = "0x24D3348", VA = "0x24D3348")]
	private float אݳ\u06DB\u0739()
	{
	}

	// Token: 0x0600124C RID: 4684 RVA: 0x00069DFC File Offset: 0x00067FFC
	[Token(Token = "0x600124C")]
	[Address(RVA = "0x24D3448", Offset = "0x24D3448", VA = "0x24D3448")]
	private void \u0558ݕݤݮ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[15129];
		MB3_MultiMeshBaker խ_u07F6ݎ_u082A = this.խ\u07F6ݎ\u082A;
		List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
		this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ;
		IEnumerator routine = this.\u059Bޥצߔ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600124D RID: 4685 RVA: 0x00069E50 File Offset: 0x00068050
	[Token(Token = "0x600124D")]
	[Address(RVA = "0x24D3704", Offset = "0x24D3704", VA = "0x24D3704")]
	private void ࡉࡡܡߕ()
	{
	}

	// Token: 0x0600124E RID: 4686 RVA: 0x00069E60 File Offset: 0x00068060
	[Token(Token = "0x600124E")]
	[Address(RVA = "0x24D37E4", Offset = "0x24D37E4", VA = "0x24D37E4")]
	private IEnumerator \u06D4ݜي\u0599()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 0L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600124F RID: 4687 RVA: 0x00069E84 File Offset: 0x00068084
	[Token(Token = "0x600124F")]
	[Address(RVA = "0x24D385C", Offset = "0x24D385C", VA = "0x24D385C")]
	private void ߅\u070Fޑ\u0876()
	{
	}

	// Token: 0x06001250 RID: 4688 RVA: 0x00069E94 File Offset: 0x00068094
	[Token(Token = "0x6001250")]
	[Address(RVA = "0x24D393C", Offset = "0x24D393C", VA = "0x24D393C")]
	private void הԥ\u05B5ݴ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[64];
		GameObject ټߎ_u0589ߛ = this.ټߎ\u0589ߛ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject == null || gameObject != null)
		{
			Transform transform = gameObject2.transform;
			long minInclusive = 1L;
			int maxExclusive = 175;
			int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
			Transform transform2 = gameObject2.transform;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			Transform transform3 = gameObject2.transform;
			List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
			List<GameObject> u0739_u083Dࡉߩ2 = this.\u0739\u083Dࡉߩ;
			this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ2;
			IEnumerator routine = this.ԥݽ\u05B5ࢴ();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001251 RID: 4689 RVA: 0x00069F6C File Offset: 0x0006816C
	[Token(Token = "0x6001251")]
	[Address(RVA = "0x24D3EA0", Offset = "0x24D3EA0", VA = "0x24D3EA0")]
	private void ޤչ߉\u0702()
	{
	}

	// Token: 0x06001252 RID: 4690 RVA: 0x00069F7C File Offset: 0x0006817C
	[Token(Token = "0x6001252")]
	[Address(RVA = "0x24D3F80", Offset = "0x24D3F80", VA = "0x24D3F80")]
	private void ݸԲ\u0616Ԫ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[8649];
		GameObject ټߎ_u0589ߛ = this.ټߎ\u0589ߛ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject == null || gameObject != null)
		{
			Transform transform = gameObject2.transform;
			long minInclusive = 1L;
			int maxExclusive = 78;
			int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
			Transform transform2 = gameObject2.transform;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			Transform transform3 = gameObject2.transform;
			List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
			List<GameObject> u0739_u083Dࡉߩ2 = this.\u0739\u083Dࡉߩ;
			this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ2;
			IEnumerator routine = this.ԥݽ\u05B5ࢴ();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001253 RID: 4691 RVA: 0x0006A048 File Offset: 0x00068248
	[Token(Token = "0x6001253")]
	[Address(RVA = "0x24D43C4", Offset = "0x24D43C4", VA = "0x24D43C4")]
	private void \u055E\u064E\u073Dࢷ()
	{
	}

	// Token: 0x06001254 RID: 4692 RVA: 0x0006A058 File Offset: 0x00068258
	[Token(Token = "0x6001254")]
	[Address(RVA = "0x24D44A4", Offset = "0x24D44A4", VA = "0x24D44A4")]
	private void ࡩݮڢՠ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[625];
		GameObject ټߎ_u0589ߛ = this.ټߎ\u0589ߛ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject == null || gameObject != null)
		{
			Transform transform = gameObject2.transform;
			long maxExclusive = 0L;
			int num = UnityEngine.Random.Range(0, (int)maxExclusive);
			Transform transform2 = gameObject2.transform;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			Transform transform3 = gameObject2.transform;
			List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001255 RID: 4693 RVA: 0x0006A10C File Offset: 0x0006830C
	[Token(Token = "0x6001255")]
	[Address(RVA = "0x24D27BC", Offset = "0x24D27BC", VA = "0x24D27BC")]
	private IEnumerator ߁ݻ٧ߓ()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 0L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001256 RID: 4694 RVA: 0x0006A130 File Offset: 0x00068330
	[Token(Token = "0x6001256")]
	[Address(RVA = "0x24D488C", Offset = "0x24D488C", VA = "0x24D488C")]
	private void ޠۋ\u0530\u073E()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[10609];
		MB3_MultiMeshBaker խ_u07F6ݎ_u082A = this.խ\u07F6ݎ\u082A;
		List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
		this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ;
		IEnumerator routine = this.ԥݽ\u05B5ࢴ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001257 RID: 4695 RVA: 0x0006A184 File Offset: 0x00068384
	[Token(Token = "0x6001257")]
	[Address(RVA = "0x24D49D0", Offset = "0x24D49D0", VA = "0x24D49D0")]
	private float ي\u0878ڤݝ()
	{
	}

	// Token: 0x06001258 RID: 4696 RVA: 0x0006A194 File Offset: 0x00068394
	[Token(Token = "0x6001258")]
	[Address(RVA = "0x24D4AD0", Offset = "0x24D4AD0", VA = "0x24D4AD0")]
	private float ࢱ\u0833\u059Cݍ()
	{
	}

	// Token: 0x06001259 RID: 4697 RVA: 0x0006A1A4 File Offset: 0x000683A4
	[Token(Token = "0x6001259")]
	[Address(RVA = "0x24D4BD0", Offset = "0x24D4BD0", VA = "0x24D4BD0")]
	private void \u066D\u05BDې߃()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[11236];
	}

	// Token: 0x0600125A RID: 4698 RVA: 0x0006A240 File Offset: 0x00068440
	[Token(Token = "0x600125A")]
	[Address(RVA = "0x24D5070", Offset = "0x24D5070", VA = "0x24D5070")]
	private void Start()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[100];
		GameObject ټߎ_u0589ߛ = this.ټߎ\u0589ߛ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject == null || gameObject != null)
		{
			Transform transform = gameObject2.transform;
			int maxExclusive = 360;
			int num = UnityEngine.Random.Range(0, maxExclusive);
			Transform transform2 = gameObject2.transform;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			Transform transform3 = gameObject2.transform;
			List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
			List<GameObject> u0739_u083Dࡉߩ2 = this.\u0739\u083Dࡉߩ;
			this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ2;
			IEnumerator routine = this.ࡢݯ\u0836ܙ();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600125B RID: 4699 RVA: 0x0006A314 File Offset: 0x00068514
	[Token(Token = "0x600125B")]
	[Address(RVA = "0x24D4EF8", Offset = "0x24D4EF8", VA = "0x24D4EF8")]
	private float ֈݜ\u058Aԩ()
	{
	}

	// Token: 0x0600125C RID: 4700 RVA: 0x0006A324 File Offset: 0x00068524
	[Token(Token = "0x600125C")]
	[Address(RVA = "0x24D5590", Offset = "0x24D5590", VA = "0x24D5590")]
	private void \u06D6ې\u083Bࠉ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[1];
		GameObject ټߎ_u0589ߛ = this.ټߎ\u0589ߛ;
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject == null || gameObject != null)
		{
			Transform transform = gameObject2.transform;
			long minInclusive = 1L;
			int maxExclusive = 141;
			int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
			Transform transform2 = gameObject2.transform;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			Transform transform3 = gameObject2.transform;
			List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
			List<GameObject> u0739_u083Dࡉߩ2 = this.\u0739\u083Dࡉߩ;
			this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ2;
			IEnumerator routine = this.\u059Bޥצߔ();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600125D RID: 4701 RVA: 0x0006A3EC File Offset: 0x000685EC
	[Token(Token = "0x600125D")]
	[Address(RVA = "0x24D5904", Offset = "0x24D5904", VA = "0x24D5904")]
	private void \u058EԸس\u0819()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[6084];
		MB3_MultiMeshBaker խ_u07F6ݎ_u082A = this.խ\u07F6ݎ\u082A;
		List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
		this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ;
		IEnumerator routine = this.\u059Bޥצߔ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600125E RID: 4702 RVA: 0x0006A440 File Offset: 0x00068640
	[Token(Token = "0x600125E")]
	[Address(RVA = "0x24D5518", Offset = "0x24D5518", VA = "0x24D5518")]
	private IEnumerator ࡢݯ\u0836ܙ()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 0L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600125F RID: 4703 RVA: 0x0006A464 File Offset: 0x00068664
	[Token(Token = "0x600125F")]
	[Address(RVA = "0x24D5A48", Offset = "0x24D5A48", VA = "0x24D5A48")]
	private void Ԁוև\u065B()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[11881];
		MB3_MultiMeshBaker խ_u07F6ݎ_u082A = this.խ\u07F6ݎ\u082A;
		List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
		this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ;
		IEnumerator routine = this.\u0837ږԡ\u0890();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001260 RID: 4704 RVA: 0x0006A4B8 File Offset: 0x000686B8
	[Token(Token = "0x6001260")]
	[Address(RVA = "0x24D5480", Offset = "0x24D5480", VA = "0x24D5480")]
	private float ࡆࠁ\u085Fࡡ()
	{
	}

	// Token: 0x06001261 RID: 4705 RVA: 0x0006A4C8 File Offset: 0x000686C8
	[Token(Token = "0x6001261")]
	[Address(RVA = "0x24D358C", Offset = "0x24D358C", VA = "0x24D358C")]
	private float \u0832ذԱӖ()
	{
	}

	// Token: 0x06001262 RID: 4706 RVA: 0x0006A4D8 File Offset: 0x000686D8
	[Token(Token = "0x6001262")]
	[Address(RVA = "0x24D5B8C", Offset = "0x24D5B8C", VA = "0x24D5B8C")]
	private IEnumerator ԟ\u07F5\u05EDӵ()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 0L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001263 RID: 4707 RVA: 0x0006A4FC File Offset: 0x000686FC
	[Token(Token = "0x6001263")]
	[Address(RVA = "0x24D5C04", Offset = "0x24D5C04", VA = "0x24D5C04")]
	private void \u0656ӺմՁ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[13924];
		GameObject ټߎ_u0589ߛ = this.ټߎ\u0589ߛ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject == null || gameObject != null)
		{
			Transform transform = gameObject2.transform;
			long maxExclusive = 0L;
			int num = UnityEngine.Random.Range(1, (int)maxExclusive);
			Transform transform2 = gameObject2.transform;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			Transform transform3 = gameObject2.transform;
			List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001264 RID: 4708 RVA: 0x0006A5B0 File Offset: 0x000687B0
	[Token(Token = "0x6001264")]
	[Address(RVA = "0x24D368C", Offset = "0x24D368C", VA = "0x24D368C")]
	private IEnumerator \u059Bޥצߔ()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 1L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001265 RID: 4709 RVA: 0x0006A5D4 File Offset: 0x000687D4
	[Token(Token = "0x6001265")]
	[Address(RVA = "0x24D5F74", Offset = "0x24D5F74", VA = "0x24D5F74")]
	private void ١ۏ\u05C4ӝ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[4356];
		MB3_MultiMeshBaker խ_u07F6ݎ_u082A = this.խ\u07F6ݎ\u082A;
		List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
		this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ;
		IEnumerator routine = this.ԟ\u07F5\u05EDӵ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001266 RID: 4710 RVA: 0x0006A628 File Offset: 0x00068828
	[Token(Token = "0x6001266")]
	[Address(RVA = "0x24D60B8", Offset = "0x24D60B8", VA = "0x24D60B8")]
	private IEnumerator ࢬ\u081Fէ\u058E()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 1L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001267 RID: 4711 RVA: 0x0006A64C File Offset: 0x0006884C
	[Token(Token = "0x6001267")]
	[Address(RVA = "0x24D6130", Offset = "0x24D6130", VA = "0x24D6130")]
	private void Ӄۇރࡑ()
	{
	}

	// Token: 0x06001268 RID: 4712 RVA: 0x0006A65C File Offset: 0x0006885C
	[Token(Token = "0x6001268")]
	[Address(RVA = "0x24D6210", Offset = "0x24D6210", VA = "0x24D6210")]
	private void ҿ\u07BBҽ\u0599()
	{
	}

	// Token: 0x06001269 RID: 4713 RVA: 0x0006A66C File Offset: 0x0006886C
	[Token(Token = "0x6001269")]
	[Address(RVA = "0x24D62F0", Offset = "0x24D62F0", VA = "0x24D62F0")]
	private void ہډࠉӥ()
	{
	}

	// Token: 0x0600126A RID: 4714 RVA: 0x0006A67C File Offset: 0x0006887C
	[Token(Token = "0x600126A")]
	[Address(RVA = "0x24D63D0", Offset = "0x24D63D0", VA = "0x24D63D0")]
	private void ۆڛߟ\u05A0()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[25];
		MB3_MultiMeshBaker խ_u07F6ݎ_u082A = this.խ\u07F6ݎ\u082A;
		List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
		this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ;
		IEnumerator routine = this.\u06D4ݜي\u0599();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600126B RID: 4715 RVA: 0x0006A6CC File Offset: 0x000688CC
	[Token(Token = "0x600126B")]
	[Address(RVA = "0x24D6514", Offset = "0x24D6514", VA = "0x24D6514")]
	private void \u06EDٵ۶\u06DB()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[15376];
		MB3_MultiMeshBaker խ_u07F6ݎ_u082A = this.խ\u07F6ݎ\u082A;
		List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
		this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ;
		IEnumerator routine = this.ӌߒࡆࠈ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600126C RID: 4716 RVA: 0x0006A720 File Offset: 0x00068920
	[Token(Token = "0x600126C")]
	[Address(RVA = "0x24D6658", Offset = "0x24D6658", VA = "0x24D6658")]
	private void OnGUI()
	{
	}

	// Token: 0x0600126D RID: 4717 RVA: 0x0006A730 File Offset: 0x00068930
	[Token(Token = "0x600126D")]
	[Address(RVA = "0x24D6738", Offset = "0x24D6738", VA = "0x24D6738")]
	private float \u0704\u0608ք\u058D()
	{
	}

	// Token: 0x0600126E RID: 4718 RVA: 0x0006A740 File Offset: 0x00068940
	[Token(Token = "0x600126E")]
	[Address(RVA = "0x24D6838", Offset = "0x24D6838", VA = "0x24D6838")]
	private void \u07EB\u0597ࢳڪ()
	{
	}

	// Token: 0x0600126F RID: 4719 RVA: 0x0006A750 File Offset: 0x00068950
	[Token(Token = "0x600126F")]
	[Address(RVA = "0x24D6918", Offset = "0x24D6918", VA = "0x24D6918")]
	private void וࡪךӧ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[11664];
	}

	// Token: 0x06001270 RID: 4720 RVA: 0x0006A7EC File Offset: 0x000689EC
	[Token(Token = "0x6001270")]
	[Address(RVA = "0x24D6C20", Offset = "0x24D6C20", VA = "0x24D6C20")]
	private void ܡӯ\u06E8\u07B0()
	{
	}

	// Token: 0x06001271 RID: 4721 RVA: 0x0006A7FC File Offset: 0x000689FC
	[Token(Token = "0x6001271")]
	[Address(RVA = "0x24D4814", Offset = "0x24D4814", VA = "0x24D4814")]
	private IEnumerator \u0837ږԡ\u0890()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 1L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001272 RID: 4722 RVA: 0x0006A820 File Offset: 0x00068A20
	[Token(Token = "0x6001272")]
	[Address(RVA = "0x24D2B54", Offset = "0x24D2B54", VA = "0x24D2B54")]
	private float Ҿܟࡗ\u0654()
	{
	}

	// Token: 0x06001273 RID: 4723 RVA: 0x0006A830 File Offset: 0x00068A30
	[Token(Token = "0x6001273")]
	[Address(RVA = "0x24D6D00", Offset = "0x24D6D00", VA = "0x24D6D00")]
	private void \u064Bࢮ\u0589\u05FF()
	{
	}

	// Token: 0x06001274 RID: 4724 RVA: 0x0006A840 File Offset: 0x00068A40
	[Token(Token = "0x6001274")]
	[Address(RVA = "0x24D3DB0", Offset = "0x24D3DB0", VA = "0x24D3DB0")]
	private float \u06E1ޔݡࡓ()
	{
	}

	// Token: 0x06001275 RID: 4725 RVA: 0x0006A850 File Offset: 0x00068A50
	[Token(Token = "0x6001275")]
	[Address(RVA = "0x24D4FF8", Offset = "0x24D4FF8", VA = "0x24D4FF8")]
	private IEnumerator \u05B1ՑӒࠑ()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 0L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001276 RID: 4726 RVA: 0x0006A874 File Offset: 0x00068A74
	[Token(Token = "0x6001276")]
	[Address(RVA = "0x24D2C54", Offset = "0x24D2C54", VA = "0x24D2C54")]
	private IEnumerator ӌߒࡆࠈ()
	{
		long <>1__state;
		MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁ u05BB_u081C_u0881߁ = new MB_DynamicAddDeleteExample.\u05BB\u081C\u0881߁((int)<>1__state);
		<>1__state = 0L;
		u05BB_u081C_u0881߁.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001277 RID: 4727 RVA: 0x0006A898 File Offset: 0x00068A98
	[Token(Token = "0x6001277")]
	[Address(RVA = "0x24D6DE0", Offset = "0x24D6DE0", VA = "0x24D6DE0")]
	private void ڄ\u0734ԛ\u05C8()
	{
	}

	// Token: 0x06001278 RID: 4728 RVA: 0x0006A8A8 File Offset: 0x00068AA8
	[Token(Token = "0x6001278")]
	[Address(RVA = "0x24D6EC0", Offset = "0x24D6EC0", VA = "0x24D6EC0")]
	private void ڣֆ\u07F4ڌ()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.խ\u07F6ݎ\u082A = componentInChildren;
		GameObject[] array = new GameObject[4900];
		MB3_MultiMeshBaker խ_u07F6ݎ_u082A = this.խ\u07F6ݎ\u082A;
		List<GameObject> u0739_u083Dࡉߩ = this.\u0739\u083Dࡉߩ;
		this.ܭ\u0738\u058Dࢮ = u0739_u083Dࡉߩ;
		IEnumerator routine = this.ӌߒࡆࠈ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001279 RID: 4729 RVA: 0x0006A8FC File Offset: 0x00068AFC
	[Token(Token = "0x6001279")]
	[Address(RVA = "0x24D7004", Offset = "0x24D7004", VA = "0x24D7004")]
	private void \u07F7ե\u081Fܗ()
	{
	}

	// Token: 0x04000253 RID: 595
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000253")]
	public GameObject ټߎ\u0589ߛ;

	// Token: 0x04000254 RID: 596
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000254")]
	private List<GameObject> \u0739\u083Dࡉߩ;

	// Token: 0x04000255 RID: 597
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000255")]
	private MB3_MultiMeshBaker խ\u07F6ݎ\u082A;

	// Token: 0x04000256 RID: 598
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000256")]
	private GameObject[] ܭ\u0738\u058Dࢮ;
}
