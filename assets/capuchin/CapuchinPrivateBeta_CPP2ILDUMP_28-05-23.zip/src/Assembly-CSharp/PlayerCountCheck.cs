﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200008F RID: 143
[Token(Token = "0x200008F")]
public class PlayerCountCheck : MonoBehaviour
{
	// Token: 0x060015A1 RID: 5537 RVA: 0x00079714 File Offset: 0x00077914
	[Token(Token = "0x60015A1")]
	[Address(RVA = "0x29A0470", Offset = "0x29A0470", VA = "0x29A0470")]
	private void \u087BӦןݩ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
	}

	// Token: 0x060015A2 RID: 5538 RVA: 0x00079764 File Offset: 0x00077964
	[Token(Token = "0x60015A2")]
	[Address(RVA = "0x29A0534", Offset = "0x29A0534", VA = "0x29A0534")]
	private void \u070Aәޣے()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015A3 RID: 5539 RVA: 0x000797AC File Offset: 0x000779AC
	[Token(Token = "0x60015A3")]
	[Address(RVA = "0x29A05E4", Offset = "0x29A05E4", VA = "0x29A05E4")]
	private void ٴݵۃ\u05AF()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
	}

	// Token: 0x060015A4 RID: 5540 RVA: 0x000797F4 File Offset: 0x000779F4
	[Token(Token = "0x60015A4")]
	[Address(RVA = "0x29A06A8", Offset = "0x29A06A8", VA = "0x29A06A8")]
	private void \u0614ࢥӴ\u086C()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015A5 RID: 5541 RVA: 0x0007983C File Offset: 0x00077A3C
	[Token(Token = "0x60015A5")]
	[Address(RVA = "0x29A0758", Offset = "0x29A0758", VA = "0x29A0758")]
	private void Ҽ\u08B5ځ\u0658()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015A6 RID: 5542 RVA: 0x00079888 File Offset: 0x00077A88
	[Token(Token = "0x60015A6")]
	[Address(RVA = "0x29A0818", Offset = "0x29A0818", VA = "0x29A0818")]
	private void \u0838ӆڛӑ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 1L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015A7 RID: 5543 RVA: 0x000798DC File Offset: 0x00077ADC
	[Token(Token = "0x60015A7")]
	[Address(RVA = "0x29A08D8", Offset = "0x29A08D8", VA = "0x29A08D8")]
	private void ڑߒجވ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015A8 RID: 5544 RVA: 0x00079924 File Offset: 0x00077B24
	[Token(Token = "0x60015A8")]
	[Address(RVA = "0x29A0988", Offset = "0x29A0988", VA = "0x29A0988")]
	private void ڃրӢԖ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015A9 RID: 5545 RVA: 0x00079974 File Offset: 0x00077B74
	[Token(Token = "0x60015A9")]
	[Address(RVA = "0x29A0A48", Offset = "0x29A0A48", VA = "0x29A0A48")]
	private void ԟ\u086Cޣ\u055E()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 1L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015AA RID: 5546 RVA: 0x000799BC File Offset: 0x00077BBC
	[Token(Token = "0x60015AA")]
	[Address(RVA = "0x29A0AF8", Offset = "0x29A0AF8", VA = "0x29A0AF8")]
	private void ժ\u065Dԯࡘ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015AB RID: 5547 RVA: 0x00079A04 File Offset: 0x00077C04
	[Token(Token = "0x60015AB")]
	[Address(RVA = "0x29A0BA8", Offset = "0x29A0BA8", VA = "0x29A0BA8")]
	private void \u0654ޛ\u07FAذ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
	}

	// Token: 0x060015AC RID: 5548 RVA: 0x00079A54 File Offset: 0x00077C54
	[Token(Token = "0x60015AC")]
	[Address(RVA = "0x29A0C6C", Offset = "0x29A0C6C", VA = "0x29A0C6C")]
	private void ԣԭՋࠏ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 1L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015AD RID: 5549 RVA: 0x00079A9C File Offset: 0x00077C9C
	[Token(Token = "0x60015AD")]
	[Address(RVA = "0x29A0D1C", Offset = "0x29A0D1C", VA = "0x29A0D1C")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015AE RID: 5550 RVA: 0x00079AE4 File Offset: 0x00077CE4
	[Token(Token = "0x60015AE")]
	[Address(RVA = "0x29A0DCC", Offset = "0x29A0DCC", VA = "0x29A0DCC")]
	private void \u0886Ҽ\u058Dߛ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
	}

	// Token: 0x060015AF RID: 5551 RVA: 0x00079B34 File Offset: 0x00077D34
	[Token(Token = "0x60015AF")]
	[Address(RVA = "0x29A0E90", Offset = "0x29A0E90", VA = "0x29A0E90")]
	private void ފՖߢ\u059B()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 1L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015B0 RID: 5552 RVA: 0x00079B7C File Offset: 0x00077D7C
	[Token(Token = "0x60015B0")]
	[Address(RVA = "0x29A0F40", Offset = "0x29A0F40", VA = "0x29A0F40")]
	private void Update()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
	}

	// Token: 0x060015B1 RID: 5553 RVA: 0x00079BCC File Offset: 0x00077DCC
	[Token(Token = "0x60015B1")]
	[Address(RVA = "0x29A1004", Offset = "0x29A1004", VA = "0x29A1004")]
	private void ӻӒݝ߃()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015B2 RID: 5554 RVA: 0x00079C20 File Offset: 0x00077E20
	[Token(Token = "0x60015B2")]
	[Address(RVA = "0x29A10C4", Offset = "0x29A10C4", VA = "0x29A10C4")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		bool inRoom = PhotonNetwork.InRoom;
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015B3 RID: 5555 RVA: 0x00079C5C File Offset: 0x00077E5C
	[Token(Token = "0x60015B3")]
	[Address(RVA = "0x29A1174", Offset = "0x29A1174", VA = "0x29A1174")]
	private void Ҿࢹؼס()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 1L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015B4 RID: 5556 RVA: 0x00079CB0 File Offset: 0x00077EB0
	[Token(Token = "0x60015B4")]
	[Address(RVA = "0x29A1234", Offset = "0x29A1234", VA = "0x29A1234")]
	private void څࡣڐ\u0657()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
	}

	// Token: 0x060015B5 RID: 5557 RVA: 0x00079D00 File Offset: 0x00077F00
	[Token(Token = "0x60015B5")]
	[Address(RVA = "0x29A12F8", Offset = "0x29A12F8", VA = "0x29A12F8")]
	private void \u061B\u05EEوۈ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015B6 RID: 5558 RVA: 0x00079D48 File Offset: 0x00077F48
	[Token(Token = "0x60015B6")]
	[Address(RVA = "0x29A13A8", Offset = "0x29A13A8", VA = "0x29A13A8")]
	private void ࢫ\u0876չՍ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
	}

	// Token: 0x060015B7 RID: 5559 RVA: 0x00079D98 File Offset: 0x00077F98
	[Token(Token = "0x60015B7")]
	[Address(RVA = "0x29A146C", Offset = "0x29A146C", VA = "0x29A146C")]
	private void ں٢ࡡ\u05EC()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
	}

	// Token: 0x060015B8 RID: 5560 RVA: 0x00079DE8 File Offset: 0x00077FE8
	[Token(Token = "0x60015B8")]
	[Address(RVA = "0x29A1530", Offset = "0x29A1530", VA = "0x29A1530")]
	private void \u0881ݗӟ\u07BD()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
	}

	// Token: 0x060015B9 RID: 5561 RVA: 0x00079E38 File Offset: 0x00078038
	[Token(Token = "0x60015B9")]
	[Address(RVA = "0x29A15F4", Offset = "0x29A15F4", VA = "0x29A15F4")]
	private void \u05F7ԝߠӱ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015BA RID: 5562 RVA: 0x00079E80 File Offset: 0x00078080
	[Token(Token = "0x60015BA")]
	[Address(RVA = "0x29A16A4", Offset = "0x29A16A4", VA = "0x29A16A4")]
	private void \u0732ڙԒࢺ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 1L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015BB RID: 5563 RVA: 0x00079EC8 File Offset: 0x000780C8
	[Token(Token = "0x60015BB")]
	[Address(RVA = "0x29A174C", Offset = "0x29A174C", VA = "0x29A174C")]
	private void ւࡂ\u0883\u0872()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015BC RID: 5564 RVA: 0x00079F10 File Offset: 0x00078110
	[Token(Token = "0x60015BC")]
	[Address(RVA = "0x29A17FC", Offset = "0x29A17FC", VA = "0x29A17FC")]
	public PlayerCountCheck()
	{
	}

	// Token: 0x060015BD RID: 5565 RVA: 0x00079F24 File Offset: 0x00078124
	[Token(Token = "0x60015BD")]
	[Address(RVA = "0x29A1804", Offset = "0x29A1804", VA = "0x29A1804")]
	private void Ӣ\u0592ߨׯ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 0L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015BE RID: 5566 RVA: 0x00079F78 File Offset: 0x00078178
	[Token(Token = "0x60015BE")]
	[Address(RVA = "0x29A18C4", Offset = "0x29A18C4", VA = "0x29A18C4")]
	private void \u05EDց\u081Cت()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 1L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x060015BF RID: 5567 RVA: 0x00079FC0 File Offset: 0x000781C0
	[Token(Token = "0x60015BF")]
	[Address(RVA = "0x29A1974", Offset = "0x29A1974", VA = "0x29A1974")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject u086E_u0818Ӿߒ = this.\u086E\u0818Ӿߒ;
		long active = 1L;
		u086E_u0818Ӿߒ.SetActive(active != 0L);
	}

	// Token: 0x040002B8 RID: 696
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002B8")]
	public GameObject \u086E\u0818Ӿߒ;
}
