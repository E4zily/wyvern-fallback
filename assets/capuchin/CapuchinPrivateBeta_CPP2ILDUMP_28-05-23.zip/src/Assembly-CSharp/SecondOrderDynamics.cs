﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000DA RID: 218
[Token(Token = "0x20000DA")]
public class SecondOrderDynamics : MonoBehaviour
{
	// Token: 0x06002152 RID: 8530 RVA: 0x000B19F4 File Offset: 0x000AFBF4
	[Token(Token = "0x6002152")]
	[Address(RVA = "0x2B6A064", Offset = "0x2B6A064", VA = "0x2B6A064")]
	public void ٴݵۃ\u05AF()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002153 RID: 8531 RVA: 0x000B1AEC File Offset: 0x000AFCEC
	[Token(Token = "0x6002153")]
	[Address(RVA = "0x2B6A1A0", Offset = "0x2B6A1A0", VA = "0x2B6A1A0")]
	public void \u0614ࢥӴ\u086C()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002154 RID: 8532 RVA: 0x000B1BE4 File Offset: 0x000AFDE4
	[Token(Token = "0x6002154")]
	[Address(RVA = "0x2B6A2DC", Offset = "0x2B6A2DC", VA = "0x2B6A2DC")]
	public void ߊ\u066A\u05CFԉ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002155 RID: 8533 RVA: 0x000B1CDC File Offset: 0x000AFEDC
	[Token(Token = "0x6002155")]
	[Address(RVA = "0x2B6A418", Offset = "0x2B6A418", VA = "0x2B6A418")]
	public void չւت\u061E()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002156 RID: 8534 RVA: 0x000B1DD4 File Offset: 0x000AFFD4
	[Token(Token = "0x6002156")]
	[Address(RVA = "0x2B6A554", Offset = "0x2B6A554", VA = "0x2B6A554")]
	private void \u07EBࠎיࡂ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002157 RID: 8535 RVA: 0x000B1DF4 File Offset: 0x000AFFF4
	[Token(Token = "0x6002157")]
	[Address(RVA = "0x2B6A58C", Offset = "0x2B6A58C", VA = "0x2B6A58C")]
	public void \u07F5\u0657\u055Aߍ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002158 RID: 8536 RVA: 0x000B1EEC File Offset: 0x000B00EC
	[Token(Token = "0x6002158")]
	[Address(RVA = "0x2B6A6C8", Offset = "0x2B6A6C8", VA = "0x2B6A6C8")]
	public void \u07FB\u07BC\u0887ӟ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002159 RID: 8537 RVA: 0x000B1FE4 File Offset: 0x000B01E4
	[Token(Token = "0x6002159")]
	[Address(RVA = "0x2B6A804", Offset = "0x2B6A804", VA = "0x2B6A804")]
	public void ی\u0823ڇݔ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600215A RID: 8538 RVA: 0x000B20DC File Offset: 0x000B02DC
	[Token(Token = "0x600215A")]
	[Address(RVA = "0x2B6A940", Offset = "0x2B6A940", VA = "0x2B6A940")]
	private void \u066Dӝߏآ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600215B RID: 8539 RVA: 0x000B20FC File Offset: 0x000B02FC
	[Token(Token = "0x600215B")]
	[Address(RVA = "0x2B6A978", Offset = "0x2B6A978", VA = "0x2B6A978")]
	private void ۿࢹ\u0705\u0825()
	{
	}

	// Token: 0x0600215C RID: 8540 RVA: 0x000B2110 File Offset: 0x000B0310
	[Token(Token = "0x600215C")]
	[Address(RVA = "0x2B6A9B0", Offset = "0x2B6A9B0", VA = "0x2B6A9B0")]
	private void ۊո\u0612\u0595()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600215D RID: 8541 RVA: 0x000B2130 File Offset: 0x000B0330
	[Token(Token = "0x600215D")]
	[Address(RVA = "0x2B6A9E8", Offset = "0x2B6A9E8", VA = "0x2B6A9E8")]
	private void \u0881\u0743\u07EB\u0747()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600215E RID: 8542 RVA: 0x000B2150 File Offset: 0x000B0350
	[Token(Token = "0x600215E")]
	[Address(RVA = "0x2B6AA20", Offset = "0x2B6AA20", VA = "0x2B6AA20")]
	private void \u05FEօ\u06D7ࡁ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600215F RID: 8543 RVA: 0x000B2170 File Offset: 0x000B0370
	[Token(Token = "0x600215F")]
	[Address(RVA = "0x2B6AA58", Offset = "0x2B6AA58", VA = "0x2B6AA58")]
	public void \u0599ږࠆ\u065F()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002160 RID: 8544 RVA: 0x000B2268 File Offset: 0x000B0468
	[Token(Token = "0x6002160")]
	[Address(RVA = "0x2B6AB94", Offset = "0x2B6AB94", VA = "0x2B6AB94")]
	private void ڣֆ\u07F4ڌ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002161 RID: 8545 RVA: 0x000B2288 File Offset: 0x000B0488
	[Token(Token = "0x6002161")]
	[Address(RVA = "0x2B6ABCC", Offset = "0x2B6ABCC", VA = "0x2B6ABCC")]
	public void \u0881ݗӟ\u07BD()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002162 RID: 8546 RVA: 0x000B2380 File Offset: 0x000B0580
	[Token(Token = "0x6002162")]
	[Address(RVA = "0x2B6AD08", Offset = "0x2B6AD08", VA = "0x2B6AD08")]
	public void ւࡂ\u0883\u0872()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002163 RID: 8547 RVA: 0x000B2478 File Offset: 0x000B0678
	[Token(Token = "0x6002163")]
	[Address(RVA = "0x2B6AE44", Offset = "0x2B6AE44", VA = "0x2B6AE44")]
	public void ފՖߢ\u059B()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002164 RID: 8548 RVA: 0x000B2564 File Offset: 0x000B0764
	[Token(Token = "0x6002164")]
	[Address(RVA = "0x2B6AF80", Offset = "0x2B6AF80", VA = "0x2B6AF80")]
	private void աؾێړ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002165 RID: 8549 RVA: 0x000B2584 File Offset: 0x000B0784
	[Token(Token = "0x6002165")]
	[Address(RVA = "0x2B6AFB8", Offset = "0x2B6AFB8", VA = "0x2B6AFB8")]
	private void Գӿېչ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002166 RID: 8550 RVA: 0x000B25A4 File Offset: 0x000B07A4
	[Token(Token = "0x6002166")]
	[Address(RVA = "0x2B6AFF0", Offset = "0x2B6AFF0", VA = "0x2B6AFF0")]
	private void ߗࠊ\u05CAܝ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002167 RID: 8551 RVA: 0x000B25C4 File Offset: 0x000B07C4
	[Token(Token = "0x6002167")]
	[Address(RVA = "0x2B6B028", Offset = "0x2B6B028", VA = "0x2B6B028")]
	private void ߖհݣ߀()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002168 RID: 8552 RVA: 0x000B25E4 File Offset: 0x000B07E4
	[Token(Token = "0x6002168")]
	[Address(RVA = "0x2B6B060", Offset = "0x2B6B060", VA = "0x2B6B060")]
	private void ۆڛߟ\u05A0()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002169 RID: 8553 RVA: 0x000B2604 File Offset: 0x000B0804
	[Token(Token = "0x6002169")]
	[Address(RVA = "0x2B6B098", Offset = "0x2B6B098", VA = "0x2B6B098")]
	private void \u066D\u05BDې߃()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600216A RID: 8554 RVA: 0x000B2624 File Offset: 0x000B0824
	[Token(Token = "0x600216A")]
	[Address(RVA = "0x2B6B0D0", Offset = "0x2B6B0D0", VA = "0x2B6B0D0")]
	public void \u05ABࡡ\u07ABݾ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600216B RID: 8555 RVA: 0x000B271C File Offset: 0x000B091C
	[Token(Token = "0x600216B")]
	[Address(RVA = "0x2B6B20C", Offset = "0x2B6B20C", VA = "0x2B6B20C")]
	public void \u05B3ࢹߧ\u07AA()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600216C RID: 8556 RVA: 0x000B2814 File Offset: 0x000B0A14
	[Token(Token = "0x600216C")]
	[Address(RVA = "0x2B6B348", Offset = "0x2B6B348", VA = "0x2B6B348")]
	public void Update()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600216D RID: 8557 RVA: 0x000B2904 File Offset: 0x000B0B04
	[Token(Token = "0x600216D")]
	[Address(RVA = "0x2B6B468", Offset = "0x2B6B468", VA = "0x2B6B468")]
	public void ࡊ\u0592\u07AB\u05B2()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600216E RID: 8558 RVA: 0x000B29FC File Offset: 0x000B0BFC
	[Token(Token = "0x600216E")]
	[Address(RVA = "0x2B6B5A4", Offset = "0x2B6B5A4", VA = "0x2B6B5A4")]
	public void ں٢ࡡ\u05EC()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600216F RID: 8559 RVA: 0x000B2AF4 File Offset: 0x000B0CF4
	[Token(Token = "0x600216F")]
	[Address(RVA = "0x2B6B6E0", Offset = "0x2B6B6E0", VA = "0x2B6B6E0")]
	private void Ԁוև\u065B()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002170 RID: 8560 RVA: 0x000B2B14 File Offset: 0x000B0D14
	[Token(Token = "0x6002170")]
	[Address(RVA = "0x2B6B718", Offset = "0x2B6B718", VA = "0x2B6B718")]
	public void \u070Aәޣے()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002171 RID: 8561 RVA: 0x000B2C0C File Offset: 0x000B0E0C
	[Token(Token = "0x6002171")]
	[Address(RVA = "0x2B6B854", Offset = "0x2B6B854", VA = "0x2B6B854")]
	public void Ԉ۴ࡉࢬ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002172 RID: 8562 RVA: 0x000B2CF8 File Offset: 0x000B0EF8
	[Token(Token = "0x6002172")]
	[Address(RVA = "0x2B6B990", Offset = "0x2B6B990", VA = "0x2B6B990")]
	private void \u070Fߨ\u05B0ۈ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002173 RID: 8563 RVA: 0x000B2D18 File Offset: 0x000B0F18
	[Token(Token = "0x6002173")]
	[Address(RVA = "0x2B6B9C8", Offset = "0x2B6B9C8", VA = "0x2B6B9C8")]
	public void ߑ\u0885\u05BBߕ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num = this.١դގݝ;
		float z2 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002174 RID: 8564 RVA: 0x000B2DFC File Offset: 0x000B0FFC
	[Token(Token = "0x6002174")]
	[Address(RVA = "0x2B6BB04", Offset = "0x2B6BB04", VA = "0x2B6BB04")]
	public void ڃրӢԖ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002175 RID: 8565 RVA: 0x000B2EF4 File Offset: 0x000B10F4
	[Token(Token = "0x6002175")]
	[Address(RVA = "0x2B6BC40", Offset = "0x2B6BC40", VA = "0x2B6BC40")]
	public void \u07BDއڸ\u0834()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002176 RID: 8566 RVA: 0x000B2FEC File Offset: 0x000B11EC
	[Token(Token = "0x6002176")]
	[Address(RVA = "0x2B6BD7C", Offset = "0x2B6BD7C", VA = "0x2B6BD7C")]
	public void ى߁ٱՏ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
	}

	// Token: 0x06002177 RID: 8567 RVA: 0x000B30D8 File Offset: 0x000B12D8
	[Token(Token = "0x6002177")]
	[Address(RVA = "0x2B6BEB8", Offset = "0x2B6BEB8", VA = "0x2B6BEB8")]
	private void گ\u085E\u073Dڊ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002178 RID: 8568 RVA: 0x000B30F8 File Offset: 0x000B12F8
	[Token(Token = "0x6002178")]
	[Address(RVA = "0x2B6BEF0", Offset = "0x2B6BEF0", VA = "0x2B6BEF0")]
	public void צ\u0874ڵ\u059A()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002179 RID: 8569 RVA: 0x000B31F0 File Offset: 0x000B13F0
	[Token(Token = "0x6002179")]
	[Address(RVA = "0x2B6C02C", Offset = "0x2B6C02C", VA = "0x2B6C02C")]
	private void ࢳ\u088E٠ݪ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600217A RID: 8570 RVA: 0x000B3210 File Offset: 0x000B1410
	[Token(Token = "0x600217A")]
	[Address(RVA = "0x2B6C064", Offset = "0x2B6C064", VA = "0x2B6C064")]
	private void \u0834\u0817ރࡔ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600217B RID: 8571 RVA: 0x000B3230 File Offset: 0x000B1430
	[Token(Token = "0x600217B")]
	[Address(RVA = "0x2B6C09C", Offset = "0x2B6C09C", VA = "0x2B6C09C")]
	private void ӭࡖݲ\u05BD()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600217C RID: 8572 RVA: 0x000B3250 File Offset: 0x000B1450
	[Token(Token = "0x600217C")]
	[Address(RVA = "0x2B6C0D4", Offset = "0x2B6C0D4", VA = "0x2B6C0D4")]
	private void چ\u05AEךڰ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600217D RID: 8573 RVA: 0x000B3270 File Offset: 0x000B1470
	[Token(Token = "0x600217D")]
	[Address(RVA = "0x2B6C10C", Offset = "0x2B6C10C", VA = "0x2B6C10C")]
	private void \u058EԸس\u0819()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600217E RID: 8574 RVA: 0x000B3290 File Offset: 0x000B1490
	[Token(Token = "0x600217E")]
	[Address(RVA = "0x2B6C144", Offset = "0x2B6C144", VA = "0x2B6C144")]
	private void ࢥ\u081CՕࡋ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600217F RID: 8575 RVA: 0x000B32B0 File Offset: 0x000B14B0
	[Token(Token = "0x600217F")]
	[Address(RVA = "0x2B6C17C", Offset = "0x2B6C17C", VA = "0x2B6C17C")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002180 RID: 8576 RVA: 0x000B33A8 File Offset: 0x000B15A8
	[Token(Token = "0x6002180")]
	[Address(RVA = "0x2B6C2B4", Offset = "0x2B6C2B4", VA = "0x2B6C2B4")]
	public void \u055Cࢯܯ\u0898()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002181 RID: 8577 RVA: 0x000B34A0 File Offset: 0x000B16A0
	[Token(Token = "0x6002181")]
	[Address(RVA = "0x2B6C3EC", Offset = "0x2B6C3EC", VA = "0x2B6C3EC")]
	public void \u0870\u05B3Ց\u066A()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002182 RID: 8578 RVA: 0x000B3598 File Offset: 0x000B1798
	[Token(Token = "0x6002182")]
	[Address(RVA = "0x2B6C528", Offset = "0x2B6C528", VA = "0x2B6C528")]
	public void \u0654ޛ\u07FAذ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002183 RID: 8579 RVA: 0x000B3690 File Offset: 0x000B1890
	[Token(Token = "0x6002183")]
	[Address(RVA = "0x2B6C664", Offset = "0x2B6C664", VA = "0x2B6C664")]
	private void ޙߍ\u081A\u0651()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002184 RID: 8580 RVA: 0x000B36B0 File Offset: 0x000B18B0
	[Token(Token = "0x6002184")]
	[Address(RVA = "0x2B6C69C", Offset = "0x2B6C69C", VA = "0x2B6C69C")]
	public void \u05F7ԝߠӱ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002185 RID: 8581 RVA: 0x000B37A8 File Offset: 0x000B19A8
	[Token(Token = "0x6002185")]
	[Address(RVA = "0x2B6C7D8", Offset = "0x2B6C7D8", VA = "0x2B6C7D8")]
	public void \u089F\u085Fէ\u059A()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002186 RID: 8582 RVA: 0x000B38A0 File Offset: 0x000B1AA0
	[Token(Token = "0x6002186")]
	[Address(RVA = "0x2B6C914", Offset = "0x2B6C914", VA = "0x2B6C914")]
	public void Ӌ\u089C\u0700ܧ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002187 RID: 8583 RVA: 0x000B3998 File Offset: 0x000B1B98
	[Token(Token = "0x6002187")]
	[Address(RVA = "0x2B6CA50", Offset = "0x2B6CA50", VA = "0x2B6CA50")]
	private void \u0825ӆا\u07BE()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002188 RID: 8584 RVA: 0x000B39B8 File Offset: 0x000B1BB8
	[Token(Token = "0x6002188")]
	[Address(RVA = "0x2B6CA88", Offset = "0x2B6CA88", VA = "0x2B6CA88")]
	private void \u073BօӁ\u059A()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002189 RID: 8585 RVA: 0x000B39D8 File Offset: 0x000B1BD8
	[Token(Token = "0x6002189")]
	[Address(RVA = "0x2B6CAC0", Offset = "0x2B6CAC0", VA = "0x2B6CAC0")]
	public void ԣԭՋࠏ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600218A RID: 8586 RVA: 0x000B3AD0 File Offset: 0x000B1CD0
	[Token(Token = "0x600218A")]
	[Address(RVA = "0x2B6CBFC", Offset = "0x2B6CBFC", VA = "0x2B6CBFC")]
	public void څࡣڐ\u0657()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600218B RID: 8587 RVA: 0x000B3BC8 File Offset: 0x000B1DC8
	[Token(Token = "0x600218B")]
	[Address(RVA = "0x2B6CD38", Offset = "0x2B6CD38", VA = "0x2B6CD38")]
	private void \u073Bݲձݕ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600218C RID: 8588 RVA: 0x000B3BE8 File Offset: 0x000B1DE8
	[Token(Token = "0x600218C")]
	[Address(RVA = "0x2B6CD70", Offset = "0x2B6CD70", VA = "0x2B6CD70")]
	private void ݡز٨հ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600218D RID: 8589 RVA: 0x000B3C08 File Offset: 0x000B1E08
	[Token(Token = "0x600218D")]
	[Address(RVA = "0x2B6CDA8", Offset = "0x2B6CDA8", VA = "0x2B6CDA8")]
	private void Start()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600218E RID: 8590 RVA: 0x000B3C28 File Offset: 0x000B1E28
	[Token(Token = "0x600218E")]
	[Address(RVA = "0x2B6CDE0", Offset = "0x2B6CDE0", VA = "0x2B6CDE0")]
	public void յߪؾՀ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600218F RID: 8591 RVA: 0x000B3D20 File Offset: 0x000B1F20
	[Token(Token = "0x600218F")]
	[Address(RVA = "0x2B6CF1C", Offset = "0x2B6CF1C", VA = "0x2B6CF1C")]
	public void \u07B6կպ߃()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002190 RID: 8592 RVA: 0x000B3E0C File Offset: 0x000B200C
	[Token(Token = "0x6002190")]
	[Address(RVA = "0x2B6D058", Offset = "0x2B6D058", VA = "0x2B6D058")]
	private void \u0739߉ڵݞ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002191 RID: 8593 RVA: 0x000B3E2C File Offset: 0x000B202C
	[Token(Token = "0x6002191")]
	[Address(RVA = "0x2B6D090", Offset = "0x2B6D090", VA = "0x2B6D090")]
	public void ժ\u065Dԯࡘ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002192 RID: 8594 RVA: 0x000B3F24 File Offset: 0x000B2124
	[Token(Token = "0x6002192")]
	[Address(RVA = "0x2B6D1CC", Offset = "0x2B6D1CC", VA = "0x2B6D1CC")]
	private void ޠۋ\u0530\u073E()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002193 RID: 8595 RVA: 0x000B3F44 File Offset: 0x000B2144
	[Token(Token = "0x6002193")]
	[Address(RVA = "0x2B6D204", Offset = "0x2B6D204", VA = "0x2B6D204")]
	private void ԞԌ\u086FՇ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002194 RID: 8596 RVA: 0x000B3F64 File Offset: 0x000B2164
	[Token(Token = "0x6002194")]
	[Address(RVA = "0x2B6D23C", Offset = "0x2B6D23C", VA = "0x2B6D23C")]
	public void Ԡݘעࠀ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x06002195 RID: 8597 RVA: 0x000B405C File Offset: 0x000B225C
	[Token(Token = "0x6002195")]
	[Address(RVA = "0x2B6D378", Offset = "0x2B6D378", VA = "0x2B6D378")]
	private void ߠ\u07AAߚթ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002196 RID: 8598 RVA: 0x000B407C File Offset: 0x000B227C
	[Token(Token = "0x6002196")]
	[Address(RVA = "0x2B6D3B0", Offset = "0x2B6D3B0", VA = "0x2B6D3B0")]
	private void \u05ABݿࡋ\u06E9()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002197 RID: 8599 RVA: 0x000B409C File Offset: 0x000B229C
	[Token(Token = "0x6002197")]
	[Address(RVA = "0x2B6D3E8", Offset = "0x2B6D3E8", VA = "0x2B6D3E8")]
	private void ߁\u0829\u073E\u081A()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002198 RID: 8600 RVA: 0x000B40BC File Offset: 0x000B22BC
	[Token(Token = "0x6002198")]
	[Address(RVA = "0x2B6D420", Offset = "0x2B6D420", VA = "0x2B6D420")]
	private void \u06EDٵ۶\u06DB()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x06002199 RID: 8601 RVA: 0x000B40DC File Offset: 0x000B22DC
	[Token(Token = "0x6002199")]
	[Address(RVA = "0x2B6D458", Offset = "0x2B6D458", VA = "0x2B6D458")]
	private void \u086Bԍࡊڭ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600219A RID: 8602 RVA: 0x000B40FC File Offset: 0x000B22FC
	[Token(Token = "0x600219A")]
	[Address(RVA = "0x2B6D490", Offset = "0x2B6D490", VA = "0x2B6D490")]
	public void יԠ\u07EDԺ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600219B RID: 8603 RVA: 0x000B41F4 File Offset: 0x000B23F4
	[Token(Token = "0x600219B")]
	[Address(RVA = "0x2B6D5CC", Offset = "0x2B6D5CC", VA = "0x2B6D5CC")]
	private void ۮߝڪڐ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600219C RID: 8604 RVA: 0x000B4214 File Offset: 0x000B2414
	[Token(Token = "0x600219C")]
	[Address(RVA = "0x2B6D604", Offset = "0x2B6D604", VA = "0x2B6D604")]
	private void ݸԲ\u0616Ԫ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0600219D RID: 8605 RVA: 0x000B4234 File Offset: 0x000B2434
	[Token(Token = "0x600219D")]
	[Address(RVA = "0x2B6D63C", Offset = "0x2B6D63C", VA = "0x2B6D63C")]
	public void طӏܙࢺ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600219E RID: 8606 RVA: 0x000B432C File Offset: 0x000B252C
	[Token(Token = "0x600219E")]
	[Address(RVA = "0x2B6D778", Offset = "0x2B6D778", VA = "0x2B6D778")]
	public void ո\u07AA\u05BDࠕ()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x0600219F RID: 8607 RVA: 0x000B4424 File Offset: 0x000B2624
	[Token(Token = "0x600219F")]
	[Address(RVA = "0x2B6D8B4", Offset = "0x2B6D8B4", VA = "0x2B6D8B4")]
	public void ܫ\u070Fۃ\u07F2()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x060021A0 RID: 8608 RVA: 0x000B451C File Offset: 0x000B271C
	[Token(Token = "0x60021A0")]
	[Address(RVA = "0x2B6D9F0", Offset = "0x2B6D9F0", VA = "0x2B6D9F0")]
	private void \u0882צ\u0821\u05B4()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x060021A1 RID: 8609 RVA: 0x000B453C File Offset: 0x000B273C
	[Token(Token = "0x60021A1")]
	[Address(RVA = "0x2B6DA28", Offset = "0x2B6DA28", VA = "0x2B6DA28")]
	public void ӻӒݝ߃()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x060021A2 RID: 8610 RVA: 0x000B4634 File Offset: 0x000B2834
	[Token(Token = "0x60021A2")]
	[Address(RVA = "0x2B6DB64", Offset = "0x2B6DB64", VA = "0x2B6DB64")]
	public SecondOrderDynamics()
	{
	}

	// Token: 0x060021A3 RID: 8611 RVA: 0x000B4648 File Offset: 0x000B2848
	[Token(Token = "0x60021A3")]
	[Address(RVA = "0x2B6DB6C", Offset = "0x2B6DB6C", VA = "0x2B6DB6C")]
	public void ܣ\u086E\u05CF\u06D8()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x060021A4 RID: 8612 RVA: 0x000B4740 File Offset: 0x000B2940
	[Token(Token = "0x60021A4")]
	[Address(RVA = "0x2B6DCA8", Offset = "0x2B6DCA8", VA = "0x2B6DCA8")]
	public void Ҿࢹؼס()
	{
		float deltaTime = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		Transform transform = this.ࠔؼࡏݥ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		Vector3 position = transform.position;
		this.ڗٽ\u05BDմ.y = ڼ_u07B9_u083Dݯ;
		this.ڗٽ\u05BDմ.z = ࢲ_u0833_u059BԌ;
		float x = this.\u05AF\u06D9ܬ\u0705.x;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float num = this.ޔӊڰڏ;
		float x2 = this.Ծ\u06FEࢷࡘ.x;
		float u06E4ߧهݥ = this.\u06E4ߧهݥ;
		float num2 = this.١դގݝ;
		float z3 = this.ࠂࡦԈل.z;
		float u06FD_u0740_u081Fࠃ = this.\u06FD\u0740\u081Fࠃ;
		Transform ւݍ_u05BA_u05FA = this.ւݍ\u05BA\u05FA;
		this.ࠂࡦԈل.z = z;
		this.Ծ\u06FEࢷࡘ.x = deltaTime;
		this.Ծ\u06FEࢷࡘ.z = u06FD_u0740_u081Fࠃ;
	}

	// Token: 0x060021A5 RID: 8613 RVA: 0x000B4838 File Offset: 0x000B2A38
	[Token(Token = "0x60021A5")]
	[Address(RVA = "0x2B6DDE4", Offset = "0x2B6DDE4", VA = "0x2B6DDE4")]
	private void \u0656ӺմՁ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x060021A6 RID: 8614 RVA: 0x000B4858 File Offset: 0x000B2A58
	[Token(Token = "0x60021A6")]
	[Address(RVA = "0x2B6DE1C", Offset = "0x2B6DE1C", VA = "0x2B6DE1C")]
	private void \u065F\u0839ܤ\u073C()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x060021A7 RID: 8615 RVA: 0x000B4878 File Offset: 0x000B2A78
	[Token(Token = "0x60021A7")]
	[Address(RVA = "0x2B6DE54", Offset = "0x2B6DE54", VA = "0x2B6DE54")]
	private void ۲ڂ\u05B1ڨ()
	{
		Vector3 position = this.ւݍ\u05BA\u05FA.position;
	}

	// Token: 0x0400044E RID: 1102
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400044E")]
	private Vector3 \u06E8ޱ\u089F\u082A;

	// Token: 0x0400044F RID: 1103
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x400044F")]
	private Vector3 ڗٽ\u05BDմ;

	// Token: 0x04000450 RID: 1104
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000450")]
	private Vector3 \u05AF\u06D9ܬ\u0705;

	// Token: 0x04000451 RID: 1105
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x4000451")]
	public Vector3 ࠂࡦԈل;

	// Token: 0x04000452 RID: 1106
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000452")]
	public Vector3 Ծ\u06FEࢷࡘ;

	// Token: 0x04000453 RID: 1107
	[FieldOffset(Offset = "0x54")]
	[Token(Token = "0x4000453")]
	private float ޔӊڰڏ;

	// Token: 0x04000454 RID: 1108
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000454")]
	private float \u06FD\u0740\u081Fࠃ;

	// Token: 0x04000455 RID: 1109
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x4000455")]
	private float \u06E4ߧهݥ;

	// Token: 0x04000456 RID: 1110
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000456")]
	private float ١դގݝ;

	// Token: 0x04000457 RID: 1111
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000457")]
	public Transform ւݍ\u05BA\u05FA;

	// Token: 0x04000458 RID: 1112
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000458")]
	public Transform ࠔؼࡏݥ;

	// Token: 0x04000459 RID: 1113
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000459")]
	public float ڼ\u07B9\u083Dݯ;

	// Token: 0x0400045A RID: 1114
	[FieldOffset(Offset = "0x7C")]
	[Token(Token = "0x400045A")]
	public float ࢲ\u0833\u059BԌ;

	// Token: 0x0400045B RID: 1115
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x400045B")]
	public float Ӫ\u0830\u07B9ګ;
}
