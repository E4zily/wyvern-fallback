﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Photon.Rooms
{
	// Token: 0x02000114 RID: 276
	[Token(Token = "0x2000114")]
	public class RoomListingMenu : MonoBehaviourPunCallbacks
	{
		// Token: 0x06002AEC RID: 10988 RVA: 0x00103214 File Offset: 0x00101414
		[Token(Token = "0x6002AEC")]
		[Address(RVA = "0x2B6318C", Offset = "0x2B6318C", VA = "0x2B6318C")]
		private void Start()
		{
			RoomListingMenu.Instance = this;
			GameObject[] array = this.scriptApplys;
		}

		// Token: 0x06002AED RID: 10989 RVA: 0x0010323C File Offset: 0x0010143C
		[Token(Token = "0x6002AED")]
		[Address(RVA = "0x2B63254", Offset = "0x2B63254", VA = "0x2B63254")]
		private void FixedUpdate()
		{
			long num = 1L;
			if (num == 0L)
			{
			}
			bool isConnected = PhotonNetwork.IsConnected;
			if (num == 0L)
			{
			}
			bool inLobby = PhotonNetwork.InLobby;
			long num2;
			if (!this.l)
			{
				ޖՇՎ\u0838.ڀޡ\u07A6\u065A("Joining Lobby.");
				if ("Joining Lobby." == null)
				{
				}
				bool flag = PhotonNetwork.JoinLobby();
				ޖՇՎ\u0838.ڀޡ\u07A6\u065A("Joined Lobby.");
				num2 = 1L;
				this.l = (num2 != 0L);
			}
			if (num2 == 0L)
			{
			}
			bool inLobby2 = PhotonNetwork.InLobby;
			int pos = this.posCount;
			this.UpdateMenu(pos);
			TouchScreenKeyboard touchScreenKeyboard = this.overlayKeyboard;
			if (touchScreenKeyboard != null)
			{
				bool active = touchScreenKeyboard.active;
				string text = this.overlayKeyboard.text;
				this.inputText = text;
				Transform transform = base.transform;
				long index = 0L;
				TMP_Text component = transform.GetChild((int)index).gameObject.GetComponent<TMP_Text>();
				return;
			}
		}

		// Token: 0x06002AEE RID: 10990 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002AEE")]
		[Address(RVA = "0x2B63EE8", Offset = "0x2B63EE8", VA = "0x2B63EE8", Slot = "40")]
		public override void OnRoomListUpdate(List<RoomInfo> roomList)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002AEF RID: 10991 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002AEF")]
		[Address(RVA = "0x2B63424", Offset = "0x2B63424", VA = "0x2B63424")]
		private void UpdateMenu(int pos)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002AF0 RID: 10992 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002AF0")]
		[Address(RVA = "0x2B643D8", Offset = "0x2B643D8", VA = "0x2B643D8")]
		public void ButtonPress(RoomsListingButton button)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002AF1 RID: 10993 RVA: 0x0010330C File Offset: 0x0010150C
		[Token(Token = "0x6002AF1")]
		[Address(RVA = "0x2B647EC", Offset = "0x2B647EC", VA = "0x2B647EC")]
		public RoomListingMenu()
		{
		}

		// Token: 0x040005AC RID: 1452
		[Token(Token = "0x40005AC")]
		public static RoomListingMenu Instance;

		// Token: 0x040005AD RID: 1453
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40005AD")]
		public List<RoomListingMenu.Room> rooms;

		// Token: 0x040005AE RID: 1454
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40005AE")]
		public TMP_Text infoText1;

		// Token: 0x040005AF RID: 1455
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40005AF")]
		public TMP_Text infoText2;

		// Token: 0x040005B0 RID: 1456
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40005B0")]
		public TMP_Text infoText3;

		// Token: 0x040005B1 RID: 1457
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40005B1")]
		public Image modicon1;

		// Token: 0x040005B2 RID: 1458
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x40005B2")]
		public Image modicon2;

		// Token: 0x040005B3 RID: 1459
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x40005B3")]
		public Image modicon3;

		// Token: 0x040005B4 RID: 1460
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x40005B4")]
		public Image backing1;

		// Token: 0x040005B5 RID: 1461
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x40005B5")]
		public Image backing2;

		// Token: 0x040005B6 RID: 1462
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x40005B6")]
		public Image backing3;

		// Token: 0x040005B7 RID: 1463
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x40005B7")]
		public Sprite lava;

		// Token: 0x040005B8 RID: 1464
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x40005B8")]
		public Sprite norm;

		// Token: 0x040005B9 RID: 1465
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x40005B9")]
		public GameObject[] scriptApplys;

		// Token: 0x040005BA RID: 1466
		[FieldOffset(Offset = "0x88")]
		[Token(Token = "0x40005BA")]
		private int posCount;

		// Token: 0x040005BB RID: 1467
		[FieldOffset(Offset = "0x8C")]
		[Token(Token = "0x40005BB")]
		private bool l;

		// Token: 0x040005BC RID: 1468
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x40005BC")]
		private TouchScreenKeyboard overlayKeyboard;

		// Token: 0x040005BD RID: 1469
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x40005BD")]
		private string inputText = "";

		// Token: 0x040005BE RID: 1470
		[FieldOffset(Offset = "0xA0")]
		[Token(Token = "0x40005BE")]
		private RoomsListingButton tempButton;

		// Token: 0x02000115 RID: 277
		[Token(Token = "0x2000115")]
		[Serializable]
		public struct Room
		{
			// Token: 0x040005BF RID: 1471
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x40005BF")]
			public string RoomName;

			// Token: 0x040005C0 RID: 1472
			[FieldOffset(Offset = "0x8")]
			[Token(Token = "0x40005C0")]
			public int playerCount;

			// Token: 0x040005C1 RID: 1473
			[FieldOffset(Offset = "0xC")]
			[Token(Token = "0x40005C1")]
			public bool inLava;

			// Token: 0x040005C2 RID: 1474
			[FieldOffset(Offset = "0xD")]
			[Token(Token = "0x40005C2")]
			public bool isJoinable;

			// Token: 0x040005C3 RID: 1475
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x40005C3")]
			public int maxPlayers;

			// Token: 0x040005C4 RID: 1476
			[FieldOffset(Offset = "0x14")]
			[Token(Token = "0x40005C4")]
			public bool hasStaff;
		}
	}
}
