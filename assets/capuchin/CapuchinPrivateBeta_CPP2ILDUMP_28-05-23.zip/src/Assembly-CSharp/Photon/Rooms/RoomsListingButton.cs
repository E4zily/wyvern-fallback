﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Photon.Rooms
{
	// Token: 0x02000116 RID: 278
	[Token(Token = "0x2000116")]
	public class RoomsListingButton : MonoBehaviour
	{
		// Token: 0x06002AF2 RID: 10994 RVA: 0x0010332C File Offset: 0x0010152C
		[Token(Token = "0x6002AF2")]
		[Address(RVA = "0x2B64848", Offset = "0x2B64848", VA = "0x2B64848")]
		private void Start()
		{
			string name = base.gameObject.name;
			this.function = name;
		}

		// Token: 0x06002AF3 RID: 10995 RVA: 0x00103354 File Offset: 0x00101554
		[Token(Token = "0x6002AF3")]
		[Address(RVA = "0x2B64888", Offset = "0x2B64888", VA = "0x2B64888")]
		private void Update()
		{
			if (this.press)
			{
				RoomListingMenu instance = RoomListingMenu.Instance;
				return;
			}
		}

		// Token: 0x06002AF4 RID: 10996 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002AF4")]
		[Address(RVA = "0x2B648FC", Offset = "0x2B648FC", VA = "0x2B648FC")]
		private void OnTriggerEnter(Collider other)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002AF5 RID: 10997 RVA: 0x00103378 File Offset: 0x00101578
		[Token(Token = "0x6002AF5")]
		[Address(RVA = "0x2B649DC", Offset = "0x2B649DC", VA = "0x2B649DC")]
		public RoomsListingButton()
		{
		}

		// Token: 0x040005C5 RID: 1477
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40005C5")]
		public string function;

		// Token: 0x040005C6 RID: 1478
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40005C6")]
		public bool press;
	}
}
