﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.AI;

// Token: 0x02000066 RID: 102
[Token(Token = "0x2000066")]
public class PatrolAI : MonoBehaviour
{
	// Token: 0x06000EC2 RID: 3778 RVA: 0x000556C0 File Offset: 0x000538C0
	[Token(Token = "0x6000EC2")]
	[Address(RVA = "0x2D4D25C", Offset = "0x2D4D25C", VA = "0x2D4D25C")]
	private void ࡀڮӌߕ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("Faild To Add Winner Money: ");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.٨\u0883ݪש(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Transform transform2;
		Vector3 position5 = transform2.position;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.ٻݨ\u0595\u0870();
			return;
		}
	}

	// Token: 0x06000EC3 RID: 3779 RVA: 0x00055844 File Offset: 0x00053A44
	[Token(Token = "0x6000EC3")]
	[Address(RVA = "0x2D4D80C", Offset = "0x2D4D80C", VA = "0x2D4D80C")]
	private void \u05A2\u0599ڐڎ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000EC4 RID: 3780 RVA: 0x00055870 File Offset: 0x00053A70
	[Token(Token = "0x6000EC4")]
	[Address(RVA = "0x2D4D85C", Offset = "0x2D4D85C", VA = "0x2D4D85C")]
	private void ޡࠅ\u089Aߔ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000EC5 RID: 3781 RVA: 0x0005588C File Offset: 0x00053A8C
	[Token(Token = "0x6000EC5")]
	[Address(RVA = "0x2D4D8B8", Offset = "0x2D4D8B8", VA = "0x2D4D8B8")]
	private Transform \u06E7\u05C9ԓ\u0898(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000EC6 RID: 3782 RVA: 0x000558C4 File Offset: 0x00053AC4
	[Token(Token = "0x6000EC6")]
	[Address(RVA = "0x2D4D9C0", Offset = "0x2D4D9C0", VA = "0x2D4D9C0")]
	private Transform \u060Bֈ\u0605ԋ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000EC7 RID: 3783 RVA: 0x000558F4 File Offset: 0x00053AF4
	[Token(Token = "0x6000EC7")]
	[Address(RVA = "0x2D4DAA8", Offset = "0x2D4DAA8", VA = "0x2D4DAA8")]
	public void \u0886\u0740\u0605\u088B()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000EC8 RID: 3784 RVA: 0x00055928 File Offset: 0x00053B28
	[Token(Token = "0x6000EC8")]
	[Address(RVA = "0x2D4DC18", Offset = "0x2D4DC18", VA = "0x2D4DC18")]
	public PatrolAI()
	{
	}

	// Token: 0x06000EC9 RID: 3785 RVA: 0x00055948 File Offset: 0x00053B48
	[Token(Token = "0x6000EC9")]
	[Address(RVA = "0x2D4DC28", Offset = "0x2D4DC28", VA = "0x2D4DC28")]
	private void Ԉӊ\u07B7ܮ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000ECA RID: 3786 RVA: 0x0005597C File Offset: 0x00053B7C
	[Token(Token = "0x6000ECA")]
	[Address(RVA = "0x2D4DC78", Offset = "0x2D4DC78", VA = "0x2D4DC78")]
	private void ۯݬ\u065Cޓ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000ECB RID: 3787 RVA: 0x000559A8 File Offset: 0x00053BA8
	[Token(Token = "0x6000ECB")]
	[Address(RVA = "0x2D4DCC8", Offset = "0x2D4DCC8", VA = "0x2D4DCC8")]
	public void լҿࢶ\u089E()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000ECC RID: 3788 RVA: 0x000559C8 File Offset: 0x00053BC8
	[Token(Token = "0x6000ECC")]
	[Address(RVA = "0x2D4DCE4", Offset = "0x2D4DCE4", VA = "0x2D4DCE4")]
	public void \u06D8نԚ\u06E4()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000ECD RID: 3789 RVA: 0x000559E8 File Offset: 0x00053BE8
	[Token(Token = "0x6000ECD")]
	[Address(RVA = "0x2D4DD00", Offset = "0x2D4DD00", VA = "0x2D4DD00")]
	private Transform \u081A\u07ABӘۮ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000ECE RID: 3790 RVA: 0x00055A14 File Offset: 0x00053C14
	[Token(Token = "0x6000ECE")]
	[Address(RVA = "0x2D4DDE8", Offset = "0x2D4DDE8", VA = "0x2D4DDE8")]
	public void էڨڻ\u06D6()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000ECF RID: 3791 RVA: 0x00055A34 File Offset: 0x00053C34
	[Token(Token = "0x6000ECF")]
	[Address(RVA = "0x2D4DE04", Offset = "0x2D4DE04", VA = "0x2D4DE04")]
	public void ࠁף\u0735ߍ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000ED0 RID: 3792 RVA: 0x00055A54 File Offset: 0x00053C54
	[Token(Token = "0x6000ED0")]
	[Address(RVA = "0x2D4DE20", Offset = "0x2D4DE20", VA = "0x2D4DE20")]
	private void \u066Aࢴࢧ\u0600()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000ED1 RID: 3793 RVA: 0x00055A88 File Offset: 0x00053C88
	[Token(Token = "0x6000ED1")]
	[Address(RVA = "0x2D4DE70", Offset = "0x2D4DE70", VA = "0x2D4DE70")]
	public void \u0611ࡡ\u08B5Ԭ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000ED2 RID: 3794 RVA: 0x00055ABC File Offset: 0x00053CBC
	[Token(Token = "0x6000ED2")]
	[Address(RVA = "0x2D4DFC4", Offset = "0x2D4DFC4", VA = "0x2D4DFC4")]
	public void \u06EDԒߝ߃()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000ED3 RID: 3795 RVA: 0x00055ADC File Offset: 0x00053CDC
	[Token(Token = "0x6000ED3")]
	[Address(RVA = "0x2D4DFE0", Offset = "0x2D4DFE0", VA = "0x2D4DFE0")]
	public void \u070Aࡑ\u0730ޒ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000ED4 RID: 3796 RVA: 0x00055AFC File Offset: 0x00053CFC
	[Token(Token = "0x6000ED4")]
	[Address(RVA = "0x2D4DFFC", Offset = "0x2D4DFFC", VA = "0x2D4DFFC")]
	public void \u05A4ԏիԘ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000ED5 RID: 3797 RVA: 0x00055B30 File Offset: 0x00053D30
	[Token(Token = "0x6000ED5")]
	[Address(RVA = "0x2D4E16C", Offset = "0x2D4E16C", VA = "0x2D4E16C")]
	private Transform ӻࡃࠍՊ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000ED6 RID: 3798 RVA: 0x00055B5C File Offset: 0x00053D5C
	[Token(Token = "0x6000ED6")]
	[Address(RVA = "0x2D4E254", Offset = "0x2D4E254", VA = "0x2D4E254")]
	private Transform ٨Դ\u05ECࠍ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000ED7 RID: 3799 RVA: 0x00055B94 File Offset: 0x00053D94
	[Token(Token = "0x6000ED7")]
	[Address(RVA = "0x2D4E35C", Offset = "0x2D4E35C", VA = "0x2D4E35C")]
	private void ݱ\u0832ݥ\u08B5()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000ED8 RID: 3800 RVA: 0x00055BB0 File Offset: 0x00053DB0
	[Token(Token = "0x6000ED8")]
	[Address(RVA = "0x2D4E3B8", Offset = "0x2D4E3B8", VA = "0x2D4E3B8")]
	private Transform \u0602\u0558\u066B\u06E2(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000ED9 RID: 3801 RVA: 0x00055BE8 File Offset: 0x00053DE8
	[Token(Token = "0x6000ED9")]
	[Address(RVA = "0x2D4E4C0", Offset = "0x2D4E4C0", VA = "0x2D4E4C0")]
	public void Ԛ\u064C\u086Dړ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000EDA RID: 3802 RVA: 0x00055C08 File Offset: 0x00053E08
	[Token(Token = "0x6000EDA")]
	[Address(RVA = "0x2D4E4DC", Offset = "0x2D4E4DC", VA = "0x2D4E4DC")]
	public void އ\u0878ڞݳ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000EDB RID: 3803 RVA: 0x00055C3C File Offset: 0x00053E3C
	[Token(Token = "0x6000EDB")]
	[Address(RVA = "0x2D4E64C", Offset = "0x2D4E64C", VA = "0x2D4E64C")]
	private void \u0829\u05FDژտ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("TurnAmount");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u05B2މݓ\u070F(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = transform.position;
		Vector3 position4 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		Vector3 position5 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 1L;
		long u0657Ռہԭ = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u0705րӥࡦ();
			this.\u0657Ռہԭ = (u0657Ռہԭ != 0L);
			return;
		}
	}

	// Token: 0x06000EDC RID: 3804 RVA: 0x00055DC8 File Offset: 0x00053FC8
	[Token(Token = "0x6000EDC")]
	[Address(RVA = "0x2D4EBE0", Offset = "0x2D4EBE0", VA = "0x2D4EBE0")]
	public void Ӭٸמՠ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000EDD RID: 3805 RVA: 0x00055DFC File Offset: 0x00053FFC
	[Token(Token = "0x6000EDD")]
	[Address(RVA = "0x2D4ED50", Offset = "0x2D4ED50", VA = "0x2D4ED50")]
	[PunRPC]
	public void PlayNoise()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000EDE RID: 3806 RVA: 0x00055E1C File Offset: 0x0005401C
	[Token(Token = "0x6000EDE")]
	[Address(RVA = "0x2D4ED6C", Offset = "0x2D4ED6C", VA = "0x2D4ED6C")]
	public void \u061Fת߇ӂ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000EDF RID: 3807 RVA: 0x00055E4C File Offset: 0x0005404C
	[Token(Token = "0x6000EDF")]
	[Address(RVA = "0x2D4EEC0", Offset = "0x2D4EEC0", VA = "0x2D4EEC0")]
	public void ݑ\u07BFԬו()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000EE0 RID: 3808 RVA: 0x00055E6C File Offset: 0x0005406C
	[Token(Token = "0x6000EE0")]
	[Address(RVA = "0x2D4EEDC", Offset = "0x2D4EEDC", VA = "0x2D4EEDC")]
	private Transform \u07ACڏ\u074Bޟ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000EE1 RID: 3809 RVA: 0x00055EA4 File Offset: 0x000540A4
	[Token(Token = "0x6000EE1")]
	[Address(RVA = "0x2D4EFE4", Offset = "0x2D4EFE4", VA = "0x2D4EFE4")]
	private void \u0828Ә\u087DԊ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000EE2 RID: 3810 RVA: 0x00055ED8 File Offset: 0x000540D8
	[Token(Token = "0x6000EE2")]
	[Address(RVA = "0x2D4F034", Offset = "0x2D4F034", VA = "0x2D4F034")]
	private void ۮߝڪڐ()
	{
	}

	// Token: 0x06000EE3 RID: 3811 RVA: 0x00055EE8 File Offset: 0x000540E8
	[Token(Token = "0x6000EE3")]
	[Address(RVA = "0x2D4F090", Offset = "0x2D4F090", VA = "0x2D4F090")]
	private void \u0818ՠש\u0731()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000EE4 RID: 3812 RVA: 0x00055F04 File Offset: 0x00054104
	[Token(Token = "0x6000EE4")]
	[Address(RVA = "0x2D4F0EC", Offset = "0x2D4F0EC", VA = "0x2D4F0EC")]
	private Transform ܜӎڇ٤(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000EE5 RID: 3813 RVA: 0x00055F3C File Offset: 0x0005413C
	[Token(Token = "0x6000EE5")]
	[Address(RVA = "0x2D4F1F4", Offset = "0x2D4F1F4", VA = "0x2D4F1F4")]
	public void \u07B8ۈהء()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000EE6 RID: 3814 RVA: 0x00055F5C File Offset: 0x0005415C
	[Token(Token = "0x6000EE6")]
	[Address(RVA = "0x2D4F210", Offset = "0x2D4F210", VA = "0x2D4F210")]
	private void \u065D\u070Aٶࢰ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000EE7 RID: 3815 RVA: 0x00055F78 File Offset: 0x00054178
	[Token(Token = "0x6000EE7")]
	[Address(RVA = "0x2D4F26C", Offset = "0x2D4F26C", VA = "0x2D4F26C")]
	private void ضݡࡩ۷()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000EE8 RID: 3816 RVA: 0x00055FAC File Offset: 0x000541AC
	[Token(Token = "0x6000EE8")]
	[Address(RVA = "0x2D4F2BC", Offset = "0x2D4F2BC", VA = "0x2D4F2BC")]
	public void ۻ\u074A\u07B9כ()
	{
	}

	// Token: 0x06000EE9 RID: 3817 RVA: 0x00055FC0 File Offset: 0x000541C0
	[Token(Token = "0x6000EE9")]
	[Address(RVA = "0x2D4F2D8", Offset = "0x2D4F2D8", VA = "0x2D4F2D8")]
	private void ࠈ\u07A9\u05B3Ծ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("FingerTip");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.ޕ߇\u060Fټ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Transform playerCam = this.Ցԑٶ\u0749.playerCam;
		Transform transform2;
		Vector3 position7 = transform2.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		if (this.\u0657Ռہԭ)
		{
			this.ߕݹم\u0654();
			return;
		}
	}

	// Token: 0x06000EEA RID: 3818 RVA: 0x00056154 File Offset: 0x00054354
	[Token(Token = "0x6000EEA")]
	[Address(RVA = "0x2D4F870", Offset = "0x2D4F870", VA = "0x2D4F870")]
	private void \u07B5\u07A9\u0602Ԟ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000EEB RID: 3819 RVA: 0x00056188 File Offset: 0x00054388
	[Token(Token = "0x6000EEB")]
	[Address(RVA = "0x2D4F71C", Offset = "0x2D4F71C", VA = "0x2D4F71C")]
	public void ߕݹم\u0654()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000EEC RID: 3820 RVA: 0x000561BC File Offset: 0x000543BC
	[Token(Token = "0x6000EEC")]
	[Address(RVA = "0x2D4F8C0", Offset = "0x2D4F8C0", VA = "0x2D4F8C0")]
	private void ڷԲ\u0618ރ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("Update User Inventory");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u081A\u07ABӘۮ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u05A4ԏիԘ();
			return;
		}
	}

	// Token: 0x06000EED RID: 3821 RVA: 0x00056364 File Offset: 0x00054564
	[Token(Token = "0x6000EED")]
	[Address(RVA = "0x2D4FC1C", Offset = "0x2D4FC1C", VA = "0x2D4FC1C")]
	private Transform ޒ\u074A\u07B2ݶ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000EEE RID: 3822 RVA: 0x0005639C File Offset: 0x0005459C
	[Token(Token = "0x6000EEE")]
	[Address(RVA = "0x2D4FD24", Offset = "0x2D4FD24", VA = "0x2D4FD24")]
	private void ࡩࠏࡅբ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000EEF RID: 3823 RVA: 0x000563D0 File Offset: 0x000545D0
	[Token(Token = "0x6000EEF")]
	[Address(RVA = "0x2D4FD74", Offset = "0x2D4FD74", VA = "0x2D4FD74")]
	private Transform ݨݽՎ\u07FA(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000EF0 RID: 3824 RVA: 0x00056408 File Offset: 0x00054608
	[Token(Token = "0x6000EF0")]
	[Address(RVA = "0x2D4FE7C", Offset = "0x2D4FE7C", VA = "0x2D4FE7C")]
	private void ١ۏ\u05C4ӝ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000EF1 RID: 3825 RVA: 0x00056424 File Offset: 0x00054624
	[Token(Token = "0x6000EF1")]
	[Address(RVA = "0x2D4FED8", Offset = "0x2D4FED8", VA = "0x2D4FED8")]
	public void \u089AԴ\u05EDղ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000EF2 RID: 3826 RVA: 0x00056458 File Offset: 0x00054658
	[Token(Token = "0x6000EF2")]
	[Address(RVA = "0x2D4EA8C", Offset = "0x2D4EA8C", VA = "0x2D4EA8C")]
	public void \u0705րӥࡦ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000EF3 RID: 3827 RVA: 0x0005648C File Offset: 0x0005468C
	[Token(Token = "0x6000EF3")]
	[Address(RVA = "0x2D50048", Offset = "0x2D50048", VA = "0x2D50048")]
	private void ׯࠋ\u060C۰()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag(". Please update you game to the latest version");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u06D7\u05F5\u0658ݣ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		long active = 0L;
		this.Ցԑٶ\u0749.rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u061Fת߇ӂ();
			return;
		}
	}

	// Token: 0x06000EF4 RID: 3828 RVA: 0x0005660C File Offset: 0x0005480C
	[Token(Token = "0x6000EF4")]
	[Address(RVA = "0x2D504A0", Offset = "0x2D504A0", VA = "0x2D504A0")]
	private Transform \u066Bݻۺ\u066C(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000EF5 RID: 3829 RVA: 0x0005663C File Offset: 0x0005483C
	[Token(Token = "0x6000EF5")]
	[Address(RVA = "0x2D50588", Offset = "0x2D50588", VA = "0x2D50588")]
	private void \u061B\u05EEوۈ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u081A\u07ABӘۮ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = transform.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u0886\u0740\u0605\u088B();
			long u0657Ռہԭ = 1L;
			this.\u0657Ռہԭ = (u0657Ռہԭ != 0L);
			return;
		}
	}

	// Token: 0x06000EF6 RID: 3830 RVA: 0x000567D8 File Offset: 0x000549D8
	[Token(Token = "0x6000EF6")]
	[Address(RVA = "0x2D5002C", Offset = "0x2D5002C", VA = "0x2D5002C")]
	public void \u06E1\u0742\u073Bՠ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000EF7 RID: 3831 RVA: 0x000567F8 File Offset: 0x000549F8
	[Token(Token = "0x6000EF7")]
	[Address(RVA = "0x2D508E0", Offset = "0x2D508E0", VA = "0x2D508E0")]
	public void ݛ\u0894ӌ\u07B6()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000EF8 RID: 3832 RVA: 0x00056818 File Offset: 0x00054A18
	[Token(Token = "0x6000EF8")]
	[Address(RVA = "0x2D508FC", Offset = "0x2D508FC", VA = "0x2D508FC")]
	private void OnDrawGizmosSelected()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000EF9 RID: 3833 RVA: 0x0005684C File Offset: 0x00054A4C
	[Token(Token = "0x6000EF9")]
	[Address(RVA = "0x2D4D5B0", Offset = "0x2D4D5B0", VA = "0x2D4D5B0")]
	private Transform ٨\u0883ݪש(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000EFA RID: 3834 RVA: 0x00056884 File Offset: 0x00054A84
	[Token(Token = "0x6000EFA")]
	[Address(RVA = "0x2D5094C", Offset = "0x2D5094C", VA = "0x2D5094C")]
	private void յߪؾՀ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("TurnAmount");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u0816ոٺࡗ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = transform.position;
		Vector3 position4 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		Vector3 position5 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 1L;
		long u0657Ռہԭ = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u05A4ԏիԘ();
			this.\u0657Ռہԭ = (u0657Ռہԭ != 0L);
			return;
		}
	}

	// Token: 0x06000EFB RID: 3835 RVA: 0x00056A18 File Offset: 0x00054C18
	[Token(Token = "0x6000EFB")]
	[Address(RVA = "0x2D50D8C", Offset = "0x2D50D8C", VA = "0x2D50D8C")]
	private void \u07A6\u0748է\u0703()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000EFC RID: 3836 RVA: 0x00056A4C File Offset: 0x00054C4C
	[Token(Token = "0x6000EFC")]
	[Address(RVA = "0x2D50DDC", Offset = "0x2D50DDC", VA = "0x2D50DDC")]
	public void \u0701ݛגݸ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000EFD RID: 3837 RVA: 0x00056A80 File Offset: 0x00054C80
	[Token(Token = "0x6000EFD")]
	[Address(RVA = "0x2D50F4C", Offset = "0x2D50F4C", VA = "0x2D50F4C")]
	private void Update()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("Player");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.ݨݽՎ\u07FA(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u0656\u07A9ݓӮ();
			return;
		}
	}

	// Token: 0x06000EFE RID: 3838 RVA: 0x00056C1C File Offset: 0x00054E1C
	[Token(Token = "0x6000EFE")]
	[Address(RVA = "0x2D513F8", Offset = "0x2D513F8", VA = "0x2D513F8")]
	public void \u0878ӱݫ\u060E()
	{
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000EFF RID: 3839 RVA: 0x00056C48 File Offset: 0x00054E48
	[Token(Token = "0x6000EFF")]
	[Address(RVA = "0x2D51568", Offset = "0x2D51568", VA = "0x2D51568")]
	private void ࡃںӅ\u073F()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F00 RID: 3840 RVA: 0x00056C7C File Offset: 0x00054E7C
	[Token(Token = "0x6000F00")]
	[Address(RVA = "0x2D515B8", Offset = "0x2D515B8", VA = "0x2D515B8")]
	private void ԼܫӉࠌ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F01 RID: 3841 RVA: 0x00056CB0 File Offset: 0x00054EB0
	[Token(Token = "0x6000F01")]
	[Address(RVA = "0x2D51608", Offset = "0x2D51608", VA = "0x2D51608")]
	private Transform ۑր\u0610ࢧ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F02 RID: 3842 RVA: 0x00056CE8 File Offset: 0x00054EE8
	[Token(Token = "0x6000F02")]
	[Address(RVA = "0x2D51710", Offset = "0x2D51710", VA = "0x2D51710")]
	public void ӭࢴ\u0878\u06EC()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F03 RID: 3843 RVA: 0x00056D1C File Offset: 0x00054F1C
	[Token(Token = "0x6000F03")]
	[Address(RVA = "0x2D51880", Offset = "0x2D51880", VA = "0x2D51880")]
	private Transform \u06E4ࢱ\u06E1\u05AF(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F04 RID: 3844 RVA: 0x00056D4C File Offset: 0x00054F4C
	[Token(Token = "0x6000F04")]
	[Address(RVA = "0x2D51968", Offset = "0x2D51968", VA = "0x2D51968")]
	public void ծ\u05C0\u0597\u0653()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F05 RID: 3845 RVA: 0x00056D6C File Offset: 0x00054F6C
	[Token(Token = "0x6000F05")]
	[Address(RVA = "0x2D51984", Offset = "0x2D51984", VA = "0x2D51984")]
	private Transform ݿߕ\u05F9ޖ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F06 RID: 3846 RVA: 0x00056DA4 File Offset: 0x00054FA4
	[Token(Token = "0x6000F06")]
	[Address(RVA = "0x2D51A8C", Offset = "0x2D51A8C", VA = "0x2D51A8C")]
	private void Ԉ۴ࡉࢬ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("Song Index: ");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u066Bݻۺ\u066C(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.ࢺࠊ\u05AAࡄ();
			return;
		}
	}

	// Token: 0x06000F07 RID: 3847 RVA: 0x00056F4C File Offset: 0x0005514C
	[Token(Token = "0x6000F07")]
	[Address(RVA = "0x2D51F38", Offset = "0x2D51F38", VA = "0x2D51F38")]
	private void ד\u064D\u0655ݫ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("Vector1_d371bd24217449349bd747533d51af6b");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.ӻࡃࠍՊ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Transform transform2;
		Vector3 position5 = transform2.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u061Fת߇ӂ();
			return;
		}
	}

	// Token: 0x06000F08 RID: 3848 RVA: 0x000570F0 File Offset: 0x000552F0
	[Token(Token = "0x6000F08")]
	[Address(RVA = "0x2D52280", Offset = "0x2D52280", VA = "0x2D52280")]
	public void ࢬزڼࠐ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F09 RID: 3849 RVA: 0x00057124 File Offset: 0x00055324
	[Token(Token = "0x6000F09")]
	[Address(RVA = "0x2D523F0", Offset = "0x2D523F0", VA = "0x2D523F0")]
	private void ױԚԩۺ()
	{
		NavMeshAgent navMeshAgent;
		this.ࠅڵࢢԲ = navMeshAgent;
	}

	// Token: 0x06000F0A RID: 3850 RVA: 0x00057138 File Offset: 0x00055338
	[Token(Token = "0x6000F0A")]
	[Address(RVA = "0x2D5244C", Offset = "0x2D5244C", VA = "0x2D5244C")]
	private void \u0817\u0704Ԏڲ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F0B RID: 3851 RVA: 0x00057154 File Offset: 0x00055354
	[Token(Token = "0x6000F0B")]
	[Address(RVA = "0x2D524A8", Offset = "0x2D524A8", VA = "0x2D524A8")]
	private Transform \u07BEٯۈࡥ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F0C RID: 3852 RVA: 0x0005718C File Offset: 0x0005538C
	[Token(Token = "0x6000F0C")]
	[Address(RVA = "0x2D525B0", Offset = "0x2D525B0", VA = "0x2D525B0")]
	private void ࡥշӞھ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("true");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u0816ոٺࡗ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.ٻݨ\u0595\u0870();
			long u0657Ռہԭ = 1L;
			this.\u0657Ռہԭ = (u0657Ռہԭ != 0L);
			return;
		}
	}

	// Token: 0x06000F0D RID: 3853 RVA: 0x00057328 File Offset: 0x00055528
	[Token(Token = "0x6000F0D")]
	[Address(RVA = "0x2D52910", Offset = "0x2D52910", VA = "0x2D52910")]
	private void Ԓ\u05FBثڇ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F0E RID: 3854 RVA: 0x0005735C File Offset: 0x0005555C
	[Token(Token = "0x6000F0E")]
	[Address(RVA = "0x2D52960", Offset = "0x2D52960", VA = "0x2D52960")]
	private void \u06D4ڟڎޜ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("FingerTip");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u06D7\u05F5\u0658ݣ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u0878آ\u05F7ח();
			long u0657Ռہԭ = 1L;
			this.\u0657Ռہԭ = (u0657Ռہԭ != 0L);
			return;
		}
	}

	// Token: 0x06000F0F RID: 3855 RVA: 0x00057504 File Offset: 0x00055704
	[Token(Token = "0x6000F0F")]
	[Address(RVA = "0x2D52E14", Offset = "0x2D52E14", VA = "0x2D52E14")]
	private void ո\u07AA\u05BDࠕ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("5BN");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u05B2މݓ\u070F(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.ࢺࠊ\u05AAࡄ();
			return;
		}
	}

	// Token: 0x06000F10 RID: 3856 RVA: 0x000576A0 File Offset: 0x000558A0
	[Token(Token = "0x6000F10")]
	[Address(RVA = "0x2D5316C", Offset = "0x2D5316C", VA = "0x2D5316C")]
	private Transform \u0590\u0889ܨ\u07F2(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F11 RID: 3857 RVA: 0x000576D8 File Offset: 0x000558D8
	[Token(Token = "0x6000F11")]
	[Address(RVA = "0x2D523D4", Offset = "0x2D523D4", VA = "0x2D523D4")]
	public void ۻכߟ\u05FA()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F12 RID: 3858 RVA: 0x000576F8 File Offset: 0x000558F8
	[Token(Token = "0x6000F12")]
	[Address(RVA = "0x2D53274", Offset = "0x2D53274", VA = "0x2D53274")]
	private Transform \u085Cӽߌ\u0737(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F13 RID: 3859 RVA: 0x00057730 File Offset: 0x00055930
	[Token(Token = "0x6000F13")]
	[Address(RVA = "0x2D5337C", Offset = "0x2D5337C", VA = "0x2D5337C")]
	public void \u05CFӋӯԻ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F14 RID: 3860 RVA: 0x00057764 File Offset: 0x00055964
	[Token(Token = "0x6000F14")]
	[Address(RVA = "0x2D534D0", Offset = "0x2D534D0", VA = "0x2D534D0")]
	public void ޞՐࡖ\u0653()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F15 RID: 3861 RVA: 0x00057784 File Offset: 0x00055984
	[Token(Token = "0x6000F15")]
	[Address(RVA = "0x2D534EC", Offset = "0x2D534EC", VA = "0x2D534EC")]
	private void \u066D\u05BDې߃()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F16 RID: 3862 RVA: 0x000577A0 File Offset: 0x000559A0
	[Token(Token = "0x6000F16")]
	[Address(RVA = "0x2D53548", Offset = "0x2D53548", VA = "0x2D53548")]
	private void ࡩݮڢՠ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F17 RID: 3863 RVA: 0x000577BC File Offset: 0x000559BC
	[Token(Token = "0x6000F17")]
	[Address(RVA = "0x2D535A4", Offset = "0x2D535A4", VA = "0x2D535A4")]
	private Transform ԋ\u081Cߊ\u06E9(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F18 RID: 3864 RVA: 0x000577EC File Offset: 0x000559EC
	[Token(Token = "0x6000F18")]
	[Address(RVA = "0x2D5368C", Offset = "0x2D5368C", VA = "0x2D5368C")]
	private void \u055Cࢯܯ\u0898()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("Damaged Arm");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.ۼ\u06E0\u06FDܖ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u061Fת߇ӂ();
			long u0657Ռہԭ = 1L;
			this.\u0657Ռہԭ = (u0657Ռہԭ != 0L);
			return;
		}
	}

	// Token: 0x06000F19 RID: 3865 RVA: 0x00057994 File Offset: 0x00055B94
	[Token(Token = "0x6000F19")]
	[Address(RVA = "0x2D53AEC", Offset = "0x2D53AEC", VA = "0x2D53AEC")]
	private void \u0832ࢳޤ\u07B5()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("/");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.ܜӎڇ٤(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Transform playerCam = this.Ցԑٶ\u0749.playerCam;
		Vector3 position7 = playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (playerCam != null)
		{
			this.\u05A4ԏիԘ();
			return;
		}
	}

	// Token: 0x06000F1A RID: 3866 RVA: 0x00057B30 File Offset: 0x00055D30
	[Token(Token = "0x6000F1A")]
	[Address(RVA = "0x2D4F634", Offset = "0x2D4F634", VA = "0x2D4F634")]
	private Transform ޕ߇\u060Fټ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F1B RID: 3867 RVA: 0x00057B5C File Offset: 0x00055D5C
	[Token(Token = "0x6000F1B")]
	[Address(RVA = "0x2D53E40", Offset = "0x2D53E40", VA = "0x2D53E40")]
	private Transform ئڌ\u0882ԅ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F1C RID: 3868 RVA: 0x00057B94 File Offset: 0x00055D94
	[Token(Token = "0x6000F1C")]
	[Address(RVA = "0x2D53F48", Offset = "0x2D53F48", VA = "0x2D53F48")]
	private void ژךՈ\u0597()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("Player");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.ޕ߇\u060Fټ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u0701ݛגݸ();
			return;
		}
	}

	// Token: 0x06000F1D RID: 3869 RVA: 0x00057D30 File Offset: 0x00055F30
	[Token(Token = "0x6000F1D")]
	[Address(RVA = "0x2D542A0", Offset = "0x2D542A0", VA = "0x2D542A0")]
	private void ޥ\u089Dڢ\u06E3()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F1E RID: 3870 RVA: 0x00057D4C File Offset: 0x00055F4C
	[Token(Token = "0x6000F1E")]
	[Address(RVA = "0x2D542FC", Offset = "0x2D542FC", VA = "0x2D542FC")]
	private void \u05ADܜࡦێ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F1F RID: 3871 RVA: 0x00057D80 File Offset: 0x00055F80
	[Token(Token = "0x6000F1F")]
	[Address(RVA = "0x2D5434C", Offset = "0x2D5434C", VA = "0x2D5434C")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("On");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.މ\u06E1\u05A4Ӈ(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u0656\u07A9ݓӮ();
			long u0657Ռہԭ = 1L;
			this.\u0657Ռہԭ = (u0657Ռہԭ != 0L);
			return;
		}
	}

	// Token: 0x06000F20 RID: 3872 RVA: 0x00057F24 File Offset: 0x00056124
	[Token(Token = "0x6000F20")]
	[Address(RVA = "0x2D547A8", Offset = "0x2D547A8", VA = "0x2D547A8")]
	private void ࢥ\u081CՕࡋ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F21 RID: 3873 RVA: 0x00057F40 File Offset: 0x00056140
	[Token(Token = "0x6000F21")]
	[Address(RVA = "0x2D4ED34", Offset = "0x2D4ED34", VA = "0x2D4ED34")]
	public void \u07AF\u0708\u05CEߞ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F22 RID: 3874 RVA: 0x00057F60 File Offset: 0x00056160
	[Token(Token = "0x6000F22")]
	[Address(RVA = "0x2D54804", Offset = "0x2D54804", VA = "0x2D54804")]
	private void ߉ې\u07F6Ӭ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F23 RID: 3875 RVA: 0x00057F7C File Offset: 0x0005617C
	[Token(Token = "0x6000F23")]
	[Address(RVA = "0x2D54860", Offset = "0x2D54860", VA = "0x2D54860")]
	public void ՖߦԿԬ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F24 RID: 3876 RVA: 0x00057F9C File Offset: 0x0005619C
	[Token(Token = "0x6000F24")]
	[Address(RVA = "0x2D5487C", Offset = "0x2D5487C", VA = "0x2D5487C")]
	private void ࢳ\u088E٠ݪ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F25 RID: 3877 RVA: 0x00057FB8 File Offset: 0x000561B8
	[Token(Token = "0x6000F25")]
	[Address(RVA = "0x2D548D8", Offset = "0x2D548D8", VA = "0x2D548D8")]
	private void Ӌڤ\u07F1\u066D()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F26 RID: 3878 RVA: 0x00057FEC File Offset: 0x000561EC
	[Token(Token = "0x6000F26")]
	[Address(RVA = "0x2D54928", Offset = "0x2D54928", VA = "0x2D54928")]
	private Transform ࠏӾ٥\u05B2(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F27 RID: 3879 RVA: 0x0005801C File Offset: 0x0005621C
	[Token(Token = "0x6000F27")]
	[Address(RVA = "0x2D54A10", Offset = "0x2D54A10", VA = "0x2D54A10")]
	private void וԣ\u0876Ԟ()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("Holdable");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u085Cӽߌ\u0737(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		long עۅ_u05ED_u = 1L;
		this.עۅ\u05ED\u0599 = (עۅ_u05ED_u != 0L);
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.۰ܦ\u060C\u07BD();
			long u0657Ռہԭ = 1L;
			this.\u0657Ռہԭ = (u0657Ռہԭ != 0L);
			return;
		}
	}

	// Token: 0x06000F28 RID: 3880 RVA: 0x000581C4 File Offset: 0x000563C4
	[Token(Token = "0x6000F28")]
	[Address(RVA = "0x2D54EC0", Offset = "0x2D54EC0", VA = "0x2D54EC0")]
	public void \u0603\u0820Ӿ\u06ED()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F29 RID: 3881 RVA: 0x000581E4 File Offset: 0x000563E4
	[Token(Token = "0x6000F29")]
	[Address(RVA = "0x2D50CA4", Offset = "0x2D50CA4", VA = "0x2D50CA4")]
	private Transform \u0816ոٺࡗ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F2A RID: 3882 RVA: 0x00058214 File Offset: 0x00056414
	[Token(Token = "0x6000F2A")]
	[Address(RVA = "0x2D54EDC", Offset = "0x2D54EDC", VA = "0x2D54EDC")]
	private Transform \u061Fڠւ\u05C7(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F2B RID: 3883 RVA: 0x0005824C File Offset: 0x0005644C
	[Token(Token = "0x6000F2B")]
	[Address(RVA = "0x2D54FE4", Offset = "0x2D54FE4", VA = "0x2D54FE4")]
	private void ޝԖ\u0836\u06D8()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F2C RID: 3884 RVA: 0x00058268 File Offset: 0x00056468
	[Token(Token = "0x6000F2C")]
	[Address(RVA = "0x2D4E630", Offset = "0x2D4E630", VA = "0x2D4E630")]
	public void ԟ\u0831ڜߋ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F2D RID: 3885 RVA: 0x00058288 File Offset: 0x00056488
	[Token(Token = "0x6000F2D")]
	[Address(RVA = "0x2D55040", Offset = "0x2D55040", VA = "0x2D55040")]
	private void \u07AEܘޜذ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F2E RID: 3886 RVA: 0x000582BC File Offset: 0x000564BC
	[Token(Token = "0x6000F2E")]
	[Address(RVA = "0x2D5154C", Offset = "0x2D5154C", VA = "0x2D5154C")]
	public void ݍ\u070Bӥؼ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F2F RID: 3887 RVA: 0x000582DC File Offset: 0x000564DC
	[Token(Token = "0x6000F2F")]
	[Address(RVA = "0x2D55090", Offset = "0x2D55090", VA = "0x2D55090")]
	public void \u05FAؽԦࠇ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F30 RID: 3888 RVA: 0x00058310 File Offset: 0x00056510
	[Token(Token = "0x6000F30")]
	[Address(RVA = "0x2D512A4", Offset = "0x2D512A4", VA = "0x2D512A4")]
	public void \u0656\u07A9ݓӮ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F31 RID: 3889 RVA: 0x00058344 File Offset: 0x00056544
	[Token(Token = "0x6000F31")]
	[Address(RVA = "0x2D551E4", Offset = "0x2D551E4", VA = "0x2D551E4")]
	private void نո\u0599\u0589()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F32 RID: 3890 RVA: 0x00058360 File Offset: 0x00056560
	[Token(Token = "0x6000F32")]
	[Address(RVA = "0x2D55240", Offset = "0x2D55240", VA = "0x2D55240")]
	private void ߓ\u06E3\u05C7ۋ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F33 RID: 3891 RVA: 0x0005837C File Offset: 0x0005657C
	[Token(Token = "0x6000F33")]
	[Address(RVA = "0x2D5529C", Offset = "0x2D5529C", VA = "0x2D5529C")]
	public void \u05A7߇\u066Bڅ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F34 RID: 3892 RVA: 0x0005839C File Offset: 0x0005659C
	[Token(Token = "0x6000F34")]
	[Address(RVA = "0x2D552B8", Offset = "0x2D552B8", VA = "0x2D552B8")]
	private void ݶߔ\u081Aպ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F35 RID: 3893 RVA: 0x000583B8 File Offset: 0x000565B8
	[Token(Token = "0x6000F35")]
	[Address(RVA = "0x2D55314", Offset = "0x2D55314", VA = "0x2D55314")]
	private void Start()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F36 RID: 3894 RVA: 0x000583D4 File Offset: 0x000565D4
	[Token(Token = "0x6000F36")]
	[Address(RVA = "0x2D55370", Offset = "0x2D55370", VA = "0x2D55370")]
	public void տࠑڣ\u05A9()
	{
		if (!true)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F37 RID: 3895 RVA: 0x00058404 File Offset: 0x00056604
	[Token(Token = "0x6000F37")]
	[Address(RVA = "0x2D50398", Offset = "0x2D50398", VA = "0x2D50398")]
	private Transform \u06D7\u05F5\u0658ݣ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F38 RID: 3896 RVA: 0x0005843C File Offset: 0x0005663C
	[Token(Token = "0x6000F38")]
	[Address(RVA = "0x2D554C4", Offset = "0x2D554C4", VA = "0x2D554C4")]
	private void \u05AFߏ\u0897Ӝ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F39 RID: 3897 RVA: 0x00058470 File Offset: 0x00056670
	[Token(Token = "0x6000F39")]
	[Address(RVA = "0x2D55514", Offset = "0x2D55514", VA = "0x2D55514")]
	private void ݲן٤\u088F()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag("isLava");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.\u0602\u0558\u066B\u06E2(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		float speed;
		this.ࠅڵࢢԲ.speed = speed;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u0878ӱݫ\u060E();
			return;
		}
	}

	// Token: 0x06000F3A RID: 3898 RVA: 0x00058600 File Offset: 0x00056800
	[Token(Token = "0x6000F3A")]
	[Address(RVA = "0x2D50F30", Offset = "0x2D50F30", VA = "0x2D50F30")]
	public void ࡠ\u055Cۄ\u060A()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F3B RID: 3899 RVA: 0x00058620 File Offset: 0x00056820
	[Token(Token = "0x6000F3B")]
	[Address(RVA = "0x2D4DBFC", Offset = "0x2D4DBFC", VA = "0x2D4DBFC")]
	public void ٨\u0601ӻ߃()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F3C RID: 3900 RVA: 0x00058640 File Offset: 0x00056840
	[Token(Token = "0x6000F3C")]
	[Address(RVA = "0x2D539E4", Offset = "0x2D539E4", VA = "0x2D539E4")]
	private Transform ۼ\u06E0\u06FDܖ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F3D RID: 3901 RVA: 0x00058678 File Offset: 0x00056878
	[Token(Token = "0x6000F3D")]
	[Address(RVA = "0x2D5586C", Offset = "0x2D5586C", VA = "0x2D5586C")]
	private void ԦӔԁֆ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F3E RID: 3902 RVA: 0x00058694 File Offset: 0x00056894
	[Token(Token = "0x6000F3E")]
	[Address(RVA = "0x2D546A0", Offset = "0x2D546A0", VA = "0x2D546A0")]
	private Transform މ\u06E1\u05A4Ӈ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F3F RID: 3903 RVA: 0x000586CC File Offset: 0x000568CC
	[Token(Token = "0x6000F3F")]
	[Address(RVA = "0x2D558C8", Offset = "0x2D558C8", VA = "0x2D558C8")]
	public void ߈ۅܫߦ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F40 RID: 3904 RVA: 0x000586EC File Offset: 0x000568EC
	[Token(Token = "0x6000F40")]
	[Address(RVA = "0x2D51DE4", Offset = "0x2D51DE4", VA = "0x2D51DE4")]
	public void ࢺࠊ\u05AAࡄ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F41 RID: 3905 RVA: 0x00058720 File Offset: 0x00056920
	[Token(Token = "0x6000F41")]
	[Address(RVA = "0x2D558E4", Offset = "0x2D558E4", VA = "0x2D558E4")]
	private Transform ހݸվߞ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F42 RID: 3906 RVA: 0x0005874C File Offset: 0x0005694C
	[Token(Token = "0x6000F42")]
	[Address(RVA = "0x2D54D6C", Offset = "0x2D54D6C", VA = "0x2D54D6C")]
	public void ۰ܦ\u060C\u07BD()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000F43 RID: 3907 RVA: 0x00058770 File Offset: 0x00056970
	[Token(Token = "0x6000F43")]
	[Address(RVA = "0x2D559CC", Offset = "0x2D559CC", VA = "0x2D559CC")]
	private void Ӗ\u081Eٶ\u060E()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F44 RID: 3908 RVA: 0x000587A4 File Offset: 0x000569A4
	[Token(Token = "0x6000F44")]
	[Address(RVA = "0x2D55A1C", Offset = "0x2D55A1C", VA = "0x2D55A1C")]
	public void ݜމ\u083Aޥ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F45 RID: 3909 RVA: 0x000587D8 File Offset: 0x000569D8
	[Token(Token = "0x6000F45")]
	[Address(RVA = "0x2D55B70", Offset = "0x2D55B70", VA = "0x2D55B70")]
	private Transform \u05C8ݒچ\u0595(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F46 RID: 3910 RVA: 0x00058808 File Offset: 0x00056A08
	[Token(Token = "0x6000F46")]
	[Address(RVA = "0x2D55C58", Offset = "0x2D55C58", VA = "0x2D55C58")]
	private Transform ӳحٯم(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F47 RID: 3911 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000F47")]
	[Address(RVA = "0x2D55D40", Offset = "0x2D55D40", VA = "0x2D55D40")]
	private void \u05FEօ\u06D7ࡁ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000F48 RID: 3912 RVA: 0x00058834 File Offset: 0x00056A34
	[Token(Token = "0x6000F48")]
	[Address(RVA = "0x2D55D9C", Offset = "0x2D55D9C", VA = "0x2D55D9C")]
	private void ފՖߢ\u059B()
	{
		NavMeshPathStatus pathStatus = this.ࠅڵࢢԲ.pathStatus;
		this.\u0597դ\u05AC\u088D = pathStatus;
		GameObject[] u05C7Ԫ_u055Cܔ = GameObject.FindGameObjectsWithTag(" hours. You were banned because of ");
		this.\u05C7Ԫ\u055Cܔ = u05C7Ԫ_u055Cܔ;
		GameObject[] u05C7Ԫ_u055Cܔ2 = this.\u05C7Ԫ\u055Cܔ;
		Transform transform = this.ࢻ\u087F\u0831۱(u05C7Ԫ_u055Cܔ2);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
		NavMeshAgent navMeshAgent = this.ࠅڵࢢԲ;
		float ގܪ_u07F6ޘ = this.ގܪ\u07F6ޘ;
		float speed;
		navMeshAgent.speed = speed;
		NavMeshAgent navMeshAgent2 = this.ࠅڵࢢԲ;
		PatrolAI.Dave ցԑٶ_u = this.Ցԑٶ\u0749;
		Vector3 position6 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u2 = this.Ցԑٶ\u0749;
		Vector3 position7 = this.Ցԑٶ\u0749.playerCam.position;
		PatrolAI.Dave ցԑٶ_u3 = this.Ցԑٶ\u0749;
		GameObject rightArmIK = this.Ցԑٶ\u0749.rightArmIK;
		long active = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.\u0657Ռہԭ)
		{
			this.\u0656\u07A9ݓӮ();
			return;
		}
	}

	// Token: 0x06000F49 RID: 3913 RVA: 0x000589C0 File Offset: 0x00056BC0
	[Token(Token = "0x6000F49")]
	[Address(RVA = "0x2D561DC", Offset = "0x2D561DC", VA = "0x2D561DC")]
	private void \u070Fߨ\u05B0ۈ()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F4A RID: 3914 RVA: 0x000589DC File Offset: 0x00056BDC
	[Token(Token = "0x6000F4A")]
	[Address(RVA = "0x2D4E9A4", Offset = "0x2D4E9A4", VA = "0x2D4E9A4")]
	private Transform \u05B2މݓ\u070F(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F4B RID: 3915 RVA: 0x00058A0C File Offset: 0x00056C0C
	[Token(Token = "0x6000F4B")]
	[Address(RVA = "0x2D4E150", Offset = "0x2D4E150", VA = "0x2D4E150")]
	public void ڮ\u06DFخ\u0602()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F4C RID: 3916 RVA: 0x00058A2C File Offset: 0x00056C2C
	[Token(Token = "0x6000F4C")]
	[Address(RVA = "0x2D56238", Offset = "0x2D56238", VA = "0x2D56238")]
	public void ۂىԡظ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F4D RID: 3917 RVA: 0x00058A58 File Offset: 0x00056C58
	[Token(Token = "0x6000F4D")]
	[Address(RVA = "0x2D5638C", Offset = "0x2D5638C", VA = "0x2D5638C")]
	private Transform ޗ\u066Cԍڑ(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F4E RID: 3918 RVA: 0x00058A84 File Offset: 0x00056C84
	[Token(Token = "0x6000F4E")]
	[Address(RVA = "0x2D56474", Offset = "0x2D56474", VA = "0x2D56474")]
	private void \u0708\u0601օޝ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F4F RID: 3919 RVA: 0x00058AB8 File Offset: 0x00056CB8
	[Token(Token = "0x6000F4F")]
	[Address(RVA = "0x2D51864", Offset = "0x2D51864", VA = "0x2D51864")]
	public void \u07A9ے\u0557Ӱ()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F50 RID: 3920 RVA: 0x00058AD8 File Offset: 0x00056CD8
	[Token(Token = "0x6000F50")]
	[Address(RVA = "0x2D564C4", Offset = "0x2D564C4", VA = "0x2D564C4")]
	private void ۆڛߟ\u05A0()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.ࠅڵࢢԲ = component;
	}

	// Token: 0x06000F51 RID: 3921 RVA: 0x00058AF4 File Offset: 0x00056CF4
	[Token(Token = "0x6000F51")]
	[Address(RVA = "0x2D56520", Offset = "0x2D56520", VA = "0x2D56520")]
	private void س\u083F\u0606\u082F()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F52 RID: 3922 RVA: 0x00058B28 File Offset: 0x00056D28
	[Token(Token = "0x6000F52")]
	[Address(RVA = "0x2D56570", Offset = "0x2D56570", VA = "0x2D56570")]
	private void ߋޣࢠڍ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F53 RID: 3923 RVA: 0x00058B5C File Offset: 0x00056D5C
	[Token(Token = "0x6000F53")]
	[Address(RVA = "0x2D565C0", Offset = "0x2D565C0", VA = "0x2D565C0")]
	public void Ӓߙߏی()
	{
		this.ٳ\u07F3ࢷԜ.Play();
	}

	// Token: 0x06000F54 RID: 3924 RVA: 0x00058B7C File Offset: 0x00056D7C
	[Token(Token = "0x6000F54")]
	[Address(RVA = "0x2D4D6B8", Offset = "0x2D4D6B8", VA = "0x2D4D6B8")]
	public void ٻݨ\u0595\u0870()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F55 RID: 3925 RVA: 0x00058BAC File Offset: 0x00056DAC
	[Token(Token = "0x6000F55")]
	[Address(RVA = "0x2D565DC", Offset = "0x2D565DC", VA = "0x2D565DC")]
	private void \u05FEӦ\u061AӨ()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
		float յ_u0732ډӬ = this.յ\u0732ډӬ;
	}

	// Token: 0x06000F56 RID: 3926 RVA: 0x00058BE0 File Offset: 0x00056DE0
	[Token(Token = "0x6000F56")]
	[Address(RVA = "0x2D560F4", Offset = "0x2D560F4", VA = "0x2D560F4")]
	private Transform ࢻ\u087F\u0831۱(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x06000F57 RID: 3927 RVA: 0x00058C10 File Offset: 0x00056E10
	[Token(Token = "0x6000F57")]
	[Address(RVA = "0x2D52CC0", Offset = "0x2D52CC0", VA = "0x2D52CC0")]
	public void \u0878آ\u05F7ח()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		PhotonView ӆ_u07A6ࡓ_u086D = this.Ӆ\u07A6ࡓ\u086D;
	}

	// Token: 0x06000F58 RID: 3928 RVA: 0x00058C44 File Offset: 0x00056E44
	[Token(Token = "0x6000F58")]
	[Address(RVA = "0x2D5662C", Offset = "0x2D5662C", VA = "0x2D5662C")]
	private Transform \u065Dدտ\u065E(GameObject[] ӆ\u05FFӥج)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Transform result;
		return result;
	}

	// Token: 0x0400020F RID: 527
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400020F")]
	private NavMeshAgent ࠅڵࢢԲ;

	// Token: 0x04000210 RID: 528
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000210")]
	private GameObject[] \u05C7Ԫ\u055Cܔ;

	// Token: 0x04000211 RID: 529
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000211")]
	public float յ\u0732ډӬ = (float)16512;

	// Token: 0x04000212 RID: 530
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000212")]
	public Transform Ӌڻࡈأ;

	// Token: 0x04000213 RID: 531
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000213")]
	public AiTarget ӟ\u060A\u0704ߒ;

	// Token: 0x04000214 RID: 532
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000214")]
	public float ࢠԿ\u081C\u0821;

	// Token: 0x04000215 RID: 533
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000215")]
	public float ގܪ\u07F6ޘ;

	// Token: 0x04000216 RID: 534
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000216")]
	private bool עۅ\u05ED\u0599;

	// Token: 0x04000217 RID: 535
	[FieldOffset(Offset = "0x4C")]
	[Token(Token = "0x4000217")]
	private NavMeshPathStatus \u0597դ\u05AC\u088D;

	// Token: 0x04000218 RID: 536
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000218")]
	public float פ߈ک\u0732;

	// Token: 0x04000219 RID: 537
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000219")]
	public AudioSource ٳ\u07F3ࢷԜ;

	// Token: 0x0400021A RID: 538
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400021A")]
	public PhotonView Ӆ\u07A6ࡓ\u086D;

	// Token: 0x0400021B RID: 539
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x400021B")]
	private bool \u0657Ռہԭ;

	// Token: 0x0400021C RID: 540
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x400021C")]
	public PatrolAI.Dave Ցԑٶ\u0749;

	// Token: 0x02000067 RID: 103
	[Token(Token = "0x2000067")]
	[Serializable]
	public struct Dave
	{
		// Token: 0x0400021D RID: 541
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400021D")]
		public GameObject leftArmTarget;

		// Token: 0x0400021E RID: 542
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x400021E")]
		public GameObject leftArmIK;

		// Token: 0x0400021F RID: 543
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400021F")]
		public GameObject rightArmTarget;

		// Token: 0x04000220 RID: 544
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000220")]
		public GameObject rightArmIK;

		// Token: 0x04000221 RID: 545
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000221")]
		public Transform playerCam;
	}
}
