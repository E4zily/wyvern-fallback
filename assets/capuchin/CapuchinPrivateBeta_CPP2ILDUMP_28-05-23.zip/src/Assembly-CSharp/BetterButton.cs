﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000099 RID: 153
[Token(Token = "0x2000099")]
public class BetterButton : MonoBehaviour
{
	// Token: 0x060016C2 RID: 5826 RVA: 0x00080F14 File Offset: 0x0007F114
	[Token(Token = "0x60016C2")]
	[Address(RVA = "0x2C140F8", Offset = "0x2C140F8", VA = "0x2C140F8")]
	private void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016C3 RID: 5827 RVA: 0x00080F40 File Offset: 0x0007F140
	[Token(Token = "0x60016C3")]
	[Address(RVA = "0x2C141BC", Offset = "0x2C141BC", VA = "0x2C141BC")]
	private void \u0748\u05F4Նۏ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016C4 RID: 5828 RVA: 0x00080F6C File Offset: 0x0007F16C
	[Token(Token = "0x60016C4")]
	[Address(RVA = "0x2C14280", Offset = "0x2C14280", VA = "0x2C14280")]
	private void ࢳ\u06D8Ԙ\u05FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016C5 RID: 5829 RVA: 0x00080F98 File Offset: 0x0007F198
	[Token(Token = "0x60016C5")]
	[Address(RVA = "0x2C14344", Offset = "0x2C14344", VA = "0x2C14344")]
	private void \u07BF\u0705\u0824ڮ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016C6 RID: 5830 RVA: 0x00080FC4 File Offset: 0x0007F1C4
	[Token(Token = "0x60016C6")]
	[Address(RVA = "0x2C14408", Offset = "0x2C14408", VA = "0x2C14408")]
	private void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016C7 RID: 5831 RVA: 0x00080FF0 File Offset: 0x0007F1F0
	[Token(Token = "0x60016C7")]
	[Address(RVA = "0x2C144CC", Offset = "0x2C144CC", VA = "0x2C144CC")]
	private void Պ\u07F7\u066AՅ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016C8 RID: 5832 RVA: 0x0008101C File Offset: 0x0007F21C
	[Token(Token = "0x60016C8")]
	[Address(RVA = "0x2C14590", Offset = "0x2C14590", VA = "0x2C14590")]
	private void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016C9 RID: 5833 RVA: 0x00081048 File Offset: 0x0007F248
	[Token(Token = "0x60016C9")]
	[Address(RVA = "0x2C14654", Offset = "0x2C14654", VA = "0x2C14654")]
	private void \u0879\u0748ߙݥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016CA RID: 5834 RVA: 0x00081074 File Offset: 0x0007F274
	[Token(Token = "0x60016CA")]
	[Address(RVA = "0x2C14718", Offset = "0x2C14718", VA = "0x2C14718")]
	private void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016CB RID: 5835 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60016CB")]
	[Address(RVA = "0x2C147DC", Offset = "0x2C147DC", VA = "0x2C147DC")]
	private void \u07B3\u07BD\u05FF\u0859(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016CC RID: 5836 RVA: 0x000810A0 File Offset: 0x0007F2A0
	[Token(Token = "0x60016CC")]
	[Address(RVA = "0x2C148A0", Offset = "0x2C148A0", VA = "0x2C148A0")]
	private void ܫ\u085Eہӝ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016CD RID: 5837 RVA: 0x000810CC File Offset: 0x0007F2CC
	[Token(Token = "0x60016CD")]
	[Address(RVA = "0x2C14964", Offset = "0x2C14964", VA = "0x2C14964")]
	public BetterButton()
	{
	}

	// Token: 0x060016CE RID: 5838 RVA: 0x000810E0 File Offset: 0x0007F2E0
	[Token(Token = "0x60016CE")]
	[Address(RVA = "0x2C1496C", Offset = "0x2C1496C", VA = "0x2C1496C")]
	private void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.ٵ\u061Eӊօ.Invoke();
	}

	// Token: 0x060016CF RID: 5839 RVA: 0x0008110C File Offset: 0x0007F30C
	[Token(Token = "0x60016CF")]
	[Address(RVA = "0x2C14A30", Offset = "0x2C14A30", VA = "0x2C14A30")]
	private void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		bool flag = \u07FEל\u05AC\u0877;
	}

	// Token: 0x060016D0 RID: 5840 RVA: 0x00081130 File Offset: 0x0007F330
	[Token(Token = "0x60016D0")]
	[Address(RVA = "0x2C14AF4", Offset = "0x2C14AF4", VA = "0x2C14AF4")]
	private void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		bool flag = \u07FEל\u05AC\u0877;
		this.ٵ\u061Eӊօ.Invoke();
	}

	// Token: 0x060016D1 RID: 5841 RVA: 0x00081160 File Offset: 0x0007F360
	[Token(Token = "0x60016D1")]
	[Address(RVA = "0x2C14BB8", Offset = "0x2C14BB8", VA = "0x2C14BB8")]
	private void \u0885ےܝ\u05BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016D2 RID: 5842 RVA: 0x0008118C File Offset: 0x0007F38C
	[Token(Token = "0x60016D2")]
	[Address(RVA = "0x2C14C7C", Offset = "0x2C14C7C", VA = "0x2C14C7C")]
	private void ߃\u0602\u0891߇(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016D3 RID: 5843 RVA: 0x000811B8 File Offset: 0x0007F3B8
	[Token(Token = "0x60016D3")]
	[Address(RVA = "0x2C14D40", Offset = "0x2C14D40", VA = "0x2C14D40")]
	private void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.ٵ\u061Eӊօ.Invoke();
	}

	// Token: 0x060016D4 RID: 5844 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60016D4")]
	[Address(RVA = "0x2C14E04", Offset = "0x2C14E04", VA = "0x2C14E04")]
	private void \u05F8ڛߠ\u05BC(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016D5 RID: 5845 RVA: 0x000811E4 File Offset: 0x0007F3E4
	[Token(Token = "0x60016D5")]
	[Address(RVA = "0x2C14EC8", Offset = "0x2C14EC8", VA = "0x2C14EC8")]
	private void ࢲ\u061C\u0817ݽ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016D6 RID: 5846 RVA: 0x00081210 File Offset: 0x0007F410
	[Token(Token = "0x60016D6")]
	[Address(RVA = "0x2C14F8C", Offset = "0x2C14F8C", VA = "0x2C14F8C")]
	private void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016D7 RID: 5847 RVA: 0x0008123C File Offset: 0x0007F43C
	[Token(Token = "0x60016D7")]
	[Address(RVA = "0x2C15050", Offset = "0x2C15050", VA = "0x2C15050")]
	private void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.ٵ\u061Eӊօ.Invoke();
	}

	// Token: 0x060016D8 RID: 5848 RVA: 0x00081268 File Offset: 0x0007F468
	[Token(Token = "0x60016D8")]
	[Address(RVA = "0x2C15114", Offset = "0x2C15114", VA = "0x2C15114")]
	private void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016D9 RID: 5849 RVA: 0x00081294 File Offset: 0x0007F494
	[Token(Token = "0x60016D9")]
	[Address(RVA = "0x2C151D8", Offset = "0x2C151D8", VA = "0x2C151D8")]
	private void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.ٵ\u061Eӊօ.Invoke();
	}

	// Token: 0x060016DA RID: 5850 RVA: 0x000812C0 File Offset: 0x0007F4C0
	[Token(Token = "0x60016DA")]
	[Address(RVA = "0x2C1529C", Offset = "0x2C1529C", VA = "0x2C1529C")]
	private void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016DB RID: 5851 RVA: 0x000812EC File Offset: 0x0007F4EC
	[Token(Token = "0x60016DB")]
	[Address(RVA = "0x2C15360", Offset = "0x2C15360", VA = "0x2C15360")]
	private void \u0872\u0610ۅ\u06E1(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016DC RID: 5852 RVA: 0x00081318 File Offset: 0x0007F518
	[Token(Token = "0x60016DC")]
	[Address(RVA = "0x2C15424", Offset = "0x2C15424", VA = "0x2C15424")]
	private void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.ٵ\u061Eӊօ.Invoke();
	}

	// Token: 0x060016DD RID: 5853 RVA: 0x00081344 File Offset: 0x0007F544
	[Token(Token = "0x60016DD")]
	[Address(RVA = "0x2C154E8", Offset = "0x2C154E8", VA = "0x2C154E8")]
	private void ܮݫ߅ࡃ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		bool flag = \u07FEל\u05AC\u0877;
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016DE RID: 5854 RVA: 0x00081374 File Offset: 0x0007F574
	[Token(Token = "0x60016DE")]
	[Address(RVA = "0x2C155AC", Offset = "0x2C155AC", VA = "0x2C155AC")]
	private void \u085Cݯژ\u05FA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016DF RID: 5855 RVA: 0x000813A0 File Offset: 0x0007F5A0
	[Token(Token = "0x60016DF")]
	[Address(RVA = "0x2C15670", Offset = "0x2C15670", VA = "0x2C15670")]
	private void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.ٵ\u061Eӊօ.Invoke();
	}

	// Token: 0x060016E0 RID: 5856 RVA: 0x000813CC File Offset: 0x0007F5CC
	[Token(Token = "0x60016E0")]
	[Address(RVA = "0x2C15734", Offset = "0x2C15734", VA = "0x2C15734")]
	private void \u0609ۯ\u05B4ؼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016E1 RID: 5857 RVA: 0x000813F8 File Offset: 0x0007F5F8
	[Token(Token = "0x60016E1")]
	[Address(RVA = "0x2C157F8", Offset = "0x2C157F8", VA = "0x2C157F8")]
	private void \u0872יԁӦ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016E2 RID: 5858 RVA: 0x00081424 File Offset: 0x0007F624
	[Token(Token = "0x60016E2")]
	[Address(RVA = "0x2C158BC", Offset = "0x2C158BC", VA = "0x2C158BC")]
	private void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.ٵ\u061Eӊօ.Invoke();
	}

	// Token: 0x060016E3 RID: 5859 RVA: 0x00081450 File Offset: 0x0007F650
	[Token(Token = "0x60016E3")]
	[Address(RVA = "0x2C15980", Offset = "0x2C15980", VA = "0x2C15980")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.ٵ\u061Eӊօ.Invoke();
	}

	// Token: 0x060016E4 RID: 5860 RVA: 0x0008147C File Offset: 0x0007F67C
	[Token(Token = "0x60016E4")]
	[Address(RVA = "0x2C15A44", Offset = "0x2C15A44", VA = "0x2C15A44")]
	private void ت\u05F9ޅ\u059A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x060016E5 RID: 5861 RVA: 0x000814A8 File Offset: 0x0007F6A8
	[Token(Token = "0x60016E5")]
	[Address(RVA = "0x2C15B08", Offset = "0x2C15B08", VA = "0x2C15B08")]
	private void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.ٵ\u061Eӊօ.Invoke();
	}

	// Token: 0x060016E6 RID: 5862 RVA: 0x000814D4 File Offset: 0x0007F6D4
	[Token(Token = "0x60016E6")]
	[Address(RVA = "0x2C15BCC", Offset = "0x2C15BCC", VA = "0x2C15BCC")]
	private void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
	}

	// Token: 0x060016E7 RID: 5863 RVA: 0x000814F4 File Offset: 0x0007F6F4
	[Token(Token = "0x60016E7")]
	[Address(RVA = "0x2C15C90", Offset = "0x2C15C90", VA = "0x2C15C90")]
	private void \u083Eܙ\u07FD\u0706(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.حՑ\u05A4ࡑ.Invoke();
	}

	// Token: 0x040002D8 RID: 728
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002D8")]
	public UnityEvent ٵ\u061Eӊօ;

	// Token: 0x040002D9 RID: 729
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002D9")]
	public UnityEvent حՑ\u05A4ࡑ;
}
