﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200004D RID: 77
[Token(Token = "0x200004D")]
public class ColorButton : MonoBehaviour
{
	// Token: 0x06000ABA RID: 2746 RVA: 0x00039D90 File Offset: 0x00037F90
	[Token(Token = "0x6000ABA")]
	[Address(RVA = "0x2923D04", Offset = "0x2923D04", VA = "0x2923D04")]
	private void Ԉ۴ࡉࢬ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ԯ\u07F8ܨӔ();
		}
	}

	// Token: 0x06000ABB RID: 2747 RVA: 0x00039DD0 File Offset: 0x00037FD0
	[Token(Token = "0x6000ABB")]
	[Address(RVA = "0x2923ED0", Offset = "0x2923ED0", VA = "0x2923ED0")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "\n";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ԯ\u07F8ܨӔ();
	}

	// Token: 0x06000ABC RID: 2748 RVA: 0x00039E1C File Offset: 0x0003801C
	[Token(Token = "0x6000ABC")]
	[Address(RVA = "0x2923FC4", Offset = "0x2923FC4", VA = "0x2923FC4")]
	private void \u0654ޛ\u07FAذ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			return;
		}
	}

	// Token: 0x06000ABD RID: 2749 RVA: 0x00039E50 File Offset: 0x00038050
	[Token(Token = "0x6000ABD")]
	[Address(RVA = "0x29241A0", Offset = "0x29241A0", VA = "0x29241A0")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "KeyPos";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.כ\u0702ݬ\u07F4();
	}

	// Token: 0x06000ABE RID: 2750 RVA: 0x00039E9C File Offset: 0x0003809C
	[Token(Token = "0x6000ABE")]
	[Address(RVA = "0x29243A8", Offset = "0x29243A8", VA = "0x29243A8")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
	}

	// Token: 0x06000ABF RID: 2751 RVA: 0x00039ED4 File Offset: 0x000380D4
	[Token(Token = "0x6000ABF")]
	[Address(RVA = "0x29245E4", Offset = "0x29245E4", VA = "0x29245E4")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == " and the correct version is ";
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ӳܠԇߋ();
	}

	// Token: 0x06000AC0 RID: 2752 RVA: 0x00039F10 File Offset: 0x00038110
	[Token(Token = "0x6000AC0")]
	[Address(RVA = "0x2924820", Offset = "0x2924820", VA = "0x2924820")]
	private void \u089F\u085Fէ\u059A()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.٠ԂՐڙ();
		}
	}

	// Token: 0x06000AC1 RID: 2753 RVA: 0x00039F50 File Offset: 0x00038150
	[Token(Token = "0x6000AC1")]
	[Address(RVA = "0x29249F8", Offset = "0x29249F8", VA = "0x29249F8")]
	public void \u059B\u081F\u05FEڂ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Failed to get catalog, cosmetic name, and price. Exact error details is: ";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.Ӏ\u07B4إ\u082A();
	}

	// Token: 0x06000AC2 RID: 2754 RVA: 0x00039F9C File Offset: 0x0003819C
	[Token(Token = "0x6000AC2")]
	[Address(RVA = "0x2924C34", Offset = "0x2924C34", VA = "0x2924C34")]
	private void \u0872މࢮՃ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.գޠӾԲ();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AC3 RID: 2755 RVA: 0x00039FE4 File Offset: 0x000381E4
	[Token(Token = "0x6000AC3")]
	[Address(RVA = "0x2924E10", Offset = "0x2924E10", VA = "0x2924E10")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HandR";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.יࡓߞڦ();
	}

	// Token: 0x06000AC4 RID: 2756 RVA: 0x0003A030 File Offset: 0x00038230
	[Token(Token = "0x6000AC4")]
	[Address(RVA = "0x2925038", Offset = "0x2925038", VA = "0x2925038")]
	private void ژךՈ\u0597()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.Ռ\u05EEߠԇ();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AC5 RID: 2757 RVA: 0x0003A078 File Offset: 0x00038278
	[Token(Token = "0x6000AC5")]
	[Address(RVA = "0x2925208", Offset = "0x2925208", VA = "0x2925208")]
	public void \u05AD\u0881ࡆݡ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "make more points bobo";
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
	}

	// Token: 0x06000AC6 RID: 2758 RVA: 0x0003A0AC File Offset: 0x000382AC
	[Token(Token = "0x6000AC6")]
	[Address(RVA = "0x2925444", Offset = "0x2925444", VA = "0x2925444")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ޚئ\u089Bܖ();
	}

	// Token: 0x06000AC7 RID: 2759 RVA: 0x0003A0F8 File Offset: 0x000382F8
	[Token(Token = "0x6000AC7")]
	[Address(RVA = "0x2925664", Offset = "0x2925664", VA = "0x2925664")]
	private void \u0892ܒܬޓ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ڠը\u0736\u055C();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AC8 RID: 2760 RVA: 0x0003A140 File Offset: 0x00038340
	[Token(Token = "0x6000AC8")]
	[Address(RVA = "0x2925854", Offset = "0x2925854", VA = "0x2925854")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Body";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		ColorManager.ލ\u0882ײࢲ.\u05F6\u0878ݙ\u07BD();
	}

	// Token: 0x06000AC9 RID: 2761 RVA: 0x0003A188 File Offset: 0x00038388
	[Token(Token = "0x6000AC9")]
	[Address(RVA = "0x2925A68", Offset = "0x2925A68", VA = "0x2925A68")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Thumb";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ءۄڥࢣ();
	}

	// Token: 0x06000ACA RID: 2762 RVA: 0x0003A1D4 File Offset: 0x000383D4
	[Token(Token = "0x6000ACA")]
	[Address(RVA = "0x2925C78", Offset = "0x2925C78", VA = "0x2925C78")]
	private void \u061B\u05EEوۈ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ԝץԡ\u0822();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000ACB RID: 2763 RVA: 0x0003A21C File Offset: 0x0003841C
	[Token(Token = "0x6000ACB")]
	[Address(RVA = "0x2925E58", Offset = "0x2925E58", VA = "0x2925E58")]
	private void Ԡݘעࠀ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ژӐӽڙ();
		}
	}

	// Token: 0x06000ACC RID: 2764 RVA: 0x0003A25C File Offset: 0x0003845C
	[Token(Token = "0x6000ACC")]
	[Address(RVA = "0x2926030", Offset = "0x2926030", VA = "0x2926030")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "META";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ࢢ\u0886ࢨԳ();
	}

	// Token: 0x06000ACD RID: 2765 RVA: 0x0003A2A8 File Offset: 0x000384A8
	[Token(Token = "0x6000ACD")]
	[Address(RVA = "0x2926268", Offset = "0x2926268", VA = "0x2926268")]
	private void Ӧد\u060Eࡏ()
	{
		if (true)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.Ӡ\u0836٥\u060F();
		}
	}

	// Token: 0x06000ACE RID: 2766 RVA: 0x0003A2E0 File Offset: 0x000384E0
	[Token(Token = "0x6000ACE")]
	[Address(RVA = "0x2926310", Offset = "0x2926310", VA = "0x2926310")]
	public void Փ\u06DF\u0839ԟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Faild To Add Winner Money: ";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.Ӏ\u07B4إ\u082A();
	}

	// Token: 0x06000ACF RID: 2767 RVA: 0x0003A32C File Offset: 0x0003852C
	[Token(Token = "0x6000ACF")]
	[Address(RVA = "0x2926404", Offset = "0x2926404", VA = "0x2926404")]
	private void Ҿࢹؼס()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.\u07BA\u083Dӡ\u0732();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AD0 RID: 2768 RVA: 0x0003A374 File Offset: 0x00038574
	[Token(Token = "0x6000AD0")]
	[Address(RVA = "0x29265D0", Offset = "0x29265D0", VA = "0x29265D0")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == " and the correct version is ";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ژӐӽڙ();
	}

	// Token: 0x06000AD1 RID: 2769 RVA: 0x0003A3BC File Offset: 0x000385BC
	[Token(Token = "0x6000AD1")]
	[Address(RVA = "0x29266C4", Offset = "0x29266C4", VA = "0x29266C4")]
	private void \u05F7ԝߠӱ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.\u05EEܓԘӰ();
		}
	}

	// Token: 0x06000AD2 RID: 2770 RVA: 0x0003A3FC File Offset: 0x000385FC
	[Token(Token = "0x6000AD2")]
	[Address(RVA = "0x29268B4", Offset = "0x29268B4", VA = "0x29268B4")]
	private void ى߁ٱՏ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ݮ\u05B0\u0608ڹ();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AD3 RID: 2771 RVA: 0x0003A444 File Offset: 0x00038644
	[Token(Token = "0x6000AD3")]
	[Address(RVA = "0x2926A8C", Offset = "0x2926A8C", VA = "0x2926A8C")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "M/d/yyyy";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.\u05AD\u0640۰ԯ();
	}

	// Token: 0x06000AD4 RID: 2772 RVA: 0x0003A490 File Offset: 0x00038690
	[Token(Token = "0x6000AD4")]
	[Address(RVA = "0x2926CA0", Offset = "0x2926CA0", VA = "0x2926CA0")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "hand 1";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.բҼم\u086F();
	}

	// Token: 0x06000AD5 RID: 2773 RVA: 0x0003A4DC File Offset: 0x000386DC
	[Token(Token = "0x6000AD5")]
	[Address(RVA = "0x2926EC4", Offset = "0x2926EC4", VA = "0x2926EC4")]
	private void \u060B\u0614\u0821ע()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ނը\u0732\u0558();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AD6 RID: 2774 RVA: 0x0003A524 File Offset: 0x00038724
	[Token(Token = "0x6000AD6")]
	[Address(RVA = "0x2927098", Offset = "0x2927098", VA = "0x2927098")]
	public void \u05AB\u05BEӞނ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Bruh i cannot go here you stupid L bozo";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.գԁܐխ();
	}

	// Token: 0x06000AD7 RID: 2775 RVA: 0x0003A570 File Offset: 0x00038770
	[Token(Token = "0x6000AD7")]
	[Address(RVA = "0x29272A8", Offset = "0x29272A8", VA = "0x29272A8")]
	private void \u0832ࢳޤ\u07B5()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		}
	}

	// Token: 0x06000AD8 RID: 2776 RVA: 0x0003A598 File Offset: 0x00038798
	[Token(Token = "0x6000AD8")]
	[Address(RVA = "0x2927468", Offset = "0x2927468", VA = "0x2927468")]
	public void ܯר\u05C7ڗ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Head";
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
	}

	// Token: 0x06000AD9 RID: 2777 RVA: 0x0003A5D0 File Offset: 0x000387D0
	[Token(Token = "0x6000AD9")]
	[Address(RVA = "0x292755C", Offset = "0x292755C", VA = "0x292755C")]
	private void \u0838ӆڛӑ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ނը\u0732\u0558();
		}
	}

	// Token: 0x06000ADA RID: 2778 RVA: 0x0003A610 File Offset: 0x00038810
	[Token(Token = "0x6000ADA")]
	[Address(RVA = "0x2927604", Offset = "0x2927604", VA = "0x2927604")]
	private void ڦکӁ\u06E2()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.Քջۼװ();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000ADB RID: 2779 RVA: 0x0003A658 File Offset: 0x00038858
	[Token(Token = "0x6000ADB")]
	[Address(RVA = "0x29277CC", Offset = "0x29277CC", VA = "0x29277CC")]
	private void \u07FE\u0882Զ\u066D()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ךئ\u05BDՂ();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000ADC RID: 2780 RVA: 0x0003A6A0 File Offset: 0x000388A0
	[Token(Token = "0x6000ADC")]
	[Address(RVA = "0x29279BC", Offset = "0x29279BC", VA = "0x29279BC")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.٠ԂՐڙ();
	}

	// Token: 0x06000ADD RID: 2781 RVA: 0x0003A6EC File Offset: 0x000388EC
	[Token(Token = "0x6000ADD")]
	[Address(RVA = "0x2927AB0", Offset = "0x2927AB0", VA = "0x2927AB0")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "sound play play";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.Ӡ\u0836٥\u060F();
	}

	// Token: 0x06000ADE RID: 2782 RVA: 0x0003A738 File Offset: 0x00038938
	[Token(Token = "0x6000ADE")]
	[Address(RVA = "0x2927BA4", Offset = "0x2927BA4", VA = "0x2927BA4")]
	private void \u087BӦןݩ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ڲ\u0592\u07F7ك();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000ADF RID: 2783 RVA: 0x0003A780 File Offset: 0x00038980
	[Token(Token = "0x6000ADF")]
	[Address(RVA = "0x2927D94", Offset = "0x2927D94", VA = "0x2927D94")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.\u0878ݼՏ\u0707();
	}

	// Token: 0x06000AE0 RID: 2784 RVA: 0x0003A7CC File Offset: 0x000389CC
	[Token(Token = "0x6000AE0")]
	[Address(RVA = "0x2927FB8", Offset = "0x2927FB8", VA = "0x2927FB8")]
	private void ܫ\u070Fۃ\u07F2()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.\u05CDڿӟҾ();
		}
	}

	// Token: 0x06000AE1 RID: 2785 RVA: 0x0003A80C File Offset: 0x00038A0C
	[Token(Token = "0x6000AE1")]
	[Address(RVA = "0x2928184", Offset = "0x2928184", VA = "0x2928184")]
	private void \u0705\u0816\u0739դ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ՅӇࢧ\u05FD();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AE2 RID: 2786 RVA: 0x0003A854 File Offset: 0x00038A54
	[Token(Token = "0x6000AE2")]
	[Address(RVA = "0x2928364", Offset = "0x2928364", VA = "0x2928364")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.٠ԂՐڙ();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AE3 RID: 2787 RVA: 0x0003A89C File Offset: 0x00038A9C
	[Token(Token = "0x6000AE3")]
	[Address(RVA = "0x2928410", Offset = "0x2928410", VA = "0x2928410")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.יࡓߞڦ();
	}

	// Token: 0x06000AE4 RID: 2788 RVA: 0x0003A8E8 File Offset: 0x00038AE8
	[Token(Token = "0x6000AE4")]
	[Address(RVA = "0x2928504", Offset = "0x2928504", VA = "0x2928504")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "EnableCosmetic";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ࢢ\u0886ࢨԳ();
	}

	// Token: 0x06000AE5 RID: 2789 RVA: 0x0003A934 File Offset: 0x00038B34
	[Token(Token = "0x6000AE5")]
	[Address(RVA = "0x29285F8", Offset = "0x29285F8", VA = "0x29285F8")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Game Started";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.\u085AҼӓߦ();
	}

	// Token: 0x06000AE6 RID: 2790 RVA: 0x0003A980 File Offset: 0x00038B80
	[Token(Token = "0x6000AE6")]
	[Address(RVA = "0x2928818", Offset = "0x2928818", VA = "0x2928818")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "CASUAL";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ڍޖ\u05BEڕ();
	}

	// Token: 0x06000AE7 RID: 2791 RVA: 0x0003A9CC File Offset: 0x00038BCC
	[Token(Token = "0x6000AE7")]
	[Address(RVA = "0x2928A54", Offset = "0x2928A54", VA = "0x2928A54")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ԩسӦ\u0611();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AE8 RID: 2792 RVA: 0x0003AA14 File Offset: 0x00038C14
	[Token(Token = "0x6000AE8")]
	[Address(RVA = "0x2928C24", Offset = "0x2928C24", VA = "0x2928C24")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
	}

	// Token: 0x06000AE9 RID: 2793 RVA: 0x0003AA44 File Offset: 0x00038C44
	[Token(Token = "0x6000AE9")]
	[Address(RVA = "0x2928D18", Offset = "0x2928D18", VA = "0x2928D18")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Joined Public Room Successfully";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.\u073Eݕ\u0700\u073B();
	}

	// Token: 0x06000AEA RID: 2794 RVA: 0x0003AA90 File Offset: 0x00038C90
	[Token(Token = "0x6000AEA")]
	[Address(RVA = "0x2928F2C", Offset = "0x2928F2C", VA = "0x2928F2C")]
	public void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "StartSong";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.כ\u0702ݬ\u07F4();
	}

	// Token: 0x06000AEB RID: 2795 RVA: 0x0003AADC File Offset: 0x00038CDC
	[Token(Token = "0x6000AEB")]
	[Address(RVA = "0x2929020", Offset = "0x2929020", VA = "0x2929020")]
	public void \u06DAٻࠕڡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.\u05AD\u0640۰ԯ();
	}

	// Token: 0x06000AEC RID: 2796 RVA: 0x0003AB28 File Offset: 0x00038D28
	[Token(Token = "0x6000AEC")]
	[Address(RVA = "0x2929114", Offset = "0x2929114", VA = "0x2929114")]
	public void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Trying Getting Entilement...";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ԯ\u07F8ܨӔ();
	}

	// Token: 0x06000AED RID: 2797 RVA: 0x0003AB74 File Offset: 0x00038D74
	[Token(Token = "0x6000AED")]
	[Address(RVA = "0x2929208", Offset = "0x2929208", VA = "0x2929208")]
	private void Update()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.SetColor();
		}
	}

	// Token: 0x06000AEE RID: 2798 RVA: 0x0003ABB4 File Offset: 0x00038DB4
	[Token(Token = "0x6000AEE")]
	[Address(RVA = "0x29292B0", Offset = "0x29292B0", VA = "0x29292B0")]
	public void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ࠃ\u05F5ٸ\u05F4();
	}

	// Token: 0x06000AEF RID: 2799 RVA: 0x0003AC00 File Offset: 0x00038E00
	[Token(Token = "0x6000AEF")]
	[Address(RVA = "0x29294C8", Offset = "0x29294C8", VA = "0x29294C8")]
	private void ٴݵۃ\u05AF()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ࢯӆԑہ();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AF0 RID: 2800 RVA: 0x0003AC48 File Offset: 0x00038E48
	[Token(Token = "0x6000AF0")]
	[Address(RVA = "0x29296A0", Offset = "0x29296A0", VA = "0x29296A0")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "character limit reached";
		ColorManager ލ_u0882ײࢲ = ColorManager.ލ\u0882ײࢲ;
		PhotonView pvCache = ލ_u0882ײࢲ.pvCache;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ލ_u0882ײࢲ.ӈ\u0838\u07BFԻ = u060F_u081D_u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ژӐӽڙ();
	}

	// Token: 0x06000AF1 RID: 2801 RVA: 0x0003ACA0 File Offset: 0x00038EA0
	[Token(Token = "0x6000AF1")]
	[Address(RVA = "0x2929794", Offset = "0x2929794", VA = "0x2929794")]
	private void ؤ\u05C8ԛ\u083F()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.SetColor();
		}
	}

	// Token: 0x06000AF2 RID: 2802 RVA: 0x0003ACE0 File Offset: 0x00038EE0
	[Token(Token = "0x6000AF2")]
	[Address(RVA = "0x292983C", Offset = "0x292983C", VA = "0x292983C")]
	private void \u07F7ܙײ\u05B5()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.יࡓߞڦ();
		}
	}

	// Token: 0x06000AF3 RID: 2803 RVA: 0x0003AD20 File Offset: 0x00038F20
	[Token(Token = "0x6000AF3")]
	[Address(RVA = "0x29298E4", Offset = "0x29298E4", VA = "0x29298E4")]
	private void \u05EDց\u081Cت()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.\u05CDڿӟҾ();
		}
	}

	// Token: 0x06000AF4 RID: 2804 RVA: 0x0003AD60 File Offset: 0x00038F60
	[Token(Token = "0x6000AF4")]
	[Address(RVA = "0x292998C", Offset = "0x292998C", VA = "0x292998C")]
	public void \u081FԘں\u07B2(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.٠ԂՐڙ();
	}

	// Token: 0x06000AF5 RID: 2805 RVA: 0x0003ADAC File Offset: 0x00038FAC
	[Token(Token = "0x6000AF5")]
	[Address(RVA = "0x2929A80", Offset = "0x2929A80", VA = "0x2929A80")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "goUpRPC";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.\u0832ߔܩժ();
	}

	// Token: 0x06000AF6 RID: 2806 RVA: 0x0003ADF8 File Offset: 0x00038FF8
	[Token(Token = "0x6000AF6")]
	[Address(RVA = "0x2929C94", Offset = "0x2929C94", VA = "0x2929C94")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayerHead";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ՅӇࢧ\u05FD();
	}

	// Token: 0x06000AF7 RID: 2807 RVA: 0x0003AE44 File Offset: 0x00039044
	[Token(Token = "0x6000AF7")]
	[Address(RVA = "0x2929D88", Offset = "0x2929D88", VA = "0x2929D88")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == " hours. You were banned because of ";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ࢯӆԑہ();
	}

	// Token: 0x06000AF8 RID: 2808 RVA: 0x0003AE90 File Offset: 0x00039090
	[Token(Token = "0x6000AF8")]
	[Address(RVA = "0x2929E7C", Offset = "0x2929E7C", VA = "0x2929E7C")]
	private void ժ\u065Dԯࡘ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.Ӏ\u07B4إ\u082A();
		}
	}

	// Token: 0x06000AF9 RID: 2809 RVA: 0x0003AED0 File Offset: 0x000390D0
	[Token(Token = "0x6000AF9")]
	[Address(RVA = "0x2929F24", Offset = "0x2929F24", VA = "0x2929F24")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Left a room";
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ӳܠԇߋ();
	}

	// Token: 0x06000AFA RID: 2810 RVA: 0x0003AF14 File Offset: 0x00039114
	[Token(Token = "0x6000AFA")]
	[Address(RVA = "0x292A018", Offset = "0x292A018", VA = "0x292A018")]
	private void \u07BDއڸ\u0834()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		}
	}

	// Token: 0x06000AFB RID: 2811 RVA: 0x0003AF3C File Offset: 0x0003913C
	[Token(Token = "0x6000AFB")]
	[Address(RVA = "0x292A1DC", Offset = "0x292A1DC", VA = "0x292A1DC")]
	private void Ӣ\u0592ߨׯ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.SetColor();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000AFC RID: 2812 RVA: 0x0003AF84 File Offset: 0x00039184
	[Token(Token = "0x6000AFC")]
	[Address(RVA = "0x292A288", Offset = "0x292A288", VA = "0x292A288")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ڲ\u0592\u07F7ك();
	}

	// Token: 0x06000AFD RID: 2813 RVA: 0x0003AFD0 File Offset: 0x000391D0
	[Token(Token = "0x6000AFD")]
	[Address(RVA = "0x292A37C", Offset = "0x292A37C", VA = "0x292A37C")]
	private void \u0821\u059Fӕ\u0607()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ڲ\u0592\u07F7ك();
		}
	}

	// Token: 0x06000AFE RID: 2814 RVA: 0x0003B010 File Offset: 0x00039210
	[Token(Token = "0x6000AFE")]
	[Address(RVA = "0x292A424", Offset = "0x292A424", VA = "0x292A424")]
	public void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "SetColor";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.\u085AҼӓߦ();
	}

	// Token: 0x06000AFF RID: 2815 RVA: 0x0003B05C File Offset: 0x0003925C
	[Token(Token = "0x6000AFF")]
	[Address(RVA = "0x292A518", Offset = "0x292A518", VA = "0x292A518")]
	private void \u05F8ݑ\u06ECߞ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.\u06DAؠڿ\u0743();
		}
	}

	// Token: 0x06000B00 RID: 2816 RVA: 0x0003B09C File Offset: 0x0003929C
	[Token(Token = "0x6000B00")]
	[Address(RVA = "0x292A6E0", Offset = "0x292A6E0", VA = "0x292A6E0")]
	public void ڷ\u0826ӹڥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Diffuse";
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
	}

	// Token: 0x06000B01 RID: 2817 RVA: 0x0003B0D4 File Offset: 0x000392D4
	[Token(Token = "0x6000B01")]
	[Address(RVA = "0x292A8EC", Offset = "0x292A8EC", VA = "0x292A8EC")]
	public ColorButton()
	{
	}

	// Token: 0x06000B02 RID: 2818 RVA: 0x0003B0E8 File Offset: 0x000392E8
	[Token(Token = "0x6000B02")]
	[Address(RVA = "0x292A8F4", Offset = "0x292A8F4", VA = "0x292A8F4")]
	private void ߊ\u066A\u05CFԉ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.\u05F6\u0878ݙ\u07BD();
		}
	}

	// Token: 0x06000B03 RID: 2819 RVA: 0x0003B128 File Offset: 0x00039328
	[Token(Token = "0x6000B03")]
	[Address(RVA = "0x292A99C", Offset = "0x292A99C", VA = "0x292A99C")]
	private void \u05ABࡡ\u07ABݾ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.\u0878ݼՏ\u0707();
		}
	}

	// Token: 0x06000B04 RID: 2820 RVA: 0x0003B168 File Offset: 0x00039368
	[Token(Token = "0x6000B04")]
	[Address(RVA = "0x292AA44", Offset = "0x292AA44", VA = "0x292AA44")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Vertical";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.ءۄڥࢣ();
	}

	// Token: 0x06000B05 RID: 2821 RVA: 0x0003B1B4 File Offset: 0x000393B4
	[Token(Token = "0x6000B05")]
	[Address(RVA = "0x292AB38", Offset = "0x292AB38", VA = "0x292AB38")]
	private void ߑ\u0885\u05BBߕ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ࢢ\u0886ࢨԳ();
		}
	}

	// Token: 0x06000B06 RID: 2822 RVA: 0x0003B1F4 File Offset: 0x000393F4
	[Token(Token = "0x6000B06")]
	[Address(RVA = "0x292ABE0", Offset = "0x292ABE0", VA = "0x292ABE0")]
	private void יԠ\u07EDԺ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.ءۄڥࢣ();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000B07 RID: 2823 RVA: 0x0003B23C File Offset: 0x0003943C
	[Token(Token = "0x6000B07")]
	[Address(RVA = "0x292AC8C", Offset = "0x292AC8C", VA = "0x292AC8C")]
	private void ԣԭՋࠏ()
	{
		if (this.Ԉ\u086B\u05A4\u0897)
		{
			float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
			float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
			ColorManager.ލ\u0882ײࢲ.\u05F6\u0878ݙ\u07BD();
			long ԉ_u086B_u05A4_u = 1L;
			this.Ԉ\u086B\u05A4\u0897 = (ԉ_u086B_u05A4_u != 0L);
		}
	}

	// Token: 0x06000B08 RID: 2824 RVA: 0x0003B284 File Offset: 0x00039484
	[Token(Token = "0x6000B08")]
	[Address(RVA = "0x292AD38", Offset = "0x292AD38", VA = "0x292AD38")]
	public void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Muted";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.߈\u05ADڮ\u0889();
	}

	// Token: 0x06000B09 RID: 2825 RVA: 0x0003B2D0 File Offset: 0x000394D0
	[Token(Token = "0x6000B09")]
	[Address(RVA = "0x292AF70", Offset = "0x292AF70", VA = "0x292AF70")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		float[] u06ED_u06D8_u060B_u = ColorManager.ލ\u0882ײࢲ.\u06ED\u06D8\u060B\u0832;
		float u060F_u081D_u07BEܡ = this.\u060F\u081D\u07BEܡ;
		ColorManager.ލ\u0882ײࢲ.SetColor();
	}

	// Token: 0x04000188 RID: 392
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000188")]
	public float \u060F\u081D\u07BEܡ;

	// Token: 0x04000189 RID: 393
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4000189")]
	public ColorButton.Ӷ\u081F\u064E\u0825 ձ߃\u07BA\u06E8;

	// Token: 0x0400018A RID: 394
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400018A")]
	public bool Ԉ\u086B\u05A4\u0897;

	// Token: 0x0200004E RID: 78
	[Token(Token = "0x200004E")]
	public enum Ӷ\u081F\u064E\u0825
	{
		// Token: 0x0400018C RID: 396
		[Token(Token = "0x400018C")]
		Ԫ\u070Fٴԏ,
		// Token: 0x0400018D RID: 397
		[Token(Token = "0x400018D")]
		ݛ\u07B9\u05A4ӵ,
		// Token: 0x0400018E RID: 398
		[Token(Token = "0x400018E")]
		ڀ\u06ECנ\u066C
	}
}
