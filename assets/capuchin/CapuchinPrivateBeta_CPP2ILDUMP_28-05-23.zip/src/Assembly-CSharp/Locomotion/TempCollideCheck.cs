﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Locomotion
{
	// Token: 0x02000112 RID: 274
	[Token(Token = "0x2000112")]
	public class TempCollideCheck : MonoBehaviour
	{
		// Token: 0x06002A5B RID: 10843 RVA: 0x00101A2C File Offset: 0x000FFC2C
		[Token(Token = "0x6002A5B")]
		[Address(RVA = "0x2F229E8", Offset = "0x2F229E8", VA = "0x2F229E8")]
		private void ӥԞֆ\u0655(Collision ݫ\u0618ۃࡔ)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 1L;
			كݕ_u05F3_u.ࢥԕ\u07B2ڙ(this, u07EBԍیޑ != 0L, ݫ\u0618ۃࡔ);
		}

		// Token: 0x06002A5C RID: 10844 RVA: 0x00101A50 File Offset: 0x000FFC50
		[Token(Token = "0x6002A5C")]
		[Address(RVA = "0x2F22A5C", Offset = "0x2F22A5C", VA = "0x2F22A5C")]
		private void \u089F\u073C\u059D\u06DE(Collision ݫ\u0618ۃࡔ)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 0L;
			كݕ_u05F3_u.ࡋ\u07B6\u05FD\u07EE(this, u07EBԍیޑ != 0L, ݫ\u0618ۃࡔ);
		}

		// Token: 0x06002A5D RID: 10845 RVA: 0x00101A74 File Offset: 0x000FFC74
		[Token(Token = "0x6002A5D")]
		[Address(RVA = "0x2F22AD0", Offset = "0x2F22AD0", VA = "0x2F22AD0")]
		public TempCollideCheck()
		{
		}

		// Token: 0x06002A5E RID: 10846 RVA: 0x00101A88 File Offset: 0x000FFC88
		[Token(Token = "0x6002A5E")]
		[Address(RVA = "0x2F22AD8", Offset = "0x2F22AD8", VA = "0x2F22AD8")]
		private void ԜӰֆג(Collision \u07FEל\u05AC\u0877)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 0L;
			كݕ_u05F3_u.ࡋ\u07B6\u05FD\u07EE(this, u07EBԍیޑ != 0L, \u07FEל\u05AC\u0877);
		}

		// Token: 0x06002A5F RID: 10847 RVA: 0x00101AAC File Offset: 0x000FFCAC
		[Token(Token = "0x6002A5F")]
		[Address(RVA = "0x2F22B4C", Offset = "0x2F22B4C", VA = "0x2F22B4C")]
		private void օړԾա(Collision \u07FEל\u05AC\u0877)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 0L;
			كݕ_u05F3_u.\u0888ࢥօࡒ(this, u07EBԍیޑ != 0L, \u07FEל\u05AC\u0877);
		}

		// Token: 0x06002A60 RID: 10848 RVA: 0x00101AD0 File Offset: 0x000FFCD0
		[Token(Token = "0x6002A60")]
		[Address(RVA = "0x2F22BC0", Offset = "0x2F22BC0", VA = "0x2F22BC0")]
		private void \u088Cݭ\u059F\u0889(Collision ݫ\u0618ۃࡔ)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 0L;
			كݕ_u05F3_u.ߦܔחݳ(this, u07EBԍیޑ != 0L, ݫ\u0618ۃࡔ);
		}

		// Token: 0x06002A61 RID: 10849 RVA: 0x00101AF4 File Offset: 0x000FFCF4
		[Token(Token = "0x6002A61")]
		[Address(RVA = "0x2F22C34", Offset = "0x2F22C34", VA = "0x2F22C34")]
		private void ߒ\u065EՎࡖ()
		{
			bool flag = base.gameObject.name == "Vector1_d371bd24217449349bd747533d51af6b";
			this.ԩӼؿ\u0654 = ("Vector1_d371bd24217449349bd747533d51af6b" != null);
		}

		// Token: 0x06002A62 RID: 10850 RVA: 0x00101B28 File Offset: 0x000FFD28
		[Token(Token = "0x6002A62")]
		[Address(RVA = "0x2F22CA8", Offset = "0x2F22CA8", VA = "0x2F22CA8")]
		private void \u05BDӚࢡ\u0816(Collision \u07FEל\u05AC\u0877)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 1L;
			كݕ_u05F3_u.ߦܔחݳ(this, u07EBԍیޑ != 0L, \u07FEל\u05AC\u0877);
		}

		// Token: 0x06002A63 RID: 10851 RVA: 0x00101B4C File Offset: 0x000FFD4C
		[Token(Token = "0x6002A63")]
		[Address(RVA = "0x2F22D1C", Offset = "0x2F22D1C", VA = "0x2F22D1C")]
		private void וࡪךӧ()
		{
			bool flag = base.gameObject.name == "run";
			this.ԩӼؿ\u0654 = ("run" != null);
		}

		// Token: 0x06002A64 RID: 10852 RVA: 0x00101B80 File Offset: 0x000FFD80
		[Token(Token = "0x6002A64")]
		[Address(RVA = "0x2F22D90", Offset = "0x2F22D90", VA = "0x2F22D90")]
		private void Ԯ\u0883\u0591\u066C()
		{
			bool flag = base.gameObject.name == "An error has occured while buying bananas, please restart your game and try again";
			this.ԩӼؿ\u0654 = ("An error has occured while buying bananas, please restart your game and try again" != null);
		}

		// Token: 0x06002A65 RID: 10853 RVA: 0x00101BB4 File Offset: 0x000FFDB4
		[Token(Token = "0x6002A65")]
		[Address(RVA = "0x2F22E04", Offset = "0x2F22E04", VA = "0x2F22E04")]
		private void דٺޞߩ(Collision \u07FEל\u05AC\u0877)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 1L;
			كݕ_u05F3_u.ࢥԕ\u07B2ڙ(this, u07EBԍیޑ != 0L, \u07FEל\u05AC\u0877);
		}

		// Token: 0x06002A66 RID: 10854 RVA: 0x00101BD8 File Offset: 0x000FFDD8
		[Token(Token = "0x6002A66")]
		[Address(RVA = "0x2F22E78", Offset = "0x2F22E78", VA = "0x2F22E78")]
		private void OnCollisionEnter(Collision \u07FEל\u05AC\u0877)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 0L;
			كݕ_u05F3_u.\u0888ࢥօࡒ(this, u07EBԍیޑ != 0L, \u07FEל\u05AC\u0877);
		}

		// Token: 0x06002A67 RID: 10855 RVA: 0x00101BFC File Offset: 0x000FFDFC
		[Token(Token = "0x6002A67")]
		[Address(RVA = "0x2F22EEC", Offset = "0x2F22EEC", VA = "0x2F22EEC")]
		private void OnCollisionExit(Collision ݫ\u0618ۃࡔ)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 1L;
			كݕ_u05F3_u.\u0888ࢥօࡒ(this, u07EBԍیޑ != 0L, ݫ\u0618ۃࡔ);
		}

		// Token: 0x06002A68 RID: 10856 RVA: 0x00101C20 File Offset: 0x000FFE20
		[Token(Token = "0x6002A68")]
		[Address(RVA = "0x2F22F60", Offset = "0x2F22F60", VA = "0x2F22F60")]
		private void ࢰחڵࡓ()
		{
			bool flag = base.gameObject.name == "All audio clips have been played.";
			this.ԩӼؿ\u0654 = ("All audio clips have been played." != null);
		}

		// Token: 0x06002A69 RID: 10857 RVA: 0x00101C54 File Offset: 0x000FFE54
		[Token(Token = "0x6002A69")]
		[Address(RVA = "0x2F22FD4", Offset = "0x2F22FD4", VA = "0x2F22FD4")]
		private void Start()
		{
			bool flag = base.gameObject.name == "HandL";
			this.ԩӼؿ\u0654 = ("HandL" != null);
		}

		// Token: 0x06002A6A RID: 10858 RVA: 0x00101C88 File Offset: 0x000FFE88
		[Token(Token = "0x6002A6A")]
		[Address(RVA = "0x2F23048", Offset = "0x2F23048", VA = "0x2F23048")]
		private void \u070BԆ\u074Bڢ(Collision ݫ\u0618ۃࡔ)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 1L;
			كݕ_u05F3_u.\u0888ࢥօࡒ(this, u07EBԍیޑ != 0L, ݫ\u0618ۃࡔ);
		}

		// Token: 0x06002A6B RID: 10859 RVA: 0x00101CAC File Offset: 0x000FFEAC
		[Token(Token = "0x6002A6B")]
		[Address(RVA = "0x2F230BC", Offset = "0x2F230BC", VA = "0x2F230BC")]
		private void \u06D9\u0895\u060Cڊ(Collision \u07FEל\u05AC\u0877)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 0L;
			كݕ_u05F3_u.\u0888ࢥօࡒ(this, u07EBԍیޑ != 0L, \u07FEל\u05AC\u0877);
		}

		// Token: 0x06002A6C RID: 10860 RVA: 0x00101CD0 File Offset: 0x000FFED0
		[Token(Token = "0x6002A6C")]
		[Address(RVA = "0x2F23130", Offset = "0x2F23130", VA = "0x2F23130")]
		private void بի\u0738ޞ(Collision ݫ\u0618ۃࡔ)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 0L;
			كݕ_u05F3_u.ߦܔחݳ(this, u07EBԍیޑ != 0L, ݫ\u0618ۃࡔ);
		}

		// Token: 0x06002A6D RID: 10861 RVA: 0x00101CF4 File Offset: 0x000FFEF4
		[Token(Token = "0x6002A6D")]
		[Address(RVA = "0x2F231A4", Offset = "0x2F231A4", VA = "0x2F231A4")]
		private void \u05ABݿࡋ\u06E9()
		{
			bool flag = base.gameObject.name == "TurnAmount";
			this.ԩӼؿ\u0654 = ("TurnAmount" != null);
		}

		// Token: 0x06002A6E RID: 10862 RVA: 0x00101D28 File Offset: 0x000FFF28
		[Token(Token = "0x6002A6E")]
		[Address(RVA = "0x2F23218", Offset = "0x2F23218", VA = "0x2F23218")]
		private void ࢣࡒࠅԸ(Collision ݫ\u0618ۃࡔ)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 1L;
			كݕ_u05F3_u.\u0888ࢥօࡒ(this, u07EBԍیޑ != 0L, ݫ\u0618ۃࡔ);
		}

		// Token: 0x06002A6F RID: 10863 RVA: 0x00101D4C File Offset: 0x000FFF4C
		[Token(Token = "0x6002A6F")]
		[Address(RVA = "0x2F2328C", Offset = "0x2F2328C", VA = "0x2F2328C")]
		private void ۳ݢܡԭ(Collision \u07FEל\u05AC\u0877)
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			long u07EBԍیޑ = 1L;
			كݕ_u05F3_u.\u0888ࢥօࡒ(this, u07EBԍیޑ != 0L, \u07FEל\u05AC\u0877);
		}

		// Token: 0x040005A8 RID: 1448
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40005A8")]
		public bool ԩӼؿ\u0654;
	}
}
