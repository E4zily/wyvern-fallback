﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

namespace Locomotion
{
	// Token: 0x0200010D RID: 269
	[Token(Token = "0x200010D")]
	public class Player : MonoBehaviour
	{
		// Token: 0x06002A1E RID: 10782 RVA: 0x000FFAC8 File Offset: 0x000FDCC8
		[Token(Token = "0x6002A1E")]
		[Address(RVA = "0x299A88C", Offset = "0x299A88C", VA = "0x299A88C")]
		private void ڗ߈ޓ߉()
		{
			if (this.\u088C\u05A2\u05A7ӑ)
			{
				Vector3 position = this.LeftHand.position;
				Vector3 position2 = this.LeftTarget.position;
				float num = this.climbForce;
				float num2 = this.ڱڣ\u0819\u05AD();
				if (this.\u088B\u070Dל١)
				{
					Rigidbody սիӫԭ = this.ՍԻӫԭ;
					Vector3 velocity = this.ՍԻӫԭ.velocity;
					float num3 = this.climbDrag;
				}
			}
			if (this.ӄՌ\u081Fࢯ)
			{
				Vector3 position3 = this.RightHand.position;
				Vector3 position4 = this.RightTarget.position;
				float num4 = this.climbForce;
				float num5 = this.ڱڣ\u0819\u05AD();
				if (this.\u088B\u070Dל١)
				{
					Rigidbody սիӫԭ2 = this.ՍԻӫԭ;
					Vector3 velocity2 = this.ՍԻӫԭ.velocity;
					float num6 = this.climbDrag;
					return;
				}
			}
		}

		// Token: 0x06002A1F RID: 10783 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002A1F")]
		[Address(RVA = "0x299AC80", Offset = "0x299AC80", VA = "0x299AC80")]
		private void ՔԶ\u05C3ۀ(bool \u058F\u083Dۀڃ)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002A20 RID: 10784 RVA: 0x000FFB88 File Offset: 0x000FDD88
		[Token(Token = "0x6002A20")]
		[Address(RVA = "0x299AEC0", Offset = "0x299AEC0", VA = "0x299AEC0")]
		public IEnumerator կը\u06EAہ()
		{
			long <>1__state;
			Player.ֆٽ\u0873ܣ ֆٽ_u0873ܣ = new Player.ֆٽ\u0873ܣ((int)<>1__state);
			<>1__state = 0L;
			ֆٽ_u0873ܣ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A21 RID: 10785 RVA: 0x000FFBAC File Offset: 0x000FDDAC
		[Token(Token = "0x6002A21")]
		[Address(RVA = "0x299AF38", Offset = "0x299AF38", VA = "0x299AF38")]
		public IEnumerator \u05F3Ӓ۰Ԃ()
		{
			long <>1__state;
			Player.ֆٽ\u0873ܣ ֆٽ_u0873ܣ = new Player.ֆٽ\u0873ܣ((int)<>1__state);
			<>1__state = 0L;
			ֆٽ_u0873ܣ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A22 RID: 10786 RVA: 0x000FFBD0 File Offset: 0x000FDDD0
		[Token(Token = "0x6002A22")]
		[Address(RVA = "0x299AFB0", Offset = "0x299AFB0", VA = "0x299AFB0")]
		public IEnumerator ޥӜՕ\u0558()
		{
			long <>1__state;
			Player.ڬ\u07ECڭҽ ڬ_u07ECڭҽ = new Player.ڬ\u07ECڭҽ((int)<>1__state);
			<>1__state = 1L;
			ڬ_u07ECڭҽ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A23 RID: 10787 RVA: 0x000FFBF4 File Offset: 0x000FDDF4
		[Token(Token = "0x6002A23")]
		[Address(RVA = "0x299B028", Offset = "0x299B028", VA = "0x299B028")]
		public Player()
		{
		}

		// Token: 0x06002A24 RID: 10788 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002A24")]
		[Address(RVA = "0x299B050", Offset = "0x299B050", VA = "0x299B050")]
		private void LateUpdate()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002A25 RID: 10789 RVA: 0x000FFC14 File Offset: 0x000FDE14
		[Token(Token = "0x6002A25")]
		[Address(RVA = "0x299B14C", Offset = "0x299B14C", VA = "0x299B14C")]
		public IEnumerator س۳ݳ\u05B1()
		{
			long <>1__state;
			Player.ڬ\u07ECڭҽ ڬ_u07ECڭҽ = new Player.ڬ\u07ECڭҽ((int)<>1__state);
			<>1__state = 0L;
			ڬ_u07ECڭҽ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A26 RID: 10790 RVA: 0x000FFC38 File Offset: 0x000FDE38
		[Token(Token = "0x6002A26")]
		[Address(RVA = "0x299B1C4", Offset = "0x299B1C4", VA = "0x299B1C4")]
		private void \u061B\u05EEوۈ()
		{
			if (!true)
			{
			}
			if (!this.\u0610Ӎ\u0615ۃ && this.\u065A\u07F0\u0599ߛ)
			{
				IEnumerator routine = this.Ԩڮڨ\u05AC();
				Coroutine coroutine = base.StartCoroutine(routine);
			}
			if (this.ԧ\u06E7ذࢯ && this.\u065A\u07F0\u0599ߛ)
			{
				IEnumerator routine2 = this.Ԩڮڨ\u05AC();
				Coroutine coroutine2 = base.StartCoroutine(routine2);
			}
		}

		// Token: 0x06002A27 RID: 10791 RVA: 0x000FFC8C File Offset: 0x000FDE8C
		[Token(Token = "0x6002A27")]
		[Address(RVA = "0x299B348", Offset = "0x299B348", VA = "0x299B348")]
		private float ӹܓҼࡃ()
		{
			do
			{
				bool u088C_u05A2_u05A7ӑ = this.\u088C\u05A2\u05A7ӑ;
				bool աݦդך = this.Աݦդך;
				if (u088C_u05A2_u05A7ӑ && !աݦդך)
				{
					Vector3 localPosition = this.LeftTarget.localPosition;
					float z = this.\u05F8د\u089Dޓ.z;
					float fixedDeltaTime = Time.fixedDeltaTime;
					Rigidbody leftHand = this.LeftHand;
				}
				Vector3 localPosition2 = this.LeftTarget.localPosition;
				float z2 = this.\u05F8د\u089Dޓ.z;
				float fixedDeltaTime2 = Time.fixedDeltaTime;
				Vector3 position = this.LeftHand.position;
			}
			while (!this.ӄՌ\u081Fࢯ || this.\u0821\u0594ࠌԃ);
			Vector3 localPosition3 = this.RightTarget.localPosition;
			float x = this.գړࠑࡋ.x;
			float z3 = this.գړࠑࡋ.z;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			Vector3 position2 = this.RightHand.position;
			throw new NullReferenceException();
		}

		// Token: 0x06002A28 RID: 10792 RVA: 0x000FFD60 File Offset: 0x000FDF60
		[Token(Token = "0x6002A28")]
		[Address(RVA = "0x299B2D0", Offset = "0x299B2D0", VA = "0x299B2D0")]
		public IEnumerator Ԩڮڨ\u05AC()
		{
			long <>1__state;
			Player.\u0893ٯՍԦ u0893ٯՍԦ = new Player.\u0893ٯՍԦ((int)<>1__state);
			<>1__state = 0L;
			u0893ٯՍԦ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A29 RID: 10793 RVA: 0x000FFD84 File Offset: 0x000FDF84
		[Token(Token = "0x6002A29")]
		[Address(RVA = "0x299B5C4", Offset = "0x299B5C4", VA = "0x299B5C4")]
		public IEnumerator ݺݛޱؼ()
		{
			long <>1__state;
			Player.ڬ\u07ECڭҽ ڬ_u07ECڭҽ = new Player.ڬ\u07ECڭҽ((int)<>1__state);
			<>1__state = 0L;
			ڬ_u07ECڭҽ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A2A RID: 10794 RVA: 0x000FFDA8 File Offset: 0x000FDFA8
		[Token(Token = "0x6002A2A")]
		[Address(RVA = "0x299B63C", Offset = "0x299B63C", VA = "0x299B63C")]
		private void ޜފ\u06E0ە()
		{
			float num = this.rotfrequency;
			float num2 = this.rotDamping;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Quaternion rotation = this.LeftTarget.rotation;
			Quaternion rotation2 = this.LeftHand.rotation;
			Vector3 angularVelocity = this.LeftHand.angularVelocity;
			Rigidbody leftHand = this.LeftHand;
			float num3 = this.rotfrequency;
			float num4 = this.rotDamping;
			float fixedDeltaTime5 = Time.fixedDeltaTime;
			float fixedDeltaTime6 = Time.fixedDeltaTime;
			float fixedDeltaTime7 = Time.fixedDeltaTime;
			float fixedDeltaTime8 = Time.fixedDeltaTime;
			Quaternion rotation3 = this.RightTarget.rotation;
			Quaternion rotation4 = this.RightHand.rotation;
			Vector3 angularVelocity2 = this.RightHand.angularVelocity;
			Rigidbody rightHand = this.RightHand;
		}

		// Token: 0x06002A2B RID: 10795 RVA: 0x000FFE94 File Offset: 0x000FE094
		[Token(Token = "0x6002A2B")]
		[Address(RVA = "0x299BA10", Offset = "0x299BA10", VA = "0x299BA10")]
		private void ࡦࢣ\u061Dڱ()
		{
			float num = this.frequency;
			float num2 = this.damping;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.ՍԻӫԭ.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Rigidbody leftHand = this.LeftHand;
			Vector3 position3 = this.RightTarget.position;
			Vector3 position4 = this.RightHand.position;
			Vector3 velocity3 = this.ՍԻӫԭ.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
			Rigidbody rightHand = this.RightHand;
		}

		// Token: 0x06002A2C RID: 10796 RVA: 0x000FFF54 File Offset: 0x000FE154
		[Token(Token = "0x6002A2C")]
		[Address(RVA = "0x299BC80", Offset = "0x299BC80", VA = "0x299BC80")]
		private void Update()
		{
			if (!true)
			{
			}
			if (!this.\u0610Ӎ\u0615ۃ && this.\u065A\u07F0\u0599ߛ)
			{
				IEnumerator routine = this.Ԩڮڨ\u05AC();
				Coroutine coroutine = base.StartCoroutine(routine);
			}
			if (this.ԧ\u06E7ذࢯ && this.\u065A\u07F0\u0599ߛ)
			{
				IEnumerator routine2 = this.Ԩڮڨ\u05AC();
				Coroutine coroutine2 = base.StartCoroutine(routine2);
			}
		}

		// Token: 0x06002A2D RID: 10797 RVA: 0x000FFFA8 File Offset: 0x000FE1A8
		[Token(Token = "0x6002A2D")]
		[Address(RVA = "0x299BD8C", Offset = "0x299BD8C", VA = "0x299BD8C")]
		public void ࢥԕ\u07B2ڙ(TempCollideCheck \u089D\u0887өࢺ, bool \u07EBԍیޑ, Collision ࠀӛٷ\u0884)
		{
			if (\u089D\u0887өࢺ.ԩӼؿ\u0654)
			{
				long u088C_u05A2_u05A7ӑ = 1L;
				this.\u088C\u05A2\u05A7ӑ = (u088C_u05A2_u05A7ӑ != 0L);
				GameObject gameObject = ࠀӛٷ\u0884.gameObject;
				if (!\u089D\u0887өࢺ.ԩӼؿ\u0654)
				{
					return;
				}
			}
			else
			{
				GameObject gameObject2 = ࠀӛٷ\u0884.gameObject;
				long ӄՌ_u081Fࢯ = 1L;
				this.ӄՌ\u081Fࢯ = (ӄՌ_u081Fࢯ != 0L);
			}
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("manual footTimings length should be equal to the leg count");
		}

		// Token: 0x06002A2E RID: 10798 RVA: 0x00100250 File Offset: 0x000FE450
		[Token(Token = "0x6002A2E")]
		[Address(RVA = "0x299C268", Offset = "0x299C268", VA = "0x299C268")]
		private void ӫࡩ\u0829ވ()
		{
			float num = this.frequency;
			float num2 = this.damping;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.ՍԻӫԭ.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Rigidbody leftHand = this.LeftHand;
			Vector3 position3 = this.RightTarget.position;
			Vector3 position4 = this.RightHand.position;
			Vector3 velocity3 = this.ՍԻӫԭ.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
			Rigidbody rightHand = this.RightHand;
		}

		// Token: 0x06002A2F RID: 10799 RVA: 0x00100310 File Offset: 0x000FE510
		[Token(Token = "0x6002A2F")]
		[Address(RVA = "0x299C4D8", Offset = "0x299C4D8", VA = "0x299C4D8")]
		public void \u0888ࢥօࡒ(TempCollideCheck \u089D\u0887өࢺ, bool \u07EBԍیޑ, Collision ࠀӛٷ\u0884)
		{
			if (\u089D\u0887өࢺ.ԩӼؿ\u0654)
			{
				GameObject gameObject = ࠀӛٷ\u0884.gameObject;
				if (!\u089D\u0887өࢺ.ԩӼؿ\u0654)
				{
					return;
				}
			}
			else
			{
				GameObject gameObject2 = ࠀӛٷ\u0884.gameObject;
			}
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Stopped Colliding");
		}

		// Token: 0x06002A30 RID: 10800 RVA: 0x00100578 File Offset: 0x000FE778
		[Token(Token = "0x6002A30")]
		[Address(RVA = "0x299CBBC", Offset = "0x299CBBC", VA = "0x299CBBC")]
		private void ۍ\u05CAۋݿ()
		{
			if (!this.\u088B\u070Dל١)
			{
				Transform transform = this.RightHand.transform;
				Vector3 position = this.RightTarget.position;
				Transform transform2 = this.LeftHand.transform;
				Vector3 position2 = this.LeftTarget.position;
				return;
			}
			this.ץ\u073Fߙ\u070E();
			this.ࡤӓ\u0704ժ();
			this.ڗ߈ޓ߉();
			if (this.disableMovement)
			{
				return;
			}
		}

		// Token: 0x06002A31 RID: 10801 RVA: 0x001005E0 File Offset: 0x000FE7E0
		[Token(Token = "0x6002A31")]
		[Address(RVA = "0x299D310", Offset = "0x299D310", VA = "0x299D310")]
		private void FixedUpdate()
		{
			if (!this.\u088B\u070Dל١)
			{
				Transform transform = this.RightHand.transform;
				Vector3 position = this.RightTarget.position;
				Transform transform2 = this.LeftHand.transform;
				Vector3 position2 = this.LeftTarget.position;
				return;
			}
			this.ץ\u073Fߙ\u070E();
			this.ޜފ\u06E0ە();
			this.ڗ߈ޓ߉();
			if (this.disableMovement)
			{
				return;
			}
		}

		// Token: 0x06002A32 RID: 10802 RVA: 0x00100648 File Offset: 0x000FE848
		[Token(Token = "0x6002A32")]
		[Address(RVA = "0x299D3E0", Offset = "0x299D3E0", VA = "0x299D3E0")]
		private void ނ\u0837\u0835\u0833()
		{
			float num = this.frequency;
			float num2 = this.damping;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.ՍԻӫԭ.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Rigidbody leftHand = this.LeftHand;
			Vector3 position3 = this.RightTarget.position;
			Vector3 position4 = this.RightHand.position;
			Vector3 velocity3 = this.ՍԻӫԭ.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
			Rigidbody rightHand = this.RightHand;
		}

		// Token: 0x06002A33 RID: 10803 RVA: 0x00100708 File Offset: 0x000FE908
		[Token(Token = "0x6002A33")]
		[Address(RVA = "0x299D650", Offset = "0x299D650", VA = "0x299D650")]
		public void ࡋ\u07B6\u05FD\u07EE(TempCollideCheck \u089D\u0887өࢺ, bool \u07EBԍیޑ, Collision ࠀӛٷ\u0884)
		{
			if (\u089D\u0887өࢺ.ԩӼؿ\u0654)
			{
				GameObject gameObject = ࠀӛٷ\u0884.gameObject;
				if (!\u089D\u0887өࢺ.ԩӼؿ\u0654)
				{
					return;
				}
			}
			else
			{
				GameObject gameObject2 = ࠀӛٷ\u0884.gameObject;
			}
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.");
		}

		// Token: 0x06002A34 RID: 10804 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002A34")]
		[Address(RVA = "0x299C98C", Offset = "0x299C98C", VA = "0x299C98C")]
		private void ࢻԩڪࡐ(bool \u058F\u083Dۀڃ)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002A35 RID: 10805 RVA: 0x00100998 File Offset: 0x000FEB98
		[Token(Token = "0x6002A35")]
		[Address(RVA = "0x299CC94", Offset = "0x299CC94", VA = "0x299CC94")]
		private void ץ\u073Fߙ\u070E()
		{
			float num = this.frequency;
			float num2 = this.damping;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.ՍԻӫԭ.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Rigidbody leftHand = this.LeftHand;
			Vector3 position3 = this.RightTarget.position;
			Vector3 position4 = this.RightHand.position;
			Vector3 velocity3 = this.ՍԻӫԭ.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
			Rigidbody rightHand = this.RightHand;
		}

		// Token: 0x06002A36 RID: 10806 RVA: 0x00100A58 File Offset: 0x000FEC58
		[Token(Token = "0x6002A36")]
		[Address(RVA = "0x299DB20", Offset = "0x299DB20", VA = "0x299DB20")]
		public void \u06D7\u05FDڳԦ(TempCollideCheck \u089D\u0887өࢺ, bool \u07EBԍیޑ, Collision ࠀӛٷ\u0884)
		{
			if (\u089D\u0887өࢺ.ԩӼؿ\u0654)
			{
				GameObject gameObject = ࠀӛٷ\u0884.gameObject;
				if (!\u089D\u0887өࢺ.ԩӼؿ\u0654)
				{
					return;
				}
			}
			else
			{
				GameObject gameObject2 = ࠀӛٷ\u0884.gameObject;
			}
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("ErrorScreen");
		}

		// Token: 0x06002A37 RID: 10807 RVA: 0x00100D20 File Offset: 0x000FEF20
		[Token(Token = "0x6002A37")]
		[Address(RVA = "0x299E01C", Offset = "0x299E01C", VA = "0x299E01C")]
		private float \u082Dӫ\u07A9\u0658()
		{
			do
			{
				bool u088C_u05A2_u05A7ӑ = this.\u088C\u05A2\u05A7ӑ;
				bool աݦդך = this.Աݦդך;
				if (u088C_u05A2_u05A7ӑ && !աݦդך)
				{
					Vector3 localPosition = this.LeftTarget.localPosition;
					float z = this.\u05F8د\u089Dޓ.z;
					float fixedDeltaTime = Time.fixedDeltaTime;
					Rigidbody leftHand = this.LeftHand;
				}
				Vector3 localPosition2 = this.LeftTarget.localPosition;
				float z2 = this.\u05F8د\u089Dޓ.z;
				float fixedDeltaTime2 = Time.fixedDeltaTime;
				Vector3 position = this.LeftHand.position;
			}
			while (!this.ӄՌ\u081Fࢯ || this.\u0821\u0594ࠌԃ);
			Vector3 localPosition3 = this.RightTarget.localPosition;
			float x = this.գړࠑࡋ.x;
			float z3 = this.գړࠑࡋ.z;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			Vector3 position2 = this.RightHand.position;
			throw new NullReferenceException();
		}

		// Token: 0x06002A38 RID: 10808 RVA: 0x00100DF4 File Offset: 0x000FEFF4
		[Token(Token = "0x6002A38")]
		[Address(RVA = "0x299E294", Offset = "0x299E294", VA = "0x299E294")]
		private void ڑߒجވ()
		{
			if (!true)
			{
			}
			if (!this.\u0610Ӎ\u0615ۃ && this.\u065A\u07F0\u0599ߛ)
			{
				IEnumerator routine = this.Ԩڮڨ\u05AC();
				Coroutine coroutine = base.StartCoroutine(routine);
			}
			if (this.ԧ\u06E7ذࢯ && this.\u065A\u07F0\u0599ߛ)
			{
				IEnumerator routine2 = this.Ԩڮڨ\u05AC();
				Coroutine coroutine2 = base.StartCoroutine(routine2);
				long ԧ_u06E7ذࢯ = 1L;
				this.ԧ\u06E7ذࢯ = (ԧ_u06E7ذࢯ != 0L);
			}
		}

		// Token: 0x06002A39 RID: 10809 RVA: 0x00100E50 File Offset: 0x000FF050
		[Token(Token = "0x6002A39")]
		[Address(RVA = "0x299E3A4", Offset = "0x299E3A4", VA = "0x299E3A4")]
		private void \u0884\u088E\u065CӲ()
		{
			if (this.\u088C\u05A2\u05A7ӑ)
			{
				Vector3 position = this.LeftHand.position;
				Vector3 position2 = this.LeftTarget.position;
				float num = this.climbForce;
				float num2 = this.թ\u0600ԫ\u0640();
				if (this.\u088B\u070Dל١)
				{
					Rigidbody սիӫԭ = this.ՍԻӫԭ;
					Vector3 velocity = this.ՍԻӫԭ.velocity;
					float num3 = this.climbDrag;
				}
			}
			if (this.ӄՌ\u081Fࢯ)
			{
				Vector3 position3 = this.RightHand.position;
				Vector3 position4 = this.RightTarget.position;
				float num4 = this.climbForce;
				float num5 = this.\u082Dӫ\u07A9\u0658();
				if (this.\u088B\u070Dל١)
				{
					Rigidbody սիӫԭ2 = this.ՍԻӫԭ;
					Vector3 velocity2 = this.ՍԻӫԭ.velocity;
					float num6 = this.climbDrag;
					return;
				}
			}
		}

		// Token: 0x06002A3A RID: 10810 RVA: 0x00100F10 File Offset: 0x000FF110
		[Token(Token = "0x6002A3A")]
		[Address(RVA = "0x299E800", Offset = "0x299E800", VA = "0x299E800")]
		public IEnumerator ӟ\u07A8\u0608ք()
		{
			long <>1__state;
			Player.ֆٽ\u0873ܣ ֆٽ_u0873ܣ = new Player.ֆٽ\u0873ܣ((int)<>1__state);
			<>1__state = 0L;
			ֆٽ_u0873ܣ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A3B RID: 10811 RVA: 0x00100F34 File Offset: 0x000FF134
		[Token(Token = "0x6002A3B")]
		[Address(RVA = "0x299E878", Offset = "0x299E878", VA = "0x299E878")]
		public void ߦܔחݳ(TempCollideCheck \u089D\u0887өࢺ, bool \u07EBԍیޑ, Collision ࠀӛٷ\u0884)
		{
			if (\u089D\u0887өࢺ.ԩӼؿ\u0654)
			{
				GameObject gameObject = ࠀӛٷ\u0884.gameObject;
				if (!\u089D\u0887өࢺ.ԩӼؿ\u0654)
				{
					return;
				}
			}
			else
			{
				GameObject gameObject2 = ࠀӛٷ\u0884.gameObject;
			}
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("");
		}

		// Token: 0x06002A3C RID: 10812 RVA: 0x001011BC File Offset: 0x000FF3BC
		[Token(Token = "0x6002A3C")]
		[Address(RVA = "0x299E584", Offset = "0x299E584", VA = "0x299E584")]
		private float թ\u0600ԫ\u0640()
		{
			do
			{
				bool u088C_u05A2_u05A7ӑ = this.\u088C\u05A2\u05A7ӑ;
				bool աݦդך = this.Աݦդך;
				if (u088C_u05A2_u05A7ӑ && !աݦդך)
				{
					Vector3 localPosition = this.LeftTarget.localPosition;
					float z = this.\u05F8د\u089Dޓ.z;
					float fixedDeltaTime = Time.fixedDeltaTime;
					Rigidbody leftHand = this.LeftHand;
				}
				Vector3 localPosition2 = this.LeftTarget.localPosition;
				float z2 = this.\u05F8د\u089Dޓ.z;
				float fixedDeltaTime2 = Time.fixedDeltaTime;
				Vector3 position = this.LeftHand.position;
			}
			while (!this.ӄՌ\u081Fࢯ || this.\u0821\u0594ࠌԃ);
			Vector3 localPosition3 = this.RightTarget.localPosition;
			float x = this.գړࠑࡋ.x;
			float z3 = this.գړࠑࡋ.z;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			Vector3 position2 = this.RightHand.position;
			throw new NullReferenceException();
		}

		// Token: 0x06002A3D RID: 10813 RVA: 0x00101290 File Offset: 0x000FF490
		[Token(Token = "0x6002A3D")]
		[Address(RVA = "0x299ED48", Offset = "0x299ED48", VA = "0x299ED48")]
		public IEnumerator \u07AE\u073F\u07B7ݵ()
		{
			long <>1__state;
			Player.ڬ\u07ECڭҽ ڬ_u07ECڭҽ = new Player.ڬ\u07ECڭҽ((int)<>1__state);
			<>1__state = 1L;
			ڬ_u07ECڭҽ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A3E RID: 10814 RVA: 0x001012B4 File Offset: 0x000FF4B4
		[Token(Token = "0x6002A3E")]
		[Address(RVA = "0x299EDC0", Offset = "0x299EDC0", VA = "0x299EDC0")]
		private void ԉ\u07F7דڱ()
		{
			TempCollideCheck tempCollideCheck = this.LeftHand.gameObject.AddComponent<TempCollideCheck>();
			TempCollideCheck tempCollideCheck2 = this.RightHand.gameObject.AddComponent<TempCollideCheck>();
		}

		// Token: 0x06002A3F RID: 10815 RVA: 0x001012EC File Offset: 0x000FF4EC
		[Token(Token = "0x6002A3F")]
		[Address(RVA = "0x299EE3C", Offset = "0x299EE3C", VA = "0x299EE3C")]
		public IEnumerator \u07B7וզӖ()
		{
			long <>1__state;
			Player.ڬ\u07ECڭҽ ڬ_u07ECڭҽ = new Player.ڬ\u07ECڭҽ((int)<>1__state);
			<>1__state = 0L;
			ڬ_u07ECڭҽ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A40 RID: 10816 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002A40")]
		[Address(RVA = "0x299EEB4", Offset = "0x299EEB4", VA = "0x299EEB4")]
		private void ߆۰\u05BFߍ()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002A41 RID: 10817 RVA: 0x00101310 File Offset: 0x000FF510
		[Token(Token = "0x6002A41")]
		[Address(RVA = "0x299AA6C", Offset = "0x299AA6C", VA = "0x299AA6C")]
		private float ڱڣ\u0819\u05AD()
		{
			do
			{
				bool u088C_u05A2_u05A7ӑ = this.\u088C\u05A2\u05A7ӑ;
				bool աݦդך = this.Աݦդך;
				if (u088C_u05A2_u05A7ӑ && !աݦդך)
				{
					Vector3 localPosition = this.LeftTarget.localPosition;
					float z = this.\u05F8د\u089Dޓ.z;
					float fixedDeltaTime = Time.fixedDeltaTime;
					Rigidbody leftHand = this.LeftHand;
				}
				Vector3 localPosition2 = this.LeftTarget.localPosition;
				float z2 = this.\u05F8د\u089Dޓ.z;
				float fixedDeltaTime2 = Time.fixedDeltaTime;
				Vector3 position = this.LeftHand.position;
			}
			while (!this.ӄՌ\u081Fࢯ || this.\u0821\u0594ࠌԃ);
			Vector3 localPosition3 = this.RightTarget.localPosition;
			float x = this.գړࠑࡋ.x;
			float z3 = this.գړࠑࡋ.z;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			Vector3 position2 = this.RightHand.position;
			throw new NullReferenceException();
		}

		// Token: 0x06002A42 RID: 10818 RVA: 0x001013E4 File Offset: 0x000FF5E4
		[Token(Token = "0x6002A42")]
		[Address(RVA = "0x299EFBC", Offset = "0x299EFBC", VA = "0x299EFBC")]
		private void \u0817ӗ\u082Aݱ()
		{
			float num = this.frequency;
			float num2 = this.damping;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.ՍԻӫԭ.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Rigidbody leftHand = this.LeftHand;
			Vector3 position3 = this.RightTarget.position;
			Vector3 position4 = this.RightHand.position;
			Vector3 velocity3 = this.ՍԻӫԭ.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
			Rigidbody rightHand = this.RightHand;
		}

		// Token: 0x06002A43 RID: 10819 RVA: 0x001014A4 File Offset: 0x000FF6A4
		[Token(Token = "0x6002A43")]
		[Address(RVA = "0x299F22C", Offset = "0x299F22C", VA = "0x299F22C")]
		public IEnumerator \u083B\u0704ݪ\u087F()
		{
			long <>1__state;
			Player.ֆٽ\u0873ܣ ֆٽ_u0873ܣ = new Player.ֆٽ\u0873ܣ((int)<>1__state);
			<>1__state = 0L;
			ֆٽ_u0873ܣ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A44 RID: 10820 RVA: 0x001014C8 File Offset: 0x000FF6C8
		[Token(Token = "0x6002A44")]
		[Address(RVA = "0x299CEE4", Offset = "0x299CEE4", VA = "0x299CEE4")]
		private void ࡤӓ\u0704ժ()
		{
			float num = this.rotfrequency;
			float num2 = this.rotDamping;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Quaternion rotation = this.LeftTarget.rotation;
			Quaternion rotation2 = this.LeftHand.rotation;
			Vector3 angularVelocity = this.LeftHand.angularVelocity;
			Rigidbody leftHand = this.LeftHand;
			float num3 = this.rotfrequency;
			float num4 = this.rotDamping;
			float fixedDeltaTime5 = Time.fixedDeltaTime;
			float fixedDeltaTime6 = Time.fixedDeltaTime;
			float fixedDeltaTime7 = Time.fixedDeltaTime;
			float fixedDeltaTime8 = Time.fixedDeltaTime;
			Quaternion rotation3 = this.RightTarget.rotation;
			Quaternion rotation4 = this.RightHand.rotation;
			Vector3 angularVelocity2 = this.RightHand.angularVelocity;
			Rigidbody rightHand = this.RightHand;
		}

		// Token: 0x06002A45 RID: 10821 RVA: 0x001015B4 File Offset: 0x000FF7B4
		[Token(Token = "0x6002A45")]
		[Address(RVA = "0x299F2A4", Offset = "0x299F2A4", VA = "0x299F2A4")]
		private void Start()
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			Player.كݕ\u05F3\u0589 = this;
			Transform leftTarget = this.LeftTarget;
			Rigidbody leftHand = this.LeftHand;
			Vector3 position = leftTarget.position;
			Transform leftTarget2 = this.LeftTarget;
			Rigidbody leftHand2 = this.LeftHand;
			Quaternion rotation = leftTarget2.rotation;
			Transform rightTarget = this.RightTarget;
			Rigidbody rightHand = this.RightHand;
			Vector3 position2 = rightTarget.position;
			Transform rightTarget2 = this.RightTarget;
			Rigidbody rightHand2 = this.RightHand;
			Quaternion rotation2 = rightTarget2.rotation;
			Rigidbody leftHand3 = this.LeftHand;
			Rigidbody rightHand3 = this.RightHand;
			Vector3 position3 = this.LeftHand.position;
			Vector3 position4 = this.LeftHand.position;
		}

		// Token: 0x06002A46 RID: 10822 RVA: 0x00101660 File Offset: 0x000FF860
		[Token(Token = "0x6002A46")]
		[Address(RVA = "0x299F454", Offset = "0x299F454", VA = "0x299F454")]
		private void \u0736\u06E0\u06E0څ()
		{
			if (!this.\u088B\u070Dל١)
			{
				Transform transform = this.RightHand.transform;
				Vector3 position = this.RightTarget.position;
				Transform transform2 = this.LeftHand.transform;
				Vector3 position2 = this.LeftTarget.position;
				return;
			}
			this.ࡦࢣ\u061Dڱ();
			this.ޜފ\u06E0ە();
			this.\u0884\u088E\u065CӲ();
			if (this.disableMovement)
			{
				return;
			}
		}

		// Token: 0x06002A47 RID: 10823 RVA: 0x001016C8 File Offset: 0x000FF8C8
		[Token(Token = "0x6002A47")]
		[Address(RVA = "0x299F52C", Offset = "0x299F52C", VA = "0x299F52C")]
		private void ࡩݮڢՠ()
		{
			Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
			Player.كݕ\u05F3\u0589 = this;
			Transform leftTarget = this.LeftTarget;
			Rigidbody leftHand = this.LeftHand;
			Vector3 position = leftTarget.position;
			Transform leftTarget2 = this.LeftTarget;
			Rigidbody leftHand2 = this.LeftHand;
			Quaternion rotation = leftTarget2.rotation;
			Transform rightTarget = this.RightTarget;
			Rigidbody rightHand = this.RightHand;
			Vector3 position2 = rightTarget.position;
			Transform rightTarget2 = this.RightTarget;
			Rigidbody rightHand2 = this.RightHand;
			Quaternion rotation2 = rightTarget2.rotation;
			Rigidbody leftHand3 = this.LeftHand;
			Rigidbody rightHand3 = this.RightHand;
			Vector3 position3 = this.LeftHand.position;
			Vector3 position4 = this.LeftHand.position;
		}

		// Token: 0x06002A48 RID: 10824 RVA: 0x00101774 File Offset: 0x000FF974
		[Token(Token = "0x6002A48")]
		[Address(RVA = "0x299F6D4", Offset = "0x299F6D4", VA = "0x299F6D4")]
		private void Awake()
		{
			TempCollideCheck tempCollideCheck = this.LeftHand.gameObject.AddComponent<TempCollideCheck>();
			TempCollideCheck tempCollideCheck2 = this.RightHand.gameObject.AddComponent<TempCollideCheck>();
		}

		// Token: 0x0400056D RID: 1389
		[Token(Token = "0x400056D")]
		public static Player كݕ\u05F3\u0589;

		// Token: 0x0400056E RID: 1390
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400056E")]
		[SerializeField]
		[Header("PID")]
		private float frequency;

		// Token: 0x0400056F RID: 1391
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x400056F")]
		[SerializeField]
		private float damping;

		// Token: 0x04000570 RID: 1392
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000570")]
		[SerializeField]
		private float rotfrequency;

		// Token: 0x04000571 RID: 1393
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4000571")]
		[SerializeField]
		private float rotDamping;

		// Token: 0x04000572 RID: 1394
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000572")]
		public Rigidbody ՍԻӫԭ;

		// Token: 0x04000573 RID: 1395
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000573")]
		[SerializeField]
		private Transform LeftTarget;

		// Token: 0x04000574 RID: 1396
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000574")]
		[SerializeField]
		private Rigidbody LeftHand;

		// Token: 0x04000575 RID: 1397
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000575")]
		[SerializeField]
		private Transform RightTarget;

		// Token: 0x04000576 RID: 1398
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000576")]
		[SerializeField]
		private Rigidbody RightHand;

		// Token: 0x04000577 RID: 1399
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000577")]
		[SerializeField]
		private float hitAmountL;

		// Token: 0x04000578 RID: 1400
		[FieldOffset(Offset = "0x54")]
		[Token(Token = "0x4000578")]
		[SerializeField]
		private float hitAmountR;

		// Token: 0x04000579 RID: 1401
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000579")]
		[SerializeField]
		[Space]
		[Header("Springs (should be 400, 200, and false)")]
		private float climbForce;

		// Token: 0x0400057A RID: 1402
		[FieldOffset(Offset = "0x5C")]
		[Token(Token = "0x400057A")]
		[SerializeField]
		private float climbDrag;

		// Token: 0x0400057B RID: 1403
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x400057B")]
		[SerializeField]
		private bool disableMovement;

		// Token: 0x0400057C RID: 1404
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x400057C")]
		public AudioSource \u07A9Ԓգ߄;

		// Token: 0x0400057D RID: 1405
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x400057D")]
		public AudioSource ڒۆڿՎ;

		// Token: 0x0400057E RID: 1406
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x400057E")]
		public AudioClip[] ݭܬࡓݒ;

		// Token: 0x0400057F RID: 1407
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x400057F")]
		public AudioClip[] ٩\u05AD\u081C\u0821;

		// Token: 0x04000580 RID: 1408
		[FieldOffset(Offset = "0x88")]
		[Token(Token = "0x4000580")]
		public AudioClip[] Ժ\u05CD\u0882\u05AF;

		// Token: 0x04000581 RID: 1409
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000581")]
		public AudioClip[] \u059B\u070B\u07BFߌ;

		// Token: 0x04000582 RID: 1410
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x4000582")]
		public AudioClip[] \u0891ԽޓԾ;

		// Token: 0x04000583 RID: 1411
		[FieldOffset(Offset = "0xA0")]
		[Token(Token = "0x4000583")]
		public AudioClip[] \u05B5\u07B8ܞٳ;

		// Token: 0x04000584 RID: 1412
		[FieldOffset(Offset = "0xA8")]
		[Token(Token = "0x4000584")]
		public AudioClip[] ދӫӏݛ;

		// Token: 0x04000585 RID: 1413
		[FieldOffset(Offset = "0xB0")]
		[Token(Token = "0x4000585")]
		public AudioClip[] \u05FCއܖԽ;

		// Token: 0x04000586 RID: 1414
		[FieldOffset(Offset = "0xB8")]
		[Token(Token = "0x4000586")]
		public AudioClip[] ߢ\u0603\u085A\u05B0;

		// Token: 0x04000587 RID: 1415
		[FieldOffset(Offset = "0xC0")]
		[Token(Token = "0x4000587")]
		public AudioClip[] \u058Aࡊ\u06EDܕ;

		// Token: 0x04000588 RID: 1416
		[FieldOffset(Offset = "0xC8")]
		[Token(Token = "0x4000588")]
		public ParticleSystem ԯםӮۏ;

		// Token: 0x04000589 RID: 1417
		[FieldOffset(Offset = "0xD0")]
		[Token(Token = "0x4000589")]
		public bool \u0610Ӎ\u0615ۃ;

		// Token: 0x0400058A RID: 1418
		[FieldOffset(Offset = "0xD1")]
		[Token(Token = "0x400058A")]
		public bool \u065A\u07F0\u0599ߛ;

		// Token: 0x0400058B RID: 1419
		[FieldOffset(Offset = "0xD2")]
		[Token(Token = "0x400058B")]
		public bool ԧ\u06E7ذࢯ;

		// Token: 0x0400058C RID: 1420
		[FieldOffset(Offset = "0xD4")]
		[Token(Token = "0x400058C")]
		public float ڛ۰\u0700Կ;

		// Token: 0x0400058D RID: 1421
		[FieldOffset(Offset = "0xD8")]
		[Token(Token = "0x400058D")]
		public Transform \u0880\u07A8ݠڝ;

		// Token: 0x0400058E RID: 1422
		[FieldOffset(Offset = "0xE0")]
		[Token(Token = "0x400058E")]
		public AudioSource ۍ\u0745\u060E\u082E;

		// Token: 0x0400058F RID: 1423
		[FieldOffset(Offset = "0xE8")]
		[Token(Token = "0x400058F")]
		private InputDevice ڵ\u05A3\u0894ࠑ;

		// Token: 0x04000590 RID: 1424
		[FieldOffset(Offset = "0xF8")]
		[Token(Token = "0x4000590")]
		private InputDevice ݙޢغކ;

		// Token: 0x04000591 RID: 1425
		[FieldOffset(Offset = "0x108")]
		[Token(Token = "0x4000591")]
		private bool \u07EEݩڏࠉ = 257 != 0;

		// Token: 0x04000592 RID: 1426
		[FieldOffset(Offset = "0x109")]
		[Token(Token = "0x4000592")]
		private bool \u088B\u070Dל١;

		// Token: 0x04000593 RID: 1427
		[FieldOffset(Offset = "0x10C")]
		[Token(Token = "0x4000593")]
		private Vector3 \u05F8د\u089Dޓ;

		// Token: 0x04000594 RID: 1428
		[FieldOffset(Offset = "0x118")]
		[Token(Token = "0x4000594")]
		private Vector3 գړࠑࡋ;

		// Token: 0x04000595 RID: 1429
		[FieldOffset(Offset = "0x124")]
		[Token(Token = "0x4000595")]
		private bool \u088C\u05A2\u05A7ӑ;

		// Token: 0x04000596 RID: 1430
		[FieldOffset(Offset = "0x125")]
		[Token(Token = "0x4000596")]
		private bool ӄՌ\u081Fࢯ;

		// Token: 0x04000597 RID: 1431
		[FieldOffset(Offset = "0x126")]
		[Token(Token = "0x4000597")]
		private bool \u0821\u0594ࠌԃ;

		// Token: 0x04000598 RID: 1432
		[FieldOffset(Offset = "0x127")]
		[Token(Token = "0x4000598")]
		private bool Աݦդך;

		// Token: 0x0200010E RID: 270
		[Token(Token = "0x200010E")]
		[Serializable]
		public struct MatHitData
		{
			// Token: 0x04000599 RID: 1433
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4000599")]
			public string materialName;

			// Token: 0x0400059A RID: 1434
			[FieldOffset(Offset = "0x8")]
			[Token(Token = "0x400059A")]
			public bool OverrideSound;

			// Token: 0x0400059B RID: 1435
			[FieldOffset(Offset = "0xC")]
			[Token(Token = "0x400059B")]
			public float SoundOverride;

			// Token: 0x0400059C RID: 1436
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x400059C")]
			public AudioClip audio;

			// Token: 0x0400059D RID: 1437
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x400059D")]
			public Vector2 pitchAB;

			// Token: 0x0400059E RID: 1438
			[FieldOffset(Offset = "0x20")]
			[Token(Token = "0x400059E")]
			public bool slip;
		}
	}
}
