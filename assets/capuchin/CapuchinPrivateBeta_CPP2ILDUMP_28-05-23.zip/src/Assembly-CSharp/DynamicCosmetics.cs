﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using CapuchinPlayFab;
using Cpp2IlInjected;
using Photon.Pun;
using PlayFab;
using PlayFab.ClientModels;
using TMPro;
using UnityEngine;

// Token: 0x02000050 RID: 80
[Token(Token = "0x2000050")]
public class DynamicCosmetics : MonoBehaviourPunCallbacks
{
	// Token: 0x06000B92 RID: 2962 RVA: 0x0003DCE4 File Offset: 0x0003BEE4
	[Token(Token = "0x6000B92")]
	[Address(RVA = "0x28C917C", Offset = "0x28C917C", VA = "0x28C917C")]
	private void ࢣ\u0700Ԩա()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
		long num = 1L;
		this.փךړս = (num != 0L);
	}

	// Token: 0x06000B93 RID: 2963 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000B93")]
	[Address(RVA = "0x28C9354", Offset = "0x28C9354", VA = "0x28C9354")]
	public void ࡉ\u0700ޣՔ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B94 RID: 2964 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000B94")]
	[Address(RVA = "0x28CA31C", Offset = "0x28CA31C", VA = "0x28CA31C")]
	public void ӿ\u05C9Ԅ\u07A8()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B95 RID: 2965 RVA: 0x0003DD14 File Offset: 0x0003BF14
	[Token(Token = "0x6000B95")]
	[Address(RVA = "0x28CA70C", Offset = "0x28CA70C", VA = "0x28CA70C")]
	private IEnumerator ࡖ\u0888\u0734Ԋ(PurchaseCosmeticButton \u061Aոԕע)
	{
		long <>1__state;
		DynamicCosmetics.չӺ\u064Fࠆ չӺ_u064Fࠆ = new DynamicCosmetics.չӺ\u064Fࠆ((int)<>1__state);
		<>1__state = 1L;
		չӺ_u064Fࠆ.button = \u061Aոԕע;
		throw new NullReferenceException();
	}

	// Token: 0x06000B96 RID: 2966 RVA: 0x0003DD38 File Offset: 0x0003BF38
	[Token(Token = "0x6000B96")]
	[Address(RVA = "0x28CA784", Offset = "0x28CA784", VA = "0x28CA784")]
	private void ԎޗוӖ()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000B97 RID: 2967 RVA: 0x0003DD60 File Offset: 0x0003BF60
	[Token(Token = "0x6000B97")]
	[Address(RVA = "0x28CA958", Offset = "0x28CA958", VA = "0x28CA958")]
	[CompilerGenerated]
	private void ࢨԑ\u05A1\u07EF(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
		Dictionary<string, int> virtualCurrency2 = ޅࢶ\u05F3ܪ.VirtualCurrency;
	}

	// Token: 0x06000B98 RID: 2968 RVA: 0x0003DD84 File Offset: 0x0003BF84
	[Token(Token = "0x6000B98")]
	[Address(RVA = "0x28CAA2C", Offset = "0x28CAA2C", VA = "0x28CAA2C", Slot = "45")]
	public override void OnConnectedToMaster()
	{
		long num = 1L;
		this.փךړս = (num != 0L);
		this.ࢣ\u0700Ԩա();
	}

	// Token: 0x06000B99 RID: 2969 RVA: 0x0003DDA0 File Offset: 0x0003BFA0
	[Token(Token = "0x6000B99")]
	[Address(RVA = "0x28CAA38", Offset = "0x28CAA38", VA = "0x28CAA38")]
	private void ӏ\u07F6\u0822\u055F(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
		this.\u07F3ۀޜڹ = virtualCurrency;
		Dictionary<string, int> virtualCurrency2 = ޅࢶ\u05F3ܪ.VirtualCurrency;
		TMP_Text u07F1ڨ_u05EC_u082D = this.\u07F1ڨ\u05EC\u082D;
	}

	// Token: 0x06000B9A RID: 2970 RVA: 0x0003DDD0 File Offset: 0x0003BFD0
	[Token(Token = "0x6000B9A")]
	[Address(RVA = "0x28CAB18", Offset = "0x28CAB18", VA = "0x28CAB18")]
	private void ޔޔߪ\u05A4()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000B9B RID: 2971 RVA: 0x0003DDF8 File Offset: 0x0003BFF8
	[Token(Token = "0x6000B9B")]
	[Address(RVA = "0x28CACEC", Offset = "0x28CACEC", VA = "0x28CACEC")]
	public void ࠉ\u0559ӭ\u0886(PurchaseCosmeticButton \u061Aոԕע)
	{
		this.ԎޗוӖ();
		int u07F3ۀޜڹ = this.\u07F3ۀޜڹ;
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "goDownRPC";
		purchaseItemRequest.CatalogVersion = "EnableCosmetic";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000B9C RID: 2972 RVA: 0x0003DE68 File Offset: 0x0003C068
	[Token(Token = "0x6000B9C")]
	[Address(RVA = "0x28CB074", Offset = "0x28CB074", VA = "0x28CB074")]
	public void ߗӔ\u074Cࢩ(string \u07AE\u0615\u088C\u07ED, DynamicCosmeticsButton \u061Aոԕע)
	{
		TMP_Text u05A8ޖޔ_u = \u061Aոԕע.\u05A8ޖޔ\u0891;
		List<DynamicCosmetics.CosmeticItem> list = this.ݜߍٴע;
		List<DynamicCosmetics.CosmeticItem> list2 = this.ݜߍٴע;
		PhotonView photonView = this.ޣߑԤࡩ;
		object[] array = new object[0];
		if (\u07AE\u0615\u088C\u07ED == null || \u07AE\u0615\u088C\u07ED != null)
		{
			TMP_Text u05A8ޖޔ_u2 = \u061Aոԕע.\u05A8ޖޔ\u0891;
			DynamicCosmetics[] ސ_u087Cظج = this.ސ\u087Cظج;
			PhotonView pvCache = ސ_u087Cظج.pvCache;
			List<DynamicCosmetics.CosmeticItem> ܝࢪӅ_u = ސ_u087Cظج.ܝࢪӅ\u0615;
			DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.\u05B0Ӄ\u081D\u07A7;
			PhotonView pvCache2 = ސ_u087Cظج.pvCache;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000B9D RID: 2973 RVA: 0x0003DF54 File Offset: 0x0003C154
	[Token(Token = "0x6000B9D")]
	[Address(RVA = "0x28CB53C", Offset = "0x28CB53C", VA = "0x28CB53C")]
	public DynamicCosmetics()
	{
	}

	// Token: 0x06000B9E RID: 2974 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000B9E")]
	[Address(RVA = "0x28CB544", Offset = "0x28CB544", VA = "0x28CB544")]
	private void \u07FE\u0882Զ\u066D()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B9F RID: 2975 RVA: 0x0003DF68 File Offset: 0x0003C168
	[Token(Token = "0x6000B9F")]
	[Address(RVA = "0x28CBBEC", Offset = "0x28CBBEC", VA = "0x28CBBEC")]
	public void ن\u0741ݐߊ(PurchaseCosmeticButton \u061Aոԕע)
	{
		this.ԎޗוӖ();
		int u07F3ۀޜڹ = this.\u07F3ۀޜڹ;
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "Add/Remove Glasses";
		purchaseItemRequest.CatalogVersion = "User has been reported for: ";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000BA0 RID: 2976 RVA: 0x0003DFD8 File Offset: 0x0003C1D8
	[Token(Token = "0x6000BA0")]
	[Address(RVA = "0x28CBF74", Offset = "0x28CBF74", VA = "0x28CBF74")]
	public void ޢ\u05A8\u07FF\u0881(DynamicCosmeticsButton \u061Aոԕע)
	{
		string u061Aոԕע = \u061Aոԕע.\u061Aոԕע;
		if (u061Aոԕע != null)
		{
			bool flag = u061Aոԕע == "Toxicity";
			return;
		}
		long num = 1L;
		this.փךړս = (num != 0L);
	}

	// Token: 0x06000BA1 RID: 2977 RVA: 0x0003E0BC File Offset: 0x0003C2BC
	[Token(Token = "0x6000BA1")]
	[Address(RVA = "0x28CC668", Offset = "0x28CC668", VA = "0x28CC668")]
	private IEnumerator ױۈܞծ(PurchaseCosmeticButton \u061Aոԕע)
	{
		long <>1__state;
		DynamicCosmetics.չӺ\u064Fࠆ չӺ_u064Fࠆ = new DynamicCosmetics.չӺ\u064Fࠆ((int)<>1__state);
		<>1__state = 0L;
		չӺ_u064Fࠆ.button = \u061Aոԕע;
		throw new NullReferenceException();
	}

	// Token: 0x06000BA2 RID: 2978 RVA: 0x0003E0E0 File Offset: 0x0003C2E0
	[Token(Token = "0x6000BA2")]
	[Address(RVA = "0x28CC6E0", Offset = "0x28CC6E0", VA = "0x28CC6E0")]
	private IEnumerator \u0596Ժ\u07F6ࠀ(PurchaseCosmeticButton \u061Aոԕע)
	{
		long <>1__state;
		DynamicCosmetics.չӺ\u064Fࠆ չӺ_u064Fࠆ = new DynamicCosmetics.չӺ\u064Fࠆ((int)<>1__state);
		<>1__state = 1L;
		չӺ_u064Fࠆ.button = \u061Aոԕע;
		throw new NullReferenceException();
	}

	// Token: 0x06000BA3 RID: 2979 RVA: 0x0003E104 File Offset: 0x0003C304
	[Token(Token = "0x6000BA3")]
	[Address(RVA = "0x28CC758", Offset = "0x28CC758", VA = "0x28CC758")]
	public void ࢱݺ٥ե(DynamicCosmeticsButton \u061Aոԕע)
	{
		string u061Aոԕע = \u061Aոԕע.\u061Aոԕע;
		if (u061Aոԕע != null)
		{
			bool flag = u061Aոԕע == "Hats";
			return;
		}
		long num = 1L;
		this.փךړս = (num != 0L);
	}

	// Token: 0x06000BA4 RID: 2980 RVA: 0x0003E1D8 File Offset: 0x0003C3D8
	[Token(Token = "0x6000BA4")]
	[Address(RVA = "0x28CCE30", Offset = "0x28CCE30", VA = "0x28CCE30")]
	public void \u0670\u06E6ښ\u0613(DynamicCosmeticsButton \u061Aոԕע)
	{
		string u061Aոԕע = \u061Aոԕע.\u061Aոԕע;
		if (u061Aոԕע != null)
		{
			bool flag = u061Aոԕע == "containsStaff";
			long num = 3L;
			this.ߊߑࢯߊ = (int)num;
			return;
		}
		long num2 = 1L;
		this.փךړս = (num2 != 0L);
	}

	// Token: 0x06000BA5 RID: 2981 RVA: 0x0003E2B4 File Offset: 0x0003C4B4
	[Token(Token = "0x6000BA5")]
	[Address(RVA = "0x28CD068", Offset = "0x28CD068", VA = "0x28CD068")]
	private void \u08B5Әߦݣ()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000BA6 RID: 2982 RVA: 0x0003E2DC File Offset: 0x0003C4DC
	[Token(Token = "0x6000BA6")]
	[Address(RVA = "0x28CAFFC", Offset = "0x28CAFFC", VA = "0x28CAFFC")]
	private IEnumerator \u0859Ԣل\u081A(PurchaseCosmeticButton \u061Aոԕע)
	{
		long <>1__state;
		DynamicCosmetics.չӺ\u064Fࠆ չӺ_u064Fࠆ = new DynamicCosmetics.չӺ\u064Fࠆ((int)<>1__state);
		<>1__state = 1L;
		չӺ_u064Fࠆ.button = \u061Aոԕע;
		throw new NullReferenceException();
	}

	// Token: 0x06000BA7 RID: 2983 RVA: 0x0003E300 File Offset: 0x0003C500
	[Token(Token = "0x6000BA7")]
	[Address(RVA = "0x28CD23C", Offset = "0x28CD23C", VA = "0x28CD23C")]
	public void \u0732ߩګ\u0818(PurchaseCosmeticButton \u061Aոԕע)
	{
		this.ࢣ\u0700Ԩա();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "BN";
		purchaseItemRequest.CatalogVersion = "CapuchinStore";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000BA8 RID: 2984 RVA: 0x0003E368 File Offset: 0x0003C568
	[Token(Token = "0x6000BA8")]
	[Address(RVA = "0x28CD54C", Offset = "0x28CD54C", VA = "0x28CD54C")]
	private void \u05A7ݒ\u083B\u081C()
	{
		DynamicCosmetics.ލ\u0882ײࢲ = this;
	}

	// Token: 0x06000BA9 RID: 2985 RVA: 0x0003E37C File Offset: 0x0003C57C
	[Token(Token = "0x6000BA9")]
	[Address(RVA = "0x28CC97C", Offset = "0x28CC97C", VA = "0x28CC97C")]
	public void ࡁ\u05BF٠\u07EE(string \u07AE\u0615\u088C\u07ED, DynamicCosmeticsButton \u061Aոԕע)
	{
		TMP_Text u05A8ޖޔ_u = \u061Aոԕע.\u05A8ޖޔ\u0891;
		List<DynamicCosmetics.CosmeticItem> list = this.ݜߍٴע;
		List<DynamicCosmetics.CosmeticItem> list2 = this.ݜߍٴע;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.\u05B0Ӄ\u081D\u07A7;
		PhotonView photonView = this.ޣߑԤࡩ;
		object[] array = new object[1];
		if (\u07AE\u0615\u088C\u07ED == null || \u07AE\u0615\u088C\u07ED != null)
		{
			TMP_Text u05A8ޖޔ_u2 = \u061Aոԕע.\u05A8ޖޔ\u0891;
			DynamicCosmetics[] ސ_u087Cظج = this.ސ\u087Cظج;
			PhotonView pvCache = ސ_u087Cظج.pvCache;
			object[] instantiationDataField = pvCache.instantiationDataField;
			DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A2 = this.\u05B0Ӄ\u081D\u07A7;
			PhotonView pvCache2 = ސ_u087Cظج.pvCache;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000BAA RID: 2986 RVA: 0x0003E464 File Offset: 0x0003C664
	[Token(Token = "0x6000BAA")]
	[Address(RVA = "0x28CBEFC", Offset = "0x28CBEFC", VA = "0x28CBEFC")]
	private IEnumerator ӛ\u05BBӠؽ(PurchaseCosmeticButton \u061Aոԕע)
	{
		long <>1__state;
		DynamicCosmetics.չӺ\u064Fࠆ չӺ_u064Fࠆ = new DynamicCosmetics.չӺ\u064Fࠆ((int)<>1__state);
		<>1__state = 0L;
		չӺ_u064Fࠆ.button = \u061Aոԕע;
		throw new NullReferenceException();
	}

	// Token: 0x06000BAB RID: 2987 RVA: 0x0003E488 File Offset: 0x0003C688
	[Token(Token = "0x6000BAB")]
	[Address(RVA = "0x28CD5B4", Offset = "0x28CD5B4", VA = "0x28CD5B4")]
	private void \u07B4\u0827םڵ()
	{
		DynamicCosmetics.ލ\u0882ײࢲ = this;
		long num = 8L;
		this.ߊߑࢯߊ = (int)num;
	}

	// Token: 0x06000BAC RID: 2988 RVA: 0x0003E4A4 File Offset: 0x0003C6A4
	[Token(Token = "0x6000BAC")]
	[Address(RVA = "0x28CD620", Offset = "0x28CD620", VA = "0x28CD620")]
	private IEnumerator \u05A2ڬ\u05A1Բ(PurchaseCosmeticButton \u061Aոԕע)
	{
		long <>1__state;
		DynamicCosmetics.չӺ\u064Fࠆ չӺ_u064Fࠆ = new DynamicCosmetics.չӺ\u064Fࠆ((int)<>1__state);
		<>1__state = 1L;
		չӺ_u064Fࠆ.button = \u061Aոԕע;
		throw new NullReferenceException();
	}

	// Token: 0x06000BAD RID: 2989 RVA: 0x0003E4C8 File Offset: 0x0003C6C8
	[Token(Token = "0x6000BAD")]
	[Address(RVA = "0x28CD698", Offset = "0x28CD698", VA = "0x28CD698")]
	public void \u05F6يݬ\u0610(string \u07AE\u0615\u088C\u07ED, DynamicCosmeticsButton \u061Aոԕע)
	{
		TMP_Text u05A8ޖޔ_u = \u061Aոԕע.\u05A8ޖޔ\u0891;
		List<DynamicCosmetics.CosmeticItem> list = this.ݜߍٴע;
		List<DynamicCosmetics.CosmeticItem> list2 = this.ݜߍٴע;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.\u05B0Ӄ\u081D\u07A7;
		PhotonView photonView = this.ޣߑԤࡩ;
		object[] array = new object[1];
		if (\u07AE\u0615\u088C\u07ED == null || \u07AE\u0615\u088C\u07ED != null)
		{
			TMP_Text u05A8ޖޔ_u2 = \u061Aոԕע.\u05A8ޖޔ\u0891;
			DynamicCosmetics[] ސ_u087Cظج = this.ސ\u087Cظج;
			PhotonView pvCache = ސ_u087Cظج.pvCache;
			int ownerActorNr = pvCache.ownerActorNr;
			DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A2 = this.\u05B0Ӄ\u081D\u07A7;
			PhotonView pvCache2 = ސ_u087Cظج.pvCache;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000BAE RID: 2990 RVA: 0x0003E5A8 File Offset: 0x0003C7A8
	[Token(Token = "0x6000BAE")]
	[Address(RVA = "0x28CDB58", Offset = "0x28CDB58", VA = "0x28CDB58")]
	private void Awake()
	{
		DynamicCosmetics.ލ\u0882ײࢲ = this;
		long num = 2L;
		this.ߊߑࢯߊ = (int)num;
	}

	// Token: 0x06000BAF RID: 2991 RVA: 0x0003E5C4 File Offset: 0x0003C7C4
	[Token(Token = "0x6000BAF")]
	[Address(RVA = "0x28CDBC4", Offset = "0x28CDBC4", VA = "0x28CDBC4")]
	public void ى\u0875\u0876ڝ(PurchaseCosmeticButton \u061Aոԕע)
	{
		this.\u08B5Әߦݣ();
		int u07F3ۀޜڹ = this.\u07F3ۀޜڹ;
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "";
		purchaseItemRequest.CatalogVersion = "Network Player";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000BB0 RID: 2992 RVA: 0x0003E634 File Offset: 0x0003C834
	[Token(Token = "0x6000BB0")]
	[Address(RVA = "0x28CDF4C", Offset = "0x28CDF4C", VA = "0x28CDF4C")]
	public void \u066Bࢳֈԫ(PurchaseCosmeticButton \u061Aոԕע)
	{
		this.ࢣ\u0700Ԩա();
		int u07F3ۀޜڹ = this.\u07F3ۀޜڹ;
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "HandR";
		purchaseItemRequest.CatalogVersion = "Agreed";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000BB1 RID: 2993 RVA: 0x0003E69C File Offset: 0x0003C89C
	[Token(Token = "0x6000BB1")]
	[Address(RVA = "0x28CE25C", Offset = "0x28CE25C", VA = "0x28CE25C")]
	private IEnumerator \u07AEإފՌ(PurchaseCosmeticButton \u061Aոԕע)
	{
		long <>1__state;
		DynamicCosmetics.չӺ\u064Fࠆ չӺ_u064Fࠆ = new DynamicCosmetics.չӺ\u064Fࠆ((int)<>1__state);
		<>1__state = 1L;
		չӺ_u064Fࠆ.button = \u061Aոԕע;
		throw new NullReferenceException();
	}

	// Token: 0x06000BB2 RID: 2994 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000BB2")]
	[Address(RVA = "0x28CE2D4", Offset = "0x28CE2D4", VA = "0x28CE2D4")]
	private void ԟ\u086Cޣ\u055E()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BB3 RID: 2995 RVA: 0x0003E6C0 File Offset: 0x0003C8C0
	[Token(Token = "0x6000BB3")]
	[Address(RVA = "0x28CECF8", Offset = "0x28CECF8", VA = "0x28CECF8")]
	public void ٢ӲߠӐ(PurchaseCosmeticButton \u061Aոԕע)
	{
		this.ԎޗוӖ();
		int u07F3ۀޜڹ = this.\u07F3ۀޜڹ;
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.CatalogVersion = "On";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000BB4 RID: 2996 RVA: 0x0003E724 File Offset: 0x0003C924
	[Token(Token = "0x6000BB4")]
	[Address(RVA = "0x28CF008", Offset = "0x28CF008", VA = "0x28CF008")]
	private IEnumerator \u05CA\u066Cࡘي(PurchaseCosmeticButton \u061Aոԕע)
	{
		long <>1__state;
		DynamicCosmetics.չӺ\u064Fࠆ չӺ_u064Fࠆ = new DynamicCosmetics.չӺ\u064Fࠆ((int)<>1__state);
		<>1__state = 1L;
		չӺ_u064Fࠆ.button = \u061Aոԕע;
		throw new NullReferenceException();
	}

	// Token: 0x06000BB5 RID: 2997 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000BB5")]
	[Address(RVA = "0x28CF080", Offset = "0x28CF080", VA = "0x28CF080")]
	private void ފՖߢ\u059B()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BB6 RID: 2998 RVA: 0x0003E748 File Offset: 0x0003C948
	[Token(Token = "0x6000BB6")]
	[Address(RVA = "0x28CC190", Offset = "0x28CC190", VA = "0x28CC190")]
	public void ߟ\u0612\u0735\u0740(string \u07AE\u0615\u088C\u07ED, DynamicCosmeticsButton \u061Aոԕע)
	{
		TMP_Text u05A8ޖޔ_u = \u061Aոԕע.\u05A8ޖޔ\u0891;
		List<DynamicCosmetics.CosmeticItem> list = this.ݜߍٴע;
		List<DynamicCosmetics.CosmeticItem> list2 = this.ݜߍٴע;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.\u05B0Ӄ\u081D\u07A7;
		PhotonView photonView = this.ޣߑԤࡩ;
		object[] array = new object[1];
		if (\u07AE\u0615\u088C\u07ED == null || \u07AE\u0615\u088C\u07ED != null)
		{
			TMP_Text u05A8ޖޔ_u2 = \u061Aոԕע.\u05A8ޖޔ\u0891;
			DynamicCosmetics[] ސ_u087Cظج = this.ސ\u087Cظج;
			PhotonView pvCache = ސ_u087Cظج.pvCache;
			object[] instantiationDataField = pvCache.instantiationDataField;
			DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A2 = this.\u05B0Ӄ\u081D\u07A7;
			PhotonView pvCache2 = ސ_u087Cظج.pvCache;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000BB7 RID: 2999 RVA: 0x0003E838 File Offset: 0x0003CA38
	[Token(Token = "0x6000BB7")]
	[Address(RVA = "0x28CF704", Offset = "0x28CF704", VA = "0x28CF704")]
	public void \u08B5\u061Fݫو(PurchaseCosmeticButton \u061Aոԕע)
	{
		new DynamicCosmetics.ߕݶ\u07F8ԭ().<>4__this = this;
		this.ԎޗוӖ();
		int u07F3ۀޜڹ = this.\u07F3ۀޜڹ;
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "username";
		purchaseItemRequest.CatalogVersion = "_Tint";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000BB8 RID: 3000 RVA: 0x0003E8A0 File Offset: 0x0003CAA0
	[Token(Token = "0x6000BB8")]
	[Address(RVA = "0x28CDED4", Offset = "0x28CDED4", VA = "0x28CDED4")]
	private IEnumerator ۄߣࢤӈ(PurchaseCosmeticButton \u061Aոԕע)
	{
		long <>1__state;
		DynamicCosmetics.չӺ\u064Fࠆ չӺ_u064Fࠆ = new DynamicCosmetics.չӺ\u064Fࠆ((int)<>1__state);
		<>1__state = 0L;
		չӺ_u064Fࠆ.button = \u061Aոԕע;
		throw new NullReferenceException();
	}

	// Token: 0x06000BB9 RID: 3001 RVA: 0x0003E8C4 File Offset: 0x0003CAC4
	[Token(Token = "0x6000BB9")]
	[Address(RVA = "0x28CFA14", Offset = "0x28CFA14", VA = "0x28CFA14")]
	public void \u05A6Ԝؤޣ(string \u07AE\u0615\u088C\u07ED, DynamicCosmeticsButton \u061Aոԕע)
	{
		TMP_Text u05A8ޖޔ_u = \u061Aոԕע.\u05A8ޖޔ\u0891;
		List<DynamicCosmetics.CosmeticItem> list = this.ݜߍٴע;
		List<DynamicCosmetics.CosmeticItem> list2 = this.ݜߍٴע;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.\u05B0Ӄ\u081D\u07A7;
		PhotonView photonView = this.ޣߑԤࡩ;
		object[] array = new object[1];
		if (\u07AE\u0615\u088C\u07ED == null || \u07AE\u0615\u088C\u07ED != null)
		{
			TMP_Text u05A8ޖޔ_u2 = \u061Aոԕע.\u05A8ޖޔ\u0891;
			DynamicCosmetics[] ސ_u087Cظج = this.ސ\u087Cظج;
			PhotonView pvCache = ސ_u087Cظج.pvCache;
			object[] instantiationDataField = pvCache.instantiationDataField;
			DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A2 = this.\u05B0Ӄ\u081D\u07A7;
			PhotonView pvCache2 = ސ_u087Cظج.pvCache;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000BBA RID: 3002 RVA: 0x0003E9B4 File Offset: 0x0003CBB4
	[Token(Token = "0x6000BBA")]
	[Address(RVA = "0x28CFEEC", Offset = "0x28CFEEC", VA = "0x28CFEEC")]
	public void Ԑ\u086Cڦҿ(string \u07AE\u0615\u088C\u07ED, DynamicCosmeticsButton \u061Aոԕע)
	{
		TMP_Text u05A8ޖޔ_u = \u061Aոԕע.\u05A8ޖޔ\u0891;
		List<DynamicCosmetics.CosmeticItem> list = this.ݜߍٴע;
		List<DynamicCosmetics.CosmeticItem> list2 = this.ݜߍٴע;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.\u05B0Ӄ\u081D\u07A7;
		PhotonView photonView = this.ޣߑԤࡩ;
		object[] array = new object[1];
		if (\u07AE\u0615\u088C\u07ED == null || \u07AE\u0615\u088C\u07ED != null)
		{
			TMP_Text u05A8ޖޔ_u2 = \u061Aոԕע.\u05A8ޖޔ\u0891;
			DynamicCosmetics[] ސ_u087Cظج = this.ސ\u087Cظج;
			PhotonView pvCache = ސ_u087Cظج.pvCache;
			object[] instantiationDataField = pvCache.instantiationDataField;
			DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A2 = this.\u05B0Ӄ\u081D\u07A7;
			PhotonView pvCache2 = ސ_u087Cظج.pvCache;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000BBB RID: 3003 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000BBB")]
	[Address(RVA = "0x28D03C4", Offset = "0x28D03C4", VA = "0x28D03C4")]
	private void Update()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BBC RID: 3004 RVA: 0x0003EAA4 File Offset: 0x0003CCA4
	[Token(Token = "0x6000BBC")]
	[Address(RVA = "0x28D0A90", Offset = "0x28D0A90", VA = "0x28D0A90")]
	private void ڊ\u0745\u07ED\u07A7(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
		this.\u07F3ۀޜڹ = virtualCurrency;
		Dictionary<string, int> virtualCurrency2 = ޅࢶ\u05F3ܪ.VirtualCurrency;
		TMP_Text u07F1ڨ_u05EC_u082D = this.\u07F1ڨ\u05EC\u082D;
	}

	// Token: 0x06000BBD RID: 3005 RVA: 0x0003EAD4 File Offset: 0x0003CCD4
	[Token(Token = "0x6000BBD")]
	[Address(RVA = "0x28D0B70", Offset = "0x28D0B70", VA = "0x28D0B70")]
	private void ӂߡՅר()
	{
		DynamicCosmetics.ލ\u0882ײࢲ = this;
		this.ߊߑࢯߊ = 5;
	}

	// Token: 0x06000BBE RID: 3006 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000BBE")]
	[Address(RVA = "0x28CE9A0", Offset = "0x28CE9A0", VA = "0x28CE9A0")]
	public void \u085E\u06FDݾհ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BBF RID: 3007 RVA: 0x0003EAF0 File Offset: 0x0003CCF0
	[Token(Token = "0x6000BBF")]
	[Address(RVA = "0x28D0BDC", Offset = "0x28D0BDC", VA = "0x28D0BDC")]
	private void \u07F2\u07F7\u06FE\u081D()
	{
		DynamicCosmetics.ލ\u0882ײࢲ = this;
		long num = 8L;
		this.ߊߑࢯߊ = (int)num;
	}

	// Token: 0x06000BC0 RID: 3008 RVA: 0x0003EB0C File Offset: 0x0003CD0C
	[Token(Token = "0x6000BC0")]
	[Address(RVA = "0x28D0C48", Offset = "0x28D0C48", VA = "0x28D0C48")]
	private void ߄\u07FBࡡ\u07AF()
	{
		DynamicCosmetics.ލ\u0882ײࢲ = this;
		long num = 8L;
		this.ߊߑࢯߊ = (int)num;
	}

	// Token: 0x06000BC1 RID: 3009 RVA: 0x0003EB28 File Offset: 0x0003CD28
	[Token(Token = "0x6000BC1")]
	[Address(RVA = "0x28D0CB4", Offset = "0x28D0CB4", VA = "0x28D0CB4")]
	public void \u0828\u0530م\u0653(PurchaseCosmeticButton \u061Aոԕע)
	{
		this.\u08B5Әߦݣ();
		int u07F3ۀޜڹ = this.\u07F3ۀޜڹ;
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.CatalogVersion = "hh:mmtt";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x0400019B RID: 411
	[Token(Token = "0x400019B")]
	public static DynamicCosmetics ލ\u0882ײࢲ;

	// Token: 0x0400019C RID: 412
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400019C")]
	public List<DynamicCosmetics.CosmeticItem> ܢ\u05ACڅة;

	// Token: 0x0400019D RID: 413
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400019D")]
	[Space]
	public List<DynamicCosmetics.CosmeticItem> ܝࢪӅ\u0615;

	// Token: 0x0400019E RID: 414
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400019E")]
	public List<DynamicCosmetics.CosmeticItem> ߇\u0885\u0888\u0701;

	// Token: 0x0400019F RID: 415
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400019F")]
	public List<DynamicCosmetics.CosmeticItem> ӓٱ\u0742\u05C1;

	// Token: 0x040001A0 RID: 416
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40001A0")]
	public List<DynamicCosmetics.CosmeticItem> \u060C\u06EA\u055CԀ;

	// Token: 0x040001A1 RID: 417
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40001A1")]
	public int \u07F3ۀޜڹ;

	// Token: 0x040001A2 RID: 418
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40001A2")]
	public TMP_Text \u07F1ڨ\u05EC\u082D;

	// Token: 0x040001A3 RID: 419
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40001A3")]
	[Space]
	public DynamicParent[] Ӑ\u086BԁԻ;

	// Token: 0x040001A4 RID: 420
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x40001A4")]
	[Space]
	public DynamicCosmetics.ԟ\u0825\u07EF߅ \u05B0Ӄ\u081D\u07A7;

	// Token: 0x040001A5 RID: 421
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x40001A5")]
	public NetworkPlayerSpawner ݺ\u05F9פݵ;

	// Token: 0x040001A6 RID: 422
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x40001A6")]
	private PhotonView ޣߑԤࡩ;

	// Token: 0x040001A7 RID: 423
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x40001A7")]
	public DynamicCosmetics[] ސ\u087Cظج;

	// Token: 0x040001A8 RID: 424
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x40001A8")]
	public List<DynamicCosmetics.CosmeticItem> ݜߍٴע;

	// Token: 0x040001A9 RID: 425
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x40001A9")]
	public int \u0590\u0744Ӈܕ;

	// Token: 0x040001AA RID: 426
	[FieldOffset(Offset = "0x8C")]
	[Token(Token = "0x40001AA")]
	public int ߙڍפؼ;

	// Token: 0x040001AB RID: 427
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x40001AB")]
	public int ߊߑࢯߊ;

	// Token: 0x040001AC RID: 428
	[FieldOffset(Offset = "0x94")]
	[Token(Token = "0x40001AC")]
	[HideInInspector]
	public bool փךړս;

	// Token: 0x02000051 RID: 81
	[Token(Token = "0x2000051")]
	[Serializable]
	public struct CosmeticItem
	{
		// Token: 0x040001AD RID: 429
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40001AD")]
		public string itemName;

		// Token: 0x040001AE RID: 430
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x40001AE")]
		[Space]
		public DynamicCosmetics.ԟ\u0825\u07EF߅ itemCategory;

		// Token: 0x040001AF RID: 431
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40001AF")]
		[Space]
		public string displayName;
	}

	// Token: 0x02000052 RID: 82
	[Token(Token = "0x2000052")]
	public enum ԟ\u0825\u07EF߅
	{
		// Token: 0x040001B1 RID: 433
		[Token(Token = "0x40001B1")]
		ڕ\u05ACӂ\u081F,
		// Token: 0x040001B2 RID: 434
		[Token(Token = "0x40001B2")]
		ࠎ\u06DEڂݚ,
		// Token: 0x040001B3 RID: 435
		[Token(Token = "0x40001B3")]
		\u06DB\u05AC\u07B0\u086B
	}

	// Token: 0x02000053 RID: 83
	[Token(Token = "0x2000053")]
	[CompilerGenerated]
	private sealed class ߕݶ\u07F8ԭ
	{
		// Token: 0x06000BC2 RID: 3010 RVA: 0x0003EB8C File Offset: 0x0003CD8C
		[Token(Token = "0x6000BC2")]
		[Address(RVA = "0x213222C", Offset = "0x213222C", VA = "0x213222C")]
		public ߕݶ\u07F8ԭ()
		{
		}

		// Token: 0x06000BC3 RID: 3011 RVA: 0x0003EBA0 File Offset: 0x0003CDA0
		[Token(Token = "0x6000BC3")]
		[Address(RVA = "0x2132234", Offset = "0x2132234", VA = "0x2132234")]
		internal void \u05EBӵݞ\u0816(PurchaseItemResult result)
		{
			List<ItemInstance> u0738ؿࠇؠ = LoginManager.كݕ\u05F3\u0589.\u0738ؿࠇؠ;
			TMP_Text u05A8ޖޔ_u = this.button.\u05A8ޖޔ\u0891;
			DynamicCosmetics dynamicCosmetics = this.<>4__this;
			long փךړս = 1L;
			dynamicCosmetics.փךړս = (փךړս != 0L);
			this.<>4__this.ࢣ\u0700Ԩա();
		}

		// Token: 0x040001B4 RID: 436
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40001B4")]
		public PurchaseCosmeticButton button;

		// Token: 0x040001B5 RID: 437
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40001B5")]
		public DynamicCosmetics <>4__this;
	}
}
