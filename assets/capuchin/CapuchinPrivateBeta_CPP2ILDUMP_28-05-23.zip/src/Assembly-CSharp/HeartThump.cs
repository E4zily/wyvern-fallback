﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000BF RID: 191
[Token(Token = "0x20000BF")]
public class HeartThump : MonoBehaviour
{
	// Token: 0x06001C4A RID: 7242 RVA: 0x00092C18 File Offset: 0x00090E18
	[Token(Token = "0x6001C4A")]
	[Address(RVA = "0x2753C50", Offset = "0x2753C50", VA = "0x2753C50")]
	public void ԣԭՋࠏ()
	{
		float u0870_u0878_u059Dء = this.\u0870\u0878\u059Dء;
		Vector3 position = base.transform.position;
		Vector3 position2 = this.߉ࡌڙ\u05C1.position;
	}

	// Token: 0x06001C4B RID: 7243 RVA: 0x00092C4C File Offset: 0x00090E4C
	[Token(Token = "0x6001C4B")]
	[Address(RVA = "0x2753CDC", Offset = "0x2753CDC", VA = "0x2753CDC")]
	public IEnumerator ܕ\u086Cԓݗ()
	{
		long <>1__state;
		HeartThump.ڥ\u07B0ܖڄ ڥ_u07B0ܖڄ = new HeartThump.ڥ\u07B0ܖڄ((int)<>1__state);
		<>1__state = 0L;
		ڥ_u07B0ܖڄ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001C4C RID: 7244 RVA: 0x00092C70 File Offset: 0x00090E70
	[Token(Token = "0x6001C4C")]
	[Address(RVA = "0x2753D54", Offset = "0x2753D54", VA = "0x2753D54")]
	public void ئ\u08B5ۂۮ()
	{
		Coroutine coroutine = base.StartCoroutine("spooky guy true");
	}

	// Token: 0x06001C4D RID: 7245 RVA: 0x00092C8C File Offset: 0x00090E8C
	[Token(Token = "0x6001C4D")]
	[Address(RVA = "0x2753DA4", Offset = "0x2753DA4", VA = "0x2753DA4")]
	public void ޟݔԈԭ()
	{
		Coroutine coroutine = base.StartCoroutine("sound play play");
	}

	// Token: 0x06001C4E RID: 7246 RVA: 0x00092CA8 File Offset: 0x00090EA8
	[Token(Token = "0x6001C4E")]
	[Address(RVA = "0x2753DF4", Offset = "0x2753DF4", VA = "0x2753DF4")]
	public void Awake()
	{
	}

	// Token: 0x06001C4F RID: 7247 RVA: 0x00092CB8 File Offset: 0x00090EB8
	[Token(Token = "0x6001C4F")]
	[Address(RVA = "0x2753E44", Offset = "0x2753E44", VA = "0x2753E44")]
	public void Update()
	{
		float u0870_u0878_u059Dء = this.\u0870\u0878\u059Dء;
		Vector3 position = base.transform.position;
		Vector3 position2 = this.߉ࡌڙ\u05C1.position;
	}

	// Token: 0x06001C50 RID: 7248 RVA: 0x00092CEC File Offset: 0x00090EEC
	[Token(Token = "0x6001C50")]
	[Address(RVA = "0x2753ED0", Offset = "0x2753ED0", VA = "0x2753ED0")]
	public void \u070Aәޣے()
	{
		float u0870_u0878_u059Dء = this.\u0870\u0878\u059Dء;
		Vector3 position = base.transform.position;
		Vector3 position2 = this.߉ࡌڙ\u05C1.position;
	}

	// Token: 0x06001C51 RID: 7249 RVA: 0x00092D20 File Offset: 0x00090F20
	[Token(Token = "0x6001C51")]
	[Address(RVA = "0x2753F5C", Offset = "0x2753F5C", VA = "0x2753F5C")]
	public HeartThump()
	{
	}

	// Token: 0x06001C52 RID: 7250 RVA: 0x00092D34 File Offset: 0x00090F34
	[Token(Token = "0x6001C52")]
	[Address(RVA = "0x2753F64", Offset = "0x2753F64", VA = "0x2753F64")]
	public IEnumerator ٳࢠڷݐ()
	{
		long <>1__state;
		HeartThump.ڥ\u07B0ܖڄ ڥ_u07B0ܖڄ = new HeartThump.ڥ\u07B0ܖڄ((int)<>1__state);
		<>1__state = 1L;
		ڥ_u07B0ܖڄ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001C53 RID: 7251 RVA: 0x00092D58 File Offset: 0x00090F58
	[Token(Token = "0x6001C53")]
	[Address(RVA = "0x2753FDC", Offset = "0x2753FDC", VA = "0x2753FDC")]
	public void څ\u0705بޑ()
	{
		Coroutine coroutine = base.StartCoroutine("");
	}

	// Token: 0x06001C54 RID: 7252 RVA: 0x00092D74 File Offset: 0x00090F74
	[Token(Token = "0x6001C54")]
	[Address(RVA = "0x275402C", Offset = "0x275402C", VA = "0x275402C")]
	public void \u061B\u05EEوۈ()
	{
		float u0870_u0878_u059Dء = this.\u0870\u0878\u059Dء;
		Vector3 position = base.transform.position;
		Vector3 position2 = this.߉ࡌڙ\u05C1.position;
	}

	// Token: 0x06001C55 RID: 7253 RVA: 0x00092DA8 File Offset: 0x00090FA8
	[Token(Token = "0x6001C55")]
	[Address(RVA = "0x27540B8", Offset = "0x27540B8", VA = "0x27540B8")]
	public void \u05F7ԝߠӱ()
	{
		float u0870_u0878_u059Dء = this.\u0870\u0878\u059Dء;
		Vector3 position = base.transform.position;
		Vector3 position2 = this.߉ࡌڙ\u05C1.position;
	}

	// Token: 0x06001C56 RID: 7254 RVA: 0x00092DDC File Offset: 0x00090FDC
	[Token(Token = "0x6001C56")]
	[Address(RVA = "0x2754144", Offset = "0x2754144", VA = "0x2754144")]
	public IEnumerator Ӿ\u0706ޏޡ()
	{
		long <>1__state;
		HeartThump.ڥ\u07B0ܖڄ ڥ_u07B0ܖڄ = new HeartThump.ڥ\u07B0ܖڄ((int)<>1__state);
		<>1__state = 0L;
		ڥ_u07B0ܖڄ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001C57 RID: 7255 RVA: 0x00092E00 File Offset: 0x00091000
	[Token(Token = "0x6001C57")]
	[Address(RVA = "0x27541BC", Offset = "0x27541BC", VA = "0x27541BC")]
	public void ފՖߢ\u059B()
	{
		float u0870_u0878_u059Dء = this.\u0870\u0878\u059Dء;
		Vector3 position = base.transform.position;
		Vector3 position2 = this.߉ࡌڙ\u05C1.position;
	}

	// Token: 0x06001C58 RID: 7256 RVA: 0x00092E34 File Offset: 0x00091034
	[Token(Token = "0x6001C58")]
	[Address(RVA = "0x2754248", Offset = "0x2754248", VA = "0x2754248")]
	public IEnumerator ࢻږܮڋ()
	{
		long <>1__state;
		HeartThump.ڥ\u07B0ܖڄ ڥ_u07B0ܖڄ = new HeartThump.ڥ\u07B0ܖڄ((int)<>1__state);
		<>1__state = 0L;
		ڥ_u07B0ܖڄ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001C59 RID: 7257 RVA: 0x00092E58 File Offset: 0x00091058
	[Token(Token = "0x6001C59")]
	[Address(RVA = "0x27542C0", Offset = "0x27542C0", VA = "0x27542C0")]
	public void Ռ\u06EA\u05AFࡇ()
	{
		Coroutine coroutine = base.StartCoroutine("Tagged");
	}

	// Token: 0x06001C5A RID: 7258 RVA: 0x00092E74 File Offset: 0x00091074
	[Token(Token = "0x6001C5A")]
	[Address(RVA = "0x2754310", Offset = "0x2754310", VA = "0x2754310")]
	public IEnumerator ࠌ\u06E8ӭՒ()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06001C5B RID: 7259 RVA: 0x00092E88 File Offset: 0x00091088
	[Token(Token = "0x6001C5B")]
	[Address(RVA = "0x2754388", Offset = "0x2754388", VA = "0x2754388")]
	public void ߄\u07FBࡡ\u07AF()
	{
		Coroutine coroutine = base.StartCoroutine("Bruh i cannot go here you stupid L bozo");
	}

	// Token: 0x06001C5C RID: 7260 RVA: 0x00092EA4 File Offset: 0x000910A4
	[Token(Token = "0x6001C5C")]
	[Address(RVA = "0x27543D8", Offset = "0x27543D8", VA = "0x27543D8")]
	public IEnumerator ܦՍ\u064Eڦ()
	{
		long <>1__state;
		HeartThump.ڥ\u07B0ܖڄ ڥ_u07B0ܖڄ = new HeartThump.ڥ\u07B0ܖڄ((int)<>1__state);
		<>1__state = 0L;
		ڥ_u07B0ܖڄ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x040003A9 RID: 937
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003A9")]
	public float ի\u0746ܥ\u07B9;

	// Token: 0x040003AA RID: 938
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003AA")]
	public Transform ߉ࡌڙ\u05C1;

	// Token: 0x040003AB RID: 939
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003AB")]
	public AudioSource \u073B\u070Aޏࡂ;

	// Token: 0x040003AC RID: 940
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003AC")]
	public AudioClip ӥٵۏՅ;

	// Token: 0x040003AD RID: 941
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40003AD")]
	public float \u0870\u0878\u059Dء;
}
