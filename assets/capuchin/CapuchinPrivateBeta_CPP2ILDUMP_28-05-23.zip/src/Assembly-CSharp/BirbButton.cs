﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200009A RID: 154
[Token(Token = "0x200009A")]
public class BirbButton : MonoBehaviour
{
	// Token: 0x060016E8 RID: 5864 RVA: 0x00081520 File Offset: 0x0007F720
	[Token(Token = "0x60016E8")]
	[Address(RVA = "0x2712430", Offset = "0x2712430", VA = "0x2712430", Slot = "4")]
	public virtual void ӫٷ\u0618ݔ()
	{
	}

	// Token: 0x060016E9 RID: 5865 RVA: 0x00081530 File Offset: 0x0007F730
	[Token(Token = "0x60016E9")]
	[Address(RVA = "0x2712434", Offset = "0x2712434", VA = "0x2712434")]
	private void ئأԵߑ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060016EA RID: 5866 RVA: 0x00081550 File Offset: 0x0007F750
	[Token(Token = "0x60016EA")]
	[Address(RVA = "0x27124FC", Offset = "0x27124FC", VA = "0x27124FC", Slot = "5")]
	public virtual void \u0743ߣࡄװ()
	{
	}

	// Token: 0x060016EB RID: 5867 RVA: 0x00081560 File Offset: 0x0007F760
	[Token(Token = "0x60016EB")]
	[Address(RVA = "0x2712500", Offset = "0x2712500", VA = "0x2712500", Slot = "6")]
	public virtual void \u07BB߁تԿ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060016EC RID: 5868 RVA: 0x00081570 File Offset: 0x0007F770
	[Token(Token = "0x60016EC")]
	[Address(RVA = "0x2712504", Offset = "0x2712504", VA = "0x2712504")]
	private void ә\u0730\u0839\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.\u060F\u0652\u0614ݚ();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x060016ED RID: 5869 RVA: 0x000815D0 File Offset: 0x0007F7D0
	[Token(Token = "0x60016ED")]
	[Address(RVA = "0x2712750", Offset = "0x2712750", VA = "0x2712750")]
	private void ߨࠊ\u083F\u088C(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.Ӗ\u0897\u087Dڼ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060016EE RID: 5870 RVA: 0x000815F0 File Offset: 0x0007F7F0
	[Token(Token = "0x60016EE")]
	[Address(RVA = "0x2712824", Offset = "0x2712824", VA = "0x2712824")]
	private void ܖռ\u05C8\u089F(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060016EF RID: 5871 RVA: 0x00081610 File Offset: 0x0007F810
	[Token(Token = "0x60016EF")]
	[Address(RVA = "0x27128E8", Offset = "0x27128E8", VA = "0x27128E8", Slot = "7")]
	public virtual void ݹ\u0604ԕܤ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060016F0 RID: 5872 RVA: 0x00081620 File Offset: 0x0007F820
	[Token(Token = "0x60016F0")]
	[Address(RVA = "0x27128EC", Offset = "0x27128EC", VA = "0x27128EC", Slot = "8")]
	public virtual void \u05A8ԁئӒ()
	{
	}

	// Token: 0x060016F1 RID: 5873 RVA: 0x00081630 File Offset: 0x0007F830
	[Token(Token = "0x60016F1")]
	[Address(RVA = "0x27128F0", Offset = "0x27128F0", VA = "0x27128F0", Slot = "9")]
	public virtual void ࠕՂ\u07A9Ө(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060016F2 RID: 5874 RVA: 0x00081640 File Offset: 0x0007F840
	[Token(Token = "0x60016F2")]
	[Address(RVA = "0x27128F4", Offset = "0x27128F4", VA = "0x27128F4")]
	public IEnumerator Ԁ\u05EB\u0607א()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 1L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060016F3 RID: 5875 RVA: 0x00081664 File Offset: 0x0007F864
	[Token(Token = "0x60016F3")]
	[Address(RVA = "0x271296C", Offset = "0x271296C", VA = "0x271296C", Slot = "10")]
	public virtual void Յ\u0741ތԲ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060016F4 RID: 5876 RVA: 0x00081674 File Offset: 0x0007F874
	[Token(Token = "0x60016F4")]
	[Address(RVA = "0x2712970", Offset = "0x2712970", VA = "0x2712970")]
	private void \u085Bי\u07EBٴ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u058Fݽךݶ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060016F5 RID: 5877 RVA: 0x00081694 File Offset: 0x0007F894
	[Token(Token = "0x60016F5")]
	[Address(RVA = "0x2712A44", Offset = "0x2712A44", VA = "0x2712A44")]
	private IEnumerator \u0591\u05BDՍ߁(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		BirbButton.\u0731ۀܔӠ u0731ۀܔӠ = new BirbButton.\u0731ۀܔӠ((int)<>1__state);
		<>1__state = 0L;
		u0731ۀܔӠ.<>4__this = this;
		u0731ۀܔӠ.forLeftController = (typeof(BirbButton.\u0731ۀܔӠ).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060016F6 RID: 5878 RVA: 0x000816C4 File Offset: 0x0007F8C4
	[Token(Token = "0x60016F6")]
	[Address(RVA = "0x2712AE8", Offset = "0x2712AE8", VA = "0x2712AE8")]
	private void ࡩ\u07FF\u0833ࠆ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060016F7 RID: 5879 RVA: 0x000816E4 File Offset: 0x0007F8E4
	[Token(Token = "0x60016F7")]
	[Address(RVA = "0x2712BB0", Offset = "0x2712BB0", VA = "0x2712BB0")]
	private IEnumerator ޛԞۑ\u06DA(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		BirbButton.\u0731ۀܔӠ u0731ۀܔӠ = new BirbButton.\u0731ۀܔӠ((int)<>1__state);
		<>1__state = 0L;
		u0731ۀܔӠ.<>4__this = this;
		u0731ۀܔӠ.forLeftController = (typeof(BirbButton.\u0731ۀܔӠ).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060016F8 RID: 5880 RVA: 0x00081714 File Offset: 0x0007F914
	[Token(Token = "0x60016F8")]
	[Address(RVA = "0x2712780", Offset = "0x2712780", VA = "0x2712780")]
	private IEnumerator Ӗ\u0897\u087Dڼ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		BirbButton.\u0731ۀܔӠ u0731ۀܔӠ = new BirbButton.\u0731ۀܔӠ((int)<>1__state);
		<>1__state = 0L;
		u0731ۀܔӠ.<>4__this = this;
		u0731ۀܔӠ.forLeftController = (typeof(BirbButton.\u0731ۀܔӠ).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060016F9 RID: 5881 RVA: 0x00081744 File Offset: 0x0007F944
	[Token(Token = "0x60016F9")]
	[Address(RVA = "0x2712C54", Offset = "0x2712C54", VA = "0x2712C54")]
	private void ܮݫ߅ࡃ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060016FA RID: 5882 RVA: 0x00081764 File Offset: 0x0007F964
	[Token(Token = "0x60016FA")]
	[Address(RVA = "0x2712D18", Offset = "0x2712D18", VA = "0x2712D18")]
	public IEnumerator \u05A5\u0559\u0880ݸ()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 1L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060016FB RID: 5883 RVA: 0x00081788 File Offset: 0x0007F988
	[Token(Token = "0x60016FB")]
	[Address(RVA = "0x2712D90", Offset = "0x2712D90", VA = "0x2712D90", Slot = "11")]
	public virtual void \u07FCՑ\u0899߀()
	{
	}

	// Token: 0x060016FC RID: 5884 RVA: 0x00081798 File Offset: 0x0007F998
	[Token(Token = "0x60016FC")]
	[Address(RVA = "0x2712D94", Offset = "0x2712D94", VA = "0x2712D94")]
	private void ӛׯ\u05CBӿ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ܘ\u081Aڧو(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060016FD RID: 5885 RVA: 0x000817B8 File Offset: 0x0007F9B8
	[Token(Token = "0x60016FD")]
	[Address(RVA = "0x2712E68", Offset = "0x2712E68", VA = "0x2712E68")]
	private void ۅ\u05A6\u05A4ӵ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.Ԁ\u05EB\u0607א();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x060016FE RID: 5886 RVA: 0x00081818 File Offset: 0x0007FA18
	[Token(Token = "0x60016FE")]
	[Address(RVA = "0x271303C", Offset = "0x271303C", VA = "0x271303C", Slot = "12")]
	public virtual void ہ\u0606\u07A6Ԟ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060016FF RID: 5887 RVA: 0x00081828 File Offset: 0x0007FA28
	[Token(Token = "0x60016FF")]
	[Address(RVA = "0x2713040", Offset = "0x2713040", VA = "0x2713040", Slot = "13")]
	public virtual void \u0885Ԟ\u061Cױ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001700 RID: 5888 RVA: 0x00081838 File Offset: 0x0007FA38
	[Token(Token = "0x6001700")]
	[Address(RVA = "0x2713044", Offset = "0x2713044", VA = "0x2713044")]
	private void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001701 RID: 5889 RVA: 0x00081858 File Offset: 0x0007FA58
	[Token(Token = "0x6001701")]
	[Address(RVA = "0x27130FC", Offset = "0x27130FC", VA = "0x27130FC")]
	private void ծت\u05C3ی(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u07ACԬӻݧ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001702 RID: 5890 RVA: 0x00081878 File Offset: 0x0007FA78
	[Token(Token = "0x6001702")]
	[Address(RVA = "0x27131D0", Offset = "0x27131D0", VA = "0x27131D0")]
	public IEnumerator \u0744ݢצض()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 0L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001703 RID: 5891 RVA: 0x0008189C File Offset: 0x0007FA9C
	[Token(Token = "0x6001703")]
	[Address(RVA = "0x2713248", Offset = "0x2713248", VA = "0x2713248")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.ܕݡۀࡧ();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001704 RID: 5892 RVA: 0x000818FC File Offset: 0x0007FAFC
	[Token(Token = "0x6001704")]
	[Address(RVA = "0x2713484", Offset = "0x2713484", VA = "0x2713484", Slot = "14")]
	public virtual void Քݡڭٮ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001705 RID: 5893 RVA: 0x0008190C File Offset: 0x0007FB0C
	[Token(Token = "0x6001705")]
	[Address(RVA = "0x2713488", Offset = "0x2713488", VA = "0x2713488", Slot = "15")]
	public virtual void ݥޠ\u07AA\u0602()
	{
	}

	// Token: 0x06001706 RID: 5894 RVA: 0x0008191C File Offset: 0x0007FB1C
	[Token(Token = "0x6001706")]
	[Address(RVA = "0x271348C", Offset = "0x271348C", VA = "0x271348C")]
	private void \u0872יԁӦ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001707 RID: 5895 RVA: 0x0008193C File Offset: 0x0007FB3C
	[Token(Token = "0x6001707")]
	[Address(RVA = "0x2713550", Offset = "0x2713550", VA = "0x2713550")]
	public IEnumerator \u061Aׯ\u08B5ر()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 0L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001708 RID: 5896 RVA: 0x00081960 File Offset: 0x0007FB60
	[Token(Token = "0x6001708")]
	[Address(RVA = "0x27135C8", Offset = "0x27135C8", VA = "0x27135C8")]
	private void ࢫݶ\u06EC\u05B2(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.Ӗ\u0897\u087Dڼ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001709 RID: 5897 RVA: 0x00081980 File Offset: 0x0007FB80
	[Token(Token = "0x6001709")]
	[Address(RVA = "0x27135F8", Offset = "0x27135F8", VA = "0x27135F8")]
	public IEnumerator \u05A6Ր\u060C\u05A1()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 1L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600170A RID: 5898 RVA: 0x000819A4 File Offset: 0x0007FBA4
	[Token(Token = "0x600170A")]
	[Address(RVA = "0x2712DC4", Offset = "0x2712DC4", VA = "0x2712DC4")]
	private IEnumerator ܘ\u081Aڧو(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		BirbButton.\u0731ۀܔӠ u0731ۀܔӠ = new BirbButton.\u0731ۀܔӠ((int)<>1__state);
		<>1__state = 0L;
		u0731ۀܔӠ.forLeftController = (typeof(BirbButton.\u0731ۀܔӠ).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600170B RID: 5899 RVA: 0x000819CC File Offset: 0x0007FBCC
	[Token(Token = "0x600170B")]
	[Address(RVA = "0x2713670", Offset = "0x2713670", VA = "0x2713670", Slot = "16")]
	public virtual void ӧݕ\u05B7\u07F4(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x0600170C RID: 5900 RVA: 0x000819DC File Offset: 0x0007FBDC
	[Token(Token = "0x600170C")]
	[Address(RVA = "0x2713674", Offset = "0x2713674", VA = "0x2713674")]
	private IEnumerator \u0824ڂڙۏ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		BirbButton.\u0731ۀܔӠ u0731ۀܔӠ = new BirbButton.\u0731ۀܔӠ((int)<>1__state);
		<>1__state = 1L;
		u0731ۀܔӠ.<>4__this = this;
		u0731ۀܔӠ.forLeftController = (typeof(BirbButton.\u0731ۀܔӠ).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600170D RID: 5901 RVA: 0x00081A0C File Offset: 0x0007FC0C
	[Token(Token = "0x600170D")]
	[Address(RVA = "0x2713718", Offset = "0x2713718", VA = "0x2713718")]
	public IEnumerator \u07FCٮ\u07EC\u05FA()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 1L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600170E RID: 5902 RVA: 0x00081A30 File Offset: 0x0007FC30
	[Token(Token = "0x600170E")]
	[Address(RVA = "0x27133DC", Offset = "0x27133DC", VA = "0x27133DC")]
	private void \u0735ڲӠ\u05C6(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ܘ\u081Aڧو(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600170F RID: 5903 RVA: 0x00081A50 File Offset: 0x0007FC50
	[Token(Token = "0x600170F")]
	[Address(RVA = "0x2713790", Offset = "0x2713790", VA = "0x2713790")]
	public IEnumerator ࠐݧ\u059E\u07FF()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 0L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001710 RID: 5904 RVA: 0x00081A74 File Offset: 0x0007FC74
	[Token(Token = "0x6001710")]
	[Address(RVA = "0x2713808", Offset = "0x2713808", VA = "0x2713808")]
	private void ޓӥ\u088Eܖ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001711 RID: 5905 RVA: 0x00081A94 File Offset: 0x0007FC94
	[Token(Token = "0x6001711")]
	[Address(RVA = "0x27138D0", Offset = "0x27138D0", VA = "0x27138D0")]
	private void ӕࠌܣڃ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u058Fݽךݶ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001712 RID: 5906 RVA: 0x00081AB4 File Offset: 0x0007FCB4
	[Token(Token = "0x6001712")]
	[Address(RVA = "0x2713900", Offset = "0x2713900", VA = "0x2713900")]
	private void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.ؠࡀ\u060Fێ();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001713 RID: 5907 RVA: 0x00081B14 File Offset: 0x0007FD14
	[Token(Token = "0x6001713")]
	[Address(RVA = "0x2713B18", Offset = "0x2713B18", VA = "0x2713B18")]
	private void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.\u061Aׯ\u08B5ر();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001714 RID: 5908 RVA: 0x00081B74 File Offset: 0x0007FD74
	[Token(Token = "0x6001714")]
	[Address(RVA = "0x2713CBC", Offset = "0x2713CBC", VA = "0x2713CBC")]
	private void \u086BأՋב(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ޛԞۑ\u06DA(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001715 RID: 5909 RVA: 0x00081B94 File Offset: 0x0007FD94
	[Token(Token = "0x6001715")]
	[Address(RVA = "0x2713CEC", Offset = "0x2713CEC", VA = "0x2713CEC")]
	private void \u06E2ڇ\u07BF߃(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001716 RID: 5910 RVA: 0x00081BB4 File Offset: 0x0007FDB4
	[Token(Token = "0x6001716")]
	[Address(RVA = "0x2713DB0", Offset = "0x2713DB0", VA = "0x2713DB0")]
	private void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001717 RID: 5911 RVA: 0x00081BD4 File Offset: 0x0007FDD4
	[Token(Token = "0x6001717")]
	[Address(RVA = "0x2713E78", Offset = "0x2713E78", VA = "0x2713E78")]
	private void Ոڷد\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.ܘ\u05F4ߌӶ();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001718 RID: 5912 RVA: 0x00081C34 File Offset: 0x0007FE34
	[Token(Token = "0x6001718")]
	[Address(RVA = "0x2714090", Offset = "0x2714090", VA = "0x2714090", Slot = "17")]
	public virtual void \u059Eפ\u07F7ߌ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001719 RID: 5913 RVA: 0x00081C44 File Offset: 0x0007FE44
	[Token(Token = "0x6001719")]
	[Address(RVA = "0x2714094", Offset = "0x2714094", VA = "0x2714094", Slot = "18")]
	public virtual void \u0827ڇݽ\u07F2()
	{
	}

	// Token: 0x0600171A RID: 5914 RVA: 0x00081C54 File Offset: 0x0007FE54
	[Token(Token = "0x600171A")]
	[Address(RVA = "0x2714098", Offset = "0x2714098", VA = "0x2714098")]
	public IEnumerator \u070Cࢬ\u05C9ԇ()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 1L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600171B RID: 5915 RVA: 0x00081C78 File Offset: 0x0007FE78
	[Token(Token = "0x600171B")]
	[Address(RVA = "0x2714110", Offset = "0x2714110", VA = "0x2714110")]
	private void ڟࡖӇ߄(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ޛԞۑ\u06DA(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600171C RID: 5916 RVA: 0x00081C98 File Offset: 0x0007FE98
	[Token(Token = "0x600171C")]
	[Address(RVA = "0x2714140", Offset = "0x2714140", VA = "0x2714140")]
	public IEnumerator \u0835ڬژݶ()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 0L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600171D RID: 5917 RVA: 0x00081CBC File Offset: 0x0007FEBC
	[Token(Token = "0x600171D")]
	[Address(RVA = "0x27141B8", Offset = "0x27141B8", VA = "0x27141B8")]
	private void Փ\u06DF\u0839ԟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.ࠐݧ\u059E\u07FF();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x0600171E RID: 5918 RVA: 0x00081D1C File Offset: 0x0007FF1C
	[Token(Token = "0x600171E")]
	[Address(RVA = "0x271435C", Offset = "0x271435C", VA = "0x271435C")]
	private void ىރ\u0704ݟ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x0600171F RID: 5919 RVA: 0x00081D3C File Offset: 0x0007FF3C
	[Token(Token = "0x600171F")]
	[Address(RVA = "0x2714424", Offset = "0x2714424", VA = "0x2714424")]
	private void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.\u061Aׯ\u08B5ر();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001720 RID: 5920 RVA: 0x00081D9C File Offset: 0x0007FF9C
	[Token(Token = "0x6001720")]
	[Address(RVA = "0x27145F8", Offset = "0x27145F8", VA = "0x27145F8")]
	private void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.ܕݡۀࡧ();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001721 RID: 5921 RVA: 0x00081DFC File Offset: 0x0007FFFC
	[Token(Token = "0x6001721")]
	[Address(RVA = "0x271479C", Offset = "0x271479C", VA = "0x271479C")]
	private void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.ؠࡀ\u060Fێ();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001722 RID: 5922 RVA: 0x00081E5C File Offset: 0x0008005C
	[Token(Token = "0x6001722")]
	[Address(RVA = "0x2714940", Offset = "0x2714940", VA = "0x2714940", Slot = "19")]
	public virtual void \u07A6ږӦ\u0592()
	{
	}

	// Token: 0x06001723 RID: 5923 RVA: 0x00081E6C File Offset: 0x0008006C
	[Token(Token = "0x6001723")]
	[Address(RVA = "0x2714018", Offset = "0x2714018", VA = "0x2714018")]
	public IEnumerator ܘ\u05F4ߌӶ()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 0L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001724 RID: 5924 RVA: 0x00081E90 File Offset: 0x00080090
	[Token(Token = "0x6001724")]
	[Address(RVA = "0x2714944", Offset = "0x2714944", VA = "0x2714944", Slot = "20")]
	public virtual void Ӑ\u06E8١۶()
	{
	}

	// Token: 0x06001725 RID: 5925 RVA: 0x00081EA0 File Offset: 0x000800A0
	[Token(Token = "0x6001725")]
	[Address(RVA = "0x271300C", Offset = "0x271300C", VA = "0x271300C")]
	private void ӧ\u06EC\u06DEզ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u058Fݽךݶ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001726 RID: 5926 RVA: 0x00081EC0 File Offset: 0x000800C0
	[Token(Token = "0x6001726")]
	[Address(RVA = "0x2714948", Offset = "0x2714948", VA = "0x2714948")]
	private void \u06E9\u0740մ\u0746(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001727 RID: 5927 RVA: 0x00081EE0 File Offset: 0x000800E0
	[Token(Token = "0x6001727")]
	[Address(RVA = "0x2714A10", Offset = "0x2714A10", VA = "0x2714A10", Slot = "21")]
	public virtual void \u055Dآ\u0592ݒ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001728 RID: 5928 RVA: 0x00081EF0 File Offset: 0x000800F0
	[Token(Token = "0x6001728")]
	[Address(RVA = "0x2714A14", Offset = "0x2714A14", VA = "0x2714A14", Slot = "22")]
	public virtual void \u0732إ\u06DAԋ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001729 RID: 5929 RVA: 0x00081F00 File Offset: 0x00080100
	[Token(Token = "0x6001729")]
	[Address(RVA = "0x2714A18", Offset = "0x2714A18", VA = "0x2714A18", Slot = "23")]
	public virtual void ߧցӡכ()
	{
	}

	// Token: 0x0600172A RID: 5930 RVA: 0x00081F10 File Offset: 0x00080110
	[Token(Token = "0x600172A")]
	[Address(RVA = "0x2714A1C", Offset = "0x2714A1C", VA = "0x2714A1C", Slot = "24")]
	public virtual void \u0593ږ\u07AC\u089C()
	{
	}

	// Token: 0x0600172B RID: 5931 RVA: 0x00081F20 File Offset: 0x00080120
	[Token(Token = "0x600172B")]
	[Address(RVA = "0x2714A20", Offset = "0x2714A20", VA = "0x2714A20", Slot = "25")]
	public virtual void ޡ\u083Cߒߦ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x0600172C RID: 5932 RVA: 0x00081F30 File Offset: 0x00080130
	[Token(Token = "0x600172C")]
	[Address(RVA = "0x2714A24", Offset = "0x2714A24", VA = "0x2714A24")]
	private void ډ\u0611߁ڞ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ܘ\u081Aڧو(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600172D RID: 5933 RVA: 0x00081F50 File Offset: 0x00080150
	[Token(Token = "0x600172D")]
	[Address(RVA = "0x2714A54", Offset = "0x2714A54", VA = "0x2714A54")]
	private void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.ؠࡀ\u060Fێ();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x0600172E RID: 5934 RVA: 0x00081FB0 File Offset: 0x000801B0
	[Token(Token = "0x600172E")]
	[Address(RVA = "0x271340C", Offset = "0x271340C", VA = "0x271340C")]
	public IEnumerator ܕݡۀࡧ()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 0L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600172F RID: 5935 RVA: 0x00081FD4 File Offset: 0x000801D4
	[Token(Token = "0x600172F")]
	[Address(RVA = "0x2714BF8", Offset = "0x2714BF8", VA = "0x2714BF8", Slot = "26")]
	public virtual void \u06DF\u07BCߦ\u0746(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001730 RID: 5936 RVA: 0x00081FE4 File Offset: 0x000801E4
	[Token(Token = "0x6001730")]
	[Address(RVA = "0x2714BFC", Offset = "0x2714BFC", VA = "0x2714BFC")]
	private void ڎՅڤࠊ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001731 RID: 5937 RVA: 0x00082004 File Offset: 0x00080204
	[Token(Token = "0x6001731")]
	[Address(RVA = "0x2714CC4", Offset = "0x2714CC4", VA = "0x2714CC4", Slot = "27")]
	public virtual void Օ\u0598۵Ӹ()
	{
	}

	// Token: 0x06001732 RID: 5938 RVA: 0x00082014 File Offset: 0x00080214
	[Token(Token = "0x6001732")]
	[Address(RVA = "0x2714CC8", Offset = "0x2714CC8", VA = "0x2714CC8", Slot = "28")]
	public virtual void \u0557\u0654ل\u0652(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001733 RID: 5939 RVA: 0x00082024 File Offset: 0x00080224
	[Token(Token = "0x6001733")]
	[Address(RVA = "0x2714CCC", Offset = "0x2714CCC", VA = "0x2714CCC", Slot = "29")]
	public virtual void ܫ߈ࡤޖ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001734 RID: 5940 RVA: 0x00082034 File Offset: 0x00080234
	[Token(Token = "0x6001734")]
	[Address(RVA = "0x2714CD0", Offset = "0x2714CD0", VA = "0x2714CD0")]
	public IEnumerator ݖ\u05FA\u081Fخ()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 1L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001735 RID: 5941 RVA: 0x00082058 File Offset: 0x00080258
	[Token(Token = "0x6001735")]
	[Address(RVA = "0x2714D48", Offset = "0x2714D48", VA = "0x2714D48")]
	private void \u06D4\u088Dհװ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u0824ڂڙۏ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001736 RID: 5942 RVA: 0x00082078 File Offset: 0x00080278
	[Token(Token = "0x6001736")]
	[Address(RVA = "0x2714D78", Offset = "0x2714D78", VA = "0x2714D78", Slot = "30")]
	public virtual void صࡡߏӾ()
	{
	}

	// Token: 0x06001737 RID: 5943 RVA: 0x00082088 File Offset: 0x00080288
	[Token(Token = "0x6001737")]
	[Address(RVA = "0x2714D7C", Offset = "0x2714D7C", VA = "0x2714D7C")]
	private void ڕ\u087Bա\u0893(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001738 RID: 5944 RVA: 0x000820A8 File Offset: 0x000802A8
	[Token(Token = "0x6001738")]
	[Address(RVA = "0x2714E44", Offset = "0x2714E44", VA = "0x2714E44")]
	private void ڿ\u07ADݠڧ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001739 RID: 5945 RVA: 0x000820C8 File Offset: 0x000802C8
	[Token(Token = "0x6001739")]
	[Address(RVA = "0x2714F0C", Offset = "0x2714F0C", VA = "0x2714F0C")]
	public BirbButton()
	{
	}

	// Token: 0x0600173A RID: 5946 RVA: 0x000820E8 File Offset: 0x000802E8
	[Token(Token = "0x600173A")]
	[Address(RVA = "0x2714F20", Offset = "0x2714F20", VA = "0x2714F20")]
	private void Ԭ\u07A6Ԥק(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u0824ڂڙۏ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600173B RID: 5947 RVA: 0x00082108 File Offset: 0x00080308
	[Token(Token = "0x600173B")]
	[Address(RVA = "0x2714F50", Offset = "0x2714F50", VA = "0x2714F50", Slot = "31")]
	public virtual void Գ\u085C߁ߑ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x0600173C RID: 5948 RVA: 0x00082118 File Offset: 0x00080318
	[Token(Token = "0x600173C")]
	[Address(RVA = "0x27145C8", Offset = "0x27145C8", VA = "0x27145C8")]
	private void ࡖݎݘߚ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u0591\u05BDՍ߁(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600173D RID: 5949 RVA: 0x00082138 File Offset: 0x00080338
	[Token(Token = "0x600173D")]
	[Address(RVA = "0x2714F54", Offset = "0x2714F54", VA = "0x2714F54", Slot = "32")]
	public virtual void ۵ߔ\u073Aڑ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x0600173E RID: 5950 RVA: 0x00082148 File Offset: 0x00080348
	[Token(Token = "0x600173E")]
	[Address(RVA = "0x2714F58", Offset = "0x2714F58", VA = "0x2714F58", Slot = "33")]
	public virtual void ӞӟٴӜ()
	{
	}

	// Token: 0x0600173F RID: 5951 RVA: 0x00082158 File Offset: 0x00080358
	[Token(Token = "0x600173F")]
	[Address(RVA = "0x2713AA0", Offset = "0x2713AA0", VA = "0x2713AA0")]
	public IEnumerator ؠࡀ\u060Fێ()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 0L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001740 RID: 5952 RVA: 0x0008217C File Offset: 0x0008037C
	[Token(Token = "0x6001740")]
	[Address(RVA = "0x2714F5C", Offset = "0x2714F5C", VA = "0x2714F5C")]
	private void \u086D\u089AԾ\u0881(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001741 RID: 5953 RVA: 0x0008219C File Offset: 0x0008039C
	[Token(Token = "0x6001741")]
	[Address(RVA = "0x27126D8", Offset = "0x27126D8", VA = "0x27126D8")]
	public IEnumerator \u060F\u0652\u0614ݚ()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 0L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001742 RID: 5954 RVA: 0x000821C0 File Offset: 0x000803C0
	[Token(Token = "0x6001742")]
	[Address(RVA = "0x2715024", Offset = "0x2715024", VA = "0x2715024")]
	public IEnumerator ߦݜӆ\u055D()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 0L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001743 RID: 5955 RVA: 0x000821E4 File Offset: 0x000803E4
	[Token(Token = "0x6001743")]
	[Address(RVA = "0x271509C", Offset = "0x271509C", VA = "0x271509C", Slot = "34")]
	public virtual void Ҽ\u0612ք\u0731(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001744 RID: 5956 RVA: 0x000821F4 File Offset: 0x000803F4
	[Token(Token = "0x6001744")]
	[Address(RVA = "0x271312C", Offset = "0x271312C", VA = "0x271312C")]
	private IEnumerator \u07ACԬӻݧ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		BirbButton.\u0731ۀܔӠ u0731ۀܔӠ = new BirbButton.\u0731ۀܔӠ((int)<>1__state);
		<>1__state = 1L;
		u0731ۀܔӠ.<>4__this = this;
		u0731ۀܔӠ.forLeftController = (typeof(BirbButton.\u0731ۀܔӠ).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001745 RID: 5957 RVA: 0x00082224 File Offset: 0x00080424
	[Token(Token = "0x6001745")]
	[Address(RVA = "0x27150A0", Offset = "0x27150A0", VA = "0x27150A0")]
	private void ے\u059Fࢰس(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.\u070Cࢬ\u05C9ԇ();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001746 RID: 5958 RVA: 0x00082284 File Offset: 0x00080484
	[Token(Token = "0x6001746")]
	[Address(RVA = "0x2715244", Offset = "0x2715244", VA = "0x2715244", Slot = "35")]
	public virtual void \u085Eي\u07A7ӥ()
	{
	}

	// Token: 0x06001747 RID: 5959 RVA: 0x00082294 File Offset: 0x00080494
	[Token(Token = "0x6001747")]
	[Address(RVA = "0x2715248", Offset = "0x2715248", VA = "0x2715248")]
	private void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001748 RID: 5960 RVA: 0x000822B4 File Offset: 0x000804B4
	[Token(Token = "0x6001748")]
	[Address(RVA = "0x271530C", Offset = "0x271530C", VA = "0x271530C")]
	private void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.ܕݡۀࡧ();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001749 RID: 5961 RVA: 0x00082314 File Offset: 0x00080514
	[Token(Token = "0x6001749")]
	[Address(RVA = "0x27154E0", Offset = "0x27154E0", VA = "0x27154E0")]
	private IEnumerator \u083Eءղݯ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		BirbButton.\u0731ۀܔӠ u0731ۀܔӠ = new BirbButton.\u0731ۀܔӠ((int)<>1__state);
		<>1__state = 0L;
		u0731ۀܔӠ.<>4__this = this;
		u0731ۀܔӠ.forLeftController = (typeof(BirbButton.\u0731ۀܔӠ).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600174A RID: 5962 RVA: 0x00082344 File Offset: 0x00080544
	[Token(Token = "0x600174A")]
	[Address(RVA = "0x2715584", Offset = "0x2715584", VA = "0x2715584")]
	public IEnumerator Ӈ\u064Bࢪ\u089B()
	{
		long <>1__state;
		BirbButton.ټێԓ\u0652 ټێԓ_u = new BirbButton.ټێԓ\u0652((int)<>1__state);
		<>1__state = 0L;
		ټێԓ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600174B RID: 5963 RVA: 0x00082368 File Offset: 0x00080568
	[Token(Token = "0x600174B")]
	[Address(RVA = "0x27155FC", Offset = "0x27155FC", VA = "0x27155FC")]
	private void Ԃ\u058Aܫջ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		Material material = base.GetComponent<MeshRenderer>().material;
		HandColliders handColliders;
		bool u089Bݼۄ_u = handColliders.\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		HandColliders handColliders2;
		bool u089Bݼۄ_u2 = handColliders2.\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.\u061Aׯ\u08B5ر();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x0600174C RID: 5964 RVA: 0x000823BC File Offset: 0x000805BC
	[Token(Token = "0x600174C")]
	[Address(RVA = "0x27157A0", Offset = "0x27157A0", VA = "0x27157A0", Slot = "36")]
	public virtual void ܣ\u07F3\u0599ժ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x0600174D RID: 5965 RVA: 0x000823CC File Offset: 0x000805CC
	[Token(Token = "0x600174D")]
	[Address(RVA = "0x27129A0", Offset = "0x27129A0", VA = "0x27129A0")]
	private IEnumerator \u058Fݽךݶ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		BirbButton.\u0731ۀܔӠ u0731ۀܔӠ = new BirbButton.\u0731ۀܔӠ((int)<>1__state);
		<>1__state = 0L;
		u0731ۀܔӠ.<>4__this = this;
		u0731ۀܔӠ.forLeftController = (typeof(BirbButton.\u0731ۀܔӠ).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600174E RID: 5966 RVA: 0x000823FC File Offset: 0x000805FC
	[Token(Token = "0x600174E")]
	[Address(RVA = "0x27157A4", Offset = "0x27157A4", VA = "0x27157A4", Slot = "37")]
	public virtual void ټڽ\u0702۲(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x0600174F RID: 5967 RVA: 0x0008240C File Offset: 0x0008060C
	[Token(Token = "0x600174F")]
	[Address(RVA = "0x27157A8", Offset = "0x27157A8", VA = "0x27157A8", Slot = "38")]
	public virtual void ܐڬڞڞ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001750 RID: 5968 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001750")]
	[Address(RVA = "0x27157AC", Offset = "0x27157AC", VA = "0x27157AC")]
	private void \u07BF\u0705\u0824ڮ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001751 RID: 5969 RVA: 0x0008241C File Offset: 0x0008061C
	[Token(Token = "0x6001751")]
	[Address(RVA = "0x2715874", Offset = "0x2715874", VA = "0x2715874", Slot = "39")]
	public virtual void ԅՏ\u089D\u05CC()
	{
	}

	// Token: 0x06001752 RID: 5970 RVA: 0x0008242C File Offset: 0x0008062C
	[Token(Token = "0x6001752")]
	[Address(RVA = "0x27126A8", Offset = "0x27126A8", VA = "0x27126A8")]
	private void ܕࢨؤޡ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u083Eءղݯ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001753 RID: 5971 RVA: 0x0008244C File Offset: 0x0008064C
	[Token(Token = "0x6001753")]
	[Address(RVA = "0x2715878", Offset = "0x2715878", VA = "0x2715878")]
	private void ԉՔӸ\u06DC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.\u0744ݢצض();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001754 RID: 5972 RVA: 0x000824AC File Offset: 0x000806AC
	[Token(Token = "0x6001754")]
	[Address(RVA = "0x2715A1C", Offset = "0x2715A1C", VA = "0x2715A1C", Slot = "40")]
	public virtual void ࢣ\u0819ࢭث()
	{
	}

	// Token: 0x06001755 RID: 5973 RVA: 0x000824BC File Offset: 0x000806BC
	[Token(Token = "0x6001755")]
	[Address(RVA = "0x2715A20", Offset = "0x2715A20", VA = "0x2715A20")]
	private void \u07FE߆לى(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.ߦݜӆ\u055D();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001756 RID: 5974 RVA: 0x0008251C File Offset: 0x0008071C
	[Token(Token = "0x6001756")]
	[Address(RVA = "0x2715BC0", Offset = "0x2715BC0", VA = "0x2715BC0", Slot = "41")]
	public virtual void رࠉ\u085AԳ()
	{
	}

	// Token: 0x06001757 RID: 5975 RVA: 0x0008252C File Offset: 0x0008072C
	[Token(Token = "0x6001757")]
	[Address(RVA = "0x2715BC4", Offset = "0x2715BC4", VA = "0x2715BC4", Slot = "42")]
	public virtual void ߄\u086Bݵ\u05A6(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06001758 RID: 5976 RVA: 0x0008253C File Offset: 0x0008073C
	[Token(Token = "0x6001758")]
	[Address(RVA = "0x27154B0", Offset = "0x27154B0", VA = "0x27154B0")]
	private void \u088C\u08B5ߡ\u05AF(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u083Eءղݯ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001759 RID: 5977 RVA: 0x0008255C File Offset: 0x0008075C
	[Token(Token = "0x6001759")]
	[Address(RVA = "0x2715BC8", Offset = "0x2715BC8", VA = "0x2715BC8")]
	private void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		Material material = base.GetComponent<MeshRenderer>().material;
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<HandColliders>().\u089Bݼۄ\u0875;
		IEnumerator routine2 = this.\u060F\u0652\u0614ݚ();
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x040002DA RID: 730
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002DA")]
	private float \u087C\u0593Ӛ\u07A6 = (float)52429;
}
