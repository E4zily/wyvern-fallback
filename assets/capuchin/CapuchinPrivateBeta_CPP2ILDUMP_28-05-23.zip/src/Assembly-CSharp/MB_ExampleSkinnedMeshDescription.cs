﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200007C RID: 124
[Token(Token = "0x200007C")]
public class MB_ExampleSkinnedMeshDescription : MonoBehaviour
{
	// Token: 0x060012DD RID: 4829 RVA: 0x0006B764 File Offset: 0x00069964
	[Token(Token = "0x60012DD")]
	[Address(RVA = "0x2C5959C", Offset = "0x2C5959C", VA = "0x2C5959C")]
	private void \u05C4עڻ\u0732()
	{
	}

	// Token: 0x060012DE RID: 4830 RVA: 0x0006B774 File Offset: 0x00069974
	[Token(Token = "0x60012DE")]
	[Address(RVA = "0x2C5967C", Offset = "0x2C5967C", VA = "0x2C5967C")]
	private void Ӯޱ\u0703ࢪ()
	{
	}

	// Token: 0x060012DF RID: 4831 RVA: 0x0006B784 File Offset: 0x00069984
	[Token(Token = "0x60012DF")]
	[Address(RVA = "0x2C5975C", Offset = "0x2C5975C", VA = "0x2C5975C")]
	private void و߂\u06DBڅ()
	{
	}

	// Token: 0x060012E0 RID: 4832 RVA: 0x0006B794 File Offset: 0x00069994
	[Token(Token = "0x60012E0")]
	[Address(RVA = "0x2C5983C", Offset = "0x2C5983C", VA = "0x2C5983C")]
	private void ہډࠉӥ()
	{
	}

	// Token: 0x060012E1 RID: 4833 RVA: 0x0006B7A4 File Offset: 0x000699A4
	[Token(Token = "0x60012E1")]
	[Address(RVA = "0x2C5991C", Offset = "0x2C5991C", VA = "0x2C5991C")]
	private void ԗӣ\u07BAߩ()
	{
	}

	// Token: 0x060012E2 RID: 4834 RVA: 0x0006B7B4 File Offset: 0x000699B4
	[Token(Token = "0x60012E2")]
	[Address(RVA = "0x2C599FC", Offset = "0x2C599FC", VA = "0x2C599FC")]
	private void \u07EB\u0597ࢳڪ()
	{
	}

	// Token: 0x060012E3 RID: 4835 RVA: 0x0006B7C4 File Offset: 0x000699C4
	[Token(Token = "0x60012E3")]
	[Address(RVA = "0x2C59ADC", Offset = "0x2C59ADC", VA = "0x2C59ADC")]
	private void ٧ص\u073FӜ()
	{
	}

	// Token: 0x060012E4 RID: 4836 RVA: 0x0006B7D4 File Offset: 0x000699D4
	[Token(Token = "0x60012E4")]
	[Address(RVA = "0x2C59BBC", Offset = "0x2C59BBC", VA = "0x2C59BBC")]
	public MB_ExampleSkinnedMeshDescription()
	{
	}

	// Token: 0x060012E5 RID: 4837 RVA: 0x0006B7E8 File Offset: 0x000699E8
	[Token(Token = "0x60012E5")]
	[Address(RVA = "0x2C59BC4", Offset = "0x2C59BC4", VA = "0x2C59BC4")]
	private void \u05CAө\u0872\u058F()
	{
	}

	// Token: 0x060012E6 RID: 4838 RVA: 0x0006B7F8 File Offset: 0x000699F8
	[Token(Token = "0x60012E6")]
	[Address(RVA = "0x2C59CA4", Offset = "0x2C59CA4", VA = "0x2C59CA4")]
	private void \u07F7ե\u081Fܗ()
	{
	}

	// Token: 0x060012E7 RID: 4839 RVA: 0x0006B808 File Offset: 0x00069A08
	[Token(Token = "0x60012E7")]
	[Address(RVA = "0x2C59D84", Offset = "0x2C59D84", VA = "0x2C59D84")]
	private void ߅\u070Fޑ\u0876()
	{
	}

	// Token: 0x060012E8 RID: 4840 RVA: 0x0006B818 File Offset: 0x00069A18
	[Token(Token = "0x60012E8")]
	[Address(RVA = "0x2C59E64", Offset = "0x2C59E64", VA = "0x2C59E64")]
	private void \u0598ڂ\u088AՋ()
	{
	}

	// Token: 0x060012E9 RID: 4841 RVA: 0x0006B828 File Offset: 0x00069A28
	[Token(Token = "0x60012E9")]
	[Address(RVA = "0x2C59F44", Offset = "0x2C59F44", VA = "0x2C59F44")]
	private void \u0859\u0895ӇԚ()
	{
	}

	// Token: 0x060012EA RID: 4842 RVA: 0x0006B838 File Offset: 0x00069A38
	[Token(Token = "0x60012EA")]
	[Address(RVA = "0x2C5A024", Offset = "0x2C5A024", VA = "0x2C5A024")]
	private void \u0880ݚވԿ()
	{
	}

	// Token: 0x060012EB RID: 4843 RVA: 0x0006B848 File Offset: 0x00069A48
	[Token(Token = "0x60012EB")]
	[Address(RVA = "0x2C5A104", Offset = "0x2C5A104", VA = "0x2C5A104")]
	private void \u07AFࡓݣ\u06E9()
	{
		if (!true)
		{
		}
	}

	// Token: 0x060012EC RID: 4844 RVA: 0x0006B858 File Offset: 0x00069A58
	[Token(Token = "0x60012EC")]
	[Address(RVA = "0x2C5A1E4", Offset = "0x2C5A1E4", VA = "0x2C5A1E4")]
	private void \u064Bࢮ\u0589\u05FF()
	{
	}

	// Token: 0x060012ED RID: 4845 RVA: 0x0006B868 File Offset: 0x00069A68
	[Token(Token = "0x60012ED")]
	[Address(RVA = "0x2C5A2C4", Offset = "0x2C5A2C4", VA = "0x2C5A2C4")]
	private void \u060Eװ\u085Cࢶ()
	{
	}

	// Token: 0x060012EE RID: 4846 RVA: 0x0006B878 File Offset: 0x00069A78
	[Token(Token = "0x60012EE")]
	[Address(RVA = "0x2C5A3A4", Offset = "0x2C5A3A4", VA = "0x2C5A3A4")]
	private void ޥل\u0605Ԅ()
	{
	}

	// Token: 0x060012EF RID: 4847 RVA: 0x0006B888 File Offset: 0x00069A88
	[Token(Token = "0x60012EF")]
	[Address(RVA = "0x2C5A484", Offset = "0x2C5A484", VA = "0x2C5A484")]
	private void ى\u05F4ڷ߉()
	{
	}

	// Token: 0x060012F0 RID: 4848 RVA: 0x0006B898 File Offset: 0x00069A98
	[Token(Token = "0x60012F0")]
	[Address(RVA = "0x2C5A564", Offset = "0x2C5A564", VA = "0x2C5A564")]
	private void ܡӯ\u06E8\u07B0()
	{
	}

	// Token: 0x060012F1 RID: 4849 RVA: 0x0006B8A8 File Offset: 0x00069AA8
	[Token(Token = "0x60012F1")]
	[Address(RVA = "0x2C5A644", Offset = "0x2C5A644", VA = "0x2C5A644")]
	private void \u0589٣ޖԀ()
	{
	}

	// Token: 0x060012F2 RID: 4850 RVA: 0x0006B8B8 File Offset: 0x00069AB8
	[Token(Token = "0x60012F2")]
	[Address(RVA = "0x2C5A724", Offset = "0x2C5A724", VA = "0x2C5A724")]
	private void \u07FBع߉ٶ()
	{
	}

	// Token: 0x060012F3 RID: 4851 RVA: 0x0006B8C8 File Offset: 0x00069AC8
	[Token(Token = "0x60012F3")]
	[Address(RVA = "0x2C5A804", Offset = "0x2C5A804", VA = "0x2C5A804")]
	private void Ӄۇރࡑ()
	{
	}

	// Token: 0x060012F4 RID: 4852 RVA: 0x0006B8D8 File Offset: 0x00069AD8
	[Token(Token = "0x60012F4")]
	[Address(RVA = "0x2C5A8E4", Offset = "0x2C5A8E4", VA = "0x2C5A8E4")]
	private void \u05BA\u0893ހՎ()
	{
	}

	// Token: 0x060012F5 RID: 4853 RVA: 0x0006B8E8 File Offset: 0x00069AE8
	[Token(Token = "0x60012F5")]
	[Address(RVA = "0x2C5A9C4", Offset = "0x2C5A9C4", VA = "0x2C5A9C4")]
	private void \u0859ؤԗԧ()
	{
	}

	// Token: 0x060012F6 RID: 4854 RVA: 0x0006B8F8 File Offset: 0x00069AF8
	[Token(Token = "0x60012F6")]
	[Address(RVA = "0x2C5AAA4", Offset = "0x2C5AAA4", VA = "0x2C5AAA4")]
	private void \u0594ٺԏ\u05CA()
	{
	}

	// Token: 0x060012F7 RID: 4855 RVA: 0x0006B908 File Offset: 0x00069B08
	[Token(Token = "0x60012F7")]
	[Address(RVA = "0x2C5AB84", Offset = "0x2C5AB84", VA = "0x2C5AB84")]
	private void ۃ\u087EڴՊ()
	{
	}

	// Token: 0x060012F8 RID: 4856 RVA: 0x0006B918 File Offset: 0x00069B18
	[Token(Token = "0x60012F8")]
	[Address(RVA = "0x2C5AC64", Offset = "0x2C5AC64", VA = "0x2C5AC64")]
	private void ޒӠۅߐ()
	{
	}

	// Token: 0x060012F9 RID: 4857 RVA: 0x0006B928 File Offset: 0x00069B28
	[Token(Token = "0x60012F9")]
	[Address(RVA = "0x2C5AD44", Offset = "0x2C5AD44", VA = "0x2C5AD44")]
	private void Ԁߚޘٴ()
	{
	}

	// Token: 0x060012FA RID: 4858 RVA: 0x0006B938 File Offset: 0x00069B38
	[Token(Token = "0x60012FA")]
	[Address(RVA = "0x2C5AE24", Offset = "0x2C5AE24", VA = "0x2C5AE24")]
	private void چאӣک()
	{
	}

	// Token: 0x060012FB RID: 4859 RVA: 0x0006B948 File Offset: 0x00069B48
	[Token(Token = "0x60012FB")]
	[Address(RVA = "0x2C5AF04", Offset = "0x2C5AF04", VA = "0x2C5AF04")]
	private void \u055E\u064E\u073Dࢷ()
	{
	}

	// Token: 0x060012FC RID: 4860 RVA: 0x0006B958 File Offset: 0x00069B58
	[Token(Token = "0x60012FC")]
	[Address(RVA = "0x2C5AFE4", Offset = "0x2C5AFE4", VA = "0x2C5AFE4")]
	private void ҿ\u07BBҽ\u0599()
	{
	}

	// Token: 0x060012FD RID: 4861 RVA: 0x0006B968 File Offset: 0x00069B68
	[Token(Token = "0x60012FD")]
	[Address(RVA = "0x2C5B0C4", Offset = "0x2C5B0C4", VA = "0x2C5B0C4")]
	private void Ԅڌ\u0659߀()
	{
	}

	// Token: 0x060012FE RID: 4862 RVA: 0x0006B978 File Offset: 0x00069B78
	[Token(Token = "0x60012FE")]
	[Address(RVA = "0x2C5B1A4", Offset = "0x2C5B1A4", VA = "0x2C5B1A4")]
	private void OnGUI()
	{
	}

	// Token: 0x060012FF RID: 4863 RVA: 0x0006B988 File Offset: 0x00069B88
	[Token(Token = "0x60012FF")]
	[Address(RVA = "0x2C5B284", Offset = "0x2C5B284", VA = "0x2C5B284")]
	private void \u05AE\u05B6\u055A\u05B1()
	{
	}
}
