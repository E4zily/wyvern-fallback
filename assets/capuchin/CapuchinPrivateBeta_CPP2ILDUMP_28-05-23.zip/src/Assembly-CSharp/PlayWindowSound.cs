﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000D5 RID: 213
[Token(Token = "0x20000D5")]
public class PlayWindowSound : MonoBehaviour
{
	// Token: 0x06002041 RID: 8257 RVA: 0x000A82B4 File Offset: 0x000A64B4
	[Token(Token = "0x6002041")]
	[Address(RVA = "0x299A500", Offset = "0x299A500", VA = "0x299A500")]
	public PlayWindowSound()
	{
	}

	// Token: 0x06002042 RID: 8258 RVA: 0x000A82C8 File Offset: 0x000A64C8
	[Token(Token = "0x6002042")]
	[Address(RVA = "0x299A508", Offset = "0x299A508", VA = "0x299A508")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002043 RID: 8259 RVA: 0x000A82F0 File Offset: 0x000A64F0
	[Token(Token = "0x6002043")]
	[Address(RVA = "0x299A52C", Offset = "0x299A52C", VA = "0x299A52C")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002044 RID: 8260 RVA: 0x000A8318 File Offset: 0x000A6518
	[Token(Token = "0x6002044")]
	[Address(RVA = "0x299A550", Offset = "0x299A550", VA = "0x299A550")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002045 RID: 8261 RVA: 0x000A8340 File Offset: 0x000A6540
	[Token(Token = "0x6002045")]
	[Address(RVA = "0x299A574", Offset = "0x299A574", VA = "0x299A574")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002046 RID: 8262 RVA: 0x000A8368 File Offset: 0x000A6568
	[Token(Token = "0x6002046")]
	[Address(RVA = "0x299A598", Offset = "0x299A598", VA = "0x299A598")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002047 RID: 8263 RVA: 0x000A8390 File Offset: 0x000A6590
	[Token(Token = "0x6002047")]
	[Address(RVA = "0x299A5BC", Offset = "0x299A5BC", VA = "0x299A5BC")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002048 RID: 8264 RVA: 0x000A83B8 File Offset: 0x000A65B8
	[Token(Token = "0x6002048")]
	[Address(RVA = "0x299A5E0", Offset = "0x299A5E0", VA = "0x299A5E0")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002049 RID: 8265 RVA: 0x000A83E0 File Offset: 0x000A65E0
	[Token(Token = "0x6002049")]
	[Address(RVA = "0x299A604", Offset = "0x299A604", VA = "0x299A604")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x0600204A RID: 8266 RVA: 0x000A8408 File Offset: 0x000A6608
	[Token(Token = "0x600204A")]
	[Address(RVA = "0x299A628", Offset = "0x299A628", VA = "0x299A628")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x0600204B RID: 8267 RVA: 0x000A8430 File Offset: 0x000A6630
	[Token(Token = "0x600204B")]
	[Address(RVA = "0x299A64C", Offset = "0x299A64C", VA = "0x299A64C")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x0600204C RID: 8268 RVA: 0x000A8458 File Offset: 0x000A6658
	[Token(Token = "0x600204C")]
	[Address(RVA = "0x299A670", Offset = "0x299A670", VA = "0x299A670")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x0600204D RID: 8269 RVA: 0x000A8480 File Offset: 0x000A6680
	[Token(Token = "0x600204D")]
	[Address(RVA = "0x299A694", Offset = "0x299A694", VA = "0x299A694")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
	}

	// Token: 0x0600204E RID: 8270 RVA: 0x000A849C File Offset: 0x000A669C
	[Token(Token = "0x600204E")]
	[Address(RVA = "0x299A6B8", Offset = "0x299A6B8", VA = "0x299A6B8")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x0600204F RID: 8271 RVA: 0x000A84C4 File Offset: 0x000A66C4
	[Token(Token = "0x600204F")]
	[Address(RVA = "0x299A6DC", Offset = "0x299A6DC", VA = "0x299A6DC")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
	}

	// Token: 0x06002050 RID: 8272 RVA: 0x000A84E0 File Offset: 0x000A66E0
	[Token(Token = "0x6002050")]
	[Address(RVA = "0x299A700", Offset = "0x299A700", VA = "0x299A700")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002051 RID: 8273 RVA: 0x000A8508 File Offset: 0x000A6708
	[Token(Token = "0x6002051")]
	[Address(RVA = "0x299A724", Offset = "0x299A724", VA = "0x299A724")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002052 RID: 8274 RVA: 0x000A8530 File Offset: 0x000A6730
	[Token(Token = "0x6002052")]
	[Address(RVA = "0x299A748", Offset = "0x299A748", VA = "0x299A748")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002053 RID: 8275 RVA: 0x000A8558 File Offset: 0x000A6758
	[Token(Token = "0x6002053")]
	[Address(RVA = "0x299A76C", Offset = "0x299A76C", VA = "0x299A76C")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002054 RID: 8276 RVA: 0x000A8580 File Offset: 0x000A6780
	[Token(Token = "0x6002054")]
	[Address(RVA = "0x299A790", Offset = "0x299A790", VA = "0x299A790")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002055 RID: 8277 RVA: 0x000A85A8 File Offset: 0x000A67A8
	[Token(Token = "0x6002055")]
	[Address(RVA = "0x299A7B4", Offset = "0x299A7B4", VA = "0x299A7B4")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002056 RID: 8278 RVA: 0x000A85D0 File Offset: 0x000A67D0
	[Token(Token = "0x6002056")]
	[Address(RVA = "0x299A7D8", Offset = "0x299A7D8", VA = "0x299A7D8")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002057 RID: 8279 RVA: 0x000A85F8 File Offset: 0x000A67F8
	[Token(Token = "0x6002057")]
	[Address(RVA = "0x299A7FC", Offset = "0x299A7FC", VA = "0x299A7FC")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002058 RID: 8280 RVA: 0x000A8620 File Offset: 0x000A6820
	[Token(Token = "0x6002058")]
	[Address(RVA = "0x299A820", Offset = "0x299A820", VA = "0x299A820")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x06002059 RID: 8281 RVA: 0x000A8648 File Offset: 0x000A6848
	[Token(Token = "0x6002059")]
	[Address(RVA = "0x299A844", Offset = "0x299A844", VA = "0x299A844")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x0600205A RID: 8282 RVA: 0x000A8670 File Offset: 0x000A6870
	[Token(Token = "0x600205A")]
	[Address(RVA = "0x299A868", Offset = "0x299A868", VA = "0x299A868")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		AudioSource ոӌ۹ࡀ = this.ՈӋ۹ࡀ;
		AudioClip ӿߢߙ_u = this.Ӿߢߙ\u0598;
		ոӌ۹ࡀ.PlayOneShot(ӿߢߙ_u);
	}

	// Token: 0x04000424 RID: 1060
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000424")]
	public AudioClip Ӿߢߙ\u0598;

	// Token: 0x04000425 RID: 1061
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000425")]
	public AudioSource ՈӋ۹ࡀ;
}
