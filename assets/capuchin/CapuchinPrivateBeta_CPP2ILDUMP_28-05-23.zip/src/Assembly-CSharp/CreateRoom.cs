﻿using System;
using Cpp2IlInjected;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;

// Token: 0x0200003F RID: 63
[Token(Token = "0x200003F")]
public class CreateRoom : MonoBehaviourPunCallbacks
{
	// Token: 0x0600088A RID: 2186 RVA: 0x0002EFFC File Offset: 0x0002D1FC
	[Token(Token = "0x600088A")]
	[Address(RVA = "0x2896A98", Offset = "0x2896A98", VA = "0x2896A98")]
	public void Start()
	{
		CreateRoom.Instance = this;
	}

	// Token: 0x0600088B RID: 2187 RVA: 0x0002F010 File Offset: 0x0002D210
	[Token(Token = "0x600088B")]
	[Address(RVA = "0x2896AEC", Offset = "0x2896AEC", VA = "0x2896AEC")]
	public void CreateRoomLol()
	{
		if (!true)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
		if (this.roomName.m_CachedPtr == 0)
		{
		}
		bool isConnected2 = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600088C RID: 2188 RVA: 0x0002F084 File Offset: 0x0002D284
	[Token(Token = "0x600088C")]
	[Address(RVA = "0x2896F40", Offset = "0x2896F40", VA = "0x2896F40")]
	public void LeaveRoomLol()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LeaveRoom(true);
	}

	// Token: 0x0600088D RID: 2189 RVA: 0x0002F0A0 File Offset: 0x0002D2A0
	[Token(Token = "0x600088D")]
	[Address(RVA = "0x2896C7C", Offset = "0x2896C7C", VA = "0x2896C7C")]
	public void CreateSillyRoom(string roomName)
	{
		RoomOptions roomOptions = new RoomOptions();
		byte b = this.maxPlayers;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.isVisible = (257 != 0);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		roomOptions.MaxPlayers = b;
		Hashtable hashtable = new Hashtable();
		Hashtable hashtable2 = new Hashtable();
		string[] customRoomPropertiesForLobby = new string[2];
		if ("isLava" != null)
		{
			if ("isLava" != null)
			{
				return;
			}
		}
		else
		{
			if ("containsStaff" == null)
			{
				roomOptions.CustomRoomPropertiesForLobby = customRoomPropertiesForLobby;
				return;
			}
			if ("containsStaff" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600088E RID: 2190 RVA: 0x0002F128 File Offset: 0x0002D328
	[Token(Token = "0x600088E")]
	[Address(RVA = "0x2896FA0", Offset = "0x2896FA0", VA = "0x2896FA0", Slot = "35")]
	public override void OnCreatedRoom()
	{
		TextMeshPro textMeshPro = this.roomName;
		if (" successfully!" == null)
		{
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x0600088F RID: 2191 RVA: 0x0002F150 File Offset: 0x0002D350
	[Token(Token = "0x600088F")]
	[Address(RVA = "0x2897068", Offset = "0x2897068", VA = "0x2897068", Slot = "33")]
	public override void OnCreateRoomFailed(short returnCode, string message)
	{
		Debug.Log("Room Creation Failed: " + message);
	}

	// Token: 0x06000890 RID: 2192 RVA: 0x0002F194 File Offset: 0x0002D394
	[Token(Token = "0x6000890")]
	[Address(RVA = "0x2897198", Offset = "0x2897198", VA = "0x2897198")]
	public CreateRoom()
	{
	}

	// Token: 0x0400011C RID: 284
	[Token(Token = "0x400011C")]
	public static CreateRoom Instance;

	// Token: 0x0400011D RID: 285
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400011D")]
	[SerializeField]
	public TextMeshPro roomName;

	// Token: 0x0400011E RID: 286
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400011E")]
	public byte maxPlayers;

	// Token: 0x0400011F RID: 287
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400011F")]
	public LobbyStats LobbyStats;
}
