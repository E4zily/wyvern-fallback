﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200000A RID: 10
[Token(Token = "0x200000A")]
public class BobObjectManager : MonoBehaviour
{
	// Token: 0x0600010B RID: 267 RVA: 0x0000D648 File Offset: 0x0000B848
	[Token(Token = "0x600010B")]
	[Address(RVA = "0x27196E8", Offset = "0x27196E8", VA = "0x27196E8")]
	public void ߃\u0602\u0891߇(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600010C RID: 268 RVA: 0x0000D678 File Offset: 0x0000B878
	[Token(Token = "0x600010C")]
	[Address(RVA = "0x27197B0", Offset = "0x27197B0", VA = "0x27197B0")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600010D RID: 269 RVA: 0x0000D6A8 File Offset: 0x0000B8A8
	[Token(Token = "0x600010D")]
	[Address(RVA = "0x2719878", Offset = "0x2719878", VA = "0x2719878")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
	}

	// Token: 0x0600010E RID: 270 RVA: 0x0000D6CC File Offset: 0x0000B8CC
	[Token(Token = "0x600010E")]
	[Address(RVA = "0x2719940", Offset = "0x2719940", VA = "0x2719940")]
	public void ࢳ\u06D8Ԙ\u05FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600010F RID: 271 RVA: 0x0000D6FC File Offset: 0x0000B8FC
	[Token(Token = "0x600010F")]
	[Address(RVA = "0x2719A08", Offset = "0x2719A08", VA = "0x2719A08")]
	public void \u06E2ڇ\u07BF߃(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000110 RID: 272 RVA: 0x0000D72C File Offset: 0x0000B92C
	[Token(Token = "0x6000110")]
	[Address(RVA = "0x2719AD0", Offset = "0x2719AD0", VA = "0x2719AD0")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000111 RID: 273 RVA: 0x0000D75C File Offset: 0x0000B95C
	[Token(Token = "0x6000111")]
	[Address(RVA = "0x2719B98", Offset = "0x2719B98", VA = "0x2719B98")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000112 RID: 274 RVA: 0x0000D78C File Offset: 0x0000B98C
	[Token(Token = "0x6000112")]
	[Address(RVA = "0x2719C60", Offset = "0x2719C60", VA = "0x2719C60")]
	public void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000113 RID: 275 RVA: 0x0000D7BC File Offset: 0x0000B9BC
	[Token(Token = "0x6000113")]
	[Address(RVA = "0x2719D28", Offset = "0x2719D28", VA = "0x2719D28")]
	public void \u05A0ڵ\u0823ڈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000114 RID: 276 RVA: 0x0000D7EC File Offset: 0x0000B9EC
	[Token(Token = "0x6000114")]
	[Address(RVA = "0x2719DF0", Offset = "0x2719DF0", VA = "0x2719DF0")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000115 RID: 277 RVA: 0x0000D81C File Offset: 0x0000BA1C
	[Token(Token = "0x6000115")]
	[Address(RVA = "0x2719EB8", Offset = "0x2719EB8", VA = "0x2719EB8")]
	public void ة\u066Dࡏԫ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000116 RID: 278 RVA: 0x0000D84C File Offset: 0x0000BA4C
	[Token(Token = "0x6000116")]
	[Address(RVA = "0x2719F80", Offset = "0x2719F80", VA = "0x2719F80")]
	public void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000117 RID: 279 RVA: 0x0000D87C File Offset: 0x0000BA7C
	[Token(Token = "0x6000117")]
	[Address(RVA = "0x271A048", Offset = "0x271A048", VA = "0x271A048")]
	public void \u06DEӸԏ\u07BF(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000118 RID: 280 RVA: 0x0000D8AC File Offset: 0x0000BAAC
	[Token(Token = "0x6000118")]
	[Address(RVA = "0x271A110", Offset = "0x271A110", VA = "0x271A110")]
	public void Ԍޟࡀݲ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000119 RID: 281 RVA: 0x0000D8DC File Offset: 0x0000BADC
	[Token(Token = "0x6000119")]
	[Address(RVA = "0x271A1D8", Offset = "0x271A1D8", VA = "0x271A1D8")]
	public void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600011A RID: 282 RVA: 0x0000D90C File Offset: 0x0000BB0C
	[Token(Token = "0x600011A")]
	[Address(RVA = "0x271A2A0", Offset = "0x271A2A0", VA = "0x271A2A0")]
	public void ؽ\u058C\u05A6\u0871(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600011B RID: 283 RVA: 0x0000D93C File Offset: 0x0000BB3C
	[Token(Token = "0x600011B")]
	[Address(RVA = "0x271A368", Offset = "0x271A368", VA = "0x271A368")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600011C RID: 284 RVA: 0x0000D96C File Offset: 0x0000BB6C
	[Token(Token = "0x600011C")]
	[Address(RVA = "0x271A430", Offset = "0x271A430", VA = "0x271A430")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600011D RID: 285 RVA: 0x0000D99C File Offset: 0x0000BB9C
	[Token(Token = "0x600011D")]
	[Address(RVA = "0x271A4F8", Offset = "0x271A4F8", VA = "0x271A4F8")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600011E RID: 286 RVA: 0x0000D9CC File Offset: 0x0000BBCC
	[Token(Token = "0x600011E")]
	[Address(RVA = "0x271A5C0", Offset = "0x271A5C0", VA = "0x271A5C0")]
	public void ٽ߆ࡑՄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600011F RID: 287 RVA: 0x0000D9FC File Offset: 0x0000BBFC
	[Token(Token = "0x600011F")]
	[Address(RVA = "0x271A688", Offset = "0x271A688", VA = "0x271A688")]
	public void ԁؼՖռ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000120 RID: 288 RVA: 0x0000DA2C File Offset: 0x0000BC2C
	[Token(Token = "0x6000120")]
	[Address(RVA = "0x271A750", Offset = "0x271A750", VA = "0x271A750")]
	public void \u083Eܙ\u07FD\u0706(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000121 RID: 289 RVA: 0x0000DA5C File Offset: 0x0000BC5C
	[Token(Token = "0x6000121")]
	[Address(RVA = "0x271A818", Offset = "0x271A818", VA = "0x271A818")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000122 RID: 290 RVA: 0x0000DA8C File Offset: 0x0000BC8C
	[Token(Token = "0x6000122")]
	[Address(RVA = "0x271A8E0", Offset = "0x271A8E0", VA = "0x271A8E0")]
	public void ԗ\u05F9ҿ\u0834(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000123 RID: 291 RVA: 0x0000DABC File Offset: 0x0000BCBC
	[Token(Token = "0x6000123")]
	[Address(RVA = "0x271A9A8", Offset = "0x271A9A8", VA = "0x271A9A8")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000124 RID: 292 RVA: 0x0000DAEC File Offset: 0x0000BCEC
	[Token(Token = "0x6000124")]
	[Address(RVA = "0x271AA70", Offset = "0x271AA70", VA = "0x271AA70")]
	public void \u05F8ڛߠ\u05BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000125 RID: 293 RVA: 0x0000DB1C File Offset: 0x0000BD1C
	[Token(Token = "0x6000125")]
	[Address(RVA = "0x271AB38", Offset = "0x271AB38", VA = "0x271AB38")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000126 RID: 294 RVA: 0x0000DB4C File Offset: 0x0000BD4C
	[Token(Token = "0x6000126")]
	[Address(RVA = "0x271AC00", Offset = "0x271AC00", VA = "0x271AC00")]
	public void ӻڊ\u05B3ۍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000127 RID: 295 RVA: 0x0000DB7C File Offset: 0x0000BD7C
	[Token(Token = "0x6000127")]
	[Address(RVA = "0x271ACC8", Offset = "0x271ACC8", VA = "0x271ACC8")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000128 RID: 296 RVA: 0x0000DBAC File Offset: 0x0000BDAC
	[Token(Token = "0x6000128")]
	[Address(RVA = "0x271AD90", Offset = "0x271AD90", VA = "0x271AD90")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000129 RID: 297 RVA: 0x0000DBDC File Offset: 0x0000BDDC
	[Token(Token = "0x6000129")]
	[Address(RVA = "0x271AE58", Offset = "0x271AE58", VA = "0x271AE58")]
	public void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600012A RID: 298 RVA: 0x0000DC0C File Offset: 0x0000BE0C
	[Token(Token = "0x600012A")]
	[Address(RVA = "0x271AF20", Offset = "0x271AF20", VA = "0x271AF20")]
	public void \u0825\u05CEݍ\u083C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600012B RID: 299 RVA: 0x0000DC3C File Offset: 0x0000BE3C
	[Token(Token = "0x600012B")]
	[Address(RVA = "0x271AFE8", Offset = "0x271AFE8", VA = "0x271AFE8")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600012C RID: 300 RVA: 0x0000DC6C File Offset: 0x0000BE6C
	[Token(Token = "0x600012C")]
	[Address(RVA = "0x271B0B0", Offset = "0x271B0B0", VA = "0x271B0B0")]
	public void سࡕԞ߆(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600012D RID: 301 RVA: 0x0000DC9C File Offset: 0x0000BE9C
	[Token(Token = "0x600012D")]
	[Address(RVA = "0x271B178", Offset = "0x271B178", VA = "0x271B178")]
	public void ہۼآԄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600012E RID: 302 RVA: 0x0000DCCC File Offset: 0x0000BECC
	[Token(Token = "0x600012E")]
	[Address(RVA = "0x271B240", Offset = "0x271B240", VA = "0x271B240")]
	public void \u05B2۳\u0590\u0612(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600012F RID: 303 RVA: 0x0000DCFC File Offset: 0x0000BEFC
	[Token(Token = "0x600012F")]
	[Address(RVA = "0x271B308", Offset = "0x271B308", VA = "0x271B308")]
	public BobObjectManager()
	{
	}

	// Token: 0x06000130 RID: 304 RVA: 0x0000DD10 File Offset: 0x0000BF10
	[Token(Token = "0x6000130")]
	[Address(RVA = "0x271B310", Offset = "0x271B310", VA = "0x271B310")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000131 RID: 305 RVA: 0x0000DD40 File Offset: 0x0000BF40
	[Token(Token = "0x6000131")]
	[Address(RVA = "0x271B3D8", Offset = "0x271B3D8", VA = "0x271B3D8")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000132 RID: 306 RVA: 0x0000DD70 File Offset: 0x0000BF70
	[Token(Token = "0x6000132")]
	[Address(RVA = "0x271B4A0", Offset = "0x271B4A0", VA = "0x271B4A0")]
	public void قԙ\u0653պ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		bool flag = \u07FEל\u05AC\u0877;
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000133 RID: 307 RVA: 0x0000DDA4 File Offset: 0x0000BFA4
	[Token(Token = "0x6000133")]
	[Address(RVA = "0x271B568", Offset = "0x271B568", VA = "0x271B568")]
	public void ܯר\u05C7ڗ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000134 RID: 308 RVA: 0x0000DDD4 File Offset: 0x0000BFD4
	[Token(Token = "0x6000134")]
	[Address(RVA = "0x271B630", Offset = "0x271B630", VA = "0x271B630")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000135 RID: 309 RVA: 0x0000DE04 File Offset: 0x0000C004
	[Token(Token = "0x6000135")]
	[Address(RVA = "0x271B6F8", Offset = "0x271B6F8", VA = "0x271B6F8")]
	public void ڎՅڤࠊ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000136 RID: 310 RVA: 0x0000DE34 File Offset: 0x0000C034
	[Token(Token = "0x6000136")]
	[Address(RVA = "0x271B7C0", Offset = "0x271B7C0", VA = "0x271B7C0")]
	public void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000137 RID: 311 RVA: 0x0000DE64 File Offset: 0x0000C064
	[Token(Token = "0x6000137")]
	[Address(RVA = "0x271B888", Offset = "0x271B888", VA = "0x271B888")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000138 RID: 312 RVA: 0x0000DE94 File Offset: 0x0000C094
	[Token(Token = "0x6000138")]
	[Address(RVA = "0x271B950", Offset = "0x271B950", VA = "0x271B950")]
	public void Ԍߊٱݩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000139 RID: 313 RVA: 0x0000DEC4 File Offset: 0x0000C0C4
	[Token(Token = "0x6000139")]
	[Address(RVA = "0x271BA18", Offset = "0x271BA18", VA = "0x271BA18")]
	public void ۷ޞ\u07AFߍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600013A RID: 314 RVA: 0x0000DEF4 File Offset: 0x0000C0F4
	[Token(Token = "0x600013A")]
	[Address(RVA = "0x271BAE0", Offset = "0x271BAE0", VA = "0x271BAE0")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600013B RID: 315 RVA: 0x0000DF24 File Offset: 0x0000C124
	[Token(Token = "0x600013B")]
	[Address(RVA = "0x271BBA8", Offset = "0x271BBA8", VA = "0x271BBA8")]
	public void \u0748\u05F4Նۏ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600013C RID: 316 RVA: 0x0000DF54 File Offset: 0x0000C154
	[Token(Token = "0x600013C")]
	[Address(RVA = "0x271BC70", Offset = "0x271BC70", VA = "0x271BC70")]
	public void ت\u05F9ޅ\u059A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600013D RID: 317 RVA: 0x0000DF84 File Offset: 0x0000C184
	[Token(Token = "0x600013D")]
	[Address(RVA = "0x271BD38", Offset = "0x271BD38", VA = "0x271BD38")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600013E RID: 318 RVA: 0x0000DFB4 File Offset: 0x0000C1B4
	[Token(Token = "0x600013E")]
	[Address(RVA = "0x271BE00", Offset = "0x271BE00", VA = "0x271BE00")]
	public void \u0609ۯ\u05B4ؼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600013F RID: 319 RVA: 0x0000DFE4 File Offset: 0x0000C1E4
	[Token(Token = "0x600013F")]
	[Address(RVA = "0x271BEC8", Offset = "0x271BEC8", VA = "0x271BEC8")]
	public void Պ\u07F7\u066AՅ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000140 RID: 320 RVA: 0x0000E014 File Offset: 0x0000C214
	[Token(Token = "0x6000140")]
	[Address(RVA = "0x271BF90", Offset = "0x271BF90", VA = "0x271BF90")]
	public void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000141 RID: 321 RVA: 0x0000E044 File Offset: 0x0000C244
	[Token(Token = "0x6000141")]
	[Address(RVA = "0x271C058", Offset = "0x271C058", VA = "0x271C058")]
	public void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000142 RID: 322 RVA: 0x0000E074 File Offset: 0x0000C274
	[Token(Token = "0x6000142")]
	[Address(RVA = "0x271C120", Offset = "0x271C120", VA = "0x271C120")]
	public void Ӛ\u055D\u0651Խ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000143 RID: 323 RVA: 0x0000E0A4 File Offset: 0x0000C2A4
	[Token(Token = "0x6000143")]
	[Address(RVA = "0x271C1E8", Offset = "0x271C1E8", VA = "0x271C1E8")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000144 RID: 324 RVA: 0x0000E0D4 File Offset: 0x0000C2D4
	[Token(Token = "0x6000144")]
	[Address(RVA = "0x271C2B0", Offset = "0x271C2B0", VA = "0x271C2B0")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000145 RID: 325 RVA: 0x0000E104 File Offset: 0x0000C304
	[Token(Token = "0x6000145")]
	[Address(RVA = "0x271C378", Offset = "0x271C378", VA = "0x271C378")]
	public void \u07B2߆Ժࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000146 RID: 326 RVA: 0x0000E134 File Offset: 0x0000C334
	[Token(Token = "0x6000146")]
	[Address(RVA = "0x271C440", Offset = "0x271C440", VA = "0x271C440")]
	public void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000147 RID: 327 RVA: 0x0000E164 File Offset: 0x0000C364
	[Token(Token = "0x6000147")]
	[Address(RVA = "0x271C508", Offset = "0x271C508", VA = "0x271C508")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000148 RID: 328 RVA: 0x0000E194 File Offset: 0x0000C394
	[Token(Token = "0x6000148")]
	[Address(RVA = "0x271C5D0", Offset = "0x271C5D0", VA = "0x271C5D0")]
	public void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x06000149 RID: 329 RVA: 0x0000E1C4 File Offset: 0x0000C3C4
	[Token(Token = "0x6000149")]
	[Address(RVA = "0x271C698", Offset = "0x271C698", VA = "0x271C698")]
	public void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600014A RID: 330 RVA: 0x0000E1F4 File Offset: 0x0000C3F4
	[Token(Token = "0x600014A")]
	[Address(RVA = "0x271C760", Offset = "0x271C760", VA = "0x271C760")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600014B RID: 331 RVA: 0x0000E224 File Offset: 0x0000C424
	[Token(Token = "0x600014B")]
	[Address(RVA = "0x271C828", Offset = "0x271C828", VA = "0x271C828")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600014C RID: 332 RVA: 0x0000E254 File Offset: 0x0000C454
	[Token(Token = "0x600014C")]
	[Address(RVA = "0x271C8F0", Offset = "0x271C8F0", VA = "0x271C8F0")]
	public void ܘݱ\u083CԲ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 0L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600014D RID: 333 RVA: 0x0000E284 File Offset: 0x0000C484
	[Token(Token = "0x600014D")]
	[Address(RVA = "0x271C9B8", Offset = "0x271C9B8", VA = "0x271C9B8")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0600014E RID: 334 RVA: 0x0000E2B4 File Offset: 0x0000C4B4
	[Token(Token = "0x600014E")]
	[Address(RVA = "0x271CA80", Offset = "0x271CA80", VA = "0x271CA80")]
	public void ܫ\u085Eہӝ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0702_u05A2Ԭԃ = this.\u0702\u05A2Ԭԃ;
		long active = 1L;
		u0702_u05A2Ԭԃ.SetActive(active != 0L);
	}

	// Token: 0x0400002D RID: 45
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400002D")]
	public GameObject \u0702\u05A2Ԭԃ;
}
