﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x02000037 RID: 55
[Token(Token = "0x2000037")]
public class NetworkManager : MonoBehaviourPunCallbacks
{
	// Token: 0x06000713 RID: 1811 RVA: 0x00028CB8 File Offset: 0x00026EB8
	[Token(Token = "0x6000713")]
	[Address(RVA = "0x2D3B0FC", Offset = "0x2D3B0FC", VA = "0x2D3B0FC")]
	private void \u085Eֈԧ\u070C()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("FingerTip");
	}

	// Token: 0x06000714 RID: 1812 RVA: 0x00028CE8 File Offset: 0x00026EE8
	[Token(Token = "0x6000714")]
	[Address(RVA = "0x2D3B1A4", Offset = "0x2D3B1A4", VA = "0x2D3B1A4")]
	private void ۮߝڪڐ()
	{
		this.\u074Bڑ\u05C4ո();
	}

	// Token: 0x06000715 RID: 1813 RVA: 0x00028CFC File Offset: 0x00026EFC
	[Token(Token = "0x6000715")]
	[Address(RVA = "0x2D3B250", Offset = "0x2D3B250", VA = "0x2D3B250")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
		this.ࡅӐڱԾ();
	}

	// Token: 0x06000716 RID: 1814 RVA: 0x00028D10 File Offset: 0x00026F10
	[Token(Token = "0x6000716")]
	[Address(RVA = "0x2D3B2FC", Offset = "0x2D3B2FC", VA = "0x2D3B2FC")]
	private void ١ۏ\u05C4ӝ()
	{
		this.Ӎ\u05C2ࢩԁ();
	}

	// Token: 0x06000717 RID: 1815 RVA: 0x00028D24 File Offset: 0x00026F24
	[Token(Token = "0x6000717")]
	[Address(RVA = "0x2D3B3A8", Offset = "0x2D3B3A8", VA = "0x2D3B3A8")]
	private void վࠐ\u085A\u0895()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("run");
	}

	// Token: 0x06000718 RID: 1816 RVA: 0x00028D54 File Offset: 0x00026F54
	[Token(Token = "0x6000718")]
	[Address(RVA = "0x2D3B450", Offset = "0x2D3B450", VA = "0x2D3B450", Slot = "43")]
	public override void OnPlayerLeftRoom(Player ݑڋۋӈ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("A Player has left the Room.");
		base.OnPlayerLeftRoom(ݑڋۋӈ);
	}

	// Token: 0x06000719 RID: 1817 RVA: 0x00028D7C File Offset: 0x00026F7C
	[Token(Token = "0x6000719")]
	[Address(RVA = "0x2D3B4E4", Offset = "0x2D3B4E4", VA = "0x2D3B4E4")]
	private void ߒ\u065EՎࡖ()
	{
		this.ࡅӐڱԾ();
	}

	// Token: 0x0600071A RID: 1818 RVA: 0x00028D90 File Offset: 0x00026F90
	[Token(Token = "0x600071A")]
	[Address(RVA = "0x2D3B4E8", Offset = "0x2D3B4E8", VA = "0x2D3B4E8", Slot = "41")]
	public override void OnJoinedRoom()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Joined a Room.");
		base.OnJoinedRoom();
	}

	// Token: 0x0600071B RID: 1819 RVA: 0x00028DB4 File Offset: 0x00026FB4
	[Token(Token = "0x600071B")]
	[Address(RVA = "0x2D3B56C", Offset = "0x2D3B56C", VA = "0x2D3B56C")]
	private void ࢰחڵࡓ()
	{
		this.ڿԯ\u05B2خ();
	}

	// Token: 0x0600071C RID: 1820 RVA: 0x00028DC8 File Offset: 0x00026FC8
	[Token(Token = "0x600071C")]
	[Address(RVA = "0x2D3B618", Offset = "0x2D3B618", VA = "0x2D3B618")]
	private void ػݚفޓ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Faild To Add Winner Money: ");
	}

	// Token: 0x0600071D RID: 1821 RVA: 0x00028DF8 File Offset: 0x00026FF8
	[Token(Token = "0x600071D")]
	[Address(RVA = "0x2D3B6C0", Offset = "0x2D3B6C0", VA = "0x2D3B6C0", Slot = "45")]
	public override void OnConnectedToMaster()
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Connected to Server.");
		base.OnConnectedToMaster();
		Hashtable hashtable = new Hashtable();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.MaxPlayers = 10;
		roomOptions.isVisible = (257 != 0);
		if (10 == 0)
		{
		}
	}

	// Token: 0x0600071E RID: 1822 RVA: 0x00028E48 File Offset: 0x00027048
	[Token(Token = "0x600071E")]
	[Address(RVA = "0x2D3B888", Offset = "0x2D3B888", VA = "0x2D3B888")]
	private void ڍ\u058Bݗࡣ()
	{
		this.լހݺղ();
	}

	// Token: 0x0600071F RID: 1823 RVA: 0x00028E5C File Offset: 0x0002705C
	[Token(Token = "0x600071F")]
	[Address(RVA = "0x2D3B934", Offset = "0x2D3B934", VA = "0x2D3B934")]
	private void ࠏޤݳ\u06DD()
	{
		this.ݐ\u07ACج\u061C();
	}

	// Token: 0x06000720 RID: 1824 RVA: 0x00028E70 File Offset: 0x00027070
	[Token(Token = "0x6000720")]
	[Address(RVA = "0x2D3B9E0", Offset = "0x2D3B9E0", VA = "0x2D3B9E0")]
	private void \u0733ࡂ\u0736ࠕ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("\tExpires: ");
	}

	// Token: 0x06000721 RID: 1825 RVA: 0x00028EA0 File Offset: 0x000270A0
	[Token(Token = "0x6000721")]
	[Address(RVA = "0x2D3BA88", Offset = "0x2D3BA88", VA = "0x2D3BA88")]
	private void \u06EDٵ۶\u06DB()
	{
		this.ࡅӐڱԾ();
	}

	// Token: 0x06000722 RID: 1826 RVA: 0x00028EB4 File Offset: 0x000270B4
	[Token(Token = "0x6000722")]
	[Address(RVA = "0x2D3BA8C", Offset = "0x2D3BA8C", VA = "0x2D3BA8C")]
	private void \u085Aڏ\u0591ٶ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Room Name: ");
	}

	// Token: 0x06000723 RID: 1827 RVA: 0x00028EE4 File Offset: 0x000270E4
	[Token(Token = "0x6000723")]
	[Address(RVA = "0x2D3B1A8", Offset = "0x2D3B1A8", VA = "0x2D3B1A8")]
	private void \u074Bڑ\u05C4ո()
	{
		if ("\ud9c0\udc00" == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("True");
	}

	// Token: 0x06000724 RID: 1828 RVA: 0x00028F14 File Offset: 0x00027114
	[Token(Token = "0x6000724")]
	[Address(RVA = "0x2D3BB34", Offset = "0x2D3BB34", VA = "0x2D3BB34")]
	private void \u066Aشӵԕ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Joined a Room.");
	}

	// Token: 0x06000725 RID: 1829 RVA: 0x00028F44 File Offset: 0x00027144
	[Token(Token = "0x6000725")]
	[Address(RVA = "0x2D3BBDC", Offset = "0x2D3BBDC", VA = "0x2D3BBDC")]
	private void \u0834\u0817ރࡔ()
	{
		this.\u085Aڏ\u0591ٶ();
	}

	// Token: 0x06000726 RID: 1830 RVA: 0x00028F58 File Offset: 0x00027158
	[Token(Token = "0x6000726")]
	[Address(RVA = "0x2D3BBE0", Offset = "0x2D3BBE0", VA = "0x2D3BBE0")]
	private void \u0838ڹ\u07F5\u07AE()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("ORGPORT");
	}

	// Token: 0x06000727 RID: 1831 RVA: 0x00028F88 File Offset: 0x00027188
	[Token(Token = "0x6000727")]
	[Address(RVA = "0x2D3BC88", Offset = "0x2D3BC88", VA = "0x2D3BC88")]
	private void ߉ې\u07F6Ӭ()
	{
		this.լހݺղ();
	}

	// Token: 0x06000728 RID: 1832 RVA: 0x00028F9C File Offset: 0x0002719C
	[Token(Token = "0x6000728")]
	[Address(RVA = "0x2D3BC8C", Offset = "0x2D3BC8C", VA = "0x2D3BC8C")]
	private void ۊ\u0837ࢮڅ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("monkeScream");
	}

	// Token: 0x06000729 RID: 1833 RVA: 0x00028FCC File Offset: 0x000271CC
	[Token(Token = "0x6000729")]
	[Address(RVA = "0x2D3BD34", Offset = "0x2D3BD34", VA = "0x2D3BD34")]
	private void ߒޛ۹ז()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Found Gameobject: ");
	}

	// Token: 0x0600072A RID: 1834 RVA: 0x00028FFC File Offset: 0x000271FC
	[Token(Token = "0x600072A")]
	[Address(RVA = "0x2D3BDDC", Offset = "0x2D3BDDC", VA = "0x2D3BDDC")]
	private void ڣֆ\u07F4ڌ()
	{
		this.\u085Aڏ\u0591ٶ();
	}

	// Token: 0x0600072B RID: 1835 RVA: 0x00029010 File Offset: 0x00027210
	[Token(Token = "0x600072B")]
	[Address(RVA = "0x2D3BDE0", Offset = "0x2D3BDE0", VA = "0x2D3BDE0")]
	private void ޡࠅ\u089Aߔ()
	{
		this.ӯܛ\u055Aץ();
	}

	// Token: 0x0600072C RID: 1836 RVA: 0x00029024 File Offset: 0x00027224
	[Token(Token = "0x600072C")]
	[Address(RVA = "0x2D3BE8C", Offset = "0x2D3BE8C", VA = "0x2D3BE8C")]
	private void \u05ABޑ\u05FD\u05BF()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Faild To Add Winner Money: ");
	}

	// Token: 0x0600072D RID: 1837 RVA: 0x00029054 File Offset: 0x00027254
	[Token(Token = "0x600072D")]
	[Address(RVA = "0x2D3BF34", Offset = "0x2D3BF34", VA = "0x2D3BF34")]
	private void ޠۋ\u0530\u073E()
	{
		this.ڿԯ\u05B2خ();
	}

	// Token: 0x0600072E RID: 1838 RVA: 0x00029068 File Offset: 0x00027268
	[Token(Token = "0x600072E")]
	[Address(RVA = "0x2D3BF38", Offset = "0x2D3BF38", VA = "0x2D3BF38")]
	private void \u0558ݕݤݮ()
	{
		this.\u0733ࡂ\u0736ࠕ();
	}

	// Token: 0x0600072F RID: 1839 RVA: 0x0002907C File Offset: 0x0002727C
	[Token(Token = "0x600072F")]
	[Address(RVA = "0x2D3BF3C", Offset = "0x2D3BF3C", VA = "0x2D3BF3C")]
	private void ߊڌӅ\u0596()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("ErrorScreen");
	}

	// Token: 0x06000730 RID: 1840 RVA: 0x000290AC File Offset: 0x000272AC
	[Token(Token = "0x6000730")]
	[Address(RVA = "0x2D3BFE4", Offset = "0x2D3BFE4", VA = "0x2D3BFE4")]
	private void ࡖ\u0731\u05C2ߪ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Name Changing Error. Error: ");
	}

	// Token: 0x06000731 RID: 1841 RVA: 0x000290DC File Offset: 0x000272DC
	[Token(Token = "0x6000731")]
	[Address(RVA = "0x2D3C08C", Offset = "0x2D3C08C", VA = "0x2D3C08C")]
	private void ۆڛߟ\u05A0()
	{
		this.ࡅӐڱԾ();
	}

	// Token: 0x06000732 RID: 1842 RVA: 0x000290F0 File Offset: 0x000272F0
	[Token(Token = "0x6000732")]
	[Address(RVA = "0x2D3BDE4", Offset = "0x2D3BDE4", VA = "0x2D3BDE4")]
	private void ӯܛ\u055Aץ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("typesOfTalk");
	}

	// Token: 0x06000733 RID: 1843 RVA: 0x00029120 File Offset: 0x00027320
	[Token(Token = "0x6000733")]
	[Address(RVA = "0x2D3B938", Offset = "0x2D3B938", VA = "0x2D3B938")]
	private void ݐ\u07ACج\u061C()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("isLava");
	}

	// Token: 0x06000734 RID: 1844 RVA: 0x00029150 File Offset: 0x00027350
	[Token(Token = "0x6000734")]
	[Address(RVA = "0x2D3B570", Offset = "0x2D3B570", VA = "0x2D3B570")]
	private void ڿԯ\u05B2خ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
	}

	// Token: 0x06000735 RID: 1845 RVA: 0x00029180 File Offset: 0x00027380
	[Token(Token = "0x6000735")]
	[Address(RVA = "0x2D3B300", Offset = "0x2D3B300", VA = "0x2D3B300")]
	private void Ӎ\u05C2ࢩԁ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Try Connect To Server...");
	}

	// Token: 0x06000736 RID: 1846 RVA: 0x000291B0 File Offset: 0x000273B0
	[Token(Token = "0x6000736")]
	[Address(RVA = "0x2D3C090", Offset = "0x2D3C090", VA = "0x2D3C090")]
	private void ա\u0881ہࡆ()
	{
		if ("koi8r" == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000737 RID: 1847 RVA: 0x000291D4 File Offset: 0x000273D4
	[Token(Token = "0x6000737")]
	[Address(RVA = "0x2D3C138", Offset = "0x2D3C138", VA = "0x2D3C138", Slot = "42")]
	public override void OnPlayerEnteredRoom(Player \u05FB\u0610\u05F7\u065F)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("A new Player joined a Room.");
		base.OnPlayerEnteredRoom(\u05FB\u0610\u05F7\u065F);
	}

	// Token: 0x06000738 RID: 1848 RVA: 0x000291FC File Offset: 0x000273FC
	[Token(Token = "0x6000738")]
	[Address(RVA = "0x2D3C1CC", Offset = "0x2D3C1CC", VA = "0x2D3C1CC")]
	private void ןٮ\u061FԺ()
	{
		this.\u0733ࡂ\u0736ࠕ();
	}

	// Token: 0x06000739 RID: 1849 RVA: 0x00029210 File Offset: 0x00027410
	[Token(Token = "0x6000739")]
	[Address(RVA = "0x2D3C1D0", Offset = "0x2D3C1D0", VA = "0x2D3C1D0")]
	private void \u088Bޢޚֆ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Start Gamemode");
	}

	// Token: 0x0600073A RID: 1850 RVA: 0x00029240 File Offset: 0x00027440
	[Token(Token = "0x600073A")]
	[Address(RVA = "0x2D3B254", Offset = "0x2D3B254", VA = "0x2D3B254")]
	private void ࡅӐڱԾ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Start Gamemode");
	}

	// Token: 0x0600073B RID: 1851 RVA: 0x00029270 File Offset: 0x00027470
	[Token(Token = "0x600073B")]
	[Address(RVA = "0x2D3C278", Offset = "0x2D3C278", VA = "0x2D3C278")]
	private void Start()
	{
		this.Ӎ\u05C2ࢩԁ();
	}

	// Token: 0x0600073C RID: 1852 RVA: 0x00029284 File Offset: 0x00027484
	[Token(Token = "0x600073C")]
	[Address(RVA = "0x2D3C27C", Offset = "0x2D3C27C", VA = "0x2D3C27C")]
	private void حتݻ\u05B0()
	{
		this.\u0872߆ݵڈ();
	}

	// Token: 0x0600073D RID: 1853 RVA: 0x00029298 File Offset: 0x00027498
	[Token(Token = "0x600073D")]
	[Address(RVA = "0x2D3C328", Offset = "0x2D3C328", VA = "0x2D3C328")]
	private void צөࠑߪ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("isLava");
	}

	// Token: 0x0600073E RID: 1854 RVA: 0x000292C8 File Offset: 0x000274C8
	[Token(Token = "0x600073E")]
	[Address(RVA = "0x2D3B88C", Offset = "0x2D3B88C", VA = "0x2D3B88C")]
	private void լހݺղ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("FingerTip");
	}

	// Token: 0x0600073F RID: 1855 RVA: 0x000292F8 File Offset: 0x000274F8
	[Token(Token = "0x600073F")]
	[Address(RVA = "0x2D3C3D0", Offset = "0x2D3C3D0", VA = "0x2D3C3D0")]
	private void וࡪךӧ()
	{
		this.ߒޛ۹ז();
	}

	// Token: 0x06000740 RID: 1856 RVA: 0x0002930C File Offset: 0x0002750C
	[Token(Token = "0x6000740")]
	[Address(RVA = "0x2D3C3D4", Offset = "0x2D3C3D4", VA = "0x2D3C3D4")]
	private void ࢥ\u081CՕࡋ()
	{
		this.լހݺղ();
	}

	// Token: 0x06000741 RID: 1857 RVA: 0x00029320 File Offset: 0x00027520
	[Token(Token = "0x6000741")]
	[Address(RVA = "0x2D3C280", Offset = "0x2D3C280", VA = "0x2D3C280")]
	private void \u0872߆ݵڈ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.ConnectUsingSettings();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("PURCHASE");
	}

	// Token: 0x06000742 RID: 1858 RVA: 0x00029350 File Offset: 0x00027550
	[Token(Token = "0x6000742")]
	[Address(RVA = "0x2D3C3D8", Offset = "0x2D3C3D8", VA = "0x2D3C3D8")]
	private void ݱ\u0832ݥ\u08B5()
	{
		this.ߒޛ۹ז();
	}

	// Token: 0x06000743 RID: 1859 RVA: 0x00029364 File Offset: 0x00027564
	[Token(Token = "0x6000743")]
	[Address(RVA = "0x2D3C3DC", Offset = "0x2D3C3DC", VA = "0x2D3C3DC")]
	private void \u06D6ې\u083Bࠉ()
	{
		this.լހݺղ();
	}

	// Token: 0x06000744 RID: 1860 RVA: 0x00029378 File Offset: 0x00027578
	[Token(Token = "0x6000744")]
	[Address(RVA = "0x2D3C3E0", Offset = "0x2D3C3E0", VA = "0x2D3C3E0")]
	public NetworkManager()
	{
	}

	// Token: 0x06000745 RID: 1861 RVA: 0x0002938C File Offset: 0x0002758C
	[Token(Token = "0x6000745")]
	[Address(RVA = "0x2D3C3E8", Offset = "0x2D3C3E8", VA = "0x2D3C3E8")]
	private void \u0656ӺմՁ()
	{
		this.\u0733ࡂ\u0736ࠕ();
	}
}
