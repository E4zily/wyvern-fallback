﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000D1 RID: 209
[Token(Token = "0x20000D1")]
public class ParentOnEnter : MonoBehaviour
{
	// Token: 0x06001FB4 RID: 8116 RVA: 0x000A67DC File Offset: 0x000A49DC
	[Token(Token = "0x6001FB4")]
	[Address(RVA = "0x2D4AB24", Offset = "0x2D4AB24", VA = "0x2D4AB24")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FB5 RID: 8117 RVA: 0x000A6808 File Offset: 0x000A4A08
	[Token(Token = "0x6001FB5")]
	[Address(RVA = "0x2D4ABBC", Offset = "0x2D4ABBC", VA = "0x2D4ABBC")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FB6 RID: 8118 RVA: 0x000A6844 File Offset: 0x000A4A44
	[Token(Token = "0x6001FB6")]
	[Address(RVA = "0x2D4AC54", Offset = "0x2D4AC54", VA = "0x2D4AC54")]
	public void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("TurnAmount");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FB7 RID: 8119 RVA: 0x000A6870 File Offset: 0x000A4A70
	[Token(Token = "0x6001FB7")]
	[Address(RVA = "0x2D4ACEC", Offset = "0x2D4ACEC", VA = "0x2D4ACEC")]
	public void ؽ\u058C\u05A6\u0871(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_WobbleX");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FB8 RID: 8120 RVA: 0x000A689C File Offset: 0x000A4A9C
	[Token(Token = "0x6001FB8")]
	[Address(RVA = "0x2D4AD84", Offset = "0x2D4AD84", VA = "0x2D4AD84")]
	public void ܯר\u05C7ڗ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FB9 RID: 8121 RVA: 0x000A68D8 File Offset: 0x000A4AD8
	[Token(Token = "0x6001FB9")]
	[Address(RVA = "0x2D4AE1C", Offset = "0x2D4AE1C", VA = "0x2D4AE1C")]
	public ParentOnEnter()
	{
	}

	// Token: 0x06001FBA RID: 8122 RVA: 0x000A68EC File Offset: 0x000A4AEC
	[Token(Token = "0x6001FBA")]
	[Address(RVA = "0x2D4AE24", Offset = "0x2D4AE24", VA = "0x2D4AE24")]
	public void \u0836Չװߟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FBB RID: 8123 RVA: 0x000A6918 File Offset: 0x000A4B18
	[Token(Token = "0x6001FBB")]
	[Address(RVA = "0x2D4AEBC", Offset = "0x2D4AEBC", VA = "0x2D4AEBC")]
	public void ؽܗӊә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("tutorialCheck");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FBC RID: 8124 RVA: 0x000A6944 File Offset: 0x000A4B44
	[Token(Token = "0x6001FBC")]
	[Address(RVA = "0x2D4AF54", Offset = "0x2D4AF54", VA = "0x2D4AF54")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ENABLE");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FBD RID: 8125 RVA: 0x000A6980 File Offset: 0x000A4B80
	[Token(Token = "0x6001FBD")]
	[Address(RVA = "0x2D4AFEC", Offset = "0x2D4AFEC", VA = "0x2D4AFEC")]
	public void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Players: ");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FBE RID: 8126 RVA: 0x000A69BC File Offset: 0x000A4BBC
	[Token(Token = "0x6001FBE")]
	[Address(RVA = "0x2D4B084", Offset = "0x2D4B084", VA = "0x2D4B084")]
	public void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("An error has occured while buying bananas, please restart your game and try again");
	}

	// Token: 0x06001FBF RID: 8127 RVA: 0x000A69E4 File Offset: 0x000A4BE4
	[Token(Token = "0x6001FBF")]
	[Address(RVA = "0x2D4B11C", Offset = "0x2D4B11C", VA = "0x2D4B11C")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("containsStaff");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FC0 RID: 8128 RVA: 0x000A6A20 File Offset: 0x000A4C20
	[Token(Token = "0x6001FC0")]
	[Address(RVA = "0x2D4B1B4", Offset = "0x2D4B1B4", VA = "0x2D4B1B4")]
	public void ہۼآԄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("isLava");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FC1 RID: 8129 RVA: 0x000A6A5C File Offset: 0x000A4C5C
	[Token(Token = "0x6001FC1")]
	[Address(RVA = "0x2D4B24C", Offset = "0x2D4B24C", VA = "0x2D4B24C")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Meta Platform entitlement error: ");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FC2 RID: 8130 RVA: 0x000A6A98 File Offset: 0x000A4C98
	[Token(Token = "0x6001FC2")]
	[Address(RVA = "0x2D4B2E4", Offset = "0x2D4B2E4", VA = "0x2D4B2E4")]
	public void ߂ڞ\u0600\u07FB(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FC3 RID: 8131 RVA: 0x000A6AC4 File Offset: 0x000A4CC4
	[Token(Token = "0x6001FC3")]
	[Address(RVA = "0x2D4B37C", Offset = "0x2D4B37C", VA = "0x2D4B37C")]
	public void ەԌ\u05C7\u085D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Push To Talk");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FC4 RID: 8132 RVA: 0x000A6B00 File Offset: 0x000A4D00
	[Token(Token = "0x6001FC4")]
	[Address(RVA = "0x2D4B414", Offset = "0x2D4B414", VA = "0x2D4B414")]
	public void \u0619طӍ\u083D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FC5 RID: 8133 RVA: 0x000A6B2C File Offset: 0x000A4D2C
	[Token(Token = "0x6001FC5")]
	[Address(RVA = "0x2D4B4AC", Offset = "0x2D4B4AC", VA = "0x2D4B4AC")]
	public void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(".Please press the button if you would like to play alone");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FC6 RID: 8134 RVA: 0x000A6B58 File Offset: 0x000A4D58
	[Token(Token = "0x6001FC6")]
	[Address(RVA = "0x2D4B544", Offset = "0x2D4B544", VA = "0x2D4B544")]
	public void \u083Eܙ\u07FD\u0706(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Charging...");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FC7 RID: 8135 RVA: 0x000A6B84 File Offset: 0x000A4D84
	[Token(Token = "0x6001FC7")]
	[Address(RVA = "0x2D4B5DC", Offset = "0x2D4B5DC", VA = "0x2D4B5DC")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Stopped Colliding");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FC8 RID: 8136 RVA: 0x000A6BC0 File Offset: 0x000A4DC0
	[Token(Token = "0x6001FC8")]
	[Address(RVA = "0x2D4B674", Offset = "0x2D4B674", VA = "0x2D4B674")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("back");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FC9 RID: 8137 RVA: 0x000A6BFC File Offset: 0x000A4DFC
	[Token(Token = "0x6001FC9")]
	[Address(RVA = "0x2D4B70C", Offset = "0x2D4B70C", VA = "0x2D4B70C")]
	public void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("Hats");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FCA RID: 8138 RVA: 0x000A6C24 File Offset: 0x000A4E24
	[Token(Token = "0x6001FCA")]
	[Address(RVA = "0x2D4B7A4", Offset = "0x2D4B7A4", VA = "0x2D4B7A4")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FCB RID: 8139 RVA: 0x000A6C60 File Offset: 0x000A4E60
	[Token(Token = "0x6001FCB")]
	[Address(RVA = "0x2D4B83C", Offset = "0x2D4B83C", VA = "0x2D4B83C")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("gamemode");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FCC RID: 8140 RVA: 0x000A6C9C File Offset: 0x000A4E9C
	[Token(Token = "0x6001FCC")]
	[Address(RVA = "0x2D4B8D4", Offset = "0x2D4B8D4", VA = "0x2D4B8D4")]
	public void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_BumpScale");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FCD RID: 8141 RVA: 0x000A6CD8 File Offset: 0x000A4ED8
	[Token(Token = "0x6001FCD")]
	[Address(RVA = "0x2D4B96C", Offset = "0x2D4B96C", VA = "0x2D4B96C")]
	public void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Not connected to room");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FCE RID: 8142 RVA: 0x000A6D04 File Offset: 0x000A4F04
	[Token(Token = "0x6001FCE")]
	[Address(RVA = "0x2D4BA04", Offset = "0x2D4BA04", VA = "0x2D4BA04")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FCF RID: 8143 RVA: 0x000A6D40 File Offset: 0x000A4F40
	[Token(Token = "0x6001FCF")]
	[Address(RVA = "0x2D4BA9C", Offset = "0x2D4BA9C", VA = "0x2D4BA9C")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeMaterialToNormal");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FD0 RID: 8144 RVA: 0x000A6D7C File Offset: 0x000A4F7C
	[Token(Token = "0x6001FD0")]
	[Address(RVA = "0x2D4BB34", Offset = "0x2D4BB34", VA = "0x2D4BB34")]
	public void ࢦ\u073Aӟࡆ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FD1 RID: 8145 RVA: 0x000A6DA8 File Offset: 0x000A4FA8
	[Token(Token = "0x6001FD1")]
	[Address(RVA = "0x2D4BBCC", Offset = "0x2D4BBCC", VA = "0x2D4BBCC")]
	public void ӻڊ\u05B3ۍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("BloodKill");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FD2 RID: 8146 RVA: 0x000A6DD4 File Offset: 0x000A4FD4
	[Token(Token = "0x6001FD2")]
	[Address(RVA = "0x2D4BC64", Offset = "0x2D4BC64", VA = "0x2D4BC64")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("DisableCosmetic");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FD3 RID: 8147 RVA: 0x000A6E10 File Offset: 0x000A5010
	[Token(Token = "0x6001FD3")]
	[Address(RVA = "0x2D4BCFC", Offset = "0x2D4BCFC", VA = "0x2D4BCFC")]
	public void ۷ޞ\u07AFߍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FD4 RID: 8148 RVA: 0x000A6E4C File Offset: 0x000A504C
	[Token(Token = "0x6001FD4")]
	[Address(RVA = "0x2D4BD94", Offset = "0x2D4BD94", VA = "0x2D4BD94")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FD5 RID: 8149 RVA: 0x000A6E7C File Offset: 0x000A507C
	[Token(Token = "0x6001FD5")]
	[Address(RVA = "0x2D4BE2C", Offset = "0x2D4BE2C", VA = "0x2D4BE2C")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("Added Winner Money");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FD6 RID: 8150 RVA: 0x000A6EB4 File Offset: 0x000A50B4
	[Token(Token = "0x6001FD6")]
	[Address(RVA = "0x2D4BEC4", Offset = "0x2D4BEC4", VA = "0x2D4BEC4")]
	public void \u06E2ڇ\u07BF߃(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("\n Time: ");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FD7 RID: 8151 RVA: 0x000A6EE0 File Offset: 0x000A50E0
	[Token(Token = "0x6001FD7")]
	[Address(RVA = "0x2D4BF5C", Offset = "0x2D4BF5C", VA = "0x2D4BF5C")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FD8 RID: 8152 RVA: 0x000A6F1C File Offset: 0x000A511C
	[Token(Token = "0x6001FD8")]
	[Address(RVA = "0x2D4BFF4", Offset = "0x2D4BFF4", VA = "0x2D4BFF4")]
	public void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("BLUPORT");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FD9 RID: 8153 RVA: 0x000A6F44 File Offset: 0x000A5144
	[Token(Token = "0x6001FD9")]
	[Address(RVA = "0x2D4C08C", Offset = "0x2D4C08C", VA = "0x2D4C08C")]
	public void ࡅڑկئ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FDA RID: 8154 RVA: 0x000A6F70 File Offset: 0x000A5170
	[Token(Token = "0x6001FDA")]
	[Address(RVA = "0x2D4C124", Offset = "0x2D4C124", VA = "0x2D4C124")]
	public void \u0885ےܝ\u05BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("typesOfTalk");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FDB RID: 8155 RVA: 0x000A6F9C File Offset: 0x000A519C
	[Token(Token = "0x6001FDB")]
	[Address(RVA = "0x2D4C1BC", Offset = "0x2D4C1BC", VA = "0x2D4C1BC")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("/");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FDC RID: 8156 RVA: 0x000A6FD8 File Offset: 0x000A51D8
	[Token(Token = "0x6001FDC")]
	[Address(RVA = "0x2D4C254", Offset = "0x2D4C254", VA = "0x2D4C254")]
	public void ԗ\u05F9ҿ\u0834(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Starting to bake textures on frame ");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FDD RID: 8157 RVA: 0x000A7014 File Offset: 0x000A5214
	[Token(Token = "0x6001FDD")]
	[Address(RVA = "0x2D4C2EC", Offset = "0x2D4C2EC", VA = "0x2D4C2EC")]
	public void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("button");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FDE RID: 8158 RVA: 0x000A7040 File Offset: 0x000A5240
	[Token(Token = "0x6001FDE")]
	[Address(RVA = "0x2D4C384", Offset = "0x2D4C384", VA = "0x2D4C384")]
	public void \u0589\u0740\u05C6ӧ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Trying Getting Entilement...");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FDF RID: 8159 RVA: 0x000A706C File Offset: 0x000A526C
	[Token(Token = "0x6001FDF")]
	[Address(RVA = "0x2D4C41C", Offset = "0x2D4C41C", VA = "0x2D4C41C")]
	public void ԁؼՖռ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FE0 RID: 8160 RVA: 0x000A7098 File Offset: 0x000A5298
	[Token(Token = "0x6001FE0")]
	[Address(RVA = "0x2D4C4B4", Offset = "0x2D4C4B4", VA = "0x2D4C4B4")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("Player");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FE1 RID: 8161 RVA: 0x000A70D0 File Offset: 0x000A52D0
	[Token(Token = "0x6001FE1")]
	[Address(RVA = "0x2D4C54C", Offset = "0x2D4C54C", VA = "0x2D4C54C")]
	public void \u0879\u0748ߙݥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FE2 RID: 8162 RVA: 0x000A70FC File Offset: 0x000A52FC
	[Token(Token = "0x6001FE2")]
	[Address(RVA = "0x2D4C5E4", Offset = "0x2D4C5E4", VA = "0x2D4C5E4")]
	public void \u085Cݯژ\u05FA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Name Changing Error. Error: ");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FE3 RID: 8163 RVA: 0x000A7128 File Offset: 0x000A5328
	[Token(Token = "0x6001FE3")]
	[Address(RVA = "0x2D4C67C", Offset = "0x2D4C67C", VA = "0x2D4C67C")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("All audio clips have been played.");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FE4 RID: 8164 RVA: 0x000A7160 File Offset: 0x000A5360
	[Token(Token = "0x6001FE4")]
	[Address(RVA = "0x2D4C714", Offset = "0x2D4C714", VA = "0x2D4C714")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayerDeath");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FE5 RID: 8165 RVA: 0x000A719C File Offset: 0x000A539C
	[Token(Token = "0x6001FE5")]
	[Address(RVA = "0x2D4C7AC", Offset = "0x2D4C7AC", VA = "0x2D4C7AC")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Add/Remove Hat");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FE6 RID: 8166 RVA: 0x000A71D8 File Offset: 0x000A53D8
	[Token(Token = "0x6001FE6")]
	[Address(RVA = "0x2D4C844", Offset = "0x2D4C844", VA = "0x2D4C844")]
	public void ڎՅڤࠊ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Tagged");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FE7 RID: 8167 RVA: 0x000A7204 File Offset: 0x000A5404
	[Token(Token = "0x6001FE7")]
	[Address(RVA = "0x2D4C8DC", Offset = "0x2D4C8DC", VA = "0x2D4C8DC")]
	public void \u07B4\u0594ԁڇ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FE8 RID: 8168 RVA: 0x000A7240 File Offset: 0x000A5440
	[Token(Token = "0x6001FE8")]
	[Address(RVA = "0x2D4C974", Offset = "0x2D4C974", VA = "0x2D4C974")]
	public void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FE9 RID: 8169 RVA: 0x000A727C File Offset: 0x000A547C
	[Token(Token = "0x6001FE9")]
	[Address(RVA = "0x2D4CA0C", Offset = "0x2D4CA0C", VA = "0x2D4CA0C")]
	public void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(". Please update you game to the latest version");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FEA RID: 8170 RVA: 0x000A72B8 File Offset: 0x000A54B8
	[Token(Token = "0x6001FEA")]
	[Address(RVA = "0x2D4CAA4", Offset = "0x2D4CAA4", VA = "0x2D4CAA4")]
	public void سࡕԞ߆(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("You are not the master of the server, you cannot start the game.");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FEB RID: 8171 RVA: 0x000A72F4 File Offset: 0x000A54F4
	[Token(Token = "0x6001FEB")]
	[Address(RVA = "0x2D4CB3C", Offset = "0x2D4CB3C", VA = "0x2D4CB3C")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FEC RID: 8172 RVA: 0x000A732C File Offset: 0x000A552C
	[Token(Token = "0x6001FEC")]
	[Address(RVA = "0x2D4CBD4", Offset = "0x2D4CBD4", VA = "0x2D4CBD4")]
	public void ފԅ\u0881ݾ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("DisableCosmetic");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FED RID: 8173 RVA: 0x000A7368 File Offset: 0x000A5568
	[Token(Token = "0x6001FED")]
	[Address(RVA = "0x2D4CC6C", Offset = "0x2D4CC6C", VA = "0x2D4CC6C")]
	public void Ԍߊٱݩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("procedural animation script required on ");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FEE RID: 8174 RVA: 0x000A7394 File Offset: 0x000A5594
	[Token(Token = "0x6001FEE")]
	[Address(RVA = "0x2D4CD04", Offset = "0x2D4CD04", VA = "0x2D4CD04")]
	public void ܘݱ\u083CԲ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FEF RID: 8175 RVA: 0x000A73D0 File Offset: 0x000A55D0
	[Token(Token = "0x6001FEF")]
	[Address(RVA = "0x2D4CD9C", Offset = "0x2D4CD9C", VA = "0x2D4CD9C")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Tagged");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FF0 RID: 8176 RVA: 0x000A740C File Offset: 0x000A560C
	[Token(Token = "0x6001FF0")]
	[Address(RVA = "0x2D4CE34", Offset = "0x2D4CE34", VA = "0x2D4CE34")]
	public void ࢳ\u06D8Ԙ\u05FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Added Winner Money");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FF1 RID: 8177 RVA: 0x000A7438 File Offset: 0x000A5638
	[Token(Token = "0x6001FF1")]
	[Address(RVA = "0x2D4CECC", Offset = "0x2D4CECC", VA = "0x2D4CECC")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("NetworkPlayer");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FF2 RID: 8178 RVA: 0x000A7474 File Offset: 0x000A5674
	[Token(Token = "0x6001FF2")]
	[Address(RVA = "0x2D4CF64", Offset = "0x2D4CF64", VA = "0x2D4CF64")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Meta Platform entitlement error: ");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Transform ࢸݯ_u07F1_u06D = this.ࢸݯ\u07F1\u06D4;
		u081B_u070Aߢࡁ.parent = ࢸݯ_u07F1_u06D;
	}

	// Token: 0x06001FF3 RID: 8179 RVA: 0x000A74B0 File Offset: 0x000A56B0
	[Token(Token = "0x6001FF3")]
	[Address(RVA = "0x2D4CFFC", Offset = "0x2D4CFFC", VA = "0x2D4CFFC")]
	public void ٽ߆ࡑՄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeToRegular");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FF4 RID: 8180 RVA: 0x000A74DC File Offset: 0x000A56DC
	[Token(Token = "0x6001FF4")]
	[Address(RVA = "0x2D4D094", Offset = "0x2D4D094", VA = "0x2D4D094")]
	public void \u05F8ڛߠ\u05BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("NetworkGunShoot");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FF5 RID: 8181 RVA: 0x000A7508 File Offset: 0x000A5708
	[Token(Token = "0x6001FF5")]
	[Address(RVA = "0x2D4D12C", Offset = "0x2D4D12C", VA = "0x2D4D12C")]
	public void \u06DEӸԏ\u07BF(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06001FF6 RID: 8182 RVA: 0x000A7534 File Offset: 0x000A5734
	[Token(Token = "0x6001FF6")]
	[Address(RVA = "0x2D4D1C4", Offset = "0x2D4D1C4", VA = "0x2D4D1C4")]
	public void ߂ӹ\u05C6\u07F9(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("False");
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x04000419 RID: 1049
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000419")]
	public Transform \u081B\u070Aߢࡁ;

	// Token: 0x0400041A RID: 1050
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400041A")]
	public Transform ࢸݯ\u07F1\u06D4;
}
