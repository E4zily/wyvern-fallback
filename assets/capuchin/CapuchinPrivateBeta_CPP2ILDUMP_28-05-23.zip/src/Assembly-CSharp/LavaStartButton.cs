﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000070 RID: 112
[Token(Token = "0x2000070")]
public class LavaStartButton : MonoBehaviour
{
	// Token: 0x060010A4 RID: 4260 RVA: 0x0006205C File Offset: 0x0006025C
	[Token(Token = "0x60010A4")]
	[Address(RVA = "0x2CCE800", Offset = "0x2CCE800", VA = "0x2CCE800")]
	public LavaStartButton()
	{
	}

	// Token: 0x060010A5 RID: 4261 RVA: 0x00062070 File Offset: 0x00060270
	[Token(Token = "0x60010A5")]
	[Address(RVA = "0x2CCE808", Offset = "0x2CCE808", VA = "0x2CCE808")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)17230;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)8192;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.Ԧ\u083E\u0652۲(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010A6 RID: 4262 RVA: 0x000620DC File Offset: 0x000602DC
	[Token(Token = "0x60010A6")]
	[Address(RVA = "0x2CCE914", Offset = "0x2CCE914", VA = "0x2CCE914")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		bool flag = \u07FEל\u05AC\u0877;
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)49152;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)24576;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010A7 RID: 4263 RVA: 0x00062154 File Offset: 0x00060354
	[Token(Token = "0x60010A7")]
	[Address(RVA = "0x2CCEA28", Offset = "0x2CCEA28", VA = "0x2CCEA28")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)32768;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)16384;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.ࠕ\u0828\u06DAց(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010A8 RID: 4264 RVA: 0x000621C8 File Offset: 0x000603C8
	[Token(Token = "0x60010A8")]
	[Address(RVA = "0x2CCEB3C", Offset = "0x2CCEB3C", VA = "0x2CCEB3C")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)17560;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17217;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.ࠕ\u0828\u06DAց(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010A9 RID: 4265 RVA: 0x00062234 File Offset: 0x00060434
	[Token(Token = "0x60010A9")]
	[Address(RVA = "0x2CCEC44", Offset = "0x2CCEC44", VA = "0x2CCEC44")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17036;
		}
		LavaManager ݽ_u085Dԁٿ3 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ3.ࠕ\u0828\u06DAց(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010AA RID: 4266 RVA: 0x0006229C File Offset: 0x0006049C
	[Token(Token = "0x60010AA")]
	[Address(RVA = "0x2CCED4C", Offset = "0x2CCED4C", VA = "0x2CCED4C")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)16384;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17232;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u0893Նխڭ(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010AB RID: 4267 RVA: 0x00062310 File Offset: 0x00060510
	[Token(Token = "0x60010AB")]
	[Address(RVA = "0x2CCEE5C", Offset = "0x2CCEE5C", VA = "0x2CCEE5C")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)40960;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17593;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.Ԧ\u083E\u0652۲(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010AC RID: 4268 RVA: 0x0006237C File Offset: 0x0006057C
	[Token(Token = "0x60010AC")]
	[Address(RVA = "0x2CCEF68", Offset = "0x2CCEF68", VA = "0x2CCEF68")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)8192;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17175;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010AD RID: 4269 RVA: 0x000623E8 File Offset: 0x000605E8
	[Token(Token = "0x60010AD")]
	[Address(RVA = "0x2CCF074", Offset = "0x2CCF074", VA = "0x2CCF074")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)16384;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17465;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u0893Նխڭ(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010AE RID: 4270 RVA: 0x0006245C File Offset: 0x0006065C
	[Token(Token = "0x60010AE")]
	[Address(RVA = "0x2CCF184", Offset = "0x2CCF184", VA = "0x2CCF184")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)32768;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17387;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.ࠕ\u0828\u06DAց(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010AF RID: 4271 RVA: 0x000624D0 File Offset: 0x000606D0
	[Token(Token = "0x60010AF")]
	[Address(RVA = "0x2CCF294", Offset = "0x2CCF294", VA = "0x2CCF294")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)40960;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)40960;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010B0 RID: 4272 RVA: 0x0006253C File Offset: 0x0006073C
	[Token(Token = "0x60010B0")]
	[Address(RVA = "0x2CCF3A4", Offset = "0x2CCF3A4", VA = "0x2CCF3A4")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)17196;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)32768;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u0893Նխڭ(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010B1 RID: 4273 RVA: 0x000625A8 File Offset: 0x000607A8
	[Token(Token = "0x60010B1")]
	[Address(RVA = "0x2CCF4B0", Offset = "0x2CCF4B0", VA = "0x2CCF4B0")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)17421;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)16736;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010B2 RID: 4274 RVA: 0x00062614 File Offset: 0x00060814
	[Token(Token = "0x60010B2")]
	[Address(RVA = "0x2CCF5B8", Offset = "0x2CCF5B8", VA = "0x2CCF5B8")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)17314;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17502;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u0893Նխڭ(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010B3 RID: 4275 RVA: 0x00062680 File Offset: 0x00060880
	[Token(Token = "0x60010B3")]
	[Address(RVA = "0x2CCF6C0", Offset = "0x2CCF6C0", VA = "0x2CCF6C0")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)24576;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)32768;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u0893Նխڭ(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010B4 RID: 4276 RVA: 0x000626EC File Offset: 0x000608EC
	[Token(Token = "0x60010B4")]
	[Address(RVA = "0x2CCF7D0", Offset = "0x2CCF7D0", VA = "0x2CCF7D0")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)17397;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)32768;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010B5 RID: 4277 RVA: 0x00062760 File Offset: 0x00060960
	[Token(Token = "0x60010B5")]
	[Address(RVA = "0x2CCF8E0", Offset = "0x2CCF8E0", VA = "0x2CCF8E0")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)49152;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)32768;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010B6 RID: 4278 RVA: 0x000627CC File Offset: 0x000609CC
	[Token(Token = "0x60010B6")]
	[Address(RVA = "0x2CCF9F0", Offset = "0x2CCF9F0", VA = "0x2CCF9F0")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)16896;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17440;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010B7 RID: 4279 RVA: 0x00062840 File Offset: 0x00060A40
	[Token(Token = "0x60010B7")]
	[Address(RVA = "0x2CCFAFC", Offset = "0x2CCFAFC", VA = "0x2CCFAFC")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)17307;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)8192;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010B8 RID: 4280 RVA: 0x000628B4 File Offset: 0x00060AB4
	[Token(Token = "0x60010B8")]
	[Address(RVA = "0x2CCFC0C", Offset = "0x2CCFC0C", VA = "0x2CCFC0C")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)17094;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)32768;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010B9 RID: 4281 RVA: 0x00062928 File Offset: 0x00060B28
	[Token(Token = "0x60010B9")]
	[Address(RVA = "0x2CCFD1C", Offset = "0x2CCFD1C", VA = "0x2CCFD1C")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)17640;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)16384;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.Ԧ\u083E\u0652۲(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010BA RID: 4282 RVA: 0x0006299C File Offset: 0x00060B9C
	[Token(Token = "0x60010BA")]
	[Address(RVA = "0x2CCFE2C", Offset = "0x2CCFE2C", VA = "0x2CCFE2C")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)16384;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)57344;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010BB RID: 4283 RVA: 0x00062A10 File Offset: 0x00060C10
	[Token(Token = "0x60010BB")]
	[Address(RVA = "0x2CCFF40", Offset = "0x2CCFF40", VA = "0x2CCFF40")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)17292;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17042;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.ࠕ\u0828\u06DAց(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010BC RID: 4284 RVA: 0x00062A7C File Offset: 0x00060C7C
	[Token(Token = "0x60010BC")]
	[Address(RVA = "0x2CD0048", Offset = "0x2CD0048", VA = "0x2CD0048")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)40960;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)49152;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u059FԽޅ\u07EF(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010BD RID: 4285 RVA: 0x00062AE8 File Offset: 0x00060CE8
	[Token(Token = "0x60010BD")]
	[Address(RVA = "0x2CD0158", Offset = "0x2CD0158", VA = "0x2CD0158")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)8192;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)49152;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.ࠕ\u0828\u06DAց(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010BE RID: 4286 RVA: 0x00062B54 File Offset: 0x00060D54
	[Token(Token = "0x60010BE")]
	[Address(RVA = "0x2CD0268", Offset = "0x2CD0268", VA = "0x2CD0268")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)8192;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)32768;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.\u0893Նխڭ(ڧ_u0605Գ_u07F);
	}

	// Token: 0x060010BF RID: 4287 RVA: 0x00062BC8 File Offset: 0x00060DC8
	[Token(Token = "0x60010BF")]
	[Address(RVA = "0x2CD037C", Offset = "0x2CD037C", VA = "0x2CD037C")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0879ڠܠӀ)
		{
			LavaManager ݽ_u085Dԁٿ = this.ݽ\u085Dԁٿ;
			long ҽ_u082EهԀ = 1L;
			ݽ_u085Dԁٿ.Ҽ\u082EهԀ = (ҽ_u082EهԀ != 0L);
			this.ݽ\u085Dԁٿ.\u0746Ԟࡕߩ.z = (float)49152;
			this.ݽ\u085Dԁٿ.\u064E\u06DFࡘվ = (float)17519;
		}
		LavaManager ݽ_u085Dԁٿ2 = this.ݽ\u085Dԁٿ;
		bool ڧ_u0605Գ_u07F = this.ڧ\u0605Գ\u07F6;
		ݽ_u085Dԁٿ2.ࠕ\u0828\u06DAց(ڧ_u0605Գ_u07F);
	}

	// Token: 0x0400023C RID: 572
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400023C")]
	public LavaManager ݽ\u085Dԁٿ;

	// Token: 0x0400023D RID: 573
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400023D")]
	private bool ڧ\u0605Գ\u07F6;

	// Token: 0x0400023E RID: 574
	[FieldOffset(Offset = "0x21")]
	[Token(Token = "0x400023E")]
	public bool \u0879ڠܠӀ;
}
