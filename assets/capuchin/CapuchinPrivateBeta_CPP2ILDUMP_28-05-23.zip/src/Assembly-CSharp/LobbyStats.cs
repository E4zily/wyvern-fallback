﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;

// Token: 0x02000073 RID: 115
[Token(Token = "0x2000073")]
public class LobbyStats : MonoBehaviourPunCallbacks
{
	// Token: 0x06001124 RID: 4388 RVA: 0x00063FD4 File Offset: 0x000621D4
	[Token(Token = "0x6001124")]
	[Address(RVA = "0x2CDC1DC", Offset = "0x2CDC1DC", VA = "0x2CDC1DC")]
	public void ہ\u0746\u05FCߏ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
	}

	// Token: 0x06001125 RID: 4389 RVA: 0x00064008 File Offset: 0x00062208
	[Token(Token = "0x6001125")]
	[Address(RVA = "0x2CDC274", Offset = "0x2CDC274", VA = "0x2CDC274")]
	public void יԠ\u07EDԺ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "ErrorScreen" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "You have been banned for " + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "Players: " + name;
	}

	// Token: 0x06001126 RID: 4390 RVA: 0x000640E0 File Offset: 0x000622E0
	[Token(Token = "0x6001126")]
	[Address(RVA = "0x2CDC534", Offset = "0x2CDC534", VA = "0x2CDC534")]
	public void \u0891\u0618Զޠ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "TurnAmount" + ܩݟ_u0883۱;
	}

	// Token: 0x06001127 RID: 4391 RVA: 0x00064134 File Offset: 0x00062334
	[Token(Token = "0x6001127")]
	[Address(RVA = "0x2CDC5CC", Offset = "0x2CDC5CC", VA = "0x2CDC5CC")]
	public void ى߁ٱՏ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "_WobbleZ" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "_BaseMap" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "DISABLE" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "NetworkPlayer" + name;
	}

	// Token: 0x06001128 RID: 4392 RVA: 0x0006420C File Offset: 0x0006240C
	[Token(Token = "0x6001128")]
	[Address(RVA = "0x2CDC88C", Offset = "0x2CDC88C", VA = "0x2CDC88C")]
	public void \u07FE\u0882Զ\u066D()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "BLUTARG" + str;
		string str2;
		string text2 = "Not enough amount of currency" + str2;
		string str3;
		string text3 = "Name Changing Error. Error: " + str3;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "Start Gamemode" + name;
	}

	// Token: 0x06001129 RID: 4393 RVA: 0x00064294 File Offset: 0x00062494
	[Token(Token = "0x6001129")]
	[Address(RVA = "0x2CDCB40", Offset = "0x2CDCB40", VA = "0x2CDCB40")]
	public void ܫ\u070Fۃ\u07F2()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "typesOfTalk" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Start Gamemode" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Body" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "5BN" + name;
	}

	// Token: 0x0600112A RID: 4394 RVA: 0x0006435C File Offset: 0x0006255C
	[Token(Token = "0x600112A")]
	[Address(RVA = "0x2CDCE00", Offset = "0x2CDCE00", VA = "0x2CDCE00")]
	public void צ\u0874ڵ\u059A()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "got funky mone" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Hate Speech" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "FingerTip" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "Fire Stick Is Lighting..." + name;
	}

	// Token: 0x0600112B RID: 4395 RVA: 0x00064434 File Offset: 0x00062634
	[Token(Token = "0x600112B")]
	[Address(RVA = "0x2CDD0C0", Offset = "0x2CDD0C0", VA = "0x2CDD0C0")]
	public void Ҿࢹؼס()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "TurnAmount" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Agreed" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Tagging" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "Photon token acquired!" + name;
	}

	// Token: 0x0600112C RID: 4396 RVA: 0x0006450C File Offset: 0x0006270C
	[Token(Token = "0x600112C")]
	[Address(RVA = "0x2CDD380", Offset = "0x2CDD380", VA = "0x2CDD380")]
	public void \u05C4Խࡉہ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Tagged" + ܩݟ_u0883۱;
	}

	// Token: 0x0600112D RID: 4397 RVA: 0x00064560 File Offset: 0x00062760
	[Token(Token = "0x600112D")]
	[Address(RVA = "0x2CDD418", Offset = "0x2CDD418", VA = "0x2CDD418")]
	public void ߤ\u0819\u0589հ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "gameMode" + ܩݟ_u0883۱;
	}

	// Token: 0x0600112E RID: 4398 RVA: 0x000645B4 File Offset: 0x000627B4
	[Token(Token = "0x600112E")]
	[Address(RVA = "0x2CDD4B0", Offset = "0x2CDD4B0", VA = "0x2CDD4B0")]
	public void \u0816\u082B\u0888ԑ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Failed to login, please restart" + ܩݟ_u0883۱;
	}

	// Token: 0x0600112F RID: 4399 RVA: 0x00064608 File Offset: 0x00062808
	[Token(Token = "0x600112F")]
	[Address(RVA = "0x2CDD548", Offset = "0x2CDD548", VA = "0x2CDD548")]
	public void ڧځܗߞ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Vertical" + ܩݟ_u0883۱;
	}

	// Token: 0x06001130 RID: 4400 RVA: 0x0006465C File Offset: 0x0006285C
	[Token(Token = "0x6001130")]
	[Address(RVA = "0x2CDD5E0", Offset = "0x2CDD5E0", VA = "0x2CDD5E0")]
	public void \u089F\u085Fէ\u059A()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "next" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "gameMode" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "ChangePlayerSize" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "User has been reported for: " + name;
	}

	// Token: 0x06001131 RID: 4401 RVA: 0x00064734 File Offset: 0x00062934
	[Token(Token = "0x6001131")]
	[Address(RVA = "0x2CDD8A0", Offset = "0x2CDD8A0", VA = "0x2CDD8A0")]
	public void ӽԾԗ\u0872()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "hh:mmtt" + ܩݟ_u0883۱;
	}

	// Token: 0x06001132 RID: 4402 RVA: 0x00064788 File Offset: 0x00062988
	[Token(Token = "0x6001132")]
	[Address(RVA = "0x2CDD938", Offset = "0x2CDD938", VA = "0x2CDD938")]
	public void ӅӲݣ\u05C0()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "PURCHASED" + ܩݟ_u0883۱;
	}

	// Token: 0x06001133 RID: 4403 RVA: 0x000647DC File Offset: 0x000629DC
	[Token(Token = "0x6001133")]
	[Address(RVA = "0x2CDD9D0", Offset = "0x2CDD9D0", VA = "0x2CDD9D0")]
	public void ׯԗߢ\u058E()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "PlayerHead" + ܩݟ_u0883۱;
	}

	// Token: 0x06001134 RID: 4404 RVA: 0x00064830 File Offset: 0x00062A30
	[Token(Token = "0x6001134")]
	[Address(RVA = "0x2CDDA68", Offset = "0x2CDDA68", VA = "0x2CDDA68")]
	public void Ӌ\u089C\u0700ܧ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "Song Index: " + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Joined a Room." + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "A new Player joined a Room." + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = ". Please update you game to the latest version" + name;
	}

	// Token: 0x06001135 RID: 4405 RVA: 0x00064908 File Offset: 0x00062B08
	[Token(Token = "0x6001135")]
	[Address(RVA = "0x2CDDD28", Offset = "0x2CDDD28", VA = "0x2CDDD28")]
	public void ޜ\u059A\u073D\u05BE()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "True" + ܩݟ_u0883۱;
	}

	// Token: 0x06001136 RID: 4406 RVA: 0x0006495C File Offset: 0x00062B5C
	[Token(Token = "0x6001136")]
	[Address(RVA = "0x2CDDDC0", Offset = "0x2CDDDC0", VA = "0x2CDDDC0")]
	public void ւࡂ\u0883\u0872()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "On" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Muted" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "containsStaff" + name;
	}

	// Token: 0x06001137 RID: 4407 RVA: 0x00064A34 File Offset: 0x00062C34
	[Token(Token = "0x6001137")]
	[Address(RVA = "0x2CDE080", Offset = "0x2CDE080", VA = "0x2CDE080")]
	public void \u070A\u06E8ࡐӐ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Open" + ܩݟ_u0883۱;
	}

	// Token: 0x06001138 RID: 4408 RVA: 0x00064A88 File Offset: 0x00062C88
	[Token(Token = "0x6001138")]
	[Address(RVA = "0x2CDE118", Offset = "0x2CDE118", VA = "0x2CDE118")]
	public void \u060B\u0614\u0821ע()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "Hats" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Cheating" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "true" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "You are not the master of the server, you cannot start the game." + name;
	}

	// Token: 0x06001139 RID: 4409 RVA: 0x00064B60 File Offset: 0x00062D60
	[Token(Token = "0x6001139")]
	[Address(RVA = "0x2CDE3D8", Offset = "0x2CDE3D8", VA = "0x2CDE3D8")]
	public void \u061B\u05EEوۈ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "You struck apon an error. " + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "next" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string text4;
		string text3 = text4 + text4;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text5 = "Open" + name;
	}

	// Token: 0x0600113A RID: 4410 RVA: 0x00064C34 File Offset: 0x00062E34
	[Token(Token = "0x600113A")]
	[Address(RVA = "0x2CDE680", Offset = "0x2CDE680", VA = "0x2CDE680")]
	public void \u05F8ݑ\u06ECߞ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "Player" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Not connected to room" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "FingerTip" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "StartGamemode" + name;
	}

	// Token: 0x0600113B RID: 4411 RVA: 0x00064D0C File Offset: 0x00062F0C
	[Token(Token = "0x600113B")]
	[Address(RVA = "0x2CDE940", Offset = "0x2CDE940", VA = "0x2CDE940")]
	public void ١\u0740ݡߎ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = " hours. You were banned because of " + ܩݟ_u0883۱;
	}

	// Token: 0x0600113C RID: 4412 RVA: 0x00064D60 File Offset: 0x00062F60
	[Token(Token = "0x600113C")]
	[Address(RVA = "0x2CDE9D8", Offset = "0x2CDE9D8", VA = "0x2CDE9D8")]
	public void ӻӒݝ߃()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "TurnAmount" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene." + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "_BumpMap" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "Player" + name;
	}

	// Token: 0x0600113D RID: 4413 RVA: 0x00064E38 File Offset: 0x00063038
	[Token(Token = "0x600113D")]
	[Address(RVA = "0x2CDEC98", Offset = "0x2CDEC98", VA = "0x2CDEC98")]
	public void ݩ\u0530ەࢴ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "ChangeToRegular" + ܩݟ_u0883۱;
	}

	// Token: 0x0600113E RID: 4414 RVA: 0x00064E8C File Offset: 0x0006308C
	[Token(Token = "0x600113E")]
	[Address(RVA = "0x2CDED30", Offset = "0x2CDED30", VA = "0x2CDED30")]
	public void ژךՈ\u0597()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "Start Gamemode" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "DisableCosmetic" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "PlayerHead" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "User is on an outdated version of Capuchin. Your version is " + name;
	}

	// Token: 0x0600113F RID: 4415 RVA: 0x00064F64 File Offset: 0x00063164
	[Token(Token = "0x600113F")]
	[Address(RVA = "0x2CDEFF0", Offset = "0x2CDEFF0", VA = "0x2CDEFF0")]
	public void גࡅչڷ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "FingerTip" + ܩݟ_u0883۱;
	}

	// Token: 0x06001140 RID: 4416 RVA: 0x00064FB8 File Offset: 0x000631B8
	[Token(Token = "0x6001140")]
	[Address(RVA = "0x2CDF088", Offset = "0x2CDF088", VA = "0x2CDF088")]
	public void ࢶ٠\u086D\u0708()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "FingerTip" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "QuickStatic" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Vector1_d371bd24217449349bd747533d51af6b" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "Room1" + name;
	}

	// Token: 0x06001141 RID: 4417 RVA: 0x00065090 File Offset: 0x00063290
	[Token(Token = "0x6001141")]
	[Address(RVA = "0x2CDF348", Offset = "0x2CDF348", VA = "0x2CDF348")]
	public void ܠڠ\u073C\u05EB()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = " and the correct version is " + ܩݟ_u0883۱;
	}

	// Token: 0x06001142 RID: 4418 RVA: 0x000650E4 File Offset: 0x000632E4
	[Token(Token = "0x6001142")]
	[Address(RVA = "0x2CDF3E0", Offset = "0x2CDF3E0", VA = "0x2CDF3E0")]
	public void ݛܯמݕ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "On" + ܩݟ_u0883۱;
	}

	// Token: 0x06001143 RID: 4419 RVA: 0x00065138 File Offset: 0x00063338
	[Token(Token = "0x6001143")]
	[Address(RVA = "0x2CDF478", Offset = "0x2CDF478", VA = "0x2CDF478")]
	public void \u0530\u07B3ݩݼ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "username" + ܩݟ_u0883۱;
	}

	// Token: 0x06001144 RID: 4420 RVA: 0x0006518C File Offset: 0x0006338C
	[Token(Token = "0x6001144")]
	[Address(RVA = "0x2CDF510", Offset = "0x2CDF510", VA = "0x2CDF510")]
	public void \u059B\u07B4\u0740ҿ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "isLava" + ܩݟ_u0883۱;
	}

	// Token: 0x06001145 RID: 4421 RVA: 0x000651E0 File Offset: 0x000633E0
	[Token(Token = "0x6001145")]
	[Address(RVA = "0x2CDF5A8", Offset = "0x2CDF5A8", VA = "0x2CDF5A8")]
	public void \u0881ݗӟ\u07BD()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "Bruh i cannot go here you stupid L bozo" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "PURCHASE" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Version" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "PlayerHead" + name;
	}

	// Token: 0x06001146 RID: 4422 RVA: 0x000652B8 File Offset: 0x000634B8
	[Token(Token = "0x6001146")]
	[Address(RVA = "0x2CDF868", Offset = "0x2CDF868", VA = "0x2CDF868")]
	public void \u061Fࡆ\u086F\u07B0()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "_BaseColor" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Player" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "HandR" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "EnableCosmetic" + name;
	}

	// Token: 0x06001147 RID: 4423 RVA: 0x00065390 File Offset: 0x00063590
	[Token(Token = "0x6001147")]
	[Address(RVA = "0x2CDFB1C", Offset = "0x2CDFB1C", VA = "0x2CDFB1C")]
	public void \u05C4ݳ\u05BCࡂ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "TurnAmount" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "MetaId" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Not connected to room" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "_Smoothness" + name;
	}

	// Token: 0x06001148 RID: 4424 RVA: 0x00065468 File Offset: 0x00063668
	[Token(Token = "0x6001148")]
	[Address(RVA = "0x2CDFDDC", Offset = "0x2CDFDDC", VA = "0x2CDFDDC")]
	public void \u0836\u089Dی\u0735()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "\n" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "username" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "DisableCosmetic" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "User has been reported for: " + name;
	}

	// Token: 0x06001149 RID: 4425 RVA: 0x00065540 File Offset: 0x00063740
	[Token(Token = "0x6001149")]
	[Address(RVA = "0x2CE009C", Offset = "0x2CE009C", VA = "0x2CE009C")]
	public void չۼձ\u0836()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "ErrorScreen" + ܩݟ_u0883۱;
	}

	// Token: 0x0600114A RID: 4426 RVA: 0x00065594 File Offset: 0x00063794
	[Token(Token = "0x600114A")]
	[Address(RVA = "0x2CE0134", Offset = "0x2CE0134", VA = "0x2CE0134")]
	public void كࡠԉی()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "token" + ܩݟ_u0883۱;
	}

	// Token: 0x0600114B RID: 4427 RVA: 0x000655E8 File Offset: 0x000637E8
	[Token(Token = "0x600114B")]
	[Address(RVA = "0x2CE01CC", Offset = "0x2CE01CC", VA = "0x2CE01CC")]
	public void \u055Cࢯܯ\u0898()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "Not connected to room" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "PlayerHead" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Try Connect To Server..." + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "BN" + name;
	}

	// Token: 0x0600114C RID: 4428 RVA: 0x000656C0 File Offset: 0x000638C0
	[Token(Token = "0x600114C")]
	[Address(RVA = "0x2CE0480", Offset = "0x2CE0480", VA = "0x2CE0480")]
	public void ں٢ࡡ\u05EC()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "PlayWave" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "run" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "CASUAL" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n" + name;
	}

	// Token: 0x0600114D RID: 4429 RVA: 0x00065798 File Offset: 0x00063998
	[Token(Token = "0x600114D")]
	[Address(RVA = "0x2CE0740", Offset = "0x2CE0740", VA = "0x2CE0740")]
	public void \u07BDއڸ\u0834()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "BN" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Name Changing Error. Error: " + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Start Gamemode" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "containsStaff" + name;
	}

	// Token: 0x0600114E RID: 4430 RVA: 0x00065870 File Offset: 0x00063A70
	[Token(Token = "0x600114E")]
	[Address(RVA = "0x2CE0A00", Offset = "0x2CE0A00", VA = "0x2CE0A00")]
	public void ڤ\u064C\u0748ݶ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "INSIGNIFICANT CURRENCY" + ܩݟ_u0883۱;
	}

	// Token: 0x0600114F RID: 4431 RVA: 0x000658C4 File Offset: 0x00063AC4
	[Token(Token = "0x600114F")]
	[Address(RVA = "0x2CE0A98", Offset = "0x2CE0A98", VA = "0x2CE0A98")]
	public void \u088Cލࠏخ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "gamemode" + ܩݟ_u0883۱;
	}

	// Token: 0x06001150 RID: 4432 RVA: 0x00065918 File Offset: 0x00063B18
	[Token(Token = "0x6001150")]
	[Address(RVA = "0x2CE0B30", Offset = "0x2CE0B30", VA = "0x2CE0B30")]
	public void ټݝݫۉ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Completed baking textures on frame " + ܩݟ_u0883۱;
	}

	// Token: 0x06001151 RID: 4433 RVA: 0x0006596C File Offset: 0x00063B6C
	[Token(Token = "0x6001151")]
	[Address(RVA = "0x2CE0BC8", Offset = "0x2CE0BC8", VA = "0x2CE0BC8")]
	public void ڐױ\u05F5ڗ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "FingerTip" + ܩݟ_u0883۱;
	}

	// Token: 0x06001152 RID: 4434 RVA: 0x000659C0 File Offset: 0x00063BC0
	[Token(Token = "0x6001152")]
	[Address(RVA = "0x2CE0C60", Offset = "0x2CE0C60", VA = "0x2CE0C60")]
	public void \u07BCӱӧӡ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "FingerTip" + ܩݟ_u0883۱;
	}

	// Token: 0x06001153 RID: 4435 RVA: 0x00065A14 File Offset: 0x00063C14
	[Token(Token = "0x6001153")]
	[Address(RVA = "0x2CE0CF8", Offset = "0x2CE0CF8", VA = "0x2CE0CF8")]
	public void Ӧ\u07FDջ\u07F3()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Update User Inventory" + ܩݟ_u0883۱;
	}

	// Token: 0x06001154 RID: 4436 RVA: 0x00065A68 File Offset: 0x00063C68
	[Token(Token = "0x6001154")]
	[Address(RVA = "0x2CE0D90", Offset = "0x2CE0D90", VA = "0x2CE0D90")]
	public void \u05B3ࢹߧ\u07AA()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "Updating Material to: " + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "username" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = " hours. You were banned because of " + name;
	}

	// Token: 0x06001155 RID: 4437 RVA: 0x00065B40 File Offset: 0x00063D40
	[Token(Token = "0x6001155")]
	[Address(RVA = "0x2CE1044", Offset = "0x2CE1044", VA = "0x2CE1044")]
	public void չւت\u061E()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "isLava" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "ENABLE" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Holdable" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "ErrorScreen" + name;
	}

	// Token: 0x06001156 RID: 4438 RVA: 0x00065C18 File Offset: 0x00063E18
	[Token(Token = "0x6001156")]
	[Address(RVA = "0x2CE1304", Offset = "0x2CE1304", VA = "0x2CE1304")]
	public void Ԉ۴ࡉࢬ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "PlayerHead" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Charging..." + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Start Gamemode" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		Room currentRoom = PhotonNetwork.CurrentRoom;
	}

	// Token: 0x06001157 RID: 4439 RVA: 0x00065CDC File Offset: 0x00063EDC
	[Token(Token = "0x6001157")]
	[Address(RVA = "0x2CE15C4", Offset = "0x2CE15C4", VA = "0x2CE15C4")]
	public void \u0892ܒܬޓ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Add/Remove Glasses" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "username" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "On" + name;
	}

	// Token: 0x06001158 RID: 4440 RVA: 0x00065DB4 File Offset: 0x00063FB4
	[Token(Token = "0x6001158")]
	[Address(RVA = "0x2CE186C", Offset = "0x2CE186C", VA = "0x2CE186C")]
	public void ࢨؤࡋԩ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "This is the 5000 Bananas button, and it was just clicked" + ܩݟ_u0883۱;
	}

	// Token: 0x06001159 RID: 4441 RVA: 0x00065E08 File Offset: 0x00064008
	[Token(Token = "0x6001159")]
	[Address(RVA = "0x2CE1904", Offset = "0x2CE1904", VA = "0x2CE1904")]
	public void \u07F5\u0657\u055Aߍ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "ChangeToRegular" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "containsStaff" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "containsStaff" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "username" + name;
	}

	// Token: 0x0600115A RID: 4442 RVA: 0x00065EE0 File Offset: 0x000640E0
	[Token(Token = "0x600115A")]
	[Address(RVA = "0x2CE1BB8", Offset = "0x2CE1BB8", VA = "0x2CE1BB8")]
	public void ہ\u0613ܢ\u07B4()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "You struck apon an error. " + ܩݟ_u0883۱;
	}

	// Token: 0x0600115B RID: 4443 RVA: 0x00065F34 File Offset: 0x00064134
	[Token(Token = "0x600115B")]
	[Address(RVA = "0x2CE1C50", Offset = "0x2CE1C50", VA = "0x2CE1C50")]
	public void \u07FBߑࢯڼ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Photon token acquired!" + ܩݟ_u0883۱;
	}

	// Token: 0x0600115C RID: 4444 RVA: 0x00065F88 File Offset: 0x00064188
	[Token(Token = "0x600115C")]
	[Address(RVA = "0x2CE1CE8", Offset = "0x2CE1CE8", VA = "0x2CE1CE8")]
	public void څࡣڐ\u0657()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "username" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "manual footTimings length should be equal to the leg count" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Tagged" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "isLava" + name;
	}

	// Token: 0x0600115D RID: 4445 RVA: 0x00066060 File Offset: 0x00064260
	[Token(Token = "0x600115D")]
	[Address(RVA = "0x2CE1F9C", Offset = "0x2CE1F9C", VA = "0x2CE1F9C")]
	public void \u05B9\u0881\u05C5ܕ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Trigger" + ܩݟ_u0883۱;
	}

	// Token: 0x0600115E RID: 4446 RVA: 0x000660B4 File Offset: 0x000642B4
	[Token(Token = "0x600115E")]
	[Address(RVA = "0x2CE2034", Offset = "0x2CE2034", VA = "0x2CE2034")]
	public void \u065FӁ\u0640ࡍ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Starting to bake textures on frame " + ܩݟ_u0883۱;
	}

	// Token: 0x0600115F RID: 4447 RVA: 0x00066108 File Offset: 0x00064308
	[Token(Token = "0x600115F")]
	[Address(RVA = "0x2CE20CC", Offset = "0x2CE20CC", VA = "0x2CE20CC")]
	public void \u0732ڙԒࢺ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "isLava" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "containsStaff" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text3 = "M/d/yyyy" + name;
	}

	// Token: 0x06001160 RID: 4448 RVA: 0x000661D0 File Offset: 0x000643D0
	[Token(Token = "0x6001160")]
	[Address(RVA = "0x2CE238C", Offset = "0x2CE238C", VA = "0x2CE238C")]
	public void \u0897\u0619ݨس()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "\tExpires: " + ܩݟ_u0883۱;
	}

	// Token: 0x06001161 RID: 4449 RVA: 0x00066224 File Offset: 0x00064424
	[Token(Token = "0x6001161")]
	[Address(RVA = "0x2CE2424", Offset = "0x2CE2424", VA = "0x2CE2424")]
	public void \u05C8ڭӷࡑ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "DisableCosmetic" + ܩݟ_u0883۱;
	}

	// Token: 0x06001162 RID: 4450 RVA: 0x00066278 File Offset: 0x00064478
	[Token(Token = "0x6001162")]
	[Address(RVA = "0x2CE24BC", Offset = "0x2CE24BC", VA = "0x2CE24BC")]
	public void \u0704٣\u088Fթ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "isLava" + ܩݟ_u0883۱;
	}

	// Token: 0x06001163 RID: 4451 RVA: 0x000662CC File Offset: 0x000644CC
	[Token(Token = "0x6001163")]
	[Address(RVA = "0x2CE2554", Offset = "0x2CE2554", VA = "0x2CE2554")]
	public void ࡉ\u086Eօه()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Muted" + ܩݟ_u0883۱;
	}

	// Token: 0x06001164 RID: 4452 RVA: 0x00066320 File Offset: 0x00064520
	[Token(Token = "0x6001164")]
	[Address(RVA = "0x2CE25EC", Offset = "0x2CE25EC", VA = "0x2CE25EC")]
	public LobbyStats()
	{
	}

	// Token: 0x06001165 RID: 4453 RVA: 0x00066334 File Offset: 0x00064534
	[Token(Token = "0x6001165")]
	[Address(RVA = "0x2CE25F4", Offset = "0x2CE25F4", VA = "0x2CE25F4")]
	public void ࢳޑհ\u088B()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 1L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Connected to Server." + ܩݟ_u0883۱;
	}

	// Token: 0x06001166 RID: 4454 RVA: 0x00066388 File Offset: 0x00064588
	[Token(Token = "0x6001166")]
	[Address(RVA = "0x2CE268C", Offset = "0x2CE268C", VA = "0x2CE268C")]
	public void \u05AEػ۴Ӑ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 0L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Count of rooms " + ܩݟ_u0883۱;
	}

	// Token: 0x06001167 RID: 4455 RVA: 0x000663DC File Offset: 0x000645DC
	[Token(Token = "0x6001167")]
	[Address(RVA = "0x2CE2724", Offset = "0x2CE2724", VA = "0x2CE2724")]
	public void ո\u07AA\u05BDࠕ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "hh:mmtt" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "You Already Own This Item" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Is Colliding" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = ". Please update you game to the latest version" + name;
	}

	// Token: 0x06001168 RID: 4456 RVA: 0x000664B4 File Offset: 0x000646B4
	[Token(Token = "0x6001168")]
	[Address(RVA = "0x2CE29E4", Offset = "0x2CE29E4", VA = "0x2CE29E4")]
	public void \u070Aәޣے()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "/" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "ENABLE" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Player" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "SetColor" + name;
	}

	// Token: 0x06001169 RID: 4457 RVA: 0x0006658C File Offset: 0x0006478C
	[Token(Token = "0x6001169")]
	[Address(RVA = "0x2CE2CA4", Offset = "0x2CE2CA4", VA = "0x2CE2CA4")]
	public void ފՖߢ\u059B()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "HorrorAgreement" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Vector1_d371bd24217449349bd747533d51af6b" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Player" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "username" + name;
	}

	// Token: 0x0600116A RID: 4458 RVA: 0x00066664 File Offset: 0x00064864
	[Token(Token = "0x600116A")]
	[Address(RVA = "0x2CE2F58", Offset = "0x2CE2F58", VA = "0x2CE2F58")]
	public void \u0872މࢮՃ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "DISABLE" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "username" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Completed baking textures on frame " + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "Reason: " + name;
	}

	// Token: 0x0600116B RID: 4459 RVA: 0x0006673C File Offset: 0x0006493C
	[Token(Token = "0x600116B")]
	[Address(RVA = "0x2CE320C", Offset = "0x2CE320C", VA = "0x2CE320C")]
	public void \u0870\u05B3Ց\u066A()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "containsStaff" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Vector1_d371bd24217449349bd747533d51af6b" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "containsStaff" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "ChangeToRegular" + name;
	}

	// Token: 0x0600116C RID: 4460 RVA: 0x00066814 File Offset: 0x00064A14
	[Token(Token = "0x600116C")]
	[Address(RVA = "0x2CE34C0", Offset = "0x2CE34C0", VA = "0x2CE34C0")]
	public void و\u0818\u082Cش()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "Charged!" + ܩݟ_u0883۱;
	}

	// Token: 0x0600116D RID: 4461 RVA: 0x00066868 File Offset: 0x00064A68
	[Token(Token = "0x600116D")]
	[Address(RVA = "0x2CE3558", Offset = "0x2CE3558", VA = "0x2CE3558")]
	public void \u0592ࡧӉڵ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "FingerTip" + ܩݟ_u0883۱;
	}

	// Token: 0x0600116E RID: 4462 RVA: 0x000668BC File Offset: 0x00064ABC
	[Token(Token = "0x600116E")]
	[Address(RVA = "0x2CE35F0", Offset = "0x2CE35F0", VA = "0x2CE35F0")]
	public void \u05EDց\u081Cت()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "Player" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "This is the 1000 Bananas button, and it was just clicked" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "EnableCosmetic" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "_WobbleX" + name;
	}

	// Token: 0x0600116F RID: 4463 RVA: 0x00066994 File Offset: 0x00064B94
	[Token(Token = "0x600116F")]
	[Address(RVA = "0x2CE389C", Offset = "0x2CE389C", VA = "0x2CE389C")]
	public void Update()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "Players Online: " + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Players In Room: " + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Count of rooms " + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "Room Name: " + name;
	}

	// Token: 0x06001170 RID: 4464 RVA: 0x00066A6C File Offset: 0x00064C6C
	[Token(Token = "0x6001170")]
	[Address(RVA = "0x2CE3B1C", Offset = "0x2CE3B1C", VA = "0x2CE3B1C")]
	public void ߑ\u0885\u05BBߕ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "PURCHASE" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Universal Render Pipeline/Lit" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "_Tint" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "BN" + name;
	}

	// Token: 0x06001171 RID: 4465 RVA: 0x00066B44 File Offset: 0x00064D44
	[Token(Token = "0x6001171")]
	[Address(RVA = "0x2CE3DDC", Offset = "0x2CE3DDC", VA = "0x2CE3DDC")]
	public void Ӧد\u060Eࡏ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "Not connected to room" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "Player" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "Diffuse" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "goDownRPC" + name;
	}

	// Token: 0x06001172 RID: 4466 RVA: 0x00066C1C File Offset: 0x00064E1C
	[Token(Token = "0x6001172")]
	[Address(RVA = "0x2CE409C", Offset = "0x2CE409C", VA = "0x2CE409C")]
	public void ۃ\u0594ߜӶ()
	{
		GameObject ԙڜߗ_u08B = this.ԙڜߗ\u08B5;
		long active = 0L;
		ԙڜߗ_u08B.SetActive(active != 0L);
		GameObject u059Cڲޔӥ = this.\u059Cڲޔӥ;
		long active2 = 1L;
		u059Cڲޔӥ.SetActive(active2 != 0L);
		TextMeshPro textMeshPro = this.ڹࢰիڛ;
		string ܩݟ_u0883۱ = this.ܩݟ\u0883۱;
		string text = "DISABLE" + ܩݟ_u0883۱;
	}

	// Token: 0x06001173 RID: 4467 RVA: 0x00066C70 File Offset: 0x00064E70
	[Token(Token = "0x6001173")]
	[Address(RVA = "0x2CE4134", Offset = "0x2CE4134", VA = "0x2CE4134")]
	public void \u05F7ԝߠӱ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num == 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.ۏ\u07BAغ\u06DE = countOfPlayersOnMaster;
		int countOfPlayers = PhotonNetwork.CountOfPlayers;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		string text = "PRESS AGAIN TO CONFIRM" + str;
		TextMeshPro textMeshPro = this.ڙپէב;
		string str2;
		string text2 = "username" + str2;
		TextMeshPro ض_u06DFձތ = this.ض\u06DFձތ;
		string str3;
		string text3 = "_Tint" + str3;
		TextMeshPro u06E6_u0598_u060Fݻ = this.\u06E6\u0598\u060Fݻ;
		string name = PhotonNetwork.CurrentRoom.name;
		string text4 = "This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n" + name;
	}

	// Token: 0x04000241 RID: 577
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000241")]
	public TextMeshPro \u05EDݻ\u05F3\u089A;

	// Token: 0x04000242 RID: 578
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000242")]
	public TextMeshPro ڙپէב;

	// Token: 0x04000243 RID: 579
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000243")]
	public TextMeshPro ض\u06DFձތ;

	// Token: 0x04000244 RID: 580
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000244")]
	public TextMeshPro \u06E6\u0598\u060Fݻ;

	// Token: 0x04000245 RID: 581
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000245")]
	public int ۏ\u07BAغ\u06DE;

	// Token: 0x04000246 RID: 582
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000246")]
	public int ࡋԓۉ\u0605;

	// Token: 0x04000247 RID: 583
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000247")]
	public int ߙٻۑ\u0605;

	// Token: 0x04000248 RID: 584
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000248")]
	public TextMeshPro ڹࢰիڛ;

	// Token: 0x04000249 RID: 585
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000249")]
	public string ܩݟ\u0883۱;

	// Token: 0x0400024A RID: 586
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400024A")]
	public GameObject \u059Cڲޔӥ;

	// Token: 0x0400024B RID: 587
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x400024B")]
	public GameObject ԙڜߗ\u08B5;
}
