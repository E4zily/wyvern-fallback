﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200008D RID: 141
[Token(Token = "0x200008D")]
public class PhysicsRig : MonoBehaviour
{
	// Token: 0x06001505 RID: 5381 RVA: 0x00075BC8 File Offset: 0x00073DC8
	[Token(Token = "0x6001505")]
	[Address(RVA = "0x2EB7758", Offset = "0x2EB7758", VA = "0x2EB7758")]
	private void ࢰחڵࡓ()
	{
	}

	// Token: 0x06001506 RID: 5382 RVA: 0x00075BD8 File Offset: 0x00073DD8
	[Token(Token = "0x6001506")]
	[Address(RVA = "0x2EB775C", Offset = "0x2EB775C", VA = "0x2EB775C")]
	private void ڍ\u058Bݗࡣ()
	{
	}

	// Token: 0x06001507 RID: 5383 RVA: 0x00075BE8 File Offset: 0x00073DE8
	[Token(Token = "0x6001507")]
	[Address(RVA = "0x2EB7760", Offset = "0x2EB7760", VA = "0x2EB7760")]
	private void \u089F\u085Fէ\u059A()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
	}

	// Token: 0x06001508 RID: 5384 RVA: 0x00075CE4 File Offset: 0x00073EE4
	[Token(Token = "0x6001508")]
	[Address(RVA = "0x2EB78FC", Offset = "0x2EB78FC", VA = "0x2EB78FC")]
	private void \u06E1ԁՈڄ()
	{
	}

	// Token: 0x06001509 RID: 5385 RVA: 0x00075CF4 File Offset: 0x00073EF4
	[Token(Token = "0x6001509")]
	[Address(RVA = "0x2EB7900", Offset = "0x2EB7900", VA = "0x2EB7900")]
	private void ڔӈӋڤ()
	{
	}

	// Token: 0x0600150A RID: 5386 RVA: 0x00075D04 File Offset: 0x00073F04
	[Token(Token = "0x600150A")]
	[Address(RVA = "0x2EB7904", Offset = "0x2EB7904", VA = "0x2EB7904")]
	private void \u07FAۯضߙ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x0600150B RID: 5387 RVA: 0x00075E00 File Offset: 0x00074000
	[Token(Token = "0x600150B")]
	[Address(RVA = "0x2EB7AA0", Offset = "0x2EB7AA0", VA = "0x2EB7AA0")]
	private void \u0595ժջܥ()
	{
	}

	// Token: 0x0600150C RID: 5388 RVA: 0x00075E10 File Offset: 0x00074010
	[Token(Token = "0x600150C")]
	[Address(RVA = "0x2EB7AA4", Offset = "0x2EB7AA4", VA = "0x2EB7AA4")]
	private void \u089Fױۄݩ()
	{
	}

	// Token: 0x0600150D RID: 5389 RVA: 0x00075E20 File Offset: 0x00074020
	[Token(Token = "0x600150D")]
	[Address(RVA = "0x2EB7AA8", Offset = "0x2EB7AA8", VA = "0x2EB7AA8")]
	private void \u05F8ݑ\u06ECߞ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation2 = transform4.localRotation;
	}

	// Token: 0x0600150E RID: 5390 RVA: 0x00075F1C File Offset: 0x0007411C
	[Token(Token = "0x600150E")]
	[Address(RVA = "0x2EB7C44", Offset = "0x2EB7C44", VA = "0x2EB7C44")]
	private void \u066B\u06DCݬࡖ()
	{
	}

	// Token: 0x0600150F RID: 5391 RVA: 0x00075F2C File Offset: 0x0007412C
	[Token(Token = "0x600150F")]
	[Address(RVA = "0x2EB7C48", Offset = "0x2EB7C48", VA = "0x2EB7C48")]
	private void ښمݷ\u0559()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001510 RID: 5392 RVA: 0x00076038 File Offset: 0x00074238
	[Token(Token = "0x6001510")]
	[Address(RVA = "0x2EB7DE4", Offset = "0x2EB7DE4", VA = "0x2EB7DE4")]
	private void Ճࠈޛݞ()
	{
	}

	// Token: 0x06001511 RID: 5393 RVA: 0x00076048 File Offset: 0x00074248
	[Token(Token = "0x6001511")]
	[Address(RVA = "0x2EB7DE8", Offset = "0x2EB7DE8", VA = "0x2EB7DE8")]
	private void ߇ܝܮ\u087F()
	{
	}

	// Token: 0x06001512 RID: 5394 RVA: 0x00076058 File Offset: 0x00074258
	[Token(Token = "0x6001512")]
	[Address(RVA = "0x2EB7DEC", Offset = "0x2EB7DEC", VA = "0x2EB7DEC")]
	private void \u07F7\u0651ӽ\u0557()
	{
	}

	// Token: 0x06001513 RID: 5395 RVA: 0x00076068 File Offset: 0x00074268
	[Token(Token = "0x6001513")]
	[Address(RVA = "0x2EB7DF0", Offset = "0x2EB7DF0", VA = "0x2EB7DF0")]
	private void \u081FڰՂإ()
	{
	}

	// Token: 0x06001514 RID: 5396 RVA: 0x00076078 File Offset: 0x00074278
	[Token(Token = "0x6001514")]
	[Address(RVA = "0x2EB7DF4", Offset = "0x2EB7DF4", VA = "0x2EB7DF4")]
	private void Start()
	{
	}

	// Token: 0x06001515 RID: 5397 RVA: 0x00076088 File Offset: 0x00074288
	[Token(Token = "0x6001515")]
	[Address(RVA = "0x2EB7DF8", Offset = "0x2EB7DF8", VA = "0x2EB7DF8")]
	private void ܤ\u05AE\u06DF\u05B9()
	{
	}

	// Token: 0x06001516 RID: 5398 RVA: 0x00076098 File Offset: 0x00074298
	[Token(Token = "0x6001516")]
	[Address(RVA = "0x2EB7DFC", Offset = "0x2EB7DFC", VA = "0x2EB7DFC")]
	private void بࠂռ\u05C6()
	{
	}

	// Token: 0x06001517 RID: 5399 RVA: 0x000760A8 File Offset: 0x000742A8
	[Token(Token = "0x6001517")]
	[Address(RVA = "0x2EB7E00", Offset = "0x2EB7E00", VA = "0x2EB7E00")]
	private void \u07F7ܙײ\u05B5()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001518 RID: 5400 RVA: 0x000761B4 File Offset: 0x000743B4
	[Token(Token = "0x6001518")]
	[Address(RVA = "0x2EB7F9C", Offset = "0x2EB7F9C", VA = "0x2EB7F9C")]
	private void حتݻ\u05B0()
	{
	}

	// Token: 0x06001519 RID: 5401 RVA: 0x000761C4 File Offset: 0x000743C4
	[Token(Token = "0x6001519")]
	[Address(RVA = "0x2EB7FA0", Offset = "0x2EB7FA0", VA = "0x2EB7FA0")]
	private void ߠ\u07AAߚթ()
	{
	}

	// Token: 0x0600151A RID: 5402 RVA: 0x000761D4 File Offset: 0x000743D4
	[Token(Token = "0x600151A")]
	[Address(RVA = "0x2EB7FA4", Offset = "0x2EB7FA4", VA = "0x2EB7FA4")]
	private void ؠࡒࢢԃ()
	{
	}

	// Token: 0x0600151B RID: 5403 RVA: 0x000761E4 File Offset: 0x000743E4
	[Token(Token = "0x600151B")]
	[Address(RVA = "0x2EB7FA8", Offset = "0x2EB7FA8", VA = "0x2EB7FA8")]
	private void \u05EDց\u081Cت()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = transform2.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x0600151C RID: 5404 RVA: 0x000762D8 File Offset: 0x000744D8
	[Token(Token = "0x600151C")]
	[Address(RVA = "0x2EB8144", Offset = "0x2EB8144", VA = "0x2EB8144")]
	private void إݩ\u0886ԟ()
	{
	}

	// Token: 0x0600151D RID: 5405 RVA: 0x000762E8 File Offset: 0x000744E8
	[Token(Token = "0x600151D")]
	[Address(RVA = "0x2EB8148", Offset = "0x2EB8148", VA = "0x2EB8148")]
	private void \u0827ߜ\u07FD\u07F4()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x0600151E RID: 5406 RVA: 0x000763F4 File Offset: 0x000745F4
	[Token(Token = "0x600151E")]
	[Address(RVA = "0x2EB82E4", Offset = "0x2EB82E4", VA = "0x2EB82E4")]
	private void ࢧӾڈց()
	{
	}

	// Token: 0x0600151F RID: 5407 RVA: 0x00076404 File Offset: 0x00074604
	[Token(Token = "0x600151F")]
	[Address(RVA = "0x2EB82E8", Offset = "0x2EB82E8", VA = "0x2EB82E8")]
	private void دז\u06EDճ()
	{
	}

	// Token: 0x06001520 RID: 5408 RVA: 0x00076414 File Offset: 0x00074614
	[Token(Token = "0x6001520")]
	[Address(RVA = "0x2EB82EC", Offset = "0x2EB82EC", VA = "0x2EB82EC")]
	private void \u0882צ\u0821\u05B4()
	{
	}

	// Token: 0x06001521 RID: 5409 RVA: 0x00076424 File Offset: 0x00074624
	[Token(Token = "0x6001521")]
	[Address(RVA = "0x2EB82F0", Offset = "0x2EB82F0", VA = "0x2EB82F0")]
	private void \u070Aәޣے()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001522 RID: 5410 RVA: 0x00076530 File Offset: 0x00074730
	[Token(Token = "0x6001522")]
	[Address(RVA = "0x2EB848C", Offset = "0x2EB848C", VA = "0x2EB848C")]
	private void نո\u0599\u0589()
	{
	}

	// Token: 0x06001523 RID: 5411 RVA: 0x00076540 File Offset: 0x00074740
	[Token(Token = "0x6001523")]
	[Address(RVA = "0x2EB8490", Offset = "0x2EB8490", VA = "0x2EB8490")]
	private void ӛ\u082Eؿڕ()
	{
	}

	// Token: 0x06001524 RID: 5412 RVA: 0x00076550 File Offset: 0x00074750
	[Token(Token = "0x6001524")]
	[Address(RVA = "0x2EB8494", Offset = "0x2EB8494", VA = "0x2EB8494")]
	private void Ӄ\u07BAࡌՅ()
	{
	}

	// Token: 0x06001525 RID: 5413 RVA: 0x00076560 File Offset: 0x00074760
	[Token(Token = "0x6001525")]
	[Address(RVA = "0x2EB8498", Offset = "0x2EB8498", VA = "0x2EB8498")]
	private void ٴݵۃ\u05AF()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001526 RID: 5414 RVA: 0x0007666C File Offset: 0x0007486C
	[Token(Token = "0x6001526")]
	[Address(RVA = "0x2EB8634", Offset = "0x2EB8634", VA = "0x2EB8634")]
	private void ڽ\u0894ىޡ()
	{
	}

	// Token: 0x06001527 RID: 5415 RVA: 0x0007667C File Offset: 0x0007487C
	[Token(Token = "0x6001527")]
	[Address(RVA = "0x2EB8638", Offset = "0x2EB8638", VA = "0x2EB8638")]
	private void ۋ\u060Fࡍم()
	{
	}

	// Token: 0x06001528 RID: 5416 RVA: 0x0007668C File Offset: 0x0007488C
	[Token(Token = "0x6001528")]
	[Address(RVA = "0x2EB863C", Offset = "0x2EB863C", VA = "0x2EB863C")]
	private void \u07B6կպ߃()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001529 RID: 5417 RVA: 0x00076798 File Offset: 0x00074998
	[Token(Token = "0x6001529")]
	[Address(RVA = "0x2EB87D8", Offset = "0x2EB87D8", VA = "0x2EB87D8")]
	private void ݜ\u061E\u082F\u0875()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x0600152A RID: 5418 RVA: 0x000768A4 File Offset: 0x00074AA4
	[Token(Token = "0x600152A")]
	[Address(RVA = "0x2EB8974", Offset = "0x2EB8974", VA = "0x2EB8974")]
	private void ࢨػքߞ()
	{
	}

	// Token: 0x0600152B RID: 5419 RVA: 0x000768B4 File Offset: 0x00074AB4
	[Token(Token = "0x600152B")]
	[Address(RVA = "0x2EB8978", Offset = "0x2EB8978", VA = "0x2EB8978")]
	private void \u07A8Ӥթݠ()
	{
	}

	// Token: 0x0600152C RID: 5420 RVA: 0x000768C4 File Offset: 0x00074AC4
	[Token(Token = "0x600152C")]
	[Address(RVA = "0x2EB897C", Offset = "0x2EB897C", VA = "0x2EB897C")]
	private void طӏܙࢺ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Vector3 localPosition7 = this.ٶج߇ټ.localPosition;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform3.localRotation;
	}

	// Token: 0x0600152D RID: 5421 RVA: 0x000769C4 File Offset: 0x00074BC4
	[Token(Token = "0x600152D")]
	[Address(RVA = "0x2EB8B18", Offset = "0x2EB8B18", VA = "0x2EB8B18")]
	private void \u05C1ޔӃ۸()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x0600152E RID: 5422 RVA: 0x00076AD0 File Offset: 0x00074CD0
	[Token(Token = "0x600152E")]
	[Address(RVA = "0x2EB8CB4", Offset = "0x2EB8CB4", VA = "0x2EB8CB4")]
	private void \u074A\u081B\u05FFԛ()
	{
	}

	// Token: 0x0600152F RID: 5423 RVA: 0x00076AE0 File Offset: 0x00074CE0
	[Token(Token = "0x600152F")]
	[Address(RVA = "0x2EB8CB8", Offset = "0x2EB8CB8", VA = "0x2EB8CB8")]
	private void ࡥշӞھ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001530 RID: 5424 RVA: 0x00076BEC File Offset: 0x00074DEC
	[Token(Token = "0x6001530")]
	[Address(RVA = "0x2EB8E54", Offset = "0x2EB8E54", VA = "0x2EB8E54")]
	private void ܙ\u06FEөࠕ()
	{
	}

	// Token: 0x06001531 RID: 5425 RVA: 0x00076BFC File Offset: 0x00074DFC
	[Token(Token = "0x6001531")]
	[Address(RVA = "0x2EB8E58", Offset = "0x2EB8E58", VA = "0x2EB8E58")]
	private void \u0870\u05B3Ց\u066A()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001532 RID: 5426 RVA: 0x00076D08 File Offset: 0x00074F08
	[Token(Token = "0x6001532")]
	[Address(RVA = "0x2EB8FF4", Offset = "0x2EB8FF4", VA = "0x2EB8FF4")]
	private void Ԯԇݯԃ()
	{
	}

	// Token: 0x06001533 RID: 5427 RVA: 0x00076D18 File Offset: 0x00074F18
	[Token(Token = "0x6001533")]
	[Address(RVA = "0x2EB8FF8", Offset = "0x2EB8FF8", VA = "0x2EB8FF8")]
	private void \u087Dܠ\u07FFӴ()
	{
	}

	// Token: 0x06001534 RID: 5428 RVA: 0x00076D28 File Offset: 0x00074F28
	[Token(Token = "0x6001534")]
	[Address(RVA = "0x2EB8FFC", Offset = "0x2EB8FFC", VA = "0x2EB8FFC")]
	private void ࡕߕ\u0707ݩ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001535 RID: 5429 RVA: 0x00076E34 File Offset: 0x00075034
	[Token(Token = "0x6001535")]
	[Address(RVA = "0x2EB9198", Offset = "0x2EB9198", VA = "0x2EB9198")]
	private void \u066D\u05BDې߃()
	{
	}

	// Token: 0x06001536 RID: 5430 RVA: 0x00076E44 File Offset: 0x00075044
	[Token(Token = "0x6001536")]
	[Address(RVA = "0x2EB919C", Offset = "0x2EB919C", VA = "0x2EB919C")]
	private void ٧ؠԬט()
	{
	}

	// Token: 0x06001537 RID: 5431 RVA: 0x00076E54 File Offset: 0x00075054
	[Token(Token = "0x6001537")]
	[Address(RVA = "0x2EB91A0", Offset = "0x2EB91A0", VA = "0x2EB91A0")]
	private void \u0654ޛ\u07FAذ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition4 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition5 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition6 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001538 RID: 5432 RVA: 0x00076F54 File Offset: 0x00075154
	[Token(Token = "0x6001538")]
	[Address(RVA = "0x2EB933C", Offset = "0x2EB933C", VA = "0x2EB933C")]
	private void \u064Dۿ\u07BB\u05C0()
	{
	}

	// Token: 0x06001539 RID: 5433 RVA: 0x00076F64 File Offset: 0x00075164
	[Token(Token = "0x6001539")]
	[Address(RVA = "0x2EB9340", Offset = "0x2EB9340", VA = "0x2EB9340")]
	private void ߟߥࡉپ()
	{
	}

	// Token: 0x0600153A RID: 5434 RVA: 0x00076F74 File Offset: 0x00075174
	[Token(Token = "0x600153A")]
	[Address(RVA = "0x2EB9344", Offset = "0x2EB9344", VA = "0x2EB9344")]
	private void \u05AE\u0740ࡩڥ()
	{
	}

	// Token: 0x0600153B RID: 5435 RVA: 0x00076F84 File Offset: 0x00075184
	[Token(Token = "0x600153B")]
	[Address(RVA = "0x2EB9348", Offset = "0x2EB9348", VA = "0x2EB9348")]
	private void ࢶ٠\u086D\u0708()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x0600153C RID: 5436 RVA: 0x00077090 File Offset: 0x00075290
	[Token(Token = "0x600153C")]
	[Address(RVA = "0x2EB94E4", Offset = "0x2EB94E4", VA = "0x2EB94E4")]
	private void ռտܙߗ()
	{
	}

	// Token: 0x0600153D RID: 5437 RVA: 0x000770A0 File Offset: 0x000752A0
	[Token(Token = "0x600153D")]
	[Address(RVA = "0x2EB94E8", Offset = "0x2EB94E8", VA = "0x2EB94E8")]
	private void ւࢢدࠈ()
	{
	}

	// Token: 0x0600153E RID: 5438 RVA: 0x000770B0 File Offset: 0x000752B0
	[Token(Token = "0x600153E")]
	[Address(RVA = "0x2EB94EC", Offset = "0x2EB94EC", VA = "0x2EB94EC")]
	private void \u06FD\u070Fߩ\u0589()
	{
	}

	// Token: 0x0600153F RID: 5439 RVA: 0x000770C0 File Offset: 0x000752C0
	[Token(Token = "0x600153F")]
	[Address(RVA = "0x2EB94F0", Offset = "0x2EB94F0", VA = "0x2EB94F0")]
	private void LateUpdate()
	{
	}

	// Token: 0x06001540 RID: 5440 RVA: 0x000770D0 File Offset: 0x000752D0
	[Token(Token = "0x6001540")]
	[Address(RVA = "0x2EB94F4", Offset = "0x2EB94F4", VA = "0x2EB94F4")]
	private void \u0603\u0593\u05B3\u0886()
	{
	}

	// Token: 0x06001541 RID: 5441 RVA: 0x000770E0 File Offset: 0x000752E0
	[Token(Token = "0x6001541")]
	[Address(RVA = "0x2EB94F8", Offset = "0x2EB94F8", VA = "0x2EB94F8")]
	private void \u0706\u05CDߜح()
	{
	}

	// Token: 0x06001542 RID: 5442 RVA: 0x000770F0 File Offset: 0x000752F0
	[Token(Token = "0x6001542")]
	[Address(RVA = "0x2EB94FC", Offset = "0x2EB94FC", VA = "0x2EB94FC")]
	private void Ԁ\u05EB\u085Eՠ()
	{
	}

	// Token: 0x06001543 RID: 5443 RVA: 0x00077100 File Offset: 0x00075300
	[Token(Token = "0x6001543")]
	[Address(RVA = "0x2EB9500", Offset = "0x2EB9500", VA = "0x2EB9500")]
	private void ޒ\u0816Ӑ۱()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001544 RID: 5444 RVA: 0x0007720C File Offset: 0x0007540C
	[Token(Token = "0x6001544")]
	[Address(RVA = "0x2EB969C", Offset = "0x2EB969C", VA = "0x2EB969C")]
	private void קܥ\u061Dߧ()
	{
	}

	// Token: 0x06001545 RID: 5445 RVA: 0x0007721C File Offset: 0x0007541C
	[Token(Token = "0x6001545")]
	[Address(RVA = "0x2EB96A0", Offset = "0x2EB96A0", VA = "0x2EB96A0")]
	private void ֆؼࢹߖ()
	{
	}

	// Token: 0x06001546 RID: 5446 RVA: 0x0007722C File Offset: 0x0007542C
	[Token(Token = "0x6001546")]
	[Address(RVA = "0x2EB96A4", Offset = "0x2EB96A4", VA = "0x2EB96A4")]
	private void \u0886Ҽ\u058Dߛ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001547 RID: 5447 RVA: 0x00077338 File Offset: 0x00075538
	[Token(Token = "0x6001547")]
	[Address(RVA = "0x2EB9840", Offset = "0x2EB9840", VA = "0x2EB9840")]
	private void ߗࠊ\u05CAܝ()
	{
	}

	// Token: 0x06001548 RID: 5448 RVA: 0x00077348 File Offset: 0x00075548
	[Token(Token = "0x6001548")]
	[Address(RVA = "0x2EB9844", Offset = "0x2EB9844", VA = "0x2EB9844")]
	private void ߑ\u0885\u05BBߕ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001549 RID: 5449 RVA: 0x00077454 File Offset: 0x00075654
	[Token(Token = "0x6001549")]
	[Address(RVA = "0x2EB99E0", Offset = "0x2EB99E0", VA = "0x2EB99E0")]
	private void \u05B3ࢹߧ\u07AA()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x0600154A RID: 5450 RVA: 0x00077560 File Offset: 0x00075760
	[Token(Token = "0x600154A")]
	[Address(RVA = "0x2EB9B7C", Offset = "0x2EB9B7C", VA = "0x2EB9B7C")]
	private void ӹߞ\u081C߄()
	{
	}

	// Token: 0x0600154B RID: 5451 RVA: 0x00077570 File Offset: 0x00075770
	[Token(Token = "0x600154B")]
	[Address(RVA = "0x2EB9B80", Offset = "0x2EB9B80", VA = "0x2EB9B80")]
	private void ژךՈ\u0597()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x0600154C RID: 5452 RVA: 0x0007767C File Offset: 0x0007587C
	[Token(Token = "0x600154C")]
	[Address(RVA = "0x2EB9D1C", Offset = "0x2EB9D1C", VA = "0x2EB9D1C")]
	private void \u07F8ձݠߜ()
	{
	}

	// Token: 0x0600154D RID: 5453 RVA: 0x0007768C File Offset: 0x0007588C
	[Token(Token = "0x600154D")]
	[Address(RVA = "0x2EB9D20", Offset = "0x2EB9D20", VA = "0x2EB9D20")]
	private void ߉ې\u07F6Ӭ()
	{
	}

	// Token: 0x0600154E RID: 5454 RVA: 0x0007769C File Offset: 0x0007589C
	[Token(Token = "0x600154E")]
	[Address(RVA = "0x2EB9D24", Offset = "0x2EB9D24", VA = "0x2EB9D24")]
	private void ࢥ\u081CՕࡋ()
	{
	}

	// Token: 0x0600154F RID: 5455 RVA: 0x000776AC File Offset: 0x000758AC
	[Token(Token = "0x600154F")]
	[Address(RVA = "0x2EB9D28", Offset = "0x2EB9D28", VA = "0x2EB9D28")]
	private void ݘܕܗԣ()
	{
	}

	// Token: 0x06001550 RID: 5456 RVA: 0x000776BC File Offset: 0x000758BC
	[Token(Token = "0x6001550")]
	[Address(RVA = "0x2EB9D2C", Offset = "0x2EB9D2C", VA = "0x2EB9D2C")]
	private void \u089Aࡆժߏ()
	{
	}

	// Token: 0x06001551 RID: 5457 RVA: 0x000776CC File Offset: 0x000758CC
	[Token(Token = "0x6001551")]
	[Address(RVA = "0x2EB9D30", Offset = "0x2EB9D30", VA = "0x2EB9D30")]
	private void Ӧد\u060Eࡏ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001552 RID: 5458 RVA: 0x000777D8 File Offset: 0x000759D8
	[Token(Token = "0x6001552")]
	[Address(RVA = "0x2EB9ECC", Offset = "0x2EB9ECC", VA = "0x2EB9ECC")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
	}

	// Token: 0x06001553 RID: 5459 RVA: 0x000777E8 File Offset: 0x000759E8
	[Token(Token = "0x6001553")]
	[Address(RVA = "0x2EB9ED0", Offset = "0x2EB9ED0", VA = "0x2EB9ED0")]
	private void \u07B2\u0823ծݠ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition4 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition5 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition6 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001554 RID: 5460 RVA: 0x000778E8 File Offset: 0x00075AE8
	[Token(Token = "0x6001554")]
	[Address(RVA = "0x2EBA06C", Offset = "0x2EBA06C", VA = "0x2EBA06C")]
	private void \u055E\u0703\u0700ܠ()
	{
	}

	// Token: 0x06001555 RID: 5461 RVA: 0x000778F8 File Offset: 0x00075AF8
	[Token(Token = "0x6001555")]
	[Address(RVA = "0x2EBA070", Offset = "0x2EBA070", VA = "0x2EBA070")]
	private void նܒزԊ()
	{
	}

	// Token: 0x06001556 RID: 5462 RVA: 0x00077908 File Offset: 0x00075B08
	[Token(Token = "0x6001556")]
	[Address(RVA = "0x2EBA074", Offset = "0x2EBA074", VA = "0x2EBA074")]
	public PhysicsRig()
	{
	}

	// Token: 0x06001557 RID: 5463 RVA: 0x0007791C File Offset: 0x00075B1C
	[Token(Token = "0x6001557")]
	[Address(RVA = "0x2EBA088", Offset = "0x2EBA088", VA = "0x2EBA088")]
	private void \u05AC\u07F0\u07EEࡥ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001558 RID: 5464 RVA: 0x00077A28 File Offset: 0x00075C28
	[Token(Token = "0x6001558")]
	[Address(RVA = "0x2EBA224", Offset = "0x2EBA224", VA = "0x2EBA224")]
	private void ߖհݣ߀()
	{
	}

	// Token: 0x06001559 RID: 5465 RVA: 0x00077A38 File Offset: 0x00075C38
	[Token(Token = "0x6001559")]
	[Address(RVA = "0x2EBA228", Offset = "0x2EBA228", VA = "0x2EBA228")]
	private void הԥ\u05B5ݴ()
	{
	}

	// Token: 0x0600155A RID: 5466 RVA: 0x00077A48 File Offset: 0x00075C48
	[Token(Token = "0x600155A")]
	[Address(RVA = "0x2EBA22C", Offset = "0x2EBA22C", VA = "0x2EBA22C")]
	private void ޅࡡ\u07AB\u07B3()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Quaternion localRotation3 = this.ٶج߇ټ.localRotation;
	}

	// Token: 0x0600155B RID: 5467 RVA: 0x00077B40 File Offset: 0x00075D40
	[Token(Token = "0x600155B")]
	[Address(RVA = "0x2EBA3C8", Offset = "0x2EBA3C8", VA = "0x2EBA3C8")]
	private void \u058EԸس\u0819()
	{
	}

	// Token: 0x0600155C RID: 5468 RVA: 0x00077B50 File Offset: 0x00075D50
	[Token(Token = "0x600155C")]
	[Address(RVA = "0x2EBA3CC", Offset = "0x2EBA3CC", VA = "0x2EBA3CC")]
	private void \u0825ӆا\u07BE()
	{
	}

	// Token: 0x0600155D RID: 5469 RVA: 0x00077B60 File Offset: 0x00075D60
	[Token(Token = "0x600155D")]
	[Address(RVA = "0x2EBA3D0", Offset = "0x2EBA3D0", VA = "0x2EBA3D0")]
	private void װڎ\u064C\u085F()
	{
	}

	// Token: 0x0600155E RID: 5470 RVA: 0x00077B70 File Offset: 0x00075D70
	[Token(Token = "0x600155E")]
	[Address(RVA = "0x2EBA3D4", Offset = "0x2EBA3D4", VA = "0x2EBA3D4")]
	private void ӣՃ\u07FAԟ()
	{
	}

	// Token: 0x0600155F RID: 5471 RVA: 0x00077B80 File Offset: 0x00075D80
	[Token(Token = "0x600155F")]
	[Address(RVA = "0x2EBA3D8", Offset = "0x2EBA3D8", VA = "0x2EBA3D8")]
	private void \u07BDއڸ\u0834()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = u0870_u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001560 RID: 5472 RVA: 0x00077C88 File Offset: 0x00075E88
	[Token(Token = "0x6001560")]
	[Address(RVA = "0x2EBA574", Offset = "0x2EBA574", VA = "0x2EBA574")]
	private void Update()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Vector3 localPosition6 = this.ӓ\u0816\u089D\u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001561 RID: 5473 RVA: 0x00077D88 File Offset: 0x00075F88
	[Token(Token = "0x6001561")]
	[Address(RVA = "0x2EBA710", Offset = "0x2EBA710", VA = "0x2EBA710")]
	private void \u060AԨصݚ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001562 RID: 5474 RVA: 0x00077E94 File Offset: 0x00076094
	[Token(Token = "0x6001562")]
	[Address(RVA = "0x2EBA8AC", Offset = "0x2EBA8AC", VA = "0x2EBA8AC")]
	private void ڈՓ\u0652\u0871()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001563 RID: 5475 RVA: 0x00077FA0 File Offset: 0x000761A0
	[Token(Token = "0x6001563")]
	[Address(RVA = "0x2EBAA48", Offset = "0x2EBAA48", VA = "0x2EBAA48")]
	private void \u05A1ߡࡅࢮ()
	{
	}

	// Token: 0x06001564 RID: 5476 RVA: 0x00077FB0 File Offset: 0x000761B0
	[Token(Token = "0x6001564")]
	[Address(RVA = "0x2EBAA4C", Offset = "0x2EBAA4C", VA = "0x2EBAA4C")]
	private void ࡢض\u07ACנ()
	{
	}

	// Token: 0x06001565 RID: 5477 RVA: 0x00077FC0 File Offset: 0x000761C0
	[Token(Token = "0x6001565")]
	[Address(RVA = "0x2EBAA50", Offset = "0x2EBAA50", VA = "0x2EBAA50")]
	private void խۏ\u05FFڹ()
	{
	}

	// Token: 0x06001566 RID: 5478 RVA: 0x00077FD0 File Offset: 0x000761D0
	[Token(Token = "0x6001566")]
	[Address(RVA = "0x2EBAA54", Offset = "0x2EBAA54", VA = "0x2EBAA54")]
	private void ܫ\u070Fۃ\u07F2()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001567 RID: 5479 RVA: 0x000780DC File Offset: 0x000762DC
	[Token(Token = "0x6001567")]
	[Address(RVA = "0x2EBABF0", Offset = "0x2EBABF0", VA = "0x2EBABF0")]
	private void ӻӒݝ߃()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001568 RID: 5480 RVA: 0x000781E8 File Offset: 0x000763E8
	[Token(Token = "0x6001568")]
	[Address(RVA = "0x2EBAD8C", Offset = "0x2EBAD8C", VA = "0x2EBAD8C")]
	private void ۆڛߟ\u05A0()
	{
	}

	// Token: 0x06001569 RID: 5481 RVA: 0x000781F8 File Offset: 0x000763F8
	[Token(Token = "0x6001569")]
	[Address(RVA = "0x2EBAD90", Offset = "0x2EBAD90", VA = "0x2EBAD90")]
	private void Ջއٵյ()
	{
	}

	// Token: 0x0600156A RID: 5482 RVA: 0x00078208 File Offset: 0x00076408
	[Token(Token = "0x600156A")]
	[Address(RVA = "0x2EBAD94", Offset = "0x2EBAD94", VA = "0x2EBAD94")]
	private void \u0733ߜܣԻ()
	{
	}

	// Token: 0x0600156B RID: 5483 RVA: 0x00078218 File Offset: 0x00076418
	[Token(Token = "0x600156B")]
	[Address(RVA = "0x2EBAD98", Offset = "0x2EBAD98", VA = "0x2EBAD98")]
	private void ݠ\u07EBӁ\u0652()
	{
	}

	// Token: 0x0600156C RID: 5484 RVA: 0x00078228 File Offset: 0x00076428
	[Token(Token = "0x600156C")]
	[Address(RVA = "0x2EBAD9C", Offset = "0x2EBAD9C", VA = "0x2EBAD9C")]
	private void \u0704زք٥()
	{
	}

	// Token: 0x0600156D RID: 5485 RVA: 0x00078238 File Offset: 0x00076438
	[Token(Token = "0x600156D")]
	[Address(RVA = "0x2EBADA0", Offset = "0x2EBADA0", VA = "0x2EBADA0")]
	private void ڽة\u05EBԠ()
	{
	}

	// Token: 0x0600156E RID: 5486 RVA: 0x00078248 File Offset: 0x00076448
	[Token(Token = "0x600156E")]
	[Address(RVA = "0x2EBADA4", Offset = "0x2EBADA4", VA = "0x2EBADA4")]
	private void \u0599ږࠆ\u065F()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x0600156F RID: 5487 RVA: 0x00078354 File Offset: 0x00076554
	[Token(Token = "0x600156F")]
	[Address(RVA = "0x2EBAF40", Offset = "0x2EBAF40", VA = "0x2EBAF40")]
	private void \u05A5Ӽ\u0834ג()
	{
	}

	// Token: 0x06001570 RID: 5488 RVA: 0x00078364 File Offset: 0x00076564
	[Token(Token = "0x6001570")]
	[Address(RVA = "0x2EBAF44", Offset = "0x2EBAF44", VA = "0x2EBAF44")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition6 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001571 RID: 5489 RVA: 0x00078460 File Offset: 0x00076660
	[Token(Token = "0x6001571")]
	[Address(RVA = "0x2EBB0E0", Offset = "0x2EBB0E0", VA = "0x2EBB0E0")]
	private void \u073Fߗބݝ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition4 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition5 = ӓ_u0816_u089D_u061B.localPosition;
		Quaternion localRotation2 = this.ӓ\u0816\u089D\u061B.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition6 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001572 RID: 5490 RVA: 0x00078554 File Offset: 0x00076754
	[Token(Token = "0x6001572")]
	[Address(RVA = "0x2EBB27C", Offset = "0x2EBB27C", VA = "0x2EBB27C")]
	private void ԙضփӌ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition3 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition4 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001573 RID: 5491 RVA: 0x00078648 File Offset: 0x00076848
	[Token(Token = "0x6001573")]
	[Address(RVA = "0x2EBB418", Offset = "0x2EBB418", VA = "0x2EBB418")]
	private void \u081Cߌ\u0876Բ()
	{
	}

	// Token: 0x06001574 RID: 5492 RVA: 0x00078658 File Offset: 0x00076858
	[Token(Token = "0x6001574")]
	[Address(RVA = "0x2EBB41C", Offset = "0x2EBB41C", VA = "0x2EBB41C")]
	private void \u083Dܔةއ()
	{
	}

	// Token: 0x06001575 RID: 5493 RVA: 0x00078668 File Offset: 0x00076868
	[Token(Token = "0x6001575")]
	[Address(RVA = "0x2EBB420", Offset = "0x2EBB420", VA = "0x2EBB420")]
	private void ݫࢷࠃ\u0820()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001576 RID: 5494 RVA: 0x00078774 File Offset: 0x00076974
	[Token(Token = "0x6001576")]
	[Address(RVA = "0x2EBB5BC", Offset = "0x2EBB5BC", VA = "0x2EBB5BC")]
	private void \u066D߅ռ\u07F1()
	{
	}

	// Token: 0x06001577 RID: 5495 RVA: 0x00078784 File Offset: 0x00076984
	[Token(Token = "0x6001577")]
	[Address(RVA = "0x2EBB5C0", Offset = "0x2EBB5C0", VA = "0x2EBB5C0")]
	private void ࠌࢡࠕ۷()
	{
	}

	// Token: 0x06001578 RID: 5496 RVA: 0x00078794 File Offset: 0x00076994
	[Token(Token = "0x6001578")]
	[Address(RVA = "0x2EBB5C4", Offset = "0x2EBB5C4", VA = "0x2EBB5C4")]
	private void \u0590\u0882\u0883ࡦ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Vector3 localPosition7 = this.ٶج߇ټ.localPosition;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform3.localRotation;
	}

	// Token: 0x06001579 RID: 5497 RVA: 0x00078894 File Offset: 0x00076A94
	[Token(Token = "0x6001579")]
	[Address(RVA = "0x2EBB760", Offset = "0x2EBB760", VA = "0x2EBB760")]
	private void \u089Fށհ\u083F()
	{
	}

	// Token: 0x0600157A RID: 5498 RVA: 0x000788A4 File Offset: 0x00076AA4
	[Token(Token = "0x600157A")]
	[Address(RVA = "0x2EBB764", Offset = "0x2EBB764", VA = "0x2EBB764")]
	private void ٻӸ\u0818\u087A()
	{
	}

	// Token: 0x0600157B RID: 5499 RVA: 0x000788B4 File Offset: 0x00076AB4
	[Token(Token = "0x600157B")]
	[Address(RVA = "0x2EBB768", Offset = "0x2EBB768", VA = "0x2EBB768")]
	private void \u065F\u0839ܤ\u073C()
	{
	}

	// Token: 0x0600157C RID: 5500 RVA: 0x000788C4 File Offset: 0x00076AC4
	[Token(Token = "0x600157C")]
	[Address(RVA = "0x2EBB76C", Offset = "0x2EBB76C", VA = "0x2EBB76C")]
	private void ӷӛࠔ\u07AC()
	{
	}

	// Token: 0x0600157D RID: 5501 RVA: 0x000788D4 File Offset: 0x00076AD4
	[Token(Token = "0x600157D")]
	[Address(RVA = "0x2EBB770", Offset = "0x2EBB770", VA = "0x2EBB770")]
	private void ܕ\u0595\u07AEࠋ()
	{
	}

	// Token: 0x0600157E RID: 5502 RVA: 0x000788E4 File Offset: 0x00076AE4
	[Token(Token = "0x600157E")]
	[Address(RVA = "0x2EBB774", Offset = "0x2EBB774", VA = "0x2EBB774")]
	private void չւت\u061E()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x0600157F RID: 5503 RVA: 0x000789F0 File Offset: 0x00076BF0
	[Token(Token = "0x600157F")]
	[Address(RVA = "0x2EBB910", Offset = "0x2EBB910", VA = "0x2EBB910")]
	private void ڃݚ\u07ACՒ()
	{
	}

	// Token: 0x06001580 RID: 5504 RVA: 0x00078A00 File Offset: 0x00076C00
	[Token(Token = "0x6001580")]
	[Address(RVA = "0x2EBB914", Offset = "0x2EBB914", VA = "0x2EBB914")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001581 RID: 5505 RVA: 0x00078B0C File Offset: 0x00076D0C
	[Token(Token = "0x6001581")]
	[Address(RVA = "0x2EBBAB0", Offset = "0x2EBBAB0", VA = "0x2EBBAB0")]
	private void \u060B\u0614\u0821ע()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition4 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition5 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition6 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001582 RID: 5506 RVA: 0x00078C0C File Offset: 0x00076E0C
	[Token(Token = "0x6001582")]
	[Address(RVA = "0x2EBBC4C", Offset = "0x2EBBC4C", VA = "0x2EBBC4C")]
	private void \u086Bԍࡊڭ()
	{
	}

	// Token: 0x06001583 RID: 5507 RVA: 0x00078C1C File Offset: 0x00076E1C
	[Token(Token = "0x6001583")]
	[Address(RVA = "0x2EBBC50", Offset = "0x2EBBC50", VA = "0x2EBBC50")]
	private void ݸ\u082Bߗ\u05FD()
	{
		Vector3 localPosition = this.ٶج߇ټ.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		Transform transform = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform2 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform2.localPosition;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform3.localRotation;
	}

	// Token: 0x06001584 RID: 5508 RVA: 0x00078D18 File Offset: 0x00076F18
	[Token(Token = "0x6001584")]
	[Address(RVA = "0x2EBBDEC", Offset = "0x2EBBDEC", VA = "0x2EBBDEC")]
	private void ߊ\u066A\u05CFԉ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x06001585 RID: 5509 RVA: 0x00078E24 File Offset: 0x00077024
	[Token(Token = "0x6001585")]
	[Address(RVA = "0x2EBBF88", Offset = "0x2EBBF88", VA = "0x2EBBF88")]
	private void \u05F8ࡂࡧ\u07FA()
	{
	}

	// Token: 0x06001586 RID: 5510 RVA: 0x00078E34 File Offset: 0x00077034
	[Token(Token = "0x6001586")]
	[Address(RVA = "0x2EBBF8C", Offset = "0x2EBBF8C", VA = "0x2EBBF8C")]
	private void յߪؾՀ()
	{
		Transform transform = this.ٶج߇ټ;
		CapsuleCollider u0870_u061Eڢݳ = this.\u0870\u061Eڢݳ;
		Vector3 localPosition = transform.localPosition;
		float u0608طࠊ_u05B = this.\u0608طࠊ\u05B0;
		float num = this.عࢧՒڌ;
		float height;
		u0870_u061Eڢݳ.height = height;
		Transform transform2 = this.\u0870\u061Eڢݳ.transform;
		Vector3 localPosition2 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition3 = this.ٶج߇ټ.localPosition;
		Vector3 localPosition4 = this.ٶج߇ټ.localPosition;
		Transform ޒӇӥ_u07F = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A = this.و\u05AFӯ\u07A7;
		Vector3 localPosition5 = ޒӇӥ_u07F.localPosition;
		Transform ޒӇӥ_u07F2 = this.ޒӇӥ\u07F5;
		ConfigurableJoint و_u05AFӯ_u07A2 = this.و\u05AFӯ\u07A7;
		Quaternion localRotation = ޒӇӥ_u07F2.localRotation;
		Transform ӓ_u0816_u089D_u061B = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ = this.ܐ\u0889Թࢭ;
		Vector3 localPosition6 = ӓ_u0816_u089D_u061B.localPosition;
		Transform ӓ_u0816_u089D_u061B2 = this.ӓ\u0816\u089D\u061B;
		ConfigurableJoint ܐ_u0889Թࢭ2 = this.ܐ\u0889Թࢭ;
		Quaternion localRotation2 = ӓ_u0816_u089D_u061B2.localRotation;
		Transform transform3 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B = this.\u07F2ۅ\u0557\u05B8;
		Vector3 localPosition7 = transform3.localPosition;
		Transform transform4 = this.ٶج߇ټ;
		ConfigurableJoint u07F2ۅ_u0557_u05B2 = this.\u07F2ۅ\u0557\u05B8;
		Quaternion localRotation3 = transform4.localRotation;
	}

	// Token: 0x040002A2 RID: 674
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002A2")]
	public Transform ٶج߇ټ;

	// Token: 0x040002A3 RID: 675
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002A3")]
	public Transform ޒӇӥ\u07F5;

	// Token: 0x040002A4 RID: 676
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40002A4")]
	public Transform ӓ\u0816\u089D\u061B;

	// Token: 0x040002A5 RID: 677
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40002A5")]
	public ConfigurableJoint \u07F2ۅ\u0557\u05B8;

	// Token: 0x040002A6 RID: 678
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40002A6")]
	public ConfigurableJoint و\u05AFӯ\u07A7;

	// Token: 0x040002A7 RID: 679
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40002A7")]
	public ConfigurableJoint ܐ\u0889Թࢭ;

	// Token: 0x040002A8 RID: 680
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40002A8")]
	public CapsuleCollider \u0870\u061Eڢݳ;

	// Token: 0x040002A9 RID: 681
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40002A9")]
	public Transform ࠓղ\u05BBݨ;

	// Token: 0x040002AA RID: 682
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40002AA")]
	public float \u0608طࠊ\u05B0;

	// Token: 0x040002AB RID: 683
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x40002AB")]
	public float عࢧՒڌ;
}
