﻿using System;
using System.Collections;
using Cpp2IlInjected;
using DigitalOpus.MB.Core;
using UnityEngine;

// Token: 0x02000074 RID: 116
[Token(Token = "0x2000074")]
public class BakeTexturesAtRuntime : MonoBehaviour
{
	// Token: 0x06001174 RID: 4468 RVA: 0x00066D48 File Offset: 0x00064F48
	[Token(Token = "0x6001174")]
	[Address(RVA = "0x2A53934", Offset = "0x2A53934", VA = "0x2A53934")]
	private void ࡒ\u081Dց\u089A()
	{
		if (!true)
		{
		}
		Debug.Log("DISABLE");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Hats" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x06001175 RID: 4469 RVA: 0x00066DC0 File Offset: 0x00064FC0
	[Token(Token = "0x6001175")]
	[Address(RVA = "0x2A53B3C", Offset = "0x2A53B3C", VA = "0x2A53B3C")]
	private void ޢܝ\u0653\u07AE()
	{
		if (!true)
		{
		}
		Debug.Log("Calling success callback. baking meshes");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Completed baking textures on frame " + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x06001176 RID: 4470 RVA: 0x00066E38 File Offset: 0x00065038
	[Token(Token = "0x6001176")]
	[Address(RVA = "0x2A53D44", Offset = "0x2A53D44", VA = "0x2A53D44")]
	private void ٩ڕԧ\u066B()
	{
		if (!true)
		{
		}
		Debug.Log("isLava");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "DISABLE" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x06001177 RID: 4471 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001177")]
	[Address(RVA = "0x2A53F4C", Offset = "0x2A53F4C", VA = "0x2A53F4C")]
	private void ރࠄԧ٧()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001178 RID: 4472 RVA: 0x00066EB0 File Offset: 0x000650B0
	[Token(Token = "0x6001178")]
	[Address(RVA = "0x2A54154", Offset = "0x2A54154", VA = "0x2A54154")]
	private void ܛ\u066Bܤ\u05F5()
	{
		Debug.Log("User is on an outdated version of Capuchin. Your version is ");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "True" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x06001179 RID: 4473 RVA: 0x00066F28 File Offset: 0x00065128
	[Token(Token = "0x6001179")]
	[Address(RVA = "0x2A5435C", Offset = "0x2A5435C", VA = "0x2A5435C")]
	private void جےކ\u07EF()
	{
		if (!true)
		{
		}
		Debug.Log("_Smoothness");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "NormalWeather" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x0600117A RID: 4474 RVA: 0x00066FA0 File Offset: 0x000651A0
	[Token(Token = "0x600117A")]
	[Address(RVA = "0x2A54564", Offset = "0x2A54564", VA = "0x2A54564")]
	private void \u05BA\u0893ހՎ()
	{
		string str;
		string text = "Player" + str;
		if ("Player" == null)
		{
		}
		if ("Player" == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "NGNNoSound" + str2;
		if ("FingerTip" == null)
		{
		}
		Debug.Log(message);
		MB3_MeshBaker componentInChildren2 = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		GameObject gameObject = this.ࠔؼࡏݥ;
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600117B RID: 4475 RVA: 0x00067080 File Offset: 0x00065280
	[Token(Token = "0x600117B")]
	[Address(RVA = "0x2A54D1C", Offset = "0x2A54D1C", VA = "0x2A54D1C")]
	private void ڡࡔ\u086Dհ()
	{
		if (!true)
		{
		}
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "goUpRPC" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x0600117C RID: 4476 RVA: 0x000670F8 File Offset: 0x000652F8
	[Token(Token = "0x600117C")]
	[Address(RVA = "0x2A54C14", Offset = "0x2A54C14", VA = "0x2A54C14")]
	public string ߦ߄\u055Fࡃ()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "\n Time: ";
	}

	// Token: 0x0600117D RID: 4477 RVA: 0x0006711C File Offset: 0x0006531C
	[Token(Token = "0x600117D")]
	[Address(RVA = "0x2A54F24", Offset = "0x2A54F24", VA = "0x2A54F24")]
	public BakeTexturesAtRuntime()
	{
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ u0659_u0601_u07EDڂ = new MB3_TextureCombiner.\u0659\u0601\u07EDڂ();
		base..ctor();
	}

	// Token: 0x0600117E RID: 4478 RVA: 0x00067138 File Offset: 0x00065338
	[Token(Token = "0x600117E")]
	[Address(RVA = "0x2A54F94", Offset = "0x2A54F94", VA = "0x2A54F94")]
	private void ԗӣ\u07BAߩ()
	{
		string str;
		string text = "containsStaff" + str;
		if ("containsStaff" == null)
		{
		}
		if ("containsStaff" == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "ChangeMaterialToNormal" + str2;
		if ("BN" == null)
		{
		}
		Debug.Log(message);
		MB3_MeshBaker componentInChildren2 = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component2 = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600117F RID: 4479 RVA: 0x0006721C File Offset: 0x0006541C
	[Token(Token = "0x600117F")]
	[Address(RVA = "0x2A55760", Offset = "0x2A55760", VA = "0x2A55760")]
	private void ޘ\u087Dࢭ\u070B()
	{
		if (!true)
		{
		}
		Debug.Log("Player");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		GameObject gameObject = this.ࠔؼࡏݥ;
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		if (!ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834 || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		Debug.Log("Regular" + str);
	}

	// Token: 0x06001180 RID: 4480 RVA: 0x00067288 File Offset: 0x00065488
	[Token(Token = "0x6001180")]
	[Address(RVA = "0x2A55968", Offset = "0x2A55968", VA = "0x2A55968")]
	private void \u086Cߝߑࢱ()
	{
		if (!true)
		{
		}
		Debug.Log("NetworkPlayer");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "FingerTip" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x06001181 RID: 4481 RVA: 0x00067300 File Offset: 0x00065500
	[Token(Token = "0x6001181")]
	[Address(RVA = "0x2A55B70", Offset = "0x2A55B70", VA = "0x2A55B70")]
	private void Ӱי\u05AAڧ()
	{
		if (!true)
		{
		}
		Debug.Log("TurnAmount");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "SetColor" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x06001182 RID: 4482 RVA: 0x00067378 File Offset: 0x00065578
	[Token(Token = "0x6001182")]
	[Address(RVA = "0x2A55D78", Offset = "0x2A55D78", VA = "0x2A55D78")]
	private void Ӄۇރࡑ()
	{
		string str;
		string text = " hours. You were banned because of " + str;
		if (" hours. You were banned because of " == null)
		{
		}
		if (" hours. You were banned because of " == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "username" + str2;
		if ("Player" == null)
		{
		}
		Debug.Log(message);
		MB3_MeshBaker componentInChildren2 = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component2 = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001183 RID: 4483 RVA: 0x0006745C File Offset: 0x0006565C
	[Token(Token = "0x6001183")]
	[Address(RVA = "0x2A5652C", Offset = "0x2A5652C", VA = "0x2A5652C")]
	private void ӹԾ\u05CB\u05A5()
	{
		Debug.Log("CapuchinStore");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Player" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x06001184 RID: 4484 RVA: 0x000674D4 File Offset: 0x000656D4
	[Token(Token = "0x6001184")]
	[Address(RVA = "0x2A56734", Offset = "0x2A56734", VA = "0x2A56734")]
	private void \u064Bࢮ\u0589\u05FF()
	{
		string str;
		string text = "EnableCosmetic" + str;
		if ("EnableCosmetic" == null)
		{
		}
		if ("EnableCosmetic" == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "You are on an outdated version of Capuchin. Your version is " + str2;
		if ("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe." == null)
		{
		}
		Debug.Log(message);
		MB3_TextureBaker component2 = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001185 RID: 4485 RVA: 0x000675AC File Offset: 0x000657AC
	[Token(Token = "0x6001185")]
	[Address(RVA = "0x2A556D0", Offset = "0x2A556D0", VA = "0x2A556D0")]
	public string ܭࡐ\u086E\u07B4()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "Found Gameobject: ";
	}

	// Token: 0x06001186 RID: 4486 RVA: 0x000675D0 File Offset: 0x000657D0
	[Token(Token = "0x6001186")]
	[Address(RVA = "0x2A56DE4", Offset = "0x2A56DE4", VA = "0x2A56DE4")]
	public string ԓږڒٯ()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "trol";
	}

	// Token: 0x06001187 RID: 4487 RVA: 0x000675F4 File Offset: 0x000657F4
	[Token(Token = "0x6001187")]
	[Address(RVA = "0x2A56E74", Offset = "0x2A56E74", VA = "0x2A56E74")]
	public string \u082Eݎ\u0891է()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "Try Connect To Server...";
	}

	// Token: 0x06001188 RID: 4488 RVA: 0x00067618 File Offset: 0x00065818
	[Token(Token = "0x6001188")]
	[Address(RVA = "0x2A56F04", Offset = "0x2A56F04", VA = "0x2A56F04")]
	public string \u086B\u07F0یש()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "MetaAuth";
	}

	// Token: 0x06001189 RID: 4489 RVA: 0x0006763C File Offset: 0x0006583C
	[Token(Token = "0x6001189")]
	[Address(RVA = "0x2A54C8C", Offset = "0x2A54C8C", VA = "0x2A54C8C")]
	public string Ӝ\u0619ڙԴ()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "Player was caught cheating";
	}

	// Token: 0x0600118A RID: 4490 RVA: 0x00067660 File Offset: 0x00065860
	[Token(Token = "0x600118A")]
	[Address(RVA = "0x2A56F94", Offset = "0x2A56F94", VA = "0x2A56F94")]
	private void \u05B9ٷݔײ()
	{
		if (!true)
		{
		}
		Debug.Log("Failed to login, please restart");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Body" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x0600118B RID: 4491 RVA: 0x000676D8 File Offset: 0x000658D8
	[Token(Token = "0x600118B")]
	[Address(RVA = "0x2A5719C", Offset = "0x2A5719C", VA = "0x2A5719C")]
	private void ࡂڴ\u05C1\u064E()
	{
		string str;
		string text = "Charging..." + str;
		if ("Charging..." == null)
		{
		}
		if ("Charging..." == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "DisableCosmetic" + str2;
		if ("NoseAttachPoint" == null)
		{
		}
		Debug.Log(message);
		MB3_TextureBaker component2 = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600118C RID: 4492 RVA: 0x000677B0 File Offset: 0x000659B0
	[Token(Token = "0x600118C")]
	[Address(RVA = "0x2A578DC", Offset = "0x2A578DC", VA = "0x2A578DC")]
	private void Տ\u059Aڡڼ()
	{
		if (!true)
		{
		}
		Debug.Log("EnableCosmetic");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "FingerTip" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x0600118D RID: 4493 RVA: 0x00067828 File Offset: 0x00065A28
	[Token(Token = "0x600118D")]
	[Address(RVA = "0x2A57AE4", Offset = "0x2A57AE4", VA = "0x2A57AE4")]
	public string \u07EC\u06E4Ԗ\u05AA()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "TurnAmount";
	}

	// Token: 0x0600118E RID: 4494 RVA: 0x0006784C File Offset: 0x00065A4C
	[Token(Token = "0x600118E")]
	[Address(RVA = "0x2A57B74", Offset = "0x2A57B74", VA = "0x2A57B74")]
	public string ࢯֆࠈ\u0825()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "friend";
	}

	// Token: 0x0600118F RID: 4495 RVA: 0x00067870 File Offset: 0x00065A70
	[Token(Token = "0x600118F")]
	[Address(RVA = "0x2A57C04", Offset = "0x2A57C04", VA = "0x2A57C04")]
	private void ӟ\u0651ࡑࢰ()
	{
		if (!true)
		{
		}
		Debug.Log("sound play play");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "containsStaff" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x06001190 RID: 4496 RVA: 0x000678E8 File Offset: 0x00065AE8
	[Token(Token = "0x6001190")]
	[Address(RVA = "0x2A57E0C", Offset = "0x2A57E0C", VA = "0x2A57E0C")]
	private void ۵\u05EEߑچ()
	{
		string str;
		string text = "Player" + str;
		if ("Player" == null)
		{
		}
		if ("Player" == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "FingerTip" + str2;
		if ("Player was caught cheating" == null)
		{
		}
		Debug.Log(message);
		MB3_MeshBaker componentInChildren2 = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component2 = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001191 RID: 4497 RVA: 0x000679CC File Offset: 0x00065BCC
	[Token(Token = "0x6001191")]
	[Address(RVA = "0x2A584BC", Offset = "0x2A584BC", VA = "0x2A584BC")]
	private void ࢦߚԬސ()
	{
		if (!true)
		{
		}
		Debug.Log("isLava");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "character limit reached" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x06001192 RID: 4498 RVA: 0x00067A44 File Offset: 0x00065C44
	[Token(Token = "0x6001192")]
	[Address(RVA = "0x2A586C4", Offset = "0x2A586C4", VA = "0x2A586C4")]
	public string דڐ\u06EB\u0892()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "Left a room";
	}

	// Token: 0x06001193 RID: 4499 RVA: 0x00067A68 File Offset: 0x00065C68
	[Token(Token = "0x6001193")]
	[Address(RVA = "0x2A58754", Offset = "0x2A58754", VA = "0x2A58754")]
	private void ࠂ۰߂ࡏ()
	{
		if (!true)
		{
		}
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		if (!ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834 || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		Debug.Log("Adding " + str);
	}

	// Token: 0x06001194 RID: 4500 RVA: 0x00067AD8 File Offset: 0x00065CD8
	[Token(Token = "0x6001194")]
	[Address(RVA = "0x2A56428", Offset = "0x2A56428", VA = "0x2A56428")]
	public string ࠒ\u074B\u05BB\u0706()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "Diffuse";
	}

	// Token: 0x06001195 RID: 4501 RVA: 0x00067AFC File Offset: 0x00065CFC
	[Token(Token = "0x6001195")]
	[Address(RVA = "0x2A5895C", Offset = "0x2A5895C", VA = "0x2A5895C")]
	private void Օ\u0839\u07BAܤ()
	{
		Debug.Log("A new Player joined a Room.");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		if (!ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834 || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		Debug.Log("ErrorScreen" + str);
	}

	// Token: 0x06001196 RID: 4502 RVA: 0x00067B68 File Offset: 0x00065D68
	[Token(Token = "0x6001196")]
	[Address(RVA = "0x2A58B64", Offset = "0x2A58B64", VA = "0x2A58B64")]
	private void \u06ECޔ\u082Dࠓ()
	{
		if (!true)
		{
		}
		Debug.Log("Vertical");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Display Name Changed!" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x06001197 RID: 4503 RVA: 0x00067BE0 File Offset: 0x00065DE0
	[Token(Token = "0x6001197")]
	[Address(RVA = "0x2A58D6C", Offset = "0x2A58D6C", VA = "0x2A58D6C")]
	private void \u0859ؤԗԧ()
	{
		string str;
		string text = "ORGPORT" + str;
		if ("ORGPORT" == null)
		{
		}
		if ("ORGPORT" == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "" + str2;
		if ("\n" == null)
		{
		}
		Debug.Log(message);
		MB3_MeshBaker componentInChildren2 = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component2 = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06001198 RID: 4504 RVA: 0x00067CC4 File Offset: 0x00065EC4
	[Token(Token = "0x6001198")]
	[Address(RVA = "0x2A564B8", Offset = "0x2A564B8", VA = "0x2A564B8")]
	public string ࡧך\u07BDԕ()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "Player";
	}

	// Token: 0x06001199 RID: 4505 RVA: 0x00067CE8 File Offset: 0x00065EE8
	[Token(Token = "0x6001199")]
	[Address(RVA = "0x2A5784C", Offset = "0x2A5784C", VA = "0x2A5784C")]
	public string ݐ\u07F6ӘԵ()
	{
		/*
An exception occurred when decompiling this method (06001199)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.String BakeTexturesAtRuntime::ݐ߶ӘԵ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Ӂڵࠓ۰(var_1_07, call:Ӂڵࠓ۰(Աڨߴط::ِ׫ְՕ)); 	stloc:Ӂڵࠓ۰(var_3_0F, call:Ӂڵࠓ۰(Աڨߴط::ِ׫ְՕ)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600119A RID: 4506 RVA: 0x00067D04 File Offset: 0x00065F04
	[Token(Token = "0x600119A")]
	[Address(RVA = "0x2A5941C", Offset = "0x2A5941C", VA = "0x2A5941C")]
	public string ߃\u0743ٳӳ()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "TurnAmount";
	}

	// Token: 0x0600119B RID: 4507 RVA: 0x00067D28 File Offset: 0x00065F28
	[Token(Token = "0x600119B")]
	[Address(RVA = "0x2A594AC", Offset = "0x2A594AC", VA = "0x2A594AC")]
	public string ٸܚگ\u0658()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "ChangeToTagged";
	}

	// Token: 0x0600119C RID: 4508 RVA: 0x00067D4C File Offset: 0x00065F4C
	[Token(Token = "0x600119C")]
	[Address(RVA = "0x2A5953C", Offset = "0x2A5953C", VA = "0x2A5953C")]
	private void ࢷ\u089C\u0821\u05CF()
	{
		string str;
		string text = "Mesh" + str;
		if ("Mesh" == null)
		{
		}
		if ("Mesh" == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "Failed to login, please restart" + str2;
		if ("EnableCosmetic" == null)
		{
		}
		Debug.Log(message);
		MB3_MeshBaker componentInChildren2 = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component2 = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600119D RID: 4509 RVA: 0x00067E30 File Offset: 0x00066030
	[Token(Token = "0x600119D")]
	[Address(RVA = "0x2A59BEC", Offset = "0x2A59BEC", VA = "0x2A59BEC")]
	private void ڟԃڈق()
	{
		if (!true)
		{
		}
		Debug.Log("CapuchinRemade");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		if (!ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834 || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		Debug.Log("typesOfTalk" + str);
	}

	// Token: 0x0600119E RID: 4510 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600119E")]
	[Address(RVA = "0x2A59DF4", Offset = "0x2A59DF4", VA = "0x2A59DF4")]
	private void \u07AFࡓݣ\u06E9()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600119F RID: 4511 RVA: 0x00067EA0 File Offset: 0x000660A0
	[Token(Token = "0x600119F")]
	[Address(RVA = "0x2A5A534", Offset = "0x2A5A534", VA = "0x2A5A534")]
	private void \u0598ڂ\u088AՋ()
	{
		string str;
		string text = "Tagged" + str;
		if ("Tagged" == null)
		{
		}
		if ("Tagged" == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "Display Name Changed!" + str2;
		if ("{0} ({1})" == null)
		{
		}
		Debug.Log(message);
		MB3_MeshBaker componentInChildren2 = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component2 = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060011A0 RID: 4512 RVA: 0x00067F7C File Offset: 0x0006617C
	[Token(Token = "0x60011A0")]
	[Address(RVA = "0x2A5AC74", Offset = "0x2A5AC74", VA = "0x2A5AC74")]
	private void \u07F7\u05F6\u082Aࢰ()
	{
		if (!true)
		{
		}
		Debug.Log("spooky guy true");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "TurnAmount" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x060011A1 RID: 4513 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60011A1")]
	[Address(RVA = "0x2A5AE7C", Offset = "0x2A5AE7C", VA = "0x2A5AE7C")]
	private void ى\u05F4ڷ߉()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060011A2 RID: 4514 RVA: 0x00067FF4 File Offset: 0x000661F4
	[Token(Token = "0x60011A2")]
	[Address(RVA = "0x2A5B52C", Offset = "0x2A5B52C", VA = "0x2A5B52C")]
	private void Ժӻҿӽ()
	{
		if (!true)
		{
		}
		Debug.Log("FingerTip");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "closeToObject" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x060011A3 RID: 4515 RVA: 0x0006806C File Offset: 0x0006626C
	[Token(Token = "0x60011A3")]
	[Address(RVA = "0x2A5A4A4", Offset = "0x2A5A4A4", VA = "0x2A5A4A4")]
	public string \u0610۳\u06D9\u05FD()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.";
	}

	// Token: 0x060011A4 RID: 4516 RVA: 0x00068090 File Offset: 0x00066290
	[Token(Token = "0x60011A4")]
	[Address(RVA = "0x2A5B734", Offset = "0x2A5B734", VA = "0x2A5B734")]
	private void OnGUI()
	{
		string str;
		string text = "Time to bake textures: " + str;
		if ("Time to bake textures: " == null)
		{
		}
		if ("Time to bake textures: " == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		Debug.Log("Starting to bake textures on frame " + str2);
		MB3_MeshBaker componentInChildren2 = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component2 = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060011A5 RID: 4517 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60011A5")]
	[Address(RVA = "0x2A5BDE4", Offset = "0x2A5BDE4", VA = "0x2A5BDE4")]
	private void ߌڟ\u07EEҼ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060011A6 RID: 4518 RVA: 0x0006816C File Offset: 0x0006636C
	[Token(Token = "0x60011A6")]
	[Address(RVA = "0x2A5C494", Offset = "0x2A5C494", VA = "0x2A5C494")]
	private void ࡉࡡܡߕ()
	{
		string str;
		string text = " and the correct version is " + str;
		if (" and the correct version is " == null)
		{
		}
		if (" and the correct version is " == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB_AtlasesAndRects[] array = component.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "closeToObject" + str2;
		if (typeof(MB3_MeshCombinerSingle).TypeHandle == null)
		{
		}
		Debug.Log(message);
		MB3_MeshBaker componentInChildren2 = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component2 = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060011A7 RID: 4519 RVA: 0x00068250 File Offset: 0x00066450
	[Token(Token = "0x60011A7")]
	[Address(RVA = "0x2A55644", Offset = "0x2A55644", VA = "0x2A55644")]
	public string ۹\u07ED\u05B9ه()
	{
		if (Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ() != Աڨ\u07F4ط.Ӂڵࠓ۰.\u0741\u06ED\u05A0\u0747)
		{
			Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		}
		return "Version";
	}

	// Token: 0x060011A8 RID: 4520 RVA: 0x00068274 File Offset: 0x00066474
	[Token(Token = "0x60011A8")]
	[Address(RVA = "0x2A5CB28", Offset = "0x2A5CB28", VA = "0x2A5CB28")]
	private void ࢱټطӬ()
	{
		if (!true)
		{
		}
		Debug.Log("DISABLE");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Completed baking textures on frame " + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x060011A9 RID: 4521 RVA: 0x000682EC File Offset: 0x000664EC
	[Token(Token = "0x60011A9")]
	[Address(RVA = "0x2A5CD30", Offset = "0x2A5CD30", VA = "0x2A5CD30")]
	public string ӻ\u0749ձ\u087C()
	{
		if (Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ() != Աڨ\u07F4ط.Ӂڵࠓ۰.\u0741\u06ED\u05A0\u0747)
		{
			Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		}
		return "isLava";
	}

	// Token: 0x060011AA RID: 4522 RVA: 0x00068310 File Offset: 0x00066510
	[Token(Token = "0x60011AA")]
	[Address(RVA = "0x2A5CDBC", Offset = "0x2A5CDBC", VA = "0x2A5CDBC")]
	public string ࡖաڍڎ()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "Round end";
	}

	// Token: 0x060011AB RID: 4523 RVA: 0x00068334 File Offset: 0x00066534
	[Token(Token = "0x60011AB")]
	[Address(RVA = "0x2A5CE4C", Offset = "0x2A5CE4C", VA = "0x2A5CE4C")]
	private void Ԇڊٴ\u058F()
	{
		if (!true)
		{
		}
		Debug.Log("Faild To Add Winner Money: ");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Is Colliding" + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x060011AC RID: 4524 RVA: 0x000683AC File Offset: 0x000665AC
	[Token(Token = "0x60011AC")]
	[Address(RVA = "0x2A5D054", Offset = "0x2A5D054", VA = "0x2A5D054")]
	public string ࡒق\u07A7ࢨ()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "FingerTip";
	}

	// Token: 0x060011AD RID: 4525 RVA: 0x000683D0 File Offset: 0x000665D0
	[Token(Token = "0x60011AD")]
	[Address(RVA = "0x2A5D0E4", Offset = "0x2A5D0E4", VA = "0x2A5D0E4")]
	private void ջ\u089Fփࠄ()
	{
		if (!true)
		{
		}
		Debug.Log(".Please press the button if you would like to play alone");
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		bool u0655Հԓ_u = ޅࢶ_u05F3ܪ.\u0655Հԓ\u0834;
		if (!u0655Հԓ_u || ޅࢶ_u05F3ܪ.ݙ\u065Dӕ\u05C3)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Updating Material to: " + str;
		if (!u0655Հԓ_u)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x060011AE RID: 4526 RVA: 0x00068448 File Offset: 0x00066648
	[Token(Token = "0x60011AE")]
	[Address(RVA = "0x2A5D2EC", Offset = "0x2A5D2EC", VA = "0x2A5D2EC")]
	private void Ԩ\u058Eۉ\u0607()
	{
		string str;
		string text = "tutorialCheck" + str;
		if ("tutorialCheck" == null)
		{
		}
		if ("tutorialCheck" == null)
		{
		}
		MB3_MeshBaker componentInChildren = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		GameObject gameObject = this.ࠔؼࡏݥ;
		MB2_TextureBakeResults mb2_TextureBakeResults = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		Material material = new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		MB3_TextureBaker mb3_TextureBaker;
		MB_AtlasesAndRects[] array = mb3_TextureBaker.\u082Dߧپݟ();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "ChangeToTagged" + str2;
		if ("Player" == null)
		{
		}
		Debug.Log(message);
		MB3_MeshBaker componentInChildren2 = this.ࠔؼࡏݥ.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.ࠔؼࡏݥ.GetComponent<MB3_TextureBaker>();
		MB2_TextureBakeResults mb2_TextureBakeResults2 = ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		Material material2 = new Material(Shader.Find(name2));
		MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ_u05F3ܪ = this.ޅࢶ\u05F3ܪ;
		IEnumerator routine;
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060011AF RID: 4527 RVA: 0x00068534 File Offset: 0x00066734
	[Token(Token = "0x60011AF")]
	[Address(RVA = "0x2A5ABE4", Offset = "0x2A5ABE4", VA = "0x2A5ABE4")]
	public string ࢫ\u05A7\u05B4Ն()
	{
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰ = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		Աڨ\u07F4ط.Ӂڵࠓ۰ ӂڵࠓ۰2 = Աڨ\u07F4ط.\u0650\u05EB\u05B0Օ();
		return "isLava";
	}

	// Token: 0x0400024C RID: 588
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400024C")]
	public GameObject ࠔؼࡏݥ;

	// Token: 0x0400024D RID: 589
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400024D")]
	private float ࢸࠒױܜ;

	// Token: 0x0400024E RID: 590
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400024E")]
	private MB3_TextureCombiner.\u0659\u0601\u07EDڂ ޅࢶ\u05F3ܪ;
}
