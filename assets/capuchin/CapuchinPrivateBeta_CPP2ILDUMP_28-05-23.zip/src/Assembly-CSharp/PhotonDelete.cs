﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000D2 RID: 210
[Token(Token = "0x20000D2")]
public class PhotonDelete : MonoBehaviour
{
	// Token: 0x06001FF7 RID: 8183 RVA: 0x000A7560 File Offset: 0x000A5760
	[Token(Token = "0x6001FF7")]
	[Address(RVA = "0x2EB24EC", Offset = "0x2EB24EC", VA = "0x2EB24EC")]
	public PhotonDelete()
	{
	}

	// Token: 0x06001FF8 RID: 8184 RVA: 0x000A7574 File Offset: 0x000A5774
	[Token(Token = "0x6001FF8")]
	[Address(RVA = "0x2EB24F4", Offset = "0x2EB24F4", VA = "0x2EB24F4")]
	public void ܣ\u086E\u05CF\u06D8()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
	}

	// Token: 0x06001FF9 RID: 8185 RVA: 0x000A75A8 File Offset: 0x000A57A8
	[Token(Token = "0x6001FF9")]
	[Address(RVA = "0x2EB25D0", Offset = "0x2EB25D0", VA = "0x2EB25D0")]
	public void څࡣڐ\u0657()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001FFA RID: 8186 RVA: 0x000A75E4 File Offset: 0x000A57E4
	[Token(Token = "0x6001FFA")]
	[Address(RVA = "0x2EB26AC", Offset = "0x2EB26AC", VA = "0x2EB26AC")]
	public void \u05F7ԝߠӱ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001FFB RID: 8187 RVA: 0x000A7620 File Offset: 0x000A5820
	[Token(Token = "0x6001FFB")]
	[Address(RVA = "0x2EB2788", Offset = "0x2EB2788", VA = "0x2EB2788")]
	public void Update()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001FFC RID: 8188 RVA: 0x000A765C File Offset: 0x000A585C
	[Token(Token = "0x6001FFC")]
	[Address(RVA = "0x2EB285C", Offset = "0x2EB285C", VA = "0x2EB285C")]
	public void \u070Aәޣے()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001FFD RID: 8189 RVA: 0x000A7698 File Offset: 0x000A5898
	[Token(Token = "0x6001FFD")]
	[Address(RVA = "0x2EB2938", Offset = "0x2EB2938", VA = "0x2EB2938")]
	public void \u05EDց\u081Cت()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001FFE RID: 8190 RVA: 0x000A76D4 File Offset: 0x000A58D4
	[Token(Token = "0x6001FFE")]
	[Address(RVA = "0x2EB2A14", Offset = "0x2EB2A14", VA = "0x2EB2A14")]
	public void ފՖߢ\u059B()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001FFF RID: 8191 RVA: 0x000A7710 File Offset: 0x000A5910
	[Token(Token = "0x6001FFF")]
	[Address(RVA = "0x2EB2AF0", Offset = "0x2EB2AF0", VA = "0x2EB2AF0")]
	public void Ҿࢹؼס()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002000 RID: 8192 RVA: 0x000A774C File Offset: 0x000A594C
	[Token(Token = "0x6002000")]
	[Address(RVA = "0x2EB2BCC", Offset = "0x2EB2BCC", VA = "0x2EB2BCC")]
	public void ժ\u065Dԯࡘ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002001 RID: 8193 RVA: 0x000A7788 File Offset: 0x000A5988
	[Token(Token = "0x6002001")]
	[Address(RVA = "0x2EB2CA8", Offset = "0x2EB2CA8", VA = "0x2EB2CA8")]
	public void ԣԭՋࠏ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002002 RID: 8194 RVA: 0x000A77C4 File Offset: 0x000A59C4
	[Token(Token = "0x6002002")]
	[Address(RVA = "0x2EB2D84", Offset = "0x2EB2D84", VA = "0x2EB2D84")]
	public void Ӣ\u0592ߨׯ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002003 RID: 8195 RVA: 0x000A7800 File Offset: 0x000A5A00
	[Token(Token = "0x6002003")]
	[Address(RVA = "0x2EB2E60", Offset = "0x2EB2E60", VA = "0x2EB2E60")]
	public void \u0732ڙԒࢺ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002004 RID: 8196 RVA: 0x000A783C File Offset: 0x000A5A3C
	[Token(Token = "0x6002004")]
	[Address(RVA = "0x2EB2F3C", Offset = "0x2EB2F3C", VA = "0x2EB2F3C")]
	public void ԟ\u086Cޣ\u055E()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002005 RID: 8197 RVA: 0x000A7878 File Offset: 0x000A5A78
	[Token(Token = "0x6002005")]
	[Address(RVA = "0x2EB3018", Offset = "0x2EB3018", VA = "0x2EB3018")]
	public void \u0654ޛ\u07FAذ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002006 RID: 8198 RVA: 0x000A78B4 File Offset: 0x000A5AB4
	[Token(Token = "0x6002006")]
	[Address(RVA = "0x2EB30F4", Offset = "0x2EB30F4", VA = "0x2EB30F4")]
	public void ւࡂ\u0883\u0872()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002007 RID: 8199 RVA: 0x000A78F0 File Offset: 0x000A5AF0
	[Token(Token = "0x6002007")]
	[Address(RVA = "0x2EB31D0", Offset = "0x2EB31D0", VA = "0x2EB31D0")]
	public void \u061B\u05EEوۈ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002008 RID: 8200 RVA: 0x000A792C File Offset: 0x000A5B2C
	[Token(Token = "0x6002008")]
	[Address(RVA = "0x2EB32AC", Offset = "0x2EB32AC", VA = "0x2EB32AC")]
	public void \u0881ݗӟ\u07BD()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002009 RID: 8201 RVA: 0x000A7968 File Offset: 0x000A5B68
	[Token(Token = "0x6002009")]
	[Address(RVA = "0x2EB3388", Offset = "0x2EB3388", VA = "0x2EB3388")]
	public void ڑߒجވ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.ۉ٧\u082Bӵ = component;
		float num2 = this.ݶՈהՇ;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
	}

	// Token: 0x0400041B RID: 1051
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400041B")]
	private GameObject ۉ٧\u082Bӵ;

	// Token: 0x0400041C RID: 1052
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400041C")]
	public float ݶՈהՇ;
}
