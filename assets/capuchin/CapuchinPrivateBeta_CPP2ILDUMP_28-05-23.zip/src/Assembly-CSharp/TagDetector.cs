﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200000E RID: 14
[Token(Token = "0x200000E")]
public class TagDetector : MonoBehaviourPunCallbacks
{
	// Token: 0x060001F9 RID: 505 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60001F9")]
	[Address(RVA = "0x2862554", Offset = "0x2862554", VA = "0x2862554")]
	private void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001FA RID: 506 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60001FA")]
	[Address(RVA = "0x2862A78", Offset = "0x2862A78", VA = "0x2862A78")]
	private void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001FB RID: 507 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60001FB")]
	[Address(RVA = "0x2863074", Offset = "0x2863074", VA = "0x2863074")]
	private void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001FC RID: 508 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60001FC")]
	[Address(RVA = "0x2863660", Offset = "0x2863660", VA = "0x2863660")]
	private void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001FD RID: 509 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60001FD")]
	[Address(RVA = "0x2863C60", Offset = "0x2863C60", VA = "0x2863C60")]
	private void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001FE RID: 510 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60001FE")]
	[Address(RVA = "0x2864188", Offset = "0x2864188", VA = "0x2864188")]
	private void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001FF RID: 511 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60001FF")]
	[Address(RVA = "0x2864788", Offset = "0x2864788", VA = "0x2864788")]
	private void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000200 RID: 512 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000200")]
	[Address(RVA = "0x2864D84", Offset = "0x2864D84", VA = "0x2864D84")]
	private void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000201 RID: 513 RVA: 0x00010780 File Offset: 0x0000E980
	[Token(Token = "0x6000201")]
	[Address(RVA = "0x2865384", Offset = "0x2865384", VA = "0x2865384")]
	public TagDetector()
	{
	}

	// Token: 0x06000202 RID: 514 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000202")]
	[Address(RVA = "0x286538C", Offset = "0x286538C", VA = "0x286538C")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000203 RID: 515 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000203")]
	[Address(RVA = "0x286597C", Offset = "0x286597C", VA = "0x286597C")]
	private void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000204 RID: 516 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000204")]
	[Address(RVA = "0x2865F78", Offset = "0x2865F78", VA = "0x2865F78")]
	private void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000205 RID: 517 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000205")]
	[Address(RVA = "0x2866574", Offset = "0x2866574", VA = "0x2866574")]
	private void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000206 RID: 518 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000206")]
	[Address(RVA = "0x2866B70", Offset = "0x2866B70", VA = "0x2866B70")]
	private void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000207 RID: 519 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000207")]
	[Address(RVA = "0x286707C", Offset = "0x286707C", VA = "0x286707C")]
	private void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000208 RID: 520 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000208")]
	[Address(RVA = "0x286767C", Offset = "0x286767C", VA = "0x286767C")]
	private void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000209 RID: 521 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000209")]
	[Address(RVA = "0x2867BA4", Offset = "0x2867BA4", VA = "0x2867BA4")]
	private void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600020A RID: 522 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600020A")]
	[Address(RVA = "0x28681A4", Offset = "0x28681A4", VA = "0x28681A4")]
	private void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600020B RID: 523 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600020B")]
	[Address(RVA = "0x28687A0", Offset = "0x28687A0", VA = "0x28687A0")]
	private void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600020C RID: 524 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600020C")]
	[Address(RVA = "0x2868D9C", Offset = "0x2868D9C", VA = "0x2868D9C")]
	private void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0400003D RID: 61
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400003D")]
	public PhotonView \u06EBسىڙ;

	// Token: 0x0400003E RID: 62
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400003E")]
	public PhotonView \u07F5\u0838պ\u0875;

	// Token: 0x0400003F RID: 63
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400003F")]
	public TagManager ߤՏ\u0702\u06D7;
}
