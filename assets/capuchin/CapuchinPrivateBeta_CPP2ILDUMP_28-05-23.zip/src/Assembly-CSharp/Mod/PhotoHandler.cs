﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

namespace Mod
{
	// Token: 0x0200011F RID: 287
	[Token(Token = "0x200011F")]
	[AddComponentMenu("CameraPhoto/PhotoHandler/Screen Shot DEMO")]
	public class PhotoHandler : MonoBehaviour
	{
		// Token: 0x06002B98 RID: 11160 RVA: 0x00107A2C File Offset: 0x00105C2C
		[Token(Token = "0x6002B98")]
		[Address(RVA = "0x2EB2024", Offset = "0x2EB2024", VA = "0x2EB2024")]
		public void CaptureScreenShot()
		{
			Camera component = base.GetComponent<Camera>();
			this.cam = component;
			PhotoHandler.Resolution resolution = this.res;
		}

		// Token: 0x06002B99 RID: 11161 RVA: 0x00107B70 File Offset: 0x00105D70
		[Token(Token = "0x6002B99")]
		[Address(RVA = "0x2EB230C", Offset = "0x2EB230C", VA = "0x2EB230C")]
		private IEnumerator SendWebhook(string link, string messgae, byte[] photo)
		{
			long <>1__state;
			PhotoHandler.<SendWebhook>d__15 <SendWebhook>d__ = new PhotoHandler.<SendWebhook>d__15((int)<>1__state);
			<>1__state = 0L;
			<SendWebhook>d__.<>4__this = this;
			<SendWebhook>d__.link = link;
			<SendWebhook>d__.messgae = messgae;
			<SendWebhook>d__.photo = photo;
			throw new NullReferenceException();
		}

		// Token: 0x06002B9A RID: 11162 RVA: 0x00107BA8 File Offset: 0x00105DA8
		[Token(Token = "0x6002B9A")]
		[Address(RVA = "0x2EB23D0", Offset = "0x2EB23D0", VA = "0x2EB23D0")]
		private void Update()
		{
			float num = this.timer;
			this.previewCam.Render();
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x06002B9B RID: 11163 RVA: 0x00107BD8 File Offset: 0x00105DD8
		[Token(Token = "0x6002B9B")]
		[Address(RVA = "0x2EB2434", Offset = "0x2EB2434", VA = "0x2EB2434")]
		public PhotoHandler()
		{
			long num = 2L;
			this.res = (PhotoHandler.Resolution)num;
			this.webhooklink = "";
			this.Message = "New Photo!";
			this.FileName = "Photo";
			base..ctor();
		}

		// Token: 0x0400060C RID: 1548
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400060C")]
		public int captureWidth;

		// Token: 0x0400060D RID: 1549
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x400060D")]
		public int captureHeight;

		// Token: 0x0400060E RID: 1550
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400060E")]
		public PhotoHandler.Resolution res;

		// Token: 0x0400060F RID: 1551
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400060F")]
		public GameObject hideGameObject;

		// Token: 0x04000610 RID: 1552
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000610")]
		private Rect rect;

		// Token: 0x04000611 RID: 1553
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000611")]
		private RenderTexture renderTexture;

		// Token: 0x04000612 RID: 1554
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000612")]
		private Texture2D screenShot;

		// Token: 0x04000613 RID: 1555
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000613")]
		private Camera cam;

		// Token: 0x04000614 RID: 1556
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000614")]
		public string webhooklink;

		// Token: 0x04000615 RID: 1557
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x4000615")]
		public string Message;

		// Token: 0x04000616 RID: 1558
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x4000616")]
		public string FileName;

		// Token: 0x04000617 RID: 1559
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x4000617")]
		public Camera previewCam;

		// Token: 0x04000618 RID: 1560
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x4000618")]
		private float timer;

		// Token: 0x02000120 RID: 288
		[Token(Token = "0x2000120")]
		public enum Resolution
		{
			// Token: 0x0400061A RID: 1562
			[Token(Token = "0x400061A")]
			_480p,
			// Token: 0x0400061B RID: 1563
			[Token(Token = "0x400061B")]
			_720p,
			// Token: 0x0400061C RID: 1564
			[Token(Token = "0x400061C")]
			_1080p,
			// Token: 0x0400061D RID: 1565
			[Token(Token = "0x400061D")]
			_4k
		}
	}
}
