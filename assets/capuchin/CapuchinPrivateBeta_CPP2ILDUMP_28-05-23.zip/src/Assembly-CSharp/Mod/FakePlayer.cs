﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000123 RID: 291
	[Token(Token = "0x2000123")]
	public class FakePlayer : MonoBehaviour
	{
		// Token: 0x06002BA5 RID: 11173 RVA: 0x00107E38 File Offset: 0x00106038
		[Token(Token = "0x6002BA5")]
		[Address(RVA = "0x1D8AA8C", Offset = "0x1D8AA8C", VA = "0x1D8AA8C")]
		public void ChangeState()
		{
			GameObject networkManager = this.NetworkManager;
			if (this.enable)
			{
				long active = 1L;
				networkManager.SetActive(active != 0L);
				return;
			}
			long active2 = 0L;
			networkManager.SetActive(active2 != 0L);
		}

		// Token: 0x06002BA6 RID: 11174 RVA: 0x00107E70 File Offset: 0x00106070
		[Token(Token = "0x6002BA6")]
		[Address(RVA = "0x1D8AAC4", Offset = "0x1D8AAC4", VA = "0x1D8AAC4")]
		public FakePlayer()
		{
		}

		// Token: 0x04000627 RID: 1575
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000627")]
		public GameObject NetworkManager;

		// Token: 0x04000628 RID: 1576
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000628")]
		public bool enable;
	}
}
