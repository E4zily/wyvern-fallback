﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000122 RID: 290
	[Token(Token = "0x2000122")]
	public class PlayerList : MonoBehaviour
	{
		// Token: 0x06002BA3 RID: 11171 RVA: 0x00107DB4 File Offset: 0x00105FB4
		[Token(Token = "0x6002BA3")]
		[Address(RVA = "0x29A1FD0", Offset = "0x29A1FD0", VA = "0x29A1FD0")]
		private void Update()
		{
			if (!true)
			{
			}
			string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
		}

		// Token: 0x06002BA4 RID: 11172 RVA: 0x00107E24 File Offset: 0x00106024
		[Token(Token = "0x6002BA4")]
		[Address(RVA = "0x29A2208", Offset = "0x29A2208", VA = "0x29A2208")]
		public PlayerList()
		{
		}

		// Token: 0x04000625 RID: 1573
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000625")]
		public string[] usernames;

		// Token: 0x04000626 RID: 1574
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000626")]
		public TMP_Text displaySpot;
	}
}
