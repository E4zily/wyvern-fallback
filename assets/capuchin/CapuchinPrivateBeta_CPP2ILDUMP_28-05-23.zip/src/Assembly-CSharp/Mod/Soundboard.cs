﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

namespace Mod
{
	// Token: 0x0200012D RID: 301
	[Token(Token = "0x200012D")]
	public class Soundboard : MonoBehaviour
	{
		// Token: 0x06002BCD RID: 11213 RVA: 0x00108824 File Offset: 0x00106A24
		[Token(Token = "0x6002BCD")]
		[Address(RVA = "0x2F7888C", Offset = "0x2F7888C", VA = "0x2F7888C")]
		[PunRPC]
		public void PlaySound(int sound)
		{
			AudioClip[] array = this.sounds;
			AudioClip.PCMReaderCallback pcmreaderCallback = array.m_PCMReaderCallback;
			AudioSource audioSource = this.audioSource;
			AudioClip.PCMSetPositionCallback pcmsetPositionCallback = array.m_PCMSetPositionCallback;
		}

		// Token: 0x06002BCE RID: 11214 RVA: 0x0010885C File Offset: 0x00106A5C
		[Token(Token = "0x6002BCE")]
		[Address(RVA = "0x2F788D4", Offset = "0x2F788D4", VA = "0x2F788D4")]
		[PunRPC]
		public void Stop()
		{
			this.audioSource.Stop();
		}

		// Token: 0x06002BCF RID: 11215 RVA: 0x0010887C File Offset: 0x00106A7C
		[Token(Token = "0x6002BCF")]
		[Address(RVA = "0x2F788F0", Offset = "0x2F788F0", VA = "0x2F788F0")]
		public void remoteSound(int sound)
		{
			PhotonView photonView = this.view;
			object[] array = new object[1];
			if (typeof(int).TypeHandle == null || typeof(int).TypeHandle != null)
			{
				return;
			}
			throw new ArrayTypeMismatchException();
		}

		// Token: 0x06002BD0 RID: 11216 RVA: 0x001088B8 File Offset: 0x00106AB8
		[Token(Token = "0x6002BD0")]
		[Address(RVA = "0x2F789FC", Offset = "0x2F789FC", VA = "0x2F789FC")]
		public void remoteStop()
		{
			PhotonView photonView = this.view;
		}

		// Token: 0x06002BD1 RID: 11217 RVA: 0x001088D4 File Offset: 0x00106AD4
		[Token(Token = "0x6002BD1")]
		[Address(RVA = "0x2F78AFC", Offset = "0x2F78AFC", VA = "0x2F78AFC")]
		public Soundboard()
		{
		}

		// Token: 0x0400065D RID: 1629
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400065D")]
		public PhotonView view;

		// Token: 0x0400065E RID: 1630
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400065E")]
		public AudioClip[] sounds;

		// Token: 0x0400065F RID: 1631
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400065F")]
		public AudioSource audioSource;
	}
}
