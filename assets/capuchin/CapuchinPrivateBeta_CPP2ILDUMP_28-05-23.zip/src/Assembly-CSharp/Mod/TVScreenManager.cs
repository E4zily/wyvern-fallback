﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Video;

namespace Mod
{
	// Token: 0x0200012E RID: 302
	[Token(Token = "0x200012E")]
	public class TVScreenManager : MonoBehaviour
	{
		// Token: 0x06002BD2 RID: 11218 RVA: 0x001088E8 File Offset: 0x00106AE8
		[Token(Token = "0x6002BD2")]
		[Address(RVA = "0x2862168", Offset = "0x2862168", VA = "0x2862168")]
		public void ITSHAPPENINGBRO()
		{
			PhotonView photonView = this.PhotonView;
		}

		// Token: 0x06002BD3 RID: 11219 RVA: 0x00108904 File Offset: 0x00106B04
		[Token(Token = "0x6002BD3")]
		[Address(RVA = "0x2862268", Offset = "0x2862268", VA = "0x2862268")]
		private void Update()
		{
			if (this.levaemealone)
			{
				float num = this.timer;
				float deltaTime = Time.deltaTime;
			}
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool inRoom = PhotonNetwork.InRoom;
			if (this.debug)
			{
				this.ITSHAPPENINGBRO();
			}
			float num2 = this.timer;
		}

		// Token: 0x06002BD4 RID: 11220 RVA: 0x00108960 File Offset: 0x00106B60
		[Token(Token = "0x6002BD4")]
		[Address(RVA = "0x2862404", Offset = "0x2862404", VA = "0x2862404")]
		[PunRPC]
		public void BringTheTVDown()
		{
			GameObject gameObject = this.tv;
			long active = 1L;
			long num = 1L;
			gameObject.SetActive(active != 0L);
			Animator animator = this.Animator;
			long value = 1L;
			animator.SetBool("GoDown", value != 0L);
			GameObject gameObject2 = this.otherTVPart;
			this.levaemealone = (num != 0L);
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.otherotherTVPart;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
			this.VideoPlayer.Play();
		}

		// Token: 0x06002BD5 RID: 11221 RVA: 0x001089D8 File Offset: 0x00106BD8
		[Token(Token = "0x6002BD5")]
		[Address(RVA = "0x28624B4", Offset = "0x28624B4", VA = "0x28624B4")]
		[PunRPC]
		public void BringTVUp()
		{
			Animator animator = this.Animator;
			long value = 0L;
			animator.SetBool("GoDown", value != 0L);
			GameObject gameObject = this.otherTVPart;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.otherotherTVPart;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			this.VideoPlayer.Stop();
		}

		// Token: 0x06002BD6 RID: 11222 RVA: 0x00108A30 File Offset: 0x00106C30
		[Token(Token = "0x6002BD6")]
		[Address(RVA = "0x286254C", Offset = "0x286254C", VA = "0x286254C")]
		public TVScreenManager()
		{
		}

		// Token: 0x04000660 RID: 1632
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000660")]
		public Animator Animator;

		// Token: 0x04000661 RID: 1633
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000661")]
		public PhotonView PhotonView;

		// Token: 0x04000662 RID: 1634
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000662")]
		public VideoPlayer VideoPlayer;

		// Token: 0x04000663 RID: 1635
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000663")]
		public GameObject tv;

		// Token: 0x04000664 RID: 1636
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000664")]
		private bool levaemealone;

		// Token: 0x04000665 RID: 1637
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000665")]
		public GameObject otherTVPart;

		// Token: 0x04000666 RID: 1638
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000666")]
		public GameObject otherotherTVPart;

		// Token: 0x04000667 RID: 1639
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000667")]
		public float timer;

		// Token: 0x04000668 RID: 1640
		[FieldOffset(Offset = "0x54")]
		[Token(Token = "0x4000668")]
		public bool debug;
	}
}
