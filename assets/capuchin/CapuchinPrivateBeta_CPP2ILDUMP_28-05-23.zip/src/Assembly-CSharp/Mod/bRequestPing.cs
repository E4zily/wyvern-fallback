﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000131 RID: 305
	[Token(Token = "0x2000131")]
	public class bRequestPing : MonoBehaviour
	{
		// Token: 0x06002BDB RID: 11227 RVA: 0x00108B70 File Offset: 0x00106D70
		[Token(Token = "0x6002BDB")]
		[Address(RVA = "0x2AFD614", Offset = "0x2AFD614", VA = "0x2AFD614")]
		[PunRPC]
		public void Ping(string target)
		{
			if (!true)
			{
			}
			string nickName = PhotonNetwork.LocalPlayer.nickName;
			bool flag = target == nickName;
			PhotonView photonView = this.view;
			object[] array = new object[1];
			string <UserId>k__BackingField = PhotonNetwork.LocalPlayer.<UserId>k__BackingField;
			if (<UserId>k__BackingField == null || <UserId>k__BackingField != null)
			{
				return;
			}
			throw new ArrayTypeMismatchException();
		}

		// Token: 0x06002BDC RID: 11228 RVA: 0x00108BD0 File Offset: 0x00106DD0
		[Token(Token = "0x6002BDC")]
		[Address(RVA = "0x2AFD780", Offset = "0x2AFD780", VA = "0x2AFD780")]
		[PunRPC]
		public void Pong(string uid)
		{
			this.targetUid = uid;
		}

		// Token: 0x06002BDD RID: 11229 RVA: 0x00108BE8 File Offset: 0x00106DE8
		[Token(Token = "0x6002BDD")]
		[Address(RVA = "0x2AFD7B0", Offset = "0x2AFD7B0", VA = "0x2AFD7B0")]
		public bRequestPing()
		{
		}

		// Token: 0x04000671 RID: 1649
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000671")]
		public PhotonView view;

		// Token: 0x04000672 RID: 1650
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000672")]
		public string targetUid;

		// Token: 0x04000673 RID: 1651
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000673")]
		public bool recieved;
	}
}
