﻿using System;
using System.Collections;
using System.Collections.Generic;
using Cpp2IlInjected;
using Locomotion;
using Photon.Pun;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000124 RID: 292
	[Token(Token = "0x2000124")]
	public class Kicks : MonoBehaviour
	{
		// Token: 0x06002BA7 RID: 11175 RVA: 0x00107E84 File Offset: 0x00106084
		[Token(Token = "0x6002BA7")]
		[Address(RVA = "0x2AD6190", Offset = "0x2AD6190", VA = "0x2AD6190")]
		private void Update()
		{
			long num = 1L;
			List<string> list = this.deadPeople;
			if (num == 0L)
			{
			}
			string nickName = PhotonNetwork.LocalPlayer.nickName;
			long num2;
			if (!this.isKicked)
			{
				IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
				Transform transform = this.backrooms;
				Transform transform2 = this.xrOrigin;
				Vector3 position = transform.position;
				Transform transform3 = this.backrooms;
				Transform transform4 = this.physRig;
				Vector3 position2 = transform3.position;
				num2 = 1L;
				this.isKicked = (num2 != 0L);
			}
			if (num2 == 0L)
			{
			}
			PhotonNetwork.Disconnect();
		}

		// Token: 0x06002BA8 RID: 11176 RVA: 0x00107F10 File Offset: 0x00106110
		[Token(Token = "0x6002BA8")]
		[Address(RVA = "0x2AD62E4", Offset = "0x2AD62E4", VA = "0x2AD62E4")]
		[PunRPC]
		public void KickPlayer(string player)
		{
			List<string> list = this.deadPeople;
		}

		// Token: 0x06002BA9 RID: 11177 RVA: 0x00107F2C File Offset: 0x0010612C
		[Token(Token = "0x6002BA9")]
		[Address(RVA = "0x2AD6348", Offset = "0x2AD6348", VA = "0x2AD6348")]
		public IEnumerator SendWebhook(string name)
		{
			long <>1__state;
			Kicks.<SendWebhook>d__10 <SendWebhook>d__ = new Kicks.<SendWebhook>d__10((int)<>1__state);
			<>1__state = 0L;
			<SendWebhook>d__.<>4__this = this;
			<SendWebhook>d__.name = name;
			throw new NullReferenceException();
		}

		// Token: 0x06002BAA RID: 11178 RVA: 0x00107F58 File Offset: 0x00106158
		[Token(Token = "0x6002BAA")]
		[Address(RVA = "0x2AD63DC", Offset = "0x2AD63DC", VA = "0x2AD63DC")]
		public Kicks()
		{
		}

		// Token: 0x04000629 RID: 1577
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000629")]
		public List<string> deadPeople;

		// Token: 0x0400062A RID: 1578
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400062A")]
		public PhotonView view;

		// Token: 0x0400062B RID: 1579
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400062B")]
		[Header("trolling")]
		public bool isKicked;

		// Token: 0x0400062C RID: 1580
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400062C")]
		public Transform xrOrigin;

		// Token: 0x0400062D RID: 1581
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x400062D")]
		public Transform physRig;

		// Token: 0x0400062E RID: 1582
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x400062E")]
		public PhysicsHand[] hands;

		// Token: 0x0400062F RID: 1583
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x400062F")]
		public Transform backrooms;

		// Token: 0x04000630 RID: 1584
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000630")]
		[Header("webhook")]
		public string wHookurl;
	}
}
