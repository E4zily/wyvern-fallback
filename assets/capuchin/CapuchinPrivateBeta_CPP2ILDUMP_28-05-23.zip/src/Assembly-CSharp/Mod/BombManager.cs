﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace Mod
{
	// Token: 0x0200012A RID: 298
	[Token(Token = "0x200012A")]
	public class BombManager : MonoBehaviourPun
	{
		// Token: 0x06002BC5 RID: 11205 RVA: 0x0010862C File Offset: 0x0010682C
		[Token(Token = "0x6002BC5")]
		[Address(RVA = "0x271D66C", Offset = "0x271D66C", VA = "0x271D66C")]
		private void Start()
		{
			BombManager.Instance = this;
		}

		// Token: 0x06002BC6 RID: 11206 RVA: 0x00108640 File Offset: 0x00106840
		[Token(Token = "0x6002BC6")]
		[Address(RVA = "0x271D6C0", Offset = "0x271D6C0", VA = "0x271D6C0")]
		public void Bomb(BombManager.bomb bombChoice, BombMenu menu)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				bool inRoom = PhotonNetwork.InRoom;
				PhotonView photonView = base.photonView;
				Player <Owner>k__BackingField = NetworkPlayerSpawner.كݕ\u05F3\u0589.ڽߗ\u0652\u089E.<Owner>k__BackingField;
				photonView.TransferOwnership(<Owner>k__BackingField);
			}
			string b_target = menu.b_target;
			this.target = b_target;
			if (bombChoice == BombManager.bomb.missile)
			{
				PhotonView photonView2 = base.photonView;
				object[] array = new object[1];
				return;
			}
		}

		// Token: 0x06002BC7 RID: 11207 RVA: 0x001086D4 File Offset: 0x001068D4
		[Token(Token = "0x6002BC7")]
		[Address(RVA = "0x271D8E8", Offset = "0x271D8E8", VA = "0x271D8E8")]
		[PunRPC]
		private void LaunchMissile(bool nuke)
		{
			Transform transform = this.start;
			GameObject gameObject = this.nukePrefab;
		}

		// Token: 0x06002BC8 RID: 11208 RVA: 0x00108770 File Offset: 0x00106970
		[Token(Token = "0x6002BC8")]
		[Address(RVA = "0x271DA6C", Offset = "0x271DA6C", VA = "0x271DA6C")]
		public BombManager()
		{
		}

		// Token: 0x0400064E RID: 1614
		[Token(Token = "0x400064E")]
		public static BombManager Instance;

		// Token: 0x0400064F RID: 1615
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400064F")]
		public Transform[] missileTargets;

		// Token: 0x04000650 RID: 1616
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000650")]
		public Transform bridge;

		// Token: 0x04000651 RID: 1617
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000651")]
		public Transform shop;

		// Token: 0x04000652 RID: 1618
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000652")]
		public Transform waterfall;

		// Token: 0x04000653 RID: 1619
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000653")]
		public Transform start;

		// Token: 0x04000654 RID: 1620
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000654")]
		public GameObject nukePrefab;

		// Token: 0x04000655 RID: 1621
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000655")]
		public GameObject missilePrefab;

		// Token: 0x04000656 RID: 1622
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000656")]
		public string target;

		// Token: 0x0200012B RID: 299
		[Token(Token = "0x200012B")]
		public enum bomb
		{
			// Token: 0x04000658 RID: 1624
			[Token(Token = "0x4000658")]
			missile,
			// Token: 0x04000659 RID: 1625
			[Token(Token = "0x4000659")]
			nuke
		}
	}
}
