﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000128 RID: 296
	[Token(Token = "0x2000128")]
	public class Bomb : MonoBehaviour
	{
		// Token: 0x06002BBB RID: 11195 RVA: 0x001083D4 File Offset: 0x001065D4
		[Token(Token = "0x6002BBB")]
		[Address(RVA = "0x271D170", Offset = "0x271D170", VA = "0x271D170")]
		private void Start()
		{
			Rigidbody component = GameObject.Find("XR Origin").GetComponent<Rigidbody>();
			this.player = component;
		}

		// Token: 0x06002BBC RID: 11196 RVA: 0x00108400 File Offset: 0x00106600
		[Token(Token = "0x6002BBC")]
		[Address(RVA = "0x271D1F0", Offset = "0x271D1F0", VA = "0x271D1F0")]
		private void Update()
		{
			long num = 1L;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Vector3 position2 = this.target.position;
			float num2 = this.speed;
			Transform transform2 = base.transform;
			Transform transform3 = this.target;
			transform2.LookAt(transform3);
			Vector3 position3 = this.raycastPoint.position;
			Vector3 forward = this.raycastPoint.forward;
			float num3 = this.rayDis;
			Vector3 position4 = this.raycastPoint.position;
			Vector3 forward2 = this.raycastPoint.forward;
			Color white = Color.white;
			float num4 = this.rayDis;
			if (num == 0L)
			{
			}
			if (!this.exploded)
			{
				if (typeof(UnityEngine.Object).TypeHandle == null)
				{
				}
				if (typeof(UnityEngine.Object).TypeHandle == null)
				{
				}
				Debug.Log("hit ground");
				MeshRenderer component = base.GetComponent<MeshRenderer>();
				long enabled = 0L;
				component.enabled = (enabled != 0L);
				Collider collider;
				Transform transform4 = collider.transform;
				Transform transform5 = this.hitPoint;
				Rigidbody rigidbody = this.player;
				int num5 = this.i;
				Vector3 position5 = transform5.position;
				this.system.Play();
				IEnumerator routine = this.wait();
				Coroutine coroutine = base.StartCoroutine(routine);
				long num6 = 1L;
				this.exploded = (num6 != 0L);
			}
		}

		// Token: 0x06002BBD RID: 11197 RVA: 0x00108538 File Offset: 0x00106738
		[Token(Token = "0x6002BBD")]
		[Address(RVA = "0x271D5EC", Offset = "0x271D5EC", VA = "0x271D5EC")]
		private IEnumerator wait()
		{
			long <>1__state;
			Bomb.<wait>d__11 <wait>d__ = new Bomb.<wait>d__11((int)<>1__state);
			<>1__state = 0L;
			<wait>d__.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002BBE RID: 11198 RVA: 0x0010855C File Offset: 0x0010675C
		[Token(Token = "0x6002BBE")]
		[Address(RVA = "0x271D664", Offset = "0x271D664", VA = "0x271D664")]
		public Bomb()
		{
		}

		// Token: 0x04000642 RID: 1602
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000642")]
		public Transform target;

		// Token: 0x04000643 RID: 1603
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000643")]
		public float speed;

		// Token: 0x04000644 RID: 1604
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000644")]
		public Transform raycastPoint;

		// Token: 0x04000645 RID: 1605
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000645")]
		public float rayDis;

		// Token: 0x04000646 RID: 1606
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000646")]
		private Transform hitPoint;

		// Token: 0x04000647 RID: 1607
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000647")]
		public ParticleSystem system;

		// Token: 0x04000648 RID: 1608
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000648")]
		private Rigidbody player;

		// Token: 0x04000649 RID: 1609
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000649")]
		private bool exploded;

		// Token: 0x0400064A RID: 1610
		[FieldOffset(Offset = "0x54")]
		[Token(Token = "0x400064A")]
		public int i;
	}
}
