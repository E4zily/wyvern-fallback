﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000126 RID: 294
	[Token(Token = "0x2000126")]
	public class ModPlayerList : MonoBehaviour
	{
		// Token: 0x06002BB2 RID: 11186 RVA: 0x00108114 File Offset: 0x00106314
		[Token(Token = "0x6002BB2")]
		[Address(RVA = "0x23B12C0", Offset = "0x23B12C0", VA = "0x23B12C0")]
		private void Start()
		{
		}

		// Token: 0x06002BB3 RID: 11187 RVA: 0x00108124 File Offset: 0x00106324
		[Token(Token = "0x6002BB3")]
		[Address(RVA = "0x23B12C8", Offset = "0x23B12C8", VA = "0x23B12C8")]
		private void Update()
		{
			if (!true)
			{
			}
			bool inRoom = PhotonNetwork.InRoom;
			GameObject[] array = GameObject.FindGameObjectsWithTag("NetworkPlayer");
			this.players = array;
			if ("NetworkPlayer" == null)
			{
			}
			byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		}

		// Token: 0x06002BB4 RID: 11188 RVA: 0x001081B4 File Offset: 0x001063B4
		[Token(Token = "0x6002BB4")]
		[Address(RVA = "0x23B158C", Offset = "0x23B158C", VA = "0x23B158C")]
		public ModPlayerList()
		{
		}

		// Token: 0x04000636 RID: 1590
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000636")]
		public GameObject[] players;

		// Token: 0x04000637 RID: 1591
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000637")]
		public GameObject[] playerItems;

		// Token: 0x04000638 RID: 1592
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000638")]
		private int prevPlayerc;
	}
}
