﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000130 RID: 304
	[Token(Token = "0x2000130")]
	public class TeleportMenu : MonoBehaviour
	{
		// Token: 0x06002BD9 RID: 11225 RVA: 0x00108B00 File Offset: 0x00106D00
		[Token(Token = "0x6002BD9")]
		[Address(RVA = "0x2F1FCF8", Offset = "0x2F1FCF8", VA = "0x2F1FCF8")]
		public void tp(int location)
		{
			PhysicsHand[] array = this.hands;
			float frequency = array.frequency;
			float frequency2 = array.frequency;
			Transform[] array2 = this.teleports;
			Transform transform = this.player;
			Transform[] array3 = this.teleports;
			Transform transform2 = this.physrig;
			Vector3 position = transform.position;
		}

		// Token: 0x06002BDA RID: 11226 RVA: 0x00108B5C File Offset: 0x00106D5C
		[Token(Token = "0x6002BDA")]
		[Address(RVA = "0x2F1FE08", Offset = "0x2F1FE08", VA = "0x2F1FE08")]
		public TeleportMenu()
		{
		}

		// Token: 0x0400066D RID: 1645
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400066D")]
		public Transform player;

		// Token: 0x0400066E RID: 1646
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400066E")]
		public Transform physrig;

		// Token: 0x0400066F RID: 1647
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400066F")]
		public Transform[] teleports;

		// Token: 0x04000670 RID: 1648
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000670")]
		public PhysicsHand[] hands;
	}
}
