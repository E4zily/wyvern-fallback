﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

namespace Mod
{
	// Token: 0x0200012F RID: 303
	[Token(Token = "0x200012F")]
	public class TakePhoto : MonoBehaviour
	{
		// Token: 0x06002BD7 RID: 11223 RVA: 0x00108A44 File Offset: 0x00106C44
		[Token(Token = "0x6002BD7")]
		[Address(RVA = "0x286BD80", Offset = "0x286BD80", VA = "0x286BD80")]
		public void Update()
		{
			if (InputDevices.GetDeviceAtXRNode(this.Controller) == null)
			{
			}
			if (!this.idk)
			{
				if (typeof(DateTime).TypeHandle == null)
				{
				}
				string str = DateTime.UtcNow.ToLocalTime().ToString("hh:mm:sstt");
				string str2 = DateTime.UtcNow.ToLocalTime().ToString("M/d/yyyy");
				PhotoHandler photoHandler = this.PhotoHandler;
				string message = "Date: " + str2 + "\n Time: " + str;
				photoHandler.Message = message;
				this.PhotoHandler.CaptureScreenShot();
				this.clipSound.Play();
				return;
			}
		}

		// Token: 0x06002BD8 RID: 11224 RVA: 0x00108AEC File Offset: 0x00106CEC
		[Token(Token = "0x6002BD8")]
		[Address(RVA = "0x286BF9C", Offset = "0x286BF9C", VA = "0x286BF9C")]
		public TakePhoto()
		{
		}

		// Token: 0x04000669 RID: 1641
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000669")]
		public XRNode Controller;

		// Token: 0x0400066A RID: 1642
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400066A")]
		public PhotoHandler PhotoHandler;

		// Token: 0x0400066B RID: 1643
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400066B")]
		public AudioSource clipSound;

		// Token: 0x0400066C RID: 1644
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400066C")]
		private bool idk;
	}
}
