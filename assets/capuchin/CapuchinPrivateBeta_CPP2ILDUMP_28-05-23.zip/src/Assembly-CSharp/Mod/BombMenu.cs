﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

namespace Mod
{
	// Token: 0x0200012C RID: 300
	[Token(Token = "0x200012C")]
	public class BombMenu : MonoBehaviour
	{
		// Token: 0x06002BC9 RID: 11209 RVA: 0x00108784 File Offset: 0x00106984
		[Token(Token = "0x6002BC9")]
		[Address(RVA = "0x271DA74", Offset = "0x271DA74", VA = "0x271DA74")]
		public void SetTarget()
		{
			int value = this.dropdown.m_Value;
			string text;
			this.b_target = text;
		}

		// Token: 0x06002BCA RID: 11210 RVA: 0x001087AC File Offset: 0x001069AC
		[Token(Token = "0x6002BCA")]
		[Address(RVA = "0x271DAC4", Offset = "0x271DAC4", VA = "0x271DAC4")]
		public void LaunchSingleMissile()
		{
			if (this.Launching)
			{
				return;
			}
			long launching = 1L;
			this.Launching = (launching != 0L);
			BombManager instance = BombManager.Instance;
		}

		// Token: 0x06002BCB RID: 11211 RVA: 0x001087D8 File Offset: 0x001069D8
		[Token(Token = "0x6002BCB")]
		[Address(RVA = "0x271DB40", Offset = "0x271DB40", VA = "0x271DB40")]
		public void LaunchNuke()
		{
			if (this.Launching)
			{
				return;
			}
			long launching = 1L;
			this.Launching = (launching != 0L);
			BombManager instance = BombManager.Instance;
		}

		// Token: 0x06002BCC RID: 11212 RVA: 0x00108804 File Offset: 0x00106A04
		[Token(Token = "0x6002BCC")]
		[Address(RVA = "0x271DBBC", Offset = "0x271DBBC", VA = "0x271DBBC")]
		public BombMenu()
		{
		}

		// Token: 0x0400065A RID: 1626
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400065A")]
		public bool Launching;

		// Token: 0x0400065B RID: 1627
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400065B")]
		public string b_target = "Bridge";

		// Token: 0x0400065C RID: 1628
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400065C")]
		public TMP_Dropdown dropdown;
	}
}
