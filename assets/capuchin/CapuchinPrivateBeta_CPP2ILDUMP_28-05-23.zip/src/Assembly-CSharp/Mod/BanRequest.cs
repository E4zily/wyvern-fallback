﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

namespace Mod
{
	// Token: 0x0200011C RID: 284
	[Token(Token = "0x200011C")]
	public class BanRequest : MonoBehaviour
	{
		// Token: 0x06002B84 RID: 11140 RVA: 0x00107544 File Offset: 0x00105744
		[Token(Token = "0x6002B84")]
		[Address(RVA = "0x2C0E7EC", Offset = "0x2C0E7EC", VA = "0x2C0E7EC")]
		public void banReq()
		{
			PhotonView view = this.uid.view;
			object[] array = new object[1];
			string nickName = this.playerItem.player.<Owner>k__BackingField.nickName;
			if (nickName == null || nickName != null)
			{
				IEnumerator routine = this.pinged();
				Coroutine coroutine = base.StartCoroutine(routine);
				return;
			}
			throw new ArrayTypeMismatchException();
		}

		// Token: 0x06002B85 RID: 11141 RVA: 0x001075A4 File Offset: 0x001057A4
		[Token(Token = "0x6002B85")]
		[Address(RVA = "0x2C0E97C", Offset = "0x2C0E97C", VA = "0x2C0E97C")]
		public void LateUpdate()
		{
			string nickName = this.playerItem.player.<Owner>k__BackingField.nickName;
			TMP_Text tmp_Text = this.title;
			string text = "Ban " + nickName;
		}

		// Token: 0x06002B86 RID: 11142 RVA: 0x001075E0 File Offset: 0x001057E0
		[Token(Token = "0x6002B86")]
		[Address(RVA = "0x2C0EA08", Offset = "0x2C0EA08", VA = "0x2C0EA08")]
		public void selectPlayer(PlayerItem p)
		{
			this.playerItem = p;
		}

		// Token: 0x06002B87 RID: 11143 RVA: 0x001075F4 File Offset: 0x001057F4
		[Token(Token = "0x6002B87")]
		[Address(RVA = "0x2C0EA10", Offset = "0x2C0EA10", VA = "0x2C0EA10")]
		public IEnumerator SendWebhook()
		{
			long <>1__state;
			BanRequest.<SendWebhook>d__9 <SendWebhook>d__ = new BanRequest.<SendWebhook>d__9((int)<>1__state);
			<>1__state = 0L;
			<SendWebhook>d__.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002B88 RID: 11144 RVA: 0x00107618 File Offset: 0x00105818
		[Token(Token = "0x6002B88")]
		[Address(RVA = "0x2C0E904", Offset = "0x2C0E904", VA = "0x2C0E904")]
		public IEnumerator pinged()
		{
			long <>1__state;
			BanRequest.<pinged>d__10 <pinged>d__ = new BanRequest.<pinged>d__10((int)<>1__state);
			<>1__state = 0L;
			throw new NullReferenceException();
		}

		// Token: 0x06002B89 RID: 11145 RVA: 0x00107634 File Offset: 0x00105834
		[Token(Token = "0x6002B89")]
		[Address(RVA = "0x2C0EA88", Offset = "0x2C0EA88", VA = "0x2C0EA88")]
		public BanRequest()
		{
		}

		// Token: 0x040005FF RID: 1535
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40005FF")]
		public string wHookurl;

		// Token: 0x04000600 RID: 1536
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000600")]
		public PlayerItem playerItem;

		// Token: 0x04000601 RID: 1537
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000601")]
		public bRequestPing uid;

		// Token: 0x04000602 RID: 1538
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000602")]
		public TMP_Dropdown dropdown;

		// Token: 0x04000603 RID: 1539
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000603")]
		public TMP_Text title;

		// Token: 0x04000604 RID: 1540
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000604")]
		public string[] banReasons;
	}
}
