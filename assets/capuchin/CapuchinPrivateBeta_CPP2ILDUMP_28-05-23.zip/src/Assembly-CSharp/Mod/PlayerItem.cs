﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Mod
{
	// Token: 0x02000127 RID: 295
	[Token(Token = "0x2000127")]
	public class PlayerItem : MonoBehaviour
	{
		// Token: 0x06002BB5 RID: 11189 RVA: 0x001081C8 File Offset: 0x001063C8
		[Token(Token = "0x6002BB5")]
		[Address(RVA = "0x29A1A24", Offset = "0x29A1A24", VA = "0x29A1A24")]
		private void Start()
		{
		}

		// Token: 0x06002BB6 RID: 11190 RVA: 0x001081D8 File Offset: 0x001063D8
		[Token(Token = "0x6002BB6")]
		[Address(RVA = "0x29A1A28", Offset = "0x29A1A28", VA = "0x29A1A28")]
		private void LateUpdate()
		{
			Player <Owner>k__BackingField = this.player.<Owner>k__BackingField;
			TMP_Text tmp_Text = this.text;
			string nickName = <Owner>k__BackingField.nickName;
			bool isOn = this.toggle.m_IsOn;
			AudioSource audioSource = this.playera;
			this.audioIsolated = isOn;
			GameObject gameObject = this.disabledAudio;
			bool flag = this.audioIsolated;
		}

		// Token: 0x06002BB7 RID: 11191 RVA: 0x00108230 File Offset: 0x00106430
		[Token(Token = "0x6002BB7")]
		[Address(RVA = "0x29A1AB4", Offset = "0x29A1AB4", VA = "0x29A1AB4")]
		public void KickPlayer()
		{
			this.kick.view.RequestOwnership();
			Player <Owner>k__BackingField = this.player.<Owner>k__BackingField;
			Kicks kicks = this.kick;
			string nickName = <Owner>k__BackingField.nickName;
			IEnumerator routine = kicks.SendWebhook(nickName);
			Coroutine coroutine = kicks.StartCoroutine(routine);
			PhotonView view = this.kick.view;
			string nickName2 = this.player.<Owner>k__BackingField.nickName;
			if (nickName2 == null || nickName2 != null)
			{
				return;
			}
			throw new ArrayTypeMismatchException();
		}

		// Token: 0x06002BB8 RID: 11192 RVA: 0x001082B4 File Offset: 0x001064B4
		[Token(Token = "0x6002BB8")]
		[Address(RVA = "0x29A1BFC", Offset = "0x29A1BFC", VA = "0x29A1BFC")]
		public void Fling()
		{
			this.troller.Ӆ\u07A6ࡓ\u086D.RequestOwnership();
			PhotonView ӆ_u07A6ࡓ_u086D = this.troller.Ӆ\u07A6ࡓ\u086D;
			object[] array = new object[2];
			string nickName = this.player.<Owner>k__BackingField.nickName;
			if ((nickName == null || nickName != null) && (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null))
			{
				return;
			}
			throw new ArrayTypeMismatchException();
		}

		// Token: 0x06002BB9 RID: 11193 RVA: 0x0010831C File Offset: 0x0010651C
		[Token(Token = "0x6002BB9")]
		[Address(RVA = "0x29A1D70", Offset = "0x29A1D70", VA = "0x29A1D70")]
		public void sTaunt()
		{
			this.troller.Ӆ\u07A6ࡓ\u086D.RequestOwnership();
			PhotonView ӆ_u07A6ࡓ_u086D = this.troller.Ӆ\u07A6ࡓ\u086D;
			object[] array = new object[2];
			string nickName = this.player.<Owner>k__BackingField.nickName;
			if ((nickName == null || nickName != null) && (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null))
			{
				string name = this.taunt.name;
				Transform transform = this.player.transform;
				long index = 0L;
				Vector3 position = transform.GetChild((int)index).position;
				Quaternion identity = Quaternion.identity;
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				return;
			}
			throw new ArrayTypeMismatchException();
		}

		// Token: 0x06002BBA RID: 11194 RVA: 0x001083C0 File Offset: 0x001065C0
		[Token(Token = "0x6002BBA")]
		[Address(RVA = "0x29A1FC8", Offset = "0x29A1FC8", VA = "0x29A1FC8")]
		public PlayerItem()
		{
		}

		// Token: 0x04000639 RID: 1593
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000639")]
		public PhotonView player;

		// Token: 0x0400063A RID: 1594
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400063A")]
		public TMP_Text text;

		// Token: 0x0400063B RID: 1595
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400063B")]
		public Kicks kick;

		// Token: 0x0400063C RID: 1596
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400063C")]
		public AudioSource playera;

		// Token: 0x0400063D RID: 1597
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x400063D")]
		public bool audioIsolated;

		// Token: 0x0400063E RID: 1598
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x400063E")]
		public GameObject disabledAudio;

		// Token: 0x0400063F RID: 1599
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x400063F")]
		public Toggle toggle;

		// Token: 0x04000640 RID: 1600
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000640")]
		public troller troller;

		// Token: 0x04000641 RID: 1601
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000641")]
		public GameObject taunt;
	}
}
