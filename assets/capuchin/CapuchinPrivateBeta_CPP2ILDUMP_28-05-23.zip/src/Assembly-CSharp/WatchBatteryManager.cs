﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;
using VLB;

// Token: 0x020000F2 RID: 242
[Token(Token = "0x20000F2")]
public class WatchBatteryManager : MonoBehaviour
{
	// Token: 0x06002552 RID: 9554 RVA: 0x000C5790 File Offset: 0x000C3990
	[Token(Token = "0x6002552")]
	[Address(RVA = "0x2C7C6B4", Offset = "0x2C7C6B4", VA = "0x2C7C6B4")]
	public void ڷ\u0826ӹڥ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.GetComponent<Charger>();
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Reason: ");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x06002553 RID: 9555 RVA: 0x000C57E8 File Offset: 0x000C39E8
	[Token(Token = "0x6002553")]
	[Address(RVA = "0x2C7C7F0", Offset = "0x2C7C7F0", VA = "0x2C7C7F0")]
	public void ߃\u0602\u0891߇(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x06002554 RID: 9556 RVA: 0x000C5828 File Offset: 0x000C3A28
	[Token(Token = "0x6002554")]
	[Address(RVA = "0x2C7C8D8", Offset = "0x2C7C8D8", VA = "0x2C7C8D8")]
	public void \u06E2ڇ\u07BF߃(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x06002555 RID: 9557 RVA: 0x000C5874 File Offset: 0x000C3A74
	[Token(Token = "0x6002555")]
	[Address(RVA = "0x2C7C9C4", Offset = "0x2C7C9C4", VA = "0x2C7C9C4")]
	public void \u0594\u0887ܭ\u0899()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x06002556 RID: 9558 RVA: 0x000C58D4 File Offset: 0x000C3AD4
	[Token(Token = "0x6002556")]
	[Address(RVA = "0x2C7CA4C", Offset = "0x2C7CA4C", VA = "0x2C7CA4C")]
	public void \u081Cәࡃ۵()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			string name = ڸޢޝ_u05B3.gameObject.name;
			if ("Not connected to room" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag = ڸޢޝ_u05B5.gameObject.name == "Room1";
		if ("Room1" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Open");
			long ࡣ_u087F_u0651މ = 1L;
			this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ډ\u06EB\u07EFڒ();
	}

	// Token: 0x06002557 RID: 9559 RVA: 0x000C5B20 File Offset: 0x000C3D20
	[Token(Token = "0x6002557")]
	[Address(RVA = "0x2C7D02C", Offset = "0x2C7D02C", VA = "0x2C7D02C")]
	public void \u074C\u0830\u0594ԡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("NetworkPlayer");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long ࡣ_u087F_u0651މ = 1L;
		this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x06002558 RID: 9560 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002558")]
	[Address(RVA = "0x2C7D168", Offset = "0x2C7D168", VA = "0x2C7D168")]
	public void ے\u059Fࢰس(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002559 RID: 9561 RVA: 0x000C5B7C File Offset: 0x000C3D7C
	[Token(Token = "0x6002559")]
	[Address(RVA = "0x2C7D2A0", Offset = "0x2C7D2A0", VA = "0x2C7D2A0")]
	public void ٩\u06E1\u065F\u086F()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x0600255A RID: 9562 RVA: 0x000C5BC4 File Offset: 0x000C3DC4
	[Token(Token = "0x600255A")]
	[Address(RVA = "0x2C7D2F8", Offset = "0x2C7D2F8", VA = "0x2C7D2F8")]
	public void \u06DEӸԏ\u07BF(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x0600255B RID: 9563 RVA: 0x000C5C10 File Offset: 0x000C3E10
	[Token(Token = "0x600255B")]
	[Address(RVA = "0x2C7D3E4", Offset = "0x2C7D3E4", VA = "0x2C7D3E4")]
	public void \u064F\u07BEցڙ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x0600255C RID: 9564 RVA: 0x000C5C58 File Offset: 0x000C3E58
	[Token(Token = "0x600255C")]
	[Address(RVA = "0x2C7D43C", Offset = "0x2C7D43C", VA = "0x2C7D43C")]
	public void Ԕٸࠔ\u07AF()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x0600255D RID: 9565 RVA: 0x000C5CA0 File Offset: 0x000C3EA0
	[Token(Token = "0x600255D")]
	[Address(RVA = "0x2C7D494", Offset = "0x2C7D494", VA = "0x2C7D494")]
	public void ࡆմԍܠ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x0600255E RID: 9566 RVA: 0x000C5CE8 File Offset: 0x000C3EE8
	[Token(Token = "0x600255E")]
	[Address(RVA = "0x2C7D4EC", Offset = "0x2C7D4EC", VA = "0x2C7D4EC")]
	public void \u05F8ݑ\u06ECߞ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "PURCHASED";
			if ("PURCHASED" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == ".Please press the button if you would like to play alone";
		if (".Please press the button if you would like to play alone" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Player");
		}
		this.ׯ\u05B4ןӫ();
	}

	// Token: 0x0600255F RID: 9567 RVA: 0x000C5F28 File Offset: 0x000C4128
	[Token(Token = "0x600255F")]
	[Address(RVA = "0x2C7DAC8", Offset = "0x2C7DAC8", VA = "0x2C7DAC8")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("HandL");
	}

	// Token: 0x06002560 RID: 9568 RVA: 0x000C5F60 File Offset: 0x000C4160
	[Token(Token = "0x6002560")]
	[Address(RVA = "0x2C7DC00", Offset = "0x2C7DC00", VA = "0x2C7DC00")]
	public void ܮߎ\u074Cه()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x06002561 RID: 9569 RVA: 0x000C5FC0 File Offset: 0x000C41C0
	[Token(Token = "0x6002561")]
	[Address(RVA = "0x2C7DC88", Offset = "0x2C7DC88", VA = "0x2C7DC88")]
	public void \u0703\u086B\u085DՉ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x06002562 RID: 9570 RVA: 0x000C6008 File Offset: 0x000C4208
	[Token(Token = "0x6002562")]
	[Address(RVA = "0x2C7DCE0", Offset = "0x2C7DCE0", VA = "0x2C7DCE0")]
	public void ࢲ\u061C\u0817ݽ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x06002563 RID: 9571 RVA: 0x000C6054 File Offset: 0x000C4254
	[Token(Token = "0x6002563")]
	[Address(RVA = "0x2C7DDCC", Offset = "0x2C7DDCC", VA = "0x2C7DDCC")]
	public void ڳݏࡑ\u082A()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x06002564 RID: 9572 RVA: 0x000C60B4 File Offset: 0x000C42B4
	[Token(Token = "0x6002564")]
	[Address(RVA = "0x2C7DE54", Offset = "0x2C7DE54", VA = "0x2C7DE54")]
	public void ޏԀ\u0654\u0889()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x06002565 RID: 9573 RVA: 0x000C60FC File Offset: 0x000C42FC
	[Token(Token = "0x6002565")]
	[Address(RVA = "0x2C7DEAC", Offset = "0x2C7DEAC", VA = "0x2C7DEAC")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x06002566 RID: 9574 RVA: 0x000C613C File Offset: 0x000C433C
	[Token(Token = "0x6002566")]
	[Address(RVA = "0x2C7DF94", Offset = "0x2C7DF94", VA = "0x2C7DF94")]
	public void Ԧמࡡھ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x06002567 RID: 9575 RVA: 0x000C6184 File Offset: 0x000C4384
	[Token(Token = "0x6002567")]
	[Address(RVA = "0x2C7DFEC", Offset = "0x2C7DFEC", VA = "0x2C7DFEC")]
	public void \u055Cࢯܯ\u0898()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ2;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "HOLY MOLY THE STICK IS ON FIRE!!!!!!";
			if ("HOLY MOLY THE STICK IS ON FIRE!!!!!!" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "PRESS AGAIN TO CONFIRM";
		if ("PRESS AGAIN TO CONFIRM" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Regular");
		}
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.Ԇݎӗܠ();
	}

	// Token: 0x06002568 RID: 9576 RVA: 0x000C63CC File Offset: 0x000C45CC
	[Token(Token = "0x6002568")]
	[Address(RVA = "0x2C7E5C8", Offset = "0x2C7E5C8", VA = "0x2C7E5C8")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("_Tint");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x06002569 RID: 9577 RVA: 0x000C6420 File Offset: 0x000C4620
	[Token(Token = "0x6002569")]
	[Address(RVA = "0x2C7E700", Offset = "0x2C7E700", VA = "0x2C7E700")]
	public void ۅ\u089B\u06EDڰ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x0600256A RID: 9578 RVA: 0x000C6468 File Offset: 0x000C4668
	[Token(Token = "0x600256A")]
	[Address(RVA = "0x2C7E570", Offset = "0x2C7E570", VA = "0x2C7E570")]
	public void \u070BӾܬ\u0604()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x0600256B RID: 9579 RVA: 0x000C64B0 File Offset: 0x000C46B0
	[Token(Token = "0x600256B")]
	[Address(RVA = "0x2C7E758", Offset = "0x2C7E758", VA = "0x2C7E758")]
	public void ڑߒجވ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "Player";
			if ("Player" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "typesOfTalk";
		if ("typesOfTalk" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Player");
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.\u05C0۳\u07FD\u0618();
	}

	// Token: 0x0600256C RID: 9580 RVA: 0x000C66F4 File Offset: 0x000C48F4
	[Token(Token = "0x600256C")]
	[Address(RVA = "0x2C7ECD0", Offset = "0x2C7ECD0", VA = "0x2C7ECD0")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("NetworkGunShoot");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long ࡣ_u087F_u0651މ = 1L;
		this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x0600256D RID: 9581 RVA: 0x000C6750 File Offset: 0x000C4950
	[Token(Token = "0x600256D")]
	[Address(RVA = "0x2C7EE0C", Offset = "0x2C7EE0C", VA = "0x2C7EE0C")]
	public void \u07F3\u0876ߗ\u06FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x0600256E RID: 9582 RVA: 0x000C679C File Offset: 0x000C499C
	[Token(Token = "0x600256E")]
	[Address(RVA = "0x2C7DA70", Offset = "0x2C7DA70", VA = "0x2C7DA70")]
	public void ߈ٺհֈ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		long active2 = 1L;
		gameObject.SetActive(active2 != 0L);
		long active3 = 1L;
		gameObject.SetActive(active3 != 0L);
	}

	// Token: 0x0600256F RID: 9583 RVA: 0x000C67D4 File Offset: 0x000C49D4
	[Token(Token = "0x600256F")]
	[Address(RVA = "0x2C7EEF8", Offset = "0x2C7EEF8", VA = "0x2C7EEF8")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		long num = 1L;
		this.\u05EEࢶ\u0655ێ = (num != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("NetworkPlayer");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		this.ࡣ\u087F\u0651މ = (num != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x06002570 RID: 9584 RVA: 0x000C6838 File Offset: 0x000C4A38
	[Token(Token = "0x6002570")]
	[Address(RVA = "0x2C7F034", Offset = "0x2C7F034", VA = "0x2C7F034")]
	public void Ӫش\u0742ۂ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x06002571 RID: 9585 RVA: 0x000C6880 File Offset: 0x000C4A80
	[Token(Token = "0x6002571")]
	[Address(RVA = "0x2C7F08C", Offset = "0x2C7F08C", VA = "0x2C7F08C")]
	public void ߑ\u0885\u05BBߕ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "You Already Own This Item";
			if ("You Already Own This Item" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:";
		if ("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("true");
			long ࡣ_u087F_u0651މ = 1L;
			this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		}
		this.ӝݞޗק();
	}

	// Token: 0x06002572 RID: 9586 RVA: 0x000C6AC4 File Offset: 0x000C4CC4
	[Token(Token = "0x6002572")]
	[Address(RVA = "0x2C7F614", Offset = "0x2C7F614", VA = "0x2C7F614")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("QuickStatic");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x06002573 RID: 9587 RVA: 0x000C6B18 File Offset: 0x000C4D18
	[Token(Token = "0x6002573")]
	[Address(RVA = "0x2C7F74C", Offset = "0x2C7F74C", VA = "0x2C7F74C")]
	public void ۅՇߎ\u05FA()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x06002574 RID: 9588 RVA: 0x000C6B60 File Offset: 0x000C4D60
	[Token(Token = "0x6002574")]
	[Address(RVA = "0x2C7F7A4", Offset = "0x2C7F7A4", VA = "0x2C7F7A4")]
	public void յؿӘߖ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x06002575 RID: 9589 RVA: 0x000C6BB8 File Offset: 0x000C4DB8
	[Token(Token = "0x6002575")]
	[Address(RVA = "0x2C7F82C", Offset = "0x2C7F82C", VA = "0x2C7F82C")]
	public void \u06DAٻࠕڡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("A Player has left the Room.");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long ࡣ_u087F_u0651މ = 1L;
		this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x06002576 RID: 9590 RVA: 0x000C6C14 File Offset: 0x000C4E14
	[Token(Token = "0x6002576")]
	[Address(RVA = "0x2C7F968", Offset = "0x2C7F968", VA = "0x2C7F968")]
	public void \u059B\u081F\u05FEڂ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		long num = 1L;
		this.\u05EEࢶ\u0655ێ = (num != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("username");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		this.ࡣ\u087F\u0651މ = (num != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x06002577 RID: 9591 RVA: 0x000C6C78 File Offset: 0x000C4E78
	[Token(Token = "0x6002577")]
	[Address(RVA = "0x2C7FAA4", Offset = "0x2C7FAA4", VA = "0x2C7FAA4")]
	public void \u0744\u0617\u0609Ԣ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x06002578 RID: 9592 RVA: 0x000C6CC0 File Offset: 0x000C4EC0
	[Token(Token = "0x6002578")]
	[Address(RVA = "0x2C7FAFC", Offset = "0x2C7FAFC", VA = "0x2C7FAFC")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Not connected to room");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x06002579 RID: 9593 RVA: 0x000C6D1C File Offset: 0x000C4F1C
	[Token(Token = "0x6002579")]
	[Address(RVA = "0x2C7FC38", Offset = "0x2C7FC38", VA = "0x2C7FC38")]
	public void ںڈߧӪ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		this.Թ\u06DFأר.SetActive(active2 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x0600257A RID: 9594 RVA: 0x000C6D74 File Offset: 0x000C4F74
	[Token(Token = "0x600257A")]
	[Address(RVA = "0x2C7FCC0", Offset = "0x2C7FCC0", VA = "0x2C7FCC0")]
	public void \u087FݭԪࢶ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x0600257B RID: 9595 RVA: 0x000C6DBC File Offset: 0x000C4FBC
	[Token(Token = "0x600257B")]
	[Address(RVA = "0x2C7FD18", Offset = "0x2C7FD18", VA = "0x2C7FD18")]
	public void ذۈ\u07F4\u07EC()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x0600257C RID: 9596 RVA: 0x000C6E1C File Offset: 0x000C501C
	[Token(Token = "0x600257C")]
	[Address(RVA = "0x2C7FDA0", Offset = "0x2C7FDA0", VA = "0x2C7FDA0")]
	public void ފԅ\u0881ݾ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		long num = 1L;
		this.\u05EEࢶ\u0655ێ = (num != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Open");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		this.ࡣ\u087F\u0651މ = (num != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x0600257D RID: 9597 RVA: 0x000C6E80 File Offset: 0x000C5080
	[Token(Token = "0x600257D")]
	[Address(RVA = "0x2C7FEDC", Offset = "0x2C7FEDC", VA = "0x2C7FEDC")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.GetComponent<Charger>();
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Charged!");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x0600257E RID: 9598 RVA: 0x000C6ED8 File Offset: 0x000C50D8
	[Token(Token = "0x600257E")]
	[Address(RVA = "0x2C80018", Offset = "0x2C80018", VA = "0x2C80018")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Charging...");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x0600257F RID: 9599 RVA: 0x000C6F34 File Offset: 0x000C5134
	[Token(Token = "0x600257F")]
	[Address(RVA = "0x2C80154", Offset = "0x2C80154", VA = "0x2C80154")]
	public void ېۂ\u08B5ԣ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x06002580 RID: 9600 RVA: 0x000C6F7C File Offset: 0x000C517C
	[Token(Token = "0x6002580")]
	[Address(RVA = "0x2C801AC", Offset = "0x2C801AC", VA = "0x2C801AC")]
	public void ڳ\u06FDࡕ\u06EC()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x06002581 RID: 9601 RVA: 0x000C6FC4 File Offset: 0x000C51C4
	[Token(Token = "0x6002581")]
	[Address(RVA = "0x2C7D9E8", Offset = "0x2C7D9E8", VA = "0x2C7D9E8")]
	public void ׯ\u05B4ןӫ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x06002582 RID: 9602 RVA: 0x000C7024 File Offset: 0x000C5224
	[Token(Token = "0x6002582")]
	[Address(RVA = "0x2C80204", Offset = "0x2C80204", VA = "0x2C80204")]
	public void ١ۍؾջ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		long active3 = 1L;
		ܗ_u083Cݰߡ.SetActive(active3 != 0L);
	}

	// Token: 0x06002583 RID: 9603 RVA: 0x000C7064 File Offset: 0x000C5264
	[Token(Token = "0x6002583")]
	[Address(RVA = "0x2C8025C", Offset = "0x2C8025C", VA = "0x2C8025C")]
	public void ԙӆݦ\u0888()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x06002584 RID: 9604 RVA: 0x000C70C4 File Offset: 0x000C52C4
	[Token(Token = "0x6002584")]
	[Address(RVA = "0x2C7EC48", Offset = "0x2C7EC48", VA = "0x2C7EC48")]
	public void \u05C0۳\u07FD\u0618()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x06002585 RID: 9605 RVA: 0x000C7124 File Offset: 0x000C5324
	[Token(Token = "0x6002585")]
	[Address(RVA = "0x2C802E4", Offset = "0x2C802E4", VA = "0x2C802E4")]
	public void \u07FE\u0882Զ\u066D()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "Damaged Arm";
			if ("Damaged Arm" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "Head";
		if ("Head" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("You Already Own This Item");
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ׯ\u05B4ןӫ();
	}

	// Token: 0x06002586 RID: 9606 RVA: 0x000C7370 File Offset: 0x000C5570
	[Token(Token = "0x6002586")]
	[Address(RVA = "0x2C807DC", Offset = "0x2C807DC", VA = "0x2C807DC")]
	public void ع߁եӔ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x06002587 RID: 9607 RVA: 0x000C73D0 File Offset: 0x000C55D0
	[Token(Token = "0x6002587")]
	[Address(RVA = "0x2C80864", Offset = "0x2C80864", VA = "0x2C80864")]
	public void Update()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "FLSPTLT";
			if ("FLSPTLT" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "FLSPTLT";
		if ("FLSPTLT" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Charged!");
			long ࡣ_u087F_u0651މ = 1L;
			this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ӝݞޗק();
	}

	// Token: 0x06002588 RID: 9608 RVA: 0x000C762C File Offset: 0x000C582C
	[Token(Token = "0x6002588")]
	[Address(RVA = "0x2C80D34", Offset = "0x2C80D34", VA = "0x2C80D34")]
	public void կܘԄԮ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x06002589 RID: 9609 RVA: 0x000C768C File Offset: 0x000C588C
	[Token(Token = "0x6002589")]
	[Address(RVA = "0x2C80DBC", Offset = "0x2C80DBC", VA = "0x2C80DBC")]
	public void Ԍߊٱݩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x0600258A RID: 9610 RVA: 0x000C76D8 File Offset: 0x000C58D8
	[Token(Token = "0x600258A")]
	[Address(RVA = "0x2C80EA8", Offset = "0x2C80EA8", VA = "0x2C80EA8")]
	public void ޓӥ\u088Eܖ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x0600258B RID: 9611 RVA: 0x000C7724 File Offset: 0x000C5924
	[Token(Token = "0x600258B")]
	[Address(RVA = "0x2C7CFD4", Offset = "0x2C7CFD4", VA = "0x2C7CFD4")]
	public void \u06DAࢹ\u0888\u05B8()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x0600258C RID: 9612 RVA: 0x000C7764 File Offset: 0x000C5964
	[Token(Token = "0x600258C")]
	[Address(RVA = "0x2C80F94", Offset = "0x2C80F94", VA = "0x2C80F94")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Connected to Server.");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long ࡣ_u087F_u0651މ = 1L;
		this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x0600258D RID: 9613 RVA: 0x000C77C0 File Offset: 0x000C59C0
	[Token(Token = "0x600258D")]
	[Address(RVA = "0x2C810D0", Offset = "0x2C810D0", VA = "0x2C810D0")]
	public void ߗ\u088B\u05C2ڌ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x0600258E RID: 9614 RVA: 0x000C7808 File Offset: 0x000C5A08
	[Token(Token = "0x600258E")]
	[Address(RVA = "0x2C81128", Offset = "0x2C81128", VA = "0x2C81128")]
	public void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		long active = 0L;
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long ࡣ_u087F_u0651މ = 1L;
		this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x0600258F RID: 9615 RVA: 0x000C7858 File Offset: 0x000C5A58
	[Token(Token = "0x600258F")]
	[Address(RVA = "0x2C81264", Offset = "0x2C81264", VA = "0x2C81264")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		long num = 1L;
		this.\u05EEࢶ\u0655ێ = (num != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("sound play stopped");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		this.ࡣ\u087F\u0651މ = (num != 0L);
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x06002590 RID: 9616 RVA: 0x000C78BC File Offset: 0x000C5ABC
	[Token(Token = "0x6002590")]
	[Address(RVA = "0x2C813A0", Offset = "0x2C813A0", VA = "0x2C813A0")]
	public void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x06002591 RID: 9617 RVA: 0x000C7908 File Offset: 0x000C5B08
	[Token(Token = "0x6002591")]
	[Address(RVA = "0x2C8148C", Offset = "0x2C8148C", VA = "0x2C8148C")]
	public void צ\u0874ڵ\u059A()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "Network Player";
			if ("Network Player" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "_Tint";
		if ("_Tint" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("MetaAuth");
			long ࡣ_u087F_u0651މ = 1L;
			this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ն\u0742\u083F\u0640();
	}

	// Token: 0x06002592 RID: 9618 RVA: 0x000C7B64 File Offset: 0x000C5D64
	[Token(Token = "0x6002592")]
	[Address(RVA = "0x2C81A68", Offset = "0x2C81A68", VA = "0x2C81A68")]
	public void \u05ABࡡ\u07ABݾ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == " hours. You were banned because of ";
			if (" hours. You were banned because of " == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "username";
		if ("username" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Body");
			long ࡣ_u087F_u0651މ = 1L;
			this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ع߁եӔ();
	}

	// Token: 0x06002593 RID: 9619 RVA: 0x000C7DC0 File Offset: 0x000C5FC0
	[Token(Token = "0x6002593")]
	[Address(RVA = "0x2C81F68", Offset = "0x2C81F68", VA = "0x2C81F68")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("username");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x06002594 RID: 9620 RVA: 0x000C7E14 File Offset: 0x000C6014
	[Token(Token = "0x6002594")]
	[Address(RVA = "0x2C820A0", Offset = "0x2C820A0", VA = "0x2C820A0")]
	public void ܚ\u0891\u0891չ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x06002595 RID: 9621 RVA: 0x000C7E5C File Offset: 0x000C605C
	[Token(Token = "0x6002595")]
	[Address(RVA = "0x2C81988", Offset = "0x2C81988", VA = "0x2C81988")]
	public void ն\u0742\u083F\u0640()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x06002596 RID: 9622 RVA: 0x000C7EBC File Offset: 0x000C60BC
	[Token(Token = "0x6002596")]
	[Address(RVA = "0x2C820F8", Offset = "0x2C820F8", VA = "0x2C820F8")]
	public void ڠ\u0659ӧ\u0884()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x06002597 RID: 9623 RVA: 0x000C7F04 File Offset: 0x000C6104
	[Token(Token = "0x6002597")]
	[Address(RVA = "0x2C82150", Offset = "0x2C82150", VA = "0x2C82150")]
	public void Ҿࢹؼס()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		float deltaTime = Time.deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B2.gameObject.name == "TurnAmount";
			if ("TurnAmount" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			float intensity = ڸޢޝ_u05B3.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity2;
			ڸޢޝ_u05B3.intensity = intensity2;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B4.gameObject.name == "trol";
		if ("trol" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B5.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Round end");
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ذۈ\u07F4\u07EC();
	}

	// Token: 0x06002598 RID: 9624 RVA: 0x000C813C File Offset: 0x000C633C
	[Token(Token = "0x6002598")]
	[Address(RVA = "0x2C82648", Offset = "0x2C82648", VA = "0x2C82648")]
	public void ی\u0823ڇݔ()
	{
		if ("\ud9c0\udc00" == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "CapuchinRemade";
			if ("\ud9c0\udc00" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "Player";
		if ("\ud9c0\udc00" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("isLava");
			long ࡣ_u087F_u0651މ = 1L;
			this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.سࠊԏף();
	}

	// Token: 0x06002599 RID: 9625 RVA: 0x000C8398 File Offset: 0x000C6598
	[Token(Token = "0x6002599")]
	[Address(RVA = "0x2C82BD0", Offset = "0x2C82BD0", VA = "0x2C82BD0")]
	public void \u07F5\u0657\u055Aߍ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "Not enough amount of currency";
			if ("Not enough amount of currency" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "Diffuse";
		if ("Diffuse" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			Debug.Log("This is the 5000 Bananas button, and it was just clicked");
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.յؿӘߖ();
	}

	// Token: 0x0600259A RID: 9626 RVA: 0x000C85E0 File Offset: 0x000C67E0
	[Token(Token = "0x600259A")]
	[Address(RVA = "0x2C830CC", Offset = "0x2C830CC", VA = "0x2C830CC")]
	public void \u0819Փٲࡪ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x0600259B RID: 9627 RVA: 0x000C862C File Offset: 0x000C682C
	[Token(Token = "0x600259B")]
	[Address(RVA = "0x2C831B8", Offset = "0x2C831B8", VA = "0x2C831B8")]
	public void \u060Eח\u05F3\u05FD()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x0600259C RID: 9628 RVA: 0x000C868C File Offset: 0x000C688C
	[Token(Token = "0x600259C")]
	[Address(RVA = "0x2C83240", Offset = "0x2C83240", VA = "0x2C83240")]
	public void ࡕߕ\u0707ݩ()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "Player";
			if ("Player" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "SetColor";
		if ("SetColor" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("You have been banned for ");
			long ࡣ_u087F_u0651މ = 1L;
			this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		}
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.կܘԄԮ();
	}

	// Token: 0x0600259D RID: 9629 RVA: 0x000C88D8 File Offset: 0x000C6AD8
	[Token(Token = "0x600259D")]
	[Address(RVA = "0x2C82B48", Offset = "0x2C82B48", VA = "0x2C82B48")]
	public void سࠊԏף()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x0600259E RID: 9630 RVA: 0x000C8938 File Offset: 0x000C6B38
	[Token(Token = "0x600259E")]
	[Address(RVA = "0x2C83740", Offset = "0x2C83740", VA = "0x2C83740")]
	public void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x0600259F RID: 9631 RVA: 0x000C8984 File Offset: 0x000C6B84
	[Token(Token = "0x600259F")]
	[Address(RVA = "0x2C8382C", Offset = "0x2C8382C", VA = "0x2C8382C")]
	public void \u0701م\u0742\u05FB()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x060025A0 RID: 9632 RVA: 0x000C89CC File Offset: 0x000C6BCC
	[Token(Token = "0x60025A0")]
	[Address(RVA = "0x2C83884", Offset = "0x2C83884", VA = "0x2C83884")]
	public void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("\n Time: ");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long ࡣ_u087F_u0651މ = 1L;
		this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x060025A1 RID: 9633 RVA: 0x000C8A28 File Offset: 0x000C6C28
	[Token(Token = "0x60025A1")]
	[Address(RVA = "0x2C839C0", Offset = "0x2C839C0", VA = "0x2C839C0")]
	public void ځޤקࠈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x060025A2 RID: 9634 RVA: 0x000C8A74 File Offset: 0x000C6C74
	[Token(Token = "0x60025A2")]
	[Address(RVA = "0x2C83AAC", Offset = "0x2C83AAC", VA = "0x2C83AAC")]
	public void ݖջࠃױ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x060025A3 RID: 9635 RVA: 0x000C8ABC File Offset: 0x000C6CBC
	[Token(Token = "0x60025A3")]
	[Address(RVA = "0x2C83B04", Offset = "0x2C83B04", VA = "0x2C83B04")]
	public void ݛ\u0599\u05C2ڒ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "User has been reported for: ";
			if ("User has been reported for: " == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "Updating Material to: ";
		if ("Updating Material to: " == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Thumb");
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ڳݏࡑ\u082A();
	}

	// Token: 0x060025A4 RID: 9636 RVA: 0x000C8D0C File Offset: 0x000C6F0C
	[Token(Token = "0x60025A4")]
	[Address(RVA = "0x2C84000", Offset = "0x2C84000", VA = "0x2C84000")]
	public void \u0654ޛ\u07FAذ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		Light أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "True";
			if ("True" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "ChangeMaterialToNormal";
		if ("ChangeMaterialToNormal" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("True");
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ںڈߧӪ();
	}

	// Token: 0x060025A5 RID: 9637 RVA: 0x000C8F4C File Offset: 0x000C714C
	[Token(Token = "0x60025A5")]
	[Address(RVA = "0x2C844F0", Offset = "0x2C844F0", VA = "0x2C844F0")]
	public void \u06E7ذ\u07A9\u081C()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x060025A6 RID: 9638 RVA: 0x000C8FAC File Offset: 0x000C71AC
	[Token(Token = "0x60025A6")]
	[Address(RVA = "0x2C7CF4C", Offset = "0x2C7CF4C", VA = "0x2C7CF4C")]
	public void ډ\u06EB\u07EFڒ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x060025A7 RID: 9639 RVA: 0x000C900C File Offset: 0x000C720C
	[Token(Token = "0x60025A7")]
	[Address(RVA = "0x2C84578", Offset = "0x2C84578", VA = "0x2C84578")]
	public void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x060025A8 RID: 9640 RVA: 0x000C9058 File Offset: 0x000C7258
	[Token(Token = "0x60025A8")]
	[Address(RVA = "0x2C84664", Offset = "0x2C84664", VA = "0x2C84664")]
	public WatchBatteryManager()
	{
	}

	// Token: 0x060025A9 RID: 9641 RVA: 0x000C908C File Offset: 0x000C728C
	[Token(Token = "0x60025A9")]
	[Address(RVA = "0x2C7E4E8", Offset = "0x2C7E4E8", VA = "0x2C7E4E8")]
	public void Ԇݎӗܠ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x060025AA RID: 9642 RVA: 0x000C90EC File Offset: 0x000C72EC
	[Token(Token = "0x60025AA")]
	[Address(RVA = "0x2C7F58C", Offset = "0x2C7F58C", VA = "0x2C7F58C")]
	public void ӝݞޗק()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x060025AB RID: 9643 RVA: 0x000C914C File Offset: 0x000C734C
	[Token(Token = "0x60025AB")]
	[Address(RVA = "0x2C84684", Offset = "0x2C84684", VA = "0x2C84684")]
	public void \u081FԘں\u07B2(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("HandR");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x060025AC RID: 9644 RVA: 0x000C91A0 File Offset: 0x000C73A0
	[Token(Token = "0x60025AC")]
	[Address(RVA = "0x2C847BC", Offset = "0x2C847BC", VA = "0x2C847BC")]
	public void ة\u066Dࡏԫ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log(" and for the price of ");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long ࡣ_u087F_u0651މ = 1L;
		this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x060025AD RID: 9645 RVA: 0x000C91FC File Offset: 0x000C73FC
	[Token(Token = "0x60025AD")]
	[Address(RVA = "0x2C848F8", Offset = "0x2C848F8", VA = "0x2C848F8")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("PlayerHead");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x060025AE RID: 9646 RVA: 0x000C9250 File Offset: 0x000C7450
	[Token(Token = "0x60025AE")]
	[Address(RVA = "0x2C84A30", Offset = "0x2C84A30", VA = "0x2C84A30")]
	public void \u0879\u0748ߙݥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x060025AF RID: 9647 RVA: 0x000C9290 File Offset: 0x000C7490
	[Token(Token = "0x60025AF")]
	[Address(RVA = "0x2C84B18", Offset = "0x2C84B18", VA = "0x2C84B18")]
	public void \u0838ӆڛӑ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "BN";
			if ("BN" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "ChangeToRegular";
		if ("ChangeToRegular" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Muted");
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ذۈ\u07F4\u07EC();
	}

	// Token: 0x060025B0 RID: 9648 RVA: 0x000C94E0 File Offset: 0x000C76E0
	[Token(Token = "0x60025B0")]
	[Address(RVA = "0x2C85018", Offset = "0x2C85018", VA = "0x2C85018")]
	public void ژךՈ\u0597()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "isLava";
			if ("isLava" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "ENABLE";
		if ("ENABLE" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("username");
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ڳݏࡑ\u082A();
	}

	// Token: 0x060025B1 RID: 9649 RVA: 0x000C9730 File Offset: 0x000C7930
	[Token(Token = "0x60025B1")]
	[Address(RVA = "0x2C85514", Offset = "0x2C85514", VA = "0x2C85514")]
	public void ԹԀݰࡧ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 1L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x060025B2 RID: 9650 RVA: 0x000C9778 File Offset: 0x000C7978
	[Token(Token = "0x60025B2")]
	[Address(RVA = "0x2C8556C", Offset = "0x2C8556C", VA = "0x2C8556C")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("isLava");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long ࡣ_u087F_u0651މ = 1L;
		this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x060025B3 RID: 9651 RVA: 0x000C97D4 File Offset: 0x000C79D4
	[Token(Token = "0x60025B3")]
	[Address(RVA = "0x2C856A8", Offset = "0x2C856A8", VA = "0x2C856A8")]
	public void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long u05EEࢶ_u0655ێ = 1L;
		this.\u05EEࢶ\u0655ێ = (u05EEࢶ_u0655ێ != 0L);
		long active = 0L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Stop();
	}

	// Token: 0x060025B4 RID: 9652 RVA: 0x000C9820 File Offset: 0x000C7A20
	[Token(Token = "0x60025B4")]
	[Address(RVA = "0x2C85794", Offset = "0x2C85794", VA = "0x2C85794")]
	public void ݓڐ٦Ӻ()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 1L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
		bool isPlaying = this.ࡐݸص٠.isPlaying;
	}

	// Token: 0x060025B5 RID: 9653 RVA: 0x000C9880 File Offset: 0x000C7A80
	[Token(Token = "0x60025B5")]
	[Address(RVA = "0x2C81A10", Offset = "0x2C81A10", VA = "0x2C81A10")]
	public void \u0736Ӥԋ\u0607()
	{
		GameObject gameObject = this.ߙԩӗࡩ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject ܗ_u083Cݰߡ = this.ܗ\u083Cݰߡ;
		long active2 = 0L;
		ܗ_u083Cݰߡ.SetActive(active2 != 0L);
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long active3 = 0L;
		թ_u06DFأר.SetActive(active3 != 0L);
	}

	// Token: 0x060025B6 RID: 9654 RVA: 0x000C98C8 File Offset: 0x000C7AC8
	[Token(Token = "0x60025B6")]
	[Address(RVA = "0x2C8581C", Offset = "0x2C8581C", VA = "0x2C8581C")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<Charger>();
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
		GameObject թ_u06DFأר = this.Թ\u06DFأר;
		long ࡣ_u087F_u0651މ = 1L;
		this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		long active = 1L;
		թ_u06DFأר.SetActive(active != 0L);
		this.ک\u058Eս\u05EC.Play();
	}

	// Token: 0x060025B7 RID: 9655 RVA: 0x000C9924 File Offset: 0x000C7B24
	[Token(Token = "0x60025B7")]
	[Address(RVA = "0x2C85958", Offset = "0x2C85958", VA = "0x2C85958")]
	public void \u05C4ݳ\u05BCࡂ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
		this.\u05A1ڏ\u059B\u0890 = u05EEݠ_u05FFը;
		Light ڸޢޝ_u05B;
		this.ڸޢޝ\u05B2 = ڸޢޝ_u05B;
		float ࡈࠁ_u055Dӊ = this.ࡈࠁ\u055Dӊ;
		VolumetricLightBeam أ_u085DڌԺ;
		this.أ\u085DڌԺ = أ_u085DڌԺ;
		Image ޢԞ_u061B_u081A = this.ޢԞ\u061B\u081A;
		float ࡈࠁ_u055Dӊ2 = this.ࡈࠁ\u055Dӊ;
		float ࡈࠁ_u055Dӊ3 = this.ࡈࠁ\u055Dӊ;
		Light ڸޢޝ_u05B2 = this.ڸޢޝ\u05B2;
		float intensity = ڸޢޝ_u05B2.intensity;
		float deltaTime = Time.deltaTime;
		ڸޢޝ_u05B2.intensity = deltaTime;
		bool u05EEࢶ_u0655ێ = this.\u05EEࢶ\u0655ێ;
		float ࡈࠁ_u055Dӊ4 = this.ࡈࠁ\u055Dӊ;
		float r;
		if (u05EEࢶ_u0655ێ)
		{
			float ࡃ_u0827ݯ_u = this.ࡃ\u0827ݯ\u0606;
			Light ڸޢޝ_u05B3 = this.ڸޢޝ\u05B2;
			this.ࡈࠁ\u055Dӊ = ࡈࠁ_u055Dӊ3;
			bool flag = ڸޢޝ_u05B3.gameObject.name == "True";
			if ("True" == null)
			{
			}
			bool inRoom2 = PhotonNetwork.InRoom;
			Light ڸޢޝ_u05B4 = this.ڸޢޝ\u05B2;
			float intensity2 = ڸޢޝ_u05B4.intensity;
			float ࡃ_u0827ݯ_u2 = this.ࡃ\u0827ݯ\u0606;
			float intensity3;
			ڸޢޝ_u05B4.intensity = intensity3;
			Image ޢԞ_u061B_u081A2 = this.ޢԞ\u061B\u081A;
			float b = this.\u06D8\u07EFߜ\u0833.b;
			float a = this.\u06D8\u07EFߜ\u0833.a;
			r = this.\u06D8\u07EFߜ\u0833.r;
			float g = this.\u06D8\u07EFߜ\u0833.g;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light ڸޢޝ_u05B5 = this.ڸޢޝ\u05B2;
		this.ࡈࠁ\u055Dӊ = r;
		bool flag2 = ڸޢޝ_u05B5.gameObject.name == "EnableCosmetic";
		if ("EnableCosmetic" == null)
		{
		}
		bool inRoom3 = PhotonNetwork.InRoom;
		Light ڸޢޝ_u05B6 = this.ڸޢޝ\u05B2;
		float ࡈࠁ_u055Dӊ5 = this.ࡈࠁ\u055Dӊ;
		ڸޢޝ_u05B6.intensity = deltaTime3;
		Image ޢԞ_u061B_u081A3 = this.ޢԞ\u061B\u081A;
		float b2 = this.ט\u05F7ݔ\u07F4.b;
		float a2 = this.ט\u05F7ݔ\u07F4.a;
		float r2 = this.ט\u05F7ݔ\u07F4.r;
		float g2 = this.ט\u05F7ݔ\u07F4.g;
		float deltaTime4 = Time.deltaTime;
		float ࡈࠁ_u055Dӊ6 = this.ࡈࠁ\u055Dӊ;
		this.ک\u058Eս\u05EC.Stop();
		if (!this.ࡣ\u087F\u0651މ)
		{
			this.ۋࠎӖހ.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("/");
			long ࡣ_u087F_u0651މ = 1L;
			this.ࡣ\u087F\u0651މ = (ࡣ_u087F_u0651މ != 0L);
		}
		float ࡈࠁ_u055Dӊ7 = this.ࡈࠁ\u055Dӊ;
		this.ӝݞޗק();
	}

	// Token: 0x040004A1 RID: 1185
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004A1")]
	public float ࡈࠁ\u055Dӊ = (float)17076;

	// Token: 0x040004A2 RID: 1186
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40004A2")]
	public bool \u05EEࢶ\u0655ێ;

	// Token: 0x040004A3 RID: 1187
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004A3")]
	public float ࡃ\u0827ݯ\u0606;

	// Token: 0x040004A4 RID: 1188
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40004A4")]
	public GameObject ߙԩӗࡩ;

	// Token: 0x040004A5 RID: 1189
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40004A5")]
	public GameObject ܗ\u083Cݰߡ;

	// Token: 0x040004A6 RID: 1190
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40004A6")]
	public float ࡖӜ\u0818Ք = (float)16704;

	// Token: 0x040004A7 RID: 1191
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40004A7")]
	public AudioSource ک\u058Eս\u05EC;

	// Token: 0x040004A8 RID: 1192
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40004A8")]
	public AudioSource ۋࠎӖހ;

	// Token: 0x040004A9 RID: 1193
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40004A9")]
	public AudioSource ࡐݸص٠;

	// Token: 0x040004AA RID: 1194
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40004AA")]
	public GameObject Թ\u06DFأר;

	// Token: 0x040004AB RID: 1195
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x40004AB")]
	private bool ࡣ\u087F\u0651މ;

	// Token: 0x040004AC RID: 1196
	[FieldOffset(Offset = "0x61")]
	[Token(Token = "0x40004AC")]
	private bool ݢ\u064E\u0822\u05B7;

	// Token: 0x040004AD RID: 1197
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x40004AD")]
	private Light ڸޢޝ\u05B2;

	// Token: 0x040004AE RID: 1198
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x40004AE")]
	private VolumetricLightBeam أ\u085DڌԺ;

	// Token: 0x040004AF RID: 1199
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x40004AF")]
	public NetworkPlayerSpawner ݺ\u05F9פݵ;

	// Token: 0x040004B0 RID: 1200
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x40004B0")]
	private GameObject \u05A1ڏ\u059B\u0890;

	// Token: 0x040004B1 RID: 1201
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x40004B1")]
	[Space]
	public Image ޢԞ\u061B\u081A;

	// Token: 0x040004B2 RID: 1202
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x40004B2")]
	private float ۲ԨՈ\u065F;

	// Token: 0x040004B3 RID: 1203
	[FieldOffset(Offset = "0x94")]
	[Token(Token = "0x40004B3")]
	private float ߟ١չ߇ = (float)17096;

	// Token: 0x040004B4 RID: 1204
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x40004B4")]
	public Color \u06D8\u07EFߜ\u0833;

	// Token: 0x040004B5 RID: 1205
	[FieldOffset(Offset = "0xA8")]
	[Token(Token = "0x40004B5")]
	public Color ט\u05F7ݔ\u07F4;
}
