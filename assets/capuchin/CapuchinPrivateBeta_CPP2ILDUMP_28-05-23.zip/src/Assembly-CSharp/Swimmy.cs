﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000042 RID: 66
[Token(Token = "0x2000042")]
public class Swimmy : MonoBehaviour
{
	// Token: 0x06000906 RID: 2310 RVA: 0x00031C38 File Offset: 0x0002FE38
	[Token(Token = "0x6000906")]
	[Address(RVA = "0x2F7B038", Offset = "0x2F7B038", VA = "0x2F7B038")]
	private void \u0887ࡒ\u0613\u07B8()
	{
		if (!true)
		{
		}
		float տݻ_u05A7ࡧ = this.տݻ\u05A7ࡧ;
		float ԥӿնӲ = this.ԤӿնӲ;
		Rigidbody u05A9_u0820ӗ_u = this.\u05A9\u0820ӗ\u0820;
		float x = this.ࠍ\u07FEݽ\u070C.x;
		float u059Bٻڤ_u082E = this.\u059Bٻڤ\u082E;
		float z = this.\u089F\u06DCՐࡐ.z;
	}

	// Token: 0x06000907 RID: 2311 RVA: 0x00031C88 File Offset: 0x0002FE88
	[Token(Token = "0x6000907")]
	[Address(RVA = "0x2F7B19C", Offset = "0x2F7B19C", VA = "0x2F7B19C")]
	private void ݸԲ\u0616Ԫ()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000908 RID: 2312 RVA: 0x00031CC8 File Offset: 0x0002FEC8
	[Token(Token = "0x6000908")]
	[Address(RVA = "0x2F7B1D8", Offset = "0x2F7B1D8", VA = "0x2F7B1D8")]
	private void ןأ\u05C0ب()
	{
		if (!true)
		{
		}
		float տݻ_u05A7ࡧ = this.տݻ\u05A7ࡧ;
		float ԥӿնӲ = this.ԤӿնӲ;
		Rigidbody u05A9_u0820ӗ_u = this.\u05A9\u0820ӗ\u0820;
		float x = this.ࠍ\u07FEݽ\u070C.x;
		float u059Bٻڤ_u082E = this.\u059Bٻڤ\u082E;
		float z = this.ࠍ\u07FEݽ\u070C.z;
		float z2 = this.\u089F\u06DCՐࡐ.z;
	}

	// Token: 0x06000909 RID: 2313 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000909")]
	[Address(RVA = "0x2F7B33C", Offset = "0x2F7B33C", VA = "0x2F7B33C")]
	public void ߒࠅߝ۹()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600090A RID: 2314 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600090A")]
	[Address(RVA = "0x2F7B438", Offset = "0x2F7B438", VA = "0x2F7B438")]
	public void \u0559\u05FEפ\u05CD()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600090B RID: 2315 RVA: 0x00031D28 File Offset: 0x0002FF28
	[Token(Token = "0x600090B")]
	[Address(RVA = "0x2F7B54C", Offset = "0x2F7B54C", VA = "0x2F7B54C")]
	private void \u06EDٵ۶\u06DB()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600090C RID: 2316 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600090C")]
	[Address(RVA = "0x2F7B588", Offset = "0x2F7B588", VA = "0x2F7B588")]
	public void \u0607\u0747\u058Aף()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600090D RID: 2317 RVA: 0x00031D68 File Offset: 0x0002FF68
	[Token(Token = "0x600090D")]
	[Address(RVA = "0x2F7B684", Offset = "0x2F7B684", VA = "0x2F7B684")]
	private void ࡩݮڢՠ()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600090E RID: 2318 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600090E")]
	[Address(RVA = "0x2F7B6C0", Offset = "0x2F7B6C0", VA = "0x2F7B6C0")]
	public void Ԁ\u05EB\u085Eՠ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600090F RID: 2319 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600090F")]
	[Address(RVA = "0x2F7B7BC", Offset = "0x2F7B7BC", VA = "0x2F7B7BC")]
	public void Ԯԇݯԃ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000910 RID: 2320 RVA: 0x00031DA8 File Offset: 0x0002FFA8
	[Token(Token = "0x6000910")]
	[Address(RVA = "0x2F7B8C4", Offset = "0x2F7B8C4", VA = "0x2F7B8C4")]
	public void \u06DEԍӂս()
	{
		ThrowHelper.ThrowArgumentOutOfRangeException();
	}

	// Token: 0x06000911 RID: 2321 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000911")]
	[Address(RVA = "0x2F7B9CC", Offset = "0x2F7B9CC", VA = "0x2F7B9CC")]
	public void \u0747ݦޖݔ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000912 RID: 2322 RVA: 0x00031DC4 File Offset: 0x0002FFC4
	[Token(Token = "0x6000912")]
	[Address(RVA = "0x2F7BAD4", Offset = "0x2F7BAD4", VA = "0x2F7BAD4")]
	private void ݤۅࢦӃ()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.өՆԉ\u065C = deviceAtXRNode;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000913 RID: 2323 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000913")]
	[Address(RVA = "0x2F7BB10", Offset = "0x2F7BB10", VA = "0x2F7BB10")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000914 RID: 2324 RVA: 0x00031E08 File Offset: 0x00030008
	[Token(Token = "0x6000914")]
	[Address(RVA = "0x2F7BC0C", Offset = "0x2F7BC0C", VA = "0x2F7BC0C")]
	private void \u07AAح\u087Fܩ()
	{
		if (!true)
		{
		}
		float տݻ_u05A7ࡧ = this.տݻ\u05A7ࡧ;
		float ԥӿնӲ = this.ԤӿնӲ;
		Rigidbody u05A9_u0820ӗ_u = this.\u05A9\u0820ӗ\u0820;
		float x = this.ࠍ\u07FEݽ\u070C.x;
		float u059Bٻڤ_u082E = this.\u059Bٻڤ\u082E;
		float z = this.\u089F\u06DCՐࡐ.z;
	}

	// Token: 0x06000915 RID: 2325 RVA: 0x00031E58 File Offset: 0x00030058
	[Token(Token = "0x6000915")]
	[Address(RVA = "0x2F7BD70", Offset = "0x2F7BD70", VA = "0x2F7BD70")]
	private void \u073BօӁ\u059A()
	{
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		long initialized = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized != 0L);
	}

	// Token: 0x06000916 RID: 2326 RVA: 0x00031E88 File Offset: 0x00030088
	[Token(Token = "0x6000916")]
	[Address(RVA = "0x2F7BDAC", Offset = "0x2F7BDAC", VA = "0x2F7BDAC")]
	public Swimmy()
	{
	}

	// Token: 0x06000917 RID: 2327 RVA: 0x00031E9C File Offset: 0x0003009C
	[Token(Token = "0x6000917")]
	[Address(RVA = "0x2F7BDB4", Offset = "0x2F7BDB4", VA = "0x2F7BDB4")]
	private void ۮߝڪڐ()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000918 RID: 2328 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000918")]
	[Address(RVA = "0x2F7BDF0", Offset = "0x2F7BDF0", VA = "0x2F7BDF0")]
	public void ӣՃ\u07FAԟ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000919 RID: 2329 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000919")]
	[Address(RVA = "0x2F7BEEC", Offset = "0x2F7BEEC", VA = "0x2F7BEEC")]
	public void \u05A1ߡࡅࢮ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600091A RID: 2330 RVA: 0x00031EDC File Offset: 0x000300DC
	[Token(Token = "0x600091A")]
	[Address(RVA = "0x2F7BFE8", Offset = "0x2F7BFE8", VA = "0x2F7BFE8")]
	private void \u05ABݿࡋ\u06E9()
	{
		long initialized = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.\u05BFڥ\u0596ࡏ = deviceAtXRNode;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode2 = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.өՆԉ\u065C = deviceAtXRNode2;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600091B RID: 2331 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600091B")]
	[Address(RVA = "0x2F7C024", Offset = "0x2F7C024", VA = "0x2F7C024")]
	public void ӀԹ\u06DA\u05C5()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600091C RID: 2332 RVA: 0x00031F24 File Offset: 0x00030124
	[Token(Token = "0x600091C")]
	[Address(RVA = "0x2F7C12C", Offset = "0x2F7C12C", VA = "0x2F7C12C")]
	private void ࡅݐ\u082Dք()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600091D RID: 2333 RVA: 0x00031F64 File Offset: 0x00030164
	[Token(Token = "0x600091D")]
	[Address(RVA = "0x2F7C168", Offset = "0x2F7C168", VA = "0x2F7C168")]
	private void FixedUpdate()
	{
		if (!true)
		{
		}
		float տݻ_u05A7ࡧ = this.տݻ\u05A7ࡧ;
		float ԥӿնӲ = this.ԤӿնӲ;
		Rigidbody u05A9_u0820ӗ_u = this.\u05A9\u0820ӗ\u0820;
		float x = this.ࠍ\u07FEݽ\u070C.x;
		float u059Bٻڤ_u082E = this.\u059Bٻڤ\u082E;
		float z = this.ࠍ\u07FEݽ\u070C.z;
		float z2 = this.\u089F\u06DCՐࡐ.z;
	}

	// Token: 0x0600091E RID: 2334 RVA: 0x00031FC4 File Offset: 0x000301C4
	[Token(Token = "0x600091E")]
	[Address(RVA = "0x2F7C2CC", Offset = "0x2F7C2CC", VA = "0x2F7C2CC")]
	private void Start()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.өՆԉ\u065C = deviceAtXRNode;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600091F RID: 2335 RVA: 0x00032008 File Offset: 0x00030208
	[Token(Token = "0x600091F")]
	[Address(RVA = "0x2F7C308", Offset = "0x2F7C308", VA = "0x2F7C308")]
	private void ם\u06FDւԋ()
	{
		if (!true)
		{
		}
		float տݻ_u05A7ࡧ = this.տݻ\u05A7ࡧ;
		float ԥӿնӲ = this.ԤӿնӲ;
		Rigidbody u05A9_u0820ӗ_u = this.\u05A9\u0820ӗ\u0820;
		float x = this.ࠍ\u07FEݽ\u070C.x;
		float u059Bٻڤ_u082E = this.\u059Bٻڤ\u082E;
		float z = this.ࠍ\u07FEݽ\u070C.z;
		float z2 = this.\u089F\u06DCՐࡐ.z;
	}

	// Token: 0x06000920 RID: 2336 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000920")]
	[Address(RVA = "0x2F7C46C", Offset = "0x2F7C46C", VA = "0x2F7C46C")]
	public void ԛ\u07EFӶ\u065A()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000921 RID: 2337 RVA: 0x00032068 File Offset: 0x00030268
	[Token(Token = "0x6000921")]
	[Address(RVA = "0x2F7C574", Offset = "0x2F7C574", VA = "0x2F7C574")]
	private void ࡇ\u0559یՒ()
	{
		if (!true)
		{
		}
		float տݻ_u05A7ࡧ = this.տݻ\u05A7ࡧ;
		float ԥӿնӲ = this.ԤӿնӲ;
		Rigidbody u05A9_u0820ӗ_u = this.\u05A9\u0820ӗ\u0820;
		float x = this.ࠍ\u07FEݽ\u070C.x;
		float u059Bٻڤ_u082E = this.\u059Bٻڤ\u082E;
		float z = this.ࠍ\u07FEݽ\u070C.z;
		float z2 = this.\u089F\u06DCՐࡐ.z;
	}

	// Token: 0x06000922 RID: 2338 RVA: 0x000320C8 File Offset: 0x000302C8
	[Token(Token = "0x6000922")]
	[Address(RVA = "0x2F7C6D8", Offset = "0x2F7C6D8", VA = "0x2F7C6D8")]
	private void \u0890ؤߪފ()
	{
		if (!true)
		{
		}
		float տݻ_u05A7ࡧ = this.տݻ\u05A7ࡧ;
		float ԥӿնӲ = this.ԤӿնӲ;
		Rigidbody u05A9_u0820ӗ_u = this.\u05A9\u0820ӗ\u0820;
		float x = this.ࠍ\u07FEݽ\u070C.x;
		float u059Bٻڤ_u082E = this.\u059Bٻڤ\u082E;
		float z = this.ࠍ\u07FEݽ\u070C.z;
		float z2 = this.\u089F\u06DCՐࡐ.z;
	}

	// Token: 0x06000923 RID: 2339 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000923")]
	[Address(RVA = "0x2F7C83C", Offset = "0x2F7C83C", VA = "0x2F7C83C")]
	public void րࢢ\u0830Ӥ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000924 RID: 2340 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000924")]
	[Address(RVA = "0x2F7C938", Offset = "0x2F7C938", VA = "0x2F7C938")]
	public void ה\u07F4Ց\u0889()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000925 RID: 2341 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000925")]
	[Address(RVA = "0x2F7CA4C", Offset = "0x2F7CA4C", VA = "0x2F7CA4C")]
	public void \u064Dۿ\u07BB\u05C0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000926 RID: 2342 RVA: 0x00032128 File Offset: 0x00030328
	[Token(Token = "0x6000926")]
	[Address(RVA = "0x2F7CB48", Offset = "0x2F7CB48", VA = "0x2F7CB48")]
	private void Ԧ\u0876ծՎ()
	{
		if (!true)
		{
		}
		float տݻ_u05A7ࡧ = this.տݻ\u05A7ࡧ;
		float ԥӿնӲ = this.ԤӿնӲ;
		Rigidbody u05A9_u0820ӗ_u = this.\u05A9\u0820ӗ\u0820;
		float x = this.ࠍ\u07FEݽ\u070C.x;
		float u059Bٻڤ_u082E = this.\u059Bٻڤ\u082E;
		float z = this.ࠍ\u07FEݽ\u070C.z;
		float z2 = this.\u089F\u06DCՐࡐ.z;
	}

	// Token: 0x06000927 RID: 2343 RVA: 0x00032188 File Offset: 0x00030388
	[Token(Token = "0x6000927")]
	[Address(RVA = "0x2F7CCAC", Offset = "0x2F7CCAC", VA = "0x2F7CCAC")]
	private void ߒ\u065EՎࡖ()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000928 RID: 2344 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000928")]
	[Address(RVA = "0x2F7CCE8", Offset = "0x2F7CCE8", VA = "0x2F7CCE8")]
	public void ےؠպ\u05FC()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0400013C RID: 316
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400013C")]
	private InputDevice \u05BFڥ\u0596ࡏ;

	// Token: 0x0400013D RID: 317
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400013D")]
	private InputDevice өՆԉ\u065C;

	// Token: 0x0400013E RID: 318
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400013E")]
	public Vector3 ࠍ\u07FEݽ\u070C;

	// Token: 0x0400013F RID: 319
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x400013F")]
	public Vector3 \u089F\u06DCՐࡐ;

	// Token: 0x04000140 RID: 320
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000140")]
	private InputDevice ڵ\u05A3\u0894ࠑ;

	// Token: 0x04000141 RID: 321
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000141")]
	private InputDevice ݙޢغކ;

	// Token: 0x04000142 RID: 322
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000142")]
	public Rigidbody \u05A9\u0820ӗ\u0820;

	// Token: 0x04000143 RID: 323
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000143")]
	public float տݻ\u05A7ࡧ;

	// Token: 0x04000144 RID: 324
	[FieldOffset(Offset = "0x7C")]
	[Token(Token = "0x4000144")]
	public float ԤӿնӲ;

	// Token: 0x04000145 RID: 325
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4000145")]
	public float ߂ؽڵ\u07B9;

	// Token: 0x04000146 RID: 326
	[FieldOffset(Offset = "0x84")]
	[Token(Token = "0x4000146")]
	public float \u059Bٻڤ\u082E;
}
