﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Rendering;

// Token: 0x020000F3 RID: 243
[Token(Token = "0x20000F3")]
public class WeatherCycle : MonoBehaviour
{
	// Token: 0x060025B8 RID: 9656 RVA: 0x000C9B7C File Offset: 0x000C7D7C
	[Token(Token = "0x60025B8")]
	[Address(RVA = "0x2DCFE7C", Offset = "0x2DCFE7C", VA = "0x2DCFE7C")]
	public void \u0707߇\u070C\u0590()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Cheating", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025B9 RID: 9657 RVA: 0x000C9CF8 File Offset: 0x000C7EF8
	[Token(Token = "0x60025B9")]
	[Address(RVA = "0x2DD0064", Offset = "0x2DD0064", VA = "0x2DD0064")]
	public void \u0599\u0881ւף()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x060025BA RID: 9658 RVA: 0x000C9E80 File Offset: 0x000C8080
	[Token(Token = "0x60025BA")]
	[Address(RVA = "0x2DD0250", Offset = "0x2DD0250", VA = "0x2DD0250")]
	private void Ӕ\u066D߂\u0877()
	{
		Color fogColor = RenderSettings.fogColor;
		Color fogColor2;
		RenderSettings.fogColor = fogColor2;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 16384;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Is Colliding", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 32768;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025BB RID: 9659 RVA: 0x000CA0C0 File Offset: 0x000C82C0
	[Token(Token = "0x60025BB")]
	[Address(RVA = "0x2DD0618", Offset = "0x2DD0618", VA = "0x2DD0618")]
	public void ࠈݪӃ\u065F()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float deltaTime4 = Time.deltaTime;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x060025BC RID: 9660 RVA: 0x000CA138 File Offset: 0x000C8338
	[Token(Token = "0x60025BC")]
	[Address(RVA = "0x2DD0808", Offset = "0x2DD0808", VA = "0x2DD0808")]
	public void ۺ\u05B0ۻ\u0618()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025BD RID: 9661 RVA: 0x000CA2AC File Offset: 0x000C84AC
	[Token(Token = "0x60025BD")]
	[Address(RVA = "0x2DD09F0", Offset = "0x2DD09F0", VA = "0x2DD09F0")]
	public void Ӭ\u083D\u0731ا()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 17458;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("ORGTARG", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17232;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025BE RID: 9662 RVA: 0x000CA4EC File Offset: 0x000C86EC
	[Token(Token = "0x60025BE")]
	[Address(RVA = "0x2DD0DA8", Offset = "0x2DD0DA8", VA = "0x2DD0DA8")]
	public void ԣ\u0731\u0879ܕ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Vector1_d371bd24217449349bd747533d51af6b");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("FingerTip");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("Updating Material to: ");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("BLUTARG");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x060025BF RID: 9663 RVA: 0x000CA7CC File Offset: 0x000C89CC
	[Token(Token = "0x60025BF")]
	[Address(RVA = "0x2DD10F0", Offset = "0x2DD10F0", VA = "0x2DD10F0")]
	public void ڌӬ\u088C\u087B()
	{
		while (!true)
		{
		}
		LightmapData lightmapData = new LightmapData();
		LightmapData[] lightmaps = LightmapSettings.lightmaps;
		if (lightmapData == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (lightmaps.m_Dir != null)
		{
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
	}

	// Token: 0x060025C0 RID: 9664 RVA: 0x000CA854 File Offset: 0x000C8A54
	[Token(Token = "0x60025C0")]
	[Address(RVA = "0x2DD1428", Offset = "0x2DD1428", VA = "0x2DD1428")]
	private void ײԶ\u089Bם()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025C1 RID: 9665 RVA: 0x000CA870 File Offset: 0x000C8A70
	[Token(Token = "0x60025C1")]
	[Address(RVA = "0x2DD1528", Offset = "0x2DD1528", VA = "0x2DD1528")]
	public void \u0600\u05A6ࡂࡇ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Player", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025C2 RID: 9666 RVA: 0x000CA9EC File Offset: 0x000C8BEC
	[Token(Token = "0x60025C2")]
	[Address(RVA = "0x2DD1710", Offset = "0x2DD1710", VA = "0x2DD1710")]
	public void Ԡכࠃݸ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("false", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025C3 RID: 9667 RVA: 0x000CAB68 File Offset: 0x000C8D68
	[Token(Token = "0x60025C3")]
	[Address(RVA = "0x2DD18FC", Offset = "0x2DD18FC", VA = "0x2DD18FC")]
	private void ݺՠࢱ\u0708()
	{
		Color fogColor = RenderSettings.fogColor;
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 32768;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Universal Render Pipeline/Lit", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17070;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025C4 RID: 9668 RVA: 0x000CADA8 File Offset: 0x000C8FA8
	[Token(Token = "0x60025C4")]
	[Address(RVA = "0x2DD1CC0", Offset = "0x2DD1CC0", VA = "0x2DD1CC0")]
	private void բ\u06EB\u0602Ӑ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025C5 RID: 9669 RVA: 0x000CADC4 File Offset: 0x000C8FC4
	[Token(Token = "0x60025C5")]
	[Address(RVA = "0x2DD1DC0", Offset = "0x2DD1DC0", VA = "0x2DD1DC0")]
	public void ضקڙࢤ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 40960;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Player", value);
		AudioSource ڞه_u0749_u089D;
		if (this.ӻهࡀ\u05C1)
		{
			ڞه_u0749_u089D = this.ڞه\u0749\u089D;
			ڞه_u0749_u089D.Play();
		}
		AudioSource ڞه_u0749_u089D2 = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		ڞه_u0749_u089D2.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17653;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025C6 RID: 9670 RVA: 0x000CAFFC File Offset: 0x000C91FC
	[Token(Token = "0x60025C6")]
	[Address(RVA = "0x2DD2178", Offset = "0x2DD2178", VA = "0x2DD2178")]
	private void ٨\u06DBܐޒ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ = 8192;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Universal Render Pipeline/Lit", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17302;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025C7 RID: 9671 RVA: 0x000CB23C File Offset: 0x000C943C
	[Token(Token = "0x60025C7")]
	[Address(RVA = "0x2DD2538", Offset = "0x2DD2538", VA = "0x2DD2538")]
	private void ل\u055B\u0828ࢱ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025C8 RID: 9672 RVA: 0x000CB258 File Offset: 0x000C9458
	[Token(Token = "0x60025C8")]
	[Address(RVA = "0x2DD2638", Offset = "0x2DD2638", VA = "0x2DD2638")]
	public void \u06E4\u055A\u0893\u0888()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Right Hand", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025C9 RID: 9673 RVA: 0x000CB3C8 File Offset: 0x000C95C8
	[Token(Token = "0x60025C9")]
	[Address(RVA = "0x2DD2824", Offset = "0x2DD2824", VA = "0x2DD2824")]
	public void ߁Շݥ\u082E()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Players: ");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("TurnAmount");
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r2 = this.\u0870ࠅ\u089Bߕ.r;
			float g2 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("username");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r6 = this.\u0610ݫӕ\u06DF.r;
		float g6 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("containsStaff");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x060025CA RID: 9674 RVA: 0x000CB690 File Offset: 0x000C9890
	[Token(Token = "0x60025CA")]
	[Address(RVA = "0x2DD2B60", Offset = "0x2DD2B60", VA = "0x2DD2B60")]
	private void ࡇ\u0530ڱԜ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 32768;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("This is the 2500 Bananas button, and it was just clicked", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17474;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025CB RID: 9675 RVA: 0x000CB8D0 File Offset: 0x000C9AD0
	[Token(Token = "0x60025CB")]
	[Address(RVA = "0x2DD2F24", Offset = "0x2DD2F24", VA = "0x2DD2F24")]
	public void ԩߊ۶ն()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("StartGamemode");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Date: ");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("sound play play");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b6 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Found Gameobject: ");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x060025CC RID: 9676 RVA: 0x000CBB98 File Offset: 0x000C9D98
	[Token(Token = "0x60025CC")]
	[Address(RVA = "0x2DD3270", Offset = "0x2DD3270", VA = "0x2DD3270")]
	private void ܖ\u0894ؿ\u05FE()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 17215;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Vertical", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 32768;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025CD RID: 9677 RVA: 0x000CBDE4 File Offset: 0x000C9FE4
	[Token(Token = "0x60025CD")]
	[Address(RVA = "0x2DD3634", Offset = "0x2DD3634", VA = "0x2DD3634")]
	private void ӳӥ\u0821\u06DB()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025CE RID: 9678 RVA: 0x000CBE00 File Offset: 0x000CA000
	[Token(Token = "0x60025CE")]
	[Address(RVA = "0x2DD3734", Offset = "0x2DD3734", VA = "0x2DD3734")]
	public void ֆ\u05FBܜ\u088A()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("FingerTip", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025CF RID: 9679 RVA: 0x000CBF7C File Offset: 0x000CA17C
	[Token(Token = "0x60025CF")]
	[Address(RVA = "0x2DD391C", Offset = "0x2DD391C", VA = "0x2DD391C")]
	public void \u07B3װ\u05A9ڰ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 49152;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("ChangePlayerSize", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17319;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025D0 RID: 9680 RVA: 0x000CC1C4 File Offset: 0x000CA3C4
	[Token(Token = "0x60025D0")]
	[Address(RVA = "0x2DD3CD8", Offset = "0x2DD3CD8", VA = "0x2DD3CD8")]
	private void ذ\u07A7Ի\u061F()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 57344;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("ORGTARG", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17146;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025D1 RID: 9681 RVA: 0x000CC40C File Offset: 0x000CA60C
	[Token(Token = "0x60025D1")]
	[Address(RVA = "0x2DD4098", Offset = "0x2DD4098", VA = "0x2DD4098")]
	private void ܯӠ\u0825ࠀ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025D2 RID: 9682 RVA: 0x000CC428 File Offset: 0x000CA628
	[Token(Token = "0x60025D2")]
	[Address(RVA = "0x2DD4198", Offset = "0x2DD4198", VA = "0x2DD4198")]
	public void ۺ\u0619բӖ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 17348;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Collided", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 49152;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025D3 RID: 9683 RVA: 0x000CC674 File Offset: 0x000CA874
	[Token(Token = "0x60025D3")]
	[Address(RVA = "0x2DD4558", Offset = "0x2DD4558", VA = "0x2DD4558")]
	public void \u0558ڠ\u085Bԃ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("You have been banned for ");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("username");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Damaged Arm");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x060025D4 RID: 9684 RVA: 0x000CC954 File Offset: 0x000CAB54
	[Token(Token = "0x60025D4")]
	[Address(RVA = "0x2DD48A0", Offset = "0x2DD48A0", VA = "0x2DD48A0")]
	public void ޓרڨӅ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("closeToObject", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060025D5 RID: 9685 RVA: 0x000CCAC0 File Offset: 0x000CACC0
	[Token(Token = "0x60025D5")]
	[Address(RVA = "0x2DD4A88", Offset = "0x2DD4A88", VA = "0x2DD4A88")]
	private void կہ\u055D\u0732()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025D6 RID: 9686 RVA: 0x000CCADC File Offset: 0x000CACDC
	[Token(Token = "0x60025D6")]
	[Address(RVA = "0x2DD4B88", Offset = "0x2DD4B88", VA = "0x2DD4B88")]
	private void ࡢ\u05C4\u087Eӏ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 16384;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("You have been banned for ", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 16384;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025D7 RID: 9687 RVA: 0x000CCD28 File Offset: 0x000CAF28
	[Token(Token = "0x60025D7")]
	[Address(RVA = "0x2DD4F4C", Offset = "0x2DD4F4C", VA = "0x2DD4F4C")]
	public void \u0557\u0670ݿؤ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("DisableCosmetic", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025D8 RID: 9688 RVA: 0x000CCEA4 File Offset: 0x000CB0A4
	[Token(Token = "0x60025D8")]
	[Address(RVA = "0x2DD5138", Offset = "0x2DD5138", VA = "0x2DD5138")]
	public void ڿٽ߆\u07F6()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("FingerTip", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025D9 RID: 9689 RVA: 0x000CD020 File Offset: 0x000CB220
	[Token(Token = "0x60025D9")]
	[Address(RVA = "0x2DD5320", Offset = "0x2DD5320", VA = "0x2DD5320")]
	public void \u0736\u06E0\u06E0څ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("NetworkGunShoot");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Reason: ");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("username");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Joined a Room.");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x060025DA RID: 9690 RVA: 0x000CD2F8 File Offset: 0x000CB4F8
	[Token(Token = "0x60025DA")]
	[Address(RVA = "0x2DD5660", Offset = "0x2DD5660", VA = "0x2DD5660")]
	public void \u089Dݢڒࢨ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x060025DB RID: 9691 RVA: 0x000CD468 File Offset: 0x000CB668
	[Token(Token = "0x60025DB")]
	[Address(RVA = "0x2DD5850", Offset = "0x2DD5850", VA = "0x2DD5850")]
	private void \u05AAԣޅ\u06FE()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 32768;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat(" hours. You were banned because of ", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 49152;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025DC RID: 9692 RVA: 0x000CD6A4 File Offset: 0x000CB8A4
	[Token(Token = "0x60025DC")]
	[Address(RVA = "0x2DD5C18", Offset = "0x2DD5C18", VA = "0x2DD5C18")]
	public void ٸݴࠌ\u06E6()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("KeyPos", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025DD RID: 9693 RVA: 0x000CD820 File Offset: 0x000CBA20
	[Token(Token = "0x60025DD")]
	[Address(RVA = "0x2DD5E00", Offset = "0x2DD5E00", VA = "0x2DD5E00")]
	private void مӋٺӷ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025DE RID: 9694 RVA: 0x000CD83C File Offset: 0x000CBA3C
	[Token(Token = "0x60025DE")]
	[Address(RVA = "0x2DD5F00", Offset = "0x2DD5F00", VA = "0x2DD5F00")]
	public void ٺࢪ\u081Cع()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("A new Player joined a Room.", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025DF RID: 9695 RVA: 0x000CD9B8 File Offset: 0x000CBBB8
	[Token(Token = "0x60025DF")]
	[Address(RVA = "0x2DD60E8", Offset = "0x2DD60E8", VA = "0x2DD60E8")]
	public void ࡋՓրދ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("true", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025E0 RID: 9696 RVA: 0x000CDB34 File Offset: 0x000CBD34
	[Token(Token = "0x60025E0")]
	[Address(RVA = "0x2DD62D0", Offset = "0x2DD62D0", VA = "0x2DD62D0")]
	private void ݝ۲ނ\u06DD()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025E1 RID: 9697 RVA: 0x000CDB50 File Offset: 0x000CBD50
	[Token(Token = "0x60025E1")]
	[Address(RVA = "0x2DD63D0", Offset = "0x2DD63D0", VA = "0x2DD63D0")]
	public void \u07B6کՐ\u058B()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat(" hours. You were banned because of ", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x060025E2 RID: 9698 RVA: 0x000CDCD8 File Offset: 0x000CBED8
	[Token(Token = "0x60025E2")]
	[Address(RVA = "0x2DD65C0", Offset = "0x2DD65C0", VA = "0x2DD65C0")]
	public void \u06DEҾݩ\u0702()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Horizontal", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025E3 RID: 9699 RVA: 0x000CDE54 File Offset: 0x000CC054
	[Token(Token = "0x60025E3")]
	[Address(RVA = "0x2DD67A8", Offset = "0x2DD67A8", VA = "0x2DD67A8")]
	public void քәکҿ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 17545;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat(". Please update you game to the latest version", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 24576;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025E4 RID: 9700 RVA: 0x000CE088 File Offset: 0x000CC288
	[Token(Token = "0x60025E4")]
	[Address(RVA = "0x2DD6B60", Offset = "0x2DD6B60", VA = "0x2DD6B60")]
	public void \u06DAࢰ\u0891۲()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x060025E5 RID: 9701 RVA: 0x000CE208 File Offset: 0x000CC408
	[Token(Token = "0x60025E5")]
	[Address(RVA = "0x2DD6D50", Offset = "0x2DD6D50", VA = "0x2DD6D50")]
	public void ڏ\u066C\u055C\u06DD()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Found Gameobject: ");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("An error has occured while buying bananas, please restart your game and try again");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("META");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Added Winner Money");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x060025E6 RID: 9702 RVA: 0x000CE4E8 File Offset: 0x000CC6E8
	[Token(Token = "0x60025E6")]
	[Address(RVA = "0x2DD7098", Offset = "0x2DD7098", VA = "0x2DD7098")]
	public void \u064E\u0828ݫ\u0592()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("SetColor", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025E7 RID: 9703 RVA: 0x000CE664 File Offset: 0x000CC864
	[Token(Token = "0x60025E7")]
	[Address(RVA = "0x2DD7280", Offset = "0x2DD7280", VA = "0x2DD7280")]
	public void \u0877߈ۏ\u083E()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Diffuse");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("TurnAmount");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("_BaseMap");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x060025E8 RID: 9704 RVA: 0x000CE944 File Offset: 0x000CCB44
	[Token(Token = "0x60025E8")]
	[Address(RVA = "0x2DD75C8", Offset = "0x2DD75C8", VA = "0x2DD75C8")]
	public void ݿמ\u0557\u05B9()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 17493;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("hand 1", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 49152;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025E9 RID: 9705 RVA: 0x000CEB84 File Offset: 0x000CCD84
	[Token(Token = "0x60025E9")]
	[Address(RVA = "0x2DD7980", Offset = "0x2DD7980", VA = "0x2DD7980")]
	private void ԤԚࠇ\u05C3()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 24576;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 24576;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025EA RID: 9706 RVA: 0x000CEDC0 File Offset: 0x000CCFC0
	[Token(Token = "0x60025EA")]
	[Address(RVA = "0x2DD7D44", Offset = "0x2DD7D44", VA = "0x2DD7D44")]
	public void ݿ\u07F0\u087Fլ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("TurnAmount");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Tagging");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("{0} ({1})");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("5BN");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x060025EB RID: 9707 RVA: 0x000CF0A0 File Offset: 0x000CD2A0
	[Token(Token = "0x60025EB")]
	[Address(RVA = "0x2DD808C", Offset = "0x2DD808C", VA = "0x2DD808C")]
	public void \u0611ك\u0706\u082C()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 16384;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("typesOfTalk", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17180;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025EC RID: 9708 RVA: 0x000CF2E4 File Offset: 0x000CD4E4
	[Token(Token = "0x60025EC")]
	[Address(RVA = "0x2DD844C", Offset = "0x2DD844C", VA = "0x2DD844C")]
	private void ح\u058Dոڎ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 32768;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("PURCHASE", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17327;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025ED RID: 9709 RVA: 0x000CF4FC File Offset: 0x000CD6FC
	[Token(Token = "0x60025ED")]
	[Address(RVA = "0x2DD880C", Offset = "0x2DD880C", VA = "0x2DD880C")]
	private void \u07B6\u083Eڅ\u064C()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025EE RID: 9710 RVA: 0x000CF518 File Offset: 0x000CD718
	[Token(Token = "0x60025EE")]
	[Address(RVA = "0x2DD890C", Offset = "0x2DD890C", VA = "0x2DD890C")]
	public void ײࡂࢨ\u055D()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat(" and the correct version is ", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025EF RID: 9711 RVA: 0x000CF694 File Offset: 0x000CD894
	[Token(Token = "0x60025EF")]
	[Address(RVA = "0x2DD8AF4", Offset = "0x2DD8AF4", VA = "0x2DD8AF4")]
	private void \u059Fࠋܘࠂ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025F0 RID: 9712 RVA: 0x000CF6B0 File Offset: 0x000CD8B0
	[Token(Token = "0x60025F0")]
	[Address(RVA = "0x2DD8BF4", Offset = "0x2DD8BF4", VA = "0x2DD8BF4")]
	public void ࡑ\u05CAԴߢ()
	{
		Vector4 vector = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 24576;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("containsStaff", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 32768;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025F1 RID: 9713 RVA: 0x000CF8F4 File Offset: 0x000CDAF4
	[Token(Token = "0x60025F1")]
	[Address(RVA = "0x2DD8FB0", Offset = "0x2DD8FB0", VA = "0x2DD8FB0")]
	private void ݙࡎߣצ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025F2 RID: 9714 RVA: 0x000CF910 File Offset: 0x000CDB10
	[Token(Token = "0x60025F2")]
	[Address(RVA = "0x2DD90B0", Offset = "0x2DD90B0", VA = "0x2DD90B0")]
	public void \u064Dܚ߇\u07F7()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 16384;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("TurnAmount", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 32768;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025F3 RID: 9715 RVA: 0x000CFB50 File Offset: 0x000CDD50
	[Token(Token = "0x60025F3")]
	[Address(RVA = "0x2DD9478", Offset = "0x2DD9478", VA = "0x2DD9478")]
	public void \u06E3\u07A6ސԽ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		int u059F_u0592_u06DFࡏ2 = 49152;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("TurnAmount", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 16384;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x060025F4 RID: 9716 RVA: 0x000CFD80 File Offset: 0x000CDF80
	[Token(Token = "0x60025F4")]
	[Address(RVA = "0x2DD9838", Offset = "0x2DD9838", VA = "0x2DD9838")]
	public void ࡒ\u0608Վࠉ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("PURCHASED!", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025F5 RID: 9717 RVA: 0x000CFEEC File Offset: 0x000CE0EC
	[Token(Token = "0x60025F5")]
	[Address(RVA = "0x2DD9A24", Offset = "0x2DD9A24", VA = "0x2DD9A24")]
	private void \u058Bࠐݡծ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025F6 RID: 9718 RVA: 0x000CFF08 File Offset: 0x000CE108
	[Token(Token = "0x60025F6")]
	[Address(RVA = "0x2DD9B24", Offset = "0x2DD9B24", VA = "0x2DD9B24")]
	public void \u070B۰\u0656ծ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("closeToObject", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025F7 RID: 9719 RVA: 0x000D0084 File Offset: 0x000CE284
	[Token(Token = "0x60025F7")]
	[Address(RVA = "0x2DD9D0C", Offset = "0x2DD9D0C", VA = "0x2DD9D0C")]
	public void կߊ\u0709\u0833()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("BN", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025F8 RID: 9720 RVA: 0x000D0200 File Offset: 0x000CE400
	[Token(Token = "0x60025F8")]
	[Address(RVA = "0x2DD9EF4", Offset = "0x2DD9EF4", VA = "0x2DD9EF4")]
	public void ۼ\u058Cڄ\u06D8()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Player was caught cheating", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025F9 RID: 9721 RVA: 0x000D037C File Offset: 0x000CE57C
	[Token(Token = "0x60025F9")]
	[Address(RVA = "0x2DDA0DC", Offset = "0x2DDA0DC", VA = "0x2DDA0DC")]
	private void ܢݵړש()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025FA RID: 9722 RVA: 0x000D0398 File Offset: 0x000CE598
	[Token(Token = "0x60025FA")]
	[Address(RVA = "0x2DDA1DC", Offset = "0x2DDA1DC", VA = "0x2DDA1DC")]
	public void ٵނܠ\u082B()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("A Player has left the Room.", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025FB RID: 9723 RVA: 0x000D0508 File Offset: 0x000CE708
	[Token(Token = "0x60025FB")]
	[Address(RVA = "0x2DDA3C8", Offset = "0x2DDA3C8", VA = "0x2DDA3C8")]
	private void \u05CD\u087CՓڍ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025FC RID: 9724 RVA: 0x000D0524 File Offset: 0x000CE724
	[Token(Token = "0x60025FC")]
	[Address(RVA = "0x2DDA4C8", Offset = "0x2DDA4C8", VA = "0x2DDA4C8")]
	public void \u0874إՎ\u059A()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("\n Time: ", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060025FD RID: 9725 RVA: 0x000D06A0 File Offset: 0x000CE8A0
	[Token(Token = "0x60025FD")]
	[Address(RVA = "0x2DDA6B0", Offset = "0x2DDA6B0", VA = "0x2DDA6B0")]
	private void ܞݤ\u05B4Ӟ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x060025FE RID: 9726 RVA: 0x000D06BC File Offset: 0x000CE8BC
	[Token(Token = "0x60025FE")]
	[Address(RVA = "0x2DDA7B0", Offset = "0x2DDA7B0", VA = "0x2DDA7B0")]
	public void ݨӫ\u0596ٮ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Not connected to room");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Tagged");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("BN");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x060025FF RID: 9727 RVA: 0x000D0994 File Offset: 0x000CEB94
	[Token(Token = "0x60025FF")]
	[Address(RVA = "0x2DDAAE8", Offset = "0x2DDAAE8", VA = "0x2DDAAE8")]
	public void ف\u073Aۇا()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 32768;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("deathScream", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17600;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002600 RID: 9728 RVA: 0x000D0BC4 File Offset: 0x000CEDC4
	[Token(Token = "0x6002600")]
	[Address(RVA = "0x2DDAEA0", Offset = "0x2DDAEA0", VA = "0x2DDAEA0")]
	public void ڷԟ\u087D\u05B9()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Try Connect To Server...");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Found Gameobject: ");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("We don't need this electrical box");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("containsStaff");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x06002601 RID: 9729 RVA: 0x000D0E9C File Offset: 0x000CF09C
	[Token(Token = "0x6002601")]
	[Address(RVA = "0x2DDB1EC", Offset = "0x2DDB1EC", VA = "0x2DDB1EC")]
	public void Ӥө\u07FCݢ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("_Tint", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002602 RID: 9730 RVA: 0x000D1018 File Offset: 0x000CF218
	[Token(Token = "0x6002602")]
	[Address(RVA = "0x2DDB3D4", Offset = "0x2DDB3D4", VA = "0x2DDB3D4")]
	private void ԭ\u07FE\u0597ࠉ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002603 RID: 9731 RVA: 0x000D1034 File Offset: 0x000CF234
	[Token(Token = "0x6002603")]
	[Address(RVA = "0x2DDB4D4", Offset = "0x2DDB4D4", VA = "0x2DDB4D4")]
	private void ܟڵ\u085Eۋ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002604 RID: 9732 RVA: 0x000D1050 File Offset: 0x000CF250
	[Token(Token = "0x6002604")]
	[Address(RVA = "0x2DDB5D4", Offset = "0x2DDB5D4", VA = "0x2DDB5D4")]
	public void \u0737փ\u07F2م()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Not connected to room", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002605 RID: 9733 RVA: 0x000D11CC File Offset: 0x000CF3CC
	[Token(Token = "0x6002605")]
	[Address(RVA = "0x2DDB7BC", Offset = "0x2DDB7BC", VA = "0x2DDB7BC")]
	public void \u06E1ۺԹ\u06EB()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("monke screamed", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002606 RID: 9734 RVA: 0x000D1348 File Offset: 0x000CF548
	[Token(Token = "0x6002606")]
	[Address(RVA = "0x2DDB9A4", Offset = "0x2DDB9A4", VA = "0x2DDB9A4")]
	public void \u0882ݨ\u0893ࡇ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("DisableCosmetic");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("True");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x06002607 RID: 9735 RVA: 0x000D1600 File Offset: 0x000CF800
	[Token(Token = "0x6002607")]
	[Address(RVA = "0x2DDBCF0", Offset = "0x2DDBCF0", VA = "0x2DDBCF0")]
	public void \u0735ރ\u05FD\u0559()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("BLUTARG", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002608 RID: 9736 RVA: 0x000D177C File Offset: 0x000CF97C
	[Token(Token = "0x6002608")]
	[Address(RVA = "0x2DDBED8", Offset = "0x2DDBED8", VA = "0x2DDBED8")]
	public void ՄӦӝ\u07F3()
	{
		Color fogColor = RenderSettings.fogColor;
		Color fogColor2;
		RenderSettings.fogColor = fogColor2;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 32768;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("ErrorScreen", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 49152;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002609 RID: 9737 RVA: 0x000D19B4 File Offset: 0x000CFBB4
	[Token(Token = "0x6002609")]
	[Address(RVA = "0x2DDC294", Offset = "0x2DDC294", VA = "0x2DDC294")]
	public void Աࢦ\u05CAޡ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Reason: ");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("SetColor");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("PRESS AGAIN TO CONFIRM");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("typesOfTalk");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x0600260A RID: 9738 RVA: 0x000D1C90 File Offset: 0x000CFE90
	[Token(Token = "0x600260A")]
	[Address(RVA = "0x2DDC5DC", Offset = "0x2DDC5DC", VA = "0x2DDC5DC")]
	public void ࡇ\u0559یՒ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Player");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Failed to login, please restart");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("Joined a Room.");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b6 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("EnableCosmetic");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x0600260B RID: 9739 RVA: 0x000D1F58 File Offset: 0x000D0158
	[Token(Token = "0x600260B")]
	[Address(RVA = "0x2DDC928", Offset = "0x2DDC928", VA = "0x2DDC928")]
	private void ӆ\u0707ࢠ\u0879()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 49152;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Universal Render Pipeline/Lit", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 8192;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x0600260C RID: 9740 RVA: 0x000D2198 File Offset: 0x000D0398
	[Token(Token = "0x600260C")]
	[Address(RVA = "0x2DDCCE8", Offset = "0x2DDCCE8", VA = "0x2DDCCE8")]
	public void ӴݔӀ\u0652()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Damaged Arm", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x0600260D RID: 9741 RVA: 0x000D2314 File Offset: 0x000D0514
	[Token(Token = "0x600260D")]
	[Address(RVA = "0x2DDCED0", Offset = "0x2DDCED0", VA = "0x2DDCED0")]
	private void نۋ\u061FԐ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 40960;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("ChangeToRegular", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 32768;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x0600260E RID: 9742 RVA: 0x000D256C File Offset: 0x000D076C
	[Token(Token = "0x600260E")]
	[Address(RVA = "0x2DDD29C", Offset = "0x2DDD29C", VA = "0x2DDD29C")]
	private void ޛךԄࢮ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 49152;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Platform failed to initialize due to exception.", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 49152;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x0600260F RID: 9743 RVA: 0x000D27C4 File Offset: 0x000D09C4
	[Token(Token = "0x600260F")]
	[Address(RVA = "0x2DDD668", Offset = "0x2DDD668", VA = "0x2DDD668")]
	public void ҿ\u0828\u05CFԹ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Calling success callback. baking meshes", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002610 RID: 9744 RVA: 0x000D2940 File Offset: 0x000D0B40
	[Token(Token = "0x6002610")]
	[Address(RVA = "0x2DDD850", Offset = "0x2DDD850", VA = "0x2DDD850")]
	public void FixedUpdate()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		bool u05A9_u05F3ݬ_u066A = this.\u05A9\u05F3ݬ\u066A;
		Color color = u074CܛӇ١.GetColor("_Tint");
		if (u05A9_u05F3ݬ_u066A)
		{
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Color color2 = this.\u0606\u0825\u061Dߥ.GetColor("_Tint");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color3 = this.\u0606\u0825\u061Dߥ.GetColor("_Tint");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x06002611 RID: 9745 RVA: 0x000D2C08 File Offset: 0x000D0E08
	[Token(Token = "0x6002611")]
	[Address(RVA = "0x2DDDB00", Offset = "0x2DDDB00", VA = "0x2DDDB00")]
	public void ԿՂզړ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Reason: ");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("gamemode");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("isLava");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x06002612 RID: 9746 RVA: 0x000D2EE0 File Offset: 0x000D10E0
	[Token(Token = "0x6002612")]
	[Address(RVA = "0x2DDDE4C", Offset = "0x2DDDE4C", VA = "0x2DDDE4C")]
	private void Ө٧\u06EDո()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002613 RID: 9747 RVA: 0x000D2EFC File Offset: 0x000D10FC
	[Token(Token = "0x6002613")]
	[Address(RVA = "0x2DDDF4C", Offset = "0x2DDDF4C", VA = "0x2DDDF4C")]
	public void \u089F\u073C\u0590\u07F2()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("typesOfTalk", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002614 RID: 9748 RVA: 0x000D3078 File Offset: 0x000D1278
	[Token(Token = "0x6002614")]
	[Address(RVA = "0x2DDE134", Offset = "0x2DDE134", VA = "0x2DDE134")]
	private void \u064BԜࠋ\u07B2()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 16384;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Joined Public Room Successfully", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 8192;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002615 RID: 9749 RVA: 0x000D32C4 File Offset: 0x000D14C4
	[Token(Token = "0x6002615")]
	[Address(RVA = "0x2DDE4FC", Offset = "0x2DDE4FC", VA = "0x2DDE4FC")]
	public void \u07BE\u0898\u061Dә()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("ORGTARG");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Agreed");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor(". Please update you game to the latest version");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Player");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x06002616 RID: 9750 RVA: 0x000D35A0 File Offset: 0x000D17A0
	[Token(Token = "0x6002616")]
	[Address(RVA = "0x2DDE838", Offset = "0x2DDE838", VA = "0x2DDE838")]
	private void Ո\u061Aފ\u064E()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 49152;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("/", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17377;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002617 RID: 9751 RVA: 0x000D37EC File Offset: 0x000D19EC
	[Token(Token = "0x6002617")]
	[Address(RVA = "0x2DDEBF8", Offset = "0x2DDEBF8", VA = "0x2DDEBF8")]
	public void \u0819ڀ\u05C4ࡉ()
	{
		Color fogColor = RenderSettings.fogColor;
		Vector4 v;
		Color color = v;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 17332;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Player", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 16448;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002618 RID: 9752 RVA: 0x000D3A3C File Offset: 0x000D1C3C
	[Token(Token = "0x6002618")]
	[Address(RVA = "0x2DDEFB0", Offset = "0x2DDEFB0", VA = "0x2DDEFB0")]
	private void \u05A0ݑץ\u0733()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002619 RID: 9753 RVA: 0x000D3A58 File Offset: 0x000D1C58
	[Token(Token = "0x6002619")]
	[Address(RVA = "0x2DDF0B0", Offset = "0x2DDF0B0", VA = "0x2DDF0B0")]
	private void \u059B\u081Eߌچ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x0600261A RID: 9754 RVA: 0x000D3A74 File Offset: 0x000D1C74
	[Token(Token = "0x600261A")]
	[Address(RVA = "0x2DDF1B0", Offset = "0x2DDF1B0", VA = "0x2DDF1B0")]
	private void ࡨࢶ\u06DAࡠ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x0600261B RID: 9755 RVA: 0x000D3A90 File Offset: 0x000D1C90
	[Token(Token = "0x600261B")]
	[Address(RVA = "0x2DDF2B0", Offset = "0x2DDF2B0", VA = "0x2DDF2B0")]
	[PunRPC]
	public void NormalWeather()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value = Mathf.Lerp(deltaTime2, fogEndDistance, fogEndDistance);
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		float num2 = Mathf.Lerp(fogEndDistance, fogEndDistance, fogEndDistance);
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		float num3 = Mathf.Lerp(fogEndDistance, fogEndDistance, fogEndDistance);
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float a2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4 = Mathf.Lerp(a2, fogEndDistance, fogEndDistance);
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x0600261C RID: 9756 RVA: 0x000D3C40 File Offset: 0x000D1E40
	[Token(Token = "0x600261C")]
	[Address(RVA = "0x2DDF48C", Offset = "0x2DDF48C", VA = "0x2DDF48C")]
	public void ݲ\u06E6ҽࡩ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Vector1_d371bd24217449349bd747533d51af6b");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("gravThing");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("Not connected to room");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Name Changing Error. Error: ");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x0600261D RID: 9757 RVA: 0x000D3F20 File Offset: 0x000D2120
	[Token(Token = "0x600261D")]
	[Address(RVA = "0x2DDF7D4", Offset = "0x2DDF7D4", VA = "0x2DDF7D4")]
	public void \u07BBۯ٤ࠍ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Song Index: ");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("PushToTalk");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor(".Please press the button if you would like to play alone");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Fire Stick Is Lighting...");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x0600261E RID: 9758 RVA: 0x000D41F8 File Offset: 0x000D23F8
	[Token(Token = "0x600261E")]
	[Address(RVA = "0x2DDFB20", Offset = "0x2DDFB20", VA = "0x2DDFB20")]
	public void \u0600փ\u088Fࡅ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("true", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x0600261F RID: 9759 RVA: 0x000D4374 File Offset: 0x000D2574
	[Token(Token = "0x600261F")]
	[Address(RVA = "0x2DDFD08", Offset = "0x2DDFD08", VA = "0x2DDFD08")]
	public void \u066BեٮՒ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		GameObject thunderThing = this.ࡐ\u085E\u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 32768;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Player", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 49152;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002620 RID: 9760 RVA: 0x000D45A8 File Offset: 0x000D27A8
	[Token(Token = "0x6002620")]
	[Address(RVA = "0x2DE00C8", Offset = "0x2DE00C8", VA = "0x2DE00C8")]
	private void ՁՐ\u0817Բ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002621 RID: 9761 RVA: 0x000D45C4 File Offset: 0x000D27C4
	[Token(Token = "0x6002621")]
	[Address(RVA = "0x2DE01C8", Offset = "0x2DE01C8", VA = "0x2DE01C8")]
	public void Տ\u0896ܜݬ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("PlayerHead");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Purchased: ");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("You are not the master of the server, you cannot start the game.");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("All audio clips have been played.");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x06002622 RID: 9762 RVA: 0x000D489C File Offset: 0x000D2A9C
	[Token(Token = "0x6002622")]
	[Address(RVA = "0x2DE0514", Offset = "0x2DE0514", VA = "0x2DE0514")]
	public void \u086CӥՄ\u065E()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("NoseAttachPoint", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002623 RID: 9763 RVA: 0x000D4A18 File Offset: 0x000D2C18
	[Token(Token = "0x6002623")]
	[Address(RVA = "0x2DE06FC", Offset = "0x2DE06FC", VA = "0x2DE06FC")]
	public void ߧՀߎԲ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("NetworkGunShoot", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x06002624 RID: 9764 RVA: 0x000D4BA0 File Offset: 0x000D2DA0
	[Token(Token = "0x6002624")]
	[Address(RVA = "0x2DE08EC", Offset = "0x2DE08EC", VA = "0x2DE08EC")]
	private void \u0603ܗ\u081F\u0609()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002625 RID: 9765 RVA: 0x000D4BBC File Offset: 0x000D2DBC
	[Token(Token = "0x6002625")]
	[Address(RVA = "0x2DE09EC", Offset = "0x2DE09EC", VA = "0x2DE09EC")]
	public void ԝ\u086B\u0614ױ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 17401;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat(", ", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 49152;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002626 RID: 9766 RVA: 0x000D4DFC File Offset: 0x000D2FFC
	[Token(Token = "0x6002626")]
	[Address(RVA = "0x2DE0DA8", Offset = "0x2DE0DA8", VA = "0x2DE0DA8")]
	public void ܔ\u07F5ԯԔ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Universal Render Pipeline/Lit");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Player");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("monke is not my monke");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("StartGamemode");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x06002627 RID: 9767 RVA: 0x000D50D4 File Offset: 0x000D32D4
	[Token(Token = "0x6002627")]
	[Address(RVA = "0x2DE10F4", Offset = "0x2DE10F4", VA = "0x2DE10F4")]
	private void ݿا\u0825ײ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 16384;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Name Changing Error. Error: ", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 16384;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002628 RID: 9768 RVA: 0x000D532C File Offset: 0x000D352C
	[Token(Token = "0x6002628")]
	[Address(RVA = "0x2DE14C0", Offset = "0x2DE14C0", VA = "0x2DE14C0")]
	public void Ԥ\u05AD\u0640ݺ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("next", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002629 RID: 9769 RVA: 0x000D54A8 File Offset: 0x000D36A8
	[Token(Token = "0x6002629")]
	[Address(RVA = "0x2DE16A8", Offset = "0x2DE16A8", VA = "0x2DE16A8")]
	public void ހގܢ\u07EB()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 17434;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Added Winner Money", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 16384;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x0600262A RID: 9770 RVA: 0x000D56E8 File Offset: 0x000D38E8
	[Token(Token = "0x600262A")]
	[Address(RVA = "0x2DE1A60", Offset = "0x2DE1A60", VA = "0x2DE1A60")]
	private void ӎՅۄ\u089B()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x0600262B RID: 9771 RVA: 0x000D5704 File Offset: 0x000D3904
	[Token(Token = "0x600262B")]
	[Address(RVA = "0x2DE1B60", Offset = "0x2DE1B60", VA = "0x2DE1B60")]
	private void \u0892Դܗն()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x0600262C RID: 9772 RVA: 0x000D5720 File Offset: 0x000D3920
	[Token(Token = "0x600262C")]
	[Address(RVA = "0x2DE1C60", Offset = "0x2DE1C60", VA = "0x2DE1C60")]
	public void ԹߦԻ\u0640()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Player", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x0600262D RID: 9773 RVA: 0x000D589C File Offset: 0x000D3A9C
	[Token(Token = "0x600262D")]
	[Address(RVA = "0x2DE1E48", Offset = "0x2DE1E48", VA = "0x2DE1E48")]
	public void \u05CEڥڸӊ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Purchase For ", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x0600262E RID: 9774 RVA: 0x000D5A18 File Offset: 0x000D3C18
	[Token(Token = "0x600262E")]
	[Address(RVA = "0x2DE2034", Offset = "0x2DE2034", VA = "0x2DE2034")]
	private void \u055AӖࢣࢺ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 16384;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("\tExpires: ", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 49152;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x0600262F RID: 9775 RVA: 0x000D5C64 File Offset: 0x000D3E64
	[Token(Token = "0x600262F")]
	[Address(RVA = "0x2DE23F8", Offset = "0x2DE23F8", VA = "0x2DE23F8")]
	public void ټ\u088FՓ\u07EB()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 32768;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Holdable", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 8192;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002630 RID: 9776 RVA: 0x000D5EA4 File Offset: 0x000D40A4
	[Token(Token = "0x6002630")]
	[Address(RVA = "0x2DE27B4", Offset = "0x2DE27B4", VA = "0x2DE27B4")]
	private void ࢹ\u060B\u083DՔ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002631 RID: 9777 RVA: 0x000D5EC0 File Offset: 0x000D40C0
	[Token(Token = "0x6002631")]
	[Address(RVA = "0x2DE28B4", Offset = "0x2DE28B4", VA = "0x2DE28B4")]
	private void ԠېքӉ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 17559;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("ScoreCounter", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 57344;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002632 RID: 9778 RVA: 0x000D610C File Offset: 0x000D430C
	[Token(Token = "0x6002632")]
	[Address(RVA = "0x2DE2C78", Offset = "0x2DE2C78", VA = "0x2DE2C78")]
	public void \u060Cࡃࠈݱ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("HDRP/Lit");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Color color2 = u074CܛӇ١.GetColor("ChangeToTagged");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u074CܛӇ١.GetColor("Player");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("FLSPTLT");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x06002633 RID: 9779 RVA: 0x000D63D8 File Offset: 0x000D45D8
	[Token(Token = "0x6002633")]
	[Address(RVA = "0x2DE2FC4", Offset = "0x2DE2FC4", VA = "0x2DE2FC4")]
	public void \u05BD\u060Cׯӻ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 40960;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat(", ", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 17271;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002634 RID: 9780 RVA: 0x000D6618 File Offset: 0x000D4818
	[Token(Token = "0x6002634")]
	[Address(RVA = "0x2DE337C", Offset = "0x2DE337C", VA = "0x2DE337C")]
	public void ػӿڒ\u0883()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("5BN", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002635 RID: 9781 RVA: 0x000D6794 File Offset: 0x000D4994
	[Token(Token = "0x6002635")]
	[Address(RVA = "0x2DE3568", Offset = "0x2DE3568", VA = "0x2DE3568")]
	public void ۼࡥә۸()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 32768;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Combine textures & build combined mesh all at once", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 8192;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002636 RID: 9782 RVA: 0x000D69D4 File Offset: 0x000D4BD4
	[Token(Token = "0x6002636")]
	[Address(RVA = "0x2DE3928", Offset = "0x2DE3928", VA = "0x2DE3928")]
	public void ۻ\u0894נࡊ()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
	}

	// Token: 0x06002637 RID: 9783 RVA: 0x000D6BF8 File Offset: 0x000D4DF8
	[Token(Token = "0x6002637")]
	[Address(RVA = "0x2DE3CAC", Offset = "0x2DE3CAC", VA = "0x2DE3CAC")]
	private void \u085Bգ\u07B4Կ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002638 RID: 9784 RVA: 0x000D6C14 File Offset: 0x000D4E14
	[Token(Token = "0x6002638")]
	[Address(RVA = "0x2DE3DAC", Offset = "0x2DE3DAC", VA = "0x2DE3DAC")]
	private void Ӹڠޥڠ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002639 RID: 9785 RVA: 0x000D6C30 File Offset: 0x000D4E30
	[Token(Token = "0x6002639")]
	[Address(RVA = "0x2DE3EAC", Offset = "0x2DE3EAC", VA = "0x2DE3EAC")]
	public void Ԯ߈ڸ\u085C()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x0600263A RID: 9786 RVA: 0x000D6DAC File Offset: 0x000D4FAC
	[Token(Token = "0x600263A")]
	[Address(RVA = "0x2DE4098", Offset = "0x2DE4098", VA = "0x2DE4098")]
	public void \u082Bݿݵ\u055C()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("EnableCosmetic", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x0600263B RID: 9787 RVA: 0x000D6F34 File Offset: 0x000D5134
	[Token(Token = "0x600263B")]
	[Address(RVA = "0x2DE4288", Offset = "0x2DE4288", VA = "0x2DE4288")]
	public void ܚ\u06E5\u087Fӊ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("deathScream", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x0600263C RID: 9788 RVA: 0x000D70B0 File Offset: 0x000D52B0
	[Token(Token = "0x600263C")]
	[Address(RVA = "0x2DE446C", Offset = "0x2DE446C", VA = "0x2DE446C")]
	public void \u07AF\u0896\u05CA\u07B4()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat(" hour. You were banned because of ", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x0600263D RID: 9789 RVA: 0x000D722C File Offset: 0x000D542C
	[Token(Token = "0x600263D")]
	[Address(RVA = "0x2DE4654", Offset = "0x2DE4654", VA = "0x2DE4654")]
	private void ߙכڪי()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 24576;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Player", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 16384;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x0600263E RID: 9790 RVA: 0x000D7478 File Offset: 0x000D5678
	[Token(Token = "0x600263E")]
	[Address(RVA = "0x2DE4A18", Offset = "0x2DE4A18", VA = "0x2DE4A18")]
	public void ي\u081B\u0652\u06E4()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 16384;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("ENABLE", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 16384;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x0600263F RID: 9791 RVA: 0x000D76C4 File Offset: 0x000D58C4
	[Token(Token = "0x600263F")]
	[Address(RVA = "0x2DE4DDC", Offset = "0x2DE4DDC", VA = "0x2DE4DDC")]
	private void ݔࢩތ\u05FC()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002640 RID: 9792 RVA: 0x000D76E0 File Offset: 0x000D58E0
	[Token(Token = "0x6002640")]
	[Address(RVA = "0x2DE4EDC", Offset = "0x2DE4EDC", VA = "0x2DE4EDC")]
	private void ݍשތٯ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002641 RID: 9793 RVA: 0x000D76FC File Offset: 0x000D58FC
	[Token(Token = "0x6002641")]
	[Address(RVA = "0x2DE4FDC", Offset = "0x2DE4FDC", VA = "0x2DE4FDC")]
	[PunRPC]
	private void RainAndThunderWeather()
	{
		Color fogColor = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		long maxExclusive = 0L;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		int num2 = UnityEngine.Random.Range(0, (int)maxExclusive);
		GameObject thunderThing2 = ࡐ_u085E_u089Eԉ.thunderThing;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num3;
		RenderSettings.fogEndDistance = num3;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num3;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num4 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num5;
		ڞه_u0749_u089D.volume = num5;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
	}

	// Token: 0x06002642 RID: 9794 RVA: 0x000D7918 File Offset: 0x000D5B18
	[Token(Token = "0x6002642")]
	[Address(RVA = "0x2DE5368", Offset = "0x2DE5368", VA = "0x2DE5368")]
	private void ՏӁ\u07BB\u07BC()
	{
		Vector4 vector = RenderSettings.fogColor;
		this.ר\u086E\u05B0\u083E.Play();
		float u059F_u0592_u06DFࡏ = this.\u059F\u0592\u06DFࡏ;
		float u059Bڝڞԏ = this.\u059Bڝڞԏ;
		ParticleSystem strike = this.ࡐ\u085E\u089Eԉ.strike;
		Transform transform = this.ࡐ\u085E\u089Eԉ.thunderThing.transform;
		WeatherCycle.Thunder ࡐ_u085E_u089Eԉ = this.ࡐ\u085E\u089Eԉ;
		ParticleSystem strike2 = ࡐ_u085E_u089Eԉ.strike;
		GameObject thunderThing = ࡐ_u085E_u089Eԉ.thunderThing;
		AudioClip[] sounds = this.ࡐ\u085E\u089Eԉ.sounds;
		AudioClip.PCMReaderCallback pcmreaderCallback = sounds.m_PCMReaderCallback;
		AudioSource thunder = this.ࡐ\u085E\u089Eԉ.thunder;
		object target = sounds.m_PCMReaderCallback.m_target;
		this.ࡐ\u085E\u089Eԉ.strike.Play();
		int u059F_u0592_u06DFࡏ2 = 49152;
		this.\u059F\u0592\u06DFࡏ = (float)u059F_u0592_u06DFࡏ2;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Collided", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		int ࡑ۳_u0596_u066C = 32768;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
	}

	// Token: 0x06002643 RID: 9795 RVA: 0x000D7B64 File Offset: 0x000D5D64
	[Token(Token = "0x6002643")]
	[Address(RVA = "0x2DE5730", Offset = "0x2DE5730", VA = "0x2DE5730")]
	public void ڍ\u088Eࡏޗ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002644 RID: 9796 RVA: 0x000D7CD4 File Offset: 0x000D5ED4
	[Token(Token = "0x6002644")]
	[Address(RVA = "0x2DE5918", Offset = "0x2DE5918", VA = "0x2DE5918")]
	private void \u07FE\u0732ݥ\u05A8()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002645 RID: 9797 RVA: 0x000D7CF0 File Offset: 0x000D5EF0
	[Token(Token = "0x6002645")]
	[Address(RVA = "0x2DE5A18", Offset = "0x2DE5A18", VA = "0x2DE5A18")]
	public void ڥչھ\u07BF()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Key", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x06002646 RID: 9798 RVA: 0x000D7E6C File Offset: 0x000D606C
	[Token(Token = "0x6002646")]
	[Address(RVA = "0x2DE5C04", Offset = "0x2DE5C04", VA = "0x2DE5C04")]
	public void ޞؽ\u06EDս()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("PlayNoise");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("monke is not my monke");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("tutorialCheck");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Player");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x06002647 RID: 9799 RVA: 0x000D8144 File Offset: 0x000D6344
	[Token(Token = "0x6002647")]
	[Address(RVA = "0x2DE5F50", Offset = "0x2DE5F50", VA = "0x2DE5F50")]
	public void Ծ\u0700ࡏմ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("KeyPos");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Start Gamemode");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("Room1");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("DisableCosmetic");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x06002648 RID: 9800 RVA: 0x000D841C File Offset: 0x000D661C
	[Token(Token = "0x6002648")]
	[Address(RVA = "0x2DE629C", Offset = "0x2DE629C", VA = "0x2DE629C")]
	private void ۆܞݨ\u0879()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x06002649 RID: 9801 RVA: 0x000D8438 File Offset: 0x000D6638
	[Token(Token = "0x6002649")]
	[Address(RVA = "0x2DE639C", Offset = "0x2DE639C", VA = "0x2DE639C")]
	public void ޛ\u0822\u05AFݎ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("DisableCosmetic");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("gravThing");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Name Changing Error. Error: ");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x0600264A RID: 9802 RVA: 0x000D8718 File Offset: 0x000D6918
	[Token(Token = "0x600264A")]
	[Address(RVA = "0x2DE66E4", Offset = "0x2DE66E4", VA = "0x2DE66E4")]
	private void ݐן\u087Eޅ()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x0600264B RID: 9803 RVA: 0x000D8734 File Offset: 0x000D6934
	[Token(Token = "0x600264B")]
	[Address(RVA = "0x2DE67E4", Offset = "0x2DE67E4", VA = "0x2DE67E4")]
	public void ݵՂ\u0709ھ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value = Mathf.Lerp(deltaTime2, fogEndDistance, fogEndDistance);
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		float num2 = Mathf.Lerp(fogEndDistance, fogEndDistance, fogEndDistance);
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		float num3 = Mathf.Lerp(fogEndDistance, fogEndDistance, fogEndDistance);
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float a2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4 = Mathf.Lerp(a2, fogEndDistance, fogEndDistance);
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x0600264C RID: 9804 RVA: 0x000D88E4 File Offset: 0x000D6AE4
	[Token(Token = "0x600264C")]
	[Address(RVA = "0x2DE69BC", Offset = "0x2DE69BC", VA = "0x2DE69BC")]
	public void ࠇ\u087DػՏ()
	{
		if (this.ࠇԫޔࠕ)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
			lightmapData.lightmapColor = ێص_u05ECࡄ;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			Texture2D dir = lightmaps.m_Dir;
		}
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("BLUPORT");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("FingerTip");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("Tagged");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("PlayerHead");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x0600264D RID: 9805 RVA: 0x000D8BBC File Offset: 0x000D6DBC
	[Token(Token = "0x600264D")]
	[Address(RVA = "0x2DE6D08", Offset = "0x2DE6D08", VA = "0x2DE6D08")]
	private void Ԭ\u059B\u05B5\u0657()
	{
		WeatherCycle.Photon u0599_u05F9ڠ_u089C = this.\u0599\u05F9ڠ\u089C;
	}

	// Token: 0x0600264E RID: 9806 RVA: 0x000D8BD8 File Offset: 0x000D6DD8
	[Token(Token = "0x600264E")]
	[Address(RVA = "0x2DE6E08", Offset = "0x2DE6E08", VA = "0x2DE6E08")]
	public void \u07AAح\u087Fܩ()
	{
		bool flag = this.ࠇԫޔࠕ;
		LightmapData lightmapData = new LightmapData();
		Texture2D ێص_u05ECࡄ = this.ێص\u05ECࡄ;
		lightmapData.lightmapColor = ێص_u05ECࡄ;
		LightmapData[] lightmaps = LightmapSettings.lightmaps;
		if (lightmapData == null)
		{
			throw new ArrayTypeMismatchException();
		}
		Texture2D dir = lightmaps.m_Dir;
		Material u074CܛӇ١ = this.\u074CܛӇ١;
		Material u0606_u0825_u061Dߥ;
		if (this.\u05A9\u05F3ݬ\u066A)
		{
			Color color = u074CܛӇ١.GetColor("Platform failed to initialize due to exception.");
			float r = this.ӯۋߢڲ.r;
			float g = this.ӯۋߢڲ.g;
			float b = this.ӯۋߢڲ.b;
			float a = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			u0606_u0825_u061Dߥ = this.\u0606\u0825\u061Dߥ;
			Color color2 = u0606_u0825_u061Dߥ.GetColor("ChangeToRegular");
			float r2 = this.ӯۋߢڲ.r;
			float g2 = this.ӯۋߢڲ.g;
			float b2 = this.ӯۋߢڲ.b;
			float a2 = this.ӯۋߢڲ.a;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			float r3 = this.\u0870ࠅ\u089Bߕ.r;
			float g3 = this.\u0870ࠅ\u089Bߕ.g;
			float b3 = this.\u0870ࠅ\u089Bߕ.b;
			float a3 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			float r4 = this.\u0870ࠅ\u089Bߕ.r;
			float g4 = this.\u0870ࠅ\u089Bߕ.g;
			float b4 = this.\u0870ࠅ\u089Bߕ.b;
			float a4 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			float r5 = this.\u0870ࠅ\u089Bߕ.r;
			float g5 = this.\u0870ࠅ\u089Bߕ.g;
			float b5 = this.\u0870ࠅ\u089Bߕ.b;
			float a5 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			float r6 = this.\u0870ࠅ\u089Bߕ.r;
			float g6 = this.\u0870ࠅ\u089Bߕ.g;
			float b6 = this.\u0870ࠅ\u089Bߕ.b;
			float a6 = this.\u0870ࠅ\u089Bߕ.a;
			float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
			return;
		}
		Color color3 = u0606_u0825_u061Dߥ.GetColor("run");
		float u05B9ߎܩ_u7 = this.\u05B9ߎܩ\u0613;
		float r7 = this.\u0610ݫӕ\u06DF.r;
		float g7 = this.\u0610ݫӕ\u06DF.g;
		float b7 = this.\u0610ݫӕ\u06DF.b;
		float a7 = this.\u0610ݫӕ\u06DF.a;
		Color color4 = this.\u0606\u0825\u061Dߥ.GetColor("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		float u05B9ߎܩ_u8 = this.\u05B9ߎܩ\u0613;
		float r8 = this.\u0610ݫӕ\u06DF.r;
		float g8 = this.\u0610ݫӕ\u06DF.g;
		float b8 = this.\u0610ݫӕ\u06DF.b;
		float a8 = this.\u0610ݫӕ\u06DF.a;
	}

	// Token: 0x0600264F RID: 9807 RVA: 0x000D8EB0 File Offset: 0x000D70B0
	[Token(Token = "0x600264F")]
	[Address(RVA = "0x2DE7154", Offset = "0x2DE7154", VA = "0x2DE7154")]
	public WeatherCycle()
	{
	}

	// Token: 0x06002650 RID: 9808 RVA: 0x000D8EC4 File Offset: 0x000D70C4
	[Token(Token = "0x6002650")]
	[Address(RVA = "0x2DE71D4", Offset = "0x2DE71D4", VA = "0x2DE71D4")]
	public void ݮࢴԸڔ()
	{
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float flspeed2 = this.ݛՖ\u0605ࠇ.FLspeed;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		this.ݛՖ\u0605ࠇ.FLspeed = flspeed2;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Song Index: ", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = flspeed2;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = flspeed2;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x040004B6 RID: 1206
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004B6")]
	public float شڥۃڊ;

	// Token: 0x040004B7 RID: 1207
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40004B7")]
	public float \u059Bڝڞԏ;

	// Token: 0x040004B8 RID: 1208
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004B8")]
	public WeatherCycle.\u055EݹՀ\u0839 ࢢ\u088CӦ\u082C;

	// Token: 0x040004B9 RID: 1209
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x40004B9")]
	public Color ן\u0704\u058F߅;

	// Token: 0x040004BA RID: 1210
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40004BA")]
	public ParticleSystem ר\u086E\u05B0\u083E;

	// Token: 0x040004BB RID: 1211
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40004BB")]
	public bool ӑטԖک;

	// Token: 0x040004BC RID: 1212
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40004BC")]
	public Material ڥڲӷډ;

	// Token: 0x040004BD RID: 1213
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40004BD")]
	public WeatherCycle.lerpSpeeds ݛՖ\u0605ࠇ;

	// Token: 0x040004BE RID: 1214
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x40004BE")]
	[SerializeField]
	private Volume volume;

	// Token: 0x040004BF RID: 1215
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x40004BF")]
	private float \u0881ޡࡅ\u05B9;

	// Token: 0x040004C0 RID: 1216
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x40004C0")]
	public GameObject ۴\u05EBی\u0823;

	// Token: 0x040004C1 RID: 1217
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x40004C1")]
	public AudioSource ڞه\u0749\u089D;

	// Token: 0x040004C2 RID: 1218
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x40004C2")]
	private float ٠ػע\u05AB;

	// Token: 0x040004C3 RID: 1219
	[FieldOffset(Offset = "0x8C")]
	[Token(Token = "0x40004C3")]
	public bool ӻهࡀ\u05C1;

	// Token: 0x040004C4 RID: 1220
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x40004C4")]
	public WeatherCycle.Thunder ࡐ\u085E\u089Eԉ;

	// Token: 0x040004C5 RID: 1221
	[FieldOffset(Offset = "0xB8")]
	[Token(Token = "0x40004C5")]
	public WeatherCycle.Photon \u0599\u05F9ڠ\u089C;

	// Token: 0x040004C6 RID: 1222
	[FieldOffset(Offset = "0xC0")]
	[Token(Token = "0x40004C6")]
	private bool \u088FӨ\u065F\u05C1;

	// Token: 0x040004C7 RID: 1223
	[FieldOffset(Offset = "0xC4")]
	[Token(Token = "0x40004C7")]
	private float ࡑ۳\u0596\u066C;

	// Token: 0x040004C8 RID: 1224
	[FieldOffset(Offset = "0xC8")]
	[Token(Token = "0x40004C8")]
	private float \u059F\u0592\u06DFࡏ;

	// Token: 0x040004C9 RID: 1225
	[FieldOffset(Offset = "0xCC")]
	[Token(Token = "0x40004C9")]
	public bool \u05A9\u05F3ݬ\u066A;

	// Token: 0x040004CA RID: 1226
	[FieldOffset(Offset = "0xD0")]
	[Token(Token = "0x40004CA")]
	public Material \u074CܛӇ١;

	// Token: 0x040004CB RID: 1227
	[FieldOffset(Offset = "0xD8")]
	[Token(Token = "0x40004CB")]
	public Material \u0606\u0825\u061Dߥ;

	// Token: 0x040004CC RID: 1228
	[FieldOffset(Offset = "0xE0")]
	[Token(Token = "0x40004CC")]
	public float \u05B9ߎܩ\u0613;

	// Token: 0x040004CD RID: 1229
	[FieldOffset(Offset = "0xE4")]
	[Token(Token = "0x40004CD")]
	private Color \u0610ݫӕ\u06DF;

	// Token: 0x040004CE RID: 1230
	[FieldOffset(Offset = "0xF4")]
	[Token(Token = "0x40004CE")]
	private Color ӯۋߢڲ;

	// Token: 0x040004CF RID: 1231
	[FieldOffset(Offset = "0x104")]
	[Token(Token = "0x40004CF")]
	public Color \u0870ࠅ\u089Bߕ;

	// Token: 0x040004D0 RID: 1232
	[FieldOffset(Offset = "0x118")]
	[Token(Token = "0x40004D0")]
	public Texture2D ێص\u05ECࡄ;

	// Token: 0x040004D1 RID: 1233
	[FieldOffset(Offset = "0x120")]
	[Token(Token = "0x40004D1")]
	public Texture2D ݻޠ\u0609ݧ;

	// Token: 0x040004D2 RID: 1234
	[FieldOffset(Offset = "0x128")]
	[Token(Token = "0x40004D2")]
	public bool ࠇԫޔࠕ;

	// Token: 0x020000F4 RID: 244
	[Token(Token = "0x20000F4")]
	public enum \u055EݹՀ\u0839
	{
		// Token: 0x040004D4 RID: 1236
		[Token(Token = "0x40004D4")]
		Ԁࡩػ\u086F,
		// Token: 0x040004D5 RID: 1237
		[Token(Token = "0x40004D5")]
		[InspectorName("Rain & Thunder")]
		ڔ\u07BF\u07B9ܛ
	}

	// Token: 0x020000F5 RID: 245
	[Token(Token = "0x20000F5")]
	[Serializable]
	public struct lerpSpeeds
	{
		// Token: 0x040004D6 RID: 1238
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40004D6")]
		[Header("Lerp Values (Order should be 10, 1, 1, and 1)")]
		public float FLspeed;

		// Token: 0x040004D7 RID: 1239
		[FieldOffset(Offset = "0x4")]
		[Token(Token = "0x40004D7")]
		public float volumeWeightSpeed;

		// Token: 0x040004D8 RID: 1240
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x40004D8")]
		public float RLspeed;

		// Token: 0x040004D9 RID: 1241
		[FieldOffset(Offset = "0xC")]
		[Token(Token = "0x40004D9")]
		public float RALspeed;

		// Token: 0x040004DA RID: 1242
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40004DA")]
		public float cloudLerpSpeed;
	}

	// Token: 0x020000F6 RID: 246
	[Token(Token = "0x20000F6")]
	[Serializable]
	public struct Thunder
	{
		// Token: 0x040004DB RID: 1243
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40004DB")]
		public Transform[] possibleLightningStrikes;

		// Token: 0x040004DC RID: 1244
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x40004DC")]
		public AudioSource thunder;

		// Token: 0x040004DD RID: 1245
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40004DD")]
		public AudioClip[] sounds;

		// Token: 0x040004DE RID: 1246
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40004DE")]
		public ParticleSystem strike;

		// Token: 0x040004DF RID: 1247
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40004DF")]
		public GameObject thunderThing;
	}

	// Token: 0x020000F7 RID: 247
	[Token(Token = "0x20000F7")]
	[Serializable]
	public struct Photon
	{
		// Token: 0x040004E0 RID: 1248
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40004E0")]
		public PhotonView photonView;
	}
}
