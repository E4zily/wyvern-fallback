﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200000F RID: 15
[Token(Token = "0x200000F")]
[Serializable]
public struct TeamSettings
{
	// Token: 0x04000040 RID: 64
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000040")]
	[Header("Materials")]
	public Material Tagged;

	// Token: 0x04000041 RID: 65
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x4000041")]
	public Material Reg;
}
