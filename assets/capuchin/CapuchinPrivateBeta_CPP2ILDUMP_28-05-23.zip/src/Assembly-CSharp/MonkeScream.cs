﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000CA RID: 202
[Token(Token = "0x20000CA")]
public class MonkeScream : MonoBehaviour
{
	// Token: 0x06001E8A RID: 7818 RVA: 0x0009F1C0 File Offset: 0x0009D3C0
	[Token(Token = "0x6001E8A")]
	[Address(RVA = "0x23B1594", Offset = "0x23B1594", VA = "0x23B1594")]
	public void ߠ\u07AAߚթ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
	}

	// Token: 0x06001E8B RID: 7819 RVA: 0x0009F200 File Offset: 0x0009D400
	[Token(Token = "0x6001E8B")]
	[Address(RVA = "0x23B165C", Offset = "0x23B165C", VA = "0x23B165C")]
	private void ԣ\u05ADߗא()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001E8C RID: 7820 RVA: 0x0009F248 File Offset: 0x0009D448
	[Token(Token = "0x6001E8C")]
	[Address(RVA = "0x23B16DC", Offset = "0x23B16DC", VA = "0x23B16DC")]
	private void ӂޡࠁө()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001E8D RID: 7821 RVA: 0x0009F290 File Offset: 0x0009D490
	[Token(Token = "0x6001E8D")]
	[Address(RVA = "0x23B175C", Offset = "0x23B175C", VA = "0x23B175C")]
	public void ߁\u0829\u073E\u081A()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("HeadAttachPoint");
	}

	// Token: 0x06001E8E RID: 7822 RVA: 0x0009F2D0 File Offset: 0x0009D4D0
	[Token(Token = "0x6001E8E")]
	[Address(RVA = "0x23B1824", Offset = "0x23B1824", VA = "0x23B1824")]
	public void \u06EDٵ۶\u06DB()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("You are not the master of the server, you cannot start the game.");
	}

	// Token: 0x06001E8F RID: 7823 RVA: 0x0009F310 File Offset: 0x0009D510
	[Token(Token = "0x6001E8F")]
	[Address(RVA = "0x23B18EC", Offset = "0x23B18EC", VA = "0x23B18EC")]
	public void \u087BӦןݩ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("ChangeToTagged");
			return;
		}
	}

	// Token: 0x06001E90 RID: 7824 RVA: 0x0009F354 File Offset: 0x0009D554
	[Token(Token = "0x6001E90")]
	[Address(RVA = "0x23B1A9C", Offset = "0x23B1A9C", VA = "0x23B1A9C")]
	public void \u0836Ծߣڲ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Failed To Join Public Room Successfully. The error is: ");
	}

	// Token: 0x06001E91 RID: 7825 RVA: 0x0009F394 File Offset: 0x0009D594
	[Token(Token = "0x6001E91")]
	[Address(RVA = "0x23B1B64", Offset = "0x23B1B64", VA = "0x23B1B64")]
	public void ӛ\u082Eؿڕ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("/");
	}

	// Token: 0x06001E92 RID: 7826 RVA: 0x0009F3D4 File Offset: 0x0009D5D4
	[Token(Token = "0x6001E92")]
	[Address(RVA = "0x23B1C2C", Offset = "0x23B1C2C", VA = "0x23B1C2C")]
	private void \u0817\u0888دՄ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001E93 RID: 7827 RVA: 0x0009F41C File Offset: 0x0009D61C
	[Token(Token = "0x6001E93")]
	[Address(RVA = "0x23B1CAC", Offset = "0x23B1CAC", VA = "0x23B1CAC")]
	public void Ջއٵյ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("containsStaff");
	}

	// Token: 0x06001E94 RID: 7828 RVA: 0x0009F45C File Offset: 0x0009D65C
	[Token(Token = "0x6001E94")]
	[Address(RVA = "0x23B1D74", Offset = "0x23B1D74", VA = "0x23B1D74")]
	public void ӭࡖݲ\u05BD()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("This is the 2500 Bananas button, and it was just clicked");
	}

	// Token: 0x06001E95 RID: 7829 RVA: 0x0009F49C File Offset: 0x0009D69C
	[Token(Token = "0x6001E95")]
	[Address(RVA = "0x23B1E3C", Offset = "0x23B1E3C", VA = "0x23B1E3C")]
	public void \u0705\u0816\u0739դ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Error");
			return;
		}
	}

	// Token: 0x06001E96 RID: 7830 RVA: 0x0009F4E0 File Offset: 0x0009D6E0
	[Token(Token = "0x6001E96")]
	[Address(RVA = "0x23B1FEC", Offset = "0x23B1FEC", VA = "0x23B1FEC")]
	public void \u070E\u066Dӯ\u05F4()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("isLava");
	}

	// Token: 0x06001E97 RID: 7831 RVA: 0x0009F520 File Offset: 0x0009D720
	[Token(Token = "0x6001E97")]
	[Address(RVA = "0x23B20B4", Offset = "0x23B20B4", VA = "0x23B20B4")]
	public void ݱ\u0832ݥ\u08B5()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("_Tint");
	}

	// Token: 0x06001E98 RID: 7832 RVA: 0x0009F560 File Offset: 0x0009D760
	[Token(Token = "0x6001E98")]
	[Address(RVA = "0x23B217C", Offset = "0x23B217C", VA = "0x23B217C")]
	public void ԣԭՋࠏ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("PURCHASE");
			return;
		}
	}

	// Token: 0x06001E99 RID: 7833 RVA: 0x0009F5A4 File Offset: 0x0009D7A4
	[Token(Token = "0x6001E99")]
	[Address(RVA = "0x23B232C", Offset = "0x23B232C", VA = "0x23B232C")]
	private void މյ\u064Bӱ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001E9A RID: 7834 RVA: 0x0009F5EC File Offset: 0x0009D7EC
	[Token(Token = "0x6001E9A")]
	[Address(RVA = "0x23B23AC", Offset = "0x23B23AC", VA = "0x23B23AC")]
	public void ۓݳۯ٨()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("DisableCosmetic");
	}

	// Token: 0x06001E9B RID: 7835 RVA: 0x0009F62C File Offset: 0x0009D82C
	[Token(Token = "0x6001E9B")]
	[Address(RVA = "0x23B2474", Offset = "0x23B2474", VA = "0x23B2474")]
	public void ࠌࢡࠕ۷()
	{
		if (this.߅\u089C\u087BӞ != null)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("_Tint");
	}

	// Token: 0x06001E9C RID: 7836 RVA: 0x0009F668 File Offset: 0x0009D868
	[Token(Token = "0x6001E9C")]
	[Address(RVA = "0x23B253C", Offset = "0x23B253C", VA = "0x23B253C")]
	public void ۲ڂ\u05B1ڨ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("back");
	}

	// Token: 0x06001E9D RID: 7837 RVA: 0x0009F6A8 File Offset: 0x0009D8A8
	[Token(Token = "0x6001E9D")]
	[Address(RVA = "0x23B2604", Offset = "0x23B2604", VA = "0x23B2604")]
	private void ڦڣղ\u0703()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001E9E RID: 7838 RVA: 0x0009F6F0 File Offset: 0x0009D8F0
	[Token(Token = "0x6001E9E")]
	[Address(RVA = "0x23B2684", Offset = "0x23B2684", VA = "0x23B2684")]
	public void \u05F8ݑ\u06ECߞ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("username");
			return;
		}
	}

	// Token: 0x06001E9F RID: 7839 RVA: 0x0009F734 File Offset: 0x0009D934
	[Token(Token = "0x6001E9F")]
	[Address(RVA = "0x23B2834", Offset = "0x23B2834", VA = "0x23B2834")]
	[PunRPC]
	private void monkeScream()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EA0 RID: 7840 RVA: 0x0009F77C File Offset: 0x0009D97C
	[Token(Token = "0x6001EA0")]
	[Address(RVA = "0x23B28B4", Offset = "0x23B28B4", VA = "0x23B28B4")]
	private void ڤۑ\u085Fݰ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EA1 RID: 7841 RVA: 0x0009F7C4 File Offset: 0x0009D9C4
	[Token(Token = "0x6001EA1")]
	[Address(RVA = "0x23B2934", Offset = "0x23B2934", VA = "0x23B2934")]
	public void \u06D6ې\u083Bࠉ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Added Winner Money");
	}

	// Token: 0x06001EA2 RID: 7842 RVA: 0x0009F804 File Offset: 0x0009DA04
	[Token(Token = "0x6001EA2")]
	[Address(RVA = "0x23B29FC", Offset = "0x23B29FC", VA = "0x23B29FC")]
	private void ࢴة߈\u05AC()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EA3 RID: 7843 RVA: 0x0009F84C File Offset: 0x0009DA4C
	[Token(Token = "0x6001EA3")]
	[Address(RVA = "0x23B2A7C", Offset = "0x23B2A7C", VA = "0x23B2A7C")]
	public void \u065F\u0839ܤ\u073C()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("M/d/yyyy");
	}

	// Token: 0x06001EA4 RID: 7844 RVA: 0x0009F88C File Offset: 0x0009DA8C
	[Token(Token = "0x6001EA4")]
	[Address(RVA = "0x23B2B44", Offset = "0x23B2B44", VA = "0x23B2B44")]
	public void ߓ\u06E3\u05C7ۋ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
	}

	// Token: 0x06001EA5 RID: 7845 RVA: 0x0009F8CC File Offset: 0x0009DACC
	[Token(Token = "0x6001EA5")]
	[Address(RVA = "0x23B2C0C", Offset = "0x23B2C0C", VA = "0x23B2C0C")]
	private void \u0658ۑ\u083Dޗ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EA6 RID: 7846 RVA: 0x0009F914 File Offset: 0x0009DB14
	[Token(Token = "0x6001EA6")]
	[Address(RVA = "0x23B2C8C", Offset = "0x23B2C8C", VA = "0x23B2C8C")]
	public void ࡀڮӌߕ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("run");
			return;
		}
	}

	// Token: 0x06001EA7 RID: 7847 RVA: 0x0009F958 File Offset: 0x0009DB58
	[Token(Token = "0x6001EA7")]
	[Address(RVA = "0x23B2E38", Offset = "0x23B2E38", VA = "0x23B2E38")]
	public void ࢰחڵࡓ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("A Player has left the Room.");
	}

	// Token: 0x06001EA8 RID: 7848 RVA: 0x0009F998 File Offset: 0x0009DB98
	[Token(Token = "0x6001EA8")]
	[Address(RVA = "0x23B2F00", Offset = "0x23B2F00", VA = "0x23B2F00")]
	private void \u082C\u0592\u0826Վ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EA9 RID: 7849 RVA: 0x0009F9E0 File Offset: 0x0009DBE0
	[Token(Token = "0x6001EA9")]
	[Address(RVA = "0x23B2F80", Offset = "0x23B2F80", VA = "0x23B2F80")]
	public void \u059AՏ\u0600\u0872()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("\n");
	}

	// Token: 0x06001EAA RID: 7850 RVA: 0x0009FA20 File Offset: 0x0009DC20
	[Token(Token = "0x6001EAA")]
	[Address(RVA = "0x23B3048", Offset = "0x23B3048", VA = "0x23B3048")]
	public void \u0832ࢳޤ\u07B5()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Right Hand");
			return;
		}
	}

	// Token: 0x06001EAB RID: 7851 RVA: 0x0009FA64 File Offset: 0x0009DC64
	[Token(Token = "0x6001EAB")]
	[Address(RVA = "0x23B31F8", Offset = "0x23B31F8", VA = "0x23B31F8")]
	public void \u066A\u059Eټ\u085A()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001EAC RID: 7852 RVA: 0x0009FA9C File Offset: 0x0009DC9C
	[Token(Token = "0x6001EAC")]
	[Address(RVA = "0x23B32C0", Offset = "0x23B32C0", VA = "0x23B32C0")]
	public void \u061B\u05EEوۈ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		bool <IsMine>k__BackingField = this.߅\u089C\u087BӞ.<IsMine>k__BackingField;
		if (<IsMine>k__BackingField)
		{
			if (!<IsMine>k__BackingField)
			{
			}
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("");
			return;
		}
	}

	// Token: 0x06001EAD RID: 7853 RVA: 0x0009FAE8 File Offset: 0x0009DCE8
	[Token(Token = "0x6001EAD")]
	[Address(RVA = "0x23B3470", Offset = "0x23B3470", VA = "0x23B3470")]
	public void ԞԌ\u086FՇ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Starting to bake textures on frame ");
	}

	// Token: 0x06001EAE RID: 7854 RVA: 0x0009FB28 File Offset: 0x0009DD28
	[Token(Token = "0x6001EAE")]
	[Address(RVA = "0x23B3538", Offset = "0x23B3538", VA = "0x23B3538")]
	public void ٠ӄ\u087Cٸ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("EnableCosmetic");
			return;
		}
	}

	// Token: 0x06001EAF RID: 7855 RVA: 0x0009FB6C File Offset: 0x0009DD6C
	[Token(Token = "0x6001EAF")]
	[Address(RVA = "0x23B36E8", Offset = "0x23B36E8", VA = "0x23B36E8")]
	private void \u05FCٺލࠆ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EB0 RID: 7856 RVA: 0x0009FBB4 File Offset: 0x0009DDB4
	[Token(Token = "0x6001EB0")]
	[Address(RVA = "0x23B3768", Offset = "0x23B3768", VA = "0x23B3768")]
	private void \u082Eժ\u0611\u086C()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EB1 RID: 7857 RVA: 0x0009FBFC File Offset: 0x0009DDFC
	[Token(Token = "0x6001EB1")]
	[Address(RVA = "0x23B37E8", Offset = "0x23B37E8", VA = "0x23B37E8")]
	public void ԙضփӌ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("username");
			return;
		}
	}

	// Token: 0x06001EB2 RID: 7858 RVA: 0x0009FC40 File Offset: 0x0009DE40
	[Token(Token = "0x6001EB2")]
	[Address(RVA = "0x23B3998", Offset = "0x23B3998", VA = "0x23B3998")]
	public void \u0881\u0743\u07EB\u0747()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
	}

	// Token: 0x06001EB3 RID: 7859 RVA: 0x0009FC80 File Offset: 0x0009DE80
	[Token(Token = "0x6001EB3")]
	[Address(RVA = "0x23B3A5C", Offset = "0x23B3A5C", VA = "0x23B3A5C")]
	public void Ԁוև\u065B()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("FingerTip");
	}

	// Token: 0x06001EB4 RID: 7860 RVA: 0x0009FCC0 File Offset: 0x0009DEC0
	[Token(Token = "0x6001EB4")]
	[Address(RVA = "0x23B3B24", Offset = "0x23B3B24", VA = "0x23B3B24")]
	public void \u05AC\u07F0\u07EEࡥ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("MetaId");
			return;
		}
	}

	// Token: 0x06001EB5 RID: 7861 RVA: 0x0009FD04 File Offset: 0x0009DF04
	[Token(Token = "0x6001EB5")]
	[Address(RVA = "0x23B3CD4", Offset = "0x23B3CD4", VA = "0x23B3CD4")]
	private void ר\u0701\u05A6ޖ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EB6 RID: 7862 RVA: 0x0009FD4C File Offset: 0x0009DF4C
	[Token(Token = "0x6001EB6")]
	[Address(RVA = "0x23B3D54", Offset = "0x23B3D54", VA = "0x23B3D54")]
	public void ݡز٨հ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("BN");
	}

	// Token: 0x06001EB7 RID: 7863 RVA: 0x0009FD8C File Offset: 0x0009DF8C
	[Token(Token = "0x6001EB7")]
	[Address(RVA = "0x23B3E1C", Offset = "0x23B3E1C", VA = "0x23B3E1C")]
	public MonkeScream()
	{
	}

	// Token: 0x06001EB8 RID: 7864 RVA: 0x0009FDA0 File Offset: 0x0009DFA0
	[Token(Token = "0x6001EB8")]
	[Address(RVA = "0x23B3E24", Offset = "0x23B3E24", VA = "0x23B3E24")]
	public void \u070Fߨ\u05B0ۈ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Error");
	}

	// Token: 0x06001EB9 RID: 7865 RVA: 0x0009FDE0 File Offset: 0x0009DFE0
	[Token(Token = "0x6001EB9")]
	[Address(RVA = "0x23B3EEC", Offset = "0x23B3EEC", VA = "0x23B3EEC")]
	private void \u06E5\u065F\u0828\u05B3()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EBA RID: 7866 RVA: 0x0009FE28 File Offset: 0x0009E028
	[Token(Token = "0x6001EBA")]
	[Address(RVA = "0x23B3F6C", Offset = "0x23B3F6C", VA = "0x23B3F6C")]
	private void ݜӆ\u0870\u05FB()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EBB RID: 7867 RVA: 0x0009FE70 File Offset: 0x0009E070
	[Token(Token = "0x6001EBB")]
	[Address(RVA = "0x23B3FEC", Offset = "0x23B3FEC", VA = "0x23B3FEC")]
	public void \u0827ߜ\u07FD\u07F4()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Try Connect To Server...");
			return;
		}
	}

	// Token: 0x06001EBC RID: 7868 RVA: 0x0009FEB4 File Offset: 0x0009E0B4
	[Token(Token = "0x6001EBC")]
	[Address(RVA = "0x23B419C", Offset = "0x23B419C", VA = "0x23B419C")]
	private void \u0833\u05B4ݑޣ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EBD RID: 7869 RVA: 0x0009FEFC File Offset: 0x0009E0FC
	[Token(Token = "0x6001EBD")]
	[Address(RVA = "0x23B421C", Offset = "0x23B421C", VA = "0x23B421C")]
	public void ޒ\u0816Ӑ۱()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("PRESS AGAIN TO CONFIRM");
			return;
		}
	}

	// Token: 0x06001EBE RID: 7870 RVA: 0x0009FF40 File Offset: 0x0009E140
	[Token(Token = "0x6001EBE")]
	[Address(RVA = "0x23B43CC", Offset = "0x23B43CC", VA = "0x23B43CC")]
	private void ץڱࠓࢲ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EBF RID: 7871 RVA: 0x0009FF88 File Offset: 0x0009E188
	[Token(Token = "0x6001EBF")]
	[Address(RVA = "0x23B444C", Offset = "0x23B444C", VA = "0x23B444C")]
	private void \u058E\u0746\u0654\u05C5()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EC0 RID: 7872 RVA: 0x0009FFD0 File Offset: 0x0009E1D0
	[Token(Token = "0x6001EC0")]
	[Address(RVA = "0x23B44CC", Offset = "0x23B44CC", VA = "0x23B44CC")]
	private void ܬݒעف()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EC1 RID: 7873 RVA: 0x000A0018 File Offset: 0x0009E218
	[Token(Token = "0x6001EC1")]
	[Address(RVA = "0x23B454C", Offset = "0x23B454C", VA = "0x23B454C")]
	public void \u0733ߜܣԻ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("You are on an outdated version of Capuchin. Your version is ");
	}

	// Token: 0x06001EC2 RID: 7874 RVA: 0x000A0058 File Offset: 0x0009E258
	[Token(Token = "0x6001EC2")]
	[Address(RVA = "0x23B4614", Offset = "0x23B4614", VA = "0x23B4614")]
	public void ۊո\u0612\u0595()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Charging...");
	}

	// Token: 0x06001EC3 RID: 7875 RVA: 0x000A0098 File Offset: 0x0009E298
	[Token(Token = "0x6001EC3")]
	[Address(RVA = "0x23B46DC", Offset = "0x23B46DC", VA = "0x23B46DC")]
	public void Ӻ\u0828\u07BD\u06ED()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("closeToObject");
			return;
		}
	}

	// Token: 0x06001EC4 RID: 7876 RVA: 0x000A00DC File Offset: 0x0009E2DC
	[Token(Token = "0x6001EC4")]
	[Address(RVA = "0x23B488C", Offset = "0x23B488C", VA = "0x23B488C")]
	public void Start()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("monke is not my monke");
	}

	// Token: 0x06001EC5 RID: 7877 RVA: 0x000A011C File Offset: 0x0009E31C
	[Token(Token = "0x6001EC5")]
	[Address(RVA = "0x23B4950", Offset = "0x23B4950", VA = "0x23B4950")]
	public void ݤۅࢦӃ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("_Tint");
	}

	// Token: 0x06001EC6 RID: 7878 RVA: 0x000A015C File Offset: 0x0009E35C
	[Token(Token = "0x6001EC6")]
	[Address(RVA = "0x23B4A18", Offset = "0x23B4A18", VA = "0x23B4A18")]
	public void աؾێړ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("You are on an outdated version of Capuchin. Your version is ");
	}

	// Token: 0x06001EC7 RID: 7879 RVA: 0x000A019C File Offset: 0x0009E39C
	[Token(Token = "0x6001EC7")]
	[Address(RVA = "0x23B4AE0", Offset = "0x23B4AE0", VA = "0x23B4AE0")]
	public void ڍ\u058Bݗࡣ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("username");
	}

	// Token: 0x06001EC8 RID: 7880 RVA: 0x000A01DC File Offset: 0x0009E3DC
	[Token(Token = "0x6001EC8")]
	[Address(RVA = "0x23B4BA8", Offset = "0x23B4BA8", VA = "0x23B4BA8")]
	public void \u0614ࢥӴ\u086C()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Purchase For ");
			return;
		}
	}

	// Token: 0x06001EC9 RID: 7881 RVA: 0x000A0220 File Offset: 0x0009E420
	[Token(Token = "0x6001EC9")]
	[Address(RVA = "0x23B4D54", Offset = "0x23B4D54", VA = "0x23B4D54")]
	public void וࡪךӧ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("username");
	}

	// Token: 0x06001ECA RID: 7882 RVA: 0x000A0260 File Offset: 0x0009E460
	[Token(Token = "0x6001ECA")]
	[Address(RVA = "0x23B4E1C", Offset = "0x23B4E1C", VA = "0x23B4E1C")]
	public void ד\u073C\u0613چ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("false");
			return;
		}
	}

	// Token: 0x06001ECB RID: 7883 RVA: 0x000A02A4 File Offset: 0x0009E4A4
	[Token(Token = "0x6001ECB")]
	[Address(RVA = "0x23B4FC8", Offset = "0x23B4FC8", VA = "0x23B4FC8")]
	private void \u05A4ӠՒࡤ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001ECC RID: 7884 RVA: 0x000A02EC File Offset: 0x0009E4EC
	[Token(Token = "0x6001ECC")]
	[Address(RVA = "0x23B5048", Offset = "0x23B5048", VA = "0x23B5048")]
	public void څࡣڐ\u0657()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.");
			return;
		}
	}

	// Token: 0x06001ECD RID: 7885 RVA: 0x000A0330 File Offset: 0x0009E530
	[Token(Token = "0x6001ECD")]
	[Address(RVA = "0x23B51F8", Offset = "0x23B51F8", VA = "0x23B51F8")]
	public void \u05C1ܡԘޘ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Trying Getting Entilement...");
	}

	// Token: 0x06001ECE RID: 7886 RVA: 0x000A0370 File Offset: 0x0009E570
	[Token(Token = "0x6001ECE")]
	[Address(RVA = "0x23B52C0", Offset = "0x23B52C0", VA = "0x23B52C0")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Joined a Room.");
			return;
		}
	}

	// Token: 0x06001ECF RID: 7887 RVA: 0x000A03B4 File Offset: 0x0009E5B4
	[Token(Token = "0x6001ECF")]
	[Address(RVA = "0x23B5470", Offset = "0x23B5470", VA = "0x23B5470")]
	public void Ճࠈޛݞ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("monke is not my monke");
	}

	// Token: 0x06001ED0 RID: 7888 RVA: 0x000A03F4 File Offset: 0x0009E5F4
	[Token(Token = "0x6001ED0")]
	[Address(RVA = "0x23B5538", Offset = "0x23B5538", VA = "0x23B5538")]
	public void گ\u085E\u073Dڊ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Vertical");
	}

	// Token: 0x06001ED1 RID: 7889 RVA: 0x000A0434 File Offset: 0x0009E634
	[Token(Token = "0x6001ED1")]
	[Address(RVA = "0x23B5600", Offset = "0x23B5600", VA = "0x23B5600")]
	public void حتݻ\u05B0()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Agreed");
	}

	// Token: 0x06001ED2 RID: 7890 RVA: 0x000A0474 File Offset: 0x0009E674
	[Token(Token = "0x6001ED2")]
	[Address(RVA = "0x23B56C8", Offset = "0x23B56C8", VA = "0x23B56C8")]
	public void ݫࢷࠃ\u0820()
	{
		float deltaTime = Time.deltaTime;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("clickLol");
	}

	// Token: 0x06001ED3 RID: 7891 RVA: 0x000A04A4 File Offset: 0x0009E6A4
	[Token(Token = "0x6001ED3")]
	[Address(RVA = "0x23B5878", Offset = "0x23B5878", VA = "0x23B5878")]
	private void ݨ\u0703ࢳԠ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001ED4 RID: 7892 RVA: 0x000A04EC File Offset: 0x0009E6EC
	[Token(Token = "0x6001ED4")]
	[Address(RVA = "0x23B58F8", Offset = "0x23B58F8", VA = "0x23B58F8")]
	private void ӧ\u07BA\u06E3ڞ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001ED5 RID: 7893 RVA: 0x000A0534 File Offset: 0x0009E734
	[Token(Token = "0x6001ED5")]
	[Address(RVA = "0x23B5978", Offset = "0x23B5978", VA = "0x23B5978")]
	private void ߥԐ\u085Fڰ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001ED6 RID: 7894 RVA: 0x000A057C File Offset: 0x0009E77C
	[Token(Token = "0x6001ED6")]
	[Address(RVA = "0x23B59F8", Offset = "0x23B59F8", VA = "0x23B59F8")]
	private void ו\u088E٥ݕ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001ED7 RID: 7895 RVA: 0x000A05C4 File Offset: 0x0009E7C4
	[Token(Token = "0x6001ED7")]
	[Address(RVA = "0x23B5A78", Offset = "0x23B5A78", VA = "0x23B5A78")]
	public void ی\u0823ڇݔ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("username");
			return;
		}
	}

	// Token: 0x06001ED8 RID: 7896 RVA: 0x000A0608 File Offset: 0x0009E808
	[Token(Token = "0x6001ED8")]
	[Address(RVA = "0x23B5C28", Offset = "0x23B5C28", VA = "0x23B5C28")]
	public void ޥ\u089Dڢ\u06E3()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		Debug.Log("TurnAmount");
	}

	// Token: 0x06001ED9 RID: 7897 RVA: 0x000A0644 File Offset: 0x0009E844
	[Token(Token = "0x6001ED9")]
	[Address(RVA = "0x23B5CF0", Offset = "0x23B5CF0", VA = "0x23B5CF0")]
	public void ޙߍ\u081A\u0651()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Calling success callback. baking meshes");
	}

	// Token: 0x06001EDA RID: 7898 RVA: 0x000A0684 File Offset: 0x0009E884
	[Token(Token = "0x6001EDA")]
	[Address(RVA = "0x23B5DB8", Offset = "0x23B5DB8", VA = "0x23B5DB8")]
	private void ԭݪӃ\u058B()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EDB RID: 7899 RVA: 0x000A06CC File Offset: 0x0009E8CC
	[Token(Token = "0x6001EDB")]
	[Address(RVA = "0x23B5E38", Offset = "0x23B5E38", VA = "0x23B5E38")]
	public void Update()
	{
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("monke screamed");
			return;
		}
	}

	// Token: 0x06001EDC RID: 7900 RVA: 0x000A0708 File Offset: 0x0009E908
	[Token(Token = "0x6001EDC")]
	[Address(RVA = "0x23B5FE0", Offset = "0x23B5FE0", VA = "0x23B5FE0")]
	public void \u05F7ԝߠӱ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Starting to bake textures on frame ");
			return;
		}
	}

	// Token: 0x06001EDD RID: 7901 RVA: 0x000A074C File Offset: 0x0009E94C
	[Token(Token = "0x6001EDD")]
	[Address(RVA = "0x23B6190", Offset = "0x23B6190", VA = "0x23B6190")]
	public void \u073BօӁ\u059A()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player was caught cheating");
	}

	// Token: 0x06001EDE RID: 7902 RVA: 0x000A078C File Offset: 0x0009E98C
	[Token(Token = "0x6001EDE")]
	[Address(RVA = "0x23B6258", Offset = "0x23B6258", VA = "0x23B6258")]
	public void \u073DӦ۵\u07F0()
	{
		float volume;
		this.ءչۿݿ.volume = volume;
	}

	// Token: 0x06001EDF RID: 7903 RVA: 0x000A07C0 File Offset: 0x0009E9C0
	[Token(Token = "0x6001EDF")]
	[Address(RVA = "0x23B6320", Offset = "0x23B6320", VA = "0x23B6320")]
	public void \u060B\u0886\u0730\u05FF()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("containsStaff");
			return;
		}
	}

	// Token: 0x06001EE0 RID: 7904 RVA: 0x000A0804 File Offset: 0x0009EA04
	[Token(Token = "0x6001EE0")]
	[Address(RVA = "0x23B64D0", Offset = "0x23B64D0", VA = "0x23B64D0")]
	public void ބՅ١\u082D()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("On");
	}

	// Token: 0x06001EE1 RID: 7905 RVA: 0x000A0844 File Offset: 0x0009EA44
	[Token(Token = "0x6001EE1")]
	[Address(RVA = "0x23B6598", Offset = "0x23B6598", VA = "0x23B6598")]
	public void ݶߔ\u081Aպ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("A Player has left the Room.");
	}

	// Token: 0x06001EE2 RID: 7906 RVA: 0x000A0884 File Offset: 0x0009EA84
	[Token(Token = "0x6001EE2")]
	[Address(RVA = "0x23B6660", Offset = "0x23B6660", VA = "0x23B6660")]
	public void צ\u0874ڵ\u059A()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("ChangeToTagged");
			return;
		}
	}

	// Token: 0x06001EE3 RID: 7907 RVA: 0x000A08C8 File Offset: 0x0009EAC8
	[Token(Token = "0x6001EE3")]
	[Address(RVA = "0x23B6810", Offset = "0x23B6810", VA = "0x23B6810")]
	private void \u0829\u073EցԞ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EE4 RID: 7908 RVA: 0x000A0910 File Offset: 0x0009EB10
	[Token(Token = "0x6001EE4")]
	[Address(RVA = "0x23B6890", Offset = "0x23B6890", VA = "0x23B6890")]
	public void \u086Bԍࡊڭ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("CASUAL");
	}

	// Token: 0x06001EE5 RID: 7909 RVA: 0x000A0950 File Offset: 0x0009EB50
	[Token(Token = "0x6001EE5")]
	[Address(RVA = "0x23B6958", Offset = "0x23B6958", VA = "0x23B6958")]
	public void ޝԖ\u0836\u06D8()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("CapuchinStore");
	}

	// Token: 0x06001EE6 RID: 7910 RVA: 0x000A0990 File Offset: 0x0009EB90
	[Token(Token = "0x6001EE6")]
	[Address(RVA = "0x23B6A20", Offset = "0x23B6A20", VA = "0x23B6A20")]
	public void \u0599ږࠆ\u065F()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("ENABLE");
			return;
		}
	}

	// Token: 0x06001EE7 RID: 7911 RVA: 0x000A09D4 File Offset: 0x0009EBD4
	[Token(Token = "0x6001EE7")]
	[Address(RVA = "0x23B6BD0", Offset = "0x23B6BD0", VA = "0x23B6BD0")]
	private void \u0608\u0822ӷր()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EE8 RID: 7912 RVA: 0x000A0A1C File Offset: 0x0009EC1C
	[Token(Token = "0x6001EE8")]
	[Address(RVA = "0x23B6C50", Offset = "0x23B6C50", VA = "0x23B6C50")]
	public void \u0732ڙԒࢺ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("NetworkPlayer");
			return;
		}
	}

	// Token: 0x06001EE9 RID: 7913 RVA: 0x000A0A60 File Offset: 0x0009EC60
	[Token(Token = "0x6001EE9")]
	[Address(RVA = "0x23B6E00", Offset = "0x23B6E00", VA = "0x23B6E00")]
	public void \u0870\u05B3Ց\u066A()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("On");
			return;
		}
	}

	// Token: 0x06001EEA RID: 7914 RVA: 0x000A0AA4 File Offset: 0x0009ECA4
	[Token(Token = "0x6001EEA")]
	[Address(RVA = "0x23B6FB0", Offset = "0x23B6FB0", VA = "0x23B6FB0")]
	public void ࠏޤݳ\u06DD()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("ChangeToRegular");
	}

	// Token: 0x06001EEB RID: 7915 RVA: 0x000A0AE4 File Offset: 0x0009ECE4
	[Token(Token = "0x6001EEB")]
	[Address(RVA = "0x23B7078", Offset = "0x23B7078", VA = "0x23B7078")]
	public void չւت\u061E()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("DisableCosmetic");
			return;
		}
	}

	// Token: 0x06001EEC RID: 7916 RVA: 0x000A0B28 File Offset: 0x0009ED28
	[Token(Token = "0x6001EEC")]
	[Address(RVA = "0x23B7224", Offset = "0x23B7224", VA = "0x23B7224")]
	public void ߒ\u065EՎࡖ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("run");
	}

	// Token: 0x06001EED RID: 7917 RVA: 0x000A0B68 File Offset: 0x0009ED68
	[Token(Token = "0x6001EED")]
	[Address(RVA = "0x23B72EC", Offset = "0x23B72EC", VA = "0x23B72EC")]
	public void \u0830ݥ\u0896Ԕ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Open");
	}

	// Token: 0x06001EEE RID: 7918 RVA: 0x000A0BA8 File Offset: 0x0009EDA8
	[Token(Token = "0x6001EEE")]
	[Address(RVA = "0x23B73B4", Offset = "0x23B73B4", VA = "0x23B73B4")]
	private void \u0882\u0744\u0609\u05BC()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EEF RID: 7919 RVA: 0x000A0BF0 File Offset: 0x0009EDF0
	[Token(Token = "0x6001EEF")]
	[Address(RVA = "0x23B7434", Offset = "0x23B7434", VA = "0x23B7434")]
	public void \u05A5Ԇࠇޏ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("M/d/yyyy");
	}

	// Token: 0x06001EF0 RID: 7920 RVA: 0x000A0C30 File Offset: 0x0009EE30
	[Token(Token = "0x6001EF0")]
	[Address(RVA = "0x23B74FC", Offset = "0x23B74FC", VA = "0x23B74FC")]
	public void ࢶ٠\u086D\u0708()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		PhotonView ߅_u089C_u087BӞ = this.߅\u089C\u087BӞ;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
	}

	// Token: 0x06001EF1 RID: 7921 RVA: 0x000A0C70 File Offset: 0x0009EE70
	[Token(Token = "0x6001EF1")]
	[Address(RVA = "0x23B76AC", Offset = "0x23B76AC", VA = "0x23B76AC")]
	private void ہӢ\u066D\u05F3()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EF2 RID: 7922 RVA: 0x000A0CB8 File Offset: 0x0009EEB8
	[Token(Token = "0x6001EF2")]
	[Address(RVA = "0x23B772C", Offset = "0x23B772C", VA = "0x23B772C")]
	private void \u0874ࡀݑٲ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EF3 RID: 7923 RVA: 0x000A0D00 File Offset: 0x0009EF00
	[Token(Token = "0x6001EF3")]
	[Address(RVA = "0x23B77AC", Offset = "0x23B77AC", VA = "0x23B77AC")]
	public void \u085Dۍ\u0659Ӂ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Joined a Room.");
			return;
		}
	}

	// Token: 0x06001EF4 RID: 7924 RVA: 0x000A0D44 File Offset: 0x0009EF44
	[Token(Token = "0x6001EF4")]
	[Address(RVA = "0x23B795C", Offset = "0x23B795C", VA = "0x23B795C")]
	public void Գӿېչ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("META");
	}

	// Token: 0x06001EF5 RID: 7925 RVA: 0x000A0D84 File Offset: 0x0009EF84
	[Token(Token = "0x6001EF5")]
	[Address(RVA = "0x23B7A24", Offset = "0x23B7A24", VA = "0x23B7A24")]
	public void ࡅݐ\u082Dք()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
	}

	// Token: 0x06001EF6 RID: 7926 RVA: 0x000A0DC4 File Offset: 0x0009EFC4
	[Token(Token = "0x6001EF6")]
	[Address(RVA = "0x23B7AEC", Offset = "0x23B7AEC", VA = "0x23B7AEC")]
	public void \u055A\u08B5\u0733ӡ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Failed to login, please restart");
			return;
		}
	}

	// Token: 0x06001EF7 RID: 7927 RVA: 0x000A0E08 File Offset: 0x0009F008
	[Token(Token = "0x6001EF7")]
	[Address(RVA = "0x23B7C9C", Offset = "0x23B7C9C", VA = "0x23B7C9C")]
	private void \u0707ګ١ڀ()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001EF8 RID: 7928 RVA: 0x000A0E50 File Offset: 0x0009F050
	[Token(Token = "0x6001EF8")]
	[Address(RVA = "0x23B7D1C", Offset = "0x23B7D1C", VA = "0x23B7D1C")]
	public void ں٢ࡡ\u05EC()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("We don't need this electrical box");
			return;
		}
	}

	// Token: 0x06001EF9 RID: 7929 RVA: 0x000A0E94 File Offset: 0x0009F094
	[Token(Token = "0x6001EF9")]
	[Address(RVA = "0x23B7ECC", Offset = "0x23B7ECC", VA = "0x23B7ECC")]
	public void ӷӛࠔ\u07AC()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("User has been reported for: ");
	}

	// Token: 0x06001EFA RID: 7930 RVA: 0x000A0ED4 File Offset: 0x0009F0D4
	[Token(Token = "0x6001EFA")]
	[Address(RVA = "0x23B7F94", Offset = "0x23B7F94", VA = "0x23B7F94")]
	public void Ҽ\u08B5ځ\u0658()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Combine textures & build combined mesh all at once");
			return;
		}
	}

	// Token: 0x06001EFB RID: 7931 RVA: 0x000A0F18 File Offset: 0x0009F118
	[Token(Token = "0x6001EFB")]
	[Address(RVA = "0x23B8144", Offset = "0x23B8144", VA = "0x23B8144")]
	public void \u0882צ\u0821\u05B4()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001EFC RID: 7932 RVA: 0x000A0F50 File Offset: 0x0009F150
	[Token(Token = "0x6001EFC")]
	[Address(RVA = "0x23B820C", Offset = "0x23B820C", VA = "0x23B820C")]
	public void ދ\u05A3\u06DCہ()
	{
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			float volume;
			this.ءչۿݿ.volume = volume;
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Player");
	}

	// Token: 0x06001EFD RID: 7933 RVA: 0x000A0F90 File Offset: 0x0009F190
	[Token(Token = "0x6001EFD")]
	[Address(RVA = "0x23B82D4", Offset = "0x23B82D4", VA = "0x23B82D4")]
	public void ӒԂࡩࡓ()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("_BumpScale");
	}

	// Token: 0x06001EFE RID: 7934 RVA: 0x000A0FC8 File Offset: 0x0009F1C8
	[Token(Token = "0x6001EFE")]
	[Address(RVA = "0x23B8484", Offset = "0x23B8484", VA = "0x23B8484")]
	public void ࡊ\u0592\u07AB\u05B2()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			return;
		}
	}

	// Token: 0x06001EFF RID: 7935 RVA: 0x000A1004 File Offset: 0x0009F204
	[Token(Token = "0x6001EFF")]
	[Address(RVA = "0x23B8634", Offset = "0x23B8634", VA = "0x23B8634")]
	private void \u065D۶\u0833\u0610()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001F00 RID: 7936 RVA: 0x000A104C File Offset: 0x0009F24C
	[Token(Token = "0x6001F00")]
	[Address(RVA = "0x23B86B4", Offset = "0x23B86B4", VA = "0x23B86B4")]
	private void \u059A\u05B8ߧ\u06FD()
	{
		AudioClip[] ط_u088FՔ۰ = this.ط\u088FՔ۰;
		AudioClip.PCMReaderCallback pcmreaderCallback = ط_u088FՔ۰.m_PCMReaderCallback;
		AudioSource audioSource = this.ءչۿݿ;
		object target = ط_u088FՔ۰.m_PCMReaderCallback.m_target;
		this.ءչۿݿ.Play();
	}

	// Token: 0x06001F01 RID: 7937 RVA: 0x000A1094 File Offset: 0x0009F294
	[Token(Token = "0x6001F01")]
	[Address(RVA = "0x23B8734", Offset = "0x23B8734", VA = "0x23B8734")]
	public void ࢭ\u0589\u0892\u058A()
	{
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
		if (this.߅\u089C\u087BӞ.<IsMine>k__BackingField)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("typesOfTalk");
			return;
		}
	}

	// Token: 0x040003F7 RID: 1015
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003F7")]
	public AudioClip[] ط\u088FՔ۰;

	// Token: 0x040003F8 RID: 1016
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003F8")]
	public AudioSource ءչۿݿ;

	// Token: 0x040003F9 RID: 1017
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003F9")]
	public float ݶՈהՇ;

	// Token: 0x040003FA RID: 1018
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003FA")]
	public PhotonView ߅\u089C\u087BӞ;
}
