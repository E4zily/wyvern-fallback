﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000B9 RID: 185
[Token(Token = "0x20000B9")]
public class ElevatorManager : MonoBehaviour
{
	// Token: 0x06001AC3 RID: 6851 RVA: 0x0008CD1C File Offset: 0x0008AF1C
	[Token(Token = "0x6001AC3")]
	[Address(RVA = "0x28E09DC", Offset = "0x28E09DC", VA = "0x28E09DC")]
	public void ڠ۷\u061F\u06E2()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AC4 RID: 6852 RVA: 0x0008CD64 File Offset: 0x0008AF64
	[Token(Token = "0x6001AC4")]
	[Address(RVA = "0x28E0A34", Offset = "0x28E0A34", VA = "0x28E0A34")]
	public void ܩࡓ\u07FEՔ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AC5 RID: 6853 RVA: 0x0008CDAC File Offset: 0x0008AFAC
	[Token(Token = "0x6001AC5")]
	[Address(RVA = "0x28DF268", Offset = "0x28DF268", VA = "0x28DF268")]
	public void ԙہ\u0826Ӽ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AC6 RID: 6854 RVA: 0x0008CDC8 File Offset: 0x0008AFC8
	[Token(Token = "0x6001AC6")]
	[Address(RVA = "0x28E0A8C", Offset = "0x28E0A8C", VA = "0x28E0A8C")]
	public void צ\u055F\u07AC\u0658()
	{
	}

	// Token: 0x06001AC7 RID: 6855 RVA: 0x0008CDDC File Offset: 0x0008AFDC
	[Token(Token = "0x6001AC7")]
	[Address(RVA = "0x28E0B8C", Offset = "0x28E0B8C", VA = "0x28E0B8C")]
	public void \u05C9ֆڎӦ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AC8 RID: 6856 RVA: 0x0008CE24 File Offset: 0x0008B024
	[Token(Token = "0x6001AC8")]
	[Address(RVA = "0x28DE25C", Offset = "0x28DE25C", VA = "0x28DE25C")]
	public void ܐݭӐ\u0640()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AC9 RID: 6857 RVA: 0x0008CE40 File Offset: 0x0008B040
	[Token(Token = "0x6001AC9")]
	[Address(RVA = "0x28E016C", Offset = "0x28E016C", VA = "0x28E016C")]
	public void \u07BAޚՑԯ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001ACA RID: 6858 RVA: 0x0008CE5C File Offset: 0x0008B05C
	[Token(Token = "0x6001ACA")]
	[Address(RVA = "0x28E0BE4", Offset = "0x28E0BE4", VA = "0x28E0BE4")]
	public void ت\u0612Փ\u06E5()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		this.ࠍԠԢأ.enabled = (enabled != 0L);
	}

	// Token: 0x06001ACB RID: 6859 RVA: 0x0008CE9C File Offset: 0x0008B09C
	[Token(Token = "0x6001ACB")]
	[Address(RVA = "0x28E0C3C", Offset = "0x28E0C3C", VA = "0x28E0C3C")]
	public void \u0557ӑӔӈ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001ACC RID: 6860 RVA: 0x0008CEEC File Offset: 0x0008B0EC
	[Token(Token = "0x6001ACC")]
	[Address(RVA = "0x28E0C94", Offset = "0x28E0C94", VA = "0x28E0C94")]
	public void Ӻ\u0828\u07BD\u06ED()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)16384;
		}
	}

	// Token: 0x06001ACD RID: 6861 RVA: 0x0008CF48 File Offset: 0x0008B148
	[Token(Token = "0x6001ACD")]
	[Address(RVA = "0x28E0D20", Offset = "0x28E0D20", VA = "0x28E0D20")]
	public void ڰذڦױ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001ACE RID: 6862 RVA: 0x0008CF90 File Offset: 0x0008B190
	[Token(Token = "0x6001ACE")]
	[Address(RVA = "0x28E0D78", Offset = "0x28E0D78", VA = "0x28E0D78")]
	public void \u087E\u058F\u074BՐ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001ACF RID: 6863 RVA: 0x0008CFD8 File Offset: 0x0008B1D8
	[Token(Token = "0x6001ACF")]
	[Address(RVA = "0x28E0DD0", Offset = "0x28E0DD0", VA = "0x28E0DD0")]
	public void \u0738ںےݪ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AD0 RID: 6864 RVA: 0x0008CFF4 File Offset: 0x0008B1F4
	[Token(Token = "0x6001AD0")]
	[Address(RVA = "0x28E0ED0", Offset = "0x28E0ED0", VA = "0x28E0ED0")]
	public void ܘ\u0828ߒݚ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AD1 RID: 6865 RVA: 0x0008D010 File Offset: 0x0008B210
	[Token(Token = "0x6001AD1")]
	[Address(RVA = "0x28E0FD0", Offset = "0x28E0FD0", VA = "0x28E0FD0")]
	public void ھ\u05FC\u0650Ԉ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		long enabled2 = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AD2 RID: 6866 RVA: 0x0008D044 File Offset: 0x0008B244
	[Token(Token = "0x6001AD2")]
	[Address(RVA = "0x28E1024", Offset = "0x28E1024", VA = "0x28E1024")]
	public void ڵݬ\u055D߀()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AD3 RID: 6867 RVA: 0x0008D060 File Offset: 0x0008B260
	[Token(Token = "0x6001AD3")]
	[Address(RVA = "0x28E1124", Offset = "0x28E1124", VA = "0x28E1124")]
	public void \u0832ࢳޤ\u07B5()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			long num2 = 1L;
			this.ݶՈהՇ = (float)24576;
			this.ҽߙԑץ = (num2 != 0L);
		}
	}

	// Token: 0x06001AD4 RID: 6868 RVA: 0x0008D0C8 File Offset: 0x0008B2C8
	[Token(Token = "0x6001AD4")]
	[Address(RVA = "0x28DE814", Offset = "0x28DE814", VA = "0x28DE814")]
	public void \u0650\u06E3\u0654ב()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AD5 RID: 6869 RVA: 0x0008D0E4 File Offset: 0x0008B2E4
	[Token(Token = "0x6001AD5")]
	[Address(RVA = "0x28E11B4", Offset = "0x28E11B4", VA = "0x28E11B4")]
	public void ࡪ\u0603ࡆբ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AD6 RID: 6870 RVA: 0x0008D100 File Offset: 0x0008B300
	[Token(Token = "0x6001AD6")]
	[Address(RVA = "0x28E12B4", Offset = "0x28E12B4", VA = "0x28E12B4")]
	public void ࡢԴ߉گ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AD7 RID: 6871 RVA: 0x0008D150 File Offset: 0x0008B350
	[Token(Token = "0x6001AD7")]
	[Address(RVA = "0x28DDDA4", Offset = "0x28DDDA4", VA = "0x28DDDA4")]
	public void Թ\u082F\u0594ԩ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AD8 RID: 6872 RVA: 0x0008D16C File Offset: 0x0008B36C
	[Token(Token = "0x6001AD8")]
	[Address(RVA = "0x28E130C", Offset = "0x28E130C", VA = "0x28E130C")]
	public void ߨ\u0700ޜ\u07FB()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001AD9 RID: 6873 RVA: 0x0008D198 File Offset: 0x0008B398
	[Token(Token = "0x6001AD9")]
	[Address(RVA = "0x28E1360", Offset = "0x28E1360", VA = "0x28E1360")]
	public void \u07FE\u0882Զ\u066D()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)16384;
		}
	}

	// Token: 0x06001ADA RID: 6874 RVA: 0x0008D1F4 File Offset: 0x0008B3F4
	[Token(Token = "0x6001ADA")]
	[Address(RVA = "0x28E13EC", Offset = "0x28E13EC", VA = "0x28E13EC")]
	public void \u061B\u05EEوۈ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			long num2 = 1L;
			this.ݶՈהՇ = (float)32768;
			this.ҽߙԑץ = (num2 != 0L);
		}
	}

	// Token: 0x06001ADB RID: 6875 RVA: 0x0008D25C File Offset: 0x0008B45C
	[Token(Token = "0x6001ADB")]
	[Address(RVA = "0x28E147C", Offset = "0x28E147C", VA = "0x28E147C")]
	public void \u055A\u08B5\u0733ӡ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)24576;
		}
	}

	// Token: 0x06001ADC RID: 6876 RVA: 0x0008D2B8 File Offset: 0x0008B4B8
	[Token(Token = "0x6001ADC")]
	[Address(RVA = "0x28E1508", Offset = "0x28E1508", VA = "0x28E1508")]
	public void \u05ABࡡ\u07ABݾ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 1L;
			long num2 = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)40960;
			this.ҽߙԑץ = (num2 != 0L);
		}
	}

	// Token: 0x06001ADD RID: 6877 RVA: 0x0008D320 File Offset: 0x0008B520
	[Token(Token = "0x6001ADD")]
	[Address(RVA = "0x28E1598", Offset = "0x28E1598", VA = "0x28E1598")]
	public void ӿ\u05BBࡩߘ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001ADE RID: 6878 RVA: 0x0008D368 File Offset: 0x0008B568
	[Token(Token = "0x6001ADE")]
	[Address(RVA = "0x28DE638", Offset = "0x28DE638", VA = "0x28DE638")]
	public void מ١ࡃ\u06FE()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001ADF RID: 6879 RVA: 0x0008D384 File Offset: 0x0008B584
	[Token(Token = "0x6001ADF")]
	[Address(RVA = "0x28E15F0", Offset = "0x28E15F0", VA = "0x28E15F0")]
	public void \u07B6կպ߃()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)17655;
		}
	}

	// Token: 0x06001AE0 RID: 6880 RVA: 0x0008D3E0 File Offset: 0x0008B5E0
	[Token(Token = "0x6001AE0")]
	[Address(RVA = "0x28E1678", Offset = "0x28E1678", VA = "0x28E1678")]
	public void Update()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)16800;
		}
	}

	// Token: 0x06001AE1 RID: 6881 RVA: 0x0008D43C File Offset: 0x0008B63C
	[Token(Token = "0x6001AE1")]
	[Address(RVA = "0x28DF9D8", Offset = "0x28DF9D8", VA = "0x28DF9D8")]
	public void ࢮࠍ\u06D9ࠉ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AE2 RID: 6882 RVA: 0x0008D458 File Offset: 0x0008B658
	[Token(Token = "0x6001AE2")]
	[Address(RVA = "0x28E16F8", Offset = "0x28E16F8", VA = "0x28E16F8")]
	public void \u07FFݼ\u058F\u083A()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AE3 RID: 6883 RVA: 0x0008D494 File Offset: 0x0008B694
	[Token(Token = "0x6001AE3")]
	[Address(RVA = "0x28E174C", Offset = "0x28E174C", VA = "0x28E174C")]
	public void \u0731\u0885\u05CCݏ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		long enabled2 = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AE4 RID: 6884 RVA: 0x0008D4C8 File Offset: 0x0008B6C8
	[Token(Token = "0x6001AE4")]
	[Address(RVA = "0x28E17A0", Offset = "0x28E17A0", VA = "0x28E17A0")]
	public void ܫ\u070Fۃ\u07F2()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)49152;
		}
	}

	// Token: 0x06001AE5 RID: 6885 RVA: 0x0008D524 File Offset: 0x0008B724
	[Token(Token = "0x6001AE5")]
	[Address(RVA = "0x28E1830", Offset = "0x28E1830", VA = "0x28E1830")]
	public void \u06FDՒ߄ࢫ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AE6 RID: 6886 RVA: 0x0008D540 File Offset: 0x0008B740
	[Token(Token = "0x6001AE6")]
	[Address(RVA = "0x28DDCA4", Offset = "0x28DDCA4", VA = "0x28DDCA4")]
	public void ݡࡠࡃܜ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AE7 RID: 6887 RVA: 0x0008D55C File Offset: 0x0008B75C
	[Token(Token = "0x6001AE7")]
	[Address(RVA = "0x28E1930", Offset = "0x28E1930", VA = "0x28E1930")]
	public void \u0878٢\u05BE\u07F0()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AE8 RID: 6888 RVA: 0x0008D5AC File Offset: 0x0008B7AC
	[Token(Token = "0x6001AE8")]
	[Address(RVA = "0x28E1988", Offset = "0x28E1988", VA = "0x28E1988")]
	public void ٠\u06E7\u0614լ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AE9 RID: 6889 RVA: 0x0008D5FC File Offset: 0x0008B7FC
	[Token(Token = "0x6001AE9")]
	[Address(RVA = "0x28E19E0", Offset = "0x28E19E0", VA = "0x28E19E0")]
	public void ࡏ\u0885ۑ\u087E()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AEA RID: 6890 RVA: 0x0008D644 File Offset: 0x0008B844
	[Token(Token = "0x6001AEA")]
	[Address(RVA = "0x28DEEB0", Offset = "0x28DEEB0", VA = "0x28DEEB0")]
	public void ݛ\u05EBդߌ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AEB RID: 6891 RVA: 0x0008D660 File Offset: 0x0008B860
	[Token(Token = "0x6001AEB")]
	[Address(RVA = "0x28E1A38", Offset = "0x28E1A38", VA = "0x28E1A38")]
	public void ١٠ܨԍ()
	{
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AEC RID: 6892 RVA: 0x0008D6A0 File Offset: 0x0008B8A0
	[Token(Token = "0x6001AEC")]
	[Address(RVA = "0x28E1A90", Offset = "0x28E1A90", VA = "0x28E1A90")]
	public void ߊ\u066A\u05CFԉ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)16384;
		}
	}

	// Token: 0x06001AED RID: 6893 RVA: 0x0008D6FC File Offset: 0x0008B8FC
	[Token(Token = "0x6001AED")]
	[Address(RVA = "0x28E1B1C", Offset = "0x28E1B1C", VA = "0x28E1B1C")]
	public void \u07A6ԅܪ\u0820()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AEE RID: 6894 RVA: 0x0008D738 File Offset: 0x0008B938
	[Token(Token = "0x6001AEE")]
	[Address(RVA = "0x28E1B70", Offset = "0x28E1B70", VA = "0x28E1B70")]
	public void \u073Fߗބݝ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			long num2 = 1L;
			this.ݶՈהՇ = (float)16384;
			this.ҽߙԑץ = (num2 != 0L);
		}
	}

	// Token: 0x06001AEF RID: 6895 RVA: 0x0008D7A0 File Offset: 0x0008B9A0
	[Token(Token = "0x6001AEF")]
	[Address(RVA = "0x28E1C00", Offset = "0x28E1C00", VA = "0x28E1C00")]
	public void \u05A7ԂՁݝ()
	{
		long num = 1L;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		if (num == 0L)
		{
		}
	}

	// Token: 0x06001AF0 RID: 6896 RVA: 0x0008D7C0 File Offset: 0x0008B9C0
	[Token(Token = "0x6001AF0")]
	[Address(RVA = "0x28DFCB4", Offset = "0x28DFCB4", VA = "0x28DFCB4")]
	public void \u0831\u06DCӞԺ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AF1 RID: 6897 RVA: 0x0008D7DC File Offset: 0x0008B9DC
	[Token(Token = "0x6001AF1")]
	[Address(RVA = "0x28E1D00", Offset = "0x28E1D00", VA = "0x28E1D00")]
	public void ࡇӤ۲ղ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AF2 RID: 6898 RVA: 0x0008D7F8 File Offset: 0x0008B9F8
	[Token(Token = "0x6001AF2")]
	[Address(RVA = "0x28E07DC", Offset = "0x28E07DC", VA = "0x28E07DC")]
	public void ݮעفӪ()
	{
	}

	// Token: 0x06001AF3 RID: 6899 RVA: 0x0008D80C File Offset: 0x0008BA0C
	[Token(Token = "0x6001AF3")]
	[Address(RVA = "0x28DF368", Offset = "0x28DF368", VA = "0x28DF368")]
	public void \u064DԵ\u073C\u073F()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AF4 RID: 6900 RVA: 0x0008D828 File Offset: 0x0008BA28
	[Token(Token = "0x6001AF4")]
	[Address(RVA = "0x28DE35C", Offset = "0x28DE35C", VA = "0x28DE35C")]
	public void \u065C߁څܪ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AF5 RID: 6901 RVA: 0x0008D844 File Offset: 0x0008BA44
	[Token(Token = "0x6001AF5")]
	[Address(RVA = "0x28E1E00", Offset = "0x28E1E00", VA = "0x28E1E00")]
	public void Ӧد\u060Eࡏ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			long num2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)8192;
			this.ҽߙԑץ = (num2 != 0L);
		}
	}

	// Token: 0x06001AF6 RID: 6902 RVA: 0x0008D8AC File Offset: 0x0008BAAC
	[Token(Token = "0x6001AF6")]
	[Address(RVA = "0x28E1E90", Offset = "0x28E1E90", VA = "0x28E1E90")]
	public void \u0872\u07EEۍԡ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AF7 RID: 6903 RVA: 0x0008D8C8 File Offset: 0x0008BAC8
	[Token(Token = "0x6001AF7")]
	[Address(RVA = "0x28E1F90", Offset = "0x28E1F90", VA = "0x28E1F90")]
	public void \u0736סޞߘ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AF8 RID: 6904 RVA: 0x0008D910 File Offset: 0x0008BB10
	[Token(Token = "0x6001AF8")]
	[Address(RVA = "0x28E1FE8", Offset = "0x28E1FE8", VA = "0x28E1FE8")]
	public void ފՖߢ\u059B()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)32768;
		}
	}

	// Token: 0x06001AF9 RID: 6905 RVA: 0x0008D96C File Offset: 0x0008BB6C
	[Token(Token = "0x6001AF9")]
	[Address(RVA = "0x28E2074", Offset = "0x28E2074", VA = "0x28E2074")]
	public void \u05C9ࠀӽه()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AFA RID: 6906 RVA: 0x0008D988 File Offset: 0x0008BB88
	[Token(Token = "0x6001AFA")]
	[Address(RVA = "0x28E2174", Offset = "0x28E2174", VA = "0x28E2174")]
	public void ݳېټ\u083F()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001AFB RID: 6907 RVA: 0x0008D9D0 File Offset: 0x0008BBD0
	[Token(Token = "0x6001AFB")]
	[Address(RVA = "0x28DFE90", Offset = "0x28DFE90", VA = "0x28DFE90")]
	public void Ԫԋ\u07FBߠ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AFC RID: 6908 RVA: 0x0008D9EC File Offset: 0x0008BBEC
	[Token(Token = "0x6001AFC")]
	[Address(RVA = "0x28E21CC", Offset = "0x28E21CC", VA = "0x28E21CC")]
	public void \u0891۸\u0612\u0892()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001AFD RID: 6909 RVA: 0x0008DA08 File Offset: 0x0008BC08
	[Token(Token = "0x6001AFD")]
	[Address(RVA = "0x28E22CC", Offset = "0x28E22CC", VA = "0x28E22CC")]
	public void ࢫ\u0876չՍ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)40960;
		}
	}

	// Token: 0x06001AFE RID: 6910 RVA: 0x0008DA64 File Offset: 0x0008BC64
	[Token(Token = "0x6001AFE")]
	[Address(RVA = "0x28E2358", Offset = "0x28E2358", VA = "0x28E2358")]
	public void ٴݵۃ\u05AF()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			long num2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)17324;
			this.ҽߙԑץ = (num2 != 0L);
		}
	}

	// Token: 0x06001AFF RID: 6911 RVA: 0x0008DACC File Offset: 0x0008BCCC
	[Token(Token = "0x6001AFF")]
	[Address(RVA = "0x28E23E4", Offset = "0x28E23E4", VA = "0x28E23E4")]
	public void ߀އ\u07F3\u06D8()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B00 RID: 6912 RVA: 0x0008DB08 File Offset: 0x0008BD08
	[Token(Token = "0x6001B00")]
	[Address(RVA = "0x28DECD4", Offset = "0x28DECD4", VA = "0x28DECD4")]
	public void \u0557ࠄӉՑ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B01 RID: 6913 RVA: 0x0008DB24 File Offset: 0x0008BD24
	[Token(Token = "0x6001B01")]
	[Address(RVA = "0x28E2438", Offset = "0x28E2438", VA = "0x28E2438")]
	public void ٤\u0700\u07B2ٯ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B02 RID: 6914 RVA: 0x0008DB40 File Offset: 0x0008BD40
	[Token(Token = "0x6001B02")]
	[Address(RVA = "0x28DE538", Offset = "0x28DE538", VA = "0x28DE538")]
	public void \u066D߈ےܒ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B03 RID: 6915 RVA: 0x0008DB5C File Offset: 0x0008BD5C
	[Token(Token = "0x6001B03")]
	[Address(RVA = "0x28DFAD8", Offset = "0x28DFAD8", VA = "0x28DFAD8")]
	public void ץ\u059Bܘء()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B04 RID: 6916 RVA: 0x0008DB78 File Offset: 0x0008BD78
	[Token(Token = "0x6001B04")]
	[Address(RVA = "0x28E2538", Offset = "0x28E2538", VA = "0x28E2538")]
	public void \u0530ࡏ\u07B3\u05C6()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B05 RID: 6917 RVA: 0x0008DBC0 File Offset: 0x0008BDC0
	[Token(Token = "0x6001B05")]
	[Address(RVA = "0x28E2590", Offset = "0x28E2590", VA = "0x28E2590")]
	public void ࠆٿ\u087C\u05B9()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B06 RID: 6918 RVA: 0x0008DC08 File Offset: 0x0008BE08
	[Token(Token = "0x6001B06")]
	[Address(RVA = "0x28E25E8", Offset = "0x28E25E8", VA = "0x28E25E8")]
	public ElevatorManager()
	{
	}

	// Token: 0x06001B07 RID: 6919 RVA: 0x0008DC28 File Offset: 0x0008BE28
	[Token(Token = "0x6001B07")]
	[Address(RVA = "0x28E25F8", Offset = "0x28E25F8", VA = "0x28E25F8")]
	[PunRPC]
	public void goDownRPC()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B08 RID: 6920 RVA: 0x0008DC78 File Offset: 0x0008BE78
	[Token(Token = "0x6001B08")]
	[Address(RVA = "0x28E2650", Offset = "0x28E2650", VA = "0x28E2650")]
	public void ߤۆࡒՉ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B09 RID: 6921 RVA: 0x0008DC94 File Offset: 0x0008BE94
	[Token(Token = "0x6001B09")]
	[Address(RVA = "0x28E2750", Offset = "0x28E2750", VA = "0x28E2750")]
	public void ݛ\u0599\u05C2ڒ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)17144;
		}
	}

	// Token: 0x06001B0A RID: 6922 RVA: 0x0008DCF0 File Offset: 0x0008BEF0
	[Token(Token = "0x6001B0A")]
	[Address(RVA = "0x28DDF80", Offset = "0x28DDF80", VA = "0x28DDF80")]
	public void \u0733ܢ\u06D4\u073A()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B0B RID: 6923 RVA: 0x0008DD0C File Offset: 0x0008BF0C
	[Token(Token = "0x6001B0B")]
	[Address(RVA = "0x28E27D8", Offset = "0x28E27D8", VA = "0x28E27D8")]
	public void \u0882\u055C\u0888ߥ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled != 0L);
			this.ݶՈהՇ = (float)16384;
		}
	}

	// Token: 0x06001B0C RID: 6924 RVA: 0x0008DD5C File Offset: 0x0008BF5C
	[Token(Token = "0x6001B0C")]
	[Address(RVA = "0x28E2864", Offset = "0x28E2864", VA = "0x28E2864")]
	public void ٵ\u0618\u05B5ԛ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B0D RID: 6925 RVA: 0x0008DDA4 File Offset: 0x0008BFA4
	[Token(Token = "0x6001B0D")]
	[Address(RVA = "0x28E28BC", Offset = "0x28E28BC", VA = "0x28E28BC")]
	public void \u0827ߜ\u07FD\u07F4()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)32768;
		}
	}

	// Token: 0x06001B0E RID: 6926 RVA: 0x0008DE00 File Offset: 0x0008C000
	[Token(Token = "0x6001B0E")]
	[Address(RVA = "0x28E2948", Offset = "0x28E2948", VA = "0x28E2948")]
	public void ԙضփӌ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			long num2 = 1L;
			this.ݶՈהՇ = (float)16384;
			this.ҽߙԑץ = (num2 != 0L);
		}
	}

	// Token: 0x06001B0F RID: 6927 RVA: 0x0008DE68 File Offset: 0x0008C068
	[Token(Token = "0x6001B0F")]
	[Address(RVA = "0x28E29D8", Offset = "0x28E29D8", VA = "0x28E29D8")]
	public void \u0877Ԍ\u0611\u089B()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B10 RID: 6928 RVA: 0x0008DEB0 File Offset: 0x0008C0B0
	[Token(Token = "0x6001B10")]
	[Address(RVA = "0x28E2A30", Offset = "0x28E2A30", VA = "0x28E2A30")]
	public void ڈՓ\u0652\u0871()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)17146;
		}
	}

	// Token: 0x06001B11 RID: 6929 RVA: 0x0008DF0C File Offset: 0x0008C10C
	[Token(Token = "0x6001B11")]
	[Address(RVA = "0x28E2AB8", Offset = "0x28E2AB8", VA = "0x28E2AB8")]
	public void \u07BDԫ\u05B2ۯ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B12 RID: 6930 RVA: 0x0008DF5C File Offset: 0x0008C15C
	[Token(Token = "0x6001B12")]
	[Address(RVA = "0x28E2B10", Offset = "0x28E2B10", VA = "0x28E2B10")]
	public void \u0837\u0609߀ا()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B13 RID: 6931 RVA: 0x0008DFAC File Offset: 0x0008C1AC
	[Token(Token = "0x6001B13")]
	[Address(RVA = "0x28E2B68", Offset = "0x28E2B68", VA = "0x28E2B68")]
	public void ר\u06E2ڱԜ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B14 RID: 6932 RVA: 0x0008DFFC File Offset: 0x0008C1FC
	[Token(Token = "0x6001B14")]
	[Address(RVA = "0x28E2BC0", Offset = "0x28E2BC0", VA = "0x28E2BC0")]
	public void ٠ӄ\u087Cٸ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)32768;
		}
	}

	// Token: 0x06001B15 RID: 6933 RVA: 0x0008E058 File Offset: 0x0008C258
	[Token(Token = "0x6001B15")]
	[Address(RVA = "0x28E08DC", Offset = "0x28E08DC", VA = "0x28E08DC")]
	public void ڞ\u07FAڷ\u0884()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B16 RID: 6934 RVA: 0x0008E074 File Offset: 0x0008C274
	[Token(Token = "0x6001B16")]
	[Address(RVA = "0x28E2C4C", Offset = "0x28E2C4C", VA = "0x28E2C4C")]
	public void Ծرտב()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B17 RID: 6935 RVA: 0x0008E090 File Offset: 0x0008C290
	[Token(Token = "0x6001B17")]
	[Address(RVA = "0x28E2D4C", Offset = "0x28E2D4C", VA = "0x28E2D4C")]
	public void \u0615\u088E\u064Bә()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B18 RID: 6936 RVA: 0x0008E0AC File Offset: 0x0008C2AC
	[Token(Token = "0x6001B18")]
	[Address(RVA = "0x28E2E4C", Offset = "0x28E2E4C", VA = "0x28E2E4C")]
	public void \u05BE\u07BBڣ\u059F()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B19 RID: 6937 RVA: 0x0008E0FC File Offset: 0x0008C2FC
	[Token(Token = "0x6001B19")]
	[Address(RVA = "0x28E2EA4", Offset = "0x28E2EA4", VA = "0x28E2EA4")]
	public void \u0838ӆڛӑ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)32768;
		}
	}

	// Token: 0x06001B1A RID: 6938 RVA: 0x0008E158 File Offset: 0x0008C358
	[Token(Token = "0x6001B1A")]
	[Address(RVA = "0x28E2F30", Offset = "0x28E2F30", VA = "0x28E2F30")]
	public void ۅ\u0837\u05CB\u05BA()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B1B RID: 6939 RVA: 0x0008E174 File Offset: 0x0008C374
	[Token(Token = "0x6001B1B")]
	[Address(RVA = "0x28E3030", Offset = "0x28E3030", VA = "0x28E3030")]
	public void \u07B2\u05C3\u0836\u07B5()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B1C RID: 6940 RVA: 0x0008E190 File Offset: 0x0008C390
	[Token(Token = "0x6001B1C")]
	[Address(RVA = "0x28E3130", Offset = "0x28E3130", VA = "0x28E3130")]
	public void \u085F\u0557\u07FF\u066C()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B1D RID: 6941 RVA: 0x0008E1CC File Offset: 0x0008C3CC
	[Token(Token = "0x6001B1D")]
	[Address(RVA = "0x28E3184", Offset = "0x28E3184", VA = "0x28E3184")]
	public void \u082E\u0608ۂө()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B1E RID: 6942 RVA: 0x0008E214 File Offset: 0x0008C414
	[Token(Token = "0x6001B1E")]
	[Address(RVA = "0x28E0524", Offset = "0x28E0524", VA = "0x28E0524")]
	public void ࡤ\u06E4ةع()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B1F RID: 6943 RVA: 0x0008E230 File Offset: 0x0008C430
	[Token(Token = "0x6001B1F")]
	[Address(RVA = "0x28DF620", Offset = "0x28DF620", VA = "0x28DF620")]
	public void \u082Eߞԙݻ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B20 RID: 6944 RVA: 0x0008E24C File Offset: 0x0008C44C
	[Token(Token = "0x6001B20")]
	[Address(RVA = "0x28E31DC", Offset = "0x28E31DC", VA = "0x28E31DC")]
	public void ࡒ\u061AԌՐ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B21 RID: 6945 RVA: 0x0008E288 File Offset: 0x0008C488
	[Token(Token = "0x6001B21")]
	[Address(RVA = "0x28E3230", Offset = "0x28E3230", VA = "0x28E3230")]
	public void \u081Cәࡃ۵()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 1L;
			long num2 = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)49152;
			this.ҽߙԑץ = (num2 != 0L);
		}
	}

	// Token: 0x06001B22 RID: 6946 RVA: 0x0008E2F0 File Offset: 0x0008C4F0
	[Token(Token = "0x6001B22")]
	[Address(RVA = "0x28E32C0", Offset = "0x28E32C0", VA = "0x28E32C0")]
	public void \u0898\u074Aهפ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B23 RID: 6947 RVA: 0x0008E32C File Offset: 0x0008C52C
	[Token(Token = "0x6001B23")]
	[Address(RVA = "0x28DEBD4", Offset = "0x28DEBD4", VA = "0x28DEBD4")]
	public void ԈلՔ\u07F6()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B24 RID: 6948 RVA: 0x0008E348 File Offset: 0x0008C548
	[Token(Token = "0x6001B24")]
	[Address(RVA = "0x28DF08C", Offset = "0x28DF08C", VA = "0x28DF08C")]
	public void ࡃ\u0819\u083D\u070E()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B25 RID: 6949 RVA: 0x0008E364 File Offset: 0x0008C564
	[Token(Token = "0x6001B25")]
	[Address(RVA = "0x28E3314", Offset = "0x28E3314", VA = "0x28E3314")]
	public void ԣԫߗ\u0595()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B26 RID: 6950 RVA: 0x0008E3A0 File Offset: 0x0008C5A0
	[Token(Token = "0x6001B26")]
	[Address(RVA = "0x28E3368", Offset = "0x28E3368", VA = "0x28E3368")]
	public void \u0734۱Өӟ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B27 RID: 6951 RVA: 0x0008E3BC File Offset: 0x0008C5BC
	[Token(Token = "0x6001B27")]
	[Address(RVA = "0x28E3468", Offset = "0x28E3468", VA = "0x28E3468")]
	public void Ԟࠆ\u0700ط()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		long enabled2 = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B28 RID: 6952 RVA: 0x0008E404 File Offset: 0x0008C604
	[Token(Token = "0x6001B28")]
	[Address(RVA = "0x28E34C0", Offset = "0x28E34C0", VA = "0x28E34C0")]
	public void ݕ\u081F߉ܟ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B29 RID: 6953 RVA: 0x0008E454 File Offset: 0x0008C654
	[Token(Token = "0x6001B29")]
	[Address(RVA = "0x28E3518", Offset = "0x28E3518", VA = "0x28E3518")]
	public void \u0872މࢮՃ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 0L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			long num2 = 1L;
			this.ݶՈהՇ = (float)24576;
			this.ҽߙԑץ = (num2 != 0L);
		}
	}

	// Token: 0x06001B2A RID: 6954 RVA: 0x0008E4BC File Offset: 0x0008C6BC
	[Token(Token = "0x6001B2A")]
	[Address(RVA = "0x28E35A8", Offset = "0x28E35A8", VA = "0x28E35A8")]
	public void \u0893\u0702ءՖ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B2B RID: 6955 RVA: 0x0008E504 File Offset: 0x0008C704
	[Token(Token = "0x6001B2B")]
	[Address(RVA = "0x28E3600", Offset = "0x28E3600", VA = "0x28E3600")]
	public void \u0609\u0559\u070Aݿ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B2C RID: 6956 RVA: 0x0008E554 File Offset: 0x0008C754
	[Token(Token = "0x6001B2C")]
	[Address(RVA = "0x28E3658", Offset = "0x28E3658", VA = "0x28E3658")]
	public void \u05C2ࢠӈת()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 1L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B2D RID: 6957 RVA: 0x0008E590 File Offset: 0x0008C790
	[Token(Token = "0x6001B2D")]
	[Address(RVA = "0x28E0348", Offset = "0x28E0348", VA = "0x28E0348")]
	public void \u06E1ߕ\u0824Ԫ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B2E RID: 6958 RVA: 0x0008E5AC File Offset: 0x0008C7AC
	[Token(Token = "0x6001B2E")]
	[Address(RVA = "0x28E36AC", Offset = "0x28E36AC", VA = "0x28E36AC")]
	public void ࡇږܯ\u0592()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B2F RID: 6959 RVA: 0x0008E5C8 File Offset: 0x0008C7C8
	[Token(Token = "0x6001B2F")]
	[Address(RVA = "0x28DF7FC", Offset = "0x28DF7FC", VA = "0x28DF7FC")]
	public void \u074C\u0870ࠈՓ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B30 RID: 6960 RVA: 0x0008E5E4 File Offset: 0x0008C7E4
	[Token(Token = "0x6001B30")]
	[Address(RVA = "0x28E37AC", Offset = "0x28E37AC", VA = "0x28E37AC")]
	public void \u07F3٢\u0601ט()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B31 RID: 6961 RVA: 0x0008E600 File Offset: 0x0008C800
	[Token(Token = "0x6001B31")]
	[Address(RVA = "0x28E006C", Offset = "0x28E006C", VA = "0x28E006C")]
	public void \u06D9۲צ\u05B2()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B32 RID: 6962 RVA: 0x0008E61C File Offset: 0x0008C81C
	[Token(Token = "0x6001B32")]
	[Address(RVA = "0x28E38AC", Offset = "0x28E38AC", VA = "0x28E38AC")]
	public void Ԟӯ\u0591ئ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001B33 RID: 6963 RVA: 0x0008E654 File Offset: 0x0008C854
	[Token(Token = "0x6001B33")]
	[Address(RVA = "0x28E3904", Offset = "0x28E3904", VA = "0x28E3904")]
	public void ࠔۆܬۿ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
		this.ҽߙԑץ = (ٽ_u0886ࡠԢ != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001B34 RID: 6964 RVA: 0x0008E694 File Offset: 0x0008C894
	[Token(Token = "0x6001B34")]
	[Address(RVA = "0x28E395C", Offset = "0x28E395C", VA = "0x28E395C")]
	public void \u0826\u0749\u07BFࢯ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B35 RID: 6965 RVA: 0x0008E6B0 File Offset: 0x0008C8B0
	[Token(Token = "0x6001B35")]
	[Address(RVA = "0x28E3A5C", Offset = "0x28E3A5C", VA = "0x28E3A5C")]
	public void ࠊդӮٴ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B36 RID: 6966 RVA: 0x0008E6CC File Offset: 0x0008C8CC
	[Token(Token = "0x6001B36")]
	[Address(RVA = "0x28DE9F0", Offset = "0x28DE9F0", VA = "0x28DE9F0")]
	public void ه\u055Cࡋۋ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B37 RID: 6967 RVA: 0x0008E6E8 File Offset: 0x0008C8E8
	[Token(Token = "0x6001B37")]
	[Address(RVA = "0x28E3B5C", Offset = "0x28E3B5C", VA = "0x28E3B5C")]
	public void ہ\u06D8\u06D7ڧ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B38 RID: 6968 RVA: 0x0008E724 File Offset: 0x0008C924
	[Token(Token = "0x6001B38")]
	[Address(RVA = "0x28E3BB0", Offset = "0x28E3BB0", VA = "0x28E3BB0")]
	[PunRPC]
	public void goUpRPC()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long num = 1L;
		this.ҽߙԑץ = (num != 0L);
		long enabled = 0L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B39 RID: 6969 RVA: 0x0008E76C File Offset: 0x0008C96C
	[Token(Token = "0x6001B39")]
	[Address(RVA = "0x28DE080", Offset = "0x28DE080", VA = "0x28DE080")]
	public void \u0887\u07BBלࡔ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06001B3A RID: 6970 RVA: 0x0008E788 File Offset: 0x0008C988
	[Token(Token = "0x6001B3A")]
	[Address(RVA = "0x28E3C08", Offset = "0x28E3C08", VA = "0x28E3C08")]
	public void ӒԂࡩࡓ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)17487;
		}
	}

	// Token: 0x06001B3B RID: 6971 RVA: 0x0008E7E0 File Offset: 0x0008C9E0
	[Token(Token = "0x6001B3B")]
	[Address(RVA = "0x28E3C90", Offset = "0x28E3C90", VA = "0x28E3C90")]
	public void ܪ\u07BB\u086Bࠆ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)49152;
		}
	}

	// Token: 0x06001B3C RID: 6972 RVA: 0x0008E83C File Offset: 0x0008CA3C
	[Token(Token = "0x6001B3C")]
	[Address(RVA = "0x28E3D1C", Offset = "0x28E3D1C", VA = "0x28E3D1C")]
	public void \u083A\u06ED\u05B7ٶ()
	{
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
		long enabled = 1L;
		u0874ړ_u0603ӕ.enabled = (enabled != 0L);
		BoxCollider boxCollider = this.ࠍԠԢأ;
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001B3D RID: 6973 RVA: 0x0008E878 File Offset: 0x0008CA78
	[Token(Token = "0x6001B3D")]
	[Address(RVA = "0x28E3D70", Offset = "0x28E3D70", VA = "0x28E3D70")]
	public void ی\u0823ڇݔ()
	{
		if (this.ҽߙԑץ)
		{
			float num = this.ݶՈהՇ;
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.ࠍԠԢأ;
			long enabled = 1L;
			long num2 = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider u0874ړ_u0603ӕ = this.\u0874ړ\u0603ӕ;
			long enabled2 = 1L;
			u0874ړ_u0603ӕ.enabled = (enabled2 != 0L);
			this.ݶՈהՇ = (float)57344;
			this.ҽߙԑץ = (num2 != 0L);
		}
	}

	// Token: 0x04000390 RID: 912
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000390")]
	public bool ࠈւ\u074Aڡ;

	// Token: 0x04000391 RID: 913
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x4000391")]
	public bool ܤ\u06FDܜ٤;

	// Token: 0x04000392 RID: 914
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000392")]
	public DoorLerp \u0558\u0654ڄ\u087E;

	// Token: 0x04000393 RID: 915
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000393")]
	public BoxCollider ࠍԠԢأ;

	// Token: 0x04000394 RID: 916
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000394")]
	public BoxCollider \u0874ړ\u0603ӕ;

	// Token: 0x04000395 RID: 917
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000395")]
	public PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x04000396 RID: 918
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000396")]
	public float ݶՈהՇ = (float)16800;

	// Token: 0x04000397 RID: 919
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000397")]
	private bool ҽߙԑץ;
}
