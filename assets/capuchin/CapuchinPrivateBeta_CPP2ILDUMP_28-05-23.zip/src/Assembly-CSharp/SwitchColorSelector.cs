﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000045 RID: 69
[Token(Token = "0x2000045")]
public class SwitchColorSelector : MonoBehaviour
{
	// Token: 0x06000992 RID: 2450 RVA: 0x000334D8 File Offset: 0x000316D8
	[Token(Token = "0x6000992")]
	[Address(RVA = "0x285AA28", Offset = "0x285AA28", VA = "0x285AA28")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Trying Getting Entilement...";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 1L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 1L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000993 RID: 2451 RVA: 0x000335C8 File Offset: 0x000317C8
	[Token(Token = "0x6000993")]
	[Address(RVA = "0x285AB80", Offset = "0x285AB80", VA = "0x285AB80")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "CapuchinStore";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		GameObject ӯ_u088Dٯ_u2;
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			long active7 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			long active9 = 1L;
			թࡄ_u05FCؤ3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000994 RID: 2452 RVA: 0x000336A8 File Offset: 0x000318A8
	[Token(Token = "0x6000994")]
	[Address(RVA = "0x285ACD8", Offset = "0x285ACD8", VA = "0x285ACD8")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Meta Platform entitlement error: ";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 1L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 1L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 1L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000995 RID: 2453 RVA: 0x00033798 File Offset: 0x00031998
	[Token(Token = "0x6000995")]
	[Address(RVA = "0x285AE30", Offset = "0x285AE30", VA = "0x285AE30")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 1L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000996 RID: 2454 RVA: 0x00033888 File Offset: 0x00031A88
	[Token(Token = "0x6000996")]
	[Address(RVA = "0x285AF88", Offset = "0x285AF88", VA = "0x285AF88")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 1L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 1L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000997 RID: 2455 RVA: 0x00033978 File Offset: 0x00031B78
	[Token(Token = "0x6000997")]
	[Address(RVA = "0x285B0E0", Offset = "0x285B0E0", VA = "0x285B0E0")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Regular";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 1L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 1L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000998 RID: 2456 RVA: 0x00033A68 File Offset: 0x00031C68
	[Token(Token = "0x6000998")]
	[Address(RVA = "0x285B238", Offset = "0x285B238", VA = "0x285B238")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "5BN";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 1L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 1L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000999 RID: 2457 RVA: 0x00033B58 File Offset: 0x00031D58
	[Token(Token = "0x6000999")]
	[Address(RVA = "0x285B390", Offset = "0x285B390", VA = "0x285B390")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HandL";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600099A RID: 2458 RVA: 0x00033C48 File Offset: 0x00031E48
	[Token(Token = "0x600099A")]
	[Address(RVA = "0x285B4E8", Offset = "0x285B4E8", VA = "0x285B4E8")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active = 1L;
			թࡄ_u05FCؤ.SetActive(active != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active2 = 0L;
			ӯ_u088Dٯ_u.SetActive(active2 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active3 = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active3 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active4 = 1L;
			թࡄ_u05FCؤ2.SetActive(active4 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active5 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active5 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active6 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active6 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active7 = 0L;
			թࡄ_u05FCؤ3.SetActive(active7 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active8 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active8 != 0L);
			return;
		}
	}

	// Token: 0x0600099B RID: 2459 RVA: 0x00033D28 File Offset: 0x00031F28
	[Token(Token = "0x600099B")]
	[Address(RVA = "0x285B640", Offset = "0x285B640", VA = "0x285B640")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		long active3;
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			this.\u088F\u074A\u05F8ޛ.SetActive(active3 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active4 = 0L;
			թࡄ_u05FCؤ2.SetActive(active4 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active5 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active5 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active6 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active6 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active7 = 1L;
			թࡄ_u05FCؤ3.SetActive(active7 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active8 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active8 != 0L);
			return;
		}
	}

	// Token: 0x0600099C RID: 2460 RVA: 0x00033E0C File Offset: 0x0003200C
	[Token(Token = "0x600099C")]
	[Address(RVA = "0x285B798", Offset = "0x285B798", VA = "0x285B798")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "A new Player joined a Room.";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 1L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 1L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600099D RID: 2461 RVA: 0x00033EFC File Offset: 0x000320FC
	[Token(Token = "0x600099D")]
	[Address(RVA = "0x285B8F0", Offset = "0x285B8F0", VA = "0x285B8F0")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Damaged Arm";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 1L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600099E RID: 2462 RVA: 0x00033FEC File Offset: 0x000321EC
	[Token(Token = "0x600099E")]
	[Address(RVA = "0x285BA48", Offset = "0x285BA48", VA = "0x285BA48")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Mesh";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600099F RID: 2463 RVA: 0x000340DC File Offset: 0x000322DC
	[Token(Token = "0x600099F")]
	[Address(RVA = "0x285BBA0", Offset = "0x285BBA0", VA = "0x285BBA0")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Trigger";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009A0 RID: 2464 RVA: 0x000341CC File Offset: 0x000323CC
	[Token(Token = "0x60009A0")]
	[Address(RVA = "0x285BCF8", Offset = "0x285BCF8", VA = "0x285BCF8")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 1L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 1L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009A1 RID: 2465 RVA: 0x000342BC File Offset: 0x000324BC
	[Token(Token = "0x60009A1")]
	[Address(RVA = "0x285BE50", Offset = "0x285BE50", VA = "0x285BE50")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Meta Platform entitlement error: ";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 1L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009A2 RID: 2466 RVA: 0x000343AC File Offset: 0x000325AC
	[Token(Token = "0x60009A2")]
	[Address(RVA = "0x285BFA8", Offset = "0x285BFA8", VA = "0x285BFA8")]
	public SwitchColorSelector()
	{
	}

	// Token: 0x060009A3 RID: 2467 RVA: 0x000343C0 File Offset: 0x000325C0
	[Token(Token = "0x60009A3")]
	[Address(RVA = "0x285BFB0", Offset = "0x285BFB0", VA = "0x285BFB0")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "\n Time: ";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009A4 RID: 2468 RVA: 0x000344B0 File Offset: 0x000326B0
	[Token(Token = "0x60009A4")]
	[Address(RVA = "0x285C108", Offset = "0x285C108", VA = "0x285C108")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 1L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009A5 RID: 2469 RVA: 0x000345A0 File Offset: 0x000327A0
	[Token(Token = "0x60009A5")]
	[Address(RVA = "0x285C260", Offset = "0x285C260", VA = "0x285C260")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009A6 RID: 2470 RVA: 0x00034690 File Offset: 0x00032890
	[Token(Token = "0x60009A6")]
	[Address(RVA = "0x285C3B8", Offset = "0x285C3B8", VA = "0x285C3B8")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		bool ԅݫ_u0711_u = this.Ԅݫ\u0711\u0837;
		GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
		long active7 = 0L;
		u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
		GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
		long active8 = 0L;
		թࡄ_u05FCؤ3.SetActive(active8 != 0L);
		GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
		long active9 = 1L;
		ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
	}

	// Token: 0x060009A7 RID: 2471 RVA: 0x00034780 File Offset: 0x00032980
	[Token(Token = "0x60009A7")]
	[Address(RVA = "0x285C510", Offset = "0x285C510", VA = "0x285C510")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 1L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			this.Ӯ\u088Dٯ\u0670.SetActive(active5 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active6 = 1L;
			u088F_u074A_u05F8ޛ3.SetActive(active6 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active7 = 0L;
			թࡄ_u05FCؤ3.SetActive(active7 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active8 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active8 != 0L);
			return;
		}
	}

	// Token: 0x060009A8 RID: 2472 RVA: 0x0003486C File Offset: 0x00032A6C
	[Token(Token = "0x60009A8")]
	[Address(RVA = "0x285C668", Offset = "0x285C668", VA = "0x285C668")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == ".Please press the button if you would like to play alone";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 1L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 1L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 1L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009A9 RID: 2473 RVA: 0x0003495C File Offset: 0x00032B5C
	[Token(Token = "0x60009A9")]
	[Address(RVA = "0x285C7C0", Offset = "0x285C7C0", VA = "0x285C7C0")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "typesOfTalk";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 0L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		bool ԅݫ_u0711_u = this.Ԅݫ\u0711\u0837;
		GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
		long active7 = 0L;
		u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
		GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
		long active8 = 0L;
		թࡄ_u05FCؤ3.SetActive(active8 != 0L);
		GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
		long active9 = 1L;
		ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
	}

	// Token: 0x060009AA RID: 2474 RVA: 0x00034A4C File Offset: 0x00032C4C
	[Token(Token = "0x60009AA")]
	[Address(RVA = "0x285C918", Offset = "0x285C918", VA = "0x285C918")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Reason: ";
		bool ջ_u05B6_u07ABԵ = this.ջ\u05B6\u07ABԵ;
		GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
		long active = 0L;
		u088F_u074A_u05F8ޛ.SetActive(active != 0L);
		GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
		long active2 = 1L;
		թࡄ_u05FCؤ.SetActive(active2 != 0L);
		GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
		long active3 = 0L;
		ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 1L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009AB RID: 2475 RVA: 0x00034B40 File Offset: 0x00032D40
	[Token(Token = "0x60009AB")]
	[Address(RVA = "0x285CA70", Offset = "0x285CA70", VA = "0x285CA70")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 1L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 0L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009AC RID: 2476 RVA: 0x00034C30 File Offset: 0x00032E30
	[Token(Token = "0x60009AC")]
	[Address(RVA = "0x285CBC8", Offset = "0x285CBC8", VA = "0x285CBC8")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Agreed";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 1L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 0L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009AD RID: 2477 RVA: 0x00034D20 File Offset: 0x00032F20
	[Token(Token = "0x60009AD")]
	[Address(RVA = "0x285CD20", Offset = "0x285CD20", VA = "0x285CD20")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "hh:mmtt";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 0L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 1L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 0L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active6 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 0L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u3 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 1L;
			ӯ_u088Dٯ_u3.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x060009AE RID: 2478 RVA: 0x00034E10 File Offset: 0x00033010
	[Token(Token = "0x60009AE")]
	[Address(RVA = "0x285CE78", Offset = "0x285CE78", VA = "0x285CE78")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "User has been reported for: ";
		if (this.ջ\u05B6\u07ABԵ)
		{
			GameObject u088F_u074A_u05F8ޛ = this.\u088F\u074A\u05F8ޛ;
			long active = 1L;
			u088F_u074A_u05F8ޛ.SetActive(active != 0L);
			GameObject թࡄ_u05FCؤ = this.թࡄ\u05FCؤ;
			long active2 = 0L;
			թࡄ_u05FCؤ.SetActive(active2 != 0L);
			GameObject ӯ_u088Dٯ_u = this.Ӯ\u088Dٯ\u0670;
			long active3 = 0L;
			ӯ_u088Dٯ_u.SetActive(active3 != 0L);
		}
		if (this.\u0557یԈ\u0822)
		{
			GameObject u088F_u074A_u05F8ޛ2 = this.\u088F\u074A\u05F8ޛ;
			long active4 = 1L;
			u088F_u074A_u05F8ޛ2.SetActive(active4 != 0L);
			GameObject թࡄ_u05FCؤ2 = this.թࡄ\u05FCؤ;
			long active5 = 1L;
			թࡄ_u05FCؤ2.SetActive(active5 != 0L);
			long active6 = 0L;
			թࡄ_u05FCؤ2.SetActive(active6 != 0L);
		}
		if (this.Ԅݫ\u0711\u0837)
		{
			GameObject u088F_u074A_u05F8ޛ3 = this.\u088F\u074A\u05F8ޛ;
			long active7 = 1L;
			u088F_u074A_u05F8ޛ3.SetActive(active7 != 0L);
			GameObject թࡄ_u05FCؤ3 = this.թࡄ\u05FCؤ;
			long active8 = 0L;
			թࡄ_u05FCؤ3.SetActive(active8 != 0L);
			GameObject ӯ_u088Dٯ_u2 = this.Ӯ\u088Dٯ\u0670;
			long active9 = 1L;
			ӯ_u088Dٯ_u2.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x04000164 RID: 356
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000164")]
	public bool ջ\u05B6\u07ABԵ;

	// Token: 0x04000165 RID: 357
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x4000165")]
	public bool \u0557یԈ\u0822;

	// Token: 0x04000166 RID: 358
	[FieldOffset(Offset = "0x1A")]
	[Token(Token = "0x4000166")]
	public bool Ԅݫ\u0711\u0837;

	// Token: 0x04000167 RID: 359
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000167")]
	public GameObject \u088F\u074A\u05F8ޛ;

	// Token: 0x04000168 RID: 360
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000168")]
	public GameObject թࡄ\u05FCؤ;

	// Token: 0x04000169 RID: 361
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000169")]
	public GameObject Ӯ\u088Dٯ\u0670;
}
