﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000BC RID: 188
[Token(Token = "0x20000BC")]
public class FlashlightPhoton : MonoBehaviour
{
	// Token: 0x06001BD8 RID: 7128 RVA: 0x000913E0 File Offset: 0x0008F5E0
	[Token(Token = "0x6001BD8")]
	[Address(RVA = "0x2E6DFF4", Offset = "0x2E6DFF4", VA = "0x2E6DFF4")]
	private void ں٢ࡡ\u05EC()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BD9 RID: 7129 RVA: 0x00091440 File Offset: 0x0008F640
	[Token(Token = "0x6001BD9")]
	[Address(RVA = "0x2E6E06C", Offset = "0x2E6E06C", VA = "0x2E6E06C")]
	private void \u070Aәޣے()
	{
		GameObject u0879_u082Bڨࠋ2;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			if (this.\u0899ډڜ\u059E == null)
			{
				return;
			}
		}
		else
		{
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			long active2 = 1L;
			u0899ډڜ_u059E.SetActive(active2 != 0L);
			u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		}
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BDA RID: 7130 RVA: 0x000914A0 File Offset: 0x0008F6A0
	[Token(Token = "0x6001BDA")]
	[Address(RVA = "0x2E6E0E0", Offset = "0x2E6E0E0", VA = "0x2E6E0E0")]
	private void Ӣ\u0592ߨׯ()
	{
		GameObject u0879_u082Bڨࠋ2;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			if (this.\u0899ډڜ\u059E == null)
			{
				return;
			}
		}
		else
		{
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			long active2 = 1L;
			u0899ډڜ_u059E.SetActive(active2 != 0L);
			u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		}
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BDB RID: 7131 RVA: 0x00091500 File Offset: 0x0008F700
	[Token(Token = "0x6001BDB")]
	[Address(RVA = "0x2E6E154", Offset = "0x2E6E154", VA = "0x2E6E154")]
	private void \u0881ݗӟ\u07BD()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BDC RID: 7132 RVA: 0x00091560 File Offset: 0x0008F760
	[Token(Token = "0x6001BDC")]
	[Address(RVA = "0x2E6E1CC", Offset = "0x2E6E1CC", VA = "0x2E6E1CC")]
	private void ӻӒݝ߃()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BDD RID: 7133 RVA: 0x000915C0 File Offset: 0x0008F7C0
	[Token(Token = "0x6001BDD")]
	[Address(RVA = "0x2E6E244", Offset = "0x2E6E244", VA = "0x2E6E244")]
	private void \u0886Ҽ\u058Dߛ()
	{
		GameObject u0879_u082Bڨࠋ2;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			if (this.\u0899ډڜ\u059E == null)
			{
				return;
			}
		}
		else
		{
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			long active2 = 0L;
			u0899ډڜ_u059E.SetActive(active2 != 0L);
			u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		}
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BDE RID: 7134 RVA: 0x00091620 File Offset: 0x0008F820
	[Token(Token = "0x6001BDE")]
	[Address(RVA = "0x2E6E2B8", Offset = "0x2E6E2B8", VA = "0x2E6E2B8")]
	private void ւࡂ\u0883\u0872()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BDF RID: 7135 RVA: 0x00091680 File Offset: 0x0008F880
	[Token(Token = "0x6001BDF")]
	[Address(RVA = "0x2E6E330", Offset = "0x2E6E330", VA = "0x2E6E330")]
	private void Update()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BE0 RID: 7136 RVA: 0x000916E0 File Offset: 0x0008F8E0
	[Token(Token = "0x6001BE0")]
	[Address(RVA = "0x2E6E3A8", Offset = "0x2E6E3A8", VA = "0x2E6E3A8")]
	private void \u05EDց\u081Cت()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BE1 RID: 7137 RVA: 0x00091740 File Offset: 0x0008F940
	[Token(Token = "0x6001BE1")]
	[Address(RVA = "0x2E6E420", Offset = "0x2E6E420", VA = "0x2E6E420")]
	private void Ҽ\u08B5ځ\u0658()
	{
		GameObject u0879_u082Bڨࠋ2;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			if (this.\u0899ډڜ\u059E == null)
			{
				return;
			}
		}
		else
		{
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			long active2 = 0L;
			u0899ډڜ_u059E.SetActive(active2 != 0L);
			u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		}
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BE2 RID: 7138 RVA: 0x000917A0 File Offset: 0x0008F9A0
	[Token(Token = "0x6001BE2")]
	[Address(RVA = "0x2E6E494", Offset = "0x2E6E494", VA = "0x2E6E494")]
	private void \u087BӦןݩ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BE3 RID: 7139 RVA: 0x00091800 File Offset: 0x0008FA00
	[Token(Token = "0x6001BE3")]
	[Address(RVA = "0x2E6E50C", Offset = "0x2E6E50C", VA = "0x2E6E50C")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		GameObject u0879_u082Bڨࠋ2;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			if (this.\u0899ډڜ\u059E == null)
			{
				return;
			}
		}
		else
		{
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			long active2 = 1L;
			u0899ډڜ_u059E.SetActive(active2 != 0L);
			u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		}
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BE4 RID: 7140 RVA: 0x00091860 File Offset: 0x0008FA60
	[Token(Token = "0x6001BE4")]
	[Address(RVA = "0x2E6E580", Offset = "0x2E6E580", VA = "0x2E6E580")]
	public FlashlightPhoton()
	{
	}

	// Token: 0x06001BE5 RID: 7141 RVA: 0x00091874 File Offset: 0x0008FA74
	[Token(Token = "0x6001BE5")]
	[Address(RVA = "0x2E6E588", Offset = "0x2E6E588", VA = "0x2E6E588")]
	private void ࢫ\u0876չՍ()
	{
		GameObject u0879_u082Bڨࠋ2;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			if (this.\u0899ډڜ\u059E == null)
			{
				return;
			}
		}
		else
		{
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			long active2 = 0L;
			u0899ډڜ_u059E.SetActive(active2 != 0L);
			u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		}
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BE6 RID: 7142 RVA: 0x000918D4 File Offset: 0x0008FAD4
	[Token(Token = "0x6001BE6")]
	[Address(RVA = "0x2E6E5FC", Offset = "0x2E6E5FC", VA = "0x2E6E5FC")]
	private void \u061B\u05EEوۈ()
	{
		GameObject u0879_u082Bڨࠋ2;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			if (this.\u0899ډڜ\u059E == null)
			{
				return;
			}
		}
		else
		{
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			long active2 = 1L;
			u0899ډڜ_u059E.SetActive(active2 != 0L);
			u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		}
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BE7 RID: 7143 RVA: 0x00091934 File Offset: 0x0008FB34
	[Token(Token = "0x6001BE7")]
	[Address(RVA = "0x2E6E670", Offset = "0x2E6E670", VA = "0x2E6E670")]
	private void ފՖߢ\u059B()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 0L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BE8 RID: 7144 RVA: 0x00091994 File Offset: 0x0008FB94
	[Token(Token = "0x6001BE8")]
	[Address(RVA = "0x2E6E6E8", Offset = "0x2E6E6E8", VA = "0x2E6E6E8")]
	private void \u07FE\u0882Զ\u066D()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BE9 RID: 7145 RVA: 0x000919F4 File Offset: 0x0008FBF4
	[Token(Token = "0x6001BE9")]
	[Address(RVA = "0x2E6E760", Offset = "0x2E6E760", VA = "0x2E6E760")]
	private void \u0732ڙԒࢺ()
	{
		GameObject u0879_u082Bڨࠋ2;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			if (this.\u0899ډڜ\u059E == null)
			{
				return;
			}
		}
		else
		{
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			long active2 = 1L;
			u0899ډڜ_u059E.SetActive(active2 != 0L);
			u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		}
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BEA RID: 7146 RVA: 0x00091A54 File Offset: 0x0008FC54
	[Token(Token = "0x6001BEA")]
	[Address(RVA = "0x2E6E7D4", Offset = "0x2E6E7D4", VA = "0x2E6E7D4")]
	private void ԣԭՋࠏ()
	{
		GameObject u0879_u082Bڨࠋ2;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			if (u0879_u082Bڨࠋ == null)
			{
				return;
			}
		}
		else
		{
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			long active2 = 1L;
			u0899ډڜ_u059E.SetActive(active2 != 0L);
			u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		}
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BEB RID: 7147 RVA: 0x00091AAC File Offset: 0x0008FCAC
	[Token(Token = "0x6001BEB")]
	[Address(RVA = "0x2E6E848", Offset = "0x2E6E848", VA = "0x2E6E848")]
	private void څࡣڐ\u0657()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BEC RID: 7148 RVA: 0x00091B0C File Offset: 0x0008FD0C
	[Token(Token = "0x6001BEC")]
	[Address(RVA = "0x2E6E8C0", Offset = "0x2E6E8C0", VA = "0x2E6E8C0")]
	private void Ҿࢹؼס()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 0L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BED RID: 7149 RVA: 0x00091B6C File Offset: 0x0008FD6C
	[Token(Token = "0x6001BED")]
	[Address(RVA = "0x2E6E938", Offset = "0x2E6E938", VA = "0x2E6E938")]
	private void \u0654ޛ\u07FAذ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BEE RID: 7150 RVA: 0x00091BCC File Offset: 0x0008FDCC
	[Token(Token = "0x6001BEE")]
	[Address(RVA = "0x2E6E9B0", Offset = "0x2E6E9B0", VA = "0x2E6E9B0")]
	private void ժ\u065Dԯࡘ()
	{
		GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
		long active = 1L;
		u0879_u082Bڨࠋ.SetActive(active != 0L);
		if (this.\u0899ډڜ\u059E == null)
		{
			return;
		}
		long active2 = 1L;
		GameObject gameObject;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06001BEF RID: 7151 RVA: 0x00091C1C File Offset: 0x0008FE1C
	[Token(Token = "0x6001BEF")]
	[Address(RVA = "0x2E6EA24", Offset = "0x2E6EA24", VA = "0x2E6EA24")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BF0 RID: 7152 RVA: 0x00091C7C File Offset: 0x0008FE7C
	[Token(Token = "0x6001BF0")]
	[Address(RVA = "0x2E6EA9C", Offset = "0x2E6EA9C", VA = "0x2E6EA9C")]
	private void \u05F7ԝߠӱ()
	{
		GameObject u0879_u082Bڨࠋ2;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			if (this.\u0899ډڜ\u059E == null)
			{
				return;
			}
		}
		else
		{
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			long active2 = 0L;
			u0899ډڜ_u059E.SetActive(active2 != 0L);
			u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		}
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BF1 RID: 7153 RVA: 0x00091CDC File Offset: 0x0008FEDC
	[Token(Token = "0x6001BF1")]
	[Address(RVA = "0x2E6EB10", Offset = "0x2E6EB10", VA = "0x2E6EB10")]
	private void ڃրӢԖ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			return;
		}
		GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BF2 RID: 7154 RVA: 0x00091D34 File Offset: 0x0008FF34
	[Token(Token = "0x6001BF2")]
	[Address(RVA = "0x2E6EB88", Offset = "0x2E6EB88", VA = "0x2E6EB88")]
	private void \u0614ࢥӴ\u086C()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 0L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BF3 RID: 7155 RVA: 0x00091D94 File Offset: 0x0008FF94
	[Token(Token = "0x6001BF3")]
	[Address(RVA = "0x2E6EBFC", Offset = "0x2E6EBFC", VA = "0x2E6EBFC")]
	private void \u0838ӆڛӑ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			if (this == null)
			{
				return;
			}
		}
	}

	// Token: 0x06001BF4 RID: 7156 RVA: 0x00091DC0 File Offset: 0x0008FFC0
	[Token(Token = "0x6001BF4")]
	[Address(RVA = "0x2E6EC70", Offset = "0x2E6EC70", VA = "0x2E6EC70")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BF5 RID: 7157 RVA: 0x00091E20 File Offset: 0x00090020
	[Token(Token = "0x6001BF5")]
	[Address(RVA = "0x2E6ECE8", Offset = "0x2E6ECE8", VA = "0x2E6ECE8")]
	private void ٴݵۃ\u05AF()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 1L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 0L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BF6 RID: 7158 RVA: 0x00091E80 File Offset: 0x00090080
	[Token(Token = "0x6001BF6")]
	[Address(RVA = "0x2E6ED60", Offset = "0x2E6ED60", VA = "0x2E6ED60")]
	private void ڑߒجވ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x06001BF7 RID: 7159 RVA: 0x00091EE0 File Offset: 0x000900E0
	[Token(Token = "0x6001BF7")]
	[Address(RVA = "0x2E6EDD8", Offset = "0x2E6EDD8", VA = "0x2E6EDD8")]
	private void ԟ\u086Cޣ\u055E()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			GameObject u0879_u082Bڨࠋ = this.\u0879\u082Bڨࠋ;
			long active = 0L;
			u0879_u082Bڨࠋ.SetActive(active != 0L);
			GameObject u0899ډڜ_u059E = this.\u0899ډڜ\u059E;
			return;
		}
		GameObject u0899ډڜ_u059E2 = this.\u0899ډڜ\u059E;
		long active2 = 1L;
		u0899ډڜ_u059E2.SetActive(active2 != 0L);
		GameObject u0879_u082Bڨࠋ2 = this.\u0879\u082Bڨࠋ;
		long active3 = 1L;
		u0879_u082Bڨࠋ2.SetActive(active3 != 0L);
	}

	// Token: 0x0400039C RID: 924
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400039C")]
	public GameObject \u0899ډڜ\u059E;

	// Token: 0x0400039D RID: 925
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400039D")]
	public GameObject \u0879\u082Bڨࠋ;

	// Token: 0x0400039E RID: 926
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400039E")]
	public PhotonView \u07AE\u05AF\u064FԖ;
}
