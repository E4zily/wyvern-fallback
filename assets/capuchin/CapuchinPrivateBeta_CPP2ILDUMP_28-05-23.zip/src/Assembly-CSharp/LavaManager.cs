﻿using System;
using System.Collections;
using CapuchinPlayFab;
using Cpp2IlInjected;
using ExitGames.Client.Photon;
using Locomotion;
using Photon.Pun;
using PlayFab;
using PlayFab.ClientModels;
using UnityEngine;

// Token: 0x020000C3 RID: 195
[Token(Token = "0x20000C3")]
public class LavaManager : MonoBehaviour
{
	// Token: 0x06001CD1 RID: 7377 RVA: 0x00095354 File Offset: 0x00093554
	[Token(Token = "0x6001CD1")]
	[Address(RVA = "0x2ADAAE4", Offset = "0x2ADAAE4", VA = "0x2ADAAE4")]
	public void ދۿߝݥ()
	{
		NetworkPlayerSpawner ӛ߇_u0558_u = this.ӛ߇\u0558\u0736;
		PhotonView component = ӛ߇_u0558_u.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		if ("NetworkPlayer" != null)
		{
			if ("NetworkPlayer" != null)
			{
				return;
			}
		}
		else
		{
			long u05C4ࡑڍۺ = 0L;
			PhotonView pvCache = ӛ߇_u0558_u.pvCache;
			ӛ߇_u0558_u.\u05C4ࡑڍۺ = (u05C4ࡑڍۺ != 0L);
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array = new object[0];
			if ("DisableCosmetic" == null)
			{
				return;
			}
			if ("DisableCosmetic" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CD2 RID: 7378 RVA: 0x000953D4 File Offset: 0x000935D4
	[Token(Token = "0x6001CD2")]
	[Address(RVA = "0x2ADACCC", Offset = "0x2ADACCC", VA = "0x2ADACCC")]
	private void \u0821\u059Fӕ\u0607()
	{
		if (this.\u05CDࠇܩܚ)
		{
			GameObject ך_u0897_u05BE_u085B = this.ך\u0897\u05BE\u085B;
			long active = 1L;
			ך_u0897_u05BE_u085B.SetActive(active != 0L);
			GameObject u074C_u0707_u0595յ = this.\u074C\u0707\u0595յ;
			long active2 = 0L;
			u074C_u0707_u0595յ.SetActive(active2 != 0L);
			GameObject gameObject = this.\u0619\u0894Ա\u05CF.gameObject;
			long active3 = 0L;
			gameObject.SetActive(active3 != 0L);
			GameObject u061Aոԕע = this.\u061Aոԕע;
			long active4 = 1L;
			u061Aոԕע.SetActive(active4 != 0L);
			GameObject u06E1۷_u070Cۇ = this.\u06E1۷\u070Cۇ;
			long active5 = 0L;
			u06E1۷_u070Cۇ.SetActive(active5 != 0L);
			GameObject gameObject2 = this.ӿӊܞܤ;
			long active6 = 0L;
			gameObject2.SetActive(active6 != 0L);
			GameObject խښ_u05A4_u = this.Խښ\u05A4\u0836;
			long active7 = 1L;
			խښ_u05A4_u.SetActive(active7 != 0L);
			GameObject u05A9ۉ_u05B3_u = this.\u05A9ۉ\u05B3\u0706;
			long active8 = 1L;
			u05A9ۉ_u05B3_u.SetActive(active8 != 0L);
			GameObject ٸڼ_u05B5Ӹ = this.ٸڼ\u05B5Ӹ;
			long active9 = 1L;
			ٸڼ_u05B5Ӹ.SetActive(active9 != 0L);
			GameObject ݱԐࠆ_u065F = this.ݱԐࠆ\u065F;
			long active10 = 0L;
			ݱԐࠆ_u065F.SetActive(active10 != 0L);
			GameObject u06E3ݎԶԛ = this.\u06E3ݎԶԛ;
			long active11 = 0L;
			u06E3ݎԶԛ.SetActive(active11 != 0L);
			if (!this.\u05F3ۂ\u0899آ)
			{
				IEnumerator routine = this.\u083FקՅ\u05F7();
				Coroutine coroutine = base.StartCoroutine(routine);
			}
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				Transform u0619_u0894Ա_u05CF = this.\u0619\u0894Ա\u05CF;
				float deltaTime = Time.deltaTime;
				float x = this.\u0746Ԟࡕߩ.x;
				float y = this.\u0746Ԟࡕߩ.y;
				float z = this.\u0746Ԟࡕߩ.z;
			}
			Vector3 position = this.\u0619\u0894Ա\u05CF.position;
			float u064E_u06DFࡘվ = this.\u064E\u06DFࡘվ;
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				object[] array = new object[0];
				if (typeof(bool).TypeHandle != null && typeof(bool).TypeHandle == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			}
			AudioLowPassFilter[] array2 = this.ࡥԇࠀڷ;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		Transform ֆܧבӒ = this.ՖܧבӒ;
		Transform u0619_u0894Ա_u05CF2 = this.\u0619\u0894Ա\u05CF;
		Vector3 position2 = ֆܧבӒ.position;
		if (this.\u07BF\u05CD۳Ӵ)
		{
			Vector3 position3 = this.\u05F8ܔԐٿ.position;
			Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
			Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
			Vector3 position4 = u05F8ܔԐٿ.position;
			GameObject ٸڼ_u05B5Ӹ2 = this.ٸڼ\u05B5Ӹ;
			long active12 = 0L;
			ٸڼ_u05B5Ӹ2.SetActive(active12 != 0L);
			GameObject ݱԐࠆ_u065F2 = this.ݱԐࠆ\u065F;
			long active13 = 0L;
			ݱԐࠆ_u065F2.SetActive(active13 != 0L);
			return;
		}
		long num;
		if (this.ࡌ\u082F߄س)
		{
			Rigidbody աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			long useGravity = 1L;
			աߞ_u07A7ߦ.useGravity = (useGravity != 0L);
			Rigidbody ցԁ_u0740օ = this.ՑԀ\u0740օ;
			long useGravity2 = 1L;
			ցԁ_u0740օ.useGravity = (useGravity2 != 0L);
			Rigidbody u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			long useGravity3 = 0L;
			u0741_u06E2ӳࢣ.useGravity = (useGravity3 != 0L);
			this.ދۿߝݥ();
			Swimmy ڢݕڕ_u06E = this.ڢݕڕ\u06E8;
			num = 0L;
			ڢݕڕ_u06E.enabled = (num != 0L);
			this.ڑ\u0881\u0603ԋ();
		}
		this.\u061Aոԕע.SetActive(num != 0L);
		GameObject u06E1۷_u070Cۇ2 = this.\u06E1۷\u070Cۇ;
		long active14 = 1L;
		u06E1۷_u070Cۇ2.SetActive(active14 != 0L);
		GameObject gameObject3 = this.ӿӊܞܤ;
		long active15 = 1L;
		gameObject3.SetActive(active15 != 0L);
		GameObject ٸڼ_u05B5Ӹ3 = this.ٸڼ\u05B5Ӹ;
		long active16 = 0L;
		ٸڼ_u05B5Ӹ3.SetActive(active16 != 0L);
		GameObject ݱԐࠆ_u065F3 = this.ݱԐࠆ\u065F;
		long active17 = 1L;
		ݱԐࠆ_u065F3.SetActive(active17 != 0L);
		GameObject ך_u0897_u05BE_u085B2 = this.ך\u0897\u05BE\u085B;
		long active18 = 0L;
		ך_u0897_u05BE_u085B2.SetActive(active18 != 0L);
		GameObject u074C_u0707_u0595յ2 = this.\u074C\u0707\u0595յ;
		long active19 = 1L;
		u074C_u0707_u0595յ2.SetActive(active19 != 0L);
		GameObject u05A9ۉ_u05B3_u2 = this.\u05A9ۉ\u05B3\u0706;
		long active20 = 1L;
		u05A9ۉ_u05B3_u2.SetActive(active20 != 0L);
		this.\u06E3ݎԶԛ.SetActive(active20 != 0L);
		GameObject gameObject4 = this.\u0619\u0894Ա\u05CF.gameObject;
		long active21 = 0L;
		gameObject4.SetActive(active21 != 0L);
		AudioLowPassFilter[] array3 = this.ࡥԇࠀڷ;
	}

	// Token: 0x06001CD3 RID: 7379 RVA: 0x00095770 File Offset: 0x00093970
	[Token(Token = "0x6001CD3")]
	[Address(RVA = "0x2AD6520", Offset = "0x2AD6520", VA = "0x2AD6520")]
	public void \u060Dӫߠވ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[0];
	}

	// Token: 0x06001CD4 RID: 7380 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001CD4")]
	[Address(RVA = "0x2ADB570", Offset = "0x2ADB570", VA = "0x2ADB570")]
	public void ԏ\u06DCޒ\u07FF()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001CD5 RID: 7381 RVA: 0x000957DC File Offset: 0x000939DC
	[Token(Token = "0x6001CD5")]
	[Address(RVA = "0x2AD7694", Offset = "0x2AD7694", VA = "0x2AD7694")]
	public void Ӥܗ\u07BFӱ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[1];
		if ("true" != null)
		{
			if ("true" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[1];
			if ("false" == null)
			{
				return;
			}
			if ("false" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CD6 RID: 7382 RVA: 0x00095850 File Offset: 0x00093A50
	[Token(Token = "0x6001CD6")]
	[Address(RVA = "0x2ADB758", Offset = "0x2ADB758", VA = "0x2ADB758")]
	private void Ԧࡒ\u0877ܬ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001CD7 RID: 7383 RVA: 0x0009587C File Offset: 0x00093A7C
	[Token(Token = "0x6001CD7")]
	[Address(RVA = "0x2ADB830", Offset = "0x2ADB830", VA = "0x2ADB830")]
	public void ڵ\u0590ܜӢ(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u0746Ԟࡕߩ.z = (float)17529;
			this.\u064E\u06DFࡘվ = (float)17625;
		}
		this.\u05CDࠇܩܚ = (17529 != 0);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001CD8 RID: 7384 RVA: 0x000958F8 File Offset: 0x00093AF8
	[Token(Token = "0x6001CD8")]
	[Address(RVA = "0x2ADB90C", Offset = "0x2ADB90C", VA = "0x2ADB90C")]
	private void \u083Fۯӽ\u06D7(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001CD9 RID: 7385 RVA: 0x00095924 File Offset: 0x00093B24
	[Token(Token = "0x6001CD9")]
	[Address(RVA = "0x2ADB9E4", Offset = "0x2ADB9E4", VA = "0x2ADB9E4")]
	private void \u0828\u074A۵ߕ(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Connected to Server.");
		this.ڐۊࠔ\u0651.\u05A9ըկڲ();
	}

	// Token: 0x06001CDA RID: 7386 RVA: 0x00095954 File Offset: 0x00093B54
	[Token(Token = "0x6001CDA")]
	[Address(RVA = "0x2ADBA70", Offset = "0x2ADBA70", VA = "0x2ADBA70")]
	private void ࢧٵҽ\u06E3(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Added Winner Money");
		this.ڐۊࠔ\u0651.\u0530\u05FDސ\u07B0();
	}

	// Token: 0x06001CDB RID: 7387 RVA: 0x00095984 File Offset: 0x00093B84
	[Token(Token = "0x6001CDB")]
	[Address(RVA = "0x2ADBAFC", Offset = "0x2ADBAFC", VA = "0x2ADBAFC")]
	public IEnumerator ߙࢶࢸ\u060B()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06001CDC RID: 7388 RVA: 0x00095998 File Offset: 0x00093B98
	[Token(Token = "0x6001CDC")]
	[Address(RVA = "0x2ADBB74", Offset = "0x2ADBB74", VA = "0x2ADBB74")]
	private void \u05AA\u059Dߛࢪ()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string u073BӵӞ_u07FD = this.\u073BӵӞ\u07FD;
		addUserVirtualCurrencyRequest.VirtualCurrency = u073BӵӞ_u07FD;
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001CDD RID: 7389 RVA: 0x000959C8 File Offset: 0x00093BC8
	[Token(Token = "0x6001CDD")]
	[Address(RVA = "0x2AD6700", Offset = "0x2AD6700", VA = "0x2AD6700")]
	public void \u05CF\u0839ݙԟ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[1];
		if ("TurnAmount" != null)
		{
			if ("TurnAmount" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[0];
			if ("NetworkPlayer" == null)
			{
				return;
			}
			if ("NetworkPlayer" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CDE RID: 7390 RVA: 0x00095A40 File Offset: 0x00093C40
	[Token(Token = "0x6001CDE")]
	[Address(RVA = "0x2ADBCEC", Offset = "0x2ADBCEC", VA = "0x2ADBCEC")]
	private void \u0705ܩտԇ(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Error");
		this.ڐۊࠔ\u0651.\u07F2߂ނ\u083F();
	}

	// Token: 0x06001CDF RID: 7391 RVA: 0x00095A70 File Offset: 0x00093C70
	[Token(Token = "0x6001CDF")]
	[Address(RVA = "0x2AD7FF0", Offset = "0x2AD7FF0", VA = "0x2AD7FF0")]
	public void ݻޑ\u083Fգ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[1];
		if ("Skelechin" != null)
		{
			if ("Skelechin" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[1];
			if ("CapuchinRemade" == null)
			{
				return;
			}
			if ("CapuchinRemade" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CE0 RID: 7392 RVA: 0x00095AE4 File Offset: 0x00093CE4
	[Token(Token = "0x6001CE0")]
	[Address(RVA = "0x2ADBD78", Offset = "0x2ADBD78", VA = "0x2ADBD78")]
	public IEnumerator ۅ\u06FE\u06FD\u07FB()
	{
		long <>1__state;
		LavaManager.ؽ\u0835ڻӡ ؽ_u0835ڻӡ = new LavaManager.ؽ\u0835ڻӡ((int)<>1__state);
		<>1__state = 1L;
		ؽ_u0835ڻӡ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001CE1 RID: 7393 RVA: 0x00095B08 File Offset: 0x00093D08
	[Token(Token = "0x6001CE1")]
	[Address(RVA = "0x2ADBDF0", Offset = "0x2ADBDF0", VA = "0x2ADBDF0")]
	private void ٻ٢ڳ\u0837(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("amongus");
		this.ڐۊࠔ\u0651.ۆ\u05C8خ\u0612();
	}

	// Token: 0x06001CE2 RID: 7394 RVA: 0x00095B38 File Offset: 0x00093D38
	[Token(Token = "0x6001CE2")]
	[Address(RVA = "0x2ADBE7C", Offset = "0x2ADBE7C", VA = "0x2ADBE7C")]
	private void ӟӟڔމ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001CE3 RID: 7395 RVA: 0x00095B64 File Offset: 0x00093D64
	[Token(Token = "0x6001CE3")]
	[Address(RVA = "0x2AD6B5C", Offset = "0x2AD6B5C", VA = "0x2AD6B5C")]
	public void Ӝ\u07F1ࡁܘ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[1];
		if ("hh:mm:sstt" != null)
		{
			if ("hh:mm:sstt" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] parameters = new object[1];
			if ("Reason: " == null)
			{
				component2.RPC("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n", RpcTarget.AllViaServer, parameters);
				return;
			}
			if ("Reason: " != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CE4 RID: 7396 RVA: 0x00095BE8 File Offset: 0x00093DE8
	[Token(Token = "0x6001CE4")]
	[Address(RVA = "0x2ADBF54", Offset = "0x2ADBF54", VA = "0x2ADBF54")]
	private void ٺۍܢӂ()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string u073BӵӞ_u07FD = this.\u073BӵӞ\u07FD;
		addUserVirtualCurrencyRequest.VirtualCurrency = u073BӵӞ_u07FD;
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001CE5 RID: 7397 RVA: 0x00095C18 File Offset: 0x00093E18
	[Token(Token = "0x6001CE5")]
	[Address(RVA = "0x2ADC0CC", Offset = "0x2ADC0CC", VA = "0x2ADC0CC")]
	public void \u07AE\u0884քӷ(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u0746Ԟࡕߩ.z = (float)17509;
			this.\u064E\u06DFࡘվ = (float)57344;
		}
		this.\u05CDࠇܩܚ = (17509 != 0);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001CE6 RID: 7398 RVA: 0x00095C94 File Offset: 0x00093E94
	[Token(Token = "0x6001CE6")]
	[Address(RVA = "0x2ADC1AC", Offset = "0x2ADC1AC", VA = "0x2ADC1AC")]
	public void \u0893Նխڭ(bool ݙӲࡅҿ)
	{
		this.\u07AE\u05AF\u064FԖ.RequestOwnership();
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(bool).TypeHandle == null || typeof(bool).TypeHandle != null)
		{
			if ("EnableCosmetic" == null)
			{
			}
			ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CE7 RID: 7399 RVA: 0x00095D08 File Offset: 0x00093F08
	[Token(Token = "0x6001CE7")]
	[Address(RVA = "0x2ADC478", Offset = "0x2ADC478", VA = "0x2ADC478")]
	public void ړܕࡊ\u073E(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u0746Ԟࡕߩ.z = (float)17387;
			this.\u064E\u06DFࡘվ = (float)17220;
		}
		this.\u05CDࠇܩܚ = (17387 != 0);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001CE8 RID: 7400 RVA: 0x00095D84 File Offset: 0x00093F84
	[Token(Token = "0x6001CE8")]
	[Address(RVA = "0x2ADC554", Offset = "0x2ADC554", VA = "0x2ADC554")]
	private void \u0605\u0733\u0829ܪ()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		long virtualCurrency = 0L;
		addUserVirtualCurrencyRequest.VirtualCurrency = virtualCurrency;
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001CE9 RID: 7401 RVA: 0x00095DB0 File Offset: 0x00093FB0
	[Token(Token = "0x6001CE9")]
	[Address(RVA = "0x2ADC6CC", Offset = "0x2ADC6CC", VA = "0x2ADC6CC")]
	private void ࡏیخ\u0823(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001CEA RID: 7402 RVA: 0x00095DDC File Offset: 0x00093FDC
	[Token(Token = "0x6001CEA")]
	[Address(RVA = "0x2ADC7A4", Offset = "0x2ADC7A4", VA = "0x2ADC7A4")]
	public void ԽӦێײ(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u0746Ԟࡕߩ.z = (float)8192;
			this.\u064E\u06DFࡘվ = (float)40960;
		}
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001CEB RID: 7403 RVA: 0x00095E4C File Offset: 0x0009404C
	[Token(Token = "0x6001CEB")]
	[Address(RVA = "0x2ADC888", Offset = "0x2ADC888", VA = "0x2ADC888")]
	public void ץӤكݎ(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u0746Ԟࡕߩ.z = (float)16384;
			this.\u064E\u06DFࡘվ = (float)49152;
		}
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001CEC RID: 7404 RVA: 0x00095EBC File Offset: 0x000940BC
	[Token(Token = "0x6001CEC")]
	[Address(RVA = "0x2ADC96C", Offset = "0x2ADC96C", VA = "0x2ADC96C")]
	public IEnumerator Ӭӂޡ߀()
	{
		long <>1__state;
		LavaManager.ؽ\u0835ڻӡ ؽ_u0835ڻӡ = new LavaManager.ؽ\u0835ڻӡ((int)<>1__state);
		<>1__state = 0L;
		ؽ_u0835ڻӡ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001CED RID: 7405 RVA: 0x00095EE0 File Offset: 0x000940E0
	[Token(Token = "0x6001CED")]
	[Address(RVA = "0x2ADC9E4", Offset = "0x2ADC9E4", VA = "0x2ADC9E4")]
	public void Ԧ\u083E\u0652۲(bool ݙӲࡅҿ)
	{
		this.\u07AE\u05AF\u064FԖ.RequestOwnership();
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(bool).TypeHandle == null || typeof(bool).TypeHandle != null)
		{
			if ("Platform failed to initialize due to exception." == null)
			{
			}
			ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CEE RID: 7406 RVA: 0x00095F4C File Offset: 0x0009414C
	[Token(Token = "0x6001CEE")]
	[Address(RVA = "0x2ADCCA8", Offset = "0x2ADCCA8", VA = "0x2ADCCA8")]
	private void ڷ\u07AF߄ٳ(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		this.ڐۊࠔ\u0651.ۆ\u05C8خ\u0612();
	}

	// Token: 0x06001CEF RID: 7407 RVA: 0x00095F74 File Offset: 0x00094174
	[Token(Token = "0x6001CEF")]
	[Address(RVA = "0x2ADCD34", Offset = "0x2ADCD34", VA = "0x2ADCD34")]
	private void ԟ\u086Cޣ\u055E()
	{
		if (this.\u05CDࠇܩܚ)
		{
			GameObject ך_u0897_u05BE_u085B = this.ך\u0897\u05BE\u085B;
			long active = 1L;
			ך_u0897_u05BE_u085B.SetActive(active != 0L);
			GameObject u074C_u0707_u0595յ = this.\u074C\u0707\u0595յ;
			long active2 = 0L;
			u074C_u0707_u0595յ.SetActive(active2 != 0L);
			GameObject gameObject = this.\u0619\u0894Ա\u05CF.gameObject;
			long active3 = 1L;
			gameObject.SetActive(active3 != 0L);
			GameObject u061Aոԕע = this.\u061Aոԕע;
			long active4 = 1L;
			u061Aոԕע.SetActive(active4 != 0L);
			GameObject u06E1۷_u070Cۇ = this.\u06E1۷\u070Cۇ;
			long active5 = 1L;
			u06E1۷_u070Cۇ.SetActive(active5 != 0L);
			GameObject gameObject2 = this.ӿӊܞܤ;
			long active6 = 1L;
			gameObject2.SetActive(active6 != 0L);
			GameObject խښ_u05A4_u = this.Խښ\u05A4\u0836;
			long active7 = 1L;
			խښ_u05A4_u.SetActive(active7 != 0L);
			GameObject u05A9ۉ_u05B3_u = this.\u05A9ۉ\u05B3\u0706;
			long active8 = 0L;
			u05A9ۉ_u05B3_u.SetActive(active8 != 0L);
			GameObject ٸڼ_u05B5Ӹ = this.ٸڼ\u05B5Ӹ;
			bool u07BF_u05CD۳Ӵ = this.\u07BF\u05CD۳Ӵ;
			long active9 = 1L;
			ٸڼ_u05B5Ӹ.SetActive(active9 != 0L);
			GameObject ݱԐࠆ_u065F = this.ݱԐࠆ\u065F;
			if (u07BF_u05CD۳Ӵ)
			{
				return;
			}
			long active10 = 1L;
			GameObject ݱԐࠆ_u065F2;
			ݱԐࠆ_u065F2.SetActive(active10 != 0L);
			GameObject u06E3ݎԶԛ = this.\u06E3ݎԶԛ;
			long active11 = 0L;
			u06E3ݎԶԛ.SetActive(active11 != 0L);
			bool u05F3ۂ_u0899آ = this.\u05F3ۂ\u0899آ;
			long num = 1L;
			this.ࡌ\u082F߄س = (num != 0L);
			if (!u05F3ۂ_u0899آ)
			{
				IEnumerator routine = this.ۅ\u06FE\u06FD\u07FB();
				Coroutine coroutine = base.StartCoroutine(routine);
				this.\u05F3ۂ\u0899آ = (num != 0L);
			}
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				Transform u0619_u0894Ա_u05CF = this.\u0619\u0894Ա\u05CF;
				float deltaTime = Time.deltaTime;
				float x = this.\u0746Ԟࡕߩ.x;
				float y = this.\u0746Ԟࡕߩ.y;
				float z = this.\u0746Ԟࡕߩ.z;
			}
			Vector3 position = this.\u0619\u0894Ա\u05CF.position;
			float u064E_u06DFࡘվ = this.\u064E\u06DFࡘվ;
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				object[] array = new object[0];
				if (typeof(bool).TypeHandle != null && typeof(bool).TypeHandle == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			}
			AudioLowPassFilter[] array2 = this.ࡥԇࠀڷ;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		else
		{
			Transform ֆܧבӒ = this.ՖܧבӒ;
			Transform u0619_u0894Ա_u05CF2 = this.\u0619\u0894Ա\u05CF;
			Vector3 position2 = ֆܧבӒ.position;
			if (this.\u07BF\u05CD۳Ӵ)
			{
				Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
				Transform transform = this.ڿӣԛӾ;
				Vector3 position3 = u05F8ܔԐٿ.position;
				Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
				Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
				Vector3 position4 = u05F8ܔԐٿ2.position;
				GameObject ٸڼ_u05B5Ӹ2 = this.ٸڼ\u05B5Ӹ;
				long active12 = 1L;
				ٸڼ_u05B5Ӹ2.SetActive(active12 != 0L);
				GameObject ݱԐࠆ_u065F2 = this.ݱԐࠆ\u065F;
				long active13 = 1L;
				ݱԐࠆ_u065F2.SetActive(active13 != 0L);
				return;
			}
			if (this.ࡌ\u082F߄س)
			{
				long useGravity;
				this.աߞ\u07A7ߦ.useGravity = (useGravity != 0L);
				Rigidbody ցԁ_u0740օ = this.ՑԀ\u0740օ;
				long useGravity2 = 0L;
				ցԁ_u0740օ.useGravity = (useGravity2 != 0L);
				Rigidbody u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
				long useGravity3 = 0L;
				u0741_u06E2ӳࢣ.useGravity = (useGravity3 != 0L);
				this.\u0740\u0896۶ޗ();
				Swimmy ڢݕڕ_u06E = this.ڢݕڕ\u06E8;
				long enabled = 0L;
				ڢݕڕ_u06E.enabled = (enabled != 0L);
				this.ٺۍܢӂ();
			}
			GameObject u061Aոԕע2 = this.\u061Aոԕע;
			long active14 = 0L;
			u061Aոԕע2.SetActive(active14 != 0L);
			GameObject u06E1۷_u070Cۇ2 = this.\u06E1۷\u070Cۇ;
			long active15 = 0L;
			u06E1۷_u070Cۇ2.SetActive(active15 != 0L);
			GameObject gameObject3 = this.ӿӊܞܤ;
			long active16 = 1L;
			gameObject3.SetActive(active16 != 0L);
			GameObject ٸڼ_u05B5Ӹ3 = this.ٸڼ\u05B5Ӹ;
			long active17 = 0L;
			ٸڼ_u05B5Ӹ3.SetActive(active17 != 0L);
			GameObject ݱԐࠆ_u065F3 = this.ݱԐࠆ\u065F;
			long active18 = 0L;
			ݱԐࠆ_u065F3.SetActive(active18 != 0L);
			GameObject ך_u0897_u05BE_u085B2 = this.ך\u0897\u05BE\u085B;
			long active19 = 0L;
			ך_u0897_u05BE_u085B2.SetActive(active19 != 0L);
			GameObject u074C_u0707_u0595յ2 = this.\u074C\u0707\u0595յ;
			long active20 = 1L;
			u074C_u0707_u0595յ2.SetActive(active20 != 0L);
			GameObject u05A9ۉ_u05B3_u2 = this.\u05A9ۉ\u05B3\u0706;
			long active21 = 1L;
			u05A9ۉ_u05B3_u2.SetActive(active21 != 0L);
			GameObject u06E3ݎԶԛ2 = this.\u06E3ݎԶԛ;
			long active22 = 1L;
			u06E3ݎԶԛ2.SetActive(active22 != 0L);
			GameObject gameObject4 = this.\u0619\u0894Ա\u05CF.gameObject;
			long active23 = 1L;
			gameObject4.SetActive(active23 != 0L);
			AudioLowPassFilter[] array3 = this.ࡥԇࠀڷ;
			return;
		}
	}

	// Token: 0x06001CF0 RID: 7408 RVA: 0x00096368 File Offset: 0x00094568
	[Token(Token = "0x6001CF0")]
	[Address(RVA = "0x2ADD618", Offset = "0x2ADD618", VA = "0x2ADD618")]
	private void ث\u0741\u07BC\u0597(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001CF1 RID: 7409 RVA: 0x00096394 File Offset: 0x00094594
	[Token(Token = "0x6001CF1")]
	[Address(RVA = "0x2ADD6F0", Offset = "0x2ADD6F0", VA = "0x2ADD6F0")]
	private void բࡓ\u073FԮ()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string u073BӵӞ_u07FD = this.\u073BӵӞ\u07FD;
		addUserVirtualCurrencyRequest.VirtualCurrency = u073BӵӞ_u07FD;
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001CF2 RID: 7410 RVA: 0x000963C4 File Offset: 0x000945C4
	[Token(Token = "0x6001CF2")]
	[Address(RVA = "0x2AD8578", Offset = "0x2AD8578", VA = "0x2AD8578")]
	public void ւߠݱԕ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[0];
		if ("TurnAmount" != null)
		{
			if ("TurnAmount" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[1];
			if ("Player" != null)
			{
				if ("Player" != null)
				{
					return;
				}
			}
			else
			{
				if (typeof(object[]).TypeHandle != null)
				{
					return;
				}
				throw new IndexOutOfRangeException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CF3 RID: 7411 RVA: 0x00096444 File Offset: 0x00094644
	[Token(Token = "0x6001CF3")]
	[Address(RVA = "0x2ADD868", Offset = "0x2ADD868", VA = "0x2ADD868")]
	public void ڭ\u05B1ࡌ۴()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[1];
		if ("NetworkPlayer" != null)
		{
			if ("NetworkPlayer" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[0];
			if ("{0} ({1})" == null)
			{
				return;
			}
			if ("{0} ({1})" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CF4 RID: 7412 RVA: 0x000964BC File Offset: 0x000946BC
	[Token(Token = "0x6001CF4")]
	[Address(RVA = "0x2ADDA48", Offset = "0x2ADDA48", VA = "0x2ADDA48")]
	public void \u055Cࡐڀױ(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u0746Ԟࡕߩ.z = (float)17466;
			this.\u064E\u06DFࡘվ = (float)32768;
		}
		this.\u05CDࠇܩܚ = (17466 != 0);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001CF5 RID: 7413 RVA: 0x00096538 File Offset: 0x00094738
	[Token(Token = "0x6001CF5")]
	[Address(RVA = "0x2ADDB28", Offset = "0x2ADDB28", VA = "0x2ADDB28")]
	private void ࢭ\u0589\u0892\u058A()
	{
		if (this.\u05CDࠇܩܚ)
		{
			GameObject ך_u0897_u05BE_u085B = this.ך\u0897\u05BE\u085B;
			long active = 1L;
			ך_u0897_u05BE_u085B.SetActive(active != 0L);
			GameObject u074C_u0707_u0595յ = this.\u074C\u0707\u0595յ;
			long active2 = 1L;
			u074C_u0707_u0595յ.SetActive(active2 != 0L);
			GameObject gameObject = this.\u0619\u0894Ա\u05CF.gameObject;
			long active3 = 1L;
			gameObject.SetActive(active3 != 0L);
			GameObject u061Aոԕע = this.\u061Aոԕע;
			long active4 = 1L;
			u061Aոԕע.SetActive(active4 != 0L);
			GameObject u06E1۷_u070Cۇ = this.\u06E1۷\u070Cۇ;
			long active5 = 1L;
			u06E1۷_u070Cۇ.SetActive(active5 != 0L);
			GameObject gameObject2 = this.ӿӊܞܤ;
			long active6 = 1L;
			gameObject2.SetActive(active6 != 0L);
			GameObject խښ_u05A4_u = this.Խښ\u05A4\u0836;
			long active7 = 0L;
			խښ_u05A4_u.SetActive(active7 != 0L);
			long active8 = 0L;
			խښ_u05A4_u.SetActive(active8 != 0L);
			GameObject ٸڼ_u05B5Ӹ = this.ٸڼ\u05B5Ӹ;
			if (this.\u07BF\u05CD۳Ӵ)
			{
				return;
			}
			long active9 = 1L;
			GameObject ݱԐࠆ_u065F;
			ݱԐࠆ_u065F.SetActive(active9 != 0L);
			GameObject ݱԐࠆ_u065F2 = this.ݱԐࠆ\u065F;
			long active10 = 0L;
			ݱԐࠆ_u065F2.SetActive(active10 != 0L);
			GameObject u06E3ݎԶԛ = this.\u06E3ݎԶԛ;
			long active11 = 1L;
			long u05F3ۂ_u0899آ = 1L;
			u06E3ݎԶԛ.SetActive(active11 != 0L);
			if (!this.\u05F3ۂ\u0899آ)
			{
				IEnumerator routine = this.ڛࠂޜי();
				Coroutine coroutine = base.StartCoroutine(routine);
				this.\u05F3ۂ\u0899آ = (u05F3ۂ_u0899آ != 0L);
			}
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				Transform u0619_u0894Ա_u05CF = this.\u0619\u0894Ա\u05CF;
				float deltaTime = Time.deltaTime;
				float x = this.\u0746Ԟࡕߩ.x;
				float y = this.\u0746Ԟࡕߩ.y;
				float z = this.\u0746Ԟࡕߩ.z;
			}
			Vector3 position = this.\u0619\u0894Ա\u05CF.position;
			float u064E_u06DFࡘվ = this.\u064E\u06DFࡘվ;
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				object[] array = new object[1];
				if (typeof(bool).TypeHandle != null && typeof(bool).TypeHandle == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			}
			AudioLowPassFilter[] array2 = this.ࡥԇࠀڷ;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		else
		{
			Transform ֆܧבӒ = this.ՖܧבӒ;
			Transform u0619_u0894Ա_u05CF2 = this.\u0619\u0894Ա\u05CF;
			Vector3 position2 = ֆܧבӒ.position;
			bool u07BF_u05CD۳Ӵ = this.\u07BF\u05CD۳Ӵ;
			int u064E_u06DFࡘվ2 = 32768;
			int z2 = 17479;
			long u05F3ۂ_u0899آ2 = 1L;
			this.\u0746Ԟࡕߩ.z = (float)z2;
			this.\u064E\u06DFࡘվ = (float)u064E_u06DFࡘվ2;
			this.\u05F3ۂ\u0899آ = (u05F3ۂ_u0899آ2 != 0L);
			if (u07BF_u05CD۳Ӵ)
			{
				Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
				Transform transform = this.ڿӣԛӾ;
				Vector3 position3 = u05F8ܔԐٿ.position;
				Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
				Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
				Vector3 position4 = u05F8ܔԐٿ2.position;
				GameObject ٸڼ_u05B5Ӹ2 = this.ٸڼ\u05B5Ӹ;
				long active12 = 0L;
				ٸڼ_u05B5Ӹ2.SetActive(active12 != 0L);
				GameObject ݱԐࠆ_u065F = this.ݱԐࠆ\u065F;
				long active13 = 0L;
				ݱԐࠆ_u065F.SetActive(active13 != 0L);
				long u07BF_u05CD۳Ӵ2 = 1L;
				this.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ2 != 0L);
				return;
			}
			if (this.ࡌ\u082F߄س)
			{
				Rigidbody աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
				long useGravity = 0L;
				աߞ_u07A7ߦ.useGravity = (useGravity != 0L);
				Rigidbody ցԁ_u0740օ = this.ՑԀ\u0740օ;
				long useGravity2 = 1L;
				ցԁ_u0740օ.useGravity = (useGravity2 != 0L);
				Rigidbody u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
				long useGravity3 = 0L;
				u0741_u06E2ӳࢣ.useGravity = (useGravity3 != 0L);
				this.۵Ԥࡠځ();
				Swimmy ڢݕڕ_u06E = this.ڢݕڕ\u06E8;
				long enabled = 1L;
				ڢݕڕ_u06E.enabled = (enabled != 0L);
				this.ٺۍܢӂ();
			}
			GameObject u061Aոԕע2 = this.\u061Aոԕע;
			long u07BF_u05CD۳Ӵ3 = 1L;
			this.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ3 != 0L);
			long active14 = 0L;
			u061Aոԕע2.SetActive(active14 != 0L);
			GameObject u06E1۷_u070Cۇ2 = this.\u06E1۷\u070Cۇ;
			long active15 = 1L;
			u06E1۷_u070Cۇ2.SetActive(active15 != 0L);
			GameObject gameObject3 = this.ӿӊܞܤ;
			long active16 = 1L;
			gameObject3.SetActive(active16 != 0L);
			GameObject ٸڼ_u05B5Ӹ3 = this.ٸڼ\u05B5Ӹ;
			long active17 = 0L;
			ٸڼ_u05B5Ӹ3.SetActive(active17 != 0L);
			GameObject ݱԐࠆ_u065F3 = this.ݱԐࠆ\u065F;
			long active18 = 1L;
			ݱԐࠆ_u065F3.SetActive(active18 != 0L);
			GameObject ך_u0897_u05BE_u085B2 = this.ך\u0897\u05BE\u085B;
			long active19 = 1L;
			ך_u0897_u05BE_u085B2.SetActive(active19 != 0L);
			GameObject u074C_u0707_u0595յ2 = this.\u074C\u0707\u0595յ;
			long active20 = 1L;
			u074C_u0707_u0595յ2.SetActive(active20 != 0L);
			GameObject u05A9ۉ_u05B3_u = this.\u05A9ۉ\u05B3\u0706;
			long active21 = 1L;
			u05A9ۉ_u05B3_u.SetActive(active21 != 0L);
			GameObject u06E3ݎԶԛ2 = this.\u06E3ݎԶԛ;
			long active22 = 1L;
			u06E3ݎԶԛ2.SetActive(active22 != 0L);
			GameObject gameObject4 = this.\u0619\u0894Ա\u05CF.gameObject;
			long active23 = 0L;
			gameObject4.SetActive(active23 != 0L);
			AudioLowPassFilter[] array3 = this.ࡥԇࠀڷ;
			return;
		}
	}

	// Token: 0x06001CF6 RID: 7414 RVA: 0x0009694C File Offset: 0x00094B4C
	[Token(Token = "0x6001CF6")]
	[Address(RVA = "0x2ADE45C", Offset = "0x2ADE45C", VA = "0x2ADE45C")]
	private void \u0732\u0703\u086C\u05B2(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001CF7 RID: 7415 RVA: 0x00096978 File Offset: 0x00094B78
	[Token(Token = "0x6001CF7")]
	[Address(RVA = "0x2ADE534", Offset = "0x2ADE534", VA = "0x2ADE534")]
	private void ܪ\u073A\u05A5\u05CB(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Players Online: ");
		this.ڐۊࠔ\u0651.\u0617\u0897\u087C\u0616();
	}

	// Token: 0x06001CF8 RID: 7416 RVA: 0x000969A8 File Offset: 0x00094BA8
	[Token(Token = "0x6001CF8")]
	[Address(RVA = "0x2ADE200", Offset = "0x2ADE200", VA = "0x2ADE200")]
	public IEnumerator ڛࠂޜי()
	{
		long <>1__state;
		LavaManager.ؽ\u0835ڻӡ ؽ_u0835ڻӡ = new LavaManager.ؽ\u0835ڻӡ((int)<>1__state);
		<>1__state = 1L;
		ؽ_u0835ڻӡ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001CF9 RID: 7417 RVA: 0x000969CC File Offset: 0x00094BCC
	[Token(Token = "0x6001CF9")]
	[Address(RVA = "0x2ADE5C0", Offset = "0x2ADE5C0", VA = "0x2ADE5C0")]
	private void \u0870\u05B3Ց\u066A()
	{
		if (this.\u05CDࠇܩܚ)
		{
			GameObject ך_u0897_u05BE_u085B = this.ך\u0897\u05BE\u085B;
			long active = 1L;
			ך_u0897_u05BE_u085B.SetActive(active != 0L);
			GameObject u074C_u0707_u0595յ = this.\u074C\u0707\u0595յ;
			long active2 = 1L;
			u074C_u0707_u0595յ.SetActive(active2 != 0L);
			GameObject gameObject = this.\u0619\u0894Ա\u05CF.gameObject;
			long active3 = 1L;
			gameObject.SetActive(active3 != 0L);
			GameObject u061Aոԕע = this.\u061Aոԕע;
			long active4 = 1L;
			u061Aոԕע.SetActive(active4 != 0L);
			GameObject u06E1۷_u070Cۇ = this.\u06E1۷\u070Cۇ;
			long active5 = 0L;
			u06E1۷_u070Cۇ.SetActive(active5 != 0L);
			GameObject gameObject2 = this.ӿӊܞܤ;
			long active6 = 0L;
			gameObject2.SetActive(active6 != 0L);
			GameObject խښ_u05A4_u = this.Խښ\u05A4\u0836;
			long active7 = 1L;
			խښ_u05A4_u.SetActive(active7 != 0L);
			GameObject u05A9ۉ_u05B3_u = this.\u05A9ۉ\u05B3\u0706;
			long active8 = 1L;
			u05A9ۉ_u05B3_u.SetActive(active8 != 0L);
			GameObject ٸڼ_u05B5Ӹ = this.ٸڼ\u05B5Ӹ;
			long active9 = 1L;
			ٸڼ_u05B5Ӹ.SetActive(active9 != 0L);
			GameObject ݱԐࠆ_u065F = this.ݱԐࠆ\u065F;
			long active10 = 1L;
			long ࡌ_u082F߄س = 1L;
			ݱԐࠆ_u065F.SetActive(active10 != 0L);
			GameObject u06E3ݎԶԛ = this.\u06E3ݎԶԛ;
			long active11 = 0L;
			u06E3ݎԶԛ.SetActive(active11 != 0L);
			bool u05F3ۂ_u0899آ = this.\u05F3ۂ\u0899آ;
			this.ࡌ\u082F߄س = (ࡌ_u082F߄س != 0L);
			if (!u05F3ۂ_u0899آ)
			{
				IEnumerator routine = this.\u0873Ӳ\u086E\u089A();
				Coroutine coroutine = base.StartCoroutine(routine);
			}
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				Transform u0619_u0894Ա_u05CF = this.\u0619\u0894Ա\u05CF;
				float deltaTime = Time.deltaTime;
				float x = this.\u0746Ԟࡕߩ.x;
				float y = this.\u0746Ԟࡕߩ.y;
				float z = this.\u0746Ԟࡕߩ.z;
			}
			Vector3 position = this.\u0619\u0894Ա\u05CF.position;
			float u064E_u06DFࡘվ = this.\u064E\u06DFࡘվ;
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				if (typeof(bool).TypeHandle != null && typeof(bool).TypeHandle == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			}
			AudioLowPassFilter[] array = this.ࡥԇࠀڷ;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		Transform ֆܧבӒ = this.ՖܧבӒ;
		Transform u0619_u0894Ա_u05CF2 = this.\u0619\u0894Ա\u05CF;
		Vector3 position2 = ֆܧבӒ.position;
		bool u07BF_u05CD۳Ӵ = this.\u07BF\u05CD۳Ӵ;
		int z2 = 49152;
		int u064E_u06DFࡘվ2 = 40960;
		long u05F3ۂ_u0899آ2 = 1L;
		this.\u0746Ԟࡕߩ.z = (float)z2;
		this.\u064E\u06DFࡘվ = (float)u064E_u06DFࡘվ2;
		this.\u05F3ۂ\u0899آ = (u05F3ۂ_u0899آ2 != 0L);
		if (u07BF_u05CD۳Ӵ)
		{
			Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
			Transform transform = this.ڿӣԛӾ;
			Vector3 position3 = u05F8ܔԐٿ.position;
			Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
			Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
			Vector3 position4 = u05F8ܔԐٿ2.position;
			GameObject ٸڼ_u05B5Ӹ2 = this.ٸڼ\u05B5Ӹ;
			long active12 = 1L;
			long u07BF_u05CD۳Ӵ2 = 1L;
			ٸڼ_u05B5Ӹ2.SetActive(active12 != 0L);
			GameObject ݱԐࠆ_u065F2 = this.ݱԐࠆ\u065F;
			long active13 = 0L;
			ݱԐࠆ_u065F2.SetActive(active13 != 0L);
			this.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ2 != 0L);
			return;
		}
		if (this.ࡌ\u082F߄س)
		{
			Rigidbody աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			long useGravity = 1L;
			աߞ_u07A7ߦ.useGravity = (useGravity != 0L);
			Rigidbody ցԁ_u0740օ = this.ՑԀ\u0740օ;
			long useGravity2 = 0L;
			ցԁ_u0740օ.useGravity = (useGravity2 != 0L);
			Rigidbody u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			long useGravity3 = 1L;
			u0741_u06E2ӳࢣ.useGravity = (useGravity3 != 0L);
			this.ԏ\u06DCޒ\u07FF();
			Swimmy ڢݕڕ_u06E = this.ڢݕڕ\u06E8;
			long enabled = 1L;
			ڢݕڕ_u06E.enabled = (enabled != 0L);
			this.ڑ\u0881\u0603ԋ();
		}
		GameObject u061Aոԕע2 = this.\u061Aոԕע;
		long u07BF_u05CD۳Ӵ3 = 1L;
		this.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ3 != 0L);
		long active14 = 0L;
		u061Aոԕע2.SetActive(active14 != 0L);
		GameObject u06E1۷_u070Cۇ2 = this.\u06E1۷\u070Cۇ;
		long active15 = 1L;
		u06E1۷_u070Cۇ2.SetActive(active15 != 0L);
		GameObject gameObject3 = this.ӿӊܞܤ;
		long active16 = 0L;
		gameObject3.SetActive(active16 != 0L);
		GameObject ٸڼ_u05B5Ӹ3 = this.ٸڼ\u05B5Ӹ;
		long active17 = 0L;
		ٸڼ_u05B5Ӹ3.SetActive(active17 != 0L);
		GameObject ݱԐࠆ_u065F3 = this.ݱԐࠆ\u065F;
		long active18 = 1L;
		ݱԐࠆ_u065F3.SetActive(active18 != 0L);
		GameObject ך_u0897_u05BE_u085B2 = this.ך\u0897\u05BE\u085B;
		long active19 = 1L;
		ך_u0897_u05BE_u085B2.SetActive(active19 != 0L);
		GameObject u074C_u0707_u0595յ2 = this.\u074C\u0707\u0595յ;
		long active20 = 0L;
		u074C_u0707_u0595յ2.SetActive(active20 != 0L);
		GameObject u05A9ۉ_u05B3_u2 = this.\u05A9ۉ\u05B3\u0706;
		long active21 = 0L;
		u05A9ۉ_u05B3_u2.SetActive(active21 != 0L);
		GameObject u06E3ݎԶԛ2 = this.\u06E3ݎԶԛ;
		long active22 = 0L;
		u06E3ݎԶԛ2.SetActive(active22 != 0L);
		GameObject gameObject4 = this.\u0619\u0894Ա\u05CF.gameObject;
		long active23 = 0L;
		gameObject4.SetActive(active23 != 0L);
		AudioLowPassFilter[] array2 = this.ࡥԇࠀڷ;
	}

	// Token: 0x06001CFA RID: 7418 RVA: 0x00096DC8 File Offset: 0x00094FC8
	[Token(Token = "0x6001CFA")]
	[Address(RVA = "0x2ADED00", Offset = "0x2ADED00", VA = "0x2ADED00")]
	private void \u082C\u05B1րݷ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001CFB RID: 7419 RVA: 0x00096DF4 File Offset: 0x00094FF4
	[Token(Token = "0x6001CFB")]
	[Address(RVA = "0x2AD79B8", Offset = "0x2AD79B8", VA = "0x2AD79B8")]
	public void \u0740\u085E\u07FF\u064B()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[1];
		if ("isLava" != null)
		{
			if ("isLava" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] parameters = new object[1];
			if ("PRESS AGAIN TO CONFIRM" == null)
			{
				component2.RPC("containsStaff", RpcTarget.AllViaServer, parameters);
				return;
			}
			if ("PRESS AGAIN TO CONFIRM" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CFC RID: 7420 RVA: 0x00096E78 File Offset: 0x00095078
	[Token(Token = "0x6001CFC")]
	[Address(RVA = "0x2ADEDD8", Offset = "0x2ADEDD8", VA = "0x2ADEDD8")]
	private void Update()
	{
		if (this.\u05CDࠇܩܚ)
		{
			GameObject ך_u0897_u05BE_u085B = this.ך\u0897\u05BE\u085B;
			long active = 1L;
			ך_u0897_u05BE_u085B.SetActive(active != 0L);
			GameObject u074C_u0707_u0595յ = this.\u074C\u0707\u0595յ;
			long active2 = 0L;
			u074C_u0707_u0595յ.SetActive(active2 != 0L);
			GameObject gameObject = this.\u0619\u0894Ա\u05CF.gameObject;
			long active3 = 1L;
			gameObject.SetActive(active3 != 0L);
			GameObject u061Aոԕע = this.\u061Aոԕע;
			long active4 = 0L;
			u061Aոԕע.SetActive(active4 != 0L);
			GameObject u06E1۷_u070Cۇ = this.\u06E1۷\u070Cۇ;
			long active5 = 0L;
			u06E1۷_u070Cۇ.SetActive(active5 != 0L);
			GameObject gameObject2 = this.ӿӊܞܤ;
			long active6 = 0L;
			gameObject2.SetActive(active6 != 0L);
			GameObject խښ_u05A4_u = this.Խښ\u05A4\u0836;
			long active7 = 1L;
			խښ_u05A4_u.SetActive(active7 != 0L);
			GameObject u05A9ۉ_u05B3_u = this.\u05A9ۉ\u05B3\u0706;
			long active8 = 0L;
			u05A9ۉ_u05B3_u.SetActive(active8 != 0L);
			GameObject ٸڼ_u05B5Ӹ = this.ٸڼ\u05B5Ӹ;
			if (this.\u07BF\u05CD۳Ӵ)
			{
				long active9 = 1L;
				ٸڼ_u05B5Ӹ.SetActive(active9 != 0L);
				GameObject ݱԐࠆ_u065F = this.ݱԐࠆ\u065F;
				return;
			}
			long active10 = 0L;
			GameObject ݱԐࠆ_u065F2;
			ݱԐࠆ_u065F2.SetActive(active10 != 0L);
			GameObject ݱԐࠆ_u065F3 = this.ݱԐࠆ\u065F;
			long active11 = 1L;
			ݱԐࠆ_u065F3.SetActive(active11 != 0L);
			GameObject u06E3ݎԶԛ = this.\u06E3ݎԶԛ;
			long active12 = 1L;
			long num = 1L;
			u06E3ݎԶԛ.SetActive(active12 != 0L);
			bool u05F3ۂ_u0899آ = this.\u05F3ۂ\u0899آ;
			this.ࡌ\u082F߄س = (num != 0L);
			if (!u05F3ۂ_u0899آ)
			{
				IEnumerator routine = this.و\u06D8\u066Dࢶ();
				Coroutine coroutine = base.StartCoroutine(routine);
				this.\u05F3ۂ\u0899آ = (num != 0L);
			}
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				Transform u0619_u0894Ա_u05CF = this.\u0619\u0894Ա\u05CF;
				float deltaTime = Time.deltaTime;
				float x = this.\u0746Ԟࡕߩ.x;
				float y = this.\u0746Ԟࡕߩ.y;
				float z = this.\u0746Ԟࡕߩ.z;
			}
			Vector3 position = this.\u0619\u0894Ա\u05CF.position;
			float u064E_u06DFࡘվ = this.\u064E\u06DFࡘվ;
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				object[] array = new object[1];
				if (typeof(bool).TypeHandle != null && typeof(bool).TypeHandle == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			}
			AudioLowPassFilter[] array2 = this.ࡥԇࠀڷ;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		else
		{
			Transform ֆܧבӒ = this.ՖܧבӒ;
			Transform u0619_u0894Ա_u05CF2 = this.\u0619\u0894Ա\u05CF;
			Vector3 position2 = ֆܧבӒ.position;
			if (this.\u07BF\u05CD۳Ӵ)
			{
				Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
				Transform transform = this.ڿӣԛӾ;
				Vector3 position3 = u05F8ܔԐٿ.position;
				Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
				Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
				Vector3 position4 = u05F8ܔԐٿ2.position;
				GameObject ٸڼ_u05B5Ӹ2 = this.ٸڼ\u05B5Ӹ;
				long active13 = 1L;
				ٸڼ_u05B5Ӹ2.SetActive(active13 != 0L);
				GameObject ݱԐࠆ_u065F2 = this.ݱԐࠆ\u065F;
				long active14 = 0L;
				ݱԐࠆ_u065F2.SetActive(active14 != 0L);
				return;
			}
			bool flag;
			if (flag)
			{
				Rigidbody աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
				long useGravity = 1L;
				աߞ_u07A7ߦ.useGravity = (useGravity != 0L);
				Rigidbody ցԁ_u0740օ = this.ՑԀ\u0740օ;
				long useGravity2 = 1L;
				ցԁ_u0740օ.useGravity = (useGravity2 != 0L);
				Rigidbody u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
				long useGravity3 = 1L;
				u0741_u06E2ӳࢣ.useGravity = (useGravity3 != 0L);
				this.ۃٹ\u059D\u0703();
				Swimmy ڢݕڕ_u06E = this.ڢݕڕ\u06E8;
				long enabled = 0L;
				ڢݕڕ_u06E.enabled = (enabled != 0L);
				this.\u0605\u0733\u0829ܪ();
			}
			GameObject u061Aոԕע2 = this.\u061Aոԕע;
			long active15 = 1L;
			u061Aոԕע2.SetActive(active15 != 0L);
			GameObject u06E1۷_u070Cۇ2 = this.\u06E1۷\u070Cۇ;
			long active16 = 1L;
			u06E1۷_u070Cۇ2.SetActive(active16 != 0L);
			GameObject gameObject3 = this.ӿӊܞܤ;
			long active17 = 1L;
			gameObject3.SetActive(active17 != 0L);
			GameObject ٸڼ_u05B5Ӹ3 = this.ٸڼ\u05B5Ӹ;
			long active18 = 1L;
			ٸڼ_u05B5Ӹ3.SetActive(active18 != 0L);
			GameObject ݱԐࠆ_u065F4 = this.ݱԐࠆ\u065F;
			long active19 = 0L;
			ݱԐࠆ_u065F4.SetActive(active19 != 0L);
			GameObject ך_u0897_u05BE_u085B2 = this.ך\u0897\u05BE\u085B;
			long active20 = 0L;
			ך_u0897_u05BE_u085B2.SetActive(active20 != 0L);
			GameObject u074C_u0707_u0595յ2 = this.\u074C\u0707\u0595յ;
			long active21 = 1L;
			u074C_u0707_u0595յ2.SetActive(active21 != 0L);
			GameObject u05A9ۉ_u05B3_u2 = this.\u05A9ۉ\u05B3\u0706;
			long active22 = 1L;
			u05A9ۉ_u05B3_u2.SetActive(active22 != 0L);
			GameObject u06E3ݎԶԛ2 = this.\u06E3ݎԶԛ;
			long active23 = 0L;
			u06E3ݎԶԛ2.SetActive(active23 != 0L);
			GameObject gameObject4 = this.\u0619\u0894Ա\u05CF.gameObject;
			long active24 = 0L;
			gameObject4.SetActive(active24 != 0L);
			AudioLowPassFilter[] array3 = this.ࡥԇࠀڷ;
			return;
		}
	}

	// Token: 0x06001CFD RID: 7421 RVA: 0x00097280 File Offset: 0x00095480
	[Token(Token = "0x6001CFD")]
	[Address(RVA = "0x2ADEC88", Offset = "0x2ADEC88", VA = "0x2ADEC88")]
	public IEnumerator \u0873Ӳ\u086E\u089A()
	{
		long <>1__state;
		LavaManager.ؽ\u0835ڻӡ ؽ_u0835ڻӡ = new LavaManager.ؽ\u0835ڻӡ((int)<>1__state);
		<>1__state = 1L;
		ؽ_u0835ڻӡ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001CFE RID: 7422 RVA: 0x000972A4 File Offset: 0x000954A4
	[Token(Token = "0x6001CFE")]
	[Address(RVA = "0x2ADE278", Offset = "0x2ADE278", VA = "0x2ADE278")]
	public void ۵Ԥࡠځ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[0];
		if ("Vector1_d371bd24217449349bd747533d51af6b" != null)
		{
			if ("Vector1_d371bd24217449349bd747533d51af6b" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[0];
			if ("TurnAmount" == null)
			{
				return;
			}
			if ("TurnAmount" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001CFF RID: 7423 RVA: 0x0009731C File Offset: 0x0009551C
	[Token(Token = "0x6001CFF")]
	[Address(RVA = "0x2ADF718", Offset = "0x2ADF718", VA = "0x2ADF718")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		if (this.\u05CDࠇܩܚ)
		{
			GameObject ך_u0897_u05BE_u085B = this.ך\u0897\u05BE\u085B;
			long active = 0L;
			ך_u0897_u05BE_u085B.SetActive(active != 0L);
			GameObject u074C_u0707_u0595յ = this.\u074C\u0707\u0595յ;
			long active2 = 1L;
			u074C_u0707_u0595յ.SetActive(active2 != 0L);
			GameObject gameObject = this.\u0619\u0894Ա\u05CF.gameObject;
			long active3 = 1L;
			gameObject.SetActive(active3 != 0L);
			GameObject u061Aոԕע = this.\u061Aոԕע;
			long active4 = 1L;
			u061Aոԕע.SetActive(active4 != 0L);
			GameObject u06E1۷_u070Cۇ = this.\u06E1۷\u070Cۇ;
			long active5 = 0L;
			u06E1۷_u070Cۇ.SetActive(active5 != 0L);
			GameObject gameObject2 = this.ӿӊܞܤ;
			long active6 = 1L;
			gameObject2.SetActive(active6 != 0L);
			GameObject խښ_u05A4_u = this.Խښ\u05A4\u0836;
			long active7 = 0L;
			խښ_u05A4_u.SetActive(active7 != 0L);
			GameObject u05A9ۉ_u05B3_u = this.\u05A9ۉ\u05B3\u0706;
			long active8 = 1L;
			u05A9ۉ_u05B3_u.SetActive(active8 != 0L);
			GameObject ٸڼ_u05B5Ӹ = this.ٸڼ\u05B5Ӹ;
			bool u07BF_u05CD۳Ӵ = this.\u07BF\u05CD۳Ӵ;
			long active9 = 1L;
			ٸڼ_u05B5Ӹ.SetActive(active9 != 0L);
			GameObject ݱԐࠆ_u065F = this.ݱԐࠆ\u065F;
			if (u07BF_u05CD۳Ӵ)
			{
				return;
			}
			long active10 = 1L;
			GameObject ݱԐࠆ_u065F2;
			ݱԐࠆ_u065F2.SetActive(active10 != 0L);
			GameObject u06E3ݎԶԛ = this.\u06E3ݎԶԛ;
			long active11 = 1L;
			long ࡌ_u082F߄س = 1L;
			u06E3ݎԶԛ.SetActive(active11 != 0L);
			bool u05F3ۂ_u0899آ = this.\u05F3ۂ\u0899آ;
			this.ࡌ\u082F߄س = (ࡌ_u082F߄س != 0L);
			if (!u05F3ۂ_u0899آ)
			{
				IEnumerator routine = this.ڛࠂޜי();
				Coroutine coroutine = base.StartCoroutine(routine);
			}
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				Transform u0619_u0894Ա_u05CF = this.\u0619\u0894Ա\u05CF;
				float deltaTime = Time.deltaTime;
				float x = this.\u0746Ԟࡕߩ.x;
				float y = this.\u0746Ԟࡕߩ.y;
				float z = this.\u0746Ԟࡕߩ.z;
			}
			Vector3 position = this.\u0619\u0894Ա\u05CF.position;
			float u064E_u06DFࡘվ = this.\u064E\u06DFࡘվ;
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				object[] array = new object[0];
				if (typeof(bool).TypeHandle != null && typeof(bool).TypeHandle == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			}
			AudioLowPassFilter[] array2 = this.ࡥԇࠀڷ;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		else
		{
			Transform ֆܧבӒ = this.ՖܧבӒ;
			Transform u0619_u0894Ա_u05CF2 = this.\u0619\u0894Ա\u05CF;
			Vector3 position2 = ֆܧבӒ.position;
			bool u07BF_u05CD۳Ӵ2 = this.\u07BF\u05CD۳Ӵ;
			int z2 = 57344;
			int u064E_u06DFࡘվ2 = 24576;
			long u05F3ۂ_u0899آ2 = 1L;
			this.\u0746Ԟࡕߩ.z = (float)z2;
			this.\u064E\u06DFࡘվ = (float)u064E_u06DFࡘվ2;
			this.\u05F3ۂ\u0899آ = (u05F3ۂ_u0899آ2 != 0L);
			if (u07BF_u05CD۳Ӵ2)
			{
				Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
				Transform transform = this.ڿӣԛӾ;
				Vector3 position3 = u05F8ܔԐٿ.position;
				Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
				Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
				Vector3 position4 = u05F8ܔԐٿ2.position;
				GameObject ٸڼ_u05B5Ӹ2 = this.ٸڼ\u05B5Ӹ;
				long active12 = 1L;
				ٸڼ_u05B5Ӹ2.SetActive(active12 != 0L);
				GameObject ݱԐࠆ_u065F2 = this.ݱԐࠆ\u065F;
				long active13 = 0L;
				ݱԐࠆ_u065F2.SetActive(active13 != 0L);
				return;
			}
			if (this.ࡌ\u082F߄س)
			{
				Rigidbody աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
				long useGravity = 1L;
				աߞ_u07A7ߦ.useGravity = (useGravity != 0L);
				Rigidbody ցԁ_u0740օ = this.ՑԀ\u0740օ;
				long useGravity2 = 0L;
				ցԁ_u0740օ.useGravity = (useGravity2 != 0L);
				Rigidbody u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
				long useGravity3 = 1L;
				long ࡌ_u082F߄س2 = 1L;
				u0741_u06E2ӳࢣ.useGravity = (useGravity3 != 0L);
				this.ڭ\u05B1ࡌ۴();
				Swimmy ڢݕڕ_u06E = this.ڢݕڕ\u06E8;
				long enabled = 1L;
				ڢݕڕ_u06E.enabled = (enabled != 0L);
				this.\u05AA\u059Dߛࢪ();
				this.ࡌ\u082F߄س = (ࡌ_u082F߄س2 != 0L);
			}
			GameObject u061Aոԕע2 = this.\u061Aոԕע;
			long active14 = 0L;
			u061Aոԕע2.SetActive(active14 != 0L);
			GameObject u06E1۷_u070Cۇ2 = this.\u06E1۷\u070Cۇ;
			long active15 = 1L;
			u06E1۷_u070Cۇ2.SetActive(active15 != 0L);
			GameObject gameObject3 = this.ӿӊܞܤ;
			long active16 = 1L;
			gameObject3.SetActive(active16 != 0L);
			GameObject ٸڼ_u05B5Ӹ3 = this.ٸڼ\u05B5Ӹ;
			long active17 = 1L;
			ٸڼ_u05B5Ӹ3.SetActive(active17 != 0L);
			GameObject ݱԐࠆ_u065F3 = this.ݱԐࠆ\u065F;
			long active18 = 1L;
			ݱԐࠆ_u065F3.SetActive(active18 != 0L);
			GameObject ך_u0897_u05BE_u085B2 = this.ך\u0897\u05BE\u085B;
			long active19 = 1L;
			ך_u0897_u05BE_u085B2.SetActive(active19 != 0L);
			GameObject u074C_u0707_u0595յ2 = this.\u074C\u0707\u0595յ;
			long active20 = 0L;
			u074C_u0707_u0595յ2.SetActive(active20 != 0L);
			GameObject u05A9ۉ_u05B3_u2 = this.\u05A9ۉ\u05B3\u0706;
			long active21 = 0L;
			u05A9ۉ_u05B3_u2.SetActive(active21 != 0L);
			GameObject u06E3ݎԶԛ2 = this.\u06E3ݎԶԛ;
			long active22 = 1L;
			u06E3ݎԶԛ2.SetActive(active22 != 0L);
			GameObject gameObject4 = this.\u0619\u0894Ա\u05CF.gameObject;
			long active23 = 0L;
			gameObject4.SetActive(active23 != 0L);
			AudioLowPassFilter[] array3 = this.ࡥԇࠀڷ;
			return;
		}
	}

	// Token: 0x06001D00 RID: 7424 RVA: 0x00097744 File Offset: 0x00095944
	[Token(Token = "0x6001D00")]
	[Address(RVA = "0x2ADFE08", Offset = "0x2ADFE08", VA = "0x2ADFE08")]
	private void \u05B6\u07A9ٱر(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("hh:mmtt");
		this.ڐۊࠔ\u0651.\u073Aڝձ\u0823();
	}

	// Token: 0x06001D01 RID: 7425 RVA: 0x00097774 File Offset: 0x00095974
	[Token(Token = "0x6001D01")]
	[Address(RVA = "0x2ADFE94", Offset = "0x2ADFE94", VA = "0x2ADFE94")]
	public IEnumerator \u082E\u07F8פߨ()
	{
		long <>1__state;
		LavaManager.ؽ\u0835ڻӡ ؽ_u0835ڻӡ = new LavaManager.ؽ\u0835ڻӡ((int)<>1__state);
		<>1__state = 0L;
		ؽ_u0835ڻӡ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D02 RID: 7426 RVA: 0x00097798 File Offset: 0x00095998
	[Token(Token = "0x6001D02")]
	[Address(RVA = "0x2ADFF0C", Offset = "0x2ADFF0C", VA = "0x2ADFF0C")]
	public void \u059FԽޅ\u07EF(bool ݙӲࡅҿ)
	{
		this.\u07AE\u05AF\u064FԖ.RequestOwnership();
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(bool).TypeHandle == null || typeof(bool).TypeHandle != null)
		{
			if ("Regular" == null)
			{
			}
			ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D03 RID: 7427 RVA: 0x00097810 File Offset: 0x00095A10
	[Token(Token = "0x6001D03")]
	[Address(RVA = "0x2ADD438", Offset = "0x2ADD438", VA = "0x2ADD438")]
	public void \u0740\u0896۶ޗ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		if ("BloodKill" != null)
		{
			if ("BloodKill" != null)
			{
				return;
			}
		}
		else
		{
			long instantiationDataField = 0L;
			if (component.Group == 0)
			{
				throw new IndexOutOfRangeException();
			}
			component.instantiationDataField = instantiationDataField;
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array = new object[0];
			if ("isLava" == null)
			{
				return;
			}
			if ("isLava" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D04 RID: 7428 RVA: 0x00097890 File Offset: 0x00095A90
	[Token(Token = "0x6001D04")]
	[Address(RVA = "0x2ADF4C0", Offset = "0x2ADF4C0", VA = "0x2ADF4C0")]
	public IEnumerator و\u06D8\u066Dࢶ()
	{
		long <>1__state;
		LavaManager.ؽ\u0835ڻӡ ؽ_u0835ڻӡ = new LavaManager.ؽ\u0835ڻӡ((int)<>1__state);
		<>1__state = 0L;
		ؽ_u0835ڻӡ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D05 RID: 7429 RVA: 0x000978B4 File Offset: 0x00095AB4
	[Token(Token = "0x6001D05")]
	[Address(RVA = "0x2AE01DC", Offset = "0x2AE01DC", VA = "0x2AE01DC")]
	private void ټߘގ\u085C()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string u073BӵӞ_u07FD = this.\u073BӵӞ\u07FD;
		addUserVirtualCurrencyRequest.VirtualCurrency = u073BӵӞ_u07FD;
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001D06 RID: 7430 RVA: 0x000978E4 File Offset: 0x00095AE4
	[Token(Token = "0x6001D06")]
	[Address(RVA = "0x2AD705C", Offset = "0x2AD705C", VA = "0x2AD705C")]
	public void إࡅܬՍ()
	{
		object[] parameters = new object[0];
		if ("Tagging" != null)
		{
			if ("Tagging" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView photonView;
			photonView.RPC("_BumpMap", RpcTarget.AllViaServer, parameters);
			object[] array = new object[1];
			if ("DisableCosmetic" == null)
			{
				return;
			}
			if ("DisableCosmetic" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D07 RID: 7431 RVA: 0x00097948 File Offset: 0x00095B48
	[Token(Token = "0x6001D07")]
	[Address(RVA = "0x2AE0354", Offset = "0x2AE0354", VA = "0x2AE0354")]
	public IEnumerator \u088Bޡࢶߊ()
	{
		long <>1__state;
		LavaManager.ؽ\u0835ڻӡ ؽ_u0835ڻӡ = new LavaManager.ؽ\u0835ڻӡ((int)<>1__state);
		<>1__state = 1L;
		ؽ_u0835ڻӡ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D08 RID: 7432 RVA: 0x0009796C File Offset: 0x00095B6C
	[Token(Token = "0x6001D08")]
	[Address(RVA = "0x2AE03CC", Offset = "0x2AE03CC", VA = "0x2AE03CC")]
	public void \u0741پޒ\u064E()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[1];
		if ("FingerTip" != null)
		{
			if ("FingerTip" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[1];
			if ("_WobbleZ" == null)
			{
				return;
			}
			if ("_WobbleZ" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D09 RID: 7433 RVA: 0x000979E0 File Offset: 0x00095BE0
	[Token(Token = "0x6001D09")]
	[Address(RVA = "0x2AD6D40", Offset = "0x2AD6D40", VA = "0x2AD6D40")]
	public void Շ\u0650ࡅڸ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[0];
		if ("\tExpires: " != null)
		{
			if ("\tExpires: " != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[0];
			if ("username" == null)
			{
				return;
			}
			if ("username" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D0A RID: 7434 RVA: 0x00097A5C File Offset: 0x00095C5C
	[Token(Token = "0x6001D0A")]
	[Address(RVA = "0x2AE05B0", Offset = "0x2AE05B0", VA = "0x2AE05B0")]
	public void փג\u07EBޛ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[1];
		if ("You have been banned for " != null)
		{
			if ("You have been banned for " != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] parameters = new object[0];
			if ("hh:mm:sstt" == null)
			{
				component2.RPC("Key", RpcTarget.AllViaServer, parameters);
				return;
			}
			if ("hh:mm:sstt" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D0B RID: 7435 RVA: 0x00097AE0 File Offset: 0x00095CE0
	[Token(Token = "0x6001D0B")]
	[Address(RVA = "0x2AE0780", Offset = "0x2AE0780", VA = "0x2AE0780")]
	private void \u089Aࢺࠉ\u0742(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("isLava");
		this.ڐۊࠔ\u0651.\u07F2߂ނ\u083F();
	}

	// Token: 0x06001D0C RID: 7436 RVA: 0x00097B10 File Offset: 0x00095D10
	[Token(Token = "0x6001D0C")]
	[Address(RVA = "0x2AE080C", Offset = "0x2AE080C", VA = "0x2AE080C")]
	private void \u05AF\u0818Պ\u05F7(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("false");
		this.ڐۊࠔ\u0651.\u073Aڝձ\u0823();
	}

	// Token: 0x06001D0D RID: 7437 RVA: 0x00097B40 File Offset: 0x00095D40
	[Token(Token = "0x6001D0D")]
	[Address(RVA = "0x2AE0898", Offset = "0x2AE0898", VA = "0x2AE0898")]
	public void ࠕ\u0828\u06DAց(bool ݙӲࡅҿ)
	{
		this.\u07AE\u05AF\u064FԖ.RequestOwnership();
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(bool).TypeHandle == null || typeof(bool).TypeHandle != null)
		{
			if ("gamemode" == null)
			{
			}
			ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D0E RID: 7438 RVA: 0x00097BA8 File Offset: 0x00095DA8
	[Token(Token = "0x6001D0E")]
	[Address(RVA = "0x2AE0B2C", Offset = "0x2AE0B2C", VA = "0x2AE0B2C")]
	public void ݟ\u05AB\u061Fد()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] parameters = new object[1];
		if ("Failed to login, please restart" != null)
		{
			if ("Failed to login, please restart" != null)
			{
				return;
			}
		}
		else
		{
			component.RPC("monke is not my monke", RpcTarget.AllViaServer, parameters);
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			if ("Player" == null)
			{
				long lastOnSerializeDataSent = 0L;
				byte group = component2.Group;
				component2.lastOnSerializeDataSent = lastOnSerializeDataSent;
				return;
			}
			if ("Player" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D0F RID: 7439 RVA: 0x00097C30 File Offset: 0x00095E30
	[Token(Token = "0x6001D0F")]
	[Address(RVA = "0x2AE0D00", Offset = "0x2AE0D00", VA = "0x2AE0D00")]
	private void \u07FE\u0882Զ\u066D()
	{
		if (this.\u05CDࠇܩܚ)
		{
			GameObject ך_u0897_u05BE_u085B = this.ך\u0897\u05BE\u085B;
			long active = 0L;
			ך_u0897_u05BE_u085B.SetActive(active != 0L);
			GameObject u074C_u0707_u0595յ = this.\u074C\u0707\u0595յ;
			long active2 = 1L;
			u074C_u0707_u0595յ.SetActive(active2 != 0L);
			GameObject gameObject = this.\u0619\u0894Ա\u05CF.gameObject;
			long active3 = 0L;
			gameObject.SetActive(active3 != 0L);
			GameObject u061Aոԕע = this.\u061Aոԕע;
			long active4 = 0L;
			u061Aոԕע.SetActive(active4 != 0L);
			GameObject u06E1۷_u070Cۇ = this.\u06E1۷\u070Cۇ;
			long active5 = 1L;
			u06E1۷_u070Cۇ.SetActive(active5 != 0L);
			GameObject gameObject2 = this.ӿӊܞܤ;
			long active6 = 0L;
			gameObject2.SetActive(active6 != 0L);
			GameObject խښ_u05A4_u = this.Խښ\u05A4\u0836;
			long active7 = 1L;
			խښ_u05A4_u.SetActive(active7 != 0L);
			GameObject u05A9ۉ_u05B3_u = this.\u05A9ۉ\u05B3\u0706;
			long active8 = 0L;
			u05A9ۉ_u05B3_u.SetActive(active8 != 0L);
			GameObject ٸڼ_u05B5Ӹ = this.ٸڼ\u05B5Ӹ;
			if (this.\u07BF\u05CD۳Ӵ)
			{
				long active9 = 0L;
				ٸڼ_u05B5Ӹ.SetActive(active9 != 0L);
				GameObject ݱԐࠆ_u065F = this.ݱԐࠆ\u065F;
				return;
			}
			long active10 = 1L;
			GameObject ݱԐࠆ_u065F2;
			ݱԐࠆ_u065F2.SetActive(active10 != 0L);
			GameObject ݱԐࠆ_u065F3 = this.ݱԐࠆ\u065F;
			long active11 = 0L;
			ݱԐࠆ_u065F3.SetActive(active11 != 0L);
			GameObject u06E3ݎԶԛ = this.\u06E3ݎԶԛ;
			long active12 = 0L;
			u06E3ݎԶԛ.SetActive(active12 != 0L);
			bool u05F3ۂ_u0899آ = this.\u05F3ۂ\u0899آ;
			long num = 1L;
			this.ࡌ\u082F߄س = (num != 0L);
			if (!u05F3ۂ_u0899آ)
			{
				IEnumerator routine = this.ۅ\u06FE\u06FD\u07FB();
				Coroutine coroutine = base.StartCoroutine(routine);
				this.\u05F3ۂ\u0899آ = (num != 0L);
			}
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				Transform u0619_u0894Ա_u05CF = this.\u0619\u0894Ա\u05CF;
				float deltaTime = Time.deltaTime;
				float x = this.\u0746Ԟࡕߩ.x;
				float y = this.\u0746Ԟࡕߩ.y;
			}
			Vector3 position = this.\u0619\u0894Ա\u05CF.position;
			float u064E_u06DFࡘվ = this.\u064E\u06DFࡘվ;
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				object[] array = new object[1];
				if (typeof(bool).TypeHandle != null && typeof(bool).TypeHandle == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			}
			AudioLowPassFilter[] array2 = this.ࡥԇࠀڷ;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		else
		{
			Transform ֆܧבӒ = this.ՖܧבӒ;
			Transform u0619_u0894Ա_u05CF2 = this.\u0619\u0894Ա\u05CF;
			Vector3 position2 = ֆܧבӒ.position;
			bool u07BF_u05CD۳Ӵ = this.\u07BF\u05CD۳Ӵ;
			int z = 49152;
			int u064E_u06DFࡘվ2 = 32768;
			this.\u0746Ԟࡕߩ.z = (float)z;
			this.\u064E\u06DFࡘվ = (float)u064E_u06DFࡘվ2;
			if (u07BF_u05CD۳Ӵ)
			{
				Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
				Transform transform = this.ڿӣԛӾ;
				Vector3 position3 = u05F8ܔԐٿ.position;
				Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
				Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
				Vector3 position4 = u05F8ܔԐٿ2.position;
				GameObject ٸڼ_u05B5Ӹ2 = this.ٸڼ\u05B5Ӹ;
				long active13 = 1L;
				long u07BF_u05CD۳Ӵ2 = 1L;
				ٸڼ_u05B5Ӹ2.SetActive(active13 != 0L);
				GameObject ݱԐࠆ_u065F2 = this.ݱԐࠆ\u065F;
				long active14 = 1L;
				ݱԐࠆ_u065F2.SetActive(active14 != 0L);
				this.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ2 != 0L);
				return;
			}
			if (this.ࡌ\u082F߄س)
			{
				Rigidbody աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
				long useGravity = 1L;
				աߞ_u07A7ߦ.useGravity = (useGravity != 0L);
				Rigidbody ցԁ_u0740օ = this.ՑԀ\u0740օ;
				long useGravity2 = 0L;
				ցԁ_u0740օ.useGravity = (useGravity2 != 0L);
				Rigidbody u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
				long useGravity3 = 1L;
				u0741_u06E2ӳࢣ.useGravity = (useGravity3 != 0L);
				this.փג\u07EBޛ();
				Swimmy ڢݕڕ_u06E = this.ڢݕڕ\u06E8;
				long enabled = 1L;
				ڢݕڕ_u06E.enabled = (enabled != 0L);
				this.բࡓ\u073FԮ();
			}
			GameObject u061Aոԕע2 = this.\u061Aոԕע;
			long active15 = 0L;
			u061Aոԕע2.SetActive(active15 != 0L);
			GameObject u06E1۷_u070Cۇ2 = this.\u06E1۷\u070Cۇ;
			long active16 = 0L;
			u06E1۷_u070Cۇ2.SetActive(active16 != 0L);
			GameObject gameObject3 = this.ӿӊܞܤ;
			long active17 = 1L;
			gameObject3.SetActive(active17 != 0L);
			GameObject ٸڼ_u05B5Ӹ3 = this.ٸڼ\u05B5Ӹ;
			long active18 = 0L;
			ٸڼ_u05B5Ӹ3.SetActive(active18 != 0L);
			long active19 = 0L;
			ٸڼ_u05B5Ӹ3.SetActive(active19 != 0L);
			this.ך\u0897\u05BE\u085B.SetActive(active19 != 0L);
			GameObject u074C_u0707_u0595յ2 = this.\u074C\u0707\u0595յ;
			long active20 = 0L;
			u074C_u0707_u0595յ2.SetActive(active20 != 0L);
			GameObject u05A9ۉ_u05B3_u2 = this.\u05A9ۉ\u05B3\u0706;
			long active21 = 0L;
			u05A9ۉ_u05B3_u2.SetActive(active21 != 0L);
			GameObject u06E3ݎԶԛ2 = this.\u06E3ݎԶԛ;
			long active22 = 1L;
			u06E3ݎԶԛ2.SetActive(active22 != 0L);
			GameObject gameObject4 = this.\u0619\u0894Ա\u05CF.gameObject;
			long active23 = 1L;
			gameObject4.SetActive(active23 != 0L);
			AudioLowPassFilter[] array3 = this.ࡥԇࠀڷ;
			return;
		}
	}

	// Token: 0x06001D10 RID: 7440 RVA: 0x00098038 File Offset: 0x00096238
	[Token(Token = "0x6001D10")]
	[Address(RVA = "0x2AE1404", Offset = "0x2AE1404", VA = "0x2AE1404")]
	public void Ӯ\u07AAڄر(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u0746Ԟࡕߩ.z = (float)17274;
			this.\u064E\u06DFࡘվ = (float)49152;
		}
		this.\u05CDࠇܩܚ = (17274 != 0);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001D11 RID: 7441 RVA: 0x000980B4 File Offset: 0x000962B4
	[Token(Token = "0x6001D11")]
	[Address(RVA = "0x2ADF538", Offset = "0x2ADF538", VA = "0x2ADF538")]
	public void ۃٹ\u059D\u0703()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[1];
		if ("Skelechin" != null)
		{
			if ("Skelechin" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[1];
			if ("CapuchinRemade" == null)
			{
				return;
			}
			if ("CapuchinRemade" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D12 RID: 7442 RVA: 0x00098128 File Offset: 0x00096328
	[Token(Token = "0x6001D12")]
	[Address(RVA = "0x2AE14E4", Offset = "0x2AE14E4", VA = "0x2AE14E4")]
	private void څӘޱ\u060C(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001D13 RID: 7443 RVA: 0x00098154 File Offset: 0x00096354
	[Token(Token = "0x6001D13")]
	[Address(RVA = "0x2AE15BC", Offset = "0x2AE15BC", VA = "0x2AE15BC")]
	private void حԜ\u06E9հ(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Skelechin");
		this.ڐۊࠔ\u0651.\u073Aڝձ\u0823();
	}

	// Token: 0x06001D14 RID: 7444 RVA: 0x00098184 File Offset: 0x00096384
	[Token(Token = "0x6001D14")]
	[Address(RVA = "0x2AE1648", Offset = "0x2AE1648", VA = "0x2AE1648")]
	public void ݿպࢢࡩ(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u0746Ԟࡕߩ.z = (float)57344;
			this.\u064E\u06DFࡘվ = (float)57344;
		}
		this.\u05CDࠇܩܚ = (57344 != 0);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001D15 RID: 7445 RVA: 0x00098200 File Offset: 0x00096400
	[Token(Token = "0x6001D15")]
	[Address(RVA = "0x2AE172C", Offset = "0x2AE172C", VA = "0x2AE172C")]
	public void ԋࢰ\u07F4\u0608(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u0746Ԟࡕߩ.z = (float)17210;
			this.\u064E\u06DFࡘվ = (float)17329;
		}
		this.\u05CDࠇܩܚ = (17210 != 0);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001D16 RID: 7446 RVA: 0x0009827C File Offset: 0x0009647C
	[Token(Token = "0x6001D16")]
	[Address(RVA = "0x2AE1808", Offset = "0x2AE1808", VA = "0x2AE1808")]
	private void Ԍ\u058Bݖۄ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001D17 RID: 7447 RVA: 0x000982A8 File Offset: 0x000964A8
	[Token(Token = "0x6001D17")]
	[Address(RVA = "0x2AE18E0", Offset = "0x2AE18E0", VA = "0x2AE18E0")]
	private void ڃրӢԖ()
	{
		if (this.\u05CDࠇܩܚ)
		{
			GameObject ך_u0897_u05BE_u085B = this.ך\u0897\u05BE\u085B;
			long active = 1L;
			ך_u0897_u05BE_u085B.SetActive(active != 0L);
			GameObject u074C_u0707_u0595յ = this.\u074C\u0707\u0595յ;
			long active2 = 1L;
			u074C_u0707_u0595յ.SetActive(active2 != 0L);
			GameObject gameObject = this.\u0619\u0894Ա\u05CF.gameObject;
			long active3 = 0L;
			gameObject.SetActive(active3 != 0L);
			GameObject u061Aոԕע = this.\u061Aոԕע;
			long active4 = 1L;
			u061Aոԕע.SetActive(active4 != 0L);
			GameObject u06E1۷_u070Cۇ = this.\u06E1۷\u070Cۇ;
			long active5 = 0L;
			u06E1۷_u070Cۇ.SetActive(active5 != 0L);
			GameObject gameObject2 = this.ӿӊܞܤ;
			long active6 = 0L;
			gameObject2.SetActive(active6 != 0L);
			GameObject խښ_u05A4_u = this.Խښ\u05A4\u0836;
			long active7 = 0L;
			խښ_u05A4_u.SetActive(active7 != 0L);
			GameObject u05A9ۉ_u05B3_u = this.\u05A9ۉ\u05B3\u0706;
			long active8 = 0L;
			u05A9ۉ_u05B3_u.SetActive(active8 != 0L);
			GameObject ٸڼ_u05B5Ӹ = this.ٸڼ\u05B5Ӹ;
			long active9 = 0L;
			ٸڼ_u05B5Ӹ.SetActive(active9 != 0L);
			GameObject ݱԐࠆ_u065F = this.ݱԐࠆ\u065F;
			long active10 = 0L;
			ݱԐࠆ_u065F.SetActive(active10 != 0L);
			GameObject u06E3ݎԶԛ = this.\u06E3ݎԶԛ;
			long active11 = 0L;
			u06E3ݎԶԛ.SetActive(active11 != 0L);
			if (!this.\u05F3ۂ\u0899آ)
			{
				IEnumerator routine = this.\u083FקՅ\u05F7();
				Coroutine coroutine = base.StartCoroutine(routine);
			}
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				Transform u0619_u0894Ա_u05CF = this.\u0619\u0894Ա\u05CF;
				float deltaTime = Time.deltaTime;
				float x = this.\u0746Ԟࡕߩ.x;
				float y = this.\u0746Ԟࡕߩ.y;
				float z = this.\u0746Ԟࡕߩ.z;
			}
			Vector3 position = this.\u0619\u0894Ա\u05CF.position;
			float u064E_u06DFࡘվ = this.\u064E\u06DFࡘվ;
			if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
			{
				object[] array = new object[0];
				if (typeof(bool).TypeHandle != null && typeof(bool).TypeHandle == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				ExitGames.Client.Photon.Hashtable customProperties = PhotonNetwork.CurrentRoom.customProperties;
			}
			AudioLowPassFilter[] array2 = this.ࡥԇࠀڷ;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		Transform ֆܧבӒ = this.ՖܧבӒ;
		Transform u0619_u0894Ա_u05CF2 = this.\u0619\u0894Ա\u05CF;
		Vector3 position2 = ֆܧבӒ.position;
		bool u07BF_u05CD۳Ӵ = this.\u07BF\u05CD۳Ӵ;
		if (u07BF_u05CD۳Ӵ)
		{
			Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
			Transform transform = this.ڿӣԛӾ;
			Vector3 position3 = u05F8ܔԐٿ.position;
			Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
			Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
			Vector3 position4 = u05F8ܔԐٿ2.position;
			GameObject ٸڼ_u05B5Ӹ2 = this.ٸڼ\u05B5Ӹ;
			long active12 = 1L;
			ٸڼ_u05B5Ӹ2.SetActive(active12 != 0L);
			GameObject ݱԐࠆ_u065F2 = this.ݱԐࠆ\u065F;
			long active13 = 0L;
			ݱԐࠆ_u065F2.SetActive(active13 != 0L);
			return;
		}
		if (this.ࡌ\u082F߄س)
		{
			Rigidbody աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			long useGravity = 0L;
			աߞ_u07A7ߦ.useGravity = (useGravity != 0L);
			Rigidbody ցԁ_u0740օ = this.ՑԀ\u0740օ;
			long useGravity2 = 0L;
			ցԁ_u0740օ.useGravity = (useGravity2 != 0L);
			Rigidbody u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			long useGravity3 = 0L;
			u0741_u06E2ӳࢣ.useGravity = (useGravity3 != 0L);
			this.ۃٹ\u059D\u0703();
			Swimmy ڢݕڕ_u06E = this.ڢݕڕ\u06E8;
			long enabled = 1L;
			ڢݕڕ_u06E.enabled = (enabled != 0L);
			this.ڑ\u0881\u0603ԋ();
		}
		GameObject u061Aոԕע2 = this.\u061Aոԕע;
		long active14 = 0L;
		u061Aոԕע2.SetActive(active14 != 0L);
		GameObject u06E1۷_u070Cۇ2 = this.\u06E1۷\u070Cۇ;
		long active15 = 1L;
		u06E1۷_u070Cۇ2.SetActive(active15 != 0L);
		GameObject gameObject3 = this.ӿӊܞܤ;
		long active16 = 0L;
		gameObject3.SetActive(active16 != 0L);
		this.ٸڼ\u05B5Ӹ.SetActive(active16 != 0L);
		GameObject ݱԐࠆ_u065F3 = this.ݱԐࠆ\u065F;
		long active17 = 1L;
		ݱԐࠆ_u065F3.SetActive(active17 != 0L);
		GameObject ך_u0897_u05BE_u085B2 = this.ך\u0897\u05BE\u085B;
		long active18 = 1L;
		ך_u0897_u05BE_u085B2.SetActive(active18 != 0L);
		GameObject u074C_u0707_u0595յ2 = this.\u074C\u0707\u0595յ;
		long active19 = 1L;
		u074C_u0707_u0595յ2.SetActive(active19 != 0L);
		GameObject u05A9ۉ_u05B3_u2 = this.\u05A9ۉ\u05B3\u0706;
		long active20 = 0L;
		u05A9ۉ_u05B3_u2.SetActive(active20 != 0L);
		GameObject u06E3ݎԶԛ2 = this.\u06E3ݎԶԛ;
		long active21 = 0L;
		u06E3ݎԶԛ2.SetActive(active21 != 0L);
		GameObject gameObject4 = this.\u0619\u0894Ա\u05CF.gameObject;
		long active22 = 0L;
		gameObject4.SetActive(active22 != 0L);
		AudioLowPassFilter[] array3 = this.ࡥԇࠀڷ;
	}

	// Token: 0x06001D18 RID: 7448 RVA: 0x00098664 File Offset: 0x00096864
	[Token(Token = "0x6001D18")]
	[Address(RVA = "0x2AE1F94", Offset = "0x2AE1F94", VA = "0x2AE1F94")]
	public LavaManager()
	{
	}

	// Token: 0x06001D19 RID: 7449 RVA: 0x00098678 File Offset: 0x00096878
	[Token(Token = "0x6001D19")]
	[Address(RVA = "0x2AD7240", Offset = "0x2AD7240", VA = "0x2AD7240")]
	public void ܣֆױݘ()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[0];
		if ("CapuchinRemade" != null)
		{
			if ("CapuchinRemade" != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[0];
			if ("\n" == null)
			{
				return;
			}
			if ("\n" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D1A RID: 7450 RVA: 0x000986F4 File Offset: 0x000968F4
	[Token(Token = "0x6001D1A")]
	[Address(RVA = "0x2ADB3F8", Offset = "0x2ADB3F8", VA = "0x2ADB3F8")]
	private void ڑ\u0881\u0603ԋ()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string u073BӵӞ_u07FD = this.\u073BӵӞ\u07FD;
		addUserVirtualCurrencyRequest.VirtualCurrency = u073BӵӞ_u07FD;
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001D1B RID: 7451 RVA: 0x00098724 File Offset: 0x00096924
	[Token(Token = "0x6001D1B")]
	[Address(RVA = "0x2AE1F9C", Offset = "0x2AE1F9C", VA = "0x2AE1F9C")]
	private void \u0601\u07B3\u0614ۃ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001D1C RID: 7452 RVA: 0x00098750 File Offset: 0x00096950
	[Token(Token = "0x6001D1C")]
	[Address(RVA = "0x2AD7B98", Offset = "0x2AD7B98", VA = "0x2AD7B98")]
	public void ࡈ\u06DC\u087E\u0834()
	{
		PhotonView component = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[0];
		if ("You are on an outdated version of Capuchin. Your version is " != null)
		{
			if ("You are on an outdated version of Capuchin. Your version is " != null)
			{
				return;
			}
		}
		else
		{
			PhotonView component2 = this.ӛ߇\u0558\u0736.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			object[] array2 = new object[0];
			if ("monke is not my monke" == null)
			{
				return;
			}
			if ("monke is not my monke" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D1D RID: 7453 RVA: 0x000987CC File Offset: 0x000969CC
	[Token(Token = "0x6001D1D")]
	[Address(RVA = "0x2AE2074", Offset = "0x2AE2074", VA = "0x2AE2074")]
	private void ܠڬԳߣ()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string u073BӵӞ_u07FD = this.\u073BӵӞ\u07FD;
		addUserVirtualCurrencyRequest.VirtualCurrency = u073BӵӞ_u07FD;
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001D1E RID: 7454 RVA: 0x000987FC File Offset: 0x000969FC
	[Token(Token = "0x6001D1E")]
	[Address(RVA = "0x2AE21EC", Offset = "0x2AE21EC", VA = "0x2AE21EC")]
	[PunRPC]
	public void gamemode(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u064E\u06DFࡘվ = (float)17036;
		}
		this.\u05CDࠇܩܚ = (17036 != 0);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001D1F RID: 7455 RVA: 0x00098868 File Offset: 0x00096A68
	[Token(Token = "0x6001D1F")]
	[Address(RVA = "0x2AE22C4", Offset = "0x2AE22C4", VA = "0x2AE22C4")]
	private void ݧ\u061Dࢡڬ()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string u073BӵӞ_u07FD = this.\u073BӵӞ\u07FD;
		addUserVirtualCurrencyRequest.VirtualCurrency = u073BӵӞ_u07FD;
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001D20 RID: 7456 RVA: 0x00098898 File Offset: 0x00096A98
	[Token(Token = "0x6001D20")]
	[Address(RVA = "0x2AE243C", Offset = "0x2AE243C", VA = "0x2AE243C")]
	private void ٷې\u08B5ٯ(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("FLSPTLT");
		this.ڐۊࠔ\u0651.ۆ\u05C8خ\u0612();
	}

	// Token: 0x06001D21 RID: 7457 RVA: 0x000988C8 File Offset: 0x00096AC8
	[Token(Token = "0x6001D21")]
	[Address(RVA = "0x2AE24C8", Offset = "0x2AE24C8", VA = "0x2AE24C8")]
	public IEnumerator ߖݩӘ\u081C()
	{
		LavaManager.ؽ\u0835ڻӡ ؽ_u0835ڻӡ;
		ؽ_u0835ڻӡ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D22 RID: 7458 RVA: 0x000988E4 File Offset: 0x00096AE4
	[Token(Token = "0x6001D22")]
	[Address(RVA = "0x2ADB380", Offset = "0x2ADB380", VA = "0x2ADB380")]
	public IEnumerator \u083FקՅ\u05F7()
	{
		long <>1__state;
		LavaManager.ؽ\u0835ڻӡ ؽ_u0835ڻӡ = new LavaManager.ؽ\u0835ڻӡ((int)<>1__state);
		<>1__state = 1L;
		ؽ_u0835ڻӡ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D23 RID: 7459 RVA: 0x00098908 File Offset: 0x00096B08
	[Token(Token = "0x6001D23")]
	[Address(RVA = "0x2AE2540", Offset = "0x2AE2540", VA = "0x2AE2540")]
	public void \u0746ڌԚԒ(bool \u081B۰\u0606\u0870)
	{
		if (this.Ҽ\u082EهԀ)
		{
			this.\u0746Ԟࡕߩ.z = (float)49152;
			this.\u064E\u06DFࡘվ = (float)17384;
		}
		this.\u05CDࠇܩܚ = (49152 != 0);
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform u05F8ܔԐٿ = this.\u05F8ܔԐٿ;
		Transform transform = this.ڿӣԛӾ;
		Vector3 position = u05F8ܔԐٿ.position;
		Transform u05F8ܔԐٿ2 = this.\u05F8ܔԐٿ;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u05F8ܔԐٿ2.position;
	}

	// Token: 0x06001D24 RID: 7460 RVA: 0x00098984 File Offset: 0x00096B84
	[Token(Token = "0x6001D24")]
	[Address(RVA = "0x2AE2620", Offset = "0x2AE2620", VA = "0x2AE2620")]
	private void ߧܡࡌܝ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001D25 RID: 7461 RVA: 0x000989B0 File Offset: 0x00096BB0
	[Token(Token = "0x6001D25")]
	[Address(RVA = "0x2AE26F8", Offset = "0x2AE26F8", VA = "0x2AE26F8")]
	private void \u0891\u0832דه(PlayFabError ہ\u0613ܢ\u07B4)
	{
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x040003C2 RID: 962
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003C2")]
	public PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x040003C3 RID: 963
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003C3")]
	public Transform \u0619\u0894Ա\u05CF;

	// Token: 0x040003C4 RID: 964
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003C4")]
	public Transform ՖܧבӒ;

	// Token: 0x040003C5 RID: 965
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003C5")]
	public Vector3 \u0746Ԟࡕߩ;

	// Token: 0x040003C6 RID: 966
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40003C6")]
	public GameObject ך\u0897\u05BE\u085B;

	// Token: 0x040003C7 RID: 967
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40003C7")]
	public GameObject \u074C\u0707\u0595յ;

	// Token: 0x040003C8 RID: 968
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40003C8")]
	public GameObject \u061Aոԕע;

	// Token: 0x040003C9 RID: 969
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40003C9")]
	public GameObject \u06E3ݎԶԛ;

	// Token: 0x040003CA RID: 970
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x40003CA")]
	public Transform ڿӣԛӾ;

	// Token: 0x040003CB RID: 971
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x40003CB")]
	public Transform \u0593ևڮ߁;

	// Token: 0x040003CC RID: 972
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x40003CC")]
	public Transform \u05F8ܔԐٿ;

	// Token: 0x040003CD RID: 973
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x40003CD")]
	public AudioLowPassFilter[] ࡥԇࠀڷ;

	// Token: 0x040003CE RID: 974
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x40003CE")]
	public AudioSource[] ݍࠄ\u058Fࠂ;

	// Token: 0x040003CF RID: 975
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x40003CF")]
	public GameObject ڬژߗݼ;

	// Token: 0x040003D0 RID: 976
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x40003D0")]
	public GameObject \u05BEࡁ\u0558غ;

	// Token: 0x040003D1 RID: 977
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x40003D1")]
	public GameObject \u06E1۷\u070Cۇ;

	// Token: 0x040003D2 RID: 978
	[FieldOffset(Offset = "0xA0")]
	[Token(Token = "0x40003D2")]
	public GameObject ӿӊܞܤ;

	// Token: 0x040003D3 RID: 979
	[FieldOffset(Offset = "0xA8")]
	[Token(Token = "0x40003D3")]
	public bool \u05CDࠇܩܚ;

	// Token: 0x040003D4 RID: 980
	[FieldOffset(Offset = "0xA9")]
	[Token(Token = "0x40003D4")]
	public bool \u07BF\u05CD۳Ӵ;

	// Token: 0x040003D5 RID: 981
	[FieldOffset(Offset = "0xAA")]
	[Token(Token = "0x40003D5")]
	private bool \u05F3ۂ\u0899آ;

	// Token: 0x040003D6 RID: 982
	[FieldOffset(Offset = "0xAB")]
	[Token(Token = "0x40003D6")]
	private bool ࡌ\u082F߄س;

	// Token: 0x040003D7 RID: 983
	[FieldOffset(Offset = "0xB0")]
	[Token(Token = "0x40003D7")]
	public LoginManager ڐۊࠔ\u0651;

	// Token: 0x040003D8 RID: 984
	[FieldOffset(Offset = "0xB8")]
	[Token(Token = "0x40003D8")]
	public GameObject ٸڼ\u05B5Ӹ;

	// Token: 0x040003D9 RID: 985
	[FieldOffset(Offset = "0xC0")]
	[Token(Token = "0x40003D9")]
	public GameObject ݱԐࠆ\u065F;

	// Token: 0x040003DA RID: 986
	[FieldOffset(Offset = "0xC8")]
	[Token(Token = "0x40003DA")]
	public GameObject \u05A9ۉ\u05B3\u0706;

	// Token: 0x040003DB RID: 987
	[FieldOffset(Offset = "0xD0")]
	[Token(Token = "0x40003DB")]
	public AudioSource ځԫڊן;

	// Token: 0x040003DC RID: 988
	[FieldOffset(Offset = "0xD8")]
	[Token(Token = "0x40003DC")]
	public Rigidbody աߞ\u07A7ߦ;

	// Token: 0x040003DD RID: 989
	[FieldOffset(Offset = "0xE0")]
	[Token(Token = "0x40003DD")]
	public Rigidbody ՑԀ\u0740օ;

	// Token: 0x040003DE RID: 990
	[FieldOffset(Offset = "0xE8")]
	[Token(Token = "0x40003DE")]
	public Rigidbody \u0741\u06E2ӳࢣ;

	// Token: 0x040003DF RID: 991
	[FieldOffset(Offset = "0xF0")]
	[Token(Token = "0x40003DF")]
	public Swimmy ڢݕڕ\u06E8;

	// Token: 0x040003E0 RID: 992
	[FieldOffset(Offset = "0xF8")]
	[Token(Token = "0x40003E0")]
	public float \u064E\u06DFࡘվ;

	// Token: 0x040003E1 RID: 993
	[FieldOffset(Offset = "0xFC")]
	[Token(Token = "0x40003E1")]
	public bool Ҽ\u082EهԀ;

	// Token: 0x040003E2 RID: 994
	[FieldOffset(Offset = "0x100")]
	[Token(Token = "0x40003E2")]
	public GameObject Խښ\u05A4\u0836;

	// Token: 0x040003E3 RID: 995
	[FieldOffset(Offset = "0x108")]
	[Token(Token = "0x40003E3")]
	public NetworkPlayerSpawner ӛ߇\u0558\u0736;

	// Token: 0x040003E4 RID: 996
	[FieldOffset(Offset = "0x110")]
	[Token(Token = "0x40003E4")]
	public string \u073BӵӞ\u07FD;
}
