﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000CD RID: 205
[Token(Token = "0x20000CD")]
public class NetworkHitsounds : MonoBehaviour
{
	// Token: 0x06001F4D RID: 8013 RVA: 0x000A2DDC File Offset: 0x000A0FDC
	[Token(Token = "0x6001F4D")]
	[Address(RVA = "0x23C2B50", Offset = "0x23C2B50", VA = "0x23C2B50")]
	private void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F4E RID: 8014 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001F4E")]
	[Address(RVA = "0x23C2DA4", Offset = "0x23C2DA4", VA = "0x23C2DA4")]
	private void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001F4F RID: 8015 RVA: 0x000A2EE4 File Offset: 0x000A10E4
	[Token(Token = "0x6001F4F")]
	[Address(RVA = "0x23C2FF8", Offset = "0x23C2FF8", VA = "0x23C2FF8")]
	private void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
		if (this.٩\u05AD\u081C\u0821 == null)
		{
			return;
		}
		AudioSource u0617_u087Fտߎ2 = this.\u0617\u087Fտߎ;
		AudioClip[] array;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = array.m_PCMReaderCallback;
	}

	// Token: 0x06001F50 RID: 8016 RVA: 0x000A2FE4 File Offset: 0x000A11E4
	[Token(Token = "0x6001F50")]
	[Address(RVA = "0x23C324C", Offset = "0x23C324C", VA = "0x23C324C")]
	private void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F51 RID: 8017 RVA: 0x000A30E8 File Offset: 0x000A12E8
	[Token(Token = "0x6001F51")]
	[Address(RVA = "0x23C34A0", Offset = "0x23C34A0", VA = "0x23C34A0")]
	private void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if ("IsLowSurrogates" == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F52 RID: 8018 RVA: 0x000A31F0 File Offset: 0x000A13F0
	[Token(Token = "0x6001F52")]
	[Address(RVA = "0x23C36F4", Offset = "0x23C36F4", VA = "0x23C36F4")]
	private void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F53 RID: 8019 RVA: 0x000A32F8 File Offset: 0x000A14F8
	[Token(Token = "0x6001F53")]
	[Address(RVA = "0x23C3948", Offset = "0x23C3948", VA = "0x23C3948")]
	private void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F54 RID: 8020 RVA: 0x000A3400 File Offset: 0x000A1600
	[Token(Token = "0x6001F54")]
	[Address(RVA = "0x23C3B9C", Offset = "0x23C3B9C", VA = "0x23C3B9C")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F55 RID: 8021 RVA: 0x000A34F8 File Offset: 0x000A16F8
	[Token(Token = "0x6001F55")]
	[Address(RVA = "0x23C3DE4", Offset = "0x23C3DE4", VA = "0x23C3DE4")]
	private void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		long maxExclusive = 0L;
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		int num = UnityEngine.Random.Range(0, (int)maxExclusive);
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F56 RID: 8022 RVA: 0x000A35FC File Offset: 0x000A17FC
	[Token(Token = "0x6001F56")]
	[Address(RVA = "0x23C4038", Offset = "0x23C4038", VA = "0x23C4038")]
	private void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F57 RID: 8023 RVA: 0x000A3704 File Offset: 0x000A1904
	[Token(Token = "0x6001F57")]
	[Address(RVA = "0x23C428C", Offset = "0x23C428C", VA = "0x23C428C")]
	private void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F58 RID: 8024 RVA: 0x000A380C File Offset: 0x000A1A0C
	[Token(Token = "0x6001F58")]
	[Address(RVA = "0x23C44E0", Offset = "0x23C44E0", VA = "0x23C44E0")]
	private void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F59 RID: 8025 RVA: 0x000A3914 File Offset: 0x000A1B14
	[Token(Token = "0x6001F59")]
	[Address(RVA = "0x23C4734", Offset = "0x23C4734", VA = "0x23C4734")]
	private void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F5A RID: 8026 RVA: 0x000A3A1C File Offset: 0x000A1C1C
	[Token(Token = "0x6001F5A")]
	[Address(RVA = "0x23C4988", Offset = "0x23C4988", VA = "0x23C4988")]
	private void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F5B RID: 8027 RVA: 0x000A3B20 File Offset: 0x000A1D20
	[Token(Token = "0x6001F5B")]
	[Address(RVA = "0x23C4BDC", Offset = "0x23C4BDC", VA = "0x23C4BDC")]
	private void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F5C RID: 8028 RVA: 0x000A3C28 File Offset: 0x000A1E28
	[Token(Token = "0x6001F5C")]
	[Address(RVA = "0x23C4E30", Offset = "0x23C4E30", VA = "0x23C4E30")]
	private void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F5D RID: 8029 RVA: 0x000A3D30 File Offset: 0x000A1F30
	[Token(Token = "0x6001F5D")]
	[Address(RVA = "0x23C5084", Offset = "0x23C5084", VA = "0x23C5084")]
	private void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F5E RID: 8030 RVA: 0x000A3E38 File Offset: 0x000A2038
	[Token(Token = "0x6001F5E")]
	[Address(RVA = "0x23C52D8", Offset = "0x23C52D8", VA = "0x23C52D8")]
	private void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F5F RID: 8031 RVA: 0x000A3F40 File Offset: 0x000A2140
	[Token(Token = "0x6001F5F")]
	[Address(RVA = "0x23C552C", Offset = "0x23C552C", VA = "0x23C552C")]
	private void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F60 RID: 8032 RVA: 0x000A4044 File Offset: 0x000A2244
	[Token(Token = "0x6001F60")]
	[Address(RVA = "0x23C5780", Offset = "0x23C5780", VA = "0x23C5780")]
	private void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F61 RID: 8033 RVA: 0x000A414C File Offset: 0x000A234C
	[Token(Token = "0x6001F61")]
	[Address(RVA = "0x23C59D4", Offset = "0x23C59D4", VA = "0x23C59D4")]
	private void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F62 RID: 8034 RVA: 0x000A4254 File Offset: 0x000A2454
	[Token(Token = "0x6001F62")]
	[Address(RVA = "0x23C5C28", Offset = "0x23C5C28", VA = "0x23C5C28")]
	private void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F63 RID: 8035 RVA: 0x000A435C File Offset: 0x000A255C
	[Token(Token = "0x6001F63")]
	[Address(RVA = "0x23C5E7C", Offset = "0x23C5E7C", VA = "0x23C5E7C")]
	private void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F64 RID: 8036 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001F64")]
	[Address(RVA = "0x23C60D0", Offset = "0x23C60D0", VA = "0x23C60D0")]
	private void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001F65 RID: 8037 RVA: 0x000A4464 File Offset: 0x000A2664
	[Token(Token = "0x6001F65")]
	[Address(RVA = "0x23C6324", Offset = "0x23C6324", VA = "0x23C6324")]
	private void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F66 RID: 8038 RVA: 0x000A456C File Offset: 0x000A276C
	[Token(Token = "0x6001F66")]
	[Address(RVA = "0x23C6578", Offset = "0x23C6578", VA = "0x23C6578")]
	private void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F67 RID: 8039 RVA: 0x000A4674 File Offset: 0x000A2874
	[Token(Token = "0x6001F67")]
	[Address(RVA = "0x23C67CC", Offset = "0x23C67CC", VA = "0x23C67CC")]
	private void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F68 RID: 8040 RVA: 0x000A477C File Offset: 0x000A297C
	[Token(Token = "0x6001F68")]
	[Address(RVA = "0x23C6A20", Offset = "0x23C6A20", VA = "0x23C6A20")]
	private void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F69 RID: 8041 RVA: 0x000A4884 File Offset: 0x000A2A84
	[Token(Token = "0x6001F69")]
	[Address(RVA = "0x23C6C74", Offset = "0x23C6C74", VA = "0x23C6C74")]
	private void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F6A RID: 8042 RVA: 0x000A498C File Offset: 0x000A2B8C
	[Token(Token = "0x6001F6A")]
	[Address(RVA = "0x23C6EC8", Offset = "0x23C6EC8", VA = "0x23C6EC8")]
	private void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F6B RID: 8043 RVA: 0x000A4A94 File Offset: 0x000A2C94
	[Token(Token = "0x6001F6B")]
	[Address(RVA = "0x23C711C", Offset = "0x23C711C", VA = "0x23C711C")]
	private void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F6C RID: 8044 RVA: 0x000A4B94 File Offset: 0x000A2D94
	[Token(Token = "0x6001F6C")]
	[Address(RVA = "0x23C7370", Offset = "0x23C7370", VA = "0x23C7370")]
	private void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F6D RID: 8045 RVA: 0x000A4C9C File Offset: 0x000A2E9C
	[Token(Token = "0x6001F6D")]
	[Address(RVA = "0x23C75C4", Offset = "0x23C75C4", VA = "0x23C75C4")]
	private void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F6E RID: 8046 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001F6E")]
	[Address(RVA = "0x23C7818", Offset = "0x23C7818", VA = "0x23C7818")]
	private void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001F6F RID: 8047 RVA: 0x000A4D98 File Offset: 0x000A2F98
	[Token(Token = "0x6001F6F")]
	[Address(RVA = "0x23C7A6C", Offset = "0x23C7A6C", VA = "0x23C7A6C")]
	private void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F70 RID: 8048 RVA: 0x000A4EA0 File Offset: 0x000A30A0
	[Token(Token = "0x6001F70")]
	[Address(RVA = "0x23C7CC0", Offset = "0x23C7CC0", VA = "0x23C7CC0")]
	private void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F71 RID: 8049 RVA: 0x000A4FA4 File Offset: 0x000A31A4
	[Token(Token = "0x6001F71")]
	[Address(RVA = "0x23C7F14", Offset = "0x23C7F14", VA = "0x23C7F14")]
	private void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F72 RID: 8050 RVA: 0x000A50AC File Offset: 0x000A32AC
	[Token(Token = "0x6001F72")]
	[Address(RVA = "0x23C8168", Offset = "0x23C8168", VA = "0x23C8168")]
	public NetworkHitsounds()
	{
		long u07EEݩڏࠉ = 1L;
		this.\u07EEݩڏࠉ = (u07EEݩڏࠉ != 0L);
		base..ctor();
	}

	// Token: 0x06001F73 RID: 8051 RVA: 0x000A50C8 File Offset: 0x000A32C8
	[Token(Token = "0x6001F73")]
	[Address(RVA = "0x23C8178", Offset = "0x23C8178", VA = "0x23C8178")]
	private void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F74 RID: 8052 RVA: 0x000A51D0 File Offset: 0x000A33D0
	[Token(Token = "0x6001F74")]
	[Address(RVA = "0x23C83CC", Offset = "0x23C83CC", VA = "0x23C83CC")]
	private void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F75 RID: 8053 RVA: 0x000A52CC File Offset: 0x000A34CC
	[Token(Token = "0x6001F75")]
	[Address(RVA = "0x23C8620", Offset = "0x23C8620", VA = "0x23C8620")]
	private void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F76 RID: 8054 RVA: 0x000A53D4 File Offset: 0x000A35D4
	[Token(Token = "0x6001F76")]
	[Address(RVA = "0x23C8874", Offset = "0x23C8874", VA = "0x23C8874")]
	private void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F77 RID: 8055 RVA: 0x000A54DC File Offset: 0x000A36DC
	[Token(Token = "0x6001F77")]
	[Address(RVA = "0x23C8AC8", Offset = "0x23C8AC8", VA = "0x23C8AC8")]
	private void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		long maxExclusive = 0L;
		int num = UnityEngine.Random.Range(0, (int)maxExclusive);
	}

	// Token: 0x06001F78 RID: 8056 RVA: 0x000A554C File Offset: 0x000A374C
	[Token(Token = "0x6001F78")]
	[Address(RVA = "0x23C8D1C", Offset = "0x23C8D1C", VA = "0x23C8D1C")]
	private void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F79 RID: 8057 RVA: 0x000A5654 File Offset: 0x000A3854
	[Token(Token = "0x6001F79")]
	[Address(RVA = "0x23C8F70", Offset = "0x23C8F70", VA = "0x23C8F70")]
	private void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F7A RID: 8058 RVA: 0x000A575C File Offset: 0x000A395C
	[Token(Token = "0x6001F7A")]
	[Address(RVA = "0x23C91C4", Offset = "0x23C91C4", VA = "0x23C91C4")]
	private void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F7B RID: 8059 RVA: 0x000A5864 File Offset: 0x000A3A64
	[Token(Token = "0x6001F7B")]
	[Address(RVA = "0x23C9418", Offset = "0x23C9418", VA = "0x23C9418")]
	private void ܘݱ\u083CԲ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip.PCMReaderCallback pcmreaderCallback = this.٩\u05AD\u081C\u0821.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F7C RID: 8060 RVA: 0x000A595C File Offset: 0x000A3B5C
	[Token(Token = "0x6001F7C")]
	[Address(RVA = "0x23C966C", Offset = "0x23C966C", VA = "0x23C966C")]
	private void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F7D RID: 8061 RVA: 0x000A5A64 File Offset: 0x000A3C64
	[Token(Token = "0x6001F7D")]
	[Address(RVA = "0x23C98C0", Offset = "0x23C98C0", VA = "0x23C98C0")]
	private void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x06001F7E RID: 8062 RVA: 0x000A5B6C File Offset: 0x000A3D6C
	[Token(Token = "0x6001F7E")]
	[Address(RVA = "0x23C9B14", Offset = "0x23C9B14", VA = "0x23C9B14")]
	private void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		Surface component = \u07FEל\u05AC\u0877.gameObject.GetComponent<Surface>();
		this.Ւӄߛӓ = component;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = ٩_u05AD_u081C_u.m_PCMReaderCallback.m_target;
		this.\u0617\u087Fտߎ.Play();
	}

	// Token: 0x04000409 RID: 1033
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000409")]
	public AudioClip[] ݭܬࡓݒ;

	// Token: 0x0400040A RID: 1034
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400040A")]
	public AudioClip[] ٩\u05AD\u081C\u0821;

	// Token: 0x0400040B RID: 1035
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400040B")]
	public AudioClip[] Ժ\u05CD\u0882\u05AF;

	// Token: 0x0400040C RID: 1036
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400040C")]
	public AudioClip[] \u059B\u070B\u07BFߌ;

	// Token: 0x0400040D RID: 1037
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400040D")]
	public AudioSource \u0617\u087Fտߎ;

	// Token: 0x0400040E RID: 1038
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400040E")]
	public AudioClip[] \u0891ԽޓԾ;

	// Token: 0x0400040F RID: 1039
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400040F")]
	public AudioClip[] \u05B5\u07B8ܞٳ;

	// Token: 0x04000410 RID: 1040
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000410")]
	public AudioClip[] ދӫӏݛ;

	// Token: 0x04000411 RID: 1041
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000411")]
	public AudioClip[] \u05FCއܖԽ;

	// Token: 0x04000412 RID: 1042
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000412")]
	public AudioClip[] ߢ\u0603\u085A\u05B0;

	// Token: 0x04000413 RID: 1043
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000413")]
	public AudioClip[] \u058Aࡊ\u06EDܕ;

	// Token: 0x04000414 RID: 1044
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000414")]
	private bool \u07EEݩڏࠉ;

	// Token: 0x04000415 RID: 1045
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000415")]
	private Surface Ւӄߛӓ;
}
