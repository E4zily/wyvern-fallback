﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200005B RID: 91
[Token(Token = "0x200005B")]
public class DrillMovement : MonoBehaviour
{
	// Token: 0x06000CF5 RID: 3317 RVA: 0x000447F8 File Offset: 0x000429F8
	[Token(Token = "0x6000CF5")]
	[Address(RVA = "0x2FC4F74", Offset = "0x2FC4F74", VA = "0x2FC4F74")]
	private void \u07FE\u0882Զ\u066D()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)32768;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000CF6 RID: 3318 RVA: 0x00044998 File Offset: 0x00042B98
	[Token(Token = "0x6000CF6")]
	[Address(RVA = "0x2FC517C", Offset = "0x2FC517C", VA = "0x2FC517C")]
	private void ߁\u0829\u073E\u081A()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000CF7 RID: 3319 RVA: 0x000449B8 File Offset: 0x00042BB8
	[Token(Token = "0x6000CF7")]
	[Address(RVA = "0x2FC51B4", Offset = "0x2FC51B4", VA = "0x2FC51B4")]
	private void ӻӒݝ߃()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17527;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000CF8 RID: 3320 RVA: 0x00044B58 File Offset: 0x00042D58
	[Token(Token = "0x6000CF8")]
	[Address(RVA = "0x2FC53B8", Offset = "0x2FC53B8", VA = "0x2FC53B8")]
	private void \u07F7ܙײ\u05B5()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Transform ԁ_u0884_u070Fࢯ = this.ԁ\u0884\u070Fࢯ;
		Vector3 position2 = transform.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)8192;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000CF9 RID: 3321 RVA: 0x00044CFC File Offset: 0x00042EFC
	[Token(Token = "0x6000CF9")]
	[Address(RVA = "0x2FC55C0", Offset = "0x2FC55C0", VA = "0x2FC55C0")]
	private void \u065F\u0839ܤ\u073C()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000CFA RID: 3322 RVA: 0x00044D1C File Offset: 0x00042F1C
	[Token(Token = "0x6000CFA")]
	[Address(RVA = "0x2FC55F8", Offset = "0x2FC55F8", VA = "0x2FC55F8")]
	private void Start()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000CFB RID: 3323 RVA: 0x00044D3C File Offset: 0x00042F3C
	[Token(Token = "0x6000CFB")]
	[Address(RVA = "0x2FC5630", Offset = "0x2FC5630", VA = "0x2FC5630")]
	private void \u0614ࢥӴ\u086C()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)49152;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000CFC RID: 3324 RVA: 0x00044ECC File Offset: 0x000430CC
	[Token(Token = "0x6000CFC")]
	[Address(RVA = "0x2FC5838", Offset = "0x2FC5838", VA = "0x2FC5838")]
	private void ٠ӄ\u087Cٸ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)49152;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000CFD RID: 3325 RVA: 0x00045064 File Offset: 0x00043264
	[Token(Token = "0x6000CFD")]
	[Address(RVA = "0x2FC5A40", Offset = "0x2FC5A40", VA = "0x2FC5A40")]
	private void ո\u07AA\u05BDࠕ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)32768;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000CFE RID: 3326 RVA: 0x00045204 File Offset: 0x00043404
	[Token(Token = "0x6000CFE")]
	[Address(RVA = "0x2FC5C48", Offset = "0x2FC5C48", VA = "0x2FC5C48")]
	private void \u05A5Ԇࠇޏ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000CFF RID: 3327 RVA: 0x00045224 File Offset: 0x00043424
	[Token(Token = "0x6000CFF")]
	[Address(RVA = "0x2FC5C80", Offset = "0x2FC5C80", VA = "0x2FC5C80")]
	private void \u081FڰՂإ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D00 RID: 3328 RVA: 0x00045244 File Offset: 0x00043444
	[Token(Token = "0x6000D00")]
	[Address(RVA = "0x2FC5CB8", Offset = "0x2FC5CB8", VA = "0x2FC5CB8")]
	private void \u0739߉ڵݞ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D01 RID: 3329 RVA: 0x00045264 File Offset: 0x00043464
	[Token(Token = "0x6000D01")]
	[Address(RVA = "0x2FC5CF0", Offset = "0x2FC5CF0", VA = "0x2FC5CF0")]
	private void ӧ\u0608\u086Cճ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D02 RID: 3330 RVA: 0x00045284 File Offset: 0x00043484
	[Token(Token = "0x6000D02")]
	[Address(RVA = "0x2FC5D28", Offset = "0x2FC5D28", VA = "0x2FC5D28")]
	private void \u070Aәޣے()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17244;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D03 RID: 3331 RVA: 0x00045424 File Offset: 0x00043624
	[Token(Token = "0x6000D03")]
	[Address(RVA = "0x2FC5F2C", Offset = "0x2FC5F2C", VA = "0x2FC5F2C")]
	private void \u07B6կպ߃()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Vector3 position = base.transform.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17218;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D04 RID: 3332 RVA: 0x000455BC File Offset: 0x000437BC
	[Token(Token = "0x6000D04")]
	[Address(RVA = "0x2FC6130", Offset = "0x2FC6130", VA = "0x2FC6130")]
	private void \u0892ܒܬޓ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)57344;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D05 RID: 3333 RVA: 0x00045758 File Offset: 0x00043958
	[Token(Token = "0x6000D05")]
	[Address(RVA = "0x2FC6338", Offset = "0x2FC6338", VA = "0x2FC6338")]
	private void ہݕ\u07EFԒ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)8192;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D06 RID: 3334 RVA: 0x000458F8 File Offset: 0x00043AF8
	[Token(Token = "0x6000D06")]
	[Address(RVA = "0x2FC6540", Offset = "0x2FC6540", VA = "0x2FC6540")]
	private void ԙضփӌ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17474;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D07 RID: 3335 RVA: 0x00045A90 File Offset: 0x00043C90
	[Token(Token = "0x6000D07")]
	[Address(RVA = "0x2FC6744", Offset = "0x2FC6744", VA = "0x2FC6744")]
	private void \u0881ݗӟ\u07BD()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)16384;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D08 RID: 3336 RVA: 0x00045C2C File Offset: 0x00043E2C
	[Token(Token = "0x6000D08")]
	[Address(RVA = "0x2FC694C", Offset = "0x2FC694C", VA = "0x2FC694C")]
	private void ӭࡖݲ\u05BD()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D09 RID: 3337 RVA: 0x00045C4C File Offset: 0x00043E4C
	[Token(Token = "0x6000D09")]
	[Address(RVA = "0x2FC6984", Offset = "0x2FC6984", VA = "0x2FC6984")]
	private void \u0599ږࠆ\u065F()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)32768;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D0A RID: 3338 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Token(Token = "0x6000D0A")]
	[Address(RVA = "0x2FC6B8C", Offset = "0x2FC6B8C", VA = "0x2FC6B8C")]
	private void ߄Ӄ\u0613ھ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D0B RID: 3339 RVA: 0x00045E04 File Offset: 0x00044004
	[Token(Token = "0x6000D0B")]
	[Address(RVA = "0x2FC6BC4", Offset = "0x2FC6BC4", VA = "0x2FC6BC4")]
	private void Update()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z2 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z3 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D0C RID: 3340 RVA: 0x00045F8C File Offset: 0x0004418C
	[Token(Token = "0x6000D0C")]
	[Address(RVA = "0x2FC6DC0", Offset = "0x2FC6DC0", VA = "0x2FC6DC0")]
	private void ފՖߢ\u059B()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)40960;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D0D RID: 3341 RVA: 0x0004612C File Offset: 0x0004432C
	[Token(Token = "0x6000D0D")]
	[Address(RVA = "0x2FC6FC8", Offset = "0x2FC6FC8", VA = "0x2FC6FC8")]
	private void \u07B2\u0823ծݠ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17046;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D0E RID: 3342 RVA: 0x000462CC File Offset: 0x000444CC
	[Token(Token = "0x6000D0E")]
	[Address(RVA = "0x2FC71CC", Offset = "0x2FC71CC", VA = "0x2FC71CC")]
	private void \u05AC\u07F0\u07EEࡥ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x = this.ވߩչߨ.x;
		float y = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x2 = this.۱ނ\u06E6ވ.x;
		float x3 = this.\u0708ܗ\u082D\u07F1.x;
		float y2 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y3 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)49152;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D0F RID: 3343 RVA: 0x00046450 File Offset: 0x00044650
	[Token(Token = "0x6000D0F")]
	[Address(RVA = "0x2FC73D4", Offset = "0x2FC73D4", VA = "0x2FC73D4")]
	private void ߓ\u06E3\u05C7ۋ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D10 RID: 3344 RVA: 0x00046470 File Offset: 0x00044670
	[Token(Token = "0x6000D10")]
	[Address(RVA = "0x2FC740C", Offset = "0x2FC740C", VA = "0x2FC740C")]
	private void \u066A\u059Eټ\u085A()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D11 RID: 3345 RVA: 0x00046490 File Offset: 0x00044690
	[Token(Token = "0x6000D11")]
	[Address(RVA = "0x2FC7444", Offset = "0x2FC7444", VA = "0x2FC7444")]
	private void ࢥ\u081CՕࡋ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D12 RID: 3346 RVA: 0x000464B0 File Offset: 0x000446B0
	[Token(Token = "0x6000D12")]
	[Address(RVA = "0x2FC747C", Offset = "0x2FC747C", VA = "0x2FC747C")]
	private void Ջއٵյ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D13 RID: 3347 RVA: 0x000464D0 File Offset: 0x000446D0
	[Token(Token = "0x6000D13")]
	[Address(RVA = "0x2FC74B4", Offset = "0x2FC74B4", VA = "0x2FC74B4")]
	private void طӏܙࢺ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17199;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D14 RID: 3348 RVA: 0x00046670 File Offset: 0x00044870
	[Token(Token = "0x6000D14")]
	[Address(RVA = "0x2FC76B8", Offset = "0x2FC76B8", VA = "0x2FC76B8")]
	private void וࡪךӧ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D15 RID: 3349 RVA: 0x00046690 File Offset: 0x00044890
	[Token(Token = "0x6000D15")]
	[Address(RVA = "0x2FC76F0", Offset = "0x2FC76F0", VA = "0x2FC76F0")]
	private void \u06EDٵ۶\u06DB()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D16 RID: 3350 RVA: 0x000466B0 File Offset: 0x000448B0
	[Token(Token = "0x6000D16")]
	[Address(RVA = "0x2FC7728", Offset = "0x2FC7728", VA = "0x2FC7728")]
	private void ۮߝڪڐ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D17 RID: 3351 RVA: 0x000466D0 File Offset: 0x000448D0
	[Token(Token = "0x6000D17")]
	[Address(RVA = "0x2FC7760", Offset = "0x2FC7760", VA = "0x2FC7760")]
	private void \u06D4ڟڎޜ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)16904;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D18 RID: 3352 RVA: 0x00046870 File Offset: 0x00044A70
	[Token(Token = "0x6000D18")]
	[Address(RVA = "0x2FC7964", Offset = "0x2FC7964", VA = "0x2FC7964")]
	private void ڷԲ\u0618ރ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)57344;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D19 RID: 3353 RVA: 0x00046A08 File Offset: 0x00044C08
	[Token(Token = "0x6000D19")]
	[Address(RVA = "0x2FC7B6C", Offset = "0x2FC7B6C", VA = "0x2FC7B6C")]
	private void ࡅݐ\u082Dք()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D1A RID: 3354 RVA: 0x00046A28 File Offset: 0x00044C28
	[Token(Token = "0x6000D1A")]
	[Address(RVA = "0x2FC7BA4", Offset = "0x2FC7BA4", VA = "0x2FC7BA4")]
	private void ۲ڂ\u05B1ڨ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D1B RID: 3355 RVA: 0x00046A48 File Offset: 0x00044C48
	[Token(Token = "0x6000D1B")]
	[Address(RVA = "0x2FC7BDC", Offset = "0x2FC7BDC", VA = "0x2FC7BDC")]
	private void \u05FEօ\u06D7ࡁ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D1C RID: 3356 RVA: 0x00046A68 File Offset: 0x00044C68
	[Token(Token = "0x6000D1C")]
	[Address(RVA = "0x2FC7C14", Offset = "0x2FC7C14", VA = "0x2FC7C14")]
	private void \u087BӦןݩ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17473;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D1D RID: 3357 RVA: 0x00046C00 File Offset: 0x00044E00
	[Token(Token = "0x6000D1D")]
	[Address(RVA = "0x2FC7E18", Offset = "0x2FC7E18", VA = "0x2FC7E18")]
	private void ד\u073C\u0613چ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)24576;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D1E RID: 3358 RVA: 0x00046DA0 File Offset: 0x00044FA0
	[Token(Token = "0x6000D1E")]
	[Address(RVA = "0x2FC8020", Offset = "0x2FC8020", VA = "0x2FC8020")]
	private void פۈيݤ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)49152;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D1F RID: 3359 RVA: 0x00046F40 File Offset: 0x00045140
	[Token(Token = "0x6000D1F")]
	[Address(RVA = "0x2FC8228", Offset = "0x2FC8228", VA = "0x2FC8228")]
	private void \u07EBࠎיࡂ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D20 RID: 3360 RVA: 0x00046F60 File Offset: 0x00045160
	[Token(Token = "0x6000D20")]
	[Address(RVA = "0x2FC8260", Offset = "0x2FC8260", VA = "0x2FC8260")]
	private void ߑ\u0885\u05BBߕ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		Transform transform;
		Vector3 position = transform.position;
		Vector3 position2 = transform.position;
		float deltaTime4 = Time.deltaTime;
		float num = Mathf.Clamp01(deltaTime4);
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000D21 RID: 3361 RVA: 0x00046FE8 File Offset: 0x000451E8
	[Token(Token = "0x6000D21")]
	[Address(RVA = "0x2FC8468", Offset = "0x2FC8468", VA = "0x2FC8468")]
	private void نո\u0599\u0589()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D22 RID: 3362 RVA: 0x00047008 File Offset: 0x00045208
	[Token(Token = "0x6000D22")]
	[Address(RVA = "0x2FC84A0", Offset = "0x2FC84A0", VA = "0x2FC84A0")]
	private void ޙߍ\u081A\u0651()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D23 RID: 3363 RVA: 0x00047028 File Offset: 0x00045228
	[Token(Token = "0x6000D23")]
	[Address(RVA = "0x2FC84D8", Offset = "0x2FC84D8", VA = "0x2FC84D8")]
	private void ݡز٨հ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D24 RID: 3364 RVA: 0x00047048 File Offset: 0x00045248
	[Token(Token = "0x6000D24")]
	[Address(RVA = "0x2FC8510", Offset = "0x2FC8510", VA = "0x2FC8510")]
	private void \u05ABࡡ\u07ABݾ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)49152;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D25 RID: 3365 RVA: 0x000471E8 File Offset: 0x000453E8
	[Token(Token = "0x6000D25")]
	[Address(RVA = "0x2FC8718", Offset = "0x2FC8718", VA = "0x2FC8718")]
	private void ݤۅࢦӃ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D26 RID: 3366 RVA: 0x00047208 File Offset: 0x00045408
	[Token(Token = "0x6000D26")]
	[Address(RVA = "0x2FC8750", Offset = "0x2FC8750", VA = "0x2FC8750")]
	private void ۿࢹ\u0705\u0825()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D27 RID: 3367 RVA: 0x00047228 File Offset: 0x00045428
	[Token(Token = "0x6000D27")]
	[Address(RVA = "0x2FC8788", Offset = "0x2FC8788", VA = "0x2FC8788")]
	private void ڑߒجވ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Vector3 position = base.transform.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)8192;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D28 RID: 3368 RVA: 0x000473C0 File Offset: 0x000455C0
	[Token(Token = "0x6000D28")]
	[Address(RVA = "0x2FC8990", Offset = "0x2FC8990", VA = "0x2FC8990")]
	private void \u0652\u058Bک\u061C()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D29 RID: 3369 RVA: 0x000473E0 File Offset: 0x000455E0
	[Token(Token = "0x6000D29")]
	[Address(RVA = "0x2FC89C8", Offset = "0x2FC89C8", VA = "0x2FC89C8")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)24576;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D2A RID: 3370 RVA: 0x0004757C File Offset: 0x0004577C
	[Token(Token = "0x6000D2A")]
	[Address(RVA = "0x2FC8BD0", Offset = "0x2FC8BD0", VA = "0x2FC8BD0")]
	private void ߗࠊ\u05CAܝ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D2B RID: 3371 RVA: 0x0004759C File Offset: 0x0004579C
	[Token(Token = "0x6000D2B")]
	[Address(RVA = "0x2FC8C08", Offset = "0x2FC8C08", VA = "0x2FC8C08")]
	private void ١ۏ\u05C4ӝ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D2C RID: 3372 RVA: 0x000475BC File Offset: 0x000457BC
	[Token(Token = "0x6000D2C")]
	[Address(RVA = "0x2FC8C40", Offset = "0x2FC8C40", VA = "0x2FC8C40")]
	private void ࡎ\u05C2սࠇ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D2D RID: 3373 RVA: 0x000475DC File Offset: 0x000457DC
	[Token(Token = "0x6000D2D")]
	[Address(RVA = "0x2FC8C78", Offset = "0x2FC8C78", VA = "0x2FC8C78")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)32768;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000D2E RID: 3374 RVA: 0x00047774 File Offset: 0x00045974
	[Token(Token = "0x6000D2E")]
	[Address(RVA = "0x2FC8E80", Offset = "0x2FC8E80", VA = "0x2FC8E80")]
	private void \u066D\u05BDې߃()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D2F RID: 3375 RVA: 0x00047794 File Offset: 0x00045994
	[Token(Token = "0x6000D2F")]
	[Address(RVA = "0x2FC8EB8", Offset = "0x2FC8EB8", VA = "0x2FC8EB8")]
	private void ޡࠅ\u089Aߔ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D30 RID: 3376 RVA: 0x000477B4 File Offset: 0x000459B4
	[Token(Token = "0x6000D30")]
	[Address(RVA = "0x2FC8EF0", Offset = "0x2FC8EF0", VA = "0x2FC8EF0")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D31 RID: 3377 RVA: 0x000477D4 File Offset: 0x000459D4
	[Token(Token = "0x6000D31")]
	[Address(RVA = "0x2FC8F28", Offset = "0x2FC8F28", VA = "0x2FC8F28")]
	private void Ҽ\u08B5ځ\u0658()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)16384;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D32 RID: 3378 RVA: 0x00047968 File Offset: 0x00045B68
	[Token(Token = "0x6000D32")]
	[Address(RVA = "0x2FC9130", Offset = "0x2FC9130", VA = "0x2FC9130")]
	private void ى߁ٱՏ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)49152;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D33 RID: 3379 RVA: 0x00047B08 File Offset: 0x00045D08
	[Token(Token = "0x6000D33")]
	[Address(RVA = "0x2FC9338", Offset = "0x2FC9338", VA = "0x2FC9338")]
	private void \u07A8Ӥթݠ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D34 RID: 3380 RVA: 0x00047B28 File Offset: 0x00045D28
	[Token(Token = "0x6000D34")]
	[Address(RVA = "0x2FC9370", Offset = "0x2FC9370", VA = "0x2FC9370")]
	private void \u0882צ\u0821\u05B4()
	{
	}

	// Token: 0x06000D35 RID: 3381 RVA: 0x00047B3C File Offset: 0x00045D3C
	[Token(Token = "0x6000D35")]
	[Address(RVA = "0x2FC93A8", Offset = "0x2FC93A8", VA = "0x2FC93A8")]
	private void יԠ\u07EDԺ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = ࡌ_u0608ࡔ_u05B.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)8192;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D36 RID: 3382 RVA: 0x00047CD0 File Offset: 0x00045ED0
	[Token(Token = "0x6000D36")]
	[Address(RVA = "0x2FC95B0", Offset = "0x2FC95B0", VA = "0x2FC95B0")]
	private void \u0705\u0816\u0739դ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)32768;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D37 RID: 3383 RVA: 0x00047E68 File Offset: 0x00046068
	[Token(Token = "0x6000D37")]
	[Address(RVA = "0x2FC97B8", Offset = "0x2FC97B8", VA = "0x2FC97B8")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)49152;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D38 RID: 3384 RVA: 0x00048008 File Offset: 0x00046208
	[Token(Token = "0x6000D38")]
	[Address(RVA = "0x2FC99C0", Offset = "0x2FC99C0", VA = "0x2FC99C0")]
	private void \u059AՏ\u0600\u0872()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D39 RID: 3385 RVA: 0x00048028 File Offset: 0x00046228
	[Token(Token = "0x6000D39")]
	[Address(RVA = "0x2FC99F8", Offset = "0x2FC99F8", VA = "0x2FC99F8")]
	private void ןٮ\u061FԺ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D3A RID: 3386 RVA: 0x00048048 File Offset: 0x00046248
	[Token(Token = "0x6000D3A")]
	[Address(RVA = "0x2FC9A30", Offset = "0x2FC9A30", VA = "0x2FC9A30")]
	private void \u061B\u05EEوۈ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17293;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D3B RID: 3387 RVA: 0x000481E8 File Offset: 0x000463E8
	[Token(Token = "0x6000D3B")]
	[Address(RVA = "0x2FC9C34", Offset = "0x2FC9C34", VA = "0x2FC9C34")]
	private void \u05F8ݑ\u06ECߞ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)8192;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D3C RID: 3388 RVA: 0x00048388 File Offset: 0x00046588
	[Token(Token = "0x6000D3C")]
	[Address(RVA = "0x2FC9E3C", Offset = "0x2FC9E3C", VA = "0x2FC9E3C")]
	private void \u05F7ԝߠӱ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17394;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D3D RID: 3389 RVA: 0x00048528 File Offset: 0x00046728
	[Token(Token = "0x6000D3D")]
	[Address(RVA = "0x2FCA040", Offset = "0x2FCA040", VA = "0x2FCA040")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)32768;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D3E RID: 3390 RVA: 0x000486C8 File Offset: 0x000468C8
	[Token(Token = "0x6000D3E")]
	[Address(RVA = "0x2FCA248", Offset = "0x2FCA248", VA = "0x2FCA248")]
	private void ӷӛࠔ\u07AC()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D3F RID: 3391 RVA: 0x000486E8 File Offset: 0x000468E8
	[Token(Token = "0x6000D3F")]
	[Address(RVA = "0x2FCA280", Offset = "0x2FCA280", VA = "0x2FCA280")]
	private void ژךՈ\u0597()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)16384;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D40 RID: 3392 RVA: 0x00048888 File Offset: 0x00046A88
	[Token(Token = "0x6000D40")]
	[Address(RVA = "0x2FCA488", Offset = "0x2FCA488", VA = "0x2FCA488")]
	private void \u0590\u0882\u0883ࡦ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.ݶՈהՇ = (float)16576;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D41 RID: 3393 RVA: 0x00048A28 File Offset: 0x00046C28
	[Token(Token = "0x6000D41")]
	[Address(RVA = "0x2FCA688", Offset = "0x2FCA688", VA = "0x2FCA688")]
	private void \u0827ߜ\u07FD\u07F4()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17016;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D42 RID: 3394 RVA: 0x00048BC8 File Offset: 0x00046DC8
	[Token(Token = "0x6000D42")]
	[Address(RVA = "0x2FCA88C", Offset = "0x2FCA88C", VA = "0x2FCA88C")]
	private void \u082E\u06EBݼڏ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D43 RID: 3395 RVA: 0x00048BE8 File Offset: 0x00046DE8
	[Token(Token = "0x6000D43")]
	[Address(RVA = "0x2FCA8C4", Offset = "0x2FCA8C4", VA = "0x2FCA8C4")]
	public DrillMovement()
	{
	}

	// Token: 0x06000D44 RID: 3396 RVA: 0x00048BFC File Offset: 0x00046DFC
	[Token(Token = "0x6000D44")]
	[Address(RVA = "0x2FCA8CC", Offset = "0x2FCA8CC", VA = "0x2FCA8CC")]
	private void ࡕߕ\u0707ݩ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17545;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D45 RID: 3397 RVA: 0x00048D9C File Offset: 0x00046F9C
	[Token(Token = "0x6000D45")]
	[Address(RVA = "0x2FCAAD0", Offset = "0x2FCAAD0", VA = "0x2FCAAD0")]
	private void ࢳ\u088E٠ݪ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D46 RID: 3398 RVA: 0x00048DBC File Offset: 0x00046FBC
	[Token(Token = "0x6000D46")]
	[Address(RVA = "0x2FCAB08", Offset = "0x2FCAB08", VA = "0x2FCAB08")]
	private void \u0818ՠש\u0731()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D47 RID: 3399 RVA: 0x00048DDC File Offset: 0x00046FDC
	[Token(Token = "0x6000D47")]
	[Address(RVA = "0x2FCAB40", Offset = "0x2FCAB40", VA = "0x2FCAB40")]
	private void \u0656ӺմՁ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D48 RID: 3400 RVA: 0x00048DFC File Offset: 0x00046FFC
	[Token(Token = "0x6000D48")]
	[Address(RVA = "0x2FCAB78", Offset = "0x2FCAB78", VA = "0x2FCAB78")]
	private void ߠ\u07AAߚթ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D49 RID: 3401 RVA: 0x00048E1C File Offset: 0x0004701C
	[Token(Token = "0x6000D49")]
	[Address(RVA = "0x2FCABB0", Offset = "0x2FCABB0", VA = "0x2FCABB0")]
	private void \u05C8\u05BFࠁف()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D4A RID: 3402 RVA: 0x00048E3C File Offset: 0x0004703C
	[Token(Token = "0x6000D4A")]
	[Address(RVA = "0x2FCABE8", Offset = "0x2FCABE8", VA = "0x2FCABE8")]
	private void ދ\u05A3\u06DCہ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D4B RID: 3403 RVA: 0x00048E5C File Offset: 0x0004705C
	[Token(Token = "0x6000D4B")]
	[Address(RVA = "0x2FCAC20", Offset = "0x2FCAC20", VA = "0x2FCAC20")]
	private void \u0825ӆا\u07BE()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D4C RID: 3404 RVA: 0x00048E7C File Offset: 0x0004707C
	[Token(Token = "0x6000D4C")]
	[Address(RVA = "0x2FCAC58", Offset = "0x2FCAC58", VA = "0x2FCAC58")]
	private void ڃրӢԖ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17474;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D4D RID: 3405 RVA: 0x0004901C File Offset: 0x0004721C
	[Token(Token = "0x6000D4D")]
	[Address(RVA = "0x2FCAE5C", Offset = "0x2FCAE5C", VA = "0x2FCAE5C")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)49152;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D4E RID: 3406 RVA: 0x000491BC File Offset: 0x000473BC
	[Token(Token = "0x6000D4E")]
	[Address(RVA = "0x2FCB064", Offset = "0x2FCB064", VA = "0x2FCB064")]
	private void \u05EDց\u081Cت()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)32768;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D4F RID: 3407 RVA: 0x0004935C File Offset: 0x0004755C
	[Token(Token = "0x6000D4F")]
	[Address(RVA = "0x2FCB26C", Offset = "0x2FCB26C", VA = "0x2FCB26C")]
	private void ԣԭՋࠏ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)16384;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D50 RID: 3408 RVA: 0x000494FC File Offset: 0x000476FC
	[Token(Token = "0x6000D50")]
	[Address(RVA = "0x2FCB474", Offset = "0x2FCB474", VA = "0x2FCB474")]
	private void \u07F5\u0657\u055Aߍ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		Transform ࡌ_u0608ࡔ_u05B = this.ࡌ\u0608ࡔ\u05B0;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		float deltaTime3 = Time.deltaTime;
		float x = this.ز\u0595\u0593\u05A0.x;
		float y = this.ز\u0595\u0593\u05A0.y;
		float z = this.ز\u0595\u0593\u05A0.z;
		Transform transform = base.transform;
		Vector3 position = this.ޛٮܫ\u083D.position;
		float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		Vector3 position2 = this.ԁ\u0884\u070Fࢯ.position;
		float x3 = this.۱ނ\u06E6ވ.x;
		float x4 = this.\u0708ܗ\u082D\u07F1.x;
		float y3 = this.\u0708ܗ\u082D\u07F1.y;
		float z3 = this.\u0708ܗ\u082D\u07F1.z;
		float y4 = this.۱ނ\u06E6ވ.y;
		float z4 = this.۱ނ\u06E6ވ.z;
		float deltaTime4 = Time.deltaTime;
		float ԇ߃տࡇ = this.Ԇ߃տࡇ;
		float num = Mathf.Clamp01(deltaTime4);
		float num2 = this.ݶՈהՇ;
		float բߐ_u0591_u = this.բߐ\u0591\u0656;
		float u0602_u05C4ޜԭ2 = this.\u0602\u05C4ޜԭ;
		float ࡘ_u0659א_u06DE = this.ࡘ\u0659א\u06DE;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ2;
		this.ݶՈהՇ = (float)17283;
		float deltaTime5 = Time.deltaTime;
		this.ݶՈהՇ = u0602_u05C4ޜԭ2;
	}

	// Token: 0x06000D51 RID: 3409 RVA: 0x00049698 File Offset: 0x00047898
	[Token(Token = "0x6000D51")]
	[Address(RVA = "0x2FCB678", Offset = "0x2FCB678", VA = "0x2FCB678")]
	private void \u05F5ߪތӝ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D52 RID: 3410 RVA: 0x000496B8 File Offset: 0x000478B8
	[Token(Token = "0x6000D52")]
	[Address(RVA = "0x2FCB6B0", Offset = "0x2FCB6B0", VA = "0x2FCB6B0")]
	private void הԥ\u05B5ݴ()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x06000D53 RID: 3411 RVA: 0x000496D8 File Offset: 0x000478D8
	[Token(Token = "0x6000D53")]
	[Address(RVA = "0x2FCB6E8", Offset = "0x2FCB6E8", VA = "0x2FCB6E8")]
	private void ۊո\u0612\u0595()
	{
		Vector3 position = this.ԁ\u0884\u070Fࢯ.position;
	}

	// Token: 0x040001D5 RID: 469
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001D5")]
	public float ࢥ\u0824Ҽ\u05FB;

	// Token: 0x040001D6 RID: 470
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40001D6")]
	public float ش\u085C\u0823փ;

	// Token: 0x040001D7 RID: 471
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001D7")]
	public float \u0602\u05C4ޜԭ;

	// Token: 0x040001D8 RID: 472
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001D8")]
	public Transform ޛٮܫ\u083D;

	// Token: 0x040001D9 RID: 473
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40001D9")]
	public Transform ࡌ\u0608ࡔ\u05B0;

	// Token: 0x040001DA RID: 474
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40001DA")]
	public Transform ԁ\u0884\u070Fࢯ;

	// Token: 0x040001DB RID: 475
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40001DB")]
	public Vector3 ز\u0595\u0593\u05A0;

	// Token: 0x040001DC RID: 476
	[FieldOffset(Offset = "0x4C")]
	[Token(Token = "0x40001DC")]
	public Vector3 ވߩչߨ;

	// Token: 0x040001DD RID: 477
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40001DD")]
	public Vector3 ۱ނ\u06E6ވ;

	// Token: 0x040001DE RID: 478
	[FieldOffset(Offset = "0x64")]
	[Token(Token = "0x40001DE")]
	public float Ԇ߃տࡇ;

	// Token: 0x040001DF RID: 479
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x40001DF")]
	private float ےӃڈ\u07B3;

	// Token: 0x040001E0 RID: 480
	[FieldOffset(Offset = "0x6C")]
	[Token(Token = "0x40001E0")]
	public float բߐ\u0591\u0656;

	// Token: 0x040001E1 RID: 481
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x40001E1")]
	public float ࡘ\u0659א\u06DE;

	// Token: 0x040001E2 RID: 482
	[FieldOffset(Offset = "0x74")]
	[Token(Token = "0x40001E2")]
	public bool \u0616ߧإࡘ;

	// Token: 0x040001E3 RID: 483
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x40001E3")]
	public float \u0883ڦࡠۇ;

	// Token: 0x040001E4 RID: 484
	[FieldOffset(Offset = "0x7C")]
	[Token(Token = "0x40001E4")]
	private float ݶՈהՇ;

	// Token: 0x040001E5 RID: 485
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x40001E5")]
	private Vector3 \u0708ܗ\u082D\u07F1;
}
