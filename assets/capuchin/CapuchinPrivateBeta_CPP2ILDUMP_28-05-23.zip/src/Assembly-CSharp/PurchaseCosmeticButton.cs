﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

// Token: 0x02000058 RID: 88
[Token(Token = "0x2000058")]
public class PurchaseCosmeticButton : MonoBehaviourPunCallbacks
{
	// Token: 0x06000C61 RID: 3169 RVA: 0x000414E0 File Offset: 0x0003F6E0
	[Token(Token = "0x6000C61")]
	[Address(RVA = "0x2C4A460", Offset = "0x2C4A460", VA = "0x2C4A460")]
	private void ݱ\u0832ݥ\u08B5()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C62 RID: 3170 RVA: 0x00041518 File Offset: 0x0003F718
	[Token(Token = "0x6000C62")]
	[Address(RVA = "0x2C4A5F4", Offset = "0x2C4A5F4", VA = "0x2C4A5F4")]
	private void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ى\u0875\u0876ڝ(this);
	}

	// Token: 0x06000C63 RID: 3171 RVA: 0x00041560 File Offset: 0x0003F760
	[Token(Token = "0x6000C63")]
	[Address(RVA = "0x2C4A764", Offset = "0x2C4A764", VA = "0x2C4A764")]
	private void ࠏڐ\u088Bօ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u0828\u0530م\u0653(this);
	}

	// Token: 0x06000C64 RID: 3172 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C64")]
	[Address(RVA = "0x2C4A8D4", Offset = "0x2C4A8D4", VA = "0x2C4A8D4")]
	private void \u05AC\u07F0\u07EEࡥ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C65 RID: 3173 RVA: 0x000415A8 File Offset: 0x0003F7A8
	[Token(Token = "0x6000C65")]
	[Address(RVA = "0x2C4AA84", Offset = "0x2C4AA84", VA = "0x2C4AA84")]
	private void ӷӛࠔ\u07AC()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C66 RID: 3174 RVA: 0x000415E0 File Offset: 0x0003F7E0
	[Token(Token = "0x6000C66")]
	[Address(RVA = "0x2C4AC18", Offset = "0x2C4AC18", VA = "0x2C4AC18")]
	private void \u07FF\u05BCޥڡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
	}

	// Token: 0x06000C67 RID: 3175 RVA: 0x00041618 File Offset: 0x0003F818
	[Token(Token = "0x6000C67")]
	[Address(RVA = "0x2C4AD88", Offset = "0x2C4AD88", VA = "0x2C4AD88")]
	private void \u081FڰՂإ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C68 RID: 3176 RVA: 0x00041650 File Offset: 0x0003F850
	[Token(Token = "0x6000C68")]
	[Address(RVA = "0x2C4AF1C", Offset = "0x2C4AF1C", VA = "0x2C4AF1C")]
	private void ޝԖ\u0836\u06D8()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C69 RID: 3177 RVA: 0x00041688 File Offset: 0x0003F888
	[Token(Token = "0x6000C69")]
	[Address(RVA = "0x2C4B0B0", Offset = "0x2C4B0B0", VA = "0x2C4B0B0")]
	private void \u055E\u0703\u0700ܠ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C6A RID: 3178 RVA: 0x000416C0 File Offset: 0x0003F8C0
	[Token(Token = "0x6000C6A")]
	[Address(RVA = "0x2C4B244", Offset = "0x2C4B244", VA = "0x2C4B244")]
	private void ݶߔ\u081Aպ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C6B RID: 3179 RVA: 0x000416F8 File Offset: 0x0003F8F8
	[Token(Token = "0x6000C6B")]
	[Address(RVA = "0x2C4B3D8", Offset = "0x2C4B3D8", VA = "0x2C4B3D8")]
	private void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u066Bࢳֈԫ(this);
	}

	// Token: 0x06000C6C RID: 3180 RVA: 0x00041740 File Offset: 0x0003F940
	[Token(Token = "0x6000C6C")]
	[Address(RVA = "0x2C4B548", Offset = "0x2C4B548", VA = "0x2C4B548")]
	private void ߁\u0829\u073E\u081A()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C6D RID: 3181 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C6D")]
	[Address(RVA = "0x2C4B6DC", Offset = "0x2C4B6DC", VA = "0x2C4B6DC")]
	private void ܫ\u070Fۃ\u07F2()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C6E RID: 3182 RVA: 0x00041778 File Offset: 0x0003F978
	[Token(Token = "0x6000C6E")]
	[Address(RVA = "0x2C4B8C0", Offset = "0x2C4B8C0", VA = "0x2C4B8C0")]
	private void ࠌࢡࠕ۷()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C6F RID: 3183 RVA: 0x000417B0 File Offset: 0x0003F9B0
	[Token(Token = "0x6000C6F")]
	[Address(RVA = "0x2C4BA54", Offset = "0x2C4BA54", VA = "0x2C4BA54")]
	private void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ن\u0741ݐߊ(this);
	}

	// Token: 0x06000C70 RID: 3184 RVA: 0x000417F8 File Offset: 0x0003F9F8
	[Token(Token = "0x6000C70")]
	[Address(RVA = "0x2C4BBC4", Offset = "0x2C4BBC4", VA = "0x2C4BBC4")]
	private void ۳ܧ\u074Bץ()
	{
		if (this.\u0593գࢡӼ && !this.\u05B9\u0617\u07EE\u07ED)
		{
			TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
			DynamicCosmetics.ލ\u0882ײࢲ.٢ӲߠӐ(this);
			return;
		}
		long u05B9_u0617_u07EE_u07ED = 1L;
		ThrowHelper.ThrowArgumentOutOfRangeException();
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		bool flag = " stream.Available: " == ظݓ_u0897_u05B;
		if (!this.\u05B9\u0617\u07EE\u07ED)
		{
			TMP_Text u05A8ޖޔ_u2 = this.\u05A8ޖޔ\u0891;
			this.\u05B9\u0617\u07EE\u07ED = (u05B9_u0617_u07EE_u07ED != 0L);
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000C71 RID: 3185 RVA: 0x00041870 File Offset: 0x0003FA70
	[Token(Token = "0x6000C71")]
	[Address(RVA = "0x2C4BDA8", Offset = "0x2C4BDA8", VA = "0x2C4BDA8")]
	private void \u082E\u06EBݼڏ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C72 RID: 3186 RVA: 0x000418A8 File Offset: 0x0003FAA8
	[Token(Token = "0x6000C72")]
	[Address(RVA = "0x2C4BF3C", Offset = "0x2C4BF3C", VA = "0x2C4BF3C")]
	public PurchaseCosmeticButton()
	{
	}

	// Token: 0x06000C73 RID: 3187 RVA: 0x000418BC File Offset: 0x0003FABC
	[Token(Token = "0x6000C73")]
	[Address(RVA = "0x2C4BF44", Offset = "0x2C4BF44", VA = "0x2C4BF44")]
	private void \u066A\u059Eټ\u085A()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C74 RID: 3188 RVA: 0x000418F4 File Offset: 0x0003FAF4
	[Token(Token = "0x6000C74")]
	[Address(RVA = "0x2C4C0D8", Offset = "0x2C4C0D8", VA = "0x2C4C0D8")]
	private void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (typeof(UnityEngine.Object).TypeHandle != null)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u0732ߩګ\u0818(this);
	}

	// Token: 0x06000C75 RID: 3189 RVA: 0x0004193C File Offset: 0x0003FB3C
	[Token(Token = "0x6000C75")]
	[Address(RVA = "0x2C4C248", Offset = "0x2C4C248", VA = "0x2C4C248")]
	private void ݡز٨հ()
	{
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		bool flag = "TurnAmount" == ظݓ_u0897_u05B;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C76 RID: 3190 RVA: 0x00041974 File Offset: 0x0003FB74
	[Token(Token = "0x6000C76")]
	[Address(RVA = "0x2C4C3DC", Offset = "0x2C4C3DC", VA = "0x2C4C3DC")]
	private void Գӿېչ()
	{
		DynamicCosmetics ލ_u0882ײࢲ = DynamicCosmetics.ލ\u0882ײࢲ;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		bool flag = "Add/Remove Glasses" == ظݓ_u0897_u05B;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C77 RID: 3191 RVA: 0x000419B4 File Offset: 0x0003FBB4
	[Token(Token = "0x6000C77")]
	[Address(RVA = "0x2C4C570", Offset = "0x2C4C570", VA = "0x2C4C570")]
	private void եݚۆ\u0890(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C78 RID: 3192 RVA: 0x000419F0 File Offset: 0x0003FBF0
	[Token(Token = "0x6000C78")]
	[Address(RVA = "0x2C4C6E0", Offset = "0x2C4C6E0", VA = "0x2C4C6E0")]
	private void Ԍڏ\u0879թ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u0732ߩګ\u0818(this);
	}

	// Token: 0x06000C79 RID: 3193 RVA: 0x00041A38 File Offset: 0x0003FC38
	[Token(Token = "0x6000C79")]
	[Address(RVA = "0x2C4C850", Offset = "0x2C4C850", VA = "0x2C4C850")]
	private void ԦӔԁֆ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C7A RID: 3194 RVA: 0x00041A70 File Offset: 0x0003FC70
	[Token(Token = "0x6000C7A")]
	[Address(RVA = "0x2C4C9E4", Offset = "0x2C4C9E4", VA = "0x2C4C9E4")]
	private void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ن\u0741ݐߊ(this);
	}

	// Token: 0x06000C7B RID: 3195 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C7B")]
	[Address(RVA = "0x2C4CB54", Offset = "0x2C4CB54", VA = "0x2C4CB54")]
	private void \u0886Ҽ\u058Dߛ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C7C RID: 3196 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C7C")]
	[Address(RVA = "0x2C4CD04", Offset = "0x2C4CD04", VA = "0x2C4CD04")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C7D RID: 3197 RVA: 0x00041AB8 File Offset: 0x0003FCB8
	[Token(Token = "0x6000C7D")]
	[Address(RVA = "0x2C4CEB4", Offset = "0x2C4CEB4", VA = "0x2C4CEB4")]
	private void \u07B4\u0594ԁڇ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ى\u0875\u0876ڝ(this);
	}

	// Token: 0x06000C7E RID: 3198 RVA: 0x00041B08 File Offset: 0x0003FD08
	[Token(Token = "0x6000C7E")]
	[Address(RVA = "0x2C4D024", Offset = "0x2C4D024", VA = "0x2C4D024")]
	private void ߒ\u065EՎࡖ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C7F RID: 3199 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C7F")]
	[Address(RVA = "0x2C4D1B8", Offset = "0x2C4D1B8", VA = "0x2C4D1B8")]
	private void \u0654ޛ\u07FAذ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C80 RID: 3200 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C80")]
	[Address(RVA = "0x2C4D368", Offset = "0x2C4D368", VA = "0x2C4D368")]
	private void ד\u073C\u0613چ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C81 RID: 3201 RVA: 0x00041B40 File Offset: 0x0003FD40
	[Token(Token = "0x6000C81")]
	[Address(RVA = "0x2C4D550", Offset = "0x2C4D550", VA = "0x2C4D550")]
	private void \u05FEօ\u06D7ࡁ()
	{
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		bool flag = "Photon token acquired!" == ظݓ_u0897_u05B;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C82 RID: 3202 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C82")]
	[Address(RVA = "0x2C4D6E4", Offset = "0x2C4D6E4", VA = "0x2C4D6E4")]
	private void طӏܙࢺ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C83 RID: 3203 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C83")]
	[Address(RVA = "0x2C4D8C0", Offset = "0x2C4D8C0", VA = "0x2C4D8C0")]
	private void \u0836\u089Dی\u0735()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C84 RID: 3204 RVA: 0x00041B78 File Offset: 0x0003FD78
	[Token(Token = "0x6000C84")]
	[Address(RVA = "0x2C4DA98", Offset = "0x2C4DA98", VA = "0x2C4DA98")]
	private void ࡅݐ\u082Dք()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C85 RID: 3205 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C85")]
	[Address(RVA = "0x2C4DC2C", Offset = "0x2C4DC2C", VA = "0x2C4DC2C")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C86 RID: 3206 RVA: 0x00041BB0 File Offset: 0x0003FDB0
	[Token(Token = "0x6000C86")]
	[Address(RVA = "0x2C4DE14", Offset = "0x2C4DE14", VA = "0x2C4DE14")]
	private void \u05ABݿࡋ\u06E9()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C87 RID: 3207 RVA: 0x00041BE8 File Offset: 0x0003FDE8
	[Token(Token = "0x6000C87")]
	[Address(RVA = "0x2C4DFA8", Offset = "0x2C4DFA8", VA = "0x2C4DFA8")]
	private void ןٮ\u061FԺ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C88 RID: 3208 RVA: 0x00041C20 File Offset: 0x0003FE20
	[Token(Token = "0x6000C88")]
	[Address(RVA = "0x2C4E13C", Offset = "0x2C4E13C", VA = "0x2C4E13C")]
	private void \u059B\u081F\u05FEڂ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u08B5\u061Fݫو(this);
	}

	// Token: 0x06000C89 RID: 3209 RVA: 0x00041C68 File Offset: 0x0003FE68
	[Token(Token = "0x6000C89")]
	[Address(RVA = "0x2C4E2AC", Offset = "0x2C4E2AC", VA = "0x2C4E2AC")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u0732ߩګ\u0818(this);
	}

	// Token: 0x06000C8A RID: 3210 RVA: 0x00041CAC File Offset: 0x0003FEAC
	[Token(Token = "0x6000C8A")]
	[Address(RVA = "0x2C4E408", Offset = "0x2C4E408", VA = "0x2C4E408")]
	private void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics ލ_u0882ײࢲ = DynamicCosmetics.ލ\u0882ײࢲ;
	}

	// Token: 0x06000C8B RID: 3211 RVA: 0x00041CF0 File Offset: 0x0003FEF0
	[Token(Token = "0x6000C8B")]
	[Address(RVA = "0x2C4E578", Offset = "0x2C4E578", VA = "0x2C4E578")]
	private void Փ\u06DF\u0839ԟ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ن\u0741ݐߊ(this);
	}

	// Token: 0x06000C8C RID: 3212 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C8C")]
	[Address(RVA = "0x2C4E6E8", Offset = "0x2C4E6E8", VA = "0x2C4E6E8")]
	private void \u0892ܒܬޓ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C8D RID: 3213 RVA: 0x00041D34 File Offset: 0x0003FF34
	[Token(Token = "0x6000C8D")]
	[Address(RVA = "0x2C4E898", Offset = "0x2C4E898", VA = "0x2C4E898")]
	private void Ջއٵյ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C8E RID: 3214 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C8E")]
	[Address(RVA = "0x2C4EA2C", Offset = "0x2C4EA2C", VA = "0x2C4EA2C")]
	private void \u0870\u05B3Ց\u066A()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C8F RID: 3215 RVA: 0x00041D6C File Offset: 0x0003FF6C
	[Token(Token = "0x6000C8F")]
	[Address(RVA = "0x2C4EBD8", Offset = "0x2C4EBD8", VA = "0x2C4EBD8")]
	private void \u061B\u05EEوۈ()
	{
		if (this.\u0593գࢡӼ)
		{
			bool u05B9_u0617_u07EE_u07ED = this.\u05B9\u0617\u07EE\u07ED;
			long u0593գࢡӼ = 1L;
			this.\u0593գࢡӼ = (u0593գࢡӼ != 0L);
			if (!u05B9_u0617_u07EE_u07ED)
			{
				TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
				DynamicCosmetics.ލ\u0882ײࢲ.\u066Bࢳֈԫ(this);
				return;
			}
		}
		long u05B9_u0617_u07EE_u07ED2 = 1L;
		ThrowHelper.ThrowArgumentOutOfRangeException();
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		bool flag = " stream.Available: " == ظݓ_u0897_u05B;
		if (!this.\u05B9\u0617\u07EE\u07ED)
		{
			TMP_Text u05A8ޖޔ_u2 = this.\u05A8ޖޔ\u0891;
			this.\u05B9\u0617\u07EE\u07ED = (u05B9_u0617_u07EE_u07ED2 != 0L);
		}
		while (" stream.Available: " != null)
		{
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000C90 RID: 3216 RVA: 0x00041DF8 File Offset: 0x0003FFF8
	[Token(Token = "0x6000C90")]
	[Address(RVA = "0x2C4EDC0", Offset = "0x2C4EDC0", VA = "0x2C4EDC0")]
	private void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u0828\u0530م\u0653(this);
	}

	// Token: 0x06000C91 RID: 3217 RVA: 0x00041E40 File Offset: 0x00040040
	[Token(Token = "0x6000C91")]
	[Address(RVA = "0x2C4EF30", Offset = "0x2C4EF30", VA = "0x2C4EF30")]
	private void ػԚԃڻ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.٢ӲߠӐ(this);
	}

	// Token: 0x06000C92 RID: 3218 RVA: 0x00041E88 File Offset: 0x00040088
	[Token(Token = "0x6000C92")]
	[Address(RVA = "0x2C4F0A0", Offset = "0x2C4F0A0", VA = "0x2C4F0A0")]
	private void ߉ې\u07F6Ӭ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C93 RID: 3219 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C93")]
	[Address(RVA = "0x2C4F234", Offset = "0x2C4F234", VA = "0x2C4F234")]
	private void Ҽ\u08B5ځ\u0658()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C94 RID: 3220 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C94")]
	[Address(RVA = "0x2C4F41C", Offset = "0x2C4F41C", VA = "0x2C4F41C")]
	private void ݫࢷࠃ\u0820()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C95 RID: 3221 RVA: 0x00041EC0 File Offset: 0x000400C0
	[Token(Token = "0x6000C95")]
	[Address(RVA = "0x2C4F5CC", Offset = "0x2C4F5CC", VA = "0x2C4F5CC")]
	private void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ࠉ\u0559ӭ\u0886(this);
	}

	// Token: 0x06000C96 RID: 3222 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C96")]
	[Address(RVA = "0x2C4F73C", Offset = "0x2C4F73C", VA = "0x2C4F73C")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C97 RID: 3223 RVA: 0x00041F08 File Offset: 0x00040108
	[Token(Token = "0x6000C97")]
	[Address(RVA = "0x2C4F8F0", Offset = "0x2C4F8F0", VA = "0x2C4F8F0")]
	private void \u05AB\u05BEӞނ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		DynamicCosmetics.ލ\u0882ײࢲ.٢ӲߠӐ(this);
	}

	// Token: 0x06000C98 RID: 3224 RVA: 0x00041F48 File Offset: 0x00040148
	[Token(Token = "0x6000C98")]
	[Address(RVA = "0x2C4FA60", Offset = "0x2C4FA60", VA = "0x2C4FA60")]
	private void \u05F5ߪތӝ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C99 RID: 3225 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C99")]
	[Address(RVA = "0x2C4FBF4", Offset = "0x2C4FBF4", VA = "0x2C4FBF4")]
	private void ڃրӢԖ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C9A RID: 3226 RVA: 0x00041F80 File Offset: 0x00040180
	[Token(Token = "0x6000C9A")]
	[Address(RVA = "0x2C4FDA8", Offset = "0x2C4FDA8", VA = "0x2C4FDA8")]
	private void Start()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C9B RID: 3227 RVA: 0x00041FB8 File Offset: 0x000401B8
	[Token(Token = "0x6000C9B")]
	[Address(RVA = "0x2C4FF3C", Offset = "0x2C4FF3C", VA = "0x2C4FF3C")]
	private void \u0881\u0743\u07EB\u0747()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C9C RID: 3228 RVA: 0x00041FF0 File Offset: 0x000401F0
	[Token(Token = "0x6000C9C")]
	[Address(RVA = "0x2C500D0", Offset = "0x2C500D0", VA = "0x2C500D0")]
	private void \u0733ߜܣԻ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C9D RID: 3229 RVA: 0x00042028 File Offset: 0x00040228
	[Token(Token = "0x6000C9D")]
	[Address(RVA = "0x2C50264", Offset = "0x2C50264", VA = "0x2C50264")]
	private void ۿࢹ\u0705\u0825()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C9E RID: 3230 RVA: 0x00042060 File Offset: 0x00040260
	[Token(Token = "0x6000C9E")]
	[Address(RVA = "0x2C503F8", Offset = "0x2C503F8", VA = "0x2C503F8")]
	private void וࡪךӧ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C9F RID: 3231 RVA: 0x00042098 File Offset: 0x00040298
	[Token(Token = "0x6000C9F")]
	[Address(RVA = "0x2C5058C", Offset = "0x2C5058C", VA = "0x2C5058C")]
	private void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u0828\u0530م\u0653(this);
	}

	// Token: 0x06000CA0 RID: 3232 RVA: 0x000420E0 File Offset: 0x000402E0
	[Token(Token = "0x6000CA0")]
	[Address(RVA = "0x2C506FC", Offset = "0x2C506FC", VA = "0x2C506FC")]
	private void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u08B5\u061Fݫو(this);
	}

	// Token: 0x06000CA1 RID: 3233 RVA: 0x00042120 File Offset: 0x00040320
	[Token(Token = "0x6000CA1")]
	[Address(RVA = "0x2C5086C", Offset = "0x2C5086C", VA = "0x2C5086C")]
	private void ޛװہװ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u066Bࢳֈԫ(this);
	}

	// Token: 0x06000CA2 RID: 3234 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CA2")]
	[Address(RVA = "0x2C509DC", Offset = "0x2C509DC", VA = "0x2C509DC")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CA3 RID: 3235 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CA3")]
	[Address(RVA = "0x2C50B8C", Offset = "0x2C50B8C", VA = "0x2C50B8C")]
	private void ࢴ\u087A\u07B9ࢢ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CA4 RID: 3236 RVA: 0x00042168 File Offset: 0x00040368
	[Token(Token = "0x6000CA4")]
	[Address(RVA = "0x2C50D40", Offset = "0x2C50D40", VA = "0x2C50D40")]
	private void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ن\u0741ݐߊ(this);
	}

	// Token: 0x06000CA5 RID: 3237 RVA: 0x000421B0 File Offset: 0x000403B0
	[Token(Token = "0x6000CA5")]
	[Address(RVA = "0x2C50EB0", Offset = "0x2C50EB0", VA = "0x2C50EB0")]
	private void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ن\u0741ݐߊ(this);
	}

	// Token: 0x06000CA6 RID: 3238 RVA: 0x000421F8 File Offset: 0x000403F8
	[Token(Token = "0x6000CA6")]
	[Address(RVA = "0x2C51020", Offset = "0x2C51020", VA = "0x2C51020")]
	private void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ن\u0741ݐߊ(this);
	}

	// Token: 0x06000CA7 RID: 3239 RVA: 0x00042240 File Offset: 0x00040440
	[Token(Token = "0x6000CA7")]
	[Address(RVA = "0x2C51190", Offset = "0x2C51190", VA = "0x2C51190")]
	private void ل\u0732ߍӒ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u066Bࢳֈԫ(this);
	}

	// Token: 0x06000CA8 RID: 3240 RVA: 0x00042288 File Offset: 0x00040488
	[Token(Token = "0x6000CA8")]
	[Address(RVA = "0x2C51300", Offset = "0x2C51300", VA = "0x2C51300")]
	private void ࢧӾڈց()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CA9 RID: 3241 RVA: 0x000422C0 File Offset: 0x000404C0
	[Token(Token = "0x6000CA9")]
	[Address(RVA = "0x2C51494", Offset = "0x2C51494", VA = "0x2C51494")]
	private void ࢢ٧\u085DԀ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ى\u0875\u0876ڝ(this);
	}

	// Token: 0x06000CAA RID: 3242 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CAA")]
	[Address(RVA = "0x2C51604", Offset = "0x2C51604", VA = "0x2C51604")]
	private void \u085Dۍ\u0659Ӂ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CAB RID: 3243 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CAB")]
	[Address(RVA = "0x2C517B4", Offset = "0x2C517B4", VA = "0x2C517B4")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CAC RID: 3244 RVA: 0x00042308 File Offset: 0x00040508
	[Token(Token = "0x6000CAC")]
	[Address(RVA = "0x2C51998", Offset = "0x2C51998", VA = "0x2C51998")]
	private void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ن\u0741ݐߊ(this);
	}

	// Token: 0x06000CAD RID: 3245 RVA: 0x00042350 File Offset: 0x00040550
	[Token(Token = "0x6000CAD")]
	[Address(RVA = "0x2C51B08", Offset = "0x2C51B08", VA = "0x2C51B08")]
	private void ے\u059Fࢰس(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.٢ӲߠӐ(this);
	}

	// Token: 0x06000CAE RID: 3246 RVA: 0x00042398 File Offset: 0x00040598
	[Token(Token = "0x6000CAE")]
	[Address(RVA = "0x2C51C78", Offset = "0x2C51C78", VA = "0x2C51C78")]
	private void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u0732ߩګ\u0818(this);
	}

	// Token: 0x06000CAF RID: 3247 RVA: 0x000423E0 File Offset: 0x000405E0
	[Token(Token = "0x6000CAF")]
	[Address(RVA = "0x2C51DE8", Offset = "0x2C51DE8", VA = "0x2C51DE8")]
	private void \u073BօӁ\u059A()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
	}

	// Token: 0x06000CB0 RID: 3248 RVA: 0x00042410 File Offset: 0x00040610
	[Token(Token = "0x6000CB0")]
	[Address(RVA = "0x2C51F7C", Offset = "0x2C51F7C", VA = "0x2C51F7C")]
	private void ۊո\u0612\u0595()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CB1 RID: 3249 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CB1")]
	[Address(RVA = "0x2C52110", Offset = "0x2C52110", VA = "0x2C52110")]
	private void \u0881ݗӟ\u07BD()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CB2 RID: 3250 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CB2")]
	[Address(RVA = "0x2C522C4", Offset = "0x2C522C4", VA = "0x2C522C4")]
	private void Update()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CB3 RID: 3251 RVA: 0x00042448 File Offset: 0x00040648
	[Token(Token = "0x6000CB3")]
	[Address(RVA = "0x2C52494", Offset = "0x2C52494", VA = "0x2C52494")]
	private void ۲ڂ\u05B1ڨ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CB4 RID: 3252 RVA: 0x00042480 File Offset: 0x00040680
	[Token(Token = "0x6000CB4")]
	[Address(RVA = "0x2C52628", Offset = "0x2C52628", VA = "0x2C52628")]
	private void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u066Bࢳֈԫ(this);
	}

	// Token: 0x06000CB5 RID: 3253 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CB5")]
	[Address(RVA = "0x2C52798", Offset = "0x2C52798", VA = "0x2C52798")]
	private void \u0884ٿ\u0659ԫ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CB6 RID: 3254 RVA: 0x000424C8 File Offset: 0x000406C8
	[Token(Token = "0x6000CB6")]
	[Address(RVA = "0x2C52908", Offset = "0x2C52908", VA = "0x2C52908")]
	private void ࡎ\u05C2սࠇ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CB7 RID: 3255 RVA: 0x00042500 File Offset: 0x00040700
	[Token(Token = "0x6000CB7")]
	[Address(RVA = "0x2C52A9C", Offset = "0x2C52A9C", VA = "0x2C52A9C")]
	private void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if ("IsLowSurrogates" == null)
		{
		}
		bool flag = component;
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u08B5\u061Fݫو(this);
	}

	// Token: 0x06000CB8 RID: 3256 RVA: 0x00042554 File Offset: 0x00040754
	[Token(Token = "0x6000CB8")]
	[Address(RVA = "0x2C52C0C", Offset = "0x2C52C0C", VA = "0x2C52C0C")]
	private void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.ى\u0875\u0876ڝ(this);
	}

	// Token: 0x06000CB9 RID: 3257 RVA: 0x0004259C File Offset: 0x0004079C
	[Token(Token = "0x6000CB9")]
	[Address(RVA = "0x2C52D7C", Offset = "0x2C52D7C", VA = "0x2C52D7C")]
	private void \u059AՏ\u0600\u0872()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CBA RID: 3258 RVA: 0x000425D4 File Offset: 0x000407D4
	[Token(Token = "0x6000CBA")]
	[Address(RVA = "0x2C52F10", Offset = "0x2C52F10", VA = "0x2C52F10")]
	private void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CBB RID: 3259 RVA: 0x00042614 File Offset: 0x00040814
	[Token(Token = "0x6000CBB")]
	[Address(RVA = "0x2C5306C", Offset = "0x2C5306C", VA = "0x2C5306C")]
	private void \u0604\u065Dވڟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (typeof(UnityEngine.Object).TypeHandle != null)
		{
			return;
		}
		DynamicCosmetics ލ_u0882ײࢲ = DynamicCosmetics.ލ\u0882ײࢲ;
	}

	// Token: 0x06000CBC RID: 3260 RVA: 0x00042648 File Offset: 0x00040848
	[Token(Token = "0x6000CBC")]
	[Address(RVA = "0x2C531DC", Offset = "0x2C531DC", VA = "0x2C531DC")]
	private void ࡩݮڢՠ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CBD RID: 3261 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CBD")]
	[Address(RVA = "0x2C53370", Offset = "0x2C53370", VA = "0x2C53370")]
	private void ո\u07AA\u05BDࠕ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CBE RID: 3262 RVA: 0x00042680 File Offset: 0x00040880
	[Token(Token = "0x6000CBE")]
	[Address(RVA = "0x2C5351C", Offset = "0x2C5351C", VA = "0x2C5351C")]
	private void ߠ\u07AAߚթ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CBF RID: 3263 RVA: 0x000426B8 File Offset: 0x000408B8
	[Token(Token = "0x6000CBF")]
	[Address(RVA = "0x2C536B0", Offset = "0x2C536B0", VA = "0x2C536B0")]
	private void ݤۅࢦӃ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CC0 RID: 3264 RVA: 0x000426F0 File Offset: 0x000408F0
	[Token(Token = "0x6000CC0")]
	[Address(RVA = "0x2C53844", Offset = "0x2C53844", VA = "0x2C53844")]
	private void ә\u0730\u0839\u083F(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u066Bࢳֈԫ(this);
	}

	// Token: 0x06000CC1 RID: 3265 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CC1")]
	[Address(RVA = "0x2C539B4", Offset = "0x2C539B4", VA = "0x2C539B4")]
	private void ڑߒجވ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CC2 RID: 3266 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CC2")]
	[Address(RVA = "0x2C53B64", Offset = "0x2C53B64", VA = "0x2C53B64")]
	private void \u0832ࢳޤ\u07B5()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CC3 RID: 3267 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CC3")]
	[Address(RVA = "0x2C53D3C", Offset = "0x2C53D3C", VA = "0x2C53D3C")]
	private void ࡕߕ\u0707ݩ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CC4 RID: 3268 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CC4")]
	[Address(RVA = "0x2C53F14", Offset = "0x2C53F14", VA = "0x2C53F14")]
	private void ࢫ\u0876չՍ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CC5 RID: 3269 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CC5")]
	[Address(RVA = "0x2C540C4", Offset = "0x2C540C4", VA = "0x2C540C4")]
	private void ߑ\u0885\u05BBߕ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CC6 RID: 3270 RVA: 0x00042734 File Offset: 0x00040934
	[Token(Token = "0x6000CC6")]
	[Address(RVA = "0x2C54278", Offset = "0x2C54278", VA = "0x2C54278")]
	private void ڄ߃ԇӶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u08B5\u061Fݫو(this);
	}

	// Token: 0x06000CC7 RID: 3271 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000CC7")]
	[Address(RVA = "0x2C543D4", Offset = "0x2C543D4", VA = "0x2C543D4")]
	private void Ԡݘעࠀ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000CC8 RID: 3272 RVA: 0x0004277C File Offset: 0x0004097C
	[Token(Token = "0x6000CC8")]
	[Address(RVA = "0x2C545B8", Offset = "0x2C545B8", VA = "0x2C545B8")]
	private void ճ\u0828Ԓհ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u05B9\u0617\u07EE\u07ED)
		{
			return;
		}
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
		DynamicCosmetics.ލ\u0882ײࢲ.\u08B5\u061Fݫو(this);
	}

	// Token: 0x06000CC9 RID: 3273 RVA: 0x000427C4 File Offset: 0x000409C4
	[Token(Token = "0x6000CC9")]
	[Address(RVA = "0x2C54728", Offset = "0x2C54728", VA = "0x2C54728")]
	private void \u0818ՠש\u0731()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CCA RID: 3274 RVA: 0x000427FC File Offset: 0x000409FC
	[Token(Token = "0x6000CCA")]
	[Address(RVA = "0x2C548BC", Offset = "0x2C548BC", VA = "0x2C548BC")]
	private void ۮߝڪڐ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CCB RID: 3275 RVA: 0x00042834 File Offset: 0x00040A34
	[Token(Token = "0x6000CCB")]
	[Address(RVA = "0x2C54A50", Offset = "0x2C54A50", VA = "0x2C54A50")]
	private void ݛࠈ\u07F0ޱ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
		string ظݓ_u0897_u05B = this.ظݓ\u0897\u05B4;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000CCC RID: 3276 RVA: 0x0004286C File Offset: 0x00040A6C
	[Token(Token = "0x6000CCC")]
	[Address(RVA = "0x2C54BE4", Offset = "0x2C54BE4", VA = "0x2C54BE4")]
	private void \u05C1ܡԘޘ()
	{
		List<DynamicCosmetics.CosmeticItem> ܢ_u05ACڅة = DynamicCosmetics.ލ\u0882ײࢲ.ܢ\u05ACڅة;
	}

	// Token: 0x040001C5 RID: 453
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001C5")]
	public TMP_Text \u05A8ޖޔ\u0891;

	// Token: 0x040001C6 RID: 454
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001C6")]
	public string ظݓ\u0897\u05B4;

	// Token: 0x040001C7 RID: 455
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40001C7")]
	[HideInInspector]
	public bool \u0593գࢡӼ;

	// Token: 0x040001C8 RID: 456
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x40001C8")]
	public int ࡣࢻ\u0600\u085A;

	// Token: 0x040001C9 RID: 457
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40001C9")]
	private bool \u05B9\u0617\u07EE\u07ED;
}
