﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000092 RID: 146
[Token(Token = "0x2000092")]
public class RadarNetwork : MonoBehaviour
{
	// Token: 0x06001611 RID: 5649 RVA: 0x0007BA24 File Offset: 0x00079C24
	[Token(Token = "0x6001611")]
	[Address(RVA = "0x2F9E340", Offset = "0x2F9E340", VA = "0x2F9E340")]
	private void ٴݵۃ\u05AF()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001612 RID: 5650 RVA: 0x0007BA58 File Offset: 0x00079C58
	[Token(Token = "0x6001612")]
	[Address(RVA = "0x2F9E37C", Offset = "0x2F9E37C", VA = "0x2F9E37C")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001613 RID: 5651 RVA: 0x0007BA8C File Offset: 0x00079C8C
	[Token(Token = "0x6001613")]
	[Address(RVA = "0x2F9E3B8", Offset = "0x2F9E3B8", VA = "0x2F9E3B8")]
	private void \u070Aәޣے()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001614 RID: 5652 RVA: 0x0007BAC0 File Offset: 0x00079CC0
	[Token(Token = "0x6001614")]
	[Address(RVA = "0x2F9E3F4", Offset = "0x2F9E3F4", VA = "0x2F9E3F4")]
	private void ފՖߢ\u059B()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001615 RID: 5653 RVA: 0x0007BAF4 File Offset: 0x00079CF4
	[Token(Token = "0x6001615")]
	[Address(RVA = "0x2F9E430", Offset = "0x2F9E430", VA = "0x2F9E430")]
	private void ԟ\u086Cޣ\u055E()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001616 RID: 5654 RVA: 0x0007BB28 File Offset: 0x00079D28
	[Token(Token = "0x6001616")]
	[Address(RVA = "0x2F9E46C", Offset = "0x2F9E46C", VA = "0x2F9E46C")]
	private void ڑߒجވ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001617 RID: 5655 RVA: 0x0007BB54 File Offset: 0x00079D54
	[Token(Token = "0x6001617")]
	[Address(RVA = "0x2F9E498", Offset = "0x2F9E498", VA = "0x2F9E498")]
	private void \u07FE\u0882Զ\u066D()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001618 RID: 5656 RVA: 0x0007BB80 File Offset: 0x00079D80
	[Token(Token = "0x6001618")]
	[Address(RVA = "0x2F9E4C4", Offset = "0x2F9E4C4", VA = "0x2F9E4C4")]
	private void \u0886Ҽ\u058Dߛ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001619 RID: 5657 RVA: 0x0007BBB4 File Offset: 0x00079DB4
	[Token(Token = "0x6001619")]
	[Address(RVA = "0x2F9E500", Offset = "0x2F9E500", VA = "0x2F9E500")]
	private void Update()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x0600161A RID: 5658 RVA: 0x0007BBE8 File Offset: 0x00079DE8
	[Token(Token = "0x600161A")]
	[Address(RVA = "0x2F9E53C", Offset = "0x2F9E53C", VA = "0x2F9E53C")]
	private void ւࡂ\u0883\u0872()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x0600161B RID: 5659 RVA: 0x0007BC1C File Offset: 0x00079E1C
	[Token(Token = "0x600161B")]
	[Address(RVA = "0x2F9E578", Offset = "0x2F9E578", VA = "0x2F9E578")]
	private void Ҿࢹؼס()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x0600161C RID: 5660 RVA: 0x0007BC48 File Offset: 0x00079E48
	[Token(Token = "0x600161C")]
	[Address(RVA = "0x2F9E5A4", Offset = "0x2F9E5A4", VA = "0x2F9E5A4")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x0600161D RID: 5661 RVA: 0x0007BC7C File Offset: 0x00079E7C
	[Token(Token = "0x600161D")]
	[Address(RVA = "0x2F9E5E0", Offset = "0x2F9E5E0", VA = "0x2F9E5E0")]
	private void ࢫ\u0876չՍ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
	}

	// Token: 0x0600161E RID: 5662 RVA: 0x0007BCB0 File Offset: 0x00079EB0
	[Token(Token = "0x600161E")]
	[Address(RVA = "0x2F9E61C", Offset = "0x2F9E61C", VA = "0x2F9E61C")]
	private void ں٢ࡡ\u05EC()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x0600161F RID: 5663 RVA: 0x0007BCE4 File Offset: 0x00079EE4
	[Token(Token = "0x600161F")]
	[Address(RVA = "0x2F9E658", Offset = "0x2F9E658", VA = "0x2F9E658")]
	private void ժ\u065Dԯࡘ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
	}

	// Token: 0x06001620 RID: 5664 RVA: 0x0007BD18 File Offset: 0x00079F18
	[Token(Token = "0x6001620")]
	[Address(RVA = "0x2F9E694", Offset = "0x2F9E694", VA = "0x2F9E694")]
	private void ڃրӢԖ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001621 RID: 5665 RVA: 0x0007BD44 File Offset: 0x00079F44
	[Token(Token = "0x6001621")]
	[Address(RVA = "0x2F9E6C0", Offset = "0x2F9E6C0", VA = "0x2F9E6C0")]
	private void \u0732ڙԒࢺ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001622 RID: 5666 RVA: 0x0007BD78 File Offset: 0x00079F78
	[Token(Token = "0x6001622")]
	[Address(RVA = "0x2F9E6FC", Offset = "0x2F9E6FC", VA = "0x2F9E6FC")]
	public RadarNetwork()
	{
	}

	// Token: 0x06001623 RID: 5667 RVA: 0x0007BD8C File Offset: 0x00079F8C
	[Token(Token = "0x6001623")]
	[Address(RVA = "0x2F9E704", Offset = "0x2F9E704", VA = "0x2F9E704")]
	private void ӻӒݝ߃()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001624 RID: 5668 RVA: 0x0007BDC0 File Offset: 0x00079FC0
	[Token(Token = "0x6001624")]
	[Address(RVA = "0x2F9E740", Offset = "0x2F9E740", VA = "0x2F9E740")]
	private void \u0614ࢥӴ\u086C()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001625 RID: 5669 RVA: 0x0007BDF4 File Offset: 0x00079FF4
	[Token(Token = "0x6001625")]
	[Address(RVA = "0x2F9E77C", Offset = "0x2F9E77C", VA = "0x2F9E77C")]
	private void \u087BӦןݩ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001626 RID: 5670 RVA: 0x0007BE28 File Offset: 0x0007A028
	[Token(Token = "0x6001626")]
	[Address(RVA = "0x2F9E7B8", Offset = "0x2F9E7B8", VA = "0x2F9E7B8")]
	private void \u05EDց\u081Cت()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001627 RID: 5671 RVA: 0x0007BE5C File Offset: 0x0007A05C
	[Token(Token = "0x6001627")]
	[Address(RVA = "0x2F9E7F4", Offset = "0x2F9E7F4", VA = "0x2F9E7F4")]
	private void \u0881ݗӟ\u07BD()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001628 RID: 5672 RVA: 0x0007BE88 File Offset: 0x0007A088
	[Token(Token = "0x6001628")]
	[Address(RVA = "0x2F9E820", Offset = "0x2F9E820", VA = "0x2F9E820")]
	private void \u061B\u05EEوۈ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001629 RID: 5673 RVA: 0x0007BEBC File Offset: 0x0007A0BC
	[Token(Token = "0x6001629")]
	[Address(RVA = "0x2F9E85C", Offset = "0x2F9E85C", VA = "0x2F9E85C")]
	private void \u05F7ԝߠӱ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
	}

	// Token: 0x0600162A RID: 5674 RVA: 0x0007BEE0 File Offset: 0x0007A0E0
	[Token(Token = "0x600162A")]
	[Address(RVA = "0x2F9E888", Offset = "0x2F9E888", VA = "0x2F9E888")]
	private void Ӣ\u0592ߨׯ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x0600162B RID: 5675 RVA: 0x0007BF14 File Offset: 0x0007A114
	[Token(Token = "0x600162B")]
	[Address(RVA = "0x2F9E8C4", Offset = "0x2F9E8C4", VA = "0x2F9E8C4")]
	private void \u0838ӆڛӑ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x0600162C RID: 5676 RVA: 0x0007BF40 File Offset: 0x0007A140
	[Token(Token = "0x600162C")]
	[Address(RVA = "0x2F9E8F0", Offset = "0x2F9E8F0", VA = "0x2F9E8F0")]
	private void څࡣڐ\u0657()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x0600162D RID: 5677 RVA: 0x0007BF74 File Offset: 0x0007A174
	[Token(Token = "0x600162D")]
	[Address(RVA = "0x2F9E92C", Offset = "0x2F9E92C", VA = "0x2F9E92C")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x0600162E RID: 5678 RVA: 0x0007BFA0 File Offset: 0x0007A1A0
	[Token(Token = "0x600162E")]
	[Address(RVA = "0x2F9E958", Offset = "0x2F9E958", VA = "0x2F9E958")]
	private void ژךՈ\u0597()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x0600162F RID: 5679 RVA: 0x0007BFD4 File Offset: 0x0007A1D4
	[Token(Token = "0x600162F")]
	[Address(RVA = "0x2F9E994", Offset = "0x2F9E994", VA = "0x2F9E994")]
	private void Ҽ\u08B5ځ\u0658()
	{
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001630 RID: 5680 RVA: 0x0007BFF8 File Offset: 0x0007A1F8
	[Token(Token = "0x6001630")]
	[Address(RVA = "0x2F9E9C0", Offset = "0x2F9E9C0", VA = "0x2F9E9C0")]
	private void ԣԭՋࠏ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		long active = 0L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x06001631 RID: 5681 RVA: 0x0007C024 File Offset: 0x0007A224
	[Token(Token = "0x6001631")]
	[Address(RVA = "0x2F9E9EC", Offset = "0x2F9E9EC", VA = "0x2F9E9EC")]
	private void \u0654ޛ\u07FAذ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject u0711_u061Bرࡇ = this.\u0711\u061Bرࡇ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		u0711_u061Bرࡇ.SetActive(active != 0L);
	}

	// Token: 0x040002C2 RID: 706
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002C2")]
	public GameObject \u0711\u061Bرࡇ;

	// Token: 0x040002C3 RID: 707
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002C3")]
	public PhotonView \u07AE\u05AF\u064FԖ;
}
