﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x02000136 RID: 310
	internal class AttributeAttribute : Attribute
	{
		// Token: 0x04000679 RID: 1657
		public string Name;

		// Token: 0x0400067A RID: 1658
		public string RVA;

		// Token: 0x0400067B RID: 1659
		public string Offset;
	}
}
