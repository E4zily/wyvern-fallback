﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x02000135 RID: 309
	internal class FieldOffsetAttribute : Attribute
	{
		// Token: 0x04000678 RID: 1656
		public string Offset;
	}
}
