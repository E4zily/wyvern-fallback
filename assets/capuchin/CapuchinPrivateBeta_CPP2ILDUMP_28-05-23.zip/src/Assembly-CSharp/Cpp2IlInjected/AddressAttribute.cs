﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x02000134 RID: 308
	internal class AddressAttribute : Attribute
	{
		// Token: 0x04000674 RID: 1652
		public string RVA;

		// Token: 0x04000675 RID: 1653
		public string Offset;

		// Token: 0x04000676 RID: 1654
		public string VA;

		// Token: 0x04000677 RID: 1655
		public string Slot;
	}
}
