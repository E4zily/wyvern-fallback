﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x02000139 RID: 313
	internal class AnalysisFailedException : Exception
	{
		// Token: 0x06002BF1 RID: 11249 RVA: 0x00108E62 File Offset: 0x00107062
		public AnalysisFailedException(string message) : base(message)
		{
		}
	}
}
