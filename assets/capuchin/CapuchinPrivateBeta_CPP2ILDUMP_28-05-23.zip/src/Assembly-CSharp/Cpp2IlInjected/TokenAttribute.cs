﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x02000138 RID: 312
	internal class TokenAttribute : Attribute
	{
		// Token: 0x0400067D RID: 1661
		public string Token;
	}
}
