﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x02000137 RID: 311
	internal class MetadataOffsetAttribute : Attribute
	{
		// Token: 0x0400067C RID: 1660
		public string Offset;
	}
}
