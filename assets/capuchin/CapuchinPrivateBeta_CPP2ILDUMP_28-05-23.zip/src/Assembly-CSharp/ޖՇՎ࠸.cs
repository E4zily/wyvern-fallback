﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using TMPro;

// Token: 0x020000AD RID: 173
[Token(Token = "0x20000AD")]
public class ޖՇՎ\u0838
{
	// Token: 0x060019C5 RID: 6597 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60019C5")]
	[Address(RVA = "0x212BE38", Offset = "0x212BE38", VA = "0x212BE38")]
	public static void ڣ\u05F6\u0874\u0830(string \u0656\u0898ر\u0896)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019C6 RID: 6598 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60019C6")]
	[Address(RVA = "0x212C2E8", Offset = "0x212C2E8", VA = "0x212C2E8")]
	public static void ڒ\u0833\u066Bձ(string \u0656\u0898ر\u0896)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019C7 RID: 6599 RVA: 0x0008B29C File Offset: 0x0008949C
	[Token(Token = "0x60019C7")]
	[Address(RVA = "0x212C794", Offset = "0x212C794", VA = "0x212C794")]
	public static void \u05C2\u06E7\u07FF\u05CD()
	{
		TMP_Text ۶_u066Aޡ_u070F = DisplayLogsToText.كݕ\u05F3\u0589.۶\u066Aޡ\u070F;
		List<string> ܦ߈ࢷՋ = DisplayLogsToText.كݕ\u05F3\u0589.ܦ߈ࢷՋ;
		Dictionary<string, int> u082Aӫݗߥ = DisplayLogsToText.كݕ\u05F3\u0589.\u082Aӫݗߥ;
	}

	// Token: 0x060019C8 RID: 6600 RVA: 0x0008B2D0 File Offset: 0x000894D0
	[Token(Token = "0x60019C8")]
	[Address(RVA = "0x212C87C", Offset = "0x212C87C", VA = "0x212C87C")]
	public ޖՇՎ\u0838()
	{
	}

	// Token: 0x060019C9 RID: 6601 RVA: 0x0008B2E4 File Offset: 0x000894E4
	[Token(Token = "0x60019C9")]
	[Address(RVA = "0x212C884", Offset = "0x212C884", VA = "0x212C884")]
	public static void \u07B4\u0705\u05CD\u0619()
	{
		TMP_Text ۶_u066Aޡ_u070F = DisplayLogsToText.كݕ\u05F3\u0589.۶\u066Aޡ\u070F;
		List<string> ܦ߈ࢷՋ = DisplayLogsToText.كݕ\u05F3\u0589.ܦ߈ࢷՋ;
		Dictionary<string, int> u082Aӫݗߥ = DisplayLogsToText.كݕ\u05F3\u0589.\u082Aӫݗߥ;
	}

	// Token: 0x060019CA RID: 6602 RVA: 0x0008B318 File Offset: 0x00089518
	[Token(Token = "0x60019CA")]
	[Address(RVA = "0x212C96C", Offset = "0x212C96C", VA = "0x212C96C")]
	public static void ץڡ߆ף()
	{
		TMP_Text ۶_u066Aޡ_u070F = DisplayLogsToText.كݕ\u05F3\u0589.۶\u066Aޡ\u070F;
		List<string> ܦ߈ࢷՋ = DisplayLogsToText.كݕ\u05F3\u0589.ܦ߈ࢷՋ;
		Dictionary<string, int> u082Aӫݗߥ = DisplayLogsToText.كݕ\u05F3\u0589.\u082Aӫݗߥ;
	}

	// Token: 0x060019CB RID: 6603 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60019CB")]
	[Address(RVA = "0x212CA54", Offset = "0x212CA54", VA = "0x212CA54")]
	public static void ײݰ\u06D7ى(string \u0656\u0898ر\u0896)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019CC RID: 6604 RVA: 0x0008B34C File Offset: 0x0008954C
	[Token(Token = "0x60019CC")]
	[Address(RVA = "0x212CF04", Offset = "0x212CF04", VA = "0x212CF04")]
	public static void \u0740ࢣ\u089D٢()
	{
		TMP_Text ۶_u066Aޡ_u070F = DisplayLogsToText.كݕ\u05F3\u0589.۶\u066Aޡ\u070F;
		List<string> ܦ߈ࢷՋ = DisplayLogsToText.كݕ\u05F3\u0589.ܦ߈ࢷՋ;
		Dictionary<string, int> u082Aӫݗߥ = DisplayLogsToText.كݕ\u05F3\u0589.\u082Aӫݗߥ;
	}

	// Token: 0x060019CD RID: 6605 RVA: 0x0008B380 File Offset: 0x00089580
	[Token(Token = "0x60019CD")]
	[Address(RVA = "0x212CFEC", Offset = "0x212CFEC", VA = "0x212CFEC")]
	public static void ؠՔܙݱ()
	{
		TMP_Text ۶_u066Aޡ_u070F = DisplayLogsToText.كݕ\u05F3\u0589.۶\u066Aޡ\u070F;
		List<string> ܦ߈ࢷՋ = DisplayLogsToText.كݕ\u05F3\u0589.ܦ߈ࢷՋ;
		Dictionary<string, int> u082Aӫݗߥ = DisplayLogsToText.كݕ\u05F3\u0589.\u082Aӫݗߥ;
	}

	// Token: 0x060019CE RID: 6606 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60019CE")]
	[Address(RVA = "0x212D0D4", Offset = "0x212D0D4", VA = "0x212D0D4")]
	public static void \u05B5\u0878\u085EԂ(string \u0656\u0898ر\u0896)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019CF RID: 6607 RVA: 0x0008B3B4 File Offset: 0x000895B4
	[Token(Token = "0x60019CF")]
	[Address(RVA = "0x212D584", Offset = "0x212D584", VA = "0x212D584")]
	public static void ٤\u05FAࠑࢩ()
	{
		TMP_Text ۶_u066Aޡ_u070F = DisplayLogsToText.كݕ\u05F3\u0589.۶\u066Aޡ\u070F;
		List<string> ܦ߈ࢷՋ = DisplayLogsToText.كݕ\u05F3\u0589.ܦ߈ࢷՋ;
		Dictionary<string, int> u082Aӫݗߥ = DisplayLogsToText.كݕ\u05F3\u0589.\u082Aӫݗߥ;
	}

	// Token: 0x060019D0 RID: 6608 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60019D0")]
	[Address(RVA = "0x212D66C", Offset = "0x212D66C", VA = "0x212D66C")]
	public static void \u05B5ԁ\u055Aࢢ(string \u0656\u0898ر\u0896)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019D1 RID: 6609 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60019D1")]
	[Address(RVA = "0x212DB18", Offset = "0x212DB18", VA = "0x212DB18")]
	public static void \u07EF\u061Aޞ\u0608(string \u0656\u0898ر\u0896)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019D2 RID: 6610 RVA: 0x0008B3E8 File Offset: 0x000895E8
	[Token(Token = "0x60019D2")]
	[Address(RVA = "0x212DFC8", Offset = "0x212DFC8", VA = "0x212DFC8")]
	public static void ڨӐاݻ()
	{
		TMP_Text ۶_u066Aޡ_u070F = DisplayLogsToText.كݕ\u05F3\u0589.۶\u066Aޡ\u070F;
		List<string> ܦ߈ࢷՋ = DisplayLogsToText.كݕ\u05F3\u0589.ܦ߈ࢷՋ;
		Dictionary<string, int> u082Aӫݗߥ = DisplayLogsToText.كݕ\u05F3\u0589.\u082Aӫݗߥ;
	}

	// Token: 0x060019D3 RID: 6611 RVA: 0x0008B41C File Offset: 0x0008961C
	[Token(Token = "0x60019D3")]
	[Address(RVA = "0x212E0B0", Offset = "0x212E0B0", VA = "0x212E0B0")]
	public static void \u0613ݎ\u05CDӞ()
	{
		TMP_Text ۶_u066Aޡ_u070F = DisplayLogsToText.كݕ\u05F3\u0589.۶\u066Aޡ\u070F;
		List<string> ܦ߈ࢷՋ = DisplayLogsToText.كݕ\u05F3\u0589.ܦ߈ࢷՋ;
		Dictionary<string, int> u082Aӫݗߥ = DisplayLogsToText.كݕ\u05F3\u0589.\u082Aӫݗߥ;
	}

	// Token: 0x060019D4 RID: 6612 RVA: 0x0008B450 File Offset: 0x00089650
	[Token(Token = "0x60019D4")]
	[Address(RVA = "0x212E198", Offset = "0x212E198", VA = "0x212E198")]
	public static void \u082CߛԳٴ()
	{
		TMP_Text ۶_u066Aޡ_u070F = DisplayLogsToText.كݕ\u05F3\u0589.۶\u066Aޡ\u070F;
		List<string> ܦ߈ࢷՋ = DisplayLogsToText.كݕ\u05F3\u0589.ܦ߈ࢷՋ;
		Dictionary<string, int> u082Aӫݗߥ = DisplayLogsToText.كݕ\u05F3\u0589.\u082Aӫݗߥ;
	}

	// Token: 0x060019D5 RID: 6613 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60019D5")]
	[Address(RVA = "0x212E280", Offset = "0x212E280", VA = "0x212E280")]
	public static void \u089BӔڑۋ(string \u0656\u0898ر\u0896)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019D6 RID: 6614 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60019D6")]
	[Address(RVA = "0x212E72C", Offset = "0x212E72C", VA = "0x212E72C")]
	public static void ڀޡ\u07A6\u065A(string \u0656\u0898ر\u0896)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019D7 RID: 6615 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60019D7")]
	[Address(RVA = "0x212EBD8", Offset = "0x212EBD8", VA = "0x212EBD8")]
	public static void މܝ\u0654ޙ(string \u0656\u0898ر\u0896)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x020000AE RID: 174
	[Token(Token = "0x20000AE")]
	[CompilerGenerated]
	private sealed class \u088Bٵڛտ
	{
		// Token: 0x060019D8 RID: 6616 RVA: 0x0008B484 File Offset: 0x00089684
		[Token(Token = "0x60019D8")]
		[Address(RVA = "0x30830D8", Offset = "0x30830D8", VA = "0x30830D8")]
		public \u088Bٵڛտ()
		{
		}

		// Token: 0x060019D9 RID: 6617 RVA: 0x0008B498 File Offset: 0x00089698
		[Token(Token = "0x60019D9")]
		[Address(RVA = "0x30830E0", Offset = "0x30830E0", VA = "0x30830E0")]
		internal bool ۴Ӄ\u058B\u0886(string m)
		{
			string value = this.message;
			return m.Equals(value);
		}

		// Token: 0x060019DA RID: 6618 RVA: 0x0008B4BC File Offset: 0x000896BC
		[Token(Token = "0x60019DA")]
		[Address(RVA = "0x3083104", Offset = "0x3083104", VA = "0x3083104")]
		internal string ڷࡘոӴ(string m, int i)
		{
			int num = this.messageIndex;
			return this.messageWithCount;
		}

		// Token: 0x04000327 RID: 807
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000327")]
		public string message;

		// Token: 0x04000328 RID: 808
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000328")]
		public int messageIndex;

		// Token: 0x04000329 RID: 809
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000329")]
		public string messageWithCount;
	}
}
