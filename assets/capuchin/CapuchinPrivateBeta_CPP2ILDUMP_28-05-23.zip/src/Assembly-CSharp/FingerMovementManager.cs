﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200005E RID: 94
[Token(Token = "0x200005E")]
[ExecuteAlways]
public class FingerMovementManager : MonoBehaviourPun
{
	// Token: 0x06000DDE RID: 3550 RVA: 0x0004B214 File Offset: 0x00049414
	[Token(Token = "0x6000DDE")]
	[Address(RVA = "0x1D8BA44", Offset = "0x1D8BA44", VA = "0x1D8BA44")]
	private void \u0656ӺմՁ()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000DDF RID: 3551 RVA: 0x0004B22C File Offset: 0x0004942C
	[Token(Token = "0x6000DDF")]
	[Address(RVA = "0x1D8BA50", Offset = "0x1D8BA50", VA = "0x1D8BA50")]
	private void ӭࡢࢬ\u0703()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.ړղ\u064Eշ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u07BF\u05A9\u059Fࡁ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DE0 RID: 3552 RVA: 0x0004B560 File Offset: 0x00049760
	[Token(Token = "0x6000DE0")]
	[Address(RVA = "0x1D8D02C", Offset = "0x1D8D02C", VA = "0x1D8D02C")]
	private void ࠌࢡࠕ۷()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000DE1 RID: 3553 RVA: 0x0004B578 File Offset: 0x00049778
	[Token(Token = "0x6000DE1")]
	[Address(RVA = "0x1D8D038", Offset = "0x1D8D038", VA = "0x1D8D038")]
	private void ע߅ࡋ\u05BC()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DE2 RID: 3554 RVA: 0x0004B5E8 File Offset: 0x000497E8
	[Token(Token = "0x6000DE2")]
	[Address(RVA = "0x1D8D330", Offset = "0x1D8D330", VA = "0x1D8D330")]
	private void \u07ACࠎ\u06E9ڙ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DE3 RID: 3555 RVA: 0x0004B660 File Offset: 0x00049860
	[Token(Token = "0x6000DE3")]
	[Address(RVA = "0x1D8D658", Offset = "0x1D8D658", VA = "0x1D8D658")]
	private void ܣݏ۳ݕ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DE4 RID: 3556 RVA: 0x0004B6D0 File Offset: 0x000498D0
	[Token(Token = "0x6000DE4")]
	[Address(RVA = "0x1D8D960", Offset = "0x1D8D960", VA = "0x1D8D960")]
	private void ߄Ӄ\u0613ھ()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000DE5 RID: 3557 RVA: 0x0004B6E8 File Offset: 0x000498E8
	[Token(Token = "0x6000DE5")]
	[Address(RVA = "0x1D8D96C", Offset = "0x1D8D96C", VA = "0x1D8D96C")]
	private void ࡌݽٯۋ()
	{
		for (;;)
		{
			if (this.\u0658\u059Bټ\u073B)
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.ޘ\u05C6ۑԖ();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
				Vector3 zero = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
				Vector3 zero2 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
				Vector3 zero3 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					break;
				}
			}
			else
			{
				this.\u061Eۑ\u05FDӚ();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F13 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F14 = this.ז\u07ADࡒ\u061F;
				Vector3 zero4 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F15 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F16 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u4 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F17 = this.ז\u07ADࡒ\u061F;
				Vector3 zero5 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F18 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F19 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u5 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F20 = this.ז\u07ADࡒ\u061F;
				Vector3 zero6 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F21 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F22 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u6 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000DE6 RID: 3558 RVA: 0x0004BA1C File Offset: 0x00049C1C
	[Token(Token = "0x6000DE6")]
	[Address(RVA = "0x1D8EF7C", Offset = "0x1D8EF7C", VA = "0x1D8EF7C")]
	private void ބՅ١\u082D()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000DE7 RID: 3559 RVA: 0x0004BA34 File Offset: 0x00049C34
	[Token(Token = "0x6000DE7")]
	[Address(RVA = "0x1D8EF88", Offset = "0x1D8EF88", VA = "0x1D8EF88")]
	private void \u065DԄԮә()
	{
		if (!true)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DE8 RID: 3560 RVA: 0x0004BAA0 File Offset: 0x00049CA0
	[Token(Token = "0x6000DE8")]
	[Address(RVA = "0x1D8F294", Offset = "0x1D8F294", VA = "0x1D8F294")]
	private void ߠ\u07AAߚթ()
	{
	}

	// Token: 0x06000DE9 RID: 3561 RVA: 0x0004BAB0 File Offset: 0x00049CB0
	[Token(Token = "0x6000DE9")]
	[Address(RVA = "0x1D8F29C", Offset = "0x1D8F29C", VA = "0x1D8F29C")]
	private void աؾێړ()
	{
	}

	// Token: 0x06000DEA RID: 3562 RVA: 0x0004BAC0 File Offset: 0x00049CC0
	[Token(Token = "0x6000DEA")]
	[Address(RVA = "0x1D8F2A4", Offset = "0x1D8F2A4", VA = "0x1D8F2A4")]
	private void ࢥ\u05B5ސޥ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DEB RID: 3563 RVA: 0x0004BB38 File Offset: 0x00049D38
	[Token(Token = "0x6000DEB")]
	[Address(RVA = "0x1D8F5C0", Offset = "0x1D8F5C0", VA = "0x1D8F5C0")]
	private void \u0885\u081BӤܜ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DEC RID: 3564 RVA: 0x0004BBA8 File Offset: 0x00049DA8
	[Token(Token = "0x6000DEC")]
	[Address(RVA = "0x1D8F8E8", Offset = "0x1D8F8E8", VA = "0x1D8F8E8")]
	private void \u0741ՁԆۄ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DED RID: 3565 RVA: 0x0004BC20 File Offset: 0x00049E20
	[Token(Token = "0x6000DED")]
	[Address(RVA = "0x1D8FC10", Offset = "0x1D8FC10", VA = "0x1D8FC10")]
	private void ڌהբݕ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DEE RID: 3566 RVA: 0x0004BC98 File Offset: 0x00049E98
	[Token(Token = "0x6000DEE")]
	[Address(RVA = "0x1D8FF40", Offset = "0x1D8FF40", VA = "0x1D8FF40")]
	private void ދܐضړ()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			this.\u06E8\u073E\u081Cҽ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ߡهھߍ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DEF RID: 3567 RVA: 0x0004BFB0 File Offset: 0x0004A1B0
	[Token(Token = "0x6000DEF")]
	[Address(RVA = "0x1D914BC", Offset = "0x1D914BC", VA = "0x1D914BC")]
	private void ߞ\u087Bࡅ\u0895()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DF0 RID: 3568 RVA: 0x0004C028 File Offset: 0x0004A228
	[Token(Token = "0x6000DF0")]
	[Address(RVA = "0x1D917E0", Offset = "0x1D917E0", VA = "0x1D917E0")]
	private void ӣڢࡁ\u0878()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DF1 RID: 3569 RVA: 0x0004C09C File Offset: 0x0004A29C
	[Token(Token = "0x6000DF1")]
	[Address(RVA = "0x1D91B00", Offset = "0x1D91B00", VA = "0x1D91B00")]
	private void دז\u06EDճ()
	{
		for (;;)
		{
			if (this.\u0658\u059Bټ\u073B)
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.\u083CԯӰ\u05F5();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
				Vector3 zero = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
				Vector3 zero2 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
				Vector3 zero3 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					break;
				}
			}
			else
			{
				this.ܩ\u07AEޣذ();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F13 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F14 = this.ז\u07ADࡒ\u061F;
				Vector3 zero4 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F15 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F16 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u4 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F17 = this.ז\u07ADࡒ\u061F;
				Vector3 zero5 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F18 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F19 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u5 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F20 = this.ז\u07ADࡒ\u061F;
				Vector3 zero6 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F21 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F22 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u6 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000DF2 RID: 3570 RVA: 0x0004C3C8 File Offset: 0x0004A5C8
	[Token(Token = "0x6000DF2")]
	[Address(RVA = "0x1D93194", Offset = "0x1D93194", VA = "0x1D93194")]
	private void \u0705\u083EԪڸ()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			this.ݥԥ\u065A\u05C8();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ӣڢࡁ\u0878();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DF3 RID: 3571 RVA: 0x0004C6EC File Offset: 0x0004A8EC
	[Token(Token = "0x6000DF3")]
	[Address(RVA = "0x1D944C4", Offset = "0x1D944C4", VA = "0x1D944C4")]
	private void װڎ\u064C\u085F()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.\u06E8\u073E\u081Cҽ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u05F8Թ\u088Bذ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DF4 RID: 3572 RVA: 0x0004CA1C File Offset: 0x0004AC1C
	[Token(Token = "0x6000DF4")]
	[Address(RVA = "0x1D9582C", Offset = "0x1D9582C", VA = "0x1D9582C")]
	private void Ӎ\u070BԤߓ()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			this.דߪࡓ\u0749();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ࡒ\u0747ө\u088E();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DF5 RID: 3573 RVA: 0x0004CD4C File Offset: 0x0004AF4C
	[Token(Token = "0x6000DF5")]
	[Address(RVA = "0x1D96E74", Offset = "0x1D96E74", VA = "0x1D96E74")]
	private void ڹӹچة()
	{
		while (this.\u0658\u059Bټ\u073B)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.ޘ\u05C6ۑԖ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		this.\u07ACࠎ\u06E9ڙ();
		FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
	}

	// Token: 0x06000DF6 RID: 3574 RVA: 0x0004D07C File Offset: 0x0004B27C
	[Token(Token = "0x6000DF6")]
	[Address(RVA = "0x1D97ED8", Offset = "0x1D97ED8", VA = "0x1D97ED8")]
	private void ߁\u0829\u073E\u081A()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000DF7 RID: 3575 RVA: 0x0004D094 File Offset: 0x0004B294
	[Token(Token = "0x6000DF7")]
	[Address(RVA = "0x1D97EE4", Offset = "0x1D97EE4", VA = "0x1D97EE4")]
	private void ӭࡖݲ\u05BD()
	{
	}

	// Token: 0x06000DF8 RID: 3576 RVA: 0x0004D0A4 File Offset: 0x0004B2A4
	[Token(Token = "0x6000DF8")]
	[Address(RVA = "0x1D8E910", Offset = "0x1D8E910", VA = "0x1D8E910")]
	private void \u061Eۑ\u05FDӚ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DF9 RID: 3577 RVA: 0x0004D11C File Offset: 0x0004B31C
	[Token(Token = "0x6000DF9")]
	[Address(RVA = "0x1D97EEC", Offset = "0x1D97EEC", VA = "0x1D97EEC")]
	private void ւࢢدࠈ()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			this.ࡒ\u0747ө\u088E();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u087E\u05C7\u0836ٮ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DFA RID: 3578 RVA: 0x0004D448 File Offset: 0x0004B648
	[Token(Token = "0x6000DFA")]
	[Address(RVA = "0x1D99194", Offset = "0x1D99194", VA = "0x1D99194")]
	private void \u05ADڴ\u0599ࢩ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DFB RID: 3579 RVA: 0x0004D4C4 File Offset: 0x0004B6C4
	[Token(Token = "0x6000DFB")]
	[Address(RVA = "0x1D994EC", Offset = "0x1D994EC", VA = "0x1D994EC")]
	private void \u06DC\u05AF\u0530\u065B()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DFC RID: 3580 RVA: 0x0004D53C File Offset: 0x0004B73C
	[Token(Token = "0x6000DFC")]
	[Address(RVA = "0x1D9980C", Offset = "0x1D9980C", VA = "0x1D9980C")]
	private void \u07BCݛ\u07F1۸()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.\u05ADڴ\u0599ࢩ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ࡒ\u0747ө\u088E();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DFD RID: 3581 RVA: 0x0004D86C File Offset: 0x0004BA6C
	[Token(Token = "0x6000DFD")]
	[Address(RVA = "0x1D92B20", Offset = "0x1D92B20", VA = "0x1D92B20")]
	private void ܩ\u07AEޣذ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DFE RID: 3582 RVA: 0x0004D8DC File Offset: 0x0004BADC
	[Token(Token = "0x6000DFE")]
	[Address(RVA = "0x1D9A860", Offset = "0x1D9A860", VA = "0x1D9A860")]
	private void ࢺ\u0599\u07A6\u0650()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.ݥԥ\u065A\u05C8();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u087E\u05C7\u0836ٮ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000DFF RID: 3583 RVA: 0x0004DBE4 File Offset: 0x0004BDE4
	[Token(Token = "0x6000DFF")]
	[Address(RVA = "0x1D9B76C", Offset = "0x1D9B76C", VA = "0x1D9B76C")]
	private void \u05F8ڶ\u070Aө()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			this.\u061Eۑ\u05FDӚ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ߡ\u0825\u0889Ԛ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E00 RID: 3584 RVA: 0x0004DF20 File Offset: 0x0004C120
	[Token(Token = "0x6000E00")]
	[Address(RVA = "0x1D9CAA8", Offset = "0x1D9CAA8", VA = "0x1D9CAA8")]
	private void \u089Fށհ\u083F()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.ޘ\u05C6ۑԖ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u06E8\u073E\u081Cҽ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E01 RID: 3585 RVA: 0x0004E234 File Offset: 0x0004C434
	[Token(Token = "0x6000E01")]
	[Address(RVA = "0x1D9D9E8", Offset = "0x1D9D9E8", VA = "0x1D9D9E8")]
	private void ࡇܛ\u06E7ح()
	{
		while (this.\u0658\u059Bټ\u073B)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.ړղ\u064Eշ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		this.דߪࡓ\u0749();
		FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
	}

	// Token: 0x06000E02 RID: 3586 RVA: 0x0004E55C File Offset: 0x0004C75C
	[Token(Token = "0x6000E02")]
	[Address(RVA = "0x1D9E9B8", Offset = "0x1D9E9B8", VA = "0x1D9E9B8")]
	private void ݡز٨հ()
	{
	}

	// Token: 0x06000E03 RID: 3587 RVA: 0x0004E56C File Offset: 0x0004C76C
	[Token(Token = "0x6000E03")]
	[Address(RVA = "0x1D9E9C0", Offset = "0x1D9E9C0", VA = "0x1D9E9C0")]
	private void ࠎճ\u05F9م()
	{
		for (;;)
		{
			if (this.\u0658\u059Bټ\u073B)
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.\u06DC\u05AF\u0530\u065B();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
				Vector3 zero = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
				Vector3 zero2 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
				Vector3 zero3 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					break;
				}
			}
			else
			{
				this.ߞ\u087Bࡅ\u0895();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F13 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F14 = this.ז\u07ADࡒ\u061F;
				Vector3 zero4 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F15 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F16 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u4 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F17 = this.ז\u07ADࡒ\u061F;
				Vector3 zero5 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F18 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F19 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u5 = this.\u05A9ݐ\u061A\u0893;
				Vector3 zero6 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F20 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F21 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u6 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000E04 RID: 3588 RVA: 0x0004E8A0 File Offset: 0x0004CAA0
	[Token(Token = "0x6000E04")]
	[Address(RVA = "0x1D8EC40", Offset = "0x1D8EC40", VA = "0x1D8EC40")]
	private void ޘ\u05C6ۑԖ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E05 RID: 3589 RVA: 0x0004E918 File Offset: 0x0004CB18
	[Token(Token = "0x6000E05")]
	[Address(RVA = "0x1D9F9CC", Offset = "0x1D9F9CC", VA = "0x1D9F9CC")]
	private void ࠏޤݳ\u06DD()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E06 RID: 3590 RVA: 0x0004E930 File Offset: 0x0004CB30
	[Token(Token = "0x6000E06")]
	[Address(RVA = "0x1D9F9D8", Offset = "0x1D9F9D8", VA = "0x1D9F9D8")]
	private void ߇ܝܮ\u087F()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ڌהբݕ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E07 RID: 3591 RVA: 0x0004EC54 File Offset: 0x0004CE54
	[Token(Token = "0x6000E07")]
	[Address(RVA = "0x1DA0968", Offset = "0x1DA0968", VA = "0x1DA0968")]
	private void \u05C8\u05BFࠁف()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E08 RID: 3592 RVA: 0x0004EC6C File Offset: 0x0004CE6C
	[Token(Token = "0x6000E08")]
	[Address(RVA = "0x1DA0974", Offset = "0x1DA0974", VA = "0x1DA0974")]
	private void \u0739߉ڵݞ()
	{
	}

	// Token: 0x06000E09 RID: 3593 RVA: 0x0004EC7C File Offset: 0x0004CE7C
	[Token(Token = "0x6000E09")]
	[Address(RVA = "0x1DA097C", Offset = "0x1DA097C", VA = "0x1DA097C")]
	private void \u05A0\u05B4\u05F5ߣ()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.ݥԥ\u065A\u05C8();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ݥԥ\u065A\u05C8();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E0A RID: 3594 RVA: 0x0004EF90 File Offset: 0x0004D190
	[Token(Token = "0x6000E0A")]
	[Address(RVA = "0x1DA18F4", Offset = "0x1DA18F4", VA = "0x1DA18F4")]
	private void ڍ\u058Bݗࡣ()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E0B RID: 3595 RVA: 0x0004EFA8 File Offset: 0x0004D1A8
	[Token(Token = "0x6000E0B")]
	[Address(RVA = "0x1DA1900", Offset = "0x1DA1900", VA = "0x1DA1900")]
	private void \u0896ࠍࡢۯ()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.\u06EB\u088Eפ\u070F();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ܣݏ۳ݕ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E0C RID: 3596 RVA: 0x0004F2D0 File Offset: 0x0004D4D0
	[Token(Token = "0x6000E0C")]
	[Address(RVA = "0x1DA2B94", Offset = "0x1DA2B94", VA = "0x1DA2B94")]
	private void نո\u0599\u0589()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E0D RID: 3597 RVA: 0x0004F2E8 File Offset: 0x0004D4E8
	[Token(Token = "0x6000E0D")]
	[Address(RVA = "0x1DA2BA0", Offset = "0x1DA2BA0", VA = "0x1DA2BA0")]
	private void ٻӸ\u0818\u087A()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			this.բࢶӣ\u07AE();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ڼ\u0825\u05F3Ը();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E0E RID: 3598 RVA: 0x0004F610 File Offset: 0x0004D810
	[Token(Token = "0x6000E0E")]
	[Address(RVA = "0x1DA41BC", Offset = "0x1DA41BC", VA = "0x1DA41BC")]
	private void \u05ABݿࡋ\u06E9()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E0F RID: 3599 RVA: 0x0004F628 File Offset: 0x0004D828
	[Token(Token = "0x6000E0F")]
	[Address(RVA = "0x1DA41C8", Offset = "0x1DA41C8", VA = "0x1DA41C8")]
	private void شԚ\u0650\u05BC()
	{
		while (this.\u0658\u059Bټ\u073B)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.\u05F8Թ\u088Bذ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		this.ӣڢࡁ\u0878();
		FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
	}

	// Token: 0x06000E10 RID: 3600 RVA: 0x0004F948 File Offset: 0x0004DB48
	[Token(Token = "0x6000E10")]
	[Address(RVA = "0x1DA5164", Offset = "0x1DA5164", VA = "0x1DA5164")]
	private void ؠࡒࢢԃ()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			this.\u05ADڴ\u0599ࢩ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u0885\u081BӤܜ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E11 RID: 3601 RVA: 0x0004FC64 File Offset: 0x0004DE64
	[Token(Token = "0x6000E11")]
	[Address(RVA = "0x1DA60AC", Offset = "0x1DA60AC", VA = "0x1DA60AC")]
	private void \u0704زք٥()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.\u06DC\u05AF\u0530\u065B();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u07BF\u05A9\u059Fࡁ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E12 RID: 3602 RVA: 0x0004FF90 File Offset: 0x0004E190
	[Token(Token = "0x6000E12")]
	[Address(RVA = "0x1DA3B44", Offset = "0x1DA3B44", VA = "0x1DA3B44")]
	private void բࢶӣ\u07AE()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E13 RID: 3603 RVA: 0x00050008 File Offset: 0x0004E208
	[Token(Token = "0x6000E13")]
	[Address(RVA = "0x1D92E5C", Offset = "0x1D92E5C", VA = "0x1D92E5C")]
	private void \u083CԯӰ\u05F5()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E14 RID: 3604 RVA: 0x00050080 File Offset: 0x0004E280
	[Token(Token = "0x6000E14")]
	[Address(RVA = "0x1DA70B8", Offset = "0x1DA70B8", VA = "0x1DA70B8")]
	private void \u087Dܠ\u07FFӴ()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.ڼ\u0825\u05F3Ը();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u06E8\u073E\u081Cҽ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E15 RID: 3605 RVA: 0x000503B4 File Offset: 0x0004E5B4
	[Token(Token = "0x6000E15")]
	[Address(RVA = "0x1DA80C8", Offset = "0x1DA80C8", VA = "0x1DA80C8")]
	private void \u0834\u0817ރࡔ()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E16 RID: 3606 RVA: 0x000503CC File Offset: 0x0004E5CC
	[Token(Token = "0x6000E16")]
	[Address(RVA = "0x1DA80D4", Offset = "0x1DA80D4", VA = "0x1DA80D4")]
	private void ۆڛߟ\u05A0()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E17 RID: 3607 RVA: 0x000503E4 File Offset: 0x0004E5E4
	[Token(Token = "0x6000E17")]
	[Address(RVA = "0x1D9C7B4", Offset = "0x1D9C7B4", VA = "0x1D9C7B4")]
	private void ߡ\u0825\u0889Ԛ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E18 RID: 3608 RVA: 0x00050454 File Offset: 0x0004E654
	[Token(Token = "0x6000E18")]
	[Address(RVA = "0x1DA80E0", Offset = "0x1DA80E0", VA = "0x1DA80E0")]
	private void ӣՃ\u07FAԟ()
	{
		do
		{
			bool u0658_u059Bټ_u073B = this.\u0658\u059Bټ\u073B;
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.ش٢ز\u05C2();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
		}
		while (this.ז\u07ADࡒ\u061F != null);
	}

	// Token: 0x06000E19 RID: 3609 RVA: 0x00050778 File Offset: 0x0004E978
	[Token(Token = "0x6000E19")]
	[Address(RVA = "0x1D96818", Offset = "0x1D96818", VA = "0x1D96818")]
	private void דߪࡓ\u0749()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E1A RID: 3610 RVA: 0x000507F4 File Offset: 0x0004E9F4
	[Token(Token = "0x6000E1A")]
	[Address(RVA = "0x1D95504", Offset = "0x1D95504", VA = "0x1D95504")]
	private void \u05F8Թ\u088Bذ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E1B RID: 3611 RVA: 0x00050868 File Offset: 0x0004EA68
	[Token(Token = "0x6000E1B")]
	[Address(RVA = "0x1DA9360", Offset = "0x1DA9360", VA = "0x1DA9360")]
	private void րࢢ\u0830Ӥ()
	{
		while (this.\u0658\u059Bټ\u073B)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.ܩ\u07AEޣذ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		this.ܣݏ۳ݕ();
		FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
	}

	// Token: 0x06000E1C RID: 3612 RVA: 0x00050BA4 File Offset: 0x0004EDA4
	[Token(Token = "0x6000E1C")]
	[Address(RVA = "0x1DAA2E8", Offset = "0x1DAA2E8", VA = "0x1DAA2E8")]
	private void \u059AՏ\u0600\u0872()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E1D RID: 3613 RVA: 0x00050BBC File Offset: 0x0004EDBC
	[Token(Token = "0x6000E1D")]
	[Address(RVA = "0x1DAA2F4", Offset = "0x1DAA2F4", VA = "0x1DAA2F4")]
	private void قӮևݛ()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E1E RID: 3614 RVA: 0x00050BD4 File Offset: 0x0004EDD4
	[Token(Token = "0x6000E1E")]
	[Address(RVA = "0x1DAA300", Offset = "0x1DAA300", VA = "0x1DAA300")]
	private void \u0706\u05CDߜح()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.\u083CԯӰ\u05F5();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ش٢ز\u05C2();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E1F RID: 3615 RVA: 0x00050EFC File Offset: 0x0004F0FC
	[Token(Token = "0x6000E1F")]
	[Address(RVA = "0x1DAB29C", Offset = "0x1DAB29C", VA = "0x1DAB29C")]
	private void \u06D6ې\u083Bࠉ()
	{
	}

	// Token: 0x06000E20 RID: 3616 RVA: 0x00050F0C File Offset: 0x0004F10C
	[Token(Token = "0x6000E20")]
	[Address(RVA = "0x1D90E18", Offset = "0x1D90E18", VA = "0x1D90E18")]
	private void \u06E8\u073E\u081Cҽ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E21 RID: 3617 RVA: 0x00050F88 File Offset: 0x0004F188
	[Token(Token = "0x6000E21")]
	[Address(RVA = "0x1DAB2A4", Offset = "0x1DAB2A4", VA = "0x1DAB2A4")]
	private void إݩ\u0886ԟ()
	{
		while (this.\u0658\u059Bټ\u073B)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.ڼ\u0825\u05F3Ը();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		this.ע߅ࡋ\u05BC();
		FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
	}

	// Token: 0x06000E22 RID: 3618 RVA: 0x000512B8 File Offset: 0x0004F4B8
	[Token(Token = "0x6000E22")]
	[Address(RVA = "0x1DAC2E0", Offset = "0x1DAC2E0", VA = "0x1DAC2E0")]
	private void \u055C\u0670\u06EA\u05EC()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			this.\u07ACࠎ\u06E9ڙ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u0885\u081BӤܜ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E23 RID: 3619 RVA: 0x000515E0 File Offset: 0x0004F7E0
	[Token(Token = "0x6000E23")]
	[Address(RVA = "0x1DAD2F0", Offset = "0x1DAD2F0", VA = "0x1DAD2F0")]
	private void \u06E1ԁՈڄ()
	{
	}

	// Token: 0x06000E24 RID: 3620 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Token(Token = "0x6000E24")]
	[Address(RVA = "0x1DAD2F8", Offset = "0x1DAD2F8", VA = "0x1DAD2F8")]
	private void \u05A8\u06DDӚٵ()
	{
		for (;;)
		{
			if (this.\u0658\u059Bټ\u073B)
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.ܩ\u07AEޣذ();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
				Vector3 zero = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
				Vector3 zero2 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
				Vector3 zero3 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					break;
				}
			}
			else
			{
				this.\u05ADڴ\u0599ࢩ();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F13 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F14 = this.ז\u07ADࡒ\u061F;
				Vector3 zero4 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F15 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F16 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u4 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F17 = this.ז\u07ADࡒ\u061F;
				Vector3 zero5 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F18 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F19 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u5 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F20 = this.ז\u07ADࡒ\u061F;
				Vector3 zero6 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F21 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F22 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u6 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000E25 RID: 3621 RVA: 0x00051934 File Offset: 0x0004FB34
	[Token(Token = "0x6000E25")]
	[Address(RVA = "0x1DAE340", Offset = "0x1DAE340", VA = "0x1DAE340")]
	private void Start()
	{
	}

	// Token: 0x06000E26 RID: 3622 RVA: 0x00051944 File Offset: 0x0004FB44
	[Token(Token = "0x6000E26")]
	[Address(RVA = "0x1D96B6C", Offset = "0x1D96B6C", VA = "0x1D96B6C")]
	private void ࡒ\u0747ө\u088E()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E27 RID: 3623 RVA: 0x000519B4 File Offset: 0x0004FBB4
	[Token(Token = "0x6000E27")]
	[Address(RVA = "0x1DAE348", Offset = "0x1DAE348", VA = "0x1DAE348")]
	public FingerMovementManager()
	{
	}

	// Token: 0x06000E28 RID: 3624 RVA: 0x000519D4 File Offset: 0x0004FBD4
	[Token(Token = "0x6000E28")]
	[Address(RVA = "0x1DAE35C", Offset = "0x1DAE35C", VA = "0x1DAE35C")]
	private void \u085E\u065Eޞޥ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E29 RID: 3625 RVA: 0x00051A44 File Offset: 0x0004FC44
	[Token(Token = "0x6000E29")]
	[Address(RVA = "0x1D8CD08", Offset = "0x1D8CD08", VA = "0x1D8CD08")]
	private void \u07BF\u05A9\u059Fࡁ()
	{
		if (!true)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E2A RID: 3626 RVA: 0x00051AB4 File Offset: 0x0004FCB4
	[Token(Token = "0x6000E2A")]
	[Address(RVA = "0x1DAE658", Offset = "0x1DAE658", VA = "0x1DAE658")]
	private void Ծէ\u05FE\u07A9()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E2B RID: 3627 RVA: 0x00051B30 File Offset: 0x0004FD30
	[Token(Token = "0x6000E2B")]
	[Address(RVA = "0x1DAE9A8", Offset = "0x1DAE9A8", VA = "0x1DAE9A8")]
	private void \u05F8ࡂࡧ\u07FA()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			this.ࢥ\u05B5ސޥ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ߞ\u087Bࡅ\u0895();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E2C RID: 3628 RVA: 0x00051E54 File Offset: 0x00050054
	[Token(Token = "0x6000E2C")]
	[Address(RVA = "0x1DAF8CC", Offset = "0x1DAF8CC", VA = "0x1DAF8CC")]
	private void \u0558ݕݤݮ()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E2D RID: 3629 RVA: 0x00051E6C File Offset: 0x0005006C
	[Token(Token = "0x6000E2D")]
	[Address(RVA = "0x1DAF8D8", Offset = "0x1DAF8D8", VA = "0x1DAF8D8")]
	private void ࡔ\u0709\u06DBԏ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E2E RID: 3630 RVA: 0x00051ED8 File Offset: 0x000500D8
	[Token(Token = "0x6000E2E")]
	[Address(RVA = "0x1DAFC28", Offset = "0x1DAFC28", VA = "0x1DAFC28")]
	private void ޡࠅ\u089Aߔ()
	{
	}

	// Token: 0x06000E2F RID: 3631 RVA: 0x00051EE8 File Offset: 0x000500E8
	[Token(Token = "0x6000E2F")]
	[Address(RVA = "0x1DAFC30", Offset = "0x1DAFC30", VA = "0x1DAFC30")]
	private void \u0890ښՑ\u0835()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E30 RID: 3632 RVA: 0x00051F60 File Offset: 0x00050160
	[Token(Token = "0x6000E30")]
	[Address(RVA = "0x1DAFF6C", Offset = "0x1DAFF6C", VA = "0x1DAFF6C")]
	private void ڽ\u0894ىޡ()
	{
		for (;;)
		{
			if (this.\u0658\u059Bټ\u073B)
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
				Vector3 zero = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
				Vector3 zero2 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
				Vector3 zero3 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					break;
				}
			}
			else
			{
				this.\u0890ښՑ\u0835();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F13 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F14 = this.ז\u07ADࡒ\u061F;
				Vector3 zero4 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F15 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F16 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u4 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F17 = this.ז\u07ADࡒ\u061F;
				Vector3 zero5 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F18 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F19 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u5 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F20 = this.ז\u07ADࡒ\u061F;
				Vector3 zero6 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F21 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F22 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u6 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000E31 RID: 3633 RVA: 0x0005229C File Offset: 0x0005049C
	[Token(Token = "0x6000E31")]
	[Address(RVA = "0x1D91170", Offset = "0x1D91170", VA = "0x1D91170")]
	private void ߡهھߍ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E32 RID: 3634 RVA: 0x00052314 File Offset: 0x00050514
	[Token(Token = "0x6000E32")]
	[Address(RVA = "0x1DB0F4C", Offset = "0x1DB0F4C", VA = "0x1DB0F4C")]
	private void բצؽӴ()
	{
		while (this.\u0658\u059Bټ\u073B)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.\u083CԯӰ\u05F5();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		this.ࡔ\u0709\u06DBԏ();
		FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
	}

	// Token: 0x06000E33 RID: 3635 RVA: 0x00052654 File Offset: 0x00050854
	[Token(Token = "0x6000E33")]
	[Address(RVA = "0x1DB1F48", Offset = "0x1DB1F48", VA = "0x1DB1F48")]
	private void LateUpdate()
	{
		for (;;)
		{
			if (this.\u0658\u059Bټ\u073B)
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.ࡔ\u0709\u06DBԏ();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
				Vector3 zero = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
				Vector3 zero2 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
				Vector3 zero3 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					break;
				}
			}
			else
			{
				this.ࡔ\u0709\u06DBԏ();
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F13 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F14 = this.ז\u07ADࡒ\u061F;
				Vector3 zero4 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F15 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F16 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u4 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F17 = this.ז\u07ADࡒ\u061F;
				Vector3 zero5 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F18 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F19 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u5 = this.\u05A9ݐ\u061A\u0893;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F20 = this.ז\u07ADࡒ\u061F;
				Vector3 zero6 = Vector3.zero;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F21 = this.ז\u07ADࡒ\u061F;
				FingerMovementManager.RightHand ז_u07ADࡒ_u061F22 = this.ז\u07ADࡒ\u061F;
				float u05A9ݐ_u061A_u6 = this.\u05A9ݐ\u061A\u0893;
				if (this.ז\u07ADࡒ\u061F == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000E34 RID: 3636 RVA: 0x000529A4 File Offset: 0x00050BA4
	[Token(Token = "0x6000E34")]
	[Address(RVA = "0x1DB2FE0", Offset = "0x1DB2FE0", VA = "0x1DB2FE0")]
	private void گ\u085E\u073Dڊ()
	{
	}

	// Token: 0x06000E35 RID: 3637 RVA: 0x000529B4 File Offset: 0x00050BB4
	[Token(Token = "0x6000E35")]
	[Address(RVA = "0x1DB2FE8", Offset = "0x1DB2FE8", VA = "0x1DB2FE8")]
	private void ߉ې\u07F6Ӭ()
	{
	}

	// Token: 0x06000E36 RID: 3638 RVA: 0x000529C4 File Offset: 0x00050BC4
	[Token(Token = "0x6000E36")]
	[Address(RVA = "0x1DB2FF0", Offset = "0x1DB2FF0", VA = "0x1DB2FF0")]
	private void ݔ߄ޱۓ()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.\u06E8\u073E\u081Cҽ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u05ADڴ\u0599ࢩ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E37 RID: 3639 RVA: 0x00052CD0 File Offset: 0x00050ED0
	[Token(Token = "0x6000E37")]
	[Address(RVA = "0x1DB3FBC", Offset = "0x1DB3FBC", VA = "0x1DB3FBC")]
	private void ض\u064Fޢշ()
	{
		while (!this.\u0658\u059Bټ\u073B)
		{
			this.ࡒ\u0747ө\u088E();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F3 = this.ז\u07ADࡒ\u061F;
			Vector3 zero = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F4 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F5 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F6 = this.ז\u07ADࡒ\u061F;
			Vector3 zero2 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F7 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F8 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u2 = this.\u05A9ݐ\u061A\u0893;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F9 = this.ז\u07ADࡒ\u061F;
			Vector3 zero3 = Vector3.zero;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F10 = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F11 = this.ז\u07ADࡒ\u061F;
			float u05A9ݐ_u061A_u3 = this.\u05A9ݐ\u061A\u0893;
			if (this.ז\u07ADࡒ\u061F == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.\u05F8Թ\u088Bذ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F12 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E38 RID: 3640 RVA: 0x00052FF4 File Offset: 0x000511F4
	[Token(Token = "0x6000E38")]
	[Address(RVA = "0x1DA3E68", Offset = "0x1DA3E68", VA = "0x1DA3E68")]
	private void ڼ\u0825\u05F3Ը()
	{
		bool פࢴ_u060Fܘ = this.פࢴ\u060Fܘ;
		InputDevice inputDevice;
		if (inputDevice == null)
		{
		}
		FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
		FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
	}

	// Token: 0x06000E39 RID: 3641 RVA: 0x00053070 File Offset: 0x00051270
	[Token(Token = "0x6000E39")]
	[Address(RVA = "0x1DA288C", Offset = "0x1DA288C", VA = "0x1DA288C")]
	private void \u06EB\u088Eפ\u070F()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E3A RID: 3642 RVA: 0x000530E0 File Offset: 0x000512E0
	[Token(Token = "0x6000E3A")]
	[Address(RVA = "0x1D8CA18", Offset = "0x1D8CA18", VA = "0x1D8CA18")]
	private void ړղ\u064Eշ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E3B RID: 3643 RVA: 0x00053150 File Offset: 0x00051350
	[Token(Token = "0x6000E3B")]
	[Address(RVA = "0x1DB4F94", Offset = "0x1DB4F94", VA = "0x1DB4F94")]
	private void \u0818ՠש\u0731()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E3C RID: 3644 RVA: 0x00053168 File Offset: 0x00051368
	[Token(Token = "0x6000E3C")]
	[Address(RVA = "0x1DB4FA0", Offset = "0x1DB4FA0", VA = "0x1DB4FA0")]
	private void جջՌخ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E3D RID: 3645 RVA: 0x000531E0 File Offset: 0x000513E0
	[Token(Token = "0x6000E3D")]
	[Address(RVA = "0x1DB52DC", Offset = "0x1DB52DC", VA = "0x1DB52DC")]
	private void ԦӔԁֆ()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E3E RID: 3646 RVA: 0x000531F8 File Offset: 0x000513F8
	[Token(Token = "0x6000E3E")]
	[Address(RVA = "0x1DB52E8", Offset = "0x1DB52E8", VA = "0x1DB52E8")]
	private void \u082Eכ\u0640ܮ()
	{
		if (!this.\u0658\u059Bټ\u073B)
		{
			this.\u0885\u081BӤܜ();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.ӣڢࡁ\u0878();
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E3F RID: 3647 RVA: 0x00053524 File Offset: 0x00051724
	[Token(Token = "0x6000E3F")]
	[Address(RVA = "0x1D941A4", Offset = "0x1D941A4", VA = "0x1D941A4")]
	private void ݥԥ\u065A\u05C8()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E40 RID: 3648 RVA: 0x0005359C File Offset: 0x0005179C
	[Token(Token = "0x6000E40")]
	[Address(RVA = "0x1DA8FF4", Offset = "0x1DA8FF4", VA = "0x1DA8FF4")]
	private void ش٢ز\u05C2()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E41 RID: 3649 RVA: 0x00053614 File Offset: 0x00051814
	[Token(Token = "0x6000E41")]
	[Address(RVA = "0x1D98E60", Offset = "0x1D98E60", VA = "0x1D98E60")]
	private void \u087E\u05C7\u0836ٮ()
	{
		if (!this.פࢴ\u060Fܘ)
		{
			InputDevice inputDevice;
			if (inputDevice == null)
			{
			}
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F = this.ז\u07ADࡒ\u061F;
			FingerMovementManager.RightHand ז_u07ADࡒ_u061F2 = this.ז\u07ADࡒ\u061F;
			return;
		}
	}

	// Token: 0x06000E42 RID: 3650 RVA: 0x00053690 File Offset: 0x00051890
	[Token(Token = "0x6000E42")]
	[Address(RVA = "0x1DB6268", Offset = "0x1DB6268", VA = "0x1DB6268")]
	private void \u05C1ܡԘޘ()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x06000E43 RID: 3651 RVA: 0x000536A8 File Offset: 0x000518A8
	[Token(Token = "0x6000E43")]
	[Address(RVA = "0x1DB6274", Offset = "0x1DB6274", VA = "0x1DB6274")]
	private void վࡌڬ\u0591()
	{
		long פࢴ_u060Fܘ = 1L;
		this.פࢴ\u060Fܘ = (פࢴ_u060Fܘ != 0L);
	}

	// Token: 0x040001EE RID: 494
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001EE")]
	public bool \u0658\u059Bټ\u073B;

	// Token: 0x040001EF RID: 495
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x40001EF")]
	public float \u05A9ݐ\u061A\u0893 = (float)5243;

	// Token: 0x040001F0 RID: 496
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001F0")]
	public FingerMovementManager.RightHand ז\u07ADࡒ\u061F;

	// Token: 0x040001F1 RID: 497
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40001F1")]
	[Space]
	public FingerMovementManager.LeftHand ࡐկսӬ;

	// Token: 0x040001F2 RID: 498
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40001F2")]
	public bool פࢴ\u060Fܘ;

	// Token: 0x0200005F RID: 95
	[Token(Token = "0x200005F")]
	public enum \u07ABܬ\u07AF\u05A1
	{
		// Token: 0x040001F4 RID: 500
		[Token(Token = "0x40001F4")]
		Ն\u074A\u05AFܗ,
		// Token: 0x040001F5 RID: 501
		[Token(Token = "0x40001F5")]
		ߟӎݲڐ,
		// Token: 0x040001F6 RID: 502
		[Token(Token = "0x40001F6")]
		Ә\u0619ݓޙ,
		// Token: 0x040001F7 RID: 503
		[Token(Token = "0x40001F7")]
		ՆࢤՠԵ,
		// Token: 0x040001F8 RID: 504
		[Token(Token = "0x40001F8")]
		[InspectorName("Primary & Secondary")]
		ڦצߔ\u0702
	}

	// Token: 0x02000060 RID: 96
	[Token(Token = "0x2000060")]
	[Serializable]
	public struct RightHand
	{
		// Token: 0x040001F9 RID: 505
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40001F9")]
		public FingerMovementManager.RightHand.Finger[] fingers;

		// Token: 0x02000061 RID: 97
		[Token(Token = "0x2000061")]
		[Serializable]
		public struct Finger
		{
			// Token: 0x040001FA RID: 506
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x40001FA")]
			public Transform[] bones;

			// Token: 0x040001FB RID: 507
			[FieldOffset(Offset = "0x8")]
			[Token(Token = "0x40001FB")]
			public Vector3 rotation;

			// Token: 0x040001FC RID: 508
			[FieldOffset(Offset = "0x14")]
			[Token(Token = "0x40001FC")]
			public Quaternion FirstBoneoffset;

			// Token: 0x040001FD RID: 509
			[FieldOffset(Offset = "0x24")]
			[Token(Token = "0x40001FD")]
			[HideInInspector]
			public float var;

			// Token: 0x040001FE RID: 510
			[FieldOffset(Offset = "0x28")]
			[Token(Token = "0x40001FE")]
			public FingerMovementManager.\u07ABܬ\u07AF\u05A1 button;
		}
	}

	// Token: 0x02000062 RID: 98
	[Token(Token = "0x2000062")]
	[Serializable]
	public struct LeftHand
	{
		// Token: 0x040001FF RID: 511
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40001FF")]
		public FingerMovementManager.LeftHand.Finger[] fingers;

		// Token: 0x02000063 RID: 99
		[Token(Token = "0x2000063")]
		[Serializable]
		public struct Finger
		{
			// Token: 0x04000200 RID: 512
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4000200")]
			public Transform[] bones;

			// Token: 0x04000201 RID: 513
			[FieldOffset(Offset = "0x8")]
			[Token(Token = "0x4000201")]
			public Vector3 rotation;

			// Token: 0x04000202 RID: 514
			[FieldOffset(Offset = "0x14")]
			[Token(Token = "0x4000202")]
			public Quaternion FirstBoneoffset;

			// Token: 0x04000203 RID: 515
			[FieldOffset(Offset = "0x24")]
			[Token(Token = "0x4000203")]
			[HideInInspector]
			public float var;

			// Token: 0x04000204 RID: 516
			[FieldOffset(Offset = "0x28")]
			[Token(Token = "0x4000204")]
			public FingerMovementManager.\u07ABܬ\u07AF\u05A1 button;
		}
	}
}
