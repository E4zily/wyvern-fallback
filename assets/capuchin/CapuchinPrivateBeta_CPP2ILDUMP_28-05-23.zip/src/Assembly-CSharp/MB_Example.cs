﻿using System;
using Cpp2IlInjected;
using PlayFab.EconomyModels;
using UnityEngine;

// Token: 0x0200007A RID: 122
[Token(Token = "0x200007A")]
public class MB_Example : MonoBehaviour
{
	// Token: 0x06001280 RID: 4736 RVA: 0x0006A9F0 File Offset: 0x00068BF0
	[Token(Token = "0x6001280")]
	[Address(RVA = "0x2C55D78", Offset = "0x2C55D78", VA = "0x2C55D78")]
	private void Ԁ\u05EB\u085Eՠ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001281 RID: 4737 RVA: 0x0006AA18 File Offset: 0x00068C18
	[Token(Token = "0x6001281")]
	[Address(RVA = "0x2C55E08", Offset = "0x2C55E08", VA = "0x2C55E08")]
	private void LateUpdate()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001282 RID: 4738 RVA: 0x0006AA40 File Offset: 0x00068C40
	[Token(Token = "0x6001282")]
	[Address(RVA = "0x2C55E94", Offset = "0x2C55E94", VA = "0x2C55E94")]
	private void ߒࠅߝ۹()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001283 RID: 4739 RVA: 0x0006AA68 File Offset: 0x00068C68
	[Token(Token = "0x6001283")]
	[Address(RVA = "0x2C55F24", Offset = "0x2C55F24", VA = "0x2C55F24")]
	private void ߖհݣ߀()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001284 RID: 4740 RVA: 0x0006AA90 File Offset: 0x00068C90
	[Token(Token = "0x6001284")]
	[Address(RVA = "0x2C55F80", Offset = "0x2C55F80", VA = "0x2C55F80")]
	private void ࢥ\u081CՕࡋ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001285 RID: 4741 RVA: 0x0006AAB8 File Offset: 0x00068CB8
	[Token(Token = "0x6001285")]
	[Address(RVA = "0x2C55FDC", Offset = "0x2C55FDC", VA = "0x2C55FDC")]
	private void \u05C4עڻ\u0732()
	{
	}

	// Token: 0x06001286 RID: 4742 RVA: 0x0006AAC8 File Offset: 0x00068CC8
	[Token(Token = "0x6001286")]
	[Address(RVA = "0x2C560BC", Offset = "0x2C560BC", VA = "0x2C560BC")]
	private void ܞݗ\u0743Ӽ()
	{
	}

	// Token: 0x06001287 RID: 4743 RVA: 0x0006AAD8 File Offset: 0x00068CD8
	[Token(Token = "0x6001287")]
	[Address(RVA = "0x2C5619C", Offset = "0x2C5619C", VA = "0x2C5619C")]
	private void ӣՃ\u07FAԟ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001288 RID: 4744 RVA: 0x0006AB00 File Offset: 0x00068D00
	[Token(Token = "0x6001288")]
	[Address(RVA = "0x2C5622C", Offset = "0x2C5622C", VA = "0x2C5622C")]
	private void րࢢ\u0830Ӥ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001289 RID: 4745 RVA: 0x0006AB28 File Offset: 0x00068D28
	[Token(Token = "0x6001289")]
	[Address(RVA = "0x2C562BC", Offset = "0x2C562BC", VA = "0x2C562BC")]
	private void \u0741\u07A7\u0749ݧ()
	{
	}

	// Token: 0x0600128A RID: 4746 RVA: 0x0006AB38 File Offset: 0x00068D38
	[Token(Token = "0x600128A")]
	[Address(RVA = "0x2C5639C", Offset = "0x2C5639C", VA = "0x2C5639C")]
	private void ܩ\u06E2߈ջ()
	{
	}

	// Token: 0x0600128B RID: 4747 RVA: 0x0006AB48 File Offset: 0x00068D48
	[Token(Token = "0x600128B")]
	[Address(RVA = "0x2C5647C", Offset = "0x2C5647C", VA = "0x2C5647C")]
	private void \u05F8ࡂࡧ\u07FA()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x0600128C RID: 4748 RVA: 0x0006AB70 File Offset: 0x00068D70
	[Token(Token = "0x600128C")]
	[Address(RVA = "0x2C5650C", Offset = "0x2C5650C", VA = "0x2C5650C")]
	private void ג\u0816\u0891ۀ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x0600128D RID: 4749 RVA: 0x0006AB98 File Offset: 0x00068D98
	[Token(Token = "0x600128D")]
	[Address(RVA = "0x2C5659C", Offset = "0x2C5659C", VA = "0x2C5659C")]
	private void Ձߎࢺ\u060D()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x0600128E RID: 4750 RVA: 0x0006ABC0 File Offset: 0x00068DC0
	[Token(Token = "0x600128E")]
	[Address(RVA = "0x2C5662C", Offset = "0x2C5662C", VA = "0x2C5662C")]
	private void ݱ\u0832ݥ\u08B5()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x0600128F RID: 4751 RVA: 0x0006ABE8 File Offset: 0x00068DE8
	[Token(Token = "0x600128F")]
	[Address(RVA = "0x2C56688", Offset = "0x2C56688", VA = "0x2C56688")]
	private void \u07EB\u0597ࢳڪ()
	{
	}

	// Token: 0x06001290 RID: 4752 RVA: 0x0006ABF8 File Offset: 0x00068DF8
	[Token(Token = "0x6001290")]
	[Address(RVA = "0x2C56768", Offset = "0x2C56768", VA = "0x2C56768")]
	private void عۻԂ\u055E()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001291 RID: 4753 RVA: 0x0006AC20 File Offset: 0x00068E20
	[Token(Token = "0x6001291")]
	[Address(RVA = "0x2C567C4", Offset = "0x2C567C4", VA = "0x2C567C4")]
	private void ޤչ߉\u0702()
	{
	}

	// Token: 0x06001292 RID: 4754 RVA: 0x0006AC30 File Offset: 0x00068E30
	[Token(Token = "0x6001292")]
	[Address(RVA = "0x2C568A4", Offset = "0x2C568A4", VA = "0x2C568A4")]
	private void ݳ\u060E\u06FE\u065D()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001293 RID: 4755 RVA: 0x0006AC58 File Offset: 0x00068E58
	[Token(Token = "0x6001293")]
	[Address(RVA = "0x2C56934", Offset = "0x2C56934", VA = "0x2C56934")]
	private void Ӄۇރࡑ()
	{
	}

	// Token: 0x06001294 RID: 4756 RVA: 0x0006AC68 File Offset: 0x00068E68
	[Token(Token = "0x6001294")]
	[Address(RVA = "0x2C56A14", Offset = "0x2C56A14", VA = "0x2C56A14")]
	private void \u0834\u0817ރࡔ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001295 RID: 4757 RVA: 0x0006AC90 File Offset: 0x00068E90
	[Token(Token = "0x6001295")]
	[Address(RVA = "0x2C56A70", Offset = "0x2C56A70", VA = "0x2C56A70")]
	private void \u0613\u05CBݠۇ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001296 RID: 4758 RVA: 0x0006ACB8 File Offset: 0x00068EB8
	[Token(Token = "0x6001296")]
	[Address(RVA = "0x2C56B00", Offset = "0x2C56B00", VA = "0x2C56B00")]
	private void ى\u05F4ڷ߉()
	{
	}

	// Token: 0x06001297 RID: 4759 RVA: 0x0006ACC8 File Offset: 0x00068EC8
	[Token(Token = "0x6001297")]
	[Address(RVA = "0x2C56BE0", Offset = "0x2C56BE0", VA = "0x2C56BE0")]
	private void Start()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001298 RID: 4760 RVA: 0x0006ACF0 File Offset: 0x00068EF0
	[Token(Token = "0x6001298")]
	[Address(RVA = "0x2C56C3C", Offset = "0x2C56C3C", VA = "0x2C56C3C")]
	private void ࡅݐ\u082Dք()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x06001299 RID: 4761 RVA: 0x0006AD18 File Offset: 0x00068F18
	[Token(Token = "0x6001299")]
	[Address(RVA = "0x2C56C98", Offset = "0x2C56C98", VA = "0x2C56C98")]
	private void \u065F\u0839ܤ\u073C()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x0600129A RID: 4762 RVA: 0x0006AD40 File Offset: 0x00068F40
	[Token(Token = "0x600129A")]
	[Address(RVA = "0x2C56CF4", Offset = "0x2C56CF4", VA = "0x2C56CF4")]
	private void ԗӣ\u07BAߩ()
	{
		if (typeof(SubmitItemReviewVoteRequest).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600129B RID: 4763 RVA: 0x0006AD54 File Offset: 0x00068F54
	[Token(Token = "0x600129B")]
	[Address(RVA = "0x2C56DD4", Offset = "0x2C56DD4", VA = "0x2C56DD4")]
	public MB_Example()
	{
	}

	// Token: 0x0600129C RID: 4764 RVA: 0x0006AD68 File Offset: 0x00068F68
	[Token(Token = "0x600129C")]
	[Address(RVA = "0x2C56DDC", Offset = "0x2C56DDC", VA = "0x2C56DDC")]
	private void ߅\u070Fޑ\u0876()
	{
	}

	// Token: 0x0600129D RID: 4765 RVA: 0x0006AD78 File Offset: 0x00068F78
	[Token(Token = "0x600129D")]
	[Address(RVA = "0x2C56EBC", Offset = "0x2C56EBC", VA = "0x2C56EBC")]
	private void ٧ص\u073FӜ()
	{
	}

	// Token: 0x0600129E RID: 4766 RVA: 0x0006AD88 File Offset: 0x00068F88
	[Token(Token = "0x600129E")]
	[Address(RVA = "0x2C56F9C", Offset = "0x2C56F9C", VA = "0x2C56F9C")]
	private void OnGUI()
	{
	}

	// Token: 0x0600129F RID: 4767 RVA: 0x0006AD98 File Offset: 0x00068F98
	[Token(Token = "0x600129F")]
	[Address(RVA = "0x2C5707C", Offset = "0x2C5707C", VA = "0x2C5707C")]
	private void \u0607\u0747\u058Aף()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012A0 RID: 4768 RVA: 0x0006ADC0 File Offset: 0x00068FC0
	[Token(Token = "0x60012A0")]
	[Address(RVA = "0x2C5710C", Offset = "0x2C5710C", VA = "0x2C5710C")]
	private void \u0558ݕݤݮ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012A1 RID: 4769 RVA: 0x0006ADE8 File Offset: 0x00068FE8
	[Token(Token = "0x60012A1")]
	[Address(RVA = "0x2C57168", Offset = "0x2C57168", VA = "0x2C57168")]
	private void וࡪךӧ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012A2 RID: 4770 RVA: 0x0006AE10 File Offset: 0x00069010
	[Token(Token = "0x60012A2")]
	[Address(RVA = "0x2C571C4", Offset = "0x2C571C4", VA = "0x2C571C4")]
	private void ٧ؠԬט()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012A3 RID: 4771 RVA: 0x0006AE38 File Offset: 0x00069038
	[Token(Token = "0x60012A3")]
	[Address(RVA = "0x2C57254", Offset = "0x2C57254", VA = "0x2C57254")]
	private void ࢧӾڈց()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012A4 RID: 4772 RVA: 0x0006AE60 File Offset: 0x00069060
	[Token(Token = "0x60012A4")]
	[Address(RVA = "0x2C572B0", Offset = "0x2C572B0", VA = "0x2C572B0")]
	private void Ӯޱ\u0703ࢪ()
	{
	}

	// Token: 0x060012A5 RID: 4773 RVA: 0x0006AE70 File Offset: 0x00069070
	[Token(Token = "0x60012A5")]
	[Address(RVA = "0x2C57390", Offset = "0x2C57390", VA = "0x2C57390")]
	private void ࢺ\u0599\u07A6\u0650()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012A6 RID: 4774 RVA: 0x0006AE98 File Offset: 0x00069098
	[Token(Token = "0x60012A6")]
	[Address(RVA = "0x2C57420", Offset = "0x2C57420", VA = "0x2C57420")]
	private void چ\u05AEךڰ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012A7 RID: 4775 RVA: 0x0006AEC0 File Offset: 0x000690C0
	[Token(Token = "0x60012A7")]
	[Address(RVA = "0x2C5747C", Offset = "0x2C5747C", VA = "0x2C5747C")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012A8 RID: 4776 RVA: 0x0006AEE8 File Offset: 0x000690E8
	[Token(Token = "0x60012A8")]
	[Address(RVA = "0x2C574D8", Offset = "0x2C574D8", VA = "0x2C574D8")]
	private void ޒӠۅߐ()
	{
	}

	// Token: 0x060012A9 RID: 4777 RVA: 0x0006AEF8 File Offset: 0x000690F8
	[Token(Token = "0x60012A9")]
	[Address(RVA = "0x2C575B8", Offset = "0x2C575B8", VA = "0x2C575B8")]
	private void \u05BA\u0893ހՎ()
	{
	}

	// Token: 0x060012AA RID: 4778 RVA: 0x0006AF08 File Offset: 0x00069108
	[Token(Token = "0x60012AA")]
	[Address(RVA = "0x2C57698", Offset = "0x2C57698", VA = "0x2C57698")]
	private void Ԅڌ\u0659߀()
	{
	}

	// Token: 0x060012AB RID: 4779 RVA: 0x0006AF18 File Offset: 0x00069118
	[Token(Token = "0x60012AB")]
	[Address(RVA = "0x2C57778", Offset = "0x2C57778", VA = "0x2C57778")]
	private void ބܝۄ\u0703()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012AC RID: 4780 RVA: 0x0006AF40 File Offset: 0x00069140
	[Token(Token = "0x60012AC")]
	[Address(RVA = "0x2C57808", Offset = "0x2C57808", VA = "0x2C57808")]
	private void \u070Fߨ\u05B0ۈ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012AD RID: 4781 RVA: 0x0006AF68 File Offset: 0x00069168
	[Token(Token = "0x60012AD")]
	[Address(RVA = "0x2C57864", Offset = "0x2C57864", VA = "0x2C57864")]
	private void \u05CAө\u0872\u058F()
	{
	}

	// Token: 0x060012AE RID: 4782 RVA: 0x0006AF78 File Offset: 0x00069178
	[Token(Token = "0x60012AE")]
	[Address(RVA = "0x2C57944", Offset = "0x2C57944", VA = "0x2C57944")]
	private void \u07ABג\u07F4ւ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x060012AF RID: 4783 RVA: 0x0006AFA0 File Offset: 0x000691A0
	[Token(Token = "0x60012AF")]
	[Address(RVA = "0x2C579D4", Offset = "0x2C579D4", VA = "0x2C579D4")]
	private void קܥ\u061Dߧ()
	{
		MB3_MeshBaker mb3_MeshBaker = this.پԤܥز;
		GameObject[] u07F5ӊ_u0701խ = this.\u07F5ӊ\u0701խ;
		MB3_MeshBaker mb3_MeshBaker2 = this.پԤܥز;
	}

	// Token: 0x0400025A RID: 602
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400025A")]
	public MB3_MeshBaker پԤܥز;

	// Token: 0x0400025B RID: 603
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400025B")]
	public GameObject[] \u07F5ӊ\u0701խ;
}
