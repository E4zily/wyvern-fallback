﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x020000A9 RID: 169
[Token(Token = "0x20000A9")]
public class ComputerTextField : MonoBehaviour
{
	// Token: 0x06001911 RID: 6417 RVA: 0x00088D44 File Offset: 0x00086F44
	[Token(Token = "0x6001911")]
	[Address(RVA = "0x2935024", Offset = "0x2935024", VA = "0x2935024")]
	private void ޡࠅ\u089Aߔ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("_Tint");
			return;
		}
	}

	// Token: 0x06001912 RID: 6418 RVA: 0x00088D74 File Offset: 0x00086F74
	[Token(Token = "0x6001912")]
	[Address(RVA = "0x29350CC", Offset = "0x29350CC", VA = "0x29350CC")]
	private void ݤۅࢦӃ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("username");
			return;
		}
	}

	// Token: 0x06001913 RID: 6419 RVA: 0x00088DA4 File Offset: 0x00086FA4
	[Token(Token = "0x6001913")]
	[Address(RVA = "0x2935174", Offset = "0x2935174", VA = "0x2935174")]
	private void نո\u0599\u0589()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Player");
			return;
		}
	}

	// Token: 0x06001914 RID: 6420 RVA: 0x00088DD4 File Offset: 0x00086FD4
	[Token(Token = "0x6001914")]
	[Address(RVA = "0x293521C", Offset = "0x293521C", VA = "0x293521C")]
	private void ӭࡖݲ\u05BD()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("false");
			return;
		}
	}

	// Token: 0x06001915 RID: 6421 RVA: 0x00088E04 File Offset: 0x00087004
	[Token(Token = "0x6001915")]
	[Address(RVA = "0x29352C4", Offset = "0x29352C4", VA = "0x29352C4")]
	private void عۻԂ\u055E()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Game Started");
			return;
		}
	}

	// Token: 0x06001916 RID: 6422 RVA: 0x00088E34 File Offset: 0x00087034
	[Token(Token = "0x6001916")]
	[Address(RVA = "0x293536C", Offset = "0x293536C", VA = "0x293536C")]
	private void Ԯ\u0883\u0591\u066C()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Target");
			return;
		}
	}

	// Token: 0x06001917 RID: 6423 RVA: 0x00088E64 File Offset: 0x00087064
	[Token(Token = "0x6001917")]
	[Address(RVA = "0x2935414", Offset = "0x2935414", VA = "0x2935414")]
	private void ߖհݣ߀()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Key");
			return;
		}
	}

	// Token: 0x06001918 RID: 6424 RVA: 0x00088E94 File Offset: 0x00087094
	[Token(Token = "0x6001918")]
	[Address(RVA = "0x29354BC", Offset = "0x29354BC", VA = "0x29354BC")]
	private void ڣֆ\u07F4ڌ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Agreed");
			return;
		}
	}

	// Token: 0x06001919 RID: 6425 RVA: 0x00088EC4 File Offset: 0x000870C4
	[Token(Token = "0x6001919")]
	[Address(RVA = "0x2935564", Offset = "0x2935564", VA = "0x2935564")]
	private void ࡅݐ\u082Dք()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("ChangeToTagged");
			return;
		}
	}

	// Token: 0x0600191A RID: 6426 RVA: 0x00088EF4 File Offset: 0x000870F4
	[Token(Token = "0x600191A")]
	[Address(RVA = "0x293560C", Offset = "0x293560C", VA = "0x293560C")]
	private void \u086Bԍࡊڭ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("username");
			return;
		}
	}

	// Token: 0x0600191B RID: 6427 RVA: 0x00088F24 File Offset: 0x00087124
	[Token(Token = "0x600191B")]
	[Address(RVA = "0x29356B4", Offset = "0x29356B4", VA = "0x29356B4")]
	private void \u065F\u0839ܤ\u073C()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("duration done");
			return;
		}
	}

	// Token: 0x0600191C RID: 6428 RVA: 0x00088F54 File Offset: 0x00087154
	[Token(Token = "0x600191C")]
	[Address(RVA = "0x293575C", Offset = "0x293575C", VA = "0x293575C")]
	private void \u05C8\u05BFࠁف()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("META");
			return;
		}
	}

	// Token: 0x0600191D RID: 6429 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600191D")]
	[Address(RVA = "0x2935804", Offset = "0x2935804", VA = "0x2935804")]
	private void حتݻ\u05B0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600191E RID: 6430 RVA: 0x00088F84 File Offset: 0x00087184
	[Token(Token = "0x600191E")]
	[Address(RVA = "0x29358AC", Offset = "0x29358AC", VA = "0x29358AC")]
	private void ۊո\u0612\u0595()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("isLava");
			return;
		}
	}

	// Token: 0x0600191F RID: 6431 RVA: 0x00088FB4 File Offset: 0x000871B4
	[Token(Token = "0x600191F")]
	[Address(RVA = "0x2935954", Offset = "0x2935954", VA = "0x2935954")]
	private void \u066D\u05BDې߃()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("FingerTip");
			return;
		}
	}

	// Token: 0x06001920 RID: 6432 RVA: 0x00088FE4 File Offset: 0x000871E4
	[Token(Token = "0x6001920")]
	[Address(RVA = "0x29359FC", Offset = "0x29359FC", VA = "0x29359FC")]
	private void \u0558ݕݤݮ()
	{
		bool չߒԢ_u07EE = this.ՉߒԢ\u07EE;
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		string @string = PlayerPrefs.GetString("Name Changing Error. Error: ");
	}

	// Token: 0x06001921 RID: 6433 RVA: 0x00089014 File Offset: 0x00087214
	[Token(Token = "0x6001921")]
	[Address(RVA = "0x2935AA4", Offset = "0x2935AA4", VA = "0x2935AA4")]
	private void \u05ABݿࡋ\u06E9()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Horizontal");
			return;
		}
	}

	// Token: 0x06001922 RID: 6434 RVA: 0x00089044 File Offset: 0x00087244
	[Token(Token = "0x6001922")]
	[Address(RVA = "0x2935B4C", Offset = "0x2935B4C", VA = "0x2935B4C")]
	private void ࢥ\u081CՕࡋ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("isLava");
			return;
		}
	}

	// Token: 0x06001923 RID: 6435 RVA: 0x00089074 File Offset: 0x00087274
	[Token(Token = "0x6001923")]
	[Address(RVA = "0x2935BF4", Offset = "0x2935BF4", VA = "0x2935BF4")]
	private void ڍ\u058Bݗࡣ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("DISABLE");
		}
	}

	// Token: 0x06001924 RID: 6436 RVA: 0x000890A4 File Offset: 0x000872A4
	[Token(Token = "0x6001924")]
	[Address(RVA = "0x2935C9C", Offset = "0x2935C9C", VA = "0x2935C9C")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("PURCHASED");
			return;
		}
	}

	// Token: 0x06001925 RID: 6437 RVA: 0x000890D4 File Offset: 0x000872D4
	[Token(Token = "0x6001925")]
	[Address(RVA = "0x2935D44", Offset = "0x2935D44", VA = "0x2935D44")]
	private void ࠏޤݳ\u06DD()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Players In Room: ");
			return;
		}
	}

	// Token: 0x06001926 RID: 6438 RVA: 0x00089104 File Offset: 0x00087304
	[Token(Token = "0x6001926")]
	[Address(RVA = "0x2935DEC", Offset = "0x2935DEC", VA = "0x2935DEC")]
	private void ݱ\u0832ݥ\u08B5()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("FingerTip");
			return;
		}
	}

	// Token: 0x06001927 RID: 6439 RVA: 0x00089134 File Offset: 0x00087334
	[Token(Token = "0x6001927")]
	[Address(RVA = "0x2935E94", Offset = "0x2935E94", VA = "0x2935E94")]
	private void \u06EDٵ۶\u06DB()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("true");
			return;
		}
	}

	// Token: 0x06001928 RID: 6440 RVA: 0x00089164 File Offset: 0x00087364
	[Token(Token = "0x6001928")]
	[Address(RVA = "0x2935F3C", Offset = "0x2935F3C", VA = "0x2935F3C")]
	private void \u070Fߨ\u05B0ۈ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Photon token acquired!");
			return;
		}
	}

	// Token: 0x06001929 RID: 6441 RVA: 0x00089194 File Offset: 0x00087394
	[Token(Token = "0x6001929")]
	[Address(RVA = "0x2935FE4", Offset = "0x2935FE4", VA = "0x2935FE4")]
	private void Start()
	{
		if (true)
		{
			string @string = PlayerPrefs.GetString("username");
			return;
		}
	}

	// Token: 0x0600192A RID: 6442 RVA: 0x000891B8 File Offset: 0x000873B8
	[Token(Token = "0x600192A")]
	[Address(RVA = "0x293608C", Offset = "0x293608C", VA = "0x293608C")]
	private void چ\u05AEךڰ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("procedural animation script required on ");
			return;
		}
	}

	// Token: 0x0600192B RID: 6443 RVA: 0x000891E8 File Offset: 0x000873E8
	[Token(Token = "0x600192B")]
	[Address(RVA = "0x2936134", Offset = "0x2936134", VA = "0x2936134")]
	private void ޠۋ\u0530\u073E()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("HorrorAgreement");
			return;
		}
	}

	// Token: 0x0600192C RID: 6444 RVA: 0x00089218 File Offset: 0x00087418
	[Token(Token = "0x600192C")]
	[Address(RVA = "0x29361DC", Offset = "0x29361DC", VA = "0x29361DC")]
	private void ࢧӾڈց()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Universal Render Pipeline/Lit");
			return;
		}
	}

	// Token: 0x0600192D RID: 6445 RVA: 0x00089248 File Offset: 0x00087448
	[Token(Token = "0x600192D")]
	[Address(RVA = "0x2936284", Offset = "0x2936284", VA = "0x2936284")]
	private void ١ۏ\u05C4ӝ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("isLava");
			return;
		}
	}

	// Token: 0x0600192E RID: 6446 RVA: 0x00089278 File Offset: 0x00087478
	[Token(Token = "0x600192E")]
	[Address(RVA = "0x293632C", Offset = "0x293632C", VA = "0x293632C")]
	private void \u0656ӺմՁ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("/");
			return;
		}
	}

	// Token: 0x0600192F RID: 6447 RVA: 0x000892A8 File Offset: 0x000874A8
	[Token(Token = "0x600192F")]
	[Address(RVA = "0x29363D4", Offset = "0x29363D4", VA = "0x29363D4")]
	private void ߉ې\u07F6Ӭ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("EnableCosmetic");
			return;
		}
	}

	// Token: 0x06001930 RID: 6448 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001930")]
	[Address(RVA = "0x293647C", Offset = "0x293647C", VA = "0x293647C")]
	private void ۆڛߟ\u05A0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001931 RID: 6449 RVA: 0x000892D8 File Offset: 0x000874D8
	[Token(Token = "0x6001931")]
	[Address(RVA = "0x2936524", Offset = "0x2936524", VA = "0x2936524")]
	private void הԥ\u05B5ݴ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("True");
			return;
		}
	}

	// Token: 0x06001932 RID: 6450 RVA: 0x00089308 File Offset: 0x00087508
	[Token(Token = "0x6001932")]
	[Address(RVA = "0x29365CC", Offset = "0x29365CC", VA = "0x29365CC")]
	private void ןٮ\u061FԺ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("clickLol");
			return;
		}
	}

	// Token: 0x06001933 RID: 6451 RVA: 0x00089338 File Offset: 0x00087538
	[Token(Token = "0x6001933")]
	[Address(RVA = "0x2936674", Offset = "0x2936674", VA = "0x2936674")]
	private void ࢰחڵࡓ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Try Connect To Server...");
			return;
		}
	}

	// Token: 0x06001934 RID: 6452 RVA: 0x00089368 File Offset: 0x00087568
	[Token(Token = "0x6001934")]
	[Address(RVA = "0x293671C", Offset = "0x293671C", VA = "0x293671C")]
	private void ߒ\u065EՎࡖ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			return;
		}
	}

	// Token: 0x06001935 RID: 6453 RVA: 0x0008938C File Offset: 0x0008758C
	[Token(Token = "0x6001935")]
	[Address(RVA = "0x29367C4", Offset = "0x29367C4", VA = "0x29367C4")]
	private void ۮߝڪڐ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("waited for your bullshit unity grrr");
			return;
		}
	}

	// Token: 0x06001936 RID: 6454 RVA: 0x000893BC File Offset: 0x000875BC
	[Token(Token = "0x6001936")]
	[Address(RVA = "0x293686C", Offset = "0x293686C", VA = "0x293686C")]
	private void \u0834\u0817ރࡔ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("True");
			return;
		}
	}

	// Token: 0x06001937 RID: 6455 RVA: 0x000893EC File Offset: 0x000875EC
	[Token(Token = "0x6001937")]
	[Address(RVA = "0x2936914", Offset = "0x2936914", VA = "0x2936914")]
	private void \u06D6ې\u083Bࠉ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Player");
			return;
		}
	}

	// Token: 0x06001938 RID: 6456 RVA: 0x0008941C File Offset: 0x0008761C
	[Token(Token = "0x6001938")]
	[Address(RVA = "0x29369BC", Offset = "0x29369BC", VA = "0x29369BC")]
	private void ݸԲ\u0616Ԫ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("username");
			return;
		}
	}

	// Token: 0x06001939 RID: 6457 RVA: 0x0008944C File Offset: 0x0008764C
	[Token(Token = "0x6001939")]
	[Address(RVA = "0x2936A64", Offset = "0x2936A64", VA = "0x2936A64")]
	private void ܩחݵޔ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("5BN");
			return;
		}
	}

	// Token: 0x0600193A RID: 6458 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600193A")]
	[Address(RVA = "0x2936B0C", Offset = "0x2936B0C", VA = "0x2936B0C")]
	private void ӛ\u082Eؿڕ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600193B RID: 6459 RVA: 0x0008947C File Offset: 0x0008767C
	[Token(Token = "0x600193B")]
	[Address(RVA = "0x2936BB4", Offset = "0x2936BB4", VA = "0x2936BB4")]
	public ComputerTextField()
	{
	}

	// Token: 0x0600193C RID: 6460 RVA: 0x00089490 File Offset: 0x00087690
	[Token(Token = "0x600193C")]
	[Address(RVA = "0x2936BBC", Offset = "0x2936BBC", VA = "0x2936BBC")]
	private void \u07A8Ӥթݠ()
	{
		if (true)
		{
			string @string = PlayerPrefs.GetString("CapuchinStore");
			return;
		}
	}

	// Token: 0x0600193D RID: 6461 RVA: 0x000894B4 File Offset: 0x000876B4
	[Token(Token = "0x600193D")]
	[Address(RVA = "0x2936C64", Offset = "0x2936C64", VA = "0x2936C64")]
	private void \u073BօӁ\u059A()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("Body");
			return;
		}
	}

	// Token: 0x0600193E RID: 6462 RVA: 0x000894E4 File Offset: 0x000876E4
	[Token(Token = "0x600193E")]
	[Address(RVA = "0x2936D0C", Offset = "0x2936D0C", VA = "0x2936D0C")]
	private void ࡩݮڢՠ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("typesOfTalk");
			return;
		}
	}

	// Token: 0x0600193F RID: 6463 RVA: 0x00089514 File Offset: 0x00087714
	[Token(Token = "0x600193F")]
	[Address(RVA = "0x2936DB4", Offset = "0x2936DB4", VA = "0x2936DB4")]
	private void \u082E\u06EBݼڏ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("isLava");
			return;
		}
	}

	// Token: 0x06001940 RID: 6464 RVA: 0x00089544 File Offset: 0x00087744
	[Token(Token = "0x6001940")]
	[Address(RVA = "0x2936E5C", Offset = "0x2936E5C", VA = "0x2936E5C")]
	private void וࡪךӧ()
	{
		if (this.ՉߒԢ\u07EE)
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			string @string = PlayerPrefs.GetString("typesOfTalk");
			return;
		}
	}

	// Token: 0x04000320 RID: 800
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000320")]
	public bool ՉߒԢ\u07EE;
}
