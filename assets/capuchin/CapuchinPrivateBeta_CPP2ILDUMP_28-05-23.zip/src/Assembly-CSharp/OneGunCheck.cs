﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000D0 RID: 208
[Token(Token = "0x20000D0")]
public class OneGunCheck : MonoBehaviour
{
	// Token: 0x06001F9D RID: 8093 RVA: 0x000A60FC File Offset: 0x000A42FC
	[Token(Token = "0x6001F9D")]
	[Address(RVA = "0x2D496C8", Offset = "0x2D496C8", VA = "0x2D496C8")]
	public void \u0883ދ\u066C\u0859()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 1L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001F9E RID: 8094 RVA: 0x000A614C File Offset: 0x000A434C
	[Token(Token = "0x6001F9E")]
	[Address(RVA = "0x2D49740", Offset = "0x2D49740", VA = "0x2D49740")]
	public void \u0892\u061B\u0606\u06D8()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 1L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 1L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001F9F RID: 8095 RVA: 0x000A619C File Offset: 0x000A439C
	[Token(Token = "0x6001F9F")]
	[Address(RVA = "0x2D497B8", Offset = "0x2D497B8", VA = "0x2D497B8")]
	public void Ԃڏݏ\u086D()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FA0 RID: 8096 RVA: 0x000A61EC File Offset: 0x000A43EC
	[Token(Token = "0x6001FA0")]
	[Address(RVA = "0x2D49830", Offset = "0x2D49830", VA = "0x2D49830")]
	public void \u0887ࡒ\u0613\u07B8()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FA1 RID: 8097 RVA: 0x000A623C File Offset: 0x000A443C
	[Token(Token = "0x6001FA1")]
	[Address(RVA = "0x2D498A8", Offset = "0x2D498A8", VA = "0x2D498A8")]
	public void \u0736\u06E0\u06E0څ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FA2 RID: 8098 RVA: 0x000A628C File Offset: 0x000A448C
	[Token(Token = "0x6001FA2")]
	[Address(RVA = "0x2D49920", Offset = "0x2D49920", VA = "0x2D49920")]
	public void \u064Cޔաӕ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 1L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
	}

	// Token: 0x06001FA3 RID: 8099 RVA: 0x000A62CC File Offset: 0x000A44CC
	[Token(Token = "0x6001FA3")]
	[Address(RVA = "0x2D49998", Offset = "0x2D49998", VA = "0x2D49998")]
	public OneGunCheck()
	{
	}

	// Token: 0x06001FA4 RID: 8100 RVA: 0x000A62E0 File Offset: 0x000A44E0
	[Token(Token = "0x6001FA4")]
	[Address(RVA = "0x2D499A0", Offset = "0x2D499A0", VA = "0x2D499A0")]
	public void Աࢦ\u05CAޡ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 1L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FA5 RID: 8101 RVA: 0x000A6330 File Offset: 0x000A4530
	[Token(Token = "0x6001FA5")]
	[Address(RVA = "0x2D49A18", Offset = "0x2D49A18", VA = "0x2D49A18")]
	public void ޤ\u0610\u087A\u05AF()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FA6 RID: 8102 RVA: 0x000A6380 File Offset: 0x000A4580
	[Token(Token = "0x6001FA6")]
	[Address(RVA = "0x2D49A90", Offset = "0x2D49A90", VA = "0x2D49A90")]
	public void \u070EࢣԀ\u07A9()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 1L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FA7 RID: 8103 RVA: 0x000A63D0 File Offset: 0x000A45D0
	[Token(Token = "0x6001FA7")]
	[Address(RVA = "0x2D49B08", Offset = "0x2D49B08", VA = "0x2D49B08")]
	public void ࡇ\u0559یՒ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = u083AՅڰ_u.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FA8 RID: 8104 RVA: 0x000A641C File Offset: 0x000A461C
	[Token(Token = "0x6001FA8")]
	[Address(RVA = "0x2D49B80", Offset = "0x2D49B80", VA = "0x2D49B80")]
	public void \u07A7\u06DFࠈޖ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 1L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 1L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FA9 RID: 8105 RVA: 0x000A646C File Offset: 0x000A466C
	[Token(Token = "0x6001FA9")]
	[Address(RVA = "0x2D49BF8", Offset = "0x2D49BF8", VA = "0x2D49BF8")]
	public void ڸՔ\u0594ԭ()
	{
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active = 0L;
		bool activeSelf = u05C2_u0822ڳپ.activeSelf;
		this.\u083AՅڰ\u0874.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ2 = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ2.SetActive(active2 != 0L);
	}

	// Token: 0x06001FAA RID: 8106 RVA: 0x000A64BC File Offset: 0x000A46BC
	[Token(Token = "0x6001FAA")]
	[Address(RVA = "0x2D49C70", Offset = "0x2D49C70", VA = "0x2D49C70")]
	public void ןأ\u05C0ب()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FAB RID: 8107 RVA: 0x000A650C File Offset: 0x000A470C
	[Token(Token = "0x6001FAB")]
	[Address(RVA = "0x2D49CE8", Offset = "0x2D49CE8", VA = "0x2D49CE8")]
	public void ߪձԛމ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 1L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 1L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FAC RID: 8108 RVA: 0x000A655C File Offset: 0x000A475C
	[Token(Token = "0x6001FAC")]
	[Address(RVA = "0x2D49D60", Offset = "0x2D49D60", VA = "0x2D49D60")]
	public void ۍ\u05CAۋݿ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 1L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FAD RID: 8109 RVA: 0x000A65AC File Offset: 0x000A47AC
	[Token(Token = "0x6001FAD")]
	[Address(RVA = "0x2D49DD8", Offset = "0x2D49DD8", VA = "0x2D49DD8")]
	public void \u089Fکߦݭ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 1L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FAE RID: 8110 RVA: 0x000A65FC File Offset: 0x000A47FC
	[Token(Token = "0x6001FAE")]
	[Address(RVA = "0x2D49E50", Offset = "0x2D49E50", VA = "0x2D49E50")]
	public void Ա\u07B9ߒݗ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 1L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 1L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FAF RID: 8111 RVA: 0x000A664C File Offset: 0x000A484C
	[Token(Token = "0x6001FAF")]
	[Address(RVA = "0x2D49EC8", Offset = "0x2D49EC8", VA = "0x2D49EC8")]
	public void FixedUpdate()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FB0 RID: 8112 RVA: 0x000A669C File Offset: 0x000A489C
	[Token(Token = "0x6001FB0")]
	[Address(RVA = "0x2D49F40", Offset = "0x2D49F40", VA = "0x2D49F40")]
	public void \u081E١Ӕࢦ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 1L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 1L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FB1 RID: 8113 RVA: 0x000A66EC File Offset: 0x000A48EC
	[Token(Token = "0x6001FB1")]
	[Address(RVA = "0x2D49FB8", Offset = "0x2D49FB8", VA = "0x2D49FB8")]
	public void ա\u0731ࢺۊ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 1L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 1L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FB2 RID: 8114 RVA: 0x000A673C File Offset: 0x000A493C
	[Token(Token = "0x6001FB2")]
	[Address(RVA = "0x2D4A030", Offset = "0x2D4A030", VA = "0x2D4A030")]
	public void \u05BBږ\u060Cࡑ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 1L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x06001FB3 RID: 8115 RVA: 0x000A678C File Offset: 0x000A498C
	[Token(Token = "0x6001FB3")]
	[Address(RVA = "0x2D4A0A8", Offset = "0x2D4A0A8", VA = "0x2D4A0A8")]
	public void Ԧ\u0876ծՎ()
	{
		bool activeSelf = this.\u05C2\u0822ڳپ.activeSelf;
		GameObject u083AՅڰ_u = this.\u083AՅڰ\u0874;
		long active = 0L;
		u083AՅڰ_u.SetActive(active != 0L);
		bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
		GameObject u05C2_u0822ڳپ = this.\u05C2\u0822ڳپ;
		long active2 = 0L;
		u05C2_u0822ڳپ.SetActive(active2 != 0L);
	}

	// Token: 0x04000417 RID: 1047
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000417")]
	public GameObject \u05C2\u0822ڳپ;

	// Token: 0x04000418 RID: 1048
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000418")]
	public GameObject \u083AՅڰ\u0874;
}
