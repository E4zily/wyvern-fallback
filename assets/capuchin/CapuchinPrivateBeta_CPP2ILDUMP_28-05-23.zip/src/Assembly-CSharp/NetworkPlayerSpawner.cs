﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000038 RID: 56
[Token(Token = "0x2000038")]
public class NetworkPlayerSpawner : MonoBehaviourPunCallbacks
{
	// Token: 0x06000746 RID: 1862 RVA: 0x000293A0 File Offset: 0x000275A0
	[Token(Token = "0x6000746")]
	[Address(RVA = "0x2D46510", Offset = "0x2D46510", VA = "0x2D46510")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000747 RID: 1863 RVA: 0x000293B4 File Offset: 0x000275B4
	[Token(Token = "0x6000747")]
	[Address(RVA = "0x2D46564", Offset = "0x2D46564", VA = "0x2D46564")]
	private void \u07A8Ӥթݠ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000748 RID: 1864 RVA: 0x000293C8 File Offset: 0x000275C8
	[Token(Token = "0x6000748")]
	[Address(RVA = "0x2D465B8", Offset = "0x2D465B8", VA = "0x2D465B8")]
	private void ӷӛࠔ\u07AC()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000749 RID: 1865 RVA: 0x000293DC File Offset: 0x000275DC
	[Token(Token = "0x6000749")]
	[Address(RVA = "0x2D4660C", Offset = "0x2D4660C", VA = "0x2D4660C")]
	private void \u0604ߪ\u0598ࢴ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600074A RID: 1866 RVA: 0x00029400 File Offset: 0x00027600
	[Token(Token = "0x600074A")]
	[Address(RVA = "0x2D46664", Offset = "0x2D46664", VA = "0x2D46664")]
	private void ܔށԣդ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600074B RID: 1867 RVA: 0x00029424 File Offset: 0x00027624
	[Token(Token = "0x600074B")]
	[Address(RVA = "0x2D466BC", Offset = "0x2D466BC", VA = "0x2D466BC")]
	private void ܩחݵޔ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600074C RID: 1868 RVA: 0x00029438 File Offset: 0x00027638
	[Token(Token = "0x600074C")]
	[Address(RVA = "0x2D46710", Offset = "0x2D46710", VA = "0x2D46710")]
	private void Օܣ\u0825ڥ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600074D RID: 1869 RVA: 0x0002945C File Offset: 0x0002765C
	[Token(Token = "0x600074D")]
	[Address(RVA = "0x2D46768", Offset = "0x2D46768", VA = "0x2D46768")]
	private void ڣֆ\u07F4ڌ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600074E RID: 1870 RVA: 0x00029470 File Offset: 0x00027670
	[Token(Token = "0x600074E")]
	[Address(RVA = "0x2D467BC", Offset = "0x2D467BC", VA = "0x2D467BC")]
	private void ӎԘމڸ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600074F RID: 1871 RVA: 0x0002948C File Offset: 0x0002768C
	[Token(Token = "0x600074F")]
	[Address(RVA = "0x2D46814", Offset = "0x2D46814", VA = "0x2D46814")]
	private void \u087BӦןݩ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000750 RID: 1872 RVA: 0x000294EC File Offset: 0x000276EC
	[Token(Token = "0x6000750")]
	[Address(RVA = "0x2D469C4", Offset = "0x2D469C4", VA = "0x2D469C4")]
	private void ӧ\u0608\u086Cճ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000751 RID: 1873 RVA: 0x00029500 File Offset: 0x00027700
	[Token(Token = "0x6000751")]
	[Address(RVA = "0x2D46A18", Offset = "0x2D46A18", VA = "0x2D46A18")]
	private void զ\u05B8\u06ECݪ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000752 RID: 1874 RVA: 0x00029524 File Offset: 0x00027724
	[Token(Token = "0x6000752")]
	[Address(RVA = "0x2D46A70", Offset = "0x2D46A70", VA = "0x2D46A70")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000753 RID: 1875 RVA: 0x00029584 File Offset: 0x00027784
	[Token(Token = "0x6000753")]
	[Address(RVA = "0x2D46B70", Offset = "0x2D46B70", VA = "0x2D46B70")]
	private void Ճࠈޛݞ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000754 RID: 1876 RVA: 0x00029598 File Offset: 0x00027798
	[Token(Token = "0x6000754")]
	[Address(RVA = "0x2D46BC4", Offset = "0x2D46BC4", VA = "0x2D46BC4")]
	private void Գӿېչ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000755 RID: 1877 RVA: 0x000295AC File Offset: 0x000277AC
	[Token(Token = "0x6000755")]
	[Address(RVA = "0x2D46C18", Offset = "0x2D46C18", VA = "0x2D46C18")]
	private void ࡢض\u07ACנ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000756 RID: 1878 RVA: 0x000295C0 File Offset: 0x000277C0
	[Token(Token = "0x6000756")]
	[Address(RVA = "0x2D46C6C", Offset = "0x2D46C6C", VA = "0x2D46C6C")]
	private void Start()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000757 RID: 1879 RVA: 0x000295D4 File Offset: 0x000277D4
	[Token(Token = "0x6000757")]
	[Address(RVA = "0x2D46CC0", Offset = "0x2D46CC0", VA = "0x2D46CC0")]
	private void طӏܙࢺ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000758 RID: 1880 RVA: 0x00029634 File Offset: 0x00027834
	[Token(Token = "0x6000758")]
	[Address(RVA = "0x2D46E70", Offset = "0x2D46E70", VA = "0x2D46E70")]
	private void ݤۅࢦӃ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000759 RID: 1881 RVA: 0x00029648 File Offset: 0x00027848
	[Token(Token = "0x6000759")]
	[Address(RVA = "0x2D46EC4", Offset = "0x2D46EC4", VA = "0x2D46EC4")]
	private void \u07FE\u0882Զ\u066D()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x0600075A RID: 1882 RVA: 0x000296A8 File Offset: 0x000278A8
	[Token(Token = "0x600075A")]
	[Address(RVA = "0x2D4701C", Offset = "0x2D4701C", VA = "0x2D4701C")]
	private void \u059AՏ\u0600\u0872()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600075B RID: 1883 RVA: 0x000296BC File Offset: 0x000278BC
	[Token(Token = "0x600075B")]
	[Address(RVA = "0x2D47070", Offset = "0x2D47070", VA = "0x2D47070")]
	private void ࠆ\u0881Չ߉(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600075C RID: 1884 RVA: 0x000296E0 File Offset: 0x000278E0
	[Token(Token = "0x600075C")]
	[Address(RVA = "0x2D470C8", Offset = "0x2D470C8", VA = "0x2D470C8")]
	private void ߒ\u065EՎࡖ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600075D RID: 1885 RVA: 0x000296F4 File Offset: 0x000278F4
	[Token(Token = "0x600075D")]
	[Address(RVA = "0x2D4711C", Offset = "0x2D4711C", VA = "0x2D4711C")]
	private void ࢭ\u0589\u0892\u058A()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x0600075E RID: 1886 RVA: 0x00029754 File Offset: 0x00027954
	[Token(Token = "0x600075E")]
	[Address(RVA = "0x2D472CC", Offset = "0x2D472CC", VA = "0x2D472CC")]
	private void ࡅݐ\u082Dք()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600075F RID: 1887 RVA: 0x00029768 File Offset: 0x00027968
	[Token(Token = "0x600075F")]
	[Address(RVA = "0x2D47320", Offset = "0x2D47320", VA = "0x2D47320")]
	private void Ӯڶނ\u0659(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000760 RID: 1888 RVA: 0x0002978C File Offset: 0x0002798C
	[Token(Token = "0x6000760")]
	[Address(RVA = "0x2D46D68", Offset = "0x2D46D68", VA = "0x2D46D68")]
	private void \u0830ԡ\u065A\u089B(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000761 RID: 1889 RVA: 0x000297B0 File Offset: 0x000279B0
	[Token(Token = "0x6000761")]
	[Address(RVA = "0x2D47378", Offset = "0x2D47378", VA = "0x2D47378")]
	private void \u05FEօ\u06D7ࡁ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000762 RID: 1890 RVA: 0x000297C4 File Offset: 0x000279C4
	[Token(Token = "0x6000762")]
	[Address(RVA = "0x2D473CC", Offset = "0x2D473CC", VA = "0x2D473CC")]
	private void յߪؾՀ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000763 RID: 1891 RVA: 0x00029824 File Offset: 0x00027A24
	[Token(Token = "0x6000763")]
	[Address(RVA = "0x2D47524", Offset = "0x2D47524", VA = "0x2D47524")]
	private void \u05F7ԝߠӱ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000764 RID: 1892 RVA: 0x00029884 File Offset: 0x00027A84
	[Token(Token = "0x6000764")]
	[Address(RVA = "0x2D468BC", Offset = "0x2D468BC", VA = "0x2D468BC")]
	private void Ө\u07EB\u074Cࡏ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000765 RID: 1893 RVA: 0x000298A8 File Offset: 0x00027AA8
	[Token(Token = "0x6000765")]
	[Address(RVA = "0x2D4696C", Offset = "0x2D4696C", VA = "0x2D4696C")]
	private void \u065B\u082Fӈ\u05B8(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000766 RID: 1894 RVA: 0x000298CC File Offset: 0x00027ACC
	[Token(Token = "0x6000766")]
	[Address(RVA = "0x2D475CC", Offset = "0x2D475CC", VA = "0x2D475CC")]
	private void څӦܮ\u058E(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000767 RID: 1895 RVA: 0x000298F0 File Offset: 0x00027AF0
	[Token(Token = "0x6000767")]
	[Address(RVA = "0x2D47274", Offset = "0x2D47274", VA = "0x2D47274")]
	private void ըزٯܤ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000768 RID: 1896 RVA: 0x00029914 File Offset: 0x00027B14
	[Token(Token = "0x6000768")]
	[Address(RVA = "0x2D47624", Offset = "0x2D47624", VA = "0x2D47624")]
	private void ޡࠅ\u089Aߔ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000769 RID: 1897 RVA: 0x00029928 File Offset: 0x00027B28
	[Token(Token = "0x6000769")]
	[Address(RVA = "0x2D47678", Offset = "0x2D47678", VA = "0x2D47678")]
	public NetworkPlayerSpawner()
	{
	}

	// Token: 0x0600076A RID: 1898 RVA: 0x0002993C File Offset: 0x00027B3C
	[Token(Token = "0x600076A")]
	[Address(RVA = "0x2D47680", Offset = "0x2D47680", VA = "0x2D47680")]
	private void ࢴܤ\u055Aל(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600076B RID: 1899 RVA: 0x00029960 File Offset: 0x00027B60
	[Token(Token = "0x600076B")]
	[Address(RVA = "0x2D476D8", Offset = "0x2D476D8", VA = "0x2D476D8")]
	private void ٿ\u05ECࡩ٥(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600076C RID: 1900 RVA: 0x00029984 File Offset: 0x00027B84
	[Token(Token = "0x600076C")]
	[Address(RVA = "0x2D47730", Offset = "0x2D47730", VA = "0x2D47730")]
	private void ١ۏ\u05C4ӝ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600076D RID: 1901 RVA: 0x00029998 File Offset: 0x00027B98
	[Token(Token = "0x600076D")]
	[Address(RVA = "0x2D47784", Offset = "0x2D47784", VA = "0x2D47784")]
	private void Update()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x0600076E RID: 1902 RVA: 0x000299F8 File Offset: 0x00027BF8
	[Token(Token = "0x600076E")]
	[Address(RVA = "0x2D4782C", Offset = "0x2D4782C", VA = "0x2D4782C")]
	private void ޑܤࠅݽ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600076F RID: 1903 RVA: 0x00029A1C File Offset: 0x00027C1C
	[Token(Token = "0x600076F")]
	[Address(RVA = "0x2D47884", Offset = "0x2D47884", VA = "0x2D47884")]
	private void \u0881\u0743\u07EB\u0747()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000770 RID: 1904 RVA: 0x00029A30 File Offset: 0x00027C30
	[Token(Token = "0x6000770")]
	[Address(RVA = "0x2D478D8", Offset = "0x2D478D8", VA = "0x2D478D8")]
	private void ߑ\u0885\u05BBߕ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000771 RID: 1905 RVA: 0x00029A90 File Offset: 0x00027C90
	[Token(Token = "0x6000771")]
	[Address(RVA = "0x2D47A30", Offset = "0x2D47A30", VA = "0x2D47A30")]
	private void \u0652\u058Bک\u061C()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000772 RID: 1906 RVA: 0x00029AA4 File Offset: 0x00027CA4
	[Token(Token = "0x6000772")]
	[Address(RVA = "0x2D47A84", Offset = "0x2D47A84", VA = "0x2D47A84")]
	private void Ԁוև\u065B()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000773 RID: 1907 RVA: 0x00029AB8 File Offset: 0x00027CB8
	[Token(Token = "0x6000773")]
	[Address(RVA = "0x2D47AD8", Offset = "0x2D47AD8", VA = "0x2D47AD8")]
	private void ۓݳۯ٨()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000774 RID: 1908 RVA: 0x00029ACC File Offset: 0x00027CCC
	[Token(Token = "0x6000774")]
	[Address(RVA = "0x2D4721C", Offset = "0x2D4721C", VA = "0x2D4721C")]
	private void \u0894ݿܟ\u07B5(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000775 RID: 1909 RVA: 0x00029AF0 File Offset: 0x00027CF0
	[Token(Token = "0x6000775")]
	[Address(RVA = "0x2D47B2C", Offset = "0x2D47B2C", VA = "0x2D47B2C")]
	private void \u0617\u0838\u060B\u070D(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000776 RID: 1910 RVA: 0x00029B14 File Offset: 0x00027D14
	[Token(Token = "0x6000776")]
	[Address(RVA = "0x2D47980", Offset = "0x2D47980", VA = "0x2D47980")]
	private void \u06EA\u0614\u0610ܚ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000777 RID: 1911 RVA: 0x00029B38 File Offset: 0x00027D38
	[Token(Token = "0x6000777")]
	[Address(RVA = "0x2D47B84", Offset = "0x2D47B84", VA = "0x2D47B84")]
	private void \u065D\u070Aٶࢰ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000778 RID: 1912 RVA: 0x00029B4C File Offset: 0x00027D4C
	[Token(Token = "0x6000778")]
	[Address(RVA = "0x2D47BD8", Offset = "0x2D47BD8", VA = "0x2D47BD8")]
	private void \u089F\u085Fէ\u059A()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000779 RID: 1913 RVA: 0x00029BAC File Offset: 0x00027DAC
	[Token(Token = "0x6000779")]
	[Address(RVA = "0x2D47CD8", Offset = "0x2D47CD8", VA = "0x2D47CD8")]
	private void \u05ABݿࡋ\u06E9()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600077A RID: 1914 RVA: 0x00029BC0 File Offset: 0x00027DC0
	[Token(Token = "0x600077A")]
	[Address(RVA = "0x2D47D2C", Offset = "0x2D47D2C", VA = "0x2D47D2C")]
	private void ӭࡖݲ\u05BD()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600077B RID: 1915 RVA: 0x00029BD4 File Offset: 0x00027DD4
	[Token(Token = "0x600077B")]
	[Address(RVA = "0x2D47D80", Offset = "0x2D47D80", VA = "0x2D47D80")]
	private void \u0827ߜ\u07FD\u07F4()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x0600077C RID: 1916 RVA: 0x00029C34 File Offset: 0x00027E34
	[Token(Token = "0x600077C")]
	[Address(RVA = "0x2D47E80", Offset = "0x2D47E80", VA = "0x2D47E80")]
	private void \u0739߉ڵݞ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600077D RID: 1917 RVA: 0x00029C48 File Offset: 0x00027E48
	[Token(Token = "0x600077D")]
	[Address(RVA = "0x2D46E18", Offset = "0x2D46E18", VA = "0x2D46E18")]
	private void \u081A\u081C\u05C6\u0823(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x00029C6C File Offset: 0x00027E6C
	[Token(Token = "0x600077E")]
	[Address(RVA = "0x2D47ED4", Offset = "0x2D47ED4", VA = "0x2D47ED4")]
	private void ۺ\u082DܨՑ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600077F RID: 1919 RVA: 0x00029C90 File Offset: 0x00027E90
	[Token(Token = "0x600077F")]
	[Address(RVA = "0x2D47F2C", Offset = "0x2D47F2C", VA = "0x2D47F2C")]
	private void ߆ܖܟܕ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x00029CB4 File Offset: 0x00027EB4
	[Token(Token = "0x6000780")]
	[Address(RVA = "0x2D47F84", Offset = "0x2D47F84", VA = "0x2D47F84")]
	private void \u07F5\u0657\u055Aߍ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E != null)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000781 RID: 1921 RVA: 0x00029D10 File Offset: 0x00027F10
	[Token(Token = "0x6000781")]
	[Address(RVA = "0x2D46914", Offset = "0x2D46914", VA = "0x2D46914")]
	private void Ջ\u0875Խ\u0746(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000782 RID: 1922 RVA: 0x00029D34 File Offset: 0x00027F34
	[Token(Token = "0x6000782")]
	[Address(RVA = "0x2D48084", Offset = "0x2D48084", VA = "0x2D48084")]
	private void ӿهӁۮ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000783 RID: 1923 RVA: 0x00029D58 File Offset: 0x00027F58
	[Token(Token = "0x6000783")]
	[Address(RVA = "0x2D480DC", Offset = "0x2D480DC", VA = "0x2D480DC")]
	private void \u0882\u055C\u0888ߥ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000784 RID: 1924 RVA: 0x00029DB8 File Offset: 0x00027FB8
	[Token(Token = "0x6000784")]
	[Address(RVA = "0x2D481DC", Offset = "0x2D481DC", VA = "0x2D481DC")]
	private void گ\u085E\u073Dڊ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000785 RID: 1925 RVA: 0x00029DCC File Offset: 0x00027FCC
	[Token(Token = "0x6000785")]
	[Address(RVA = "0x2D48230", Offset = "0x2D48230", VA = "0x2D48230")]
	private void \u06EDٵ۶\u06DB()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000786 RID: 1926 RVA: 0x00029DE0 File Offset: 0x00027FE0
	[Token(Token = "0x6000786")]
	[Address(RVA = "0x2D48284", Offset = "0x2D48284", VA = "0x2D48284")]
	private void \u0558ݕݤݮ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000787 RID: 1927 RVA: 0x00029DF4 File Offset: 0x00027FF4
	[Token(Token = "0x6000787")]
	[Address(RVA = "0x2D47E28", Offset = "0x2D47E28", VA = "0x2D47E28")]
	private void \u0650ӈ\u073Aࢤ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000788 RID: 1928 RVA: 0x00029E18 File Offset: 0x00028018
	[Token(Token = "0x6000788")]
	[Address(RVA = "0x2D482D8", Offset = "0x2D482D8", VA = "0x2D482D8")]
	private void ޠۋ\u0530\u073E()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000789 RID: 1929 RVA: 0x00029E2C File Offset: 0x0002802C
	[Token(Token = "0x6000789")]
	[Address(RVA = "0x2D4832C", Offset = "0x2D4832C", VA = "0x2D4832C")]
	private void ࢫڨՎࡒ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600078A RID: 1930 RVA: 0x00029E50 File Offset: 0x00028050
	[Token(Token = "0x600078A")]
	[Address(RVA = "0x2D46FC4", Offset = "0x2D46FC4", VA = "0x2D46FC4")]
	private void ࠍߟ\u06EBࡐ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600078B RID: 1931 RVA: 0x00029E74 File Offset: 0x00028074
	[Token(Token = "0x600078B")]
	[Address(RVA = "0x2D48384", Offset = "0x2D48384", VA = "0x2D48384")]
	private void \u055E\u0703\u0700ܠ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600078C RID: 1932 RVA: 0x00029E88 File Offset: 0x00028088
	[Token(Token = "0x600078C")]
	[Address(RVA = "0x2D483D8", Offset = "0x2D483D8", VA = "0x2D483D8")]
	private void \u082F\u0595\u064Eࡦ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600078D RID: 1933 RVA: 0x00029EAC File Offset: 0x000280AC
	[Token(Token = "0x600078D")]
	[Address(RVA = "0x2D48430", Offset = "0x2D48430", VA = "0x2D48430", Slot = "41")]
	public override void OnJoinedRoom()
	{
		base.OnJoinedRoom();
		Vector3 position = base.transform.position;
		Quaternion rotation = base.transform.rotation;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		GameObject u05EEݠ_u05FFը;
		this.\u05EEݠ\u05FFը = u05EEݠ_u05FFը;
		PhotonView ڽߗ_u0652_u089E;
		this.ڽߗ\u0652\u089E = ڽߗ_u0652_u089E;
		Transform transform;
		Transform աߞ_u07A7ߦ = transform.Find("Head");
		this.աߞ\u07A7ߦ = աߞ_u07A7ߦ;
		Transform transform2;
		Transform ցԁ_u0740օ = transform2.Find("Left Hand");
		this.ՑԀ\u0740օ = ցԁ_u0740օ;
		Transform transform3;
		Transform u0741_u06E2ӳࢣ = transform3.Find("Right Hand");
		this.\u0741\u06E2ӳࢣ = u0741_u06E2ӳࢣ;
	}

	// Token: 0x0600078E RID: 1934 RVA: 0x00029F3C File Offset: 0x0002813C
	[Token(Token = "0x600078E")]
	[Address(RVA = "0x2D48684", Offset = "0x2D48684", VA = "0x2D48684")]
	private void څࡣڐ\u0657()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x0600078F RID: 1935 RVA: 0x00029F9C File Offset: 0x0002819C
	[Token(Token = "0x600078F")]
	[Address(RVA = "0x2D4872C", Offset = "0x2D4872C", VA = "0x2D4872C")]
	private void Ҽ\u08B5ځ\u0658()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000790 RID: 1936 RVA: 0x00029FFC File Offset: 0x000281FC
	[Token(Token = "0x6000790")]
	[Address(RVA = "0x2D487D4", Offset = "0x2D487D4", VA = "0x2D487D4")]
	private void ࡥշӞھ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000791 RID: 1937 RVA: 0x0002A05C File Offset: 0x0002825C
	[Token(Token = "0x6000791")]
	[Address(RVA = "0x2D4887C", Offset = "0x2D4887C", VA = "0x2D4887C")]
	private void ڑߒجވ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000792 RID: 1938 RVA: 0x0002A0BC File Offset: 0x000282BC
	[Token(Token = "0x6000792")]
	[Address(RVA = "0x2D48924", Offset = "0x2D48924", VA = "0x2D48924")]
	private void Ո٨ߡ\u05A9(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000793 RID: 1939 RVA: 0x0002A0E0 File Offset: 0x000282E0
	[Token(Token = "0x6000793")]
	[Address(RVA = "0x2D47C80", Offset = "0x2D47C80", VA = "0x2D47C80")]
	private void \u073Cࡐ\u085DӬ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000794 RID: 1940 RVA: 0x0002A104 File Offset: 0x00028304
	[Token(Token = "0x6000794")]
	[Address(RVA = "0x2D4897C", Offset = "0x2D4897C", VA = "0x2D4897C")]
	private void \u089E\u0890\u060A\u0827(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000795 RID: 1941 RVA: 0x0002A128 File Offset: 0x00028328
	[Token(Token = "0x6000795")]
	[Address(RVA = "0x2D489D4", Offset = "0x2D489D4", VA = "0x2D489D4")]
	private void \u0705\u0816\u0739դ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x06000796 RID: 1942 RVA: 0x0002A188 File Offset: 0x00028388
	[Token(Token = "0x6000796")]
	[Address(RVA = "0x2D46B18", Offset = "0x2D46B18", VA = "0x2D46B18")]
	private void ࢨԐԵӇ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x06000797 RID: 1943 RVA: 0x0002A1AC File Offset: 0x000283AC
	[Token(Token = "0x6000797")]
	[Address(RVA = "0x2D48A7C", Offset = "0x2D48A7C", VA = "0x2D48A7C")]
	private void ןٮ\u061FԺ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06000798 RID: 1944 RVA: 0x0002A1C0 File Offset: 0x000283C0
	[Token(Token = "0x6000798")]
	[Address(RVA = "0x2D4802C", Offset = "0x2D4802C", VA = "0x2D4802C")]
	private void \u07B3\u07A6\u0828\u05A0(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
	}

	// Token: 0x06000799 RID: 1945 RVA: 0x0002A1DC File Offset: 0x000283DC
	[Token(Token = "0x6000799")]
	[Address(RVA = "0x2D471C4", Offset = "0x2D471C4", VA = "0x2D471C4")]
	private void \u0596\u05F5ވ\u05A0(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600079A RID: 1946 RVA: 0x0002A200 File Offset: 0x00028400
	[Token(Token = "0x600079A")]
	[Address(RVA = "0x2D48AD0", Offset = "0x2D48AD0", VA = "0x2D48AD0")]
	private void ڦکӁ\u06E2()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x0600079B RID: 1947 RVA: 0x0002A260 File Offset: 0x00028460
	[Token(Token = "0x600079B")]
	[Address(RVA = "0x2D48B78", Offset = "0x2D48B78", VA = "0x2D48B78")]
	private void ԟ\u086Cޣ\u055E()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x0600079C RID: 1948 RVA: 0x0002A2C0 File Offset: 0x000284C0
	[Token(Token = "0x600079C")]
	[Address(RVA = "0x2D46F6C", Offset = "0x2D46F6C", VA = "0x2D46F6C")]
	private void \u064Fڰ\u086Eە(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x0600079D RID: 1949 RVA: 0x0002A2E4 File Offset: 0x000284E4
	[Token(Token = "0x600079D")]
	[Address(RVA = "0x2D48C20", Offset = "0x2D48C20", VA = "0x2D48C20")]
	private void \u05C8\u05BFࠁف()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600079E RID: 1950 RVA: 0x0002A2F8 File Offset: 0x000284F8
	[Token(Token = "0x600079E")]
	[Address(RVA = "0x2D48C74", Offset = "0x2D48C74", VA = "0x2D48C74")]
	private void וࡪךӧ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600079F RID: 1951 RVA: 0x0002A30C File Offset: 0x0002850C
	[Token(Token = "0x600079F")]
	[Address(RVA = "0x2D48CC8", Offset = "0x2D48CC8", VA = "0x2D48CC8")]
	private void ԙضփӌ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x060007A0 RID: 1952 RVA: 0x0002A36C File Offset: 0x0002856C
	[Token(Token = "0x60007A0")]
	[Address(RVA = "0x2D48D70", Offset = "0x2D48D70", VA = "0x2D48D70")]
	private void ࡕߕ\u0707ݩ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x060007A1 RID: 1953 RVA: 0x0002A3CC File Offset: 0x000285CC
	[Token(Token = "0x60007A1")]
	[Address(RVA = "0x2D48E18", Offset = "0x2D48E18", VA = "0x2D48E18")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x060007A2 RID: 1954 RVA: 0x0002A42C File Offset: 0x0002862C
	[Token(Token = "0x60007A2")]
	[Address(RVA = "0x2D48EC0", Offset = "0x2D48EC0", VA = "0x2D48EC0")]
	private void \u073Bݲձݕ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060007A3 RID: 1955 RVA: 0x0002A440 File Offset: 0x00028640
	[Token(Token = "0x60007A3")]
	[Address(RVA = "0x2D48F14", Offset = "0x2D48F14", VA = "0x2D48F14")]
	private void \u0745ޕ\u05C3\u0597(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x060007A4 RID: 1956 RVA: 0x0002A464 File Offset: 0x00028664
	[Token(Token = "0x60007A4")]
	[Address(RVA = "0x2D474CC", Offset = "0x2D474CC", VA = "0x2D474CC")]
	private void ࡒߐכࡧ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = ࠔؼࡏݥ.rotation;
	}

	// Token: 0x060007A5 RID: 1957 RVA: 0x0002A488 File Offset: 0x00028688
	[Token(Token = "0x60007A5")]
	[Address(RVA = "0x2D48F6C", Offset = "0x2D48F6C", VA = "0x2D48F6C")]
	private void ߓ\u06E3\u05C7ۋ()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060007A6 RID: 1958 RVA: 0x0002A49C File Offset: 0x0002869C
	[Token(Token = "0x60007A6")]
	[Address(RVA = "0x2D479D8", Offset = "0x2D479D8", VA = "0x2D479D8")]
	private void Օމ\u05F8ہ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x060007A7 RID: 1959 RVA: 0x0002A4C0 File Offset: 0x000286C0
	[Token(Token = "0x60007A7")]
	[Address(RVA = "0x2D48FC0", Offset = "0x2D48FC0", VA = "0x2D48FC0")]
	private void ؤ\u05C8ԛ\u083F()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x060007A8 RID: 1960 RVA: 0x0002A518 File Offset: 0x00028718
	[Token(Token = "0x60007A8")]
	[Address(RVA = "0x2D49068", Offset = "0x2D49068", VA = "0x2D49068")]
	private void \u066A\u059Eټ\u085A()
	{
		NetworkPlayerSpawner.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060007A9 RID: 1961 RVA: 0x0002A52C File Offset: 0x0002872C
	[Token(Token = "0x60007A9")]
	[Address(RVA = "0x2D490BC", Offset = "0x2D490BC", VA = "0x2D490BC")]
	private void \u0614ࢥӴ\u086C()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x060007AA RID: 1962 RVA: 0x0002A58C File Offset: 0x0002878C
	[Token(Token = "0x60007AA")]
	[Address(RVA = "0x2D47474", Offset = "0x2D47474", VA = "0x2D47474")]
	private void Ӿةܤޠ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x060007AB RID: 1963 RVA: 0x0002A5B0 File Offset: 0x000287B0
	[Token(Token = "0x60007AB")]
	[Address(RVA = "0x2D46DC0", Offset = "0x2D46DC0", VA = "0x2D46DC0")]
	private void ࢭ\u0819ࡪݹ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x060007AC RID: 1964 RVA: 0x0002A5D4 File Offset: 0x000287D4
	[Token(Token = "0x60007AC")]
	[Address(RVA = "0x2D49164", Offset = "0x2D49164", VA = "0x2D49164")]
	private void ڃրӢԖ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x060007AD RID: 1965 RVA: 0x0002A634 File Offset: 0x00028834
	[Token(Token = "0x60007AD")]
	[Address(RVA = "0x2D4920C", Offset = "0x2D4920C", VA = "0x2D4920C")]
	private void ݞߒࢸڢ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x060007AE RID: 1966 RVA: 0x0002A694 File Offset: 0x00028894
	[Token(Token = "0x60007AE")]
	[Address(RVA = "0x2D492B4", Offset = "0x2D492B4", VA = "0x2D492B4")]
	private void Ӧد\u060Eࡏ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x060007AF RID: 1967 RVA: 0x0002A6F4 File Offset: 0x000288F4
	[Token(Token = "0x60007AF")]
	[Address(RVA = "0x2D48184", Offset = "0x2D48184", VA = "0x2D48184")]
	private void ݷ\u0819צԠ(Transform ࠔؼࡏݥ, Transform \u0875ݙػމ)
	{
		Vector3 position = \u0875ݙػމ.position;
		Quaternion rotation = \u0875ݙػމ.rotation;
	}

	// Token: 0x060007B0 RID: 1968 RVA: 0x0002A718 File Offset: 0x00028918
	[Token(Token = "0x60007B0")]
	[Address(RVA = "0x2D4935C", Offset = "0x2D4935C", VA = "0x2D4935C")]
	private void ߊ\u066A\u05CFԉ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.ڽߗ\u0652\u089E.<IsMine>k__BackingField)
		{
			Transform աߞ_u07A7ߦ = this.աߞ\u07A7ߦ;
			Transform u0742ӥӒԔ = this.\u0742ӥӒԔ;
			Transform ցԁ_u0740օ = this.ՑԀ\u0740օ;
			Transform ݍܘ_u0597Ԯ = this.ݍܘ\u0597Ԯ;
			Transform u0741_u06E2ӳࢣ = this.\u0741\u06E2ӳࢣ;
			Transform ք_u070Aߙ_u05F = this.ք\u070Aߙ\u05F8;
			return;
		}
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x0002A778 File Offset: 0x00028978
	[Token(Token = "0x60007B1")]
	[Address(RVA = "0x2D49404", Offset = "0x2D49404", VA = "0x2D49404", Slot = "31")]
	public override void OnLeftRoom()
	{
		base.OnLeftRoom();
		GameObject u05EEݠ_u05FFը = this.\u05EEݠ\u05FFը;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		PhotonNetwork.Destroy(u05EEݠ_u05FFը);
	}

	// Token: 0x040000FD RID: 253
	[Token(Token = "0x40000FD")]
	public static NetworkPlayerSpawner كݕ\u05F3\u0589;

	// Token: 0x040000FE RID: 254
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000FE")]
	public GameObject \u05EEݠ\u05FFը;

	// Token: 0x040000FF RID: 255
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40000FF")]
	public bool \u05C4ࡑڍۺ;

	// Token: 0x04000100 RID: 256
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000100")]
	public Transform \u0742ӥӒԔ;

	// Token: 0x04000101 RID: 257
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000101")]
	public Transform ݍܘ\u0597Ԯ;

	// Token: 0x04000102 RID: 258
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000102")]
	public Transform ք\u070Aߙ\u05F8;

	// Token: 0x04000103 RID: 259
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000103")]
	private Transform աߞ\u07A7ߦ;

	// Token: 0x04000104 RID: 260
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000104")]
	private Transform ՑԀ\u0740օ;

	// Token: 0x04000105 RID: 261
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000105")]
	private Transform \u0741\u06E2ӳࢣ;

	// Token: 0x04000106 RID: 262
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000106")]
	private Transform \u0877\u0602\u05EB\u087F;

	// Token: 0x04000107 RID: 263
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000107")]
	public PhotonView ڽߗ\u0652\u089E;
}
