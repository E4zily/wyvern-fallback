﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200005D RID: 93
[Token(Token = "0x200005D")]
public class ElevatorButton : MonoBehaviour
{
	// Token: 0x06000DC8 RID: 3528 RVA: 0x0004AC6C File Offset: 0x00048E6C
	[Token(Token = "0x6000DC8")]
	[Address(RVA = "0x28DDBC8", Offset = "0x28DDBC8", VA = "0x28DDBC8")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ݡࡠࡃܜ();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.Թ\u082F\u0594ԩ();
			return;
		}
	}

	// Token: 0x06000DC9 RID: 3529 RVA: 0x0004ACB4 File Offset: 0x00048EB4
	[Token(Token = "0x6000DC9")]
	[Address(RVA = "0x28DDEA4", Offset = "0x28DDEA4", VA = "0x28DDEA4")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u0733ܢ\u06D4\u073A();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u0887\u07BBלࡔ();
			return;
		}
	}

	// Token: 0x06000DCA RID: 3530 RVA: 0x0004ACFC File Offset: 0x00048EFC
	[Token(Token = "0x6000DCA")]
	[Address(RVA = "0x28DE180", Offset = "0x28DE180", VA = "0x28DE180")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ܐݭӐ\u0640();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u065C߁څܪ();
			return;
		}
	}

	// Token: 0x06000DCB RID: 3531 RVA: 0x0004AD44 File Offset: 0x00048F44
	[Token(Token = "0x6000DCB")]
	[Address(RVA = "0x28DE45C", Offset = "0x28DE45C", VA = "0x28DE45C")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u066D߈ےܒ();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.מ١ࡃ\u06FE();
			return;
		}
	}

	// Token: 0x06000DCC RID: 3532 RVA: 0x0004AD8C File Offset: 0x00048F8C
	[Token(Token = "0x6000DCC")]
	[Address(RVA = "0x28DE738", Offset = "0x28DE738", VA = "0x28DE738")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ܐݭӐ\u0640();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u0650\u06E3\u0654ב();
			return;
		}
	}

	// Token: 0x06000DCD RID: 3533 RVA: 0x0004ADD4 File Offset: 0x00048FD4
	[Token(Token = "0x6000DCD")]
	[Address(RVA = "0x28DE914", Offset = "0x28DE914", VA = "0x28DE914")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ه\u055Cࡋۋ();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u0887\u07BBלࡔ();
			return;
		}
	}

	// Token: 0x06000DCE RID: 3534 RVA: 0x0004AE1C File Offset: 0x0004901C
	[Token(Token = "0x6000DCE")]
	[Address(RVA = "0x28DEAF0", Offset = "0x28DEAF0", VA = "0x28DEAF0")]
	public ElevatorButton()
	{
	}

	// Token: 0x06000DCF RID: 3535 RVA: 0x0004AE30 File Offset: 0x00049030
	[Token(Token = "0x6000DCF")]
	[Address(RVA = "0x28DEAF8", Offset = "0x28DEAF8", VA = "0x28DEAF8")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ԈلՔ\u07F6();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u0557ࠄӉՑ();
			return;
		}
	}

	// Token: 0x06000DD0 RID: 3536 RVA: 0x0004AE78 File Offset: 0x00049078
	[Token(Token = "0x6000DD0")]
	[Address(RVA = "0x28DEDD4", Offset = "0x28DEDD4", VA = "0x28DEDD4")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ݛ\u05EBդߌ();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u065C߁څܪ();
			return;
		}
	}

	// Token: 0x06000DD1 RID: 3537 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000DD1")]
	[Address(RVA = "0x28DEFB0", Offset = "0x28DEFB0", VA = "0x28DEFB0")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000DD2 RID: 3538 RVA: 0x0004AEC0 File Offset: 0x000490C0
	[Token(Token = "0x6000DD2")]
	[Address(RVA = "0x28DF18C", Offset = "0x28DF18C", VA = "0x28DF18C")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ԙہ\u0826Ӽ();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u064DԵ\u073C\u073F();
			return;
		}
	}

	// Token: 0x06000DD3 RID: 3539 RVA: 0x0004AEFC File Offset: 0x000490FC
	[Token(Token = "0x6000DD3")]
	[Address(RVA = "0x28DF468", Offset = "0x28DF468", VA = "0x28DF468")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ܐݭӐ\u0640();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u064DԵ\u073C\u073F();
			return;
		}
	}

	// Token: 0x06000DD4 RID: 3540 RVA: 0x0004AF44 File Offset: 0x00049144
	[Token(Token = "0x6000DD4")]
	[Address(RVA = "0x28DF544", Offset = "0x28DF544", VA = "0x28DF544")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ݡࡠࡃܜ();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u082Eߞԙݻ();
			return;
		}
	}

	// Token: 0x06000DD5 RID: 3541 RVA: 0x0004AF8C File Offset: 0x0004918C
	[Token(Token = "0x6000DD5")]
	[Address(RVA = "0x28DF720", Offset = "0x28DF720", VA = "0x28DF720")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u074C\u0870ࠈՓ();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u065C߁څܪ();
			return;
		}
	}

	// Token: 0x06000DD6 RID: 3542 RVA: 0x0004AFD4 File Offset: 0x000491D4
	[Token(Token = "0x6000DD6")]
	[Address(RVA = "0x28DF8FC", Offset = "0x28DF8FC", VA = "0x28DF8FC")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ࢮࠍ\u06D9ࠉ();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.ץ\u059Bܘء();
			return;
		}
	}

	// Token: 0x06000DD7 RID: 3543 RVA: 0x0004B01C File Offset: 0x0004921C
	[Token(Token = "0x6000DD7")]
	[Address(RVA = "0x28DFBD8", Offset = "0x28DFBD8", VA = "0x28DFBD8")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ݡࡠࡃܜ();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u0831\u06DCӞԺ();
			return;
		}
	}

	// Token: 0x06000DD8 RID: 3544 RVA: 0x0004B064 File Offset: 0x00049264
	[Token(Token = "0x6000DD8")]
	[Address(RVA = "0x28DFDB4", Offset = "0x28DFDB4", VA = "0x28DFDB4")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ԈلՔ\u07F6();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.Ԫԋ\u07FBߠ();
			return;
		}
	}

	// Token: 0x06000DD9 RID: 3545 RVA: 0x0004B0AC File Offset: 0x000492AC
	[Token(Token = "0x6000DD9")]
	[Address(RVA = "0x28DFF90", Offset = "0x28DFF90", VA = "0x28DFF90")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u06D9۲צ\u05B2();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u07BAޚՑԯ();
			return;
		}
	}

	// Token: 0x06000DDA RID: 3546 RVA: 0x0004B0F4 File Offset: 0x000492F4
	[Token(Token = "0x6000DDA")]
	[Address(RVA = "0x28E026C", Offset = "0x28E026C", VA = "0x28E026C")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u0733ܢ\u06D4\u073A();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u06E1ߕ\u0824Ԫ();
			return;
		}
	}

	// Token: 0x06000DDB RID: 3547 RVA: 0x0004B13C File Offset: 0x0004933C
	[Token(Token = "0x6000DDB")]
	[Address(RVA = "0x28E0448", Offset = "0x28E0448", VA = "0x28E0448")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.ࠈւ\u074Aڡ)
		{
			this.\u05C5Ԕ\u0700ࢶ.ࡤ\u06E4ةع();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.\u0831\u06DCӞԺ();
			return;
		}
	}

	// Token: 0x06000DDC RID: 3548 RVA: 0x0004B184 File Offset: 0x00049384
	[Token(Token = "0x6000DDC")]
	[Address(RVA = "0x28E0624", Offset = "0x28E0624", VA = "0x28E0624")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		bool ࠈւ_u074Aڡ = this.ࠈւ\u074Aڡ;
		this.\u05C5Ԕ\u0700ࢶ.ݛ\u05EBդߌ();
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.מ١ࡃ\u06FE();
			return;
		}
	}

	// Token: 0x06000DDD RID: 3549 RVA: 0x0004B1CC File Offset: 0x000493CC
	[Token(Token = "0x6000DDD")]
	[Address(RVA = "0x28E0700", Offset = "0x28E0700", VA = "0x28E0700")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (typeof(UnityEngine.Object).TypeHandle != null)
		{
			this.\u05C5Ԕ\u0700ࢶ.ݮעفӪ();
		}
		if (this.ܤ\u06FDܜ٤)
		{
			this.\u05C5Ԕ\u0700ࢶ.ڞ\u07FAڷ\u0884();
			return;
		}
	}

	// Token: 0x040001EB RID: 491
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001EB")]
	public ElevatorManager \u05C5Ԕ\u0700ࢶ;

	// Token: 0x040001EC RID: 492
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001EC")]
	public bool ࠈւ\u074Aڡ;

	// Token: 0x040001ED RID: 493
	[FieldOffset(Offset = "0x21")]
	[Token(Token = "0x40001ED")]
	public bool ܤ\u06FDܜ٤;
}
