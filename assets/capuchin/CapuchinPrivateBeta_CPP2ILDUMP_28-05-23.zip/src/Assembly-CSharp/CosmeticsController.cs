﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200009E RID: 158
[Token(Token = "0x200009E")]
public class CosmeticsController : MonoBehaviour
{
	// Token: 0x06001783 RID: 6019 RVA: 0x00082F94 File Offset: 0x00081194
	[Token(Token = "0x6001783")]
	[Address(RVA = "0x2893254", Offset = "0x2893254", VA = "0x2893254")]
	private void \u0732ڙԒࢺ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
		}
		if (this.ࡦԯ\u05EBڷ)
		{
			PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
			object[] array = new object[0];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x06001784 RID: 6020 RVA: 0x00083010 File Offset: 0x00081210
	[Token(Token = "0x6001784")]
	[Address(RVA = "0x28933C4", Offset = "0x28933C4", VA = "0x28933C4")]
	public IEnumerator Ւԟ\u0602\u06FD()
	{
		long <>1__state;
		CosmeticsController.ࡌگ߀\u06EB ࡌگ߀_u06EB = new CosmeticsController.ࡌگ߀\u06EB((int)<>1__state);
		<>1__state = 0L;
		ࡌگ߀_u06EB.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001785 RID: 6021 RVA: 0x00083034 File Offset: 0x00081234
	[Token(Token = "0x6001785")]
	[Address(RVA = "0x289343C", Offset = "0x289343C", VA = "0x289343C")]
	private void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		Material material = base.GetComponent<Renderer>().material;
		bool ڭԪԿ_u = this.ڭԪԿ\u0606;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		string u07AE_u0615_u088C_u07ED2;
		if (ڭԪԿ_u)
		{
			object[] array = new object[1];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
			{
				u07AE_u0615_u088C_u07ED2 = this.\u07AE\u0615\u088C\u07ED;
				return;
			}
		}
		else if (this.\u07AE\u0615\u088C\u07ED == null || u07AE_u0615_u088C_u07ED2 != null)
		{
			PlayerPrefs.SetString(this.\u07AE\u0615\u088C\u07ED, "On");
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001786 RID: 6022 RVA: 0x000830D8 File Offset: 0x000812D8
	[Token(Token = "0x6001786")]
	[Address(RVA = "0x28936D8", Offset = "0x28936D8", VA = "0x28936D8")]
	private void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "hh:mm:sstt";
		Material material = base.GetComponent<Renderer>().material;
		bool ڭԪԿ_u = this.ڭԪԿ\u0606;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		if (ڭԪԿ_u)
		{
			object[] array = new object[1];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
			{
				string u07AE_u0615_u088C_u07ED2 = this.\u07AE\u0615\u088C\u07ED;
				return;
			}
		}
		else
		{
			string u07AE_u0615_u088C_u07ED3 = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED3 == null || u07AE_u0615_u088C_u07ED3 != null)
			{
				PlayerPrefs.SetString(this.\u07AE\u0615\u088C\u07ED, "PLAYER IS BANNED");
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001787 RID: 6023 RVA: 0x0008317C File Offset: 0x0008137C
	[Token(Token = "0x6001787")]
	[Address(RVA = "0x2893978", Offset = "0x2893978", VA = "0x2893978")]
	private void Update()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
		}
		if (this.ࡦԯ\u05EBڷ)
		{
			PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
			object[] array = new object[1];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x06001788 RID: 6024 RVA: 0x000831F4 File Offset: 0x000813F4
	[Token(Token = "0x6001788")]
	[Address(RVA = "0x2893AE4", Offset = "0x2893AE4", VA = "0x2893AE4")]
	public void הԥ\u05B5ݴ()
	{
		bool flag = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "Target";
		IEnumerator routine = this.\u05B6ڪࡢࠈ();
		Coroutine coroutine = base.StartCoroutine(routine);
		bool flag2 = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "Name Changing Error. Error: ";
		IEnumerator routine2;
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001789 RID: 6025 RVA: 0x00083248 File Offset: 0x00081448
	[Token(Token = "0x6001789")]
	[Address(RVA = "0x2893C7C", Offset = "0x2893C7C", VA = "0x2893C7C")]
	public IEnumerator өݬ\u05BA\u07BE()
	{
		long <>1__state;
		CosmeticsController.ࡌگ߀\u06EB ࡌگ߀_u06EB = new CosmeticsController.ࡌگ߀\u06EB((int)<>1__state);
		<>1__state = 0L;
		ࡌگ߀_u06EB.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600178A RID: 6026 RVA: 0x0008326C File Offset: 0x0008146C
	[Token(Token = "0x600178A")]
	[Address(RVA = "0x2893BA8", Offset = "0x2893BA8", VA = "0x2893BA8")]
	public IEnumerator \u05B6ڪࡢࠈ()
	{
		long <>1__state;
		CosmeticsController.ࡌگ߀\u06EB ࡌگ߀_u06EB = new CosmeticsController.ࡌگ߀\u06EB((int)<>1__state);
		<>1__state = 1L;
		ࡌگ߀_u06EB.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600178B RID: 6027 RVA: 0x00083290 File Offset: 0x00081490
	[Token(Token = "0x600178B")]
	[Address(RVA = "0x2893CF4", Offset = "0x2893CF4", VA = "0x2893CF4")]
	public IEnumerator ԚڇӋև()
	{
		long <>1__state;
		CosmeticsController.ࡌگ߀\u06EB ࡌگ߀_u06EB = new CosmeticsController.ࡌگ߀\u06EB((int)<>1__state);
		<>1__state = 0L;
		ࡌگ߀_u06EB.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600178C RID: 6028 RVA: 0x000832B4 File Offset: 0x000814B4
	[Token(Token = "0x600178C")]
	[Address(RVA = "0x2893D6C", Offset = "0x2893D6C", VA = "0x2893D6C")]
	public IEnumerator כ\u05A9ࡘڙ()
	{
		/*
An exception occurred when decompiling this method (0600178C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::כ֩ࡘڙ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:'ܓްӴՃ'(var_0_06, newobj:'ܓްӴՃ'('ܓްӴՃ'::.ctor, ldloc:int64[exp:int32](var_1))); 	stloc:int64(var_1, ldc.i4:int64(1)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600178D RID: 6029 RVA: 0x000832CC File Offset: 0x000814CC
	[Token(Token = "0x600178D")]
	[Address(RVA = "0x2893DC8", Offset = "0x2893DC8", VA = "0x2893DC8")]
	private void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x0600178E RID: 6030 RVA: 0x000832EC File Offset: 0x000814EC
	[Token(Token = "0x600178E")]
	[Address(RVA = "0x2893E7C", Offset = "0x2893E7C", VA = "0x2893E7C")]
	private void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "tutorialCheck";
		Material material = base.GetComponent<Renderer>().material;
		bool ڭԪԿ_u = this.ڭԪԿ\u0606;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (ڭԪԿ_u)
		{
			return;
		}
		PlayerPrefs.SetString(this.\u07AE\u0615\u088C\u07ED, "PURCHASED");
	}

	// Token: 0x0600178F RID: 6031 RVA: 0x0008337C File Offset: 0x0008157C
	[Token(Token = "0x600178F")]
	[Address(RVA = "0x28940AC", Offset = "0x28940AC", VA = "0x28940AC")]
	private void \u087BӦןݩ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
		}
		if (this.ࡦԯ\u05EBڷ)
		{
			PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
			object[] array = new object[0];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x06001790 RID: 6032 RVA: 0x000833F8 File Offset: 0x000815F8
	[Token(Token = "0x6001790")]
	[Address(RVA = "0x289421C", Offset = "0x289421C", VA = "0x289421C")]
	public void Start()
	{
		bool flag = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "true";
		IEnumerator routine = this.ԚڇӋև();
		Coroutine coroutine = base.StartCoroutine(routine);
		bool flag2 = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "false";
		IEnumerator routine2;
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001791 RID: 6033 RVA: 0x0008344C File Offset: 0x0008164C
	[Token(Token = "0x6001791")]
	[Address(RVA = "0x289433C", Offset = "0x289433C", VA = "0x289433C")]
	public IEnumerator կ\u086Bգޚ()
	{
		long <>1__state;
		CosmeticsController.ࡌگ߀\u06EB ࡌگ߀_u06EB = new CosmeticsController.ࡌگ߀\u06EB((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x06001792 RID: 6034 RVA: 0x00083468 File Offset: 0x00081668
	[Token(Token = "0x6001792")]
	[Address(RVA = "0x28943B4", Offset = "0x28943B4", VA = "0x28943B4")]
	private void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "User has been reported for: ";
		Material material = base.GetComponent<Renderer>().material;
		bool ڭԪԿ_u = this.ڭԪԿ\u0606;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		if (ڭԪԿ_u)
		{
			object[] array = new object[0];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
			{
				string u07AE_u0615_u088C_u07ED2 = this.\u07AE\u0615\u088C\u07ED;
				return;
			}
		}
		else
		{
			string u07AE_u0615_u088C_u07ED3 = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED3 == null || u07AE_u0615_u088C_u07ED3 != null)
			{
				PlayerPrefs.SetString(this.\u07AE\u0615\u088C\u07ED, "On");
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001793 RID: 6035 RVA: 0x00083510 File Offset: 0x00081710
	[Token(Token = "0x6001793")]
	[Address(RVA = "0x2894644", Offset = "0x2894644", VA = "0x2894644")]
	public void \u073BօӁ\u059A()
	{
		bool flag = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "_Tint";
		IEnumerator routine = this.ط\u0890Ռذ();
		Coroutine coroutine = base.StartCoroutine(routine);
		bool flag2 = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "BLUTARG";
		IEnumerator routine2;
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x06001794 RID: 6036 RVA: 0x00083564 File Offset: 0x00081764
	[Token(Token = "0x6001794")]
	[Address(RVA = "0x28947DC", Offset = "0x28947DC", VA = "0x28947DC")]
	private void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001795 RID: 6037 RVA: 0x00083584 File Offset: 0x00081784
	[Token(Token = "0x6001795")]
	[Address(RVA = "0x2894890", Offset = "0x2894890", VA = "0x2894890")]
	private void ւࡂ\u0883\u0872()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
		}
		if (this.ࡦԯ\u05EBڷ)
		{
			PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
			object[] array = new object[0];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
			{
				throw new ArrayTypeMismatchException();
			}
			long ࡦԯ_u05EBڷ = 1L;
			this.ࡦԯ\u05EBڷ = (ࡦԯ_u05EBڷ != 0L);
		}
	}

	// Token: 0x06001796 RID: 6038 RVA: 0x0008360C File Offset: 0x0008180C
	[Token(Token = "0x6001796")]
	[Address(RVA = "0x2894A04", Offset = "0x2894A04", VA = "0x2894A04")]
	private void \u0872\u0610ۅ\u06E1(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001797 RID: 6039 RVA: 0x0008362C File Offset: 0x0008182C
	[Token(Token = "0x6001797")]
	[Address(RVA = "0x2893C20", Offset = "0x2893C20", VA = "0x2893C20")]
	public IEnumerator Ӯԏ\u0592\u05C3()
	{
		/*
An exception occurred when decompiling this method (06001797)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::Ӯԏ֒׃()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:'ܓްӴՃ'(var_0_06, newobj:'ܓްӴՃ'('ܓްӴՃ'::.ctor, ldloc:int64[exp:int32](var_1))); 	stloc:int64(var_1, ldc.i4:int64(1)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06001798 RID: 6040 RVA: 0x00083644 File Offset: 0x00081844
	[Token(Token = "0x6001798")]
	[Address(RVA = "0x2894AB8", Offset = "0x2894AB8", VA = "0x2894AB8")]
	public IEnumerator ڄٸ\u07B3ܞ()
	{
		long <>1__state;
		CosmeticsController.ࡌگ߀\u06EB ࡌگ߀_u06EB = new CosmeticsController.ࡌگ߀\u06EB((int)<>1__state);
		<>1__state = 1L;
		ࡌگ߀_u06EB.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001799 RID: 6041 RVA: 0x00083668 File Offset: 0x00081868
	[Token(Token = "0x6001799")]
	[Address(RVA = "0x2894B30", Offset = "0x2894B30", VA = "0x2894B30")]
	private void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Room Name: ";
		Material material = base.GetComponent<Renderer>().material;
		bool ڭԪԿ_u = this.ڭԪԿ\u0606;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (this.\u07AE\u0615\u088C\u07ED != null)
		{
		}
		if (ڭԪԿ_u)
		{
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			return;
		}
		PlayerPrefs.SetString(this.\u07AE\u0615\u088C\u07ED, "PURCHASED");
	}

	// Token: 0x0600179A RID: 6042 RVA: 0x000836F8 File Offset: 0x000818F8
	[Token(Token = "0x600179A")]
	[Address(RVA = "0x2894DA8", Offset = "0x2894DA8", VA = "0x2894DA8")]
	private void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x0600179B RID: 6043 RVA: 0x00083718 File Offset: 0x00081918
	[Token(Token = "0x600179B")]
	[Address(RVA = "0x2894E5C", Offset = "0x2894E5C", VA = "0x2894E5C")]
	public void ݤۅࢦӃ()
	{
		string @string = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED);
		IEnumerator routine = this.ط\u0890Ռذ();
		Coroutine coroutine = base.StartCoroutine(routine);
		bool flag = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "Meta Platform entitlement error: ";
		IEnumerator routine2;
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x0600179C RID: 6044 RVA: 0x00083764 File Offset: 0x00081964
	[Token(Token = "0x600179C")]
	[Address(RVA = "0x28942E0", Offset = "0x28942E0", VA = "0x28942E0")]
	public IEnumerator Փ\u06DEݖܛ()
	{
		/*
An exception occurred when decompiling this method (0600179C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::Փ۞ݖܛ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:'ܓްӴՃ'(var_0_06, newobj:'ܓްӴՃ'('ܓްӴՃ'::.ctor, ldloc:int64[exp:int32](var_1))); 	stloc:int64(var_1, ldc.i4:int64(0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600179D RID: 6045 RVA: 0x0008377C File Offset: 0x0008197C
	[Token(Token = "0x600179D")]
	[Address(RVA = "0x2894F20", Offset = "0x2894F20", VA = "0x2894F20")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
		}
		if (this.ࡦԯ\u05EBڷ)
		{
			PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
			object[] array = new object[1];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x0600179E RID: 6046 RVA: 0x000837F4 File Offset: 0x000819F4
	[Token(Token = "0x600179E")]
	[Address(RVA = "0x289508C", Offset = "0x289508C", VA = "0x289508C")]
	public void ӛ\u082Eؿڕ()
	{
		bool flag = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "_BumpScale";
		IEnumerator routine = this.өݬ\u05BA\u07BE();
		Coroutine coroutine = base.StartCoroutine(routine);
		bool flag2 = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "clickLol";
		IEnumerator routine2;
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x0600179F RID: 6047 RVA: 0x00083848 File Offset: 0x00081A48
	[Token(Token = "0x600179F")]
	[Address(RVA = "0x2895150", Offset = "0x2895150", VA = "0x2895150")]
	public void عۻԂ\u055E()
	{
		bool flag = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "RightHandAttachPoint";
		IEnumerator routine = this.ԚڇӋև();
		Coroutine coroutine = base.StartCoroutine(routine);
		bool flag2 = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "_Tint";
		IEnumerator routine2;
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x060017A0 RID: 6048 RVA: 0x0008389C File Offset: 0x00081A9C
	[Token(Token = "0x60017A0")]
	[Address(RVA = "0x2895270", Offset = "0x2895270", VA = "0x2895270")]
	private void ܫ\u085Eہӝ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060017A1 RID: 6049 RVA: 0x000838BC File Offset: 0x00081ABC
	[Token(Token = "0x60017A1")]
	[Address(RVA = "0x2895324", Offset = "0x2895324", VA = "0x2895324")]
	private void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060017A2 RID: 6050 RVA: 0x000838DC File Offset: 0x00081ADC
	[Token(Token = "0x60017A2")]
	[Address(RVA = "0x28953D4", Offset = "0x28953D4", VA = "0x28953D4")]
	private void \u0821\u059Fӕ\u0607()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView;
		photonView.lastOnSerializeDataReceived = photonView;
		if (new object[1] != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060017A3 RID: 6051 RVA: 0x0008391C File Offset: 0x00081B1C
	[Token(Token = "0x60017A3")]
	[Address(RVA = "0x2895544", Offset = "0x2895544", VA = "0x2895544")]
	public void \u06D6ې\u083Bࠉ()
	{
		bool flag = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "\n";
		IEnumerator routine = this.өݬ\u05BA\u07BE();
		Coroutine coroutine = base.StartCoroutine(routine);
		bool flag2 = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "PlayerDeath";
		IEnumerator routine2;
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x060017A4 RID: 6052 RVA: 0x00083970 File Offset: 0x00081B70
	[Token(Token = "0x60017A4")]
	[Address(RVA = "0x2895664", Offset = "0x2895664", VA = "0x2895664")]
	private void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "BloodKill";
		Material material = base.GetComponent<Renderer>().material;
		bool ڭԪԿ_u = this.ڭԪԿ\u0606;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		if (ڭԪԿ_u)
		{
			object[] array = new object[0];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
			{
				string u07AE_u0615_u088C_u07ED2 = this.\u07AE\u0615\u088C\u07ED;
				return;
			}
		}
		else
		{
			string u07AE_u0615_u088C_u07ED3 = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED3 == null || u07AE_u0615_u088C_u07ED3 != null)
			{
				PlayerPrefs.SetString(this.\u07AE\u0615\u088C\u07ED, "isLava");
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060017A5 RID: 6053 RVA: 0x00083A18 File Offset: 0x00081C18
	[Token(Token = "0x60017A5")]
	[Address(RVA = "0x2895904", Offset = "0x2895904", VA = "0x2895904")]
	private void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Key";
		Material material = base.GetComponent<Renderer>().material;
		bool ڭԪԿ_u = this.ڭԪԿ\u0606;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (ڭԪԿ_u)
		{
			string u07AE_u0615_u088C_u07ED2 = this.\u07AE\u0615\u088C\u07ED;
			return;
		}
		if ("Vector1_d371bd24217449349bd747533d51af6b" != null)
		{
			PlayerPrefs.SetString(this.\u07AE\u0615\u088C\u07ED, "Player");
			return;
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x060017A6 RID: 6054 RVA: 0x00083AB4 File Offset: 0x00081CB4
	[Token(Token = "0x60017A6")]
	[Address(RVA = "0x2895B7C", Offset = "0x2895B7C", VA = "0x2895B7C")]
	public IEnumerator ٷߑە\u07B5()
	{
		/*
An exception occurred when decompiling this method (060017A6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::ٷߑە޵()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:'ܓްӴՃ'(var_0_06, newobj:'ܓްӴՃ'('ܓްӴՃ'::.ctor, ldloc:int64[exp:int32](var_1))); 	stloc:int64(var_1, ldc.i4:int64(0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060017A7 RID: 6055 RVA: 0x00083ACC File Offset: 0x00081CCC
	[Token(Token = "0x60017A7")]
	[Address(RVA = "0x2895BD8", Offset = "0x2895BD8", VA = "0x2895BD8")]
	public IEnumerator ڥװ۴\u0602()
	{
		long <>1__state;
		CosmeticsController.ࡌگ߀\u06EB ࡌگ߀_u06EB = new CosmeticsController.ࡌگ߀\u06EB((int)<>1__state);
		<>1__state = 0L;
		ࡌگ߀_u06EB.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060017A8 RID: 6056 RVA: 0x00083AF0 File Offset: 0x00081CF0
	[Token(Token = "0x60017A8")]
	[Address(RVA = "0x2895C50", Offset = "0x2895C50", VA = "0x2895C50")]
	private void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayerHead";
		Material material = base.GetComponent<Renderer>().material;
		bool ڭԪԿ_u = this.ڭԪԿ\u0606;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		if (ڭԪԿ_u)
		{
			object[] array = new object[1];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
			{
				string u07AE_u0615_u088C_u07ED2 = this.\u07AE\u0615\u088C\u07ED;
				return;
			}
		}
		else
		{
			string u07AE_u0615_u088C_u07ED3 = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED3 == null || u07AE_u0615_u088C_u07ED3 != null)
			{
				PlayerPrefs.SetString(this.\u07AE\u0615\u088C\u07ED, "Players: ");
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060017A9 RID: 6057 RVA: 0x00083B98 File Offset: 0x00081D98
	[Token(Token = "0x60017A9")]
	[Address(RVA = "0x2895EF0", Offset = "0x2895EF0", VA = "0x2895EF0")]
	private void \u0590\u0882\u0883ࡦ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
		}
		if (this.ࡦԯ\u05EBڷ)
		{
			PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
			object[] array = new object[1];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x060017AA RID: 6058 RVA: 0x00083C10 File Offset: 0x00081E10
	[Token(Token = "0x60017AA")]
	[Address(RVA = "0x2895214", Offset = "0x2895214", VA = "0x2895214")]
	public IEnumerator ۇ\u082D\u05CF\u088B()
	{
		/*
An exception occurred when decompiling this method (060017AA)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::ۇ࠭׏ࢋ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:'ܓްӴՃ'(var_0_06, newobj:'ܓްӴՃ'('ܓްӴՃ'::.ctor, ldloc:int64[exp:int32](var_1))); 	stloc:int64(var_1, ldc.i4:int64(0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060017AB RID: 6059 RVA: 0x00083C28 File Offset: 0x00081E28
	[Token(Token = "0x60017AB")]
	[Address(RVA = "0x289605C", Offset = "0x289605C", VA = "0x289605C")]
	private void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Charging...";
		Material material = base.GetComponent<Renderer>().material;
		bool ڭԪԿ_u = this.ڭԪԿ\u0606;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		if (ڭԪԿ_u)
		{
			object[] array = new object[0];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
			{
				return;
			}
		}
		else
		{
			string u07AE_u0615_u088C_u07ED2 = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED2 == null || u07AE_u0615_u088C_u07ED2 != null)
			{
				PlayerPrefs.SetString(this.\u07AE\u0615\u088C\u07ED, "FingerTip");
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060017AC RID: 6060 RVA: 0x00083CC8 File Offset: 0x00081EC8
	[Token(Token = "0x60017AC")]
	[Address(RVA = "0x28962D4", Offset = "0x28962D4", VA = "0x28962D4")]
	public IEnumerator ݷ\u05CE\u0600\u0605()
	{
		/*
An exception occurred when decompiling this method (060017AC)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::ݷ׎؀؅()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:'ܓްӴՃ'(var_0_06, newobj:'ܓްӴՃ'('ܓްӴՃ'::.ctor, ldloc:int64[exp:int32](var_1))); 	stloc:int64(var_1, ldc.i4:int64(1)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060017AD RID: 6061 RVA: 0x00083CE0 File Offset: 0x00081EE0
	[Token(Token = "0x60017AD")]
	[Address(RVA = "0x2896330", Offset = "0x2896330", VA = "0x2896330")]
	private void قԙ\u0653պ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060017AE RID: 6062 RVA: 0x00083D00 File Offset: 0x00081F00
	[Token(Token = "0x60017AE")]
	[Address(RVA = "0x2894780", Offset = "0x2894780", VA = "0x2894780")]
	public IEnumerator ԑڎ\u061A\u089E()
	{
		/*
An exception occurred when decompiling this method (060017AE)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::ԑڎؚ࢞()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:'ܓްӴՃ'(var_0_06, newobj:'ܓްӴՃ'('ܓްӴՃ'::.ctor, ldloc:int64[exp:int32](var_1))); 	stloc:int64(var_1, ldc.i4:int64(1)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060017AF RID: 6063 RVA: 0x00083D18 File Offset: 0x00081F18
	[Token(Token = "0x60017AF")]
	[Address(RVA = "0x28963E4", Offset = "0x28963E4", VA = "0x28963E4")]
	private void پ\u05F7\u06E6ރ(Collider \u07FEל\u05AC\u0877)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060017B0 RID: 6064 RVA: 0x00083D38 File Offset: 0x00081F38
	[Token(Token = "0x60017B0")]
	[Address(RVA = "0x2894708", Offset = "0x2894708", VA = "0x2894708")]
	public IEnumerator ط\u0890Ռذ()
	{
		long <>1__state;
		CosmeticsController.ࡌگ߀\u06EB ࡌگ߀_u06EB = new CosmeticsController.ࡌگ߀\u06EB((int)<>1__state);
		<>1__state = 0L;
		ࡌگ߀_u06EB.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060017B1 RID: 6065 RVA: 0x00083D5C File Offset: 0x00081F5C
	[Token(Token = "0x60017B1")]
	[Address(RVA = "0x2896498", Offset = "0x2896498", VA = "0x2896498")]
	public CosmeticsController()
	{
	}

	// Token: 0x060017B2 RID: 6066 RVA: 0x00083D7C File Offset: 0x00081F7C
	[Token(Token = "0x60017B2")]
	[Address(RVA = "0x28964AC", Offset = "0x28964AC", VA = "0x28964AC")]
	private void \u0599ږࠆ\u065F()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
		}
		if (this.ࡦԯ\u05EBڷ)
		{
			PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
			object[] parameters = new object[1];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
			{
				throw new ArrayTypeMismatchException();
			}
			u07AE_u05AF_u064FԖ.RPC("Player", RpcTarget.AllViaServer, parameters);
			long ࡦԯ_u05EBڷ = 1L;
			this.ࡦԯ\u05EBڷ = (ࡦԯ_u05EBڷ != 0L);
		}
	}

	// Token: 0x060017B3 RID: 6067 RVA: 0x00083E10 File Offset: 0x00082010
	[Token(Token = "0x60017B3")]
	[Address(RVA = "0x289661C", Offset = "0x289661C", VA = "0x289661C")]
	public void \u082E\u06EBݼڏ()
	{
		bool flag = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "FingerTip";
		IEnumerator routine = this.ڄٸ\u07B3ܞ();
		Coroutine coroutine = base.StartCoroutine(routine);
		bool flag2 = PlayerPrefs.GetString(this.\u07AE\u0615\u088C\u07ED) == "NoseAttachPoint";
		IEnumerator routine2;
		Coroutine coroutine2 = base.StartCoroutine(routine2);
	}

	// Token: 0x060017B4 RID: 6068 RVA: 0x00083E64 File Offset: 0x00082064
	[Token(Token = "0x60017B4")]
	[Address(RVA = "0x2895608", Offset = "0x2895608", VA = "0x2895608")]
	public IEnumerator Ցگࡈ\u0656()
	{
		/*
An exception occurred when decompiling this method (060017B4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::Ցگࡈٖ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:'ܓްӴՃ'(var_0_06, newobj:'ܓްӴՃ'('ܓްӴՃ'::.ctor, ldloc:int64[exp:int32](var_1))); 	stloc:int64(var_1, ldc.i4:int64(1)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060017B5 RID: 6069 RVA: 0x00083E7C File Offset: 0x0008207C
	[Token(Token = "0x60017B5")]
	[Address(RVA = "0x28966E0", Offset = "0x28966E0", VA = "0x28966E0")]
	private void \u05F8ݑ\u06ECߞ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
		}
		if (this.ࡦԯ\u05EBڷ)
		{
			PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
			object[] array = new object[0];
			string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
			if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x060017B6 RID: 6070 RVA: 0x00083EF8 File Offset: 0x000820F8
	[Token(Token = "0x60017B6")]
	[Address(RVA = "0x289684C", Offset = "0x289684C", VA = "0x289684C")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		Material material = base.GetComponent<Renderer>().material;
		bool ڭԪԿ_u = this.ڭԪԿ\u0606;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED != null && u07AE_u0615_u088C_u07ED == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (ڭԪԿ_u)
		{
			string u07AE_u0615_u088C_u07ED2 = this.\u07AE\u0615\u088C\u07ED;
			return;
		}
		PlayerPrefs.SetString(this.\u07AE\u0615\u088C\u07ED, "false");
	}

	// Token: 0x040002E8 RID: 744
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002E8")]
	public bool ڭԪԿ\u0606;

	// Token: 0x040002E9 RID: 745
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002E9")]
	public string \u07AE\u0615\u088C\u07ED;

	// Token: 0x040002EA RID: 746
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40002EA")]
	private float \u087C\u0593Ӛ\u07A6 = (float)52429;

	// Token: 0x040002EB RID: 747
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40002EB")]
	public NetworkPlayerSpawner ߨאߨػ;

	// Token: 0x040002EC RID: 748
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40002EC")]
	private PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x040002ED RID: 749
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40002ED")]
	private bool ࡦԯ\u05EBڷ;
}
