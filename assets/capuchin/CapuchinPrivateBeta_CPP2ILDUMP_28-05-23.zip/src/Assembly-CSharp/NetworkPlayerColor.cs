﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000036 RID: 54
[Token(Token = "0x2000036")]
public class NetworkPlayerColor : MonoBehaviour
{
	// Token: 0x0600069C RID: 1692 RVA: 0x00026DAC File Offset: 0x00024FAC
	[Token(Token = "0x600069C")]
	[Address(RVA = "0x2D3CE74", Offset = "0x2D3CE74", VA = "0x2D3CE74")]
	[PunRPC]
	public void SetColor(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x0600069D RID: 1693 RVA: 0x00026DD0 File Offset: 0x00024FD0
	[Token(Token = "0x600069D")]
	[Address(RVA = "0x2D3CF84", Offset = "0x2D3CF84", VA = "0x2D3CF84")]
	private void \u055E\u0703\u0700ܠ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("Body", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("Universal Render Pipeline/Lit", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "Is Colliding";
			return;
		}
	}

	// Token: 0x0600069E RID: 1694 RVA: 0x00026E40 File Offset: 0x00025040
	[Token(Token = "0x600069E")]
	[Address(RVA = "0x2D3D130", Offset = "0x2D3D130", VA = "0x2D3D130")]
	public void \u082EՀ\u07AF\u0608(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600069F RID: 1695 RVA: 0x00026E7C File Offset: 0x0002507C
	[Token(Token = "0x600069F")]
	[Address(RVA = "0x2D3D264", Offset = "0x2D3D264", VA = "0x2D3D264")]
	public void ߈\u05ADڮ\u0889(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006A0 RID: 1696 RVA: 0x00026EA0 File Offset: 0x000250A0
	[Token(Token = "0x60006A0")]
	[Address(RVA = "0x2D3D374", Offset = "0x2D3D374", VA = "0x2D3D374")]
	public void ࢯԜכք(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006A1 RID: 1697 RVA: 0x00026EE0 File Offset: 0x000250E0
	[Token(Token = "0x60006A1")]
	[Address(RVA = "0x2D3D4A4", Offset = "0x2D3D4A4", VA = "0x2D3D4A4")]
	public void ߖ\u07EC\u0654\u07F7(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006A2 RID: 1698 RVA: 0x00026F04 File Offset: 0x00025104
	[Token(Token = "0x60006A2")]
	[Address(RVA = "0x2D3D5B4", Offset = "0x2D3D5B4", VA = "0x2D3D5B4")]
	public void ۰ݐ\u055E\u0613(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] parameters = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			u07AE_u05AF_u064FԖ.RPC("ENABLE", RpcTarget.AllViaServer, parameters);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006A3 RID: 1699 RVA: 0x00026F50 File Offset: 0x00025150
	[Token(Token = "0x60006A3")]
	[Address(RVA = "0x2D3D6E4", Offset = "0x2D3D6E4", VA = "0x2D3D6E4")]
	public void ײܢ\u05A6ࠃ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006A4 RID: 1700 RVA: 0x00026F90 File Offset: 0x00025190
	[Token(Token = "0x60006A4")]
	[Address(RVA = "0x2D3D814", Offset = "0x2D3D814", VA = "0x2D3D814")]
	private void וࡪךӧ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("procedural animation script required on ", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("Purchased: ", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "Cheating";
			return;
		}
	}

	// Token: 0x060006A5 RID: 1701 RVA: 0x00027000 File Offset: 0x00025200
	[Token(Token = "0x60006A5")]
	[Address(RVA = "0x2D3D9C0", Offset = "0x2D3D9C0", VA = "0x2D3D9C0")]
	public void \u089C\u058BߣԲ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006A6 RID: 1702 RVA: 0x00027040 File Offset: 0x00025240
	[Token(Token = "0x60006A6")]
	[Address(RVA = "0x2D3DAF0", Offset = "0x2D3DAF0", VA = "0x2D3DAF0")]
	public void \u0895ࠅ\u06DDլ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006A7 RID: 1703 RVA: 0x0002705C File Offset: 0x0002525C
	[Token(Token = "0x60006A7")]
	[Address(RVA = "0x2D3DBD8", Offset = "0x2D3DBD8", VA = "0x2D3DBD8")]
	public void \u0817ӯդ\u07B3(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006A8 RID: 1704 RVA: 0x0002709C File Offset: 0x0002529C
	[Token(Token = "0x60006A8")]
	[Address(RVA = "0x2D3DD0C", Offset = "0x2D3DD0C", VA = "0x2D3DD0C")]
	private void Start()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Shader ֆӝގس = this.Ֆӝގس;
			Texture2D value = this.ܚۃӬ߃;
			Material material;
			material.SetTexture("_BaseMap", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("_BumpMap", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "trol";
			return;
		}
	}

	// Token: 0x060006A9 RID: 1705 RVA: 0x00027108 File Offset: 0x00025308
	[Token(Token = "0x60006A9")]
	[Address(RVA = "0x2D3DEB4", Offset = "0x2D3DEB4", VA = "0x2D3DEB4")]
	public void ӡ\u0745ݳݪ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006AA RID: 1706 RVA: 0x00027144 File Offset: 0x00025344
	[Token(Token = "0x60006AA")]
	[Address(RVA = "0x2D3DFE8", Offset = "0x2D3DFE8", VA = "0x2D3DFE8")]
	public void \u086Cӌ\u07B6\u05B3(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006AB RID: 1707 RVA: 0x00027184 File Offset: 0x00025384
	[Token(Token = "0x60006AB")]
	[Address(RVA = "0x2D3E118", Offset = "0x2D3E118", VA = "0x2D3E118")]
	private void \u073BօӁ\u059A()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("EnableCosmetic", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("token", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "Player";
	}

	// Token: 0x060006AC RID: 1708 RVA: 0x000271EC File Offset: 0x000253EC
	[Token(Token = "0x60006AC")]
	[Address(RVA = "0x2D3E29C", Offset = "0x2D3E29C", VA = "0x2D3E29C")]
	public void ٱ\u064C\u055Cք(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006AD RID: 1709 RVA: 0x00027210 File Offset: 0x00025410
	[Token(Token = "0x60006AD")]
	[Address(RVA = "0x2D3E3AC", Offset = "0x2D3E3AC", VA = "0x2D3E3AC")]
	private void ԙڗ\u0705ܧ()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Shader ֆӝގس = this.Ֆӝގس;
		Texture2D texture2D = this.ܚۃӬ߃;
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
	}

	// Token: 0x060006AE RID: 1710 RVA: 0x00027250 File Offset: 0x00025450
	[Token(Token = "0x60006AE")]
	[Address(RVA = "0x2D3E530", Offset = "0x2D3E530", VA = "0x2D3E530")]
	private void ߁\u0829\u073E\u081A()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("Right Hand", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("Right Hand", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "Try Connect To Server...";
			return;
		}
	}

	// Token: 0x060006AF RID: 1711 RVA: 0x000272C0 File Offset: 0x000254C0
	[Token(Token = "0x60006AF")]
	[Address(RVA = "0x2D3E6C8", Offset = "0x2D3E6C8", VA = "0x2D3E6C8")]
	public void ދ\u0736\u05BBչ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006B0 RID: 1712 RVA: 0x000272FC File Offset: 0x000254FC
	[Token(Token = "0x60006B0")]
	[Address(RVA = "0x2D3E7FC", Offset = "0x2D3E7FC", VA = "0x2D3E7FC")]
	public void \u055CԢجփ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006B1 RID: 1713 RVA: 0x00027338 File Offset: 0x00025538
	[Token(Token = "0x60006B1")]
	[Address(RVA = "0x2D3E930", Offset = "0x2D3E930", VA = "0x2D3E930")]
	public void ࡢࡡ\u061Aԫ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006B2 RID: 1714 RVA: 0x0002735C File Offset: 0x0002555C
	[Token(Token = "0x60006B2")]
	[Address(RVA = "0x2D3EA40", Offset = "0x2D3EA40", VA = "0x2D3EA40")]
	public void \u087Aئ\u089Cࡍ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x00027398 File Offset: 0x00025598
	[Token(Token = "0x60006B3")]
	[Address(RVA = "0x2D3EB70", Offset = "0x2D3EB70", VA = "0x2D3EB70")]
	public void ࠄ\u0654\u07BDդ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006B4 RID: 1716 RVA: 0x000273BC File Offset: 0x000255BC
	[Token(Token = "0x60006B4")]
	[Address(RVA = "0x2D3EC80", Offset = "0x2D3EC80", VA = "0x2D3EC80")]
	private void ߖհݣ߀()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Shader ֆӝގس = this.Ֆӝގس;
			Texture2D texture2D = this.ܚۃӬ߃;
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			return;
		}
	}

	// Token: 0x060006B5 RID: 1717 RVA: 0x00027404 File Offset: 0x00025604
	[Token(Token = "0x60006B5")]
	[Address(RVA = "0x2D3EE2C", Offset = "0x2D3EE2C", VA = "0x2D3EE2C")]
	public void \u085AҼӓߦ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006B6 RID: 1718 RVA: 0x00027420 File Offset: 0x00025620
	[Token(Token = "0x60006B6")]
	[Address(RVA = "0x2D3EF14", Offset = "0x2D3EF14", VA = "0x2D3EF14")]
	public void \u0878ݼՏ\u0707(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x0002743C File Offset: 0x0002563C
	[Token(Token = "0x60006B7")]
	[Address(RVA = "0x2D3EFFC", Offset = "0x2D3EFFC", VA = "0x2D3EFFC")]
	public void \u070B\u0558\u074Aؽ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (array == null || array != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006B8 RID: 1720 RVA: 0x00027470 File Offset: 0x00025670
	[Token(Token = "0x60006B8")]
	[Address(RVA = "0x2D3F12C", Offset = "0x2D3F12C", VA = "0x2D3F12C")]
	private void ۆڛߟ\u05A0()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("_BaseColor", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("Room1", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = ".Please press the button if you would like to play alone";
			return;
		}
	}

	// Token: 0x060006B9 RID: 1721 RVA: 0x000274E0 File Offset: 0x000256E0
	[Token(Token = "0x60006B9")]
	[Address(RVA = "0x2D3F2D8", Offset = "0x2D3F2D8", VA = "0x2D3F2D8")]
	public void ڼ\u081Dڰ\u0870(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006BA RID: 1722 RVA: 0x00027504 File Offset: 0x00025704
	[Token(Token = "0x60006BA")]
	[Address(RVA = "0x2D3F3E8", Offset = "0x2D3F3E8", VA = "0x2D3F3E8")]
	public void ܥԦ\u0740ށ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006BB RID: 1723 RVA: 0x00027540 File Offset: 0x00025740
	[Token(Token = "0x60006BB")]
	[Address(RVA = "0x2D3F518", Offset = "0x2D3F518", VA = "0x2D3F518")]
	public void ք\u0610ک\u0558(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006BC RID: 1724 RVA: 0x00027564 File Offset: 0x00025764
	[Token(Token = "0x60006BC")]
	[Address(RVA = "0x2D3F628", Offset = "0x2D3F628", VA = "0x2D3F628")]
	private void ދ\u05A3\u06DCہ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("isLava", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("PlayWave", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "Vector1_d371bd24217449349bd747533d51af6b";
			return;
		}
	}

	// Token: 0x060006BD RID: 1725 RVA: 0x000275D4 File Offset: 0x000257D4
	[Token(Token = "0x60006BD")]
	[Address(RVA = "0x2D3F7D4", Offset = "0x2D3F7D4", VA = "0x2D3F7D4")]
	private void چ\u05AEךڰ()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("HeadAttachPoint", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("jump char false", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "A Player has left the Room.";
	}

	// Token: 0x060006BE RID: 1726 RVA: 0x0002763C File Offset: 0x0002583C
	[Token(Token = "0x60006BE")]
	[Address(RVA = "0x2D3F958", Offset = "0x2D3F958", VA = "0x2D3F958")]
	private void ࢥ\u081CՕࡋ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("typesOfTalk", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("Failed To Join Public Room Successfully. The error is: ", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "next";
			return;
		}
	}

	// Token: 0x060006BF RID: 1727 RVA: 0x000276A8 File Offset: 0x000258A8
	[Token(Token = "0x60006BF")]
	[Address(RVA = "0x2D3FB04", Offset = "0x2D3FB04", VA = "0x2D3FB04")]
	public void ࢢ\u0886ࢨԳ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006C0 RID: 1728 RVA: 0x000276CC File Offset: 0x000258CC
	[Token(Token = "0x60006C0")]
	[Address(RVA = "0x2D3FC14", Offset = "0x2D3FC14", VA = "0x2D3FC14")]
	public void ӱӻࢯؠ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006C1 RID: 1729 RVA: 0x000276E8 File Offset: 0x000258E8
	[Token(Token = "0x60006C1")]
	[Address(RVA = "0x2D3FCFC", Offset = "0x2D3FCFC", VA = "0x2D3FCFC")]
	public void ࠎޑ\u081B\u07A9(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006C2 RID: 1730 RVA: 0x00027728 File Offset: 0x00025928
	[Token(Token = "0x60006C2")]
	[Address(RVA = "0x2D3FE30", Offset = "0x2D3FE30", VA = "0x2D3FE30")]
	public void ս\u05BA\u0839ԫ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006C3 RID: 1731 RVA: 0x00027768 File Offset: 0x00025968
	[Token(Token = "0x60006C3")]
	[Address(RVA = "0x2D3FF64", Offset = "0x2D3FF64", VA = "0x2D3FF64")]
	public void ۸ࡦ\u060A\u0605(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006C4 RID: 1732 RVA: 0x000277A8 File Offset: 0x000259A8
	[Token(Token = "0x60006C4")]
	[Address(RVA = "0x2D40094", Offset = "0x2D40094", VA = "0x2D40094")]
	private void \u064FӆࡒԲ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("Failed to get catalog, cosmetic name, and price. Exact error details is: ", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("TurnAmount", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			return;
		}
	}

	// Token: 0x060006C5 RID: 1733 RVA: 0x0002780C File Offset: 0x00025A0C
	[Token(Token = "0x60006C5")]
	[Address(RVA = "0x2D40240", Offset = "0x2D40240", VA = "0x2D40240")]
	public void \u070A\u06FEࡕ\u058C(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] parameters = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			u07AE_u05AF_u064FԖ.RPC("You are not the master of the server, you cannot start the game.", RpcTarget.AllViaServer, parameters);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006C6 RID: 1734 RVA: 0x00027858 File Offset: 0x00025A58
	[Token(Token = "0x60006C6")]
	[Address(RVA = "0x2D40374", Offset = "0x2D40374", VA = "0x2D40374")]
	private void ԦӔԁֆ()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("Failed to get catalog, cosmetic name, and price. Exact error details is: ", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("Player", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "Date: ";
	}

	// Token: 0x060006C7 RID: 1735 RVA: 0x000278C0 File Offset: 0x00025AC0
	[Token(Token = "0x60006C7")]
	[Address(RVA = "0x2D404F4", Offset = "0x2D404F4", VA = "0x2D404F4")]
	private void ԞԌ\u086FՇ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("Display Name Changed!", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture(". Please update you game to the latest version", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "Player";
			return;
		}
	}

	// Token: 0x060006C8 RID: 1736 RVA: 0x00027930 File Offset: 0x00025B30
	[Token(Token = "0x60006C8")]
	[Address(RVA = "0x2D406A0", Offset = "0x2D406A0", VA = "0x2D406A0")]
	private void ռտܙߗ()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("PlayWave", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("FingerTip", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "ScoreCounter";
	}

	// Token: 0x060006C9 RID: 1737 RVA: 0x00027998 File Offset: 0x00025B98
	[Token(Token = "0x60006C9")]
	[Address(RVA = "0x2D40824", Offset = "0x2D40824", VA = "0x2D40824")]
	private void ޠۋ\u0530\u073E()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("Add/Remove Sword", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("username", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "username";
	}

	// Token: 0x060006CA RID: 1738 RVA: 0x00027A00 File Offset: 0x00025C00
	[Token(Token = "0x60006CA")]
	[Address(RVA = "0x2D40994", Offset = "0x2D40994", VA = "0x2D40994")]
	public void \u0744ݭӘڥ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006CB RID: 1739 RVA: 0x00027A40 File Offset: 0x00025C40
	[Token(Token = "0x60006CB")]
	[Address(RVA = "0x2D40AC8", Offset = "0x2D40AC8", VA = "0x2D40AC8")]
	private void \u0558ݕݤݮ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("Diffuse", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("friend", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "Joined a Room.";
			return;
		}
	}

	// Token: 0x060006CC RID: 1740 RVA: 0x00027AB0 File Offset: 0x00025CB0
	[Token(Token = "0x60006CC")]
	[Address(RVA = "0x2D40C74", Offset = "0x2D40C74", VA = "0x2D40C74")]
	private void ࡅݐ\u082Dք()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("hh:mm:sstt", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("Players: ", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			return;
		}
	}

	// Token: 0x060006CD RID: 1741 RVA: 0x00027B14 File Offset: 0x00025D14
	[Token(Token = "0x60006CD")]
	[Address(RVA = "0x2D40E20", Offset = "0x2D40E20", VA = "0x2D40E20")]
	private void \u082E\u06EBݼڏ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Shader ֆӝގس = this.Ֆӝގس;
			Texture2D value = this.ܚۃӬ߃;
			Material material;
			material.SetTexture("Player", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "NetworkGunShoot";
			return;
		}
	}

	// Token: 0x060006CE RID: 1742 RVA: 0x00027B80 File Offset: 0x00025D80
	[Token(Token = "0x60006CE")]
	[Address(RVA = "0x2D40FCC", Offset = "0x2D40FCC", VA = "0x2D40FCC")]
	public void \u0650\u0745ݴ\u0706(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006CF RID: 1743 RVA: 0x00027BBC File Offset: 0x00025DBC
	[Token(Token = "0x60006CF")]
	[Address(RVA = "0x2D41100", Offset = "0x2D41100", VA = "0x2D41100")]
	public void \u0733ӝݔ\u0884(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006D0 RID: 1744 RVA: 0x00027BD8 File Offset: 0x00025DD8
	[Token(Token = "0x60006D0")]
	[Address(RVA = "0x2D411E8", Offset = "0x2D411E8", VA = "0x2D411E8")]
	public void \u081Cӗ\u066A\u0819(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006D1 RID: 1745 RVA: 0x00027C14 File Offset: 0x00025E14
	[Token(Token = "0x60006D1")]
	[Address(RVA = "0x2D4131C", Offset = "0x2D4131C", VA = "0x2D4131C")]
	public void ړԙ\u0603\u073A(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006D2 RID: 1746 RVA: 0x00027C30 File Offset: 0x00025E30
	[Token(Token = "0x60006D2")]
	[Address(RVA = "0x2D41404", Offset = "0x2D41404", VA = "0x2D41404")]
	private void ࢰחڵࡓ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("Error", value);
			material.SetTexture("Room Name: ", value);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			return;
		}
	}

	// Token: 0x060006D3 RID: 1747 RVA: 0x00027C90 File Offset: 0x00025E90
	[Token(Token = "0x60006D3")]
	[Address(RVA = "0x2D41584", Offset = "0x2D41584", VA = "0x2D41584")]
	public void \u0611ࠍࢧי(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006D4 RID: 1748 RVA: 0x00027CAC File Offset: 0x00025EAC
	[Token(Token = "0x60006D4")]
	[Address(RVA = "0x2D4166C", Offset = "0x2D4166C", VA = "0x2D4166C")]
	public void \u0741\u07A8ԫن(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006D5 RID: 1749 RVA: 0x00027CE8 File Offset: 0x00025EE8
	[Token(Token = "0x60006D5")]
	[Address(RVA = "0x2D417A0", Offset = "0x2D417A0", VA = "0x2D417A0")]
	public void \u06FE\u0596ֆݰ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006D6 RID: 1750 RVA: 0x00027D0C File Offset: 0x00025F0C
	[Token(Token = "0x60006D6")]
	[Address(RVA = "0x2D418B0", Offset = "0x2D418B0", VA = "0x2D418B0")]
	private void նܒزԊ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("Player", value);
			material.SetTexture("Push To Talk", value);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "EnableCosmetic";
			return;
		}
	}

	// Token: 0x060006D7 RID: 1751 RVA: 0x00027D74 File Offset: 0x00025F74
	[Token(Token = "0x60006D7")]
	[Address(RVA = "0x2D41A5C", Offset = "0x2D41A5C", VA = "0x2D41A5C")]
	public void چݶޘ\u086C(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006D8 RID: 1752 RVA: 0x00027DB4 File Offset: 0x00025FB4
	[Token(Token = "0x60006D8")]
	[Address(RVA = "0x2D41B90", Offset = "0x2D41B90", VA = "0x2D41B90")]
	public void Ոܛࢶݳ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006D9 RID: 1753 RVA: 0x00027DD0 File Offset: 0x00025FD0
	[Token(Token = "0x60006D9")]
	[Address(RVA = "0x2D41C78", Offset = "0x2D41C78", VA = "0x2D41C78")]
	private void \u066A\u059Eټ\u085A()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("isLava", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("ChangePlayerSize", u05B6_u061Cױ_u083E);
			Texture2D texture2D = this.ܚۃӬ߃;
			Texture2D texture2D2 = this.ܚۃӬ߃;
			material.name = "NormalWeather";
			return;
		}
	}

	// Token: 0x060006DA RID: 1754 RVA: 0x00027E48 File Offset: 0x00026048
	[Token(Token = "0x60006DA")]
	[Address(RVA = "0x2D41E24", Offset = "0x2D41E24", VA = "0x2D41E24")]
	private void ۮߝڪڐ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("isLava", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("isLava", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "Count of rooms ";
			return;
		}
	}

	// Token: 0x060006DB RID: 1755 RVA: 0x00027EB8 File Offset: 0x000260B8
	[Token(Token = "0x60006DB")]
	[Address(RVA = "0x2D41FBC", Offset = "0x2D41FBC", VA = "0x2D41FBC")]
	public void \u0883\u087Eԗ\u0829(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006DC RID: 1756 RVA: 0x00027EF8 File Offset: 0x000260F8
	[Token(Token = "0x60006DC")]
	[Address(RVA = "0x2D420F0", Offset = "0x2D420F0", VA = "0x2D420F0")]
	public void \u05AD\u0640۰ԯ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006DD RID: 1757 RVA: 0x00027F1C File Offset: 0x0002611C
	[Token(Token = "0x60006DD")]
	[Address(RVA = "0x2D42200", Offset = "0x2D42200", VA = "0x2D42200")]
	private void \u07EBࠎיࡂ()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("Players Online: ", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("hh:mmtt", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "_BumpMap";
	}

	// Token: 0x060006DE RID: 1758 RVA: 0x00027F84 File Offset: 0x00026184
	[Token(Token = "0x60006DE")]
	[Address(RVA = "0x2D42384", Offset = "0x2D42384", VA = "0x2D42384")]
	public void \u0606ٷ\u0742\u060F(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006DF RID: 1759 RVA: 0x00027FA8 File Offset: 0x000261A8
	[Token(Token = "0x60006DF")]
	[Address(RVA = "0x2D42494", Offset = "0x2D42494", VA = "0x2D42494")]
	public void ڻݐ\u05A0\u059D(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006E0 RID: 1760 RVA: 0x00027FCC File Offset: 0x000261CC
	[Token(Token = "0x60006E0")]
	[Address(RVA = "0x2D425A4", Offset = "0x2D425A4", VA = "0x2D425A4")]
	public void ڠը\u0736\u055C(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006E1 RID: 1761 RVA: 0x00027FE8 File Offset: 0x000261E8
	[Token(Token = "0x60006E1")]
	[Address(RVA = "0x2D4268C", Offset = "0x2D4268C", VA = "0x2D4268C")]
	public void \u05C7ج\u081E\u088A(Vector3 ձ߃\u07BA\u06E8)
	{
	}

	// Token: 0x060006E2 RID: 1762 RVA: 0x00028000 File Offset: 0x00026200
	[Token(Token = "0x60006E2")]
	[Address(RVA = "0x2D42774", Offset = "0x2D42774", VA = "0x2D42774")]
	public void ޣےڐ\u064F(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] parameters = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			u07AE_u05AF_u064FԖ.RPC("isLava", RpcTarget.AllViaServer, parameters);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006E3 RID: 1763 RVA: 0x00028048 File Offset: 0x00026248
	[Token(Token = "0x60006E3")]
	[Address(RVA = "0x2D428A8", Offset = "0x2D428A8", VA = "0x2D428A8")]
	public void բҼم\u086F(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006E4 RID: 1764 RVA: 0x0002806C File Offset: 0x0002626C
	[Token(Token = "0x60006E4")]
	[Address(RVA = "0x2D429B8", Offset = "0x2D429B8", VA = "0x2D429B8")]
	private void \u070Fߨ\u05B0ۈ()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("Players: ", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("username", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "True";
	}

	// Token: 0x060006E5 RID: 1765 RVA: 0x000280D4 File Offset: 0x000262D4
	[Token(Token = "0x60006E5")]
	[Address(RVA = "0x2D42B3C", Offset = "0x2D42B3C", VA = "0x2D42B3C")]
	private void \u066D\u05BDې߃()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("BN", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("BN", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "_Tint";
	}

	// Token: 0x060006E6 RID: 1766 RVA: 0x0002813C File Offset: 0x0002633C
	[Token(Token = "0x60006E6")]
	[Address(RVA = "0x2D42CC0", Offset = "0x2D42CC0", VA = "0x2D42CC0")]
	public void יࡓߞڦ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006E7 RID: 1767 RVA: 0x00028158 File Offset: 0x00026358
	[Token(Token = "0x60006E7")]
	[Address(RVA = "0x2D42DA8", Offset = "0x2D42DA8", VA = "0x2D42DA8")]
	private void ڽة\u05EBԠ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D texture2D = this.ܚۃӬ߃;
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("Starting to bake textures on frame ", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "StartSong";
			return;
		}
	}

	// Token: 0x060006E8 RID: 1768 RVA: 0x000281BC File Offset: 0x000263BC
	[Token(Token = "0x60006E8")]
	[Address(RVA = "0x2D42F54", Offset = "0x2D42F54", VA = "0x2D42F54")]
	public void ٿ\u07B5٢ޣ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006E9 RID: 1769 RVA: 0x000281F8 File Offset: 0x000263F8
	[Token(Token = "0x60006E9")]
	[Address(RVA = "0x2D43088", Offset = "0x2D43088", VA = "0x2D43088")]
	public void \u0670\u086Eࡄ\u07FC(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		if (typeof(Vector3).TypeHandle != null && typeof(Vector3).TypeHandle == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if ("Display Name Changed!" != null)
		{
			return;
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x060006EA RID: 1770 RVA: 0x00028238 File Offset: 0x00026438
	[Token(Token = "0x60006EA")]
	[Address(RVA = "0x2D431B8", Offset = "0x2D431B8", VA = "0x2D431B8")]
	private void ޥ\u089Dڢ\u06E3()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("Bare Torso", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("hand 1", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "Player";
			return;
		}
	}

	// Token: 0x060006EB RID: 1771 RVA: 0x000282A8 File Offset: 0x000264A8
	[Token(Token = "0x60006EB")]
	[Address(RVA = "0x2D43364", Offset = "0x2D43364", VA = "0x2D43364")]
	public void \u0701߂\u0744\u0611(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006EC RID: 1772 RVA: 0x000282E4 File Offset: 0x000264E4
	[Token(Token = "0x60006EC")]
	[Address(RVA = "0x2D43494", Offset = "0x2D43494", VA = "0x2D43494")]
	public void \u07F4ݭݶ\u0596(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006ED RID: 1773 RVA: 0x00028320 File Offset: 0x00026520
	[Token(Token = "0x60006ED")]
	[Address(RVA = "0x2D435C4", Offset = "0x2D435C4", VA = "0x2D435C4")]
	public void ۄٱࠇء(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006EE RID: 1774 RVA: 0x00028360 File Offset: 0x00026560
	[Token(Token = "0x60006EE")]
	[Address(RVA = "0x2D436F4", Offset = "0x2D436F4", VA = "0x2D436F4")]
	public void ݟߗڠࡖ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006EF RID: 1775 RVA: 0x00028384 File Offset: 0x00026584
	[Token(Token = "0x60006EF")]
	[Address(RVA = "0x2D43804", Offset = "0x2D43804", VA = "0x2D43804")]
	private void הԥ\u05B5ݴ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Shader ֆӝގس = this.Ֆӝގس;
			Texture2D value = this.ܚۃӬ߃;
			Material material;
			material.SetTexture("tp 2", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("Reason: ", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "ChangeMaterialToNormal";
			return;
		}
	}

	// Token: 0x060006F0 RID: 1776 RVA: 0x000283F0 File Offset: 0x000265F0
	[Token(Token = "0x60006F0")]
	[Address(RVA = "0x2D439AC", Offset = "0x2D439AC", VA = "0x2D439AC")]
	private void ބՅ١\u082D()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("An error has occured while buying bananas, please restart your game and try again", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("TurnAmount", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "Display Name Changed!";
			return;
		}
	}

	// Token: 0x060006F1 RID: 1777 RVA: 0x00028460 File Offset: 0x00026660
	[Token(Token = "0x60006F1")]
	[Address(RVA = "0x2D43B58", Offset = "0x2D43B58", VA = "0x2D43B58")]
	private void ӷӛࠔ\u07AC()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("Key", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("trol", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "Failed to login, please restart";
	}

	// Token: 0x060006F2 RID: 1778 RVA: 0x000284C8 File Offset: 0x000266C8
	[Token(Token = "0x60006F2")]
	[Address(RVA = "0x2D43CDC", Offset = "0x2D43CDC", VA = "0x2D43CDC")]
	public void ࢥػط\u088C(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006F3 RID: 1779 RVA: 0x000284EC File Offset: 0x000266EC
	[Token(Token = "0x60006F3")]
	[Address(RVA = "0x2D43DEC", Offset = "0x2D43DEC", VA = "0x2D43DEC")]
	public void ի\u0893ࡎ۶(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006F4 RID: 1780 RVA: 0x0002852C File Offset: 0x0002672C
	[Token(Token = "0x60006F4")]
	[Address(RVA = "0x2D43F1C", Offset = "0x2D43F1C", VA = "0x2D43F1C")]
	private void ݸԲ\u0616Ԫ()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("_Tint", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("We don't need this electrical box", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = ".Please press the button if you would like to play alone";
	}

	// Token: 0x060006F5 RID: 1781 RVA: 0x00028594 File Offset: 0x00026794
	[Token(Token = "0x60006F5")]
	[Address(RVA = "0x2D440A0", Offset = "0x2D440A0", VA = "0x2D440A0")]
	private void ڣֆ\u07F4ڌ()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("containsStaff", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("sound play play", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "Agreed";
	}

	// Token: 0x060006F6 RID: 1782 RVA: 0x000285FC File Offset: 0x000267FC
	[Token(Token = "0x60006F6")]
	[Address(RVA = "0x2D44224", Offset = "0x2D44224", VA = "0x2D44224")]
	public void ࠐڅ\u0596Է(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006F7 RID: 1783 RVA: 0x00028620 File Offset: 0x00026820
	[Token(Token = "0x60006F7")]
	[Address(RVA = "0x2D44334", Offset = "0x2D44334", VA = "0x2D44334")]
	private void \u05ABݿࡋ\u06E9()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("Player", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("Cheating", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = ". Please update you game to the latest version";
	}

	// Token: 0x060006F8 RID: 1784 RVA: 0x00028688 File Offset: 0x00026888
	[Token(Token = "0x60006F8")]
	[Address(RVA = "0x2D444B8", Offset = "0x2D444B8", VA = "0x2D444B8")]
	public void ݻێԘ\u0591(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006F9 RID: 1785 RVA: 0x000286C0 File Offset: 0x000268C0
	[Token(Token = "0x60006F9")]
	[Address(RVA = "0x2D445EC", Offset = "0x2D445EC", VA = "0x2D445EC")]
	private void \u081FڰՂإ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Shader ֆӝގس = this.Ֆӝގس;
			Texture2D texture2D = this.ܚۃӬ߃;
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			return;
		}
	}

	// Token: 0x060006FA RID: 1786 RVA: 0x00028704 File Offset: 0x00026904
	[Token(Token = "0x60006FA")]
	[Address(RVA = "0x2D44784", Offset = "0x2D44784", VA = "0x2D44784")]
	public void \u0737ս\u0597\u086D(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x060006FB RID: 1787 RVA: 0x00028720 File Offset: 0x00026920
	[Token(Token = "0x60006FB")]
	[Address(RVA = "0x2D4486C", Offset = "0x2D4486C", VA = "0x2D4486C")]
	public void ߛࡊ۰ࢥ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (typeof(Vector3).TypeHandle != null && typeof(Vector3).TypeHandle == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x060006FC RID: 1788 RVA: 0x00028764 File Offset: 0x00026964
	[Token(Token = "0x60006FC")]
	[Address(RVA = "0x2D4499C", Offset = "0x2D4499C", VA = "0x2D4499C")]
	public void \u073Aںձݵ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006FD RID: 1789 RVA: 0x000287A0 File Offset: 0x000269A0
	[Token(Token = "0x60006FD")]
	[Address(RVA = "0x2D44ACC", Offset = "0x2D44ACC", VA = "0x2D44ACC")]
	public void בࡅןտ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		if (array == null || array != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006FE RID: 1790 RVA: 0x000287D8 File Offset: 0x000269D8
	[Token(Token = "0x60006FE")]
	[Address(RVA = "0x2D44BFC", Offset = "0x2D44BFC", VA = "0x2D44BFC")]
	public void ߁ߢظࢶ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060006FF RID: 1791 RVA: 0x00028814 File Offset: 0x00026A14
	[Token(Token = "0x60006FF")]
	[Address(RVA = "0x2D44D30", Offset = "0x2D44D30", VA = "0x2D44D30")]
	public void ۲\u060E\u07B9\u0591(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] parameters = new object[0];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			u07AE_u05AF_u064FԖ.RPC("Reason: ", RpcTarget.AllViaServer, parameters);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000700 RID: 1792 RVA: 0x00028860 File Offset: 0x00026A60
	[Token(Token = "0x6000700")]
	[Address(RVA = "0x2D44E60", Offset = "0x2D44E60", VA = "0x2D44E60")]
	public void ښ\u085Eԡ\u0881(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000701 RID: 1793 RVA: 0x0002889C File Offset: 0x00026A9C
	[Token(Token = "0x6000701")]
	[Address(RVA = "0x2D44F94", Offset = "0x2D44F94", VA = "0x2D44F94")]
	public void ݮڋࡘՔ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
	}

	// Token: 0x06000702 RID: 1794 RVA: 0x000288D4 File Offset: 0x00026AD4
	[Token(Token = "0x6000702")]
	[Address(RVA = "0x2D450C4", Offset = "0x2D450C4", VA = "0x2D450C4")]
	public void ۍࡅࢥ\u085B(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06000703 RID: 1795 RVA: 0x000288F8 File Offset: 0x00026AF8
	[Token(Token = "0x6000703")]
	[Address(RVA = "0x2D451D4", Offset = "0x2D451D4", VA = "0x2D451D4")]
	private void ݤۅࢦӃ()
	{
		if (!this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.Ֆӝގس);
		Texture2D value = this.ܚۃӬ߃;
		material.SetTexture("Charging...", value);
		Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
		material.SetTexture("DISABLE", u05B6_u061Cױ_u083E);
		if (this.\u081B\u070Aߢࡁ == null)
		{
			return;
		}
		material.name = "Name Changing Error. Error: ";
	}

	// Token: 0x06000704 RID: 1796 RVA: 0x00028960 File Offset: 0x00026B60
	[Token(Token = "0x6000704")]
	[Address(RVA = "0x2D45358", Offset = "0x2D45358", VA = "0x2D45358")]
	public void \u05EBػږ\u082F(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000705 RID: 1797 RVA: 0x0002899C File Offset: 0x00026B9C
	[Token(Token = "0x6000705")]
	[Address(RVA = "0x2D45488", Offset = "0x2D45488", VA = "0x2D45488")]
	public void רࠕԔ\u0745(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle != null)
		{
		}
	}

	// Token: 0x06000706 RID: 1798 RVA: 0x000289D0 File Offset: 0x00026BD0
	[Token(Token = "0x6000706")]
	[Address(RVA = "0x2D455BC", Offset = "0x2D455BC", VA = "0x2D455BC")]
	public void Ӵܘݏ\u06E9(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06000707 RID: 1799 RVA: 0x00028A0C File Offset: 0x00026C0C
	[Token(Token = "0x6000707")]
	[Address(RVA = "0x2D456F0", Offset = "0x2D456F0", VA = "0x2D456F0")]
	public void ٯڜӦӎ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06000708 RID: 1800 RVA: 0x00028A30 File Offset: 0x00026C30
	[Token(Token = "0x6000708")]
	[Address(RVA = "0x2D45800", Offset = "0x2D45800", VA = "0x2D45800")]
	private void ޡࠅ\u089Aߔ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("username", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("TurnAmount", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "ENABLE";
			return;
		}
	}

	// Token: 0x06000709 RID: 1801 RVA: 0x00028AA0 File Offset: 0x00026CA0
	[Token(Token = "0x6000709")]
	[Address(RVA = "0x2D459AC", Offset = "0x2D459AC", VA = "0x2D459AC")]
	public void \u0833ժࡂ٧(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x0600070A RID: 1802 RVA: 0x00028AC4 File Offset: 0x00026CC4
	[Token(Token = "0x600070A")]
	[Address(RVA = "0x2D45ABC", Offset = "0x2D45ABC", VA = "0x2D45ABC")]
	public void \u0885ػݫڨ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x0600070B RID: 1803 RVA: 0x00028AE8 File Offset: 0x00026CE8
	[Token(Token = "0x600070B")]
	[Address(RVA = "0x2D45BCC", Offset = "0x2D45BCC", VA = "0x2D45BCC")]
	public void ՔӔ\u0822Տ(Vector3 ձ߃\u07BA\u06E8)
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (typeof(Vector3).TypeHandle == null || typeof(Vector3).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600070C RID: 1804 RVA: 0x00028B24 File Offset: 0x00026D24
	[Token(Token = "0x600070C")]
	[Address(RVA = "0x2D45CFC", Offset = "0x2D45CFC", VA = "0x2D45CFC")]
	public NetworkPlayerColor()
	{
	}

	// Token: 0x0600070D RID: 1805 RVA: 0x00028B38 File Offset: 0x00026D38
	[Token(Token = "0x600070D")]
	[Address(RVA = "0x2D45D04", Offset = "0x2D45D04", VA = "0x2D45D04")]
	public void ࢯӆԑہ(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x0600070E RID: 1806 RVA: 0x00028B54 File Offset: 0x00026D54
	[Token(Token = "0x600070E")]
	[Address(RVA = "0x2D45DEC", Offset = "0x2D45DEC", VA = "0x2D45DEC")]
	public void \u0735Տ\u0530\u081B(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x0600070F RID: 1807 RVA: 0x00028B78 File Offset: 0x00026D78
	[Token(Token = "0x600070F")]
	[Address(RVA = "0x2D45EFC", Offset = "0x2D45EFC", VA = "0x2D45EFC")]
	public void \u0616\u06E2ޠ\u082B(Vector3 ձ߃\u07BA\u06E8)
	{
		SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
	}

	// Token: 0x06000710 RID: 1808 RVA: 0x00028B9C File Offset: 0x00026D9C
	[Token(Token = "0x6000710")]
	[Address(RVA = "0x2D4600C", Offset = "0x2D4600C", VA = "0x2D4600C")]
	private void \u059AՏ\u0600\u0872()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Material material = new Material(this.Ֆӝގس);
			Texture2D value = this.ܚۃӬ߃;
			material.SetTexture("button", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("ScoreCounter", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "ErrorScreen";
			return;
		}
	}

	// Token: 0x06000711 RID: 1809 RVA: 0x00028C0C File Offset: 0x00026E0C
	[Token(Token = "0x6000711")]
	[Address(RVA = "0x2D461B8", Offset = "0x2D461B8", VA = "0x2D461B8")]
	private void \u086Bԍࡊڭ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Shader ֆӝގس = this.Ֆӝގس;
			Texture2D texture2D = this.ܚۃӬ߃;
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			return;
		}
	}

	// Token: 0x06000712 RID: 1810 RVA: 0x00028C54 File Offset: 0x00026E54
	[Token(Token = "0x6000712")]
	[Address(RVA = "0x2D46364", Offset = "0x2D46364", VA = "0x2D46364")]
	private void ߓ\u06E3\u05C7ۋ()
	{
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			Texture2D value = this.ܚۃӬ߃;
			Material material;
			material.SetTexture("spooky guy true", value);
			Texture2D u05B6_u061Cױ_u083E = this.\u05B6\u061Cױ\u083E;
			material.SetTexture("isLava", u05B6_u061Cױ_u083E);
			SkinnedMeshRenderer[] u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			material.name = "Player";
			return;
		}
	}

	// Token: 0x040000F7 RID: 247
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000F7")]
	public Texture2D ܚۃӬ߃;

	// Token: 0x040000F8 RID: 248
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000F8")]
	public Texture2D \u05B6\u061Cױ\u083E;

	// Token: 0x040000F9 RID: 249
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40000F9")]
	public Shader Ֆӝގس;

	// Token: 0x040000FA RID: 250
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40000FA")]
	public SkinnedMeshRenderer[] \u081B\u070Aߢࡁ;

	// Token: 0x040000FB RID: 251
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40000FB")]
	public PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x040000FC RID: 252
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40000FC")]
	public Vector3 \u073E\u0895ࡎӵ;
}
