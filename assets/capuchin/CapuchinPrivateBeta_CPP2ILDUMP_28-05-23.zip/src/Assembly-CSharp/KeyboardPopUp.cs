﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x0200006F RID: 111
[Token(Token = "0x200006F")]
public class KeyboardPopUp : MonoBehaviour
{
	// Token: 0x06001050 RID: 4176 RVA: 0x00060D9C File Offset: 0x0005EF9C
	[Token(Token = "0x6001050")]
	[Address(RVA = "0x2AD2FF4", Offset = "0x2AD2FF4", VA = "0x2AD2FF4")]
	public void \u05F8ݑ\u06ECߞ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool(".Please press the button if you would like to play alone", կ٢ࠌ_u);
	}

	// Token: 0x06001051 RID: 4177 RVA: 0x00060DCC File Offset: 0x0005EFCC
	[Token(Token = "0x6001051")]
	[Address(RVA = "0x2AD3050", Offset = "0x2AD3050", VA = "0x2AD3050")]
	public void \u073Fߗބݝ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("PlayWave", կ٢ࠌ_u);
	}

	// Token: 0x06001052 RID: 4178 RVA: 0x00060DFC File Offset: 0x0005EFFC
	[Token(Token = "0x6001052")]
	[Address(RVA = "0x2AD30AC", Offset = "0x2AD30AC", VA = "0x2AD30AC")]
	public void չւت\u061E()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Name Changing Error. Error: ", կ٢ࠌ_u);
	}

	// Token: 0x06001053 RID: 4179 RVA: 0x00060E2C File Offset: 0x0005F02C
	[Token(Token = "0x6001053")]
	[Address(RVA = "0x2AD3108", Offset = "0x2AD3108", VA = "0x2AD3108")]
	public void ڷ\u0826ӹڥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		long active = 1L;
		GameObject gameObject;
		gameObject.SetActive(active != 0L);
		long active2 = 1L;
		GameObject gameObject2;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001054 RID: 4180 RVA: 0x00060E60 File Offset: 0x0005F060
	[Token(Token = "0x6001054")]
	[Address(RVA = "0x2AD3204", Offset = "0x2AD3204", VA = "0x2AD3204")]
	public void \u061Fࡆ\u086F\u07B0()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("closeToObject", կ٢ࠌ_u);
	}

	// Token: 0x06001055 RID: 4181 RVA: 0x00060E90 File Offset: 0x0005F090
	[Token(Token = "0x6001055")]
	[Address(RVA = "0x2AD3260", Offset = "0x2AD3260", VA = "0x2AD3260")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001056 RID: 4182 RVA: 0x00060EEC File Offset: 0x0005F0EC
	[Token(Token = "0x6001056")]
	[Address(RVA = "0x2AD335C", Offset = "0x2AD335C", VA = "0x2AD335C")]
	public void ӻӒݝ߃()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("FingerTip", կ٢ࠌ_u);
	}

	// Token: 0x06001057 RID: 4183 RVA: 0x00060F1C File Offset: 0x0005F11C
	[Token(Token = "0x6001057")]
	[Address(RVA = "0x2AD33B8", Offset = "0x2AD33B8", VA = "0x2AD33B8")]
	public void \u070Aәޣے()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("PlayerHead", կ٢ࠌ_u);
	}

	// Token: 0x06001058 RID: 4184 RVA: 0x00060F4C File Offset: 0x0005F14C
	[Token(Token = "0x6001058")]
	[Address(RVA = "0x2AD3414", Offset = "0x2AD3414", VA = "0x2AD3414")]
	public void յߪؾՀ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Game Started", կ٢ࠌ_u);
	}

	// Token: 0x06001059 RID: 4185 RVA: 0x00060F7C File Offset: 0x0005F17C
	[Token(Token = "0x6001059")]
	[Address(RVA = "0x2AD3470", Offset = "0x2AD3470", VA = "0x2AD3470")]
	public void ܪ\u07BB\u086Bࠆ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("username", կ٢ࠌ_u);
	}

	// Token: 0x0600105A RID: 4186 RVA: 0x00060FAC File Offset: 0x0005F1AC
	[Token(Token = "0x600105A")]
	[Address(RVA = "0x2AD34CC", Offset = "0x2AD34CC", VA = "0x2AD34CC")]
	public void Ҽ\u08B5ځ\u0658()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Meta Platform entitlement error: ", կ٢ࠌ_u);
	}

	// Token: 0x0600105B RID: 4187 RVA: 0x00060FDC File Offset: 0x0005F1DC
	[Token(Token = "0x600105B")]
	[Address(RVA = "0x2AD3528", Offset = "0x2AD3528", VA = "0x2AD3528")]
	public void \u05B3ࢹߧ\u07AA()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("_Tint", կ٢ࠌ_u);
	}

	// Token: 0x0600105C RID: 4188 RVA: 0x0006100C File Offset: 0x0005F20C
	[Token(Token = "0x600105C")]
	[Address(RVA = "0x2AD3584", Offset = "0x2AD3584", VA = "0x2AD3584")]
	public void ڃրӢԖ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("ChangeMaterialToNormal", կ٢ࠌ_u);
	}

	// Token: 0x0600105D RID: 4189 RVA: 0x0006103C File Offset: 0x0005F23C
	[Token(Token = "0x600105D")]
	[Address(RVA = "0x2AD35E0", Offset = "0x2AD35E0", VA = "0x2AD35E0")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600105E RID: 4190 RVA: 0x00061098 File Offset: 0x0005F298
	[Token(Token = "0x600105E")]
	[Address(RVA = "0x2AD36DC", Offset = "0x2AD36DC", VA = "0x2AD36DC")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.", կ٢ࠌ_u);
	}

	// Token: 0x0600105F RID: 4191 RVA: 0x000610C8 File Offset: 0x0005F2C8
	[Token(Token = "0x600105F")]
	[Address(RVA = "0x2AD3738", Offset = "0x2AD3738", VA = "0x2AD3738")]
	public void څࡣڐ\u0657()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("amongus", կ٢ࠌ_u);
	}

	// Token: 0x06001060 RID: 4192 RVA: 0x000610F8 File Offset: 0x0005F2F8
	[Token(Token = "0x6001060")]
	[Address(RVA = "0x2AD3794", Offset = "0x2AD3794", VA = "0x2AD3794")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if ("IsLowSurrogates" == null)
		{
		}
		bool flag = component;
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001061 RID: 4193 RVA: 0x00061160 File Offset: 0x0005F360
	[Token(Token = "0x6001061")]
	[Address(RVA = "0x2AD3890", Offset = "0x2AD3890", VA = "0x2AD3890")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001062 RID: 4194 RVA: 0x000611BC File Offset: 0x0005F3BC
	[Token(Token = "0x6001062")]
	[Address(RVA = "0x2AD398C", Offset = "0x2AD398C", VA = "0x2AD398C")]
	public void \u087DىԳܚ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001063 RID: 4195 RVA: 0x00061208 File Offset: 0x0005F408
	[Token(Token = "0x6001063")]
	[Address(RVA = "0x2AD3A84", Offset = "0x2AD3A84", VA = "0x2AD3A84")]
	public void \u0838ӆڛӑ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("_WobbleX", կ٢ࠌ_u);
	}

	// Token: 0x06001064 RID: 4196 RVA: 0x00061238 File Offset: 0x0005F438
	[Token(Token = "0x6001064")]
	[Address(RVA = "0x2AD3AE0", Offset = "0x2AD3AE0", VA = "0x2AD3AE0")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001065 RID: 4197 RVA: 0x00061294 File Offset: 0x0005F494
	[Token(Token = "0x6001065")]
	[Address(RVA = "0x2AD3BDC", Offset = "0x2AD3BDC", VA = "0x2AD3BDC")]
	public void \u0732ڙԒࢺ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("/", կ٢ࠌ_u);
	}

	// Token: 0x06001066 RID: 4198 RVA: 0x000612C4 File Offset: 0x0005F4C4
	[Token(Token = "0x6001066")]
	[Address(RVA = "0x2AD3C38", Offset = "0x2AD3C38", VA = "0x2AD3C38")]
	public void ܣ\u086E\u05CF\u06D8()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("User has been reported for: ", կ٢ࠌ_u);
	}

	// Token: 0x06001067 RID: 4199 RVA: 0x000612F4 File Offset: 0x0005F4F4
	[Token(Token = "0x6001067")]
	[Address(RVA = "0x2AD3C94", Offset = "0x2AD3C94", VA = "0x2AD3C94")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001068 RID: 4200 RVA: 0x00061340 File Offset: 0x0005F540
	[Token(Token = "0x6001068")]
	[Address(RVA = "0x2AD3D8C", Offset = "0x2AD3D8C", VA = "0x2AD3D8C")]
	public void ԗ\u05F9ҿ\u0834(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001069 RID: 4201 RVA: 0x0006139C File Offset: 0x0005F59C
	[Token(Token = "0x6001069")]
	[Address(RVA = "0x2AD3E88", Offset = "0x2AD3E88", VA = "0x2AD3E88")]
	public void ة\u066Dࡏԫ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600106A RID: 4202 RVA: 0x000613E8 File Offset: 0x0005F5E8
	[Token(Token = "0x600106A")]
	[Address(RVA = "0x2AD3F80", Offset = "0x2AD3F80", VA = "0x2AD3F80")]
	public void \u05AC\u07F0\u07EEࡥ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Calling success callback. baking meshes", կ٢ࠌ_u);
	}

	// Token: 0x0600106B RID: 4203 RVA: 0x00061418 File Offset: 0x0005F618
	[Token(Token = "0x600106B")]
	[Address(RVA = "0x2AD3FDC", Offset = "0x2AD3FDC", VA = "0x2AD3FDC")]
	public void ߑ\u0885\u05BBߕ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("BloodKill", կ٢ࠌ_u);
	}

	// Token: 0x0600106C RID: 4204 RVA: 0x00061448 File Offset: 0x0005F648
	[Token(Token = "0x600106C")]
	[Address(RVA = "0x2AD4038", Offset = "0x2AD4038", VA = "0x2AD4038")]
	public void ࡊ\u0592\u07AB\u05B2()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Skelechin", կ٢ࠌ_u);
	}

	// Token: 0x0600106D RID: 4205 RVA: 0x00061478 File Offset: 0x0005F678
	[Token(Token = "0x600106D")]
	[Address(RVA = "0x2AD4094", Offset = "0x2AD4094", VA = "0x2AD4094")]
	public void ٴݵۃ\u05AF()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Hats", կ٢ࠌ_u);
	}

	// Token: 0x0600106E RID: 4206 RVA: 0x000614A8 File Offset: 0x0005F6A8
	[Token(Token = "0x600106E")]
	[Address(RVA = "0x2AD40F0", Offset = "0x2AD40F0", VA = "0x2AD40F0")]
	public void ւࡂ\u0883\u0872()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool(". Please update you game to the latest version", կ٢ࠌ_u);
	}

	// Token: 0x0600106F RID: 4207 RVA: 0x000614D8 File Offset: 0x0005F6D8
	[Token(Token = "0x600106F")]
	[Address(RVA = "0x2AD414C", Offset = "0x2AD414C", VA = "0x2AD414C")]
	public void ڦکӁ\u06E2()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Not enough amount of currency", կ٢ࠌ_u);
	}

	// Token: 0x06001070 RID: 4208 RVA: 0x00061508 File Offset: 0x0005F708
	[Token(Token = "0x6001070")]
	[Address(RVA = "0x2AD41A8", Offset = "0x2AD41A8", VA = "0x2AD41A8")]
	public void יԠ\u07EDԺ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("token", կ٢ࠌ_u);
	}

	// Token: 0x06001071 RID: 4209 RVA: 0x00061538 File Offset: 0x0005F738
	[Token(Token = "0x6001071")]
	[Address(RVA = "0x2AD4204", Offset = "0x2AD4204", VA = "0x2AD4204")]
	public void տ\u06D9ܭࠊ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		long active = 0L;
		GameObject gameObject;
		gameObject.SetActive(active != 0L);
		long active2 = 1L;
		GameObject gameObject2;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001072 RID: 4210 RVA: 0x0006156C File Offset: 0x0005F76C
	[Token(Token = "0x6001072")]
	[Address(RVA = "0x2AD42FC", Offset = "0x2AD42FC", VA = "0x2AD42FC")]
	public void րۀ\u0701ԝ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001073 RID: 4211 RVA: 0x000615B8 File Offset: 0x0005F7B8
	[Token(Token = "0x6001073")]
	[Address(RVA = "0x2AD43F4", Offset = "0x2AD43F4", VA = "0x2AD43F4")]
	public void \u05F7ԝߠӱ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("goDownRPC", կ٢ࠌ_u);
	}

	// Token: 0x06001074 RID: 4212 RVA: 0x000615E8 File Offset: 0x0005F7E8
	[Token(Token = "0x6001074")]
	[Address(RVA = "0x2AD4450", Offset = "0x2AD4450", VA = "0x2AD4450")]
	public void \u0870\u05B3Ց\u066A()
	{
	}

	// Token: 0x06001075 RID: 4213 RVA: 0x000615FC File Offset: 0x0005F7FC
	[Token(Token = "0x6001075")]
	[Address(RVA = "0x2AD44AC", Offset = "0x2AD44AC", VA = "0x2AD44AC")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001076 RID: 4214 RVA: 0x00061648 File Offset: 0x0005F848
	[Token(Token = "0x6001076")]
	[Address(RVA = "0x2AD45A4", Offset = "0x2AD45A4", VA = "0x2AD45A4")]
	public void \u05C1ؽԜࡥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001077 RID: 4215 RVA: 0x00061694 File Offset: 0x0005F894
	[Token(Token = "0x6001077")]
	[Address(RVA = "0x2AD469C", Offset = "0x2AD469C", VA = "0x2AD469C")]
	public KeyboardPopUp()
	{
	}

	// Token: 0x06001078 RID: 4216 RVA: 0x000616A8 File Offset: 0x0005F8A8
	[Token(Token = "0x6001078")]
	[Address(RVA = "0x2AD46A4", Offset = "0x2AD46A4", VA = "0x2AD46A4")]
	public void ܯר\u05C7ڗ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001079 RID: 4217 RVA: 0x00061704 File Offset: 0x0005F904
	[Token(Token = "0x6001079")]
	[Address(RVA = "0x2AD47A0", Offset = "0x2AD47A0", VA = "0x2AD47A0")]
	public void ڷԲ\u0618ރ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
	}

	// Token: 0x0600107A RID: 4218 RVA: 0x00061728 File Offset: 0x0005F928
	[Token(Token = "0x600107A")]
	[Address(RVA = "0x2AD47FC", Offset = "0x2AD47FC", VA = "0x2AD47FC")]
	public void \u0654ޛ\u07FAذ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("RightHandAttachPoint", կ٢ࠌ_u);
	}

	// Token: 0x0600107B RID: 4219 RVA: 0x00061758 File Offset: 0x0005F958
	[Token(Token = "0x600107B")]
	[Address(RVA = "0x2AD4858", Offset = "0x2AD4858", VA = "0x2AD4858")]
	public void \u0881ݗӟ\u07BD()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("username", կ٢ࠌ_u);
	}

	// Token: 0x0600107C RID: 4220 RVA: 0x00061788 File Offset: 0x0005F988
	[Token(Token = "0x600107C")]
	[Address(RVA = "0x2AD48B4", Offset = "0x2AD48B4", VA = "0x2AD48B4")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600107D RID: 4221 RVA: 0x000617E0 File Offset: 0x0005F9E0
	[Token(Token = "0x600107D")]
	[Address(RVA = "0x2AD49B0", Offset = "0x2AD49B0", VA = "0x2AD49B0")]
	public void ەԌ\u05C7\u085D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600107E RID: 4222 RVA: 0x0006183C File Offset: 0x0005FA3C
	[Token(Token = "0x600107E")]
	[Address(RVA = "0x2AD4AAC", Offset = "0x2AD4AAC", VA = "0x2AD4AAC")]
	public void Ӣ\u0592ߨׯ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Mesh", կ٢ࠌ_u);
	}

	// Token: 0x0600107F RID: 4223 RVA: 0x0006186C File Offset: 0x0005FA6C
	[Token(Token = "0x600107F")]
	[Address(RVA = "0x2AD4B08", Offset = "0x2AD4B08", VA = "0x2AD4B08")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001080 RID: 4224 RVA: 0x000618C8 File Offset: 0x0005FAC8
	[Token(Token = "0x6001080")]
	[Address(RVA = "0x2AD4C04", Offset = "0x2AD4C04", VA = "0x2AD4C04")]
	public void \u07B6կպ߃()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.", կ٢ࠌ_u);
	}

	// Token: 0x06001081 RID: 4225 RVA: 0x000618F8 File Offset: 0x0005FAF8
	[Token(Token = "0x6001081")]
	[Address(RVA = "0x2AD4C60", Offset = "0x2AD4C60", VA = "0x2AD4C60")]
	public void ԟ\u086Cޣ\u055E()
	{
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
	}

	// Token: 0x06001082 RID: 4226 RVA: 0x00061914 File Offset: 0x0005FB14
	[Token(Token = "0x6001082")]
	[Address(RVA = "0x2AD4CBC", Offset = "0x2AD4CBC", VA = "0x2AD4CBC")]
	public void \u0872މࢮՃ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Reason: ", կ٢ࠌ_u);
	}

	// Token: 0x06001083 RID: 4227 RVA: 0x00061944 File Offset: 0x0005FB44
	[Token(Token = "0x6001083")]
	[Address(RVA = "0x2AD4D18", Offset = "0x2AD4D18", VA = "0x2AD4D18")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001084 RID: 4228 RVA: 0x000619A0 File Offset: 0x0005FBA0
	[Token(Token = "0x6001084")]
	[Address(RVA = "0x2AD4E14", Offset = "0x2AD4E14", VA = "0x2AD4E14")]
	public void \u061B\u05EEوۈ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("INSIGNIFICANT CURRENCY", կ٢ࠌ_u);
	}

	// Token: 0x06001085 RID: 4229 RVA: 0x000619D0 File Offset: 0x0005FBD0
	[Token(Token = "0x6001085")]
	[Address(RVA = "0x2AD4E70", Offset = "0x2AD4E70", VA = "0x2AD4E70")]
	public void يօӇ\u070D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001086 RID: 4230 RVA: 0x00061A1C File Offset: 0x0005FC1C
	[Token(Token = "0x6001086")]
	[Address(RVA = "0x2AD4F68", Offset = "0x2AD4F68", VA = "0x2AD4F68")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001087 RID: 4231 RVA: 0x00061A78 File Offset: 0x0005FC78
	[Token(Token = "0x6001087")]
	[Address(RVA = "0x2AD5064", Offset = "0x2AD5064", VA = "0x2AD5064")]
	public void \u0590\u0882\u0883ࡦ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("true", կ٢ࠌ_u);
	}

	// Token: 0x06001088 RID: 4232 RVA: 0x00061AA8 File Offset: 0x0005FCA8
	[Token(Token = "0x6001088")]
	[Address(RVA = "0x2AD50C0", Offset = "0x2AD50C0", VA = "0x2AD50C0")]
	public void \u0599ږࠆ\u065F()
	{
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
	}

	// Token: 0x06001089 RID: 4233 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001089")]
	[Address(RVA = "0x2AD511C", Offset = "0x2AD511C", VA = "0x2AD511C")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600108A RID: 4234 RVA: 0x00061AC4 File Offset: 0x0005FCC4
	[Token(Token = "0x600108A")]
	[Address(RVA = "0x2AD5214", Offset = "0x2AD5214", VA = "0x2AD5214")]
	public void ࢫ\u0876չՍ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Hats", կ٢ࠌ_u);
	}

	// Token: 0x0600108B RID: 4235 RVA: 0x00061AF4 File Offset: 0x0005FCF4
	[Token(Token = "0x600108B")]
	[Address(RVA = "0x2AD5270", Offset = "0x2AD5270", VA = "0x2AD5270")]
	public void \u05AD\u0881ࡆݡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600108C RID: 4236 RVA: 0x00061B40 File Offset: 0x0005FD40
	[Token(Token = "0x600108C")]
	[Address(RVA = "0x2AD5368", Offset = "0x2AD5368", VA = "0x2AD5368")]
	public void \u059Cݝ\u058E۳(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600108D RID: 4237 RVA: 0x00061B9C File Offset: 0x0005FD9C
	[Token(Token = "0x600108D")]
	[Address(RVA = "0x2AD5464", Offset = "0x2AD5464", VA = "0x2AD5464")]
	public void \u0892ܒܬޓ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
	}

	// Token: 0x0600108E RID: 4238 RVA: 0x00061BC0 File Offset: 0x0005FDC0
	[Token(Token = "0x600108E")]
	[Address(RVA = "0x2AD54C0", Offset = "0x2AD54C0", VA = "0x2AD54C0")]
	public void \u055Cࢯܯ\u0898()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("StartSong", կ٢ࠌ_u);
	}

	// Token: 0x0600108F RID: 4239 RVA: 0x00061BF0 File Offset: 0x0005FDF0
	[Token(Token = "0x600108F")]
	[Address(RVA = "0x2AD551C", Offset = "0x2AD551C", VA = "0x2AD551C")]
	public void ࢶ٠\u086D\u0708()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Player", կ٢ࠌ_u);
	}

	// Token: 0x06001090 RID: 4240 RVA: 0x00061C20 File Offset: 0x0005FE20
	[Token(Token = "0x6001090")]
	[Address(RVA = "0x2AD5578", Offset = "0x2AD5578", VA = "0x2AD5578")]
	public void \u05C4ݳ\u05BCࡂ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Players Online: ", կ٢ࠌ_u);
	}

	// Token: 0x06001091 RID: 4241 RVA: 0x00061C50 File Offset: 0x0005FE50
	[Token(Token = "0x6001091")]
	[Address(RVA = "0x2AD55D4", Offset = "0x2AD55D4", VA = "0x2AD55D4")]
	public void ہۼآԄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001092 RID: 4242 RVA: 0x00061C9C File Offset: 0x0005FE9C
	[Token(Token = "0x6001092")]
	[Address(RVA = "0x2AD56CC", Offset = "0x2AD56CC", VA = "0x2AD56CC")]
	public void \u0886Ҽ\u058Dߛ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("username", կ٢ࠌ_u);
	}

	// Token: 0x06001093 RID: 4243 RVA: 0x00061CCC File Offset: 0x0005FECC
	[Token(Token = "0x6001093")]
	[Address(RVA = "0x2AD5728", Offset = "0x2AD5728", VA = "0x2AD5728")]
	public void \u0705\u0816\u0739դ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("monke screamed", կ٢ࠌ_u);
	}

	// Token: 0x06001094 RID: 4244 RVA: 0x00061CFC File Offset: 0x0005FEFC
	[Token(Token = "0x6001094")]
	[Address(RVA = "0x2AD5784", Offset = "0x2AD5784", VA = "0x2AD5784")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001095 RID: 4245 RVA: 0x00061D48 File Offset: 0x0005FF48
	[Token(Token = "0x6001095")]
	[Address(RVA = "0x2AD587C", Offset = "0x2AD587C", VA = "0x2AD587C")]
	public void ފՖߢ\u059B()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Reason: ", կ٢ࠌ_u);
	}

	// Token: 0x06001096 RID: 4246 RVA: 0x00061D78 File Offset: 0x0005FF78
	[Token(Token = "0x6001096")]
	[Address(RVA = "0x2AD58D8", Offset = "0x2AD58D8", VA = "0x2AD58D8")]
	public void ۷ޞ\u07AFߍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001097 RID: 4247 RVA: 0x00061DC4 File Offset: 0x0005FFC4
	[Token(Token = "0x6001097")]
	[Address(RVA = "0x2AD59D0", Offset = "0x2AD59D0", VA = "0x2AD59D0")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		TextMeshPro u0608_u0877ԝٶ = this.\u0608\u0877ԝٶ;
		long կ٢ࠌ_u = 1L;
		this.կ٢ࠌ\u0650 = (կ٢ࠌ_u != 0L);
		GameObject gameObject = u0608_u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001098 RID: 4248 RVA: 0x00061E20 File Offset: 0x00060020
	[Token(Token = "0x6001098")]
	[Address(RVA = "0x2AD5ACC", Offset = "0x2AD5ACC", VA = "0x2AD5ACC")]
	public void ی\u0823ڇݔ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Joined Public Room Successfully", կ٢ࠌ_u);
	}

	// Token: 0x06001099 RID: 4249 RVA: 0x00061E50 File Offset: 0x00060050
	[Token(Token = "0x6001099")]
	[Address(RVA = "0x2AD5B28", Offset = "0x2AD5B28", VA = "0x2AD5B28")]
	public void ԅ\u073Fڥ\u0839()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("M/d/yyyy", կ٢ࠌ_u);
	}

	// Token: 0x0600109A RID: 4250 RVA: 0x00061E80 File Offset: 0x00060080
	[Token(Token = "0x600109A")]
	[Address(RVA = "0x2AD5B84", Offset = "0x2AD5B84", VA = "0x2AD5B84")]
	public void \u060B\u0614\u0821ע()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Players In Room: ", կ٢ࠌ_u);
	}

	// Token: 0x0600109B RID: 4251 RVA: 0x00061EB0 File Offset: 0x000600B0
	[Token(Token = "0x600109B")]
	[Address(RVA = "0x2AD5BE0", Offset = "0x2AD5BE0", VA = "0x2AD5BE0")]
	public void طӏܙࢺ()
	{
	}

	// Token: 0x0600109C RID: 4252 RVA: 0x00061EC4 File Offset: 0x000600C4
	[Token(Token = "0x600109C")]
	[Address(RVA = "0x2AD5C3C", Offset = "0x2AD5C3C", VA = "0x2AD5C3C")]
	public void ࢭ\u0589\u0892\u058A()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Vector1_d371bd24217449349bd747533d51af6b", կ٢ࠌ_u);
	}

	// Token: 0x0600109D RID: 4253 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600109D")]
	[Address(RVA = "0x2AD5C98", Offset = "0x2AD5C98", VA = "0x2AD5C98")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600109E RID: 4254 RVA: 0x00061EF4 File Offset: 0x000600F4
	[Token(Token = "0x600109E")]
	[Address(RVA = "0x2AD5D94", Offset = "0x2AD5D94", VA = "0x2AD5D94")]
	public void \u05EDց\u081Cت()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
	}

	// Token: 0x0600109F RID: 4255 RVA: 0x00061F18 File Offset: 0x00060118
	[Token(Token = "0x600109F")]
	[Address(RVA = "0x2AD5DF0", Offset = "0x2AD5DF0", VA = "0x2AD5DF0")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x060010A0 RID: 4256 RVA: 0x00061F64 File Offset: 0x00060164
	[Token(Token = "0x60010A0")]
	[Address(RVA = "0x2AD5EE8", Offset = "0x2AD5EE8", VA = "0x2AD5EE8")]
	public void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x060010A1 RID: 4257 RVA: 0x00061FB0 File Offset: 0x000601B0
	[Token(Token = "0x60010A1")]
	[Address(RVA = "0x2AD5FE0", Offset = "0x2AD5FE0", VA = "0x2AD5FE0")]
	public void Update()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("Open", կ٢ࠌ_u);
	}

	// Token: 0x060010A2 RID: 4258 RVA: 0x00061FE0 File Offset: 0x000601E0
	[Token(Token = "0x60010A2")]
	[Address(RVA = "0x2AD603C", Offset = "0x2AD603C", VA = "0x2AD603C")]
	public void ߊ\u066A\u05CFԉ()
	{
		Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
		bool կ٢ࠌ_u = this.կ٢ࠌ\u0650;
		ӳע_u070EԬ.SetBool("username", կ٢ࠌ_u);
	}

	// Token: 0x060010A3 RID: 4259 RVA: 0x00062010 File Offset: 0x00060210
	[Token(Token = "0x60010A3")]
	[Address(RVA = "0x2AD6098", Offset = "0x2AD6098", VA = "0x2AD6098")]
	public void ܘݱ\u083CԲ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject gameObject = this.\u0608\u0877ԝٶ.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.\u0871ߘ\u0822Ө.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x04000238 RID: 568
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000238")]
	public Animator ӳע\u070EԬ;

	// Token: 0x04000239 RID: 569
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000239")]
	public bool կ٢ࠌ\u0650;

	// Token: 0x0400023A RID: 570
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400023A")]
	public TextMeshPro \u0608\u0877ԝٶ;

	// Token: 0x0400023B RID: 571
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400023B")]
	public TextMeshPro \u0871ߘ\u0822Ө;
}
