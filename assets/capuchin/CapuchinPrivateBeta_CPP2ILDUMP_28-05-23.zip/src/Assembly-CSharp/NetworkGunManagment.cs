﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000CC RID: 204
[Token(Token = "0x20000CC")]
public class NetworkGunManagment : MonoBehaviour
{
	// Token: 0x06001F36 RID: 7990 RVA: 0x000A214C File Offset: 0x000A034C
	[Token(Token = "0x6001F36")]
	[Address(RVA = "0x23C1980", Offset = "0x23C1980", VA = "0x23C1980")]
	private void Ҿࢹؼס()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
		long enabled3 = 1L;
		u0825_u0743ڽ_u070A3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06001F37 RID: 7991 RVA: 0x000A21D8 File Offset: 0x000A03D8
	[Token(Token = "0x6001F37")]
	[Address(RVA = "0x23C1A44", Offset = "0x23C1A44", VA = "0x23C1A44")]
	private void ں٢ࡡ\u05EC()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F38 RID: 7992 RVA: 0x000A226C File Offset: 0x000A046C
	[Token(Token = "0x6001F38")]
	[Address(RVA = "0x23C1B18", Offset = "0x23C1B18", VA = "0x23C1B18")]
	private void \u0732ڙԒࢺ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 0L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F39 RID: 7993 RVA: 0x000A2300 File Offset: 0x000A0500
	[Token(Token = "0x6001F39")]
	[Address(RVA = "0x23C1BEC", Offset = "0x23C1BEC", VA = "0x23C1BEC")]
	private void \u0881ݗӟ\u07BD()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F3A RID: 7994 RVA: 0x000A2394 File Offset: 0x000A0594
	[Token(Token = "0x6001F3A")]
	[Address(RVA = "0x23C1CC0", Offset = "0x23C1CC0", VA = "0x23C1CC0")]
	private void ފՖߢ\u059B()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 0L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F3B RID: 7995 RVA: 0x000A2428 File Offset: 0x000A0628
	[Token(Token = "0x6001F3B")]
	[Address(RVA = "0x23C1D94", Offset = "0x23C1D94", VA = "0x23C1D94")]
	private void \u070Aәޣے()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F3C RID: 7996 RVA: 0x000A24BC File Offset: 0x000A06BC
	[Token(Token = "0x6001F3C")]
	[Address(RVA = "0x23C1E68", Offset = "0x23C1E68", VA = "0x23C1E68")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 0L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F3D RID: 7997 RVA: 0x000A2550 File Offset: 0x000A0750
	[Token(Token = "0x6001F3D")]
	[Address(RVA = "0x23C1F3C", Offset = "0x23C1F3C", VA = "0x23C1F3C")]
	private void ժ\u065Dԯࡘ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F3E RID: 7998 RVA: 0x000A25E4 File Offset: 0x000A07E4
	[Token(Token = "0x6001F3E")]
	[Address(RVA = "0x23C2010", Offset = "0x23C2010", VA = "0x23C2010")]
	private void ڃրӢԖ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 0L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F3F RID: 7999 RVA: 0x000A2678 File Offset: 0x000A0878
	[Token(Token = "0x6001F3F")]
	[Address(RVA = "0x23C20E4", Offset = "0x23C20E4", VA = "0x23C20E4")]
	private void \u05F7ԝߠӱ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
		long enabled3 = 0L;
		u0825_u0743ڽ_u070A3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06001F40 RID: 8000 RVA: 0x000A2704 File Offset: 0x000A0904
	[Token(Token = "0x6001F40")]
	[Address(RVA = "0x23C21A8", Offset = "0x23C21A8", VA = "0x23C21A8")]
	private void \u0654ޛ\u07FAذ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 0L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F41 RID: 8001 RVA: 0x000A2798 File Offset: 0x000A0998
	[Token(Token = "0x6001F41")]
	[Address(RVA = "0x23C227C", Offset = "0x23C227C", VA = "0x23C227C")]
	private void ٴݵۃ\u05AF()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 0L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
		long enabled3 = 0L;
		u0825_u0743ڽ_u070A3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06001F42 RID: 8002 RVA: 0x000A2824 File Offset: 0x000A0A24
	[Token(Token = "0x6001F42")]
	[Address(RVA = "0x23C2340", Offset = "0x23C2340", VA = "0x23C2340")]
	private void \u05EDց\u081Cت()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 0L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F43 RID: 8003 RVA: 0x000A28B8 File Offset: 0x000A0AB8
	[Token(Token = "0x6001F43")]
	[Address(RVA = "0x23C2414", Offset = "0x23C2414", VA = "0x23C2414")]
	private void Update()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
		long enabled3 = 0L;
		u0825_u0743ڽ_u070A3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06001F44 RID: 8004 RVA: 0x000A2944 File Offset: 0x000A0B44
	[Token(Token = "0x6001F44")]
	[Address(RVA = "0x23C24D8", Offset = "0x23C24D8", VA = "0x23C24D8")]
	private void \u087BӦןݩ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F45 RID: 8005 RVA: 0x000A29D4 File Offset: 0x000A0BD4
	[Token(Token = "0x6001F45")]
	[Address(RVA = "0x23C25AC", Offset = "0x23C25AC", VA = "0x23C25AC")]
	public NetworkGunManagment()
	{
	}

	// Token: 0x06001F46 RID: 8006 RVA: 0x000A29E8 File Offset: 0x000A0BE8
	[Token(Token = "0x6001F46")]
	[Address(RVA = "0x23C25B4", Offset = "0x23C25B4", VA = "0x23C25B4")]
	private void \u061B\u05EEوۈ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F47 RID: 8007 RVA: 0x000A2A7C File Offset: 0x000A0C7C
	[Token(Token = "0x6001F47")]
	[Address(RVA = "0x23C2688", Offset = "0x23C2688", VA = "0x23C2688")]
	private void څࡣڐ\u0657()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 0L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 0L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F48 RID: 8008 RVA: 0x000A2B10 File Offset: 0x000A0D10
	[Token(Token = "0x6001F48")]
	[Address(RVA = "0x23C275C", Offset = "0x23C275C", VA = "0x23C275C")]
	private void Ӣ\u0592ߨׯ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 0L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
		long enabled3 = 0L;
		u0825_u0743ڽ_u070A3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06001F49 RID: 8009 RVA: 0x000A2B9C File Offset: 0x000A0D9C
	[Token(Token = "0x6001F49")]
	[Address(RVA = "0x23C2820", Offset = "0x23C2820", VA = "0x23C2820")]
	private void ԣԭՋࠏ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x06001F4A RID: 8010 RVA: 0x000A2C30 File Offset: 0x000A0E30
	[Token(Token = "0x6001F4A")]
	[Address(RVA = "0x23C28F4", Offset = "0x23C28F4", VA = "0x23C28F4")]
	private void ڑߒجވ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 0L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 1L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
		long enabled3 = 0L;
		u0825_u0743ڽ_u070A3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06001F4B RID: 8011 RVA: 0x000A2CBC File Offset: 0x000A0EBC
	[Token(Token = "0x6001F4B")]
	[Address(RVA = "0x23C29B8", Offset = "0x23C29B8", VA = "0x23C29B8")]
	private void ւࡂ\u0883\u0872()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 1L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 0L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
		long enabled3 = 0L;
		u0825_u0743ڽ_u070A3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06001F4C RID: 8012 RVA: 0x000A2D48 File Offset: 0x000A0F48
	[Token(Token = "0x6001F4C")]
	[Address(RVA = "0x23C2A7C", Offset = "0x23C2A7C", VA = "0x23C2A7C")]
	private void ԟ\u086Cޣ\u055E()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool activeSelf = this.\u0870ݔ\u074A\u0873.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A = this.\u0825\u0743ڽ\u070A;
			long enabled = 0L;
			u0825_u0743ڽ_u070A.enabled = (enabled != 0L);
			bool activeSelf2 = this.\u083AՅڰ\u0874.activeSelf;
			ClientGunManager u0825_u0743ڽ_u070A2 = this.\u0825\u0743ڽ\u070A;
			long enabled2 = 0L;
			u0825_u0743ڽ_u070A2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.\u0870ݔ\u074A\u0873.activeSelf;
			bool activeSelf4 = this.\u083AՅڰ\u0874.activeSelf;
			return;
		}
		ClientGunManager u0825_u0743ڽ_u070A3 = this.\u0825\u0743ڽ\u070A;
	}

	// Token: 0x04000405 RID: 1029
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000405")]
	public GameObject \u0870ݔ\u074A\u0873;

	// Token: 0x04000406 RID: 1030
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000406")]
	public GameObject \u083AՅڰ\u0874;

	// Token: 0x04000407 RID: 1031
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000407")]
	public PhotonView ޣߑԤࡩ;

	// Token: 0x04000408 RID: 1032
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000408")]
	public ClientGunManager \u0825\u0743ڽ\u070A;
}
