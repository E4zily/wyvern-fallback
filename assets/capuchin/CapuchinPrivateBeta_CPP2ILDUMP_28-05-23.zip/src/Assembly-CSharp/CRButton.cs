﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200000B RID: 11
[Token(Token = "0x200000B")]
public class CRButton : MonoBehaviour
{
	// Token: 0x0600014F RID: 335 RVA: 0x0000E2E4 File Offset: 0x0000C4E4
	[Token(Token = "0x600014F")]
	[Address(RVA = "0x27223E0", Offset = "0x27223E0", VA = "0x27223E0")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 1L;
			ӳע_u070EԬ.SetBool("typesOfTalk", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000150 RID: 336 RVA: 0x0000E340 File Offset: 0x0000C540
	[Token(Token = "0x6000150")]
	[Address(RVA = "0x27224F0", Offset = "0x27224F0", VA = "0x27224F0")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 1L;
			ӳע_u070EԬ.SetBool("token", value != 0L);
		}
		if ("token" != null)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000151 RID: 337 RVA: 0x0000E39C File Offset: 0x0000C59C
	[Token(Token = "0x6000151")]
	[Address(RVA = "0x2722600", Offset = "0x2722600", VA = "0x2722600")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 0L;
			ӳע_u070EԬ.SetBool("goDownRPC", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000152 RID: 338 RVA: 0x0000E3F8 File Offset: 0x0000C5F8
	[Token(Token = "0x6000152")]
	[Address(RVA = "0x2722710", Offset = "0x2722710", VA = "0x2722710")]
	public CRButton()
	{
	}

	// Token: 0x06000153 RID: 339 RVA: 0x0000E40C File Offset: 0x0000C60C
	[Token(Token = "0x6000153")]
	[Address(RVA = "0x2722718", Offset = "0x2722718", VA = "0x2722718")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 0L;
			ӳע_u070EԬ.SetBool("Open", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000154 RID: 340 RVA: 0x0000E468 File Offset: 0x0000C668
	[Token(Token = "0x6000154")]
	[Address(RVA = "0x2722828", Offset = "0x2722828", VA = "0x2722828")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 0L;
			ӳע_u070EԬ.SetBool("manual footTimings length should be equal to the leg count", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000155 RID: 341 RVA: 0x0000E4C4 File Offset: 0x0000C6C4
	[Token(Token = "0x6000155")]
	[Address(RVA = "0x2722938", Offset = "0x2722938", VA = "0x2722938")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000156 RID: 342 RVA: 0x0000E50C File Offset: 0x0000C70C
	[Token(Token = "0x6000156")]
	[Address(RVA = "0x2722A48", Offset = "0x2722A48", VA = "0x2722A48")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 1L;
			ӳע_u070EԬ.SetBool("Players In Room: ", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000157 RID: 343 RVA: 0x0000E568 File Offset: 0x0000C768
	[Token(Token = "0x6000157")]
	[Address(RVA = "0x2722B58", Offset = "0x2722B58", VA = "0x2722B58")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 1L;
			ӳע_u070EԬ.SetBool("PlayNoise", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000158 RID: 344 RVA: 0x0000E5C4 File Offset: 0x0000C7C4
	[Token(Token = "0x6000158")]
	[Address(RVA = "0x2722C68", Offset = "0x2722C68", VA = "0x2722C68")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 0L;
			ӳע_u070EԬ.SetBool("jump char false", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000159 RID: 345 RVA: 0x0000E620 File Offset: 0x0000C820
	[Token(Token = "0x6000159")]
	[Address(RVA = "0x2722D78", Offset = "0x2722D78", VA = "0x2722D78")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 0L;
			ӳע_u070EԬ.SetBool("Collided", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015A RID: 346 RVA: 0x0000E67C File Offset: 0x0000C87C
	[Token(Token = "0x600015A")]
	[Address(RVA = "0x2722E88", Offset = "0x2722E88", VA = "0x2722E88")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 0L;
			ӳע_u070EԬ.SetBool("back", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015B RID: 347 RVA: 0x0000E6D8 File Offset: 0x0000C8D8
	[Token(Token = "0x600015B")]
	[Address(RVA = "0x2722F98", Offset = "0x2722F98", VA = "0x2722F98")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 1L;
			ӳע_u070EԬ.SetBool("Player", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015C RID: 348 RVA: 0x0000E734 File Offset: 0x0000C934
	[Token(Token = "0x600015C")]
	[Address(RVA = "0x27230A8", Offset = "0x27230A8", VA = "0x27230A8")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 0L;
			ӳע_u070EԬ.SetBool("closeToObject", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015D RID: 349 RVA: 0x0000E790 File Offset: 0x0000C990
	[Token(Token = "0x600015D")]
	[Address(RVA = "0x27231B8", Offset = "0x27231B8", VA = "0x27231B8")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 1L;
			ӳע_u070EԬ.SetBool("trol", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015E RID: 350 RVA: 0x0000E7EC File Offset: 0x0000C9EC
	[Token(Token = "0x600015E")]
	[Address(RVA = "0x27232C8", Offset = "0x27232C8", VA = "0x27232C8")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 0L;
			ӳע_u070EԬ.SetBool("Player", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015F RID: 351 RVA: 0x0000E848 File Offset: 0x0000CA48
	[Token(Token = "0x600015F")]
	[Address(RVA = "0x27233D8", Offset = "0x27233D8", VA = "0x27233D8")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 1L;
			ӳע_u070EԬ.SetBool("ScoreCounter", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000160 RID: 352 RVA: 0x0000E8A4 File Offset: 0x0000CAA4
	[Token(Token = "0x6000160")]
	[Address(RVA = "0x27234E8", Offset = "0x27234E8", VA = "0x27234E8")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 1L;
			ӳע_u070EԬ.SetBool("BN", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000161 RID: 353 RVA: 0x0000E900 File Offset: 0x0000CB00
	[Token(Token = "0x6000161")]
	[Address(RVA = "0x27235F8", Offset = "0x27235F8", VA = "0x27235F8")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u0701\u083Aݒ\u05A7)
		{
			this.\u088C\u0704ࠒޤ.CreateRoomLol();
			Animator ӳע_u070EԬ = this.ӳע\u070EԬ;
			long value = 0L;
			ӳע_u070EԬ.SetBool("A new Player joined a Room.", value != 0L);
		}
		if (this.\u0731ڏӸԫ)
		{
			this.\u088C\u0704ࠒޤ.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0400002E RID: 46
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400002E")]
	public CreateRoom \u088C\u0704ࠒޤ;

	// Token: 0x0400002F RID: 47
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400002F")]
	public bool \u0701\u083Aݒ\u05A7;

	// Token: 0x04000030 RID: 48
	[FieldOffset(Offset = "0x21")]
	[Token(Token = "0x4000030")]
	public bool \u0731ڏӸԫ;

	// Token: 0x04000031 RID: 49
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000031")]
	public Animator ӳע\u070EԬ;
}
