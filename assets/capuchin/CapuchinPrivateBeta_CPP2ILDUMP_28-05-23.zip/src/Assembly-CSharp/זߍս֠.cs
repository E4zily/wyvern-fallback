﻿using System;
using Cpp2IlInjected;

// Token: 0x02000024 RID: 36
[Token(Token = "0x2000024")]
public enum זߍս\u05A0 : byte
{
	// Token: 0x040000AD RID: 173
	[Token(Token = "0x40000AD")]
	\u0658ՖࠔӇ,
	// Token: 0x040000AE RID: 174
	[Token(Token = "0x40000AE")]
	\u0704ڇٱߎ,
	// Token: 0x040000AF RID: 175
	[Token(Token = "0x40000AF")]
	ڐࡌ\u07FFޞ,
	// Token: 0x040000B0 RID: 176
	[Token(Token = "0x40000B0")]
	\u07EC\u05B6\u05AC\u0892,
	// Token: 0x040000B1 RID: 177
	[Token(Token = "0x40000B1")]
	\u0871ࠀݛ\u05C0,
	// Token: 0x040000B2 RID: 178
	[Token(Token = "0x40000B2")]
	\u05A9\u0833ءݰ,
	// Token: 0x040000B3 RID: 179
	[Token(Token = "0x40000B3")]
	Դ\u0895\u0834ռ,
	// Token: 0x040000B4 RID: 180
	[Token(Token = "0x40000B4")]
	ۈ\u05CA\u07EBۓ,
	// Token: 0x040000B5 RID: 181
	[Token(Token = "0x40000B5")]
	ڄ\u07ACߢݻ,
	// Token: 0x040000B6 RID: 182
	[Token(Token = "0x40000B6")]
	\u05B8\u0892\u0833ۺ,
	// Token: 0x040000B7 RID: 183
	[Token(Token = "0x40000B7")]
	\u0877ڌࡓؼ
}
