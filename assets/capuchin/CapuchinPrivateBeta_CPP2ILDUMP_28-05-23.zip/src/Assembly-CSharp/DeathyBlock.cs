﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000AA RID: 170
[Token(Token = "0x20000AA")]
public class DeathyBlock : MonoBehaviour
{
	// Token: 0x06001941 RID: 6465 RVA: 0x00089574 File Offset: 0x00087774
	[Token(Token = "0x6001941")]
	[Address(RVA = "0x289A4D8", Offset = "0x289A4D8", VA = "0x289A4D8")]
	public void כࠂࡎ۲()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001942 RID: 6466 RVA: 0x00089594 File Offset: 0x00087794
	[Token(Token = "0x6001942")]
	[Address(RVA = "0x289A4F4", Offset = "0x289A4F4", VA = "0x289A4F4")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001943 RID: 6467 RVA: 0x000895CC File Offset: 0x000877CC
	[Token(Token = "0x6001943")]
	[Address(RVA = "0x289A650", Offset = "0x289A650", VA = "0x289A650")]
	public void ݶԁ\u0825\u07F1()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001944 RID: 6468 RVA: 0x000895EC File Offset: 0x000877EC
	[Token(Token = "0x6001944")]
	[Address(RVA = "0x289A66C", Offset = "0x289A66C", VA = "0x289A66C")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "\tExpires: ";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001945 RID: 6469 RVA: 0x00089624 File Offset: 0x00087824
	[Token(Token = "0x6001945")]
	[Address(RVA = "0x289A7C8", Offset = "0x289A7C8", VA = "0x289A7C8")]
	[PunRPC]
	public void deathScream()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001946 RID: 6470 RVA: 0x00089644 File Offset: 0x00087844
	[Token(Token = "0x6001946")]
	[Address(RVA = "0x289A7E4", Offset = "0x289A7E4", VA = "0x289A7E4")]
	public void ב\u0613ޕݿ()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001947 RID: 6471 RVA: 0x00089664 File Offset: 0x00087864
	[Token(Token = "0x6001947")]
	[Address(RVA = "0x289A800", Offset = "0x289A800", VA = "0x289A800")]
	public void ӎ\u073Dۍ\u0873()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001948 RID: 6472 RVA: 0x00089684 File Offset: 0x00087884
	[Token(Token = "0x6001948")]
	[Address(RVA = "0x289A81C", Offset = "0x289A81C", VA = "0x289A81C")]
	public void ݙتٿ\u05B8()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001949 RID: 6473 RVA: 0x000896A4 File Offset: 0x000878A4
	[Token(Token = "0x6001949")]
	[Address(RVA = "0x289A838", Offset = "0x289A838", VA = "0x289A838")]
	public void ة\u066Dࡏԫ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x0600194A RID: 6474 RVA: 0x000896DC File Offset: 0x000878DC
	[Token(Token = "0x600194A")]
	[Address(RVA = "0x289A994", Offset = "0x289A994", VA = "0x289A994")]
	public void ࡑܭ\u0817ޣ()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600194B RID: 6475 RVA: 0x000896FC File Offset: 0x000878FC
	[Token(Token = "0x600194B")]
	[Address(RVA = "0x289A9B0", Offset = "0x289A9B0", VA = "0x289A9B0")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "containsStaff";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x0600194C RID: 6476 RVA: 0x00089734 File Offset: 0x00087934
	[Token(Token = "0x600194C")]
	[Address(RVA = "0x289AB0C", Offset = "0x289AB0C", VA = "0x289AB0C")]
	public void ڄ\u05ADי\u05F6()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600194D RID: 6477 RVA: 0x00089754 File Offset: 0x00087954
	[Token(Token = "0x600194D")]
	[Address(RVA = "0x289AB28", Offset = "0x289AB28", VA = "0x289AB28")]
	public void \u0738ܔݥ\u0896()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600194E RID: 6478 RVA: 0x00089774 File Offset: 0x00087974
	[Token(Token = "0x600194E")]
	[Address(RVA = "0x289AB44", Offset = "0x289AB44", VA = "0x289AB44")]
	public void \u0828օ\u05FCՁ()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600194F RID: 6479 RVA: 0x00089794 File Offset: 0x00087994
	[Token(Token = "0x600194F")]
	[Address(RVA = "0x289AB60", Offset = "0x289AB60", VA = "0x289AB60")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "deathScream";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001950 RID: 6480 RVA: 0x000897CC File Offset: 0x000879CC
	[Token(Token = "0x6001950")]
	[Address(RVA = "0x289ACBC", Offset = "0x289ACBC", VA = "0x289ACBC")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You are on an outdated version of Capuchin. Your version is ";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001951 RID: 6481 RVA: 0x00089804 File Offset: 0x00087A04
	[Token(Token = "0x6001951")]
	[Address(RVA = "0x289AE18", Offset = "0x289AE18", VA = "0x289AE18")]
	public void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "tutorialCheck";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001952 RID: 6482 RVA: 0x0008983C File Offset: 0x00087A3C
	[Token(Token = "0x6001952")]
	[Address(RVA = "0x289AF74", Offset = "0x289AF74", VA = "0x289AF74")]
	public void ࡢؼ\u0611ա()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001953 RID: 6483 RVA: 0x0008985C File Offset: 0x00087A5C
	[Token(Token = "0x6001953")]
	[Address(RVA = "0x289AF90", Offset = "0x289AF90", VA = "0x289AF90")]
	public void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
	}

	// Token: 0x06001954 RID: 6484 RVA: 0x0008988C File Offset: 0x00087A8C
	[Token(Token = "0x6001954")]
	[Address(RVA = "0x289B0EC", Offset = "0x289B0EC", VA = "0x289B0EC")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "Connected to Server.";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001955 RID: 6485 RVA: 0x000898C0 File Offset: 0x00087AC0
	[Token(Token = "0x6001955")]
	[Address(RVA = "0x289B248", Offset = "0x289B248", VA = "0x289B248")]
	public void \u061B\u066Aչ\u0558()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001956 RID: 6486 RVA: 0x000898E0 File Offset: 0x00087AE0
	[Token(Token = "0x6001956")]
	[Address(RVA = "0x289B264", Offset = "0x289B264", VA = "0x289B264")]
	public void سࡕԞ߆(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001957 RID: 6487 RVA: 0x00089918 File Offset: 0x00087B18
	[Token(Token = "0x6001957")]
	[Address(RVA = "0x289B3C0", Offset = "0x289B3C0", VA = "0x289B3C0")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Name Changing Error. Error: ";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001958 RID: 6488 RVA: 0x00089950 File Offset: 0x00087B50
	[Token(Token = "0x6001958")]
	[Address(RVA = "0x289B51C", Offset = "0x289B51C", VA = "0x289B51C")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001959 RID: 6489 RVA: 0x00089984 File Offset: 0x00087B84
	[Token(Token = "0x6001959")]
	[Address(RVA = "0x289B678", Offset = "0x289B678", VA = "0x289B678")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "manual footTimings length should be equal to the leg count";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x0600195A RID: 6490 RVA: 0x000899BC File Offset: 0x00087BBC
	[Token(Token = "0x600195A")]
	[Address(RVA = "0x289B7D4", Offset = "0x289B7D4", VA = "0x289B7D4")]
	public void \u0897Ի\u061A\u086D()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600195B RID: 6491 RVA: 0x000899DC File Offset: 0x00087BDC
	[Token(Token = "0x600195B")]
	[Address(RVA = "0x289B7F0", Offset = "0x289B7F0", VA = "0x289B7F0")]
	public DeathyBlock()
	{
	}

	// Token: 0x0600195C RID: 6492 RVA: 0x000899F0 File Offset: 0x00087BF0
	[Token(Token = "0x600195C")]
	[Address(RVA = "0x289B7F8", Offset = "0x289B7F8", VA = "0x289B7F8")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x0600195D RID: 6493 RVA: 0x00089A28 File Offset: 0x00087C28
	[Token(Token = "0x600195D")]
	[Address(RVA = "0x289B954", Offset = "0x289B954", VA = "0x289B954")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x0600195E RID: 6494 RVA: 0x00089A60 File Offset: 0x00087C60
	[Token(Token = "0x600195E")]
	[Address(RVA = "0x289BAB0", Offset = "0x289BAB0", VA = "0x289BAB0")]
	public void Ժ\u060C\u07BA\u0822()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600195F RID: 6495 RVA: 0x00089A80 File Offset: 0x00087C80
	[Token(Token = "0x600195F")]
	[Address(RVA = "0x289BACC", Offset = "0x289BACC", VA = "0x289BACC")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001960 RID: 6496 RVA: 0x00089AB8 File Offset: 0x00087CB8
	[Token(Token = "0x6001960")]
	[Address(RVA = "0x289BC28", Offset = "0x289BC28", VA = "0x289BC28")]
	public void \u0618հڗ\u05A1()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001961 RID: 6497 RVA: 0x00089AD8 File Offset: 0x00087CD8
	[Token(Token = "0x6001961")]
	[Address(RVA = "0x289BC44", Offset = "0x289BC44", VA = "0x289BC44")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001962 RID: 6498 RVA: 0x00089B10 File Offset: 0x00087D10
	[Token(Token = "0x6001962")]
	[Address(RVA = "0x289BDA0", Offset = "0x289BDA0", VA = "0x289BDA0")]
	public void \u055A߀ݑԞ()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001963 RID: 6499 RVA: 0x00089B30 File Offset: 0x00087D30
	[Token(Token = "0x6001963")]
	[Address(RVA = "0x289BDBC", Offset = "0x289BDBC", VA = "0x289BDBC")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Did Hit";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001964 RID: 6500 RVA: 0x00089B68 File Offset: 0x00087D68
	[Token(Token = "0x6001964")]
	[Address(RVA = "0x289BF18", Offset = "0x289BF18", VA = "0x289BF18")]
	public void ޜ\u05A9Ӯݖ()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001965 RID: 6501 RVA: 0x00089B88 File Offset: 0x00087D88
	[Token(Token = "0x6001965")]
	[Address(RVA = "0x289BF34", Offset = "0x289BF34", VA = "0x289BF34")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001966 RID: 6502 RVA: 0x00089BC0 File Offset: 0x00087DC0
	[Token(Token = "0x6001966")]
	[Address(RVA = "0x289C090", Offset = "0x289C090", VA = "0x289C090")]
	public void \u061Aՠ\u074B߃()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001967 RID: 6503 RVA: 0x00089BE0 File Offset: 0x00087DE0
	[Token(Token = "0x6001967")]
	[Address(RVA = "0x289C0AC", Offset = "0x289C0AC", VA = "0x289C0AC")]
	public void ࡏӱӅ\u082D()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001968 RID: 6504 RVA: 0x00089C00 File Offset: 0x00087E00
	[Token(Token = "0x6001968")]
	[Address(RVA = "0x289C0C8", Offset = "0x289C0C8", VA = "0x289C0C8")]
	public void հեܚࠂ()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001969 RID: 6505 RVA: 0x00089C20 File Offset: 0x00087E20
	[Token(Token = "0x6001969")]
	[Address(RVA = "0x289C0E4", Offset = "0x289C0E4", VA = "0x289C0E4")]
	public void ߣӈ\u0825\u065F()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600196A RID: 6506 RVA: 0x00089C40 File Offset: 0x00087E40
	[Token(Token = "0x600196A")]
	[Address(RVA = "0x289C100", Offset = "0x289C100", VA = "0x289C100")]
	public void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "On";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x0600196B RID: 6507 RVA: 0x00089C78 File Offset: 0x00087E78
	[Token(Token = "0x600196B")]
	[Address(RVA = "0x289C25C", Offset = "0x289C25C", VA = "0x289C25C")]
	public void ࢺճ\u05A0ڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "tutorialCheck";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x0600196C RID: 6508 RVA: 0x00089CB0 File Offset: 0x00087EB0
	[Token(Token = "0x600196C")]
	[Address(RVA = "0x289C3B8", Offset = "0x289C3B8", VA = "0x289C3B8")]
	public void ۻ\u05CAߜז()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600196D RID: 6509 RVA: 0x00089CD0 File Offset: 0x00087ED0
	[Token(Token = "0x600196D")]
	[Address(RVA = "0x289C3D4", Offset = "0x289C3D4", VA = "0x289C3D4")]
	public void ܚٹ\u05CCޕ()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600196E RID: 6510 RVA: 0x00089CF0 File Offset: 0x00087EF0
	[Token(Token = "0x600196E")]
	[Address(RVA = "0x289C3F0", Offset = "0x289C3F0", VA = "0x289C3F0")]
	public void Ӌ\u081Bא\u083D()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600196F RID: 6511 RVA: 0x00089D10 File Offset: 0x00087F10
	[Token(Token = "0x600196F")]
	[Address(RVA = "0x289C40C", Offset = "0x289C40C", VA = "0x289C40C")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ENABLE";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001970 RID: 6512 RVA: 0x00089D48 File Offset: 0x00087F48
	[Token(Token = "0x6001970")]
	[Address(RVA = "0x289C568", Offset = "0x289C568", VA = "0x289C568")]
	public void Ӭձ\u0879\u058F()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001971 RID: 6513 RVA: 0x00089D68 File Offset: 0x00087F68
	[Token(Token = "0x6001971")]
	[Address(RVA = "0x289C584", Offset = "0x289C584", VA = "0x289C584")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "EnableCosmetic";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001972 RID: 6514 RVA: 0x00089DA0 File Offset: 0x00087FA0
	[Token(Token = "0x6001972")]
	[Address(RVA = "0x289C6E0", Offset = "0x289C6E0", VA = "0x289C6E0")]
	public void \u089C\u05EBۻ\u0828()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001973 RID: 6515 RVA: 0x00089DC0 File Offset: 0x00087FC0
	[Token(Token = "0x6001973")]
	[Address(RVA = "0x289C6FC", Offset = "0x289C6FC", VA = "0x289C6FC")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HandL";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001974 RID: 6516 RVA: 0x00089DF8 File Offset: 0x00087FF8
	[Token(Token = "0x6001974")]
	[Address(RVA = "0x289C858", Offset = "0x289C858", VA = "0x289C858")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001975 RID: 6517 RVA: 0x00089E30 File Offset: 0x00088030
	[Token(Token = "0x6001975")]
	[Address(RVA = "0x289C9B4", Offset = "0x289C9B4", VA = "0x289C9B4")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001976 RID: 6518 RVA: 0x00089E68 File Offset: 0x00088068
	[Token(Token = "0x6001976")]
	[Address(RVA = "0x289CB10", Offset = "0x289CB10", VA = "0x289CB10")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "StartGamemode";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001977 RID: 6519 RVA: 0x00089EA0 File Offset: 0x000880A0
	[Token(Token = "0x6001977")]
	[Address(RVA = "0x289CC6C", Offset = "0x289CC6C", VA = "0x289CC6C")]
	public void ܯӣӟۻ()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x06001978 RID: 6520 RVA: 0x00089EC0 File Offset: 0x000880C0
	[Token(Token = "0x6001978")]
	[Address(RVA = "0x289CC88", Offset = "0x289CC88", VA = "0x289CC88")]
	public void ܘݱ\u083CԲ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ScoreCounter";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x06001979 RID: 6521 RVA: 0x00089EF8 File Offset: 0x000880F8
	[Token(Token = "0x6001979")]
	[Address(RVA = "0x289CDE4", Offset = "0x289CDE4", VA = "0x289CDE4")]
	public void \u089A\u07AD\u05AC\u0825()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600197A RID: 6522 RVA: 0x00089F18 File Offset: 0x00088118
	[Token(Token = "0x600197A")]
	[Address(RVA = "0x289CE00", Offset = "0x289CE00", VA = "0x289CE00")]
	public void ރۏ\u0890ࢬ()
	{
		this.ևވՓٳ.Play();
	}

	// Token: 0x0600197B RID: 6523 RVA: 0x00089F38 File Offset: 0x00088138
	[Token(Token = "0x600197B")]
	[Address(RVA = "0x289CE1C", Offset = "0x289CE1C", VA = "0x289CE1C")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Trigger";
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Application.Quit();
	}

	// Token: 0x04000321 RID: 801
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000321")]
	public PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x04000322 RID: 802
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000322")]
	public AudioSource ևވՓٳ;
}
