﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000B0 RID: 176
[Token(Token = "0x20000B0")]
[AddComponentMenu("Dynamic Bone/Dynamic Bone")]
public class DynamicBone : MonoBehaviour
{
	// Token: 0x06001A3A RID: 6714 RVA: 0x0008BFBC File Offset: 0x0008A1BC
	[Token(Token = "0x6001A3A")]
	[Address(RVA = "0x2FCB720", Offset = "0x2FCB720", VA = "0x2FCB720")]
	private void \u0701\u0873ӏݒ(Transform ޝՒࠍӘ)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		new DynamicBone.\u064Eԧ٧ش().\u07A8ջԖץ = ޝՒࠍӘ;
		Matrix4x4 worldToLocalMatrix = ޝՒࠍӘ.worldToLocalMatrix;
		List<DynamicBone.\u064Eԧ٧ش> u082B_u0602_u0709_u05CF = this.\u082B\u0602\u0709\u05CF;
	}

	// Token: 0x06001A3B RID: 6715 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A3B")]
	[Address(RVA = "0x2FCB848", Offset = "0x2FCB848", VA = "0x2FCB848")]
	private void ࢪ\u05BEөث(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ, Transform زحا\u05B0, int ԧՅ\u07F0ࡇ, float ࡩ\u0892Ն\u0898)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A3C RID: 6716 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A3C")]
	[Address(RVA = "0x2FCBDB8", Offset = "0x2FCBDB8", VA = "0x2FCBDB8")]
	private static void ࠅ\u061Fࠎ\u0873()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A3D RID: 6717 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A3D")]
	[Address(RVA = "0x2FCCAB4", Offset = "0x2FCCAB4", VA = "0x2FCCAB4")]
	private void \u06E7ժݹࠁ(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A3E RID: 6718 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A3E")]
	[Address(RVA = "0x2FCCDE4", Offset = "0x2FCCDE4", VA = "0x2FCCDE4")]
	private void ڹ\u058BԐے(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ, float ހӉ\u0608ࡘ, int زӯӈۅ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A3F RID: 6719 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A3F")]
	[Address(RVA = "0x2FCD004", Offset = "0x2FCD004", VA = "0x2FCD004")]
	private void Քݚؤࢹ(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A40 RID: 6720 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A40")]
	[Address(RVA = "0x2FCD104", Offset = "0x2FCD104", VA = "0x2FCD104")]
	private void Ӿ\u0739ڽն(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A41 RID: 6721 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A41")]
	[Address(RVA = "0x2FCD440", Offset = "0x2FCD440", VA = "0x2FCD440")]
	public void Ӿ\u0739ڽն()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A42 RID: 6722 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A42")]
	[Address(RVA = "0x2FCD54C", Offset = "0x2FCD54C", VA = "0x2FCD54C")]
	private static void ࢢ\u0830\u0822ߛ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A43 RID: 6723 RVA: 0x0008BFF0 File Offset: 0x0008A1F0
	[Token(Token = "0x6001A43")]
	[Address(RVA = "0x2FCD93C", Offset = "0x2FCD93C", VA = "0x2FCD93C")]
	private void ۺߌ\u073Cࢨ(Transform ޝՒࠍӘ)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		new DynamicBone.\u064Eԧ٧ش().\u07A8ջԖץ = ޝՒࠍӘ;
		Matrix4x4 worldToLocalMatrix = ޝՒࠍӘ.worldToLocalMatrix;
		List<DynamicBone.\u064Eԧ٧ش> u082B_u0602_u0709_u05CF = this.\u082B\u0602\u0709\u05CF;
	}

	// Token: 0x06001A44 RID: 6724 RVA: 0x0008C024 File Offset: 0x0008A224
	[Token(Token = "0x6001A44")]
	[Address(RVA = "0x2FCDA64", Offset = "0x2FCDA64", VA = "0x2FCDA64")]
	private void OnDisable()
	{
		this.ࠀ٨ࡈۑ();
	}

	// Token: 0x06001A45 RID: 6725 RVA: 0x0008C038 File Offset: 0x0008A238
	[Token(Token = "0x6001A45")]
	[Address(RVA = "0x2FCDB04", Offset = "0x2FCDB04", VA = "0x2FCDB04")]
	public float ۹ڗࢪ\u06ED()
	{
		/*
An exception occurred when decompiling this method (06001A45)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single DynamicBone::۹ڗࢪۭ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_0_06, ldfld:float32(DynamicBone::ࢵؔԐࠋ, ldloc:DynamicBone(this))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06001A46 RID: 6726 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A46")]
	[Address(RVA = "0x2FCDB0C", Offset = "0x2FCDB0C", VA = "0x2FCDB0C")]
	private void ڹ\u058BԐے(float ހӉ\u0608ࡘ, int زӯӈۅ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A47 RID: 6727 RVA: 0x0008C04C File Offset: 0x0008A24C
	[Token(Token = "0x6001A47")]
	[Address(RVA = "0x2FCDBC4", Offset = "0x2FCDBC4", VA = "0x2FCDBC4")]
	public float ӮԖޜށ()
	{
		/*
An exception occurred when decompiling this method (06001A47)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single DynamicBone::ӮԖޜށ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_0_06, ldfld:float32(DynamicBone::ࢵؔԐࠋ, ldloc:DynamicBone(this))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06001A48 RID: 6728 RVA: 0x0008C060 File Offset: 0x0008A260
	[Token(Token = "0x6001A48")]
	[Address(RVA = "0x2FCDBCC", Offset = "0x2FCDBCC", VA = "0x2FCDBCC")]
	private void Update()
	{
		DynamicBone.ӎޣߘڕ ӎޣߘڕ = this.պۍبظ;
		this.ߔעاࢬ();
		int ࡂޝ_u083Aض = this.ࡂޝ\u083Aض;
		long num;
		if (this.߄ԯݭջ)
		{
			if (typeof(DynamicBone).TypeHandle == null)
			{
			}
			DynamicBone.ױךݺࢲ(this);
			num = 1L;
			this.ކ\u0589ӵտ = (num != 0L);
		}
		if (num == 0L)
		{
		}
		DynamicBone.\u0619էوԈ = DynamicBone.\u0619էوԈ;
	}

	// Token: 0x06001A49 RID: 6729 RVA: 0x0008C0AC File Offset: 0x0008A2AC
	[Token(Token = "0x6001A49")]
	[Address(RVA = "0x2FCDD6C", Offset = "0x2FCDD6C", VA = "0x2FCDD6C")]
	private void ܗݔێ\u085C()
	{
	}

	// Token: 0x06001A4A RID: 6730 RVA: 0x0008C0CC File Offset: 0x0008A2CC
	[Token(Token = "0x6001A4A")]
	[Address(RVA = "0x2FCC1A0", Offset = "0x2FCC1A0", VA = "0x2FCC1A0")]
	private void \u0598ࢫ\u05C0ږ()
	{
		bool ӱߙ_u07B5_u = this.Ӱߙ\u07B5\u0735;
		if (ӱߙ_u07B5_u)
		{
			Transform ӷݴࢭ_u = this.ӷݴࢭ\u0705;
			if (!ӱߙ_u07B5_u)
			{
			}
			Camera main = Camera.main;
			Transform transform = Camera.main.transform;
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			Vector3 position = transform.position;
			float sqrMagnitude = base.transform.position.sqrMagnitude;
			float u061F_u06EB_u05C2ܭ = this.\u061F\u06EB\u05C2ܭ;
			bool flag = this.ՠպתԥ;
			this.\u088Bݟܒڢ();
			this.ՠպתԥ = flag;
		}
	}

	// Token: 0x06001A4B RID: 6731 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A4B")]
	[Address(RVA = "0x2FCDA68", Offset = "0x2FCDA68", VA = "0x2FCDA68")]
	private void ࠀ٨ࡈۑ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A4C RID: 6732 RVA: 0x0008C14C File Offset: 0x0008A34C
	[Token(Token = "0x6001A4C")]
	[Address(RVA = "0x2FCE2E0", Offset = "0x2FCE2E0", VA = "0x2FCE2E0")]
	private void \u0881ݗӟ\u07BD()
	{
		DynamicBone.ӎޣߘڕ ӎޣߘڕ = this.պۍبظ;
		this.ߔעاࢬ();
		int ࡂޝ_u083Aض = this.ࡂޝ\u083Aض;
		if (this.߄ԯݭջ)
		{
			if (typeof(DynamicBone).TypeHandle == null)
			{
			}
			DynamicBone.ױךݺࢲ(this);
		}
		if (typeof(DynamicBone).TypeHandle == null)
		{
		}
		DynamicBone.\u0619էوԈ = DynamicBone.\u0619էوԈ;
	}

	// Token: 0x06001A4D RID: 6733 RVA: 0x0008C194 File Offset: 0x0008A394
	[Token(Token = "0x6001A4D")]
	[Address(RVA = "0x2FCE3A4", Offset = "0x2FCE3A4", VA = "0x2FCE3A4")]
	private static void \u06E0ڈӇ\u0871()
	{
	}

	// Token: 0x06001A4E RID: 6734 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A4E")]
	[Address(RVA = "0x2FCE638", Offset = "0x2FCE638", VA = "0x2FCE638")]
	private void Շ\u0887մ\u0899()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A4F RID: 6735 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A4F")]
	[Address(RVA = "0x2FCE20C", Offset = "0x2FCE20C", VA = "0x2FCE20C")]
	private void ࠀ٨ࡈۑ(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A50 RID: 6736 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A50")]
	[Address(RVA = "0x2FCE46C", Offset = "0x2FCE46C", VA = "0x2FCE46C")]
	private static DynamicBone ࡨߪݪԠ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A51 RID: 6737 RVA: 0x0008C1C4 File Offset: 0x0008A3C4
	[Token(Token = "0x6001A51")]
	[Address(RVA = "0x2FCEA28", Offset = "0x2FCEA28", VA = "0x2FCEA28")]
	private void Start()
	{
		this.ࠐԺ\u07B8\u0598();
	}

	// Token: 0x06001A52 RID: 6738 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A52")]
	[Address(RVA = "0x2FCEA2C", Offset = "0x2FCEA2C", VA = "0x2FCEA2C")]
	public void ࡨչࢪ\u083F()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A53 RID: 6739 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A53")]
	[Address(RVA = "0x2FCC540", Offset = "0x2FCC540", VA = "0x2FCC540")]
	private void \u0711ӿ\u08B5ܥ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A54 RID: 6740 RVA: 0x0008C1D8 File Offset: 0x0008A3D8
	[Token(Token = "0x6001A54")]
	[Address(RVA = "0x2FCDC94", Offset = "0x2FCDC94", VA = "0x2FCDC94")]
	private void ߔעاࢬ()
	{
		float u08B5_u0614Ԑࠋ = this.\u08B5\u0614Ԑࠋ;
		bool ӱߙ_u07B5_u = this.Ӱߙ\u07B5\u0735;
		if (!ӱߙ_u07B5_u || !ӱߙ_u07B5_u)
		{
			this.ࠀ٨ࡈۑ();
		}
		int ࡂޝ_u083Aض = this.ࡂޝ\u083Aض;
		this.ࡂޝ\u083Aض = ࡂޝ_u083Aض;
	}

	// Token: 0x06001A55 RID: 6741 RVA: 0x0008C210 File Offset: 0x0008A410
	[Token(Token = "0x6001A55")]
	[Address(RVA = "0x2FCC360", Offset = "0x2FCC360", VA = "0x2FCC360")]
	private bool ۶ࡎ\u0557\u05C6()
	{
		float u08B5_u0614Ԑࠋ = this.\u08B5\u0614Ԑࠋ;
		if (this.Ӱߙ\u07B5\u0735)
		{
			bool flag = this.ՠպתԥ;
			return;
		}
	}

	// Token: 0x06001A56 RID: 6742 RVA: 0x0008C238 File Offset: 0x0008A438
	[Token(Token = "0x6001A56")]
	[Address(RVA = "0x2FCDCE0", Offset = "0x2FCDCE0", VA = "0x2FCDCE0")]
	private static void ױךݺࢲ(DynamicBone \u082Eٷ\u06D4\u087C)
	{
		if (!true)
		{
		}
		List<DynamicBone> ӧԥ_u059F۵ = DynamicBone.ӦԤ\u059F۵;
	}

	// Token: 0x06001A57 RID: 6743 RVA: 0x0008C254 File Offset: 0x0008A454
	[Token(Token = "0x6001A57")]
	[Address(RVA = "0x2FCEAD8", Offset = "0x2FCEAD8", VA = "0x2FCEAD8")]
	private void FixedUpdate()
	{
		DynamicBone.ӎޣߘڕ ӎޣߘڕ = this.պۍبظ;
		this.ߔעاࢬ();
	}

	// Token: 0x06001A58 RID: 6744 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A58")]
	[Address(RVA = "0x2FCE150", Offset = "0x2FCE150", VA = "0x2FCE150")]
	private void \u088Bݟܒڢ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A59 RID: 6745 RVA: 0x0008C270 File Offset: 0x0008A470
	[Token(Token = "0x6001A59")]
	[Address(RVA = "0x2FCEC04", Offset = "0x2FCEC04", VA = "0x2FCEC04")]
	private void OnEnable()
	{
		this.\u088Bݟܒڢ();
	}

	// Token: 0x06001A5A RID: 6746 RVA: 0x0008C284 File Offset: 0x0008A484
	[Token(Token = "0x6001A5A")]
	[Address(RVA = "0x2FCEC08", Offset = "0x2FCEC08", VA = "0x2FCEC08")]
	private bool \u085Aߑއ\u060C()
	{
		float u08B5_u0614Ԑࠋ = this.\u08B5\u0614Ԑࠋ;
		if (this.Ӱߙ\u07B5\u0735)
		{
			bool flag = this.ՠպתԥ;
			return;
		}
	}

	// Token: 0x06001A5B RID: 6747 RVA: 0x0008C2A8 File Offset: 0x0008A4A8
	[Token(Token = "0x6001A5B")]
	[Address(RVA = "0x2FCE51C", Offset = "0x2FCE51C", VA = "0x2FCE51C")]
	private void \u073AՂښӳ()
	{
		int size = this.\u082B\u0602\u0709\u05CF._size;
		DynamicBone.ӎޣߘڕ ӎޣߘڕ = this.պۍبظ;
		float ڥ_u087Eٱӎ = this.ڥ\u087Eٱӎ;
		float ӗݙڎ_u086B = this.Ӗݙڎ\u086B;
	}

	// Token: 0x06001A5C RID: 6748 RVA: 0x0008C308 File Offset: 0x0008A508
	[Token(Token = "0x6001A5C")]
	[Address(RVA = "0x2FCED8C", Offset = "0x2FCED8C", VA = "0x2FCED8C")]
	public float \u060EԞ\u0892ࢧ()
	{
		/*
An exception occurred when decompiling this method (06001A5C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single DynamicBone::؎Ԟ࢒ࢧ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_0_06, ldfld:float32(DynamicBone::ࢵؔԐࠋ, ldloc:DynamicBone(this))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06001A5D RID: 6749 RVA: 0x0008C31C File Offset: 0x0008A51C
	[Token(Token = "0x6001A5D")]
	[Address(RVA = "0x2FCC394", Offset = "0x2FCC394", VA = "0x2FCC394")]
	private static void \u0610ףא\u07F7()
	{
		long initialState;
		AutoResetEvent autoResetEvent = new AutoResetEvent(initialState != 0L);
		initialState = 0L;
		if (typeof(AutoResetEvent).TypeHandle == null)
		{
		}
		DynamicBone.ގחӦګ = autoResetEvent;
		long initialCount;
		long maximumCount;
		Semaphore ࡊ_u0835Ԛ_u07F = new Semaphore((int)initialCount, (int)maximumCount);
		maximumCount = 2147483647L;
		initialCount = 0L;
		DynamicBone.ࡊ\u0835Ԛ\u07F7 = ࡊ_u0835Ԛ_u07F;
		int processorCount = Environment.ProcessorCount;
		long isBackground = 1L;
		Thread thread;
		thread.IsBackground = (isBackground != 0L);
		thread.Start();
	}

	// Token: 0x06001A5E RID: 6750 RVA: 0x0008C380 File Offset: 0x0008A580
	[Token(Token = "0x6001A5E")]
	[Address(RVA = "0x2FCED94", Offset = "0x2FCED94", VA = "0x2FCED94")]
	private void LateUpdate()
	{
		int ࡂޝ_u083Aض = this.ࡂޝ\u083Aض;
		if (ࡂޝ_u083Aض != 0)
		{
			if (ࡂޝ_u083Aض == 0)
			{
			}
			if (DynamicBone.\u0619էوԈ == 0)
			{
			}
			float num = this.ࠆגߑݞ;
			bool ކ_u0589ӵտ = this.ކ\u0589ӵտ;
			if (ކ_u0589ӵտ)
			{
				if (!ކ_u0589ӵտ)
				{
				}
				DynamicBone.ࢢ\u0830\u0822ߛ();
				return;
			}
			this.\u0598ࢫ\u05C0ږ();
			float u08B5_u0614Ԑࠋ = this.\u08B5\u0614Ԑࠋ;
			if (!this.Ӱߙ\u07B5\u0735 || !this.ՠպתԥ)
			{
				this.\u0711ӿ\u08B5ܥ();
				this.\u073AՂښӳ();
				this.\u0730ԣ٠Ә();
			}
		}
	}

	// Token: 0x06001A5F RID: 6751 RVA: 0x0008C3EC File Offset: 0x0008A5EC
	[Token(Token = "0x6001A5F")]
	[Address(RVA = "0x2FCEEBC", Offset = "0x2FCEEBC", VA = "0x2FCEEBC")]
	private static void \u06EAӈԛܢ(DynamicBone \u082Eٷ\u06D4\u087C)
	{
		if (!true)
		{
		}
		int num = DynamicBone.ࡊ\u0835Ԛ\u07F7.Release();
	}

	// Token: 0x06001A60 RID: 6752 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A60")]
	[Address(RVA = "0x2FCEC3C", Offset = "0x2FCEC3C", VA = "0x2FCEC3C")]
	private void \u05F4\u059B\u0606\u05B0(float ހӉ\u0608ࡘ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A61 RID: 6753 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A61")]
	[Address(RVA = "0x2FCECEC", Offset = "0x2FCECEC", VA = "0x2FCECEC")]
	private void \u05F5ڊ\u07F1ࡤ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A62 RID: 6754 RVA: 0x0008C410 File Offset: 0x0008A610
	[Token(Token = "0x6001A62")]
	[Address(RVA = "0x2FCF41C", Offset = "0x2FCF41C", VA = "0x2FCF41C")]
	private void ܡնܟ\u0742()
	{
	}

	// Token: 0x06001A63 RID: 6755 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A63")]
	[Address(RVA = "0x2FCDDE0", Offset = "0x2FCDDE0", VA = "0x2FCDDE0")]
	private void \u05F5ڊ\u07F1ࡤ(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A65 RID: 6757 RVA: 0x0008C454 File Offset: 0x0008A654
	[Token(Token = "0x6001A65")]
	[Address(RVA = "0x2FCF54C", Offset = "0x2FCF54C", VA = "0x2FCF54C")]
	private void ߖڗݲ߄()
	{
	}

	// Token: 0x06001A66 RID: 6758 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A66")]
	[Address(RVA = "0x2FCEAEC", Offset = "0x2FCEAEC", VA = "0x2FCEAEC")]
	private void \u088Bݟܒڢ(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A67 RID: 6759 RVA: 0x0008C474 File Offset: 0x0008A674
	[Token(Token = "0x6001A67")]
	[Address(RVA = "0x2FCC97C", Offset = "0x2FCC97C", VA = "0x2FCC97C")]
	private static void ץߜٹݤ(DynamicBone \u082Eٷ\u06D4\u087C)
	{
		if (!true)
		{
		}
		int num = DynamicBone.ࡊ\u0835Ԛ\u07F7.Release();
	}

	// Token: 0x06001A68 RID: 6760 RVA: 0x0008C498 File Offset: 0x0008A698
	[Token(Token = "0x6001A68")]
	[Address(RVA = "0x2FCF5BC", Offset = "0x2FCF5BC", VA = "0x2FCF5BC")]
	public DynamicBone()
	{
		long ӗݙڎ_u086B = 17008L;
		int num = 52429;
		this.Ӗݙڎ\u086B = (float)ӗݙڎ_u086B;
		this.ݭࠇ\u0613\u0610 = (float)num;
		this.Զݺ\u0839\u0733 = (float)num;
		this.ݱ\u06DC\u0590\u0820 = (float)num;
		Vector3 zero = Vector3.zero;
		Vector3 zero2 = Vector3.zero;
		Vector3 zero3 = Vector3.zero;
		long u08B5_u0614Ԑࠋ = 1065353216L;
		int u061F_u06EB_u05C2ܭ = 16800;
		long num2 = 1L;
		this.ࠆגߑݞ = (float)u08B5_u0614Ԑࠋ;
		this.\u061F\u06EB\u05C2ܭ = (float)u061F_u06EB_u05C2ܭ;
		this.߄ԯݭջ = (num2 != 0L);
		this.\u08B5\u0614Ԑࠋ = (float)u08B5_u0614Ԑࠋ;
		List<DynamicBone.\u064Eԧ٧ش> u082B_u0602_u0709_u05CF = new List();
		this.\u082B\u0602\u0709\u05CF = u082B_u0602_u0709_u05CF;
		base..ctor();
	}

	// Token: 0x06001A69 RID: 6761 RVA: 0x0008C530 File Offset: 0x0008A730
	[Token(Token = "0x6001A69")]
	[Address(RVA = "0x2FCF6AC", Offset = "0x2FCF6AC", VA = "0x2FCF6AC")]
	private static void ڴݭ\u073Aޞ()
	{
	}

	// Token: 0x06001A6A RID: 6762 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A6A")]
	[Address(RVA = "0x2FCF774", Offset = "0x2FCF774", VA = "0x2FCF774")]
	private void \u05F8Өޡ\u07B9(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A6B RID: 6763 RVA: 0x0008C560 File Offset: 0x0008A760
	[Token(Token = "0x6001A6B")]
	[Address(RVA = "0x2FCF88C", Offset = "0x2FCF88C", VA = "0x2FCF88C")]
	private void ؼԨ\u064Bה()
	{
		int size = this.\u082B\u0602\u0709\u05CF._size;
		DynamicBone.ӎޣߘڕ ӎޣߘڕ = this.պۍبظ;
		float ӗݙڎ_u086B = this.Ӗݙڎ\u086B;
		float ڥ_u087Eٱӎ = this.ڥ\u087Eٱӎ;
		float u0600ӜԊӆ = this.\u0600ӜԊӆ;
		this.\u0600ӜԊӆ = ӗݙڎ_u086B;
		this.\u0600ӜԊӆ = ӗݙڎ_u086B;
		this.ܗݔێ\u085C();
	}

	// Token: 0x06001A6C RID: 6764 RVA: 0x0008C5B4 File Offset: 0x0008A7B4
	[Token(Token = "0x6001A6C")]
	[Address(RVA = "0x2FCD4EC", Offset = "0x2FCD4EC", VA = "0x2FCD4EC")]
	public void ޠ\u05BE\u0743\u055B(float \u0830\u0740ࡔԈ)
	{
		float u08B5_u0614Ԑࠋ = this.\u08B5\u0614Ԑࠋ;
		this.ࠀ٨ࡈۑ();
	}

	// Token: 0x06001A6D RID: 6765 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A6D")]
	[Address(RVA = "0x2FCEF2C", Offset = "0x2FCEF2C", VA = "0x2FCEF2C")]
	private void \u05F4\u059B\u0606\u05B0(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ, float ހӉ\u0608ࡘ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A6E RID: 6766 RVA: 0x0008C5D8 File Offset: 0x0008A7D8
	[Token(Token = "0x6001A6E")]
	[Address(RVA = "0x2FCF9C8", Offset = "0x2FCF9C8", VA = "0x2FCF9C8")]
	private void \u0884\u059Fޓ۹()
	{
		this.Ӿ\u0739ڽն();
	}

	// Token: 0x06001A6F RID: 6767 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A6F")]
	[Address(RVA = "0x2FCC9EC", Offset = "0x2FCC9EC", VA = "0x2FCC9EC")]
	private void \u0730ԣ٠Ә()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A70 RID: 6768 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A70")]
	[Address(RVA = "0x2FCFB90", Offset = "0x2FCFB90", VA = "0x2FCFB90")]
	private void ޛӳ\u07AB\u074B(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A71 RID: 6769 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A71")]
	[Address(RVA = "0x2FCFCA8", Offset = "0x2FCFCA8", VA = "0x2FCFCA8")]
	private void \u0602څ\u055Eࢯ(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A72 RID: 6770 RVA: 0x0008C5EC File Offset: 0x0008A7EC
	[Token(Token = "0x6001A72")]
	[Address(RVA = "0x2FCFFD8", Offset = "0x2FCFFD8", VA = "0x2FCFFD8")]
	private static void ݡ\u06D9گٽ()
	{
	}

	// Token: 0x06001A73 RID: 6771 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A73")]
	[Address(RVA = "0x2FD00A0", Offset = "0x2FD00A0", VA = "0x2FD00A0")]
	private void ӻ\u0885ߕ\u0600(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ, Transform زحا\u05B0, int ԧՅ\u07F0ࡇ, float ࡩ\u0892Ն\u0898)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A74 RID: 6772 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A74")]
	[Address(RVA = "0x2FD0638", Offset = "0x2FD0638", VA = "0x2FD0638")]
	private bool բߗ\u07AB\u081E()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A75 RID: 6773 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A75")]
	[Address(RVA = "0x2FCF9CC", Offset = "0x2FCF9CC", VA = "0x2FCF9CC")]
	private void \u0730ԣ٠Ә(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ, Vector3 ظر\u0874\u0879, Vector3 ࢻݕ\u0877ߒ, Vector3 ڍ\u07F5ݫ\u074B, bool \u05A7Տ١צ, bool ւ\u086EԈӵ, bool \u0891ࡊ\u066Cڲ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A76 RID: 6774 RVA: 0x0008C61C File Offset: 0x0008A81C
	[Token(Token = "0x6001A76")]
	[Address(RVA = "0x2FD097C", Offset = "0x2FD097C", VA = "0x2FD097C")]
	private void ڏރ\u0590ԟ()
	{
		float ӗݙڎ_u086B = this.Ӗݙڎ\u086B;
		float ݭࠇ_u0613_u = this.ݭࠇ\u0613\u0610;
		this.Ӗݙڎ\u086B = ӗݙڎ_u086B;
		float value2;
		float value = Mathf.Clamp01(value2);
		float զݺ_u0839_u = this.Զݺ\u0839\u0733;
		this.ݭࠇ\u0613\u0610 = ӗݙڎ_u086B;
		float value3 = Mathf.Clamp01(value);
		float ݱ_u06DC_u0590_u = this.ݱ\u06DC\u0590\u0820;
		this.Զݺ\u0839\u0733 = ӗݙڎ_u086B;
		float value4 = Mathf.Clamp01(value3);
		float թبۿ_u064D = this.Թبۿ\u064D;
		this.ݱ\u06DC\u0590\u0820 = ӗݙڎ_u086B;
		float value5 = Mathf.Clamp01(value4);
		float u0891_u05C8_u059F٣ = this.\u0891\u05C8\u059F٣;
		float num = Mathf.Clamp01(value5);
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		this.\u0891\u05C8\u059F٣ = ӗݙڎ_u086B;
		this.\u07FE\u05F7ۿب = ӗݙڎ_u086B;
		bool isEditor = Application.isEditor;
		bool isPlaying = Application.isPlaying;
		bool flag = this.բߗ\u07AB\u081E();
		this.ߖڗݲ߄();
		this.ࠐԺ\u07B8\u0598();
	}

	// Token: 0x06001A77 RID: 6775 RVA: 0x0008C6FC File Offset: 0x0008A8FC
	[Token(Token = "0x6001A77")]
	[Address(RVA = "0x2FD0A7C", Offset = "0x2FD0A7C", VA = "0x2FD0A7C")]
	private static Vector3 ۏࡣڣք(Vector3 Ԥևٵ\u05AA, Vector3 ݧ\u06FEܜմ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001A78 RID: 6776 RVA: 0x0008C70C File Offset: 0x0008A90C
	[Token(Token = "0x6001A78")]
	[Address(RVA = "0x2FD0AB0", Offset = "0x2FD0AB0", VA = "0x2FD0AB0")]
	private void ӀԹ\u06DA\u05C5()
	{
		int ࡂޝ_u083Aض = this.ࡂޝ\u083Aض;
		if (ࡂޝ_u083Aض != 0)
		{
			if (ࡂޝ_u083Aض == 0)
			{
			}
			if (DynamicBone.\u0619էوԈ == 0)
			{
			}
			float num = this.ࠆגߑݞ;
			if (this.ކ\u0589ӵտ)
			{
				long num2 = 1L;
				this.ކ\u0589ӵտ = (num2 != 0L);
				if (num2 == 0L)
				{
				}
				DynamicBone.ࢢ\u0830\u0822ߛ();
				return;
			}
			this.\u0598ࢫ\u05C0ږ();
			float u08B5_u0614Ԑࠋ = this.\u08B5\u0614Ԑࠋ;
			if (!this.Ӱߙ\u07B5\u0735 || !this.ՠպתԥ)
			{
				this.\u0711ӿ\u08B5ܥ();
				this.\u073AՂښӳ();
				this.\u0730ԣ٠Ә();
			}
		}
	}

	// Token: 0x06001A79 RID: 6777 RVA: 0x0008C780 File Offset: 0x0008A980
	[Token(Token = "0x6001A79")]
	[Address(RVA = "0x2FCF944", Offset = "0x2FCF944", VA = "0x2FCF944")]
	private void ة\u05FF\u0818ԫ(float ހӉ\u0608ࡘ)
	{
	}

	// Token: 0x06001A7A RID: 6778 RVA: 0x0008C79C File Offset: 0x0008A99C
	[Token(Token = "0x6001A7A")]
	[Address(RVA = "0x2FD0BDC", Offset = "0x2FD0BDC", VA = "0x2FD0BDC")]
	private void OnValidate()
	{
		float ӗݙڎ_u086B = this.Ӗݙڎ\u086B;
		float ݭࠇ_u0613_u = this.ݭࠇ\u0613\u0610;
		this.Ӗݙڎ\u086B = ӗݙڎ_u086B;
		float value2;
		float value = Mathf.Clamp01(value2);
		float զݺ_u0839_u = this.Զݺ\u0839\u0733;
		this.ݭࠇ\u0613\u0610 = ӗݙڎ_u086B;
		float value3 = Mathf.Clamp01(value);
		float ݱ_u06DC_u0590_u = this.ݱ\u06DC\u0590\u0820;
		this.Զݺ\u0839\u0733 = ӗݙڎ_u086B;
		float value4 = Mathf.Clamp01(value3);
		float թبۿ_u064D = this.Թبۿ\u064D;
		this.ݱ\u06DC\u0590\u0820 = ӗݙڎ_u086B;
		float value5 = Mathf.Clamp01(value4);
		float u0891_u05C8_u059F٣ = this.\u0891\u05C8\u059F٣;
		this.Թبۿ\u064D = ӗݙڎ_u086B;
		float num = Mathf.Clamp01(value5);
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		this.\u0891\u05C8\u059F٣ = ӗݙڎ_u086B;
		this.\u07FE\u05F7ۿب = ӗݙڎ_u086B;
		bool isEditor = Application.isEditor;
		bool isPlaying = Application.isPlaying;
		bool flag = this.բߗ\u07AB\u081E();
		this.ࠀ٨ࡈۑ();
		this.ࠐԺ\u07B8\u0598();
	}

	// Token: 0x06001A7B RID: 6779 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A7B")]
	[Address(RVA = "0x2FD0CD4", Offset = "0x2FD0CD4", VA = "0x2FD0CD4")]
	private void OnDrawGizmosSelected()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A7C RID: 6780 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A7C")]
	[Address(RVA = "0x2FD0DD0", Offset = "0x2FD0DD0", VA = "0x2FD0DD0")]
	private void ڭ١Ԋԍ(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A7D RID: 6781 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A7D")]
	[Address(RVA = "0x2FCE734", Offset = "0x2FCE734", VA = "0x2FCE734")]
	public void ࠐԺ\u07B8\u0598()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A7E RID: 6782 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A7E")]
	[Address(RVA = "0x2FD1100", Offset = "0x2FD1100", VA = "0x2FD1100")]
	public void ӷܢ\u0838چ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A7F RID: 6783 RVA: 0x0008C880 File Offset: 0x0008AA80
	[Token(Token = "0x6001A7F")]
	[Address(RVA = "0x2FD11AC", Offset = "0x2FD11AC", VA = "0x2FD11AC")]
	private void \u055F\u066Dݔܪ()
	{
		this.\u088Bݟܒڢ();
	}

	// Token: 0x06001A80 RID: 6784 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A80")]
	[Address(RVA = "0x2FD11B0", Offset = "0x2FD11B0", VA = "0x2FD11B0")]
	private void ةړۃ\u06DB(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A81 RID: 6785 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A81")]
	[Address(RVA = "0x2FD12DC", Offset = "0x2FD12DC", VA = "0x2FD12DC")]
	private void \u0743ࢨ\u055Aހ(DynamicBone.\u064Eԧ٧ش ٨\u05CD\u088Fߠ)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A82 RID: 6786 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A82")]
	[Address(RVA = "0x2FD13B0", Offset = "0x2FD13B0", VA = "0x2FD13B0")]
	private static void ڜԆՖ\u0602()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x04000331 RID: 817
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000331")]
	public Transform \u07A8ջԖץ;

	// Token: 0x04000332 RID: 818
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000332")]
	public List<Transform> \u0593أՂڔ;

	// Token: 0x04000333 RID: 819
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000333")]
	public float Ӗݙڎ\u086B;

	// Token: 0x04000334 RID: 820
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x4000334")]
	public DynamicBone.ӎޣߘڕ պۍبظ;

	// Token: 0x04000335 RID: 821
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000335")]
	public float ݭࠇ\u0613\u0610;

	// Token: 0x04000336 RID: 822
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000336")]
	public AnimationCurve ۆ\u087F\u05C1ݛ;

	// Token: 0x04000337 RID: 823
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000337")]
	public float Զݺ\u0839\u0733;

	// Token: 0x04000338 RID: 824
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000338")]
	public AnimationCurve \u0709Ә\u082Eࡎ;

	// Token: 0x04000339 RID: 825
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000339")]
	public float ݱ\u06DC\u0590\u0820;

	// Token: 0x0400033A RID: 826
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400033A")]
	public AnimationCurve \u085F\u0612ލӠ;

	// Token: 0x0400033B RID: 827
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400033B")]
	public float Թبۿ\u064D;

	// Token: 0x0400033C RID: 828
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x400033C")]
	public AnimationCurve ש\u0819ࡣ\u06E7;

	// Token: 0x0400033D RID: 829
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x400033D")]
	public float \u0891\u05C8\u059F٣;

	// Token: 0x0400033E RID: 830
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x400033E")]
	public AnimationCurve ڰݦ\u083A\u086C;

	// Token: 0x0400033F RID: 831
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x400033F")]
	public float \u07FE\u05F7ۿب;

	// Token: 0x04000340 RID: 832
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x4000340")]
	public AnimationCurve ࠌգ\u07FEۏ;

	// Token: 0x04000341 RID: 833
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x4000341")]
	public float ޚ\u0590ܥࢦ;

	// Token: 0x04000342 RID: 834
	[FieldOffset(Offset = "0x94")]
	[Token(Token = "0x4000342")]
	public Vector3 \u082FԹࡁ\u0895;

	// Token: 0x04000343 RID: 835
	[FieldOffset(Offset = "0xA0")]
	[Token(Token = "0x4000343")]
	public Vector3 צۿހӝ;

	// Token: 0x04000344 RID: 836
	[FieldOffset(Offset = "0xAC")]
	[Token(Token = "0x4000344")]
	public Vector3 \u058A\u05A1\u0828ԏ;

	// Token: 0x04000345 RID: 837
	[FieldOffset(Offset = "0xB8")]
	[Token(Token = "0x4000345")]
	public float ࠆגߑݞ;

	// Token: 0x04000346 RID: 838
	[FieldOffset(Offset = "0xC0")]
	[Token(Token = "0x4000346")]
	public List<DynamicBoneColliderBase> ޒ\u0874Ժ\u0822;

	// Token: 0x04000347 RID: 839
	[FieldOffset(Offset = "0xC8")]
	[Token(Token = "0x4000347")]
	public List<Transform> \u0824ظԝӱ;

	// Token: 0x04000348 RID: 840
	[FieldOffset(Offset = "0xD0")]
	[Token(Token = "0x4000348")]
	public DynamicBone.\u0890ޛ\u085Dࡌ Իےݏ\u0859;

	// Token: 0x04000349 RID: 841
	[FieldOffset(Offset = "0xD4")]
	[Token(Token = "0x4000349")]
	public bool Ӱߙ\u07B5\u0735;

	// Token: 0x0400034A RID: 842
	[FieldOffset(Offset = "0xD8")]
	[Token(Token = "0x400034A")]
	public Transform ӷݴࢭ\u0705;

	// Token: 0x0400034B RID: 843
	[FieldOffset(Offset = "0xE0")]
	[Token(Token = "0x400034B")]
	public float \u061F\u06EB\u05C2ܭ;

	// Token: 0x0400034C RID: 844
	[FieldOffset(Offset = "0xE4")]
	[Token(Token = "0x400034C")]
	[HideInInspector]
	public bool ߄ԯݭջ;

	// Token: 0x0400034D RID: 845
	[FieldOffset(Offset = "0xE8")]
	[Token(Token = "0x400034D")]
	private Vector3 \u07FDܨ\u0652۸;

	// Token: 0x0400034E RID: 846
	[FieldOffset(Offset = "0xF4")]
	[Token(Token = "0x400034E")]
	private Vector3 ߚࡓ\u087Dս;

	// Token: 0x0400034F RID: 847
	[FieldOffset(Offset = "0x100")]
	[Token(Token = "0x400034F")]
	private float ݯӽ\u061B\u07EB;

	// Token: 0x04000350 RID: 848
	[FieldOffset(Offset = "0x104")]
	[Token(Token = "0x4000350")]
	private float \u0600ӜԊӆ;

	// Token: 0x04000351 RID: 849
	[FieldOffset(Offset = "0x108")]
	[Token(Token = "0x4000351")]
	private float \u08B5\u0614Ԑࠋ;

	// Token: 0x04000352 RID: 850
	[FieldOffset(Offset = "0x10C")]
	[Token(Token = "0x4000352")]
	private bool ՠպתԥ;

	// Token: 0x04000353 RID: 851
	[FieldOffset(Offset = "0x110")]
	[Token(Token = "0x4000353")]
	private int ࡂޝ\u083Aض;

	// Token: 0x04000354 RID: 852
	[FieldOffset(Offset = "0x118")]
	[Token(Token = "0x4000354")]
	private List<DynamicBone.\u064Eԧ٧ش> \u082B\u0602\u0709\u05CF;

	// Token: 0x04000355 RID: 853
	[FieldOffset(Offset = "0x120")]
	[Token(Token = "0x4000355")]
	private float ڥ\u087Eٱӎ;

	// Token: 0x04000356 RID: 854
	[FieldOffset(Offset = "0x128")]
	[Token(Token = "0x4000356")]
	private List<DynamicBoneColliderBase> غ\u07FFڬھ;

	// Token: 0x04000357 RID: 855
	[FieldOffset(Offset = "0x130")]
	[Token(Token = "0x4000357")]
	private bool ކ\u0589ӵտ;

	// Token: 0x04000358 RID: 856
	[Token(Token = "0x4000358")]
	private static List<DynamicBone> ӦԤ\u059F۵ = new List();

	// Token: 0x04000359 RID: 857
	[Token(Token = "0x4000359")]
	private static List<DynamicBone> Ֆ\u073C\u0615ݧ = new List();

	// Token: 0x0400035A RID: 858
	[Token(Token = "0x400035A")]
	private static AutoResetEvent ގחӦګ;

	// Token: 0x0400035B RID: 859
	[Token(Token = "0x400035B")]
	private static int ىԭࠓܚ;

	// Token: 0x0400035C RID: 860
	[Token(Token = "0x400035C")]
	private static Semaphore ࡊ\u0835Ԛ\u07F7;

	// Token: 0x0400035D RID: 861
	[Token(Token = "0x400035D")]
	private static int ݧ\u064E\u0823\u058D;

	// Token: 0x0400035E RID: 862
	[Token(Token = "0x400035E")]
	private static int \u0619էوԈ;

	// Token: 0x0400035F RID: 863
	[Token(Token = "0x400035F")]
	private static int Ԩ\u06DBԭ\u07F5;

	// Token: 0x020000B1 RID: 177
	[Token(Token = "0x20000B1")]
	public enum ӎޣߘڕ
	{
		// Token: 0x04000361 RID: 865
		[Token(Token = "0x4000361")]
		Ԁࡩػ\u086F,
		// Token: 0x04000362 RID: 866
		[Token(Token = "0x4000362")]
		\u061C\u06EDتڨ,
		// Token: 0x04000363 RID: 867
		[Token(Token = "0x4000363")]
		\u081BثԢӫ,
		// Token: 0x04000364 RID: 868
		[Token(Token = "0x4000364")]
		\u0658ՖࠔӇ
	}

	// Token: 0x020000B2 RID: 178
	[Token(Token = "0x20000B2")]
	public enum \u0890ޛ\u085Dࡌ
	{
		// Token: 0x04000366 RID: 870
		[Token(Token = "0x4000366")]
		ՃޙӚ\u083F,
		// Token: 0x04000367 RID: 871
		[Token(Token = "0x4000367")]
		\u06DBޣݦض,
		// Token: 0x04000368 RID: 872
		[Token(Token = "0x4000368")]
		ܖյӮݠ,
		// Token: 0x04000369 RID: 873
		[Token(Token = "0x4000369")]
		م\u07F1ӯࡘ
	}

	// Token: 0x020000B3 RID: 179
	[Token(Token = "0x20000B3")]
	private class \u0836\u05FF\u0703ڔ
	{
		// Token: 0x06001A83 RID: 6787 RVA: 0x0008C894 File Offset: 0x0008AA94
		[Token(Token = "0x6001A83")]
		[Address(RVA = "0x2132058", Offset = "0x2132058", VA = "0x2132058")]
		public \u0836\u05FF\u0703ڔ()
		{
		}

		// Token: 0x0400036A RID: 874
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400036A")]
		public Transform \u07AA\u07B9۸٥;

		// Token: 0x0400036B RID: 875
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400036B")]
		public int ԛ\u0700إڈ;

		// Token: 0x0400036C RID: 876
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x400036C")]
		public int ԥڲوޡ;

		// Token: 0x0400036D RID: 877
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400036D")]
		public float ݭࠇ\u0613\u0610;

		// Token: 0x0400036E RID: 878
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x400036E")]
		public float Զݺ\u0839\u0733;

		// Token: 0x0400036F RID: 879
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400036F")]
		public float ݱ\u06DC\u0590\u0820;

		// Token: 0x04000370 RID: 880
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000370")]
		public float Թبۿ\u064D;

		// Token: 0x04000371 RID: 881
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000371")]
		public float \u0891\u05C8\u059F٣;

		// Token: 0x04000372 RID: 882
		[FieldOffset(Offset = "0x34")]
		[Token(Token = "0x4000372")]
		public float \u07FE\u05F7ۿب;

		// Token: 0x04000373 RID: 883
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000373")]
		public float ۻࠃ\u07B5\u058D;

		// Token: 0x04000374 RID: 884
		[FieldOffset(Offset = "0x3C")]
		[Token(Token = "0x4000374")]
		public bool \u081D\u055Cࠈ\u05B6;

		// Token: 0x04000375 RID: 885
		[FieldOffset(Offset = "0x3D")]
		[Token(Token = "0x4000375")]
		public bool \u0741\u07B5ւތ;

		// Token: 0x04000376 RID: 886
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000376")]
		public Vector3 \u055D\u061Dࠀ\u066D;

		// Token: 0x04000377 RID: 887
		[FieldOffset(Offset = "0x4C")]
		[Token(Token = "0x4000377")]
		public Vector3 \u0733ޖ\u0618ց;

		// Token: 0x04000378 RID: 888
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000378")]
		public Vector3 \u082FԹࡁ\u0895;

		// Token: 0x04000379 RID: 889
		[FieldOffset(Offset = "0x64")]
		[Token(Token = "0x4000379")]
		public Vector3 Ӌڹ\u07AE\u0897;

		// Token: 0x0400037A RID: 890
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x400037A")]
		public Quaternion ۋԧ\u082Bٸ;

		// Token: 0x0400037B RID: 891
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x400037B")]
		public Vector3 \u058DӽՑ\u0530;

		// Token: 0x0400037C RID: 892
		[FieldOffset(Offset = "0x8C")]
		[Token(Token = "0x400037C")]
		public Vector3 ݠ\u05F8ӈխ;

		// Token: 0x0400037D RID: 893
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x400037D")]
		public Matrix4x4 ڴ۷\u05BEӛ;
	}

	// Token: 0x020000B4 RID: 180
	[Token(Token = "0x20000B4")]
	private class \u064Eԧ٧ش
	{
		// Token: 0x06001A84 RID: 6788 RVA: 0x0008C8A8 File Offset: 0x0008AAA8
		[Token(Token = "0x6001A84")]
		[Address(RVA = "0x2131FD4", Offset = "0x2131FD4", VA = "0x2131FD4")]
		public \u064Eԧ٧ش()
		{
			List<DynamicBone.\u0836\u05FF\u0703ڔ> u0888ބ_u081Fڪ = new List();
			this.\u0888ބ\u081Fڪ = u0888ބ_u081Fڪ;
			base..ctor();
		}

		// Token: 0x0400037E RID: 894
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400037E")]
		public Transform \u07A8ջԖץ;

		// Token: 0x0400037F RID: 895
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400037F")]
		public Vector3 ځܕշ\u05B4;

		// Token: 0x04000380 RID: 896
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4000380")]
		public Matrix4x4 \u0617ݙ\u07B0Ӛ;

		// Token: 0x04000381 RID: 897
		[FieldOffset(Offset = "0x64")]
		[Token(Token = "0x4000381")]
		public float ߧ\u05B2\u05C1\u073E;

		// Token: 0x04000382 RID: 898
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x4000382")]
		public List<DynamicBone.\u0836\u05FF\u0703ڔ> \u0888ބ\u081Fڪ;

		// Token: 0x04000383 RID: 899
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x4000383")]
		public Vector3 \u0836ԥࢰگ;
	}

	// Token: 0x020000B5 RID: 181
	[Token(Token = "0x20000B5")]
	[CompilerGenerated]
	private sealed class \u059E\u05FBםࢲ
	{
		// Token: 0x06001A85 RID: 6789 RVA: 0x0008C8C8 File Offset: 0x0008AAC8
		[Token(Token = "0x6001A85")]
		[Address(RVA = "0x2131F48", Offset = "0x2131F48", VA = "0x2131F48")]
		public \u059E\u05FBםࢲ()
		{
		}

		// Token: 0x06001A86 RID: 6790 RVA: 0x0008C8DC File Offset: 0x0008AADC
		[Token(Token = "0x6001A86")]
		[Address(RVA = "0x2131F50", Offset = "0x2131F50", VA = "0x2131F50")]
		internal bool ӣ\u083F\u088Dܦ(DynamicBone.\u064Eԧ٧ش x)
		{
			Transform u07A8ջԖץ = x.\u07A8ջԖץ;
			Transform y = this.root;
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			return u07A8ջԖץ == y;
		}

		// Token: 0x04000384 RID: 900
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000384")]
		public Transform root;
	}
}
