﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Locomotion;
using UnityEngine;

// Token: 0x020000C2 RID: 194
[Token(Token = "0x20000C2")]
public class LavaKill : MonoBehaviour
{
	// Token: 0x06001CA7 RID: 7335 RVA: 0x00093E08 File Offset: 0x00092008
	[Token(Token = "0x6001CA7")]
	[Address(RVA = "0x2AD63E4", Offset = "0x2AD63E4", VA = "0x2AD63E4")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Start Gamemode";
		this.ն\u0880و\u0654.\u060Dӫߠވ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.\u05CF\u0839ݙԟ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CA8 RID: 7336 RVA: 0x00093E98 File Offset: 0x00092098
	[Token(Token = "0x6001CA8")]
	[Address(RVA = "0x2AD68E8", Offset = "0x2AD68E8", VA = "0x2AD68E8")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		string name = \u07FEל\u05AC\u0877.gameObject.name;
		this.ն\u0880و\u0654.\u060Dӫߠވ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.\u060Dӫߠވ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CA9 RID: 7337 RVA: 0x00093F14 File Offset: 0x00092114
	[Token(Token = "0x6001CA9")]
	[Address(RVA = "0x2AD6A20", Offset = "0x2AD6A20", VA = "0x2AD6A20")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Left Hand";
		this.ն\u0880و\u0654.Ӝ\u07F1ࡁܘ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CAA RID: 7338 RVA: 0x00093FA4 File Offset: 0x000921A4
	[Token(Token = "0x6001CAA")]
	[Address(RVA = "0x2AD6F24", Offset = "0x2AD6F24", VA = "0x2AD6F24")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "username";
		this.ն\u0880و\u0654.إࡅܬՍ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ܣֆױݘ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CAB RID: 7339 RVA: 0x00094028 File Offset: 0x00092228
	[Token(Token = "0x6001CAB")]
	[Address(RVA = "0x2AD7424", Offset = "0x2AD7424", VA = "0x2AD7424")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		string name = \u07FEל\u05AC\u0877.gameObject.name;
		this.ն\u0880و\u0654.Ӝ\u07F1ࡁܘ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.\u060Dӫߠވ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CAC RID: 7340 RVA: 0x000940A4 File Offset: 0x000922A4
	[Token(Token = "0x6001CAC")]
	[Address(RVA = "0x2AD755C", Offset = "0x2AD755C", VA = "0x2AD755C")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "ORGPORT";
		this.ն\u0880و\u0654.Ӥܗ\u07BFӱ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CAD RID: 7341 RVA: 0x00094128 File Offset: 0x00092328
	[Token(Token = "0x6001CAD")]
	[Address(RVA = "0x2AD787C", Offset = "0x2AD787C", VA = "0x2AD787C")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "DisableCosmetic";
		this.ն\u0880و\u0654.\u0740\u085E\u07FF\u064B();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ࡈ\u06DC\u087E\u0834();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CAE RID: 7342 RVA: 0x000941B8 File Offset: 0x000923B8
	[Token(Token = "0x6001CAE")]
	[Address(RVA = "0x2AD7D7C", Offset = "0x2AD7D7C", VA = "0x2AD7D7C")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Player";
		this.ն\u0880و\u0654.Ӥܗ\u07BFӱ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.\u0740\u085E\u07FF\u064B();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CAF RID: 7343 RVA: 0x00094248 File Offset: 0x00092448
	[Token(Token = "0x6001CAF")]
	[Address(RVA = "0x2AD7EB8", Offset = "0x2AD7EB8", VA = "0x2AD7EB8")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "PRESS AGAIN TO CONFIRM";
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CB0 RID: 7344 RVA: 0x000942B8 File Offset: 0x000924B8
	[Token(Token = "0x6001CB0")]
	[Address(RVA = "0x2AD81D0", Offset = "0x2AD81D0", VA = "0x2AD81D0")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "PLAYER IS BANNED";
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CB1 RID: 7345 RVA: 0x0009433C File Offset: 0x0009253C
	[Token(Token = "0x6001CB1")]
	[Address(RVA = "0x2AD8308", Offset = "0x2AD8308", VA = "0x2AD8308")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "containsStaff";
		this.ն\u0880و\u0654.ࡈ\u06DC\u087E\u0834();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CB2 RID: 7346 RVA: 0x000943B8 File Offset: 0x000925B8
	[Token(Token = "0x6001CB2")]
	[Address(RVA = "0x2AD8440", Offset = "0x2AD8440", VA = "0x2AD8440")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "hand 2";
		this.ն\u0880و\u0654.ܣֆױݘ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ւߠݱԕ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CB3 RID: 7347 RVA: 0x0009443C File Offset: 0x0009263C
	[Token(Token = "0x6001CB3")]
	[Address(RVA = "0x2AD875C", Offset = "0x2AD875C", VA = "0x2AD875C")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Charged!";
		this.ն\u0880و\u0654.Ӥܗ\u07BFӱ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ւߠݱԕ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CB4 RID: 7348 RVA: 0x000944C4 File Offset: 0x000926C4
	[Token(Token = "0x6001CB4")]
	[Address(RVA = "0x2AD8898", Offset = "0x2AD8898", VA = "0x2AD8898")]
	public LavaKill()
	{
	}

	// Token: 0x06001CB5 RID: 7349 RVA: 0x000944D8 File Offset: 0x000926D8
	[Token(Token = "0x6001CB5")]
	[Address(RVA = "0x2AD88A0", Offset = "0x2AD88A0", VA = "0x2AD88A0")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == ".Please press the button if you would like to play alone";
		this.ն\u0880و\u0654.\u060Dӫߠވ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ܣֆױݘ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CB6 RID: 7350 RVA: 0x0009455C File Offset: 0x0009275C
	[Token(Token = "0x6001CB6")]
	[Address(RVA = "0x2AD89D8", Offset = "0x2AD89D8", VA = "0x2AD89D8")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "PlayerDeath";
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.\u0740\u085E\u07FF\u064B();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CB7 RID: 7351 RVA: 0x000945E0 File Offset: 0x000927E0
	[Token(Token = "0x6001CB7")]
	[Address(RVA = "0x2AD8B10", Offset = "0x2AD8B10", VA = "0x2AD8B10")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "A Player has left the Room.";
		this.ն\u0880و\u0654.ւߠݱԕ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.إࡅܬՍ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CB8 RID: 7352 RVA: 0x00094670 File Offset: 0x00092870
	[Token(Token = "0x6001CB8")]
	[Address(RVA = "0x2AD8C4C", Offset = "0x2AD8C4C", VA = "0x2AD8C4C")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		string name = \u07FEל\u05AC\u0877.gameObject.name;
		this.ն\u0880و\u0654.\u05CF\u0839ݙԟ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CB9 RID: 7353 RVA: 0x000946F8 File Offset: 0x000928F8
	[Token(Token = "0x6001CB9")]
	[Address(RVA = "0x2AD8D88", Offset = "0x2AD8D88", VA = "0x2AD8D88")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "EnableCosmetic";
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.إࡅܬՍ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CBA RID: 7354 RVA: 0x0009477C File Offset: 0x0009297C
	[Token(Token = "0x6001CBA")]
	[Address(RVA = "0x2AD8EC0", Offset = "0x2AD8EC0", VA = "0x2AD8EC0")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Player";
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.\u060Dӫߠވ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CBB RID: 7355 RVA: 0x0009480C File Offset: 0x00092A0C
	[Token(Token = "0x6001CBB")]
	[Address(RVA = "0x2AD8FF8", Offset = "0x2AD8FF8", VA = "0x2AD8FF8")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Head";
		this.ն\u0880و\u0654.Ӝ\u07F1ࡁܘ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ւߠݱԕ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CBC RID: 7356 RVA: 0x0009489C File Offset: 0x00092A9C
	[Token(Token = "0x6001CBC")]
	[Address(RVA = "0x2AD9134", Offset = "0x2AD9134", VA = "0x2AD9134")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Tagged";
		this.ն\u0880و\u0654.Ӥܗ\u07BFӱ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CBD RID: 7357 RVA: 0x00094918 File Offset: 0x00092B18
	[Token(Token = "0x6001CBD")]
	[Address(RVA = "0x2AD926C", Offset = "0x2AD926C", VA = "0x2AD926C")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Update User Inventory";
		this.ն\u0880و\u0654.\u05CF\u0839ݙԟ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CBE RID: 7358 RVA: 0x000949A8 File Offset: 0x00092BA8
	[Token(Token = "0x6001CBE")]
	[Address(RVA = "0x2AD93A8", Offset = "0x2AD93A8", VA = "0x2AD93A8")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		string name = \u07FEל\u05AC\u0877.gameObject.name;
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CBF RID: 7359 RVA: 0x00094A30 File Offset: 0x00092C30
	[Token(Token = "0x6001CBF")]
	[Address(RVA = "0x2AD94DC", Offset = "0x2AD94DC", VA = "0x2AD94DC")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		string name = \u07FEל\u05AC\u0877.gameObject.name;
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CC0 RID: 7360 RVA: 0x00094AAC File Offset: 0x00092CAC
	[Token(Token = "0x6001CC0")]
	[Address(RVA = "0x2AD9618", Offset = "0x2AD9618", VA = "0x2AD9618")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "got funky mone";
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.\u0740\u085E\u07FF\u064B();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CC1 RID: 7361 RVA: 0x00094B34 File Offset: 0x00092D34
	[Token(Token = "0x6001CC1")]
	[Address(RVA = "0x2AD9754", Offset = "0x2AD9754", VA = "0x2AD9754")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Collided";
		this.ն\u0880و\u0654.إࡅܬՍ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Ӥܗ\u07BFӱ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CC2 RID: 7362 RVA: 0x00094BB8 File Offset: 0x00092DB8
	[Token(Token = "0x6001CC2")]
	[Address(RVA = "0x2AD988C", Offset = "0x2AD988C", VA = "0x2AD988C")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		string name = \u07FEל\u05AC\u0877.gameObject.name;
		this.ն\u0880و\u0654.ܣֆױݘ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CC3 RID: 7363 RVA: 0x00094C34 File Offset: 0x00092E34
	[Token(Token = "0x6001CC3")]
	[Address(RVA = "0x2AD99C4", Offset = "0x2AD99C4", VA = "0x2AD99C4")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "true";
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.\u060Dӫߠވ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CC4 RID: 7364 RVA: 0x00094CB8 File Offset: 0x00092EB8
	[Token(Token = "0x6001CC4")]
	[Address(RVA = "0x2AD9AFC", Offset = "0x2AD9AFC", VA = "0x2AD9AFC")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Display Name Changed!";
		this.ն\u0880و\u0654.\u05CF\u0839ݙԟ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.ӟ\u07A8\u0608ք();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ւߠݱԕ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CC5 RID: 7365 RVA: 0x00094D48 File Offset: 0x00092F48
	[Token(Token = "0x6001CC5")]
	[Address(RVA = "0x2AD9C38", Offset = "0x2AD9C38", VA = "0x2AD9C38")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "SetColor";
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
	}

	// Token: 0x06001CC6 RID: 7366 RVA: 0x00094D80 File Offset: 0x00092F80
	[Token(Token = "0x6001CC6")]
	[Address(RVA = "0x2AD9D74", Offset = "0x2AD9D74", VA = "0x2AD9D74")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Regular";
		this.ն\u0880و\u0654.\u0740\u085E\u07FF\u064B();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.\u0740\u085E\u07FF\u064B();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CC7 RID: 7367 RVA: 0x00094E04 File Offset: 0x00093004
	[Token(Token = "0x6001CC7")]
	[Address(RVA = "0x2AD9EAC", Offset = "0x2AD9EAC", VA = "0x2AD9EAC")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Removing ";
		this.ն\u0880و\u0654.\u0740\u085E\u07FF\u064B();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Ӝ\u07F1ࡁܘ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CC8 RID: 7368 RVA: 0x00094E94 File Offset: 0x00093094
	[Token(Token = "0x6001CC8")]
	[Address(RVA = "0x2AD9FE4", Offset = "0x2AD9FE4", VA = "0x2AD9FE4")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Players: ";
		this.ն\u0880و\u0654.Ӝ\u07F1ࡁܘ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Ӝ\u07F1ࡁܘ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CC9 RID: 7369 RVA: 0x00094F18 File Offset: 0x00093118
	[Token(Token = "0x6001CC9")]
	[Address(RVA = "0x2ADA11C", Offset = "0x2ADA11C", VA = "0x2ADA11C")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "username";
		this.ն\u0880و\u0654.\u0740\u085E\u07FF\u064B();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ւߠݱԕ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CCA RID: 7370 RVA: 0x00094FA8 File Offset: 0x000931A8
	[Token(Token = "0x6001CCA")]
	[Address(RVA = "0x2ADA258", Offset = "0x2ADA258", VA = "0x2ADA258")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Not connected to room";
		this.ն\u0880و\u0654.ࡈ\u06DC\u087E\u0834();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CCB RID: 7371 RVA: 0x0009502C File Offset: 0x0009322C
	[Token(Token = "0x6001CCB")]
	[Address(RVA = "0x2ADA390", Offset = "0x2ADA390", VA = "0x2ADA390")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "Players In Room: ";
		this.ն\u0880و\u0654.ܣֆױݘ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ւߠݱԕ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CCC RID: 7372 RVA: 0x000950B0 File Offset: 0x000932B0
	[Token(Token = "0x6001CCC")]
	[Address(RVA = "0x2ADA4C8", Offset = "0x2ADA4C8", VA = "0x2ADA4C8")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "User has been reported for: ";
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CCD RID: 7373 RVA: 0x00095140 File Offset: 0x00093340
	[Token(Token = "0x6001CCD")]
	[Address(RVA = "0x2ADA604", Offset = "0x2ADA604", VA = "0x2ADA604")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "gravThing";
		this.ն\u0880و\u0654.إࡅܬՍ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u05F3Ӓ۰Ԃ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
		long u07BF_u05CD۳Ӵ = 1L;
		ն_u0880و_u.\u07BF\u05CD۳Ӵ = (u07BF_u05CD۳Ӵ != 0L);
	}

	// Token: 0x06001CCE RID: 7374 RVA: 0x000951D0 File Offset: 0x000933D0
	[Token(Token = "0x6001CCE")]
	[Address(RVA = "0x2ADA740", Offset = "0x2ADA740", VA = "0x2ADA740")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "\n";
		this.ն\u0880و\u0654.ࡈ\u06DC\u087E\u0834();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.Շ\u0650ࡅڸ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CCF RID: 7375 RVA: 0x00095254 File Offset: 0x00093454
	[Token(Token = "0x6001CCF")]
	[Address(RVA = "0x2ADA878", Offset = "0x2ADA878", VA = "0x2ADA878")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "username";
		this.ն\u0880و\u0654.ܣֆױݘ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.\u083B\u0704ݪ\u087F();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = u081B_u070Aߢࡁ.position;
		this.ն\u0880و\u0654.إࡅܬՍ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x06001CD0 RID: 7376 RVA: 0x000952D0 File Offset: 0x000934D0
	[Token(Token = "0x6001CD0")]
	[Address(RVA = "0x2ADA9AC", Offset = "0x2ADA9AC", VA = "0x2ADA9AC")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.name == "NetworkPlayer";
		this.ն\u0880و\u0654.Ӝ\u07F1ࡁܘ();
		IEnumerator enumerator = Player.كݕ\u05F3\u0589.կը\u06EAہ();
		Transform ӵߎ_u088A_u = this.ӵߎ\u088A\u0824;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ӵߎ_u088A_u.position;
		Transform ӵߎ_u088A_u2 = this.ӵߎ\u088A\u0824;
		Transform u0593ևڮ߁ = this.\u0593ևڮ߁;
		Vector3 position2 = ӵߎ_u088A_u2.position;
		this.ն\u0880و\u0654.ݻޑ\u083Fգ();
		LavaManager ն_u0880و_u = this.ն\u0880و\u0654;
	}

	// Token: 0x040003B9 RID: 953
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003B9")]
	public Transform \u081B\u070Aߢࡁ;

	// Token: 0x040003BA RID: 954
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003BA")]
	public Transform \u0593ևڮ߁;

	// Token: 0x040003BB RID: 955
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003BB")]
	public Transform ӵߎ\u088A\u0824;

	// Token: 0x040003BC RID: 956
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003BC")]
	public LavaManager ն\u0880و\u0654;

	// Token: 0x040003BD RID: 957
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40003BD")]
	public PhysicsHand[] \u0878۴\u0894ԃ;

	// Token: 0x040003BE RID: 958
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40003BE")]
	public Rigidbody աߞ\u07A7ߦ;

	// Token: 0x040003BF RID: 959
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40003BF")]
	public Rigidbody ՑԀ\u0740օ;

	// Token: 0x040003C0 RID: 960
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40003C0")]
	public Rigidbody \u0741\u06E2ӳࢣ;

	// Token: 0x040003C1 RID: 961
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40003C1")]
	public Swimmy ڢݕڕ\u06E8;
}
