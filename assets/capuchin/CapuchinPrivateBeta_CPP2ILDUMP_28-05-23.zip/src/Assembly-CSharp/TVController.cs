﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E8 RID: 232
[Token(Token = "0x20000E8")]
public class TVController : MonoBehaviour
{
	// Token: 0x060023CE RID: 9166 RVA: 0x000BC54C File Offset: 0x000BA74C
	[Token(Token = "0x60023CE")]
	[Address(RVA = "0x285CFD0", Offset = "0x285CFD0", VA = "0x285CFD0")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			TVManager u0899րࡓ_u061E = this.\u0899րࡓ\u061E;
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023CF RID: 9167 RVA: 0x000BC5A4 File Offset: 0x000BA7A4
	[Token(Token = "0x60023CF")]
	[Address(RVA = "0x285D0F0", Offset = "0x285D0F0", VA = "0x285D0F0")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("containsStaff");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023D0 RID: 9168 RVA: 0x000BC604 File Offset: 0x000BA804
	[Token(Token = "0x60023D0")]
	[Address(RVA = "0x285D20C", Offset = "0x285D20C", VA = "0x285D20C")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("typesOfTalk");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023D1 RID: 9169 RVA: 0x000BC664 File Offset: 0x000BA864
	[Token(Token = "0x60023D1")]
	[Address(RVA = "0x285D32C", Offset = "0x285D32C", VA = "0x285D32C")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			TVManager u0899րࡓ_u061E = this.\u0899րࡓ\u061E;
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023D2 RID: 9170 RVA: 0x000BC6BC File Offset: 0x000BA8BC
	[Token(Token = "0x60023D2")]
	[Address(RVA = "0x285D44C", Offset = "0x285D44C", VA = "0x285D44C")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("HorrorAgreement");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023D3 RID: 9171 RVA: 0x000BC71C File Offset: 0x000BA91C
	[Token(Token = "0x60023D3")]
	[Address(RVA = "0x285D568", Offset = "0x285D568", VA = "0x285D568")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("You Already Own This Item");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023D4 RID: 9172 RVA: 0x000BC77C File Offset: 0x000BA97C
	[Token(Token = "0x60023D4")]
	[Address(RVA = "0x285D688", Offset = "0x285D688", VA = "0x285D688")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("PURCHASE");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023D5 RID: 9173 RVA: 0x000BC7DC File Offset: 0x000BA9DC
	[Token(Token = "0x60023D5")]
	[Address(RVA = "0x285D7A8", Offset = "0x285D7A8", VA = "0x285D7A8")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("StartSong");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023D6 RID: 9174 RVA: 0x000BC83C File Offset: 0x000BAA3C
	[Token(Token = "0x60023D6")]
	[Address(RVA = "0x285D8C4", Offset = "0x285D8C4", VA = "0x285D8C4")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.GetComponent<HandColliders>();
		if (typeof(UnityEngine.Object).TypeHandle != null)
		{
		}
		if ("username" != null)
		{
			return;
		}
	}

	// Token: 0x060023D7 RID: 9175 RVA: 0x000BC86C File Offset: 0x000BAA6C
	[Token(Token = "0x60023D7")]
	[Address(RVA = "0x285D9E4", Offset = "0x285D9E4", VA = "0x285D9E4")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("jump char false");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023D8 RID: 9176 RVA: 0x000BC8CC File Offset: 0x000BAACC
	[Token(Token = "0x60023D8")]
	[Address(RVA = "0x285DB04", Offset = "0x285DB04", VA = "0x285DB04")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("FingerTip");
		}
		if (this.جࢸӭ\u0731)
		{
			bool mute = this.\u0889ԫޚࠋ.mute;
			return;
		}
	}

	// Token: 0x060023D9 RID: 9177 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60023D9")]
	[Address(RVA = "0x285DC24", Offset = "0x285DC24", VA = "0x285DC24")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060023DA RID: 9178 RVA: 0x000BC920 File Offset: 0x000BAB20
	[Token(Token = "0x60023DA")]
	[Address(RVA = "0x285DD40", Offset = "0x285DD40", VA = "0x285DD40")]
	public TVController()
	{
	}

	// Token: 0x060023DB RID: 9179 RVA: 0x000BC934 File Offset: 0x000BAB34
	[Token(Token = "0x60023DB")]
	[Address(RVA = "0x285DD48", Offset = "0x285DD48", VA = "0x285DD48")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("Did Hit");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023DC RID: 9180 RVA: 0x000BC994 File Offset: 0x000BAB94
	[Token(Token = "0x60023DC")]
	[Address(RVA = "0x285DE68", Offset = "0x285DE68", VA = "0x285DE68")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("Player");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023DD RID: 9181 RVA: 0x000BC9F4 File Offset: 0x000BABF4
	[Token(Token = "0x60023DD")]
	[Address(RVA = "0x285DF88", Offset = "0x285DF88", VA = "0x285DF88")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x060023DE RID: 9182 RVA: 0x000BCA58 File Offset: 0x000BAC58
	[Token(Token = "0x60023DE")]
	[Address(RVA = "0x285E0A8", Offset = "0x285E0A8", VA = "0x285E0A8")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("You are not the master of the server, you cannot start the game.");
		}
		if (this.جࢸӭ\u0731)
		{
			bool mute = this.\u0889ԫޚࠋ.mute;
			return;
		}
	}

	// Token: 0x060023DF RID: 9183 RVA: 0x000BCAAC File Offset: 0x000BACAC
	[Token(Token = "0x60023DF")]
	[Address(RVA = "0x285E1C4", Offset = "0x285E1C4", VA = "0x285E1C4")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023E0 RID: 9184 RVA: 0x000BCAFC File Offset: 0x000BACFC
	[Token(Token = "0x60023E0")]
	[Address(RVA = "0x285E2E4", Offset = "0x285E2E4", VA = "0x285E2E4")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("׺ٻܚٔ");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023E1 RID: 9185 RVA: 0x000BCB5C File Offset: 0x000BAD5C
	[Token(Token = "0x60023E1")]
	[Address(RVA = "0x285E404", Offset = "0x285E404", VA = "0x285E404")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("On");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023E2 RID: 9186 RVA: 0x000BCBB8 File Offset: 0x000BADB8
	[Token(Token = "0x60023E2")]
	[Address(RVA = "0x285E520", Offset = "0x285E520", VA = "0x285E520")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("HandL");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023E3 RID: 9187 RVA: 0x000BCC18 File Offset: 0x000BAE18
	[Token(Token = "0x60023E3")]
	[Address(RVA = "0x285E640", Offset = "0x285E640", VA = "0x285E640")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("isLava");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023E4 RID: 9188 RVA: 0x000BCC78 File Offset: 0x000BAE78
	[Token(Token = "0x60023E4")]
	[Address(RVA = "0x285E760", Offset = "0x285E760", VA = "0x285E760")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			Coroutine coroutine = this.\u0899րࡓ\u061E.StartCoroutine("Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023E5 RID: 9189 RVA: 0x000BCCD8 File Offset: 0x000BAED8
	[Token(Token = "0x60023E5")]
	[Address(RVA = "0x285E880", Offset = "0x285E880", VA = "0x285E880")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			TVManager u0899րࡓ_u061E = this.\u0899րࡓ\u061E;
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060023E6 RID: 9190 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60023E6")]
	[Address(RVA = "0x285E99C", Offset = "0x285E99C", VA = "0x285E99C")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060023E7 RID: 9191 RVA: 0x000BCD30 File Offset: 0x000BAF30
	[Token(Token = "0x60023E7")]
	[Address(RVA = "0x285EABC", Offset = "0x285EABC", VA = "0x285EABC")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u0730ࢯݽټ)
		{
			TVManager u0899րࡓ_u061E = this.\u0899րࡓ\u061E;
		}
		if (this.جࢸӭ\u0731)
		{
			AudioSource u0889ԫޚࠋ = this.\u0889ԫޚࠋ;
			long mute = 0L;
			bool mute2 = u0889ԫޚࠋ.mute;
			u0889ԫޚࠋ.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x0400047C RID: 1148
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400047C")]
	public bool \u0730ࢯݽټ;

	// Token: 0x0400047D RID: 1149
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x400047D")]
	public bool جࢸӭ\u0731;

	// Token: 0x0400047E RID: 1150
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400047E")]
	public AudioSource \u0889ԫޚࠋ;

	// Token: 0x0400047F RID: 1151
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400047F")]
	public TVManager \u0899րࡓ\u061E;
}
