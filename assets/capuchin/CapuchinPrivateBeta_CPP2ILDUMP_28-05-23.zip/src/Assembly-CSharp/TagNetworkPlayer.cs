﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000EB RID: 235
[Token(Token = "0x20000EB")]
public class TagNetworkPlayer : MonoBehaviour
{
	// Token: 0x06002441 RID: 9281 RVA: 0x000BE768 File Offset: 0x000BC968
	[Token(Token = "0x6002441")]
	[Address(RVA = "0x286A51C", Offset = "0x286A51C", VA = "0x286A51C")]
	public void Ӣ\u0592ߨׯ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
	}

	// Token: 0x06002442 RID: 9282 RVA: 0x000BE7A8 File Offset: 0x000BC9A8
	[Token(Token = "0x6002442")]
	[Address(RVA = "0x286A5CC", Offset = "0x286A5CC", VA = "0x286A5CC")]
	public void \u0599ږࠆ\u065F()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		if (this.ӿٱډ\u0749 == null)
		{
			return;
		}
	}

	// Token: 0x06002443 RID: 9283 RVA: 0x000BE7E0 File Offset: 0x000BC9E0
	[Token(Token = "0x6002443")]
	[Address(RVA = "0x286A64C", Offset = "0x286A64C", VA = "0x286A64C")]
	public void ԣԭՋࠏ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x06002444 RID: 9284 RVA: 0x000BE820 File Offset: 0x000BCA20
	[Token(Token = "0x6002444")]
	[Address(RVA = "0x286A718", Offset = "0x286A718", VA = "0x286A718")]
	public void ժ\u065Dԯࡘ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x06002445 RID: 9285 RVA: 0x000BE860 File Offset: 0x000BCA60
	[Token(Token = "0x6002445")]
	[Address(RVA = "0x286A7C8", Offset = "0x286A7C8", VA = "0x286A7C8")]
	public void ࢫ\u0876չՍ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x06002446 RID: 9286 RVA: 0x000BE8A0 File Offset: 0x000BCAA0
	[Token(Token = "0x6002446")]
	[Address(RVA = "0x286A878", Offset = "0x286A878", VA = "0x286A878")]
	public void \u0654ޛ\u07FAذ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		if (this.ӿٱډ\u0749 == null)
		{
			return;
		}
	}

	// Token: 0x06002447 RID: 9287 RVA: 0x000BE8D8 File Offset: 0x000BCAD8
	[Token(Token = "0x6002447")]
	[Address(RVA = "0x286A8F8", Offset = "0x286A8F8", VA = "0x286A8F8")]
	public void \u0886Ҽ\u058Dߛ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		if (this.ӿٱډ\u0749 == null)
		{
			return;
		}
	}

	// Token: 0x06002448 RID: 9288 RVA: 0x000BE910 File Offset: 0x000BCB10
	[Token(Token = "0x6002448")]
	[Address(RVA = "0x286A978", Offset = "0x286A978", VA = "0x286A978")]
	public void ܣ\u086E\u05CF\u06D8()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
	}

	// Token: 0x06002449 RID: 9289 RVA: 0x000BE950 File Offset: 0x000BCB50
	[Token(Token = "0x6002449")]
	[Address(RVA = "0x286AA28", Offset = "0x286AA28", VA = "0x286AA28")]
	public void \u0838ӆڛӑ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x0600244A RID: 9290 RVA: 0x000BE990 File Offset: 0x000BCB90
	[Token(Token = "0x600244A")]
	[Address(RVA = "0x286AAD8", Offset = "0x286AAD8", VA = "0x286AAD8")]
	public void ւࡂ\u0883\u0872()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x0600244B RID: 9291 RVA: 0x000BE9D0 File Offset: 0x000BCBD0
	[Token(Token = "0x600244B")]
	[Address(RVA = "0x286ABA4", Offset = "0x286ABA4", VA = "0x286ABA4")]
	public void Ҿࢹؼס()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x0600244C RID: 9292 RVA: 0x000BEA10 File Offset: 0x000BCC10
	[Token(Token = "0x600244C")]
	[Address(RVA = "0x286AC54", Offset = "0x286AC54", VA = "0x286AC54")]
	public void ژךՈ\u0597()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x0600244D RID: 9293 RVA: 0x000BEA50 File Offset: 0x000BCC50
	[Token(Token = "0x600244D")]
	[Address(RVA = "0x286AD20", Offset = "0x286AD20", VA = "0x286AD20")]
	public void \u0881ݗӟ\u07BD()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x0600244E RID: 9294 RVA: 0x000BEA90 File Offset: 0x000BCC90
	[Token(Token = "0x600244E")]
	[Address(RVA = "0x286ADD0", Offset = "0x286ADD0", VA = "0x286ADD0")]
	public void \u05F7ԝߠӱ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x0600244F RID: 9295 RVA: 0x000BEAD0 File Offset: 0x000BCCD0
	[Token(Token = "0x600244F")]
	[Address(RVA = "0x286AE9C", Offset = "0x286AE9C", VA = "0x286AE9C")]
	public void Update()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x06002450 RID: 9296 RVA: 0x000BEB10 File Offset: 0x000BCD10
	[Token(Token = "0x6002450")]
	[Address(RVA = "0x286AF68", Offset = "0x286AF68", VA = "0x286AF68")]
	public void \u070Aәޣے()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x06002451 RID: 9297 RVA: 0x000BEB4C File Offset: 0x000BCD4C
	[Token(Token = "0x6002451")]
	[Address(RVA = "0x286B034", Offset = "0x286B034", VA = "0x286B034")]
	public void ڃրӢԖ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x06002452 RID: 9298 RVA: 0x000BEB8C File Offset: 0x000BCD8C
	[Token(Token = "0x6002452")]
	[Address(RVA = "0x286B100", Offset = "0x286B100", VA = "0x286B100")]
	public void \u087BӦןݩ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x06002453 RID: 9299 RVA: 0x000BEBCC File Offset: 0x000BCDCC
	[Token(Token = "0x6002453")]
	[Address(RVA = "0x286B1B0", Offset = "0x286B1B0", VA = "0x286B1B0")]
	public void \u05EDց\u081Cت()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x06002454 RID: 9300 RVA: 0x000BEC0C File Offset: 0x000BCE0C
	[Token(Token = "0x6002454")]
	[Address(RVA = "0x286B27C", Offset = "0x286B27C", VA = "0x286B27C")]
	public void צ\u0874ڵ\u059A()
	{
		if (this.\u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x06002455 RID: 9301 RVA: 0x000BEC40 File Offset: 0x000BCE40
	[Token(Token = "0x6002455")]
	[Address(RVA = "0x286B348", Offset = "0x286B348", VA = "0x286B348")]
	public TagNetworkPlayer()
	{
	}

	// Token: 0x06002456 RID: 9302 RVA: 0x000BEC54 File Offset: 0x000BCE54
	[Token(Token = "0x6002456")]
	[Address(RVA = "0x286B350", Offset = "0x286B350", VA = "0x286B350")]
	public void ڑߒجވ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		if (this.ӿٱډ\u0749 == null)
		{
			return;
		}
	}

	// Token: 0x06002457 RID: 9303 RVA: 0x000BEC8C File Offset: 0x000BCE8C
	[Token(Token = "0x6002457")]
	[Address(RVA = "0x286B3D0", Offset = "0x286B3D0", VA = "0x286B3D0")]
	public void \u061B\u05EEوۈ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
	}

	// Token: 0x06002458 RID: 9304 RVA: 0x000BECCC File Offset: 0x000BCECC
	[Token(Token = "0x6002458")]
	[Address(RVA = "0x286B480", Offset = "0x286B480", VA = "0x286B480")]
	public void ފՖߢ\u059B()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		if (this.ӿٱډ\u0749 == null)
		{
			return;
		}
	}

	// Token: 0x06002459 RID: 9305 RVA: 0x000BED04 File Offset: 0x000BCF04
	[Token(Token = "0x6002459")]
	[Address(RVA = "0x286B500", Offset = "0x286B500", VA = "0x286B500")]
	public void Ҽ\u08B5ځ\u0658()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x0600245A RID: 9306 RVA: 0x000BED44 File Offset: 0x000BCF44
	[Token(Token = "0x600245A")]
	[Address(RVA = "0x286B5CC", Offset = "0x286B5CC", VA = "0x286B5CC")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x0600245B RID: 9307 RVA: 0x000BED84 File Offset: 0x000BCF84
	[Token(Token = "0x600245B")]
	[Address(RVA = "0x286B698", Offset = "0x286B698", VA = "0x286B698")]
	public void ԟ\u086Cޣ\u055E()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x0600245C RID: 9308 RVA: 0x000BEDC4 File Offset: 0x000BCFC4
	[Token(Token = "0x600245C")]
	[Address(RVA = "0x286B748", Offset = "0x286B748", VA = "0x286B748")]
	public void \u061Fࡆ\u086F\u07B0()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x0600245D RID: 9309 RVA: 0x000BEE04 File Offset: 0x000BD004
	[Token(Token = "0x600245D")]
	[Address(RVA = "0x286B7F8", Offset = "0x286B7F8", VA = "0x286B7F8")]
	public void څࡣڐ\u0657()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x0600245E RID: 9310 RVA: 0x000BEE44 File Offset: 0x000BD044
	[Token(Token = "0x600245E")]
	[Address(RVA = "0x286B8A8", Offset = "0x286B8A8", VA = "0x286B8A8")]
	public void \u0732ڙԒࢺ()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		if (this.ӿٱډ\u0749 == null)
		{
			return;
		}
	}

	// Token: 0x0600245F RID: 9311 RVA: 0x000BEE7C File Offset: 0x000BD07C
	[Token(Token = "0x600245F")]
	[Address(RVA = "0x286B928", Offset = "0x286B928", VA = "0x286B928")]
	public void ٴݵۃ\u05AF()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
	}

	// Token: 0x06002460 RID: 9312 RVA: 0x000BEEBC File Offset: 0x000BD0BC
	[Token(Token = "0x6002460")]
	[Address(RVA = "0x286B9D8", Offset = "0x286B9D8", VA = "0x286B9D8")]
	public void ں٢ࡡ\u05EC()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x06002461 RID: 9313 RVA: 0x000BEEFC File Offset: 0x000BD0FC
	[Token(Token = "0x6002461")]
	[Address(RVA = "0x286BAA4", Offset = "0x286BAA4", VA = "0x286BAA4")]
	public void \u0614ࢥӴ\u086C()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x06002462 RID: 9314 RVA: 0x000BEF3C File Offset: 0x000BD13C
	[Token(Token = "0x6002462")]
	[Address(RVA = "0x286BB54", Offset = "0x286BB54", VA = "0x286BB54")]
	public void ӻӒݝ߃()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (u05ACڎࡗخ)
		{
			Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
			return;
		}
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
	}

	// Token: 0x06002463 RID: 9315 RVA: 0x000BEF7C File Offset: 0x000BD17C
	[Token(Token = "0x6002463")]
	[Address(RVA = "0x286BC20", Offset = "0x286BC20", VA = "0x286BC20")]
	public void \u07FE\u0882Զ\u066D()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x06002464 RID: 9316 RVA: 0x000BEFBC File Offset: 0x000BD1BC
	[Token(Token = "0x6002464")]
	[Address(RVA = "0x286BCD0", Offset = "0x286BCD0", VA = "0x286BCD0")]
	public void \u0821\u059Fӕ\u0607()
	{
		bool u05ACڎࡗخ = this.\u05ACڎࡗخ;
		Renderer[] ӿٱډ_u = this.ӿٱډ\u0749;
		if (!u05ACڎࡗخ)
		{
			Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
			return;
		}
		if (ӿٱډ_u == null)
		{
			return;
		}
	}

	// Token: 0x0400048B RID: 1163
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400048B")]
	public Renderer[] ӿٱډ\u0749;

	// Token: 0x0400048C RID: 1164
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400048C")]
	public bool \u05ACڎࡗخ;

	// Token: 0x0400048D RID: 1165
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400048D")]
	public Material ل\u0826\u0703\u055E;

	// Token: 0x0400048E RID: 1166
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400048E")]
	public Material ٹ\u070BՇӽ;
}
