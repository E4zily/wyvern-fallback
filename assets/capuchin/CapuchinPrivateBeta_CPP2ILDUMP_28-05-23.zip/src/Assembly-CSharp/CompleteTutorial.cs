﻿using System;
using CapuchinPlayFab;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000025 RID: 37
[Token(Token = "0x2000025")]
public class CompleteTutorial : MonoBehaviour
{
	// Token: 0x0600043A RID: 1082 RVA: 0x0001877C File Offset: 0x0001697C
	[Token(Token = "0x600043A")]
	[Address(RVA = "0x29320C0", Offset = "0x29320C0", VA = "0x29320C0")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "button";
		if (PlayerPrefs.GetString("BLUTARG") != null)
		{
			return;
		}
		PlayerPrefs.SetString("FLSPTLT", "Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
	}

	// Token: 0x0600043B RID: 1083 RVA: 0x000187C4 File Offset: 0x000169C4
	[Token(Token = "0x600043B")]
	[Address(RVA = "0x2932198", Offset = "0x2932198", VA = "0x2932198")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Bare Torso";
		string @string = PlayerPrefs.GetString("username");
		if (@string != null)
		{
			return;
		}
		PlayerPrefs.SetString(@string, "Damaged Arm");
	}

	// Token: 0x0600043C RID: 1084 RVA: 0x00018808 File Offset: 0x00016A08
	[Token(Token = "0x600043C")]
	[Address(RVA = "0x2932270", Offset = "0x2932270", VA = "0x2932270")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		if (PlayerPrefs.GetString("tutorialCheck") != null)
		{
			return;
		}
		PlayerPrefs.SetString("tutorialCheck", "true");
	}

	// Token: 0x0600043D RID: 1085 RVA: 0x00018850 File Offset: 0x00016A50
	[Token(Token = "0x600043D")]
	[Address(RVA = "0x2932334", Offset = "0x2932334", VA = "0x2932334")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Players In Room: ";
		if (PlayerPrefs.GetString("MetaId") != null)
		{
			return;
		}
		PlayerPrefs.SetString("amongus", "Connected to Server.");
	}

	// Token: 0x0600043E RID: 1086 RVA: 0x00018898 File Offset: 0x00016A98
	[Token(Token = "0x600043E")]
	[Address(RVA = "0x293240C", Offset = "0x293240C", VA = "0x293240C")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_WobbleZ";
		if (PlayerPrefs.GetString("Add/Remove Sword") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Player", "_Tint");
	}

	// Token: 0x0600043F RID: 1087 RVA: 0x000188E0 File Offset: 0x00016AE0
	[Token(Token = "0x600043F")]
	[Address(RVA = "0x29324E4", Offset = "0x29324E4", VA = "0x29324E4")]
	public CompleteTutorial()
	{
	}

	// Token: 0x06000440 RID: 1088 RVA: 0x000188F4 File Offset: 0x00016AF4
	[Token(Token = "0x6000440")]
	[Address(RVA = "0x29324EC", Offset = "0x29324EC", VA = "0x29324EC")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "On";
		if (PlayerPrefs.GetString("CapuchinStore") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Open", "Completed baking textures on frame ");
	}

	// Token: 0x06000441 RID: 1089 RVA: 0x0001893C File Offset: 0x00016B3C
	[Token(Token = "0x6000441")]
	[Address(RVA = "0x29325C4", Offset = "0x29325C4", VA = "0x29325C4")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Charging...";
		if (PlayerPrefs.GetString("typesOfTalk") != null)
		{
			return;
		}
		PlayerPrefs.SetString("monke is not my monke", "Player");
	}

	// Token: 0x06000442 RID: 1090 RVA: 0x00018984 File Offset: 0x00016B84
	[Token(Token = "0x6000442")]
	[Address(RVA = "0x293269C", Offset = "0x293269C", VA = "0x293269C")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		if (PlayerPrefs.GetString("\tExpires: ") != null)
		{
			return;
		}
		PlayerPrefs.SetString("DisableCosmetic", "ErrorScreen");
	}

	// Token: 0x06000443 RID: 1091 RVA: 0x000189CC File Offset: 0x00016BCC
	[Token(Token = "0x6000443")]
	[Address(RVA = "0x2932774", Offset = "0x2932774", VA = "0x2932774")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		if (PlayerPrefs.GetString(". Please update you game to the latest version") != null)
		{
			return;
		}
		PlayerPrefs.SetString("monkeScream", "FingerTip");
	}

	// Token: 0x06000444 RID: 1092 RVA: 0x00018A14 File Offset: 0x00016C14
	[Token(Token = "0x6000444")]
	[Address(RVA = "0x293284C", Offset = "0x293284C", VA = "0x293284C")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Joined Public Room Successfully";
		if (PlayerPrefs.GetString("Completed baking textures on frame ") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Player", "Player");
	}

	// Token: 0x06000445 RID: 1093 RVA: 0x00018A5C File Offset: 0x00016C5C
	[Token(Token = "0x6000445")]
	[Address(RVA = "0x2932910", Offset = "0x2932910", VA = "0x2932910")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Tagged";
		if (PlayerPrefs.GetString("PushToTalk") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Player", "ORGTARG");
	}

	// Token: 0x06000446 RID: 1094 RVA: 0x00018AA4 File Offset: 0x00016CA4
	[Token(Token = "0x6000446")]
	[Address(RVA = "0x29329E8", Offset = "0x29329E8", VA = "0x29329E8")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "closeToObject";
		if (PlayerPrefs.GetString("This is the 5000 Bananas button, and it was just clicked") != null)
		{
			return;
		}
		PlayerPrefs.SetString("This is the 5000 Bananas button, and it was just clicked", "Thumb");
	}

	// Token: 0x06000447 RID: 1095 RVA: 0x00018AEC File Offset: 0x00016CEC
	[Token(Token = "0x6000447")]
	[Address(RVA = "0x2932AC0", Offset = "0x2932AC0", VA = "0x2932AC0")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		if (PlayerPrefs.GetString("Faild To Add Winner Money: ") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Time to bake textures: ", "Player");
	}

	// Token: 0x06000448 RID: 1096 RVA: 0x00018B34 File Offset: 0x00016D34
	[Token(Token = "0x6000448")]
	[Address(RVA = "0x2932B98", Offset = "0x2932B98", VA = "0x2932B98")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Is Colliding";
		if (PlayerPrefs.GetString("Player") != null)
		{
			return;
		}
		PlayerPrefs.SetString("NormalWeather", "Connected to Server.");
	}

	// Token: 0x06000449 RID: 1097 RVA: 0x00018B7C File Offset: 0x00016D7C
	[Token(Token = "0x6000449")]
	[Address(RVA = "0x2932C70", Offset = "0x2932C70", VA = "0x2932C70")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		if (PlayerPrefs.GetString("\n") != null)
		{
			return;
		}
		PlayerPrefs.SetString("hh:mmtt", "Try Connect To Server...");
	}

	// Token: 0x0600044A RID: 1098 RVA: 0x00018BC4 File Offset: 0x00016DC4
	[Token(Token = "0x600044A")]
	[Address(RVA = "0x2932D48", Offset = "0x2932D48", VA = "0x2932D48")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		if (PlayerPrefs.GetString("MetaId") != null)
		{
			return;
		}
		PlayerPrefs.SetString("M/d/yyyy", "BN");
	}

	// Token: 0x0600044B RID: 1099 RVA: 0x00018C00 File Offset: 0x00016E00
	[Token(Token = "0x600044B")]
	[Address(RVA = "0x2932E20", Offset = "0x2932E20", VA = "0x2932E20")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		if (PlayerPrefs.GetString("_Tint") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Name Changing Error. Error: ", "Vector1_d371bd24217449349bd747533d51af6b");
	}

	// Token: 0x0600044C RID: 1100 RVA: 0x00018C48 File Offset: 0x00016E48
	[Token(Token = "0x600044C")]
	[Address(RVA = "0x2932EF8", Offset = "0x2932EF8", VA = "0x2932EF8")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		if (PlayerPrefs.GetString("TurnAmount") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Failed to login, please restart", "username");
	}

	// Token: 0x0600044D RID: 1101 RVA: 0x00018C90 File Offset: 0x00016E90
	[Token(Token = "0x600044D")]
	[Address(RVA = "0x2932FD0", Offset = "0x2932FD0", VA = "0x2932FD0")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "NetworkPlayer";
		if (PlayerPrefs.GetString("ChangeToTagged") != null)
		{
			return;
		}
		PlayerPrefs.SetString("isLava", "Not connected to room");
	}

	// Token: 0x0600044E RID: 1102 RVA: 0x00018CD8 File Offset: 0x00016ED8
	[Token(Token = "0x600044E")]
	[Address(RVA = "0x29330A8", Offset = "0x29330A8", VA = "0x29330A8")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ScoreCounter";
		if (PlayerPrefs.GetString("username") != null)
		{
			return;
		}
		PlayerPrefs.SetString("This is the 1000 Bananas button, and it was just clicked", "Collided");
	}

	// Token: 0x0600044F RID: 1103 RVA: 0x00018D20 File Offset: 0x00016F20
	[Token(Token = "0x600044F")]
	[Address(RVA = "0x2933180", Offset = "0x2933180", VA = "0x2933180")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "friend";
		if (PlayerPrefs.GetString("User has been reported for: ") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Update User Inventory", "");
	}

	// Token: 0x06000450 RID: 1104 RVA: 0x00018D68 File Offset: 0x00016F68
	[Token(Token = "0x6000450")]
	[Address(RVA = "0x2933258", Offset = "0x2933258", VA = "0x2933258")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Body";
		if (PlayerPrefs.GetString("Tagged") != null)
		{
			return;
		}
		PlayerPrefs.SetString("EnableCosmetic", "TurnAmount");
	}

	// Token: 0x06000451 RID: 1105 RVA: 0x00018DB0 File Offset: 0x00016FB0
	[Token(Token = "0x6000451")]
	[Address(RVA = "0x2933330", Offset = "0x2933330", VA = "0x2933330")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You are not the master of the server, you cannot start the game.";
		if (PlayerPrefs.GetString("You are not the master of the server, you cannot start the game.") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Right Hand", "Tagged");
	}

	// Token: 0x06000452 RID: 1106 RVA: 0x00018DF8 File Offset: 0x00016FF8
	[Token(Token = "0x6000452")]
	[Address(RVA = "0x29333F4", Offset = "0x29333F4", VA = "0x29333F4")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "goDownRPC";
		if (PlayerPrefs.GetString("META") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Player", "waited for your bullshit unity grrr");
	}

	// Token: 0x06000453 RID: 1107 RVA: 0x00018E38 File Offset: 0x00017038
	[Token(Token = "0x6000453")]
	[Address(RVA = "0x29334CC", Offset = "0x29334CC", VA = "0x29334CC")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "INSIGNIFICANT CURRENCY";
		if (PlayerPrefs.GetString("username") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Completed baking textures on frame ", "PRESS AGAIN TO CONFIRM");
	}

	// Token: 0x040000B8 RID: 184
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000B8")]
	public LoginManager ڐۊࠔ\u0651;
}
