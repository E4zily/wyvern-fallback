﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Ilumisoft.RadarSystem.Demo
{
	// Token: 0x02000113 RID: 275
	[Token(Token = "0x2000113")]
	public class DemoCharacterController : MonoBehaviour
	{
		// Token: 0x06002A70 RID: 10864 RVA: 0x00101D70 File Offset: 0x000FFF70
		[Token(Token = "0x6002A70")]
		[Address(RVA = "0x28A27C4", Offset = "0x28A27C4", VA = "0x28A27C4")]
		private CharacterController ӿ\u05BC\u06D6ࢠ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A71 RID: 10865 RVA: 0x00101D84 File Offset: 0x000FFF84
		[Token(Token = "0x6002A71")]
		[Address(RVA = "0x28A27CC", Offset = "0x28A27CC", VA = "0x28A27CC")]
		private CharacterController \u070F\u065Aک\u07ED()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A72 RID: 10866 RVA: 0x00101D98 File Offset: 0x000FFF98
		[Token(Token = "0x6002A72")]
		[Address(RVA = "0x28A27D4", Offset = "0x28A27D4", VA = "0x28A27D4")]
		private void ԔޕںԻ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A73 RID: 10867 RVA: 0x00101DAC File Offset: 0x000FFFAC
		[Token(Token = "0x6002A73")]
		[Address(RVA = "0x28A27DC", Offset = "0x28A27DC", VA = "0x28A27DC")]
		private void \u0605ߕڝ\u0736()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A74 RID: 10868 RVA: 0x00101DC8 File Offset: 0x000FFFC8
		[Token(Token = "0x6002A74")]
		[Address(RVA = "0x28A2838", Offset = "0x28A2838", VA = "0x28A2838")]
		private void קӭן\u085C()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A75 RID: 10869 RVA: 0x00101DE4 File Offset: 0x000FFFE4
		[Token(Token = "0x6002A75")]
		[Address(RVA = "0x28A2894", Offset = "0x28A2894", VA = "0x28A2894")]
		private CharacterController ձݨߜ\u055B()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A76 RID: 10870 RVA: 0x00101DF8 File Offset: 0x000FFFF8
		[Token(Token = "0x6002A76")]
		[Address(RVA = "0x28A289C", Offset = "0x28A289C", VA = "0x28A289C")]
		private void ӑՎ\u07B3پ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A77 RID: 10871 RVA: 0x00101E0C File Offset: 0x0010000C
		[Token(Token = "0x6002A77")]
		[Address(RVA = "0x28A28A4", Offset = "0x28A28A4", VA = "0x28A28A4")]
		private void կӜӿڗ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A78 RID: 10872 RVA: 0x00101E28 File Offset: 0x00100028
		[Token(Token = "0x6002A78")]
		[Address(RVA = "0x28A2900", Offset = "0x28A2900", VA = "0x28A2900")]
		private CharacterController ӫࢡ٢ڝ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A79 RID: 10873 RVA: 0x00101E3C File Offset: 0x0010003C
		[Token(Token = "0x6002A79")]
		[Address(RVA = "0x28A2908", Offset = "0x28A2908", VA = "0x28A2908")]
		private void կڦԌ\u0871()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A7A RID: 10874 RVA: 0x00101E58 File Offset: 0x00100058
		[Token(Token = "0x6002A7A")]
		[Address(RVA = "0x28A2964", Offset = "0x28A2964", VA = "0x28A2964")]
		private void \u0835ٷڋߏ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A7B RID: 10875 RVA: 0x00101E74 File Offset: 0x00100074
		[Token(Token = "0x6002A7B")]
		[Address(RVA = "0x28A29C0", Offset = "0x28A29C0", VA = "0x28A29C0")]
		private void Ռ\u06EA\u05AFࡇ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A7C RID: 10876 RVA: 0x00101E90 File Offset: 0x00100090
		[Token(Token = "0x6002A7C")]
		[Address(RVA = "0x28A2A1C", Offset = "0x28A2A1C", VA = "0x28A2A1C")]
		private void \u0748\u0895\u085Aێ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A7D RID: 10877 RVA: 0x00101EA4 File Offset: 0x001000A4
		[Token(Token = "0x6002A7D")]
		[Address(RVA = "0x28A2A24", Offset = "0x28A2A24", VA = "0x28A2A24")]
		private void \u087Aצڊۀ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A7E RID: 10878 RVA: 0x00101EB8 File Offset: 0x001000B8
		[Token(Token = "0x6002A7E")]
		[Address(RVA = "0x28A2A2C", Offset = "0x28A2A2C", VA = "0x28A2A2C")]
		private void ډӁ\u05B9\u05BD()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A7F RID: 10879 RVA: 0x00101ED4 File Offset: 0x001000D4
		[Token(Token = "0x6002A7F")]
		[Address(RVA = "0x28A2A88", Offset = "0x28A2A88", VA = "0x28A2A88")]
		private void \u05CAҿӸӺ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A80 RID: 10880 RVA: 0x00101EE8 File Offset: 0x001000E8
		[Token(Token = "0x6002A80")]
		[Address(RVA = "0x28A2A90", Offset = "0x28A2A90", VA = "0x28A2A90")]
		private void ࢴ\u087A\u07B9ࢢ()
		{
			float axisRaw = Input.GetAxisRaw("PlayNoise");
			float axisRaw2 = Input.GetAxisRaw("Failed To Join Public Room Successfully. The error is: ");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002A81 RID: 10881 RVA: 0x00101F5C File Offset: 0x0010015C
		[Token(Token = "0x6002A81")]
		[Address(RVA = "0x28A2BE8", Offset = "0x28A2BE8", VA = "0x28A2BE8")]
		public DemoCharacterController()
		{
		}

		// Token: 0x06002A82 RID: 10882 RVA: 0x00101F70 File Offset: 0x00100170
		[Token(Token = "0x6002A82")]
		[Address(RVA = "0x28A2BFC", Offset = "0x28A2BFC", VA = "0x28A2BFC")]
		private void \u0601ՇԮӳ()
		{
			CharacterController <աࡅٽ_u06DA>k__BackingField;
			this.<աࡅٽ\u06DA>k__BackingField = <աࡅٽ_u06DA>k__BackingField;
		}

		// Token: 0x06002A83 RID: 10883 RVA: 0x00101F84 File Offset: 0x00100184
		[Token(Token = "0x6002A83")]
		[Address(RVA = "0x28A2C58", Offset = "0x28A2C58", VA = "0x28A2C58")]
		private void \u05F7ԝߠӱ()
		{
			float axisRaw = Input.GetAxisRaw("back");
			float axisRaw2 = Input.GetAxisRaw("Player");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002A84 RID: 10884 RVA: 0x00101FF8 File Offset: 0x001001F8
		[Token(Token = "0x6002A84")]
		[Address(RVA = "0x28A2DB0", Offset = "0x28A2DB0", VA = "0x28A2DB0")]
		private void \u05AC\u07F0\u07EEࡥ()
		{
			float axisRaw = Input.GetAxisRaw("DISABLE");
			float axisRaw2 = Input.GetAxisRaw("PlayerDeath");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002A85 RID: 10885 RVA: 0x0010206C File Offset: 0x0010026C
		[Token(Token = "0x6002A85")]
		[Address(RVA = "0x28A2F08", Offset = "0x28A2F08", VA = "0x28A2F08")]
		private void \u05BA\u087AܘҾ()
		{
			float axisRaw = Input.GetAxisRaw("Player");
			float axisRaw2 = Input.GetAxisRaw("Song Index: ");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002A86 RID: 10886 RVA: 0x001020E0 File Offset: 0x001002E0
		[Token(Token = "0x6002A86")]
		[Address(RVA = "0x28A3060", Offset = "0x28A3060", VA = "0x28A3060")]
		private CharacterController Ժࢣ\u07AAע()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A87 RID: 10887 RVA: 0x001020F4 File Offset: 0x001002F4
		[Token(Token = "0x6002A87")]
		[Address(RVA = "0x28A3068", Offset = "0x28A3068", VA = "0x28A3068")]
		private void քӆ٨ڰ()
		{
			float axisRaw = Input.GetAxisRaw("Game Started");
			float axisRaw2 = Input.GetAxisRaw("TurnAmount");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002A88 RID: 10888 RVA: 0x00102168 File Offset: 0x00100368
		[Token(Token = "0x6002A88")]
		[Address(RVA = "0x28A31C0", Offset = "0x28A31C0", VA = "0x28A31C0")]
		private CharacterController ڮࡖݑࢳ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A89 RID: 10889 RVA: 0x0010217C File Offset: 0x0010037C
		[Token(Token = "0x6002A89")]
		[Address(RVA = "0x28A31C8", Offset = "0x28A31C8", VA = "0x28A31C8")]
		private void ݽࡤڼٷ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A8A RID: 10890 RVA: 0x00102190 File Offset: 0x00100390
		[Token(Token = "0x6002A8A")]
		[Address(RVA = "0x28A31D0", Offset = "0x28A31D0", VA = "0x28A31D0")]
		private CharacterController \u06D9\u0838\u0894\u07B6()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A8B RID: 10891 RVA: 0x001021A4 File Offset: 0x001003A4
		[Token(Token = "0x6002A8B")]
		[Address(RVA = "0x28A31D8", Offset = "0x28A31D8", VA = "0x28A31D8")]
		private void ࡎ\u0891خހ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A8C RID: 10892 RVA: 0x001021B8 File Offset: 0x001003B8
		[Token(Token = "0x6002A8C")]
		[Address(RVA = "0x28A31E0", Offset = "0x28A31E0", VA = "0x28A31E0")]
		private void \u061B\u0876\u0530\u058D(CharacterController \u05FB\u05AB\u0739ڑ)
		{
		}

		// Token: 0x06002A8D RID: 10893 RVA: 0x001021C8 File Offset: 0x001003C8
		[Token(Token = "0x6002A8D")]
		[Address(RVA = "0x28A31E8", Offset = "0x28A31E8", VA = "0x28A31E8")]
		private void \u058Dת\u07ECԸ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A8E RID: 10894 RVA: 0x001021DC File Offset: 0x001003DC
		[Token(Token = "0x6002A8E")]
		[Address(RVA = "0x28A31F0", Offset = "0x28A31F0", VA = "0x28A31F0")]
		private CharacterController \u061F\u0611\u05EE\u0732()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A8F RID: 10895 RVA: 0x001021F0 File Offset: 0x001003F0
		[Token(Token = "0x6002A8F")]
		[Address(RVA = "0x28A31F8", Offset = "0x28A31F8", VA = "0x28A31F8")]
		private void ߒ\u05ABەࢩ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A90 RID: 10896 RVA: 0x00102204 File Offset: 0x00100404
		[Token(Token = "0x6002A90")]
		[Address(RVA = "0x28A3200", Offset = "0x28A3200", VA = "0x28A3200")]
		private CharacterController \u06ECӪ\u0602\u083B()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A91 RID: 10897 RVA: 0x00102218 File Offset: 0x00100418
		[Token(Token = "0x6002A91")]
		[Address(RVA = "0x28A3208", Offset = "0x28A3208", VA = "0x28A3208")]
		private CharacterController \u083A\u089Bԙ\u0825()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A92 RID: 10898 RVA: 0x0010222C File Offset: 0x0010042C
		[Token(Token = "0x6002A92")]
		[Address(RVA = "0x28A3210", Offset = "0x28A3210", VA = "0x28A3210")]
		private void ӾԴ\u05B1ࠇ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A93 RID: 10899 RVA: 0x00102248 File Offset: 0x00100448
		[Token(Token = "0x6002A93")]
		[Address(RVA = "0x28A326C", Offset = "0x28A326C", VA = "0x28A326C")]
		private void ٦ښ\u083Bڋ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A94 RID: 10900 RVA: 0x00102264 File Offset: 0x00100464
		[Token(Token = "0x6002A94")]
		[Address(RVA = "0x28A32C8", Offset = "0x28A32C8", VA = "0x28A32C8")]
		private CharacterController ܙئۯ\u05F7()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A95 RID: 10901 RVA: 0x00102278 File Offset: 0x00100478
		[Token(Token = "0x6002A95")]
		[Address(RVA = "0x28A32D0", Offset = "0x28A32D0", VA = "0x28A32D0")]
		private CharacterController טއӏ\u073A()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A96 RID: 10902 RVA: 0x0010228C File Offset: 0x0010048C
		[Token(Token = "0x6002A96")]
		[Address(RVA = "0x28A32D8", Offset = "0x28A32D8", VA = "0x28A32D8")]
		private void \u0608\u070F\u081D\u05B8()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A97 RID: 10903 RVA: 0x001022A8 File Offset: 0x001004A8
		[Token(Token = "0x6002A97")]
		[Address(RVA = "0x28A3334", Offset = "0x28A3334", VA = "0x28A3334")]
		private CharacterController \u06E6و۳ࡠ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A98 RID: 10904 RVA: 0x001022BC File Offset: 0x001004BC
		[Token(Token = "0x6002A98")]
		[Address(RVA = "0x28A333C", Offset = "0x28A333C", VA = "0x28A333C")]
		private void ߘ\u05AEԮ\u06DD()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A99 RID: 10905 RVA: 0x001022D8 File Offset: 0x001004D8
		[Token(Token = "0x6002A99")]
		[Address(RVA = "0x28A3398", Offset = "0x28A3398", VA = "0x28A3398")]
		private void \u083CԖڢ\u07FD(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A9A RID: 10906 RVA: 0x001022EC File Offset: 0x001004EC
		[Token(Token = "0x6002A9A")]
		[Address(RVA = "0x28A33A0", Offset = "0x28A33A0", VA = "0x28A33A0")]
		private void ࡕկߒٹ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002A9B RID: 10907 RVA: 0x00102308 File Offset: 0x00100508
		[Token(Token = "0x6002A9B")]
		[Address(RVA = "0x28A33FC", Offset = "0x28A33FC", VA = "0x28A33FC")]
		private CharacterController ؾޏ\u0830װ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A9C RID: 10908 RVA: 0x0010231C File Offset: 0x0010051C
		[Token(Token = "0x6002A9C")]
		[Address(RVA = "0x28A3404", Offset = "0x28A3404", VA = "0x28A3404")]
		private void ڦکӁ\u06E2()
		{
			float axisRaw = Input.GetAxisRaw("DisableCosmetic");
			float axisRaw2 = Input.GetAxisRaw("Player");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002A9D RID: 10909 RVA: 0x00102390 File Offset: 0x00100590
		[Token(Token = "0x6002A9D")]
		[Address(RVA = "0x28A355C", Offset = "0x28A355C", VA = "0x28A355C")]
		private void \u0870ݜࢳ\u05EC(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002A9E RID: 10910 RVA: 0x001023A4 File Offset: 0x001005A4
		[Token(Token = "0x6002A9E")]
		[Address(RVA = "0x28A3564", Offset = "0x28A3564", VA = "0x28A3564")]
		private CharacterController ߎ\u0601\u07B2ޅ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002A9F RID: 10911 RVA: 0x001023B8 File Offset: 0x001005B8
		[Token(Token = "0x6002A9F")]
		[Address(RVA = "0x28A356C", Offset = "0x28A356C", VA = "0x28A356C")]
		private void \u088CԳ\u05A8ݐ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AA0 RID: 10912 RVA: 0x001023D4 File Offset: 0x001005D4
		[Token(Token = "0x6002AA0")]
		[Address(RVA = "0x28A35C8", Offset = "0x28A35C8", VA = "0x28A35C8")]
		private void \u061Eڥ\u05B2տ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AA1 RID: 10913 RVA: 0x001023F0 File Offset: 0x001005F0
		[Token(Token = "0x6002AA1")]
		[Address(RVA = "0x28A3624", Offset = "0x28A3624", VA = "0x28A3624")]
		private void דڳߡࠇ()
		{
			float axisRaw = Input.GetAxisRaw("Try Connect To Server...");
			float axisRaw2 = Input.GetAxisRaw("We don't need this electrical box");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AA2 RID: 10914 RVA: 0x00102464 File Offset: 0x00100664
		[Token(Token = "0x6002AA2")]
		[Address(RVA = "0x28A377C", Offset = "0x28A377C", VA = "0x28A377C")]
		private void \u07B6կպ߃()
		{
			float axisRaw = Input.GetAxisRaw("username");
			float axisRaw2 = Input.GetAxisRaw("_WobbleZ");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AA3 RID: 10915 RVA: 0x001024D8 File Offset: 0x001006D8
		[Token(Token = "0x6002AA3")]
		[Address(RVA = "0x28A38D4", Offset = "0x28A38D4", VA = "0x28A38D4")]
		private CharacterController مئܞ\u05FB()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AA4 RID: 10916 RVA: 0x001024EC File Offset: 0x001006EC
		[Token(Token = "0x6002AA4")]
		[Address(RVA = "0x28A38DC", Offset = "0x28A38DC", VA = "0x28A38DC")]
		private void ۹\u0833\u0557ࡇ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AA5 RID: 10917 RVA: 0x00102508 File Offset: 0x00100708
		[Token(Token = "0x6002AA5")]
		[Address(RVA = "0x28A3938", Offset = "0x28A3938", VA = "0x28A3938")]
		private void \u083C\u05F7ԫڙ()
		{
			float axisRaw = Input.GetAxisRaw("TurnAmount");
			float axisRaw2 = Input.GetAxisRaw("Try Connect To Server...");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AA6 RID: 10918 RVA: 0x0010257C File Offset: 0x0010077C
		[Token(Token = "0x6002AA6")]
		[Address(RVA = "0x28A3A90", Offset = "0x28A3A90", VA = "0x28A3A90")]
		private void Awake()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AA7 RID: 10919 RVA: 0x00102598 File Offset: 0x00100798
		[Token(Token = "0x6002AA7")]
		[Address(RVA = "0x28A3AEC", Offset = "0x28A3AEC", VA = "0x28A3AEC")]
		private void ہ\u089Cܗԇ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AA8 RID: 10920 RVA: 0x001025AC File Offset: 0x001007AC
		[Token(Token = "0x6002AA8")]
		[Address(RVA = "0x28A3AF4", Offset = "0x28A3AF4", VA = "0x28A3AF4")]
		private void \u060EܞڧՄ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AA9 RID: 10921 RVA: 0x001025C0 File Offset: 0x001007C0
		[Token(Token = "0x6002AA9")]
		[Address(RVA = "0x28A3AFC", Offset = "0x28A3AFC", VA = "0x28A3AFC")]
		private CharacterController Ӡٮ\u07F0ބ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AAA RID: 10922 RVA: 0x001025D4 File Offset: 0x001007D4
		[Token(Token = "0x6002AAA")]
		[Address(RVA = "0x28A3B04", Offset = "0x28A3B04", VA = "0x28A3B04")]
		private void ڋ۸\u088Cى()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AAB RID: 10923 RVA: 0x001025F0 File Offset: 0x001007F0
		[Token(Token = "0x6002AAB")]
		[Address(RVA = "0x28A3B60", Offset = "0x28A3B60", VA = "0x28A3B60")]
		private void Ԡݘעࠀ()
		{
			float axisRaw = Input.GetAxisRaw("Player");
			float axisRaw2 = Input.GetAxisRaw("Target");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AAC RID: 10924 RVA: 0x00102664 File Offset: 0x00100864
		[Token(Token = "0x6002AAC")]
		[Address(RVA = "0x28A3CB8", Offset = "0x28A3CB8", VA = "0x28A3CB8")]
		private void ڗ\u07F0ӷ\u07A7()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AAD RID: 10925 RVA: 0x00102680 File Offset: 0x00100880
		[Token(Token = "0x6002AAD")]
		[Address(RVA = "0x28A3D14", Offset = "0x28A3D14", VA = "0x28A3D14")]
		private void \u0731ݐ\u0654ࡡ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AAE RID: 10926 RVA: 0x0010269C File Offset: 0x0010089C
		[Token(Token = "0x6002AAE")]
		[Address(RVA = "0x28A3D70", Offset = "0x28A3D70", VA = "0x28A3D70")]
		private void Ӎࡪ\u0859\u07FD()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AAF RID: 10927 RVA: 0x001026B8 File Offset: 0x001008B8
		[Token(Token = "0x6002AAF")]
		[Address(RVA = "0x28A3DCC", Offset = "0x28A3DCC", VA = "0x28A3DCC")]
		private void \u0888ࢷٺ\u073A(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AB0 RID: 10928 RVA: 0x001026CC File Offset: 0x001008CC
		[Token(Token = "0x6002AB0")]
		[Address(RVA = "0x28A3DD4", Offset = "0x28A3DD4", VA = "0x28A3DD4")]
		private CharacterController ہ\u05ADڂߚ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AB1 RID: 10929 RVA: 0x001026E0 File Offset: 0x001008E0
		[Token(Token = "0x6002AB1")]
		[Address(RVA = "0x28A3DDC", Offset = "0x28A3DDC", VA = "0x28A3DDC")]
		private void \u0835ߙݺ\u073C(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AB2 RID: 10930 RVA: 0x001026F4 File Offset: 0x001008F4
		[Token(Token = "0x6002AB2")]
		[Address(RVA = "0x28A3DE4", Offset = "0x28A3DE4", VA = "0x28A3DE4")]
		private CharacterController ߢҽբڂ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AB3 RID: 10931 RVA: 0x00102708 File Offset: 0x00100908
		[Token(Token = "0x6002AB3")]
		[Address(RVA = "0x28A3DEC", Offset = "0x28A3DEC", VA = "0x28A3DEC")]
		private void \u061Fڡ\u05FBڎ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AB4 RID: 10932 RVA: 0x0010271C File Offset: 0x0010091C
		[Token(Token = "0x6002AB4")]
		[Address(RVA = "0x28A3DF4", Offset = "0x28A3DF4", VA = "0x28A3DF4")]
		private void ࢫݡ\u0880\u0659(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AB5 RID: 10933 RVA: 0x00102730 File Offset: 0x00100930
		[Token(Token = "0x6002AB5")]
		[Address(RVA = "0x28A3DFC", Offset = "0x28A3DFC", VA = "0x28A3DFC")]
		private void \u061A\u0871ޑڗ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AB6 RID: 10934 RVA: 0x00102744 File Offset: 0x00100944
		[Token(Token = "0x6002AB6")]
		[Address(RVA = "0x28A3E04", Offset = "0x28A3E04", VA = "0x28A3E04")]
		private void \u0882\u055C\u0888ߥ()
		{
			float axisRaw = Input.GetAxisRaw("On");
			float axisRaw2 = Input.GetAxisRaw("Name Changing Error. Error: ");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AB7 RID: 10935 RVA: 0x001027B8 File Offset: 0x001009B8
		[Token(Token = "0x6002AB7")]
		[Address(RVA = "0x28A3F5C", Offset = "0x28A3F5C", VA = "0x28A3F5C")]
		private void ۶ٯڄػ()
		{
			float axisRaw = Input.GetAxisRaw("User has been reported for: ");
			float axisRaw2 = Input.GetAxisRaw("TurnAmount");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AB8 RID: 10936 RVA: 0x0010282C File Offset: 0x00100A2C
		[Token(Token = "0x6002AB8")]
		[Address(RVA = "0x28A40B4", Offset = "0x28A40B4", VA = "0x28A40B4")]
		private void ښمݷ\u0559()
		{
			float axisRaw = Input.GetAxisRaw("Connected to Server.");
			float axisRaw2 = Input.GetAxisRaw("PushToTalk");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AB9 RID: 10937 RVA: 0x0010289C File Offset: 0x00100A9C
		[Token(Token = "0x6002AB9")]
		[Address(RVA = "0x28A420C", Offset = "0x28A420C", VA = "0x28A420C")]
		private CharacterController ࠓڻӰݸ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002ABA RID: 10938 RVA: 0x001028B0 File Offset: 0x00100AB0
		[Token(Token = "0x6002ABA")]
		[Address(RVA = "0x28A4214", Offset = "0x28A4214", VA = "0x28A4214")]
		private CharacterController ޱڛ\u0875լ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002ABB RID: 10939 RVA: 0x001028C4 File Offset: 0x00100AC4
		[Token(Token = "0x6002ABB")]
		[Address(RVA = "0x28A421C", Offset = "0x28A421C", VA = "0x28A421C")]
		private void ࠋࡘӊ\u06D6(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002ABC RID: 10940 RVA: 0x001028D8 File Offset: 0x00100AD8
		[Token(Token = "0x6002ABC")]
		[Address(RVA = "0x28A4224", Offset = "0x28A4224", VA = "0x28A4224")]
		private void Ԉ۴ࡉࢬ()
		{
			float axisRaw = Input.GetAxisRaw("gravThing");
			float axisRaw2 = Input.GetAxisRaw("Wear Hoodie");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002ABD RID: 10941 RVA: 0x0010294C File Offset: 0x00100B4C
		[Token(Token = "0x6002ABD")]
		[Address(RVA = "0x28A437C", Offset = "0x28A437C", VA = "0x28A437C")]
		private void ࡀڮӌߕ()
		{
			float axisRaw = Input.GetAxisRaw("Removing ");
			float axisRaw2 = Input.GetAxisRaw("BLUPORT");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002ABE RID: 10942 RVA: 0x001029C0 File Offset: 0x00100BC0
		[Token(Token = "0x6002ABE")]
		[Address(RVA = "0x28A44D4", Offset = "0x28A44D4", VA = "0x28A44D4")]
		private void ٵҼ\u07F1ڰ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002ABF RID: 10943 RVA: 0x001029DC File Offset: 0x00100BDC
		[Token(Token = "0x6002ABF")]
		[Address(RVA = "0x28A4530", Offset = "0x28A4530", VA = "0x28A4530")]
		private CharacterController ԂԸ\u0742ࡑ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AC0 RID: 10944 RVA: 0x001029F0 File Offset: 0x00100BF0
		[Token(Token = "0x6002AC0")]
		[Address(RVA = "0x28A4538", Offset = "0x28A4538", VA = "0x28A4538")]
		private void Ӫۈߊפ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AC1 RID: 10945 RVA: 0x00102A04 File Offset: 0x00100C04
		[Token(Token = "0x6002AC1")]
		[Address(RVA = "0x28A4540", Offset = "0x28A4540", VA = "0x28A4540")]
		private void ߥ\u05FDرԓ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AC2 RID: 10946 RVA: 0x00102A20 File Offset: 0x00100C20
		[Token(Token = "0x6002AC2")]
		[Address(RVA = "0x28A459C", Offset = "0x28A459C", VA = "0x28A459C")]
		private void ߩݶغն()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AC3 RID: 10947 RVA: 0x00102A3C File Offset: 0x00100C3C
		[Token(Token = "0x6002AC3")]
		[Address(RVA = "0x28A45F8", Offset = "0x28A45F8", VA = "0x28A45F8")]
		private void չւت\u061E()
		{
			float axisRaw = Input.GetAxisRaw("M/d/yyyy");
			float axisRaw2 = Input.GetAxisRaw("TurnAmount");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AC4 RID: 10948 RVA: 0x00102AB0 File Offset: 0x00100CB0
		[Token(Token = "0x6002AC4")]
		[Address(RVA = "0x28A4750", Offset = "0x28A4750", VA = "0x28A4750")]
		private void \u0876\u05AF\u07FBإ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AC5 RID: 10949 RVA: 0x00102AC4 File Offset: 0x00100CC4
		[Token(Token = "0x6002AC5")]
		[Address(RVA = "0x28A4758", Offset = "0x28A4758", VA = "0x28A4758")]
		private void \u07F5\u0657\u055Aߍ()
		{
			float axisRaw = Input.GetAxisRaw("RainAndThunderWeather");
			float axisRaw2 = Input.GetAxisRaw("PlayWave");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AC6 RID: 10950 RVA: 0x00102B38 File Offset: 0x00100D38
		[Token(Token = "0x6002AC6")]
		[Address(RVA = "0x28A48B0", Offset = "0x28A48B0", VA = "0x28A48B0")]
		private void ފޢږܢ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AC7 RID: 10951 RVA: 0x00102B4C File Offset: 0x00100D4C
		[Token(Token = "0x6002AC7")]
		[Address(RVA = "0x28A48B8", Offset = "0x28A48B8", VA = "0x28A48B8")]
		private CharacterController \u055Eרӊڐ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AC8 RID: 10952 RVA: 0x00102B60 File Offset: 0x00100D60
		[Token(Token = "0x6002AC8")]
		[Address(RVA = "0x28A48C0", Offset = "0x28A48C0", VA = "0x28A48C0")]
		private void \u07B4\u064Fݓӈ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AC9 RID: 10953 RVA: 0x00102B74 File Offset: 0x00100D74
		[Token(Token = "0x6002AC9")]
		[Address(RVA = "0x28A48C8", Offset = "0x28A48C8", VA = "0x28A48C8")]
		private void \u05A5ࢩވ\u05B0()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002ACA RID: 10954 RVA: 0x00102B90 File Offset: 0x00100D90
		[Token(Token = "0x6002ACA")]
		[Address(RVA = "0x28A4924", Offset = "0x28A4924", VA = "0x28A4924")]
		private void \u0595ڨڗݐ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002ACB RID: 10955 RVA: 0x00102BA4 File Offset: 0x00100DA4
		[Token(Token = "0x6002ACB")]
		[Address(RVA = "0x28A492C", Offset = "0x28A492C", VA = "0x28A492C")]
		private void \u07FAۯضߙ()
		{
			float axisRaw = Input.GetAxisRaw("Player");
			float axisRaw2 = Input.GetAxisRaw("false");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002ACC RID: 10956 RVA: 0x00102C18 File Offset: 0x00100E18
		[Token(Token = "0x6002ACC")]
		[Address(RVA = "0x28A4A84", Offset = "0x28A4A84", VA = "0x28A4A84")]
		private CharacterController \u0731էԲއ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002ACD RID: 10957 RVA: 0x00102C2C File Offset: 0x00100E2C
		[Token(Token = "0x6002ACD")]
		[Address(RVA = "0x28A4A8C", Offset = "0x28A4A8C", VA = "0x28A4A8C")]
		private CharacterController כࡥג\u0819()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002ACE RID: 10958 RVA: 0x00102C40 File Offset: 0x00100E40
		[Token(Token = "0x6002ACE")]
		[Address(RVA = "0x28A4A94", Offset = "0x28A4A94", VA = "0x28A4A94")]
		private void \u0872މࢮՃ()
		{
			float axisRaw = Input.GetAxisRaw("Starting to bake textures on frame ");
			float axisRaw2 = Input.GetAxisRaw("");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002ACF RID: 10959 RVA: 0x00102CB4 File Offset: 0x00100EB4
		[Token(Token = "0x6002ACF")]
		[Address(RVA = "0x28A4BEC", Offset = "0x28A4BEC", VA = "0x28A4BEC")]
		private CharacterController ԛׯՊݑ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06002AE5 RID: 10981 RVA: 0x00103068 File Offset: 0x00101268
		// (set) Token: 0x06002AD0 RID: 10960 RVA: 0x00102CC8 File Offset: 0x00100EC8
		[Token(Token = "0x17000041")]
		private CharacterController ށղԀݐ { [Token(Token = "0x6002AE5")] [Address(RVA = "0x28A547C", Offset = "0x28A547C", VA = "0x28A547C")] get; [Token(Token = "0x6002AD0")] [Address(RVA = "0x28A4BF4", Offset = "0x28A4BF4", VA = "0x28A4BF4")] set; }

		// Token: 0x06002AD1 RID: 10961 RVA: 0x00102CDC File Offset: 0x00100EDC
		[Token(Token = "0x6002AD1")]
		[Address(RVA = "0x28A4BFC", Offset = "0x28A4BFC", VA = "0x28A4BFC")]
		private void \u06E8\u07FD\u0834ߋ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AD2 RID: 10962 RVA: 0x00102CF0 File Offset: 0x00100EF0
		[Token(Token = "0x6002AD2")]
		[Address(RVA = "0x28A4C04", Offset = "0x28A4C04", VA = "0x28A4C04")]
		private CharacterController \u0889\u07AF\u0839\u07EC()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AD3 RID: 10963 RVA: 0x00102D04 File Offset: 0x00100F04
		[Token(Token = "0x6002AD3")]
		[Address(RVA = "0x28A4C0C", Offset = "0x28A4C0C", VA = "0x28A4C0C")]
		private void ӝԦࡘࠕ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AD4 RID: 10964 RVA: 0x00102D20 File Offset: 0x00100F20
		[Token(Token = "0x6002AD4")]
		[Address(RVA = "0x28A4C68", Offset = "0x28A4C68", VA = "0x28A4C68")]
		private CharacterController ࡡӒߏߥ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AD5 RID: 10965 RVA: 0x00102D34 File Offset: 0x00100F34
		[Token(Token = "0x6002AD5")]
		[Address(RVA = "0x28A4C70", Offset = "0x28A4C70", VA = "0x28A4C70")]
		private void ࢫ\u0876չՍ()
		{
			float axisRaw = Input.GetAxisRaw("isLava");
			float axisRaw2 = Input.GetAxisRaw("Add/Remove Hat");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AD6 RID: 10966 RVA: 0x00102DA8 File Offset: 0x00100FA8
		[Token(Token = "0x6002AD6")]
		[Address(RVA = "0x28A4DC8", Offset = "0x28A4DC8", VA = "0x28A4DC8")]
		private CharacterController \u07F8\u07EEա\u0839()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AD7 RID: 10967 RVA: 0x00102DBC File Offset: 0x00100FBC
		[Token(Token = "0x6002AD7")]
		[Address(RVA = "0x28A4DD0", Offset = "0x28A4DD0", VA = "0x28A4DD0")]
		private void Update()
		{
			float axisRaw = Input.GetAxisRaw("Horizontal");
			float axisRaw2 = Input.GetAxisRaw("Vertical");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AD8 RID: 10968 RVA: 0x00102E30 File Offset: 0x00101030
		[Token(Token = "0x6002AD8")]
		[Address(RVA = "0x28A4F28", Offset = "0x28A4F28", VA = "0x28A4F28")]
		private void ۓࢬࢪ\u06E4()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AD9 RID: 10969 RVA: 0x00102E4C File Offset: 0x0010104C
		[Token(Token = "0x6002AD9")]
		[Address(RVA = "0x28A4F84", Offset = "0x28A4F84", VA = "0x28A4F84")]
		private void \u07AFӺԐӥ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002ADA RID: 10970 RVA: 0x00102E60 File Offset: 0x00101060
		[Token(Token = "0x6002ADA")]
		[Address(RVA = "0x28A4F8C", Offset = "0x28A4F8C", VA = "0x28A4F8C")]
		private void ࢯٮܤ\u061F()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002ADB RID: 10971 RVA: 0x00102E7C File Offset: 0x0010107C
		[Token(Token = "0x6002ADB")]
		[Address(RVA = "0x28A4FE8", Offset = "0x28A4FE8", VA = "0x28A4FE8")]
		private CharacterController ۼؿ\u05C9ا()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002ADC RID: 10972 RVA: 0x00102E90 File Offset: 0x00101090
		[Token(Token = "0x6002ADC")]
		[Address(RVA = "0x28A4FF0", Offset = "0x28A4FF0", VA = "0x28A4FF0")]
		private void ޟݔԈԭ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002ADD RID: 10973 RVA: 0x00102EAC File Offset: 0x001010AC
		[Token(Token = "0x6002ADD")]
		[Address(RVA = "0x28A504C", Offset = "0x28A504C", VA = "0x28A504C")]
		private void ԅ\u073Fڥ\u0839()
		{
			float axisRaw = Input.GetAxisRaw("EnableCosmetic");
			float axisRaw2 = Input.GetAxisRaw("DisableCosmetic");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002ADE RID: 10974 RVA: 0x00102F20 File Offset: 0x00101120
		[Token(Token = "0x6002ADE")]
		[Address(RVA = "0x28A51A4", Offset = "0x28A51A4", VA = "0x28A51A4")]
		private CharacterController \u0730ࡗٻ\u07ED()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002ADF RID: 10975 RVA: 0x00102F34 File Offset: 0x00101134
		[Token(Token = "0x6002ADF")]
		[Address(RVA = "0x28A51AC", Offset = "0x28A51AC", VA = "0x28A51AC")]
		private void ޞ\u07FF\u05B1\u05BB(CharacterController \u05FB\u05AB\u0739ڑ)
		{
			this.<աࡅٽ\u06DA>k__BackingField = \u05FB\u05AB\u0739ڑ;
		}

		// Token: 0x06002AE0 RID: 10976 RVA: 0x00102F48 File Offset: 0x00101148
		[Token(Token = "0x6002AE0")]
		[Address(RVA = "0x28A51B4", Offset = "0x28A51B4", VA = "0x28A51B4")]
		private void ࢶ٠\u086D\u0708()
		{
			float axisRaw = Input.GetAxisRaw("A new Player joined a Room.");
			float axisRaw2 = Input.GetAxisRaw("back");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AE1 RID: 10977 RVA: 0x00102FB8 File Offset: 0x001011B8
		[Token(Token = "0x6002AE1")]
		[Address(RVA = "0x28A530C", Offset = "0x28A530C", VA = "0x28A530C")]
		private CharacterController \u0731\u0704\u0670\u083D()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AE2 RID: 10978 RVA: 0x00102FCC File Offset: 0x001011CC
		[Token(Token = "0x6002AE2")]
		[Address(RVA = "0x28A5314", Offset = "0x28A5314", VA = "0x28A5314")]
		private CharacterController \u0881\u06FD\u05F7چ()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AE3 RID: 10979 RVA: 0x00102FE0 File Offset: 0x001011E0
		[Token(Token = "0x6002AE3")]
		[Address(RVA = "0x28A531C", Offset = "0x28A531C", VA = "0x28A531C")]
		private void ؤ\u05C8ԛ\u083F()
		{
			float axisRaw = Input.GetAxisRaw("You Already Own This Item");
			float axisRaw2 = Input.GetAxisRaw("Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AE4 RID: 10980 RVA: 0x00103054 File Offset: 0x00101254
		[Token(Token = "0x6002AE4")]
		[Address(RVA = "0x28A5474", Offset = "0x28A5474", VA = "0x28A5474")]
		private CharacterController چթ\u05B0\u05CA()
		{
			return this.<աࡅٽ\u06DA>k__BackingField;
		}

		// Token: 0x06002AE6 RID: 10982 RVA: 0x0010307C File Offset: 0x0010127C
		[Token(Token = "0x6002AE6")]
		[Address(RVA = "0x28A5484", Offset = "0x28A5484", VA = "0x28A5484")]
		private void \u05EDց\u081Cت()
		{
			float axisRaw = Input.GetAxisRaw("You have been banned for ");
			float axisRaw2 = Input.GetAxisRaw("back");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AE7 RID: 10983 RVA: 0x001030F0 File Offset: 0x001012F0
		[Token(Token = "0x6002AE7")]
		[Address(RVA = "0x28A55DC", Offset = "0x28A55DC", VA = "0x28A55DC")]
		private void \u085Dل\u07FBࡊ()
		{
			float axisRaw = Input.GetAxisRaw("tutorialCheck");
			float axisRaw2 = Input.GetAxisRaw("SetColor");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AE8 RID: 10984 RVA: 0x00103164 File Offset: 0x00101364
		[Token(Token = "0x6002AE8")]
		[Address(RVA = "0x28A5734", Offset = "0x28A5734", VA = "0x28A5734")]
		private void ࡒ\u070Eڻߪ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AE9 RID: 10985 RVA: 0x00103180 File Offset: 0x00101380
		[Token(Token = "0x6002AE9")]
		[Address(RVA = "0x28A5790", Offset = "0x28A5790", VA = "0x28A5790")]
		private void ݽ\u0706\u07ADࡇ()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.<աࡅٽ\u06DA>k__BackingField = component;
		}

		// Token: 0x06002AEA RID: 10986 RVA: 0x0010319C File Offset: 0x0010139C
		[Token(Token = "0x6002AEA")]
		[Address(RVA = "0x28A57EC", Offset = "0x28A57EC", VA = "0x28A57EC")]
		private void ӒԂࡩࡓ()
		{
			float axisRaw = Input.GetAxisRaw("Tagged");
			float u05A3_u07B9Թޜ = this.\u05A3\u07B9Թޜ;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float ӳۍՂڧ = this.ӲۍՂڧ;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			CharacterController <աࡅٽ_u06DA>k__BackingField = this.<աࡅٽ\u06DA>k__BackingField;
			Transform transform = base.transform;
		}

		// Token: 0x06002AEB RID: 10987 RVA: 0x00103204 File Offset: 0x00101404
		[Token(Token = "0x6002AEB")]
		[Address(RVA = "0x28A5944", Offset = "0x28A5944", VA = "0x28A5944")]
		private void ԟԦݸԯ(CharacterController \u05FB\u05AB\u0739ڑ)
		{
		}

		// Token: 0x040005A9 RID: 1449
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40005A9")]
		public float ӲۍՂڧ;

		// Token: 0x040005AA RID: 1450
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x40005AA")]
		public float \u05A3\u07B9Թޜ;
	}
}
