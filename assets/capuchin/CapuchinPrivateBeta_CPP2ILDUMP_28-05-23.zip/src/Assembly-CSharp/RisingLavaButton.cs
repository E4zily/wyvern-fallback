﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

// Token: 0x020000D9 RID: 217
[Token(Token = "0x20000D9")]
public class RisingLavaButton : MonoBehaviour
{
	// Token: 0x060020C8 RID: 8392 RVA: 0x000AC058 File Offset: 0x000AA258
	[Token(Token = "0x60020C8")]
	[Address(RVA = "0x2DEFC60", Offset = "0x2DEFC60", VA = "0x2DEFC60")]
	public void ۯظӽӠ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020C9 RID: 8393 RVA: 0x000AC14C File Offset: 0x000AA34C
	[Token(Token = "0x60020C9")]
	[Address(RVA = "0x2DEFD6C", Offset = "0x2DEFD6C", VA = "0x2DEFD6C")]
	public void ԙڗ\u0705ܧ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020CA RID: 8394 RVA: 0x000AC168 File Offset: 0x000AA368
	[Token(Token = "0x60020CA")]
	[Address(RVA = "0x2DEFDC8", Offset = "0x2DEFDC8", VA = "0x2DEFDC8")]
	public void \u05F4۴ޞࠅ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x060020CB RID: 8395 RVA: 0x000AC29C File Offset: 0x000AA49C
	[Token(Token = "0x60020CB")]
	[Address(RVA = "0x2DF0118", Offset = "0x2DF0118", VA = "0x2DF0118")]
	public void \u0829\u05FDژտ()
	{
		if ("\ud9c0\udc00" == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		if ("\ud9c0\udc00" == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
	}

	// Token: 0x060020CC RID: 8396 RVA: 0x000AC3D8 File Offset: 0x000AA5D8
	[Token(Token = "0x60020CC")]
	[Address(RVA = "0x2DF0480", Offset = "0x2DF0480", VA = "0x2DF0480")]
	public void ޥ\u089Dڢ\u06E3()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020CD RID: 8397 RVA: 0x000AC3F4 File Offset: 0x000AA5F4
	[Token(Token = "0x60020CD")]
	[Address(RVA = "0x2DF04DC", Offset = "0x2DF04DC", VA = "0x2DF04DC")]
	public void \u0834\u0817ރࡔ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020CE RID: 8398 RVA: 0x000AC410 File Offset: 0x000AA610
	[Token(Token = "0x60020CE")]
	[Address(RVA = "0x2DF0538", Offset = "0x2DF0538", VA = "0x2DF0538")]
	public void ߑ\u0885\u05BBߕ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
	}

	// Token: 0x060020CF RID: 8399 RVA: 0x000AC54C File Offset: 0x000AA74C
	[Token(Token = "0x60020CF")]
	[Address(RVA = "0x2DF08A8", Offset = "0x2DF08A8", VA = "0x2DF08A8")]
	public void Ԫߑࠌ\u064C()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x060020D0 RID: 8400 RVA: 0x000AC684 File Offset: 0x000AA884
	[Token(Token = "0x60020D0")]
	[Address(RVA = "0x2DF0C18", Offset = "0x2DF0C18", VA = "0x2DF0C18")]
	public void \u0818ՠש\u0731()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020D1 RID: 8401 RVA: 0x000AC6A0 File Offset: 0x000AA8A0
	[Token(Token = "0x60020D1")]
	[Address(RVA = "0x2DF0C74", Offset = "0x2DF0C74", VA = "0x2DF0C74")]
	public void ؤ\u05C8ԛ\u083F()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x060020D2 RID: 8402 RVA: 0x000AC7D4 File Offset: 0x000AA9D4
	[Token(Token = "0x60020D2")]
	[Address(RVA = "0x2DF0FD8", Offset = "0x2DF0FD8", VA = "0x2DF0FD8")]
	public void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060020D3 RID: 8403 RVA: 0x000AC82C File Offset: 0x000AAA2C
	[Token(Token = "0x60020D3")]
	[Address(RVA = "0x2DF1190", Offset = "0x2DF1190", VA = "0x2DF1190")]
	public void תߧࡓթ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020D4 RID: 8404 RVA: 0x000AC848 File Offset: 0x000AAA48
	[Token(Token = "0x60020D4")]
	[Address(RVA = "0x2DF11EC", Offset = "0x2DF11EC", VA = "0x2DF11EC")]
	public void ד\u073C\u0613چ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ3 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x060020D5 RID: 8405 RVA: 0x000AC98C File Offset: 0x000AAB8C
	[Token(Token = "0x60020D5")]
	[Address(RVA = "0x2DF1578", Offset = "0x2DF1578", VA = "0x2DF1578")]
	public void ہݕ\u07EFԒ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x060020D6 RID: 8406 RVA: 0x000ACAD4 File Offset: 0x000AACD4
	[Token(Token = "0x60020D6")]
	[Address(RVA = "0x2DF18E8", Offset = "0x2DF18E8", VA = "0x2DF18E8")]
	public void ى߁ٱՏ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x060020D7 RID: 8407 RVA: 0x000ACC1C File Offset: 0x000AAE1C
	[Token(Token = "0x60020D7")]
	[Address(RVA = "0x2DF1C54", Offset = "0x2DF1C54", VA = "0x2DF1C54")]
	public void ܥࡖ\u06E3ב()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long num = 1L;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020D8 RID: 8408 RVA: 0x000ACD1C File Offset: 0x000AAF1C
	[Token(Token = "0x60020D8")]
	[Address(RVA = "0x2DF1D64", Offset = "0x2DF1D64", VA = "0x2DF1D64")]
	public void ے\u059Fࢰس(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "On";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060020D9 RID: 8409 RVA: 0x000ACD84 File Offset: 0x000AAF84
	[Token(Token = "0x60020D9")]
	[Address(RVA = "0x2DF1F1C", Offset = "0x2DF1F1C", VA = "0x2DF1F1C")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "run";
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060020DA RID: 8410 RVA: 0x000ACDDC File Offset: 0x000AAFDC
	[Token(Token = "0x60020DA")]
	[Address(RVA = "0x2DF20D4", Offset = "0x2DF20D4", VA = "0x2DF20D4")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "spooky guy true";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060020DB RID: 8411 RVA: 0x000ACE44 File Offset: 0x000AB044
	[Token(Token = "0x60020DB")]
	[Address(RVA = "0x2DF228C", Offset = "0x2DF228C", VA = "0x2DF228C")]
	public void ࡎս\u05CAڵ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long num = 0L;
		հ_u066Aߝ_u2.isKinematic = (num != 0L);
		this.ل\u0826\u0703\u055E.SetActive(num != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long num2 = 1L;
		this.שߟ٥ܭ = (num2 != 0L);
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060020DC RID: 8412 RVA: 0x000ACF3C File Offset: 0x000AB13C
	[Token(Token = "0x60020DC")]
	[Address(RVA = "0x2DF239C", Offset = "0x2DF239C", VA = "0x2DF239C")]
	public void Վࡧ\u06FDܕ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
	}

	// Token: 0x060020DD RID: 8413 RVA: 0x000AD06C File Offset: 0x000AB26C
	[Token(Token = "0x60020DD")]
	[Address(RVA = "0x2DF2708", Offset = "0x2DF2708", VA = "0x2DF2708")]
	public void ࢰחڵࡓ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020DE RID: 8414 RVA: 0x000AD088 File Offset: 0x000AB288
	[Token(Token = "0x60020DE")]
	[Address(RVA = "0x2DF2764", Offset = "0x2DF2764", VA = "0x2DF2764")]
	public void ܩ\u05FBࢠع()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long num = 1L;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020DF RID: 8415 RVA: 0x000AD188 File Offset: 0x000AB388
	[Token(Token = "0x60020DF")]
	[Address(RVA = "0x2DF2874", Offset = "0x2DF2874", VA = "0x2DF2874")]
	public void \u061Fدߡӟ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x060020E0 RID: 8416 RVA: 0x000AD2B4 File Offset: 0x000AB4B4
	[Token(Token = "0x60020E0")]
	[Address(RVA = "0x2DF2BE0", Offset = "0x2DF2BE0", VA = "0x2DF2BE0")]
	public void Ӻ\u0828\u07BD\u06ED()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x060020E1 RID: 8417 RVA: 0x000AD3F0 File Offset: 0x000AB5F0
	[Token(Token = "0x60020E1")]
	[Address(RVA = "0x2DF2F4C", Offset = "0x2DF2F4C", VA = "0x2DF2F4C")]
	public void ڗ\u05CB\u0597Ӛ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020E2 RID: 8418 RVA: 0x000AD4E4 File Offset: 0x000AB6E4
	[Token(Token = "0x60020E2")]
	[Address(RVA = "0x2DF3058", Offset = "0x2DF3058", VA = "0x2DF3058")]
	public void ۷ܘ\u081E\u07A6()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 1L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020E3 RID: 8419 RVA: 0x000AD5D8 File Offset: 0x000AB7D8
	[Token(Token = "0x60020E3")]
	[Address(RVA = "0x2DF3164", Offset = "0x2DF3164", VA = "0x2DF3164")]
	public void \u07BDՑ\u0832ࠍ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Head";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.ע\u0707ࡩբ != null)
		{
			return;
		}
	}

	// Token: 0x060020E4 RID: 8420 RVA: 0x000AD63C File Offset: 0x000AB83C
	[Token(Token = "0x60020E4")]
	[Address(RVA = "0x2DF331C", Offset = "0x2DF331C", VA = "0x2DF331C")]
	public void \u0599ږࠆ\u065F()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ != null)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x060020E5 RID: 8421 RVA: 0x000AD774 File Offset: 0x000AB974
	[Token(Token = "0x60020E5")]
	[Address(RVA = "0x2DF3688", Offset = "0x2DF3688", VA = "0x2DF3688")]
	public void \u0589ࢰ\u07FDٽ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		this.ڣܨݜ۷.enabled = (enabled2 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled3 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled3 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled4 = 0L;
		طܦտ_u05A2.enabled = (enabled4 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled5 = 1L;
		capsuleCollider.enabled = (enabled5 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		long num = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num != 0L);
		long enabled6 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled6 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020E6 RID: 8422 RVA: 0x000AD86C File Offset: 0x000ABA6C
	[Token(Token = "0x60020E6")]
	[Address(RVA = "0x2DF3798", Offset = "0x2DF3798", VA = "0x2DF3798")]
	public void ڛ٩ރ\u0706()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020E7 RID: 8423 RVA: 0x000AD888 File Offset: 0x000ABA88
	[Token(Token = "0x60020E7")]
	[Address(RVA = "0x2DF37F4", Offset = "0x2DF37F4", VA = "0x2DF37F4")]
	public void ޥ\u0817ٸԙ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 1L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020E8 RID: 8424 RVA: 0x000AD97C File Offset: 0x000ABB7C
	[Token(Token = "0x60020E8")]
	[Address(RVA = "0x2DF3900", Offset = "0x2DF3900", VA = "0x2DF3900")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "\n Time: ";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		if (ע_u0707ࡩբ != null)
		{
			if (ע_u0707ࡩբ == null)
			{
			}
			return;
		}
	}

	// Token: 0x060020E9 RID: 8425 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60020E9")]
	[Address(RVA = "0x2DF3AB8", Offset = "0x2DF3AB8", VA = "0x2DF3AB8")]
	public void \u07F7ܙײ\u05B5()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060020EA RID: 8426 RVA: 0x000AD9E8 File Offset: 0x000ABBE8
	[Token(Token = "0x60020EA")]
	[Address(RVA = "0x2DF3E10", Offset = "0x2DF3E10", VA = "0x2DF3E10")]
	public void Update()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
			return;
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x060020EB RID: 8427 RVA: 0x000ADA38 File Offset: 0x000ABC38
	[Token(Token = "0x60020EB")]
	[Address(RVA = "0x2DF4178", Offset = "0x2DF4178", VA = "0x2DF4178")]
	public void ڪ\u086Dӄێ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not connected to room";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060020EC RID: 8428 RVA: 0x000ADAA0 File Offset: 0x000ABCA0
	[Token(Token = "0x60020EC")]
	[Address(RVA = "0x2DF4330", Offset = "0x2DF4330", VA = "0x2DF4330")]
	public void ճ\u0828Ԓհ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Open";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060020ED RID: 8429 RVA: 0x000ADB08 File Offset: 0x000ABD08
	[Token(Token = "0x60020ED")]
	[Address(RVA = "0x2DF44E8", Offset = "0x2DF44E8", VA = "0x2DF44E8")]
	public void \u0705ոՠӱ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		long num = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020EE RID: 8430 RVA: 0x000ADC08 File Offset: 0x000ABE08
	[Token(Token = "0x60020EE")]
	[Address(RVA = "0x2DF45F8", Offset = "0x2DF45F8", VA = "0x2DF45F8")]
	public void \u07EBࠎיࡂ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020EF RID: 8431 RVA: 0x000ADC24 File Offset: 0x000ABE24
	[Token(Token = "0x60020EF")]
	[Address(RVA = "0x2DF4654", Offset = "0x2DF4654", VA = "0x2DF4654")]
	public void \u074Cو\u061C\u07A6()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 1L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020F0 RID: 8432 RVA: 0x000ADD18 File Offset: 0x000ABF18
	[Token(Token = "0x60020F0")]
	[Address(RVA = "0x2DF4760", Offset = "0x2DF4760", VA = "0x2DF4760")]
	public void \u070Aәޣے()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x060020F1 RID: 8433 RVA: 0x000ADE44 File Offset: 0x000AC044
	[Token(Token = "0x60020F1")]
	[Address(RVA = "0x2DF4AA8", Offset = "0x2DF4AA8", VA = "0x2DF4AA8")]
	public void \u0617ե\u055Dߓ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 1L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020F2 RID: 8434 RVA: 0x000ADF38 File Offset: 0x000AC138
	[Token(Token = "0x60020F2")]
	[Address(RVA = "0x2DF4BB4", Offset = "0x2DF4BB4", VA = "0x2DF4BB4")]
	public void نӥ\u0614ر()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 1L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		long num = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020F3 RID: 8435 RVA: 0x000AE038 File Offset: 0x000AC238
	[Token(Token = "0x60020F3")]
	[Address(RVA = "0x2DF4CC4", Offset = "0x2DF4CC4", VA = "0x2DF4CC4")]
	public void ߄Ӄ\u0613ھ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020F4 RID: 8436 RVA: 0x000AE054 File Offset: 0x000AC254
	[Token(Token = "0x60020F4")]
	[Address(RVA = "0x2DF4D20", Offset = "0x2DF4D20", VA = "0x2DF4D20")]
	public void ں٢ࡡ\u05EC()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x060020F5 RID: 8437 RVA: 0x000AE188 File Offset: 0x000AC388
	[Token(Token = "0x60020F5")]
	[Address(RVA = "0x2DF5074", Offset = "0x2DF5074", VA = "0x2DF5074")]
	public void ܚߧۼߗ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 1L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long num = 0L;
		capsuleCollider2.enabled = (num != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long num2 = 1L;
		հ_u066Aߝ_u2.isKinematic = (num != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num2 != 0L);
		long enabled6 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled6 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 1L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020F6 RID: 8438 RVA: 0x000AE284 File Offset: 0x000AC484
	[Token(Token = "0x60020F6")]
	[Address(RVA = "0x2DF5184", Offset = "0x2DF5184", VA = "0x2DF5184")]
	public void Ӭ\u06EB\u0607ܐ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060020F7 RID: 8439 RVA: 0x000AE2EC File Offset: 0x000AC4EC
	[Token(Token = "0x60020F7")]
	[Address(RVA = "0x2DF533C", Offset = "0x2DF533C", VA = "0x2DF533C")]
	public void յߪؾՀ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x060020F8 RID: 8440 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60020F8")]
	[Address(RVA = "0x2DF567C", Offset = "0x2DF567C", VA = "0x2DF567C")]
	public void \u0705\u0816\u0739դ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060020F9 RID: 8441 RVA: 0x000AE420 File Offset: 0x000AC620
	[Token(Token = "0x60020F9")]
	[Address(RVA = "0x2DF5A0C", Offset = "0x2DF5A0C", VA = "0x2DF5A0C")]
	public void Start()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020FA RID: 8442 RVA: 0x000AE43C File Offset: 0x000AC63C
	[Token(Token = "0x60020FA")]
	[Address(RVA = "0x2DF5A68", Offset = "0x2DF5A68", VA = "0x2DF5A68")]
	public void ࡊ\u0592\u07AB\u05B2()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ3 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x060020FB RID: 8443 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60020FB")]
	[Address(RVA = "0x2DF5DF8", Offset = "0x2DF5DF8", VA = "0x2DF5DF8")]
	public void ފՖߢ\u059B()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060020FC RID: 8444 RVA: 0x000AE58C File Offset: 0x000AC78C
	[Token(Token = "0x60020FC")]
	[Address(RVA = "0x2DF6164", Offset = "0x2DF6164", VA = "0x2DF6164")]
	public void މجԽӆ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		long num = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 1L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x060020FD RID: 8445 RVA: 0x000AE68C File Offset: 0x000AC88C
	[Token(Token = "0x60020FD")]
	[Address(RVA = "0x2DF6274", Offset = "0x2DF6274", VA = "0x2DF6274")]
	public void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "duration done";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060020FE RID: 8446 RVA: 0x000AE6F4 File Offset: 0x000AC8F4
	[Token(Token = "0x60020FE")]
	[Address(RVA = "0x2DF642C", Offset = "0x2DF642C", VA = "0x2DF642C")]
	public void Ԁוև\u065B()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x060020FF RID: 8447 RVA: 0x000AE710 File Offset: 0x000AC910
	[Token(Token = "0x60020FF")]
	[Address(RVA = "0x2DF6488", Offset = "0x2DF6488", VA = "0x2DF6488")]
	public void سܠӛ\u07AA()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x06002100 RID: 8448 RVA: 0x000AE854 File Offset: 0x000ACA54
	[Token(Token = "0x6002100")]
	[Address(RVA = "0x2DF67EC", Offset = "0x2DF67EC", VA = "0x2DF67EC")]
	public void ԛۻ\u081C\u07B5(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002101 RID: 8449 RVA: 0x000AE8B4 File Offset: 0x000ACAB4
	[Token(Token = "0x6002101")]
	[Address(RVA = "0x2DF69A4", Offset = "0x2DF69A4", VA = "0x2DF69A4")]
	public void \u06D4ݑڋօ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 1L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		long num = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002102 RID: 8450 RVA: 0x000AE9B4 File Offset: 0x000ACBB4
	[Token(Token = "0x6002102")]
	[Address(RVA = "0x2DF6AB4", Offset = "0x2DF6AB4", VA = "0x2DF6AB4")]
	public void ࠍ\u06E5\u055Eئ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "MetaId";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002103 RID: 8451 RVA: 0x000AEA1C File Offset: 0x000ACC1C
	[Token(Token = "0x6002103")]
	[Address(RVA = "0x2DF6C6C", Offset = "0x2DF6C6C", VA = "0x2DF6C6C")]
	public void \u0886ۋ\u061Bޜ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		long num = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002104 RID: 8452 RVA: 0x000AEB1C File Offset: 0x000ACD1C
	[Token(Token = "0x6002104")]
	[Address(RVA = "0x2DF6D7C", Offset = "0x2DF6D7C", VA = "0x2DF6D7C")]
	public void \u0896\u06FE\u0602ӯ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002105 RID: 8453 RVA: 0x000AEB38 File Offset: 0x000ACD38
	[Token(Token = "0x6002105")]
	[Address(RVA = "0x2DF6DD8", Offset = "0x2DF6DD8", VA = "0x2DF6DD8")]
	public void \u0884ٿ\u0659ԫ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Failed to get catalog, cosmetic name, and price. Exact error details is: ";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002106 RID: 8454 RVA: 0x000AEBA0 File Offset: 0x000ACDA0
	[Token(Token = "0x6002106")]
	[Address(RVA = "0x2DF6F90", Offset = "0x2DF6F90", VA = "0x2DF6F90")]
	public void \u0881\u0743\u07EB\u0747()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002107 RID: 8455 RVA: 0x000AEBBC File Offset: 0x000ACDBC
	[Token(Token = "0x6002107")]
	[Address(RVA = "0x2DF6FEC", Offset = "0x2DF6FEC", VA = "0x2DF6FEC")]
	public void \u0832ࢳޤ\u07B5()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x06002108 RID: 8456 RVA: 0x000AECFC File Offset: 0x000ACEFC
	[Token(Token = "0x6002108")]
	[Address(RVA = "0x2DF733C", Offset = "0x2DF733C", VA = "0x2DF733C")]
	public void \u0827אݶה()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002109 RID: 8457 RVA: 0x000AEDF0 File Offset: 0x000ACFF0
	[Token(Token = "0x6002109")]
	[Address(RVA = "0x2DF7448", Offset = "0x2DF7448", VA = "0x2DF7448")]
	public void Ӌ\u089C\u0700ܧ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x0600210A RID: 8458 RVA: 0x000AEF30 File Offset: 0x000AD130
	[Token(Token = "0x600210A")]
	[Address(RVA = "0x2DF77BC", Offset = "0x2DF77BC", VA = "0x2DF77BC")]
	public void ࠈ\u07A9\u05B3Ծ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ3 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x0600210B RID: 8459 RVA: 0x000AF074 File Offset: 0x000AD274
	[Token(Token = "0x600210B")]
	[Address(RVA = "0x2DF7B44", Offset = "0x2DF7B44", VA = "0x2DF7B44")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x0600210C RID: 8460 RVA: 0x000AF1A4 File Offset: 0x000AD3A4
	[Token(Token = "0x600210C")]
	[Address(RVA = "0x2DF7EB4", Offset = "0x2DF7EB4", VA = "0x2DF7EB4")]
	public void \u0593\u05A4Ӣ\u0602()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x0600210D RID: 8461 RVA: 0x000AF1C0 File Offset: 0x000AD3C0
	[Token(Token = "0x600210D")]
	[Address(RVA = "0x2DF7F10", Offset = "0x2DF7F10", VA = "0x2DF7F10")]
	public void \u059B\u081F\u05FEڂ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600210E RID: 8462 RVA: 0x000AF228 File Offset: 0x000AD428
	[Token(Token = "0x600210E")]
	[Address(RVA = "0x2DF80C8", Offset = "0x2DF80C8", VA = "0x2DF80C8")]
	public void Ӝ\u0558ө\u070C(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		GameObject gameObject;
		bool flag = gameObject.tag == "Mesh";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600210F RID: 8463 RVA: 0x000AF290 File Offset: 0x000AD490
	[Token(Token = "0x600210F")]
	[Address(RVA = "0x2DF8280", Offset = "0x2DF8280", VA = "0x2DF8280")]
	public void ࡕߕ\u0707ݩ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ3 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x06002110 RID: 8464 RVA: 0x000AF3E0 File Offset: 0x000AD5E0
	[Token(Token = "0x6002110")]
	[Address(RVA = "0x2DF860C", Offset = "0x2DF860C", VA = "0x2DF860C")]
	public void ٨\u055EӠԛ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 1L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		long num = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002111 RID: 8465 RVA: 0x000AF4E0 File Offset: 0x000AD6E0
	[Token(Token = "0x6002111")]
	[Address(RVA = "0x2DF871C", Offset = "0x2DF871C", VA = "0x2DF871C")]
	public void ڋࠃ\u06ECࡌ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 1L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002112 RID: 8466 RVA: 0x000AF5D4 File Offset: 0x000AD7D4
	[Token(Token = "0x6002112")]
	[Address(RVA = "0x2DF8828", Offset = "0x2DF8828", VA = "0x2DF8828")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "QuickStatic";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002113 RID: 8467 RVA: 0x000AF63C File Offset: 0x000AD83C
	[Token(Token = "0x6002113")]
	[Address(RVA = "0x2DF89E0", Offset = "0x2DF89E0", VA = "0x2DF89E0")]
	public void ࢳ\u088E٠ݪ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002114 RID: 8468 RVA: 0x000AF658 File Offset: 0x000AD858
	[Token(Token = "0x6002114")]
	[Address(RVA = "0x2DF8A3C", Offset = "0x2DF8A3C", VA = "0x2DF8A3C")]
	public void \u070F߃ןہ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		this.ڣܨݜ۷.enabled = (enabled2 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled3 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled3 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled4 = 1L;
		طܦտ_u05A2.enabled = (enabled4 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled5 = 1L;
		capsuleCollider.enabled = (enabled5 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled6 = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled6 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002115 RID: 8469 RVA: 0x000AF744 File Offset: 0x000AD944
	[Token(Token = "0x6002115")]
	[Address(RVA = "0x2DF8B48", Offset = "0x2DF8B48", VA = "0x2DF8B48")]
	public void \u073Bݲձݕ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002116 RID: 8470 RVA: 0x000AF760 File Offset: 0x000AD960
	[Token(Token = "0x6002116")]
	[Address(RVA = "0x2DF8BA4", Offset = "0x2DF8BA4", VA = "0x2DF8BA4")]
	public void \u0611آצӉ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long num = 0L;
		հ_u066Aߝ_u.isKinematic = (num != 0L);
		this.ע\u0707ࡩբ.enabled = (num != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled = 1L;
		طܦտ_u05A.enabled = (enabled != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled2 = 1L;
		capsuleCollider.enabled = (enabled2 != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled3 = 0L;
		ע_u0707ࡩբ.enabled = (enabled3 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled4 = 1L;
		طܦտ_u05A2.enabled = (enabled4 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled5 = 1L;
		capsuleCollider2.enabled = (enabled5 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long num2 = 1L;
		this.שߟ٥ܭ = (num2 != 0L);
		long enabled6 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled6 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002117 RID: 8471 RVA: 0x000AF858 File Offset: 0x000ADA58
	[Token(Token = "0x6002117")]
	[Address(RVA = "0x2DF8CB4", Offset = "0x2DF8CB4", VA = "0x2DF8CB4")]
	public void \u05F7ԝߠӱ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x06002118 RID: 8472 RVA: 0x000AF998 File Offset: 0x000ADB98
	[Token(Token = "0x6002118")]
	[Address(RVA = "0x2DF9020", Offset = "0x2DF9020", VA = "0x2DF9020")]
	public void \u065D\u070Aٶࢰ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002119 RID: 8473 RVA: 0x000AF9B4 File Offset: 0x000ADBB4
	[Token(Token = "0x6002119")]
	[Address(RVA = "0x2DF907C", Offset = "0x2DF907C", VA = "0x2DF907C")]
	public void \u0830ݥ\u0896Ԕ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x0600211A RID: 8474 RVA: 0x000AF9D0 File Offset: 0x000ADBD0
	[Token(Token = "0x600211A")]
	[Address(RVA = "0x2DF90D8", Offset = "0x2DF90D8", VA = "0x2DF90D8")]
	public void \u05C8\u05BFࠁف()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x0600211B RID: 8475 RVA: 0x000AF9EC File Offset: 0x000ADBEC
	[Token(Token = "0x600211B")]
	[Address(RVA = "0x2DF9134", Offset = "0x2DF9134", VA = "0x2DF9134")]
	public void ۵Յ\u0591ژ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 1L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x0600211C RID: 8476 RVA: 0x000AFAE0 File Offset: 0x000ADCE0
	[Token(Token = "0x600211C")]
	[Address(RVA = "0x2DF9240", Offset = "0x2DF9240", VA = "0x2DF9240")]
	public void ԝڄ\u0616Ս()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		long num = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x0600211D RID: 8477 RVA: 0x000AFBE0 File Offset: 0x000ADDE0
	[Token(Token = "0x600211D")]
	[Address(RVA = "0x2DF9350", Offset = "0x2DF9350", VA = "0x2DF9350")]
	public void \u081Dڵޕ\u0658()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ3 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x0600211E RID: 8478 RVA: 0x000AFD30 File Offset: 0x000ADF30
	[Token(Token = "0x600211E")]
	[Address(RVA = "0x2DF96D0", Offset = "0x2DF96D0", VA = "0x2DF96D0")]
	public void ٽҽ\u0882կ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x0600211F RID: 8479 RVA: 0x000AFE24 File Offset: 0x000AE024
	[Token(Token = "0x600211F")]
	[Address(RVA = "0x2DF97DC", Offset = "0x2DF97DC", VA = "0x2DF97DC")]
	[PunRPC]
	public void StartGamemode()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		long num = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002120 RID: 8480 RVA: 0x000AFF24 File Offset: 0x000AE124
	[Token(Token = "0x6002120")]
	[Address(RVA = "0x2DF98EC", Offset = "0x2DF98EC", VA = "0x2DF98EC")]
	public void ւࡂ\u0883\u0872()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x06002121 RID: 8481 RVA: 0x000B0060 File Offset: 0x000AE260
	[Token(Token = "0x6002121")]
	[Address(RVA = "0x2DF9C58", Offset = "0x2DF9C58", VA = "0x2DF9C58")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002122 RID: 8482 RVA: 0x000B00C8 File Offset: 0x000AE2C8
	[Token(Token = "0x6002122")]
	[Address(RVA = "0x2DF9E10", Offset = "0x2DF9E10", VA = "0x2DF9E10")]
	public RisingLavaButton()
	{
	}

	// Token: 0x06002123 RID: 8483 RVA: 0x000B00E8 File Offset: 0x000AE2E8
	[Token(Token = "0x6002123")]
	[Address(RVA = "0x2DF9E20", Offset = "0x2DF9E20", VA = "0x2DF9E20")]
	public void ࢶ٠\u086D\u0708()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ != null)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ3 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x06002124 RID: 8484 RVA: 0x000B0234 File Offset: 0x000AE434
	[Token(Token = "0x6002124")]
	[Address(RVA = "0x2DFA1AC", Offset = "0x2DFA1AC", VA = "0x2DFA1AC")]
	public void \u07FD\u0816ۑ\u06DA()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002125 RID: 8485 RVA: 0x000B0328 File Offset: 0x000AE528
	[Token(Token = "0x6002125")]
	[Address(RVA = "0x2DFA2B8", Offset = "0x2DFA2B8", VA = "0x2DFA2B8")]
	public void ࢶ\u066CԐ\u059E()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		long isKinematic2 = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic2 != 0L);
	}

	// Token: 0x06002126 RID: 8486 RVA: 0x000B0370 File Offset: 0x000AE570
	[Token(Token = "0x6002126")]
	[Address(RVA = "0x2DFA3C8", Offset = "0x2DFA3C8", VA = "0x2DFA3C8")]
	public void ࡀڮӌߕ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x06002127 RID: 8487 RVA: 0x000B049C File Offset: 0x000AE69C
	[Token(Token = "0x6002127")]
	[Address(RVA = "0x2DFA738", Offset = "0x2DFA738", VA = "0x2DFA738")]
	public void יԠ\u07EDԺ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x06002128 RID: 8488 RVA: 0x000B05D0 File Offset: 0x000AE7D0
	[Token(Token = "0x6002128")]
	[Address(RVA = "0x2DFAAA4", Offset = "0x2DFAAA4", VA = "0x2DFAAA4")]
	public void ࡎ\u05C2սࠇ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002129 RID: 8489 RVA: 0x000B05EC File Offset: 0x000AE7EC
	[Token(Token = "0x6002129")]
	[Address(RVA = "0x2DFAB00", Offset = "0x2DFAB00", VA = "0x2DFAB00")]
	public void ٴݵۃ\u05AF()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ3 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x0600212A RID: 8490 RVA: 0x000B0714 File Offset: 0x000AE914
	[Token(Token = "0x600212A")]
	[Address(RVA = "0x2DFAE88", Offset = "0x2DFAE88", VA = "0x2DFAE88")]
	public void ԛ\u0701\u0593Ӻ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		long isKinematic2 = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic2 != 0L);
	}

	// Token: 0x0600212B RID: 8491 RVA: 0x000B075C File Offset: 0x000AE95C
	[Token(Token = "0x600212B")]
	[Address(RVA = "0x2DFAF94", Offset = "0x2DFAF94", VA = "0x2DFAF94")]
	public void \u0882\u055C\u0888ߥ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x0600212C RID: 8492 RVA: 0x000B0888 File Offset: 0x000AEA88
	[Token(Token = "0x600212C")]
	[Address(RVA = "0x2DFB2FC", Offset = "0x2DFB2FC", VA = "0x2DFB2FC")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600212D RID: 8493 RVA: 0x000B08E8 File Offset: 0x000AEAE8
	[Token(Token = "0x600212D")]
	[Address(RVA = "0x2DFB4B4", Offset = "0x2DFB4B4", VA = "0x2DFB4B4")]
	public void \u060DԠԔڇ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x0600212E RID: 8494 RVA: 0x000B09DC File Offset: 0x000AEBDC
	[Token(Token = "0x600212E")]
	[Address(RVA = "0x2DFB5C0", Offset = "0x2DFB5C0", VA = "0x2DFB5C0")]
	public void քӆ٨ڰ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x0600212F RID: 8495 RVA: 0x000B0B18 File Offset: 0x000AED18
	[Token(Token = "0x600212F")]
	[Address(RVA = "0x2DFB92C", Offset = "0x2DFB92C", VA = "0x2DFB92C")]
	public void \u05BBٵݼڨ()
	{
		TextMeshPro ڄن_u0826ה;
		this.ڄن\u0826ה = ڄن_u0826ה;
	}

	// Token: 0x06002130 RID: 8496 RVA: 0x000B0B2C File Offset: 0x000AED2C
	[Token(Token = "0x6002130")]
	[Address(RVA = "0x2DFB988", Offset = "0x2DFB988", VA = "0x2DFB988")]
	public void \u070Fߨ\u05B0ۈ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002131 RID: 8497 RVA: 0x000B0B48 File Offset: 0x000AED48
	[Token(Token = "0x6002131")]
	[Address(RVA = "0x2DFB9E4", Offset = "0x2DFB9E4", VA = "0x2DFB9E4")]
	public void ݍ\u05F4ߓ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ChangeToTagged";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002132 RID: 8498 RVA: 0x000B0BB0 File Offset: 0x000AEDB0
	[Token(Token = "0x6002132")]
	[Address(RVA = "0x2DFBB9C", Offset = "0x2DFBB9C", VA = "0x2DFBB9C")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002133 RID: 8499 RVA: 0x000B0C18 File Offset: 0x000AEE18
	[Token(Token = "0x6002133")]
	[Address(RVA = "0x2DFBD54", Offset = "0x2DFBD54", VA = "0x2DFBD54")]
	public void ܫ\u070Fۃ\u07F2()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x06002134 RID: 8500 RVA: 0x000B0D60 File Offset: 0x000AEF60
	[Token(Token = "0x6002134")]
	[Address(RVA = "0x2DFC0C0", Offset = "0x2DFC0C0", VA = "0x2DFC0C0")]
	public void \u0614ࢥӴ\u086C()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ2.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ3 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x06002135 RID: 8501 RVA: 0x000B0EA4 File Offset: 0x000AF0A4
	[Token(Token = "0x6002135")]
	[Address(RVA = "0x2DFC448", Offset = "0x2DFC448", VA = "0x2DFC448")]
	public void ޝԖ\u0836\u06D8()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002136 RID: 8502 RVA: 0x000B0EC0 File Offset: 0x000AF0C0
	[Token(Token = "0x6002136")]
	[Address(RVA = "0x2DFC4A4", Offset = "0x2DFC4A4", VA = "0x2DFC4A4")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "StartSong";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002137 RID: 8503 RVA: 0x000B0F28 File Offset: 0x000AF128
	[Token(Token = "0x6002137")]
	[Address(RVA = "0x2DFC65C", Offset = "0x2DFC65C", VA = "0x2DFC65C")]
	public void \u060B\u073Aԯ\u0557()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		long enabled6 = 1L;
		طܦտ_u05A2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 1L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002138 RID: 8504 RVA: 0x000B1014 File Offset: 0x000AF214
	[Token(Token = "0x6002138")]
	[Address(RVA = "0x2DFC768", Offset = "0x2DFC768", VA = "0x2DFC768")]
	public void حتݻ\u05B0()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002139 RID: 8505 RVA: 0x000B1030 File Offset: 0x000AF230
	[Token(Token = "0x6002139")]
	[Address(RVA = "0x2DFC7C4", Offset = "0x2DFC7C4", VA = "0x2DFC7C4")]
	public void \u073DӦ۵\u07F0()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x0600213A RID: 8506 RVA: 0x000B104C File Offset: 0x000AF24C
	[Token(Token = "0x600213A")]
	[Address(RVA = "0x2DFC820", Offset = "0x2DFC820", VA = "0x2DFC820")]
	public void ڹޱ\u0605\u065A()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 1L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 0L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 0L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
	}

	// Token: 0x0600213B RID: 8507 RVA: 0x000B1130 File Offset: 0x000AF330
	[Token(Token = "0x600213B")]
	[Address(RVA = "0x2DFC92C", Offset = "0x2DFC92C", VA = "0x2DFC92C")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "clickLol";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600213C RID: 8508 RVA: 0x000B1198 File Offset: 0x000AF398
	[Token(Token = "0x600213C")]
	[Address(RVA = "0x2DFCAE4", Offset = "0x2DFCAE4", VA = "0x2DFCAE4")]
	public void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Name Changing Error. Error: ";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600213D RID: 8509 RVA: 0x000B11F0 File Offset: 0x000AF3F0
	[Token(Token = "0x600213D")]
	[Address(RVA = "0x2DFCC9C", Offset = "0x2DFCC9C", VA = "0x2DFCC9C")]
	public void \u0825ӆا\u07BE()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x0600213E RID: 8510 RVA: 0x000B120C File Offset: 0x000AF40C
	[Token(Token = "0x600213E")]
	[Address(RVA = "0x2DFCCF8", Offset = "0x2DFCCF8", VA = "0x2DFCCF8")]
	public void ފԅ\u0881ݾ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Add/Remove Glasses";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600213F RID: 8511 RVA: 0x000B1274 File Offset: 0x000AF474
	[Token(Token = "0x600213F")]
	[Address(RVA = "0x2DFCEB0", Offset = "0x2DFCEB0", VA = "0x2DFCEB0")]
	public void ԥש\u0838ֆ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002140 RID: 8512 RVA: 0x000B1290 File Offset: 0x000AF490
	[Token(Token = "0x6002140")]
	[Address(RVA = "0x2DFCF0C", Offset = "0x2DFCF0C", VA = "0x2DFCF0C")]
	public void څࡣڐ\u0657()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
		BoxCollider ࠀ_u05CEࡆټ2 = this.ࠀ\u05CEࡆټ;
	}

	// Token: 0x06002141 RID: 8513 RVA: 0x000B13D0 File Offset: 0x000AF5D0
	[Token(Token = "0x6002141")]
	[Address(RVA = "0x2DFD25C", Offset = "0x2DFD25C", VA = "0x2DFD25C")]
	public void قӮևݛ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002142 RID: 8514 RVA: 0x000B13EC File Offset: 0x000AF5EC
	[Token(Token = "0x6002142")]
	[Address(RVA = "0x2DFD2B8", Offset = "0x2DFD2B8", VA = "0x2DFD2B8")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "True";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002143 RID: 8515 RVA: 0x000B1454 File Offset: 0x000AF654
	[Token(Token = "0x6002143")]
	[Address(RVA = "0x2DFD470", Offset = "0x2DFD470", VA = "0x2DFD470")]
	public void ۲ڂ\u05B1ڨ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002144 RID: 8516 RVA: 0x000B1470 File Offset: 0x000AF670
	[Token(Token = "0x6002144")]
	[Address(RVA = "0x2DFD4CC", Offset = "0x2DFD4CC", VA = "0x2DFD4CC")]
	public void \u0882צ\u0821\u05B4()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002145 RID: 8517 RVA: 0x000B148C File Offset: 0x000AF68C
	[Token(Token = "0x6002145")]
	[Address(RVA = "0x2DFD528", Offset = "0x2DFD528", VA = "0x2DFD528")]
	public void \u066A\u059Eټ\u085A()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002146 RID: 8518 RVA: 0x000B14A8 File Offset: 0x000AF6A8
	[Token(Token = "0x6002146")]
	[Address(RVA = "0x2DFD584", Offset = "0x2DFD584", VA = "0x2DFD584")]
	public void \u05AD\u0881ࡆݡ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002147 RID: 8519 RVA: 0x000B1500 File Offset: 0x000AF700
	[Token(Token = "0x6002147")]
	[Address(RVA = "0x2DFD73C", Offset = "0x2DFD73C", VA = "0x2DFD73C")]
	public void \u05FD\u06E1\u064Cԕ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == " hours. You were banned because of ";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002148 RID: 8520 RVA: 0x000B1568 File Offset: 0x000AF768
	[Token(Token = "0x6002148")]
	[Address(RVA = "0x2DFD8F4", Offset = "0x2DFD8F4", VA = "0x2DFD8F4")]
	public void \u066Dӝߏآ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x06002149 RID: 8521 RVA: 0x000B1584 File Offset: 0x000AF784
	[Token(Token = "0x6002149")]
	[Address(RVA = "0x2DFD950", Offset = "0x2DFD950", VA = "0x2DFD950")]
	public void ۋ\u060Fࡍم()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x0600214A RID: 8522 RVA: 0x000B15A0 File Offset: 0x000AF7A0
	[Token(Token = "0x600214A")]
	[Address(RVA = "0x2DFD9AC", Offset = "0x2DFD9AC", VA = "0x2DFD9AC")]
	public void \u07B4րࢨڝ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 1L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 0L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 1L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 1L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		long num = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		this.שߟ٥ܭ = (num != 0L);
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 1L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x0600214B RID: 8523 RVA: 0x000B16A0 File Offset: 0x000AF8A0
	[Token(Token = "0x600214B")]
	[Address(RVA = "0x2DFDABC", Offset = "0x2DFDABC", VA = "0x2DFDABC")]
	public void ڍ\u058Bݗࡣ()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x0600214C RID: 8524 RVA: 0x000B16BC File Offset: 0x000AF8BC
	[Token(Token = "0x600214C")]
	[Address(RVA = "0x2DFDB18", Offset = "0x2DFDB18", VA = "0x2DFDB18")]
	public void \u07B7ߤޟ\u058F()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.ڄن\u0826ה = componentInChildren;
	}

	// Token: 0x0600214D RID: 8525 RVA: 0x000B16D8 File Offset: 0x000AF8D8
	[Token(Token = "0x600214D")]
	[Address(RVA = "0x2DFDB74", Offset = "0x2DFDB74", VA = "0x2DFDB74")]
	public void ܙ\u061E\u05C8Ԥ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600214E RID: 8526 RVA: 0x000B1740 File Offset: 0x000AF940
	[Token(Token = "0x600214E")]
	[Address(RVA = "0x2DFDD2C", Offset = "0x2DFDD2C", VA = "0x2DFDD2C")]
	public void \u061B\u05EEوۈ()
	{
		if (!true)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		TextMeshPro ڄن_u0826ה = this.ڄن\u0826ה;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		TextMeshPro ڄن_u0826ה2 = this.ڄن\u0826ה;
	}

	// Token: 0x0600214F RID: 8527 RVA: 0x000B1880 File Offset: 0x000AFA80
	[Token(Token = "0x600214F")]
	[Address(RVA = "0x2DFE080", Offset = "0x2DFE080", VA = "0x2DFE080")]
	public void ޝ\u08B5فڨ()
	{
		Rigidbody հ_u066Aߝ_u = this.Հ\u066Aߝ\u0829;
		long isKinematic = 0L;
		հ_u066Aߝ_u.isKinematic = (isKinematic != 0L);
		SphereCollider ע_u0707ࡩբ = this.ע\u0707ࡩբ;
		long enabled = 1L;
		ע_u0707ࡩբ.enabled = (enabled != 0L);
		SphereCollider طܦտ_u05A = this.طܦտ\u05A0;
		long enabled2 = 0L;
		طܦտ_u05A.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.ڣܨݜ۷;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider ע_u0707ࡩբ2 = this.ע\u0707ࡩբ;
		long enabled4 = 0L;
		ע_u0707ࡩբ2.enabled = (enabled4 != 0L);
		SphereCollider طܦտ_u05A2 = this.طܦտ\u05A0;
		long enabled5 = 0L;
		طܦտ_u05A2.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.ڣܨݜ۷;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody հ_u066Aߝ_u2 = this.Հ\u066Aߝ\u0829;
		long isKinematic2 = 1L;
		հ_u066Aߝ_u2.isKinematic = (isKinematic2 != 0L);
		GameObject ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		long active = 1L;
		ل_u0826_u0703_u055E.SetActive(active != 0L);
		BoxCollider ࠀ_u05CEࡆټ = this.ࠀ\u05CEࡆټ;
		long enabled7 = 0L;
		ࠀ_u05CEࡆټ.enabled = (enabled7 != 0L);
		this.ڶց\u0605\u0879.Play();
		GameObject gameObject = this.ݨӨӜک;
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x06002150 RID: 8528 RVA: 0x000B1974 File Offset: 0x000AFB74
	[Token(Token = "0x6002150")]
	[Address(RVA = "0x2DFE18C", Offset = "0x2DFE18C", VA = "0x2DFE18C")]
	public void ބՅ١\u082D()
	{
		TextMeshPro ڄن_u0826ה;
		this.ڄن\u0826ה = ڄن_u0826ה;
	}

	// Token: 0x06002151 RID: 8529 RVA: 0x000B1988 File Offset: 0x000AFB88
	[Token(Token = "0x6002151")]
	[Address(RVA = "0x2DFE1E8", Offset = "0x2DFE1E8", VA = "0x2DFE1E8")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		AudioSource حف_u05C2ߞ = this.حف\u05C2ߞ;
		AudioClip u05CCܪ_u0888_u05B = this.\u05CCܪ\u0888\u05B0;
		حف_u05C2ߞ.clip = u05CCܪ_u0888_u05B;
		this.حف\u05C2ߞ.Play();
		if (this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0400043A RID: 1082
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400043A")]
	public GameObject ل\u0826\u0703\u055E;

	// Token: 0x0400043B RID: 1083
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400043B")]
	public float \u05CDԤۯҿ = (float)17174;

	// Token: 0x0400043C RID: 1084
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400043C")]
	public Transform \u081B\u070Aߢࡁ;

	// Token: 0x0400043D RID: 1085
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400043D")]
	public Transform ڿ\u058Aکܪ;

	// Token: 0x0400043E RID: 1086
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400043E")]
	public bool שߟ٥ܭ;

	// Token: 0x0400043F RID: 1087
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400043F")]
	public TextMeshPro ڄن\u0826ה;

	// Token: 0x04000440 RID: 1088
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000440")]
	public BoxCollider ࠀ\u05CEࡆټ;

	// Token: 0x04000441 RID: 1089
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000441")]
	public Rigidbody Հ\u066Aߝ\u0829;

	// Token: 0x04000442 RID: 1090
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000442")]
	public CapsuleCollider ڣܨݜ۷;

	// Token: 0x04000443 RID: 1091
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000443")]
	public SphereCollider ע\u0707ࡩբ;

	// Token: 0x04000444 RID: 1092
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000444")]
	public SphereCollider طܦտ\u05A0;

	// Token: 0x04000445 RID: 1093
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000445")]
	public GameObject ݨӨӜک;

	// Token: 0x04000446 RID: 1094
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000446")]
	public AudioSource حف\u05C2ߞ;

	// Token: 0x04000447 RID: 1095
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4000447")]
	public AudioClip ࠄԄ\u060Aߪ;

	// Token: 0x04000448 RID: 1096
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x4000448")]
	public AudioClip \u05CCܪ\u0888\u05B0;

	// Token: 0x04000449 RID: 1097
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x4000449")]
	public AudioSource ڶց\u0605\u0879;

	// Token: 0x0400044A RID: 1098
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x400044A")]
	public NetworkPlayerSpawner ߨאߨػ;

	// Token: 0x0400044B RID: 1099
	[FieldOffset(Offset = "0xA0")]
	[Token(Token = "0x400044B")]
	public PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x0400044C RID: 1100
	[FieldOffset(Offset = "0xA8")]
	[Token(Token = "0x400044C")]
	private PhotonView ߅\u089C\u087BӞ;

	// Token: 0x0400044D RID: 1101
	[FieldOffset(Offset = "0xB0")]
	[Token(Token = "0x400044D")]
	[SerializeField]
	[Header("Lerp")]
	private float lerpSpeed;
}
