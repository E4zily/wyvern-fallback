﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000AC RID: 172
[Token(Token = "0x20000AC")]
public class DisableFingerColliders : MonoBehaviour
{
	// Token: 0x0600199C RID: 6556 RVA: 0x0008A628 File Offset: 0x00088828
	[Token(Token = "0x600199C")]
	[Address(RVA = "0x28A6BBC", Offset = "0x28A6BBC", VA = "0x28A6BBC")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 1L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 1L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x0600199D RID: 6557 RVA: 0x0008A684 File Offset: 0x00088884
	[Token(Token = "0x600199D")]
	[Address(RVA = "0x28A6C2C", Offset = "0x28A6C2C", VA = "0x28A6C2C")]
	private void Ҽ\u08B5ځ\u0658()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 1L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 1L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x0600199E RID: 6558 RVA: 0x0008A6E0 File Offset: 0x000888E0
	[Token(Token = "0x600199E")]
	[Address(RVA = "0x28A6C9C", Offset = "0x28A6C9C", VA = "0x28A6C9C")]
	private void \u087BӦןݩ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		long active = 1L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x0600199F RID: 6559 RVA: 0x0008A71C File Offset: 0x0008891C
	[Token(Token = "0x600199F")]
	[Address(RVA = "0x28A6CE8", Offset = "0x28A6CE8", VA = "0x28A6CE8")]
	private void ٴݵۃ\u05AF()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019A0 RID: 6560 RVA: 0x0008A768 File Offset: 0x00088968
	[Token(Token = "0x60019A0")]
	[Address(RVA = "0x28A6D44", Offset = "0x28A6D44", VA = "0x28A6D44")]
	private void ժ\u065Dԯࡘ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
	}

	// Token: 0x060019A1 RID: 6561 RVA: 0x0008A7C4 File Offset: 0x000889C4
	[Token(Token = "0x60019A1")]
	[Address(RVA = "0x28A6DB4", Offset = "0x28A6DB4", VA = "0x28A6DB4")]
	private void Ӣ\u0592ߨׯ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 0L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 1L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019A2 RID: 6562 RVA: 0x0008A820 File Offset: 0x00088A20
	[Token(Token = "0x60019A2")]
	[Address(RVA = "0x28A6E24", Offset = "0x28A6E24", VA = "0x28A6E24")]
	private void \u0599ږࠆ\u065F()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019A3 RID: 6563 RVA: 0x0008A85C File Offset: 0x00088A5C
	[Token(Token = "0x60019A3")]
	[Address(RVA = "0x28A6E70", Offset = "0x28A6E70", VA = "0x28A6E70")]
	private void \u0732ڙԒࢺ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 0L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 0L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019A4 RID: 6564 RVA: 0x0008A8B8 File Offset: 0x00088AB8
	[Token(Token = "0x60019A4")]
	[Address(RVA = "0x28A6EE0", Offset = "0x28A6EE0", VA = "0x28A6EE0")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 1L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 1L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019A5 RID: 6565 RVA: 0x0008A914 File Offset: 0x00088B14
	[Token(Token = "0x60019A5")]
	[Address(RVA = "0x28A6F50", Offset = "0x28A6F50", VA = "0x28A6F50")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019A6 RID: 6566 RVA: 0x0008A95C File Offset: 0x00088B5C
	[Token(Token = "0x60019A6")]
	[Address(RVA = "0x28A6FAC", Offset = "0x28A6FAC", VA = "0x28A6FAC")]
	private void \u0881ݗӟ\u07BD()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 0L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 1L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019A7 RID: 6567 RVA: 0x0008A9B8 File Offset: 0x00088BB8
	[Token(Token = "0x60019A7")]
	[Address(RVA = "0x28A701C", Offset = "0x28A701C", VA = "0x28A701C")]
	private void Update()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 1L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 0L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019A8 RID: 6568 RVA: 0x0008AA14 File Offset: 0x00088C14
	[Token(Token = "0x60019A8")]
	[Address(RVA = "0x28A708C", Offset = "0x28A708C", VA = "0x28A708C")]
	private void \u0821\u059Fӕ\u0607()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019A9 RID: 6569 RVA: 0x0008AA5C File Offset: 0x00088C5C
	[Token(Token = "0x60019A9")]
	[Address(RVA = "0x28A70E8", Offset = "0x28A70E8", VA = "0x28A70E8")]
	private void \u05F8ݑ\u06ECߞ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 0L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 1L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019AA RID: 6570 RVA: 0x0008AAB8 File Offset: 0x00088CB8
	[Token(Token = "0x60019AA")]
	[Address(RVA = "0x28A7158", Offset = "0x28A7158", VA = "0x28A7158")]
	private void \u05F7ԝߠӱ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 1L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 1L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019AB RID: 6571 RVA: 0x0008AB14 File Offset: 0x00088D14
	[Token(Token = "0x60019AB")]
	[Address(RVA = "0x28A71C8", Offset = "0x28A71C8", VA = "0x28A71C8")]
	private void \u07FE\u0882Զ\u066D()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 0L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 0L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019AC RID: 6572 RVA: 0x0008AB70 File Offset: 0x00088D70
	[Token(Token = "0x60019AC")]
	[Address(RVA = "0x28A7238", Offset = "0x28A7238", VA = "0x28A7238")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long active = 1L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019AD RID: 6573 RVA: 0x0008ABBC File Offset: 0x00088DBC
	[Token(Token = "0x60019AD")]
	[Address(RVA = "0x28A7294", Offset = "0x28A7294", VA = "0x28A7294")]
	private void ࢫ\u0876չՍ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019AE RID: 6574 RVA: 0x0008AC04 File Offset: 0x00088E04
	[Token(Token = "0x60019AE")]
	[Address(RVA = "0x28A72F0", Offset = "0x28A72F0", VA = "0x28A72F0")]
	private void ں٢ࡡ\u05EC()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 0L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 1L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019AF RID: 6575 RVA: 0x0008AC60 File Offset: 0x00088E60
	[Token(Token = "0x60019AF")]
	[Address(RVA = "0x28A7360", Offset = "0x28A7360", VA = "0x28A7360")]
	private void ژךՈ\u0597()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019B0 RID: 6576 RVA: 0x0008ACAC File Offset: 0x00088EAC
	[Token(Token = "0x60019B0")]
	[Address(RVA = "0x28A73BC", Offset = "0x28A73BC", VA = "0x28A73BC")]
	private void څࡣڐ\u0657()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019B1 RID: 6577 RVA: 0x0008ACE8 File Offset: 0x00088EE8
	[Token(Token = "0x60019B1")]
	[Address(RVA = "0x28A7408", Offset = "0x28A7408", VA = "0x28A7408")]
	private void \u0654ޛ\u07FAذ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019B2 RID: 6578 RVA: 0x0008AD34 File Offset: 0x00088F34
	[Token(Token = "0x60019B2")]
	[Address(RVA = "0x28A7464", Offset = "0x28A7464", VA = "0x28A7464")]
	private void ӻӒݝ߃()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 1L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 0L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019B3 RID: 6579 RVA: 0x0008AD90 File Offset: 0x00088F90
	[Token(Token = "0x60019B3")]
	[Address(RVA = "0x28A74D4", Offset = "0x28A74D4", VA = "0x28A74D4")]
	private void \u061B\u05EEوۈ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019B4 RID: 6580 RVA: 0x0008ADD8 File Offset: 0x00088FD8
	[Token(Token = "0x60019B4")]
	[Address(RVA = "0x28A7530", Offset = "0x28A7530", VA = "0x28A7530")]
	private void \u0886Ҽ\u058Dߛ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019B5 RID: 6581 RVA: 0x0008AE24 File Offset: 0x00089024
	[Token(Token = "0x60019B5")]
	[Address(RVA = "0x28A758C", Offset = "0x28A758C", VA = "0x28A758C")]
	public DisableFingerColliders()
	{
	}

	// Token: 0x060019B6 RID: 6582 RVA: 0x0008AE38 File Offset: 0x00089038
	[Token(Token = "0x60019B6")]
	[Address(RVA = "0x28A7594", Offset = "0x28A7594", VA = "0x28A7594")]
	private void ԣԭՋࠏ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019B7 RID: 6583 RVA: 0x0008AE80 File Offset: 0x00089080
	[Token(Token = "0x60019B7")]
	[Address(RVA = "0x28A75F0", Offset = "0x28A75F0", VA = "0x28A75F0")]
	private void ڃրӢԖ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 0L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 0L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019B8 RID: 6584 RVA: 0x0008AEDC File Offset: 0x000890DC
	[Token(Token = "0x60019B8")]
	[Address(RVA = "0x28A7660", Offset = "0x28A7660", VA = "0x28A7660")]
	private void ԟ\u086Cޣ\u055E()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019B9 RID: 6585 RVA: 0x0008AF18 File Offset: 0x00089118
	[Token(Token = "0x60019B9")]
	[Address(RVA = "0x28A76AC", Offset = "0x28A76AC", VA = "0x28A76AC")]
	private void \u0838ӆڛӑ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019BA RID: 6586 RVA: 0x0008AF64 File Offset: 0x00089164
	[Token(Token = "0x60019BA")]
	[Address(RVA = "0x28A7708", Offset = "0x28A7708", VA = "0x28A7708")]
	private void \u05EDց\u081Cت()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 1L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 1L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019BB RID: 6587 RVA: 0x0008AFC0 File Offset: 0x000891C0
	[Token(Token = "0x60019BB")]
	[Address(RVA = "0x28A7778", Offset = "0x28A7778", VA = "0x28A7778")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019BC RID: 6588 RVA: 0x0008AFFC File Offset: 0x000891FC
	[Token(Token = "0x60019BC")]
	[Address(RVA = "0x28A77C4", Offset = "0x28A77C4", VA = "0x28A77C4")]
	private void ފՖߢ\u059B()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019BD RID: 6589 RVA: 0x0008B044 File Offset: 0x00089244
	[Token(Token = "0x60019BD")]
	[Address(RVA = "0x28A7820", Offset = "0x28A7820", VA = "0x28A7820")]
	private void ւࡂ\u0883\u0872()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2;
		if (<IsMine>k__BackingField)
		{
			active2 = 0L;
			return;
		}
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019BE RID: 6590 RVA: 0x0008B090 File Offset: 0x00089290
	[Token(Token = "0x60019BE")]
	[Address(RVA = "0x28A787C", Offset = "0x28A787C", VA = "0x28A787C")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019BF RID: 6591 RVA: 0x0008B0DC File Offset: 0x000892DC
	[Token(Token = "0x60019BF")]
	[Address(RVA = "0x28A78D8", Offset = "0x28A78D8", VA = "0x28A78D8")]
	private void Ҿࢹؼס()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active = 0L;
		ԩݽ_u05C8ݾ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active2 = 1L;
		ԩݽ_u05C8ݾ2.SetActive(active2 != 0L);
	}

	// Token: 0x060019C0 RID: 6592 RVA: 0x0008B12C File Offset: 0x0008932C
	[Token(Token = "0x60019C0")]
	[Address(RVA = "0x28A7948", Offset = "0x28A7948", VA = "0x28A7948")]
	private void \u070Aәޣے()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 1L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019C1 RID: 6593 RVA: 0x0008B174 File Offset: 0x00089374
	[Token(Token = "0x60019C1")]
	[Address(RVA = "0x28A79A4", Offset = "0x28A79A4", VA = "0x28A79A4")]
	private void طӏܙࢺ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		long active = 1L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019C2 RID: 6594 RVA: 0x0008B1B0 File Offset: 0x000893B0
	[Token(Token = "0x60019C2")]
	[Address(RVA = "0x28A79F0", Offset = "0x28A79F0", VA = "0x28A79F0")]
	private void \u0614ࢥӴ\u086C()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x060019C3 RID: 6595 RVA: 0x0008B1F8 File Offset: 0x000893F8
	[Token(Token = "0x60019C3")]
	[Address(RVA = "0x28A7A4C", Offset = "0x28A7A4C", VA = "0x28A7A4C")]
	private void ڑߒجވ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		GameObject ԩݽ_u05C8ݾ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long active = 1L;
			ԇݠ_u0897Ӽ.SetActive(active != 0L);
			ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
			return;
		}
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
		GameObject ԩݽ_u05C8ݾ2 = this.Ԩݽ\u05C8ݾ;
		long active3 = 0L;
		ԩݽ_u05C8ݾ2.SetActive(active3 != 0L);
	}

	// Token: 0x060019C4 RID: 6596 RVA: 0x0008B254 File Offset: 0x00089454
	[Token(Token = "0x60019C4")]
	[Address(RVA = "0x28A7ABC", Offset = "0x28A7ABC", VA = "0x28A7ABC")]
	private void צ\u0874ڵ\u059A()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ԇݠ_u0897Ӽ = this.ԇݠ\u0897Ӽ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		ԇݠ_u0897Ӽ.SetActive(active != 0L);
		GameObject ԩݽ_u05C8ݾ = this.Ԩݽ\u05C8ݾ;
		long active2 = 0L;
		ԩݽ_u05C8ݾ.SetActive(active2 != 0L);
	}

	// Token: 0x04000324 RID: 804
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000324")]
	public PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x04000325 RID: 805
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000325")]
	public GameObject ԇݠ\u0897Ӽ;

	// Token: 0x04000326 RID: 806
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000326")]
	public GameObject Ԩݽ\u05C8ݾ;
}
