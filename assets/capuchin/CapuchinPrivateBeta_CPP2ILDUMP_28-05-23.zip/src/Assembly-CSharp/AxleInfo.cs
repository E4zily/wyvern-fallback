﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000FC RID: 252
[Token(Token = "0x20000FC")]
[Serializable]
public class AxleInfo
{
	// Token: 0x06002730 RID: 10032 RVA: 0x000E4B9C File Offset: 0x000E2D9C
	[Token(Token = "0x6002730")]
	[Address(RVA = "0x2A5392C", Offset = "0x2A5392C", VA = "0x2A5392C")]
	public AxleInfo()
	{
	}

	// Token: 0x040004F1 RID: 1265
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40004F1")]
	public WheelCollider leftWheel;

	// Token: 0x040004F2 RID: 1266
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004F2")]
	public WheelCollider rightWheel;

	// Token: 0x040004F3 RID: 1267
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004F3")]
	public bool motor;

	// Token: 0x040004F4 RID: 1268
	[FieldOffset(Offset = "0x21")]
	[Token(Token = "0x40004F4")]
	public bool steering;
}
