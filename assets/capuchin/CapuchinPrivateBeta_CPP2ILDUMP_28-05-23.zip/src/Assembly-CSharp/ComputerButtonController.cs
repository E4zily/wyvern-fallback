﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using PlayFab.ClientModels;
using TMPro;
using UnityEngine;

// Token: 0x020000A6 RID: 166
[Token(Token = "0x20000A6")]
public class ComputerButtonController : BirbButton
{
	// Token: 0x060018F3 RID: 6387 RVA: 0x000884EC File Offset: 0x000866EC
	[Token(Token = "0x60018F3")]
	[Address(RVA = "0x29335A4", Offset = "0x29335A4", VA = "0x29335A4")]
	public void Start()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.\u061Aոԕע = component;
		string[] ۂԪ_u0701պ = this.ۂԪ\u0701պ;
		string[] ݕ_u0833ժӉ = this.ݕ\u0833ժӉ;
		int num;
		string str = num.ToString();
		long minInclusive = 1L;
		int maxExclusive = 1000;
		string str2 = UnityEngine.Random.Range((int)minInclusive, maxExclusive).ToString();
		string u05AD_u0892_u083B_u081C = str + str2;
		this.\u05AD\u0892\u083B\u081C = u05AD_u0892_u083B_u081C;
		IntPtr cachedPtr = this.m_CachedPtr;
		TextMeshPro u082Fޡࡥࡦ;
		this.\u082Fޡࡥࡦ = u082Fޡࡥࡦ;
	}

	// Token: 0x060018F4 RID: 6388 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018F4")]
	[Address(RVA = "0x29336D8", Offset = "0x29336D8", VA = "0x29336D8")]
	public void \u05ABݿࡋ\u06E9()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018F5 RID: 6389 RVA: 0x00088568 File Offset: 0x00086768
	[Token(Token = "0x60018F5")]
	[Address(RVA = "0x293380C", Offset = "0x293380C", VA = "0x293380C")]
	public void וࡪךӧ()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.\u061Aոԕע = component;
		string[] ۂԪ_u0701պ = this.ۂԪ\u0701պ;
		string[] ݕ_u0833ժӉ = this.ݕ\u0833ժӉ;
		int num;
		string str = num.ToString();
		long minInclusive = 1L;
		long maxExclusive = 62L;
		string str2 = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive).ToString();
		string u05AD_u0892_u083B_u081C = str + str2;
		this.\u05AD\u0892\u083B\u081C = u05AD_u0892_u083B_u081C;
		IntPtr cachedPtr = this.m_CachedPtr;
		TextMeshPro u082Fޡࡥࡦ;
		this.\u082Fޡࡥࡦ = u082Fޡࡥࡦ;
	}

	// Token: 0x060018F6 RID: 6390 RVA: 0x000885E0 File Offset: 0x000867E0
	[Token(Token = "0x60018F6")]
	[Address(RVA = "0x2933940", Offset = "0x2933940", VA = "0x2933940")]
	public ComputerButtonController()
	{
	}

	// Token: 0x060018F7 RID: 6391 RVA: 0x000885F4 File Offset: 0x000867F4
	[Token(Token = "0x60018F7")]
	[Address(RVA = "0x2933948", Offset = "0x2933948", VA = "0x2933948")]
	private IEnumerator ԓܝ\u0604ߕ()
	{
		long <>1__state;
		ComputerButtonController.ӌ\u0703\u0889\u05C2 ӌ_u0703_u0889_u05C = new ComputerButtonController.ӌ\u0703\u0889\u05C2((int)<>1__state);
		<>1__state = 1L;
		ӌ_u0703_u0889_u05C.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018F8 RID: 6392 RVA: 0x00088618 File Offset: 0x00086818
	[Token(Token = "0x60018F8")]
	[Address(RVA = "0x29339C0", Offset = "0x29339C0", VA = "0x29339C0")]
	private void \u05A7ڦ\u0700ޤ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		Coroutine coroutine = base.StartCoroutine("sound play play");
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		TextMeshPro u082Fޡࡥࡦ = this.\u082Fޡࡥࡦ;
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x060018F9 RID: 6393 RVA: 0x00088660 File Offset: 0x00086860
	[Token(Token = "0x60018F9")]
	[Address(RVA = "0x2933B30", Offset = "0x2933B30", VA = "0x2933B30")]
	public void ࢧӾڈց()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.\u061Aոԕע = component;
		string[] ۂԪ_u0701պ = this.ۂԪ\u0701պ;
		string[] ݕ_u0833ժӉ = this.ݕ\u0833ժӉ;
		int num;
		string str = num.ToString();
		long minInclusive = 1L;
		int maxExclusive = 117;
		string str2 = UnityEngine.Random.Range((int)minInclusive, maxExclusive).ToString();
		string u05AD_u0892_u083B_u081C = str + str2;
		this.\u05AD\u0892\u083B\u081C = u05AD_u0892_u083B_u081C;
		IntPtr cachedPtr = this.m_CachedPtr;
		TextMeshPro u082Fޡࡥࡦ;
		this.\u082Fޡࡥࡦ = u082Fޡࡥࡦ;
	}

	// Token: 0x060018FA RID: 6394 RVA: 0x000886D8 File Offset: 0x000868D8
	[Token(Token = "0x60018FA")]
	[Address(RVA = "0x2933C64", Offset = "0x2933C64", VA = "0x2933C64")]
	[CompilerGenerated]
	private void \u0596ӎӶܤ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		Coroutine coroutine = base.StartCoroutine("ֻࢦۅդ");
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		TextMeshPro u082Fޡࡥࡦ = this.\u082Fޡࡥࡦ;
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x060018FB RID: 6395 RVA: 0x00088720 File Offset: 0x00086920
	[Token(Token = "0x60018FB")]
	[Address(RVA = "0x2933DC0", Offset = "0x2933DC0", VA = "0x2933DC0")]
	public void ࡅݐ\u082Dք()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.\u061Aոԕע = component;
		string[] ۂԪ_u0701պ = this.ۂԪ\u0701պ;
		string[] ݕ_u0833ժӉ = this.ݕ\u0833ժӉ;
		long maxExclusive = 0L;
		int num;
		string str = num.ToString();
		string str2 = UnityEngine.Random.Range(1, (int)maxExclusive).ToString();
		string u05AD_u0892_u083B_u081C = str + str2;
		this.\u05AD\u0892\u083B\u081C = u05AD_u0892_u083B_u081C;
		IntPtr cachedPtr = this.m_CachedPtr;
		TextMeshPro u082Fޡࡥࡦ;
		this.\u082Fޡࡥࡦ = u082Fޡࡥࡦ;
	}

	// Token: 0x060018FC RID: 6396 RVA: 0x00088794 File Offset: 0x00086994
	[Token(Token = "0x60018FC")]
	[Address(RVA = "0x2933EF4", Offset = "0x2933EF4", VA = "0x2933EF4")]
	private IEnumerator \u05BBࢦۅդ()
	{
		long <>1__state;
		ComputerButtonController.ӌ\u0703\u0889\u05C2 ӌ_u0703_u0889_u05C = new ComputerButtonController.ӌ\u0703\u0889\u05C2((int)<>1__state);
		<>1__state = 0L;
		ӌ_u0703_u0889_u05C.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018FD RID: 6397 RVA: 0x000887B8 File Offset: 0x000869B8
	[Token(Token = "0x60018FD")]
	[Address(RVA = "0x2933F6C", Offset = "0x2933F6C", VA = "0x2933F6C")]
	public void ޡࠅ\u089Aߔ()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.\u061Aոԕע = component;
		string[] ۂԪ_u0701պ = this.ۂԪ\u0701պ;
		string[] ݕ_u0833ժӉ = this.ݕ\u0833ժӉ;
		int num;
		string str = num.ToString();
		int maxExclusive = 68;
		string str2 = UnityEngine.Random.Range(0, maxExclusive).ToString();
		string u05AD_u0892_u083B_u081C = str + str2;
		this.\u05AD\u0892\u083B\u081C = u05AD_u0892_u083B_u081C;
		IntPtr cachedPtr = this.m_CachedPtr;
		TextMeshPro u082Fޡࡥࡦ;
		this.\u082Fޡࡥࡦ = u082Fޡࡥࡦ;
	}

	// Token: 0x060018FE RID: 6398 RVA: 0x0008882C File Offset: 0x00086A2C
	[Token(Token = "0x60018FE")]
	[Address(RVA = "0x29340A0", Offset = "0x29340A0", VA = "0x29340A0")]
	public void \u0558ݕݤݮ()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.\u061Aոԕע = component;
		string[] ۂԪ_u0701պ = this.ۂԪ\u0701պ;
		string[] ݕ_u0833ժӉ = this.ݕ\u0833ժӉ;
		int num;
		string str = num.ToString();
		int maxExclusive = 148;
		string str2 = UnityEngine.Random.Range(0, maxExclusive).ToString();
		string u05AD_u0892_u083B_u081C = str + str2;
		this.\u05AD\u0892\u083B\u081C = u05AD_u0892_u083B_u081C;
		IntPtr cachedPtr = this.m_CachedPtr;
		TextMeshPro u082Fޡࡥࡦ;
		this.\u082Fޡࡥࡦ = u082Fޡࡥࡦ;
	}

	// Token: 0x060018FF RID: 6399 RVA: 0x000888A4 File Offset: 0x00086AA4
	[Token(Token = "0x60018FF")]
	[Address(RVA = "0x29341D4", Offset = "0x29341D4", VA = "0x29341D4")]
	private void ٧ڎդݙ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		Coroutine coroutine = base.StartCoroutine("true");
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		TextMeshPro u082Fޡࡥࡦ = this.\u082Fޡࡥࡦ;
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001900 RID: 6400 RVA: 0x000888EC File Offset: 0x00086AEC
	[Token(Token = "0x6001900")]
	[Address(RVA = "0x2934344", Offset = "0x2934344", VA = "0x2934344")]
	private IEnumerator ࡂ\u05C5٩ڲ()
	{
		long <>1__state;
		ComputerButtonController.ӌ\u0703\u0889\u05C2 ӌ_u0703_u0889_u05C = new ComputerButtonController.ӌ\u0703\u0889\u05C2((int)<>1__state);
		<>1__state = 0L;
		ӌ_u0703_u0889_u05C.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001901 RID: 6401 RVA: 0x00088910 File Offset: 0x00086B10
	[Token(Token = "0x6001901")]
	[Address(RVA = "0x29343BC", Offset = "0x29343BC", VA = "0x29343BC")]
	private void ࢮێԙࠏ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		Coroutine coroutine = base.StartCoroutine("BN");
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		TextMeshPro u082Fޡࡥࡦ = this.\u082Fޡࡥࡦ;
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001902 RID: 6402 RVA: 0x00088958 File Offset: 0x00086B58
	[Token(Token = "0x6001902")]
	[Address(RVA = "0x293452C", Offset = "0x293452C", VA = "0x293452C", Slot = "28")]
	public override void \u0557\u0654ل\u0652(bool \u089Bݼۄ\u0875)
	{
		if (this.ګ\u060Cө\u0885)
		{
			IntPtr cachedPtr = this.ࢫ\u087F\u088A\u06DD.m_CachedPtr;
			TextMeshPro ࢫ_u087F_u088A_u06DD = this.ࢫ\u087F\u088A\u06DD;
			string ә۴_u0605Ӳ = this.Ә۴\u0605Ӳ;
			return;
		}
		if (this.ܦژԫ\u05FC)
		{
			if (this.ࢫ\u087F\u088A\u06DD != null)
			{
				if (typeof(PhotonNetwork).TypeHandle == null)
				{
				}
				Player localPlayer = PhotonNetwork.LocalPlayer;
				TextMeshPro ࢫ_u087F_u088A_u06DD2 = this.ࢫ\u087F\u088A\u06DD;
				TextMeshPro ࢫ_u087F_u088A_u06DD3 = this.ࢫ\u087F\u088A\u06DD;
				UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
				string @string = PlayerPrefs.GetString("username");
				updateUserTitleDisplayNameRequest.DisplayName = @string;
				if (typeof(UpdateUserTitleDisplayNameRequest).TypeHandle == null)
				{
				}
				if ("username" == null)
				{
					Action<UpdateUserTitleDisplayNameResult> <>9__15_;
					ComputerButtonController.<>c.<>9__15_2 = <>9__15_;
				}
				return;
			}
			TextMeshPro ࢫ_u087F_u088A_u06DD4;
			bool skipLayoutUpdate = ࢫ_u087F_u088A_u06DD4.m_SkipLayoutUpdate;
			bool vertsDirty = ࢫ_u087F_u088A_u06DD4.m_VertsDirty;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			Player localPlayer2 = PhotonNetwork.LocalPlayer;
			bool vertsDirty2 = ࢫ_u087F_u088A_u06DD4.m_VertsDirty;
			bool vertsDirty3 = ࢫ_u087F_u088A_u06DD4.m_VertsDirty;
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest2 = new UpdateUserTitleDisplayNameRequest();
			string string2 = PlayerPrefs.GetString("username");
			updateUserTitleDisplayNameRequest2.DisplayName = string2;
			if (typeof(UpdateUserTitleDisplayNameRequest).TypeHandle == null)
			{
			}
			if (ComputerButtonController.<>c.<>9__15_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__15_2;
				ComputerButtonController.<>c.<>9__15_0 = <>9__15_2;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
			return;
		}
		else
		{
			if (this.߈\u07EFڇԖ)
			{
				TextMeshPro ࢫ_u087F_u088A_u06DD4 = this.ࢫ\u087F\u088A\u06DD;
				IntPtr cachedPtr2 = this.ࢫ\u087F\u088A\u06DD.m_CachedPtr;
				return;
			}
			return;
		}
	}

	// Token: 0x06001903 RID: 6403 RVA: 0x00088A9C File Offset: 0x00086C9C
	[Token(Token = "0x6001903")]
	[Address(RVA = "0x2934AB4", Offset = "0x2934AB4", VA = "0x2934AB4")]
	private void \u085Cࠌ\u07BEڼ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		Coroutine coroutine = base.StartCoroutine("FingerTip");
	}

	// Token: 0x06001904 RID: 6404 RVA: 0x00088AE0 File Offset: 0x00086CE0
	[Token(Token = "0x6001904")]
	[Address(RVA = "0x2934C24", Offset = "0x2934C24", VA = "0x2934C24")]
	private void ڥݑٱ\u07FB(PlayFabError ہ\u0613ܢ\u07B4)
	{
		Coroutine coroutine = base.StartCoroutine("Player");
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		TextMeshPro u082Fޡࡥࡦ = this.\u082Fޡࡥࡦ;
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001905 RID: 6405 RVA: 0x00088B28 File Offset: 0x00086D28
	[Token(Token = "0x6001905")]
	[Address(RVA = "0x2934D94", Offset = "0x2934D94", VA = "0x2934D94")]
	[CompilerGenerated]
	private void Իړࠓܤ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		Coroutine coroutine = base.StartCoroutine("ֻࢦۅդ");
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		TextMeshPro u082Fޡࡥࡦ = this.\u082Fޡࡥࡦ;
		if (ہ\u0613ܢ\u07B4 != null)
		{
			return;
		}
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06001906 RID: 6406 RVA: 0x00088B70 File Offset: 0x00086D70
	[Token(Token = "0x6001906")]
	[Address(RVA = "0x2934EF0", Offset = "0x2934EF0", VA = "0x2934EF0")]
	public void \u086Bԍࡊڭ()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.\u061Aոԕע = component;
		string[] ۂԪ_u0701պ = this.ۂԪ\u0701պ;
		string[] ݕ_u0833ժӉ = this.ݕ\u0833ժӉ;
		int num;
		string str = num.ToString();
		long minInclusive = 1L;
		int maxExclusive = 171;
		string str2 = UnityEngine.Random.Range((int)minInclusive, maxExclusive).ToString();
		string u05AD_u0892_u083B_u081C = str + str2;
		this.\u05AD\u0892\u083B\u081C = u05AD_u0892_u083B_u081C;
		IntPtr cachedPtr = this.m_CachedPtr;
		TextMeshPro u082Fޡࡥࡦ;
		this.\u082Fޡࡥࡦ = u082Fޡࡥࡦ;
	}

	// Token: 0x0400030D RID: 781
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400030D")]
	public string گاԵ٧;

	// Token: 0x0400030E RID: 782
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400030E")]
	public GameObject ۯ\u07B3ۀߊ;

	// Token: 0x0400030F RID: 783
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400030F")]
	public TextMeshPro ࢫ\u087F\u088A\u06DD;

	// Token: 0x04000310 RID: 784
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000310")]
	public bool ګ\u060Cө\u0885;

	// Token: 0x04000311 RID: 785
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000311")]
	public string Ә۴\u0605Ӳ;

	// Token: 0x04000312 RID: 786
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000312")]
	public bool ܦژԫ\u05FC;

	// Token: 0x04000313 RID: 787
	[FieldOffset(Offset = "0x49")]
	[Token(Token = "0x4000313")]
	public bool ߈\u07EFڇԖ;

	// Token: 0x04000314 RID: 788
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000314")]
	public string[] ۂԪ\u0701պ;

	// Token: 0x04000315 RID: 789
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000315")]
	public string[] ݕ\u0833ժӉ;

	// Token: 0x04000316 RID: 790
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000316")]
	public string \u05AD\u0892\u083B\u081C;

	// Token: 0x04000317 RID: 791
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000317")]
	private BoxCollider \u061Aոԕע;

	// Token: 0x04000318 RID: 792
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000318")]
	public GameObject ڹࢰիڛ;

	// Token: 0x04000319 RID: 793
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000319")]
	public TextMeshPro \u082Fޡࡥࡦ;
}
