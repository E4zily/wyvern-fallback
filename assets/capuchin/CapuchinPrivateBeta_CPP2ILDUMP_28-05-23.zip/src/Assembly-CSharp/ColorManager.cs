﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;

// Token: 0x0200004F RID: 79
[Token(Token = "0x200004F")]
public class ColorManager : MonoBehaviourPunCallbacks
{
	// Token: 0x06000B0A RID: 2826 RVA: 0x0003B31C File Offset: 0x0003951C
	[Token(Token = "0x6000B0A")]
	[Address(RVA = "0x292AE2C", Offset = "0x292AE2C", VA = "0x292AE2C")]
	public void ߈\u05ADڮ\u0889()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Regular");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Regular" != null)
		{
		}
	}

	// Token: 0x06000B0B RID: 2827 RVA: 0x0003B358 File Offset: 0x00039558
	[Token(Token = "0x6000B0B")]
	[Address(RVA = "0x292B064", Offset = "0x292B064", VA = "0x292B064")]
	private void ފՖߢ\u059B()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B0C RID: 2828 RVA: 0x0003B3DC File Offset: 0x000395DC
	[Token(Token = "0x6000B0C")]
	[Address(RVA = "0x292B204", Offset = "0x292B204", VA = "0x292B204")]
	private void ڈՓ\u0652\u0871()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B0D RID: 2829 RVA: 0x0003B460 File Offset: 0x00039660
	[Token(Token = "0x6000B0D")]
	[Address(RVA = "0x292B3A8", Offset = "0x292B3A8", VA = "0x292B3A8")]
	private void ԛژ\u0817\u058C()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B0E RID: 2830 RVA: 0x0003B4A0 File Offset: 0x000396A0
	[Token(Token = "0x6000B0E")]
	[Address(RVA = "0x292B4A0", Offset = "0x292B4A0", VA = "0x292B4A0")]
	private void \u05AC\u07F0\u07EEࡥ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B0F RID: 2831 RVA: 0x0003B524 File Offset: 0x00039724
	[Token(Token = "0x6000B0F")]
	[Address(RVA = "0x292B644", Offset = "0x292B644", VA = "0x292B644")]
	private void ڍ\u058Bݗࡣ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B10 RID: 2832 RVA: 0x0003B564 File Offset: 0x00039764
	[Token(Token = "0x6000B10")]
	[Address(RVA = "0x292B73C", Offset = "0x292B73C", VA = "0x292B73C")]
	private void \u05F7ԝߠӱ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B11 RID: 2833 RVA: 0x0003B5D0 File Offset: 0x000397D0
	[Token(Token = "0x6000B11")]
	[Address(RVA = "0x292B8DC", Offset = "0x292B8DC", VA = "0x292B8DC")]
	public ColorManager()
	{
		float[] u06ED_u06D8_u060B_u = new float[3];
		this.\u06ED\u06D8\u060B\u0832 = u06ED_u06D8_u060B_u;
		base..ctor();
	}

	// Token: 0x06000B12 RID: 2834 RVA: 0x0003B5F4 File Offset: 0x000397F4
	[Token(Token = "0x6000B12")]
	[Address(RVA = "0x292B944", Offset = "0x292B944", VA = "0x292B944")]
	private void ٴݵۃ\u05AF()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B13 RID: 2835 RVA: 0x0003B678 File Offset: 0x00039878
	[Token(Token = "0x6000B13")]
	[Address(RVA = "0x292BAE8", Offset = "0x292BAE8", VA = "0x292BAE8")]
	private void ݞߒࢸڢ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B14 RID: 2836 RVA: 0x0003B6FC File Offset: 0x000398FC
	[Token(Token = "0x6000B14")]
	[Address(RVA = "0x292BC88", Offset = "0x292BC88", VA = "0x292BC88", Slot = "41")]
	public override void OnJoinedRoom()
	{
		base.OnJoinedRoom();
	}

	// Token: 0x06000B15 RID: 2837 RVA: 0x0003B710 File Offset: 0x00039910
	[Token(Token = "0x6000B15")]
	[Address(RVA = "0x2929574", Offset = "0x2929574", VA = "0x2929574")]
	public void ࢯӆԑہ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("TurnAmount");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("TurnAmount" != null)
		{
		}
	}

	// Token: 0x06000B16 RID: 2838 RVA: 0x0003B74C File Offset: 0x0003994C
	[Token(Token = "0x6000B16")]
	[Address(RVA = "0x292BCE8", Offset = "0x292BCE8", VA = "0x292BCE8")]
	private void ڦکӁ\u06E2()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B17 RID: 2839 RVA: 0x0003B7C8 File Offset: 0x000399C8
	[Token(Token = "0x6000B17")]
	[Address(RVA = "0x292BE8C", Offset = "0x292BE8C", VA = "0x292BE8C")]
	private void ࢳ\u088E٠ݪ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B18 RID: 2840 RVA: 0x0003B800 File Offset: 0x00039A00
	[Token(Token = "0x6000B18")]
	[Address(RVA = "0x2927C50", Offset = "0x2927C50", VA = "0x2927C50")]
	public void ڲ\u0592\u07F7ك()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("duration done");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("duration done" != null)
		{
		}
	}

	// Token: 0x06000B19 RID: 2841 RVA: 0x0003B83C File Offset: 0x00039A3C
	[Token(Token = "0x6000B19")]
	[Address(RVA = "0x29252FC", Offset = "0x29252FC", VA = "0x29252FC")]
	public void Ӡ\u0836٥\u060F()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("hand 1");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("hand 1" != null)
		{
		}
	}

	// Token: 0x06000B1A RID: 2842 RVA: 0x0003B878 File Offset: 0x00039A78
	[Token(Token = "0x6000B1A")]
	[Address(RVA = "0x292A7D4", Offset = "0x292A7D4", VA = "0x292A7D4")]
	public void ԥӜک\u059A()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Add/Remove Sword");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Add/Remove Sword" != null)
		{
		}
	}

	// Token: 0x06000B1B RID: 2843 RVA: 0x0003B8B4 File Offset: 0x00039AB4
	[Token(Token = "0x6000B1B")]
	[Address(RVA = "0x292BF80", Offset = "0x292BF80", VA = "0x292BF80")]
	private void վࡌڬ\u0591()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		throw new MissingMethodException();
	}

	// Token: 0x06000B1C RID: 2844 RVA: 0x0003B8F4 File Offset: 0x00039AF4
	[Token(Token = "0x6000B1C")]
	[Address(RVA = "0x29286EC", Offset = "0x29286EC", VA = "0x29286EC")]
	public void \u085AҼӓߦ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("TurnAmount");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("TurnAmount" != null)
		{
		}
	}

	// Token: 0x06000B1D RID: 2845 RVA: 0x0003B930 File Offset: 0x00039B30
	[Token(Token = "0x6000B1D")]
	[Address(RVA = "0x2927878", Offset = "0x2927878", VA = "0x2927878")]
	public void ךئ\u05BDՂ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Add/Remove Sword");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Add/Remove Sword" != null)
		{
		}
	}

	// Token: 0x06000B1E RID: 2846 RVA: 0x0003B96C File Offset: 0x00039B6C
	[Token(Token = "0x6000B1E")]
	[Address(RVA = "0x2927350", Offset = "0x2927350", VA = "0x2927350")]
	public void Ԯ\u086Dک߁()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag(" and for the price of ");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if (" and for the price of " != null)
		{
		}
	}

	// Token: 0x06000B1F RID: 2847 RVA: 0x0003B9A8 File Offset: 0x00039BA8
	[Token(Token = "0x6000B1F")]
	[Address(RVA = "0x292676C", Offset = "0x292676C", VA = "0x292676C")]
	public void \u05EEܓԘӰ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("HOLY MOLY THE STICK IS ON FIRE!!!!!!");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("HOLY MOLY THE STICK IS ON FIRE!!!!!!" != null)
		{
		}
	}

	// Token: 0x06000B20 RID: 2848 RVA: 0x0003B9E4 File Offset: 0x00039BE4
	[Token(Token = "0x6000B20")]
	[Address(RVA = "0x292C074", Offset = "0x292C074", VA = "0x292C074")]
	private void Update()
	{
		TMP_Text tmp_Text = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B21 RID: 2849 RVA: 0x0003BA58 File Offset: 0x00039C58
	[Token(Token = "0x6000B21")]
	[Address(RVA = "0x292C20C", Offset = "0x292C20C", VA = "0x292C20C")]
	private void ہݕ\u07EFԒ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B22 RID: 2850 RVA: 0x0003BADC File Offset: 0x00039CDC
	[Token(Token = "0x6000B22")]
	[Address(RVA = "0x292C3AC", Offset = "0x292C3AC", VA = "0x292C3AC")]
	private void \u086Bԍࡊڭ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B23 RID: 2851 RVA: 0x0003BB1C File Offset: 0x00039D1C
	[Token(Token = "0x6000B23")]
	[Address(RVA = "0x2926F70", Offset = "0x2926F70", VA = "0x2926F70")]
	public void ނը\u0732\u0558()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Player");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Player" != null)
		{
		}
	}

	// Token: 0x06000B24 RID: 2852 RVA: 0x0003BB58 File Offset: 0x00039D58
	[Token(Token = "0x6000B24")]
	[Address(RVA = "0x292C4A4", Offset = "0x292C4A4", VA = "0x292C4A4")]
	private void ןٮ\u061FԺ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B25 RID: 2853 RVA: 0x0003BB98 File Offset: 0x00039D98
	[Token(Token = "0x6000B25")]
	[Address(RVA = "0x292C59C", Offset = "0x292C59C", VA = "0x292C59C")]
	private void ࢫ\u0876չՍ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B26 RID: 2854 RVA: 0x0003BC1C File Offset: 0x00039E1C
	[Token(Token = "0x6000B26")]
	[Address(RVA = "0x292C73C", Offset = "0x292C73C", VA = "0x292C73C")]
	private void Ԉ۴ࡉࢬ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B27 RID: 2855 RVA: 0x0003BCA0 File Offset: 0x00039EA0
	[Token(Token = "0x6000B27")]
	[Address(RVA = "0x292C8DC", Offset = "0x292C8DC", VA = "0x292C8DC")]
	private void ࡩݮڢՠ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B28 RID: 2856 RVA: 0x0003BCE0 File Offset: 0x00039EE0
	[Token(Token = "0x6000B28")]
	[Address(RVA = "0x292C9D4", Offset = "0x292C9D4", VA = "0x292C9D4")]
	private void \u05BBٵݼڨ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B29 RID: 2857 RVA: 0x0003BD20 File Offset: 0x00039F20
	[Token(Token = "0x6000B29")]
	[Address(RVA = "0x2925538", Offset = "0x2925538", VA = "0x2925538")]
	public void ޚئ\u089Bܖ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("TurnAmount");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("TurnAmount" != null)
		{
		}
	}

	// Token: 0x06000B2A RID: 2858 RVA: 0x0003BD5C File Offset: 0x00039F5C
	[Token(Token = "0x6000B2A")]
	[Address(RVA = "0x2928B00", Offset = "0x2928B00", VA = "0x2928B00")]
	public void ԩسӦ\u0611()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag(" hours. You were banned because of ");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if (" hours. You were banned because of " != null)
		{
		}
	}

	// Token: 0x06000B2B RID: 2859 RVA: 0x0003BD98 File Offset: 0x00039F98
	[Token(Token = "0x6000B2B")]
	[Address(RVA = "0x2924CE0", Offset = "0x2924CE0", VA = "0x2924CE0")]
	public void գޠӾԲ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Purchase For ");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Purchase For " != null)
		{
		}
	}

	// Token: 0x06000B2C RID: 2860 RVA: 0x0003BDD4 File Offset: 0x00039FD4
	[Token(Token = "0x6000B2C")]
	[Address(RVA = "0x292CAC8", Offset = "0x292CAC8", VA = "0x292CAC8")]
	private void ࢨػքߞ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B2D RID: 2861 RVA: 0x0003BE14 File Offset: 0x0003A014
	[Token(Token = "0x6000B2D")]
	[Address(RVA = "0x292CBBC", Offset = "0x292CBBC", VA = "0x292CBBC")]
	private void ࠐߪތԜ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B2E RID: 2862 RVA: 0x0003BE54 File Offset: 0x0003A054
	[Token(Token = "0x6000B2E")]
	[Address(RVA = "0x292CCB0", Offset = "0x292CCB0", VA = "0x292CCB0")]
	private void \u070Fߨ\u05B0ۈ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B2F RID: 2863 RVA: 0x0003BE8C File Offset: 0x0003A08C
	[Token(Token = "0x6000B2F")]
	[Address(RVA = "0x292CDA4", Offset = "0x292CDA4", VA = "0x292CDA4")]
	private void ԞԌ\u086FՇ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B30 RID: 2864 RVA: 0x0003BEC4 File Offset: 0x0003A0C4
	[Token(Token = "0x6000B30")]
	[Address(RVA = "0x292CE98", Offset = "0x292CE98", VA = "0x292CE98")]
	private void \u0896\u06FE\u0602ӯ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B31 RID: 2865 RVA: 0x0003BF04 File Offset: 0x0003A104
	[Token(Token = "0x6000B31")]
	[Address(RVA = "0x292CF8C", Offset = "0x292CF8C", VA = "0x292CF8C")]
	private void \u060AԨصݚ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B32 RID: 2866 RVA: 0x0003BF70 File Offset: 0x0003A170
	[Token(Token = "0x6000B32")]
	[Address(RVA = "0x292D12C", Offset = "0x292D12C", VA = "0x292D12C")]
	private void \u070Aәޣے()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B33 RID: 2867 RVA: 0x0003BFF4 File Offset: 0x0003A1F4
	[Token(Token = "0x6000B33")]
	[Address(RVA = "0x2925B5C", Offset = "0x2925B5C", VA = "0x2925B5C")]
	public void ءۄڥࢣ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("DisableCosmetic");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("DisableCosmetic" != null)
		{
		}
	}

	// Token: 0x06000B34 RID: 2868 RVA: 0x0003C030 File Offset: 0x0003A230
	[Token(Token = "0x6000B34")]
	[Address(RVA = "0x292D2C4", Offset = "0x292D2C4", VA = "0x292D2C4")]
	private void ո\u07AA\u05BDࠕ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B35 RID: 2869 RVA: 0x0003C0B4 File Offset: 0x0003A2B4
	[Token(Token = "0x6000B35")]
	[Address(RVA = "0x2924AEC", Offset = "0x2924AEC", VA = "0x2924AEC")]
	public void Ӏ\u07B4إ\u082A()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("FingerTip");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("FingerTip" != null)
		{
		}
	}

	// Token: 0x06000B36 RID: 2870 RVA: 0x0003C0F0 File Offset: 0x0003A2F0
	[Token(Token = "0x6000B36")]
	[Address(RVA = "0x292D468", Offset = "0x292D468", VA = "0x292D468")]
	public void \u0859ԛ߇\u07EE()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("NoseAttachPoint");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
	}

	// Token: 0x06000B37 RID: 2871 RVA: 0x0003C124 File Offset: 0x0003A324
	[Token(Token = "0x6000B37")]
	[Address(RVA = "0x2926D94", Offset = "0x2926D94", VA = "0x2926D94")]
	public void բҼم\u086F()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("FingerTip");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("FingerTip" != null)
		{
		}
	}

	// Token: 0x06000B38 RID: 2872 RVA: 0x0003C160 File Offset: 0x0003A360
	[Token(Token = "0x6000B38")]
	[Address(RVA = "0x292D5AC", Offset = "0x292D5AC", VA = "0x292D5AC")]
	private void ࡢض\u07ACנ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B39 RID: 2873 RVA: 0x0003C198 File Offset: 0x0003A398
	[Token(Token = "0x6000B39")]
	[Address(RVA = "0x292D69C", Offset = "0x292D69C", VA = "0x292D69C")]
	private void ߊ\u066A\u05CFԉ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B3A RID: 2874 RVA: 0x0003C21C File Offset: 0x0003A41C
	[Token(Token = "0x6000B3A")]
	[Address(RVA = "0x292D838", Offset = "0x292D838", VA = "0x292D838")]
	public void \u06E3\u05A7\u05ECࡆ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("FingerTip");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("FingerTip" != null)
		{
		}
	}

	// Token: 0x06000B3B RID: 2875 RVA: 0x0003C258 File Offset: 0x0003A458
	[Token(Token = "0x6000B3B")]
	[Address(RVA = "0x292D950", Offset = "0x292D950", VA = "0x292D950")]
	private void ڛ٩ރ\u0706()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B3C RID: 2876 RVA: 0x0003C298 File Offset: 0x0003A498
	[Token(Token = "0x6000B3C")]
	[Address(RVA = "0x2924294", Offset = "0x2924294", VA = "0x2924294")]
	public void כ\u0702ݬ\u07F4()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Damaged Arm");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Damaged Arm" != null)
		{
		}
	}

	// Token: 0x06000B3D RID: 2877 RVA: 0x0003C2D4 File Offset: 0x0003A4D4
	[Token(Token = "0x6000B3D")]
	[Address(RVA = "0x29293A4", Offset = "0x29293A4", VA = "0x29293A4")]
	public void ࠃ\u05F5ٸ\u05F4()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("_Tint");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("_Tint" != null)
		{
		}
	}

	// Token: 0x06000B3E RID: 2878 RVA: 0x0003C310 File Offset: 0x0003A510
	[Token(Token = "0x6000B3E")]
	[Address(RVA = "0x292DA48", Offset = "0x292DA48", VA = "0x292DA48")]
	private void \u0733ߜܣԻ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B3F RID: 2879 RVA: 0x0003C350 File Offset: 0x0003A550
	[Token(Token = "0x6000B3F")]
	[Address(RVA = "0x2926960", Offset = "0x2926960", VA = "0x2926960")]
	public void ݮ\u05B0\u0608ڹ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("HandL");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("HandL" != null)
		{
		}
	}

	// Token: 0x06000B40 RID: 2880 RVA: 0x0003C38C File Offset: 0x0003A58C
	[Token(Token = "0x6000B40")]
	[Address(RVA = "0x292DB40", Offset = "0x292DB40", VA = "0x292DB40")]
	private void \u05EDց\u081Cت()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B41 RID: 2881 RVA: 0x0003C410 File Offset: 0x0003A610
	[Token(Token = "0x6000B41")]
	[Address(RVA = "0x2926B80", Offset = "0x2926B80", VA = "0x2926B80")]
	public void \u05AD\u0640۰ԯ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("duration done");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("duration done" != null)
		{
		}
	}

	// Token: 0x06000B42 RID: 2882 RVA: 0x0003C44C File Offset: 0x0003A64C
	[Token(Token = "0x6000B42")]
	[Address(RVA = "0x292DCE0", Offset = "0x292DCE0", VA = "0x292DCE0")]
	private void ժ\u065Dԯࡘ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
	}

	// Token: 0x06000B43 RID: 2883 RVA: 0x0003C4B8 File Offset: 0x0003A6B8
	[Token(Token = "0x6000B43")]
	[Address(RVA = "0x292DE78", Offset = "0x292DE78", VA = "0x292DE78")]
	private void ڃրӢԖ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B44 RID: 2884 RVA: 0x0003C53C File Offset: 0x0003A73C
	[Token(Token = "0x6000B44")]
	[Address(RVA = "0x2923DAC", Offset = "0x2923DAC", VA = "0x2923DAC")]
	public void ԯ\u07F8ܨӔ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("ChangeToRegular");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("ChangeToRegular" != null)
		{
		}
	}

	// Token: 0x06000B45 RID: 2885 RVA: 0x0003C578 File Offset: 0x0003A778
	[Token(Token = "0x6000B45")]
	[Address(RVA = "0x292E018", Offset = "0x292E018", VA = "0x292E018")]
	private void Ҿࢹؼס()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B46 RID: 2886 RVA: 0x0003C5F4 File Offset: 0x0003A7F4
	[Token(Token = "0x6000B46")]
	[Address(RVA = "0x292E1B8", Offset = "0x292E1B8", VA = "0x292E1B8")]
	private void ݱ\u0832ݥ\u08B5()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B47 RID: 2887 RVA: 0x0003C634 File Offset: 0x0003A834
	[Token(Token = "0x6000B47")]
	[Address(RVA = "0x292E2A8", Offset = "0x292E2A8", VA = "0x292E2A8")]
	public void \u086F߂ޝࠁ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("monke screamed");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("monke screamed" != null)
		{
		}
	}

	// Token: 0x06000B48 RID: 2888 RVA: 0x0003C670 File Offset: 0x0003A870
	[Token(Token = "0x6000B48")]
	[Address(RVA = "0x292E3C4", Offset = "0x292E3C4", VA = "0x292E3C4")]
	private void ࡎ\u05C2սࠇ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B49 RID: 2889 RVA: 0x0003C6B0 File Offset: 0x0003A8B0
	[Token(Token = "0x6000B49")]
	[Address(RVA = "0x292E4B8", Offset = "0x292E4B8", VA = "0x292E4B8")]
	private void \u0817\u0704Ԏڲ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B4A RID: 2890 RVA: 0x0003C6F0 File Offset: 0x0003A8F0
	[Token(Token = "0x6000B4A")]
	[Address(RVA = "0x292E5AC", Offset = "0x292E5AC", VA = "0x292E5AC")]
	private void \u05C1ޔӃ۸()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B4B RID: 2891 RVA: 0x0003C774 File Offset: 0x0003A974
	[Token(Token = "0x6000B4B")]
	[Address(RVA = "0x292E74C", Offset = "0x292E74C", VA = "0x292E74C")]
	private void ݸԲ\u0616Ԫ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B4C RID: 2892 RVA: 0x0003C7B4 File Offset: 0x0003A9B4
	[Token(Token = "0x6000B4C")]
	[Address(RVA = "0x292E840", Offset = "0x292E840", VA = "0x292E840")]
	private void \u055Cࢯܯ\u0898()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B4D RID: 2893 RVA: 0x0003C838 File Offset: 0x0003AA38
	[Token(Token = "0x6000B4D")]
	[Address(RVA = "0x292E9E0", Offset = "0x292E9E0", VA = "0x292E9E0")]
	private void ١ۏ\u05C4ӝ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B4E RID: 2894 RVA: 0x0003C878 File Offset: 0x0003AA78
	[Token(Token = "0x6000B4E")]
	[Address(RVA = "0x2929B74", Offset = "0x2929B74", VA = "0x2929B74")]
	public void \u0832ߔܩժ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("ChangeToTagged");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("ChangeToTagged" != null)
		{
		}
	}

	// Token: 0x06000B4F RID: 2895 RVA: 0x0003C8B4 File Offset: 0x0003AAB4
	[Token(Token = "0x6000B4F")]
	[Address(RVA = "0x29248C8", Offset = "0x29248C8", VA = "0x29248C8")]
	public void ٠ԂՐڙ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("monke screamed");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("monke screamed" != null)
		{
		}
	}

	// Token: 0x06000B50 RID: 2896 RVA: 0x0003C8F0 File Offset: 0x0003AAF0
	[Token(Token = "0x6000B50")]
	[Address(RVA = "0x292EAD0", Offset = "0x292EAD0", VA = "0x292EAD0")]
	private void ࡥշӞھ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B51 RID: 2897 RVA: 0x0003C974 File Offset: 0x0003AB74
	[Token(Token = "0x6000B51")]
	[Address(RVA = "0x292890C", Offset = "0x292890C", VA = "0x292890C")]
	public void ڍޖ\u05BEڕ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Time to bake textures: ");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
	}

	// Token: 0x06000B52 RID: 2898 RVA: 0x0003C9A8 File Offset: 0x0003ABA8
	[Token(Token = "0x6000B52")]
	[Address(RVA = "0x292EC70", Offset = "0x292EC70", VA = "0x292EC70")]
	private void ޥ\u089Dڢ\u06E3()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B53 RID: 2899 RVA: 0x0003C9E8 File Offset: 0x0003ABE8
	[Token(Token = "0x6000B53")]
	[Address(RVA = "0x292ED68", Offset = "0x292ED68", VA = "0x292ED68")]
	public void ړԙ\u0603\u073A()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("MetaAuth");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("MetaAuth" != null)
		{
		}
	}

	// Token: 0x06000B54 RID: 2900 RVA: 0x0003CA24 File Offset: 0x0003AC24
	[Token(Token = "0x6000B54")]
	[Address(RVA = "0x292A0C0", Offset = "0x292A0C0", VA = "0x292A0C0")]
	public void \u0737ս\u0597\u086D()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("PlayWave");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("PlayWave" != null)
		{
		}
	}

	// Token: 0x06000B55 RID: 2901 RVA: 0x0003CA60 File Offset: 0x0003AC60
	[Token(Token = "0x6000B55")]
	[Address(RVA = "0x292EE88", Offset = "0x292EE88", VA = "0x292EE88")]
	private void \u05B3ࢹߧ\u07AA()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B56 RID: 2902 RVA: 0x0003CAE4 File Offset: 0x0003ACE4
	[Token(Token = "0x6000B56")]
	[Address(RVA = "0x292F028", Offset = "0x292F028", VA = "0x292F028")]
	private void طӏܙࢺ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B57 RID: 2903 RVA: 0x0003CB68 File Offset: 0x0003AD68
	[Token(Token = "0x6000B57")]
	[Address(RVA = "0x292F1C8", Offset = "0x292F1C8", VA = "0x292F1C8")]
	private void \u06E1ԁՈڄ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B58 RID: 2904 RVA: 0x0003CB9C File Offset: 0x0003AD9C
	[Token(Token = "0x6000B58")]
	[Address(RVA = "0x292F2B8", Offset = "0x292F2B8", VA = "0x292F2B8")]
	private void \u0881\u0743\u07EB\u0747()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B59 RID: 2905 RVA: 0x0003CBDC File Offset: 0x0003ADDC
	[Token(Token = "0x6000B59")]
	[Address(RVA = "0x2924F04", Offset = "0x2924F04", VA = "0x2924F04")]
	public void יࡓߞڦ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("got funky mone");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("got funky mone" != null)
		{
		}
	}

	// Token: 0x06000B5A RID: 2906 RVA: 0x0003CC18 File Offset: 0x0003AE18
	[Token(Token = "0x6000B5A")]
	[Address(RVA = "0x292F3B0", Offset = "0x292F3B0", VA = "0x292F3B0")]
	private void ܬԛ٣\u07FF()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B5B RID: 2907 RVA: 0x0003CC58 File Offset: 0x0003AE58
	[Token(Token = "0x6000B5B")]
	[Address(RVA = "0x292A5C0", Offset = "0x292A5C0", VA = "0x292A5C0")]
	public void \u06DAؠڿ\u0743()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Player");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Player" != null)
		{
		}
	}

	// Token: 0x06000B5C RID: 2908 RVA: 0x0003CC94 File Offset: 0x0003AE94
	[Token(Token = "0x6000B5C")]
	[Address(RVA = "0x292F4A4", Offset = "0x292F4A4", VA = "0x292F4A4")]
	private void \u073BօӁ\u059A()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B5D RID: 2909 RVA: 0x0003CCD4 File Offset: 0x0003AED4
	[Token(Token = "0x6000B5D")]
	[Address(RVA = "0x292F598", Offset = "0x292F598", VA = "0x292F598")]
	private void ٠ӄ\u087Cٸ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B5E RID: 2910 RVA: 0x0003CD58 File Offset: 0x0003AF58
	[Token(Token = "0x6000B5E")]
	[Address(RVA = "0x292F738", Offset = "0x292F738", VA = "0x292F738")]
	private void ޡࠅ\u089Aߔ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B5F RID: 2911 RVA: 0x0003CD98 File Offset: 0x0003AF98
	[Token(Token = "0x6000B5F")]
	[Address(RVA = "0x292F830", Offset = "0x292F830", VA = "0x292F830")]
	private void \u07F8ձݠߜ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B60 RID: 2912 RVA: 0x0003CDD8 File Offset: 0x0003AFD8
	[Token(Token = "0x6000B60")]
	[Address(RVA = "0x292F928", Offset = "0x292F928", VA = "0x292F928")]
	private void יԠ\u07EDԺ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B61 RID: 2913 RVA: 0x0003CE5C File Offset: 0x0003B05C
	[Token(Token = "0x6000B61")]
	[Address(RVA = "0x292FAC8", Offset = "0x292FAC8", VA = "0x292FAC8")]
	private void \u0599ږࠆ\u065F()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B62 RID: 2914 RVA: 0x0003CED8 File Offset: 0x0003B0D8
	[Token(Token = "0x6000B62")]
	[Address(RVA = "0x292718C", Offset = "0x292718C", VA = "0x292718C")]
	public void գԁܐխ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("FLSPTLT");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		PhotonView pvCache = this.pvCache;
		Material material = this.הڙࡣۼ;
		if (pvCache.<IsMine>k__BackingField)
		{
		}
		PhotonView pvCache2 = this.pvCache;
	}

	// Token: 0x06000B63 RID: 2915 RVA: 0x0003CF28 File Offset: 0x0003B128
	[Token(Token = "0x6000B63")]
	[Address(RVA = "0x292FC6C", Offset = "0x292FC6C", VA = "0x292FC6C")]
	private void פۈيݤ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B64 RID: 2916 RVA: 0x0003CFAC File Offset: 0x0003B1AC
	[Token(Token = "0x6000B64")]
	[Address(RVA = "0x292FE0C", Offset = "0x292FE0C", VA = "0x292FE0C")]
	private void ݛࠈ\u07F0ޱ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B65 RID: 2917 RVA: 0x0003CFE4 File Offset: 0x0003B1E4
	[Token(Token = "0x6000B65")]
	[Address(RVA = "0x292FF00", Offset = "0x292FF00", VA = "0x292FF00")]
	private void ۮߝڪڐ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B66 RID: 2918 RVA: 0x0003D024 File Offset: 0x0003B224
	[Token(Token = "0x6000B66")]
	[Address(RVA = "0x292FFF4", Offset = "0x292FFF4", VA = "0x292FFF4")]
	private void Ӧد\u060Eࡏ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B67 RID: 2919 RVA: 0x0003D0A8 File Offset: 0x0003B2A8
	[Token(Token = "0x6000B67")]
	[Address(RVA = "0x2928230", Offset = "0x2928230", VA = "0x2928230")]
	public void ՅӇࢧ\u05FD()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("CapuchinRemade");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("CapuchinRemade" != null)
		{
		}
	}

	// Token: 0x06000B68 RID: 2920 RVA: 0x0003D0E4 File Offset: 0x0003B2E4
	[Token(Token = "0x6000B68")]
	[Address(RVA = "0x2930198", Offset = "0x2930198", VA = "0x2930198")]
	private void \u064FӆࡒԲ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B69 RID: 2921 RVA: 0x0003D124 File Offset: 0x0003B324
	[Token(Token = "0x6000B69")]
	[Address(RVA = "0x2930290", Offset = "0x2930290", VA = "0x2930290")]
	private void عۻԂ\u055E()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B6A RID: 2922 RVA: 0x0003D164 File Offset: 0x0003B364
	[Token(Token = "0x6000B6A")]
	[Address(RVA = "0x2930380", Offset = "0x2930380", VA = "0x2930380")]
	private void ݜ\u061E\u082F\u0875()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B6B RID: 2923 RVA: 0x0003D1E8 File Offset: 0x0003B3E8
	[Token(Token = "0x6000B6B")]
	[Address(RVA = "0x2925948", Offset = "0x2925948", VA = "0x2925948")]
	public void \u05F6\u0878ݙ\u07BD()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Player");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		PhotonView pvCache = this.pvCache;
		Material material = this.הڙࡣۼ;
		if (pvCache.<IsMine>k__BackingField)
		{
		}
		PhotonView pvCache2 = this.pvCache;
	}

	// Token: 0x06000B6C RID: 2924 RVA: 0x0003D238 File Offset: 0x0003B438
	[Token(Token = "0x6000B6C")]
	[Address(RVA = "0x2930518", Offset = "0x2930518", VA = "0x2930518")]
	private void \u07EBࠎיࡂ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B6D RID: 2925 RVA: 0x0003D274 File Offset: 0x0003B474
	[Token(Token = "0x6000B6D")]
	[Address(RVA = "0x292449C", Offset = "0x292449C", VA = "0x292449C")]
	public void SetColor()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("NetworkPlayer");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("NetworkPlayer" != null)
		{
		}
	}

	// Token: 0x06000B6E RID: 2926 RVA: 0x0003D2B0 File Offset: 0x0003B4B0
	[Token(Token = "0x6000B6E")]
	[Address(RVA = "0x2928E0C", Offset = "0x2928E0C", VA = "0x2928E0C")]
	public void \u073Eݕ\u0700\u073B()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("DisableCosmetic");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("DisableCosmetic" != null)
		{
		}
	}

	// Token: 0x06000B6F RID: 2927 RVA: 0x0003D2EC File Offset: 0x0003B4EC
	[Token(Token = "0x6000B6F")]
	[Address(RVA = "0x29276B0", Offset = "0x29276B0", VA = "0x29276B0")]
	public void Քջۼװ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("hh:mmtt");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("hh:mmtt" != null)
		{
		}
	}

	// Token: 0x06000B70 RID: 2928 RVA: 0x0003D328 File Offset: 0x0003B528
	[Token(Token = "0x6000B70")]
	[Address(RVA = "0x2925F00", Offset = "0x2925F00", VA = "0x2925F00")]
	public void ژӐӽڙ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Failed to get catalog, cosmetic name, and price. Exact error details is: " != null)
		{
		}
	}

	// Token: 0x06000B71 RID: 2929 RVA: 0x0003D364 File Offset: 0x0003B564
	[Token(Token = "0x6000B71")]
	[Address(RVA = "0x29246D8", Offset = "0x29246D8", VA = "0x29246D8")]
	public void ӳܠԇߋ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("You struck apon an error. ");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("You struck apon an error. " != null)
		{
		}
	}

	// Token: 0x06000B72 RID: 2930 RVA: 0x0003D3A0 File Offset: 0x0003B5A0
	[Token(Token = "0x6000B72")]
	[Address(RVA = "0x2930608", Offset = "0x2930608", VA = "0x2930608")]
	private void ࢥ\u081CՕࡋ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B73 RID: 2931 RVA: 0x0003D3D8 File Offset: 0x0003B5D8
	[Token(Token = "0x6000B73")]
	[Address(RVA = "0x29306FC", Offset = "0x29306FC", VA = "0x29306FC")]
	private void \u0733Ԁژق()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B74 RID: 2932 RVA: 0x0003D418 File Offset: 0x0003B618
	[Token(Token = "0x6000B74")]
	[Address(RVA = "0x29307F0", Offset = "0x29307F0", VA = "0x29307F0")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
	}

	// Token: 0x06000B75 RID: 2933 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Token(Token = "0x6000B75")]
	[Address(RVA = "0x293098C", Offset = "0x293098C", VA = "0x293098C")]
	private void \u083C\u05F7ԫڙ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
	}

	// Token: 0x06000B76 RID: 2934 RVA: 0x0003D4E8 File Offset: 0x0003B6E8
	[Token(Token = "0x6000B76")]
	[Address(RVA = "0x29250E4", Offset = "0x29250E4", VA = "0x29250E4")]
	public void Ռ\u05EEߠԇ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("{0} ({1})");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("{0} ({1})" != null)
		{
		}
	}

	// Token: 0x06000B77 RID: 2935 RVA: 0x0003D524 File Offset: 0x0003B724
	[Token(Token = "0x6000B77")]
	[Address(RVA = "0x2925D24", Offset = "0x2925D24", VA = "0x2925D24")]
	public void ԝץԡ\u0822()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Room Name: ");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Room Name: " != null)
		{
		}
	}

	// Token: 0x06000B78 RID: 2936 RVA: 0x0003D560 File Offset: 0x0003B760
	[Token(Token = "0x6000B78")]
	[Address(RVA = "0x292406C", Offset = "0x292406C", VA = "0x292406C")]
	public void ܠڨލ\u0609()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Player");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Player" != null)
		{
		}
	}

	// Token: 0x06000B79 RID: 2937 RVA: 0x0003D59C File Offset: 0x0003B79C
	[Token(Token = "0x6000B79")]
	[Address(RVA = "0x29264B0", Offset = "0x29264B0", VA = "0x29264B0")]
	public void \u07BA\u083Dӡ\u0732()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("CapuchinStore");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("CapuchinStore" != null)
		{
		}
	}

	// Token: 0x06000B7A RID: 2938 RVA: 0x0003D5D8 File Offset: 0x0003B7D8
	[Token(Token = "0x6000B7A")]
	[Address(RVA = "0x2930B2C", Offset = "0x2930B2C", VA = "0x2930B2C")]
	private void گ\u085E\u073Dڊ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B7B RID: 2939 RVA: 0x0003D618 File Offset: 0x0003B818
	[Token(Token = "0x6000B7B")]
	[Address(RVA = "0x2930C20", Offset = "0x2930C20", VA = "0x2930C20")]
	private void Ԁוև\u065B()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B7C RID: 2940 RVA: 0x0003D658 File Offset: 0x0003B858
	[Token(Token = "0x6000B7C")]
	[Address(RVA = "0x2930D10", Offset = "0x2930D10", VA = "0x2930D10")]
	private void Ԡݘעࠀ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B7D RID: 2941 RVA: 0x0003D6DC File Offset: 0x0003B8DC
	[Token(Token = "0x6000B7D")]
	[Address(RVA = "0x2927E88", Offset = "0x2927E88", VA = "0x2927E88")]
	public void \u0878ݼՏ\u0707()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("QuickStatic");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("QuickStatic" != null)
		{
		}
	}

	// Token: 0x06000B7E RID: 2942 RVA: 0x0003D718 File Offset: 0x0003B918
	[Token(Token = "0x6000B7E")]
	[Address(RVA = "0x2930EB4", Offset = "0x2930EB4", VA = "0x2930EB4")]
	private void \u089Aࡆժߏ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B7F RID: 2943 RVA: 0x0003D758 File Offset: 0x0003B958
	[Token(Token = "0x6000B7F")]
	[Address(RVA = "0x2930FA8", Offset = "0x2930FA8", VA = "0x2930FA8")]
	public void Ԓײ\u061Fߜ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("TurnAmount");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("TurnAmount" != null)
		{
		}
	}

	// Token: 0x06000B80 RID: 2944 RVA: 0x0003D794 File Offset: 0x0003B994
	[Token(Token = "0x6000B80")]
	[Address(RVA = "0x29310C8", Offset = "0x29310C8", VA = "0x29310C8")]
	private void \u0830ݥ\u0896Ԕ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B81 RID: 2945 RVA: 0x0003D7D4 File Offset: 0x0003B9D4
	[Token(Token = "0x6000B81")]
	[Address(RVA = "0x29311BC", Offset = "0x29311BC", VA = "0x29311BC")]
	private void ߖհݣ߀()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B82 RID: 2946 RVA: 0x0003D814 File Offset: 0x0003BA14
	[Token(Token = "0x6000B82")]
	[Address(RVA = "0x29312AC", Offset = "0x29312AC", VA = "0x29312AC")]
	private void \u07FAۯضߙ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B83 RID: 2947 RVA: 0x0003D890 File Offset: 0x0003BA90
	[Token(Token = "0x6000B83")]
	[Address(RVA = "0x2928060", Offset = "0x2928060", VA = "0x2928060")]
	public void \u05CDڿӟҾ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("Open");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("Open" != null)
		{
		}
	}

	// Token: 0x06000B84 RID: 2948 RVA: 0x0003D8CC File Offset: 0x0003BACC
	[Token(Token = "0x6000B84")]
	[Address(RVA = "0x293144C", Offset = "0x293144C", VA = "0x293144C")]
	private void ں٢ࡡ\u05EC()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B85 RID: 2949 RVA: 0x0003D950 File Offset: 0x0003BB50
	[Token(Token = "0x6000B85")]
	[Address(RVA = "0x29315F0", Offset = "0x29315F0", VA = "0x29315F0")]
	private void \u065F\u0839ܤ\u073C()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B86 RID: 2950 RVA: 0x0003D990 File Offset: 0x0003BB90
	[Token(Token = "0x6000B86")]
	[Address(RVA = "0x29316E4", Offset = "0x29316E4", VA = "0x29316E4")]
	private void \u066Dӝߏآ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B87 RID: 2951 RVA: 0x0003D9D0 File Offset: 0x0003BBD0
	[Token(Token = "0x6000B87")]
	[Address(RVA = "0x29317D4", Offset = "0x29317D4", VA = "0x29317D4")]
	private void ބՅ١\u082D()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B88 RID: 2952 RVA: 0x0003DA10 File Offset: 0x0003BC10
	[Token(Token = "0x6000B88")]
	[Address(RVA = "0x29318C8", Offset = "0x29318C8", VA = "0x29318C8")]
	private void Վࡧ\u06FDܕ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x06000B89 RID: 2953 RVA: 0x0003DA94 File Offset: 0x0003BC94
	[Token(Token = "0x6000B89")]
	[Address(RVA = "0x2931A6C", Offset = "0x2931A6C", VA = "0x2931A6C", Slot = "42")]
	public override void OnPlayerEnteredRoom(Player \u05FB\u0610\u05F7\u065F)
	{
		base.OnPlayerEnteredRoom(\u05FB\u0610\u05F7\u065F);
	}

	// Token: 0x06000B8A RID: 2954 RVA: 0x0003DAA8 File Offset: 0x0003BCA8
	[Token(Token = "0x6000B8A")]
	[Address(RVA = "0x2931A74", Offset = "0x2931A74", VA = "0x2931A74")]
	private void ݶߔ\u081Aպ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B8B RID: 2955 RVA: 0x0003DAE4 File Offset: 0x0003BCE4
	[Token(Token = "0x6000B8B")]
	[Address(RVA = "0x2931B6C", Offset = "0x2931B6C", VA = "0x2931B6C")]
	private void ڣֆ\u07F4ڌ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B8C RID: 2956 RVA: 0x0003DB24 File Offset: 0x0003BD24
	[Token(Token = "0x6000B8C")]
	[Address(RVA = "0x2925710", Offset = "0x2925710", VA = "0x2925710")]
	public void ڠը\u0736\u055C()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("TurnAmount");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("TurnAmount" != null)
		{
		}
	}

	// Token: 0x06000B8D RID: 2957 RVA: 0x0003DB60 File Offset: 0x0003BD60
	[Token(Token = "0x6000B8D")]
	[Address(RVA = "0x2931C60", Offset = "0x2931C60", VA = "0x2931C60")]
	private void Start()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		if (typeof(ColorManager).TypeHandle != null)
		{
			float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
			float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
			return;
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x06000B8E RID: 2958 RVA: 0x0003DBA4 File Offset: 0x0003BDA4
	[Token(Token = "0x6000B8E")]
	[Address(RVA = "0x2931D3C", Offset = "0x2931D3C", VA = "0x2931D3C")]
	private void چ\u05AEךڰ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B8F RID: 2959 RVA: 0x0003DBE4 File Offset: 0x0003BDE4
	[Token(Token = "0x6000B8F")]
	[Address(RVA = "0x2931E2C", Offset = "0x2931E2C", VA = "0x2931E2C")]
	private void \u05C1ܡԘޘ()
	{
		ColorManager.ލ\u0882ײࢲ = this;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u2 = this.\u06ED\u06D8\u060B\u0832;
		float[] u06ED_u06D8_u060B_u3 = this.\u06ED\u06D8\u060B\u0832;
	}

	// Token: 0x06000B90 RID: 2960 RVA: 0x0003DC24 File Offset: 0x0003BE24
	[Token(Token = "0x6000B90")]
	[Address(RVA = "0x2926124", Offset = "0x2926124", VA = "0x2926124")]
	public void ࢢ\u0886ࢨԳ()
	{
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		GameObject[] ӈ_u0838_u07BFԻ = GameObject.FindGameObjectsWithTag("TurnAmount");
		this.ӈ\u0838\u07BFԻ = ӈ_u0838_u07BFԻ;
		if ("TurnAmount" != null)
		{
		}
	}

	// Token: 0x06000B91 RID: 2961 RVA: 0x0003DC60 File Offset: 0x0003BE60
	[Token(Token = "0x6000B91")]
	[Address(RVA = "0x2931F1C", Offset = "0x2931F1C", VA = "0x2931F1C")]
	private void \u0705\u0816\u0739դ()
	{
		TMP_Text tmp_Text = this.ࢷӠࡗࡩ;
		TMP_Text u0705مڤࠄ = this.\u0705مڤࠄ;
		TMP_Text tmp_Text2 = this.ئՑࡉӍ;
		float[] u06ED_u06D8_u060B_u = this.\u06ED\u06D8\u060B\u0832;
		Material material = this.הڙࡣۼ;
		Material ա_u0617ݺӼ = this.Ա\u0617ݺӼ;
		float r = this.ձ߃\u07BA\u06E8.r;
		float g = this.ձ߃\u07BA\u06E8.g;
		float b = this.ձ߃\u07BA\u06E8.b;
		float a = this.ձ߃\u07BA\u06E8.a;
	}

	// Token: 0x0400018F RID: 399
	[Token(Token = "0x400018F")]
	public static ColorManager ލ\u0882ײࢲ;

	// Token: 0x04000190 RID: 400
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000190")]
	private GameObject[] ӈ\u0838\u07BFԻ;

	// Token: 0x04000191 RID: 401
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000191")]
	public Material הڙࡣۼ;

	// Token: 0x04000192 RID: 402
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000192")]
	public Material Ա\u0617ݺӼ;

	// Token: 0x04000193 RID: 403
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000193")]
	public Color ձ߃\u07BA\u06E8;

	// Token: 0x04000194 RID: 404
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000194")]
	public float[] \u06ED\u06D8\u060B\u0832;

	// Token: 0x04000195 RID: 405
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000195")]
	public TMP_Text ࢷӠࡗࡩ;

	// Token: 0x04000196 RID: 406
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000196")]
	public TMP_Text \u0705مڤࠄ;

	// Token: 0x04000197 RID: 407
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000197")]
	public TMP_Text ئՑࡉӍ;

	// Token: 0x04000198 RID: 408
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000198")]
	private string \u05CBטڻݲ;

	// Token: 0x04000199 RID: 409
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000199")]
	private string ڵ\u05CFߔӖ;

	// Token: 0x0400019A RID: 410
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x400019A")]
	private string ݰԐ\u073D\u081E;
}
