﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200001F RID: 31
[Token(Token = "0x200001F")]
public class Blink : MonoBehaviour
{
	// Token: 0x060003C8 RID: 968 RVA: 0x00016BF8 File Offset: 0x00014DF8
	[Token(Token = "0x60003C8")]
	[Address(RVA = "0x2718714", Offset = "0x2718714", VA = "0x2718714")]
	public void ࡅݐ\u082Dք()
	{
		IEnumerator routine = this.\u0611ڸޤ\u0816();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003C9 RID: 969 RVA: 0x00016C20 File Offset: 0x00014E20
	[Token(Token = "0x60003C9")]
	[Address(RVA = "0x27187E0", Offset = "0x27187E0", VA = "0x27187E0")]
	public IEnumerator \u06DE\u05C6Ըس()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 1L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003CA RID: 970 RVA: 0x00016C44 File Offset: 0x00014E44
	[Token(Token = "0x60003CA")]
	[Address(RVA = "0x2718858", Offset = "0x2718858", VA = "0x2718858")]
	public void ݤۅࢦӃ()
	{
		IEnumerator routine = this.ڐޛ\u06DFۺ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003CB RID: 971 RVA: 0x00016C6C File Offset: 0x00014E6C
	[Token(Token = "0x60003CB")]
	[Address(RVA = "0x2718924", Offset = "0x2718924", VA = "0x2718924")]
	public void \u06D6ې\u083Bࠉ()
	{
		IEnumerator routine = this.ڈ\u0708Մࠎ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003CC RID: 972 RVA: 0x00016C94 File Offset: 0x00014E94
	[Token(Token = "0x60003CC")]
	[Address(RVA = "0x27189F0", Offset = "0x27189F0", VA = "0x27189F0")]
	public void וࡪךӧ()
	{
		IEnumerator routine = this.ڈ\u0708Մࠎ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003CD RID: 973 RVA: 0x00016CBC File Offset: 0x00014EBC
	[Token(Token = "0x60003CD")]
	[Address(RVA = "0x2718A44", Offset = "0x2718A44", VA = "0x2718A44")]
	public void ڍ\u058Bݗࡣ()
	{
		IEnumerator routine = this.\u083Cܨ\u087E\u0593();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003CE RID: 974 RVA: 0x00016CE4 File Offset: 0x00014EE4
	[Token(Token = "0x60003CE")]
	[Address(RVA = "0x2718B10", Offset = "0x2718B10", VA = "0x2718B10")]
	public void ࡩݮڢՠ()
	{
		IEnumerator routine = this.\u0558\u0833\u085Bډ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003CF RID: 975 RVA: 0x00016D0C File Offset: 0x00014F0C
	[Token(Token = "0x60003CF")]
	[Address(RVA = "0x2718BDC", Offset = "0x2718BDC", VA = "0x2718BDC")]
	public void \u05F6\u05A6ӓ\u06DC()
	{
		IEnumerator routine = this.\u055D\u0656סټ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003D0 RID: 976 RVA: 0x00016D30 File Offset: 0x00014F30
	[Token(Token = "0x60003D0")]
	[Address(RVA = "0x2718CA8", Offset = "0x2718CA8", VA = "0x2718CA8")]
	public IEnumerator \u07AA\u07A7ࠎߤ()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 0L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003D1 RID: 977 RVA: 0x00016D54 File Offset: 0x00014F54
	[Token(Token = "0x60003D1")]
	[Address(RVA = "0x2718B64", Offset = "0x2718B64", VA = "0x2718B64")]
	public IEnumerator \u0558\u0833\u085Bډ()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 1L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003D2 RID: 978 RVA: 0x00016D78 File Offset: 0x00014F78
	[Token(Token = "0x60003D2")]
	[Address(RVA = "0x2718D20", Offset = "0x2718D20", VA = "0x2718D20")]
	public IEnumerator ࠕո\u05CAә()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 1L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003D3 RID: 979 RVA: 0x00016D9C File Offset: 0x00014F9C
	[Token(Token = "0x60003D3")]
	[Address(RVA = "0x2718768", Offset = "0x2718768", VA = "0x2718768")]
	public IEnumerator \u0611ڸޤ\u0816()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 0L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003D4 RID: 980 RVA: 0x00016DC0 File Offset: 0x00014FC0
	[Token(Token = "0x60003D4")]
	[Address(RVA = "0x2718D98", Offset = "0x2718D98", VA = "0x2718D98")]
	public void \u082E\u06EBݼڏ()
	{
		IEnumerator routine = this.ӷ\u05BDԞ\u0824();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003D5 RID: 981 RVA: 0x00016DE8 File Offset: 0x00014FE8
	[Token(Token = "0x60003D5")]
	[Address(RVA = "0x2718DEC", Offset = "0x2718DEC", VA = "0x2718DEC")]
	public IEnumerator ӷ\u05BDԞ\u0824()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 1L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003D6 RID: 982 RVA: 0x00016E0C File Offset: 0x0001500C
	[Token(Token = "0x60003D6")]
	[Address(RVA = "0x2718E64", Offset = "0x2718E64", VA = "0x2718E64")]
	public void Start()
	{
		IEnumerator routine = this.\u083Cܨ\u087E\u0593();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003D7 RID: 983 RVA: 0x00016E34 File Offset: 0x00015034
	[Token(Token = "0x60003D7")]
	[Address(RVA = "0x2718EB0", Offset = "0x2718EB0", VA = "0x2718EB0")]
	public void ۆڛߟ\u05A0()
	{
		IEnumerator routine = this.ڈ\u0708Մࠎ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003D8 RID: 984 RVA: 0x00016E5C File Offset: 0x0001505C
	[Token(Token = "0x60003D8")]
	[Address(RVA = "0x2718978", Offset = "0x2718978", VA = "0x2718978")]
	public IEnumerator ڈ\u0708Մࠎ()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 1L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003D9 RID: 985 RVA: 0x00016E80 File Offset: 0x00015080
	[Token(Token = "0x60003D9")]
	[Address(RVA = "0x2718F00", Offset = "0x2718F00", VA = "0x2718F00")]
	public IEnumerator \u088Fߥ\u0875ԏ()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 0L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003DA RID: 986 RVA: 0x00016EA4 File Offset: 0x000150A4
	[Token(Token = "0x60003DA")]
	[Address(RVA = "0x2718C30", Offset = "0x2718C30", VA = "0x2718C30")]
	public IEnumerator \u055D\u0656סټ()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 1L;
		throw new NullReferenceException();
	}

	// Token: 0x060003DB RID: 987 RVA: 0x00016EC0 File Offset: 0x000150C0
	[Token(Token = "0x60003DB")]
	[Address(RVA = "0x2718F78", Offset = "0x2718F78", VA = "0x2718F78")]
	public void ݸԲ\u0616Ԫ()
	{
		IEnumerator routine = this.ڐޛ\u06DFۺ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003DC RID: 988 RVA: 0x00016EE8 File Offset: 0x000150E8
	[Token(Token = "0x60003DC")]
	[Address(RVA = "0x2718FCC", Offset = "0x2718FCC", VA = "0x2718FCC")]
	public void ߖհݣ߀()
	{
		IEnumerator routine = this.\u088Fߥ\u0875ԏ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
			throw new MissingMethodException();
		}
	}

	// Token: 0x060003DD RID: 989 RVA: 0x00016F14 File Offset: 0x00015114
	[Token(Token = "0x60003DD")]
	[Address(RVA = "0x2719020", Offset = "0x2719020", VA = "0x2719020")]
	public void ޠۋ\u0530\u073E()
	{
		IEnumerator routine = this.ࠕո\u05CAә();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003DE RID: 990 RVA: 0x00016F3C File Offset: 0x0001513C
	[Token(Token = "0x60003DE")]
	[Address(RVA = "0x2719074", Offset = "0x2719074", VA = "0x2719074")]
	public void \u073BօӁ\u059A()
	{
		IEnumerator routine = this.\u07F2\u070FՕږ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003DF RID: 991 RVA: 0x00016F64 File Offset: 0x00015164
	[Token(Token = "0x60003DF")]
	[Address(RVA = "0x2719140", Offset = "0x2719140", VA = "0x2719140")]
	public IEnumerator ە\u086Fԡ\u0655()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 1L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E0 RID: 992 RVA: 0x00016F88 File Offset: 0x00015188
	[Token(Token = "0x60003E0")]
	[Address(RVA = "0x27188AC", Offset = "0x27188AC", VA = "0x27188AC")]
	public IEnumerator ڐޛ\u06DFۺ()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 0L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E1 RID: 993 RVA: 0x00016FAC File Offset: 0x000151AC
	[Token(Token = "0x60003E1")]
	[Address(RVA = "0x27191B8", Offset = "0x27191B8", VA = "0x27191B8")]
	public IEnumerator \u07F8ӵےٯ()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 0L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E2 RID: 994 RVA: 0x00016FD0 File Offset: 0x000151D0
	[Token(Token = "0x60003E2")]
	[Address(RVA = "0x2719230", Offset = "0x2719230", VA = "0x2719230")]
	public IEnumerator \u073D\u0885Ԁ\u059F()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 1L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E3 RID: 995 RVA: 0x00016FF4 File Offset: 0x000151F4
	[Token(Token = "0x60003E3")]
	[Address(RVA = "0x27192A8", Offset = "0x27192A8", VA = "0x27192A8")]
	public void ࠏޤݳ\u06DD()
	{
		IEnumerator routine = this.ӷ\u05BDԞ\u0824();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003E4 RID: 996 RVA: 0x0001701C File Offset: 0x0001521C
	[Token(Token = "0x60003E4")]
	[Address(RVA = "0x27192FC", Offset = "0x27192FC", VA = "0x27192FC")]
	public IEnumerator \u05EEםԊ\u07F7()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 1L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E5 RID: 997 RVA: 0x00017040 File Offset: 0x00015240
	[Token(Token = "0x60003E5")]
	[Address(RVA = "0x2719374", Offset = "0x2719374", VA = "0x2719374")]
	public void ܩחݵޔ()
	{
		IEnumerator routine = this.\u07F2\u070FՕږ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003E6 RID: 998 RVA: 0x00017068 File Offset: 0x00015268
	[Token(Token = "0x60003E6")]
	[Address(RVA = "0x27193C8", Offset = "0x27193C8", VA = "0x27193C8")]
	public void نո\u0599\u0589()
	{
		IEnumerator routine = this.\u05B2\u05B3ݧࡀ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003E7 RID: 999 RVA: 0x00017090 File Offset: 0x00015290
	[Token(Token = "0x60003E7")]
	[Address(RVA = "0x2719494", Offset = "0x2719494", VA = "0x2719494")]
	public void ןٮ\u061FԺ()
	{
		IEnumerator routine = this.\u073D\u0885Ԁ\u059F();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003E8 RID: 1000 RVA: 0x000170B8 File Offset: 0x000152B8
	[Token(Token = "0x60003E8")]
	[Address(RVA = "0x27190C8", Offset = "0x27190C8", VA = "0x27190C8")]
	public IEnumerator \u07F2\u070FՕږ()
	{
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E9 RID: 1001 RVA: 0x000170D4 File Offset: 0x000152D4
	[Token(Token = "0x60003E9")]
	[Address(RVA = "0x27194E8", Offset = "0x27194E8", VA = "0x27194E8")]
	public void ӛ\u082Eؿڕ()
	{
		IEnumerator routine = this.ە\u086Fԡ\u0655();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003EA RID: 1002 RVA: 0x000170FC File Offset: 0x000152FC
	[Token(Token = "0x60003EA")]
	[Address(RVA = "0x271953C", Offset = "0x271953C", VA = "0x271953C")]
	public void \u0558ݕݤݮ()
	{
		IEnumerator routine = this.ڐޛ\u06DFۺ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003EB RID: 1003 RVA: 0x00017124 File Offset: 0x00015324
	[Token(Token = "0x60003EB")]
	[Address(RVA = "0x271941C", Offset = "0x271941C", VA = "0x271941C")]
	public IEnumerator \u05B2\u05B3ݧࡀ()
	{
		throw new NullReferenceException();
	}

	// Token: 0x060003EC RID: 1004 RVA: 0x00017138 File Offset: 0x00015338
	[Token(Token = "0x60003EC")]
	[Address(RVA = "0x2719590", Offset = "0x2719590", VA = "0x2719590")]
	public void \u0834\u0817ރࡔ()
	{
		IEnumerator routine = this.\u06DE\u05C6Ըس();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003ED RID: 1005 RVA: 0x00017160 File Offset: 0x00015360
	[Token(Token = "0x60003ED")]
	[Address(RVA = "0x27195E4", Offset = "0x27195E4", VA = "0x27195E4")]
	public Blink()
	{
	}

	// Token: 0x060003EE RID: 1006 RVA: 0x00017174 File Offset: 0x00015374
	[Token(Token = "0x60003EE")]
	[Address(RVA = "0x27195EC", Offset = "0x27195EC", VA = "0x27195EC")]
	public void \u086Bԍࡊڭ()
	{
		IEnumerator routine = this.\u0558\u0833\u085Bډ();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003EF RID: 1007 RVA: 0x0001719C File Offset: 0x0001539C
	[Token(Token = "0x60003EF")]
	[Address(RVA = "0x2719640", Offset = "0x2719640", VA = "0x2719640")]
	public void ݱ\u0832ݥ\u08B5()
	{
		IEnumerator routine = this.\u06DE\u05C6Ըس();
		Coroutine coroutine = base.StartCoroutine(routine);
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x060003F0 RID: 1008 RVA: 0x000171C4 File Offset: 0x000153C4
	[Token(Token = "0x60003F0")]
	[Address(RVA = "0x2718A98", Offset = "0x2718A98", VA = "0x2718A98")]
	public IEnumerator \u083Cܨ\u087E\u0593()
	{
		long <>1__state;
		Blink.\u06FD\u083Cݡޞ u06FD_u083Cݡޞ = new Blink.\u06FD\u083Cݡޞ((int)<>1__state);
		<>1__state = 0L;
		u06FD_u083Cݡޞ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003F1 RID: 1009 RVA: 0x000171E8 File Offset: 0x000153E8
	[Token(Token = "0x60003F1")]
	[Address(RVA = "0x2719694", Offset = "0x2719694", VA = "0x2719694")]
	public void ࢧӾڈց()
	{
		IEnumerator enumerator = this.\u05B2\u05B3ݧࡀ();
		if (this.\u058B\u06DC\u05BEܟ)
		{
		}
	}

	// Token: 0x04000082 RID: 130
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000082")]
	public Texture2D \u06FEݵޒ\u08B5;

	// Token: 0x04000083 RID: 131
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000083")]
	public Texture2D ԋࡡ\u06D8\u05C2;

	// Token: 0x04000084 RID: 132
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000084")]
	public Texture2D آص\u0601מ;

	// Token: 0x04000085 RID: 133
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000085")]
	public Texture2D \u06E1\u087D\u0595ߞ;

	// Token: 0x04000086 RID: 134
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000086")]
	public bool \u058B\u06DC\u05BEܟ;

	// Token: 0x04000087 RID: 135
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x4000087")]
	public float ڦ\u060B\u081Dࡎ;

	// Token: 0x04000088 RID: 136
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000088")]
	public Material \u066B\u0882ӎڝ;
}
