﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000BA RID: 186
[Token(Token = "0x20000BA")]
public class EnableWhenCollide : MonoBehaviour
{
	// Token: 0x06001B3E RID: 6974 RVA: 0x0008E8E4 File Offset: 0x0008CAE4
	[Token(Token = "0x6001B3E")]
	[Address(RVA = "0x1D874C4", Offset = "0x1D874C4", VA = "0x1D874C4")]
	public void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "DISABLE";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B3F RID: 6975 RVA: 0x0008E920 File Offset: 0x0008CB20
	[Token(Token = "0x6001B3F")]
	[Address(RVA = "0x1D87564", Offset = "0x1D87564", VA = "0x1D87564")]
	public void \u083FԤթ\u07B2(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B40 RID: 6976 RVA: 0x0008E95C File Offset: 0x0008CB5C
	[Token(Token = "0x6001B40")]
	[Address(RVA = "0x1D87604", Offset = "0x1D87604", VA = "0x1D87604")]
	public void \u06DAٻࠕڡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "All audio clips have been played.";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B41 RID: 6977 RVA: 0x0008E998 File Offset: 0x0008CB98
	[Token(Token = "0x6001B41")]
	[Address(RVA = "0x1D876A4", Offset = "0x1D876A4", VA = "0x1D876A4")]
	public void \u05B2۳\u0590\u0612(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B42 RID: 6978 RVA: 0x0008E9D4 File Offset: 0x0008CBD4
	[Token(Token = "0x6001B42")]
	[Address(RVA = "0x1D87744", Offset = "0x1D87744", VA = "0x1D87744")]
	public void \u0819Փٲࡪ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "hand 1";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B43 RID: 6979 RVA: 0x0008EA10 File Offset: 0x0008CC10
	[Token(Token = "0x6001B43")]
	[Address(RVA = "0x1D877E4", Offset = "0x1D877E4", VA = "0x1D877E4")]
	public void \u0732\u089Fࢦߣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HandR";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B44 RID: 6980 RVA: 0x0008EA4C File Offset: 0x0008CC4C
	[Token(Token = "0x6001B44")]
	[Address(RVA = "0x1D87884", Offset = "0x1D87884", VA = "0x1D87884")]
	public void ߥࠂ\u066Cࢷ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "RainAndThunderWeather";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B45 RID: 6981 RVA: 0x0008EA88 File Offset: 0x0008CC88
	[Token(Token = "0x6001B45")]
	[Address(RVA = "0x1D87924", Offset = "0x1D87924", VA = "0x1D87924")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Skelechin";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B46 RID: 6982 RVA: 0x0008EAC4 File Offset: 0x0008CCC4
	[Token(Token = "0x6001B46")]
	[Address(RVA = "0x1D879C4", Offset = "0x1D879C4", VA = "0x1D879C4")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B47 RID: 6983 RVA: 0x0008EB00 File Offset: 0x0008CD00
	[Token(Token = "0x6001B47")]
	[Address(RVA = "0x1D87A64", Offset = "0x1D87A64", VA = "0x1D87A64")]
	public void يօӇ\u070D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Start Gamemode";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B48 RID: 6984 RVA: 0x0008EB3C File Offset: 0x0008CD3C
	[Token(Token = "0x6001B48")]
	[Address(RVA = "0x1D87B04", Offset = "0x1D87B04", VA = "0x1D87B04")]
	public void א\u087A\u0607ݸ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You have been banned for ";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B49 RID: 6985 RVA: 0x0008EB78 File Offset: 0x0008CD78
	[Token(Token = "0x6001B49")]
	[Address(RVA = "0x1D87BA4", Offset = "0x1D87BA4", VA = "0x1D87BA4")]
	public void پ\u05F7\u06E6ރ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HandL";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B4A RID: 6986 RVA: 0x0008EBB4 File Offset: 0x0008CDB4
	[Token(Token = "0x6001B4A")]
	[Address(RVA = "0x1D87C44", Offset = "0x1D87C44", VA = "0x1D87C44")]
	public void \u06DC\u064DԞݤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Muted";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B4B RID: 6987 RVA: 0x0008EBF0 File Offset: 0x0008CDF0
	[Token(Token = "0x6001B4B")]
	[Address(RVA = "0x1D87CE4", Offset = "0x1D87CE4", VA = "0x1D87CE4")]
	public void \u059Cݝ\u058E۳(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "containsStaff";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B4C RID: 6988 RVA: 0x0008EC2C File Offset: 0x0008CE2C
	[Token(Token = "0x6001B4C")]
	[Address(RVA = "0x1D87D84", Offset = "0x1D87D84", VA = "0x1D87D84")]
	public void \u0748\u05F4Նۏ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B4D RID: 6989 RVA: 0x0008EC68 File Offset: 0x0008CE68
	[Token(Token = "0x6001B4D")]
	[Address(RVA = "0x1D87E24", Offset = "0x1D87E24", VA = "0x1D87E24")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "This is the 1000 Bananas button, and it was just clicked";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B4E RID: 6990 RVA: 0x0008ECA4 File Offset: 0x0008CEA4
	[Token(Token = "0x6001B4E")]
	[Address(RVA = "0x1D87EC4", Offset = "0x1D87EC4", VA = "0x1D87EC4")]
	public void Ԃ\u058Aܫջ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "/";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B4F RID: 6991 RVA: 0x0008ECE0 File Offset: 0x0008CEE0
	[Token(Token = "0x6001B4F")]
	[Address(RVA = "0x1D87F64", Offset = "0x1D87F64", VA = "0x1D87F64")]
	public void ܫ\u085Eہӝ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not connected to room";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B50 RID: 6992 RVA: 0x0008ED1C File Offset: 0x0008CF1C
	[Token(Token = "0x6001B50")]
	[Address(RVA = "0x1D88004", Offset = "0x1D88004", VA = "0x1D88004")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B51 RID: 6993 RVA: 0x0008ED4C File Offset: 0x0008CF4C
	[Token(Token = "0x6001B51")]
	[Address(RVA = "0x1D880A4", Offset = "0x1D880A4", VA = "0x1D880A4")]
	public void ځޤקࠈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Joined a Room.";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B52 RID: 6994 RVA: 0x0008ED88 File Offset: 0x0008CF88
	[Token(Token = "0x6001B52")]
	[Address(RVA = "0x1D88144", Offset = "0x1D88144", VA = "0x1D88144")]
	public void ԁؼՖռ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HandL";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B53 RID: 6995 RVA: 0x0008EDC4 File Offset: 0x0008CFC4
	[Token(Token = "0x6001B53")]
	[Address(RVA = "0x1D881E4", Offset = "0x1D881E4", VA = "0x1D881E4")]
	public void \u06DEӸԏ\u07BF(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B54 RID: 6996 RVA: 0x0008EE00 File Offset: 0x0008D000
	[Token(Token = "0x6001B54")]
	[Address(RVA = "0x1D88284", Offset = "0x1D88284", VA = "0x1D88284")]
	public void \u086D\u089AԾ\u0881(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "typesOfTalk";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B55 RID: 6997 RVA: 0x0008EE3C File Offset: 0x0008D03C
	[Token(Token = "0x6001B55")]
	[Address(RVA = "0x1D88324", Offset = "0x1D88324", VA = "0x1D88324")]
	public void \u05AB\u05BEӞނ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B56 RID: 6998 RVA: 0x0008EE78 File Offset: 0x0008D078
	[Token(Token = "0x6001B56")]
	[Address(RVA = "0x1D883C4", Offset = "0x1D883C4", VA = "0x1D883C4")]
	public void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == " hour. You were banned because of ";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B57 RID: 6999 RVA: 0x0008EEB4 File Offset: 0x0008D0B4
	[Token(Token = "0x6001B57")]
	[Address(RVA = "0x1D88464", Offset = "0x1D88464", VA = "0x1D88464")]
	public void \u0589\u0740\u05C6ӧ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B58 RID: 7000 RVA: 0x0008EEF0 File Offset: 0x0008D0F0
	[Token(Token = "0x6001B58")]
	[Address(RVA = "0x1D88504", Offset = "0x1D88504", VA = "0x1D88504")]
	public void Ԍޟࡀݲ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "closeToObject";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B59 RID: 7001 RVA: 0x0008EF2C File Offset: 0x0008D12C
	[Token(Token = "0x6001B59")]
	[Address(RVA = "0x1D885A4", Offset = "0x1D885A4", VA = "0x1D885A4")]
	public void \u07BF\u0705\u0824ڮ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Charged!";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B5A RID: 7002 RVA: 0x0008EF68 File Offset: 0x0008D168
	[Token(Token = "0x6001B5A")]
	[Address(RVA = "0x1D88644", Offset = "0x1D88644", VA = "0x1D88644")]
	public void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B5B RID: 7003 RVA: 0x0008EFA4 File Offset: 0x0008D1A4
	[Token(Token = "0x6001B5B")]
	[Address(RVA = "0x1D886E4", Offset = "0x1D886E4", VA = "0x1D886E4")]
	public void قԙ\u0653պ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Hate Speech";
	}

	// Token: 0x06001B5C RID: 7004 RVA: 0x0008EFD0 File Offset: 0x0008D1D0
	[Token(Token = "0x6001B5C")]
	[Address(RVA = "0x1D88784", Offset = "0x1D88784", VA = "0x1D88784")]
	public void ہۼآԄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "MetaId";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B5D RID: 7005 RVA: 0x0008F00C File Offset: 0x0008D20C
	[Token(Token = "0x6001B5D")]
	[Address(RVA = "0x1D88824", Offset = "0x1D88824", VA = "0x1D88824")]
	public void ة\u066Dࡏԫ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
	}

	// Token: 0x06001B5E RID: 7006 RVA: 0x0008F038 File Offset: 0x0008D238
	[Token(Token = "0x6001B5E")]
	[Address(RVA = "0x1D888C4", Offset = "0x1D888C4", VA = "0x1D888C4")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B5F RID: 7007 RVA: 0x0008F074 File Offset: 0x0008D274
	[Token(Token = "0x6001B5F")]
	[Address(RVA = "0x1D88964", Offset = "0x1D88964", VA = "0x1D88964")]
	public void Ӛ\u055D\u0651Խ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "goUpRPC";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B60 RID: 7008 RVA: 0x0008F0B0 File Offset: 0x0008D2B0
	[Token(Token = "0x6001B60")]
	[Address(RVA = "0x1D88A04", Offset = "0x1D88A04", VA = "0x1D88A04")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "True";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B61 RID: 7009 RVA: 0x0008F0EC File Offset: 0x0008D2EC
	[Token(Token = "0x6001B61")]
	[Address(RVA = "0x1D88AA4", Offset = "0x1D88AA4", VA = "0x1D88AA4")]
	public void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B62 RID: 7010 RVA: 0x0008F11C File Offset: 0x0008D31C
	[Token(Token = "0x6001B62")]
	[Address(RVA = "0x1D88B44", Offset = "0x1D88B44", VA = "0x1D88B44")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "EnableCosmetic";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B63 RID: 7011 RVA: 0x0008F158 File Offset: 0x0008D358
	[Token(Token = "0x6001B63")]
	[Address(RVA = "0x1D88BE4", Offset = "0x1D88BE4", VA = "0x1D88BE4")]
	public void ڿ\u07ADݠڧ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "DisableCosmetic";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B64 RID: 7012 RVA: 0x0008F194 File Offset: 0x0008D394
	[Token(Token = "0x6001B64")]
	[Address(RVA = "0x1D88C84", Offset = "0x1D88C84", VA = "0x1D88C84")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not enough amount of currency";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B65 RID: 7013 RVA: 0x0008F1D0 File Offset: 0x0008D3D0
	[Token(Token = "0x6001B65")]
	[Address(RVA = "0x1D88D24", Offset = "0x1D88D24", VA = "0x1D88D24")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Failed to login, please restart";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B66 RID: 7014 RVA: 0x0008F20C File Offset: 0x0008D40C
	[Token(Token = "0x6001B66")]
	[Address(RVA = "0x1D88DC4", Offset = "0x1D88DC4", VA = "0x1D88DC4")]
	public void ࢷࢯ\u05B2ݸ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Calling success callback. baking meshes";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B67 RID: 7015 RVA: 0x0008F248 File Offset: 0x0008D448
	[Token(Token = "0x6001B67")]
	[Address(RVA = "0x1D88E64", Offset = "0x1D88E64", VA = "0x1D88E64")]
	public void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Add/Remove Sword";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B68 RID: 7016 RVA: 0x0008F284 File Offset: 0x0008D484
	[Token(Token = "0x6001B68")]
	[Address(RVA = "0x1D88F04", Offset = "0x1D88F04", VA = "0x1D88F04")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_BumpMap";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B69 RID: 7017 RVA: 0x0008F2C0 File Offset: 0x0008D4C0
	[Token(Token = "0x6001B69")]
	[Address(RVA = "0x1D88FA4", Offset = "0x1D88FA4", VA = "0x1D88FA4")]
	public void ߃\u0602\u0891߇(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		throw new MissingMethodException();
	}

	// Token: 0x06001B6A RID: 7018 RVA: 0x0008F2F8 File Offset: 0x0008D4F8
	[Token(Token = "0x6001B6A")]
	[Address(RVA = "0x1D89044", Offset = "0x1D89044", VA = "0x1D89044")]
	public void ؽܗӊә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B6B RID: 7019 RVA: 0x0008F334 File Offset: 0x0008D534
	[Token(Token = "0x6001B6B")]
	[Address(RVA = "0x1D890E4", Offset = "0x1D890E4", VA = "0x1D890E4")]
	public void տ\u06D9ܭࠊ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "monke screamed";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B6C RID: 7020 RVA: 0x0008F370 File Offset: 0x0008D570
	[Token(Token = "0x6001B6C")]
	[Address(RVA = "0x1D89184", Offset = "0x1D89184", VA = "0x1D89184")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B6D RID: 7021 RVA: 0x0008F3AC File Offset: 0x0008D5AC
	[Token(Token = "0x6001B6D")]
	[Address(RVA = "0x1D89224", Offset = "0x1D89224", VA = "0x1D89224")]
	public void ܖռ\u05C8\u089F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
	}

	// Token: 0x06001B6E RID: 7022 RVA: 0x0008F3D8 File Offset: 0x0008D5D8
	[Token(Token = "0x6001B6E")]
	[Address(RVA = "0x1D892C4", Offset = "0x1D892C4", VA = "0x1D892C4")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "typesOfTalk";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B6F RID: 7023 RVA: 0x0008F414 File Offset: 0x0008D614
	[Token(Token = "0x6001B6F")]
	[Address(RVA = "0x1D89364", Offset = "0x1D89364", VA = "0x1D89364")]
	public void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B70 RID: 7024 RVA: 0x0008F450 File Offset: 0x0008D650
	[Token(Token = "0x6001B70")]
	[Address(RVA = "0x1D89404", Offset = "0x1D89404", VA = "0x1D89404")]
	public void ڷ\u0826ӹڥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B71 RID: 7025 RVA: 0x0008F48C File Offset: 0x0008D68C
	[Token(Token = "0x6001B71")]
	[Address(RVA = "0x1D894A4", Offset = "0x1D894A4", VA = "0x1D894A4")]
	public void \u073Bٿ\u0835\u085C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not connected to room";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B72 RID: 7026 RVA: 0x0008F4C8 File Offset: 0x0008D6C8
	[Token(Token = "0x6001B72")]
	[Address(RVA = "0x1D89544", Offset = "0x1D89544", VA = "0x1D89544")]
	public void ݍ\u05F4ߓ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B73 RID: 7027 RVA: 0x0008F504 File Offset: 0x0008D704
	[Token(Token = "0x6001B73")]
	[Address(RVA = "0x1D895E4", Offset = "0x1D895E4", VA = "0x1D895E4")]
	public void ݼڔ\u05CE\u0899(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B74 RID: 7028 RVA: 0x0008F540 File Offset: 0x0008D740
	[Token(Token = "0x6001B74")]
	[Address(RVA = "0x1D89684", Offset = "0x1D89684", VA = "0x1D89684")]
	public EnableWhenCollide()
	{
	}

	// Token: 0x06001B75 RID: 7029 RVA: 0x0008F554 File Offset: 0x0008D754
	[Token(Token = "0x6001B75")]
	[Address(RVA = "0x1D8968C", Offset = "0x1D8968C", VA = "0x1D8968C")]
	public void ݳՂݝ\u07B8(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "DisableCosmetic";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B76 RID: 7030 RVA: 0x0008F590 File Offset: 0x0008D790
	[Token(Token = "0x6001B76")]
	[Address(RVA = "0x1D8972C", Offset = "0x1D8972C", VA = "0x1D8972C")]
	public void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B77 RID: 7031 RVA: 0x0008F5CC File Offset: 0x0008D7CC
	[Token(Token = "0x6001B77")]
	[Address(RVA = "0x1D897CC", Offset = "0x1D897CC", VA = "0x1D897CC")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B78 RID: 7032 RVA: 0x0008F608 File Offset: 0x0008D808
	[Token(Token = "0x6001B78")]
	[Address(RVA = "0x1D8986C", Offset = "0x1D8986C", VA = "0x1D8986C")]
	public void \u07B2߆Ժࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "CapuchinStore";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B79 RID: 7033 RVA: 0x0008F644 File Offset: 0x0008D844
	[Token(Token = "0x6001B79")]
	[Address(RVA = "0x1D8990C", Offset = "0x1D8990C", VA = "0x1D8990C")]
	public void \u0705خڃ\u059B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Body";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B7A RID: 7034 RVA: 0x0008F680 File Offset: 0x0008D880
	[Token(Token = "0x6001B7A")]
	[Address(RVA = "0x1D899AC", Offset = "0x1D899AC", VA = "0x1D899AC")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B7B RID: 7035 RVA: 0x0008F6BC File Offset: 0x0008D8BC
	[Token(Token = "0x6001B7B")]
	[Address(RVA = "0x1D89A4C", Offset = "0x1D89A4C", VA = "0x1D89A4C")]
	public void \u081FԘں\u07B2(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player was caught cheating";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B7C RID: 7036 RVA: 0x0008F6F8 File Offset: 0x0008D8F8
	[Token(Token = "0x6001B7C")]
	[Address(RVA = "0x1D89AEC", Offset = "0x1D89AEC", VA = "0x1D89AEC")]
	public void \u07B3\u07BD\u05FF\u0859(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "hand 1";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B7D RID: 7037 RVA: 0x0008F734 File Offset: 0x0008D934
	[Token(Token = "0x6001B7D")]
	[Address(RVA = "0x1D89B8C", Offset = "0x1D89B8C", VA = "0x1D89B8C")]
	public void ԀۼلԊ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B7E RID: 7038 RVA: 0x0008F770 File Offset: 0x0008D970
	[Token(Token = "0x6001B7E")]
	[Address(RVA = "0x1D89C2C", Offset = "0x1D89C2C", VA = "0x1D89C2C")]
	public void Ԍߊٱݩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B7F RID: 7039 RVA: 0x0008F7AC File Offset: 0x0008D9AC
	[Token(Token = "0x6001B7F")]
	[Address(RVA = "0x1D89CCC", Offset = "0x1D89CCC", VA = "0x1D89CCC")]
	public void \u0836Չװߟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Combine textures & build combined mesh using coroutine";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B80 RID: 7040 RVA: 0x0008F7E8 File Offset: 0x0008D9E8
	[Token(Token = "0x6001B80")]
	[Address(RVA = "0x1D89D6C", Offset = "0x1D89D6C", VA = "0x1D89D6C")]
	public void ߂ڞ\u0600\u07FB(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_BumpMap";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B81 RID: 7041 RVA: 0x0008F824 File Offset: 0x0008DA24
	[Token(Token = "0x6001B81")]
	[Address(RVA = "0x1D89E0C", Offset = "0x1D89E0C", VA = "0x1D89E0C")]
	public void ىރ\u0704ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B82 RID: 7042 RVA: 0x0008F860 File Offset: 0x0008DA60
	[Token(Token = "0x6001B82")]
	[Address(RVA = "0x1D89EAC", Offset = "0x1D89EAC", VA = "0x1D89EAC")]
	public void ۷ޞ\u07AFߍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Joined a Room.";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B83 RID: 7043 RVA: 0x0008F89C File Offset: 0x0008DA9C
	[Token(Token = "0x6001B83")]
	[Address(RVA = "0x1D89F4C", Offset = "0x1D89F4C", VA = "0x1D89F4C")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "run";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B84 RID: 7044 RVA: 0x0008F8D4 File Offset: 0x0008DAD4
	[Token(Token = "0x6001B84")]
	[Address(RVA = "0x1D89FEC", Offset = "0x1D89FEC", VA = "0x1D89FEC")]
	public void \u0825\u05CEݍ\u083C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B85 RID: 7045 RVA: 0x0008F910 File Offset: 0x0008DB10
	[Token(Token = "0x6001B85")]
	[Address(RVA = "0x1D8A08C", Offset = "0x1D8A08C", VA = "0x1D8A08C")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Meta Platform entitlement error: ";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B86 RID: 7046 RVA: 0x0008F94C File Offset: 0x0008DB4C
	[Token(Token = "0x6001B86")]
	[Address(RVA = "0x1D8A12C", Offset = "0x1D8A12C", VA = "0x1D8A12C")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B87 RID: 7047 RVA: 0x0008F97C File Offset: 0x0008DB7C
	[Token(Token = "0x6001B87")]
	[Address(RVA = "0x1D8A1CC", Offset = "0x1D8A1CC", VA = "0x1D8A1CC")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Network Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B88 RID: 7048 RVA: 0x0008F9B8 File Offset: 0x0008DBB8
	[Token(Token = "0x6001B88")]
	[Address(RVA = "0x1D8A26C", Offset = "0x1D8A26C", VA = "0x1D8A26C")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "On";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B89 RID: 7049 RVA: 0x0008F9F4 File Offset: 0x0008DBF4
	[Token(Token = "0x6001B89")]
	[Address(RVA = "0x1D8A30C", Offset = "0x1D8A30C", VA = "0x1D8A30C")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B8A RID: 7050 RVA: 0x0008FA30 File Offset: 0x0008DC30
	[Token(Token = "0x6001B8A")]
	[Address(RVA = "0x1D8A3AC", Offset = "0x1D8A3AC", VA = "0x1D8A3AC")]
	public void ت\u05F9ޅ\u059A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Reason: ";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B8B RID: 7051 RVA: 0x0008FA6C File Offset: 0x0008DC6C
	[Token(Token = "0x6001B8B")]
	[Address(RVA = "0x1D8A44C", Offset = "0x1D8A44C", VA = "0x1D8A44C")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B8C RID: 7052 RVA: 0x0008FA9C File Offset: 0x0008DC9C
	[Token(Token = "0x6001B8C")]
	[Address(RVA = "0x1D8A4EC", Offset = "0x1D8A4EC", VA = "0x1D8A4EC")]
	public void ڎՅڤࠊ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "CapuchinStore";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B8D RID: 7053 RVA: 0x0008FAD8 File Offset: 0x0008DCD8
	[Token(Token = "0x6001B8D")]
	[Address(RVA = "0x1D8A58C", Offset = "0x1D8A58C", VA = "0x1D8A58C")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B8E RID: 7054 RVA: 0x0008FB14 File Offset: 0x0008DD14
	[Token(Token = "0x6001B8E")]
	[Address(RVA = "0x1D8A62C", Offset = "0x1D8A62C", VA = "0x1D8A62C")]
	public void ӳڣܟޖ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B8F RID: 7055 RVA: 0x0008FB44 File Offset: 0x0008DD44
	[Token(Token = "0x6001B8F")]
	[Address(RVA = "0x1D8A6CC", Offset = "0x1D8A6CC", VA = "0x1D8A6CC")]
	public void ճ\u0828Ԓհ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B90 RID: 7056 RVA: 0x0008FB80 File Offset: 0x0008DD80
	[Token(Token = "0x6001B90")]
	[Address(RVA = "0x1D8A76C", Offset = "0x1D8A76C", VA = "0x1D8A76C")]
	public void \u05F8ڛߠ\u05BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "waited for your bullshit unity grrr";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 1L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B91 RID: 7057 RVA: 0x0008FBBC File Offset: 0x0008DDBC
	[Token(Token = "0x6001B91")]
	[Address(RVA = "0x1D8A80C", Offset = "0x1D8A80C", VA = "0x1D8A80C")]
	public void \u0619طӍ\u083D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Adding ";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B92 RID: 7058 RVA: 0x0008FBF8 File Offset: 0x0008DDF8
	[Token(Token = "0x6001B92")]
	[Address(RVA = "0x1D8A8AC", Offset = "0x1D8A8AC", VA = "0x1D8A8AC")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "NetworkGunShoot";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B93 RID: 7059 RVA: 0x0008FC34 File Offset: 0x0008DE34
	[Token(Token = "0x6001B93")]
	[Address(RVA = "0x1D8A94C", Offset = "0x1D8A94C", VA = "0x1D8A94C")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		GameObject u07AFԌ_u05F4_u07B = this.\u07AFԌ\u05F4\u07B6;
		long active = 0L;
		u07AFԌ_u05F4_u07B.SetActive(active != 0L);
	}

	// Token: 0x06001B94 RID: 7060 RVA: 0x0008FC70 File Offset: 0x0008DE70
	[Token(Token = "0x6001B94")]
	[Address(RVA = "0x1D8A9EC", Offset = "0x1D8A9EC", VA = "0x1D8A9EC")]
	public void \u085Cݯژ\u05FA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You Already Own This Item";
	}

	// Token: 0x04000398 RID: 920
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000398")]
	public GameObject \u07AFԌ\u05F4\u07B6;
}
