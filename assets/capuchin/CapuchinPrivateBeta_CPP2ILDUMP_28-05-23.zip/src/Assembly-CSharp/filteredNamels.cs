﻿using System;
using Cpp2IlInjected;

// Token: 0x020000E4 RID: 228
[Token(Token = "0x20000E4")]
[Serializable]
public class filteredNamels
{
	// Token: 0x06002364 RID: 9060 RVA: 0x000BB090 File Offset: 0x000B9290
	[Token(Token = "0x6002364")]
	[Address(RVA = "0x2AFD7B8", Offset = "0x2AFD7B8", VA = "0x2AFD7B8")]
	public filteredNamels()
	{
	}

	// Token: 0x04000478 RID: 1144
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000478")]
	public string word;
}
