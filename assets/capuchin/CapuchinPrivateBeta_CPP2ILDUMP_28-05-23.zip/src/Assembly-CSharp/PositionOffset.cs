﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000D7 RID: 215
[Token(Token = "0x20000D7")]
public class PositionOffset : MonoBehaviour
{
	// Token: 0x0600206B RID: 8299 RVA: 0x000A86AC File Offset: 0x000A68AC
	[Token(Token = "0x600206B")]
	[Address(RVA = "0x2C4129C", Offset = "0x2C4129C", VA = "0x2C4129C")]
	private void \u0881ݗӟ\u07BD()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x0600206C RID: 8300 RVA: 0x000A86F8 File Offset: 0x000A68F8
	[Token(Token = "0x600206C")]
	[Address(RVA = "0x2C412FC", Offset = "0x2C412FC", VA = "0x2C412FC")]
	private void \u061B\u05EEوۈ()
	{
		Transform transform = base.transform;
		Transform transform2 = this.ࠔؼࡏݥ;
		Vector3 position = transform.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x0600206D RID: 8301 RVA: 0x000A8748 File Offset: 0x000A6948
	[Token(Token = "0x600206D")]
	[Address(RVA = "0x2C4135C", Offset = "0x2C4135C", VA = "0x2C4135C")]
	private void ւࡂ\u0883\u0872()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x0600206E RID: 8302 RVA: 0x000A8794 File Offset: 0x000A6994
	[Token(Token = "0x600206E")]
	[Address(RVA = "0x2C413BC", Offset = "0x2C413BC", VA = "0x2C413BC")]
	private void ժ\u065Dԯࡘ()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x0600206F RID: 8303 RVA: 0x000A87E0 File Offset: 0x000A69E0
	[Token(Token = "0x600206F")]
	[Address(RVA = "0x2C4141C", Offset = "0x2C4141C", VA = "0x2C4141C")]
	private void څࡣڐ\u0657()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x06002070 RID: 8304 RVA: 0x000A882C File Offset: 0x000A6A2C
	[Token(Token = "0x6002070")]
	[Address(RVA = "0x2C4147C", Offset = "0x2C4147C", VA = "0x2C4147C")]
	public PositionOffset()
	{
	}

	// Token: 0x06002071 RID: 8305 RVA: 0x000A8840 File Offset: 0x000A6A40
	[Token(Token = "0x6002071")]
	[Address(RVA = "0x2C41484", Offset = "0x2C41484", VA = "0x2C41484")]
	private void Update()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x06002072 RID: 8306 RVA: 0x000A888C File Offset: 0x000A6A8C
	[Token(Token = "0x6002072")]
	[Address(RVA = "0x2C414E4", Offset = "0x2C414E4", VA = "0x2C414E4")]
	private void \u0654ޛ\u07FAذ()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x06002073 RID: 8307 RVA: 0x000A88D8 File Offset: 0x000A6AD8
	[Token(Token = "0x6002073")]
	[Address(RVA = "0x2C41544", Offset = "0x2C41544", VA = "0x2C41544")]
	private void \u05F7ԝߠӱ()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x06002074 RID: 8308 RVA: 0x000A8924 File Offset: 0x000A6B24
	[Token(Token = "0x6002074")]
	[Address(RVA = "0x2C415A4", Offset = "0x2C415A4", VA = "0x2C415A4")]
	private void ں٢ࡡ\u05EC()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x06002075 RID: 8309 RVA: 0x000A8970 File Offset: 0x000A6B70
	[Token(Token = "0x6002075")]
	[Address(RVA = "0x2C41604", Offset = "0x2C41604", VA = "0x2C41604")]
	private void \u05EDց\u081Cت()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x06002076 RID: 8310 RVA: 0x000A89BC File Offset: 0x000A6BBC
	[Token(Token = "0x6002076")]
	[Address(RVA = "0x2C41664", Offset = "0x2C41664", VA = "0x2C41664")]
	private void \u070Aәޣے()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x06002077 RID: 8311 RVA: 0x000A8A08 File Offset: 0x000A6C08
	[Token(Token = "0x6002077")]
	[Address(RVA = "0x2C416C4", Offset = "0x2C416C4", VA = "0x2C416C4")]
	private void ފՖߢ\u059B()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x06002078 RID: 8312 RVA: 0x000A8A54 File Offset: 0x000A6C54
	[Token(Token = "0x6002078")]
	[Address(RVA = "0x2C41724", Offset = "0x2C41724", VA = "0x2C41724")]
	private void \u0732ڙԒࢺ()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x06002079 RID: 8313 RVA: 0x000A8AA0 File Offset: 0x000A6CA0
	[Token(Token = "0x6002079")]
	[Address(RVA = "0x2C41784", Offset = "0x2C41784", VA = "0x2C41784")]
	private void ڑߒجވ()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x0600207A RID: 8314 RVA: 0x000A8AEC File Offset: 0x000A6CEC
	[Token(Token = "0x600207A")]
	[Address(RVA = "0x2C417E4", Offset = "0x2C417E4", VA = "0x2C417E4")]
	private void Ӣ\u0592ߨׯ()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x0600207B RID: 8315 RVA: 0x000A8B38 File Offset: 0x000A6D38
	[Token(Token = "0x600207B")]
	[Address(RVA = "0x2C41844", Offset = "0x2C41844", VA = "0x2C41844")]
	private void ԣԭՋࠏ()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x0600207C RID: 8316 RVA: 0x000A8B84 File Offset: 0x000A6D84
	[Token(Token = "0x600207C")]
	[Address(RVA = "0x2C418A4", Offset = "0x2C418A4", VA = "0x2C418A4")]
	private void ԟ\u086Cޣ\u055E()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x0600207D RID: 8317 RVA: 0x000A8BD0 File Offset: 0x000A6DD0
	[Token(Token = "0x600207D")]
	[Address(RVA = "0x2C41904", Offset = "0x2C41904", VA = "0x2C41904")]
	private void Ҿࢹؼס()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x0600207E RID: 8318 RVA: 0x000A8C1C File Offset: 0x000A6E1C
	[Token(Token = "0x600207E")]
	[Address(RVA = "0x2C41964", Offset = "0x2C41964", VA = "0x2C41964")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x0600207F RID: 8319 RVA: 0x000A8C68 File Offset: 0x000A6E68
	[Token(Token = "0x600207F")]
	[Address(RVA = "0x2C419C4", Offset = "0x2C419C4", VA = "0x2C419C4")]
	private void ٴݵۃ\u05AF()
	{
		Transform transform = base.transform;
		Vector3 position = this.ࠔؼࡏݥ.position;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
	}

	// Token: 0x04000427 RID: 1063
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000427")]
	public Transform ࠔؼࡏݥ;

	// Token: 0x04000428 RID: 1064
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000428")]
	public Vector3 \u0596ߝܫو;
}
