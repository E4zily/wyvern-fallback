﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E2 RID: 226
[Token(Token = "0x20000E2")]
public class WaterWorldCollider : MonoBehaviour
{
	// Token: 0x060022F2 RID: 8946 RVA: 0x000B88C8 File Offset: 0x000B6AC8
	[Token(Token = "0x60022F2")]
	[Address(RVA = "0x2DCB6CC", Offset = "0x2DCB6CC", VA = "0x2DCB6CC")]
	public void ޠۋ\u0530\u073E()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x060022F3 RID: 8947 RVA: 0x000B88EC File Offset: 0x000B6AEC
	[Token(Token = "0x60022F3")]
	[Address(RVA = "0x2DCB6EC", Offset = "0x2DCB6EC", VA = "0x2DCB6EC")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("hh:mmtt");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x060022F4 RID: 8948 RVA: 0x000B895C File Offset: 0x000B6B5C
	[Token(Token = "0x60022F4")]
	[Address(RVA = "0x2DCB7C0", Offset = "0x2DCB7C0", VA = "0x2DCB7C0")]
	public void \u05C1ؽԜࡥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("containsStaff");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x060022F5 RID: 8949 RVA: 0x000B89CC File Offset: 0x000B6BCC
	[Token(Token = "0x60022F5")]
	[Address(RVA = "0x2DCB894", Offset = "0x2DCB894", VA = "0x2DCB894")]
	public void \u066A\u059Eټ\u085A()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x060022F6 RID: 8950 RVA: 0x000B89F0 File Offset: 0x000B6BF0
	[Token(Token = "0x60022F6")]
	[Address(RVA = "0x2DCB8B4", Offset = "0x2DCB8B4", VA = "0x2DCB8B4")]
	public void Ճࠈޛݞ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x060022F7 RID: 8951 RVA: 0x000B8A14 File Offset: 0x000B6C14
	[Token(Token = "0x60022F7")]
	[Address(RVA = "0x2DCB8D4", Offset = "0x2DCB8D4", VA = "0x2DCB8D4")]
	public void ԞԌ\u086FՇ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x060022F8 RID: 8952 RVA: 0x000B8A38 File Offset: 0x000B6C38
	[Token(Token = "0x60022F8")]
	[Address(RVA = "0x2DCB8F4", Offset = "0x2DCB8F4", VA = "0x2DCB8F4")]
	public void \u0593\u05A4Ӣ\u0602()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x060022F9 RID: 8953 RVA: 0x000B8A5C File Offset: 0x000B6C5C
	[Token(Token = "0x60022F9")]
	[Address(RVA = "0x2DCB914", Offset = "0x2DCB914", VA = "0x2DCB914")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Wear Hoodie");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x060022FA RID: 8954 RVA: 0x000B8ACC File Offset: 0x000B6CCC
	[Token(Token = "0x60022FA")]
	[Address(RVA = "0x2DCB9E8", Offset = "0x2DCB9E8", VA = "0x2DCB9E8")]
	public void ۅ\u05A6\u05A4ӵ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("{0} ({1})");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x060022FB RID: 8955 RVA: 0x000B8B3C File Offset: 0x000B6D3C
	[Token(Token = "0x60022FB")]
	[Address(RVA = "0x2DCBABC", Offset = "0x2DCBABC", VA = "0x2DCBABC")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x060022FC RID: 8956 RVA: 0x000B8BAC File Offset: 0x000B6DAC
	[Token(Token = "0x60022FC")]
	[Address(RVA = "0x2DCBB90", Offset = "0x2DCBB90", VA = "0x2DCBB90")]
	public void \u061A\u0893ڧ٥(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Skelechin");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x060022FD RID: 8957 RVA: 0x000B8C1C File Offset: 0x000B6E1C
	[Token(Token = "0x60022FD")]
	[Address(RVA = "0x2DCBC64", Offset = "0x2DCBC64", VA = "0x2DCBC64")]
	public void \u06DAٻࠕڡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ENABLE");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x060022FE RID: 8958 RVA: 0x000B8C8C File Offset: 0x000B6E8C
	[Token(Token = "0x60022FE")]
	[Address(RVA = "0x2DCBD38", Offset = "0x2DCBD38", VA = "0x2DCBD38")]
	public void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x060022FF RID: 8959 RVA: 0x000B8CFC File Offset: 0x000B6EFC
	[Token(Token = "0x60022FF")]
	[Address(RVA = "0x2DCBE0C", Offset = "0x2DCBE0C", VA = "0x2DCBE0C")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ORGTARG");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002300 RID: 8960 RVA: 0x000B8D6C File Offset: 0x000B6F6C
	[Token(Token = "0x6002300")]
	[Address(RVA = "0x2DCBEE0", Offset = "0x2DCBEE0", VA = "0x2DCBEE0")]
	public void \u059B\u081F\u05FEڂ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002301 RID: 8961 RVA: 0x000B8DDC File Offset: 0x000B6FDC
	[Token(Token = "0x6002301")]
	[Address(RVA = "0x2DCBFB4", Offset = "0x2DCBFB4", VA = "0x2DCBFB4")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002302 RID: 8962 RVA: 0x000B8E4C File Offset: 0x000B704C
	[Token(Token = "0x6002302")]
	[Address(RVA = "0x2DCC088", Offset = "0x2DCC088", VA = "0x2DCC088")]
	public void ۆڛߟ\u05A0()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002303 RID: 8963 RVA: 0x000B8E70 File Offset: 0x000B7070
	[Token(Token = "0x6002303")]
	[Address(RVA = "0x2DCC0A8", Offset = "0x2DCC0A8", VA = "0x2DCC0A8")]
	public void \u0872יԁӦ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("BN");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002304 RID: 8964 RVA: 0x000B8EE0 File Offset: 0x000B70E0
	[Token(Token = "0x6002304")]
	[Address(RVA = "0x2DCC17C", Offset = "0x2DCC17C", VA = "0x2DCC17C")]
	public void ݱ\u0832ݥ\u08B5()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002305 RID: 8965 RVA: 0x000B8F04 File Offset: 0x000B7104
	[Token(Token = "0x6002305")]
	[Address(RVA = "0x2DCC19C", Offset = "0x2DCC19C", VA = "0x2DCC19C")]
	public void \u07B2߆Ժࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002306 RID: 8966 RVA: 0x000B8F74 File Offset: 0x000B7174
	[Token(Token = "0x6002306")]
	[Address(RVA = "0x2DCC270", Offset = "0x2DCC270", VA = "0x2DCC270")]
	public void ӳڣܟޖ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002307 RID: 8967 RVA: 0x000B8FDC File Offset: 0x000B71DC
	[Token(Token = "0x6002307")]
	[Address(RVA = "0x2DCC344", Offset = "0x2DCC344", VA = "0x2DCC344")]
	public void ة\u066Dࡏԫ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Completed baking textures on frame ");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002308 RID: 8968 RVA: 0x000B904C File Offset: 0x000B724C
	[Token(Token = "0x6002308")]
	[Address(RVA = "0x2DCC418", Offset = "0x2DCC418", VA = "0x2DCC418")]
	public void \u06E2ڇ\u07BF߃(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002309 RID: 8969 RVA: 0x000B90BC File Offset: 0x000B72BC
	[Token(Token = "0x6002309")]
	[Address(RVA = "0x2DCC4EC", Offset = "0x2DCC4EC", VA = "0x2DCC4EC")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600230A RID: 8970 RVA: 0x000B912C File Offset: 0x000B732C
	[Token(Token = "0x600230A")]
	[Address(RVA = "0x2DCC5C0", Offset = "0x2DCC5C0", VA = "0x2DCC5C0")]
	public void Ԃ\u058Aܫջ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("monke is not my monke");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600230B RID: 8971 RVA: 0x000B919C File Offset: 0x000B739C
	[Token(Token = "0x600230B")]
	[Address(RVA = "0x2DCC694", Offset = "0x2DCC694", VA = "0x2DCC694")]
	public void قԙ\u0653պ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600230C RID: 8972 RVA: 0x000B920C File Offset: 0x000B740C
	[Token(Token = "0x600230C")]
	[Address(RVA = "0x2DCC768", Offset = "0x2DCC768", VA = "0x2DCC768")]
	public void \u0836Չװߟ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("NGNNoSound");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600230D RID: 8973 RVA: 0x000B9278 File Offset: 0x000B7478
	[Token(Token = "0x600230D")]
	[Address(RVA = "0x2DCC83C", Offset = "0x2DCC83C", VA = "0x2DCC83C")]
	public void Պ\u07F7\u066AՅ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600230E RID: 8974 RVA: 0x000B92E8 File Offset: 0x000B74E8
	[Token(Token = "0x600230E")]
	[Address(RVA = "0x2DCC910", Offset = "0x2DCC910", VA = "0x2DCC910")]
	public void \u0871ࢫֆ\u0899(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("PlayerDeath");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600230F RID: 8975 RVA: 0x000B9354 File Offset: 0x000B7554
	[Token(Token = "0x600230F")]
	[Address(RVA = "0x2DCC9E4", Offset = "0x2DCC9E4", VA = "0x2DCC9E4")]
	public void \u05AD\u0881ࡆݡ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("hh:mmtt");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		long active2 = 1L;
		ژه_u0878_u086B.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002310 RID: 8976 RVA: 0x000B93B8 File Offset: 0x000B75B8
	[Token(Token = "0x6002310")]
	[Address(RVA = "0x2DCCAB8", Offset = "0x2DCCAB8", VA = "0x2DCCAB8")]
	public void \u083FԤթ\u07B2(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ErrorScreen");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002311 RID: 8977 RVA: 0x000B9428 File Offset: 0x000B7628
	[Token(Token = "0x6002311")]
	[Address(RVA = "0x2DCCB8C", Offset = "0x2DCCB8C", VA = "0x2DCCB8C")]
	public void ߂ڞ\u0600\u07FB(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(" and for the price of ");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002312 RID: 8978 RVA: 0x000B9498 File Offset: 0x000B7698
	[Token(Token = "0x6002312")]
	[Address(RVA = "0x2DCCC60", Offset = "0x2DCCC60", VA = "0x2DCCC60")]
	public void ࠏڐ\u088Bօ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("You are on an outdated version of Capuchin. Your version is ");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		long active4 = 0L;
		օק_u081Dչ.SetActive(active4 != 0L);
	}

	// Token: 0x06002313 RID: 8979 RVA: 0x000B9500 File Offset: 0x000B7700
	[Token(Token = "0x6002313")]
	[Address(RVA = "0x2DCCD34", Offset = "0x2DCCD34", VA = "0x2DCCD34")]
	public void ޛװہװ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Skelechin");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002314 RID: 8980 RVA: 0x000B9570 File Offset: 0x000B7770
	[Token(Token = "0x6002314")]
	[Address(RVA = "0x2DCCE08", Offset = "0x2DCCE08", VA = "0x2DCCE08")]
	public void Ոڷد\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002315 RID: 8981 RVA: 0x000B95E0 File Offset: 0x000B77E0
	[Token(Token = "0x6002315")]
	[Address(RVA = "0x2DCCEDC", Offset = "0x2DCCEDC", VA = "0x2DCCEDC")]
	public void ԁؼՖռ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("You are on an outdated version of Capuchin. Your version is ");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002316 RID: 8982 RVA: 0x000B9650 File Offset: 0x000B7850
	[Token(Token = "0x6002316")]
	[Address(RVA = "0x2DCCFB0", Offset = "0x2DCCFB0", VA = "0x2DCCFB0")]
	public void ފԅ\u0881ݾ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		throw new MissingMethodException();
	}

	// Token: 0x06002317 RID: 8983 RVA: 0x000B96BC File Offset: 0x000B78BC
	[Token(Token = "0x6002317")]
	[Address(RVA = "0x2DCD084", Offset = "0x2DCD084", VA = "0x2DCD084")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002318 RID: 8984 RVA: 0x000B972C File Offset: 0x000B792C
	[Token(Token = "0x6002318")]
	[Address(RVA = "0x2DCD158", Offset = "0x2DCD158", VA = "0x2DCD158")]
	public void ۓڿ\u087Eݓ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("/");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002319 RID: 8985 RVA: 0x000B979C File Offset: 0x000B799C
	[Token(Token = "0x6002319")]
	[Address(RVA = "0x2DCD22C", Offset = "0x2DCD22C", VA = "0x2DCD22C")]
	public void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("typesOfTalk");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600231A RID: 8986 RVA: 0x000B980C File Offset: 0x000B7A0C
	[Token(Token = "0x600231A")]
	[Address(RVA = "0x2DCD300", Offset = "0x2DCD300", VA = "0x2DCD300")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Not connected to room");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600231B RID: 8987 RVA: 0x000B987C File Offset: 0x000B7A7C
	[Token(Token = "0x600231B")]
	[Address(RVA = "0x2DCD3D4", Offset = "0x2DCD3D4", VA = "0x2DCD3D4")]
	public void \u05B7\u05F8\u05A3ߣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Wear Hoodie");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		long active4 = 1L;
		օק_u081Dչ.SetActive(active4 != 0L);
	}

	// Token: 0x0600231C RID: 8988 RVA: 0x000B98E4 File Offset: 0x000B7AE4
	[Token(Token = "0x600231C")]
	[Address(RVA = "0x2DCD4A8", Offset = "0x2DCD4A8", VA = "0x2DCD4A8")]
	public void ݛࠈ\u07F0ޱ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600231D RID: 8989 RVA: 0x000B9908 File Offset: 0x000B7B08
	[Token(Token = "0x600231D")]
	[Address(RVA = "0x2DCD4C8", Offset = "0x2DCD4C8", VA = "0x2DCD4C8")]
	public void \u05F6\u05A6ӓ\u06DC()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600231E RID: 8990 RVA: 0x000B992C File Offset: 0x000B7B2C
	[Token(Token = "0x600231E")]
	[Address(RVA = "0x2DCD4E8", Offset = "0x2DCD4E8", VA = "0x2DCD4E8")]
	public void \u0732\u089Fࢦߣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("isLava");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600231F RID: 8991 RVA: 0x000B999C File Offset: 0x000B7B9C
	[Token(Token = "0x600231F")]
	[Address(RVA = "0x2DCD5BC", Offset = "0x2DCD5BC", VA = "0x2DCD5BC")]
	public void حتݻ\u05B0()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002320 RID: 8992 RVA: 0x000B99C0 File Offset: 0x000B7BC0
	[Token(Token = "0x6002320")]
	[Address(RVA = "0x2DCD5DC", Offset = "0x2DCD5DC", VA = "0x2DCD5DC")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002321 RID: 8993 RVA: 0x000B9A30 File Offset: 0x000B7C30
	[Token(Token = "0x6002321")]
	[Address(RVA = "0x2DCD6B0", Offset = "0x2DCD6B0", VA = "0x2DCD6B0")]
	public void ت\u05F9ޅ\u059A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002322 RID: 8994 RVA: 0x000B9AA0 File Offset: 0x000B7CA0
	[Token(Token = "0x6002322")]
	[Address(RVA = "0x2DCD784", Offset = "0x2DCD784", VA = "0x2DCD784")]
	public void \u07BF\u0705\u0824ڮ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("HandL");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		this.\u060A\u05CEӑՆ.SetActive(active3 != 0L);
	}

	// Token: 0x06002323 RID: 8995 RVA: 0x000B9B08 File Offset: 0x000B7D08
	[Token(Token = "0x6002323")]
	[Address(RVA = "0x2DCD858", Offset = "0x2DCD858", VA = "0x2DCD858")]
	public void הԥ\u05B5ݴ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002324 RID: 8996 RVA: 0x000B9B2C File Offset: 0x000B7D2C
	[Token(Token = "0x6002324")]
	[Address(RVA = "0x2DCD878", Offset = "0x2DCD878", VA = "0x2DCD878")]
	public void ӭࡖݲ\u05BD()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002325 RID: 8997 RVA: 0x000B9B50 File Offset: 0x000B7D50
	[Token(Token = "0x6002325")]
	[Address(RVA = "0x2DCD898", Offset = "0x2DCD898", VA = "0x2DCD898")]
	public void \u074C\u0830\u0594ԡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002326 RID: 8998 RVA: 0x000B9BC0 File Offset: 0x000B7DC0
	[Token(Token = "0x6002326")]
	[Address(RVA = "0x2DCD96C", Offset = "0x2DCD96C", VA = "0x2DCD96C")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("goDownRPC");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002327 RID: 8999 RVA: 0x000B9C30 File Offset: 0x000B7E30
	[Token(Token = "0x6002327")]
	[Address(RVA = "0x2DCDA40", Offset = "0x2DCDA40", VA = "0x2DCDA40")]
	public void ք\u05FEؽ\u061E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002328 RID: 9000 RVA: 0x000B9CA0 File Offset: 0x000B7EA0
	[Token(Token = "0x6002328")]
	[Address(RVA = "0x2DCDB14", Offset = "0x2DCDB14", VA = "0x2DCDB14")]
	public void \u0745\u058EԎݛ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("TurnAmount");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002329 RID: 9001 RVA: 0x000B9D10 File Offset: 0x000B7F10
	[Token(Token = "0x6002329")]
	[Address(RVA = "0x2DCDBE8", Offset = "0x2DCDBE8", VA = "0x2DCDBE8")]
	public void ئأԵߑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Diffuse");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600232A RID: 9002 RVA: 0x000B9D80 File Offset: 0x000B7F80
	[Token(Token = "0x600232A")]
	[Address(RVA = "0x2DCDCBC", Offset = "0x2DCDCBC", VA = "0x2DCDCBC")]
	public void Փ\u06DF\u0839ԟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Starting to bake textures on frame ");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600232B RID: 9003 RVA: 0x000B9DF0 File Offset: 0x000B7FF0
	[Token(Token = "0x600232B")]
	[Address(RVA = "0x2DCDD90", Offset = "0x2DCDD90", VA = "0x2DCDD90")]
	public void \u087DىԳܚ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600232C RID: 9004 RVA: 0x000B9E60 File Offset: 0x000B8060
	[Token(Token = "0x600232C")]
	[Address(RVA = "0x2DCDE64", Offset = "0x2DCDE64", VA = "0x2DCDE64")]
	public void ޝԖ\u0836\u06D8()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600232D RID: 9005 RVA: 0x000B9E84 File Offset: 0x000B8084
	[Token(Token = "0x600232D")]
	[Address(RVA = "0x2DCDE84", Offset = "0x2DCDE84", VA = "0x2DCDE84")]
	public void ࢺճ\u05A0ڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600232E RID: 9006 RVA: 0x000B9EF4 File Offset: 0x000B80F4
	[Token(Token = "0x600232E")]
	[Address(RVA = "0x2DCDF58", Offset = "0x2DCDF58", VA = "0x2DCDF58")]
	public void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Updating Material to: ");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600232F RID: 9007 RVA: 0x000B9F64 File Offset: 0x000B8164
	[Token(Token = "0x600232F")]
	[Address(RVA = "0x2DCE02C", Offset = "0x2DCE02C", VA = "0x2DCE02C")]
	public void Ӛ\u055D\u0651Խ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002330 RID: 9008 RVA: 0x000B9FD4 File Offset: 0x000B81D4
	[Token(Token = "0x6002330")]
	[Address(RVA = "0x2DCE100", Offset = "0x2DCE100", VA = "0x2DCE100")]
	public void ۷ޞ\u07AFߍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("BN");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002331 RID: 9009 RVA: 0x000BA044 File Offset: 0x000B8244
	[Token(Token = "0x6002331")]
	[Address(RVA = "0x2DCE1D4", Offset = "0x2DCE1D4", VA = "0x2DCE1D4")]
	public void \u0558ݕݤݮ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002332 RID: 9010 RVA: 0x000BA068 File Offset: 0x000B8268
	[Token(Token = "0x6002332")]
	[Address(RVA = "0x2DCE1F4", Offset = "0x2DCE1F4", VA = "0x2DCE1F4")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002333 RID: 9011 RVA: 0x000BA0D8 File Offset: 0x000B82D8
	[Token(Token = "0x6002333")]
	[Address(RVA = "0x2DCE2C8", Offset = "0x2DCE2C8", VA = "0x2DCE2C8")]
	public void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002334 RID: 9012 RVA: 0x000BA148 File Offset: 0x000B8348
	[Token(Token = "0x6002334")]
	[Address(RVA = "0x2DCE39C", Offset = "0x2DCE39C", VA = "0x2DCE39C")]
	public void \u0870߀ڿߔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("run");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002335 RID: 9013 RVA: 0x000BA1B8 File Offset: 0x000B83B8
	[Token(Token = "0x6002335")]
	[Address(RVA = "0x2DCE470", Offset = "0x2DCE470", VA = "0x2DCE470")]
	public void ػԚԃڻ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Tagged");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002336 RID: 9014 RVA: 0x000BA228 File Offset: 0x000B8428
	[Token(Token = "0x6002336")]
	[Address(RVA = "0x2DCE544", Offset = "0x2DCE544", VA = "0x2DCE544")]
	public void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002337 RID: 9015 RVA: 0x000BA298 File Offset: 0x000B8498
	[Token(Token = "0x6002337")]
	[Address(RVA = "0x2DCE618", Offset = "0x2DCE618", VA = "0x2DCE618")]
	public void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ErrorScreen");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002338 RID: 9016 RVA: 0x000BA308 File Offset: 0x000B8508
	[Token(Token = "0x6002338")]
	[Address(RVA = "0x2DCE6EC", Offset = "0x2DCE6EC", VA = "0x2DCE6EC")]
	public void \u070C\u05FD\u07F9ܬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("EnableCosmetic");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002339 RID: 9017 RVA: 0x000BA378 File Offset: 0x000B8578
	[Token(Token = "0x6002339")]
	[Address(RVA = "0x2DCE7C0", Offset = "0x2DCE7C0", VA = "0x2DCE7C0")]
	public void ࡢض\u07ACנ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600233A RID: 9018 RVA: 0x000BA39C File Offset: 0x000B859C
	[Token(Token = "0x600233A")]
	[Address(RVA = "0x2DCE7E0", Offset = "0x2DCE7E0", VA = "0x2DCE7E0")]
	public void \u086Bԍࡊڭ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600233B RID: 9019 RVA: 0x000BA3C0 File Offset: 0x000B85C0
	[Token(Token = "0x600233B")]
	[Address(RVA = "0x2DCE800", Offset = "0x2DCE800", VA = "0x2DCE800")]
	public void Start()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600233C RID: 9020 RVA: 0x000BA3E4 File Offset: 0x000B85E4
	[Token(Token = "0x600233C")]
	[Address(RVA = "0x2DCE820", Offset = "0x2DCE820", VA = "0x2DCE820")]
	public void ڣֆ\u07F4ڌ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600233D RID: 9021 RVA: 0x000BA408 File Offset: 0x000B8608
	[Token(Token = "0x600233D")]
	[Address(RVA = "0x2DCE840", Offset = "0x2DCE840", VA = "0x2DCE840")]
	public void րۀ\u0701ԝ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600233E RID: 9022 RVA: 0x000BA478 File Offset: 0x000B8678
	[Token(Token = "0x600233E")]
	[Address(RVA = "0x2DCE914", Offset = "0x2DCE914", VA = "0x2DCE914")]
	public void \u073Bݲձݕ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600233F RID: 9023 RVA: 0x000BA49C File Offset: 0x000B869C
	[Token(Token = "0x600233F")]
	[Address(RVA = "0x2DCE934", Offset = "0x2DCE934", VA = "0x2DCE934")]
	public void Ԯ\u0883\u0591\u066C()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
	}

	// Token: 0x06002340 RID: 9024 RVA: 0x000BA4B8 File Offset: 0x000B86B8
	[Token(Token = "0x6002340")]
	[Address(RVA = "0x2DCE954", Offset = "0x2DCE954", VA = "0x2DCE954")]
	public void ۿࢹ\u0705\u0825()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
	}

	// Token: 0x06002341 RID: 9025 RVA: 0x000BA4D4 File Offset: 0x000B86D4
	[Token(Token = "0x6002341")]
	[Address(RVA = "0x2DCE974", Offset = "0x2DCE974", VA = "0x2DCE974")]
	public void ܮݫ߅ࡃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002342 RID: 9026 RVA: 0x000BA544 File Offset: 0x000B8744
	[Token(Token = "0x6002342")]
	[Address(RVA = "0x2DCEA48", Offset = "0x2DCEA48", VA = "0x2DCEA48")]
	public void \u0609ۯ\u05B4ؼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ErrorScreen");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002343 RID: 9027 RVA: 0x000BA5B4 File Offset: 0x000B87B4
	[Token(Token = "0x6002343")]
	[Address(RVA = "0x2DCEB1C", Offset = "0x2DCEB1C", VA = "0x2DCEB1C")]
	public void \u064FӆࡒԲ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002344 RID: 9028 RVA: 0x000BA5D8 File Offset: 0x000B87D8
	[Token(Token = "0x6002344")]
	[Address(RVA = "0x2DCEB3C", Offset = "0x2DCEB3C", VA = "0x2DCEB3C")]
	public void ߒ\u065EՎࡖ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002345 RID: 9029 RVA: 0x000BA5FC File Offset: 0x000B87FC
	[Token(Token = "0x6002345")]
	[Address(RVA = "0x2DCEB5C", Offset = "0x2DCEB5C", VA = "0x2DCEB5C")]
	public void ڷ\u0826ӹڥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002346 RID: 9030 RVA: 0x000BA66C File Offset: 0x000B886C
	[Token(Token = "0x6002346")]
	[Address(RVA = "0x2DCEC30", Offset = "0x2DCEC30", VA = "0x2DCEC30")]
	public void \u06E9\u0740մ\u0746(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Combine textures & build combined mesh using coroutine");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002347 RID: 9031 RVA: 0x000BA6DC File Offset: 0x000B88DC
	[Token(Token = "0x6002347")]
	[Address(RVA = "0x2DCED04", Offset = "0x2DCED04", VA = "0x2DCED04")]
	public void ב\u07AFࡩ\u07FB(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("DisableCosmetic");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002348 RID: 9032 RVA: 0x000BA748 File Offset: 0x000B8948
	[Token(Token = "0x6002348")]
	[Address(RVA = "0x2DCEDD8", Offset = "0x2DCEDD8", VA = "0x2DCEDD8")]
	public void ߂ӹ\u05C6\u07F9(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Body");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002349 RID: 9033 RVA: 0x000BA7B8 File Offset: 0x000B89B8
	[Token(Token = "0x6002349")]
	[Address(RVA = "0x2DCEEAC", Offset = "0x2DCEEAC", VA = "0x2DCEEAC")]
	public void \u059Cݝ\u058E۳(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_WobbleZ");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600234A RID: 9034 RVA: 0x000BA828 File Offset: 0x000B8A28
	[Token(Token = "0x600234A")]
	[Address(RVA = "0x2DCEF80", Offset = "0x2DCEF80", VA = "0x2DCEF80")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Horizontal");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600234B RID: 9035 RVA: 0x000BA898 File Offset: 0x000B8A98
	[Token(Token = "0x600234B")]
	[Address(RVA = "0x2DCF054", Offset = "0x2DCF054", VA = "0x2DCF054")]
	public void Ӱ\u061Cإ\u06E1(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PRESS AGAIN TO CONFIRM");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600234C RID: 9036 RVA: 0x000BA908 File Offset: 0x000B8B08
	[Token(Token = "0x600234C")]
	[Address(RVA = "0x2DCF128", Offset = "0x2DCF128", VA = "0x2DCF128")]
	public void ބՅ١\u082D()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600234D RID: 9037 RVA: 0x000BA92C File Offset: 0x000B8B2C
	[Token(Token = "0x600234D")]
	[Address(RVA = "0x2DCF148", Offset = "0x2DCF148", VA = "0x2DCF148")]
	public WaterWorldCollider()
	{
	}

	// Token: 0x0600234E RID: 9038 RVA: 0x000BA940 File Offset: 0x000B8B40
	[Token(Token = "0x600234E")]
	[Address(RVA = "0x2DCF150", Offset = "0x2DCF150", VA = "0x2DCF150")]
	public void әݓ\u0610ժ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		long active3 = 1L;
		߉Ӌ_u059A_u.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600234F RID: 9039 RVA: 0x000BA9A8 File Offset: 0x000B8BA8
	[Token(Token = "0x600234F")]
	[Address(RVA = "0x2DCF224", Offset = "0x2DCF224", VA = "0x2DCF224")]
	public void ہۼآԄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Round end");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002350 RID: 9040 RVA: 0x000BAA18 File Offset: 0x000B8C18
	[Token(Token = "0x6002350")]
	[Address(RVA = "0x2DCF2F8", Offset = "0x2DCF2F8", VA = "0x2DCF2F8")]
	public void \u05FBӍݟؾ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002351 RID: 9041 RVA: 0x000BAA80 File Offset: 0x000B8C80
	[Token(Token = "0x6002351")]
	[Address(RVA = "0x2DCF3CC", Offset = "0x2DCF3CC", VA = "0x2DCF3CC")]
	public void ࡥ\u07A7\u065Eӽ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002352 RID: 9042 RVA: 0x000BAAA4 File Offset: 0x000B8CA4
	[Token(Token = "0x6002352")]
	[Address(RVA = "0x2DCF3EC", Offset = "0x2DCF3EC", VA = "0x2DCF3EC")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("On");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002353 RID: 9043 RVA: 0x000BAB14 File Offset: 0x000B8D14
	[Token(Token = "0x6002353")]
	[Address(RVA = "0x2DCF4C0", Offset = "0x2DCF4C0", VA = "0x2DCF4C0")]
	public void ܬԛ٣\u07FF()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002354 RID: 9044 RVA: 0x000BAB38 File Offset: 0x000B8D38
	[Token(Token = "0x6002354")]
	[Address(RVA = "0x2DCF4E0", Offset = "0x2DCF4E0", VA = "0x2DCF4E0")]
	public void \u0589\u0740\u05C6ӧ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Thumb");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002355 RID: 9045 RVA: 0x000BABA8 File Offset: 0x000B8DA8
	[Token(Token = "0x6002355")]
	[Address(RVA = "0x2DCF5B4", Offset = "0x2DCF5B4", VA = "0x2DCF5B4")]
	public void ࢲ\u061C\u0817ݽ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002356 RID: 9046 RVA: 0x000BAC18 File Offset: 0x000B8E18
	[Token(Token = "0x6002356")]
	[Address(RVA = "0x2DCF688", Offset = "0x2DCF688", VA = "0x2DCF688")]
	public void ل\u0732ߍӒ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002357 RID: 9047 RVA: 0x000BAC88 File Offset: 0x000B8E88
	[Token(Token = "0x6002357")]
	[Address(RVA = "0x2DCF75C", Offset = "0x2DCF75C", VA = "0x2DCF75C")]
	public void տ\u06D9ܭࠊ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Target");
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active = 1L;
		߉Ӌ_u059A_u.SetActive(active != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active2 = 1L;
		օק_u081Dչ.SetActive(active2 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active3 = 0L;
		u060A_u05CEӑՆ.SetActive(active3 != 0L);
	}

	// Token: 0x06002358 RID: 9048 RVA: 0x000BACE8 File Offset: 0x000B8EE8
	[Token(Token = "0x6002358")]
	[Address(RVA = "0x2DCF830", Offset = "0x2DCF830", VA = "0x2DCF830")]
	public void ݶߔ\u081Aպ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002359 RID: 9049 RVA: 0x000BAD0C File Offset: 0x000B8F0C
	[Token(Token = "0x6002359")]
	[Address(RVA = "0x2DCF850", Offset = "0x2DCF850", VA = "0x2DCF850")]
	public void վࡌڬ\u0591()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600235A RID: 9050 RVA: 0x000BAD30 File Offset: 0x000B8F30
	[Token(Token = "0x600235A")]
	[Address(RVA = "0x2DCF870", Offset = "0x2DCF870", VA = "0x2DCF870")]
	public void \u0834\u0817ރࡔ()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x0600235B RID: 9051 RVA: 0x000BAD54 File Offset: 0x000B8F54
	[Token(Token = "0x600235B")]
	[Address(RVA = "0x2DCF890", Offset = "0x2DCF890", VA = "0x2DCF890")]
	public void ލ\u0892\u064B\u055B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeToTagged");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600235C RID: 9052 RVA: 0x000BADC4 File Offset: 0x000B8FC4
	[Token(Token = "0x600235C")]
	[Address(RVA = "0x2DCF964", Offset = "0x2DCF964", VA = "0x2DCF964")]
	public void ܯר\u05C7ڗ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active = 1L;
		߉Ӌ_u059A_u.SetActive(active != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active2 = 0L;
		օק_u081Dչ.SetActive(active2 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active3 = 0L;
		u060A_u05CEӑՆ.SetActive(active3 != 0L);
	}

	// Token: 0x0600235D RID: 9053 RVA: 0x000BAE28 File Offset: 0x000B9028
	[Token(Token = "0x600235D")]
	[Address(RVA = "0x2DCFA38", Offset = "0x2DCFA38", VA = "0x2DCFA38")]
	public void \u083Eܙ\u07FD\u0706(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("isLava");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600235E RID: 9054 RVA: 0x000BAE98 File Offset: 0x000B9098
	[Token(Token = "0x600235E")]
	[Address(RVA = "0x2DCFB0C", Offset = "0x2DCFB0C", VA = "0x2DCFB0C")]
	public void \u065F\u0597ծܡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Collided");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 1L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 0L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x0600235F RID: 9055 RVA: 0x000BAF08 File Offset: 0x000B9108
	[Token(Token = "0x600235F")]
	[Address(RVA = "0x2DCFBE0", Offset = "0x2DCFBE0", VA = "0x2DCFBE0")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("containsStaff");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002360 RID: 9056 RVA: 0x000BAF78 File Offset: 0x000B9178
	[Token(Token = "0x6002360")]
	[Address(RVA = "0x2DCFCB4", Offset = "0x2DCFCB4", VA = "0x2DCFCB4")]
	public void Ԁוև\u065B()
	{
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
	}

	// Token: 0x06002361 RID: 9057 RVA: 0x000BAF9C File Offset: 0x000B919C
	[Token(Token = "0x6002361")]
	[Address(RVA = "0x2DCFCD4", Offset = "0x2DCFCD4", VA = "0x2DCFCD4")]
	public void Ԇܥډݑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Found Gameobject: ");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 0L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 1L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x06002362 RID: 9058 RVA: 0x000BB00C File Offset: 0x000B920C
	[Token(Token = "0x6002362")]
	[Address(RVA = "0x2DCFDA8", Offset = "0x2DCFDA8", VA = "0x2DCFDA8")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("True");
		GameObject ژه_u0878_u086B = this.ژه\u0878\u086B;
		long active = 0L;
		ژه_u0878_u086B.SetActive(active != 0L);
		GameObject ߉Ӌ_u059A_u = this.߉Ӌ\u059A\u0701;
		long active2 = 1L;
		߉Ӌ_u059A_u.SetActive(active2 != 0L);
		GameObject օק_u081Dչ = this.օק\u081Dչ;
		long active3 = 1L;
		օק_u081Dչ.SetActive(active3 != 0L);
		GameObject u060A_u05CEӑՆ = this.\u060A\u05CEӑՆ;
		long active4 = 0L;
		u060A_u05CEӑՆ.SetActive(active4 != 0L);
	}

	// Token: 0x04000473 RID: 1139
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000473")]
	public GameObject ژه\u0878\u086B;

	// Token: 0x04000474 RID: 1140
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000474")]
	public GameObject ߉Ӌ\u059A\u0701;

	// Token: 0x04000475 RID: 1141
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000475")]
	public GameObject օק\u081Dչ;

	// Token: 0x04000476 RID: 1142
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000476")]
	public GameObject \u060A\u05CEӑՆ;
}
