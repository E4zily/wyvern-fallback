﻿using System;
using Cpp2IlInjected;
using Locomotion;
using UnityEngine;

// Token: 0x0200008A RID: 138
[Token(Token = "0x200008A")]
public class Pet : MonoBehaviour
{
	// Token: 0x06001456 RID: 5206 RVA: 0x000719CC File Offset: 0x0006FBCC
	[Token(Token = "0x6001456")]
	[Address(RVA = "0x2EA8260", Offset = "0x2EA8260", VA = "0x2EA8260")]
	private void ֆࡤ\u070Fד()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001457 RID: 5207 RVA: 0x00071B4C File Offset: 0x0006FD4C
	[Token(Token = "0x6001457")]
	[Address(RVA = "0x2EA87BC", Offset = "0x2EA87BC", VA = "0x2EA87BC")]
	private void غڭ\u088DԎ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001458 RID: 5208 RVA: 0x00071CD4 File Offset: 0x0006FED4
	[Token(Token = "0x6001458")]
	[Address(RVA = "0x2EA8D18", Offset = "0x2EA8D18", VA = "0x2EA8D18")]
	private void ڰڬࡎف()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001459 RID: 5209 RVA: 0x00071E5C File Offset: 0x0007005C
	[Token(Token = "0x6001459")]
	[Address(RVA = "0x2EA9270", Offset = "0x2EA9270", VA = "0x2EA9270")]
	private void \u058DӂԆߕ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600145A RID: 5210 RVA: 0x00071FE4 File Offset: 0x000701E4
	[Token(Token = "0x600145A")]
	[Address(RVA = "0x2EA97CC", Offset = "0x2EA97CC", VA = "0x2EA97CC")]
	private void \u05FEօ\u06D7ࡁ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x0600145B RID: 5211 RVA: 0x00072018 File Offset: 0x00070218
	[Token(Token = "0x600145B")]
	[Address(RVA = "0x2EA9868", Offset = "0x2EA9868", VA = "0x2EA9868")]
	private void ۲\u0874ՏԾ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600145C RID: 5212 RVA: 0x0007219C File Offset: 0x0007039C
	[Token(Token = "0x600145C")]
	[Address(RVA = "0x2EA9DC4", Offset = "0x2EA9DC4", VA = "0x2EA9DC4")]
	private void ࢧӎࡥࡒ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600145D RID: 5213 RVA: 0x00072324 File Offset: 0x00070524
	[Token(Token = "0x600145D")]
	[Address(RVA = "0x2EAA320", Offset = "0x2EAA320", VA = "0x2EAA320")]
	private void Ԉ۴ࡉࢬ()
	{
		this.ֆࡤ\u070Fד();
	}

	// Token: 0x0600145E RID: 5214 RVA: 0x00072338 File Offset: 0x00070538
	[Token(Token = "0x600145E")]
	[Address(RVA = "0x2EAA324", Offset = "0x2EAA324", VA = "0x2EAA324")]
	private void כԍ\u058B\u0882()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600145F RID: 5215 RVA: 0x000724B8 File Offset: 0x000706B8
	[Token(Token = "0x600145F")]
	[Address(RVA = "0x2EAA878", Offset = "0x2EAA878", VA = "0x2EAA878")]
	private void ߃ցز\u0557()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001460 RID: 5216 RVA: 0x0007262C File Offset: 0x0007082C
	[Token(Token = "0x6001460")]
	[Address(RVA = "0x2EAADD4", Offset = "0x2EAADD4", VA = "0x2EAADD4")]
	private void ժ\u065Dԯࡘ()
	{
		this.ԥࡉחس();
	}

	// Token: 0x06001461 RID: 5217 RVA: 0x00072640 File Offset: 0x00070840
	[Token(Token = "0x6001461")]
	[Address(RVA = "0x2EAB334", Offset = "0x2EAB334", VA = "0x2EAB334")]
	private void ޠۋ\u0530\u073E()
	{
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x06001462 RID: 5218 RVA: 0x00072664 File Offset: 0x00070864
	[Token(Token = "0x6001462")]
	[Address(RVA = "0x2EAB3D0", Offset = "0x2EAB3D0", VA = "0x2EAB3D0")]
	private void ڦکӁ\u06E2()
	{
		this.Ӕ\u07ABԝ\u07F5();
	}

	// Token: 0x06001463 RID: 5219 RVA: 0x00072678 File Offset: 0x00070878
	[Token(Token = "0x6001463")]
	[Address(RVA = "0x2EAB92C", Offset = "0x2EAB92C", VA = "0x2EAB92C")]
	private void \u089F\u085Fէ\u059A()
	{
		this.غڭ\u088DԎ();
	}

	// Token: 0x06001464 RID: 5220 RVA: 0x0007268C File Offset: 0x0007088C
	[Token(Token = "0x6001464")]
	[Address(RVA = "0x2EAB930", Offset = "0x2EAB930", VA = "0x2EAB930")]
	private void Ӣ\u0592ߨׯ()
	{
		this.پ٨ݓ\u055C();
	}

	// Token: 0x06001465 RID: 5221 RVA: 0x000726A0 File Offset: 0x000708A0
	[Token(Token = "0x6001465")]
	[Address(RVA = "0x2EABE80", Offset = "0x2EABE80", VA = "0x2EABE80")]
	private void ۼ٧עأ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001466 RID: 5222 RVA: 0x00072824 File Offset: 0x00070A24
	[Token(Token = "0x6001466")]
	[Address(RVA = "0x2EAC3DC", Offset = "0x2EAC3DC", VA = "0x2EAC3DC")]
	private void \u05AC\u07F0\u07EEࡥ()
	{
		this.ޙӃڄۈ();
	}

	// Token: 0x06001467 RID: 5223 RVA: 0x00072838 File Offset: 0x00070A38
	[Token(Token = "0x6001467")]
	[Address(RVA = "0x2EAC93C", Offset = "0x2EAC93C", VA = "0x2EAC93C")]
	private void ٴݵۃ\u05AF()
	{
		this.\u05A4ع\u073F\u061C();
	}

	// Token: 0x06001468 RID: 5224 RVA: 0x0007284C File Offset: 0x00070A4C
	[Token(Token = "0x6001468")]
	[Address(RVA = "0x2EACE98", Offset = "0x2EACE98", VA = "0x2EACE98")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		this.۲\u0874ՏԾ();
	}

	// Token: 0x06001469 RID: 5225 RVA: 0x00072860 File Offset: 0x00070A60
	[Token(Token = "0x6001469")]
	[Address(RVA = "0x2EACE9C", Offset = "0x2EACE9C", VA = "0x2EACE9C")]
	private void ԣԭՋࠏ()
	{
		this.߃ցز\u0557();
	}

	// Token: 0x0600146A RID: 5226 RVA: 0x00072874 File Offset: 0x00070A74
	[Token(Token = "0x600146A")]
	[Address(RVA = "0x2EACEA0", Offset = "0x2EACEA0", VA = "0x2EACEA0")]
	private void عۻԂ\u055E()
	{
		Player كݕ_u05F3_u = Player.كݕ\u05F3\u0589;
		Animator ե_u0598ࡄࢶ;
		this.ե\u0598ࡄࢶ = ե_u0598ࡄࢶ;
	}

	// Token: 0x0600146B RID: 5227 RVA: 0x00072894 File Offset: 0x00070A94
	[Token(Token = "0x600146B")]
	[Address(RVA = "0x2EACF3C", Offset = "0x2EACF3C", VA = "0x2EACF3C")]
	private void \u07B2\u0823ծݠ()
	{
		this.\u05C8߆կ\u083D();
	}

	// Token: 0x0600146C RID: 5228 RVA: 0x000728A8 File Offset: 0x00070AA8
	[Token(Token = "0x600146C")]
	[Address(RVA = "0x2EAD49C", Offset = "0x2EAD49C", VA = "0x2EAD49C")]
	private void \u055Bӄߚۑ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
	}

	// Token: 0x0600146D RID: 5229 RVA: 0x00072A28 File Offset: 0x00070C28
	[Token(Token = "0x600146D")]
	[Address(RVA = "0x2EAD9F4", Offset = "0x2EAD9F4", VA = "0x2EAD9F4")]
	private void ݸԲ\u0616Ԫ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x0600146E RID: 5230 RVA: 0x00072A5C File Offset: 0x00070C5C
	[Token(Token = "0x600146E")]
	[Address(RVA = "0x2EAADD8", Offset = "0x2EAADD8", VA = "0x2EAADD8")]
	private void ԥࡉחس()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600146F RID: 5231 RVA: 0x00072BE4 File Offset: 0x00070DE4
	[Token(Token = "0x600146F")]
	[Address(RVA = "0x2EADA90", Offset = "0x2EADA90", VA = "0x2EADA90")]
	private void \u05B2تࢣނ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001470 RID: 5232 RVA: 0x00072D68 File Offset: 0x00070F68
	[Token(Token = "0x6001470")]
	[Address(RVA = "0x2EADFE8", Offset = "0x2EADFE8", VA = "0x2EADFE8")]
	private void Update()
	{
		this.پ٨ݓ\u055C();
	}

	// Token: 0x06001471 RID: 5233 RVA: 0x00072D7C File Offset: 0x00070F7C
	[Token(Token = "0x6001471")]
	[Address(RVA = "0x2EADFEC", Offset = "0x2EADFEC", VA = "0x2EADFEC")]
	private void Start()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x06001472 RID: 5234 RVA: 0x00072DB0 File Offset: 0x00070FB0
	[Token(Token = "0x6001472")]
	[Address(RVA = "0x2EAC3E0", Offset = "0x2EAC3E0", VA = "0x2EAC3E0")]
	private void ޙӃڄۈ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001473 RID: 5235 RVA: 0x00072F38 File Offset: 0x00071138
	[Token(Token = "0x6001473")]
	[Address(RVA = "0x2EAE088", Offset = "0x2EAE088", VA = "0x2EAE088")]
	private void Ԝ\u055Fӛڏ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001474 RID: 5236 RVA: 0x000730BC File Offset: 0x000712BC
	[Token(Token = "0x6001474")]
	[Address(RVA = "0x2EAE5E4", Offset = "0x2EAE5E4", VA = "0x2EAE5E4")]
	private void ؿ\u0617ؤ\u073F()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001475 RID: 5237 RVA: 0x00073240 File Offset: 0x00071440
	[Token(Token = "0x6001475")]
	[Address(RVA = "0x2EAEB3C", Offset = "0x2EAEB3C", VA = "0x2EAEB3C")]
	private void \u07F7ܙײ\u05B5()
	{
		this.ޙӃڄۈ();
	}

	// Token: 0x06001476 RID: 5238 RVA: 0x00073254 File Offset: 0x00071454
	[Token(Token = "0x6001476")]
	[Address(RVA = "0x2EAEB40", Offset = "0x2EAEB40", VA = "0x2EAEB40")]
	private void \u064B\u055A\u0650گ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001477 RID: 5239 RVA: 0x000733D8 File Offset: 0x000715D8
	[Token(Token = "0x6001477")]
	[Address(RVA = "0x2EAF09C", Offset = "0x2EAF09C", VA = "0x2EAF09C")]
	private void ۆڛߟ\u05A0()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x06001478 RID: 5240 RVA: 0x0007340C File Offset: 0x0007160C
	[Token(Token = "0x6001478")]
	[Address(RVA = "0x2EAF138", Offset = "0x2EAF138", VA = "0x2EAF138")]
	private void וࡪךӧ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x06001479 RID: 5241 RVA: 0x00073440 File Offset: 0x00071640
	[Token(Token = "0x6001479")]
	[Address(RVA = "0x2EAF1D4", Offset = "0x2EAF1D4", VA = "0x2EAF1D4")]
	private void ߒ\u065EՎࡖ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x0600147A RID: 5242 RVA: 0x00073474 File Offset: 0x00071674
	[Token(Token = "0x600147A")]
	[Address(RVA = "0x2EAF270", Offset = "0x2EAF270", VA = "0x2EAF270")]
	private void \u0614\u06EAڹ\u07BA()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600147B RID: 5243 RVA: 0x000735FC File Offset: 0x000717FC
	[Token(Token = "0x600147B")]
	[Address(RVA = "0x2EAF7C8", Offset = "0x2EAF7C8", VA = "0x2EAF7C8")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		this.߃ցز\u0557();
	}

	// Token: 0x0600147C RID: 5244 RVA: 0x00073610 File Offset: 0x00071810
	[Token(Token = "0x600147C")]
	[Address(RVA = "0x2EAF7CC", Offset = "0x2EAF7CC", VA = "0x2EAF7CC")]
	private void \u073BօӁ\u059A()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x0600147D RID: 5245 RVA: 0x00073644 File Offset: 0x00071844
	[Token(Token = "0x600147D")]
	[Address(RVA = "0x2EAF868", Offset = "0x2EAF868", VA = "0x2EAF868")]
	private void \u088C\u081A߃ࢳ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600147E RID: 5246 RVA: 0x000737C4 File Offset: 0x000719C4
	[Token(Token = "0x600147E")]
	[Address(RVA = "0x2EAFDC4", Offset = "0x2EAFDC4", VA = "0x2EAFDC4")]
	private void ԁӐշࢭ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform2 = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600147F RID: 5247 RVA: 0x00073940 File Offset: 0x00071B40
	[Token(Token = "0x600147F")]
	[Address(RVA = "0x2EB0318", Offset = "0x2EB0318", VA = "0x2EB0318")]
	private void \u082E\u06EBݼڏ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
	}

	// Token: 0x06001480 RID: 5248 RVA: 0x0007396C File Offset: 0x00071B6C
	[Token(Token = "0x6001480")]
	[Address(RVA = "0x2EB03B4", Offset = "0x2EB03B4", VA = "0x2EB03B4")]
	private void ࢶ٠\u086D\u0708()
	{
		this.\u0614\u06EAڹ\u07BA();
	}

	// Token: 0x06001481 RID: 5249 RVA: 0x00073980 File Offset: 0x00071B80
	[Token(Token = "0x6001481")]
	[Address(RVA = "0x2EB03B8", Offset = "0x2EB03B8", VA = "0x2EB03B8")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		this.ؠ\u0650\u073F\u0608();
	}

	// Token: 0x06001482 RID: 5250 RVA: 0x00073994 File Offset: 0x00071B94
	[Token(Token = "0x6001482")]
	[Address(RVA = "0x2EB0918", Offset = "0x2EB0918", VA = "0x2EB0918")]
	private void ۮߝڪڐ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x06001483 RID: 5251 RVA: 0x000739C8 File Offset: 0x00071BC8
	[Token(Token = "0x6001483")]
	[Address(RVA = "0x2EB09B4", Offset = "0x2EB09B4", VA = "0x2EB09B4")]
	private void \u05ABࡡ\u07ABݾ()
	{
		this.\u05C8߆կ\u083D();
	}

	// Token: 0x06001484 RID: 5252 RVA: 0x000739DC File Offset: 0x00071BDC
	[Token(Token = "0x6001484")]
	[Address(RVA = "0x2EB09B8", Offset = "0x2EB09B8", VA = "0x2EB09B8")]
	private void طӏܙࢺ()
	{
		this.ӝԎߗ߆();
	}

	// Token: 0x06001485 RID: 5253 RVA: 0x000739F0 File Offset: 0x00071BF0
	[Token(Token = "0x6001485")]
	[Address(RVA = "0x2EB0F18", Offset = "0x2EB0F18", VA = "0x2EB0F18")]
	public Pet()
	{
	}

	// Token: 0x06001486 RID: 5254 RVA: 0x00073A10 File Offset: 0x00071C10
	[Token(Token = "0x6001486")]
	[Address(RVA = "0x2EAB3D4", Offset = "0x2EAB3D4", VA = "0x2EAB3D4")]
	private void Ӕ\u07ABԝ\u07F5()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001487 RID: 5255 RVA: 0x00073B98 File Offset: 0x00071D98
	[Token(Token = "0x6001487")]
	[Address(RVA = "0x2EB0F34", Offset = "0x2EB0F34", VA = "0x2EB0F34")]
	private void \u065F\u0839ܤ\u073C()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x06001488 RID: 5256 RVA: 0x00073BCC File Offset: 0x00071DCC
	[Token(Token = "0x6001488")]
	[Address(RVA = "0x2EB0FD0", Offset = "0x2EB0FD0", VA = "0x2EB0FD0")]
	private void ޡࠅ\u089Aߔ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x06001489 RID: 5257 RVA: 0x00073C00 File Offset: 0x00071E00
	[Token(Token = "0x6001489")]
	[Address(RVA = "0x2EB106C", Offset = "0x2EB106C", VA = "0x2EB106C")]
	private void \u0872މࢮՃ()
	{
		this.\u058DӂԆߕ();
	}

	// Token: 0x0600148A RID: 5258 RVA: 0x00073C14 File Offset: 0x00071E14
	[Token(Token = "0x600148A")]
	[Address(RVA = "0x2EB1070", Offset = "0x2EB1070", VA = "0x2EB1070")]
	private void \u066A\u059Eټ\u085A()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x0600148B RID: 5259 RVA: 0x00073C48 File Offset: 0x00071E48
	[Token(Token = "0x600148B")]
	[Address(RVA = "0x2EAC940", Offset = "0x2EAC940", VA = "0x2EAC940")]
	private void \u05A4ع\u073F\u061C()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600148C RID: 5260 RVA: 0x00073DD0 File Offset: 0x00071FD0
	[Token(Token = "0x600148C")]
	[Address(RVA = "0x2EB110C", Offset = "0x2EB110C", VA = "0x2EB110C")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		this.ֆࡤ\u070Fד();
	}

	// Token: 0x0600148D RID: 5261 RVA: 0x00073DE4 File Offset: 0x00071FE4
	[Token(Token = "0x600148D")]
	[Address(RVA = "0x2EB03BC", Offset = "0x2EB03BC", VA = "0x2EB03BC")]
	private void ؠ\u0650\u073F\u0608()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600148E RID: 5262 RVA: 0x00073F6C File Offset: 0x0007216C
	[Token(Token = "0x600148E")]
	[Address(RVA = "0x2EB1110", Offset = "0x2EB1110", VA = "0x2EB1110")]
	private void ܩחݵޔ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x0600148F RID: 5263 RVA: 0x00073FA0 File Offset: 0x000721A0
	[Token(Token = "0x600148F")]
	[Address(RVA = "0x2EB11AC", Offset = "0x2EB11AC", VA = "0x2EB11AC")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		this.Ӕ\u07ABԝ\u07F5();
	}

	// Token: 0x06001490 RID: 5264 RVA: 0x00073FB4 File Offset: 0x000721B4
	[Token(Token = "0x6001490")]
	[Address(RVA = "0x2EB11B0", Offset = "0x2EB11B0", VA = "0x2EB11B0")]
	private void \u0656ӺմՁ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x06001491 RID: 5265 RVA: 0x00073FE8 File Offset: 0x000721E8
	[Token(Token = "0x6001491")]
	[Address(RVA = "0x2EB124C", Offset = "0x2EB124C", VA = "0x2EB124C")]
	private void Ԁוև\u065B()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x06001492 RID: 5266 RVA: 0x0007401C File Offset: 0x0007221C
	[Token(Token = "0x6001492")]
	[Address(RVA = "0x2EB12E8", Offset = "0x2EB12E8", VA = "0x2EB12E8")]
	private void \u05B3ࢹߧ\u07AA()
	{
		this.\u05A4ع\u073F\u061C();
	}

	// Token: 0x06001493 RID: 5267 RVA: 0x00074030 File Offset: 0x00072230
	[Token(Token = "0x6001493")]
	[Address(RVA = "0x2EB12EC", Offset = "0x2EB12EC", VA = "0x2EB12EC")]
	private void ӻӒݝ߃()
	{
		this.\u05B1ݳۂ\u05B7();
	}

	// Token: 0x06001494 RID: 5268 RVA: 0x00074044 File Offset: 0x00072244
	[Token(Token = "0x6001494")]
	[Address(RVA = "0x2EB184C", Offset = "0x2EB184C", VA = "0x2EB184C")]
	private void \u0870\u05B3Ց\u066A()
	{
		this.\u055Bӄߚۑ();
	}

	// Token: 0x06001495 RID: 5269 RVA: 0x00074058 File Offset: 0x00072258
	[Token(Token = "0x6001495")]
	[Address(RVA = "0x2EB1850", Offset = "0x2EB1850", VA = "0x2EB1850")]
	private void \u0597ࢮڃڶ()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001496 RID: 5270 RVA: 0x000741DC File Offset: 0x000723DC
	[Token(Token = "0x6001496")]
	[Address(RVA = "0x2EB09BC", Offset = "0x2EB09BC", VA = "0x2EB09BC")]
	private void ӝԎߗ߆()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x06001497 RID: 5271 RVA: 0x00074364 File Offset: 0x00072564
	[Token(Token = "0x6001497")]
	[Address(RVA = "0x2EB1DAC", Offset = "0x2EB1DAC", VA = "0x2EB1DAC")]
	private void حتݻ\u05B0()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x06001498 RID: 5272 RVA: 0x00074398 File Offset: 0x00072598
	[Token(Token = "0x6001498")]
	[Address(RVA = "0x2EB1E48", Offset = "0x2EB1E48", VA = "0x2EB1E48")]
	private void ܫ\u070Fۃ\u07F2()
	{
		this.ԁӐշࢭ();
	}

	// Token: 0x06001499 RID: 5273 RVA: 0x000743AC File Offset: 0x000725AC
	[Token(Token = "0x6001499")]
	[Address(RVA = "0x2EB1E4C", Offset = "0x2EB1E4C", VA = "0x2EB1E4C")]
	private void Ӌ\u089C\u0700ܧ()
	{
		this.כԍ\u058B\u0882();
	}

	// Token: 0x0600149A RID: 5274 RVA: 0x000743C0 File Offset: 0x000725C0
	[Token(Token = "0x600149A")]
	[Address(RVA = "0x2EB1E50", Offset = "0x2EB1E50", VA = "0x2EB1E50")]
	private void ߠ\u07AAߚթ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x0600149B RID: 5275 RVA: 0x000743F4 File Offset: 0x000725F4
	[Token(Token = "0x600149B")]
	[Address(RVA = "0x2EAB934", Offset = "0x2EAB934", VA = "0x2EAB934")]
	private void پ٨ݓ\u055C()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Transform transform2 = base.transform;
		Quaternion rotation = base.transform.rotation;
		float deltaTime = Time.deltaTime;
		float ӳۍՂڧ = this.ӲۍՂڧ;
		Vector3 position7 = base.transform.position;
		Vector3 forward = base.transform.forward;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
		float deltaTime2 = Time.deltaTime;
		Vector3 position8 = base.transform.position;
		Vector3 position9 = this.ߤ\u086Dܔߪ.position;
		float u065Fԓ_u0593_u = this.\u065Fԓ\u0593\u0704;
		Transform transform3 = base.transform;
		Vector3 position10 = base.transform.position;
		float deltaTime3 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num = Mathf.Clamp01(deltaTime3);
		Vector3 position11 = base.transform.position;
		Vector3 position12 = this.ߤ\u086Dܔߪ.position;
		Vector3 position13 = base.transform.position;
		Vector3 normalized = base.transform.position.normalized;
		Color green = Color.green;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600149C RID: 5276 RVA: 0x00074578 File Offset: 0x00072778
	[Token(Token = "0x600149C")]
	[Address(RVA = "0x2EB1EEC", Offset = "0x2EB1EEC", VA = "0x2EB1EEC")]
	private void Ԯ\u0883\u0591\u066C()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
		this.ե\u0598ࡄࢶ = component;
	}

	// Token: 0x0600149D RID: 5277 RVA: 0x000745AC File Offset: 0x000727AC
	[Token(Token = "0x600149D")]
	[Address(RVA = "0x2EB1F88", Offset = "0x2EB1F88", VA = "0x2EB1F88")]
	private void \u070Fߨ\u05B0ۈ()
	{
		Vector3 position = Player.كݕ\u05F3\u0589.ՍԻӫԭ.position;
		Animator component = base.GetComponent<Animator>();
	}

	// Token: 0x0600149E RID: 5278 RVA: 0x000745D8 File Offset: 0x000727D8
	[Token(Token = "0x600149E")]
	[Address(RVA = "0x2EB12F0", Offset = "0x2EB12F0", VA = "0x2EB12F0")]
	private void \u05B1ݳۂ\u05B7()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Vector3 position4 = base.transform.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600149F RID: 5279 RVA: 0x00074758 File Offset: 0x00072958
	[Token(Token = "0x600149F")]
	[Address(RVA = "0x2EACF40", Offset = "0x2EACF40", VA = "0x2EACF40")]
	private void \u05C8߆կ\u083D()
	{
		Vector3 position = this.ߤ\u086Dܔߪ.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.ܣڴՠآ.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.ܣڴՠآ.position;
		Color blue = Color.blue;
		if (typeof(Debug).TypeHandle == null)
		{
		}
	}

	// Token: 0x0400028B RID: 651
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400028B")]
	public Transform ߤ\u086Dܔߪ;

	// Token: 0x0400028C RID: 652
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400028C")]
	public RaycastHit ԏصٳ\u0740;

	// Token: 0x0400028D RID: 653
	[FieldOffset(Offset = "0x4C")]
	[Token(Token = "0x400028D")]
	public Pet.\u08B5\u0817ڿࠁ ࡖر\u0879ҿ;

	// Token: 0x0400028E RID: 654
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400028E")]
	private Animator ե\u0598ࡄࢶ;

	// Token: 0x0400028F RID: 655
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400028F")]
	private Vector3 ߜ\u0597ޢݝ;

	// Token: 0x04000290 RID: 656
	[FieldOffset(Offset = "0x64")]
	[Token(Token = "0x4000290")]
	public float \u05B9ߎܩ\u0613;

	// Token: 0x04000291 RID: 657
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000291")]
	public float Գࢻ\u0871\u07B3;

	// Token: 0x04000292 RID: 658
	[FieldOffset(Offset = "0x6C")]
	[Token(Token = "0x4000292")]
	public float ӲۍՂڧ = (float)16544;

	// Token: 0x04000293 RID: 659
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000293")]
	public Transform ܣڴՠآ;

	// Token: 0x04000294 RID: 660
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000294")]
	public float \u065Fԓ\u0593\u0704;

	// Token: 0x04000295 RID: 661
	[FieldOffset(Offset = "0x7C")]
	[Token(Token = "0x4000295")]
	public float ࡡپ\u0887ս;

	// Token: 0x0200008B RID: 139
	[Token(Token = "0x200008B")]
	public enum \u08B5\u0817ڿࠁ
	{
		// Token: 0x04000297 RID: 663
		[Token(Token = "0x4000297")]
		נӐԍӘ,
		// Token: 0x04000298 RID: 664
		[Token(Token = "0x4000298")]
		\u0825ԉԇ۵,
		// Token: 0x04000299 RID: 665
		[Token(Token = "0x4000299")]
		Ӿڸݏ\u086C
	}
}
