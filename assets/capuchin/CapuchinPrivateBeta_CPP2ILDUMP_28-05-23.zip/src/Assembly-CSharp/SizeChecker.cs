﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000DB RID: 219
[Token(Token = "0x20000DB")]
public class SizeChecker : MonoBehaviour
{
	// Token: 0x060021A8 RID: 8616 RVA: 0x000B4898 File Offset: 0x000B2A98
	[Token(Token = "0x60021A8")]
	[Address(RVA = "0x2F741C4", Offset = "0x2F741C4", VA = "0x2F741C4")]
	public void ۆڛߟ\u05A0()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021A9 RID: 8617 RVA: 0x000B48B0 File Offset: 0x000B2AB0
	[Token(Token = "0x60021A9")]
	[Address(RVA = "0x2F741EC", Offset = "0x2F741EC", VA = "0x2F741EC")]
	public void \u07EBࠎיࡂ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021AA RID: 8618 RVA: 0x000B48C8 File Offset: 0x000B2AC8
	[Token(Token = "0x60021AA")]
	[Address(RVA = "0x2F74214", Offset = "0x2F74214", VA = "0x2F74214")]
	private void ࢴ\u087A\u07B9ࢢ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021AB RID: 8619 RVA: 0x000B4900 File Offset: 0x000B2B00
	[Token(Token = "0x60021AB")]
	[Address(RVA = "0x2F74298", Offset = "0x2F74298", VA = "0x2F74298")]
	private void \u05F7ԝߠӱ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021AC RID: 8620 RVA: 0x000B4938 File Offset: 0x000B2B38
	[Token(Token = "0x60021AC")]
	[Address(RVA = "0x2F7431C", Offset = "0x2F7431C", VA = "0x2F7431C")]
	private void Վࡧ\u06FDܕ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021AD RID: 8621 RVA: 0x000B4970 File Offset: 0x000B2B70
	[Token(Token = "0x60021AD")]
	[Address(RVA = "0x2F743A0", Offset = "0x2F743A0", VA = "0x2F743A0")]
	private void \u082Eכ\u0640ܮ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021AE RID: 8622 RVA: 0x000B49A0 File Offset: 0x000B2BA0
	[Token(Token = "0x60021AE")]
	[Address(RVA = "0x2F743FC", Offset = "0x2F743FC", VA = "0x2F743FC")]
	private void ࡖקӒݾ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021AF RID: 8623 RVA: 0x000B49D0 File Offset: 0x000B2BD0
	[Token(Token = "0x60021AF")]
	[Address(RVA = "0x2F74458", Offset = "0x2F74458", VA = "0x2F74458")]
	public void ԦӔԁֆ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021B0 RID: 8624 RVA: 0x000B49E8 File Offset: 0x000B2BE8
	[Token(Token = "0x60021B0")]
	[Address(RVA = "0x2F74480", Offset = "0x2F74480", VA = "0x2F74480")]
	public void ܬԛ٣\u07FF()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021B1 RID: 8625 RVA: 0x000B4A00 File Offset: 0x000B2C00
	[Token(Token = "0x60021B1")]
	[Address(RVA = "0x2F744A8", Offset = "0x2F744A8", VA = "0x2F744A8")]
	private void Update()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021B2 RID: 8626 RVA: 0x000B4A38 File Offset: 0x000B2C38
	[Token(Token = "0x60021B2")]
	[Address(RVA = "0x2F74524", Offset = "0x2F74524", VA = "0x2F74524")]
	private void ہݕ\u07EFԒ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021B3 RID: 8627 RVA: 0x000B4A70 File Offset: 0x000B2C70
	[Token(Token = "0x60021B3")]
	[Address(RVA = "0x2F745A8", Offset = "0x2F745A8", VA = "0x2F745A8")]
	public void Ջއٵյ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021B4 RID: 8628 RVA: 0x000B4A88 File Offset: 0x000B2C88
	[Token(Token = "0x60021B4")]
	[Address(RVA = "0x2F745D0", Offset = "0x2F745D0", VA = "0x2F745D0")]
	private void ߑ\u0885\u05BBߕ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021B5 RID: 8629 RVA: 0x000B4AC0 File Offset: 0x000B2CC0
	[Token(Token = "0x60021B5")]
	[Address(RVA = "0x2F74654", Offset = "0x2F74654", VA = "0x2F74654")]
	private void \u0614ࢥӴ\u086C()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021B6 RID: 8630 RVA: 0x000B4AF8 File Offset: 0x000B2CF8
	[Token(Token = "0x60021B6")]
	[Address(RVA = "0x2F746D8", Offset = "0x2F746D8", VA = "0x2F746D8")]
	private void \u0603\u0593\u05B3\u0886()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021B7 RID: 8631 RVA: 0x000B4B28 File Offset: 0x000B2D28
	[Token(Token = "0x60021B7")]
	[Address(RVA = "0x2F74734", Offset = "0x2F74734", VA = "0x2F74734")]
	private void ڽ\u0894ىޡ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021B8 RID: 8632 RVA: 0x000B4B58 File Offset: 0x000B2D58
	[Token(Token = "0x60021B8")]
	[Address(RVA = "0x2F74790", Offset = "0x2F74790", VA = "0x2F74790")]
	private void \u07ABג\u07F4ւ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021B9 RID: 8633 RVA: 0x000B4B88 File Offset: 0x000B2D88
	[Token(Token = "0x60021B9")]
	[Address(RVA = "0x2F747EC", Offset = "0x2F747EC", VA = "0x2F747EC")]
	private void ࡥշӞھ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021BA RID: 8634 RVA: 0x000B4BC0 File Offset: 0x000B2DC0
	[Token(Token = "0x60021BA")]
	[Address(RVA = "0x2F74870", Offset = "0x2F74870", VA = "0x2F74870")]
	public void \u05ABݿࡋ\u06E9()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021BB RID: 8635 RVA: 0x000B4BD8 File Offset: 0x000B2DD8
	[Token(Token = "0x60021BB")]
	[Address(RVA = "0x2F74898", Offset = "0x2F74898", VA = "0x2F74898")]
	private void չւت\u061E()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021BC RID: 8636 RVA: 0x000B4C10 File Offset: 0x000B2E10
	[Token(Token = "0x60021BC")]
	[Address(RVA = "0x2F7491C", Offset = "0x2F7491C", VA = "0x2F7491C")]
	private void \u0882\u055C\u0888ߥ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021BD RID: 8637 RVA: 0x000B4C48 File Offset: 0x000B2E48
	[Token(Token = "0x60021BD")]
	[Address(RVA = "0x2F749A0", Offset = "0x2F749A0", VA = "0x2F749A0")]
	public void Start()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021BE RID: 8638 RVA: 0x000B4C60 File Offset: 0x000B2E60
	[Token(Token = "0x60021BE")]
	[Address(RVA = "0x2F749C8", Offset = "0x2F749C8", VA = "0x2F749C8")]
	private void פۈيݤ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021BF RID: 8639 RVA: 0x000B4C98 File Offset: 0x000B2E98
	[Token(Token = "0x60021BF")]
	[Address(RVA = "0x2F74A4C", Offset = "0x2F74A4C", VA = "0x2F74A4C")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021C0 RID: 8640 RVA: 0x000B4CD0 File Offset: 0x000B2ED0
	[Token(Token = "0x60021C0")]
	[Address(RVA = "0x2F74AD0", Offset = "0x2F74AD0", VA = "0x2F74AD0")]
	public void ԞԌ\u086FՇ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021C1 RID: 8641 RVA: 0x000B4CE8 File Offset: 0x000B2EE8
	[Token(Token = "0x60021C1")]
	[Address(RVA = "0x2F74AF8", Offset = "0x2F74AF8", VA = "0x2F74AF8")]
	private void Ӎ\u070BԤߓ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021C2 RID: 8642 RVA: 0x000B4D18 File Offset: 0x000B2F18
	[Token(Token = "0x60021C2")]
	[Address(RVA = "0x2F74B54", Offset = "0x2F74B54", VA = "0x2F74B54")]
	public void \u086Bԍࡊڭ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021C3 RID: 8643 RVA: 0x000B4D30 File Offset: 0x000B2F30
	[Token(Token = "0x60021C3")]
	[Address(RVA = "0x2F74B7C", Offset = "0x2F74B7C", VA = "0x2F74B7C")]
	private void دז\u06EDճ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021C4 RID: 8644 RVA: 0x000B4D60 File Offset: 0x000B2F60
	[Token(Token = "0x60021C4")]
	[Address(RVA = "0x2F74BD8", Offset = "0x2F74BD8", VA = "0x2F74BD8")]
	private void \u066B\u06DCݬࡖ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021C5 RID: 8645 RVA: 0x000B4D90 File Offset: 0x000B2F90
	[Token(Token = "0x60021C5")]
	[Address(RVA = "0x2F74C34", Offset = "0x2F74C34", VA = "0x2F74C34")]
	public void \u073Bݲձݕ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021C6 RID: 8646 RVA: 0x000B4DA8 File Offset: 0x000B2FA8
	[Token(Token = "0x60021C6")]
	[Address(RVA = "0x2F74C5C", Offset = "0x2F74C5C", VA = "0x2F74C5C")]
	private void \u06DEԍӂս()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021C7 RID: 8647 RVA: 0x000B4DD8 File Offset: 0x000B2FD8
	[Token(Token = "0x60021C7")]
	[Address(RVA = "0x2F74CB8", Offset = "0x2F74CB8", VA = "0x2F74CB8")]
	private void ބܝۄ\u0703()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021C8 RID: 8648 RVA: 0x000B4E08 File Offset: 0x000B3008
	[Token(Token = "0x60021C8")]
	[Address(RVA = "0x2F74D14", Offset = "0x2F74D14", VA = "0x2F74D14")]
	public void \u06D6ې\u083Bࠉ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021C9 RID: 8649 RVA: 0x000B4E20 File Offset: 0x000B3020
	[Token(Token = "0x60021C9")]
	[Address(RVA = "0x2F74D3C", Offset = "0x2F74D3C", VA = "0x2F74D3C")]
	private void ڃݚ\u07ACՒ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021CA RID: 8650 RVA: 0x000B4E50 File Offset: 0x000B3050
	[Token(Token = "0x60021CA")]
	[Address(RVA = "0x2F74D98", Offset = "0x2F74D98", VA = "0x2F74D98")]
	private void \u0607\u0747\u058Aף()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021CB RID: 8651 RVA: 0x000B4E80 File Offset: 0x000B3080
	[Token(Token = "0x60021CB")]
	[Address(RVA = "0x2F74DF4", Offset = "0x2F74DF4", VA = "0x2F74DF4")]
	public void ߠ\u07AAߚթ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021CC RID: 8652 RVA: 0x000B4E98 File Offset: 0x000B3098
	[Token(Token = "0x60021CC")]
	[Address(RVA = "0x2F74E1C", Offset = "0x2F74E1C", VA = "0x2F74E1C")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021CD RID: 8653 RVA: 0x000B4ED0 File Offset: 0x000B30D0
	[Token(Token = "0x60021CD")]
	[Address(RVA = "0x2F74E9C", Offset = "0x2F74E9C", VA = "0x2F74E9C")]
	public void աؾێړ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021CE RID: 8654 RVA: 0x000B4EE8 File Offset: 0x000B30E8
	[Token(Token = "0x60021CE")]
	[Address(RVA = "0x2F74EC4", Offset = "0x2F74EC4", VA = "0x2F74EC4")]
	public void ࡎ\u05C2սࠇ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021CF RID: 8655 RVA: 0x000B4F00 File Offset: 0x000B3100
	[Token(Token = "0x60021CF")]
	[Address(RVA = "0x2F74EEC", Offset = "0x2F74EEC", VA = "0x2F74EEC")]
	private void ӣՃ\u07FAԟ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021D0 RID: 8656 RVA: 0x000B4F30 File Offset: 0x000B3130
	[Token(Token = "0x60021D0")]
	[Address(RVA = "0x2F74F48", Offset = "0x2F74F48", VA = "0x2F74F48")]
	private void Ӧد\u060Eࡏ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021D1 RID: 8657 RVA: 0x000B4F68 File Offset: 0x000B3168
	[Token(Token = "0x60021D1")]
	[Address(RVA = "0x2F74FCC", Offset = "0x2F74FCC", VA = "0x2F74FCC")]
	private void \u05A0\u05B4\u05F5ߣ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021D2 RID: 8658 RVA: 0x000B4F98 File Offset: 0x000B3198
	[Token(Token = "0x60021D2")]
	[Address(RVA = "0x2F75028", Offset = "0x2F75028", VA = "0x2F75028")]
	private void \u061B\u05EEوۈ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021D3 RID: 8659 RVA: 0x000B4FD0 File Offset: 0x000B31D0
	[Token(Token = "0x60021D3")]
	[Address(RVA = "0x2F750AC", Offset = "0x2F750AC", VA = "0x2F750AC")]
	public SizeChecker()
	{
		long u0619_u0749ݗ_u = 1065353216L;
		this.\u0619\u0749ݗ\u0650 = (float)u0619_u0749ݗ_u;
		base..ctor();
	}

	// Token: 0x060021D4 RID: 8660 RVA: 0x000B4FF0 File Offset: 0x000B31F0
	[Token(Token = "0x60021D4")]
	[Address(RVA = "0x2F750BC", Offset = "0x2F750BC", VA = "0x2F750BC")]
	public void ޝԖ\u0836\u06D8()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021D5 RID: 8661 RVA: 0x000B5008 File Offset: 0x000B3208
	[Token(Token = "0x60021D5")]
	[Address(RVA = "0x2F750E4", Offset = "0x2F750E4", VA = "0x2F750E4")]
	public void \u081FڰՂإ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021D6 RID: 8662 RVA: 0x000B5020 File Offset: 0x000B3220
	[Token(Token = "0x60021D6")]
	[Address(RVA = "0x2F7510C", Offset = "0x2F7510C", VA = "0x2F7510C")]
	private void րࢢ\u0830Ӥ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021D7 RID: 8663 RVA: 0x000B5050 File Offset: 0x000B3250
	[Token(Token = "0x60021D7")]
	[Address(RVA = "0x2F75168", Offset = "0x2F75168", VA = "0x2F75168")]
	private void ԟ\u086Cޣ\u055E()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021D8 RID: 8664 RVA: 0x000B5088 File Offset: 0x000B3288
	[Token(Token = "0x60021D8")]
	[Address(RVA = "0x2F751EC", Offset = "0x2F751EC", VA = "0x2F751EC")]
	public void \u05F6\u05A6ӓ\u06DC()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021D9 RID: 8665 RVA: 0x000B50A0 File Offset: 0x000B32A0
	[Token(Token = "0x60021D9")]
	[Address(RVA = "0x2F75214", Offset = "0x2F75214", VA = "0x2F75214")]
	public void Գӿېչ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021DA RID: 8666 RVA: 0x000B50B8 File Offset: 0x000B32B8
	[Token(Token = "0x60021DA")]
	[Address(RVA = "0x2F7523C", Offset = "0x2F7523C", VA = "0x2F7523C")]
	private void \u064Dۿ\u07BB\u05C0()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021DB RID: 8667 RVA: 0x000B50E8 File Offset: 0x000B32E8
	[Token(Token = "0x60021DB")]
	[Address(RVA = "0x2F75298", Offset = "0x2F75298", VA = "0x2F75298")]
	public void ࢥ\u081CՕࡋ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021DC RID: 8668 RVA: 0x000B5100 File Offset: 0x000B3300
	[Token(Token = "0x60021DC")]
	[Address(RVA = "0x2F752C0", Offset = "0x2F752C0", VA = "0x2F752C0")]
	public void \u07A8Ӥթݠ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021DD RID: 8669 RVA: 0x000B5118 File Offset: 0x000B3318
	[Token(Token = "0x60021DD")]
	[Address(RVA = "0x2F752E8", Offset = "0x2F752E8", VA = "0x2F752E8")]
	private void ժ\u065Dԯࡘ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021DE RID: 8670 RVA: 0x000B5150 File Offset: 0x000B3350
	[Token(Token = "0x60021DE")]
	[Address(RVA = "0x2F7536C", Offset = "0x2F7536C", VA = "0x2F7536C")]
	private void ւࡂ\u0883\u0872()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021DF RID: 8671 RVA: 0x000B5188 File Offset: 0x000B3388
	[Token(Token = "0x60021DF")]
	[Address(RVA = "0x2F753F0", Offset = "0x2F753F0", VA = "0x2F753F0")]
	private void ٴݵۃ\u05AF()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021E0 RID: 8672 RVA: 0x000B51C0 File Offset: 0x000B33C0
	[Token(Token = "0x60021E0")]
	[Address(RVA = "0x2F75474", Offset = "0x2F75474", VA = "0x2F75474")]
	private void \u0827ߜ\u07FD\u07F4()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021E1 RID: 8673 RVA: 0x000B51F8 File Offset: 0x000B33F8
	[Token(Token = "0x60021E1")]
	[Address(RVA = "0x2F754F8", Offset = "0x2F754F8", VA = "0x2F754F8")]
	private void \u066D߅ռ\u07F1()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021E2 RID: 8674 RVA: 0x000B5228 File Offset: 0x000B3428
	[Token(Token = "0x60021E2")]
	[Address(RVA = "0x2F75554", Offset = "0x2F75554", VA = "0x2F75554")]
	private void \u055C\u0670\u06EA\u05EC()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021E3 RID: 8675 RVA: 0x000B5258 File Offset: 0x000B3458
	[Token(Token = "0x60021E3")]
	[Address(RVA = "0x2F755B0", Offset = "0x2F755B0", VA = "0x2F755B0")]
	private void ܬࡧ\u0889\u07FF()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021E4 RID: 8676 RVA: 0x000B5288 File Offset: 0x000B3488
	[Token(Token = "0x60021E4")]
	[Address(RVA = "0x2F7560C", Offset = "0x2F7560C", VA = "0x2F7560C")]
	public void ߓ\u06E3\u05C7ۋ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021E5 RID: 8677 RVA: 0x000B52A0 File Offset: 0x000B34A0
	[Token(Token = "0x60021E5")]
	[Address(RVA = "0x2F75634", Offset = "0x2F75634", VA = "0x2F75634")]
	public void ߗࠊ\u05CAܝ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021E6 RID: 8678 RVA: 0x000B52B8 File Offset: 0x000B34B8
	[Token(Token = "0x60021E6")]
	[Address(RVA = "0x2F7565C", Offset = "0x2F7565C", VA = "0x2F7565C")]
	public void قӮևݛ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021E7 RID: 8679 RVA: 0x000B52D0 File Offset: 0x000B34D0
	[Token(Token = "0x60021E7")]
	[Address(RVA = "0x2F75684", Offset = "0x2F75684", VA = "0x2F75684")]
	private void ࢫ\u0876չՍ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021E8 RID: 8680 RVA: 0x000B5308 File Offset: 0x000B3508
	[Token(Token = "0x60021E8")]
	[Address(RVA = "0x2F75708", Offset = "0x2F75708", VA = "0x2F75708")]
	private void ڷԲ\u0618ރ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021E9 RID: 8681 RVA: 0x000B5340 File Offset: 0x000B3540
	[Token(Token = "0x60021E9")]
	[Address(RVA = "0x2F7578C", Offset = "0x2F7578C", VA = "0x2F7578C")]
	public void ڣֆ\u07F4ڌ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021EA RID: 8682 RVA: 0x000B5358 File Offset: 0x000B3558
	[Token(Token = "0x60021EA")]
	[Address(RVA = "0x2F757B4", Offset = "0x2F757B4", VA = "0x2F757B4")]
	private void ݠ\u07EBӁ\u0652()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021EB RID: 8683 RVA: 0x000B5388 File Offset: 0x000B3588
	[Token(Token = "0x60021EB")]
	[Address(RVA = "0x2F75810", Offset = "0x2F75810", VA = "0x2F75810")]
	private void \u081Cәࡃ۵()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021EC RID: 8684 RVA: 0x000B53C0 File Offset: 0x000B35C0
	[Token(Token = "0x60021EC")]
	[Address(RVA = "0x2F75894", Offset = "0x2F75894", VA = "0x2F75894")]
	private void ފՖߢ\u059B()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021ED RID: 8685 RVA: 0x000B53F8 File Offset: 0x000B35F8
	[Token(Token = "0x60021ED")]
	[Address(RVA = "0x2F75918", Offset = "0x2F75918", VA = "0x2F75918")]
	private void LateUpdate()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021EE RID: 8686 RVA: 0x000B5428 File Offset: 0x000B3628
	[Token(Token = "0x60021EE")]
	[Address(RVA = "0x2F75974", Offset = "0x2F75974", VA = "0x2F75974")]
	private void ڔӈӋڤ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021EF RID: 8687 RVA: 0x000B5458 File Offset: 0x000B3658
	[Token(Token = "0x60021EF")]
	[Address(RVA = "0x2F759D0", Offset = "0x2F759D0", VA = "0x2F759D0")]
	private void \u05B3ࢹߧ\u07AA()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021F0 RID: 8688 RVA: 0x000B5490 File Offset: 0x000B3690
	[Token(Token = "0x60021F0")]
	[Address(RVA = "0x2F75A54", Offset = "0x2F75A54", VA = "0x2F75A54")]
	public void ࠏޤݳ\u06DD()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021F1 RID: 8689 RVA: 0x000B54A8 File Offset: 0x000B36A8
	[Token(Token = "0x60021F1")]
	[Address(RVA = "0x2F75A7C", Offset = "0x2F75A7C", VA = "0x2F75A7C")]
	private void Ӄ\u07BAࡌՅ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021F2 RID: 8690 RVA: 0x000B54D8 File Offset: 0x000B36D8
	[Token(Token = "0x60021F2")]
	[Address(RVA = "0x2F75AD8", Offset = "0x2F75AD8", VA = "0x2F75AD8")]
	private void ࠎճ\u05F9م()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021F3 RID: 8691 RVA: 0x000B5508 File Offset: 0x000B3708
	[Token(Token = "0x60021F3")]
	[Address(RVA = "0x2F75B34", Offset = "0x2F75B34", VA = "0x2F75B34")]
	private void Րۼئ\u0897()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021F4 RID: 8692 RVA: 0x000B5538 File Offset: 0x000B3738
	[Token(Token = "0x60021F4")]
	[Address(RVA = "0x2F75B90", Offset = "0x2F75B90", VA = "0x2F75B90")]
	private void ڈԼߥݼ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021F5 RID: 8693 RVA: 0x000B5568 File Offset: 0x000B3768
	[Token(Token = "0x60021F5")]
	[Address(RVA = "0x2F75BEC", Offset = "0x2F75BEC", VA = "0x2F75BEC")]
	private void ٠ӄ\u087Cٸ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021F6 RID: 8694 RVA: 0x000B55A0 File Offset: 0x000B37A0
	[Token(Token = "0x60021F6")]
	[Address(RVA = "0x2F75C70", Offset = "0x2F75C70", VA = "0x2F75C70")]
	private void ࡑ\u07B0ع\u05F4()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021F7 RID: 8695 RVA: 0x000B55D0 File Offset: 0x000B37D0
	[Token(Token = "0x60021F7")]
	[Address(RVA = "0x2F75CCC", Offset = "0x2F75CCC", VA = "0x2F75CCC")]
	public void ӷӛࠔ\u07AC()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021F8 RID: 8696 RVA: 0x000B55E8 File Offset: 0x000B37E8
	[Token(Token = "0x60021F8")]
	[Address(RVA = "0x2F75CF4", Offset = "0x2F75CF4", VA = "0x2F75CF4")]
	public void \u073BօӁ\u059A()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021F9 RID: 8697 RVA: 0x000B5600 File Offset: 0x000B3800
	[Token(Token = "0x60021F9")]
	[Address(RVA = "0x2F75D1C", Offset = "0x2F75D1C", VA = "0x2F75D1C")]
	public void ۮߝڪڐ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060021FA RID: 8698 RVA: 0x000B5618 File Offset: 0x000B3818
	[Token(Token = "0x60021FA")]
	[Address(RVA = "0x2F75D44", Offset = "0x2F75D44", VA = "0x2F75D44")]
	private void יԠ\u07EDԺ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021FB RID: 8699 RVA: 0x000B5650 File Offset: 0x000B3850
	[Token(Token = "0x60021FB")]
	[Address(RVA = "0x2F75DC8", Offset = "0x2F75DC8", VA = "0x2F75DC8")]
	private void ےؠպ\u05FC()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021FC RID: 8700 RVA: 0x000B567C File Offset: 0x000B387C
	[Token(Token = "0x60021FC")]
	[Address(RVA = "0x2F75E24", Offset = "0x2F75E24", VA = "0x2F75E24")]
	private void Ҽ\u08B5ځ\u0658()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021FD RID: 8701 RVA: 0x000B56B4 File Offset: 0x000B38B4
	[Token(Token = "0x60021FD")]
	[Address(RVA = "0x2F75EA8", Offset = "0x2F75EA8", VA = "0x2F75EA8")]
	private void דڳߡࠇ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060021FE RID: 8702 RVA: 0x000B56EC File Offset: 0x000B38EC
	[Token(Token = "0x60021FE")]
	[Address(RVA = "0x2F75F2C", Offset = "0x2F75F2C", VA = "0x2F75F2C")]
	private void ܕ\u0595\u07AEࠋ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x060021FF RID: 8703 RVA: 0x000B571C File Offset: 0x000B391C
	[Token(Token = "0x60021FF")]
	[Address(RVA = "0x2F75F88", Offset = "0x2F75F88", VA = "0x2F75F88")]
	public void \u0558ݕݤݮ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002200 RID: 8704 RVA: 0x000B5734 File Offset: 0x000B3934
	[Token(Token = "0x6002200")]
	[Address(RVA = "0x2F75FB0", Offset = "0x2F75FB0", VA = "0x2F75FB0")]
	private void بࠂռ\u05C6()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x06002201 RID: 8705 RVA: 0x000B5764 File Offset: 0x000B3964
	[Token(Token = "0x6002201")]
	[Address(RVA = "0x2F7600C", Offset = "0x2F7600C", VA = "0x2F7600C")]
	private void ӒԂࡩࡓ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002202 RID: 8706 RVA: 0x000B579C File Offset: 0x000B399C
	[Token(Token = "0x6002202")]
	[Address(RVA = "0x2F76090", Offset = "0x2F76090", VA = "0x2F76090")]
	private void \u05A8\u06DDӚٵ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x06002203 RID: 8707 RVA: 0x000B57CC File Offset: 0x000B39CC
	[Token(Token = "0x6002203")]
	[Address(RVA = "0x2F760EC", Offset = "0x2F760EC", VA = "0x2F760EC")]
	private void ݛ\u0599\u05C2ڒ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002204 RID: 8708 RVA: 0x000B5804 File Offset: 0x000B3A04
	[Token(Token = "0x6002204")]
	[Address(RVA = "0x2F76170", Offset = "0x2F76170", VA = "0x2F76170")]
	public void \u066D\u05BDې߃()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002205 RID: 8709 RVA: 0x000B581C File Offset: 0x000B3A1C
	[Token(Token = "0x6002205")]
	[Address(RVA = "0x2F76198", Offset = "0x2F76198", VA = "0x2F76198")]
	public void ݱ\u0832ݥ\u08B5()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002206 RID: 8710 RVA: 0x000B5834 File Offset: 0x000B3A34
	[Token(Token = "0x6002206")]
	[Address(RVA = "0x2F761C0", Offset = "0x2F761C0", VA = "0x2F761C0")]
	private void \u0892ܒܬޓ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002207 RID: 8711 RVA: 0x000B586C File Offset: 0x000B3A6C
	[Token(Token = "0x6002207")]
	[Address(RVA = "0x2F76244", Offset = "0x2F76244", VA = "0x2F76244")]
	public void הԥ\u05B5ݴ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002208 RID: 8712 RVA: 0x000B5884 File Offset: 0x000B3A84
	[Token(Token = "0x6002208")]
	[Address(RVA = "0x2F7626C", Offset = "0x2F7626C", VA = "0x2F7626C")]
	private void ݘܕܗԣ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x06002209 RID: 8713 RVA: 0x000B58B4 File Offset: 0x000B3AB4
	[Token(Token = "0x6002209")]
	[Address(RVA = "0x2F762C8", Offset = "0x2F762C8", VA = "0x2F762C8")]
	private void ࢶ٠\u086D\u0708()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x0600220A RID: 8714 RVA: 0x000B58EC File Offset: 0x000B3AEC
	[Token(Token = "0x600220A")]
	[Address(RVA = "0x2F7634C", Offset = "0x2F7634C", VA = "0x2F7634C")]
	private void \u0613\u05CBݠۇ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x0600220B RID: 8715 RVA: 0x000B591C File Offset: 0x000B3B1C
	[Token(Token = "0x600220B")]
	[Address(RVA = "0x2F763A8", Offset = "0x2F763A8", VA = "0x2F763A8")]
	private void \u0832ࢳޤ\u07B5()
	{
		Physics.gravity = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale = base.transform.localScale;
	}

	// Token: 0x0600220C RID: 8716 RVA: 0x000B5954 File Offset: 0x000B3B54
	[Token(Token = "0x600220C")]
	[Address(RVA = "0x2F7642C", Offset = "0x2F7642C", VA = "0x2F7642C")]
	public void عۻԂ\u055E()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600220D RID: 8717 RVA: 0x000B596C File Offset: 0x000B3B6C
	[Token(Token = "0x600220D")]
	[Address(RVA = "0x2F76454", Offset = "0x2F76454", VA = "0x2F76454")]
	public void ޠۋ\u0530\u073E()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600220E RID: 8718 RVA: 0x000B5984 File Offset: 0x000B3B84
	[Token(Token = "0x600220E")]
	[Address(RVA = "0x2F7647C", Offset = "0x2F7647C", VA = "0x2F7647C")]
	private void ד\u073C\u0613چ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x0600220F RID: 8719 RVA: 0x000B59BC File Offset: 0x000B3BBC
	[Token(Token = "0x600220F")]
	[Address(RVA = "0x2F76500", Offset = "0x2F76500", VA = "0x2F76500")]
	public void ޡࠅ\u089Aߔ()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002210 RID: 8720 RVA: 0x000B59D4 File Offset: 0x000B3BD4
	[Token(Token = "0x6002210")]
	[Address(RVA = "0x2F76528", Offset = "0x2F76528", VA = "0x2F76528")]
	private void յߪؾՀ()
	{
		Vector3 localScale = base.transform.localScale;
		float u05CF_u06D9բڵ = this.\u05CF\u06D9բڵ;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002211 RID: 8721 RVA: 0x000B5A0C File Offset: 0x000B3C0C
	[Token(Token = "0x6002211")]
	[Address(RVA = "0x2F765AC", Offset = "0x2F765AC", VA = "0x2F765AC")]
	public void \u058EԸس\u0819()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002212 RID: 8722 RVA: 0x000B5A24 File Offset: 0x000B3C24
	[Token(Token = "0x6002212")]
	[Address(RVA = "0x2F765D4", Offset = "0x2F765D4", VA = "0x2F765D4")]
	private void \u05A1ߡࡅࢮ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x06002213 RID: 8723 RVA: 0x000B5A54 File Offset: 0x000B3C54
	[Token(Token = "0x6002213")]
	[Address(RVA = "0x2F76630", Offset = "0x2F76630", VA = "0x2F76630")]
	private void \u0896ࠍࡢۯ()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
		float u0619_u0749ݗ_u = this.\u0619\u0749ݗ\u0650;
	}

	// Token: 0x0400045C RID: 1116
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400045C")]
	public float \u0619\u0749ݗ\u0650;

	// Token: 0x0400045D RID: 1117
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400045D")]
	public Camera \u089Dӗ\u083Cՠ;

	// Token: 0x0400045E RID: 1118
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400045E")]
	private float \u05CF\u06D9բڵ;
}
