﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000059 RID: 89
[Token(Token = "0x2000059")]
public class DampedOscillator : MonoBehaviour
{
	// Token: 0x06000CCD RID: 3277 RVA: 0x000428A0 File Offset: 0x00040AA0
	[Token(Token = "0x6000CCD")]
	[Address(RVA = "0x28971A0", Offset = "0x28971A0", VA = "0x28971A0")]
	private void څࡣڐ\u0657()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		Transform ޛٮܫ_u083D;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			ޛٮܫ_u083D = this.ޛٮܫ\u083D;
			Vector3 position = ޛٮܫ_u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		if (ޛٮܫ_u083D != null)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.ޛٮܫ\u083D.rotation;
			float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
			float x2 = this.ވߩչߨ.x;
			float y2 = this.ވߩչߨ.y;
			float z2 = this.ވߩչߨ.z;
		}
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float x3 = this.ވߩչߨ.x;
			float y3 = this.ވߩչߨ.y;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x06000CCE RID: 3278 RVA: 0x000429E8 File Offset: 0x00040BE8
	[Token(Token = "0x6000CCE")]
	[Address(RVA = "0x2897378", Offset = "0x2897378", VA = "0x2897378")]
	private void \u0732ڙԒࢺ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			Vector3 position = this.ޛٮܫ\u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		if (this.ӿ\u0558ݰݚ)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.ޛٮܫ\u083D.rotation;
			float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
			float x2 = this.ވߩչߨ.x;
			float y2 = this.ވߩչߨ.y;
			float z2 = this.ވߩչߨ.z;
		}
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float x3 = this.ވߩչߨ.x;
			float y3 = this.ވߩչߨ.y;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x06000CCF RID: 3279 RVA: 0x00042B30 File Offset: 0x00040D30
	[Token(Token = "0x6000CCF")]
	[Address(RVA = "0x2897550", Offset = "0x2897550", VA = "0x2897550")]
	private void Ӣ\u0592ߨׯ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			Vector3 position = this.ޛٮܫ\u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		if (this.ӿ\u0558ݰݚ)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.ޛٮܫ\u083D.rotation;
			float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
			float x2 = this.ވߩչߨ.x;
			float y2 = this.ވߩչߨ.y;
			float z2 = this.ވߩչߨ.z;
		}
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float x3 = this.ވߩչߨ.x;
			float y3 = this.ވߩչߨ.y;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x06000CD0 RID: 3280 RVA: 0x00042C78 File Offset: 0x00040E78
	[Token(Token = "0x6000CD0")]
	[Address(RVA = "0x2897728", Offset = "0x2897728", VA = "0x2897728")]
	private void ւࡂ\u0883\u0872()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			Vector3 position = this.ޛٮܫ\u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		if (this.ӿ\u0558ݰݚ)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.ޛٮܫ\u083D.rotation;
			float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
			float x2 = this.ވߩչߨ.x;
			float y2 = this.ވߩչߨ.y;
			float z2 = this.ވߩչߨ.z;
		}
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float x3 = this.ވߩչߨ.x;
			float y3 = this.ވߩչߨ.y;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x06000CD1 RID: 3281 RVA: 0x00042DC0 File Offset: 0x00040FC0
	[Token(Token = "0x6000CD1")]
	[Address(RVA = "0x2897900", Offset = "0x2897900", VA = "0x2897900")]
	private void \u061B\u05EEوۈ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			Vector3 position = this.ޛٮܫ\u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		if (this.ӿ\u0558ݰݚ)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.ޛٮܫ\u083D.rotation;
			float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
			float x2 = this.ވߩչߨ.x;
			float y2 = this.ވߩչߨ.y;
			float z2 = this.ވߩչߨ.z;
		}
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x06000CD2 RID: 3282 RVA: 0x00042EF0 File Offset: 0x000410F0
	[Token(Token = "0x6000CD2")]
	[Address(RVA = "0x2897AD8", Offset = "0x2897AD8", VA = "0x2897AD8")]
	private void \u05F7ԝߠӱ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			Vector3 position = this.ޛٮܫ\u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		if (this.ӿ\u0558ݰݚ)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.ޛٮܫ\u083D.rotation;
			float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
			float x2 = this.ވߩչߨ.x;
			float y2 = this.ވߩչߨ.y;
			float z2 = this.ވߩչߨ.z;
		}
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float x3 = this.ވߩչߨ.x;
			float y3 = this.ވߩչߨ.y;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x06000CD3 RID: 3283 RVA: 0x00043038 File Offset: 0x00041238
	[Token(Token = "0x6000CD3")]
	[Address(RVA = "0x2897CB0", Offset = "0x2897CB0", VA = "0x2897CB0")]
	private void \u05EDց\u081Cت()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			Vector3 position = this.ޛٮܫ\u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		if (this.ӿ\u0558ݰݚ)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.ޛٮܫ\u083D.rotation;
			float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
			float x2 = this.ވߩչߨ.x;
			float y2 = this.ވߩչߨ.y;
			float z2 = this.ވߩչߨ.z;
		}
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float x3 = this.ވߩչߨ.x;
			float y3 = this.ވߩչߨ.y;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x06000CD4 RID: 3284 RVA: 0x00043180 File Offset: 0x00041380
	[Token(Token = "0x6000CD4")]
	[Address(RVA = "0x2897E88", Offset = "0x2897E88", VA = "0x2897E88")]
	private void Update()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		Transform ޛٮܫ_u083D;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			ޛٮܫ_u083D = this.ޛٮܫ\u083D;
			Vector3 position = ޛٮܫ_u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		if (ޛٮܫ_u083D != null)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.ޛٮܫ\u083D.rotation;
			float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
			float x2 = this.ވߩչߨ.x;
			float y2 = this.ވߩչߨ.y;
			float z2 = this.ވߩչߨ.z;
		}
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x06000CD5 RID: 3285 RVA: 0x000432B0 File Offset: 0x000414B0
	[Token(Token = "0x6000CD5")]
	[Address(RVA = "0x2898060", Offset = "0x2898060", VA = "0x2898060")]
	private void ԟ\u086Cޣ\u055E()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			Vector3 position = this.ޛٮܫ\u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		if (this.ӿ\u0558ݰݚ)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.ޛٮܫ\u083D.rotation;
			float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
			float x2 = this.ވߩչߨ.x;
			float y2 = this.ވߩչߨ.y;
			float z2 = this.ވߩչߨ.z;
		}
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float x3 = this.ވߩչߨ.x;
			float y3 = this.ވߩչߨ.y;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x06000CD6 RID: 3286 RVA: 0x000433F8 File Offset: 0x000415F8
	[Token(Token = "0x6000CD6")]
	[Address(RVA = "0x2898238", Offset = "0x2898238", VA = "0x2898238")]
	public DampedOscillator()
	{
	}

	// Token: 0x06000CD7 RID: 3287 RVA: 0x0004340C File Offset: 0x0004160C
	[Token(Token = "0x6000CD7")]
	[Address(RVA = "0x2898240", Offset = "0x2898240", VA = "0x2898240")]
	private void ڑߒجވ()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			Vector3 position = this.ޛٮܫ\u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		if (this.ӿ\u0558ݰݚ)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.ޛٮܫ\u083D.rotation;
			float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
			float x2 = this.ވߩչߨ.x;
			float y2 = this.ވߩչߨ.y;
			float z2 = this.ވߩչߨ.z;
		}
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float x3 = this.ވߩչߨ.x;
			float y3 = this.ވߩչߨ.y;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x06000CD8 RID: 3288 RVA: 0x00043554 File Offset: 0x00041754
	[Token(Token = "0x6000CD8")]
	[Address(RVA = "0x2898418", Offset = "0x2898418", VA = "0x2898418")]
	private void Ҿࢹؼס()
	{
		float ےӃڈ_u07B = this.ےӃڈ\u07B3;
		float ࢥ_u0824Ҽ_u05FB = this.ࢥ\u0824Ҽ\u05FB;
		float ش_u085C_u0823փ = this.ش\u085C\u0823փ;
		float u0602_u05C4ޜԭ = this.\u0602\u05C4ޜԭ;
		float deltaTime = Time.deltaTime;
		float ےӃڈ_u07B2 = this.ےӃڈ\u07B3;
		this.\u0602\u05C4ޜԭ = u0602_u05C4ޜԭ;
		float deltaTime2 = Time.deltaTime;
		bool u082Aߟӵࠂ = this.\u082Aߟӵࠂ;
		this.ےӃڈ\u07B3 = ےӃڈ_u07B;
		if (u082Aߟӵࠂ)
		{
			Transform transform = base.transform;
			Vector3 position = this.ޛٮܫ\u083D.position;
			float ےӃڈ_u07B3 = this.ےӃڈ\u07B3;
			float x = this.ވߩչߨ.x;
			float y = this.ވߩչߨ.y;
			float z = this.ވߩչߨ.z;
		}
		bool ӿ_u0558ݰݚ = this.ӿ\u0558ݰݚ;
		Transform transform2 = base.transform;
		Quaternion rotation = this.ޛٮܫ\u083D.rotation;
		float ےӃڈ_u07B4 = this.ےӃڈ\u07B3;
		float x2 = this.ވߩչߨ.x;
		float y2 = this.ވߩչߨ.y;
		float z2 = this.ވߩչߨ.z;
		if (this.۵\u06E2ࠈډ)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.ޛٮܫ\u083D.localScale;
			float ےӃڈ_u07B5 = this.ےӃڈ\u07B3;
			float x3 = this.ވߩչߨ.x;
			float y3 = this.ވߩչߨ.y;
			float z3 = this.ވߩչߨ.z;
			return;
		}
	}

	// Token: 0x040001CA RID: 458
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001CA")]
	public float ࢥ\u0824Ҽ\u05FB;

	// Token: 0x040001CB RID: 459
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40001CB")]
	public float ش\u085C\u0823փ;

	// Token: 0x040001CC RID: 460
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001CC")]
	public float \u0602\u05C4ޜԭ;

	// Token: 0x040001CD RID: 461
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001CD")]
	public Transform ޛٮܫ\u083D;

	// Token: 0x040001CE RID: 462
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40001CE")]
	public Vector3 ވߩչߨ;

	// Token: 0x040001CF RID: 463
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x40001CF")]
	public bool \u082Aߟӵࠂ;

	// Token: 0x040001D0 RID: 464
	[FieldOffset(Offset = "0x3D")]
	[Token(Token = "0x40001D0")]
	public bool ӿ\u0558ݰݚ;

	// Token: 0x040001D1 RID: 465
	[FieldOffset(Offset = "0x3E")]
	[Token(Token = "0x40001D1")]
	public bool ۵\u06E2ࠈډ;

	// Token: 0x040001D2 RID: 466
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40001D2")]
	private float ےӃڈ\u07B3;
}
