﻿using System;
using Cpp2IlInjected;
using PlayFab.EconomyModels;
using UnityEngine;

// Token: 0x0200007F RID: 127
[Token(Token = "0x200007F")]
public class MB_SwitchBakedObjectsTexture : MonoBehaviour
{
	// Token: 0x06001322 RID: 4898 RVA: 0x0006D0DC File Offset: 0x0006B2DC
	[Token(Token = "0x6001322")]
	[Address(RVA = "0x2C6EA10", Offset = "0x2C6EA10", VA = "0x2C6EA10")]
	public void Update()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001323 RID: 4899 RVA: 0x0006D170 File Offset: 0x0006B370
	[Token(Token = "0x6001323")]
	[Address(RVA = "0x2C6ECBC", Offset = "0x2C6ECBC", VA = "0x2C6ECBC")]
	public void \u07F7ե\u081Fܗ()
	{
	}

	// Token: 0x06001324 RID: 4900 RVA: 0x0006D180 File Offset: 0x0006B380
	[Token(Token = "0x6001324")]
	[Address(RVA = "0x2C6ED9C", Offset = "0x2C6ED9C", VA = "0x2C6ED9C")]
	public void ۊո\u0612\u0595()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001325 RID: 4901 RVA: 0x0006D1A4 File Offset: 0x0006B3A4
	[Token(Token = "0x6001325")]
	[Address(RVA = "0x2C6EE40", Offset = "0x2C6EE40", VA = "0x2C6EE40")]
	public void ࡊ\u0592\u07AB\u05B2()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001326 RID: 4902 RVA: 0x0006D234 File Offset: 0x0006B434
	[Token(Token = "0x6001326")]
	[Address(RVA = "0x2C6F0EC", Offset = "0x2C6F0EC", VA = "0x2C6F0EC")]
	public void ފՖߢ\u059B()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001327 RID: 4903 RVA: 0x0006D2CC File Offset: 0x0006B4CC
	[Token(Token = "0x6001327")]
	[Address(RVA = "0x2C6F3A0", Offset = "0x2C6F3A0", VA = "0x2C6F3A0")]
	public void OnGUI()
	{
	}

	// Token: 0x06001328 RID: 4904 RVA: 0x0006D2DC File Offset: 0x0006B4DC
	[Token(Token = "0x6001328")]
	[Address(RVA = "0x2C6F480", Offset = "0x2C6F480", VA = "0x2C6F480")]
	public void ԅ\u073Fڥ\u0839()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001329 RID: 4905 RVA: 0x0006D36C File Offset: 0x0006B56C
	[Token(Token = "0x6001329")]
	[Address(RVA = "0x2C6F714", Offset = "0x2C6F714", VA = "0x2C6F714")]
	public void ۮߝڪڐ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x0600132A RID: 4906 RVA: 0x0006D390 File Offset: 0x0006B590
	[Token(Token = "0x600132A")]
	[Address(RVA = "0x2C6F7B8", Offset = "0x2C6F7B8", VA = "0x2C6F7B8")]
	public void \u05B5\u0837Ԯݢ()
	{
	}

	// Token: 0x0600132B RID: 4907 RVA: 0x0006D3A0 File Offset: 0x0006B5A0
	[Token(Token = "0x600132B")]
	[Address(RVA = "0x2C6F898", Offset = "0x2C6F898", VA = "0x2C6F898")]
	public void \u05EDց\u081Cت()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600132C RID: 4908 RVA: 0x0006D430 File Offset: 0x0006B630
	[Token(Token = "0x600132C")]
	[Address(RVA = "0x2C6FB38", Offset = "0x2C6FB38", VA = "0x2C6FB38")]
	public void \u0589٣ޖԀ()
	{
	}

	// Token: 0x0600132D RID: 4909 RVA: 0x0006D440 File Offset: 0x0006B640
	[Token(Token = "0x600132D")]
	[Address(RVA = "0x2C6FC18", Offset = "0x2C6FC18", VA = "0x2C6FC18")]
	public void \u06D4ڟڎޜ()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600132E RID: 4910 RVA: 0x0006D4D0 File Offset: 0x0006B6D0
	[Token(Token = "0x600132E")]
	[Address(RVA = "0x2C6FEB4", Offset = "0x2C6FEB4", VA = "0x2C6FEB4")]
	public void \u064Bࢮ\u0589\u05FF()
	{
	}

	// Token: 0x0600132F RID: 4911 RVA: 0x0006D4E0 File Offset: 0x0006B6E0
	[Token(Token = "0x600132F")]
	[Address(RVA = "0x2C6FF94", Offset = "0x2C6FF94", VA = "0x2C6FF94")]
	public void ۆڛߟ\u05A0()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001330 RID: 4912 RVA: 0x0006D504 File Offset: 0x0006B704
	[Token(Token = "0x6001330")]
	[Address(RVA = "0x2C70038", Offset = "0x2C70038", VA = "0x2C70038")]
	public void \u0836\u089Dی\u0735()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001331 RID: 4913 RVA: 0x0006D58C File Offset: 0x0006B78C
	[Token(Token = "0x6001331")]
	[Address(RVA = "0x2C702D0", Offset = "0x2C702D0", VA = "0x2C702D0")]
	public void ҿ\u07BBҽ\u0599()
	{
	}

	// Token: 0x06001332 RID: 4914 RVA: 0x0006D59C File Offset: 0x0006B79C
	[Token(Token = "0x6001332")]
	[Address(RVA = "0x2C703B0", Offset = "0x2C703B0", VA = "0x2C703B0")]
	public void ߠ\u07AAߚթ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001333 RID: 4915 RVA: 0x0006D5C0 File Offset: 0x0006B7C0
	[Token(Token = "0x6001333")]
	[Address(RVA = "0x2C70454", Offset = "0x2C70454", VA = "0x2C70454")]
	public void ݸԲ\u0616Ԫ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001334 RID: 4916 RVA: 0x0006D5E4 File Offset: 0x0006B7E4
	[Token(Token = "0x6001334")]
	[Address(RVA = "0x2C704F8", Offset = "0x2C704F8", VA = "0x2C704F8")]
	public void Ԁߚޘٴ()
	{
	}

	// Token: 0x06001335 RID: 4917 RVA: 0x0006D5F4 File Offset: 0x0006B7F4
	[Token(Token = "0x6001335")]
	[Address(RVA = "0x2C705D8", Offset = "0x2C705D8", VA = "0x2C705D8")]
	public void ߖհݣ߀()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001336 RID: 4918 RVA: 0x0006D618 File Offset: 0x0006B818
	[Token(Token = "0x6001336")]
	[Address(RVA = "0x2C7067C", Offset = "0x2C7067C", VA = "0x2C7067C")]
	public void ࡥ\u07A7\u065Eӽ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001337 RID: 4919 RVA: 0x0006D63C File Offset: 0x0006B83C
	[Token(Token = "0x6001337")]
	[Address(RVA = "0x2C70720", Offset = "0x2C70720", VA = "0x2C70720")]
	public void ߊ\u066A\u05CFԉ()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001338 RID: 4920 RVA: 0x0006D6D0 File Offset: 0x0006B8D0
	[Token(Token = "0x6001338")]
	[Address(RVA = "0x2C709C0", Offset = "0x2C709C0", VA = "0x2C709C0")]
	public void ں٢ࡡ\u05EC()
	{
		do
		{
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001339 RID: 4921 RVA: 0x0006D754 File Offset: 0x0006B954
	[Token(Token = "0x6001339")]
	[Address(RVA = "0x2C70C70", Offset = "0x2C70C70", VA = "0x2C70C70")]
	public void ܫ\u070Fۃ\u07F2()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600133A RID: 4922 RVA: 0x0006D7EC File Offset: 0x0006B9EC
	[Token(Token = "0x600133A")]
	[Address(RVA = "0x2C70F20", Offset = "0x2C70F20", VA = "0x2C70F20")]
	public void پߧ\u081Cӈ()
	{
	}

	// Token: 0x0600133B RID: 4923 RVA: 0x0006D7FC File Offset: 0x0006B9FC
	[Token(Token = "0x600133B")]
	[Address(RVA = "0x2C71000", Offset = "0x2C71000", VA = "0x2C71000")]
	public void Ԁוև\u065B()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x0600133C RID: 4924 RVA: 0x0006D820 File Offset: 0x0006BA20
	[Token(Token = "0x600133C")]
	[Address(RVA = "0x2C710A4", Offset = "0x2C710A4", VA = "0x2C710A4")]
	public void ڍ\u058Bݗࡣ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x0600133D RID: 4925 RVA: 0x0006D844 File Offset: 0x0006BA44
	[Token(Token = "0x600133D")]
	[Address(RVA = "0x2C71148", Offset = "0x2C71148", VA = "0x2C71148")]
	public void ד\u073C\u0613چ()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600133E RID: 4926 RVA: 0x0006D8D0 File Offset: 0x0006BAD0
	[Token(Token = "0x600133E")]
	[Address(RVA = "0x2C713E4", Offset = "0x2C713E4", VA = "0x2C713E4")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600133F RID: 4927 RVA: 0x0006D95C File Offset: 0x0006BB5C
	[Token(Token = "0x600133F")]
	[Address(RVA = "0x2C71680", Offset = "0x2C71680", VA = "0x2C71680")]
	public void \u0832ࢳޤ\u07B5()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001340 RID: 4928 RVA: 0x0006D9F0 File Offset: 0x0006BBF0
	[Token(Token = "0x6001340")]
	[Address(RVA = "0x2C71938", Offset = "0x2C71938", VA = "0x2C71938")]
	public void ١ۏ\u05C4ӝ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001341 RID: 4929 RVA: 0x0006DA14 File Offset: 0x0006BC14
	[Token(Token = "0x6001341")]
	[Address(RVA = "0x2C719DC", Offset = "0x2C719DC", VA = "0x2C719DC")]
	public void \u0598ڂ\u088AՋ()
	{
	}

	// Token: 0x06001342 RID: 4930 RVA: 0x0006DA24 File Offset: 0x0006BC24
	[Token(Token = "0x6001342")]
	[Address(RVA = "0x2C71ABC", Offset = "0x2C71ABC", VA = "0x2C71ABC")]
	public void \u07BE\u06DC\u06FDࢯ()
	{
	}

	// Token: 0x06001343 RID: 4931 RVA: 0x0006DA34 File Offset: 0x0006BC34
	[Token(Token = "0x6001343")]
	[Address(RVA = "0x2C71B9C", Offset = "0x2C71B9C", VA = "0x2C71B9C")]
	public void Ӌ\u089C\u0700ܧ()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001344 RID: 4932 RVA: 0x0006DAC0 File Offset: 0x0006BCC0
	[Token(Token = "0x6001344")]
	[Address(RVA = "0x2C71E38", Offset = "0x2C71E38", VA = "0x2C71E38")]
	public void ӛ\u082Eؿڕ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001345 RID: 4933 RVA: 0x0006DAE4 File Offset: 0x0006BCE4
	[Token(Token = "0x6001345")]
	[Address(RVA = "0x2C71EDC", Offset = "0x2C71EDC", VA = "0x2C71EDC")]
	public void ࡑࢱه\u0896()
	{
	}

	// Token: 0x06001346 RID: 4934 RVA: 0x0006DAF4 File Offset: 0x0006BCF4
	[Token(Token = "0x6001346")]
	[Address(RVA = "0x2C71FBC", Offset = "0x2C71FBC", VA = "0x2C71FBC")]
	public void ԑࡓթݩ()
	{
	}

	// Token: 0x06001347 RID: 4935 RVA: 0x0006DB04 File Offset: 0x0006BD04
	[Token(Token = "0x6001347")]
	[Address(RVA = "0x2C7209C", Offset = "0x2C7209C", VA = "0x2C7209C")]
	public void ہډࠉӥ()
	{
	}

	// Token: 0x06001348 RID: 4936 RVA: 0x0006DB14 File Offset: 0x0006BD14
	[Token(Token = "0x6001348")]
	[Address(RVA = "0x2C7217C", Offset = "0x2C7217C", VA = "0x2C7217C")]
	public void څࡣڐ\u0657()
	{
		do
		{
			long num = 1L;
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (num == 0L)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001349 RID: 4937 RVA: 0x0006DBA4 File Offset: 0x0006BDA4
	[Token(Token = "0x6001349")]
	[Address(RVA = "0x2C7242C", Offset = "0x2C7242C", VA = "0x2C7242C")]
	public void ߉ې\u07F6Ӭ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x0600134A RID: 4938 RVA: 0x0006DBC8 File Offset: 0x0006BDC8
	[Token(Token = "0x600134A")]
	[Address(RVA = "0x2C724D0", Offset = "0x2C724D0", VA = "0x2C724D0")]
	public void Start()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x0600134B RID: 4939 RVA: 0x0006DBEC File Offset: 0x0006BDEC
	[Token(Token = "0x600134B")]
	[Address(RVA = "0x2C72574", Offset = "0x2C72574", VA = "0x2C72574")]
	public void ېذ\u086E\u0732()
	{
	}

	// Token: 0x0600134C RID: 4940 RVA: 0x0006DBFC File Offset: 0x0006BDFC
	[Token(Token = "0x600134C")]
	[Address(RVA = "0x2C72654", Offset = "0x2C72654", VA = "0x2C72654")]
	public void ԣԭՋࠏ()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600134D RID: 4941 RVA: 0x0006DC8C File Offset: 0x0006BE8C
	[Token(Token = "0x600134D")]
	[Address(RVA = "0x2C7290C", Offset = "0x2C7290C", VA = "0x2C7290C")]
	public void \u0886Ҽ\u058Dߛ()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600134E RID: 4942 RVA: 0x0006DD1C File Offset: 0x0006BF1C
	[Token(Token = "0x600134E")]
	[Address(RVA = "0x2C72BA4", Offset = "0x2C72BA4", VA = "0x2C72BA4")]
	public void ݺԞտ\u0817()
	{
	}

	// Token: 0x0600134F RID: 4943 RVA: 0x0006DD2C File Offset: 0x0006BF2C
	[Token(Token = "0x600134F")]
	[Address(RVA = "0x2C72C84", Offset = "0x2C72C84", VA = "0x2C72C84")]
	public void յߪؾՀ()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001350 RID: 4944 RVA: 0x0006DDB8 File Offset: 0x0006BFB8
	[Token(Token = "0x6001350")]
	[Address(RVA = "0x2C72F38", Offset = "0x2C72F38", VA = "0x2C72F38")]
	public void ى\u05F4ڷ߉()
	{
	}

	// Token: 0x06001351 RID: 4945 RVA: 0x0006DDC8 File Offset: 0x0006BFC8
	[Token(Token = "0x6001351")]
	[Address(RVA = "0x2C73018", Offset = "0x2C73018", VA = "0x2C73018")]
	public void ۲ڂ\u05B1ڨ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001352 RID: 4946 RVA: 0x0006DDEC File Offset: 0x0006BFEC
	[Token(Token = "0x6001352")]
	[Address(RVA = "0x2C730BC", Offset = "0x2C730BC", VA = "0x2C730BC")]
	public void \u05C4\u05A8ؼӇ()
	{
	}

	// Token: 0x06001353 RID: 4947 RVA: 0x0006DDFC File Offset: 0x0006BFFC
	[Token(Token = "0x6001353")]
	[Address(RVA = "0x2C7319C", Offset = "0x2C7319C", VA = "0x2C7319C")]
	public void ٺ\u0898ޛޟ()
	{
	}

	// Token: 0x06001354 RID: 4948 RVA: 0x0006DE0C File Offset: 0x0006C00C
	[Token(Token = "0x6001354")]
	[Address(RVA = "0x2C7327C", Offset = "0x2C7327C", VA = "0x2C7327C")]
	public void \u05F8ݑ\u06ECߞ()
	{
		Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
		Material[] ڋح_u05B6_u06E = this.ڋح\u05B6\u06E9;
		if (ڋح_u05B6_u06E == null)
		{
		}
		while (ڋح_u05B6_u06E != null)
		{
		}
		throw new NullReferenceException();
	}

	// Token: 0x06001355 RID: 4949 RVA: 0x0006DE9C File Offset: 0x0006C09C
	[Token(Token = "0x6001355")]
	[Address(RVA = "0x2C73518", Offset = "0x2C73518", VA = "0x2C73518")]
	public void \u06D6ې\u083Bࠉ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001356 RID: 4950 RVA: 0x0006DEC0 File Offset: 0x0006C0C0
	[Token(Token = "0x6001356")]
	[Address(RVA = "0x2C735BC", Offset = "0x2C735BC", VA = "0x2C735BC")]
	public void \u05B3ࢹߧ\u07AA()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001357 RID: 4951 RVA: 0x0006DF50 File Offset: 0x0006C150
	[Token(Token = "0x6001357")]
	[Address(RVA = "0x2C73860", Offset = "0x2C73860", VA = "0x2C73860")]
	public void גԛכ\u0887()
	{
	}

	// Token: 0x06001358 RID: 4952 RVA: 0x0006DF60 File Offset: 0x0006C160
	[Token(Token = "0x6001358")]
	[Address(RVA = "0x2C73940", Offset = "0x2C73940", VA = "0x2C73940")]
	public MB_SwitchBakedObjectsTexture()
	{
	}

	// Token: 0x06001359 RID: 4953 RVA: 0x0006DF74 File Offset: 0x0006C174
	[Token(Token = "0x6001359")]
	[Address(RVA = "0x2C73948", Offset = "0x2C73948", VA = "0x2C73948")]
	public void ٴݵۃ\u05AF()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600135A RID: 4954 RVA: 0x0006E00C File Offset: 0x0006C20C
	[Token(Token = "0x600135A")]
	[Address(RVA = "0x2C73BF8", Offset = "0x2C73BF8", VA = "0x2C73BF8")]
	public void \u070Fߨ\u05B0ۈ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x0600135B RID: 4955 RVA: 0x0006E030 File Offset: 0x0006C230
	[Token(Token = "0x600135B")]
	[Address(RVA = "0x2C73C9C", Offset = "0x2C73C9C", VA = "0x2C73C9C")]
	public void \u0871رؤߡ()
	{
	}

	// Token: 0x0600135C RID: 4956 RVA: 0x0006E040 File Offset: 0x0006C240
	[Token(Token = "0x600135C")]
	[Address(RVA = "0x2C73D7C", Offset = "0x2C73D7C", VA = "0x2C73D7C")]
	public void \u055Cࢯܯ\u0898()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600135D RID: 4957 RVA: 0x0006E0D0 File Offset: 0x0006C2D0
	[Token(Token = "0x600135D")]
	[Address(RVA = "0x2C74030", Offset = "0x2C74030", VA = "0x2C74030")]
	public void \u0705\u0816\u0739դ()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600135E RID: 4958 RVA: 0x0006E160 File Offset: 0x0006C360
	[Token(Token = "0x600135E")]
	[Address(RVA = "0x2C742C8", Offset = "0x2C742C8", VA = "0x2C742C8")]
	public void ࡂ\u06DBࠊջ()
	{
		if (typeof(SubmitItemReviewVoteRequest).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600135F RID: 4959 RVA: 0x0006E174 File Offset: 0x0006C374
	[Token(Token = "0x600135F")]
	[Address(RVA = "0x2C743A8", Offset = "0x2C743A8", VA = "0x2C743A8")]
	public void \u0730\u061A\u058Bڷ()
	{
	}

	// Token: 0x06001360 RID: 4960 RVA: 0x0006E184 File Offset: 0x0006C384
	[Token(Token = "0x6001360")]
	[Address(RVA = "0x2C74488", Offset = "0x2C74488", VA = "0x2C74488")]
	public void \u05ABࡡ\u07ABݾ()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001361 RID: 4961 RVA: 0x0006E210 File Offset: 0x0006C410
	[Token(Token = "0x6001361")]
	[Address(RVA = "0x2C7473C", Offset = "0x2C7473C", VA = "0x2C7473C")]
	public void \u086Bԍࡊڭ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
		throw new NullReferenceException();
	}

	// Token: 0x06001362 RID: 4962 RVA: 0x0006E230 File Offset: 0x0006C430
	[Token(Token = "0x6001362")]
	[Address(RVA = "0x2C747E0", Offset = "0x2C747E0", VA = "0x2C747E0")]
	public void \u05C1ܡԘޘ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001363 RID: 4963 RVA: 0x0006E254 File Offset: 0x0006C454
	[Token(Token = "0x6001363")]
	[Address(RVA = "0x2C74884", Offset = "0x2C74884", VA = "0x2C74884")]
	public void \u0859\u0895ӇԚ()
	{
	}

	// Token: 0x06001364 RID: 4964 RVA: 0x0006E264 File Offset: 0x0006C464
	[Token(Token = "0x6001364")]
	[Address(RVA = "0x2C74964", Offset = "0x2C74964", VA = "0x2C74964")]
	public void \u06EDٵ۶\u06DB()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001365 RID: 4965 RVA: 0x0006E288 File Offset: 0x0006C488
	[Token(Token = "0x6001365")]
	[Address(RVA = "0x2C74A08", Offset = "0x2C74A08", VA = "0x2C74A08")]
	public void ڞױ\u0899\u066C()
	{
	}

	// Token: 0x06001366 RID: 4966 RVA: 0x0006E298 File Offset: 0x0006C498
	[Token(Token = "0x6001366")]
	[Address(RVA = "0x2C74AE8", Offset = "0x2C74AE8", VA = "0x2C74AE8")]
	public void چאӣک()
	{
	}

	// Token: 0x06001367 RID: 4967 RVA: 0x0006E2A8 File Offset: 0x0006C4A8
	[Token(Token = "0x6001367")]
	[Address(RVA = "0x2C74BC8", Offset = "0x2C74BC8", VA = "0x2C74BC8")]
	public void Ӯޱ\u0703ࢪ()
	{
	}

	// Token: 0x06001368 RID: 4968 RVA: 0x0006E2B8 File Offset: 0x0006C4B8
	[Token(Token = "0x6001368")]
	[Address(RVA = "0x2C74CA8", Offset = "0x2C74CA8", VA = "0x2C74CA8")]
	public void \u0741\u07A7\u0749ݧ()
	{
	}

	// Token: 0x06001369 RID: 4969 RVA: 0x0006E2C8 File Offset: 0x0006C4C8
	[Token(Token = "0x6001369")]
	[Address(RVA = "0x2C74D88", Offset = "0x2C74D88", VA = "0x2C74D88")]
	public void Ԩ\u058Eۉ\u0607()
	{
	}

	// Token: 0x0600136A RID: 4970 RVA: 0x0006E2D8 File Offset: 0x0006C4D8
	[Token(Token = "0x600136A")]
	[Address(RVA = "0x2C74E68", Offset = "0x2C74E68", VA = "0x2C74E68")]
	public void \u07FE\u0882Զ\u066D()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600136B RID: 4971 RVA: 0x0006E36C File Offset: 0x0006C56C
	[Token(Token = "0x600136B")]
	[Address(RVA = "0x2C7511C", Offset = "0x2C7511C", VA = "0x2C7511C")]
	public void \u07F7ܙײ\u05B5()
	{
		do
		{
			long num = 1L;
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (num == 0L)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600136C RID: 4972 RVA: 0x0006E3F8 File Offset: 0x0006C5F8
	[Token(Token = "0x600136C")]
	[Address(RVA = "0x2C753C8", Offset = "0x2C753C8", VA = "0x2C753C8")]
	public void Ҿࢹؼס()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600136D RID: 4973 RVA: 0x0006E490 File Offset: 0x0006C690
	[Token(Token = "0x600136D")]
	[Address(RVA = "0x2C7567C", Offset = "0x2C7567C", VA = "0x2C7567C")]
	public void گ\u085E\u073Dڊ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x0600136E RID: 4974 RVA: 0x0006E4B4 File Offset: 0x0006C6B4
	[Token(Token = "0x600136E")]
	[Address(RVA = "0x2C75720", Offset = "0x2C75720", VA = "0x2C75720")]
	public void \u05AC\u05FC\u087Dޒ()
	{
	}

	// Token: 0x0600136F RID: 4975 RVA: 0x0006E4C4 File Offset: 0x0006C6C4
	[Token(Token = "0x600136F")]
	[Address(RVA = "0x2C75800", Offset = "0x2C75800", VA = "0x2C75800")]
	public void ی\u0823ڇݔ()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
			bool flag = sharedMaterial == sharedMaterial;
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001370 RID: 4976 RVA: 0x0006E558 File Offset: 0x0006C758
	[Token(Token = "0x6001370")]
	[Address(RVA = "0x2C75A98", Offset = "0x2C75A98", VA = "0x2C75A98")]
	public void \u05BA\u0893ހՎ()
	{
	}

	// Token: 0x06001371 RID: 4977 RVA: 0x0006E568 File Offset: 0x0006C768
	[Token(Token = "0x6001371")]
	[Address(RVA = "0x2C75B78", Offset = "0x2C75B78", VA = "0x2C75B78")]
	public void ڨӵإը()
	{
	}

	// Token: 0x06001372 RID: 4978 RVA: 0x0006E578 File Offset: 0x0006C778
	[Token(Token = "0x6001372")]
	[Address(RVA = "0x2C75C58", Offset = "0x2C75C58", VA = "0x2C75C58")]
	public void چ\u05AEךڰ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001373 RID: 4979 RVA: 0x0006E59C File Offset: 0x0006C79C
	[Token(Token = "0x6001373")]
	[Address(RVA = "0x2C75CFC", Offset = "0x2C75CFC", VA = "0x2C75CFC")]
	public void ڄ\u0734ԛ\u05C8()
	{
	}

	// Token: 0x06001374 RID: 4980 RVA: 0x0006E5AC File Offset: 0x0006C7AC
	[Token(Token = "0x6001374")]
	[Address(RVA = "0x2C75DDC", Offset = "0x2C75DDC", VA = "0x2C75DDC")]
	public void ԦӔԁֆ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001375 RID: 4981 RVA: 0x0006E5D0 File Offset: 0x0006C7D0
	[Token(Token = "0x6001375")]
	[Address(RVA = "0x2C75E80", Offset = "0x2C75E80", VA = "0x2C75E80")]
	public void \u05C8\u05BFࠁف()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x06001376 RID: 4982 RVA: 0x0006E5F4 File Offset: 0x0006C7F4
	[Token(Token = "0x6001376")]
	[Address(RVA = "0x2C75F24", Offset = "0x2C75F24", VA = "0x2C75F24")]
	public void ޒӠۅߐ()
	{
	}

	// Token: 0x06001377 RID: 4983 RVA: 0x0006E604 File Offset: 0x0006C804
	[Token(Token = "0x6001377")]
	[Address(RVA = "0x2C76004", Offset = "0x2C76004", VA = "0x2C76004")]
	public void \u0838ӆڛӑ()
	{
		Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
		if (this.ڋح\u05B6\u06E9 == null)
		{
		}
		Material[] ڋح_u05B6_u06E = this.ڋح\u05B6\u06E9;
		throw new NullReferenceException();
	}

	// Token: 0x06001378 RID: 4984 RVA: 0x0006E688 File Offset: 0x0006C888
	[Token(Token = "0x6001378")]
	[Address(RVA = "0x2C762A0", Offset = "0x2C762A0", VA = "0x2C762A0")]
	public void ܩ\u06E2߈ջ()
	{
	}

	// Token: 0x06001379 RID: 4985 RVA: 0x0006E698 File Offset: 0x0006C898
	[Token(Token = "0x6001379")]
	[Address(RVA = "0x2C76380", Offset = "0x2C76380", VA = "0x2C76380")]
	public void ژךՈ\u0597()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600137A RID: 4986 RVA: 0x0006E72C File Offset: 0x0006C92C
	[Token(Token = "0x600137A")]
	[Address(RVA = "0x2C7663C", Offset = "0x2C7663C", VA = "0x2C7663C")]
	public void \u05FEօ\u06D7ࡁ()
	{
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		MB3_MeshBaker ݽ_u06E2ս_u06D2 = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x0600137B RID: 4987 RVA: 0x0006E750 File Offset: 0x0006C950
	[Token(Token = "0x600137B")]
	[Address(RVA = "0x2C766E0", Offset = "0x2C766E0", VA = "0x2C766E0")]
	public void ڦکӁ\u06E2()
	{
		do
		{
			Material sharedMaterial = this.\u05B5\u064Eࠌࠏ.sharedMaterial;
			if (this.ڋح\u05B6\u06E9 == null)
			{
			}
		}
		while (this.ڋح\u05B6\u06E9 != null);
		throw new NullReferenceException();
	}

	// Token: 0x04000266 RID: 614
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000266")]
	public MeshRenderer \u05B5\u064Eࠌࠏ;

	// Token: 0x04000267 RID: 615
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000267")]
	public Material[] ڋح\u05B6\u06E9;

	// Token: 0x04000268 RID: 616
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000268")]
	public MB3_MeshBaker ݽ\u06E2ս\u06D7;
}
