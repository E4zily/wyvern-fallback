﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200001B RID: 27
[Token(Token = "0x200001B")]
public class TeleportObject : MonoBehaviour
{
	// Token: 0x06000383 RID: 899 RVA: 0x00016220 File Offset: 0x00014420
	[Token(Token = "0x6000383")]
	[Address(RVA = "0x2F1FE10", Offset = "0x2F1FE10", VA = "0x2F1FE10")]
	private IEnumerator آࠁࠁ\u06D8()
	{
		long <>1__state;
		TeleportObject.\u06DDܭԌӁ u06DDܭԌӁ = new TeleportObject.\u06DDܭԌӁ((int)<>1__state);
		<>1__state = 0L;
		u06DDܭԌӁ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000384 RID: 900 RVA: 0x00016244 File Offset: 0x00014444
	[Token(Token = "0x6000384")]
	[Address(RVA = "0x2F1FE88", Offset = "0x2F1FE88", VA = "0x2F1FE88")]
	private IEnumerator ߩ\u06E0Ҿվ()
	{
		long <>1__state;
		TeleportObject.\u06DDܭԌӁ u06DDܭԌӁ = new TeleportObject.\u06DDܭԌӁ((int)<>1__state);
		<>1__state = 0L;
		u06DDܭԌӁ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000385 RID: 901 RVA: 0x00016268 File Offset: 0x00014468
	[Token(Token = "0x6000385")]
	[Address(RVA = "0x2F1FF00", Offset = "0x2F1FF00", VA = "0x2F1FF00")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		Transform ܘ_u055Eࡒ_u07BA = this.ܘ\u055Eࡒ\u07BA;
		Transform u0596إݒן = this.\u0596إݒן;
		Vector3 position = ܘ_u055Eࡒ_u07BA.position;
		if (this.\u0888ߨ\u0616ߤ)
		{
			Coroutine coroutine = base.StartCoroutine("_WobbleZ");
			return;
		}
	}

	// Token: 0x06000386 RID: 902 RVA: 0x000162C4 File Offset: 0x000144C4
	[Token(Token = "0x6000386")]
	[Address(RVA = "0x2F1FFC8", Offset = "0x2F1FFC8", VA = "0x2F1FFC8")]
	private IEnumerator \u0612ݳ\u05F5ݷ()
	{
		return typeof(TeleportObject.\u06DDܭԌӁ).TypeHandle;
	}

	// Token: 0x06000387 RID: 903 RVA: 0x000162EC File Offset: 0x000144EC
	[Token(Token = "0x6000387")]
	[Address(RVA = "0x2F20040", Offset = "0x2F20040", VA = "0x2F20040")]
	private IEnumerator ݯԅӽ\u0653()
	{
		TeleportObject.\u06DDܭԌӁ u06DDܭԌӁ;
		u06DDܭԌӁ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000388 RID: 904 RVA: 0x00016308 File Offset: 0x00014508
	[Token(Token = "0x6000388")]
	[Address(RVA = "0x2F200B8", Offset = "0x2F200B8", VA = "0x2F200B8")]
	private IEnumerator Ռ\u05C0\u0745\u0658()
	{
		long <>1__state;
		TeleportObject.\u06DDܭԌӁ u06DDܭԌӁ = new TeleportObject.\u06DDܭԌӁ((int)<>1__state);
		<>1__state = 0L;
		u06DDܭԌӁ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000389 RID: 905 RVA: 0x0001632C File Offset: 0x0001452C
	[Token(Token = "0x6000389")]
	[Address(RVA = "0x2F20130", Offset = "0x2F20130", VA = "0x2F20130")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		Transform ܘ_u055Eࡒ_u07BA = this.ܘ\u055Eࡒ\u07BA;
		Transform u0596إݒן = this.\u0596إݒן;
		Vector3 position = ܘ_u055Eࡒ_u07BA.position;
		if (this.\u0888ߨ\u0616ߤ)
		{
			Coroutine coroutine = base.StartCoroutine("ؒݳ׵ݷ");
			return;
		}
	}

	// Token: 0x0600038A RID: 906 RVA: 0x00016388 File Offset: 0x00014588
	[Token(Token = "0x600038A")]
	[Address(RVA = "0x2F201F8", Offset = "0x2F201F8", VA = "0x2F201F8")]
	private IEnumerator \u07BF\u07B2ߝں()
	{
		long <>1__state;
		TeleportObject.\u06DDܭԌӁ u06DDܭԌӁ = new TeleportObject.\u06DDܭԌӁ((int)<>1__state);
		<>1__state = 1L;
		u06DDܭԌӁ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600038B RID: 907 RVA: 0x000163AC File Offset: 0x000145AC
	[Token(Token = "0x600038B")]
	[Address(RVA = "0x2F20270", Offset = "0x2F20270", VA = "0x2F20270")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		Transform ܘ_u055Eࡒ_u07BA = this.ܘ\u055Eࡒ\u07BA;
		Transform u0596إݒן = this.\u0596إݒן;
		Vector3 position = ܘ_u055Eࡒ_u07BA.position;
		if (this.\u0888ߨ\u0616ߤ)
		{
			return;
		}
	}

	// Token: 0x0600038C RID: 908 RVA: 0x000163FC File Offset: 0x000145FC
	[Token(Token = "0x600038C")]
	[Address(RVA = "0x2F20338", Offset = "0x2F20338", VA = "0x2F20338")]
	private IEnumerator է\u0657ݽԈ()
	{
		long <>1__state;
		TeleportObject.\u06DDܭԌӁ u06DDܭԌӁ = new TeleportObject.\u06DDܭԌӁ((int)<>1__state);
		<>1__state = 1L;
		u06DDܭԌӁ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600038D RID: 909 RVA: 0x00016420 File Offset: 0x00014620
	[Token(Token = "0x600038D")]
	[Address(RVA = "0x2F203B0", Offset = "0x2F203B0", VA = "0x2F203B0")]
	private IEnumerator ۿ\u0897\u0821\u07BF()
	{
		long <>1__state;
		TeleportObject.\u06DDܭԌӁ u06DDܭԌӁ = new TeleportObject.\u06DDܭԌӁ((int)<>1__state);
		<>1__state = 1L;
		u06DDܭԌӁ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600038E RID: 910 RVA: 0x00016444 File Offset: 0x00014644
	[Token(Token = "0x600038E")]
	[Address(RVA = "0x2F20428", Offset = "0x2F20428", VA = "0x2F20428")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		Transform ܘ_u055Eࡒ_u07BA = this.ܘ\u055Eࡒ\u07BA;
		Transform u0596إݒן = this.\u0596إݒן;
		Vector3 position = ܘ_u055Eࡒ_u07BA.position;
		if (this.\u0888ߨ\u0616ߤ)
		{
			Coroutine coroutine = base.StartCoroutine("Player was caught cheating");
			return;
		}
	}

	// Token: 0x0600038F RID: 911 RVA: 0x000164A0 File Offset: 0x000146A0
	[Token(Token = "0x600038F")]
	[Address(RVA = "0x2F204F0", Offset = "0x2F204F0", VA = "0x2F204F0")]
	private IEnumerator ٥\u089Eݺی()
	{
		long <>1__state;
		TeleportObject.\u06DDܭԌӁ u06DDܭԌӁ = new TeleportObject.\u06DDܭԌӁ((int)<>1__state);
		<>1__state = 0L;
		u06DDܭԌӁ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000390 RID: 912 RVA: 0x000164C4 File Offset: 0x000146C4
	[Token(Token = "0x6000390")]
	[Address(RVA = "0x2F20568", Offset = "0x2F20568", VA = "0x2F20568")]
	public TeleportObject()
	{
	}

	// Token: 0x04000071 RID: 113
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000071")]
	public Transform \u0596إݒן;

	// Token: 0x04000072 RID: 114
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000072")]
	public Transform ܘ\u055Eࡒ\u07BA;

	// Token: 0x04000073 RID: 115
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000073")]
	public string \u070FӏԊӏ;

	// Token: 0x04000074 RID: 116
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000074")]
	public GameObject ݨӨӜک;

	// Token: 0x04000075 RID: 117
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000075")]
	public bool \u0888ߨ\u0616ߤ;
}
