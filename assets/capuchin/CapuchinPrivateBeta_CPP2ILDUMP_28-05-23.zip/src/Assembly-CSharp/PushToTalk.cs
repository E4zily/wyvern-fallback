﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000091 RID: 145
[Token(Token = "0x2000091")]
public class PushToTalk : MonoBehaviour
{
	// Token: 0x060015F5 RID: 5621 RVA: 0x0007ACE8 File Offset: 0x00078EE8
	[Token(Token = "0x60015F5")]
	[Address(RVA = "0x2F9B1DC", Offset = "0x2F9B1DC", VA = "0x2F9B1DC")]
	public void Ҽ\u08B5ځ\u0658()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
	}

	// Token: 0x060015F6 RID: 5622 RVA: 0x0007AD64 File Offset: 0x00078F64
	[Token(Token = "0x60015F6")]
	[Address(RVA = "0x2F9B3A0", Offset = "0x2F9B3A0", VA = "0x2F9B3A0")]
	public void ں٢ࡡ\u05EC()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x060015F7 RID: 5623 RVA: 0x0007ADE0 File Offset: 0x00078FE0
	[Token(Token = "0x60015F7")]
	[Address(RVA = "0x2F9B574", Offset = "0x2F9B574", VA = "0x2F9B574")]
	public void ڃրӢԖ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
	}

	// Token: 0x060015F8 RID: 5624 RVA: 0x0007AE5C File Offset: 0x0007905C
	[Token(Token = "0x60015F8")]
	[Address(RVA = "0x2F9B738", Offset = "0x2F9B738", VA = "0x2F9B738")]
	public void Ӣ\u0592ߨׯ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		InputDevice deviceAtXRNode2 = InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B);
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x060015F9 RID: 5625 RVA: 0x0007AED8 File Offset: 0x000790D8
	[Token(Token = "0x60015F9")]
	[Address(RVA = "0x2F9B90C", Offset = "0x2F9B90C", VA = "0x2F9B90C")]
	public void Update()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.ؼڪކޞ;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.ؼڪކޞ;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060015FA RID: 5626 RVA: 0x0007AF50 File Offset: 0x00079150
	[Token(Token = "0x60015FA")]
	[Address(RVA = "0x2F9BAC0", Offset = "0x2F9BAC0", VA = "0x2F9BAC0")]
	public void ڑߒجވ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		InputDevice deviceAtXRNode2 = InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B);
		if (deviceAtXRNode2 == null)
		{
		}
		bool initialized = deviceAtXRNode2.m_Initialized;
		GameObject gameObject = this.ؼڪކޞ;
		if (deviceAtXRNode2 != null)
		{
			return;
		}
		long active = 0L;
		gameObject.SetActive(active != 0L);
		if (deviceAtXRNode2 == null)
		{
		}
		GameObject gameObject2 = this.ؼڪކޞ;
	}

	// Token: 0x060015FB RID: 5627 RVA: 0x0007AFE0 File Offset: 0x000791E0
	[Token(Token = "0x60015FB")]
	[Address(RVA = "0x2F9BCA4", Offset = "0x2F9BCA4", VA = "0x2F9BCA4")]
	public void \u061Fࡆ\u086F\u07B0()
	{
		long num = 1L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		InputDevice deviceAtXRNode2 = InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B);
		if (num == 0L)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x060015FC RID: 5628 RVA: 0x0007B064 File Offset: 0x00079264
	[Token(Token = "0x60015FC")]
	[Address(RVA = "0x2F9BE88", Offset = "0x2F9BE88", VA = "0x2F9BE88")]
	public PushToTalk()
	{
	}

	// Token: 0x060015FD RID: 5629 RVA: 0x0007B078 File Offset: 0x00079278
	[Token(Token = "0x60015FD")]
	[Address(RVA = "0x2F9BE90", Offset = "0x2F9BE90", VA = "0x2F9BE90")]
	public void \u05EDց\u081Cت()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
	}

	// Token: 0x060015FE RID: 5630 RVA: 0x0007B0F4 File Offset: 0x000792F4
	[Token(Token = "0x60015FE")]
	[Address(RVA = "0x2F9C064", Offset = "0x2F9C064", VA = "0x2F9C064")]
	public void \u087BӦןݩ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x060015FF RID: 5631 RVA: 0x0007B170 File Offset: 0x00079370
	[Token(Token = "0x60015FF")]
	[Address(RVA = "0x2F9C248", Offset = "0x2F9C248", VA = "0x2F9C248")]
	public void \u05F7ԝߠӱ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x06001600 RID: 5632 RVA: 0x0007B1EC File Offset: 0x000793EC
	[Token(Token = "0x6001600")]
	[Address(RVA = "0x2F9C41C", Offset = "0x2F9C41C", VA = "0x2F9C41C")]
	public void څࡣڐ\u0657()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x06001601 RID: 5633 RVA: 0x0007B268 File Offset: 0x00079468
	[Token(Token = "0x6001601")]
	[Address(RVA = "0x2F9C5E0", Offset = "0x2F9C5E0", VA = "0x2F9C5E0")]
	public void ւࡂ\u0883\u0872()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
	}

	// Token: 0x06001602 RID: 5634 RVA: 0x0007B2E4 File Offset: 0x000794E4
	[Token(Token = "0x6001602")]
	[Address(RVA = "0x2F9C7B4", Offset = "0x2F9C7B4", VA = "0x2F9C7B4")]
	public void \u0654ޛ\u07FAذ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x06001603 RID: 5635 RVA: 0x0007B360 File Offset: 0x00079560
	[Token(Token = "0x6001603")]
	[Address(RVA = "0x2F9C9A8", Offset = "0x2F9C9A8", VA = "0x2F9C9A8")]
	public void \u061B\u05EEوۈ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.ؼڪކޞ;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.ؼڪކޞ;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x06001604 RID: 5636 RVA: 0x0007B3D8 File Offset: 0x000795D8
	[Token(Token = "0x6001604")]
	[Address(RVA = "0x2F9CB5C", Offset = "0x2F9CB5C", VA = "0x2F9CB5C")]
	public void ފՖߢ\u059B()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
	}

	// Token: 0x06001605 RID: 5637 RVA: 0x0007B454 File Offset: 0x00079654
	[Token(Token = "0x6001605")]
	[Address(RVA = "0x2F9CD20", Offset = "0x2F9CD20", VA = "0x2F9CD20")]
	public void \u0732ڙԒࢺ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
	}

	// Token: 0x06001606 RID: 5638 RVA: 0x0007B4D0 File Offset: 0x000796D0
	[Token(Token = "0x6001606")]
	[Address(RVA = "0x2F9CEF4", Offset = "0x2F9CEF4", VA = "0x2F9CEF4")]
	public void ܣ\u086E\u05CF\u06D8()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.ؼڪކޞ;
	}

	// Token: 0x06001607 RID: 5639 RVA: 0x0007B54C File Offset: 0x0007974C
	[Token(Token = "0x6001607")]
	[Address(RVA = "0x2F9D0C8", Offset = "0x2F9D0C8", VA = "0x2F9D0C8")]
	public void ӻӒݝ߃()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
	}

	// Token: 0x06001608 RID: 5640 RVA: 0x0007B5C8 File Offset: 0x000797C8
	[Token(Token = "0x6001608")]
	[Address(RVA = "0x2F9D29C", Offset = "0x2F9D29C", VA = "0x2F9D29C")]
	public void \u070Aәޣے()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
	}

	// Token: 0x06001609 RID: 5641 RVA: 0x0007B644 File Offset: 0x00079844
	[Token(Token = "0x6001609")]
	[Address(RVA = "0x2F9D480", Offset = "0x2F9D480", VA = "0x2F9D480")]
	public void ԟ\u086Cޣ\u055E()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x0600160A RID: 5642 RVA: 0x0007B6C0 File Offset: 0x000798C0
	[Token(Token = "0x600160A")]
	[Address(RVA = "0x2F9D664", Offset = "0x2F9D664", VA = "0x2F9D664")]
	public void ٴݵۃ\u05AF()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x0600160B RID: 5643 RVA: 0x0007B73C File Offset: 0x0007993C
	[Token(Token = "0x600160B")]
	[Address(RVA = "0x2F9D848", Offset = "0x2F9D848", VA = "0x2F9D848")]
	public void Ҿࢹؼס()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x0600160C RID: 5644 RVA: 0x0007B7B8 File Offset: 0x000799B8
	[Token(Token = "0x600160C")]
	[Address(RVA = "0x2F9DA2C", Offset = "0x2F9DA2C", VA = "0x2F9DA2C")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x0600160D RID: 5645 RVA: 0x0007B834 File Offset: 0x00079A34
	[Token(Token = "0x600160D")]
	[Address(RVA = "0x2F9DC00", Offset = "0x2F9DC00", VA = "0x2F9DC00")]
	public void ࢫ\u0876չՍ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.ؼڪކޞ;
	}

	// Token: 0x0600160E RID: 5646 RVA: 0x0007B8B0 File Offset: 0x00079AB0
	[Token(Token = "0x600160E")]
	[Address(RVA = "0x2F9DDC4", Offset = "0x2F9DDC4", VA = "0x2F9DDC4")]
	public void ԣԭՋࠏ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.ؼڪކޞ;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.ؼڪކޞ;
	}

	// Token: 0x0600160F RID: 5647 RVA: 0x0007B92C File Offset: 0x00079B2C
	[Token(Token = "0x600160F")]
	[Address(RVA = "0x2F9DF98", Offset = "0x2F9DF98", VA = "0x2F9DF98")]
	public void ժ\u065Dԯࡘ()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x06001610 RID: 5648 RVA: 0x0007B9A8 File Offset: 0x00079BA8
	[Token(Token = "0x6001610")]
	[Address(RVA = "0x2F9E16C", Offset = "0x2F9E16C", VA = "0x2F9E16C")]
	public void \u0881ݗӟ\u07BD()
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ޒӇӥ\u07F5);
		if (InputDevices.GetDeviceAtXRNode(this.ӓ\u0816\u089D\u061B) == null)
		{
		}
		GameObject gameObject = this.ؼڪކޞ;
	}

	// Token: 0x040002BF RID: 703
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002BF")]
	public XRNode ޒӇӥ\u07F5;

	// Token: 0x040002C0 RID: 704
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40002C0")]
	public XRNode ӓ\u0816\u089D\u061B;

	// Token: 0x040002C1 RID: 705
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002C1")]
	public GameObject ؼڪކޞ;
}
