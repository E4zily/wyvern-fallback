﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000089 RID: 137
[Token(Token = "0x2000089")]
public class MuteMusic : MonoBehaviour
{
	// Token: 0x0600143F RID: 5183 RVA: 0x00071568 File Offset: 0x0006F768
	[Token(Token = "0x600143F")]
	[Address(RVA = "0x23BF094", Offset = "0x23BF094", VA = "0x23BF094")]
	public MuteMusic()
	{
	}

	// Token: 0x06001440 RID: 5184 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001440")]
	[Address(RVA = "0x23BF09C", Offset = "0x23BF09C", VA = "0x23BF09C")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001441 RID: 5185 RVA: 0x0007157C File Offset: 0x0006F77C
	[Token(Token = "0x6001441")]
	[Address(RVA = "0x23BF1B8", Offset = "0x23BF1B8", VA = "0x23BF1B8")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u064F\u0820\u087CӜ == null)
		{
			return;
		}
	}

	// Token: 0x06001442 RID: 5186 RVA: 0x000715AC File Offset: 0x0006F7AC
	[Token(Token = "0x6001442")]
	[Address(RVA = "0x23BF2AC", Offset = "0x23BF2AC", VA = "0x23BF2AC")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x06001443 RID: 5187 RVA: 0x000715E4 File Offset: 0x0006F7E4
	[Token(Token = "0x6001443")]
	[Address(RVA = "0x23BF3C4", Offset = "0x23BF3C4", VA = "0x23BF3C4")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x06001444 RID: 5188 RVA: 0x0007161C File Offset: 0x0006F81C
	[Token(Token = "0x6001444")]
	[Address(RVA = "0x23BF4E0", Offset = "0x23BF4E0", VA = "0x23BF4E0")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u064F\u0820\u087CӜ == null)
		{
			return;
		}
	}

	// Token: 0x06001445 RID: 5189 RVA: 0x0007164C File Offset: 0x0006F84C
	[Token(Token = "0x6001445")]
	[Address(RVA = "0x23BF5D0", Offset = "0x23BF5D0", VA = "0x23BF5D0")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u064F\u0820\u087CӜ == null)
		{
			return;
		}
	}

	// Token: 0x06001446 RID: 5190 RVA: 0x0007167C File Offset: 0x0006F87C
	[Token(Token = "0x6001446")]
	[Address(RVA = "0x23BF6C0", Offset = "0x23BF6C0", VA = "0x23BF6C0")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u064F\u0820\u087CӜ == null)
		{
			return;
		}
	}

	// Token: 0x06001447 RID: 5191 RVA: 0x000716AC File Offset: 0x0006F8AC
	[Token(Token = "0x6001447")]
	[Address(RVA = "0x23BF7B4", Offset = "0x23BF7B4", VA = "0x23BF7B4")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x06001448 RID: 5192 RVA: 0x000716E4 File Offset: 0x0006F8E4
	[Token(Token = "0x6001448")]
	[Address(RVA = "0x23BF8D0", Offset = "0x23BF8D0", VA = "0x23BF8D0")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x06001449 RID: 5193 RVA: 0x0007171C File Offset: 0x0006F91C
	[Token(Token = "0x6001449")]
	[Address(RVA = "0x23BF9E8", Offset = "0x23BF9E8", VA = "0x23BF9E8")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x0600144A RID: 5194 RVA: 0x00071754 File Offset: 0x0006F954
	[Token(Token = "0x600144A")]
	[Address(RVA = "0x23BFB00", Offset = "0x23BFB00", VA = "0x23BFB00")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x0600144B RID: 5195 RVA: 0x0007178C File Offset: 0x0006F98C
	[Token(Token = "0x600144B")]
	[Address(RVA = "0x23BFC1C", Offset = "0x23BFC1C", VA = "0x23BFC1C")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x0600144C RID: 5196 RVA: 0x000717C4 File Offset: 0x0006F9C4
	[Token(Token = "0x600144C")]
	[Address(RVA = "0x23BFD38", Offset = "0x23BFD38", VA = "0x23BFD38")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x0600144D RID: 5197 RVA: 0x000717FC File Offset: 0x0006F9FC
	[Token(Token = "0x600144D")]
	[Address(RVA = "0x23BFE54", Offset = "0x23BFE54", VA = "0x23BFE54")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x0600144E RID: 5198 RVA: 0x00071834 File Offset: 0x0006FA34
	[Token(Token = "0x600144E")]
	[Address(RVA = "0x23BFF70", Offset = "0x23BFF70", VA = "0x23BFF70")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u064F\u0820\u087CӜ == null)
		{
			return;
		}
	}

	// Token: 0x0600144F RID: 5199 RVA: 0x00071864 File Offset: 0x0006FA64
	[Token(Token = "0x600144F")]
	[Address(RVA = "0x23C0060", Offset = "0x23C0060", VA = "0x23C0060")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u064F\u0820\u087CӜ == null)
		{
			return;
		}
	}

	// Token: 0x06001450 RID: 5200 RVA: 0x00071894 File Offset: 0x0006FA94
	[Token(Token = "0x6001450")]
	[Address(RVA = "0x23C0154", Offset = "0x23C0154", VA = "0x23C0154")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u064F\u0820\u087CӜ == null)
		{
			return;
		}
	}

	// Token: 0x06001451 RID: 5201 RVA: 0x000718C4 File Offset: 0x0006FAC4
	[Token(Token = "0x6001451")]
	[Address(RVA = "0x23C0248", Offset = "0x23C0248", VA = "0x23C0248")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x06001452 RID: 5202 RVA: 0x000718FC File Offset: 0x0006FAFC
	[Token(Token = "0x6001452")]
	[Address(RVA = "0x23C0360", Offset = "0x23C0360", VA = "0x23C0360")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x06001453 RID: 5203 RVA: 0x00071934 File Offset: 0x0006FB34
	[Token(Token = "0x6001453")]
	[Address(RVA = "0x23C047C", Offset = "0x23C047C", VA = "0x23C047C")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u064F\u0820\u087CӜ == null)
		{
			return;
		}
	}

	// Token: 0x06001454 RID: 5204 RVA: 0x00071964 File Offset: 0x0006FB64
	[Token(Token = "0x6001454")]
	[Address(RVA = "0x23C056C", Offset = "0x23C056C", VA = "0x23C056C")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		AudioSource[] u064F_u0820_u087CӜ = this.\u064F\u0820\u087CӜ;
	}

	// Token: 0x06001455 RID: 5205 RVA: 0x0007199C File Offset: 0x0006FB9C
	[Token(Token = "0x6001455")]
	[Address(RVA = "0x23C0688", Offset = "0x23C0688", VA = "0x23C0688")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		if (this.\u064F\u0820\u087CӜ == null)
		{
			return;
		}
	}

	// Token: 0x0400028A RID: 650
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400028A")]
	public AudioSource[] \u064F\u0820\u087CӜ;
}
