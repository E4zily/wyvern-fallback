﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200004B RID: 75
[Token(Token = "0x200004B")]
public class Charger : MonoBehaviour
{
	// Token: 0x06000A50 RID: 2640 RVA: 0x0003937C File Offset: 0x0003757C
	[Token(Token = "0x6000A50")]
	[Address(RVA = "0x2947AF8", Offset = "0x2947AF8", VA = "0x2947AF8")]
	private void \u07A7ࡐ\u0818ܭ()
	{
	}

	// Token: 0x06000A51 RID: 2641 RVA: 0x0003938C File Offset: 0x0003758C
	[Token(Token = "0x6000A51")]
	[Address(RVA = "0x2947AFC", Offset = "0x2947AFC", VA = "0x2947AFC")]
	private void Գӿېչ()
	{
	}

	// Token: 0x06000A52 RID: 2642 RVA: 0x0003939C File Offset: 0x0003759C
	[Token(Token = "0x6000A52")]
	[Address(RVA = "0x2947B00", Offset = "0x2947B00", VA = "0x2947B00")]
	private void \u0870\u05B3Ց\u066A()
	{
	}

	// Token: 0x06000A53 RID: 2643 RVA: 0x000393AC File Offset: 0x000375AC
	[Token(Token = "0x6000A53")]
	[Address(RVA = "0x2947B04", Offset = "0x2947B04", VA = "0x2947B04")]
	private void ۿࢹ\u0705\u0825()
	{
	}

	// Token: 0x06000A54 RID: 2644 RVA: 0x000393BC File Offset: 0x000375BC
	[Token(Token = "0x6000A54")]
	[Address(RVA = "0x2947B08", Offset = "0x2947B08", VA = "0x2947B08")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
	}

	// Token: 0x06000A55 RID: 2645 RVA: 0x000393CC File Offset: 0x000375CC
	[Token(Token = "0x6000A55")]
	[Address(RVA = "0x2947B0C", Offset = "0x2947B0C", VA = "0x2947B0C")]
	private void ࡎ\u05C2սࠇ()
	{
	}

	// Token: 0x06000A56 RID: 2646 RVA: 0x000393DC File Offset: 0x000375DC
	[Token(Token = "0x6000A56")]
	[Address(RVA = "0x2947B10", Offset = "0x2947B10", VA = "0x2947B10")]
	private void ݸԲ\u0616Ԫ()
	{
	}

	// Token: 0x06000A57 RID: 2647 RVA: 0x000393EC File Offset: 0x000375EC
	[Token(Token = "0x6000A57")]
	[Address(RVA = "0x2947B14", Offset = "0x2947B14", VA = "0x2947B14")]
	private void \u0832ࢳޤ\u07B5()
	{
	}

	// Token: 0x06000A58 RID: 2648 RVA: 0x000393FC File Offset: 0x000375FC
	[Token(Token = "0x6000A58")]
	[Address(RVA = "0x2947B18", Offset = "0x2947B18", VA = "0x2947B18")]
	private void ࢥ\u081CՕࡋ()
	{
	}

	// Token: 0x06000A59 RID: 2649 RVA: 0x0003940C File Offset: 0x0003760C
	[Token(Token = "0x6000A59")]
	[Address(RVA = "0x2947B1C", Offset = "0x2947B1C", VA = "0x2947B1C")]
	private void Ӣ\u0592ߨׯ()
	{
	}

	// Token: 0x06000A5A RID: 2650 RVA: 0x0003941C File Offset: 0x0003761C
	[Token(Token = "0x6000A5A")]
	[Address(RVA = "0x2947B20", Offset = "0x2947B20", VA = "0x2947B20")]
	private void \u0652\u058Bک\u061C()
	{
	}

	// Token: 0x06000A5B RID: 2651 RVA: 0x0003942C File Offset: 0x0003762C
	[Token(Token = "0x6000A5B")]
	[Address(RVA = "0x2947B24", Offset = "0x2947B24", VA = "0x2947B24")]
	private void \u0590\u0882\u0883ࡦ()
	{
	}

	// Token: 0x06000A5C RID: 2652 RVA: 0x0003943C File Offset: 0x0003763C
	[Token(Token = "0x6000A5C")]
	[Address(RVA = "0x2947B28", Offset = "0x2947B28", VA = "0x2947B28")]
	private void \u055E\u0703\u0700ܠ()
	{
	}

	// Token: 0x06000A5D RID: 2653 RVA: 0x0003944C File Offset: 0x0003764C
	[Token(Token = "0x6000A5D")]
	[Address(RVA = "0x2947B2C", Offset = "0x2947B2C", VA = "0x2947B2C")]
	private void ժ\u065Dԯࡘ()
	{
	}

	// Token: 0x06000A5E RID: 2654 RVA: 0x0003945C File Offset: 0x0003765C
	[Token(Token = "0x6000A5E")]
	[Address(RVA = "0x2947B30", Offset = "0x2947B30", VA = "0x2947B30")]
	private void Start()
	{
	}

	// Token: 0x06000A5F RID: 2655 RVA: 0x0003946C File Offset: 0x0003766C
	[Token(Token = "0x6000A5F")]
	[Address(RVA = "0x2947B34", Offset = "0x2947B34", VA = "0x2947B34")]
	private void \u082E\u06EBݼڏ()
	{
	}

	// Token: 0x06000A60 RID: 2656 RVA: 0x0003947C File Offset: 0x0003767C
	[Token(Token = "0x6000A60")]
	[Address(RVA = "0x2947B38", Offset = "0x2947B38", VA = "0x2947B38")]
	private void \u060B\u0614\u0821ע()
	{
	}

	// Token: 0x06000A61 RID: 2657 RVA: 0x0003948C File Offset: 0x0003768C
	[Token(Token = "0x6000A61")]
	[Address(RVA = "0x2947B3C", Offset = "0x2947B3C", VA = "0x2947B3C")]
	private void \u0599ږࠆ\u065F()
	{
	}

	// Token: 0x06000A62 RID: 2658 RVA: 0x0003949C File Offset: 0x0003769C
	[Token(Token = "0x6000A62")]
	[Address(RVA = "0x2947B40", Offset = "0x2947B40", VA = "0x2947B40")]
	private void Ԯ\u0883\u0591\u066C()
	{
	}

	// Token: 0x06000A63 RID: 2659 RVA: 0x000394AC File Offset: 0x000376AC
	[Token(Token = "0x6000A63")]
	[Address(RVA = "0x2947B44", Offset = "0x2947B44", VA = "0x2947B44")]
	private void וࡪךӧ()
	{
	}

	// Token: 0x06000A64 RID: 2660 RVA: 0x000394BC File Offset: 0x000376BC
	[Token(Token = "0x6000A64")]
	[Address(RVA = "0x2947B48", Offset = "0x2947B48", VA = "0x2947B48")]
	private void ߊ\u066A\u05CFԉ()
	{
	}

	// Token: 0x06000A65 RID: 2661 RVA: 0x000394CC File Offset: 0x000376CC
	[Token(Token = "0x6000A65")]
	[Address(RVA = "0x2947B4C", Offset = "0x2947B4C", VA = "0x2947B4C")]
	private void \u0705\u0816\u0739դ()
	{
	}

	// Token: 0x06000A66 RID: 2662 RVA: 0x000394DC File Offset: 0x000376DC
	[Token(Token = "0x6000A66")]
	[Address(RVA = "0x2947B50", Offset = "0x2947B50", VA = "0x2947B50")]
	private void \u061B\u05EEوۈ()
	{
	}

	// Token: 0x06000A67 RID: 2663 RVA: 0x000394EC File Offset: 0x000376EC
	[Token(Token = "0x6000A67")]
	[Address(RVA = "0x2947B54", Offset = "0x2947B54", VA = "0x2947B54")]
	private void \u05C1ܡԘޘ()
	{
	}

	// Token: 0x06000A68 RID: 2664 RVA: 0x000394FC File Offset: 0x000376FC
	[Token(Token = "0x6000A68")]
	[Address(RVA = "0x2947B58", Offset = "0x2947B58", VA = "0x2947B58")]
	private void ڦکӁ\u06E2()
	{
	}

	// Token: 0x06000A69 RID: 2665 RVA: 0x0003950C File Offset: 0x0003770C
	[Token(Token = "0x6000A69")]
	[Address(RVA = "0x2947B5C", Offset = "0x2947B5C", VA = "0x2947B5C")]
	private void ۊո\u0612\u0595()
	{
	}

	// Token: 0x06000A6A RID: 2666 RVA: 0x0003951C File Offset: 0x0003771C
	[Token(Token = "0x6000A6A")]
	[Address(RVA = "0x2947B60", Offset = "0x2947B60", VA = "0x2947B60")]
	private void ۮߝڪڐ()
	{
	}

	// Token: 0x06000A6B RID: 2667 RVA: 0x0003952C File Offset: 0x0003772C
	[Token(Token = "0x6000A6B")]
	[Address(RVA = "0x2947B64", Offset = "0x2947B64", VA = "0x2947B64")]
	private void \u05C8\u05BFࠁف()
	{
	}

	// Token: 0x06000A6C RID: 2668 RVA: 0x0003953C File Offset: 0x0003773C
	[Token(Token = "0x6000A6C")]
	[Address(RVA = "0x2947B68", Offset = "0x2947B68", VA = "0x2947B68")]
	private void \u0881ݗӟ\u07BD()
	{
	}

	// Token: 0x06000A6D RID: 2669 RVA: 0x0003954C File Offset: 0x0003774C
	[Token(Token = "0x6000A6D")]
	[Address(RVA = "0x2947B6C", Offset = "0x2947B6C", VA = "0x2947B6C")]
	private void Ԉ۴ࡉࢬ()
	{
	}

	// Token: 0x06000A6E RID: 2670 RVA: 0x0003955C File Offset: 0x0003775C
	[Token(Token = "0x6000A6E")]
	[Address(RVA = "0x2947B70", Offset = "0x2947B70", VA = "0x2947B70")]
	private void ԣԭՋࠏ()
	{
	}

	// Token: 0x06000A6F RID: 2671 RVA: 0x0003956C File Offset: 0x0003776C
	[Token(Token = "0x6000A6F")]
	[Address(RVA = "0x2947B74", Offset = "0x2947B74", VA = "0x2947B74")]
	private void Ԁוև\u065B()
	{
	}

	// Token: 0x06000A70 RID: 2672 RVA: 0x0003957C File Offset: 0x0003777C
	[Token(Token = "0x6000A70")]
	[Address(RVA = "0x2947B78", Offset = "0x2947B78", VA = "0x2947B78")]
	private void \u0872މࢮՃ()
	{
	}

	// Token: 0x06000A71 RID: 2673 RVA: 0x0003958C File Offset: 0x0003778C
	[Token(Token = "0x6000A71")]
	[Address(RVA = "0x2947B7C", Offset = "0x2947B7C", VA = "0x2947B7C")]
	private void Ԡݘעࠀ()
	{
	}

	// Token: 0x06000A72 RID: 2674 RVA: 0x0003959C File Offset: 0x0003779C
	[Token(Token = "0x6000A72")]
	[Address(RVA = "0x2947B80", Offset = "0x2947B80", VA = "0x2947B80")]
	private void ࠏޤݳ\u06DD()
	{
	}

	// Token: 0x06000A73 RID: 2675 RVA: 0x000395AC File Offset: 0x000377AC
	[Token(Token = "0x6000A73")]
	[Address(RVA = "0x2947B84", Offset = "0x2947B84", VA = "0x2947B84")]
	private void ࡩݮڢՠ()
	{
	}

	// Token: 0x06000A74 RID: 2676 RVA: 0x000395BC File Offset: 0x000377BC
	[Token(Token = "0x6000A74")]
	[Address(RVA = "0x2947B88", Offset = "0x2947B88", VA = "0x2947B88")]
	private void \u070Aәޣے()
	{
	}

	// Token: 0x06000A75 RID: 2677 RVA: 0x000395CC File Offset: 0x000377CC
	[Token(Token = "0x6000A75")]
	[Address(RVA = "0x2947B8C", Offset = "0x2947B8C", VA = "0x2947B8C")]
	private void \u073Fߗބݝ()
	{
	}

	// Token: 0x06000A76 RID: 2678 RVA: 0x000395DC File Offset: 0x000377DC
	[Token(Token = "0x6000A76")]
	[Address(RVA = "0x2947B90", Offset = "0x2947B90", VA = "0x2947B90")]
	private void ԞԌ\u086FՇ()
	{
	}

	// Token: 0x06000A77 RID: 2679 RVA: 0x000395EC File Offset: 0x000377EC
	[Token(Token = "0x6000A77")]
	[Address(RVA = "0x2947B94", Offset = "0x2947B94", VA = "0x2947B94")]
	private void \u05F8ݑ\u06ECߞ()
	{
	}

	// Token: 0x06000A78 RID: 2680 RVA: 0x000395FC File Offset: 0x000377FC
	[Token(Token = "0x6000A78")]
	[Address(RVA = "0x2947B98", Offset = "0x2947B98", VA = "0x2947B98")]
	private void حتݻ\u05B0()
	{
	}

	// Token: 0x06000A79 RID: 2681 RVA: 0x0003960C File Offset: 0x0003780C
	[Token(Token = "0x6000A79")]
	[Address(RVA = "0x2947B9C", Offset = "0x2947B9C", VA = "0x2947B9C")]
	private void \u05C4ݳ\u05BCࡂ()
	{
	}

	// Token: 0x06000A7A RID: 2682 RVA: 0x0003961C File Offset: 0x0003781C
	[Token(Token = "0x6000A7A")]
	[Address(RVA = "0x2947BA0", Offset = "0x2947BA0", VA = "0x2947BA0")]
	public Charger()
	{
	}

	// Token: 0x06000A7B RID: 2683 RVA: 0x00039630 File Offset: 0x00037830
	[Token(Token = "0x6000A7B")]
	[Address(RVA = "0x2947BA8", Offset = "0x2947BA8", VA = "0x2947BA8")]
	private void ݱ\u0832ݥ\u08B5()
	{
	}

	// Token: 0x06000A7C RID: 2684 RVA: 0x00039640 File Offset: 0x00037840
	[Token(Token = "0x6000A7C")]
	[Address(RVA = "0x2947BAC", Offset = "0x2947BAC", VA = "0x2947BAC")]
	private void ࡅݐ\u082Dք()
	{
	}

	// Token: 0x06000A7D RID: 2685 RVA: 0x00039650 File Offset: 0x00037850
	[Token(Token = "0x6000A7D")]
	[Address(RVA = "0x2947BB0", Offset = "0x2947BB0", VA = "0x2947BB0")]
	private void ݫࢷࠃ\u0820()
	{
	}

	// Token: 0x06000A7E RID: 2686 RVA: 0x00039660 File Offset: 0x00037860
	[Token(Token = "0x6000A7E")]
	[Address(RVA = "0x2947BB4", Offset = "0x2947BB4", VA = "0x2947BB4")]
	private void \u061Fࡆ\u086F\u07B0()
	{
	}

	// Token: 0x06000A7F RID: 2687 RVA: 0x00039670 File Offset: 0x00037870
	[Token(Token = "0x6000A7F")]
	[Address(RVA = "0x2947BB8", Offset = "0x2947BB8", VA = "0x2947BB8")]
	private void ژךՈ\u0597()
	{
	}

	// Token: 0x06000A80 RID: 2688 RVA: 0x00039680 File Offset: 0x00037880
	[Token(Token = "0x6000A80")]
	[Address(RVA = "0x2947BBC", Offset = "0x2947BBC", VA = "0x2947BBC")]
	private void \u05EDց\u081Cت()
	{
	}

	// Token: 0x06000A81 RID: 2689 RVA: 0x00039690 File Offset: 0x00037890
	[Token(Token = "0x6000A81")]
	[Address(RVA = "0x2947BC0", Offset = "0x2947BC0", VA = "0x2947BC0")]
	private void ٴݵۃ\u05AF()
	{
	}

	// Token: 0x06000A82 RID: 2690 RVA: 0x000396A0 File Offset: 0x000378A0
	[Token(Token = "0x6000A82")]
	[Address(RVA = "0x2947BC4", Offset = "0x2947BC4", VA = "0x2947BC4")]
	private void ןٮ\u061FԺ()
	{
	}

	// Token: 0x06000A83 RID: 2691 RVA: 0x000396B0 File Offset: 0x000378B0
	[Token(Token = "0x6000A83")]
	[Address(RVA = "0x2947BC8", Offset = "0x2947BC8", VA = "0x2947BC8")]
	private void ӛ\u082Eؿڕ()
	{
	}

	// Token: 0x06000A84 RID: 2692 RVA: 0x000396C0 File Offset: 0x000378C0
	[Token(Token = "0x6000A84")]
	[Address(RVA = "0x2947BCC", Offset = "0x2947BCC", VA = "0x2947BCC")]
	private void څࡣڐ\u0657()
	{
	}

	// Token: 0x06000A85 RID: 2693 RVA: 0x000396D0 File Offset: 0x000378D0
	[Token(Token = "0x6000A85")]
	[Address(RVA = "0x2947BD0", Offset = "0x2947BD0", VA = "0x2947BD0")]
	private void \u06D6ې\u083Bࠉ()
	{
	}

	// Token: 0x06000A86 RID: 2694 RVA: 0x000396E0 File Offset: 0x000378E0
	[Token(Token = "0x6000A86")]
	[Address(RVA = "0x2947BD4", Offset = "0x2947BD4", VA = "0x2947BD4")]
	private void \u05F7ԝߠӱ()
	{
	}

	// Token: 0x06000A87 RID: 2695 RVA: 0x000396F0 File Offset: 0x000378F0
	[Token(Token = "0x6000A87")]
	[Address(RVA = "0x2947BD8", Offset = "0x2947BD8", VA = "0x2947BD8")]
	private void Update()
	{
	}

	// Token: 0x06000A88 RID: 2696 RVA: 0x00039700 File Offset: 0x00037900
	[Token(Token = "0x6000A88")]
	[Address(RVA = "0x2947BDC", Offset = "0x2947BDC", VA = "0x2947BDC")]
	private void ؤ\u05C8ԛ\u083F()
	{
	}

	// Token: 0x06000A89 RID: 2697 RVA: 0x00039710 File Offset: 0x00037910
	[Token(Token = "0x6000A89")]
	[Address(RVA = "0x2947BE0", Offset = "0x2947BE0", VA = "0x2947BE0")]
	private void \u066A\u059Eټ\u085A()
	{
	}

	// Token: 0x06000A8A RID: 2698 RVA: 0x00039720 File Offset: 0x00037920
	[Token(Token = "0x6000A8A")]
	[Address(RVA = "0x2947BE4", Offset = "0x2947BE4", VA = "0x2947BE4")]
	private void \u081FڰՂإ()
	{
	}

	// Token: 0x06000A8B RID: 2699 RVA: 0x00039730 File Offset: 0x00037930
	[Token(Token = "0x6000A8B")]
	[Address(RVA = "0x2947BE8", Offset = "0x2947BE8", VA = "0x2947BE8")]
	private void ߓ\u06E3\u05C7ۋ()
	{
	}

	// Token: 0x06000A8C RID: 2700 RVA: 0x00039740 File Offset: 0x00037940
	[Token(Token = "0x6000A8C")]
	[Address(RVA = "0x2947BEC", Offset = "0x2947BEC", VA = "0x2947BEC")]
	private void Ӌ\u089C\u0700ܧ()
	{
	}

	// Token: 0x06000A8D RID: 2701 RVA: 0x00039750 File Offset: 0x00037950
	[Token(Token = "0x6000A8D")]
	[Address(RVA = "0x2947BF0", Offset = "0x2947BF0", VA = "0x2947BF0")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
	}

	// Token: 0x06000A8E RID: 2702 RVA: 0x00039760 File Offset: 0x00037960
	[Token(Token = "0x6000A8E")]
	[Address(RVA = "0x2947BF4", Offset = "0x2947BF4", VA = "0x2947BF4")]
	private void \u0656ӺմՁ()
	{
	}

	// Token: 0x06000A8F RID: 2703 RVA: 0x00039770 File Offset: 0x00037970
	[Token(Token = "0x6000A8F")]
	[Address(RVA = "0x2947BF8", Offset = "0x2947BF8", VA = "0x2947BF8")]
	private void ӭࡖݲ\u05BD()
	{
	}

	// Token: 0x06000A90 RID: 2704 RVA: 0x00039780 File Offset: 0x00037980
	[Token(Token = "0x6000A90")]
	[Address(RVA = "0x2947BFC", Offset = "0x2947BFC", VA = "0x2947BFC")]
	private void \u073Bݲձݕ()
	{
	}

	// Token: 0x06000A91 RID: 2705 RVA: 0x00039790 File Offset: 0x00037990
	[Token(Token = "0x6000A91")]
	[Address(RVA = "0x2947C00", Offset = "0x2947C00", VA = "0x2947C00")]
	private void \u065F\u0839ܤ\u073C()
	{
	}

	// Token: 0x06000A92 RID: 2706 RVA: 0x000397A0 File Offset: 0x000379A0
	[Token(Token = "0x6000A92")]
	[Address(RVA = "0x2947C04", Offset = "0x2947C04", VA = "0x2947C04")]
	private void \u07FB\u07BC\u0887ӟ()
	{
	}

	// Token: 0x06000A93 RID: 2707 RVA: 0x000397B0 File Offset: 0x000379B0
	[Token(Token = "0x6000A93")]
	[Address(RVA = "0x2947C08", Offset = "0x2947C08", VA = "0x2947C08")]
	private void ڑߒجވ()
	{
	}

	// Token: 0x06000A94 RID: 2708 RVA: 0x000397C0 File Offset: 0x000379C0
	[Token(Token = "0x6000A94")]
	[Address(RVA = "0x2947C0C", Offset = "0x2947C0C", VA = "0x2947C0C")]
	private void ޡࠅ\u089Aߔ()
	{
	}

	// Token: 0x06000A95 RID: 2709 RVA: 0x000397D0 File Offset: 0x000379D0
	[Token(Token = "0x6000A95")]
	[Address(RVA = "0x2947C10", Offset = "0x2947C10", VA = "0x2947C10")]
	private void \u073BօӁ\u059A()
	{
	}

	// Token: 0x06000A96 RID: 2710 RVA: 0x000397E0 File Offset: 0x000379E0
	[Token(Token = "0x6000A96")]
	[Address(RVA = "0x2947C14", Offset = "0x2947C14", VA = "0x2947C14")]
	private void \u087BӦןݩ()
	{
	}

	// Token: 0x06000A97 RID: 2711 RVA: 0x000397F0 File Offset: 0x000379F0
	[Token(Token = "0x6000A97")]
	[Address(RVA = "0x2947C18", Offset = "0x2947C18", VA = "0x2947C18")]
	private void יԠ\u07EDԺ()
	{
	}

	// Token: 0x06000A98 RID: 2712 RVA: 0x00039800 File Offset: 0x00037A00
	[Token(Token = "0x6000A98")]
	[Address(RVA = "0x2947C1C", Offset = "0x2947C1C", VA = "0x2947C1C")]
	private void \u06EDٵ۶\u06DB()
	{
	}
}
