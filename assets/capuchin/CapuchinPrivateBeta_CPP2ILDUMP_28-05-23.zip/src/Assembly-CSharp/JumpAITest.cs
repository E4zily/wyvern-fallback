﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200006C RID: 108
[Token(Token = "0x200006C")]
public class JumpAITest : MonoBehaviour
{
	// Token: 0x06000FB0 RID: 4016 RVA: 0x00059B50 File Offset: 0x00057D50
	[Token(Token = "0x6000FB0")]
	[Address(RVA = "0x2759350", Offset = "0x2759350", VA = "0x2759350")]
	private void Կשܐӵ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FB1 RID: 4017 RVA: 0x00059BCC File Offset: 0x00057DCC
	[Token(Token = "0x6000FB1")]
	[Address(RVA = "0x2759514", Offset = "0x2759514", VA = "0x2759514")]
	private void ݲ\u06E6ҽࡩ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FB2 RID: 4018 RVA: 0x00059C48 File Offset: 0x00057E48
	[Token(Token = "0x6000FB2")]
	[Address(RVA = "0x27596D8", Offset = "0x27596D8", VA = "0x27596D8")]
	private void \u089Aۆ\u0887\u05C0()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FB3 RID: 4019 RVA: 0x00059CC4 File Offset: 0x00057EC4
	[Token(Token = "0x6000FB3")]
	[Address(RVA = "0x275989C", Offset = "0x275989C", VA = "0x275989C")]
	private void \u089Bځԯԝ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FB4 RID: 4020 RVA: 0x00059D40 File Offset: 0x00057F40
	[Token(Token = "0x6000FB4")]
	[Address(RVA = "0x2759A60", Offset = "0x2759A60", VA = "0x2759A60")]
	private void \u0892\u061B\u0606\u06D8()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FB5 RID: 4021 RVA: 0x00059DBC File Offset: 0x00057FBC
	[Token(Token = "0x6000FB5")]
	[Address(RVA = "0x2759C24", Offset = "0x2759C24", VA = "0x2759C24")]
	private void ߪձԛމ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FB6 RID: 4022 RVA: 0x00059E38 File Offset: 0x00058038
	[Token(Token = "0x6000FB6")]
	[Address(RVA = "0x2759DE8", Offset = "0x2759DE8", VA = "0x2759DE8")]
	private void \u05AAࢦ\u060AԞ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FB7 RID: 4023 RVA: 0x00059EB4 File Offset: 0x000580B4
	[Token(Token = "0x6000FB7")]
	[Address(RVA = "0x2759FAC", Offset = "0x2759FAC", VA = "0x2759FAC")]
	private void \u07BBۯ٤ࠍ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FB8 RID: 4024 RVA: 0x00059F28 File Offset: 0x00058128
	[Token(Token = "0x6000FB8")]
	[Address(RVA = "0x275A170", Offset = "0x275A170", VA = "0x275A170")]
	private void ןأ\u05C0ب()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FB9 RID: 4025 RVA: 0x00059FA4 File Offset: 0x000581A4
	[Token(Token = "0x6000FB9")]
	[Address(RVA = "0x275A334", Offset = "0x275A334", VA = "0x275A334")]
	private void ڏי\u06E6\u070A()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FBA RID: 4026 RVA: 0x0005A020 File Offset: 0x00058220
	[Token(Token = "0x6000FBA")]
	[Address(RVA = "0x275A4F8", Offset = "0x275A4F8", VA = "0x275A4F8")]
	private void \u07BFޥ٧\u073B()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FBB RID: 4027 RVA: 0x0005A09C File Offset: 0x0005829C
	[Token(Token = "0x6000FBB")]
	[Address(RVA = "0x275A6BC", Offset = "0x275A6BC", VA = "0x275A6BC")]
	private void ࠇ\u087DػՏ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FBC RID: 4028 RVA: 0x0005A118 File Offset: 0x00058318
	[Token(Token = "0x6000FBC")]
	[Address(RVA = "0x275A880", Offset = "0x275A880", VA = "0x275A880")]
	private void ڷԟ\u087D\u05B9()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FBD RID: 4029 RVA: 0x0005A194 File Offset: 0x00058394
	[Token(Token = "0x6000FBD")]
	[Address(RVA = "0x275AA44", Offset = "0x275AA44", VA = "0x275AA44")]
	private void Աࢦ\u05CAޡ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FBE RID: 4030 RVA: 0x0005A208 File Offset: 0x00058408
	[Token(Token = "0x6000FBE")]
	[Address(RVA = "0x275AC08", Offset = "0x275AC08", VA = "0x275AC08")]
	private void \u081E١Ӕࢦ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FBF RID: 4031 RVA: 0x0005A284 File Offset: 0x00058484
	[Token(Token = "0x6000FBF")]
	[Address(RVA = "0x275ADCC", Offset = "0x275ADCC", VA = "0x275ADCC")]
	private void \u0890ؤߪފ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FC0 RID: 4032 RVA: 0x0005A300 File Offset: 0x00058500
	[Token(Token = "0x6000FC0")]
	[Address(RVA = "0x275AF90", Offset = "0x275AF90", VA = "0x275AF90")]
	private void \u07A7\u06DFࠈޖ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FC1 RID: 4033 RVA: 0x0005A36C File Offset: 0x0005856C
	[Token(Token = "0x6000FC1")]
	[Address(RVA = "0x275B154", Offset = "0x275B154", VA = "0x275B154")]
	private void ޤ\u0610\u087A\u05AF()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FC2 RID: 4034 RVA: 0x0005A3E8 File Offset: 0x000585E8
	[Token(Token = "0x6000FC2")]
	[Address(RVA = "0x275B318", Offset = "0x275B318", VA = "0x275B318")]
	private void \u070EࢣԀ\u07A9()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FC3 RID: 4035 RVA: 0x0005A464 File Offset: 0x00058664
	[Token(Token = "0x6000FC3")]
	[Address(RVA = "0x275B4DC", Offset = "0x275B4DC", VA = "0x275B4DC")]
	private void FixedUpdate()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FC4 RID: 4036 RVA: 0x0005A4E0 File Offset: 0x000586E0
	[Token(Token = "0x6000FC4")]
	[Address(RVA = "0x275B6A0", Offset = "0x275B6A0", VA = "0x275B6A0")]
	private void ڸՔ\u0594ԭ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FC5 RID: 4037 RVA: 0x0005A55C File Offset: 0x0005875C
	[Token(Token = "0x6000FC5")]
	[Address(RVA = "0x275B864", Offset = "0x275B864", VA = "0x275B864")]
	private void \u0736\u06E0\u06E0څ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FC6 RID: 4038 RVA: 0x0005A5D8 File Offset: 0x000587D8
	[Token(Token = "0x6000FC6")]
	[Address(RVA = "0x275BA28", Offset = "0x275BA28", VA = "0x275BA28")]
	private void ա\u0731ࢺۊ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FC7 RID: 4039 RVA: 0x0005A650 File Offset: 0x00058850
	[Token(Token = "0x6000FC7")]
	[Address(RVA = "0x275BBEC", Offset = "0x275BBEC", VA = "0x275BBEC")]
	private void ڿ\u06E6\u088E\u06FD()
	{
		Vector3 forward = Vector3.forward;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FC8 RID: 4040 RVA: 0x0005A698 File Offset: 0x00058898
	[Token(Token = "0x6000FC8")]
	[Address(RVA = "0x275BDB0", Offset = "0x275BDB0", VA = "0x275BDB0")]
	private void ࡇ\u0559یՒ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FC9 RID: 4041 RVA: 0x0005A714 File Offset: 0x00058914
	[Token(Token = "0x6000FC9")]
	[Address(RVA = "0x275BF74", Offset = "0x275BF74", VA = "0x275BF74")]
	private void \u064Cޔաӕ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FCA RID: 4042 RVA: 0x0005A790 File Offset: 0x00058990
	[Token(Token = "0x6000FCA")]
	[Address(RVA = "0x275C138", Offset = "0x275C138", VA = "0x275C138")]
	private void կսҾ\u06E4()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FCB RID: 4043 RVA: 0x0005A80C File Offset: 0x00058A0C
	[Token(Token = "0x6000FCB")]
	[Address(RVA = "0x275C2FC", Offset = "0x275C2FC", VA = "0x275C2FC")]
	private void ޛ\u0822\u05AFݎ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FCC RID: 4044 RVA: 0x0005A888 File Offset: 0x00058A88
	[Token(Token = "0x6000FCC")]
	[Address(RVA = "0x275C4C0", Offset = "0x275C4C0", VA = "0x275C4C0")]
	private void ڇӪࢰࡔ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FCD RID: 4045 RVA: 0x0005A8FC File Offset: 0x00058AFC
	[Token(Token = "0x6000FCD")]
	[Address(RVA = "0x275C684", Offset = "0x275C684", VA = "0x275C684")]
	private void \u0886ܬԗ\u05C0()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FCE RID: 4046 RVA: 0x0005A978 File Offset: 0x00058B78
	[Token(Token = "0x6000FCE")]
	[Address(RVA = "0x275C848", Offset = "0x275C848", VA = "0x275C848")]
	private void Ա\u07B9ߒݗ()
	{
		Vector3 forward = Vector3.forward;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FCF RID: 4047 RVA: 0x0005A9B8 File Offset: 0x00058BB8
	[Token(Token = "0x6000FCF")]
	[Address(RVA = "0x275CA0C", Offset = "0x275CA0C", VA = "0x275CA0C")]
	private void Ԃڏݏ\u086D()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FD0 RID: 4048 RVA: 0x0005AA34 File Offset: 0x00058C34
	[Token(Token = "0x6000FD0")]
	[Address(RVA = "0x275CBD0", Offset = "0x275CBD0", VA = "0x275CBD0")]
	private void ޗٻ\u0825ڔ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FD1 RID: 4049 RVA: 0x0005AAB0 File Offset: 0x00058CB0
	[Token(Token = "0x6000FD1")]
	[Address(RVA = "0x275CD94", Offset = "0x275CD94", VA = "0x275CD94")]
	private void \u0883ދ\u066C\u0859()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FD2 RID: 4050 RVA: 0x0005AB24 File Offset: 0x00058D24
	[Token(Token = "0x6000FD2")]
	[Address(RVA = "0x275CF58", Offset = "0x275CF58", VA = "0x275CF58")]
	private void ם\u06FDւԋ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FD3 RID: 4051 RVA: 0x0005ABA0 File Offset: 0x00058DA0
	[Token(Token = "0x6000FD3")]
	[Address(RVA = "0x275D11C", Offset = "0x275D11C", VA = "0x275D11C")]
	private void ԣ\u0731\u0879ܕ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FD4 RID: 4052 RVA: 0x0005AC1C File Offset: 0x00058E1C
	[Token(Token = "0x6000FD4")]
	[Address(RVA = "0x275D2E0", Offset = "0x275D2E0", VA = "0x275D2E0")]
	private void \u055F\u073C\u05F9Ԟ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FD5 RID: 4053 RVA: 0x0005AC98 File Offset: 0x00058E98
	[Token(Token = "0x6000FD5")]
	[Address(RVA = "0x275D4A4", Offset = "0x275D4A4", VA = "0x275D4A4")]
	private void ۍ\u05CAۋݿ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FD6 RID: 4054 RVA: 0x0005AD14 File Offset: 0x00058F14
	[Token(Token = "0x6000FD6")]
	[Address(RVA = "0x275D668", Offset = "0x275D668", VA = "0x275D668")]
	private void \u0887ࡒ\u0613\u07B8()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FD7 RID: 4055 RVA: 0x0005AD90 File Offset: 0x00058F90
	[Token(Token = "0x6000FD7")]
	[Address(RVA = "0x275D82C", Offset = "0x275D82C", VA = "0x275D82C")]
	private void \u05BBږ\u060Cࡑ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FD8 RID: 4056 RVA: 0x0005AE0C File Offset: 0x0005900C
	[Token(Token = "0x6000FD8")]
	[Address(RVA = "0x275D9F0", Offset = "0x275D9F0", VA = "0x275D9F0")]
	private void Ԧ\u0876ծՎ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FD9 RID: 4057 RVA: 0x0005AE88 File Offset: 0x00059088
	[Token(Token = "0x6000FD9")]
	[Address(RVA = "0x275DBB4", Offset = "0x275DBB4", VA = "0x275DBB4")]
	public JumpAITest()
	{
	}

	// Token: 0x06000FDA RID: 4058 RVA: 0x0005AE9C File Offset: 0x0005909C
	[Token(Token = "0x6000FDA")]
	[Address(RVA = "0x275DBBC", Offset = "0x275DBBC", VA = "0x275DBBC")]
	private void \u07AAح\u087Fܩ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06000FDB RID: 4059 RVA: 0x0005AF18 File Offset: 0x00059118
	[Token(Token = "0x6000FDB")]
	[Address(RVA = "0x275DD80", Offset = "0x275DD80", VA = "0x275DD80")]
	private void \u089Fکߦݭ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x04000226 RID: 550
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000226")]
	public Transform \u06ED\u0886ޣײ;

	// Token: 0x04000227 RID: 551
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000227")]
	public float ࡣڅڞӪ;
}
