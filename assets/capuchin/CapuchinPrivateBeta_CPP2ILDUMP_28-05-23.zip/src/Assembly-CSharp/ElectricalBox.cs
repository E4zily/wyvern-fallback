﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200005C RID: 92
[Token(Token = "0x200005C")]
public class ElectricalBox : MonoBehaviour
{
	// Token: 0x06000D54 RID: 3412 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000D54")]
	[Address(RVA = "0x28D975C", Offset = "0x28D975C", VA = "0x28D975C")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000D55 RID: 3413 RVA: 0x000496F8 File Offset: 0x000478F8
	[Token(Token = "0x6000D55")]
	[Address(RVA = "0x28D9810", Offset = "0x28D9810", VA = "0x28D9810")]
	public void Փ\u06DF\u0839ԟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D56 RID: 3414 RVA: 0x00049720 File Offset: 0x00047920
	[Token(Token = "0x6000D56")]
	[Address(RVA = "0x28D98C4", Offset = "0x28D98C4", VA = "0x28D98C4")]
	public void ࢦ\u073Aӟࡆ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D57 RID: 3415 RVA: 0x00049748 File Offset: 0x00047948
	[Token(Token = "0x6000D57")]
	[Address(RVA = "0x28D9978", Offset = "0x28D9978", VA = "0x28D9978")]
	private void \u0590\u0882\u0883ࡦ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u06DFӣ\u0833\u05BB();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000D58 RID: 3416 RVA: 0x0004976C File Offset: 0x0004796C
	[Token(Token = "0x6000D58")]
	[Address(RVA = "0x28D9AEC", Offset = "0x28D9AEC", VA = "0x28D9AEC")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000D59 RID: 3417 RVA: 0x0004979C File Offset: 0x0004799C
	[Token(Token = "0x6000D59")]
	[Address(RVA = "0x28D9BA4", Offset = "0x28D9BA4", VA = "0x28D9BA4")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D5A RID: 3418 RVA: 0x000497C4 File Offset: 0x000479C4
	[Token(Token = "0x6000D5A")]
	[Address(RVA = "0x28D9C58", Offset = "0x28D9C58", VA = "0x28D9C58")]
	public void \u05F8ڳ\u0600\u081F()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("DisableCosmetic");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("/");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D5B RID: 3419 RVA: 0x00049828 File Offset: 0x00047A28
	[Token(Token = "0x6000D5B")]
	[Address(RVA = "0x28D9D9C", Offset = "0x28D9D9C", VA = "0x28D9D9C")]
	public void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000D5C RID: 3420 RVA: 0x00049858 File Offset: 0x00047A58
	[Token(Token = "0x6000D5C")]
	[Address(RVA = "0x28D9E54", Offset = "0x28D9E54", VA = "0x28D9E54")]
	public void \u0819Փٲࡪ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000D5D RID: 3421 RVA: 0x00049888 File Offset: 0x00047A88
	[Token(Token = "0x6000D5D")]
	[Address(RVA = "0x28D9F0C", Offset = "0x28D9F0C", VA = "0x28D9F0C")]
	public void ӭՍݑՇ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("We don't need this electrical box");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("KeyPos");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D5E RID: 3422 RVA: 0x000498EC File Offset: 0x00047AEC
	[Token(Token = "0x6000D5E")]
	[Address(RVA = "0x28DA050", Offset = "0x28DA050", VA = "0x28DA050")]
	public void \u06D8ܡ\u0818ࡐ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Mesh");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("Joined a Room.");
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D5F RID: 3423 RVA: 0x00049948 File Offset: 0x00047B48
	[Token(Token = "0x6000D5F")]
	[Address(RVA = "0x28DA194", Offset = "0x28DA194", VA = "0x28DA194")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000D60 RID: 3424 RVA: 0x00049978 File Offset: 0x00047B78
	[Token(Token = "0x6000D60")]
	[Address(RVA = "0x28DA24C", Offset = "0x28DA24C", VA = "0x28DA24C")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D61 RID: 3425 RVA: 0x000499A0 File Offset: 0x00047BA0
	[Token(Token = "0x6000D61")]
	[Address(RVA = "0x28DA300", Offset = "0x28DA300", VA = "0x28DA300")]
	public void \u0833ٮڒՄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D62 RID: 3426 RVA: 0x000499C8 File Offset: 0x00047BC8
	[Token(Token = "0x6000D62")]
	[Address(RVA = "0x28DA3B4", Offset = "0x28DA3B4", VA = "0x28DA3B4")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.ԇأ\u06E2Մ();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000D63 RID: 3427 RVA: 0x000499EC File Offset: 0x00047BEC
	[Token(Token = "0x6000D63")]
	[Address(RVA = "0x28DA528", Offset = "0x28DA528", VA = "0x28DA528")]
	private void \u081FڰՂإ()
	{
		this.ӎږԍՓ();
	}

	// Token: 0x06000D64 RID: 3428 RVA: 0x00049A00 File Offset: 0x00047C00
	[Token(Token = "0x6000D64")]
	[Address(RVA = "0x28DA670", Offset = "0x28DA670", VA = "0x28DA670")]
	public void ࢲ\u061C\u0817ݽ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000D65 RID: 3429 RVA: 0x00049A30 File Offset: 0x00047C30
	[Token(Token = "0x6000D65")]
	[Address(RVA = "0x28DA728", Offset = "0x28DA728", VA = "0x28DA728")]
	private void Գӿېչ()
	{
		this.\u06E3ݷҼ\u074A();
	}

	// Token: 0x06000D66 RID: 3430 RVA: 0x00049A44 File Offset: 0x00047C44
	[Token(Token = "0x6000D66")]
	[Address(RVA = "0x28DA870", Offset = "0x28DA870", VA = "0x28DA870")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u055Fԁࢧ\u07AF();
		}
	}

	// Token: 0x06000D67 RID: 3431 RVA: 0x00049A60 File Offset: 0x00047C60
	[Token(Token = "0x6000D67")]
	[Address(RVA = "0x28DA9E0", Offset = "0x28DA9E0", VA = "0x28DA9E0")]
	public void ࢢ٧\u085DԀ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D68 RID: 3432 RVA: 0x00049A88 File Offset: 0x00047C88
	[Token(Token = "0x6000D68")]
	[Address(RVA = "0x28DAA94", Offset = "0x28DAA94", VA = "0x28DAA94")]
	private void ݡز٨հ()
	{
		this.Ԋࡃ\u0877ݵ();
	}

	// Token: 0x06000D69 RID: 3433 RVA: 0x00049A9C File Offset: 0x00047C9C
	[Token(Token = "0x6000D69")]
	[Address(RVA = "0x28DABDC", Offset = "0x28DABDC", VA = "0x28DABDC")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000D6A RID: 3434 RVA: 0x00049ACC File Offset: 0x00047CCC
	[Token(Token = "0x6000D6A")]
	[Address(RVA = "0x28DAC94", Offset = "0x28DAC94", VA = "0x28DAC94")]
	private void \u0836\u089Dی\u0735()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.آࢬٹ\u0872();
		}
	}

	// Token: 0x06000D6B RID: 3435 RVA: 0x00049AE8 File Offset: 0x00047CE8
	[Token(Token = "0x6000D6B")]
	[Address(RVA = "0x28DA72C", Offset = "0x28DA72C", VA = "0x28DA72C")]
	public void \u06E3ݷҼ\u074A()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("FingerTip");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("tp 2");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D6C RID: 3436 RVA: 0x00049B4C File Offset: 0x00047D4C
	[Token(Token = "0x6000D6C")]
	[Address(RVA = "0x28DAE04", Offset = "0x28DAE04", VA = "0x28DAE04")]
	private void \u0827ߜ\u07FD\u07F4()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.ӭՍݑՇ();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000D6D RID: 3437 RVA: 0x00049B70 File Offset: 0x00047D70
	[Token(Token = "0x6000D6D")]
	[Address(RVA = "0x28DAE34", Offset = "0x28DAE34", VA = "0x28DAE34")]
	public void ގ\u05A9\u05B0Վ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("Meta Platform entitlement error: ");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D6E RID: 3438 RVA: 0x00049BD4 File Offset: 0x00047DD4
	[Token(Token = "0x6000D6E")]
	[Address(RVA = "0x28DAF78", Offset = "0x28DAF78", VA = "0x28DAF78")]
	public void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D6F RID: 3439 RVA: 0x00049BFC File Offset: 0x00047DFC
	[Token(Token = "0x6000D6F")]
	[Address(RVA = "0x28DB02C", Offset = "0x28DB02C", VA = "0x28DB02C")]
	private void ދ\u05A3\u06DCہ()
	{
		this.ӭՍݑՇ();
	}

	// Token: 0x06000D70 RID: 3440 RVA: 0x00049C10 File Offset: 0x00047E10
	[Token(Token = "0x6000D70")]
	[Address(RVA = "0x28DB030", Offset = "0x28DB030", VA = "0x28DB030")]
	private void \u0614ࢥӴ\u086C()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.آࢬٹ\u0872();
		}
	}

	// Token: 0x06000D71 RID: 3441 RVA: 0x00049C2C File Offset: 0x00047E2C
	[Token(Token = "0x6000D71")]
	[Address(RVA = "0x28DB05C", Offset = "0x28DB05C", VA = "0x28DB05C")]
	private void ࢭ\u0589\u0892\u058A()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.Ԋࡃ\u0877ݵ();
		}
	}

	// Token: 0x06000D72 RID: 3442 RVA: 0x00049C48 File Offset: 0x00047E48
	[Token(Token = "0x6000D72")]
	[Address(RVA = "0x28DB088", Offset = "0x28DB088", VA = "0x28DB088")]
	private void \u061B\u05EEوۈ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.ݢߙւ\u0601();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000D73 RID: 3443 RVA: 0x00049C6C File Offset: 0x00047E6C
	[Token(Token = "0x6000D73")]
	[Address(RVA = "0x28DB1F0", Offset = "0x28DB1F0", VA = "0x28DB1F0")]
	public void ޑࡗ\u0606ࠁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D74 RID: 3444 RVA: 0x00049C94 File Offset: 0x00047E94
	[Token(Token = "0x6000D74")]
	[Address(RVA = "0x28DB2A4", Offset = "0x28DB2A4", VA = "0x28DB2A4")]
	public void խ\u07A9ޕي()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D75 RID: 3445 RVA: 0x00049CEC File Offset: 0x00047EEC
	[Token(Token = "0x6000D75")]
	[Address(RVA = "0x28DAA98", Offset = "0x28DAA98", VA = "0x28DAA98")]
	public void Ԋࡃ\u0877ݵ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Failed To Join Public Room Successfully. The error is: ");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("BLUPORT");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D76 RID: 3446 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000D76")]
	[Address(RVA = "0x28DB3E8", Offset = "0x28DB3E8", VA = "0x28DB3E8")]
	public void ࡤ\u0658ډ\u05B4(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000D77 RID: 3447 RVA: 0x00049D50 File Offset: 0x00047F50
	[Token(Token = "0x6000D77")]
	[Address(RVA = "0x28DB49C", Offset = "0x28DB49C", VA = "0x28DB49C")]
	public void ߏ\u055AԘց()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Bare Torso");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("You Already Own This Item");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D78 RID: 3448 RVA: 0x00049DB4 File Offset: 0x00047FB4
	[Token(Token = "0x6000D78")]
	[Address(RVA = "0x28DB5E0", Offset = "0x28DB5E0", VA = "0x28DB5E0")]
	public void ئأԵߑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D79 RID: 3449 RVA: 0x00049DDC File Offset: 0x00047FDC
	[Token(Token = "0x6000D79")]
	[Address(RVA = "0x28DB694", Offset = "0x28DB694", VA = "0x28DB694")]
	public void Ӭ\u06EB\u0607ܐ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D7A RID: 3450 RVA: 0x00049E04 File Offset: 0x00048004
	[Token(Token = "0x6000D7A")]
	[Address(RVA = "0x28DB748", Offset = "0x28DB748", VA = "0x28DB748")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000D7B RID: 3451 RVA: 0x00049E34 File Offset: 0x00048034
	[Token(Token = "0x6000D7B")]
	[Address(RVA = "0x28DB800", Offset = "0x28DB800", VA = "0x28DB800")]
	private void յߪؾՀ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u06DFӣ\u0833\u05BB();
		}
	}

	// Token: 0x06000D7C RID: 3452 RVA: 0x00049E50 File Offset: 0x00048050
	[Token(Token = "0x6000D7C")]
	[Address(RVA = "0x28DB82C", Offset = "0x28DB82C", VA = "0x28DB82C")]
	public void ے\u059Fࢰس(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D7D RID: 3453 RVA: 0x00049E78 File Offset: 0x00048078
	[Token(Token = "0x6000D7D")]
	[Address(RVA = "0x28DB8E0", Offset = "0x28DB8E0", VA = "0x28DB8E0")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
		this.\u05F8ڳ\u0600\u081F();
	}

	// Token: 0x06000D7E RID: 3454 RVA: 0x00049E8C File Offset: 0x0004808C
	[Token(Token = "0x6000D7E")]
	[Address(RVA = "0x28DB8E4", Offset = "0x28DB8E4", VA = "0x28DB8E4")]
	public void Өכ\u0873ݩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D7F RID: 3455 RVA: 0x00049EB4 File Offset: 0x000480B4
	[Token(Token = "0x6000D7F")]
	[Address(RVA = "0x28DB998", Offset = "0x28DB998", VA = "0x28DB998")]
	private void \u05C1ܡԘޘ()
	{
		this.խ\u07A9ޕي();
	}

	// Token: 0x06000D80 RID: 3456 RVA: 0x00049EC8 File Offset: 0x000480C8
	[Token(Token = "0x6000D80")]
	[Address(RVA = "0x28DB99C", Offset = "0x28DB99C", VA = "0x28DB99C")]
	public void ࡗ\u07B9\u0887\u06D8()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("HandR");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("Start Gamemode");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D81 RID: 3457 RVA: 0x00049F2C File Offset: 0x0004812C
	[Token(Token = "0x6000D81")]
	[Address(RVA = "0x28DBAE0", Offset = "0x28DBAE0", VA = "0x28DBAE0")]
	public ElectricalBox()
	{
	}

	// Token: 0x06000D82 RID: 3458 RVA: 0x00049F40 File Offset: 0x00048140
	[Token(Token = "0x6000D82")]
	[Address(RVA = "0x28DBAE8", Offset = "0x28DBAE8", VA = "0x28DBAE8")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000D83 RID: 3459 RVA: 0x00049F70 File Offset: 0x00048170
	[Token(Token = "0x6000D83")]
	[Address(RVA = "0x28DBBA0", Offset = "0x28DBBA0", VA = "0x28DBBA0")]
	private void \u05C8\u05BFࠁف()
	{
		this.ךגޚ\u0607();
	}

	// Token: 0x06000D84 RID: 3460 RVA: 0x00049F84 File Offset: 0x00048184
	[Token(Token = "0x6000D84")]
	[Address(RVA = "0x28DBCE8", Offset = "0x28DBCE8", VA = "0x28DBCE8")]
	public void \u0589\u0740\u05C6ӧ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
	}

	// Token: 0x06000D85 RID: 3461 RVA: 0x00049FA4 File Offset: 0x000481A4
	[Token(Token = "0x6000D85")]
	[Address(RVA = "0x28DBDA0", Offset = "0x28DBDA0", VA = "0x28DBDA0")]
	private void Ҿࢹؼס()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u06D8ܡ\u0818ࡐ();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000D86 RID: 3462 RVA: 0x00049FC8 File Offset: 0x000481C8
	[Token(Token = "0x6000D86")]
	[Address(RVA = "0x28DBDD0", Offset = "0x28DBDD0", VA = "0x28DBDD0")]
	private void ԦӔԁֆ()
	{
		this.\u06D8ܡ\u0818ࡐ();
	}

	// Token: 0x06000D87 RID: 3463 RVA: 0x00049FDC File Offset: 0x000481DC
	[Token(Token = "0x6000D87")]
	[Address(RVA = "0x28DBDD4", Offset = "0x28DBDD4", VA = "0x28DBDD4")]
	public void ޠض\u058Dԥ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Meta Platform entitlement error: ");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("Vector1_d371bd24217449349bd747533d51af6b");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D88 RID: 3464 RVA: 0x0004A040 File Offset: 0x00048240
	[Token(Token = "0x6000D88")]
	[Address(RVA = "0x28DBF18", Offset = "0x28DBF18", VA = "0x28DBF18")]
	public void \u07BDױ\u0652\u05A7()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			Debug.Log("ChangeToTagged");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("username");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform;
		Vector3 position = transform.position;
	}

	// Token: 0x06000D89 RID: 3465 RVA: 0x0004A090 File Offset: 0x00048290
	[Token(Token = "0x6000D89")]
	[Address(RVA = "0x28DC05C", Offset = "0x28DC05C", VA = "0x28DC05C")]
	private void ӒԂࡩࡓ()
	{
		bool ٥_u08B5_u0616ࡠ = this.٥\u08B5\u0616ࡠ;
		if (٥_u08B5_u0616ࡠ)
		{
			this.\u06E3ݷҼ\u074A();
			this.٥\u08B5\u0616ࡠ = ٥_u08B5_u0616ࡠ;
		}
	}

	// Token: 0x06000D8A RID: 3466 RVA: 0x0004A0B4 File Offset: 0x000482B4
	[Token(Token = "0x6000D8A")]
	[Address(RVA = "0x28DC08C", Offset = "0x28DC08C", VA = "0x28DC08C")]
	private void ؤ\u05C8ԛ\u083F()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u07BDױ\u0652\u05A7();
		}
	}

	// Token: 0x06000D8B RID: 3467 RVA: 0x0004A0D0 File Offset: 0x000482D0
	[Token(Token = "0x6000D8B")]
	[Address(RVA = "0x28DC0B8", Offset = "0x28DC0B8", VA = "0x28DC0B8")]
	public void \u0640ܜࠉ\u083A()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("HandL");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("PlayNoise");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D8C RID: 3468 RVA: 0x0004A134 File Offset: 0x00048334
	[Token(Token = "0x6000D8C")]
	[Address(RVA = "0x28DC1FC", Offset = "0x28DC1FC", VA = "0x28DC1FC")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D8D RID: 3469 RVA: 0x0004A15C File Offset: 0x0004835C
	[Token(Token = "0x6000D8D")]
	[Address(RVA = "0x28DC2B0", Offset = "0x28DC2B0", VA = "0x28DC2B0")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.ԕܞ\u07EEߚ();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000D8E RID: 3470 RVA: 0x0004A180 File Offset: 0x00048380
	[Token(Token = "0x6000D8E")]
	[Address(RVA = "0x28DC424", Offset = "0x28DC424", VA = "0x28DC424")]
	public void Ԃ\u058Aܫջ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000D8F RID: 3471 RVA: 0x0004A1AC File Offset: 0x000483AC
	[Token(Token = "0x6000D8F")]
	[Address(RVA = "0x28DC4DC", Offset = "0x28DC4DC", VA = "0x28DC4DC")]
	public void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000D90 RID: 3472 RVA: 0x0004A1D0 File Offset: 0x000483D0
	[Token(Token = "0x6000D90")]
	[Address(RVA = "0x28DC590", Offset = "0x28DC590", VA = "0x28DC590")]
	private void ہݕ\u07EFԒ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.ࢡ\u05BEߗ\u07A8();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000D91 RID: 3473 RVA: 0x0004A1F4 File Offset: 0x000483F4
	[Token(Token = "0x6000D91")]
	[Address(RVA = "0x28DC704", Offset = "0x28DC704", VA = "0x28DC704")]
	public void \u07FBࠋ\u05B4ࡗ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("CapuchinStore");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("Player");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D92 RID: 3474 RVA: 0x0004A258 File Offset: 0x00048458
	[Token(Token = "0x6000D92")]
	[Address(RVA = "0x28DC848", Offset = "0x28DC848", VA = "0x28DC848")]
	private void ࢰחڵࡓ()
	{
		this.ݢߙւ\u0601();
	}

	// Token: 0x06000D93 RID: 3475 RVA: 0x0004A26C File Offset: 0x0004846C
	[Token(Token = "0x6000D93")]
	[Address(RVA = "0x28DC84C", Offset = "0x28DC84C", VA = "0x28DC84C")]
	private void \u082E\u06EBݼڏ()
	{
		this.\u0652\u0823\u0821ԓ();
	}

	// Token: 0x06000D94 RID: 3476 RVA: 0x0004A280 File Offset: 0x00048480
	[Token(Token = "0x6000D94")]
	[Address(RVA = "0x28DC994", Offset = "0x28DC994", VA = "0x28DC994")]
	private void Update()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.ӭՍݑՇ();
		}
	}

	// Token: 0x06000D95 RID: 3477 RVA: 0x0004A29C File Offset: 0x0004849C
	[Token(Token = "0x6000D95")]
	[Address(RVA = "0x28DC9C0", Offset = "0x28DC9C0", VA = "0x28DC9C0")]
	private void \u0892ܒܬޓ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u06E3ݷҼ\u074A();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000D96 RID: 3478 RVA: 0x0004A2C0 File Offset: 0x000484C0
	[Token(Token = "0x6000D96")]
	[Address(RVA = "0x28DC9F0", Offset = "0x28DC9F0", VA = "0x28DC9F0")]
	private void ߄Ӄ\u0613ھ()
	{
		this.ԕܞ\u07EEߚ();
	}

	// Token: 0x06000D97 RID: 3479 RVA: 0x0004A2D4 File Offset: 0x000484D4
	[Token(Token = "0x6000D97")]
	[Address(RVA = "0x28DC9F4", Offset = "0x28DC9F4", VA = "0x28DC9F4")]
	private void \u058EԸس\u0819()
	{
		this.ࢡ\u05BEߗ\u07A8();
	}

	// Token: 0x06000D98 RID: 3480 RVA: 0x0004A2E8 File Offset: 0x000484E8
	[Token(Token = "0x6000D98")]
	[Address(RVA = "0x28DB0B8", Offset = "0x28DB0B8", VA = "0x28DB0B8")]
	public void ݢߙւ\u0601()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("CapuchinRemade");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("CapuchinRemade");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D99 RID: 3481 RVA: 0x0004A34C File Offset: 0x0004854C
	[Token(Token = "0x6000D99")]
	[Address(RVA = "0x28DC9F8", Offset = "0x28DC9F8", VA = "0x28DC9F8")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000D9A RID: 3482 RVA: 0x0004A378 File Offset: 0x00048578
	[Token(Token = "0x6000D9A")]
	[Address(RVA = "0x28DCAB0", Offset = "0x28DCAB0", VA = "0x28DCAB0")]
	private void ԅ\u073Fڥ\u0839()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.ӎږԍՓ();
		}
	}

	// Token: 0x06000D9B RID: 3483 RVA: 0x0004A394 File Offset: 0x00048594
	[Token(Token = "0x6000D9B")]
	[Address(RVA = "0x28DCADC", Offset = "0x28DCADC", VA = "0x28DCADC")]
	private void ӭࡖݲ\u05BD()
	{
		this.\u0652\u0823\u0821ԓ();
	}

	// Token: 0x06000D9C RID: 3484 RVA: 0x0004A3A8 File Offset: 0x000485A8
	[Token(Token = "0x6000D9C")]
	[Address(RVA = "0x28DCAE0", Offset = "0x28DCAE0", VA = "0x28DCAE0")]
	private void Ԉ۴ࡉࢬ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u06D8ܡ\u0818ࡐ();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000D9D RID: 3485 RVA: 0x0004A3CC File Offset: 0x000485CC
	[Token(Token = "0x6000D9D")]
	[Address(RVA = "0x28DACC0", Offset = "0x28DACC0", VA = "0x28DACC0")]
	public void آࢬٹ\u0872()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("username");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag(".Please press the button if you would like to play alone");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D9E RID: 3486 RVA: 0x0004A430 File Offset: 0x00048630
	[Token(Token = "0x6000D9E")]
	[Address(RVA = "0x28DCB10", Offset = "0x28DCB10", VA = "0x28DCB10")]
	private void ޥ\u089Dڢ\u06E3()
	{
		this.ӎږԍՓ();
	}

	// Token: 0x06000D9F RID: 3487 RVA: 0x0004A444 File Offset: 0x00048644
	[Token(Token = "0x6000D9F")]
	[Address(RVA = "0x28DCB14", Offset = "0x28DCB14", VA = "0x28DCB14")]
	private void ܩחݵޔ()
	{
		this.\u07FBࠋ\u05B4ࡗ();
	}

	// Token: 0x06000DA0 RID: 3488 RVA: 0x0004A458 File Offset: 0x00048658
	[Token(Token = "0x6000DA0")]
	[Address(RVA = "0x28DCB18", Offset = "0x28DCB18", VA = "0x28DCB18")]
	public void \u07B2߆Ժࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000DA1 RID: 3489 RVA: 0x0004A488 File Offset: 0x00048688
	[Token(Token = "0x6000DA1")]
	[Address(RVA = "0x28DCBD0", Offset = "0x28DCBD0", VA = "0x28DCBD0")]
	private void \u087BӦןݩ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.ӎږԍՓ();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000DA2 RID: 3490 RVA: 0x0004A4AC File Offset: 0x000486AC
	[Token(Token = "0x6000DA2")]
	[Address(RVA = "0x28DCC00", Offset = "0x28DCC00", VA = "0x28DCC00")]
	public void Դסՠԕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000DA3 RID: 3491 RVA: 0x0004A4DC File Offset: 0x000486DC
	[Token(Token = "0x6000DA3")]
	[Address(RVA = "0x28DCCB8", Offset = "0x28DCCB8", VA = "0x28DCCB8")]
	private void ד\u073C\u0613چ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u0652\u0823\u0821ԓ();
		}
	}

	// Token: 0x06000DA4 RID: 3492 RVA: 0x0004A4F8 File Offset: 0x000486F8
	[Token(Token = "0x6000DA4")]
	[Address(RVA = "0x28DCCE4", Offset = "0x28DCCE4", VA = "0x28DCCE4")]
	public void ә\u0730\u0839\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000DA5 RID: 3493 RVA: 0x0004A520 File Offset: 0x00048720
	[Token(Token = "0x6000DA5")]
	[Address(RVA = "0x28DCD98", Offset = "0x28DCD98", VA = "0x28DCD98")]
	public void \u066B\u0733ܥ\u086B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000DA6 RID: 3494 RVA: 0x0004A550 File Offset: 0x00048750
	[Token(Token = "0x6000DA6")]
	[Address(RVA = "0x28DC5C0", Offset = "0x28DC5C0", VA = "0x28DC5C0")]
	public void ࢡ\u05BEߗ\u07A8()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("trol");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("manual footTimings length should be equal to the leg count");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000DA7 RID: 3495 RVA: 0x0004A5B4 File Offset: 0x000487B4
	[Token(Token = "0x6000DA7")]
	[Address(RVA = "0x28DCE50", Offset = "0x28DCE50", VA = "0x28DCE50")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000DA8 RID: 3496 RVA: 0x0004A5DC File Offset: 0x000487DC
	[Token(Token = "0x6000DA8")]
	[Address(RVA = "0x28DCF04", Offset = "0x28DCF04", VA = "0x28DCF04")]
	public void \u0825ݚ\u060E\u05C0()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("PLAYER IS BANNED");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("username");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000DA9 RID: 3497 RVA: 0x0004A640 File Offset: 0x00048840
	[Token(Token = "0x6000DA9")]
	[Address(RVA = "0x28DD048", Offset = "0x28DD048", VA = "0x28DD048")]
	public void \u05FD\u06E1\u064Cԕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000DAA RID: 3498 RVA: 0x0004A670 File Offset: 0x00048870
	[Token(Token = "0x6000DAA")]
	[Address(RVA = "0x28DD100", Offset = "0x28DD100", VA = "0x28DD100")]
	public void ܯר\u05C7ڗ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000DAB RID: 3499 RVA: 0x0004A6A0 File Offset: 0x000488A0
	[Token(Token = "0x6000DAB")]
	[Address(RVA = "0x28DD1B8", Offset = "0x28DD1B8", VA = "0x28DD1B8")]
	public void ݨܥ\u07A9ݻ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Completed baking textures on frame ");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("Left a room");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000DAC RID: 3500 RVA: 0x0004A704 File Offset: 0x00048904
	[Token(Token = "0x6000DAC")]
	[Address(RVA = "0x28DD2FC", Offset = "0x28DD2FC", VA = "0x28DD2FC")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000DAD RID: 3501 RVA: 0x0004A72C File Offset: 0x0004892C
	[Token(Token = "0x6000DAD")]
	[Address(RVA = "0x28DA52C", Offset = "0x28DA52C", VA = "0x28DA52C")]
	public void ӎږԍՓ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("ScoreCounter");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("META");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000DAE RID: 3502 RVA: 0x0004A790 File Offset: 0x00048990
	[Token(Token = "0x6000DAE")]
	[Address(RVA = "0x28DD3B0", Offset = "0x28DD3B0", VA = "0x28DD3B0")]
	private void ࢶ٠\u086D\u0708()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u055Fԁࢧ\u07AF();
		}
	}

	// Token: 0x06000DAF RID: 3503 RVA: 0x0004A7AC File Offset: 0x000489AC
	[Token(Token = "0x6000DAF")]
	[Address(RVA = "0x28DD3DC", Offset = "0x28DD3DC", VA = "0x28DD3DC")]
	public void ڲࡐ\u070Eخ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000DB0 RID: 3504 RVA: 0x0004A7D4 File Offset: 0x000489D4
	[Token(Token = "0x6000DB0")]
	[Address(RVA = "0x28DD490", Offset = "0x28DD490", VA = "0x28DD490")]
	public void \u0836Չװߟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000DB1 RID: 3505 RVA: 0x0004A7FC File Offset: 0x000489FC
	[Token(Token = "0x6000DB1")]
	[Address(RVA = "0x28DD544", Offset = "0x28DD544", VA = "0x28DD544")]
	public void \u0705خڃ\u059B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000DB2 RID: 3506 RVA: 0x0004A82C File Offset: 0x00048A2C
	[Token(Token = "0x6000DB2")]
	[Address(RVA = "0x28D99A8", Offset = "0x28D99A8", VA = "0x28D99A8")]
	public void \u06DFӣ\u0833\u05BB()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Display Name Changed!");
			return;
		}
		GameObject[] maxExclusive;
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000DB3 RID: 3507 RVA: 0x0004A884 File Offset: 0x00048A84
	[Token(Token = "0x6000DB3")]
	[Address(RVA = "0x28DD5FC", Offset = "0x28DD5FC", VA = "0x28DD5FC")]
	public void \u06E2ڇ\u07BF߃(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000DB4 RID: 3508 RVA: 0x0004A8B0 File Offset: 0x00048AB0
	[Token(Token = "0x6000DB4")]
	[Address(RVA = "0x28DD6B4", Offset = "0x28DD6B4", VA = "0x28DD6B4")]
	private void ޠۋ\u0530\u073E()
	{
		this.ࢡ\u05BEߗ\u07A8();
	}

	// Token: 0x06000DB5 RID: 3509 RVA: 0x0004A8C4 File Offset: 0x00048AC4
	[Token(Token = "0x6000DB5")]
	[Address(RVA = "0x28DD6B8", Offset = "0x28DD6B8", VA = "0x28DD6B8")]
	public void ػԚԃڻ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000DB6 RID: 3510 RVA: 0x0004A8F4 File Offset: 0x00048AF4
	[Token(Token = "0x6000DB6")]
	[Address(RVA = "0x28DD770", Offset = "0x28DD770", VA = "0x28DD770")]
	public void әݓ\u0610ժ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
	}

	// Token: 0x06000DB7 RID: 3511 RVA: 0x0004A914 File Offset: 0x00048B14
	[Token(Token = "0x6000DB7")]
	[Address(RVA = "0x28DD828", Offset = "0x28DD828", VA = "0x28DD828")]
	private void Ӧد\u060Eࡏ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u0640ܜࠉ\u083A();
		}
	}

	// Token: 0x06000DB8 RID: 3512 RVA: 0x0004A930 File Offset: 0x00048B30
	[Token(Token = "0x6000DB8")]
	[Address(RVA = "0x28DD854", Offset = "0x28DD854", VA = "0x28DD854")]
	public void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000DB9 RID: 3513 RVA: 0x0004A958 File Offset: 0x00048B58
	[Token(Token = "0x6000DB9")]
	[Address(RVA = "0x28DD908", Offset = "0x28DD908", VA = "0x28DD908")]
	private void Start()
	{
		this.ӭՍݑՇ();
	}

	// Token: 0x06000DBA RID: 3514 RVA: 0x0004A96C File Offset: 0x00048B6C
	[Token(Token = "0x6000DBA")]
	[Address(RVA = "0x28DD90C", Offset = "0x28DD90C", VA = "0x28DD90C")]
	private void \u07A8Ӥթݠ()
	{
		this.Ԋࡃ\u0877ݵ();
	}

	// Token: 0x06000DBB RID: 3515 RVA: 0x0004A980 File Offset: 0x00048B80
	[Token(Token = "0x6000DBB")]
	[Address(RVA = "0x28DC2E0", Offset = "0x28DC2E0", VA = "0x28DC2E0")]
	public void ԕܞ\u07EEߚ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Push To Talk");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("You struck apon an error. ");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000DBC RID: 3516 RVA: 0x0004A9E4 File Offset: 0x00048BE4
	[Token(Token = "0x6000DBC")]
	[Address(RVA = "0x28DC850", Offset = "0x28DC850", VA = "0x28DC850")]
	public void \u0652\u0823\u0821ԓ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Horizontal");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("BN");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000DBD RID: 3517 RVA: 0x0004AA48 File Offset: 0x00048C48
	[Token(Token = "0x6000DBD")]
	[Address(RVA = "0x28DD910", Offset = "0x28DD910", VA = "0x28DD910")]
	private void ߓ\u06E3\u05C7ۋ()
	{
		this.ךגޚ\u0607();
	}

	// Token: 0x06000DBE RID: 3518 RVA: 0x0004AA5C File Offset: 0x00048C5C
	[Token(Token = "0x6000DBE")]
	[Address(RVA = "0x28DD914", Offset = "0x28DD914", VA = "0x28DD914")]
	public void ԉՔӸ\u06DC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06000DBF RID: 3519 RVA: 0x0004AA8C File Offset: 0x00048C8C
	[Token(Token = "0x6000DBF")]
	[Address(RVA = "0x28DD9CC", Offset = "0x28DD9CC", VA = "0x28DD9CC")]
	private void \u0832ࢳޤ\u07B5()
	{
		bool ٥_u08B5_u0616ࡠ = this.٥\u08B5\u0616ࡠ;
		this.\u06DFӣ\u0833\u05BB();
	}

	// Token: 0x06000DC0 RID: 3520 RVA: 0x0004AAA8 File Offset: 0x00048CA8
	[Token(Token = "0x6000DC0")]
	[Address(RVA = "0x28DD9F8", Offset = "0x28DD9F8", VA = "0x28DD9F8")]
	public void \u058Bࢺ\u073Fބ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06000DC1 RID: 3521 RVA: 0x0004AAD0 File Offset: 0x00048CD0
	[Token(Token = "0x6000DC1")]
	[Address(RVA = "0x28DDAAC", Offset = "0x28DDAAC", VA = "0x28DDAAC")]
	public void ت\u05F9ޅ\u059A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
	}

	// Token: 0x06000DC2 RID: 3522 RVA: 0x0004AAF0 File Offset: 0x00048CF0
	[Token(Token = "0x6000DC2")]
	[Address(RVA = "0x28DA3E4", Offset = "0x28DA3E4", VA = "0x28DA3E4")]
	public void ԇأ\u06E2Մ()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("M/d/yyyy");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag(".Please press the button if you would like to play alone");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000DC3 RID: 3523 RVA: 0x0004AB54 File Offset: 0x00048D54
	[Token(Token = "0x6000DC3")]
	[Address(RVA = "0x28DDB64", Offset = "0x28DDB64", VA = "0x28DDB64")]
	private void \u081Cәࡃ۵()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.\u0640ܜࠉ\u083A();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000DC4 RID: 3524 RVA: 0x0004AB78 File Offset: 0x00048D78
	[Token(Token = "0x6000DC4")]
	[Address(RVA = "0x28DBBA4", Offset = "0x28DBBA4", VA = "0x28DBBA4")]
	public void ךגޚ\u0607()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Not connected to room");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("Player");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform;
		Vector3 position = transform.position;
	}

	// Token: 0x06000DC5 RID: 3525 RVA: 0x0004ABD0 File Offset: 0x00048DD0
	[Token(Token = "0x6000DC5")]
	[Address(RVA = "0x28DDB94", Offset = "0x28DDB94", VA = "0x28DDB94")]
	private void ࡕߕ\u0707ݩ()
	{
		if (this.٥\u08B5\u0616ࡠ)
		{
			this.ࡗ\u07B9\u0887\u06D8();
			long ٥_u08B5_u0616ࡠ = 1L;
			this.٥\u08B5\u0616ࡠ = (٥_u08B5_u0616ࡠ != 0L);
		}
	}

	// Token: 0x06000DC6 RID: 3526 RVA: 0x0004ABF4 File Offset: 0x00048DF4
	[Token(Token = "0x6000DC6")]
	[Address(RVA = "0x28DDBC4", Offset = "0x28DDBC4", VA = "0x28DDBC4")]
	private void ࠏޤݳ\u06DD()
	{
		this.Ԋࡃ\u0877ݵ();
	}

	// Token: 0x06000DC7 RID: 3527 RVA: 0x0004AC08 File Offset: 0x00048E08
	[Token(Token = "0x6000DC7")]
	[Address(RVA = "0x28DA89C", Offset = "0x28DA89C", VA = "0x28DA89C")]
	public void \u055Fԁࢧ\u07AF()
	{
		if (this.\u0730\u0819ڔ\u0885)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("deathScream");
			return;
		}
		GameObject[] maxExclusive = GameObject.FindGameObjectsWithTag("containsStaff");
		this.ܭիڒܬ = maxExclusive;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.\u058B\u0707ܢࢷ.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x040001E6 RID: 486
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001E6")]
	public GameObject[] ܭիڒܬ;

	// Token: 0x040001E7 RID: 487
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001E7")]
	public GameObject \u058B\u0707ܢࢷ;

	// Token: 0x040001E8 RID: 488
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001E8")]
	public DoorLerp \u0558\u0654ڄ\u087E;

	// Token: 0x040001E9 RID: 489
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40001E9")]
	public bool \u0730\u0819ڔ\u0885;

	// Token: 0x040001EA RID: 490
	[FieldOffset(Offset = "0x31")]
	[Token(Token = "0x40001EA")]
	public bool ٥\u08B5\u0616ࡠ;
}
