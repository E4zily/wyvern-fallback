﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000016 RID: 22
[Token(Token = "0x2000016")]
public class CapuchinButton : MonoBehaviour
{
	// Token: 0x060002B8 RID: 696 RVA: 0x00013248 File Offset: 0x00011448
	[Token(Token = "0x60002B8")]
	[Address(RVA = "0x293CC64", Offset = "0x293CC64", VA = "0x293CC64")]
	private void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "A Player has left the Room.";
		Coroutine coroutine = base.StartCoroutine("Player");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x000132A0 File Offset: 0x000114A0
	[Token(Token = "0x60002B9")]
	[Address(RVA = "0x293CDBC", Offset = "0x293CDBC", VA = "0x293CDBC")]
	private void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Failed to login, please restart";
		Coroutine coroutine = base.StartCoroutine("FingerTip");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002BA RID: 698 RVA: 0x000132F8 File Offset: 0x000114F8
	[Token(Token = "0x60002BA")]
	[Address(RVA = "0x293CEE0", Offset = "0x293CEE0", VA = "0x293CEE0")]
	private void פ\u05F9ࡄٲ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ݴ\u0610زճ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060002BB RID: 699 RVA: 0x00013318 File Offset: 0x00011518
	[Token(Token = "0x60002BB")]
	[Address(RVA = "0x293CF10", Offset = "0x293CF10", VA = "0x293CF10")]
	private IEnumerator ݴ\u0610زճ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002BC RID: 700 RVA: 0x00013348 File Offset: 0x00011548
	[Token(Token = "0x60002BC")]
	[Address(RVA = "0x293CFB4", Offset = "0x293CFB4", VA = "0x293CFB4", Slot = "4")]
	public virtual void ݱ\u0700٥ݼ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002BD RID: 701 RVA: 0x00013358 File Offset: 0x00011558
	[Token(Token = "0x60002BD")]
	[Address(RVA = "0x293CFB8", Offset = "0x293CFB8", VA = "0x293CFB8")]
	private void ӛےܢڲ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ݴ\u0610زճ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060002BE RID: 702 RVA: 0x00013378 File Offset: 0x00011578
	[Token(Token = "0x60002BE")]
	[Address(RVA = "0x293CFE8", Offset = "0x293CFE8", VA = "0x293CFE8")]
	private void ݍ\u05F4ߓ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		Coroutine coroutine = base.StartCoroutine("_Tint");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002BF RID: 703 RVA: 0x000133D0 File Offset: 0x000115D0
	[Token(Token = "0x60002BF")]
	[Address(RVA = "0x293D10C", Offset = "0x293D10C", VA = "0x293D10C")]
	private IEnumerator \u0875ߎ٢\u05BA()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 0L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002C0 RID: 704 RVA: 0x000133F4 File Offset: 0x000115F4
	[Token(Token = "0x60002C0")]
	[Address(RVA = "0x293D184", Offset = "0x293D184", VA = "0x293D184", Slot = "5")]
	public virtual void \u0557\u0654ل\u0652(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002C1 RID: 705 RVA: 0x00013404 File Offset: 0x00011604
	[Token(Token = "0x60002C1")]
	[Address(RVA = "0x293D188", Offset = "0x293D188", VA = "0x293D188")]
	private IEnumerator Ԗؤ\u05BCࠋ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002C2 RID: 706 RVA: 0x00013434 File Offset: 0x00011634
	[Token(Token = "0x60002C2")]
	[Address(RVA = "0x293D22C", Offset = "0x293D22C", VA = "0x293D22C", Slot = "6")]
	public virtual void ݦӰٿڰ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002C3 RID: 707 RVA: 0x00013444 File Offset: 0x00011644
	[Token(Token = "0x60002C3")]
	[Address(RVA = "0x293D230", Offset = "0x293D230", VA = "0x293D230")]
	private void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Smoothness";
		Coroutine coroutine = base.StartCoroutine("Player");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002C4 RID: 708 RVA: 0x0001349C File Offset: 0x0001169C
	[Token(Token = "0x60002C4")]
	[Address(RVA = "0x293D388", Offset = "0x293D388", VA = "0x293D388")]
	private void \u081FԘں\u07B2(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "EnableCosmetic";
		Coroutine coroutine = base.StartCoroutine("Diffuse");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002C5 RID: 709 RVA: 0x000134F4 File Offset: 0x000116F4
	[Token(Token = "0x60002C5")]
	[Address(RVA = "0x293D4DC", Offset = "0x293D4DC", VA = "0x293D4DC", Slot = "7")]
	public virtual void ح\u05A1\u0739Հ()
	{
	}

	// Token: 0x060002C6 RID: 710 RVA: 0x00013504 File Offset: 0x00011704
	[Token(Token = "0x60002C6")]
	[Address(RVA = "0x293D4E0", Offset = "0x293D4E0", VA = "0x293D4E0")]
	private IEnumerator ڸ\u0559ݒן(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002C7 RID: 711 RVA: 0x00013534 File Offset: 0x00011734
	[Token(Token = "0x60002C7")]
	[Address(RVA = "0x293D584", Offset = "0x293D584", VA = "0x293D584")]
	private void ڊڕ\u0859\u0876(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u05FCإࢤ\u0653(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060002C8 RID: 712 RVA: 0x00013554 File Offset: 0x00011754
	[Token(Token = "0x60002C8")]
	[Address(RVA = "0x293D658", Offset = "0x293D658", VA = "0x293D658")]
	private void ࢻփזދ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u0859\u0884\u0652ݍ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060002C9 RID: 713 RVA: 0x00013574 File Offset: 0x00011774
	[Token(Token = "0x60002C9")]
	[Address(RVA = "0x293D72C", Offset = "0x293D72C", VA = "0x293D72C", Slot = "8")]
	public virtual void Փ\u07B9\u07F8Է()
	{
	}

	// Token: 0x060002CA RID: 714 RVA: 0x00013584 File Offset: 0x00011784
	[Token(Token = "0x60002CA")]
	[Address(RVA = "0x293D730", Offset = "0x293D730", VA = "0x293D730")]
	private void Ԍڏ\u0879թ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "On";
		Coroutine coroutine = base.StartCoroutine("Platform failed to initialize due to exception.");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002CB RID: 715 RVA: 0x000135DC File Offset: 0x000117DC
	[Token(Token = "0x60002CB")]
	[Address(RVA = "0x293D888", Offset = "0x293D888", VA = "0x293D888")]
	private void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayerHead";
		Coroutine coroutine = base.StartCoroutine("CapuchinRemade");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002CC RID: 716 RVA: 0x00013634 File Offset: 0x00011834
	[Token(Token = "0x60002CC")]
	[Address(RVA = "0x293D9E0", Offset = "0x293D9E0", VA = "0x293D9E0")]
	private void ٳךߧع(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Head";
		Coroutine coroutine = base.StartCoroutine(" and the correct version is ");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002CD RID: 717 RVA: 0x0001368C File Offset: 0x0001188C
	[Token(Token = "0x60002CD")]
	[Address(RVA = "0x293DB08", Offset = "0x293DB08", VA = "0x293DB08", Slot = "9")]
	public virtual void Ֆ\u0597ܗ\u05AD(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002CE RID: 718 RVA: 0x0001369C File Offset: 0x0001189C
	[Token(Token = "0x60002CE")]
	[Address(RVA = "0x293DB0C", Offset = "0x293DB0C", VA = "0x293DB0C")]
	private IEnumerator Ԋצߦբ()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 0L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002CF RID: 719 RVA: 0x000136C0 File Offset: 0x000118C0
	[Token(Token = "0x60002CF")]
	[Address(RVA = "0x293DB84", Offset = "0x293DB84", VA = "0x293DB84", Slot = "10")]
	public virtual void Ԗތ\u089CՑ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002D0 RID: 720 RVA: 0x000136D0 File Offset: 0x000118D0
	[Token(Token = "0x60002D0")]
	[Address(RVA = "0x293DB88", Offset = "0x293DB88", VA = "0x293DB88")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		Coroutine coroutine = base.StartCoroutine("ՊӇԨࡉ");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002D1 RID: 721 RVA: 0x00013728 File Offset: 0x00011928
	[Token(Token = "0x60002D1")]
	[Address(RVA = "0x293DCAC", Offset = "0x293DCAC", VA = "0x293DCAC")]
	private void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "";
		Coroutine coroutine = base.StartCoroutine("Player");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002D2 RID: 722 RVA: 0x00013780 File Offset: 0x00011980
	[Token(Token = "0x60002D2")]
	[Address(RVA = "0x293DE04", Offset = "0x293DE04", VA = "0x293DE04")]
	private void \u059Cݝ\u058E۳(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "gravThing";
		Coroutine coroutine = base.StartCoroutine("PRESS AGAIN TO CONFIRM");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002D3 RID: 723 RVA: 0x000137D8 File Offset: 0x000119D8
	[Token(Token = "0x60002D3")]
	[Address(RVA = "0x293DF5C", Offset = "0x293DF5C", VA = "0x293DF5C", Slot = "11")]
	public virtual void \u0830\u05C0ޟޘ()
	{
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x000137E8 File Offset: 0x000119E8
	[Token(Token = "0x60002D4")]
	[Address(RVA = "0x293DF60", Offset = "0x293DF60", VA = "0x293DF60")]
	public CapuchinButton()
	{
	}

	// Token: 0x060002D5 RID: 725 RVA: 0x00013808 File Offset: 0x00011A08
	[Token(Token = "0x60002D5")]
	[Address(RVA = "0x293DF74", Offset = "0x293DF74", VA = "0x293DF74", Slot = "12")]
	public virtual void ڎӞޅԛ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002D6 RID: 726 RVA: 0x00013818 File Offset: 0x00011A18
	[Token(Token = "0x60002D6")]
	[Address(RVA = "0x293DF78", Offset = "0x293DF78", VA = "0x293DF78", Slot = "13")]
	public virtual void Ԡ\u0530\u07FAӯ()
	{
	}

	// Token: 0x060002D7 RID: 727 RVA: 0x00013828 File Offset: 0x00011A28
	[Token(Token = "0x60002D7")]
	[Address(RVA = "0x293DF7C", Offset = "0x293DF7C", VA = "0x293DF7C")]
	private IEnumerator \u0826ڒٸ\u0832()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 1L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002D8 RID: 728 RVA: 0x0001384C File Offset: 0x00011A4C
	[Token(Token = "0x60002D8")]
	[Address(RVA = "0x293DFF4", Offset = "0x293DFF4", VA = "0x293DFF4")]
	private void \u06DAٻࠕڡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		Coroutine coroutine = base.StartCoroutine("Open");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002D9 RID: 729 RVA: 0x000138A4 File Offset: 0x00011AA4
	[Token(Token = "0x60002D9")]
	[Address(RVA = "0x293E14C", Offset = "0x293E14C", VA = "0x293E14C", Slot = "14")]
	public virtual void ؽߎم\u0592(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002DA RID: 730 RVA: 0x000138B4 File Offset: 0x00011AB4
	[Token(Token = "0x60002DA")]
	[Address(RVA = "0x293E150", Offset = "0x293E150", VA = "0x293E150")]
	private void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Agreed";
		Coroutine coroutine = base.StartCoroutine("_BumpMap");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002DB RID: 731 RVA: 0x0001390C File Offset: 0x00011B0C
	[Token(Token = "0x60002DB")]
	[Address(RVA = "0x293E278", Offset = "0x293E278", VA = "0x293E278")]
	private IEnumerator ࡩӦӶܞ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002DC RID: 732 RVA: 0x0001393C File Offset: 0x00011B3C
	[Token(Token = "0x60002DC")]
	[Address(RVA = "0x293E31C", Offset = "0x293E31C", VA = "0x293E31C")]
	private IEnumerator ߄\u066A\u0706٥()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 1L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002DD RID: 733 RVA: 0x00013960 File Offset: 0x00011B60
	[Token(Token = "0x60002DD")]
	[Address(RVA = "0x293E394", Offset = "0x293E394", VA = "0x293E394", Slot = "15")]
	public virtual void \u07B7߂ԍ\u07F1(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002DE RID: 734 RVA: 0x00013970 File Offset: 0x00011B70
	[Token(Token = "0x60002DE")]
	[Address(RVA = "0x293E398", Offset = "0x293E398", VA = "0x293E398")]
	private IEnumerator \u0600\u05EB\u055BԲ()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 0L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002DF RID: 735 RVA: 0x00013994 File Offset: 0x00011B94
	[Token(Token = "0x60002DF")]
	[Address(RVA = "0x293E410", Offset = "0x293E410", VA = "0x293E410")]
	private IEnumerator Ӈ߄Ը\u064E(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002E0 RID: 736 RVA: 0x000139C4 File Offset: 0x00011BC4
	[Token(Token = "0x60002E0")]
	[Address(RVA = "0x293E4B4", Offset = "0x293E4B4", VA = "0x293E4B4", Slot = "16")]
	public virtual void ۲ڜӤݵ()
	{
	}

	// Token: 0x060002E1 RID: 737 RVA: 0x000139D4 File Offset: 0x00011BD4
	[Token(Token = "0x60002E1")]
	[Address(RVA = "0x293E4B8", Offset = "0x293E4B8", VA = "0x293E4B8", Slot = "17")]
	public virtual void \u0747\u07A6ࠋ\u0651()
	{
	}

	// Token: 0x060002E2 RID: 738 RVA: 0x000139E4 File Offset: 0x00011BE4
	[Token(Token = "0x60002E2")]
	[Address(RVA = "0x293D358", Offset = "0x293D358", VA = "0x293D358")]
	private void إӺԘ\u06E1(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator enumerator = this.\u07ACԬӻݧ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
	}

	// Token: 0x060002E3 RID: 739 RVA: 0x000139FC File Offset: 0x00011BFC
	[Token(Token = "0x60002E3")]
	[Address(RVA = "0x293E560", Offset = "0x293E560", VA = "0x293E560")]
	private IEnumerator ը\u05AE\u0599\u058A(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002E4 RID: 740 RVA: 0x00013A2C File Offset: 0x00011C2C
	[Token(Token = "0x60002E4")]
	[Address(RVA = "0x293E604", Offset = "0x293E604", VA = "0x293E604", Slot = "18")]
	public virtual void ࢣ\u0819ࢭث()
	{
	}

	// Token: 0x060002E5 RID: 741 RVA: 0x00013A3C File Offset: 0x00011C3C
	[Token(Token = "0x60002E5")]
	[Address(RVA = "0x293E608", Offset = "0x293E608", VA = "0x293E608")]
	private IEnumerator \u05A0\u0833ڳܕ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002E6 RID: 742 RVA: 0x00013A6C File Offset: 0x00011C6C
	[Token(Token = "0x60002E6")]
	[Address(RVA = "0x293E6AC", Offset = "0x293E6AC", VA = "0x293E6AC", Slot = "19")]
	public virtual void \u0654ۑڄվ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002E7 RID: 743 RVA: 0x00013A7C File Offset: 0x00011C7C
	[Token(Token = "0x60002E7")]
	[Address(RVA = "0x293E6B0", Offset = "0x293E6B0", VA = "0x293E6B0")]
	private void ٸ\u065F\u058A\u0872(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ڼ\u059E\u06DF\u07BF(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x00013A9C File Offset: 0x00011C9C
	[Token(Token = "0x60002E8")]
	[Address(RVA = "0x293E784", Offset = "0x293E784", VA = "0x293E784")]
	private IEnumerator \u07BEٻݮߣ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002E9 RID: 745 RVA: 0x00013ACC File Offset: 0x00011CCC
	[Token(Token = "0x60002E9")]
	[Address(RVA = "0x293E828", Offset = "0x293E828", VA = "0x293E828", Slot = "20")]
	public virtual void ۋޙճܖ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002EA RID: 746 RVA: 0x00013ADC File Offset: 0x00011CDC
	[Token(Token = "0x60002EA")]
	[Address(RVA = "0x293E6E0", Offset = "0x293E6E0", VA = "0x293E6E0")]
	private IEnumerator ڼ\u059E\u06DF\u07BF(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002EB RID: 747 RVA: 0x00013B0C File Offset: 0x00011D0C
	[Token(Token = "0x60002EB")]
	[Address(RVA = "0x293E82C", Offset = "0x293E82C", VA = "0x293E82C")]
	private IEnumerator Ԙߢԟޛ()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 1L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002EC RID: 748 RVA: 0x00013B30 File Offset: 0x00011D30
	[Token(Token = "0x60002EC")]
	[Address(RVA = "0x293E8A4", Offset = "0x293E8A4", VA = "0x293E8A4")]
	private IEnumerator \u088Dؼץէ()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 0L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002ED RID: 749 RVA: 0x00013B54 File Offset: 0x00011D54
	[Token(Token = "0x60002ED")]
	[Address(RVA = "0x293E91C", Offset = "0x293E91C", VA = "0x293E91C", Slot = "21")]
	public virtual void ԃ\u065D\u086Cޙ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002EE RID: 750 RVA: 0x00013B64 File Offset: 0x00011D64
	[Token(Token = "0x60002EE")]
	[Address(RVA = "0x293E920", Offset = "0x293E920", VA = "0x293E920")]
	private IEnumerator خߓ\u0617ڇ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002EF RID: 751 RVA: 0x00013B94 File Offset: 0x00011D94
	[Token(Token = "0x60002EF")]
	[Address(RVA = "0x293E9C4", Offset = "0x293E9C4", VA = "0x293E9C4", Slot = "22")]
	public virtual void \u0885Ԟ\u061Cױ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002F0 RID: 752 RVA: 0x00013BA4 File Offset: 0x00011DA4
	[Token(Token = "0x60002F0")]
	[Address(RVA = "0x293DF2C", Offset = "0x293DF2C", VA = "0x293DF2C")]
	private void \u07BAݷ\u064B\u06E9(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.\u065Aۀӿ\u087D(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060002F1 RID: 753 RVA: 0x00013BC4 File Offset: 0x00011DC4
	[Token(Token = "0x60002F1")]
	[Address(RVA = "0x293EA6C", Offset = "0x293EA6C", VA = "0x293EA6C")]
	private void ۷ޞ\u07AFߍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "CapuchinRemade";
		Coroutine coroutine = base.StartCoroutine("Target");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002F2 RID: 754 RVA: 0x00013C14 File Offset: 0x00011E14
	[Token(Token = "0x60002F2")]
	[Address(RVA = "0x293EB94", Offset = "0x293EB94", VA = "0x293EB94")]
	private void Ԇܥډݑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You have been banned for ";
		Coroutine coroutine = base.StartCoroutine("Add/Remove Glasses");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002F3 RID: 755 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60002F3")]
	[Address(RVA = "0x293ECB8", Offset = "0x293ECB8", VA = "0x293ECB8")]
	private void ӹӼӂӄ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060002F4 RID: 756 RVA: 0x00013C6C File Offset: 0x00011E6C
	[Token(Token = "0x60002F4")]
	[Address(RVA = "0x293EDDC", Offset = "0x293EDDC", VA = "0x293EDDC", Slot = "23")]
	public virtual void \u05FF\u07EB\u0874ڄ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002F5 RID: 757 RVA: 0x00013C7C File Offset: 0x00011E7C
	[Token(Token = "0x60002F5")]
	[Address(RVA = "0x293EDE0", Offset = "0x293EDE0", VA = "0x293EDE0")]
	private IEnumerator \u05C9\u05A9ؤ\u082E(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002F6 RID: 758 RVA: 0x00013CAC File Offset: 0x00011EAC
	[Token(Token = "0x60002F6")]
	[Address(RVA = "0x293EE84", Offset = "0x293EE84", VA = "0x293EE84")]
	private void Ԃ\u058Aܫջ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Round end";
		Coroutine coroutine = base.StartCoroutine("ORGPORT");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002F7 RID: 759 RVA: 0x00013D04 File Offset: 0x00011F04
	[Token(Token = "0x60002F7")]
	[Address(RVA = "0x293D9B0", Offset = "0x293D9B0", VA = "0x293D9B0")]
	private void \u0735ڲӠ\u05C6(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ܘ\u081Aڧو(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060002F8 RID: 760 RVA: 0x00013D24 File Offset: 0x00011F24
	[Token(Token = "0x60002F8")]
	[Address(RVA = "0x293F050", Offset = "0x293F050", VA = "0x293F050")]
	private IEnumerator ܞޓ\u07B8\u07BF(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002F9 RID: 761 RVA: 0x00013D54 File Offset: 0x00011F54
	[Token(Token = "0x60002F9")]
	[Address(RVA = "0x293F0F4", Offset = "0x293F0F4", VA = "0x293F0F4", Slot = "24")]
	public virtual void ڛںԔӮ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x060002FA RID: 762 RVA: 0x00013D64 File Offset: 0x00011F64
	[Token(Token = "0x60002FA")]
	[Address(RVA = "0x293F0F8", Offset = "0x293F0F8", VA = "0x293F0F8", Slot = "25")]
	public virtual void \u0703ԂٸҼ()
	{
	}

	// Token: 0x060002FB RID: 763 RVA: 0x00013D74 File Offset: 0x00011F74
	[Token(Token = "0x60002FB")]
	[Address(RVA = "0x293F0FC", Offset = "0x293F0FC", VA = "0x293F0FC", Slot = "26")]
	public virtual void ߧցӡכ()
	{
	}

	// Token: 0x060002FC RID: 764 RVA: 0x00013D84 File Offset: 0x00011F84
	[Token(Token = "0x60002FC")]
	[Address(RVA = "0x293F100", Offset = "0x293F100", VA = "0x293F100", Slot = "27")]
	public virtual void \u0603ݻԫݵ()
	{
	}

	// Token: 0x060002FD RID: 765 RVA: 0x00013D94 File Offset: 0x00011F94
	[Token(Token = "0x60002FD")]
	[Address(RVA = "0x293F104", Offset = "0x293F104", VA = "0x293F104")]
	private void \u0607յ\u061C\u083D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		Coroutine coroutine = base.StartCoroutine("ChangeToRegular");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x060002FE RID: 766 RVA: 0x00013DEC File Offset: 0x00011FEC
	[Token(Token = "0x60002FE")]
	[Address(RVA = "0x293F228", Offset = "0x293F228", VA = "0x293F228")]
	private IEnumerator \u0879\u085Bݦߖ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002FF RID: 767 RVA: 0x00013E1C File Offset: 0x0001201C
	[Token(Token = "0x60002FF")]
	[Address(RVA = "0x293E4BC", Offset = "0x293E4BC", VA = "0x293E4BC")]
	private IEnumerator \u07ACԬӻݧ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000300 RID: 768 RVA: 0x00013E4C File Offset: 0x0001204C
	[Token(Token = "0x6000300")]
	[Address(RVA = "0x293F2CC", Offset = "0x293F2CC", VA = "0x293F2CC")]
	private void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "friend";
		Coroutine coroutine = base.StartCoroutine("PURCHASED!");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000301 RID: 769 RVA: 0x00013EA4 File Offset: 0x000120A4
	[Token(Token = "0x6000301")]
	[Address(RVA = "0x293F3F4", Offset = "0x293F3F4", VA = "0x293F3F4")]
	private void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "CapuchinRemade";
		Coroutine coroutine = base.StartCoroutine("CapuchinRemade");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000302 RID: 770 RVA: 0x00013EFC File Offset: 0x000120FC
	[Token(Token = "0x6000302")]
	[Address(RVA = "0x293F51C", Offset = "0x293F51C", VA = "0x293F51C")]
	private IEnumerator ԄӉࢻ\u06DB(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000303 RID: 771 RVA: 0x00013F2C File Offset: 0x0001212C
	[Token(Token = "0x6000303")]
	[Address(RVA = "0x293F5C0", Offset = "0x293F5C0", VA = "0x293F5C0", Slot = "28")]
	public virtual void \u0827ڇݽ\u07F2()
	{
	}

	// Token: 0x06000304 RID: 772 RVA: 0x00013F3C File Offset: 0x0001213C
	[Token(Token = "0x6000304")]
	[Address(RVA = "0x293F5C4", Offset = "0x293F5C4", VA = "0x293F5C4")]
	private void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ScoreCounter";
		Coroutine coroutine = base.StartCoroutine("PushToTalk");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000305 RID: 773 RVA: 0x00013F94 File Offset: 0x00012194
	[Token(Token = "0x6000305")]
	[Address(RVA = "0x293F6E8", Offset = "0x293F6E8", VA = "0x293F6E8")]
	private IEnumerator ݽݝܬ\u089B(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000306 RID: 774 RVA: 0x00013FC4 File Offset: 0x000121C4
	[Token(Token = "0x6000306")]
	[Address(RVA = "0x293F78C", Offset = "0x293F78C", VA = "0x293F78C", Slot = "29")]
	public virtual void ݱ\u0823ب\u06D8(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06000307 RID: 775 RVA: 0x00013FD4 File Offset: 0x000121D4
	[Token(Token = "0x6000307")]
	[Address(RVA = "0x293F790", Offset = "0x293F790", VA = "0x293F790", Slot = "30")]
	public virtual void ܬ\u0838\u0873ӿ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06000308 RID: 776 RVA: 0x00013FE4 File Offset: 0x000121E4
	[Token(Token = "0x6000308")]
	[Address(RVA = "0x293F794", Offset = "0x293F794", VA = "0x293F794", Slot = "31")]
	public virtual void պܘࡕӄ()
	{
	}

	// Token: 0x06000309 RID: 777 RVA: 0x00013FF4 File Offset: 0x000121F4
	[Token(Token = "0x6000309")]
	[Address(RVA = "0x293F798", Offset = "0x293F798", VA = "0x293F798", Slot = "32")]
	public virtual void ޛڻ\u0874ӎ()
	{
	}

	// Token: 0x0600030A RID: 778 RVA: 0x00014004 File Offset: 0x00012204
	[Token(Token = "0x600030A")]
	[Address(RVA = "0x293D5B4", Offset = "0x293D5B4", VA = "0x293D5B4")]
	private IEnumerator \u05FCإࢤ\u0653(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600030B RID: 779 RVA: 0x00014034 File Offset: 0x00012234
	[Token(Token = "0x600030B")]
	[Address(RVA = "0x293F79C", Offset = "0x293F79C", VA = "0x293F79C")]
	private IEnumerator ࡉ\u0874\u06DC\u081B(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600030C RID: 780 RVA: 0x00014064 File Offset: 0x00012264
	[Token(Token = "0x600030C")]
	[Address(RVA = "0x293F840", Offset = "0x293F840", VA = "0x293F840", Slot = "33")]
	public virtual void \u0741\u081Fہל()
	{
	}

	// Token: 0x0600030D RID: 781 RVA: 0x00014074 File Offset: 0x00012274
	[Token(Token = "0x600030D")]
	[Address(RVA = "0x293F844", Offset = "0x293F844", VA = "0x293F844", Slot = "34")]
	public virtual void הݢ\u0614ש()
	{
	}

	// Token: 0x0600030E RID: 782 RVA: 0x00014084 File Offset: 0x00012284
	[Token(Token = "0x600030E")]
	[Address(RVA = "0x293F848", Offset = "0x293F848", VA = "0x293F848")]
	private IEnumerator ܨ\u070CܓӁ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600030F RID: 783 RVA: 0x000140B4 File Offset: 0x000122B4
	[Token(Token = "0x600030F")]
	[Address(RVA = "0x293F8EC", Offset = "0x293F8EC", VA = "0x293F8EC")]
	private IEnumerator ޖۑ\u0826ן()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 0L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000310 RID: 784 RVA: 0x000140D8 File Offset: 0x000122D8
	[Token(Token = "0x6000310")]
	[Address(RVA = "0x293F964", Offset = "0x293F964", VA = "0x293F964")]
	private IEnumerator \u089AۇٿԦ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000311 RID: 785 RVA: 0x00014108 File Offset: 0x00012308
	[Token(Token = "0x6000311")]
	[Address(RVA = "0x293FA08", Offset = "0x293FA08", VA = "0x293FA08", Slot = "35")]
	public virtual void ރբ\u088E٣()
	{
	}

	// Token: 0x06000312 RID: 786 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000312")]
	[Address(RVA = "0x293FA0C", Offset = "0x293FA0C", VA = "0x293FA0C")]
	private void ࡘ\u0891ࢥ\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000313 RID: 787 RVA: 0x00014118 File Offset: 0x00012318
	[Token(Token = "0x6000313")]
	[Address(RVA = "0x293FB34", Offset = "0x293FB34", VA = "0x293FB34")]
	private void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "This is the 1000 Bananas button, and it was just clicked";
		Coroutine coroutine = base.StartCoroutine("Updating Material to: ");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000314 RID: 788 RVA: 0x00014170 File Offset: 0x00012370
	[Token(Token = "0x6000314")]
	[Address(RVA = "0x293FC5C", Offset = "0x293FC5C", VA = "0x293FC5C")]
	private IEnumerator كۈڊ\u05AA(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000315 RID: 789 RVA: 0x000141A0 File Offset: 0x000123A0
	[Token(Token = "0x6000315")]
	[Address(RVA = "0x293FD00", Offset = "0x293FD00", VA = "0x293FD00")]
	private void \u07FF\u05BCޥڡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_BumpScale";
		Coroutine coroutine = base.StartCoroutine("ChangeToTagged");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000316 RID: 790 RVA: 0x000141F8 File Offset: 0x000123F8
	[Token(Token = "0x6000316")]
	[Address(RVA = "0x293FE28", Offset = "0x293FE28", VA = "0x293FE28")]
	private IEnumerator حҿ\u065BՄ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000317 RID: 791 RVA: 0x00014228 File Offset: 0x00012428
	[Token(Token = "0x6000317")]
	[Address(RVA = "0x293FECC", Offset = "0x293FECC", VA = "0x293FECC", Slot = "36")]
	public virtual void ԑ\u0614ݖ\u05BD(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06000318 RID: 792 RVA: 0x00014238 File Offset: 0x00012438
	[Token(Token = "0x6000318")]
	[Address(RVA = "0x293FED0", Offset = "0x293FED0", VA = "0x293FED0")]
	private IEnumerator \u060Fإԧ\u088B()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 1L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000319 RID: 793 RVA: 0x0001425C File Offset: 0x0001245C
	[Token(Token = "0x6000319")]
	[Address(RVA = "0x293FF48", Offset = "0x293FF48", VA = "0x293FF48")]
	private void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == " ";
		Coroutine coroutine = base.StartCoroutine("containsStaff");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x0600031A RID: 794 RVA: 0x000142B4 File Offset: 0x000124B4
	[Token(Token = "0x600031A")]
	[Address(RVA = "0x2940070", Offset = "0x2940070", VA = "0x2940070", Slot = "37")]
	public virtual void ߠ\u0825\u087Fצ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x0600031B RID: 795 RVA: 0x000142C4 File Offset: 0x000124C4
	[Token(Token = "0x600031B")]
	[Address(RVA = "0x2940074", Offset = "0x2940074", VA = "0x2940074")]
	private IEnumerator ب\u088EՔࢧ()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 0L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600031C RID: 796 RVA: 0x000142E8 File Offset: 0x000124E8
	[Token(Token = "0x600031C")]
	[Address(RVA = "0x29400EC", Offset = "0x29400EC", VA = "0x29400EC")]
	private IEnumerator \u0831\u07ADݰԁ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600031D RID: 797 RVA: 0x00014318 File Offset: 0x00012518
	[Token(Token = "0x600031D")]
	[Address(RVA = "0x293E9C8", Offset = "0x293E9C8", VA = "0x293E9C8")]
	private IEnumerator \u065Aۀӿ\u087D(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600031E RID: 798 RVA: 0x00014348 File Offset: 0x00012548
	[Token(Token = "0x600031E")]
	[Address(RVA = "0x293EFAC", Offset = "0x293EFAC", VA = "0x293EFAC")]
	private IEnumerator ܘ\u081Aڧو(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600031F RID: 799 RVA: 0x00014378 File Offset: 0x00012578
	[Token(Token = "0x600031F")]
	[Address(RVA = "0x293D688", Offset = "0x293D688", VA = "0x293D688")]
	private IEnumerator \u0859\u0884\u0652ݍ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 1L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000320 RID: 800 RVA: 0x000143A8 File Offset: 0x000125A8
	[Token(Token = "0x6000320")]
	[Address(RVA = "0x2940190", Offset = "0x2940190", VA = "0x2940190", Slot = "38")]
	public virtual void ࢦݒՠՓ(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06000321 RID: 801 RVA: 0x000143B8 File Offset: 0x000125B8
	[Token(Token = "0x6000321")]
	[Address(RVA = "0x2940194", Offset = "0x2940194", VA = "0x2940194", Slot = "39")]
	public virtual void ذՌ\u081FӪ()
	{
	}

	// Token: 0x06000322 RID: 802 RVA: 0x000143C8 File Offset: 0x000125C8
	[Token(Token = "0x6000322")]
	[Address(RVA = "0x293D4AC", Offset = "0x293D4AC", VA = "0x293D4AC")]
	private void Ց\u073Dࡘރ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ܘ\u081Aڧو(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06000323 RID: 803 RVA: 0x000143E8 File Offset: 0x000125E8
	[Token(Token = "0x6000323")]
	[Address(RVA = "0x2940198", Offset = "0x2940198", VA = "0x2940198", Slot = "40")]
	public virtual void ӫٷ\u0618ݔ()
	{
	}

	// Token: 0x06000324 RID: 804 RVA: 0x000143F8 File Offset: 0x000125F8
	[Token(Token = "0x6000324")]
	[Address(RVA = "0x294019C", Offset = "0x294019C", VA = "0x294019C", Slot = "41")]
	public virtual void ף\u065Eܥ\u055E()
	{
	}

	// Token: 0x06000325 RID: 805 RVA: 0x00014408 File Offset: 0x00012608
	[Token(Token = "0x6000325")]
	[Address(RVA = "0x29401A0", Offset = "0x29401A0", VA = "0x29401A0", Slot = "42")]
	public virtual void ߄\u086Bݵ\u05A6(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06000326 RID: 806 RVA: 0x00014418 File Offset: 0x00012618
	[Token(Token = "0x6000326")]
	[Address(RVA = "0x293DDD4", Offset = "0x293DDD4", VA = "0x293DDD4")]
	private void \u059Fލࡇث(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ܡ\u0891\u0704\u0670(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06000327 RID: 807 RVA: 0x00014438 File Offset: 0x00012638
	[Token(Token = "0x6000327")]
	[Address(RVA = "0x293D858", Offset = "0x293D858", VA = "0x293D858")]
	private void ܘ\u0746\u05B5ޓ(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ݴ\u0610زճ(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06000328 RID: 808 RVA: 0x00014458 File Offset: 0x00012658
	[Token(Token = "0x6000328")]
	[Address(RVA = "0x2940248", Offset = "0x2940248", VA = "0x2940248")]
	private void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Reason: ";
		Coroutine coroutine = base.StartCoroutine("NoseAttachPoint");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000329 RID: 809 RVA: 0x000144B0 File Offset: 0x000126B0
	[Token(Token = "0x6000329")]
	[Address(RVA = "0x2940370", Offset = "0x2940370", VA = "0x2940370")]
	private void \u07BDՑ\u0832ࠍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ORGTARG";
		Coroutine coroutine = base.StartCoroutine("MetaId");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x0600032A RID: 810 RVA: 0x00014508 File Offset: 0x00012708
	[Token(Token = "0x600032A")]
	[Address(RVA = "0x2940494", Offset = "0x2940494", VA = "0x2940494", Slot = "43")]
	public virtual void \u0735ࡦߗ\u059B(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x0600032B RID: 811 RVA: 0x00014518 File Offset: 0x00012718
	[Token(Token = "0x600032B")]
	[Address(RVA = "0x2940498", Offset = "0x2940498", VA = "0x2940498", Slot = "44")]
	public virtual void ޓբۓ\u06E4()
	{
	}

	// Token: 0x0600032C RID: 812 RVA: 0x00014528 File Offset: 0x00012728
	[Token(Token = "0x600032C")]
	[Address(RVA = "0x294049C", Offset = "0x294049C", VA = "0x294049C")]
	private void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FLSPTLT";
		Coroutine coroutine = base.StartCoroutine("KeyPos");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x0600032D RID: 813 RVA: 0x00014580 File Offset: 0x00012780
	[Token(Token = "0x600032D")]
	[Address(RVA = "0x29405C4", Offset = "0x29405C4", VA = "0x29405C4")]
	private void \u05FD\u06E1\u064Cԕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_BaseColor";
		Coroutine coroutine = base.StartCoroutine("Did Hit");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x0600032E RID: 814 RVA: 0x000145D8 File Offset: 0x000127D8
	[Token(Token = "0x600032E")]
	[Address(RVA = "0x293E11C", Offset = "0x293E11C", VA = "0x293E11C")]
	private void ߨࠊ\u083F\u088C(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ݽݝܬ\u089B(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600032F RID: 815 RVA: 0x000145F8 File Offset: 0x000127F8
	[Token(Token = "0x600032F")]
	[Address(RVA = "0x29406E8", Offset = "0x29406E8", VA = "0x29406E8")]
	private void \u087DىԳܚ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You are not the master of the server, you cannot start the game.";
		Coroutine coroutine = base.StartCoroutine("_Tint");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000330 RID: 816 RVA: 0x00014650 File Offset: 0x00012850
	[Token(Token = "0x6000330")]
	[Address(RVA = "0x2940810", Offset = "0x2940810", VA = "0x2940810")]
	private void \u0884ٿ\u0659ԫ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "Error";
		Coroutine coroutine = base.StartCoroutine("Round end");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000331 RID: 817 RVA: 0x000146A4 File Offset: 0x000128A4
	[Token(Token = "0x6000331")]
	[Address(RVA = "0x2940938", Offset = "0x2940938", VA = "0x2940938")]
	private IEnumerator ࠔג\u0658\u06D9()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x06000332 RID: 818 RVA: 0x000146C0 File Offset: 0x000128C0
	[Token(Token = "0x6000332")]
	[Address(RVA = "0x29409B0", Offset = "0x29409B0", VA = "0x29409B0")]
	private void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not connected to room";
		Coroutine coroutine = base.StartCoroutine("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000333 RID: 819 RVA: 0x00014718 File Offset: 0x00012918
	[Token(Token = "0x6000333")]
	[Address(RVA = "0x2940AD8", Offset = "0x2940AD8", VA = "0x2940AD8")]
	private IEnumerator ՊӇԨࡉ()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 0L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000334 RID: 820 RVA: 0x0001473C File Offset: 0x0001293C
	[Token(Token = "0x6000334")]
	[Address(RVA = "0x2940B50", Offset = "0x2940B50", VA = "0x2940B50", Slot = "45")]
	public virtual void \u081Fӵהؠ()
	{
	}

	// Token: 0x06000335 RID: 821 RVA: 0x0001474C File Offset: 0x0001294C
	[Token(Token = "0x6000335")]
	[Address(RVA = "0x2940B54", Offset = "0x2940B54", VA = "0x2940B54", Slot = "46")]
	public virtual void Ҽ\u0612ք\u0731(bool \u089Bݼۄ\u0875)
	{
	}

	// Token: 0x06000336 RID: 822 RVA: 0x0001475C File Offset: 0x0001295C
	[Token(Token = "0x6000336")]
	[Address(RVA = "0x2940B58", Offset = "0x2940B58", VA = "0x2940B58", Slot = "47")]
	public virtual void شߣآ\u05BC()
	{
	}

	// Token: 0x06000337 RID: 823 RVA: 0x0001476C File Offset: 0x0001296C
	[Token(Token = "0x6000337")]
	[Address(RVA = "0x2940B5C", Offset = "0x2940B5C", VA = "0x2940B5C")]
	private void րۀ\u0701ԝ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "procedural animation script required on ";
		Coroutine coroutine = base.StartCoroutine("Joined a Room.");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000338 RID: 824 RVA: 0x000147C4 File Offset: 0x000129C4
	[Token(Token = "0x6000338")]
	[Address(RVA = "0x2940C80", Offset = "0x2940C80", VA = "0x2940C80", Slot = "48")]
	public virtual void ٷټسࡇ()
	{
	}

	// Token: 0x06000339 RID: 825 RVA: 0x000147D4 File Offset: 0x000129D4
	[Token(Token = "0x6000339")]
	[Address(RVA = "0x2940C84", Offset = "0x2940C84", VA = "0x2940C84")]
	private void ܯר\u05C7ڗ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "{0} ({1})";
		Coroutine coroutine = base.StartCoroutine("containsStaff");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x0600033A RID: 826 RVA: 0x0001482C File Offset: 0x00012A2C
	[Token(Token = "0x600033A")]
	[Address(RVA = "0x2940DAC", Offset = "0x2940DAC", VA = "0x2940DAC")]
	private IEnumerator ڹ\u05AF\u058B\u0734()
	{
		long <>1__state;
		CapuchinButton.ࢦ\u066Bӝ\u05FA ࢦ_u066Bӝ_u05FA = new CapuchinButton.ࢦ\u066Bӝ\u05FA((int)<>1__state);
		<>1__state = 0L;
		ࢦ_u066Bӝ_u05FA.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600033B RID: 827 RVA: 0x00014850 File Offset: 0x00012A50
	[Token(Token = "0x600033B")]
	[Address(RVA = "0x293CD8C", Offset = "0x293CD8C", VA = "0x293CD8C")]
	private void \u0885\u07B3Մ\u0739(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		IEnumerator routine = this.ݽݝܬ\u089B(ޡ\u082Dղӝ, ի\u0888\u07EF\u0839, ةݞ\u0838١);
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600033C RID: 828 RVA: 0x00014870 File Offset: 0x00012A70
	[Token(Token = "0x600033C")]
	[Address(RVA = "0x2940E24", Offset = "0x2940E24", VA = "0x2940E24", Slot = "49")]
	public virtual void ב߅߃\u07B6()
	{
	}

	// Token: 0x0600033D RID: 829 RVA: 0x00014880 File Offset: 0x00012A80
	[Token(Token = "0x600033D")]
	[Address(RVA = "0x2940E28", Offset = "0x2940E28", VA = "0x2940E28")]
	private void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Connected to Server.";
		Coroutine coroutine = base.StartCoroutine("monke screamed");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		IEnumerator routine;
		Coroutine coroutine2 = base.StartCoroutine(routine);
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x0600033E RID: 830 RVA: 0x000148D8 File Offset: 0x00012AD8
	[Token(Token = "0x600033E")]
	[Address(RVA = "0x29401A4", Offset = "0x29401A4", VA = "0x29401A4")]
	private IEnumerator ܡ\u0891\u0704\u0670(bool ޡ\u082Dղӝ, float ի\u0888\u07EF\u0839, float ةݞ\u0838١)
	{
		long <>1__state;
		CapuchinButton.ӰԲ\u07FB\u0594 ӱբ_u07FB_u = new CapuchinButton.ӰԲ\u07FB\u0594((int)<>1__state);
		<>1__state = 0L;
		ӱբ_u07FB_u.<>4__this = this;
		ӱբ_u07FB_u.forLeftController = (typeof(CapuchinButton.ӰԲ\u07FB\u0594).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600033F RID: 831 RVA: 0x00014908 File Offset: 0x00012B08
	[Token(Token = "0x600033F")]
	[Address(RVA = "0x2940F4C", Offset = "0x2940F4C", VA = "0x2940F4C")]
	private void \u05AD\u0881ࡆݡ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		Coroutine coroutine = base.StartCoroutine("TurnAmount");
		bool u089Bݼۄ_u = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
		bool u089Bݼۄ_u2 = \u07FEל\u05AC\u0877.GetComponent<PhysicsHand>().\u089Bݼۄ\u0875;
	}

	// Token: 0x06000340 RID: 832 RVA: 0x00014950 File Offset: 0x00012B50
	[Token(Token = "0x6000340")]
	[Address(RVA = "0x2941070", Offset = "0x2941070", VA = "0x2941070", Slot = "50")]
	public virtual void ޖӰڵ\u0872()
	{
	}

	// Token: 0x0400005C RID: 92
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400005C")]
	private float \u087C\u0593Ӛ\u07A6 = (float)52429;
}
