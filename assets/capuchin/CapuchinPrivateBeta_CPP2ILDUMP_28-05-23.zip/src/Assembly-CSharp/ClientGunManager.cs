﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020000A4 RID: 164
[Token(Token = "0x20000A4")]
public class ClientGunManager : MonoBehaviour
{
	// Token: 0x0600183E RID: 6206 RVA: 0x00085AFC File Offset: 0x00083CFC
	[Token(Token = "0x600183E")]
	[Address(RVA = "0x294847C", Offset = "0x294847C", VA = "0x294847C")]
	public void ރڣ߄ٶ()
	{
		this.\u0657ӴԾޗ();
		this.\u0670ࠏ\u0704ک();
	}

	// Token: 0x0600183F RID: 6207 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600183F")]
	[Address(RVA = "0x294877C", Offset = "0x294877C", VA = "0x294877C")]
	private void \u0833\u07FBӲ\u07F6()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001840 RID: 6208 RVA: 0x00085B18 File Offset: 0x00083D18
	[Token(Token = "0x6001840")]
	[Address(RVA = "0x29488F4", Offset = "0x29488F4", VA = "0x29488F4")]
	public void Քڜ\u070D\u0884()
	{
		this.ࡤ\u086Cݛ\u06E7();
	}

	// Token: 0x06001841 RID: 6209 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001841")]
	[Address(RVA = "0x2948B80", Offset = "0x2948B80", VA = "0x2948B80")]
	private void ӓӬ\u0742ߚ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001842 RID: 6210 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001842")]
	[Address(RVA = "0x2948CF8", Offset = "0x2948CF8", VA = "0x2948CF8")]
	private void ۮڵ\u06D9Ӝ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001843 RID: 6211 RVA: 0x00085B2C File Offset: 0x00083D2C
	[Token(Token = "0x6001843")]
	[Address(RVA = "0x2948E70", Offset = "0x2948E70", VA = "0x2948E70")]
	public void ב\u087E\u07B5ԋ()
	{
		this.Յؤӯԏ();
		this.ࢬ\u07AFڗր();
	}

	// Token: 0x06001844 RID: 6212 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001844")]
	[Address(RVA = "0x29491A4", Offset = "0x29491A4", VA = "0x29491A4")]
	private void ݕ߁\u0597ݯ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001845 RID: 6213 RVA: 0x00085B48 File Offset: 0x00083D48
	[Token(Token = "0x6001845")]
	[Address(RVA = "0x294931C", Offset = "0x294931C", VA = "0x294931C")]
	public void \u0603ܘڭࡥ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("Faild To Add Winner Money: ");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x06001846 RID: 6214 RVA: 0x00085C00 File Offset: 0x00083E00
	[Token(Token = "0x6001846")]
	[Address(RVA = "0x29495A4", Offset = "0x29495A4", VA = "0x29495A4")]
	public void մ\u082Fԑ۱()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001847 RID: 6215 RVA: 0x00085C40 File Offset: 0x00083E40
	[Token(Token = "0x6001847")]
	[Address(RVA = "0x2949608", Offset = "0x2949608", VA = "0x2949608")]
	public void \u0822\u0610\u081A\u07BF()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("DisableCosmetic");
	}

	// Token: 0x06001848 RID: 6216 RVA: 0x00085CE8 File Offset: 0x00083EE8
	[Token(Token = "0x6001848")]
	[Address(RVA = "0x29498A4", Offset = "0x29498A4", VA = "0x29498A4")]
	public void ڱۊӆھ()
	{
		this.\u0670ࠏ\u0704ک();
	}

	// Token: 0x06001849 RID: 6217 RVA: 0x00085CFC File Offset: 0x00083EFC
	[Token(Token = "0x6001849")]
	[Address(RVA = "0x29498A8", Offset = "0x29498A8", VA = "0x29498A8")]
	public void \u0740ߛڕࡥ()
	{
		this.ވ\u058F\u07BD\u0598();
		this.ߖࡠ\u082Bࠃ();
	}

	// Token: 0x0600184A RID: 6218 RVA: 0x00085D18 File Offset: 0x00083F18
	[Token(Token = "0x600184A")]
	[Address(RVA = "0x2949BCC", Offset = "0x2949BCC", VA = "0x2949BCC")]
	public void \u064Fڬؠ\u0700()
	{
		this.\u0670ࠏ\u0704ک();
	}

	// Token: 0x0600184B RID: 6219 RVA: 0x00085D2C File Offset: 0x00083F2C
	[Token(Token = "0x600184B")]
	[Address(RVA = "0x2949BD0", Offset = "0x2949BD0", VA = "0x2949BD0")]
	public void Ӭ\u06E3ӿ\u0706()
	{
		this.\u0700\u0604߅\u07A7();
	}

	// Token: 0x0600184C RID: 6220 RVA: 0x00085D40 File Offset: 0x00083F40
	[Token(Token = "0x600184C")]
	[Address(RVA = "0x2949E80", Offset = "0x2949E80", VA = "0x2949E80")]
	public void \u05B3\u0657ل\u0707()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("Body");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x0600184D RID: 6221 RVA: 0x00085E00 File Offset: 0x00084000
	[Token(Token = "0x600184D")]
	[Address(RVA = "0x29498CC", Offset = "0x29498CC", VA = "0x29498CC")]
	public void ވ\u058F\u07BD\u0598()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x0600184E RID: 6222 RVA: 0x00085E40 File Offset: 0x00084040
	[Token(Token = "0x600184E")]
	[Address(RVA = "0x294A130", Offset = "0x294A130", VA = "0x294A130")]
	public void \u08B5ػ߀ܢ()
	{
		this.ԣڸܨ\u065D();
		this.կܙՆݠ();
	}

	// Token: 0x0600184F RID: 6223 RVA: 0x00085E5C File Offset: 0x0008405C
	[Token(Token = "0x600184F")]
	[Address(RVA = "0x294A464", Offset = "0x294A464", VA = "0x294A464")]
	public void ߪ\u07FEܞ\u06DC()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001850 RID: 6224 RVA: 0x00085E9C File Offset: 0x0008409C
	[Token(Token = "0x6001850")]
	[Address(RVA = "0x294A4C8", Offset = "0x294A4C8", VA = "0x294A4C8")]
	public void \u0898\u07F3ޗ\u087A()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("A Player has left the Room.");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x06001851 RID: 6225 RVA: 0x00085F4C File Offset: 0x0008414C
	[Token(Token = "0x6001851")]
	[Address(RVA = "0x294A74C", Offset = "0x294A74C", VA = "0x294A74C")]
	public void ࢣ\u0746کל()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001852 RID: 6226 RVA: 0x00085F8C File Offset: 0x0008418C
	[Token(Token = "0x6001852")]
	[Address(RVA = "0x294A7B0", Offset = "0x294A7B0", VA = "0x294A7B0")]
	public void ܫעԌץ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001853 RID: 6227 RVA: 0x00085FCC File Offset: 0x000841CC
	[Token(Token = "0x6001853")]
	[Address(RVA = "0x294A814", Offset = "0x294A814", VA = "0x294A814")]
	public void \u070F\u0653ݾԙ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001854 RID: 6228 RVA: 0x0008600C File Offset: 0x0008420C
	[Token(Token = "0x6001854")]
	[Address(RVA = "0x294A878", Offset = "0x294A878", VA = "0x294A878")]
	private void \u0590\u0882\u0883ࡦ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("FingerTip").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			long num = 1L;
			this.\u07AC\u06E3߉տ = (num != 0L);
			this.ӓӬ\u0742ߚ();
			this.\u05C4\u05A1\u070Cڗ = (num != 0L);
		}
		long u05C4_u05A1_u070Cڗ = 1L;
		this.\u05C4\u05A1\u070Cڗ = (u05C4_u05A1_u070Cڗ != 0L);
		if (this.\u07AC\u06E3߉տ && this != null)
		{
			return;
		}
	}

	// Token: 0x06001855 RID: 6229 RVA: 0x00086088 File Offset: 0x00084288
	[Token(Token = "0x6001855")]
	[Address(RVA = "0x294AAF0", Offset = "0x294AAF0", VA = "0x294AAF0")]
	public void \u05C0\u06DDࢮ\u0898()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001856 RID: 6230 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001856")]
	[Address(RVA = "0x294AB54", Offset = "0x294AB54", VA = "0x294AB54")]
	private void ࢻԩڪࡐ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001857 RID: 6231 RVA: 0x000860C8 File Offset: 0x000842C8
	[Token(Token = "0x6001857")]
	[Address(RVA = "0x294ACCC", Offset = "0x294ACCC", VA = "0x294ACCC")]
	public void ڐۑ\u05EDӹ()
	{
		this.طٻ٩\u05C6();
		this.քӐ߃\u0748();
	}

	// Token: 0x06001858 RID: 6232 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001858")]
	[Address(RVA = "0x294AFF0", Offset = "0x294AFF0", VA = "0x294AFF0")]
	private void ڬ\u07EB\u0747ս()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001859 RID: 6233 RVA: 0x000860E4 File Offset: 0x000842E4
	[Token(Token = "0x6001859")]
	[Address(RVA = "0x294B168", Offset = "0x294B168", VA = "0x294B168")]
	public void ۶\u061Cߓԍ()
	{
		this.ײڈޜߦ();
		this.Ԁ\u064B\u070Aӳ();
	}

	// Token: 0x0600185A RID: 6234 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600185A")]
	[Address(RVA = "0x294B49C", Offset = "0x294B49C", VA = "0x294B49C")]
	private void ݓ\u0530\u0895Գ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600185B RID: 6235 RVA: 0x00086100 File Offset: 0x00084300
	[Token(Token = "0x600185B")]
	[Address(RVA = "0x294B614", Offset = "0x294B614", VA = "0x294B614")]
	public void \u0817\u0730քࠔ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x0600185C RID: 6236 RVA: 0x00086140 File Offset: 0x00084340
	[Token(Token = "0x600185C")]
	[Address(RVA = "0x294B678", Offset = "0x294B678", VA = "0x294B678")]
	private void \u087BӦןݩ()
	{
		if (true)
		{
			TextMeshPro component = GameObject.Find("PlayerHead").GetComponent<TextMeshPro>();
		}
		InputDevice inputDevice;
		if (inputDevice == null)
		{
		}
	}

	// Token: 0x0600185D RID: 6237 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600185D")]
	[Address(RVA = "0x294B8F4", Offset = "0x294B8F4", VA = "0x294B8F4")]
	private void ڐԥ\u055A\u07BF()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600185E RID: 6238 RVA: 0x0008616C File Offset: 0x0008436C
	[Token(Token = "0x600185E")]
	[Address(RVA = "0x294BA6C", Offset = "0x294BA6C", VA = "0x294BA6C")]
	public void ט\u05AEࡃڠ()
	{
		this.\u081DلӨٱ();
	}

	// Token: 0x0600185F RID: 6239 RVA: 0x00086180 File Offset: 0x00084380
	[Token(Token = "0x600185F")]
	[Address(RVA = "0x294BD10", Offset = "0x294BD10", VA = "0x294BD10")]
	public void \u07FAޚ\u087Eڃ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001860 RID: 6240 RVA: 0x000861C0 File Offset: 0x000843C0
	[Token(Token = "0x6001860")]
	[Address(RVA = "0x294BD74", Offset = "0x294BD74", VA = "0x294BD74")]
	public void ܠݳӸӨ()
	{
		this.\u06E2ܩ\u085Fࡆ();
		this.\u081DلӨٱ();
	}

	// Token: 0x06001861 RID: 6241 RVA: 0x000861DC File Offset: 0x000843DC
	[Token(Token = "0x6001861")]
	[Address(RVA = "0x29484A0", Offset = "0x29484A0", VA = "0x29484A0")]
	public void \u0657ӴԾޗ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001862 RID: 6242 RVA: 0x0008621C File Offset: 0x0008441C
	[Token(Token = "0x6001862")]
	[Address(RVA = "0x2949930", Offset = "0x2949930", VA = "0x2949930")]
	public void ߖࡠ\u082Bࠃ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("Connected to Server.");
	}

	// Token: 0x06001863 RID: 6243 RVA: 0x000862C4 File Offset: 0x000844C4
	[Token(Token = "0x6001863")]
	[Address(RVA = "0x294BDFC", Offset = "0x294BDFC", VA = "0x294BDFC")]
	public void \u07FE\u087F\u05FFׯ()
	{
		this.ۄݺ٢\u0740();
		this.կܙՆݠ();
	}

	// Token: 0x06001864 RID: 6244 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001864")]
	[Address(RVA = "0x294BE84", Offset = "0x294BE84", VA = "0x294BE84")]
	private void ض\u0887ࠍڇ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001865 RID: 6245 RVA: 0x000862E0 File Offset: 0x000844E0
	[Token(Token = "0x6001865")]
	[Address(RVA = "0x294BFFC", Offset = "0x294BFFC", VA = "0x294BFFC")]
	public void ټՕցՈ()
	{
		this.ګڵ\u0595ԕ();
		this.Ԁ\u064B\u070Aӳ();
	}

	// Token: 0x06001866 RID: 6246 RVA: 0x000862FC File Offset: 0x000844FC
	[Token(Token = "0x6001866")]
	[Address(RVA = "0x294C084", Offset = "0x294C084", VA = "0x294C084")]
	public void ޛٱ\u087Aڴ()
	{
		this.ߕ\u0885Ԥӽ();
		this.ࡤ\u086Cݛ\u06E7();
	}

	// Token: 0x06001867 RID: 6247 RVA: 0x00086318 File Offset: 0x00084518
	[Token(Token = "0x6001867")]
	[Address(RVA = "0x294C10C", Offset = "0x294C10C", VA = "0x294C10C")]
	public void ߏدԬ\u05FC()
	{
		this.Ҽ\u07F3ԛխ();
		this.քӐ߃\u0748();
	}

	// Token: 0x06001868 RID: 6248 RVA: 0x00086334 File Offset: 0x00084534
	[Token(Token = "0x6001868")]
	[Address(RVA = "0x294C194", Offset = "0x294C194", VA = "0x294C194")]
	public void \u070E\u06DDךࡎ()
	{
		this.\u0879ي\u0897ػ();
	}

	// Token: 0x06001869 RID: 6249 RVA: 0x00086348 File Offset: 0x00084548
	[Token(Token = "0x6001869")]
	[Address(RVA = "0x294C198", Offset = "0x294C198", VA = "0x294C198")]
	public void \u0879ي\u0897ػ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("On");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x0600186A RID: 6250 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600186A")]
	[Address(RVA = "0x294C41C", Offset = "0x294C41C", VA = "0x294C41C")]
	private void ߍڷߎՑ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600186B RID: 6251 RVA: 0x000863F8 File Offset: 0x000845F8
	[Token(Token = "0x600186B")]
	[Address(RVA = "0x294C814", Offset = "0x294C814", VA = "0x294C814")]
	private void \u085Dل\u07FBࡊ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			this.ݗ\u0705\u060CӘ();
		}
		long u05C4_u05A1_u070Cڗ = 1L;
		this.\u05C4\u05A1\u070Cڗ = (u05C4_u05A1_u070Cڗ != 0L);
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600186C RID: 6252 RVA: 0x0008646C File Offset: 0x0008466C
	[Token(Token = "0x600186C")]
	[Address(RVA = "0x294CA88", Offset = "0x294CA88", VA = "0x294CA88")]
	public void Րڂӕ\u088B()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x0600186D RID: 6253 RVA: 0x000864AC File Offset: 0x000846AC
	[Token(Token = "0x600186D")]
	[Address(RVA = "0x294CAEC", Offset = "0x294CAEC", VA = "0x294CAEC")]
	private void \u0836\u089Dی\u0735()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("\n Time: ").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			long u07AC_u06E3߉տ = 1L;
			this.\u07AC\u06E3߉տ = (u07AC_u06E3߉տ != 0L);
			this.ڐ\u0899\u061B\u0591();
		}
		if (this.\u07AC\u06E3߉տ)
		{
			bool <IsMine>k__BackingField = this.ޣߑԤࡩ.<IsMine>k__BackingField;
			return;
		}
	}

	// Token: 0x0600186E RID: 6254 RVA: 0x00086520 File Offset: 0x00084720
	[Token(Token = "0x600186E")]
	[Address(RVA = "0x294CED8", Offset = "0x294CED8", VA = "0x294CED8")]
	public void \u070Aۼ\u05CC\u05C2()
	{
		this.\u0700\u0604߅\u07A7();
	}

	// Token: 0x0600186F RID: 6255 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600186F")]
	[Address(RVA = "0x294CEDC", Offset = "0x294CEDC", VA = "0x294CEDC")]
	private void Ռࡆ\u07BE\u06E0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001870 RID: 6256 RVA: 0x00086534 File Offset: 0x00084734
	[Token(Token = "0x6001870")]
	[Address(RVA = "0x294D054", Offset = "0x294D054", VA = "0x294D054")]
	public void ӣࢣܣӦ()
	{
		this.\u0817\u0730քࠔ();
		this.\u081DلӨٱ();
	}

	// Token: 0x06001871 RID: 6257 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001871")]
	[Address(RVA = "0x294D078", Offset = "0x294D078", VA = "0x294D078")]
	private void Ԡࢻࢸנ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001872 RID: 6258 RVA: 0x00086550 File Offset: 0x00084750
	[Token(Token = "0x6001872")]
	[Address(RVA = "0x294D1F0", Offset = "0x294D1F0", VA = "0x294D1F0")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("Diffuse").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			this.ݗ\u0705\u060CӘ();
			long u05C4_u05A1_u070Cڗ = 1L;
			this.\u05C4\u05A1\u070Cڗ = (u05C4_u05A1_u070Cڗ != 0L);
		}
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06001873 RID: 6259 RVA: 0x000865C4 File Offset: 0x000847C4
	[Token(Token = "0x6001873")]
	[Address(RVA = "0x294AD54", Offset = "0x294AD54", VA = "0x294AD54")]
	public void քӐ߃\u0748()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("Starting to bake textures on frame ");
	}

	// Token: 0x06001874 RID: 6260 RVA: 0x00086664 File Offset: 0x00084864
	[Token(Token = "0x6001874")]
	[Address(RVA = "0x294D46C", Offset = "0x294D46C", VA = "0x294D46C")]
	public void ߑ\u061Fڼ\u085F()
	{
		this.\u0711ࢸڨ\u081A();
		this.քӐ߃\u0748();
	}

	// Token: 0x06001875 RID: 6261 RVA: 0x00086680 File Offset: 0x00084880
	[Token(Token = "0x6001875")]
	[Address(RVA = "0x294D4F4", Offset = "0x294D4F4", VA = "0x294D4F4")]
	public void ىԼ\u0670ں()
	{
		this.\u0700\u0604߅\u07A7();
	}

	// Token: 0x06001876 RID: 6262 RVA: 0x00086694 File Offset: 0x00084894
	[Token(Token = "0x6001876")]
	[Address(RVA = "0x294ACF0", Offset = "0x294ACF0", VA = "0x294ACF0")]
	public void طٻ٩\u05C6()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001877 RID: 6263 RVA: 0x000866D4 File Offset: 0x000848D4
	[Token(Token = "0x6001877")]
	[Address(RVA = "0x294D4F8", Offset = "0x294D4F8", VA = "0x294D4F8")]
	private void չւت\u061E()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("PlayerHead").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			this.ӓӬ\u0742ߚ();
			long u05C4_u05A1_u070Cڗ = 1L;
			this.\u05C4\u05A1\u070Cڗ = (u05C4_u05A1_u070Cڗ != 0L);
		}
		long u05C4_u05A1_u070Cڗ2 = 1L;
		this.\u05C4\u05A1\u070Cڗ = (u05C4_u05A1_u070Cڗ2 != 0L);
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06001878 RID: 6264 RVA: 0x00086750 File Offset: 0x00084950
	[Token(Token = "0x6001878")]
	[Address(RVA = "0x294D770", Offset = "0x294D770", VA = "0x294D770")]
	public void Ӻࢯ\u0886ޒ()
	{
		this.ࠉࡃմ\u06E4();
		this.\u0603ܘڭࡥ();
	}

	// Token: 0x06001879 RID: 6265 RVA: 0x0008676C File Offset: 0x0008496C
	[Token(Token = "0x6001879")]
	[Address(RVA = "0x294D7F8", Offset = "0x294D7F8", VA = "0x294D7F8")]
	[PunRPC]
	public void NetworkGunShoot()
	{
		this.\u0835Ե\u0872\u065F();
		this.ࢬ\u07AFڗր();
	}

	// Token: 0x0600187A RID: 6266 RVA: 0x00086788 File Offset: 0x00084988
	[Token(Token = "0x600187A")]
	[Address(RVA = "0x294D880", Offset = "0x294D880", VA = "0x294D880")]
	private void ׯࠋ\u060C۰()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("Charging...").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			this.ށ\u05B9Ԭ\u07B0();
		}
		long u05C4_u05A1_u070Cڗ = 1L;
		this.\u05C4\u05A1\u070Cڗ = (u05C4_u05A1_u070Cڗ != 0L);
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600187B RID: 6267 RVA: 0x000867FC File Offset: 0x000849FC
	[Token(Token = "0x600187B")]
	[Address(RVA = "0x294DC6C", Offset = "0x294DC6C", VA = "0x294DC6C")]
	public void ӈݟ\u0530ࠈ()
	{
		this.\u0822\u0610\u081A\u07BF();
	}

	// Token: 0x0600187C RID: 6268 RVA: 0x00086810 File Offset: 0x00084A10
	[Token(Token = "0x600187C")]
	[Address(RVA = "0x294DC70", Offset = "0x294DC70", VA = "0x294DC70")]
	public void \u060D\u083Fࢮ\u088D()
	{
		this.ߪ\u07FEܞ\u06DC();
		this.ڥԸ\u0618ࢮ();
	}

	// Token: 0x0600187D RID: 6269 RVA: 0x0008682C File Offset: 0x00084A2C
	[Token(Token = "0x600187D")]
	[Address(RVA = "0x294DF08", Offset = "0x294DF08", VA = "0x294DF08")]
	public void ݍלٷ\u058E()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x0600187E RID: 6270 RVA: 0x0008686C File Offset: 0x00084A6C
	[Token(Token = "0x600187E")]
	[Address(RVA = "0x294DF6C", Offset = "0x294DF6C", VA = "0x294DF6C")]
	public void ي\u05F3\u086Cݱ()
	{
		this.ڥԸ\u0618ࢮ();
	}

	// Token: 0x0600187F RID: 6271 RVA: 0x00086880 File Offset: 0x00084A80
	[Token(Token = "0x600187F")]
	[Address(RVA = "0x294DF70", Offset = "0x294DF70", VA = "0x294DF70")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			throw new MissingMethodException();
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		long u07AC_u06E3߉տ = 1L;
		this.\u07AC\u06E3߉տ = (u07AC_u06E3߉տ != 0L);
		this.ڬ\u07EB\u0747ս();
		long u05C4_u05A1_u070Cڗ = 1L;
		this.\u05C4\u05A1\u070Cڗ = (u05C4_u05A1_u070Cڗ != 0L);
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06001880 RID: 6272 RVA: 0x000868FC File Offset: 0x00084AFC
	[Token(Token = "0x6001880")]
	[Address(RVA = "0x294E1F0", Offset = "0x294E1F0", VA = "0x294E1F0")]
	public void \u06DA\u055BՋږ()
	{
		this.քӐ߃\u0748();
	}

	// Token: 0x06001881 RID: 6273 RVA: 0x00086910 File Offset: 0x00084B10
	[Token(Token = "0x6001881")]
	[Address(RVA = "0x294E1F4", Offset = "0x294E1F4", VA = "0x294E1F4")]
	[PunRPC]
	public void NGNNoSound()
	{
		this.ࢬ\u07AFڗր();
	}

	// Token: 0x06001882 RID: 6274 RVA: 0x00086924 File Offset: 0x00084B24
	[Token(Token = "0x6001882")]
	[Address(RVA = "0x294BA70", Offset = "0x294BA70", VA = "0x294BA70")]
	public void \u081DلӨٱ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("User has been reported for: ");
	}

	// Token: 0x06001883 RID: 6275 RVA: 0x000869D4 File Offset: 0x00084BD4
	[Token(Token = "0x6001883")]
	[Address(RVA = "0x294E1F8", Offset = "0x294E1F8", VA = "0x294E1F8")]
	public void Ӎ\u07F6\u081Eخ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x06001884 RID: 6276 RVA: 0x00086A74 File Offset: 0x00084C74
	[Token(Token = "0x6001884")]
	[Address(RVA = "0x294E47C", Offset = "0x294E47C", VA = "0x294E47C")]
	public void \u0600ܓ\u06DDב()
	{
		this.ߪ\u07FEܞ\u06DC();
		this.ט\u060E\u089B\u07F8();
	}

	// Token: 0x06001885 RID: 6277 RVA: 0x00086A90 File Offset: 0x00084C90
	[Token(Token = "0x6001885")]
	[Address(RVA = "0x294E74C", Offset = "0x294E74C", VA = "0x294E74C")]
	private void \u0829\u05FDژտ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("ChangeToTagged").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			this.ࢻԩڪࡐ();
		}
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06001886 RID: 6278 RVA: 0x00086AF8 File Offset: 0x00084CF8
	[Token(Token = "0x6001886")]
	[Address(RVA = "0x294E9BC", Offset = "0x294E9BC", VA = "0x294E9BC")]
	public void \u05C1ӷԂߜ()
	{
		this.\u06E2ܩ\u085Fࡆ();
		this.\u0603ܘڭࡥ();
	}

	// Token: 0x06001887 RID: 6279 RVA: 0x00086B14 File Offset: 0x00084D14
	[Token(Token = "0x6001887")]
	[Address(RVA = "0x294E9E0", Offset = "0x294E9E0", VA = "0x294E9E0")]
	public void \u06DE\u05ABӃ\u073E()
	{
		this.\u081DلӨٱ();
	}

	// Token: 0x06001888 RID: 6280 RVA: 0x00086B28 File Offset: 0x00084D28
	[Token(Token = "0x6001888")]
	[Address(RVA = "0x294C020", Offset = "0x294C020", VA = "0x294C020")]
	public void ګڵ\u0595ԕ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001889 RID: 6281 RVA: 0x00086B68 File Offset: 0x00084D68
	[Token(Token = "0x6001889")]
	[Address(RVA = "0x294DC94", Offset = "0x294DC94", VA = "0x294DC94")]
	public void ڥԸ\u0618ࢮ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("PURCHASED");
	}

	// Token: 0x0600188A RID: 6282 RVA: 0x00086C00 File Offset: 0x00084E00
	[Token(Token = "0x600188A")]
	[Address(RVA = "0x294B18C", Offset = "0x294B18C", VA = "0x294B18C")]
	public void ײڈޜߦ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x0600188B RID: 6283 RVA: 0x00086C40 File Offset: 0x00084E40
	[Token(Token = "0x600188B")]
	[Address(RVA = "0x294E9E4", Offset = "0x294E9E4", VA = "0x294E9E4")]
	public void \u07AAԣԝٳ()
	{
		this.\u0657ӴԾޗ();
		this.\u065Bܘۏט();
	}

	// Token: 0x0600188C RID: 6284 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600188C")]
	[Address(RVA = "0x294ECB4", Offset = "0x294ECB4", VA = "0x294ECB4")]
	private void \u06D6ҿ\u0616\u089B()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600188D RID: 6285 RVA: 0x00086C5C File Offset: 0x00084E5C
	[Token(Token = "0x600188D")]
	[Address(RVA = "0x294D794", Offset = "0x294D794", VA = "0x294D794")]
	public void ࠉࡃմ\u06E4()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x0600188E RID: 6286 RVA: 0x00086C94 File Offset: 0x00084E94
	[Token(Token = "0x600188E")]
	[Address(RVA = "0x294EE2C", Offset = "0x294EE2C", VA = "0x294EE2C")]
	private void \u07A8ڣ\u0896\u06FE()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("_BumpMap").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			long num = 1L;
			this.\u07AC\u06E3߉տ = (num != 0L);
			this.ڐ\u0899\u061B\u0591();
			this.\u05C4\u05A1\u070Cڗ = (num != 0L);
		}
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600188F RID: 6287 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600188F")]
	[Address(RVA = "0x294F0A0", Offset = "0x294F0A0", VA = "0x294F0A0")]
	private void Ԙڣ\u085Fԁ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001890 RID: 6288 RVA: 0x00086D0C File Offset: 0x00084F0C
	[Token(Token = "0x6001890")]
	[Address(RVA = "0x294A154", Offset = "0x294A154", VA = "0x294A154")]
	public void ԣڸܨ\u065D()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001891 RID: 6289 RVA: 0x00086D4C File Offset: 0x00084F4C
	[Token(Token = "0x6001891")]
	[Address(RVA = "0x294F218", Offset = "0x294F218", VA = "0x294F218")]
	public void ࡦڝ\u0884ܛ()
	{
		this.\u0884ݑӀ\u085C();
	}

	// Token: 0x06001892 RID: 6290 RVA: 0x00086D60 File Offset: 0x00084F60
	[Token(Token = "0x6001892")]
	[Address(RVA = "0x294F494", Offset = "0x294F494", VA = "0x294F494")]
	public void ࢥզԥ\u05F7()
	{
		this.ߕ\u0885Ԥӽ();
		this.քӐ߃\u0748();
	}

	// Token: 0x06001893 RID: 6291 RVA: 0x00086D7C File Offset: 0x00084F7C
	[Token(Token = "0x6001893")]
	[Address(RVA = "0x294F4B8", Offset = "0x294F4B8", VA = "0x294F4B8")]
	private void ڈՓ\u0652\u0871()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("got funky mone").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			long u07AC_u06E3߉տ = 1L;
			this.\u07AC\u06E3߉տ = (u07AC_u06E3߉տ != 0L);
			this.ݓ\u0530\u0895Գ();
		}
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06001894 RID: 6292 RVA: 0x00086DF0 File Offset: 0x00084FF0
	[Token(Token = "0x6001894")]
	[Address(RVA = "0x294F72C", Offset = "0x294F72C", VA = "0x294F72C")]
	public void ߒءי\u07FB()
	{
		this.ߖࡠ\u082Bࠃ();
	}

	// Token: 0x06001895 RID: 6293 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001895")]
	[Address(RVA = "0x294DAF4", Offset = "0x294DAF4", VA = "0x294DAF4")]
	private void ށ\u05B9Ԭ\u07B0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001896 RID: 6294 RVA: 0x00086E04 File Offset: 0x00085004
	[Token(Token = "0x6001896")]
	[Address(RVA = "0x294F730", Offset = "0x294F730", VA = "0x294F730")]
	public void Ռݞ\u065Eۅ()
	{
		this.\u0603ܘڭࡥ();
	}

	// Token: 0x06001897 RID: 6295 RVA: 0x00086E18 File Offset: 0x00085018
	[Token(Token = "0x6001897")]
	[Address(RVA = "0x294D490", Offset = "0x294D490", VA = "0x294D490")]
	public void \u0711ࢸڨ\u081A()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06001898 RID: 6296 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001898")]
	[Address(RVA = "0x294F734", Offset = "0x294F734", VA = "0x294F734")]
	private void \u059Cܯ\u0880ڬ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001899 RID: 6297 RVA: 0x00086E58 File Offset: 0x00085058
	[Token(Token = "0x6001899")]
	[Address(RVA = "0x294F8AC", Offset = "0x294F8AC", VA = "0x294F8AC")]
	public void \u073Fԥ\u0836ࠑ()
	{
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
	}

	// Token: 0x0600189A RID: 6298 RVA: 0x00086E7C File Offset: 0x0008507C
	[Token(Token = "0x600189A")]
	[Address(RVA = "0x294F910", Offset = "0x294F910", VA = "0x294F910")]
	private void ؼ\u0824ۍݟ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("You are not the master of the server, you cannot start the game.").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			this.ࠊ\u05C2ضࢡ();
		}
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600189B RID: 6299 RVA: 0x00086EE4 File Offset: 0x000850E4
	[Token(Token = "0x600189B")]
	[Address(RVA = "0x294C130", Offset = "0x294C130", VA = "0x294C130")]
	public void Ҽ\u07F3ԛխ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x0600189C RID: 6300 RVA: 0x00086F24 File Offset: 0x00085124
	[Token(Token = "0x600189C")]
	[Address(RVA = "0x294BE20", Offset = "0x294BE20", VA = "0x294BE20")]
	public void ۄݺ٢\u0740()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x0600189D RID: 6301 RVA: 0x00086F64 File Offset: 0x00085164
	[Token(Token = "0x600189D")]
	[Address(RVA = "0x294FD00", Offset = "0x294FD00", VA = "0x294FD00")]
	public void \u064C\u05BEࠁ\u0737()
	{
		this.\u0700\u0604߅\u07A7();
	}

	// Token: 0x0600189E RID: 6302 RVA: 0x00086F78 File Offset: 0x00085178
	[Token(Token = "0x600189E")]
	[Address(RVA = "0x294FD04", Offset = "0x294FD04", VA = "0x294FD04")]
	public void ڃ\u0730ࢠ\u0829()
	{
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("True");
	}

	// Token: 0x0600189F RID: 6303 RVA: 0x00087014 File Offset: 0x00085214
	[Token(Token = "0x600189F")]
	[Address(RVA = "0x294FFA0", Offset = "0x294FFA0", VA = "0x294FFA0")]
	public void \u07FA\u05F9ԁԞ()
	{
		this.\u073Fԥ\u0836ࠑ();
		this.ࡦ\u0827ࡗ\u06DF();
	}

	// Token: 0x060018A0 RID: 6304 RVA: 0x00087030 File Offset: 0x00085230
	[Token(Token = "0x60018A0")]
	[Address(RVA = "0x2948EF8", Offset = "0x2948EF8", VA = "0x2948EF8")]
	public void ࢬ\u07AFڗր()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("Target");
		this.\u0605ࠑٴ\u06E7 = "Target";
	}

	// Token: 0x060018A1 RID: 6305 RVA: 0x000870D8 File Offset: 0x000852D8
	[Token(Token = "0x60018A1")]
	[Address(RVA = "0x294EA08", Offset = "0x294EA08", VA = "0x294EA08")]
	public void \u065Bܘۏט()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("Game Started");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x060018A2 RID: 6306 RVA: 0x00087184 File Offset: 0x00085384
	[Token(Token = "0x60018A2")]
	[Address(RVA = "0x295024C", Offset = "0x295024C", VA = "0x295024C")]
	public void ޟ\u088EԻխ()
	{
		this.\u073Fԥ\u0836ࠑ();
		this.ߖࡠ\u082Bࠃ();
	}

	// Token: 0x060018A3 RID: 6307 RVA: 0x000871A0 File Offset: 0x000853A0
	[Token(Token = "0x60018A3")]
	[Address(RVA = "0x2950270", Offset = "0x2950270", VA = "0x2950270")]
	public void ۓځࡐۇ()
	{
		this.\u06E2ܩ\u085Fࡆ();
		this.\u0884ݑӀ\u085C();
	}

	// Token: 0x060018A4 RID: 6308 RVA: 0x000871BC File Offset: 0x000853BC
	[Token(Token = "0x60018A4")]
	[Address(RVA = "0x2950294", Offset = "0x2950294", VA = "0x2950294")]
	private void \u081Cәࡃ۵()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("containsStaff").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			long u07AC_u06E3߉տ = 1L;
			this.\u07AC\u06E3߉տ = (u07AC_u06E3߉տ != 0L);
			this.\u0833\u07FBӲ\u07F6();
		}
		long u05C4_u05A1_u070Cڗ = 1L;
		this.\u05C4\u05A1\u070Cڗ = (u05C4_u05A1_u070Cڗ != 0L);
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060018A5 RID: 6309 RVA: 0x00087238 File Offset: 0x00085438
	[Token(Token = "0x60018A5")]
	[Address(RVA = "0x2950514", Offset = "0x2950514", VA = "0x2950514")]
	public void ӳࠈٯ\u055E()
	{
		this.ߖࡠ\u082Bࠃ();
	}

	// Token: 0x060018A6 RID: 6310 RVA: 0x0008724C File Offset: 0x0008544C
	[Token(Token = "0x60018A6")]
	[Address(RVA = "0x2950518", Offset = "0x2950518", VA = "0x2950518")]
	public void ڢւӢܝ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("User has been reported for: ");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x060018A7 RID: 6311 RVA: 0x00087300 File Offset: 0x00085500
	[Token(Token = "0x60018A7")]
	[Address(RVA = "0x294FFC4", Offset = "0x294FFC4", VA = "0x294FFC4")]
	public void ࡦ\u0827ࡗ\u06DF()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("StartGamemode");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x060018A8 RID: 6312 RVA: 0x000873B8 File Offset: 0x000855B8
	[Token(Token = "0x60018A8")]
	[Address(RVA = "0x29507C8", Offset = "0x29507C8", VA = "0x29507C8")]
	public void \u0742ޓ\u060Eب()
	{
		this.\u0884ݑӀ\u085C();
	}

	// Token: 0x060018A9 RID: 6313 RVA: 0x000873CC File Offset: 0x000855CC
	[Token(Token = "0x60018A9")]
	[Address(RVA = "0x29507CC", Offset = "0x29507CC", VA = "0x29507CC")]
	public void ٺ\u0589ࠍپ()
	{
		this.ࡤ\u086Cݛ\u06E7();
	}

	// Token: 0x060018AA RID: 6314 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018AA")]
	[Address(RVA = "0x294C69C", Offset = "0x294C69C", VA = "0x294C69C")]
	private void ݗ\u0705\u060CӘ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018AB RID: 6315 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018AB")]
	[Address(RVA = "0x29507D0", Offset = "0x29507D0", VA = "0x29507D0")]
	private void ࠎݬڨթ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018AC RID: 6316 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018AC")]
	[Address(RVA = "0x2950948", Offset = "0x2950948", VA = "0x2950948")]
	private void և۶ף\u0749()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018AD RID: 6317 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018AD")]
	[Address(RVA = "0x2950AC0", Offset = "0x2950AC0", VA = "0x2950AC0")]
	private void Ժݕݔ\u0897()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018AE RID: 6318 RVA: 0x000873E0 File Offset: 0x000855E0
	[Token(Token = "0x60018AE")]
	[Address(RVA = "0x2950C38", Offset = "0x2950C38", VA = "0x2950C38")]
	private void \u07F5\u0657\u055Aߍ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("Meta Platform entitlement error: ").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			this.ߔݽԱԡ();
		}
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060018AF RID: 6319 RVA: 0x00087448 File Offset: 0x00085648
	[Token(Token = "0x60018AF")]
	[Address(RVA = "0x2951020", Offset = "0x2951020", VA = "0x2951020")]
	public void ߢࡌՈط()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("NetworkPlayer");
	}

	// Token: 0x060018B0 RID: 6320 RVA: 0x000874F0 File Offset: 0x000856F0
	[Token(Token = "0x60018B0")]
	[Address(RVA = "0x29512BC", Offset = "0x29512BC", VA = "0x29512BC")]
	private void ں٢ࡡ\u05EC()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("Player").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			long num = 1L;
			this.\u07AC\u06E3߉տ = (num != 0L);
			this.ࠎݬڨթ();
			this.\u05C4\u05A1\u070Cڗ = (num != 0L);
		}
		long u05C4_u05A1_u070Cڗ = 1L;
		this.\u05C4\u05A1\u070Cڗ = (u05C4_u05A1_u070Cڗ != 0L);
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060018B1 RID: 6321 RVA: 0x00087574 File Offset: 0x00085774
	[Token(Token = "0x60018B1")]
	[Address(RVA = "0x295153C", Offset = "0x295153C", VA = "0x295153C")]
	public void \u0611\u0607ࢱ\u0837()
	{
		this.ވ\u058F\u07BD\u0598();
		this.ߢࡌՈط();
	}

	// Token: 0x060018B2 RID: 6322 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018B2")]
	[Address(RVA = "0x2951560", Offset = "0x2951560", VA = "0x2951560")]
	private void ޖ\u073Eԛࢲ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018B3 RID: 6323 RVA: 0x00087590 File Offset: 0x00085790
	[Token(Token = "0x60018B3")]
	[Address(RVA = "0x29516D8", Offset = "0x29516D8", VA = "0x29516D8")]
	public void ثࠐԉك()
	{
		this.\u0835Ե\u0872\u065F();
		this.\u0898\u07F3ޗ\u087A();
	}

	// Token: 0x060018B4 RID: 6324 RVA: 0x000875AC File Offset: 0x000857AC
	[Token(Token = "0x60018B4")]
	[Address(RVA = "0x29516FC", Offset = "0x29516FC", VA = "0x29516FC")]
	public void \u05C2ࠋࠏ\u060E()
	{
		this.\u0879ي\u0897ػ();
	}

	// Token: 0x060018B5 RID: 6325 RVA: 0x000875C0 File Offset: 0x000857C0
	[Token(Token = "0x60018B5")]
	[Address(RVA = "0x2951700", Offset = "0x2951700", VA = "0x2951700")]
	public void ҿܝմר()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060018B6 RID: 6326 RVA: 0x00087600 File Offset: 0x00085800
	[Token(Token = "0x60018B6")]
	[Address(RVA = "0x294A1B8", Offset = "0x294A1B8", VA = "0x294A1B8")]
	public void կܙՆݠ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("hand 1");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x060018B7 RID: 6327 RVA: 0x000876B0 File Offset: 0x000858B0
	[Token(Token = "0x60018B7")]
	[Address(RVA = "0x2951764", Offset = "0x2951764", VA = "0x2951764")]
	public void \u0705ࡊԠد()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060018B8 RID: 6328 RVA: 0x000876F0 File Offset: 0x000858F0
	[Token(Token = "0x60018B8")]
	[Address(RVA = "0x29517C8", Offset = "0x29517C8", VA = "0x29517C8")]
	public ClientGunManager()
	{
	}

	// Token: 0x060018B9 RID: 6329 RVA: 0x00087704 File Offset: 0x00085904
	[Token(Token = "0x60018B9")]
	[Address(RVA = "0x29517D0", Offset = "0x29517D0", VA = "0x29517D0")]
	public void \u0897\u088CکՉ()
	{
		this.ߕ\u0885Ԥӽ();
		this.ߖࡠ\u082Bࠃ();
	}

	// Token: 0x060018BA RID: 6330 RVA: 0x00087720 File Offset: 0x00085920
	[Token(Token = "0x60018BA")]
	[Address(RVA = "0x2948E94", Offset = "0x2948E94", VA = "0x2948E94")]
	public void Յؤӯԏ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060018BB RID: 6331 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018BB")]
	[Address(RVA = "0x294FB88", Offset = "0x294FB88", VA = "0x294FB88")]
	private void ࠊ\u05C2ضࢡ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018BC RID: 6332 RVA: 0x00087760 File Offset: 0x00085960
	[Token(Token = "0x60018BC")]
	[Address(RVA = "0x29517F4", Offset = "0x29517F4", VA = "0x29517F4")]
	public void ݡՈճԝ()
	{
		this.\u073Fԥ\u0836ࠑ();
		this.\u0603ܘڭࡥ();
	}

	// Token: 0x060018BD RID: 6333 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018BD")]
	[Address(RVA = "0x2951818", Offset = "0x2951818", VA = "0x2951818")]
	private void \u081CࢧןԸ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018BE RID: 6334 RVA: 0x0008777C File Offset: 0x0008597C
	[Token(Token = "0x60018BE")]
	[Address(RVA = "0x2951990", Offset = "0x2951990", VA = "0x2951990")]
	private void ݞߒࢸڢ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("1BN").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			long u07AC_u06E3߉տ = 1L;
			this.\u07AC\u06E3߉տ = (u07AC_u06E3߉տ != 0L);
			this.Ԡࢻࢸנ();
		}
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060018BF RID: 6335 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018BF")]
	[Address(RVA = "0x294CD60", Offset = "0x294CD60", VA = "0x294CD60")]
	private void ڐ\u0899\u061B\u0591()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018C0 RID: 6336 RVA: 0x000877F0 File Offset: 0x000859F0
	[Token(Token = "0x60018C0")]
	[Address(RVA = "0x2951C0C", Offset = "0x2951C0C", VA = "0x2951C0C")]
	public void \u087F٢ӡ\u07F6()
	{
		this.\u0700\u0604߅\u07A7();
	}

	// Token: 0x060018C1 RID: 6337 RVA: 0x00087804 File Offset: 0x00085A04
	[Token(Token = "0x60018C1")]
	[Address(RVA = "0x29488F8", Offset = "0x29488F8", VA = "0x29488F8")]
	public void ࡤ\u086Cݛ\u06E7()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("Version");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x060018C2 RID: 6338 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018C2")]
	[Address(RVA = "0x2951C10", Offset = "0x2951C10", VA = "0x2951C10")]
	private void ݵێۄر()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018C3 RID: 6339 RVA: 0x000878BC File Offset: 0x00085ABC
	[Token(Token = "0x60018C3")]
	[Address(RVA = "0x2951D88", Offset = "0x2951D88", VA = "0x2951D88")]
	public void ݘ\u05FAԵ\u0745()
	{
		this.\u0879ي\u0897ػ();
	}

	// Token: 0x060018C4 RID: 6340 RVA: 0x000878D0 File Offset: 0x00085AD0
	[Token(Token = "0x60018C4")]
	[Address(RVA = "0x2951D8C", Offset = "0x2951D8C", VA = "0x2951D8C")]
	public void թࠂհԦ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060018C5 RID: 6341 RVA: 0x00087910 File Offset: 0x00085B10
	[Token(Token = "0x60018C5")]
	[Address(RVA = "0x2951DF0", Offset = "0x2951DF0", VA = "0x2951DF0")]
	public void \u07B5ݯ٤ࡘ()
	{
		this.ވ\u058F\u07BD\u0598();
		this.ڢւӢܝ();
	}

	// Token: 0x060018C6 RID: 6342 RVA: 0x0008792C File Offset: 0x00085B2C
	[Token(Token = "0x60018C6")]
	[Address(RVA = "0x2951E14", Offset = "0x2951E14", VA = "0x2951E14")]
	private void ߊ\u066A\u05CFԉ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("Wear Hoodie").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			this.ݕ߁\u0597ݯ();
		}
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060018C7 RID: 6343 RVA: 0x00087994 File Offset: 0x00085B94
	[Token(Token = "0x60018C7")]
	[Address(RVA = "0x2952084", Offset = "0x2952084", VA = "0x2952084")]
	public void \u058Eպࠎ\u06DD()
	{
		this.ߪ\u07FEܞ\u06DC();
		this.Ӎ\u07F6\u081Eخ();
	}

	// Token: 0x060018C8 RID: 6344 RVA: 0x000879B0 File Offset: 0x00085BB0
	[Token(Token = "0x60018C8")]
	[Address(RVA = "0x294F21C", Offset = "0x294F21C", VA = "0x294F21C")]
	public void \u0884ݑӀ\u085C()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag(" and the correct version is ");
	}

	// Token: 0x060018C9 RID: 6345 RVA: 0x00087A58 File Offset: 0x00085C58
	[Token(Token = "0x60018C9")]
	[Address(RVA = "0x29520A8", Offset = "0x29520A8", VA = "0x29520A8")]
	public void \u0613٧ӻࡓ()
	{
		this.ߖࡠ\u082Bࠃ();
	}

	// Token: 0x060018CA RID: 6346 RVA: 0x00087A6C File Offset: 0x00085C6C
	[Token(Token = "0x60018CA")]
	[Address(RVA = "0x29520AC", Offset = "0x29520AC", VA = "0x29520AC")]
	private void \u05F8ݑ\u06ECߞ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("Player").GetComponent<TextMeshPro>();
			this.ࡍڦӰߑ = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.\u05C4\u05A1\u070Cڗ)
		{
			long u07AC_u06E3߉տ = 1L;
			this.\u07AC\u06E3߉տ = (u07AC_u06E3߉տ != 0L);
			this.ڬ\u07EB\u0747ս();
		}
		if (this.\u07AC\u06E3߉տ && this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060018CB RID: 6347 RVA: 0x00087AE0 File Offset: 0x00085CE0
	[Token(Token = "0x60018CB")]
	[Address(RVA = "0x2952320", Offset = "0x2952320", VA = "0x2952320")]
	private void Update()
	{
		if (true)
		{
			TextMeshPro component = GameObject.Find("ScoreCounter").GetComponent<TextMeshPro>();
		}
		InputDevice inputDevice;
		if (inputDevice == null)
		{
		}
	}

	// Token: 0x060018CC RID: 6348 RVA: 0x00087B0C File Offset: 0x00085D0C
	[Token(Token = "0x60018CC")]
	[Address(RVA = "0x294E4A0", Offset = "0x294E4A0", VA = "0x294E4A0")]
	public void ט\u060E\u089B\u07F8()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("Wear Hoodie");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x060018CD RID: 6349 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018CD")]
	[Address(RVA = "0x2950EA8", Offset = "0x2950EA8", VA = "0x2950EA8")]
	private void ߔݽԱԡ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018CE RID: 6350 RVA: 0x00087BC4 File Offset: 0x00085DC4
	[Token(Token = "0x60018CE")]
	[Address(RVA = "0x294D81C", Offset = "0x294D81C", VA = "0x294D81C")]
	public void \u0835Ե\u0872\u065F()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060018CF RID: 6351 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018CF")]
	[Address(RVA = "0x2952590", Offset = "0x2952590", VA = "0x2952590")]
	private void ע\u07AE\u083Dء()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018D0 RID: 6352 RVA: 0x00087C04 File Offset: 0x00085E04
	[Token(Token = "0x60018D0")]
	[Address(RVA = "0x294B1F0", Offset = "0x294B1F0", VA = "0x294B1F0")]
	public void Ԁ\u064B\u070Aӳ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x060018D1 RID: 6353 RVA: 0x00087CAC File Offset: 0x00085EAC
	[Token(Token = "0x60018D1")]
	[Address(RVA = "0x294BD98", Offset = "0x294BD98", VA = "0x294BD98")]
	public void \u06E2ܩ\u085Fࡆ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060018D2 RID: 6354 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60018D2")]
	[Address(RVA = "0x2952708", Offset = "0x2952708", VA = "0x2952708")]
	private void \u0881\u0596\u07EFڠ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060018D3 RID: 6355 RVA: 0x00087CEC File Offset: 0x00085EEC
	[Token(Token = "0x60018D3")]
	[Address(RVA = "0x2952880", Offset = "0x2952880", VA = "0x2952880")]
	public void \u083Aڊࡠ\u073A()
	{
		this.\u081DلӨٱ();
	}

	// Token: 0x060018D4 RID: 6356 RVA: 0x00087D00 File Offset: 0x00085F00
	[Token(Token = "0x60018D4")]
	[Address(RVA = "0x294C0A8", Offset = "0x294C0A8", VA = "0x294C0A8")]
	public void ߕ\u0885Ԥӽ()
	{
		AudioClip[] քԲ_u08B5ӹ = this.քԲ\u08B5ӹ;
		AudioClip.PCMReaderCallback pcmreaderCallback = քԲ_u08B5ӹ.m_PCMReaderCallback;
		AudioSource ӽ_u081Dࢢڡ = this.Ӽ\u081Dࢢڡ;
		object target = քԲ_u08B5ӹ.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060018D5 RID: 6357 RVA: 0x00087D40 File Offset: 0x00085F40
	[Token(Token = "0x60018D5")]
	[Address(RVA = "0x2952884", Offset = "0x2952884", VA = "0x2952884")]
	public void ݗ\u05ADݮ\u0595()
	{
		this.\u070F\u0653ݾԙ();
		this.\u0670ࠏ\u0704ک();
	}

	// Token: 0x060018D6 RID: 6358 RVA: 0x00087D5C File Offset: 0x00085F5C
	[Token(Token = "0x60018D6")]
	[Address(RVA = "0x2948504", Offset = "0x2948504", VA = "0x2948504")]
	public void \u0670ࠏ\u0704ک()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("HDRP/Lit");
	}

	// Token: 0x060018D7 RID: 6359 RVA: 0x00087E04 File Offset: 0x00086004
	[Token(Token = "0x60018D7")]
	[Address(RVA = "0x2949BD4", Offset = "0x2949BD4", VA = "0x2949BD4")]
	public void \u0700\u0604߅\u07A7()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("Trying Getting Entilement...");
		int u0605ࠑٴ_u06E = this.\u0605ࠑٴ\u06E7;
		this.\u0605ࠑٴ\u06E7 = u0605ࠑٴ_u06E;
	}

	// Token: 0x060018D8 RID: 6360 RVA: 0x00087EB8 File Offset: 0x000860B8
	[Token(Token = "0x60018D8")]
	[Address(RVA = "0x29528A8", Offset = "0x29528A8", VA = "0x29528A8")]
	public void ࢱࢤԍށ()
	{
		Vector3 position = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ = this.\u06ED\u0886ޣײ;
		Vector3 forward = Vector3.forward;
		float num = this.ࡣڅڞӪ;
		Vector3 position2 = this.\u06ED\u0886ޣײ.position;
		Transform u06ED_u0886ޣײ2 = this.\u06ED\u0886ޣײ;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Collider collider;
		bool flag = collider.CompareTag("monke is not my monke");
	}

	// Token: 0x060018D9 RID: 6361 RVA: 0x00087F58 File Offset: 0x00086158
	[Token(Token = "0x60018D9")]
	[Address(RVA = "0x2952B1C", Offset = "0x2952B1C", VA = "0x2952B1C")]
	public void ݚאܧ\u058A()
	{
		this.ࡦ\u0827ࡗ\u06DF();
	}

	// Token: 0x060018DA RID: 6362 RVA: 0x00087F6C File Offset: 0x0008616C
	[Token(Token = "0x60018DA")]
	[Address(RVA = "0x2952B20", Offset = "0x2952B20", VA = "0x2952B20")]
	public void ڏ\u07F9ݪמ()
	{
		this.Ԁ\u064B\u070Aӳ();
	}

	// Token: 0x04000300 RID: 768
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000300")]
	public Transform \u06ED\u0886ޣײ;

	// Token: 0x04000301 RID: 769
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000301")]
	public float ࡣڅڞӪ;

	// Token: 0x04000302 RID: 770
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x4000302")]
	public bool \u07AC\u06E3߉տ;

	// Token: 0x04000303 RID: 771
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000303")]
	public ParticleSystem[] \u0879ףյל;

	// Token: 0x04000304 RID: 772
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000304")]
	public XRNode ࢳҾپݳ;

	// Token: 0x04000305 RID: 773
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x4000305")]
	public bool \u05C4\u05A1\u070Cڗ;

	// Token: 0x04000306 RID: 774
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000306")]
	public AudioSource Ӽ\u081Dࢢڡ;

	// Token: 0x04000307 RID: 775
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000307")]
	public AudioClip[] քԲ\u08B5ӹ;

	// Token: 0x04000308 RID: 776
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000308")]
	private bool \u089Bݼۄ\u0875;

	// Token: 0x04000309 RID: 777
	[FieldOffset(Offset = "0x4C")]
	[Token(Token = "0x4000309")]
	public int \u0605ࠑٴ\u06E7;

	// Token: 0x0400030A RID: 778
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400030A")]
	public TextMeshPro ࡍڦӰߑ;

	// Token: 0x0400030B RID: 779
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400030B")]
	public PhotonView ޣߑԤࡩ;
}
