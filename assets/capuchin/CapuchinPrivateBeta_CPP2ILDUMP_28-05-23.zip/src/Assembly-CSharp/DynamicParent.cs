﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000057 RID: 87
[Token(Token = "0x2000057")]
public class DynamicParent : MonoBehaviour
{
	// Token: 0x06000C3C RID: 3132 RVA: 0x00040E24 File Offset: 0x0003F024
	[Token(Token = "0x6000C3C")]
	[Address(RVA = "0x28D8458", Offset = "0x28D8458", VA = "0x28D8458")]
	public void \u07F2\u07F7\u06FE\u081D()
	{
		GameObject[] ٿֆء_u = this.ٿֆء\u0652;
		Dictionary<string, GameObject> u0607_u081A_u05CEܚ = this.\u0607\u081A\u05CEܚ;
	}

	// Token: 0x06000C3D RID: 3133 RVA: 0x00040E50 File Offset: 0x0003F050
	[Token(Token = "0x6000C3D")]
	[Address(RVA = "0x28D85F8", Offset = "0x28D85F8", VA = "0x28D85F8")]
	public void \u064FՒײә()
	{
		GameObject[] ٿֆء_u = this.ٿֆء\u0652;
		Dictionary<string, GameObject> u0607_u081A_u05CEܚ = this.\u0607\u081A\u05CEܚ;
	}

	// Token: 0x06000C3E RID: 3134 RVA: 0x00040E7C File Offset: 0x0003F07C
	[Token(Token = "0x6000C3E")]
	[Address(RVA = "0x28D8798", Offset = "0x28D8798", VA = "0x28D8798")]
	public void ى\u081Cޛ\u07EC()
	{
	}

	// Token: 0x06000C3F RID: 3135 RVA: 0x00040E9C File Offset: 0x0003F09C
	[Token(Token = "0x6000C3F")]
	[Address(RVA = "0x28C9E28", Offset = "0x28C9E28", VA = "0x28C9E28")]
	public void \u058E\u0881\u0704۹(string ޘ\u0823\u07EBԟ)
	{
		bool flag = this.ߔ\u0819ࡖߠ.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C40 RID: 3136 RVA: 0x00040EF4 File Offset: 0x0003F0F4
	[Token(Token = "0x6000C40")]
	[Address(RVA = "0x28D8938", Offset = "0x28D8938", VA = "0x28D8938")]
	private void ڜ\u0817ࡇօ(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
	}

	// Token: 0x06000C41 RID: 3137 RVA: 0x00040F08 File Offset: 0x0003F108
	[Token(Token = "0x6000C41")]
	[Address(RVA = "0x28D8958", Offset = "0x28D8958", VA = "0x28D8958")]
	public void \u0833إ\u06DEת()
	{
		GameObject[] ٿֆء_u = this.ٿֆء\u0652;
		Dictionary<string, GameObject> u0607_u081A_u05CEܚ = this.\u0607\u081A\u05CEܚ;
	}

	// Token: 0x06000C42 RID: 3138 RVA: 0x00040F34 File Offset: 0x0003F134
	[Token(Token = "0x6000C42")]
	[Address(RVA = "0x28C9FD0", Offset = "0x28C9FD0", VA = "0x28C9FD0")]
	public void \u05B1գӫک(string ޘ\u0823\u07EBԟ)
	{
		bool flag = this.ߔ\u0819ࡖߠ.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C43 RID: 3139 RVA: 0x00040F8C File Offset: 0x0003F18C
	[Token(Token = "0x6000C43")]
	[Address(RVA = "0x28D8AF8", Offset = "0x28D8AF8", VA = "0x28D8AF8")]
	private void ۯ\u06EBܣ\u085D(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		long active = 0L;
		ւݍ\u05BA\u05FA.SetActive(active != 0L);
	}

	// Token: 0x06000C44 RID: 3140 RVA: 0x00040FBC File Offset: 0x0003F1BC
	[Token(Token = "0x6000C44")]
	[Address(RVA = "0x28C9930", Offset = "0x28C9930", VA = "0x28C9930")]
	public void ݤ\u07EDצ٥(string ޘ\u0823\u07EBԟ)
	{
		bool flag = this.ߔ\u0819ࡖߠ.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C45 RID: 3141 RVA: 0x00041014 File Offset: 0x0003F214
	[Token(Token = "0x6000C45")]
	[Address(RVA = "0x28D8C20", Offset = "0x28D8C20", VA = "0x28D8C20")]
	private void ࡌ\u06E8\u0597Ӈ(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		long active = 0L;
		ւݍ\u05BA\u05FA.SetActive(active != 0L);
	}

	// Token: 0x06000C46 RID: 3142 RVA: 0x00041044 File Offset: 0x0003F244
	[Token(Token = "0x6000C46")]
	[Address(RVA = "0x28D8D68", Offset = "0x28D8D68", VA = "0x28D8D68")]
	private void ؼ\u082Eزա(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
	}

	// Token: 0x06000C47 RID: 3143 RVA: 0x00041058 File Offset: 0x0003F258
	[Token(Token = "0x6000C47")]
	[Address(RVA = "0x28D8C00", Offset = "0x28D8C00", VA = "0x28D8C00")]
	private void ԃ٣ڷԒ(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
	}

	// Token: 0x06000C48 RID: 3144 RVA: 0x0004106C File Offset: 0x0003F26C
	[Token(Token = "0x6000C48")]
	[Address(RVA = "0x28D8D88", Offset = "0x28D8D88", VA = "0x28D8D88")]
	public void ؤՠՅږ(string ޘ\u0823\u07EBԟ)
	{
		bool flag = this.ߔ\u0819ࡖߠ.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C49 RID: 3145 RVA: 0x000410C4 File Offset: 0x0003F2C4
	[Token(Token = "0x6000C49")]
	[Address(RVA = "0x28D8FF4", Offset = "0x28D8FF4", VA = "0x28D8FF4")]
	public void ئ\u08B5ۂۮ()
	{
		GameObject[] ٿֆء_u = this.ٿֆء\u0652;
		Dictionary<string, GameObject> u0607_u081A_u05CEܚ = this.\u0607\u081A\u05CEܚ;
	}

	// Token: 0x06000C4A RID: 3146 RVA: 0x000410F0 File Offset: 0x0003F2F0
	[Token(Token = "0x6000C4A")]
	[Address(RVA = "0x28CA178", Offset = "0x28CA178", VA = "0x28CA178")]
	public void Ӓ\u0737ݕ\u06E5(string ޘ\u0823\u07EBԟ)
	{
		bool flag = this.ߔ\u0819ࡖߠ.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C4B RID: 3147 RVA: 0x00041148 File Offset: 0x0003F348
	[Token(Token = "0x6000C4B")]
	[Address(RVA = "0x28D8BC0", Offset = "0x28D8BC0", VA = "0x28D8BC0")]
	private void Ԫ\u0881\u06DFص(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
	}

	// Token: 0x06000C4C RID: 3148 RVA: 0x0004115C File Offset: 0x0003F35C
	[Token(Token = "0x6000C4C")]
	[Address(RVA = "0x28D90CC", Offset = "0x28D90CC", VA = "0x28D90CC")]
	public void \u089F١ࡔ\u089F(string ޘ\u0823\u07EBԟ)
	{
		bool flag = this.ߔ\u0819ࡖߠ.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C4D RID: 3149 RVA: 0x00041198 File Offset: 0x0003F398
	[Token(Token = "0x6000C4D")]
	[Address(RVA = "0x28D9274", Offset = "0x28D9274", VA = "0x28D9274")]
	public void \u07B4\u0827םڵ()
	{
		GameObject[] ٿֆء_u = this.ٿֆء\u0652;
		Dictionary<string, GameObject> u0607_u081A_u05CEܚ = this.\u0607\u081A\u05CEܚ;
	}

	// Token: 0x06000C4E RID: 3150 RVA: 0x000411C4 File Offset: 0x0003F3C4
	[Token(Token = "0x6000C4E")]
	[Address(RVA = "0x28D8530", Offset = "0x28D8530", VA = "0x28D8530")]
	private void \u0884\u0827\u05AD٣(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		long active = 0L;
		ւݍ\u05BA\u05FA.SetActive(active != 0L);
	}

	// Token: 0x06000C4F RID: 3151 RVA: 0x000411F4 File Offset: 0x0003F3F4
	[Token(Token = "0x6000C4F")]
	[Address(RVA = "0x28D936C", Offset = "0x28D936C", VA = "0x28D936C")]
	public void \u05F4\u0894ھ\u0820()
	{
		GameObject[] ٿֆء_u = this.ٿֆء\u0652;
		Dictionary<string, GameObject> u0607_u081A_u05CEܚ = this.\u0607\u081A\u05CEܚ;
	}

	// Token: 0x06000C50 RID: 3152 RVA: 0x00041220 File Offset: 0x0003F420
	[Token(Token = "0x6000C50")]
	[Address(RVA = "0x28D934C", Offset = "0x28D934C", VA = "0x28D934C")]
	private void Ժل\u0601\u0747(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
	}

	// Token: 0x06000C51 RID: 3153 RVA: 0x00041234 File Offset: 0x0003F434
	[Token(Token = "0x6000C51")]
	[Address(RVA = "0x28C9AD8", Offset = "0x28C9AD8", VA = "0x28C9AD8")]
	public void \u06E7\u05A0\u0889ٯ(string ޘ\u0823\u07EBԟ)
	{
		bool flag = this.ߔ\u0819ࡖߠ.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C52 RID: 3154 RVA: 0x0004128C File Offset: 0x0003F48C
	[Token(Token = "0x6000C52")]
	[Address(RVA = "0x28D8870", Offset = "0x28D8870", VA = "0x28D8870")]
	private void \u060B\u05BDݪӱ(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		long active = 0L;
		ւݍ\u05BA\u05FA.SetActive(active != 0L);
	}

	// Token: 0x06000C53 RID: 3155 RVA: 0x000412BC File Offset: 0x0003F4BC
	[Token(Token = "0x6000C53")]
	[Address(RVA = "0x28D8D48", Offset = "0x28D8D48", VA = "0x28D8D48")]
	private void \u060EࡆߊӲ(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
	}

	// Token: 0x06000C54 RID: 3156 RVA: 0x000412D0 File Offset: 0x0003F4D0
	[Token(Token = "0x6000C54")]
	[Address(RVA = "0x28D9444", Offset = "0x28D9444", VA = "0x28D9444")]
	public DynamicParent()
	{
		List<GameObject> ߔ_u0819ࡖߠ = new List();
		this.ߔ\u0819ࡖߠ = ߔ_u0819ࡖߠ;
		Dictionary<string, GameObject> u0607_u081A_u05CEܚ;
		this.\u0607\u081A\u05CEܚ = u0607_u081A_u05CEܚ;
		base..ctor();
	}

	// Token: 0x06000C55 RID: 3157 RVA: 0x000412F8 File Offset: 0x0003F4F8
	[Token(Token = "0x6000C55")]
	[Address(RVA = "0x28D8D08", Offset = "0x28D8D08", VA = "0x28D8D08")]
	private void ܘ\u089Eٲࡔ(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
	}

	// Token: 0x06000C56 RID: 3158 RVA: 0x0004130C File Offset: 0x0003F50C
	[Token(Token = "0x6000C56")]
	[Address(RVA = "0x28C9C80", Offset = "0x28C9C80", VA = "0x28C9C80")]
	public void \u07FAײߏࠐ(string ޘ\u0823\u07EBԟ)
	{
		bool flag = this.ߔ\u0819ࡖߠ.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C57 RID: 3159 RVA: 0x00041348 File Offset: 0x0003F548
	[Token(Token = "0x6000C57")]
	[Address(RVA = "0x28D86D0", Offset = "0x28D86D0", VA = "0x28D86D0")]
	private void յ\u05C5\u07B6\u0884(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		long active = 0L;
		ւݍ\u05BA\u05FA.SetActive(active != 0L);
	}

	// Token: 0x06000C58 RID: 3160 RVA: 0x00041378 File Offset: 0x0003F578
	[Token(Token = "0x6000C58")]
	[Address(RVA = "0x28D8F2C", Offset = "0x28D8F2C", VA = "0x28D8F2C")]
	private void \u05AB\u087F\u055B\u064B(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		long active = 0L;
		ւݍ\u05BA\u05FA.SetActive(active != 0L);
	}

	// Token: 0x06000C59 RID: 3161 RVA: 0x000413A8 File Offset: 0x0003F5A8
	[Token(Token = "0x6000C59")]
	[Address(RVA = "0x28D8BE0", Offset = "0x28D8BE0", VA = "0x28D8BE0")]
	private void רࡌܭԣ(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
	}

	// Token: 0x06000C5A RID: 3162 RVA: 0x000413BC File Offset: 0x0003F5BC
	[Token(Token = "0x6000C5A")]
	[Address(RVA = "0x28D9514", Offset = "0x28D9514", VA = "0x28D9514")]
	public void ԉ\u07F7דڱ()
	{
		GameObject[] ٿֆء_u = this.ٿֆء\u0652;
		Dictionary<string, GameObject> u0607_u081A_u05CEܚ = this.\u0607\u081A\u05CEܚ;
	}

	// Token: 0x06000C5B RID: 3163 RVA: 0x000413E0 File Offset: 0x0003F5E0
	[Token(Token = "0x6000C5B")]
	[Address(RVA = "0x28D95CC", Offset = "0x28D95CC", VA = "0x28D95CC")]
	public void ߄\u07FBࡡ\u07AF()
	{
		GameObject[] ٿֆء_u = this.ٿֆء\u0652;
		Dictionary<string, GameObject> u0607_u081A_u05CEܚ = this.\u0607\u081A\u05CEܚ;
	}

	// Token: 0x06000C5C RID: 3164 RVA: 0x00041404 File Offset: 0x0003F604
	[Token(Token = "0x6000C5C")]
	[Address(RVA = "0x28D8A30", Offset = "0x28D8A30", VA = "0x28D8A30")]
	private void \u089A\u0700\u07B2Լ(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		long active = 0L;
		ւݍ\u05BA\u05FA.SetActive(active != 0L);
	}

	// Token: 0x06000C5D RID: 3165 RVA: 0x00041434 File Offset: 0x0003F634
	[Token(Token = "0x6000C5D")]
	[Address(RVA = "0x28D8CE8", Offset = "0x28D8CE8", VA = "0x28D8CE8")]
	private void ڎ\u0702ށ\u07EC(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
	}

	// Token: 0x06000C5E RID: 3166 RVA: 0x00041448 File Offset: 0x0003F648
	[Token(Token = "0x6000C5E")]
	[Address(RVA = "0x28C9788", Offset = "0x28C9788", VA = "0x28C9788")]
	public void ףݫӗࠈ(string ޘ\u0823\u07EBԟ)
	{
		bool flag = this.ߔ\u0819ࡖߠ.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C5F RID: 3167 RVA: 0x000414A0 File Offset: 0x0003F6A0
	[Token(Token = "0x6000C5F")]
	[Address(RVA = "0x28D9684", Offset = "0x28D9684", VA = "0x28D9684")]
	public void Awake()
	{
		GameObject[] ٿֆء_u = this.ٿֆء\u0652;
		Dictionary<string, GameObject> u0607_u081A_u05CEܚ = this.\u0607\u081A\u05CEܚ;
	}

	// Token: 0x06000C60 RID: 3168 RVA: 0x000414CC File Offset: 0x0003F6CC
	[Token(Token = "0x6000C60")]
	[Address(RVA = "0x28D8D28", Offset = "0x28D8D28", VA = "0x28D8D28")]
	private void ځيݾԽ(GameObject ւݍ\u05BA\u05FA, bool ح\u05C1\u0733Ԅ)
	{
	}

	// Token: 0x040001C1 RID: 449
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001C1")]
	public GameObject[] ٿֆء\u0652;

	// Token: 0x040001C2 RID: 450
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001C2")]
	public GameObject \u088Cԋݏ\u058F;

	// Token: 0x040001C3 RID: 451
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001C3")]
	public List<GameObject> ߔ\u0819ࡖߠ;

	// Token: 0x040001C4 RID: 452
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40001C4")]
	public Dictionary<string, GameObject> \u0607\u081A\u05CEܚ;
}
