﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.Rendering;

// Token: 0x02000005 RID: 5
[Token(Token = "0x2000005")]
public class BetterWeatherCycle : MonoBehaviour
{
	// Token: 0x060000C0 RID: 192 RVA: 0x00004AE0 File Offset: 0x00002CE0
	[Token(Token = "0x60000C0")]
	[Address(RVA = "0x2C15D54", Offset = "0x2C15D54", VA = "0x2C15D54")]
	public void ࡋձغӜ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Player");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 17428;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("ORGTARG", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060000C1 RID: 193 RVA: 0x00004C80 File Offset: 0x00002E80
	[Token(Token = "0x60000C1")]
	[Address(RVA = "0x2C15FD8", Offset = "0x2C15FD8", VA = "0x2C15FD8")]
	public void ޗٻ\u0825ڔ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("\tExpires: ");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("ErrorScreen", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060000C2 RID: 194 RVA: 0x00004E20 File Offset: 0x00003020
	[Token(Token = "0x60000C2")]
	[Address(RVA = "0x2C16260", Offset = "0x2C16260", VA = "0x2C16260")]
	public void \u089Bځԯԝ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string text = DateTime.UtcNow.ToString("Player");
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float deltaTime4 = Time.deltaTime;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x060000C3 RID: 195 RVA: 0x00004EAC File Offset: 0x000030AC
	[Token(Token = "0x60000C3")]
	[Address(RVA = "0x2C164E4", Offset = "0x2C164E4", VA = "0x2C164E4")]
	public void ޤ\u0610\u087A\u05AF()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Player");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		GameObject ۴_u05EBی_u = this.۴\u05EBی\u0823;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		bool activeSelf = ۴_u05EBی_u.activeSelf;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("CapuchinRemade", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000C4 RID: 196 RVA: 0x00005190 File Offset: 0x00003390
	[Token(Token = "0x60000C4")]
	[Address(RVA = "0x2C168FC", Offset = "0x2C168FC", VA = "0x2C168FC")]
	public void \u0886ܬԗ\u05C0()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Add/Remove Hat");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 57344;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x0000532C File Offset: 0x0000352C
	[Token(Token = "0x60000C5")]
	[Address(RVA = "0x2C16B88", Offset = "0x2C16B88", VA = "0x2C16B88")]
	public void ࠆ߆ۀפ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("_Tint");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		GameObject ۴_u05EBی_u = this.۴\u05EBی\u0823;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		bool activeSelf = ۴_u05EBی_u.activeSelf;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("closeToObject", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x0000562C File Offset: 0x0000382C
	[Token(Token = "0x60000C6")]
	[Address(RVA = "0x2C16FA4", Offset = "0x2C16FA4", VA = "0x2C16FA4")]
	public void \u089Fکߦݭ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Tagging");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x000057AC File Offset: 0x000039AC
	[Token(Token = "0x60000C7")]
	[Address(RVA = "0x2C17230", Offset = "0x2C17230", VA = "0x2C17230")]
	public void ࡇ\u0559یՒ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		DateTime utcNow = DateTime.UtcNow;
		string ӫࢡ_u06D7_u05F;
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 17310;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("tutorialCheck", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x00005940 File Offset: 0x00003B40
	[Token(Token = "0x60000C8")]
	[Address(RVA = "0x2C174B4", Offset = "0x2C174B4", VA = "0x2C174B4")]
	public void ޞؽ\u06EDս()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Try Connect To Server...");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("HandR", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000C9 RID: 201 RVA: 0x00005C20 File Offset: 0x00003E20
	[Token(Token = "0x60000C9")]
	[Address(RVA = "0x2C178D0", Offset = "0x2C178D0", VA = "0x2C178D0")]
	public void \u05BBږ\u060Cࡑ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString(" hours. You were banned because of ");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 49152;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("ChangePlayerSize", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x060000CA RID: 202 RVA: 0x00005DC8 File Offset: 0x00003FC8
	[Token(Token = "0x60000CA")]
	[Address(RVA = "0x2C17B5C", Offset = "0x2C17B5C", VA = "0x2C17B5C")]
	public void ڸՔ\u0594ԭ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("HandL");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		GameObject ۴_u05EBی_u = this.۴\u05EBی\u0823;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		bool activeSelf = ۴_u05EBی_u.activeSelf;
		int ralspeed = 17277;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000CB RID: 203 RVA: 0x0000609C File Offset: 0x0000429C
	[Token(Token = "0x60000CB")]
	[Address(RVA = "0x2C17F68", Offset = "0x2C17F68", VA = "0x2C17F68")]
	public void \u07BFޥ٧\u073B()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Player");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("HandL", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000CC RID: 204 RVA: 0x00006384 File Offset: 0x00004584
	[Token(Token = "0x60000CC")]
	[Address(RVA = "0x2C18388", Offset = "0x2C18388", VA = "0x2C18388")]
	public void ޛ\u0822\u05AFݎ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("FingerTip");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		GameObject ۴_u05EBی_u = this.۴\u05EBی\u0823;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		bool activeSelf = ۴_u05EBی_u.activeSelf;
		int ralspeed = 17247;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("FingerTip", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000CD RID: 205 RVA: 0x00006670 File Offset: 0x00004870
	[Token(Token = "0x60000CD")]
	[Address(RVA = "0x2C18794", Offset = "0x2C18794", VA = "0x2C18794")]
	public void FixedUpdate()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("hh:mmtt");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 52429;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		if (this.ӻهࡀ\u05C1)
		{
		}
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000CE RID: 206 RVA: 0x0000691C File Offset: 0x00004B1C
	[Token(Token = "0x60000CE")]
	[Address(RVA = "0x2C18B98", Offset = "0x2C18B98", VA = "0x2C18B98")]
	public void Ԃڏݏ\u086D()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("ErrorScreen");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		GameObject ۴_u05EBی_u = this.۴\u05EBی\u0823;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		bool activeSelf = ۴_u05EBی_u.activeSelf;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Open", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000CF RID: 207 RVA: 0x00006C10 File Offset: 0x00004E10
	[Token(Token = "0x60000CF")]
	[Address(RVA = "0x2C18FB0", Offset = "0x2C18FB0", VA = "0x2C18FB0")]
	public void ڷԟ\u087D\u05B9()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("false");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 17503;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("TurnAmount", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060000D0 RID: 208 RVA: 0x00006DB0 File Offset: 0x00004FB0
	[Token(Token = "0x60000D0")]
	[Address(RVA = "0x2C19234", Offset = "0x2C19234", VA = "0x2C19234")]
	public void \u0892\u061B\u0606\u06D8()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString(" and for the price of ");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Tagged", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x00006F58 File Offset: 0x00005158
	[Token(Token = "0x60000D1")]
	[Address(RVA = "0x2C194C0", Offset = "0x2C194C0", VA = "0x2C194C0")]
	public void \u07A7\u06DFࠈޖ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("PlayerHead");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 32768;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("\n", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000D2 RID: 210 RVA: 0x00007228 File Offset: 0x00005428
	[Token(Token = "0x60000D2")]
	[Address(RVA = "0x2C198E0", Offset = "0x2C198E0", VA = "0x2C198E0")]
	public void \u0609ݢ\u05F7\u0744()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Trying Getting Entilement...");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 49152;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Round end", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000D3 RID: 211 RVA: 0x000074F0 File Offset: 0x000056F0
	[Token(Token = "0x60000D3")]
	[Address(RVA = "0x2C19CF8", Offset = "0x2C19CF8", VA = "0x2C19CF8")]
	public void \u064Cޔաӕ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Room Name: ");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 8192;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Collided", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000D4 RID: 212 RVA: 0x000077E4 File Offset: 0x000059E4
	[Token(Token = "0x60000D4")]
	[Address(RVA = "0x2C1A11C", Offset = "0x2C1A11C", VA = "0x2C1A11C")]
	public void \u07BBۯ٤ࠍ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("This is the 1000 Bananas button, and it was just clicked");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 17596;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("typesOfTalk", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000D5 RID: 213 RVA: 0x00007AD4 File Offset: 0x00005CD4
	[Token(Token = "0x60000D5")]
	[Address(RVA = "0x2C1A534", Offset = "0x2C1A534", VA = "0x2C1A534")]
	public void \u0736\u06E0\u06E0څ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("ORGPORT");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 57344;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("trol", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000D6 RID: 214 RVA: 0x00007DB0 File Offset: 0x00005FB0
	[Token(Token = "0x60000D6")]
	[Address(RVA = "0x2C1A948", Offset = "0x2C1A948", VA = "0x2C1A948")]
	public void \u07AAح\u087Fܩ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString(". Please update you game to the latest version");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		GameObject ۴_u05EBی_u = this.۴\u05EBی\u0823;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		bool activeSelf = ۴_u05EBی_u.activeSelf;
		int ralspeed = 57344;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("friend", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x000080A4 File Offset: 0x000062A4
	[Token(Token = "0x60000D7")]
	[Address(RVA = "0x2C1AD60", Offset = "0x2C1AD60", VA = "0x2C1AD60")]
	public void ޝ\u088Dނپ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Round end");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 8192;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("On", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x00008380 File Offset: 0x00006580
	[Token(Token = "0x60000D8")]
	[Address(RVA = "0x2C1B178", Offset = "0x2C1B178", VA = "0x2C1B178")]
	public void ڇӪࢰࡔ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string text = DateTime.UtcNow.ToString("_Tint");
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 49152;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("StartSong", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x00008654 File Offset: 0x00006854
	[Token(Token = "0x60000D9")]
	[Address(RVA = "0x2C1B594", Offset = "0x2C1B594", VA = "0x2C1B594")]
	public void ڿ\u06E6\u088E\u06FD()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("MetaAuth");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 17435;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("containsStaff", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060000DA RID: 218 RVA: 0x000087F0 File Offset: 0x000069F0
	[Token(Token = "0x60000DA")]
	[Address(RVA = "0x2C1B818", Offset = "0x2C1B818", VA = "0x2C1B818")]
	public void \u0883ދ\u066C\u0859()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Platform failed to initialize due to exception.");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 8192;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("INSIGNIFICANT CURRENCY", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000DB RID: 219 RVA: 0x00008AC8 File Offset: 0x00006CC8
	[Token(Token = "0x60000DB")]
	[Address(RVA = "0x2C1BC2C", Offset = "0x2C1BC2C", VA = "0x2C1BC2C")]
	public void ۍ\u05CAۋݿ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("All audio clips have been played.");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		GameObject ۴_u05EBی_u = this.۴\u05EBی\u0823;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		bool activeSelf = ۴_u05EBی_u.activeSelf;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Display Name Changed!", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000DC RID: 220 RVA: 0x00008DC4 File Offset: 0x00006FC4
	[Token(Token = "0x60000DC")]
	[Address(RVA = "0x2C1C044", Offset = "0x2C1C044", VA = "0x2C1C044")]
	public void ࠇ\u087DػՏ()
	{
		if (!true)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("ScoreCounter");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		GameObject ۴_u05EBی_u = this.۴\u05EBی\u0823;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		bool activeSelf = ۴_u05EBی_u.activeSelf;
		int ralspeed = 17388;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("duration done", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000DD RID: 221 RVA: 0x00009084 File Offset: 0x00007284
	[Token(Token = "0x60000DD")]
	[Address(RVA = "0x2C1C450", Offset = "0x2C1C450", VA = "0x2C1C450")]
	public void Կשܐӵ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString(" and the correct version is ");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 24576;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060000DE RID: 222 RVA: 0x00009224 File Offset: 0x00007424
	[Token(Token = "0x60000DE")]
	[Address(RVA = "0x2C1C6D8", Offset = "0x2C1C6D8", VA = "0x2C1C6D8")]
	public void \u0887ࡒ\u0613\u07B8()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("User has been reported for: ");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 24576;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Trigger", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000DF RID: 223 RVA: 0x000094F0 File Offset: 0x000076F0
	[Token(Token = "0x60000DF")]
	[Address(RVA = "0x2C1CAF4", Offset = "0x2C1CAF4", VA = "0x2C1CAF4")]
	public void \u0890ؤߪފ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		DateTime utcNow = DateTime.UtcNow;
		string ӫࢡ_u06D7_u05F;
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		Material material = this.ڥڲӷډ;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("jump char false", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x00009664 File Offset: 0x00007864
	[Token(Token = "0x60000E0")]
	[Address(RVA = "0x2C1CD80", Offset = "0x2C1CD80", VA = "0x2C1CD80")]
	public void \u070EࢣԀ\u07A9()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Tagged");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 49152;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		Material material = this.ڥڲӷډ;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("HDRP/Lit", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num2 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		ڞه_u0749_u089D.volume = num3;
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x000097EC File Offset: 0x000079EC
	[Token(Token = "0x60000E1")]
	[Address(RVA = "0x2C1D008", Offset = "0x2C1D008", VA = "0x2C1D008")]
	public void ߪձԛމ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Vector1_d371bd24217449349bd747533d51af6b");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 24576;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("username", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000E2 RID: 226 RVA: 0x00009AB8 File Offset: 0x00007CB8
	[Token(Token = "0x60000E2")]
	[Address(RVA = "0x2C1D414", Offset = "0x2C1D414", VA = "0x2C1D414")]
	public void ա\u0731ࢺۊ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		DateTime utcNow = DateTime.UtcNow;
		string ӫࢡ_u06D7_u05F;
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 24576;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("hh:mmtt", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x00009D94 File Offset: 0x00007F94
	[Token(Token = "0x60000E3")]
	[Address(RVA = "0x2C1D830", Offset = "0x2C1D830", VA = "0x2C1D830")]
	public void ݲ\u06E6ҽࡩ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("ChangeToTagged");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 17082;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("FingerTip", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000E4 RID: 228 RVA: 0x0000A088 File Offset: 0x00008288
	[Token(Token = "0x60000E4")]
	[Address(RVA = "0x2C1DC50", Offset = "0x2C1DC50", VA = "0x2C1DC50")]
	public BetterWeatherCycle()
	{
	}

	// Token: 0x060000E5 RID: 229 RVA: 0x0000A09C File Offset: 0x0000829C
	[Token(Token = "0x60000E5")]
	[Address(RVA = "0x2C1DC58", Offset = "0x2C1DC58", VA = "0x2C1DC58")]
	public void ןأ\u05C0ب()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Body");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		GameObject ۴_u05EBی_u = this.۴\u05EBی\u0823;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		bool activeSelf = ۴_u05EBی_u.activeSelf;
		int ralspeed = 17599;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("PlayerDeath", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x0000A394 File Offset: 0x00008594
	[Token(Token = "0x60000E6")]
	[Address(RVA = "0x2C1E070", Offset = "0x2C1E070", VA = "0x2C1E070")]
	public void ם\u06FDւԋ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Reason: ");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		int ralspeed = 57344;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("INSIGNIFICANT CURRENCY", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x0000A670 File Offset: 0x00008870
	[Token(Token = "0x60000E7")]
	[Address(RVA = "0x2C1E484", Offset = "0x2C1E484", VA = "0x2C1E484")]
	public void Աࢦ\u05CAޡ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 17303;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("amongus", value);
		bool ӻهࡀ_u05C = this.ӻهࡀ\u05C1;
		if (ӻهࡀ_u05C)
		{
			this.ڞه\u0749\u089D.Play();
			this.ӻهࡀ\u05C1 = ӻهࡀ_u05C;
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x0000A948 File Offset: 0x00008B48
	[Token(Token = "0x60000E8")]
	[Address(RVA = "0x2C1E89C", Offset = "0x2C1E89C", VA = "0x2C1E89C")]
	public void \u055F\u073C\u05F9Ԟ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("PlayerHead");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 17428;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("TurnAmount", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x0000AC14 File Offset: 0x00008E14
	[Token(Token = "0x60000E9")]
	[Address(RVA = "0x2C1ECB4", Offset = "0x2C1ECB4", VA = "0x2C1ECB4")]
	public void ԣ\u0731\u0879ܕ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("TurnAmount");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 32768;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Players: ", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000EA RID: 234 RVA: 0x0000AEE4 File Offset: 0x000090E4
	[Token(Token = "0x60000EA")]
	[Address(RVA = "0x2C1F0CC", Offset = "0x2C1F0CC", VA = "0x2C1F0CC")]
	public void \u0604\u07B7ࢺݭ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Hats");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		GameObject ۴_u05EBی_u = this.۴\u05EBی\u0823;
		long u06EA_u0894ԥ٠ = 1L;
		this.\u06EA\u0894ԥ٠ = (u06EA_u0894ԥ٠ != 0L);
		bool activeSelf = ۴_u05EBی_u.activeSelf;
		int ralspeed = 16384;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("hand 1", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000EB RID: 235 RVA: 0x0000B1D8 File Offset: 0x000093D8
	[Token(Token = "0x60000EB")]
	[Address(RVA = "0x2C1F4E0", Offset = "0x2C1F4E0", VA = "0x2C1F4E0")]
	public void ڏי\u06E6\u070A()
	{
		if ("_platform" == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("HandL");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		float r = this.ן\u0704\u058F߅.r;
		float g = this.ן\u0704\u058F߅.g;
		float b = this.ן\u0704\u058F߅.b;
		float a = this.ן\u0704\u058F߅.a;
		int ralspeed = 17280;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		long num = 1L;
		this.ӑטԖک = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num2;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime2 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("BN", value);
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime3 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime4 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		AudioSource ڞه_u0749_u089D = this.ڞه\u0749\u089D;
		float num3 = ڞه_u0749_u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
		float num4;
		ڞه_u0749_u089D.volume = num4;
	}

	// Token: 0x060000EC RID: 236 RVA: 0x0000B380 File Offset: 0x00009580
	[Token(Token = "0x60000EC")]
	[Address(RVA = "0x2C1F768", Offset = "0x2C1F768", VA = "0x2C1F768")]
	public void Ա\u07B9ߒݗ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("isLava");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 32768;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000ED RID: 237 RVA: 0x0000B644 File Offset: 0x00009844
	[Token(Token = "0x60000ED")]
	[Address(RVA = "0x2C1FB88", Offset = "0x2C1FB88", VA = "0x2C1FB88")]
	public void կսҾ\u06E4()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Player");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 24576;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("tp 2", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000EE RID: 238 RVA: 0x0000B92C File Offset: 0x00009B2C
	[Token(Token = "0x60000EE")]
	[Address(RVA = "0x2C1FFA4", Offset = "0x2C1FFA4", VA = "0x2C1FFA4")]
	public void Ԧ\u0876ծՎ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("SetColor");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 49152;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat(" ", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000EF RID: 239 RVA: 0x0000BC14 File Offset: 0x00009E14
	[Token(Token = "0x60000EF")]
	[Address(RVA = "0x2C203C4", Offset = "0x2C203C4", VA = "0x2C203C4")]
	public void \u05AAࢦ\u060AԞ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string text = DateTime.UtcNow.ToString("Joined Public Room Successfully");
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 40960;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Not enough amount of currency", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x0000BEBC File Offset: 0x0000A0BC
	[Token(Token = "0x60000F0")]
	[Address(RVA = "0x2C207E0", Offset = "0x2C207E0", VA = "0x2C207E0")]
	public void \u081E١Ӕࢦ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Display Name Changed!");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		string ӫࢡ_u06D7_u05F2 = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("hh:mmtt", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
			long ӻهࡀ_u05C = 1L;
			this.ӻهࡀ\u05C1 = (ӻهࡀ_u05C != 0L);
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x0000C18C File Offset: 0x0000A38C
	[Token(Token = "0x60000F1")]
	[Address(RVA = "0x2C20BFC", Offset = "0x2C20BFC", VA = "0x2C20BFC")]
	public void \u089Aۆ\u0887\u05C0()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string text = DateTime.UtcNow.ToString(" and the correct version is ");
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		bool activeSelf = this.۴\u05EBی\u0823.activeSelf;
		int ralspeed = 24576;
		this.ݛՖ\u0605ࠇ.RALspeed = (float)ralspeed;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float flspeed = this.ݛՖ\u0605ࠇ.FLspeed;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.ר\u086E\u05B0\u083E.emission;
		float u0881ޡࡅ_u05B = this.\u0881ޡࡅ\u05B9;
		ParticleSystem.MinMaxCurve minMaxCurve = num;
		float u0881ޡࡅ_u05B2 = this.\u0881ޡࡅ\u05B9;
		float deltaTime2 = Time.deltaTime;
		float rlspeed = this.ݛՖ\u0605ࠇ.RLspeed;
		Volume volume = this.volume;
		this.\u0881ޡࡅ\u05B9 = u0881ޡࡅ_u05B;
		float weight = volume.weight;
		float deltaTime3 = Time.deltaTime;
		float volumeWeightSpeed = this.ݛՖ\u0605ࠇ.volumeWeightSpeed;
		volume.weight = u0881ޡࡅ_u05B;
		Material material = this.ڥڲӷډ;
		float ٠ػע_u05AB = this.٠ػע\u05AB;
		float deltaTime4 = Time.deltaTime;
		float cloudLerpSpeed = this.ݛՖ\u0605ࠇ.cloudLerpSpeed;
		float value;
		material.SetFloat("Regular", value);
		if (this.ӻهࡀ\u05C1)
		{
			this.ڞه\u0749\u089D.Play();
		}
		float num2 = this.ڞه\u0749\u089D.volume;
		float deltaTime5 = Time.deltaTime;
		float ralspeed2 = this.ݛՖ\u0605ࠇ.RALspeed;
	}

	// Token: 0x0400000A RID: 10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400000A")]
	[Space]
	public bool \u06EA\u0894ԥ٠;

	// Token: 0x0400000B RID: 11
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x400000B")]
	[Space]
	public BetterWeatherCycle.\u089Dԁ߃\u0888 ࢢ\u088CӦ\u082C;

	// Token: 0x0400000C RID: 12
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400000C")]
	public Color ן\u0704\u058F߅;

	// Token: 0x0400000D RID: 13
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400000D")]
	public ParticleSystem ר\u086E\u05B0\u083E;

	// Token: 0x0400000E RID: 14
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400000E")]
	public bool ӑטԖک;

	// Token: 0x0400000F RID: 15
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400000F")]
	public Material ڥڲӷډ;

	// Token: 0x04000010 RID: 16
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000010")]
	public BetterWeatherCycle.lerpSpeeds ݛՖ\u0605ࠇ;

	// Token: 0x04000011 RID: 17
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000011")]
	[SerializeField]
	private Volume volume;

	// Token: 0x04000012 RID: 18
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000012")]
	private float \u0881ޡࡅ\u05B9;

	// Token: 0x04000013 RID: 19
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000013")]
	public GameObject ۴\u05EBی\u0823;

	// Token: 0x04000014 RID: 20
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000014")]
	public AudioSource ڞه\u0749\u089D;

	// Token: 0x04000015 RID: 21
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4000015")]
	private float ٠ػע\u05AB;

	// Token: 0x04000016 RID: 22
	[FieldOffset(Offset = "0x84")]
	[Token(Token = "0x4000016")]
	public bool ӻهࡀ\u05C1;

	// Token: 0x04000017 RID: 23
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x4000017")]
	public BetterWeatherCycle.Thunder ࡐ\u085E\u089Eԉ;

	// Token: 0x04000018 RID: 24
	[FieldOffset(Offset = "0xB0")]
	[Token(Token = "0x4000018")]
	private bool \u088FӨ\u065F\u05C1;

	// Token: 0x04000019 RID: 25
	[FieldOffset(Offset = "0xB8")]
	[Token(Token = "0x4000019")]
	[Space]
	public string ӫࢡ\u06D7\u05F9;

	// Token: 0x0400001A RID: 26
	[FieldOffset(Offset = "0xC0")]
	[Token(Token = "0x400001A")]
	[Space]
	public List<string> Հ\u0816\u085Dߙ;

	// Token: 0x02000006 RID: 6
	[Token(Token = "0x2000006")]
	public enum \u089Dԁ߃\u0888
	{
		// Token: 0x0400001C RID: 28
		[Token(Token = "0x400001C")]
		Ԁࡩػ\u086F,
		// Token: 0x0400001D RID: 29
		[Token(Token = "0x400001D")]
		[InspectorName("Rain & Thunder")]
		ڔ\u07BF\u07B9ܛ
	}

	// Token: 0x02000007 RID: 7
	[Token(Token = "0x2000007")]
	[Serializable]
	public struct lerpSpeeds
	{
		// Token: 0x0400001E RID: 30
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400001E")]
		[Header("Lerp Values (Order should be 10, 1, 1, and 1)")]
		public float FLspeed;

		// Token: 0x0400001F RID: 31
		[FieldOffset(Offset = "0x4")]
		[Token(Token = "0x400001F")]
		public float volumeWeightSpeed;

		// Token: 0x04000020 RID: 32
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4000020")]
		public float RLspeed;

		// Token: 0x04000021 RID: 33
		[FieldOffset(Offset = "0xC")]
		[Token(Token = "0x4000021")]
		public float RALspeed;

		// Token: 0x04000022 RID: 34
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000022")]
		public float cloudLerpSpeed;
	}

	// Token: 0x02000008 RID: 8
	[Token(Token = "0x2000008")]
	[Serializable]
	public struct Thunder
	{
		// Token: 0x04000023 RID: 35
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000023")]
		public Transform[] possibleLightningStrikes;

		// Token: 0x04000024 RID: 36
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4000024")]
		public AudioSource thunder;

		// Token: 0x04000025 RID: 37
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000025")]
		public AudioClip[] sounds;

		// Token: 0x04000026 RID: 38
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000026")]
		public ParticleSystem strike;

		// Token: 0x04000027 RID: 39
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000027")]
		public GameObject thunderThing;
	}
}
