﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020000FD RID: 253
[Token(Token = "0x20000FD")]
public class SimpleCarController : MonoBehaviour
{
	// Token: 0x06002731 RID: 10033 RVA: 0x000E4BB0 File Offset: 0x000E2DB0
	[Token(Token = "0x6002731")]
	[Address(RVA = "0x2B6DE8C", Offset = "0x2B6DE8C", VA = "0x2B6DE8C")]
	public void ߪձԛމ()
	{
		bool flag = this.ރٹԨҼ;
		if (!flag)
		{
			return;
		}
		if (!flag)
		{
		}
		float u0655ࢰ_u0596۹ = this.\u0655ࢰ\u0596۹;
		Transform ԅڒ٠Ӻ = this.Ԅڒ٠Ӻ;
		float u0609غ_u05A8ئ = this.\u0609غ\u05A8ئ;
		Quaternion localRotation = ԅڒ٠Ӻ.localRotation;
		bool flag2 = this.۸עݮז.GetEnumerator().MoveNext();
		if (this.ߧ\u0614وԽ)
		{
			float ݷܕԅ_u = this.ݷܕԅ\u0817;
			float ݷܕԅ_u2 = this.ݷܕԅ\u0817;
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x06002732 RID: 10034 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002732")]
	[Address(RVA = "0x2B6E350", Offset = "0x2B6E350", VA = "0x2B6E350")]
	public void \u0704زք٥()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002733 RID: 10035 RVA: 0x000E4C70 File Offset: 0x000E2E70
	[Token(Token = "0x6002733")]
	[Address(RVA = "0x2B6E44C", Offset = "0x2B6E44C", VA = "0x2B6E44C")]
	private void \u06D6ې\u083Bࠉ()
	{
		Rigidbody component = base.GetComponent<Rigidbody>();
		float x = this.ݔؼࢩࡐ.x;
		float y = this.ݔؼࢩࡐ.y;
		float z = this.ݔؼࢩࡐ.z;
	}

	// Token: 0x06002734 RID: 10036 RVA: 0x000E4CB0 File Offset: 0x000E2EB0
	[Token(Token = "0x6002734")]
	[Address(RVA = "0x2B6E4B0", Offset = "0x2B6E4B0", VA = "0x2B6E4B0")]
	public void ڀݩӐ\u05C8(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002735 RID: 10037 RVA: 0x000E4CF0 File Offset: 0x000E2EF0
	[Token(Token = "0x6002735")]
	[Address(RVA = "0x2B6E57C", Offset = "0x2B6E57C", VA = "0x2B6E57C")]
	public void جԝ߅ӈ(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002736 RID: 10038 RVA: 0x000E4D30 File Offset: 0x000E2F30
	[Token(Token = "0x6002736")]
	[Address(RVA = "0x2B6E648", Offset = "0x2B6E648", VA = "0x2B6E648")]
	public void \u0883ދ\u066C\u0859()
	{
		bool flag = this.ރٹԨҼ;
		if (!flag)
		{
			return;
		}
		if (!flag)
		{
		}
		float u0655ࢰ_u0596۹ = this.\u0655ࢰ\u0596۹;
		Transform ԅڒ٠Ӻ = this.Ԅڒ٠Ӻ;
		float u0609غ_u05A8ئ = this.\u0609غ\u05A8ئ;
		Quaternion localRotation = ԅڒ٠Ӻ.localRotation;
		bool flag2 = this.۸עݮז.GetEnumerator().MoveNext();
		if (this.ߧ\u0614وԽ)
		{
			float ݷܕԅ_u = this.ݷܕԅ\u0817;
			float ݷܕԅ_u2 = this.ݷܕԅ\u0817;
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x06002737 RID: 10039 RVA: 0x000E4DF0 File Offset: 0x000E2FF0
	[Token(Token = "0x6002737")]
	[Address(RVA = "0x2B6EA40", Offset = "0x2B6EA40", VA = "0x2B6EA40")]
	private void ӛ\u082Eؿڕ()
	{
	}

	// Token: 0x06002738 RID: 10040 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002738")]
	[Address(RVA = "0x2B6EAA4", Offset = "0x2B6EAA4", VA = "0x2B6EAA4")]
	public void ւࢢدࠈ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002739 RID: 10041 RVA: 0x000E4E04 File Offset: 0x000E3004
	[Token(Token = "0x6002739")]
	[Address(RVA = "0x2B6E1B8", Offset = "0x2B6E1B8", VA = "0x2B6E1B8")]
	public void ࠊ\u061Cھ\u06D9(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x0600273A RID: 10042 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600273A")]
	[Address(RVA = "0x2B6EBAC", Offset = "0x2B6EBAC", VA = "0x2B6EBAC")]
	public void \u064Dۿ\u07BB\u05C0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600273B RID: 10043 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600273B")]
	[Address(RVA = "0x2B6ECB4", Offset = "0x2B6ECB4", VA = "0x2B6ECB4")]
	public void ݠ\u07EBӁ\u0652()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600273C RID: 10044 RVA: 0x000E4E44 File Offset: 0x000E3044
	[Token(Token = "0x600273C")]
	[Address(RVA = "0x2B6E284", Offset = "0x2B6E284", VA = "0x2B6E284")]
	public void \u0558ޏܜ\u088E(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x0600273D RID: 10045 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600273D")]
	[Address(RVA = "0x2B6EDBC", Offset = "0x2B6EDBC", VA = "0x2B6EDBC")]
	public void ࡣؠڇڠ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600273E RID: 10046 RVA: 0x000E4E84 File Offset: 0x000E3084
	[Token(Token = "0x600273E")]
	[Address(RVA = "0x2B6E974", Offset = "0x2B6E974", VA = "0x2B6E974")]
	public void \u055D߉աԾ(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x0600273F RID: 10047 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600273F")]
	[Address(RVA = "0x2B6EEC4", Offset = "0x2B6EEC4", VA = "0x2B6EEC4")]
	public void ӪࢶԒ\u06E1()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002740 RID: 10048 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002740")]
	[Address(RVA = "0x2B6EFCC", Offset = "0x2B6EFCC", VA = "0x2B6EFCC")]
	private void ݱ\u0832ݥ\u08B5()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002741 RID: 10049 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002741")]
	[Address(RVA = "0x2B6F030", Offset = "0x2B6F030", VA = "0x2B6F030")]
	public void \u060Bݐ\u0745ࢣ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002742 RID: 10050 RVA: 0x000E4EC4 File Offset: 0x000E30C4
	[Token(Token = "0x6002742")]
	[Address(RVA = "0x2B6F12C", Offset = "0x2B6F12C", VA = "0x2B6F12C")]
	public SimpleCarController()
	{
	}

	// Token: 0x06002743 RID: 10051 RVA: 0x000E4ED8 File Offset: 0x000E30D8
	[Token(Token = "0x6002743")]
	[Address(RVA = "0x2B6F134", Offset = "0x2B6F134", VA = "0x2B6F134")]
	private void عۻԂ\u055E()
	{
		Rigidbody component = base.GetComponent<Rigidbody>();
		float x = this.ݔؼࢩࡐ.x;
		float y = this.ݔؼࢩࡐ.y;
		float z = this.ݔؼࢩࡐ.z;
	}

	// Token: 0x06002744 RID: 10052 RVA: 0x000E4F18 File Offset: 0x000E3118
	[Token(Token = "0x6002744")]
	[Address(RVA = "0x2B6F198", Offset = "0x2B6F198", VA = "0x2B6F198")]
	private void \u0558ݕݤݮ()
	{
		Rigidbody component = base.GetComponent<Rigidbody>();
		float x = this.ݔؼࢩࡐ.x;
		float y = this.ݔؼࢩࡐ.y;
		float z = this.ݔؼࢩࡐ.z;
	}

	// Token: 0x06002745 RID: 10053 RVA: 0x000E4F58 File Offset: 0x000E3158
	[Token(Token = "0x6002745")]
	[Address(RVA = "0x2B6F1FC", Offset = "0x2B6F1FC", VA = "0x2B6F1FC")]
	public void \u089Bځԯԝ()
	{
		bool flag = this.ރٹԨҼ;
		if (!flag)
		{
			return;
		}
		if (!flag)
		{
		}
		float u0655ࢰ_u0596۹ = this.\u0655ࢰ\u0596۹;
		Transform ԅڒ٠Ӻ = this.Ԅڒ٠Ӻ;
		float u0609غ_u05A8ئ = this.\u0609غ\u05A8ئ;
		Quaternion localRotation = ԅڒ٠Ӻ.localRotation;
		bool flag2 = this.۸עݮז.GetEnumerator().MoveNext();
		if (this.ߧ\u0614وԽ)
		{
			float ݷܕԅ_u = this.ݷܕԅ\u0817;
			float ݷܕԅ_u2 = this.ݷܕԅ\u0817;
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x06002746 RID: 10054 RVA: 0x000E5018 File Offset: 0x000E3218
	[Token(Token = "0x6002746")]
	[Address(RVA = "0x2B6F5F4", Offset = "0x2B6F5F4", VA = "0x2B6F5F4")]
	public void Ձռ\u0878ۺ(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002747 RID: 10055 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002747")]
	[Address(RVA = "0x2B6F6C0", Offset = "0x2B6F6C0", VA = "0x2B6F6C0")]
	public void ҽגٻ\u05B7()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002748 RID: 10056 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002748")]
	[Address(RVA = "0x2B6F7C8", Offset = "0x2B6F7C8", VA = "0x2B6F7C8")]
	public void Ԁ\u05EB\u085Eՠ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002749 RID: 10057 RVA: 0x000E5058 File Offset: 0x000E3258
	[Token(Token = "0x6002749")]
	[Address(RVA = "0x2B6F8DC", Offset = "0x2B6F8DC", VA = "0x2B6F8DC")]
	private void Ԯ\u0883\u0591\u066C()
	{
		Rigidbody component = base.GetComponent<Rigidbody>();
		float x = this.ݔؼࢩࡐ.x;
		float y = this.ݔؼࢩࡐ.y;
		float z = this.ݔؼࢩࡐ.z;
	}

	// Token: 0x0600274A RID: 10058 RVA: 0x000E5098 File Offset: 0x000E3298
	[Token(Token = "0x600274A")]
	[Address(RVA = "0x2B6F940", Offset = "0x2B6F940", VA = "0x2B6F940")]
	private void ܩחݵޔ()
	{
		Rigidbody component = base.GetComponent<Rigidbody>();
		float x = this.ݔؼࢩࡐ.x;
		float y = this.ݔؼࢩࡐ.y;
		float z = this.ݔؼࢩࡐ.z;
	}

	// Token: 0x0600274B RID: 10059 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600274B")]
	[Address(RVA = "0x2B6F9A4", Offset = "0x2B6F9A4", VA = "0x2B6F9A4")]
	public void Ա\u05F9\u05BDܫ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600274C RID: 10060 RVA: 0x000E50D8 File Offset: 0x000E32D8
	[Token(Token = "0x600274C")]
	[Address(RVA = "0x2B6FAA0", Offset = "0x2B6FAA0", VA = "0x2B6FAA0")]
	public void ւܛ\u0593ߢ(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x0600274D RID: 10061 RVA: 0x000E5118 File Offset: 0x000E3318
	[Token(Token = "0x600274D")]
	[Address(RVA = "0x2B6FB6C", Offset = "0x2B6FB6C", VA = "0x2B6FB6C")]
	public void \u0745տ\u058Dվ(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x0600274E RID: 10062 RVA: 0x000E5158 File Offset: 0x000E3358
	[Token(Token = "0x600274E")]
	[Address(RVA = "0x2B6FC38", Offset = "0x2B6FC38", VA = "0x2B6FC38")]
	public void ࡐߩԇ\u05AD(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x0600274F RID: 10063 RVA: 0x000E5198 File Offset: 0x000E3398
	[Token(Token = "0x600274F")]
	[Address(RVA = "0x2B6FD04", Offset = "0x2B6FD04", VA = "0x2B6FD04")]
	public void Ӑ\u0876\u0738չ(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002750 RID: 10064 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002750")]
	[Address(RVA = "0x2B6FDD0", Offset = "0x2B6FDD0", VA = "0x2B6FDD0")]
	public void קܥ\u061Dߧ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002751 RID: 10065 RVA: 0x000E51D8 File Offset: 0x000E33D8
	[Token(Token = "0x6002751")]
	[Address(RVA = "0x2B6F528", Offset = "0x2B6F528", VA = "0x2B6F528")]
	public void ն\u06E4۸ޥ(WheelCollider ݱӶ\u065Bԟ)
	{
		if (ݱӶ\u065Bԟ.transform.childCount != 0)
		{
			Transform transform = ݱӶ\u065Bԟ.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002752 RID: 10066 RVA: 0x000E5218 File Offset: 0x000E3418
	[Token(Token = "0x6002752")]
	[Address(RVA = "0x2B6FED8", Offset = "0x2B6FED8", VA = "0x2B6FED8")]
	private void Start()
	{
		Rigidbody component = base.GetComponent<Rigidbody>();
		float x = this.ݔؼࢩࡐ.x;
		float y = this.ݔؼࢩࡐ.y;
		float z = this.ݔؼࢩࡐ.z;
	}

	// Token: 0x06002753 RID: 10067 RVA: 0x000E5258 File Offset: 0x000E3458
	[Token(Token = "0x6002753")]
	[Address(RVA = "0x2B6FF3C", Offset = "0x2B6FF3C", VA = "0x2B6FF3C")]
	private void نո\u0599\u0589()
	{
		Rigidbody component = base.GetComponent<Rigidbody>();
		float x = this.ݔؼࢩࡐ.x;
		float y = this.ݔؼࢩࡐ.y;
		float z = this.ݔؼࢩࡐ.z;
	}

	// Token: 0x06002754 RID: 10068 RVA: 0x000E5298 File Offset: 0x000E3498
	[Token(Token = "0x6002754")]
	[Address(RVA = "0x2B6FFA0", Offset = "0x2B6FFA0", VA = "0x2B6FFA0")]
	public void \u07AAح\u087Fܩ()
	{
		long num = 1L;
		if (num != 0L)
		{
			if (num == 0L)
			{
			}
			List.Enumerator enumerator;
			bool flag = enumerator.MoveNext();
			return;
		}
	}

	// Token: 0x06002755 RID: 10069 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002755")]
	[Address(RVA = "0x2B702CC", Offset = "0x2B702CC", VA = "0x2B702CC")]
	public void \u0747ݦޖݔ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002756 RID: 10070 RVA: 0x000E5310 File Offset: 0x000E3510
	[Token(Token = "0x6002756")]
	[Address(RVA = "0x2B703C8", Offset = "0x2B703C8", VA = "0x2B703C8")]
	private void ݤۅࢦӃ()
	{
		Rigidbody component = base.GetComponent<Rigidbody>();
		float x = this.ݔؼࢩࡐ.x;
		float y = this.ݔؼࢩࡐ.y;
		float z = this.ݔؼࢩࡐ.z;
	}

	// Token: 0x06002757 RID: 10071 RVA: 0x000E5350 File Offset: 0x000E3550
	[Token(Token = "0x6002757")]
	[Address(RVA = "0x2B7042C", Offset = "0x2B7042C", VA = "0x2B7042C")]
	public void \u05AAࢦ\u060AԞ()
	{
		bool flag = this.ރٹԨҼ;
		if (!flag)
		{
			return;
		}
		if (!flag)
		{
		}
		float u0655ࢰ_u0596۹ = this.\u0655ࢰ\u0596۹;
		Transform ԅڒ٠Ӻ = this.Ԅڒ٠Ӻ;
		float u0609غ_u05A8ئ = this.\u0609غ\u05A8ئ;
		Quaternion localRotation = ԅڒ٠Ӻ.localRotation;
		bool flag2 = this.۸עݮז.GetEnumerator().MoveNext();
		if (this.ߧ\u0614وԽ)
		{
			float ݷܕԅ_u = this.ݷܕԅ\u0817;
			float ݷܕԅ_u2 = this.ݷܕԅ\u0817;
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x06002758 RID: 10072 RVA: 0x000E5410 File Offset: 0x000E3610
	[Token(Token = "0x6002758")]
	[Address(RVA = "0x2B70758", Offset = "0x2B70758", VA = "0x2B70758")]
	private void \u082E\u06EBݼڏ()
	{
		Rigidbody component = base.GetComponent<Rigidbody>();
		float x = this.ݔؼࢩࡐ.x;
		float y = this.ݔؼࢩࡐ.y;
		float z = this.ݔؼࢩࡐ.z;
	}

	// Token: 0x06002759 RID: 10073 RVA: 0x000E5450 File Offset: 0x000E3650
	[Token(Token = "0x6002759")]
	[Address(RVA = "0x2B707BC", Offset = "0x2B707BC", VA = "0x2B707BC")]
	public void FixedUpdate()
	{
		bool flag = this.ރٹԨҼ;
		if (!flag)
		{
			return;
		}
		if (!flag)
		{
		}
		float u0655ࢰ_u0596۹ = this.\u0655ࢰ\u0596۹;
		Transform ԅڒ٠Ӻ = this.Ԅڒ٠Ӻ;
		float u0609غ_u05A8ئ = this.\u0609غ\u05A8ئ;
		Quaternion localRotation = ԅڒ٠Ӻ.localRotation;
		bool flag2 = this.۸עݮז.GetEnumerator().MoveNext();
		if (this.ߧ\u0614وԽ)
		{
			float ݷܕԅ_u = this.ݷܕԅ\u0817;
			float ݷܕԅ_u2 = this.ݷܕԅ\u0817;
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x0600275A RID: 10074 RVA: 0x000E5510 File Offset: 0x000E3710
	[Token(Token = "0x600275A")]
	[Address(RVA = "0x2B70AD8", Offset = "0x2B70AD8", VA = "0x2B70AD8")]
	public void \u05BBږ\u060Cࡑ()
	{
		bool flag = this.ރٹԨҼ;
		if (!flag)
		{
			return;
		}
		if (!flag)
		{
		}
		float u0655ࢰ_u0596۹ = this.\u0655ࢰ\u0596۹;
		Transform ԅڒ٠Ӻ = this.Ԅڒ٠Ӻ;
		float u0609غ_u05A8ئ = this.\u0609غ\u05A8ئ;
		Quaternion localRotation = ԅڒ٠Ӻ.localRotation;
		bool flag2 = this.۸עݮז.GetEnumerator().MoveNext();
		if (this.ߧ\u0614وԽ)
		{
			float ݷܕԅ_u = this.ݷܕԅ\u0817;
			float ݷܕԅ_u2 = this.ݷܕԅ\u0817;
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x0600275B RID: 10075 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600275B")]
	[Address(RVA = "0x2B70E04", Offset = "0x2B70E04", VA = "0x2B70E04")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600275C RID: 10076 RVA: 0x000E55D0 File Offset: 0x000E37D0
	[Token(Token = "0x600275C")]
	[Address(RVA = "0x2B70F00", Offset = "0x2B70F00", VA = "0x2B70F00")]
	public void ޗٻ\u0825ڔ()
	{
		bool flag = this.ރٹԨҼ;
		if (!flag)
		{
			return;
		}
		if (!flag)
		{
		}
		float u0655ࢰ_u0596۹ = this.\u0655ࢰ\u0596۹;
		Transform ԅڒ٠Ӻ = this.Ԅڒ٠Ӻ;
		float u0609غ_u05A8ئ = this.\u0609غ\u05A8ئ;
		Quaternion localRotation = ԅڒ٠Ӻ.localRotation;
		bool flag2 = this.۸עݮז.GetEnumerator().MoveNext();
		if (this.ߧ\u0614وԽ)
		{
			float ݷܕԅ_u = this.ݷܕԅ\u0817;
			float ݷܕԅ_u2 = this.ݷܕԅ\u0817;
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x0600275D RID: 10077 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600275D")]
	[Address(RVA = "0x2B7122C", Offset = "0x2B7122C", VA = "0x2B7122C")]
	public void \u0706\u05CDߜح()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x040004F5 RID: 1269
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004F5")]
	public List<AxleInfo> ۸עݮז;

	// Token: 0x040004F6 RID: 1270
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004F6")]
	public float \u0655ࢰ\u0596۹;

	// Token: 0x040004F7 RID: 1271
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x40004F7")]
	public float \u0609غ\u05A8ئ;

	// Token: 0x040004F8 RID: 1272
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40004F8")]
	private InputDevice ࠊފ\u064FӪ;

	// Token: 0x040004F9 RID: 1273
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40004F9")]
	private InputDevice ߌԙՏޚ;

	// Token: 0x040004FA RID: 1274
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40004FA")]
	public float ݷܕԅ\u0817;

	// Token: 0x040004FB RID: 1275
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40004FB")]
	public Transform Ԅڒ٠Ӻ;

	// Token: 0x040004FC RID: 1276
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40004FC")]
	public Vector3 ݔؼࢩࡐ;

	// Token: 0x040004FD RID: 1277
	[FieldOffset(Offset = "0x64")]
	[Token(Token = "0x40004FD")]
	public bool ރٹԨҼ;

	// Token: 0x040004FE RID: 1278
	[FieldOffset(Offset = "0x65")]
	[Token(Token = "0x40004FE")]
	private bool ߧ\u0614وԽ;
}
