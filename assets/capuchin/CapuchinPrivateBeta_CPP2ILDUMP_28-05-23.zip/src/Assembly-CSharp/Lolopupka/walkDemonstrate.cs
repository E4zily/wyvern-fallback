﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x02000105 RID: 261
	[Token(Token = "0x2000105")]
	public class walkDemonstrate : MonoBehaviour
	{
		// Token: 0x06002844 RID: 10308 RVA: 0x000F4F64 File Offset: 0x000F3164
		[Token(Token = "0x6002844")]
		[Address(RVA = "0x2120E88", Offset = "0x2120E88", VA = "0x2120E88")]
		private void \u061B\u05EEوۈ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x06002845 RID: 10309 RVA: 0x000F4FE0 File Offset: 0x000F31E0
		[Token(Token = "0x6002845")]
		[Address(RVA = "0x2121004", Offset = "0x2121004", VA = "0x2121004")]
		private void Update()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E2 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E2;
		}

		// Token: 0x06002846 RID: 10310 RVA: 0x000F5060 File Offset: 0x000F3260
		[Token(Token = "0x6002846")]
		[Address(RVA = "0x212119C", Offset = "0x212119C", VA = "0x212119C")]
		private void ڑߒجވ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x06002847 RID: 10311 RVA: 0x000F50D0 File Offset: 0x000F32D0
		[Token(Token = "0x6002847")]
		[Address(RVA = "0x2121314", Offset = "0x2121314", VA = "0x2121314")]
		private void \u087BӦןݩ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E3 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E3;
		}

		// Token: 0x06002848 RID: 10312 RVA: 0x000F515C File Offset: 0x000F335C
		[Token(Token = "0x6002848")]
		[Address(RVA = "0x21214B0", Offset = "0x21214B0", VA = "0x21214B0")]
		private void \u05EDց\u081Cت()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E2 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E2;
		}

		// Token: 0x06002849 RID: 10313 RVA: 0x000F51DC File Offset: 0x000F33DC
		[Token(Token = "0x6002849")]
		[Address(RVA = "0x2121648", Offset = "0x2121648", VA = "0x2121648")]
		private void ւࡂ\u0883\u0872()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x0600284A RID: 10314 RVA: 0x000F524C File Offset: 0x000F344C
		[Token(Token = "0x600284A")]
		[Address(RVA = "0x21217C0", Offset = "0x21217C0", VA = "0x21217C0")]
		private void ފՖߢ\u059B()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E2 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E2;
		}

		// Token: 0x0600284B RID: 10315 RVA: 0x000F52CC File Offset: 0x000F34CC
		[Token(Token = "0x600284B")]
		[Address(RVA = "0x2121958", Offset = "0x2121958", VA = "0x2121958")]
		private void \u0881ݗӟ\u07BD()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x0600284C RID: 10316 RVA: 0x000F533C File Offset: 0x000F353C
		[Token(Token = "0x600284C")]
		[Address(RVA = "0x2121AD0", Offset = "0x2121AD0", VA = "0x2121AD0")]
		private void ԟ\u086Cޣ\u055E()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E3 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E3;
		}

		// Token: 0x0600284D RID: 10317 RVA: 0x000F53C8 File Offset: 0x000F35C8
		[Token(Token = "0x600284D")]
		[Address(RVA = "0x2121C6C", Offset = "0x2121C6C", VA = "0x2121C6C")]
		public walkDemonstrate()
		{
		}

		// Token: 0x0600284E RID: 10318 RVA: 0x000F53DC File Offset: 0x000F35DC
		[Token(Token = "0x600284E")]
		[Address(RVA = "0x2121C74", Offset = "0x2121C74", VA = "0x2121C74")]
		private void ٴݵۃ\u05AF()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E2 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E2;
		}

		// Token: 0x0600284F RID: 10319 RVA: 0x000F545C File Offset: 0x000F365C
		[Token(Token = "0x600284F")]
		[Address(RVA = "0x2121E0C", Offset = "0x2121E0C", VA = "0x2121E0C")]
		private void ժ\u065Dԯࡘ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E3 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E3;
		}

		// Token: 0x06002850 RID: 10320 RVA: 0x000F54E8 File Offset: 0x000F36E8
		[Token(Token = "0x6002850")]
		[Address(RVA = "0x2121FA8", Offset = "0x2121FA8", VA = "0x2121FA8")]
		private void ࢫ\u0876չՍ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x06002851 RID: 10321 RVA: 0x000F5564 File Offset: 0x000F3764
		[Token(Token = "0x6002851")]
		[Address(RVA = "0x2122124", Offset = "0x2122124", VA = "0x2122124")]
		private void ں٢ࡡ\u05EC()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x06002852 RID: 10322 RVA: 0x000F55D4 File Offset: 0x000F37D4
		[Token(Token = "0x6002852")]
		[Address(RVA = "0x212229C", Offset = "0x212229C", VA = "0x212229C")]
		private void Ӣ\u0592ߨׯ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x06002853 RID: 10323 RVA: 0x000F5644 File Offset: 0x000F3844
		[Token(Token = "0x6002853")]
		[Address(RVA = "0x2122414", Offset = "0x2122414", VA = "0x2122414")]
		private void ԣԭՋࠏ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E2 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E2;
		}

		// Token: 0x06002854 RID: 10324 RVA: 0x000F56C4 File Offset: 0x000F38C4
		[Token(Token = "0x6002854")]
		[Address(RVA = "0x21225AC", Offset = "0x21225AC", VA = "0x21225AC")]
		private void ւ\u06E9\u06DA\u06EB()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x06002855 RID: 10325 RVA: 0x000F5740 File Offset: 0x000F3940
		[Token(Token = "0x6002855")]
		[Address(RVA = "0x2122728", Offset = "0x2122728", VA = "0x2122728")]
		private void ڃրӢԖ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x06002856 RID: 10326 RVA: 0x000F57B0 File Offset: 0x000F39B0
		[Token(Token = "0x6002856")]
		[Address(RVA = "0x21228A0", Offset = "0x21228A0", VA = "0x21228A0")]
		private void \u0654ޛ\u07FAذ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E3 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E3;
		}

		// Token: 0x06002857 RID: 10327 RVA: 0x000F583C File Offset: 0x000F3A3C
		[Token(Token = "0x6002857")]
		[Address(RVA = "0x2122A3C", Offset = "0x2122A3C", VA = "0x2122A3C")]
		private void \u0732ڙԒࢺ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x06002858 RID: 10328 RVA: 0x000F58B8 File Offset: 0x000F3AB8
		[Token(Token = "0x6002858")]
		[Address(RVA = "0x2122BB8", Offset = "0x2122BB8", VA = "0x2122BB8")]
		private void ӻӒݝ߃()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E3 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E3;
		}

		// Token: 0x06002859 RID: 10329 RVA: 0x000F5944 File Offset: 0x000F3B44
		[Token(Token = "0x6002859")]
		[Address(RVA = "0x2122D54", Offset = "0x2122D54", VA = "0x2122D54")]
		private void Ҽ\u08B5ځ\u0658()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x0600285A RID: 10330 RVA: 0x000F59B4 File Offset: 0x000F3BB4
		[Token(Token = "0x600285A")]
		[Address(RVA = "0x2122ECC", Offset = "0x2122ECC", VA = "0x2122ECC")]
		private void \u05F7ԝߠӱ()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x0600285B RID: 10331 RVA: 0x000F5A30 File Offset: 0x000F3C30
		[Token(Token = "0x600285B")]
		[Address(RVA = "0x2123048", Offset = "0x2123048", VA = "0x2123048")]
		private void \u061Fࡆ\u086F\u07B0()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E3 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E3;
		}

		// Token: 0x0600285C RID: 10332 RVA: 0x000F5ABC File Offset: 0x000F3CBC
		[Token(Token = "0x600285C")]
		[Address(RVA = "0x21231E4", Offset = "0x21231E4", VA = "0x21231E4")]
		private void \u0614ࢥӴ\u086C()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E2 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E2;
		}

		// Token: 0x0600285D RID: 10333 RVA: 0x000F5B3C File Offset: 0x000F3D3C
		[Token(Token = "0x600285D")]
		[Address(RVA = "0x212337C", Offset = "0x212337C", VA = "0x212337C")]
		private void ܣ\u086E\u05CF\u06D8()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E2 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E2;
		}

		// Token: 0x0600285E RID: 10334 RVA: 0x000F5BBC File Offset: 0x000F3DBC
		[Token(Token = "0x600285E")]
		[Address(RVA = "0x2123514", Offset = "0x2123514", VA = "0x2123514")]
		private void څࡣڐ\u0657()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x0600285F RID: 10335 RVA: 0x000F5C2C File Offset: 0x000F3E2C
		[Token(Token = "0x600285F")]
		[Address(RVA = "0x212368C", Offset = "0x212368C", VA = "0x212368C")]
		private void \u070Aәޣے()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			long ۹ࡎԬ_u058E2 = 1L;
			this.۹ࡎԬ\u058E = (int)۹ࡎԬ_u058E2;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
		}

		// Token: 0x06002860 RID: 10336 RVA: 0x000F5CA8 File Offset: 0x000F3EA8
		[Token(Token = "0x6002860")]
		[Address(RVA = "0x2123808", Offset = "0x2123808", VA = "0x2123808")]
		private void Ҿࢹؼס()
		{
			Transform[] ێ_u0741ڽҾ = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E = this.۹ࡎԬ\u058E;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Transform[] ێ_u0741ڽҾ2 = this.ێ\u0741ڽҾ;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			Vector3 position2 = base.transform.position;
			Transform[] ێ_u0741ڽҾ3 = this.ێ\u0741ڽҾ;
			int ۹ࡎԬ_u058E2 = this.۹ࡎԬ\u058E;
			this.۹ࡎԬ\u058E = ۹ࡎԬ_u058E2;
		}

		// Token: 0x04000524 RID: 1316
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000524")]
		public float \u05B9ߎܩ\u0613;

		// Token: 0x04000525 RID: 1317
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000525")]
		public Transform[] ێ\u0741ڽҾ;

		// Token: 0x04000526 RID: 1318
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000526")]
		private int ۹ࡎԬ\u058E;
	}
}
