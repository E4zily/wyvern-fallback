﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x02000106 RID: 262
	[Token(Token = "0x2000106")]
	public class GroundAlliment : MonoBehaviour
	{
		// Token: 0x06002861 RID: 10337 RVA: 0x000F5D28 File Offset: 0x000F3F28
		[Token(Token = "0x6002861")]
		[Address(RVA = "0x2E7AC54", Offset = "0x2E7AC54", VA = "0x2E7AC54")]
		private void \u0886Ҽ\u058Dߛ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002862 RID: 10338 RVA: 0x000F5E24 File Offset: 0x000F4024
		[Token(Token = "0x6002862")]
		[Address(RVA = "0x2E7AF34", Offset = "0x2E7AF34", VA = "0x2E7AF34")]
		private Quaternion \u070D\u07B9ډڽ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002863 RID: 10339 RVA: 0x000F5E3C File Offset: 0x000F403C
		[Token(Token = "0x6002863")]
		[Address(RVA = "0x2E7AFD4", Offset = "0x2E7AFD4", VA = "0x2E7AFD4")]
		private void Ԡݘעࠀ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002864 RID: 10340 RVA: 0x000F5F38 File Offset: 0x000F4138
		[Token(Token = "0x6002864")]
		[Address(RVA = "0x2E7B2B4", Offset = "0x2E7B2B4", VA = "0x2E7B2B4")]
		private void \u0892ܒܬޓ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002865 RID: 10341 RVA: 0x000F6034 File Offset: 0x000F4234
		[Token(Token = "0x6002865")]
		[Address(RVA = "0x2E7B4F4", Offset = "0x2E7B4F4", VA = "0x2E7B4F4")]
		private void \u0590\u0882\u0883ࡦ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002866 RID: 10342 RVA: 0x000F612C File Offset: 0x000F432C
		[Token(Token = "0x6002866")]
		[Address(RVA = "0x2E7B7D4", Offset = "0x2E7B7D4", VA = "0x2E7B7D4")]
		private void \u0872މࢮՃ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002867 RID: 10343 RVA: 0x000F6228 File Offset: 0x000F4428
		[Token(Token = "0x6002867")]
		[Address(RVA = "0x2E7BAB4", Offset = "0x2E7BAB4", VA = "0x2E7BAB4")]
		private Quaternion Ի\u0600ݼࡡ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002868 RID: 10344 RVA: 0x000F6240 File Offset: 0x000F4440
		[Token(Token = "0x6002868")]
		[Address(RVA = "0x2E7BB54", Offset = "0x2E7BB54", VA = "0x2E7BB54")]
		private Quaternion ډ\u0704ޒٶ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002869 RID: 10345 RVA: 0x000F6258 File Offset: 0x000F4458
		[Token(Token = "0x6002869")]
		[Address(RVA = "0x2E7BBF4", Offset = "0x2E7BBF4", VA = "0x2E7BBF4")]
		private void ٴݵۃ\u05AF()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x0600286A RID: 10346 RVA: 0x000F6354 File Offset: 0x000F4554
		[Token(Token = "0x600286A")]
		[Address(RVA = "0x2E7BED4", Offset = "0x2E7BED4", VA = "0x2E7BED4")]
		private Quaternion \u088C\u0871ࡌ\u073D(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600286B RID: 10347 RVA: 0x000F636C File Offset: 0x000F456C
		[Token(Token = "0x600286B")]
		[Address(RVA = "0x2E7BF74", Offset = "0x2E7BF74", VA = "0x2E7BF74")]
		private void \u055Cࢯܯ\u0898()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x0600286C RID: 10348 RVA: 0x000F6468 File Offset: 0x000F4668
		[Token(Token = "0x600286C")]
		[Address(RVA = "0x2E7C1B4", Offset = "0x2E7C1B4", VA = "0x2E7C1B4")]
		private void \u05B3ࢹߧ\u07AA()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x0600286D RID: 10349 RVA: 0x000F6564 File Offset: 0x000F4764
		[Token(Token = "0x600286D")]
		[Address(RVA = "0x2E7BE34", Offset = "0x2E7BE34", VA = "0x2E7BE34")]
		private Quaternion ߞל\u055A\u0859(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600286E RID: 10350 RVA: 0x000F657C File Offset: 0x000F477C
		[Token(Token = "0x600286E")]
		[Address(RVA = "0x2E7C494", Offset = "0x2E7C494", VA = "0x2E7C494")]
		private Quaternion ݾࡢکࢩ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600286F RID: 10351 RVA: 0x000F6594 File Offset: 0x000F4794
		[Token(Token = "0x600286F")]
		[Address(RVA = "0x2E7C534", Offset = "0x2E7C534", VA = "0x2E7C534")]
		private void \u07F5\u0657\u055Aߍ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002870 RID: 10352 RVA: 0x000F6690 File Offset: 0x000F4890
		[Token(Token = "0x6002870")]
		[Address(RVA = "0x2E7AE94", Offset = "0x2E7AE94", VA = "0x2E7AE94")]
		private Quaternion \u064F\u064Eߪ\u059B(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002871 RID: 10353 RVA: 0x000F66A8 File Offset: 0x000F48A8
		[Token(Token = "0x6002871")]
		[Address(RVA = "0x2E7C814", Offset = "0x2E7C814", VA = "0x2E7C814")]
		private void Ӧد\u060Eࡏ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002872 RID: 10354 RVA: 0x000F67A4 File Offset: 0x000F49A4
		[Token(Token = "0x6002872")]
		[Address(RVA = "0x2E7C3F4", Offset = "0x2E7C3F4", VA = "0x2E7C3F4")]
		private Quaternion ہ\u0741Լ\u070A(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002873 RID: 10355 RVA: 0x000F67BC File Offset: 0x000F49BC
		[Token(Token = "0x6002873")]
		[Address(RVA = "0x2E7CA54", Offset = "0x2E7CA54", VA = "0x2E7CA54")]
		private void \u05AC\u07F0\u07EEࡥ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002874 RID: 10356 RVA: 0x000F68B8 File Offset: 0x000F4AB8
		[Token(Token = "0x6002874")]
		[Address(RVA = "0x2E7CC94", Offset = "0x2E7CC94", VA = "0x2E7CC94")]
		private void צ\u0874ڵ\u059A()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002875 RID: 10357 RVA: 0x000F69B4 File Offset: 0x000F4BB4
		[Token(Token = "0x6002875")]
		[Address(RVA = "0x2E7CED4", Offset = "0x2E7CED4", VA = "0x2E7CED4")]
		private void Ӣ\u0592ߨׯ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002876 RID: 10358 RVA: 0x000F6AB0 File Offset: 0x000F4CB0
		[Token(Token = "0x6002876")]
		[Address(RVA = "0x2E7D1B4", Offset = "0x2E7D1B4", VA = "0x2E7D1B4")]
		private void \u05C4ݳ\u05BCࡂ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002877 RID: 10359 RVA: 0x000F6BAC File Offset: 0x000F4DAC
		[Token(Token = "0x6002877")]
		[Address(RVA = "0x2E7B734", Offset = "0x2E7B734", VA = "0x2E7B734")]
		private Quaternion ࡓևאࠐ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002878 RID: 10360 RVA: 0x000F6BC4 File Offset: 0x000F4DC4
		[Token(Token = "0x6002878")]
		[Address(RVA = "0x2E7D3F4", Offset = "0x2E7D3F4", VA = "0x2E7D3F4")]
		private Quaternion ӌօݒ\u05EB(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002879 RID: 10361 RVA: 0x000F6BDC File Offset: 0x000F4DDC
		[Token(Token = "0x6002879")]
		[Address(RVA = "0x2E7C774", Offset = "0x2E7C774", VA = "0x2E7C774")]
		private Quaternion \u061D\u07B9\u083Bޝ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600287A RID: 10362 RVA: 0x000F6BF4 File Offset: 0x000F4DF4
		[Token(Token = "0x600287A")]
		[Address(RVA = "0x2E7D494", Offset = "0x2E7D494", VA = "0x2E7D494")]
		private Quaternion \u05B1Շ\u07AEӜ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600287B RID: 10363 RVA: 0x000F6C0C File Offset: 0x000F4E0C
		[Token(Token = "0x600287B")]
		[Address(RVA = "0x2E7D52C", Offset = "0x2E7D52C", VA = "0x2E7D52C")]
		private Quaternion \u088F\u0599ع\u073A(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600287C RID: 10364 RVA: 0x000F6C24 File Offset: 0x000F4E24
		[Token(Token = "0x600287C")]
		[Address(RVA = "0x2E7D5CC", Offset = "0x2E7D5CC", VA = "0x2E7D5CC")]
		private void څࡣڐ\u0657()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x0600287D RID: 10365 RVA: 0x000F6D20 File Offset: 0x000F4F20
		[Token(Token = "0x600287D")]
		[Address(RVA = "0x2E7D8AC", Offset = "0x2E7D8AC", VA = "0x2E7D8AC")]
		private Quaternion \u06E3ߥԳ\u087C(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600287E RID: 10366 RVA: 0x000F6D38 File Offset: 0x000F4F38
		[Token(Token = "0x600287E")]
		[Address(RVA = "0x2E7D94C", Offset = "0x2E7D94C", VA = "0x2E7D94C")]
		private Quaternion ۵ߑԳ۹(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600287F RID: 10367 RVA: 0x000F6D50 File Offset: 0x000F4F50
		[Token(Token = "0x600287F")]
		[Address(RVA = "0x2E7D9EC", Offset = "0x2E7D9EC", VA = "0x2E7D9EC")]
		private Quaternion \u0659ֆՀթ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002880 RID: 10368 RVA: 0x000F6D68 File Offset: 0x000F4F68
		[Token(Token = "0x6002880")]
		[Address(RVA = "0x2E7BA14", Offset = "0x2E7BA14", VA = "0x2E7BA14")]
		private Quaternion ࠆݝ\u05FB\u087C(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002881 RID: 10369 RVA: 0x000F6D80 File Offset: 0x000F4F80
		[Token(Token = "0x6002881")]
		[Address(RVA = "0x2E7DA8C", Offset = "0x2E7DA8C", VA = "0x2E7DA8C")]
		private void \u087BӦןݩ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002882 RID: 10370 RVA: 0x000F6E7C File Offset: 0x000F507C
		[Token(Token = "0x6002882")]
		[Address(RVA = "0x2E7DD6C", Offset = "0x2E7DD6C", VA = "0x2E7DD6C")]
		private void չւت\u061E()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002883 RID: 10371 RVA: 0x000F6F78 File Offset: 0x000F5178
		[Token(Token = "0x6002883")]
		[Address(RVA = "0x2E7DFAC", Offset = "0x2E7DFAC", VA = "0x2E7DFAC")]
		private void ފՖߢ\u059B()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002884 RID: 10372 RVA: 0x000F7074 File Offset: 0x000F5274
		[Token(Token = "0x6002884")]
		[Address(RVA = "0x2E7E1EC", Offset = "0x2E7E1EC", VA = "0x2E7E1EC")]
		private Quaternion ޗ\u060BࡤԀ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002885 RID: 10373 RVA: 0x000F708C File Offset: 0x000F528C
		[Token(Token = "0x6002885")]
		[Address(RVA = "0x2E7E28C", Offset = "0x2E7E28C", VA = "0x2E7E28C")]
		private Quaternion \u088Dࡎ\u0609ה(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002886 RID: 10374 RVA: 0x000F70A4 File Offset: 0x000F52A4
		[Token(Token = "0x6002886")]
		[Address(RVA = "0x2E7E32C", Offset = "0x2E7E32C", VA = "0x2E7E32C")]
		private Quaternion ܪ٧ࢧٮ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002887 RID: 10375 RVA: 0x000F70BC File Offset: 0x000F52BC
		[Token(Token = "0x6002887")]
		[Address(RVA = "0x2E7E3CC", Offset = "0x2E7E3CC", VA = "0x2E7E3CC")]
		private void ࢭ\u0589\u0892\u058A()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002888 RID: 10376 RVA: 0x000F71B8 File Offset: 0x000F53B8
		[Token(Token = "0x6002888")]
		[Address(RVA = "0x2E7E6AC", Offset = "0x2E7E6AC", VA = "0x2E7E6AC")]
		private Quaternion ܮگ\u060Eك(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002889 RID: 10377 RVA: 0x000F71D0 File Offset: 0x000F53D0
		[Token(Token = "0x6002889")]
		[Address(RVA = "0x2E7E74C", Offset = "0x2E7E74C", VA = "0x2E7E74C")]
		private Quaternion \u060Aך\u0892ނ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600288A RID: 10378 RVA: 0x000F71E8 File Offset: 0x000F53E8
		[Token(Token = "0x600288A")]
		[Address(RVA = "0x2E7E7EC", Offset = "0x2E7E7EC", VA = "0x2E7E7EC")]
		private void ւࡂ\u0883\u0872()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x0600288B RID: 10379 RVA: 0x000F72E4 File Offset: 0x000F54E4
		[Token(Token = "0x600288B")]
		[Address(RVA = "0x2E7EA2C", Offset = "0x2E7EA2C", VA = "0x2E7EA2C")]
		private Quaternion ճ\u081D\u0834\u05A6(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600288C RID: 10380 RVA: 0x000F72FC File Offset: 0x000F54FC
		[Token(Token = "0x600288C")]
		[Address(RVA = "0x2E7EACC", Offset = "0x2E7EACC", VA = "0x2E7EACC")]
		private void \u061B\u05EEوۈ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x0600288D RID: 10381 RVA: 0x000F73F8 File Offset: 0x000F55F8
		[Token(Token = "0x600288D")]
		[Address(RVA = "0x2E7EDAC", Offset = "0x2E7EDAC", VA = "0x2E7EDAC")]
		private void ߊ\u066A\u05CFԉ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x0600288E RID: 10382 RVA: 0x000F74F4 File Offset: 0x000F56F4
		[Token(Token = "0x600288E")]
		[Address(RVA = "0x2E7EFEC", Offset = "0x2E7EFEC", VA = "0x2E7EFEC")]
		private void ӻӒݝ߃()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x0600288F RID: 10383 RVA: 0x000F75EC File Offset: 0x000F57EC
		[Token(Token = "0x600288F")]
		[Address(RVA = "0x2E7F22C", Offset = "0x2E7F22C", VA = "0x2E7F22C")]
		private void ڦکӁ\u06E2()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002890 RID: 10384 RVA: 0x000F76E8 File Offset: 0x000F58E8
		[Token(Token = "0x6002890")]
		[Address(RVA = "0x2E7D114", Offset = "0x2E7D114", VA = "0x2E7D114")]
		private Quaternion ހذ\u05CEݮ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002891 RID: 10385 RVA: 0x000F7700 File Offset: 0x000F5900
		[Token(Token = "0x6002891")]
		[Address(RVA = "0x2E7F46C", Offset = "0x2E7F46C", VA = "0x2E7F46C")]
		private void ى߁ٱՏ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002892 RID: 10386 RVA: 0x000F77FC File Offset: 0x000F59FC
		[Token(Token = "0x6002892")]
		[Address(RVA = "0x2E7F74C", Offset = "0x2E7F74C", VA = "0x2E7F74C")]
		private void ܫ\u070Fۃ\u07F2()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002893 RID: 10387 RVA: 0x000F78F8 File Offset: 0x000F5AF8
		[Token(Token = "0x6002893")]
		[Address(RVA = "0x2E7F98C", Offset = "0x2E7F98C", VA = "0x2E7F98C")]
		private void ؤ\u05C8ԛ\u083F()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002894 RID: 10388 RVA: 0x000F79F4 File Offset: 0x000F5BF4
		[Token(Token = "0x6002894")]
		[Address(RVA = "0x2E7FBCC", Offset = "0x2E7FBCC", VA = "0x2E7FBCC")]
		private Quaternion ز\u0820ۻ\u05BF(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002895 RID: 10389 RVA: 0x000F7A0C File Offset: 0x000F5C0C
		[Token(Token = "0x6002895")]
		[Address(RVA = "0x2E7ED0C", Offset = "0x2E7ED0C", VA = "0x2E7ED0C")]
		private Quaternion \u059Eۇօݱ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002896 RID: 10390 RVA: 0x000F7A20 File Offset: 0x000F5C20
		[Token(Token = "0x6002896")]
		[Address(RVA = "0x2E7FC6C", Offset = "0x2E7FC6C", VA = "0x2E7FC6C")]
		private Quaternion \u0871\u088C\u0657\u0818(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002897 RID: 10391 RVA: 0x000F7A38 File Offset: 0x000F5C38
		[Token(Token = "0x6002897")]
		[Address(RVA = "0x2E7FD0C", Offset = "0x2E7FD0C", VA = "0x2E7FD0C")]
		private void \u0832ࢳޤ\u07B5()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002898 RID: 10392 RVA: 0x000F7B34 File Offset: 0x000F5D34
		[Token(Token = "0x6002898")]
		[Address(RVA = "0x2E7FF4C", Offset = "0x2E7FF4C", VA = "0x2E7FF4C")]
		private void \u0836\u089Dی\u0735()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x06002899 RID: 10393 RVA: 0x000F7C30 File Offset: 0x000F5E30
		[Token(Token = "0x6002899")]
		[Address(RVA = "0x2E8018C", Offset = "0x2E8018C", VA = "0x2E8018C")]
		private void Update()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x0600289A RID: 10394 RVA: 0x000F7D2C File Offset: 0x000F5F2C
		[Token(Token = "0x600289A")]
		[Address(RVA = "0x2E803B8", Offset = "0x2E803B8", VA = "0x2E803B8")]
		private Quaternion \u06E1ޘࠓ\u061B(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600289B RID: 10395 RVA: 0x000F7D44 File Offset: 0x000F5F44
		[Token(Token = "0x600289B")]
		[Address(RVA = "0x2E80458", Offset = "0x2E80458", VA = "0x2E80458")]
		public GroundAlliment()
		{
		}

		// Token: 0x0600289C RID: 10396 RVA: 0x000F7D58 File Offset: 0x000F5F58
		[Token(Token = "0x600289C")]
		[Address(RVA = "0x2E8046C", Offset = "0x2E8046C", VA = "0x2E8046C")]
		private void ܪ\u07BB\u086Bࠆ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x0600289D RID: 10397 RVA: 0x000F7E54 File Offset: 0x000F6054
		[Token(Token = "0x600289D")]
		[Address(RVA = "0x2E7DCCC", Offset = "0x2E7DCCC", VA = "0x2E7DCCC")]
		private Quaternion \u089AԜӽס(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600289E RID: 10398 RVA: 0x000F7E6C File Offset: 0x000F606C
		[Token(Token = "0x600289E")]
		[Address(RVA = "0x2E7B214", Offset = "0x2E7B214", VA = "0x2E7B214")]
		private Quaternion ࢫ٣ר\u0618(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600289F RID: 10399 RVA: 0x000F7E84 File Offset: 0x000F6084
		[Token(Token = "0x600289F")]
		[Address(RVA = "0x2E7E60C", Offset = "0x2E7E60C", VA = "0x2E7E60C")]
		private Quaternion ࠏޥԳՖ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028A0 RID: 10400 RVA: 0x000F7E9C File Offset: 0x000F609C
		[Token(Token = "0x60028A0")]
		[Address(RVA = "0x2E8074C", Offset = "0x2E8074C", VA = "0x2E8074C")]
		private void \u089F\u085Fէ\u059A()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x060028A1 RID: 10401 RVA: 0x000F7F98 File Offset: 0x000F6198
		[Token(Token = "0x60028A1")]
		[Address(RVA = "0x2E8098C", Offset = "0x2E8098C", VA = "0x2E8098C")]
		private void ࡊ\u0592\u07AB\u05B2()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x060028A2 RID: 10402 RVA: 0x000F8094 File Offset: 0x000F6294
		[Token(Token = "0x60028A2")]
		[Address(RVA = "0x2E80BCC", Offset = "0x2E80BCC", VA = "0x2E80BCC")]
		private void ں٢ࡡ\u05EC()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x060028A3 RID: 10403 RVA: 0x000F8190 File Offset: 0x000F6390
		[Token(Token = "0x60028A3")]
		[Address(RVA = "0x2E7F6AC", Offset = "0x2E7F6AC", VA = "0x2E7F6AC")]
		private Quaternion \u05AB\u06E4Հ\u0651(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028A4 RID: 10404 RVA: 0x000F81A8 File Offset: 0x000F63A8
		[Token(Token = "0x60028A4")]
		[Address(RVA = "0x2E80E0C", Offset = "0x2E80E0C", VA = "0x2E80E0C")]
		private void ܣ\u086E\u05CF\u06D8()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x060028A5 RID: 10405 RVA: 0x000F82A4 File Offset: 0x000F64A4
		[Token(Token = "0x60028A5")]
		[Address(RVA = "0x2E8104C", Offset = "0x2E8104C", VA = "0x2E8104C")]
		private Quaternion ࠊ\u05AEٶڌ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028A6 RID: 10406 RVA: 0x000F82BC File Offset: 0x000F64BC
		[Token(Token = "0x60028A6")]
		[Address(RVA = "0x2E810EC", Offset = "0x2E810EC", VA = "0x2E810EC")]
		private void Ӌ\u089C\u0700ܧ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x060028A7 RID: 10407 RVA: 0x000F83B8 File Offset: 0x000F65B8
		[Token(Token = "0x60028A7")]
		[Address(RVA = "0x2E8132C", Offset = "0x2E8132C", VA = "0x2E8132C")]
		private void ߑ\u0885\u05BBߕ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x060028A8 RID: 10408 RVA: 0x000F84B4 File Offset: 0x000F66B4
		[Token(Token = "0x60028A8")]
		[Address(RVA = "0x2E806AC", Offset = "0x2E806AC", VA = "0x2E806AC")]
		private Quaternion ࢭ\u0590ӄޞ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028A9 RID: 10409 RVA: 0x000F84CC File Offset: 0x000F66CC
		[Token(Token = "0x60028A9")]
		[Address(RVA = "0x2E8160C", Offset = "0x2E8160C", VA = "0x2E8160C")]
		private Quaternion ܪ\u081B\u06E1ԙ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028AA RID: 10410 RVA: 0x000F84E0 File Offset: 0x000F66E0
		[Token(Token = "0x60028AA")]
		[Address(RVA = "0x2E816AC", Offset = "0x2E816AC", VA = "0x2E816AC")]
		private void \u07FB\u07BC\u0887ӟ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Transform transform;
			Vector3 position = transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform2 = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x060028AB RID: 10411 RVA: 0x000F85D8 File Offset: 0x000F67D8
		[Token(Token = "0x60028AB")]
		[Address(RVA = "0x2E8156C", Offset = "0x2E8156C", VA = "0x2E8156C")]
		private Quaternion ܩࡩࡗ\u0746(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028AC RID: 10412 RVA: 0x000F85F0 File Offset: 0x000F67F0
		[Token(Token = "0x60028AC")]
		[Address(RVA = "0x2E818EC", Offset = "0x2E818EC", VA = "0x2E818EC")]
		private void \u0732ڙԒࢺ()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x060028AD RID: 10413 RVA: 0x000F86EC File Offset: 0x000F68EC
		[Token(Token = "0x60028AD")]
		[Address(RVA = "0x2E81B2C", Offset = "0x2E81B2C", VA = "0x2E81B2C")]
		private Quaternion Ӧ\u05B0ܧࠆ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028AE RID: 10414 RVA: 0x000F8704 File Offset: 0x000F6904
		[Token(Token = "0x60028AE")]
		[Address(RVA = "0x2E7D80C", Offset = "0x2E7D80C", VA = "0x2E7D80C")]
		private Quaternion \u081A\u061E\u07ECؤ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028AF RID: 10415 RVA: 0x000F871C File Offset: 0x000F691C
		[Token(Token = "0x60028AF")]
		[Address(RVA = "0x2E81BCC", Offset = "0x2E81BCC", VA = "0x2E81BCC")]
		private Quaternion ࢱӓࠍ\u05C1(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028B0 RID: 10416 RVA: 0x000F8734 File Offset: 0x000F6934
		[Token(Token = "0x60028B0")]
		[Address(RVA = "0x2E81C6C", Offset = "0x2E81C6C", VA = "0x2E81C6C")]
		private void \u05EDց\u081Cت()
		{
			float u07B2ݪ_u082Dե = this.\u07B2ݪ\u082Dե;
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			float num = this.checkRange;
			int num2 = mask;
			float x = this.Ը\u066Cڼߦ.x;
			float y = this.Ը\u066Cڼߦ.y;
			float z = this.Ը\u066Cڼߦ.z;
			float u07B2ݪ_u082Dե2 = this.\u07B2ݪ\u082Dե;
			float y2 = this.orientationSpeed;
			float num3 = Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num4 = this.orientationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.Ը\u066Cڼߦ.x = u07B2ݪ_u082Dե2;
			this.Ը\u066Cڼߦ.y = y2;
		}

		// Token: 0x04000527 RID: 1319
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000527")]
		[SerializeField]
		private float checkRange;

		// Token: 0x04000528 RID: 1320
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000528")]
		[SerializeField]
		private float orientationSpeed;

		// Token: 0x04000529 RID: 1321
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000529")]
		[SerializeField]
		private LayerMask layerMask;

		// Token: 0x0400052A RID: 1322
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x400052A")]
		private Vector3 Ը\u066Cڼߦ;

		// Token: 0x0400052B RID: 1323
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400052B")]
		private float \u07B2ݪ\u082Dե;
	}
}
