﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x0200010A RID: 266
	[Token(Token = "0x200010A")]
	public class proceduralAnimation : MonoBehaviour
	{
		// Token: 0x060029C3 RID: 10691 RVA: 0x000FCFA4 File Offset: 0x000FB1A4
		[Token(Token = "0x60029C3")]
		[Address(RVA = "0x2E3B018", Offset = "0x2E3B018", VA = "0x2E3B018")]
		private void \u058CԲ\u06D9ت()
		{
			if (this.\u0657\u0886\u0895ߪ)
			{
				bool flag = Application.IsPlaying(this);
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				Transform transform = base.transform;
				Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				float num = this.velocityClamp;
				float ކܖࢻ_u = this.ކܖࢻ\u0877;
				float num2 = this.velocityMultiplier;
				LayerMask layerMask = this.layerMask;
				float num3 = this.legRayoffset;
				float num4 = this.legRayLength;
				float num5 = this.sphereCastRadius;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3[] u060Fݴ_u07FE_u2 = this.\u060Fݴ\u07FE\u0591;
				Vector3 up = Vector3.up;
				float num6 = this.legRayoffset;
				Vector3 up2 = Vector3.up;
				float num7 = this.legRayLength;
				Transform transform3 = base.transform;
				Vector3[] u060Fݴ_u07FE_u3 = this.\u060Fݴ\u07FE\u0591;
				float num8 = this.sphereCastRadius;
			}
		}

		// Token: 0x060029C4 RID: 10692 RVA: 0x000FD0A0 File Offset: 0x000FB2A0
		[Token(Token = "0x60029C4")]
		[Address(RVA = "0x2E3B294", Offset = "0x2E3B294", VA = "0x2E3B294")]
		private void \u0732ڙԒࢺ()
		{
			Vector3 position = base.transform.position;
			float x = this.ۄܙՕթ.x;
			float y = this.ۄܙՕթ.y;
			float z = this.ۄܙՕթ.z;
			float deltaTime = Time.deltaTime;
			float x2 = this.\u086B\u0599\u074Cנ.x;
			float y2 = this.\u086B\u0599\u074Cנ.y;
			float z2 = this.\u086B\u0599\u074Cנ.z;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float num = this.velocityClamp;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Vector3 u0737ӊٴد = this.\u0737ӊٴد;
			float z3 = this.\u0737ӊٴد.z;
			this.\u086B\u0599\u074Cנ.z = z3;
		}

		// Token: 0x060029C5 RID: 10693 RVA: 0x000FD23C File Offset: 0x000FB43C
		[Token(Token = "0x60029C5")]
		[Address(RVA = "0x2E3B880", Offset = "0x2E3B880", VA = "0x2E3B880")]
		public bool ض\u082Bճ۱(int ۹ࡎԬ\u058E)
		{
			bool[] u06D8ٺܓى = this.\u06D8ٺܓى;
			throw new NullReferenceException();
		}

		// Token: 0x060029C6 RID: 10694 RVA: 0x000FD25C File Offset: 0x000FB45C
		[Token(Token = "0x60029C6")]
		[Address(RVA = "0x2E3B8BC", Offset = "0x2E3B8BC", VA = "0x2E3B8BC")]
		public static float \u05C1Ԕߧࢢ(float \u0871ߘ\u0822Ө, float ճ\u058D\u0895מ, float ܜڃԑن, float ԝخث٧, float \u087Eցބڎ)
		{
			/*
An exception occurred when decompiling this method (060029C6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::ׁԔߧࢢ(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_0A, call:float32(Mathf::InverseLerp, ldloc:float32(ࡱߘࠢӨ), ldloc:float32(ճ֍࢕מ), ldloc:float32(ܜڃԑن))); 	stloc:float32(var_3_15, call:float32(Mathf::Lerp, ldloc:float32(ܜڃԑن), ldloc:float32(ԝخث٧), ldloc:float32(var_1_0A))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060029C7 RID: 10695 RVA: 0x000FD280 File Offset: 0x000FB480
		[Token(Token = "0x60029C7")]
		[Address(RVA = "0x2E3B904", Offset = "0x2E3B904", VA = "0x2E3B904")]
		public float ޱ\u060Eطه(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x060029C8 RID: 10696 RVA: 0x000FD2C4 File Offset: 0x000FB4C4
		[Token(Token = "0x60029C8")]
		[Address(RVA = "0x2E3BA5C", Offset = "0x2E3BA5C", VA = "0x2E3BA5C")]
		public LayerMask ٹՄӶ\u074A()
		{
			return this.layerMask;
		}

		// Token: 0x060029C9 RID: 10697 RVA: 0x000FD2D8 File Offset: 0x000FB4D8
		[Token(Token = "0x60029C9")]
		[Address(RVA = "0x2E3BA64", Offset = "0x2E3BA64", VA = "0x2E3BA64")]
		private void \u07A8Ӥթݠ()
		{
			Transform[] array = this.legIktargets;
			this.\u060Fݴ\u07FE\u0591 = typeof(Vector3[]).TypeHandle;
			Vector3[] u06FD١ב_u088B = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.\u06FD١ב\u088B = u06FD١ב_u088B;
			Vector3[] array2 = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.ࡂ߀ڗժ = array2;
			bool[] u06D8ٺܓى = new bool[this.Ӏ\u089D\u05C5ؼ];
			this.\u06D8ٺܓى = u06D8ٺܓى;
			float[] ӡ_u06D9Ӗߊ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ӡ\u06D9Ӗߊ = ӡ_u06D9Ӗߊ;
			float[] ݼ_u05F3ࢨۑ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ݼ\u05F3ࢨۑ = ݼ_u05F3ࢨۑ;
			float[] ܝ_u082EӁ_u08B = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ܝ\u082EӁ\u08B5 = ܝ_u082EӁ_u08B;
			if (this.SetTimingsManually)
			{
				float[] array3 = this.manualTimings;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Debug.LogError("BN");
			}
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			bool setTimingsManually = this.SetTimingsManually;
			float[] ӡ_u06D9Ӗߊ2 = this.ӡ\u06D9Ӗߊ;
			if (setTimingsManually)
			{
				float[] array4 = this.manualTimings;
				return;
			}
			float num = this.timigsOffset;
			Transform[] array5 = this.legIktargets;
			Vector3[] u06FD١ב_u088B2 = this.\u06FD١ב\u088B;
			Transform[] array6 = this.legIktargets;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			int ӏ_u089D_u05C5ؼ3 = this.Ӏ\u089D\u05C5ؼ;
			float num2 = this.refreshTimingRate;
			IEnumerator routine;
			Coroutine coroutine = base.StartCoroutine(routine);
		}

		// Token: 0x060029CA RID: 10698 RVA: 0x000FD410 File Offset: 0x000FB610
		[Token(Token = "0x60029CA")]
		[Address(RVA = "0x2E3BDF8", Offset = "0x2E3BDF8", VA = "0x2E3BDF8")]
		private void ڍ\u058Bݗࡣ()
		{
			Transform[] array = this.legIktargets;
			this.\u060Fݴ\u07FE\u0591 = typeof(Vector3[]).TypeHandle;
			Vector3[] u06FD١ב_u088B = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.\u06FD١ב\u088B = u06FD١ב_u088B;
			Vector3[] array2 = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.ࡂ߀ڗժ = array2;
			bool[] u06D8ٺܓى = new bool[this.Ӏ\u089D\u05C5ؼ];
			this.\u06D8ٺܓى = u06D8ٺܓى;
			float[] ӡ_u06D9Ӗߊ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ӡ\u06D9Ӗߊ = ӡ_u06D9Ӗߊ;
			float[] ݼ_u05F3ࢨۑ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ݼ\u05F3ࢨۑ = ݼ_u05F3ࢨۑ;
			float[] ܝ_u082EӁ_u08B = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ܝ\u082EӁ\u08B5 = ܝ_u082EӁ_u08B;
			if (this.SetTimingsManually)
			{
				float[] array3 = this.manualTimings;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Debug.LogError("clickLol");
			}
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			bool setTimingsManually = this.SetTimingsManually;
			float[] ӡ_u06D9Ӗߊ2 = this.ӡ\u06D9Ӗߊ;
			if (setTimingsManually)
			{
				float[] array4 = this.manualTimings;
				return;
			}
			Transform[] array5 = this.legIktargets;
			Vector3[] u06FD١ב_u088B2 = this.\u06FD١ב\u088B;
			Transform[] array6 = this.legIktargets;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			int ӏ_u089D_u05C5ؼ3 = this.Ӏ\u089D\u05C5ؼ;
			float num = this.refreshTimingRate;
			IEnumerator routine;
			Coroutine coroutine = base.StartCoroutine(routine);
		}

		// Token: 0x060029CB RID: 10699 RVA: 0x000FD53C File Offset: 0x000FB73C
		[Token(Token = "0x60029CB")]
		[Address(RVA = "0x2E3C0C8", Offset = "0x2E3C0C8", VA = "0x2E3C0C8")]
		private void \u0892ܒܬޓ()
		{
			Vector3 position = base.transform.position;
			float x = this.ۄܙՕթ.x;
			float y = this.ۄܙՕթ.y;
			float z = this.ۄܙՕթ.z;
			float deltaTime = Time.deltaTime;
			float x2 = this.\u086B\u0599\u074Cנ.x;
			float y2 = this.\u086B\u0599\u074Cנ.y;
			float z2 = this.\u086B\u0599\u074Cנ.z;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float num = this.velocityClamp;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Vector3 u0737ӊٴد = this.\u0737ӊٴد;
			float z3 = this.\u0737ӊٴد.z;
			this.\u086B\u0599\u074Cנ.z = z3;
		}

		// Token: 0x060029CC RID: 10700 RVA: 0x000FD6D8 File Offset: 0x000FB8D8
		[Token(Token = "0x60029CC")]
		[Address(RVA = "0x2E3C670", Offset = "0x2E3C670", VA = "0x2E3C670")]
		private void Գӿېչ()
		{
			Transform[] array = this.legIktargets;
			this.\u060Fݴ\u07FE\u0591 = typeof(Vector3[]).TypeHandle;
			Vector3[] u06FD١ב_u088B = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.\u06FD١ב\u088B = u06FD١ב_u088B;
			Vector3[] array2 = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.ࡂ߀ڗժ = array2;
			bool[] u06D8ٺܓى = new bool[this.Ӏ\u089D\u05C5ؼ];
			this.\u06D8ٺܓى = u06D8ٺܓى;
			float[] ӡ_u06D9Ӗߊ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ӡ\u06D9Ӗߊ = ӡ_u06D9Ӗߊ;
			float[] ݼ_u05F3ࢨۑ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ݼ\u05F3ࢨۑ = ݼ_u05F3ࢨۑ;
			float[] ܝ_u082EӁ_u08B = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ܝ\u082EӁ\u08B5 = ܝ_u082EӁ_u08B;
			if (this.SetTimingsManually)
			{
				float[] array3 = this.manualTimings;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Debug.LogError("We don't need this electrical box");
			}
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			bool setTimingsManually = this.SetTimingsManually;
			float[] ӡ_u06D9Ӗߊ2 = this.ӡ\u06D9Ӗߊ;
			if (setTimingsManually)
			{
				float[] array4 = this.manualTimings;
				return;
			}
			float num = this.timigsOffset;
			Transform[] array5 = this.legIktargets;
			Vector3[] u06FD١ב_u088B2 = this.\u06FD١ב\u088B;
			Transform[] array6 = this.legIktargets;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			int ӏ_u089D_u05C5ؼ3 = this.Ӏ\u089D\u05C5ؼ;
			float num2 = this.refreshTimingRate;
			IEnumerator routine;
			Coroutine coroutine = base.StartCoroutine(routine);
		}

		// Token: 0x060029CD RID: 10701 RVA: 0x000FD810 File Offset: 0x000FBA10
		[Token(Token = "0x60029CD")]
		[Address(RVA = "0x2E3C97C", Offset = "0x2E3C97C", VA = "0x2E3C97C")]
		public bool ڏՋ\u089C߄(int ۹ࡎԬ\u058E)
		{
			bool[] u06D8ٺܓى = this.\u06D8ٺܓى;
			throw new NullReferenceException();
		}

		// Token: 0x060029CE RID: 10702 RVA: 0x000FD830 File Offset: 0x000FBA30
		[Token(Token = "0x60029CE")]
		[Address(RVA = "0x2E3C9B8", Offset = "0x2E3C9B8", VA = "0x2E3C9B8")]
		private void Update()
		{
			Vector3 position = base.transform.position;
			float x = this.ۄܙՕթ.x;
			float y = this.ۄܙՕթ.y;
			float z = this.ۄܙՕթ.z;
			float deltaTime = Time.deltaTime;
			float x2 = this.\u086B\u0599\u074Cנ.x;
			float y2 = this.\u086B\u0599\u074Cנ.y;
			float z2 = this.\u086B\u0599\u074Cנ.z;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float num = this.velocityClamp;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Vector3 u0737ӊٴد = this.\u0737ӊٴد;
			float z3 = this.\u0737ӊٴد.z;
			this.\u086B\u0599\u074Cנ.z = z3;
		}

		// Token: 0x060029CF RID: 10703 RVA: 0x000FD9B4 File Offset: 0x000FBBB4
		[Token(Token = "0x60029CF")]
		[Address(RVA = "0x2E3CF34", Offset = "0x2E3CF34", VA = "0x2E3CF34")]
		private void Կ\u0833ࡌٽ()
		{
			if (this.\u0657\u0886\u0895ߪ)
			{
				bool flag = Application.IsPlaying(this);
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				Transform transform = base.transform;
				Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				float num = this.velocityClamp;
				float ކܖࢻ_u = this.ކܖࢻ\u0877;
				float num2 = this.velocityMultiplier;
				LayerMask layerMask = this.layerMask;
				float num3 = this.legRayoffset;
				float num4 = this.legRayLength;
				float num5 = this.sphereCastRadius;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3[] u060Fݴ_u07FE_u2 = this.\u060Fݴ\u07FE\u0591;
				Vector3 up = Vector3.up;
				float num6 = this.legRayoffset;
				Vector3 up2 = Vector3.up;
				float num7 = this.legRayLength;
				Transform transform3 = base.transform;
				Vector3[] u060Fݴ_u07FE_u3 = this.\u060Fݴ\u07FE\u0591;
				float num8 = this.sphereCastRadius;
				int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			}
		}

		// Token: 0x060029D0 RID: 10704 RVA: 0x000FDAB4 File Offset: 0x000FBCB4
		[Token(Token = "0x60029D0")]
		[Address(RVA = "0x2E3D18C", Offset = "0x2E3D18C", VA = "0x2E3D18C")]
		private float \u0558\u05F5ԣߌ(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Transform transform = base.transform;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			throw new NullReferenceException();
		}

		// Token: 0x060029D1 RID: 10705 RVA: 0x000FDAE4 File Offset: 0x000FBCE4
		[Token(Token = "0x60029D1")]
		[Address(RVA = "0x2E3D264", Offset = "0x2E3D264", VA = "0x2E3D264")]
		public LayerMask ݏӭ\u06D8\u07EF()
		{
			return this.layerMask;
		}

		// Token: 0x060029D2 RID: 10706 RVA: 0x000FDAF8 File Offset: 0x000FBCF8
		[Token(Token = "0x60029D2")]
		[Address(RVA = "0x2E3D26C", Offset = "0x2E3D26C", VA = "0x2E3D26C")]
		public LayerMask \u07F3\u0617\u05CEݟ()
		{
			return this.layerMask;
		}

		// Token: 0x060029D3 RID: 10707 RVA: 0x000FDB0C File Offset: 0x000FBD0C
		[Token(Token = "0x60029D3")]
		[Address(RVA = "0x2E3D274", Offset = "0x2E3D274", VA = "0x2E3D274")]
		public float \u05A3ࡠӞހ(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x060029D4 RID: 10708 RVA: 0x000FDB50 File Offset: 0x000FBD50
		[Token(Token = "0x60029D4")]
		[Address(RVA = "0x2E3D3CC", Offset = "0x2E3D3CC", VA = "0x2E3D3CC")]
		private void \u0881ݗӟ\u07BD()
		{
			Vector3 position = base.transform.position;
			float x = this.ۄܙՕթ.x;
			float y = this.ۄܙՕթ.y;
			float z = this.ۄܙՕթ.z;
			float deltaTime = Time.deltaTime;
			float x2 = this.\u086B\u0599\u074Cנ.x;
			float y2 = this.\u086B\u0599\u074Cנ.y;
			float z2 = this.\u086B\u0599\u074Cנ.z;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float num = this.velocityClamp;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Vector3 u0737ӊٴد = this.\u0737ӊٴد;
			float z3 = this.\u0737ӊٴد.z;
			this.\u086B\u0599\u074Cנ.z = z3;
		}

		// Token: 0x060029D5 RID: 10709 RVA: 0x000FDCEC File Offset: 0x000FBEEC
		[Token(Token = "0x60029D5")]
		[Address(RVA = "0x2E3D66C", Offset = "0x2E3D66C", VA = "0x2E3D66C")]
		private float ԛ\u05AAԩم(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Transform transform = base.transform;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			throw new NullReferenceException();
		}

		// Token: 0x060029D6 RID: 10710 RVA: 0x000FDD1C File Offset: 0x000FBF1C
		[Token(Token = "0x60029D6")]
		[Address(RVA = "0x2E3C368", Offset = "0x2E3C368", VA = "0x2E3C368")]
		public static float ࡄےՖن(float \u0871ߘ\u0822Ө, float ճ\u058D\u0895מ, float ܜڃԑن, float ԝخث٧, float \u087Eցބڎ)
		{
			/*
An exception occurred when decompiling this method (060029D6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::ࡄےՖن(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_0A, call:float32(Mathf::InverseLerp, ldloc:float32(ࡱߘࠢӨ), ldloc:float32(ճ֍࢕מ), ldloc:float32(ܜڃԑن))); 	stloc:float32(var_3_15, call:float32(Mathf::Lerp, ldloc:float32(ܜڃԑن), ldloc:float32(ԝخث٧), ldloc:float32(var_1_0A))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060029D7 RID: 10711 RVA: 0x000FDD40 File Offset: 0x000FBF40
		[Token(Token = "0x60029D7")]
		[Address(RVA = "0x2E3D744", Offset = "0x2E3D744", VA = "0x2E3D744")]
		public Transform[] \u05AE\u0837\u05C0\u0707()
		{
			return this.legIktargets;
		}

		// Token: 0x060029D8 RID: 10712 RVA: 0x000FDD54 File Offset: 0x000FBF54
		[Token(Token = "0x60029D8")]
		[Address(RVA = "0x2E3D74C", Offset = "0x2E3D74C", VA = "0x2E3D74C")]
		private float ב\u05B0\u070Bפ(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Transform transform = base.transform;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			throw new NullReferenceException();
		}

		// Token: 0x060029D9 RID: 10713 RVA: 0x000FDD84 File Offset: 0x000FBF84
		[Token(Token = "0x60029D9")]
		[Address(RVA = "0x2E3BD70", Offset = "0x2E3BD70", VA = "0x2E3BD70")]
		private IEnumerator ݕؾե\u0734(float ࡑ۳\u0596\u066C)
		{
			long <>1__state;
			proceduralAnimation.ב\u081E\u05C0ࠕ ב_u081E_u05C0ࠕ = new proceduralAnimation.ב\u081E\u05C0ࠕ((int)<>1__state);
			<>1__state = 1L;
			ב_u081E_u05C0ࠕ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029DA RID: 10714 RVA: 0x000FDDA8 File Offset: 0x000FBFA8
		[Token(Token = "0x60029DA")]
		[Address(RVA = "0x2E3D824", Offset = "0x2E3D824", VA = "0x2E3D824")]
		private void Start()
		{
			Transform[] array = this.legIktargets;
			this.\u060Fݴ\u07FE\u0591 = typeof(Vector3[]).TypeHandle;
			Vector3[] u06FD١ב_u088B = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.\u06FD١ב\u088B = u06FD١ב_u088B;
			Vector3[] array2 = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.ࡂ߀ڗժ = array2;
			bool[] u06D8ٺܓى = new bool[this.Ӏ\u089D\u05C5ؼ];
			this.\u06D8ٺܓى = u06D8ٺܓى;
			float[] ӡ_u06D9Ӗߊ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ӡ\u06D9Ӗߊ = ӡ_u06D9Ӗߊ;
			float[] ݼ_u05F3ࢨۑ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ݼ\u05F3ࢨۑ = ݼ_u05F3ࢨۑ;
			float[] ܝ_u082EӁ_u08B = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ܝ\u082EӁ\u08B5 = ܝ_u082EӁ_u08B;
			if (this.SetTimingsManually)
			{
				float[] array3 = this.manualTimings;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Debug.LogError("manual footTimings length should be equal to the leg count");
			}
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			bool setTimingsManually = this.SetTimingsManually;
			float[] ӡ_u06D9Ӗߊ2 = this.ӡ\u06D9Ӗߊ;
			if (setTimingsManually)
			{
				float[] array4 = this.manualTimings;
				return;
			}
			float num = this.timigsOffset;
			Transform[] array5 = this.legIktargets;
			Vector3[] u06FD١ב_u088B2 = this.\u06FD١ב\u088B;
			Transform[] array6 = this.legIktargets;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			int ӏ_u089D_u05C5ؼ3 = this.Ӏ\u089D\u05C5ؼ;
			float num2 = this.refreshTimingRate;
			IEnumerator routine;
			Coroutine coroutine = base.StartCoroutine(routine);
		}

		// Token: 0x060029DB RID: 10715 RVA: 0x000FDEE0 File Offset: 0x000FC0E0
		[Token(Token = "0x60029DB")]
		[Address(RVA = "0x2E3DBB8", Offset = "0x2E3DBB8", VA = "0x2E3DBB8")]
		public bool ڶ\u07AAӴࢮ(int ۹ࡎԬ\u058E)
		{
			bool[] u06D8ٺܓى = this.\u06D8ٺܓى;
			throw new NullReferenceException();
		}

		// Token: 0x060029DC RID: 10716 RVA: 0x000FDF00 File Offset: 0x000FC100
		[Token(Token = "0x60029DC")]
		[Address(RVA = "0x2E3C3B0", Offset = "0x2E3C3B0", VA = "0x2E3C3B0")]
		public void Ե\u082Fөޡ(int ۹ࡎԬ\u058E)
		{
			Transform transform = base.transform;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			Vector3 vector;
			float magnitude = vector.normalized.magnitude;
			float num = this.velocityClamp;
			float ކܖࢻ_u = this.ކܖࢻ\u0877;
			float num2 = this.velocityMultiplier;
			LayerMask layerMask = this.layerMask;
			float num3 = this.legRayoffset;
			float num4 = this.legRayLength;
			float num5 = this.sphereCastRadius;
			Vector3[] array = this.ࡂ߀ڗժ;
			float[] ܝ_u082EӁ_u08B = this.ܝ\u082EӁ\u08B5;
			float num6 = this.\u0558\u05F5ԣߌ(۹ࡎԬ\u058E);
			Transform[] array2 = this.legIktargets;
			Vector3[] array3 = this.ࡂ߀ڗժ;
			float[] ݼ_u05F3ࢨۑ = this.ݼ\u05F3ࢨۑ;
			float num7 = this.stepDistance;
			Vector3[] array4 = this.ࡂ߀ڗժ;
			Vector3 zero = Vector3.zero;
			Vector3[] array5 = this.ࡂ߀ڗժ;
			LayerMask layerMask2 = this.layerMask;
			float num8 = this.legRayoffset;
			float num9 = this.legRayLength;
			float num10 = this.sphereCastRadius;
			Vector3[] array6 = this.ࡂ߀ڗժ;
			int ڟ_u07EDՠ_u = this.ڟ\u07EDՠ\u0885;
			IEnumerator routine;
			Coroutine coroutine = base.StartCoroutine(routine);
		}

		// Token: 0x060029DD RID: 10717 RVA: 0x000FE018 File Offset: 0x000FC218
		[Token(Token = "0x60029DD")]
		[Address(RVA = "0x2E3DCA0", Offset = "0x2E3DCA0", VA = "0x2E3DCA0")]
		private void \u070Fߨ\u05B0ۈ()
		{
			Transform[] array = this.legIktargets;
			this.\u060Fݴ\u07FE\u0591 = typeof(Vector3[]).TypeHandle;
			Vector3[] u06FD١ב_u088B = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.\u06FD١ב\u088B = u06FD١ב_u088B;
			Vector3[] array2 = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.ࡂ߀ڗժ = array2;
			bool[] u06D8ٺܓى = new bool[this.Ӏ\u089D\u05C5ؼ];
			this.\u06D8ٺܓى = u06D8ٺܓى;
			float[] ӡ_u06D9Ӗߊ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ӡ\u06D9Ӗߊ = ӡ_u06D9Ӗߊ;
			float[] ݼ_u05F3ࢨۑ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ݼ\u05F3ࢨۑ = ݼ_u05F3ࢨۑ;
			float[] ܝ_u082EӁ_u08B = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ܝ\u082EӁ\u08B5 = ܝ_u082EӁ_u08B;
			if (this.SetTimingsManually)
			{
				float[] array3 = this.manualTimings;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Debug.LogError("PURCHASED");
			}
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			bool setTimingsManually = this.SetTimingsManually;
			float[] ӡ_u06D9Ӗߊ2 = this.ӡ\u06D9Ӗߊ;
			float[] array4;
			if (setTimingsManually)
			{
				array4 = this.manualTimings;
				return;
			}
			if (array4 != null)
			{
				float num = this.timigsOffset;
				Transform[] array5 = this.legIktargets;
				if (array4 != null)
				{
					Vector3[] u06FD١ב_u088B2 = this.\u06FD١ב\u088B;
					if (array5 != null)
					{
						Transform[] array6 = this.legIktargets;
						if (array4 != null)
						{
							Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
							if (array6 != null)
							{
								int ӏ_u089D_u05C5ؼ3 = this.Ӏ\u089D\u05C5ؼ;
								float num2 = this.refreshTimingRate;
								IEnumerator routine;
								Coroutine coroutine = base.StartCoroutine(routine);
								return;
							}
						}
					}
				}
			}
			throw new IndexOutOfRangeException();
		}

		// Token: 0x060029DE RID: 10718 RVA: 0x000FE160 File Offset: 0x000FC360
		[Token(Token = "0x60029DE")]
		[Address(RVA = "0x2E3DF58", Offset = "0x2E3DF58", VA = "0x2E3DF58")]
		public Transform[] \u0871ݣݩ\u058B()
		{
			return this.legIktargets;
		}

		// Token: 0x060029DF RID: 10719 RVA: 0x000FE174 File Offset: 0x000FC374
		[Token(Token = "0x60029DF")]
		[Address(RVA = "0x2E3DF60", Offset = "0x2E3DF60", VA = "0x2E3DF60")]
		private float \u05FDԦݫ\u070C(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Transform transform = base.transform;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			throw new NullReferenceException();
		}

		// Token: 0x060029E0 RID: 10720 RVA: 0x000FE1A4 File Offset: 0x000FC3A4
		[Token(Token = "0x60029E0")]
		[Address(RVA = "0x2E3E038", Offset = "0x2E3E038", VA = "0x2E3E038")]
		public bool ӏ\u0701\u0607օ(int ۹ࡎԬ\u058E)
		{
			bool[] u06D8ٺܓى = this.\u06D8ٺܓى;
			throw new NullReferenceException();
		}

		// Token: 0x060029E1 RID: 10721 RVA: 0x000FE1C4 File Offset: 0x000FC3C4
		[Token(Token = "0x60029E1")]
		[Address(RVA = "0x2E3E074", Offset = "0x2E3E074", VA = "0x2E3E074")]
		public float ݗܝ\u0879ڒ()
		{
			/*
An exception occurred when decompiling this method (060029E1)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::ݗܝࡹڒ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int32(var_0_06, ldfld:int32(proceduralAnimation::Ӏׅ࢝ؼ, ldloc:proceduralAnimation(this))); 	stloc:int64(var_1_08, ldc.i4:int64(0)); 	stloc:float32(var_2_10, call:float32(proceduralAnimation::߫ڢ٢ܓ, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_08))); 	stloc:int32(var_3_17, ldfld:int32(proceduralAnimation::Ӏׅ࢝ؼ, ldloc:proceduralAnimation(this))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060029E2 RID: 10722 RVA: 0x000FE1E8 File Offset: 0x000FC3E8
		[Token(Token = "0x60029E2")]
		[Address(RVA = "0x2E3E22C", Offset = "0x2E3E22C", VA = "0x2E3E22C")]
		private void ժ\u07FF\u070Cق()
		{
			if (this.\u0657\u0886\u0895ߪ)
			{
				bool flag = Application.IsPlaying(this);
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				Transform transform = base.transform;
				Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				float num = this.velocityClamp;
				float ކܖࢻ_u = this.ކܖࢻ\u0877;
				float num2 = this.velocityMultiplier;
				LayerMask layerMask = this.layerMask;
				float num3 = this.legRayoffset;
				float num4 = this.legRayLength;
				float num5 = this.sphereCastRadius;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3[] u060Fݴ_u07FE_u2 = this.\u060Fݴ\u07FE\u0591;
				Vector3 up = Vector3.up;
				float num6 = this.legRayoffset;
				Vector3 up2 = Vector3.up;
				float num7 = this.legRayLength;
				Transform transform3 = base.transform;
				Vector3[] u060Fݴ_u07FE_u3 = this.\u060Fݴ\u07FE\u0591;
				float num8 = this.sphereCastRadius;
			}
		}

		// Token: 0x060029E3 RID: 10723 RVA: 0x000FE2E4 File Offset: 0x000FC4E4
		[Token(Token = "0x60029E3")]
		[Address(RVA = "0x2E3E4A8", Offset = "0x2E3E4A8", VA = "0x2E3E4A8")]
		public bool ࡗࠆࢬܟ(int ۹ࡎԬ\u058E)
		{
			bool[] u06D8ٺܓى = this.\u06D8ٺܓى;
			throw new NullReferenceException();
		}

		// Token: 0x060029E4 RID: 10724 RVA: 0x000FE304 File Offset: 0x000FC504
		[Token(Token = "0x60029E4")]
		[Address(RVA = "0x2E3E4E4", Offset = "0x2E3E4E4", VA = "0x2E3E4E4")]
		public Transform[] Շܬێڿ()
		{
			return this.legIktargets;
		}

		// Token: 0x060029E5 RID: 10725 RVA: 0x000FE318 File Offset: 0x000FC518
		[Token(Token = "0x60029E5")]
		[Address(RVA = "0x2E3E4EC", Offset = "0x2E3E4EC", VA = "0x2E3E4EC")]
		public float ՍӮ\u07FDٲ()
		{
			/*
An exception occurred when decompiling this method (060029E5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::ՍӮ߽ٲ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int32(var_0_06, ldfld:int32(proceduralAnimation::Ӏׅ࢝ؼ, ldloc:proceduralAnimation(this))); 	stloc:int64(var_1_08, ldc.i4:int64(0)); 	stloc:float32(var_2_10, call:float32(proceduralAnimation::ތݻ࡙٩, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_08))); 	stloc:int32(var_3_17, ldfld:int32(proceduralAnimation::Ӏׅ࢝ؼ, ldloc:proceduralAnimation(this))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060029E6 RID: 10726 RVA: 0x000FE33C File Offset: 0x000FC53C
		[Token(Token = "0x60029E6")]
		[Address(RVA = "0x2E3E6B0", Offset = "0x2E3E6B0", VA = "0x2E3E6B0")]
		public float ߐ\u066Dևנ(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x060029E7 RID: 10727 RVA: 0x000FE380 File Offset: 0x000FC580
		[Token(Token = "0x60029E7")]
		[Address(RVA = "0x2E3E808", Offset = "0x2E3E808", VA = "0x2E3E808")]
		public bool \u05B0ޙ\u07B6\u07F1(int ۹ࡎԬ\u058E)
		{
			bool[] u06D8ٺܓى = this.\u06D8ٺܓى;
			throw new NullReferenceException();
		}

		// Token: 0x060029E8 RID: 10728 RVA: 0x000FE3A0 File Offset: 0x000FC5A0
		[Token(Token = "0x60029E8")]
		[Address(RVA = "0x2E3E844", Offset = "0x2E3E844", VA = "0x2E3E844")]
		public float ڹذ\u083Aڣ(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x060029E9 RID: 10729 RVA: 0x000FE3E4 File Offset: 0x000FC5E4
		[Token(Token = "0x60029E9")]
		[Address(RVA = "0x2E3E99C", Offset = "0x2E3E99C", VA = "0x2E3E99C")]
		private void \u07BDއڸ\u0834()
		{
			Vector3 position = base.transform.position;
			float x = this.ۄܙՕթ.x;
			float y = this.ۄܙՕթ.y;
			float z = this.ۄܙՕթ.z;
			float deltaTime = Time.deltaTime;
			float x2 = this.\u086B\u0599\u074Cנ.x;
			float y2 = this.\u086B\u0599\u074Cנ.y;
			float z2 = this.\u086B\u0599\u074Cנ.z;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float num = this.velocityClamp;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Vector3 u0737ӊٴد = this.\u0737ӊٴد;
			float z3 = this.\u0737ӊٴد.z;
			this.\u086B\u0599\u074Cנ.z = z3;
		}

		// Token: 0x060029EA RID: 10730 RVA: 0x000FE578 File Offset: 0x000FC778
		[Token(Token = "0x60029EA")]
		[Address(RVA = "0x2E3EF10", Offset = "0x2E3EF10", VA = "0x2E3EF10")]
		private void Ԡݘעࠀ()
		{
			Vector3 position = base.transform.position;
			float x = this.ۄܙՕթ.x;
			float y = this.ۄܙՕթ.y;
			float z = this.ۄܙՕթ.z;
			float deltaTime = Time.deltaTime;
			float x2 = this.\u086B\u0599\u074Cנ.x;
			float y2 = this.\u086B\u0599\u074Cנ.y;
			float z2 = this.\u086B\u0599\u074Cנ.z;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float num = this.velocityClamp;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Vector3 u0737ӊٴد = this.\u0737ӊٴد;
			float z3 = this.\u0737ӊٴد.z;
			this.\u086B\u0599\u074Cנ.z = z3;
		}

		// Token: 0x060029EB RID: 10731 RVA: 0x000FE70C File Offset: 0x000FC90C
		[Token(Token = "0x60029EB")]
		[Address(RVA = "0x2E3B530", Offset = "0x2E3B530", VA = "0x2E3B530")]
		public static float ࡠԽڏ\u05B2(float \u0871ߘ\u0822Ө, float ճ\u058D\u0895מ, float ܜڃԑن, float ԝخث٧, float \u087Eցބڎ)
		{
			/*
An exception occurred when decompiling this method (060029EB)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::ࡠԽڏֲ(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_0A, call:float32(Mathf::InverseLerp, ldloc:float32(ࡱߘࠢӨ), ldloc:float32(ճ֍࢕מ), ldloc:float32(ܜڃԑن))); 	stloc:float32(var_3_15, call:float32(Mathf::Lerp, ldloc:float32(ܜڃԑن), ldloc:float32(ԝخث٧), ldloc:float32(var_1_0A))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060029EC RID: 10732 RVA: 0x000FE730 File Offset: 0x000FC930
		[Token(Token = "0x60029EC")]
		[Address(RVA = "0x2E3F4B8", Offset = "0x2E3F4B8", VA = "0x2E3F4B8")]
		private IEnumerator \u07FEױߟ\u06DF(Vector3 Ӏ\u05A9ӻݎ, int ۹ࡎԬ\u058E)
		{
			long <>1__state;
			proceduralAnimation.ޛ\u086Cӫ\u05F9 ޛ_u086Cӫ_u05F = new proceduralAnimation.ޛ\u086Cӫ\u05F9((int)<>1__state);
			<>1__state = 1L;
			ޛ_u086Cӫ_u05F.<>4__this = this;
			ޛ_u086Cӫ_u05F.index = Ӏ\u05A9ӻݎ;
			throw new NullReferenceException();
		}

		// Token: 0x060029ED RID: 10733 RVA: 0x000FE75C File Offset: 0x000FC95C
		[Token(Token = "0x60029ED")]
		[Address(RVA = "0x2E3F564", Offset = "0x2E3F564", VA = "0x2E3F564")]
		public Transform[] \u060C\u05BAܛܡ()
		{
			return this.legIktargets;
		}

		// Token: 0x060029EE RID: 10734 RVA: 0x000FE770 File Offset: 0x000FC970
		[Token(Token = "0x60029EE")]
		[Address(RVA = "0x2E3F56C", Offset = "0x2E3F56C", VA = "0x2E3F56C")]
		private IEnumerator ӊ\u0659ӓԹ(Vector3 Ӏ\u05A9ӻݎ, int ۹ࡎԬ\u058E)
		{
			long <>1__state;
			proceduralAnimation.ޛ\u086Cӫ\u05F9 ޛ_u086Cӫ_u05F = new proceduralAnimation.ޛ\u086Cӫ\u05F9((int)<>1__state);
			<>1__state = 1L;
			ޛ_u086Cӫ_u05F.<>4__this = this;
			ޛ_u086Cӫ_u05F.index = Ӏ\u05A9ӻݎ;
			throw new NullReferenceException();
		}

		// Token: 0x060029EF RID: 10735 RVA: 0x000FE79C File Offset: 0x000FC99C
		[Token(Token = "0x60029EF")]
		[Address(RVA = "0x2E3F618", Offset = "0x2E3F618", VA = "0x2E3F618")]
		public Transform[] ԃޗ\u05C5ۃ()
		{
			return this.legIktargets;
		}

		// Token: 0x060029F0 RID: 10736 RVA: 0x000FE7B0 File Offset: 0x000FC9B0
		[Token(Token = "0x60029F0")]
		[Address(RVA = "0x2E3F620", Offset = "0x2E3F620", VA = "0x2E3F620")]
		private float ېӞԱ\u07EC(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Transform transform = base.transform;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			throw new NullReferenceException();
		}

		// Token: 0x060029F1 RID: 10737 RVA: 0x000FE7E0 File Offset: 0x000FC9E0
		[Token(Token = "0x60029F1")]
		[Address(RVA = "0x2E3F6F8", Offset = "0x2E3F6F8", VA = "0x2E3F6F8")]
		public Transform[] ԥࢦӣԘ()
		{
			return this.legIktargets;
		}

		// Token: 0x060029F2 RID: 10738 RVA: 0x000FE7F4 File Offset: 0x000FC9F4
		[Token(Token = "0x60029F2")]
		[Address(RVA = "0x2E3F700", Offset = "0x2E3F700", VA = "0x2E3F700")]
		public LayerMask ޔ\u0559ߤۉ()
		{
			return this.layerMask;
		}

		// Token: 0x060029F3 RID: 10739 RVA: 0x000FE808 File Offset: 0x000FCA08
		[Token(Token = "0x60029F3")]
		[Address(RVA = "0x2E3F1F8", Offset = "0x2E3F1F8", VA = "0x2E3F1F8")]
		public void ܯ\u0706ӳچ(int ۹ࡎԬ\u058E)
		{
			Transform transform = base.transform;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			Vector3 vector;
			float magnitude = vector.normalized.magnitude;
			float num = this.velocityClamp;
			float ކܖࢻ_u = this.ކܖࢻ\u0877;
			float num2 = this.velocityMultiplier;
			LayerMask layerMask = this.layerMask;
			float num3 = this.legRayoffset;
			float num4 = this.legRayLength;
			float num5 = this.sphereCastRadius;
			Vector3[] array = this.ࡂ߀ڗժ;
			float[] ܝ_u082EӁ_u08B = this.ܝ\u082EӁ\u08B5;
			float num6 = this.ېӞԱ\u07EC(۹ࡎԬ\u058E);
			Transform[] array2 = this.legIktargets;
			Vector3[] array3 = this.ࡂ߀ڗժ;
			float[] ݼ_u05F3ࢨۑ = this.ݼ\u05F3ࢨۑ;
			float num7 = this.stepDistance;
			Vector3[] array4 = this.ࡂ߀ڗժ;
			Vector3 zero = Vector3.zero;
			Vector3[] array5 = this.ࡂ߀ڗժ;
			LayerMask layerMask2 = this.layerMask;
			float num8 = this.legRayoffset;
			float num9 = this.legRayLength;
			float num10 = this.sphereCastRadius;
			Vector3[] array6 = this.ࡂ߀ڗժ;
			int ڟ_u07EDՠ_u = this.ڟ\u07EDՠ\u0885;
			IEnumerator routine;
			Coroutine coroutine = base.StartCoroutine(routine);
		}

		// Token: 0x060029F4 RID: 10740 RVA: 0x000FE920 File Offset: 0x000FCB20
		[Token(Token = "0x60029F4")]
		[Address(RVA = "0x2E3F708", Offset = "0x2E3F708", VA = "0x2E3F708")]
		public LayerMask \u0742ߡߓد()
		{
			return this.layerMask;
		}

		// Token: 0x060029F5 RID: 10741 RVA: 0x000FE934 File Offset: 0x000FCB34
		[Token(Token = "0x60029F5")]
		[Address(RVA = "0x2E3F710", Offset = "0x2E3F710", VA = "0x2E3F710")]
		private IEnumerator צރߕ\u0604(float ࡑ۳\u0596\u066C)
		{
			long <>1__state;
			proceduralAnimation.ב\u081E\u05C0ࠕ ב_u081E_u05C0ࠕ = new proceduralAnimation.ב\u081E\u05C0ࠕ((int)<>1__state);
			<>1__state = 0L;
			ב_u081E_u05C0ࠕ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029F6 RID: 10742 RVA: 0x000FE958 File Offset: 0x000FCB58
		[Token(Token = "0x60029F6")]
		[Address(RVA = "0x2E3B578", Offset = "0x2E3B578", VA = "0x2E3B578")]
		public static float \u05F6\u058B\u0819Ր(float \u0871ߘ\u0822Ө, float ճ\u058D\u0895מ, float ܜڃԑن, float ԝخث٧, float \u087Eցބڎ)
		{
			/*
An exception occurred when decompiling this method (060029F6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::׶֋࠙Ր(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_0A, call:float32(Mathf::InverseLerp, ldloc:float32(ࡱߘࠢӨ), ldloc:float32(ճ֍࢕מ), ldloc:float32(ܜڃԑن))); 	stloc:float32(var_3_15, call:float32(Mathf::Lerp, ldloc:float32(ܜڃԑن), ldloc:float32(ԝخث٧), ldloc:float32(var_1_0A))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060029F7 RID: 10743 RVA: 0x000FE97C File Offset: 0x000FCB7C
		[Token(Token = "0x60029F7")]
		[Address(RVA = "0x2E3F798", Offset = "0x2E3F798", VA = "0x2E3F798")]
		private void ץࠂپӖ()
		{
			if (this.\u0657\u0886\u0895ߪ)
			{
				bool flag = Application.IsPlaying(this);
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				Transform transform = base.transform;
				Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				float num = this.velocityClamp;
				float ކܖࢻ_u = this.ކܖࢻ\u0877;
				float num2 = this.velocityMultiplier;
				LayerMask layerMask = this.layerMask;
				float num3 = this.legRayoffset;
				float num4 = this.legRayLength;
				float num5 = this.sphereCastRadius;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3[] u060Fݴ_u07FE_u2 = this.\u060Fݴ\u07FE\u0591;
				Vector3 up = Vector3.up;
				float num6 = this.legRayoffset;
				Vector3 up2 = Vector3.up;
				float num7 = this.legRayLength;
				Transform transform3 = base.transform;
				Vector3[] u060Fݴ_u07FE_u3 = this.\u060Fݴ\u07FE\u0591;
				float num8 = this.sphereCastRadius;
			}
		}

		// Token: 0x060029F8 RID: 10744 RVA: 0x000FEA78 File Offset: 0x000FCC78
		[Token(Token = "0x60029F8")]
		[Address(RVA = "0x2E3DBF4", Offset = "0x2E3DBF4", VA = "0x2E3DBF4")]
		private IEnumerator ߔӧ\u083A١(Vector3 Ӏ\u05A9ӻݎ, int ۹ࡎԬ\u058E)
		{
			long <>1__state;
			proceduralAnimation.ޛ\u086Cӫ\u05F9 ޛ_u086Cӫ_u05F = new proceduralAnimation.ޛ\u086Cӫ\u05F9((int)<>1__state);
			<>1__state = 1L;
			ޛ_u086Cӫ_u05F.<>4__this = this;
			ޛ_u086Cӫ_u05F.index = Ӏ\u05A9ӻݎ;
			throw new NullReferenceException();
		}

		// Token: 0x060029F9 RID: 10745 RVA: 0x000FEAA4 File Offset: 0x000FCCA4
		[Token(Token = "0x60029F9")]
		[Address(RVA = "0x2E3FA14", Offset = "0x2E3FA14", VA = "0x2E3FA14")]
		private void \u0821\u059Fӕ\u0607()
		{
			Vector3 position = base.transform.position;
			float x = this.ۄܙՕթ.x;
			float y = this.ۄܙՕթ.y;
			float z = this.ۄܙՕթ.z;
			float deltaTime = Time.deltaTime;
			float x2 = this.\u086B\u0599\u074Cנ.x;
			float y2 = this.\u086B\u0599\u074Cנ.y;
			float z2 = this.\u086B\u0599\u074Cנ.z;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float num = this.velocityClamp;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Vector3 u0737ӊٴد = this.\u0737ӊٴد;
			float z3 = this.\u0737ӊٴد.z;
			this.\u086B\u0599\u074Cנ.z = z3;
		}

		// Token: 0x060029FA RID: 10746 RVA: 0x000FEC34 File Offset: 0x000FCE34
		[Token(Token = "0x60029FA")]
		[Address(RVA = "0x2E3FCE0", Offset = "0x2E3FCE0", VA = "0x2E3FCE0")]
		private void ߉چԓࡊ()
		{
			if (this.\u0657\u0886\u0895ߪ)
			{
				bool flag = Application.IsPlaying(this);
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				Transform transform = base.transform;
				Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				float num = this.velocityClamp;
				float ކܖࢻ_u = this.ކܖࢻ\u0877;
				float num2 = this.velocityMultiplier;
				LayerMask layerMask = this.layerMask;
				float num3 = this.legRayoffset;
				float num4 = this.legRayLength;
				float num5 = this.sphereCastRadius;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3[] u060Fݴ_u07FE_u2 = this.\u060Fݴ\u07FE\u0591;
				Vector3 up = Vector3.up;
				float num6 = this.legRayoffset;
				Vector3 up2 = Vector3.up;
				float num7 = this.legRayLength;
				Transform transform3 = base.transform;
				Vector3[] u060Fݴ_u07FE_u3 = this.\u060Fݴ\u07FE\u0591;
				float num8 = this.sphereCastRadius;
			}
		}

		// Token: 0x060029FB RID: 10747 RVA: 0x000FED30 File Offset: 0x000FCF30
		[Token(Token = "0x60029FB")]
		[Address(RVA = "0x2E3E0DC", Offset = "0x2E3E0DC", VA = "0x2E3E0DC")]
		public float \u07EBڢ٢ܓ(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x060029FC RID: 10748 RVA: 0x000FED74 File Offset: 0x000FCF74
		[Token(Token = "0x60029FC")]
		[Address(RVA = "0x2E3FF5C", Offset = "0x2E3FF5C", VA = "0x2E3FF5C")]
		private void \u06EDٵ۶\u06DB()
		{
			Transform[] array = this.legIktargets;
			this.\u060Fݴ\u07FE\u0591 = typeof(Vector3[]).TypeHandle;
			Vector3[] u06FD١ב_u088B = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.\u06FD١ב\u088B = u06FD١ב_u088B;
			Vector3[] array2 = new Vector3[this.Ӏ\u089D\u05C5ؼ];
			this.ࡂ߀ڗժ = array2;
			bool[] u06D8ٺܓى = new bool[this.Ӏ\u089D\u05C5ؼ];
			this.\u06D8ٺܓى = u06D8ٺܓى;
			float[] ӡ_u06D9Ӗߊ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ӡ\u06D9Ӗߊ = ӡ_u06D9Ӗߊ;
			float[] ݼ_u05F3ࢨۑ = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ݼ\u05F3ࢨۑ = ݼ_u05F3ࢨۑ;
			float[] ܝ_u082EӁ_u08B = new float[this.Ӏ\u089D\u05C5ؼ];
			this.ܝ\u082EӁ\u08B5 = ܝ_u082EӁ_u08B;
			if (this.SetTimingsManually)
			{
				float[] array3 = this.manualTimings;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Debug.LogError("Reason: ");
			}
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			bool setTimingsManually = this.SetTimingsManually;
			float[] ӡ_u06D9Ӗߊ2 = this.ӡ\u06D9Ӗߊ;
			if (setTimingsManually)
			{
				float[] array4 = this.manualTimings;
				return;
			}
			Transform[] array5 = this.legIktargets;
			Vector3[] u06FD١ב_u088B2 = this.\u06FD١ב\u088B;
			Transform[] array6 = this.legIktargets;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			int ӏ_u089D_u05C5ؼ3 = this.Ӏ\u089D\u05C5ؼ;
			float num = this.refreshTimingRate;
			IEnumerator routine;
			Coroutine coroutine = base.StartCoroutine(routine);
		}

		// Token: 0x060029FD RID: 10749 RVA: 0x000FEEA0 File Offset: 0x000FD0A0
		[Token(Token = "0x60029FD")]
		[Address(RVA = "0x2E4022C", Offset = "0x2E4022C", VA = "0x2E4022C")]
		public float \u05F4מ\u061Fݶ()
		{
			/*
An exception occurred when decompiling this method (060029FD)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::״מ؟ݶ()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int32(var_0_06, ldfld:int32(proceduralAnimation::Ӏׅ࢝ؼ, ldloc:proceduralAnimation(this))); 	stloc:int64(var_1_08, ldc.i4:int64(1)); 	stloc:float32(var_2_10, call:float32(proceduralAnimation::֣ࡠӞހ, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_08))); 	stloc:int32(var_3_17, ldfld:int32(proceduralAnimation::Ӏׅ࢝ؼ, ldloc:proceduralAnimation(this))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060029FE RID: 10750 RVA: 0x000FEEC4 File Offset: 0x000FD0C4
		[Token(Token = "0x60029FE")]
		[Address(RVA = "0x2E3CC78", Offset = "0x2E3CC78", VA = "0x2E3CC78")]
		public void ԗ\u05AFӁ\u05C6(int ۹ࡎԬ\u058E)
		{
			Transform transform = base.transform;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			Vector3 vector;
			float magnitude = vector.normalized.magnitude;
			float num = this.velocityClamp;
			float ކܖࢻ_u = this.ކܖࢻ\u0877;
			float num2 = this.velocityMultiplier;
			LayerMask layerMask = this.layerMask;
			float num3 = this.legRayoffset;
			float num4 = this.legRayLength;
			float num5 = this.sphereCastRadius;
			Vector3[] array = this.ࡂ߀ڗժ;
			float[] ܝ_u082EӁ_u08B = this.ܝ\u082EӁ\u08B5;
			float num6 = this.ב\u05B0\u070Bפ(۹ࡎԬ\u058E);
			Transform[] array2 = this.legIktargets;
			Vector3[] array3 = this.ࡂ߀ڗժ;
			float[] ݼ_u05F3ࢨۑ = this.ݼ\u05F3ࢨۑ;
			float num7 = this.stepDistance;
			Vector3[] array4 = this.ࡂ߀ڗժ;
			Vector3 zero = Vector3.zero;
			Vector3[] array5 = this.ࡂ߀ڗժ;
			LayerMask layerMask2 = this.layerMask;
			float num8 = this.legRayoffset;
			float num9 = this.legRayLength;
			float num10 = this.sphereCastRadius;
			Vector3[] array6 = this.ࡂ߀ڗժ;
			int ڟ_u07EDՠ_u = this.ڟ\u07EDՠ\u0885;
			IEnumerator routine;
			Coroutine coroutine = base.StartCoroutine(routine);
		}

		// Token: 0x060029FF RID: 10751 RVA: 0x000FEFDC File Offset: 0x000FD1DC
		[Token(Token = "0x60029FF")]
		[Address(RVA = "0x2E3B5C0", Offset = "0x2E3B5C0", VA = "0x2E3B5C0")]
		public void ءԈ\u07BFԜ(int ۹ࡎԬ\u058E)
		{
			Transform transform = base.transform;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			Vector3 vector;
			float magnitude = vector.normalized.magnitude;
			float num = this.velocityClamp;
			float ކܖࢻ_u = this.ކܖࢻ\u0877;
			float num2 = this.velocityMultiplier;
			LayerMask layerMask = this.layerMask;
			float num3 = this.legRayoffset;
			float num4 = this.legRayLength;
			float num5 = this.sphereCastRadius;
			Vector3[] array = this.ࡂ߀ڗժ;
			float[] ܝ_u082EӁ_u08B = this.ܝ\u082EӁ\u08B5;
			float num6 = this.\u05FDԦݫ\u070C(۹ࡎԬ\u058E);
			Transform[] array2 = this.legIktargets;
			Vector3[] array3 = this.ࡂ߀ڗժ;
			float[] ݼ_u05F3ࢨۑ = this.ݼ\u05F3ࢨۑ;
			float num7 = this.stepDistance;
			Vector3[] array4 = this.ࡂ߀ڗժ;
			Vector3 zero = Vector3.zero;
			Vector3[] array5 = this.ࡂ߀ڗժ;
			LayerMask layerMask2 = this.layerMask;
			float num8 = this.legRayoffset;
			float num9 = this.legRayLength;
			float num10 = this.sphereCastRadius;
			Vector3[] array6 = this.ࡂ߀ڗժ;
			int ڟ_u07EDՠ_u = this.ڟ\u07EDՠ\u0885;
			IEnumerator routine;
			Coroutine coroutine = base.StartCoroutine(routine);
		}

		// Token: 0x06002A00 RID: 10752 RVA: 0x000FF0F4 File Offset: 0x000FD2F4
		[Token(Token = "0x6002A00")]
		[Address(RVA = "0x2E40298", Offset = "0x2E40298", VA = "0x2E40298")]
		private IEnumerator \u073A\u060Bވ۲(Vector3 Ӏ\u05A9ӻݎ, int ۹ࡎԬ\u058E)
		{
			long <>1__state;
			proceduralAnimation.ޛ\u086Cӫ\u05F9 ޛ_u086Cӫ_u05F = new proceduralAnimation.ޛ\u086Cӫ\u05F9((int)<>1__state);
			<>1__state = 0L;
			ޛ_u086Cӫ_u05F.<>4__this = this;
			ޛ_u086Cӫ_u05F.index = Ӏ\u05A9ӻݎ;
			throw new NullReferenceException();
		}

		// Token: 0x06002A01 RID: 10753 RVA: 0x000FF120 File Offset: 0x000FD320
		[Token(Token = "0x6002A01")]
		[Address(RVA = "0x2E3DB30", Offset = "0x2E3DB30", VA = "0x2E3DB30")]
		private IEnumerator \u0872\u07F4\u061BԼ(float ࡑ۳\u0596\u066C)
		{
			long <>1__state;
			proceduralAnimation.ב\u081E\u05C0ࠕ ב_u081E_u05C0ࠕ = new proceduralAnimation.ב\u081E\u05C0ࠕ((int)<>1__state);
			<>1__state = 0L;
			ב_u081E_u05C0ࠕ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002A02 RID: 10754 RVA: 0x000FF144 File Offset: 0x000FD344
		[Token(Token = "0x6002A02")]
		[Address(RVA = "0x2E403F0", Offset = "0x2E403F0", VA = "0x2E403F0")]
		private void OnDrawGizmosSelected()
		{
			if (this.\u0657\u0886\u0895ߪ)
			{
				bool flag = Application.IsPlaying(this);
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				Transform transform = base.transform;
				Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				float num = this.velocityClamp;
				float ކܖࢻ_u = this.ކܖࢻ\u0877;
				float num2 = this.velocityMultiplier;
				LayerMask layerMask = this.layerMask;
				float num3 = this.legRayoffset;
				float num4 = this.legRayLength;
				float num5 = this.sphereCastRadius;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3[] u060Fݴ_u07FE_u2 = this.\u060Fݴ\u07FE\u0591;
				Vector3 up = Vector3.up;
				float num6 = this.legRayoffset;
				Vector3 up2 = Vector3.up;
				float num7 = this.legRayLength;
				Transform transform3 = base.transform;
				Vector3[] u060Fݴ_u07FE_u3 = this.\u060Fݴ\u07FE\u0591;
				float num8 = this.sphereCastRadius;
			}
		}

		// Token: 0x06002A03 RID: 10755 RVA: 0x000FF240 File Offset: 0x000FD440
		[Token(Token = "0x6002A03")]
		[Address(RVA = "0x2E40664", Offset = "0x2E40664", VA = "0x2E40664")]
		public LayerMask ח߆ٲݒ()
		{
			return this.layerMask;
		}

		// Token: 0x06002A04 RID: 10756 RVA: 0x000FF254 File Offset: 0x000FD454
		[Token(Token = "0x6002A04")]
		[Address(RVA = "0x2E4066C", Offset = "0x2E4066C", VA = "0x2E4066C")]
		public proceduralAnimation()
		{
			long num = 1065353216L;
			this.cycleSpeed = (float)num;
			this.timigsOffset = 0f;
			Keyframe[] array = new Keyframe[3];
			if (array.m_OutWeight != null)
			{
				float outWeight = array.m_OutWeight;
				float outWeight2 = array.m_OutWeight;
				AnimationCurve animationCurve = new AnimationCurve(array);
				this.legArcPathY = animationCurve;
				AnimationCurve animationCurve2;
				this.easingFunction = animationCurve2;
				long u0657_u0886_u0895ߪ = 1L;
				this.\u0657\u0886\u0895ߪ = (u0657_u0886_u0895ߪ != 0L);
				base..ctor();
				return;
			}
			throw new IndexOutOfRangeException();
		}

		// Token: 0x06002A05 RID: 10757 RVA: 0x000FF2D0 File Offset: 0x000FD4D0
		[Token(Token = "0x6002A05")]
		[Address(RVA = "0x2E3E558", Offset = "0x2E3E558", VA = "0x2E3E558")]
		public float ތݻ\u0859٩(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x06002A06 RID: 10758 RVA: 0x000FF314 File Offset: 0x000FD514
		[Token(Token = "0x6002A06")]
		[Address(RVA = "0x2E4087C", Offset = "0x2E4087C", VA = "0x2E4087C")]
		public LayerMask \u05C3\u06FDٷӗ()
		{
			return this.layerMask;
		}

		// Token: 0x06002A07 RID: 10759 RVA: 0x000FF328 File Offset: 0x000FD528
		[Token(Token = "0x6002A07")]
		[Address(RVA = "0x2E3EC50", Offset = "0x2E3EC50", VA = "0x2E3EC50")]
		public void Ԩռӯݴ(int ۹ࡎԬ\u058E)
		{
			Transform transform = base.transform;
			Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
			Vector3 vector;
			float magnitude = vector.normalized.magnitude;
			float num = this.velocityClamp;
			float ކܖࢻ_u = this.ކܖࢻ\u0877;
			float num2 = this.velocityMultiplier;
			LayerMask layerMask = this.layerMask;
			float num3 = this.legRayoffset;
			float num4 = this.legRayLength;
			float num5 = this.sphereCastRadius;
			Vector3[] array = this.ࡂ߀ڗժ;
			float[] ܝ_u082EӁ_u08B = this.ܝ\u082EӁ\u08B5;
			float num6 = this.\u0558\u05F5ԣߌ(۹ࡎԬ\u058E);
			Transform[] array2 = this.legIktargets;
			Vector3[] array3 = this.ࡂ߀ڗժ;
			float[] ݼ_u05F3ࢨۑ = this.ݼ\u05F3ࢨۑ;
			float num7 = this.stepDistance;
			Vector3[] array4 = this.ࡂ߀ڗժ;
			Vector3 zero = Vector3.zero;
			Vector3[] array5 = this.ࡂ߀ڗժ;
			LayerMask layerMask2 = this.layerMask;
			float num8 = this.legRayoffset;
			float num9 = this.legRayLength;
			float num10 = this.sphereCastRadius;
			Vector3[] array6 = this.ࡂ߀ڗժ;
			int ڟ_u07EDՠ_u = this.ڟ\u07EDՠ\u0885;
			IEnumerator routine;
			Coroutine coroutine = base.StartCoroutine(routine);
		}

		// Token: 0x06002A08 RID: 10760 RVA: 0x000FF440 File Offset: 0x000FD640
		[Token(Token = "0x6002A08")]
		[Address(RVA = "0x2E40884", Offset = "0x2E40884", VA = "0x2E40884")]
		private void \u05A2\u05A4ܡܨ()
		{
			if (this.\u0657\u0886\u0895ߪ)
			{
				bool flag = Application.IsPlaying(this);
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
				Transform transform = base.transform;
				Vector3[] u060Fݴ_u07FE_u = this.\u060Fݴ\u07FE\u0591;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				float num = this.velocityClamp;
				float ކܖࢻ_u = this.ކܖࢻ\u0877;
				float num2 = this.velocityMultiplier;
				LayerMask layerMask = this.layerMask;
				float num3 = this.legRayoffset;
				float num4 = this.legRayLength;
				float num5 = this.sphereCastRadius;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3[] u060Fݴ_u07FE_u2 = this.\u060Fݴ\u07FE\u0591;
				Vector3 up = Vector3.up;
				float num6 = this.legRayoffset;
				Vector3 up2 = Vector3.up;
				float num7 = this.legRayLength;
				Transform transform3 = base.transform;
				Vector3[] u060Fݴ_u07FE_u3 = this.\u060Fݴ\u07FE\u0591;
				float num8 = this.sphereCastRadius;
			}
		}

		// Token: 0x06002A09 RID: 10761 RVA: 0x000FF53C File Offset: 0x000FD73C
		[Token(Token = "0x6002A09")]
		[Address(RVA = "0x2E40B00", Offset = "0x2E40B00", VA = "0x2E40B00")]
		public float \u060D\u0530ԫ\u0883(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x06002A0A RID: 10762 RVA: 0x000FF580 File Offset: 0x000FD780
		[Token(Token = "0x6002A0A")]
		[Address(RVA = "0x2E40C58", Offset = "0x2E40C58", VA = "0x2E40C58")]
		private void ڄ\u0896\u0705غ(Vector3 Ӏ\u05A9ӻݎ, int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Transform[] array2 = this.legIktargets;
			Vector3[] u06FD١ב_u088B = this.\u06FD١ב\u088B;
			float[] ܝ_u082EӁ_u08B = this.ܝ\u082EӁ\u08B5;
			if (this.\u070Aل\u0604ࢠ != null)
			{
			}
			bool[] u06D8ٺܓى = this.\u06D8ٺܓى;
		}

		// Token: 0x06002A0B RID: 10763 RVA: 0x000FF5CC File Offset: 0x000FD7CC
		[Token(Token = "0x6002A0B")]
		[Address(RVA = "0x2E40DC8", Offset = "0x2E40DC8", VA = "0x2E40DC8")]
		public float \u06E7Խս\u07A8(int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x06002A0C RID: 10764 RVA: 0x000FF610 File Offset: 0x000FD810
		[Token(Token = "0x6002A0C")]
		[Address(RVA = "0x2E40F20", Offset = "0x2E40F20", VA = "0x2E40F20")]
		private void ܪ\u07BB\u086Bࠆ()
		{
			Vector3 position = base.transform.position;
			float x = this.ۄܙՕթ.x;
			float y = this.ۄܙՕթ.y;
			float z = this.ۄܙՕթ.z;
			float deltaTime = Time.deltaTime;
			float x2 = this.\u086B\u0599\u074Cנ.x;
			float y2 = this.\u086B\u0599\u074Cנ.y;
			float z2 = this.\u086B\u0599\u074Cנ.z;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float num = this.velocityClamp;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Vector3 u0737ӊٴد = this.\u0737ӊٴد;
			float z3 = this.\u0737ӊٴد.z;
			this.\u086B\u0599\u074Cנ.z = z3;
		}

		// Token: 0x06002A0D RID: 10765 RVA: 0x000FF79C File Offset: 0x000FD99C
		[Token(Token = "0x6002A0D")]
		[Address(RVA = "0x2E411CC", Offset = "0x2E411CC", VA = "0x2E411CC")]
		public LayerMask ֈԎ\u081B١()
		{
			return this.layerMask;
		}

		// Token: 0x06002A0E RID: 10766 RVA: 0x000FF7B0 File Offset: 0x000FD9B0
		[Token(Token = "0x6002A0E")]
		[Address(RVA = "0x2E411D4", Offset = "0x2E411D4", VA = "0x2E411D4")]
		public LayerMask ࢴեڌӽ()
		{
			return this.layerMask;
		}

		// Token: 0x06002A0F RID: 10767 RVA: 0x000FF7C4 File Offset: 0x000FD9C4
		[Token(Token = "0x6002A0F")]
		[Address(RVA = "0x2E40344", Offset = "0x2E40344", VA = "0x2E40344")]
		private IEnumerator \u082Fӄ٩ӛ(Vector3 Ӏ\u05A9ӻݎ, int ۹ࡎԬ\u058E)
		{
			long <>1__state;
			proceduralAnimation.ޛ\u086Cӫ\u05F9 ޛ_u086Cӫ_u05F = new proceduralAnimation.ޛ\u086Cӫ\u05F9((int)<>1__state);
			<>1__state = 1L;
			ޛ_u086Cӫ_u05F.<>4__this = this;
			ޛ_u086Cӫ_u05F.index = Ӏ\u05A9ӻݎ;
			throw new NullReferenceException();
		}

		// Token: 0x06002A10 RID: 10768 RVA: 0x000FF7F0 File Offset: 0x000FD9F0
		[Token(Token = "0x6002A10")]
		[Address(RVA = "0x2E411DC", Offset = "0x2E411DC", VA = "0x2E411DC")]
		public Transform[] ԔՅԥڅ()
		{
			return this.legIktargets;
		}

		// Token: 0x06002A11 RID: 10769 RVA: 0x000FF804 File Offset: 0x000FDA04
		[Token(Token = "0x6002A11")]
		[Address(RVA = "0x2E411E4", Offset = "0x2E411E4", VA = "0x2E411E4")]
		private void \u0735ݚ\u0594ۓ(Vector3 Ӏ\u05A9ӻݎ, int ۹ࡎԬ\u058E)
		{
			Transform[] array = this.legIktargets;
			Transform[] array2 = this.legIktargets;
			Vector3[] u06FD١ב_u088B = this.\u06FD١ב\u088B;
			float[] ܝ_u082EӁ_u08B = this.ܝ\u082EӁ\u08B5;
			if (this.\u070Aل\u0604ࢠ != null)
			{
			}
			bool[] u06D8ٺܓى = this.\u06D8ٺܓى;
		}

		// Token: 0x04000540 RID: 1344
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000540")]
		[SerializeField]
		[Tooltip("Step distance is used to calculate step height. When character makes a short step there is no need to rase foot all the way up so if the current step distance is less then this step distance value step height will be lover then usual.")]
		private float stepDistance;

		// Token: 0x04000541 RID: 1345
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000541")]
		[SerializeField]
		private float stepHeight;

		// Token: 0x04000542 RID: 1346
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000542")]
		[SerializeField]
		private float stepSpeed;

		// Token: 0x04000543 RID: 1347
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4000543")]
		[SerializeField]
		[Tooltip("Velocity multiplier used to make step wider when moving on high speed (if you toggle the show gizmoz below and move your model around you could clearly see what this does. The blue spheres represent the target step points and will move further ahead if you increase velocity multiplier)")]
		private float velocityMultiplier;

		// Token: 0x04000544 RID: 1348
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000544")]
		[SerializeField]
		private float cycleSpeed;

		// Token: 0x04000545 RID: 1349
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000545")]
		[SerializeField]
		[Tooltip("how often in seconds legs will move (every one second by default)")]
		private float cycleLimit;

		// Token: 0x04000546 RID: 1350
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000546")]
		[SerializeField]
		[Tooltip("â\u0080¢\tIf you want some legs to move together enable the Set Timings Manually. And add as many timings as your model has legs. The first Manual Timing is relative to the first leg in the leg IK targets array etc. For example: if your character has four legs and you want two left legs move first and two right to move second you need to set timings to [0.5, 0.5, 0, 0]. That means that first two legs will move and only 0.5 second later the second two will move. ")]
		private bool SetTimingsManually;

		// Token: 0x04000547 RID: 1351
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000547")]
		[SerializeField]
		private float[] manualTimings;

		// Token: 0x04000548 RID: 1352
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000548")]
		[SerializeField]
		[Tooltip("If you want only one leg to move at a time then set Timings offset as one divided by the number of legs. For example: if your character has four legs you need to set this as Â¼ = 0.25. The script will offset the cycle of every leg by 0.25 seconds. ")]
		private float timigsOffset;

		// Token: 0x04000549 RID: 1353
		[FieldOffset(Offset = "0x44")]
		[Token(Token = "0x4000549")]
		[SerializeField]
		[Tooltip("Velocity clamp limits the step distance while moving on high speed.")]
		private float velocityClamp;

		// Token: 0x0400054A RID: 1354
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x400054A")]
		[SerializeField]
		private LayerMask layerMask;

		// Token: 0x0400054B RID: 1355
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x400054B")]
		[SerializeField]
		private AnimationCurve legArcPathY;

		// Token: 0x0400054C RID: 1356
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x400054C")]
		[SerializeField]
		private AnimationCurve easingFunction;

		// Token: 0x0400054D RID: 1357
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x400054D")]
		[SerializeField]
		private Transform[] legIktargets;

		// Token: 0x0400054E RID: 1358
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x400054E")]
		public bool \u0657\u0886\u0895ߪ;

		// Token: 0x0400054F RID: 1359
		[FieldOffset(Offset = "0x6C")]
		[Token(Token = "0x400054F")]
		[SerializeField]
		private float legRayoffset;

		// Token: 0x04000550 RID: 1360
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x4000550")]
		[SerializeField]
		private float legRayLength;

		// Token: 0x04000551 RID: 1361
		[FieldOffset(Offset = "0x74")]
		[Token(Token = "0x4000551")]
		[SerializeField]
		[Tooltip("Ground check range for every leg")]
		private float sphereCastRadius;

		// Token: 0x04000552 RID: 1362
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x4000552")]
		[SerializeField]
		[Header("Advansed")]
		[Tooltip("Refresh Timings rate updates timings and sets it to default value to make sure every leg is making step at the right time. If your character moves slowly, you can set it as some big value like 100 so it updates only every 100 seconds but if not, you need to lower this value. For example: fast pink robot in demo scene has this value set as 10. ")]
		private float refreshTimingRate;

		// Token: 0x04000553 RID: 1363
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x4000553")]
		public EventHandler<Vector3> \u070Aل\u0604ࢠ;

		// Token: 0x04000554 RID: 1364
		[FieldOffset(Offset = "0x88")]
		[Token(Token = "0x4000554")]
		private Vector3[] \u06FD١ב\u088B;

		// Token: 0x04000555 RID: 1365
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000555")]
		private Vector3[] \u060Fݴ\u07FE\u0591;

		// Token: 0x04000556 RID: 1366
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x4000556")]
		private Vector3[] ۿӕڦ\u073B;

		// Token: 0x04000557 RID: 1367
		[FieldOffset(Offset = "0xA0")]
		[Token(Token = "0x4000557")]
		private Vector3[] ࡂ߀ڗժ;

		// Token: 0x04000558 RID: 1368
		[FieldOffset(Offset = "0xA8")]
		[Token(Token = "0x4000558")]
		private Vector3 \u0737ӊٴد;

		// Token: 0x04000559 RID: 1369
		[FieldOffset(Offset = "0xB4")]
		[Token(Token = "0x4000559")]
		private Vector3 \u086B\u0599\u074Cנ;

		// Token: 0x0400055A RID: 1370
		[FieldOffset(Offset = "0xC0")]
		[Token(Token = "0x400055A")]
		private Vector3 ۄܙՕթ;

		// Token: 0x0400055B RID: 1371
		[FieldOffset(Offset = "0xD0")]
		[Token(Token = "0x400055B")]
		private float[] ӡ\u06D9Ӗߊ;

		// Token: 0x0400055C RID: 1372
		[FieldOffset(Offset = "0xD8")]
		[Token(Token = "0x400055C")]
		private float[] Գ\u05A9ӟ\u0559;

		// Token: 0x0400055D RID: 1373
		[FieldOffset(Offset = "0xE0")]
		[Token(Token = "0x400055D")]
		private float[] ܝ\u082EӁ\u08B5;

		// Token: 0x0400055E RID: 1374
		[FieldOffset(Offset = "0xE8")]
		[Token(Token = "0x400055E")]
		private float ކܖࢻ\u0877;

		// Token: 0x0400055F RID: 1375
		[FieldOffset(Offset = "0xF0")]
		[Token(Token = "0x400055F")]
		private float[] ݼ\u05F3ࢨۑ;

		// Token: 0x04000560 RID: 1376
		[FieldOffset(Offset = "0xF8")]
		[Token(Token = "0x4000560")]
		private int Ӏ\u089D\u05C5ؼ;

		// Token: 0x04000561 RID: 1377
		[FieldOffset(Offset = "0xFC")]
		[Token(Token = "0x4000561")]
		private int ڟ\u07EDՠ\u0885;

		// Token: 0x04000562 RID: 1378
		[FieldOffset(Offset = "0x100")]
		[Token(Token = "0x4000562")]
		private bool[] \u06D8ٺܓى;
	}
}
