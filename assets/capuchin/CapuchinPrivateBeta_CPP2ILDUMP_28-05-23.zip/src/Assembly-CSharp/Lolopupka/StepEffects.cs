﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x02000108 RID: 264
	[Token(Token = "0x2000108")]
	public class StepEffects : MonoBehaviour
	{
		// Token: 0x0600292E RID: 10542 RVA: 0x000FB974 File Offset: 0x000F9B74
		[Token(Token = "0x600292E")]
		[Address(RVA = "0x2F78B48", Offset = "0x2F78B48", VA = "0x2F78B48")]
		private void Start()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) != null)
			{
			}
		}

		// Token: 0x0600292F RID: 10543 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x600292F")]
		[Address(RVA = "0x2F78D18", Offset = "0x2F78D18", VA = "0x2F78D18")]
		private void ל\u05F8ٺ\u082F(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002930 RID: 10544 RVA: 0x000FB9A0 File Offset: 0x000F9BA0
		[Token(Token = "0x6002930")]
		[Address(RVA = "0x2F78ED0", Offset = "0x2F78ED0", VA = "0x2F78ED0")]
		private void \u066D\u05BDې߃()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) != null)
			{
			}
		}

		// Token: 0x06002931 RID: 10545 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002931")]
		[Address(RVA = "0x2F790A0", Offset = "0x2F790A0", VA = "0x2F790A0")]
		private void \u07B0\u081Dۍۂ(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002932 RID: 10546 RVA: 0x000FB9CC File Offset: 0x000F9BCC
		[Token(Token = "0x6002932")]
		[Address(RVA = "0x2F79258", Offset = "0x2F79258", VA = "0x2F79258")]
		private void ߖհݣ߀()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) != null)
			{
			}
		}

		// Token: 0x06002933 RID: 10547 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002933")]
		[Address(RVA = "0x2F79428", Offset = "0x2F79428", VA = "0x2F79428")]
		private void ݯࡖٲ\u061E(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002934 RID: 10548 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002934")]
		[Address(RVA = "0x2F795E0", Offset = "0x2F795E0", VA = "0x2F795E0")]
		private void փ\u0891ۈݫ(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002935 RID: 10549 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002935")]
		[Address(RVA = "0x2F79798", Offset = "0x2F79798", VA = "0x2F79798")]
		private void ןߧҼ\u0597(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002936 RID: 10550 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002936")]
		[Address(RVA = "0x2F7994C", Offset = "0x2F7994C", VA = "0x2F7994C")]
		private void ࢨࢰ\u089Dݦ(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002937 RID: 10551 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002937")]
		[Address(RVA = "0x2F79B00", Offset = "0x2F79B00", VA = "0x2F79B00")]
		private void ࡔރࠉԇ(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002938 RID: 10552 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002938")]
		[Address(RVA = "0x2F79CB8", Offset = "0x2F79CB8", VA = "0x2F79CB8")]
		private void ݼߗ\u082D\u05FE(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002939 RID: 10553 RVA: 0x000FB9F8 File Offset: 0x000F9BF8
		[Token(Token = "0x6002939")]
		[Address(RVA = "0x2F79E6C", Offset = "0x2F79E6C", VA = "0x2F79E6C")]
		private void Ԯ\u0883\u0591\u066C()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) != null)
			{
			}
		}

		// Token: 0x0600293A RID: 10554 RVA: 0x000FBA24 File Offset: 0x000F9C24
		[Token(Token = "0x600293A")]
		[Address(RVA = "0x2F7A03C", Offset = "0x2F7A03C", VA = "0x2F7A03C")]
		private void ݤۅࢦӃ()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) != null)
			{
			}
		}

		// Token: 0x0600293B RID: 10555 RVA: 0x000FBA50 File Offset: 0x000F9C50
		[Token(Token = "0x600293B")]
		[Address(RVA = "0x2F7A20C", Offset = "0x2F7A20C", VA = "0x2F7A20C")]
		private void ࢰחڵࡓ()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) != null)
			{
			}
		}

		// Token: 0x0600293C RID: 10556 RVA: 0x000FBA7C File Offset: 0x000F9C7C
		[Token(Token = "0x600293C")]
		[Address(RVA = "0x2F7A3DC", Offset = "0x2F7A3DC", VA = "0x2F7A3DC")]
		private void \u0558ݕݤݮ()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) != null)
			{
			}
		}

		// Token: 0x0600293D RID: 10557 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x600293D")]
		[Address(RVA = "0x2F7A5AC", Offset = "0x2F7A5AC", VA = "0x2F7A5AC")]
		private void ԝޛڂړ(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600293E RID: 10558 RVA: 0x000FBAA8 File Offset: 0x000F9CA8
		[Token(Token = "0x600293E")]
		[Address(RVA = "0x2F7A764", Offset = "0x2F7A764", VA = "0x2F7A764")]
		private void ࠏޤݳ\u06DD()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) != null)
			{
			}
		}

		// Token: 0x0600293F RID: 10559 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x600293F")]
		[Address(RVA = "0x2F7A934", Offset = "0x2F7A934", VA = "0x2F7A934")]
		private void ࡈ\u089A\u059Cࡊ(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002940 RID: 10560 RVA: 0x000FBAD4 File Offset: 0x000F9CD4
		[Token(Token = "0x6002940")]
		[Address(RVA = "0x2F7AAEC", Offset = "0x2F7AAEC", VA = "0x2F7AAEC")]
		private void הԥ\u05B5ݴ()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) != null)
			{
			}
		}

		// Token: 0x06002941 RID: 10561 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002941")]
		[Address(RVA = "0x2F7ACBC", Offset = "0x2F7ACBC", VA = "0x2F7ACBC")]
		private void \u0878Պ\u07ABՖ(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002942 RID: 10562 RVA: 0x000FBB00 File Offset: 0x000F9D00
		[Token(Token = "0x6002942")]
		[Address(RVA = "0x2F7AE74", Offset = "0x2F7AE74", VA = "0x2F7AE74")]
		public StepEffects()
		{
		}

		// Token: 0x06002943 RID: 10563 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002943")]
		[Address(RVA = "0x2F7AE7C", Offset = "0x2F7AE7C", VA = "0x2F7AE7C")]
		private void ࢡغ\u086Bر(object ڿկ\u0859ػ, Vector3 \u070FՃ\u07BA\u064B)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0400053C RID: 1340
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400053C")]
		[SerializeField]
		private AudioClip[] stepSVX;

		// Token: 0x0400053D RID: 1341
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400053D")]
		[SerializeField]
		private GameObject stepVFX;

		// Token: 0x0400053E RID: 1342
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400053E")]
		private proceduralAnimation \u059DԪ\u0887փ;

		// Token: 0x0400053F RID: 1343
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400053F")]
		private AudioSource \u0617\u087Fտߎ;
	}
}
