﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x02000107 RID: 263
	[Token(Token = "0x2000107")]
	public class ProceduralBodyController : MonoBehaviour
	{
		// Token: 0x060028B1 RID: 10417 RVA: 0x000F8840 File Offset: 0x000F6A40
		[Token(Token = "0x60028B1")]
		[Address(RVA = "0x2C420EC", Offset = "0x2C420EC", VA = "0x2C420EC")]
		private Vector3 ռӡܖԏ()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x060028B2 RID: 10418 RVA: 0x000F8878 File Offset: 0x000F6A78
		[Token(Token = "0x60028B2")]
		[Address(RVA = "0x2C42190", Offset = "0x2C42190", VA = "0x2C42190")]
		private void \u0881\u0743\u07EB\u0747()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x060028B3 RID: 10419 RVA: 0x000F88A0 File Offset: 0x000F6AA0
		[Token(Token = "0x60028B3")]
		[Address(RVA = "0x2C421DC", Offset = "0x2C421DC", VA = "0x2C421DC")]
		private Vector3 \u05CC\u0821ג\u0559()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x060028B4 RID: 10420 RVA: 0x000F88D8 File Offset: 0x000F6AD8
		[Token(Token = "0x60028B4")]
		[Address(RVA = "0x2C4228C", Offset = "0x2C4228C", VA = "0x2C4228C")]
		private void ڋ۸\u088Cى()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028B5 RID: 10421 RVA: 0x000F890C File Offset: 0x000F6B0C
		[Token(Token = "0x60028B5")]
		[Address(RVA = "0x2C422D8", Offset = "0x2C422D8", VA = "0x2C422D8")]
		private Quaternion \u0821Ӧيߗ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028B6 RID: 10422 RVA: 0x000F8924 File Offset: 0x000F6B24
		[Token(Token = "0x60028B6")]
		[Address(RVA = "0x2C42378", Offset = "0x2C42378", VA = "0x2C42378")]
		private void ڹӹچة()
		{
			this.ܡܣօ\u0888();
			if (this.bodyOrientation)
			{
				this.\u05AE\u070Fڈݭ();
				return;
			}
		}

		// Token: 0x060028B7 RID: 10423 RVA: 0x000F8948 File Offset: 0x000F6B48
		[Token(Token = "0x60028B7")]
		[Address(RVA = "0x2C42908", Offset = "0x2C42908", VA = "0x2C42908")]
		private float ܒ\u059Eݥ\u088D()
		{
			float num = this.proceduralAnimation.ՍӮ\u07FDٲ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x060028B8 RID: 10424 RVA: 0x000F8970 File Offset: 0x000F6B70
		[Token(Token = "0x60028B8")]
		[Address(RVA = "0x2C42940", Offset = "0x2C42940", VA = "0x2C42940")]
		private void \u05F8ټ\u06E1\u05CF()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028B9 RID: 10425 RVA: 0x000F89A4 File Offset: 0x000F6BA4
		[Token(Token = "0x60028B9")]
		[Address(RVA = "0x2C4298C", Offset = "0x2C4298C", VA = "0x2C4298C")]
		private float \u05B0\u05A4ࠐߙ()
		{
			float num = this.proceduralAnimation.ՍӮ\u07FDٲ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x060028BA RID: 10426 RVA: 0x000F89CC File Offset: 0x000F6BCC
		[Token(Token = "0x60028BA")]
		[Address(RVA = "0x2C429C4", Offset = "0x2C429C4", VA = "0x2C429C4")]
		private void Ձߎࢺ\u060D()
		{
			this.ۏԱ\u0888ࡨ();
			if (this.bodyOrientation)
			{
				this.\u06D7\u085CԳӵ();
				return;
			}
		}

		// Token: 0x060028BB RID: 10427 RVA: 0x000F89F0 File Offset: 0x000F6BF0
		[Token(Token = "0x60028BB")]
		[Address(RVA = "0x2C42F50", Offset = "0x2C42F50", VA = "0x2C42F50")]
		private void ںڡӮޛ()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.ࠕڨ\u0741\u05B6();
				float num5 = this.height;
				float num6 = this.\u05B7\u0838Դڬ();
				Vector3 vector2 = this.ڰӌ\u0879\u0656();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.\u085E\u065Fֈ\u0823();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060028BC RID: 10428 RVA: 0x000F8B10 File Offset: 0x000F6D10
		[Token(Token = "0x60028BC")]
		[Address(RVA = "0x2C433B0", Offset = "0x2C433B0", VA = "0x2C433B0")]
		private Vector3 ٮࢫ\u061Eԉ()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x060028BD RID: 10429 RVA: 0x000F8B4C File Offset: 0x000F6D4C
		[Token(Token = "0x60028BD")]
		[Address(RVA = "0x2C43460", Offset = "0x2C43460", VA = "0x2C43460")]
		private void \u0835ߙ\u0711Ԣ()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028BE RID: 10430 RVA: 0x000F8B80 File Offset: 0x000F6D80
		[Token(Token = "0x60028BE")]
		[Address(RVA = "0x2C429FC", Offset = "0x2C429FC", VA = "0x2C429FC")]
		private void ۏԱ\u0888ࡨ()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.ࢦ\u083A\u086C\u0834();
				float num5 = this.height;
				float num6 = this.\u05B0\u05A4ࠐߙ();
				Vector3 vector2 = this.סӌ\u0659\u05F7();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.ҽ\u088Cޠ߃();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060028BF RID: 10431 RVA: 0x000F8CA0 File Offset: 0x000F6EA0
		[Token(Token = "0x60028BF")]
		[Address(RVA = "0x2C43628", Offset = "0x2C43628", VA = "0x2C43628")]
		private void \u0833إ\u06DEת()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028C0 RID: 10432 RVA: 0x000F8CD4 File Offset: 0x000F6ED4
		[Token(Token = "0x60028C0")]
		[Address(RVA = "0x2C43674", Offset = "0x2C43674", VA = "0x2C43674")]
		private float ࢭ\u0701ڔع()
		{
			float num = this.proceduralAnimation.ݗܝ\u0879ڒ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x060028C1 RID: 10433 RVA: 0x000F8CFC File Offset: 0x000F6EFC
		[Token(Token = "0x60028C1")]
		[Address(RVA = "0x2C436AC", Offset = "0x2C436AC", VA = "0x2C436AC")]
		private void Awake()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028C2 RID: 10434 RVA: 0x000F8D30 File Offset: 0x000F6F30
		[Token(Token = "0x60028C2")]
		[Address(RVA = "0x2C436F8", Offset = "0x2C436F8", VA = "0x2C436F8")]
		private void \u060F\u055D\u06D8ӯ()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028C3 RID: 10435 RVA: 0x000F8D64 File Offset: 0x000F6F64
		[Token(Token = "0x60028C3")]
		[Address(RVA = "0x2C43744", Offset = "0x2C43744", VA = "0x2C43744")]
		private void ؤ\u05FF\u0737մ()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x060028C4 RID: 10436 RVA: 0x000F8DDC File Offset: 0x000F6FDC
		[Token(Token = "0x60028C4")]
		[Address(RVA = "0x2C42C98", Offset = "0x2C42C98", VA = "0x2C42C98")]
		private void \u06D7\u085CԳӵ()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x060028C5 RID: 10437 RVA: 0x000F8EAC File Offset: 0x000F70AC
		[Token(Token = "0x60028C5")]
		[Address(RVA = "0x2C43958", Offset = "0x2C43958", VA = "0x2C43958")]
		private Quaternion \u089Fݍ\u07FB٩(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028C6 RID: 10438 RVA: 0x000F8EC4 File Offset: 0x000F70C4
		[Token(Token = "0x60028C6")]
		[Address(RVA = "0x2C439F8", Offset = "0x2C439F8", VA = "0x2C439F8")]
		private void Ԁ\u05EB\u085Eՠ()
		{
			this.ش\u0835ډࡏ();
			if (this.bodyOrientation)
			{
				this.\u0820ݜԧޅ();
				return;
			}
		}

		// Token: 0x060028C7 RID: 10439 RVA: 0x000F8EE8 File Offset: 0x000F70E8
		[Token(Token = "0x60028C7")]
		[Address(RVA = "0x2C43F74", Offset = "0x2C43F74", VA = "0x2C43F74")]
		private void ߦۏ\u05A4ߋ()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x060028C8 RID: 10440 RVA: 0x000F8FB8 File Offset: 0x000F71B8
		[Token(Token = "0x60028C8")]
		[Address(RVA = "0x2C4422C", Offset = "0x2C4422C", VA = "0x2C4422C")]
		private void זך\u0652Ձ()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x060028C9 RID: 10441 RVA: 0x000F9030 File Offset: 0x000F7230
		[Token(Token = "0x60028C9")]
		[Address(RVA = "0x2C443A0", Offset = "0x2C443A0", VA = "0x2C443A0")]
		private float ԝ\u05ED\u05FEݵ()
		{
			float num = this.proceduralAnimation.ՍӮ\u07FDٲ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x060028CA RID: 10442 RVA: 0x000F9058 File Offset: 0x000F7258
		[Token(Token = "0x60028CA")]
		[Address(RVA = "0x2C4264C", Offset = "0x2C4264C", VA = "0x2C4264C")]
		private void \u05AE\u070Fڈݭ()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x060028CB RID: 10443 RVA: 0x000F9124 File Offset: 0x000F7324
		[Token(Token = "0x60028CB")]
		[Address(RVA = "0x2C44478", Offset = "0x2C44478", VA = "0x2C44478")]
		private void \u0612\u060A\u065Aװ()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x060028CC RID: 10444 RVA: 0x000F91F0 File Offset: 0x000F73F0
		[Token(Token = "0x60028CC")]
		[Address(RVA = "0x2C447C0", Offset = "0x2C447C0", VA = "0x2C447C0")]
		private Quaternion պؽێ\u060F(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028CD RID: 10445 RVA: 0x000F9208 File Offset: 0x000F7408
		[Token(Token = "0x60028CD")]
		[Address(RVA = "0x2C44860", Offset = "0x2C44860", VA = "0x2C44860")]
		private void ڗ߆\u0653\u06E5()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.\u05CC\u0821ג\u0559();
				float num5 = this.height;
				float num6 = this.ԓࢬڋ\u083F();
				Vector3 vector2 = this.\u0891ܖժێ();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.ߍݐحڍ();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060028CE RID: 10446 RVA: 0x000F9328 File Offset: 0x000F7528
		[Token(Token = "0x60028CE")]
		[Address(RVA = "0x2C44C10", Offset = "0x2C44C10", VA = "0x2C44C10")]
		private void \u0733ߡ\u0894Ԅ()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.ݷ\u0886\u0817ڜ();
				float num5 = this.height;
				float num6 = this.\u085E\u065Fֈ\u0823();
				Vector3 vector2 = this.ݷ\u0886\u0817ڜ();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.\u05B7\u0838Դڬ();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060028CF RID: 10447 RVA: 0x000F9448 File Offset: 0x000F7648
		[Token(Token = "0x60028CF")]
		[Address(RVA = "0x2C44F4C", Offset = "0x2C44F4C", VA = "0x2C44F4C")]
		private Vector3 ײࢧց\u0617()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x060028D0 RID: 10448 RVA: 0x000F9484 File Offset: 0x000F7684
		[Token(Token = "0x60028D0")]
		[Address(RVA = "0x2C44FFC", Offset = "0x2C44FFC", VA = "0x2C44FFC")]
		private void խ\u065E\u05AE\u066A()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.\u05CC\u0821ג\u0559();
				float num5 = this.height;
				float num6 = this.\u05B0\u05A4ࠐߙ();
				Vector3 vector2 = this.\u05CC\u0821ג\u0559();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.\u058Fݬ\u070A\u05AB();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060028D1 RID: 10449 RVA: 0x000F95A4 File Offset: 0x000F77A4
		[Token(Token = "0x60028D1")]
		[Address(RVA = "0x2C452D0", Offset = "0x2C452D0", VA = "0x2C452D0")]
		private void ࠐߪތԜ()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x060028D2 RID: 10450 RVA: 0x000F95CC File Offset: 0x000F77CC
		[Token(Token = "0x60028D2")]
		[Address(RVA = "0x2C438B8", Offset = "0x2C438B8", VA = "0x2C438B8")]
		private Quaternion ۊټӀԥ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028D3 RID: 10451 RVA: 0x000F95E4 File Offset: 0x000F77E4
		[Token(Token = "0x60028D3")]
		[Address(RVA = "0x2C4531C", Offset = "0x2C4531C", VA = "0x2C4531C")]
		private Vector3 \u0614ࢠ\u07BF\u073B()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x060028D4 RID: 10452 RVA: 0x000F9620 File Offset: 0x000F7820
		[Token(Token = "0x60028D4")]
		[Address(RVA = "0x2C453CC", Offset = "0x2C453CC", VA = "0x2C453CC")]
		private void ծփԎ\u058C()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x060028D5 RID: 10453 RVA: 0x000F96EC File Offset: 0x000F78EC
		[Token(Token = "0x60028D5")]
		[Address(RVA = "0x2C45714", Offset = "0x2C45714", VA = "0x2C45714")]
		private void ݤۅࢦӃ()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x060028D6 RID: 10454 RVA: 0x000F9714 File Offset: 0x000F7914
		[Token(Token = "0x60028D6")]
		[Address(RVA = "0x2C45760", Offset = "0x2C45760", VA = "0x2C45760")]
		private void \u055E\u0703\u0700ܠ()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x060028D7 RID: 10455 RVA: 0x000F973C File Offset: 0x000F793C
		[Token(Token = "0x60028D7")]
		[Address(RVA = "0x2C457AC", Offset = "0x2C457AC", VA = "0x2C457AC")]
		private float ےݑ\u0894۳()
		{
			float num = this.proceduralAnimation.ݗܝ\u0879ڒ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x060028D8 RID: 10456 RVA: 0x000F9764 File Offset: 0x000F7964
		[Token(Token = "0x60028D8")]
		[Address(RVA = "0x2C457E4", Offset = "0x2C457E4", VA = "0x2C457E4")]
		private void \u0740ݏڊ۲()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028D9 RID: 10457 RVA: 0x000F9798 File Offset: 0x000F7998
		[Token(Token = "0x60028D9")]
		[Address(RVA = "0x2C45830", Offset = "0x2C45830", VA = "0x2C45830")]
		private void \u0708\u082Cܒ٩()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060028DA RID: 10458 RVA: 0x000F9804 File Offset: 0x000F7A04
		[Token(Token = "0x60028DA")]
		[Address(RVA = "0x2C45ACC", Offset = "0x2C45ACC", VA = "0x2C45ACC")]
		private void OnDrawGizmosSelected()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x060028DB RID: 10459 RVA: 0x000F987C File Offset: 0x000F7A7C
		[Token(Token = "0x60028DB")]
		[Address(RVA = "0x2C45C40", Offset = "0x2C45C40", VA = "0x2C45C40")]
		private void \u0835ٷڋߏ()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028DC RID: 10460 RVA: 0x000F98B0 File Offset: 0x000F7AB0
		[Token(Token = "0x60028DC")]
		[Address(RVA = "0x2C45C8C", Offset = "0x2C45C8C", VA = "0x2C45C8C")]
		private void ծߧߕ\u0605()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028DD RID: 10461 RVA: 0x000F98E4 File Offset: 0x000F7AE4
		[Token(Token = "0x60028DD")]
		[Address(RVA = "0x2C45CD8", Offset = "0x2C45CD8", VA = "0x2C45CD8")]
		private void \u05C7Ӱ\u0743\u0832()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x060028DE RID: 10462 RVA: 0x000F99B0 File Offset: 0x000F7BB0
		[Token(Token = "0x60028DE")]
		[Address(RVA = "0x2C45F84", Offset = "0x2C45F84", VA = "0x2C45F84")]
		private void ܕ\u0595\u07AEࠋ()
		{
			this.ܡܣօ\u0888();
			if (this.bodyOrientation)
			{
				this.ծփԎ\u058C();
				return;
			}
		}

		// Token: 0x060028DF RID: 10463 RVA: 0x000F99D4 File Offset: 0x000F7BD4
		[Token(Token = "0x60028DF")]
		[Address(RVA = "0x2C45FBC", Offset = "0x2C45FBC", VA = "0x2C45FBC")]
		private void \u0859ۈ٣\u07BD()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028E0 RID: 10464 RVA: 0x000F9A08 File Offset: 0x000F7C08
		[Token(Token = "0x60028E0")]
		[Address(RVA = "0x2C46008", Offset = "0x2C46008", VA = "0x2C46008")]
		private void \u05AF\u0602\u0606ࡧ()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x060028E1 RID: 10465 RVA: 0x000F9AD4 File Offset: 0x000F7CD4
		[Token(Token = "0x60028E1")]
		[Address(RVA = "0x2C46364", Offset = "0x2C46364", VA = "0x2C46364")]
		private void ٿݣڿߨ()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.ٮࢫ\u061Eԉ();
				float num5 = this.height;
				float num6 = this.\u085E\u065Fֈ\u0823();
				Vector3 vector2 = this.մӔٳࠈ();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.\u05B0\u05A4ࠐߙ();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060028E2 RID: 10466 RVA: 0x000F9BF4 File Offset: 0x000F7DF4
		[Token(Token = "0x60028E2")]
		[Address(RVA = "0x2C466A4", Offset = "0x2C466A4", VA = "0x2C466A4")]
		private Vector3 ܝ\u088B\u0605\u0876()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x060028E3 RID: 10467 RVA: 0x000F9C2C File Offset: 0x000F7E2C
		[Token(Token = "0x60028E3")]
		[Address(RVA = "0x2C46754", Offset = "0x2C46754", VA = "0x2C46754")]
		private Quaternion ށށܢ\u05A5(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028E4 RID: 10468 RVA: 0x000F9C44 File Offset: 0x000F7E44
		[Token(Token = "0x60028E4")]
		[Address(RVA = "0x2C467F4", Offset = "0x2C467F4", VA = "0x2C467F4")]
		private void \u07EEقࡊؤ()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x060028E5 RID: 10469 RVA: 0x000F9CBC File Offset: 0x000F7EBC
		[Token(Token = "0x60028E5")]
		[Address(RVA = "0x2C46968", Offset = "0x2C46968", VA = "0x2C46968")]
		private void ݔ߄ޱۓ()
		{
			this.ڪժ\u0826ת();
			if (this.bodyOrientation)
			{
				this.\u06D7\u085CԳӵ();
				return;
			}
		}

		// Token: 0x060028E6 RID: 10470 RVA: 0x000F9CE0 File Offset: 0x000F7EE0
		[Token(Token = "0x60028E6")]
		[Address(RVA = "0x2C435F0", Offset = "0x2C435F0", VA = "0x2C435F0")]
		private float ҽ\u088Cޠ߃()
		{
			float num = this.proceduralAnimation.\u05F4מ\u061Fݶ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x060028E7 RID: 10471 RVA: 0x000F9D08 File Offset: 0x000F7F08
		[Token(Token = "0x60028E7")]
		[Address(RVA = "0x2C46C3C", Offset = "0x2C46C3C", VA = "0x2C46C3C")]
		private void \u0617\u0836ײԩ()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028E8 RID: 10472 RVA: 0x000F9D3C File Offset: 0x000F7F3C
		[Token(Token = "0x60028E8")]
		[Address(RVA = "0x2C44AFC", Offset = "0x2C44AFC", VA = "0x2C44AFC")]
		private float ԓࢬڋ\u083F()
		{
			float num = this.proceduralAnimation.ՍӮ\u07FDٲ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x060028E9 RID: 10473 RVA: 0x000F9D64 File Offset: 0x000F7F64
		[Token(Token = "0x60028E9")]
		[Address(RVA = "0x2C46C88", Offset = "0x2C46C88", VA = "0x2C46C88")]
		private void \u05BAޑࢲע()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x060028EA RID: 10474 RVA: 0x000F9DDC File Offset: 0x000F7FDC
		[Token(Token = "0x60028EA")]
		[Address(RVA = "0x2C46DFC", Offset = "0x2C46DFC", VA = "0x2C46DFC")]
		private void ࢨӟۼӱ()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x060028EB RID: 10475 RVA: 0x000F9EAC File Offset: 0x000F80AC
		[Token(Token = "0x60028EB")]
		[Address(RVA = "0x2C47148", Offset = "0x2C47148", VA = "0x2C47148")]
		private void ࡎ\u05C2սࠇ()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x060028EC RID: 10476 RVA: 0x000F9ED4 File Offset: 0x000F80D4
		[Token(Token = "0x60028EC")]
		[Address(RVA = "0x2C43378", Offset = "0x2C43378", VA = "0x2C43378")]
		private float \u085E\u065Fֈ\u0823()
		{
			float num = this.proceduralAnimation.ՍӮ\u07FDٲ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x060028ED RID: 10477 RVA: 0x000F9EFC File Offset: 0x000F80FC
		[Token(Token = "0x60028ED")]
		[Address(RVA = "0x2C47194", Offset = "0x2C47194", VA = "0x2C47194")]
		private void ޠۋ\u0530\u073E()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x060028EE RID: 10478 RVA: 0x000F9F24 File Offset: 0x000F8124
		[Token(Token = "0x60028EE")]
		[Address(RVA = "0x2C471E0", Offset = "0x2C471E0", VA = "0x2C471E0")]
		private void ڐࢬ\u0617\u0882()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x060028EF RID: 10479 RVA: 0x000F9F9C File Offset: 0x000F819C
		[Token(Token = "0x60028EF")]
		[Address(RVA = "0x2C47354", Offset = "0x2C47354", VA = "0x2C47354")]
		private void ߟߥࡉپ()
		{
			this.խ\u065E\u05AE\u066A();
			if (this.bodyOrientation)
			{
				this.\u0594\u0705Ҽܜ();
				return;
			}
		}

		// Token: 0x060028F0 RID: 10480 RVA: 0x000F9FC0 File Offset: 0x000F81C0
		[Token(Token = "0x60028F0")]
		[Address(RVA = "0x2C45298", Offset = "0x2C45298", VA = "0x2C45298")]
		private float \u058Fݬ\u070A\u05AB()
		{
			float num = this.proceduralAnimation.\u05F4מ\u061Fݶ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x060028F1 RID: 10481 RVA: 0x000F9FE8 File Offset: 0x000F81E8
		[Token(Token = "0x60028F1")]
		[Address(RVA = "0x2C469A0", Offset = "0x2C469A0", VA = "0x2C469A0")]
		private void ڪժ\u0826ת()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.\u061F\u059DӼ\u085A();
				float num5 = this.height;
				float num6 = this.ےݑ\u0894۳();
				Vector3 vector2 = this.סӌ\u0659\u05F7();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.\u058Fݬ\u070A\u05AB();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060028F2 RID: 10482 RVA: 0x000FA108 File Offset: 0x000F8308
		[Token(Token = "0x60028F2")]
		[Address(RVA = "0x2C476D4", Offset = "0x2C476D4", VA = "0x2C476D4")]
		private void \u086Bԍࡊڭ()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x060028F3 RID: 10483 RVA: 0x000FA130 File Offset: 0x000F8330
		[Token(Token = "0x60028F3")]
		[Address(RVA = "0x2C47720", Offset = "0x2C47720", VA = "0x2C47720")]
		private void Ԅڮո\u081F()
		{
			this.ٿݣڿߨ();
			if (this.bodyOrientation)
			{
				this.ҿӗۏࢲ();
				return;
			}
		}

		// Token: 0x060028F4 RID: 10484 RVA: 0x000FA154 File Offset: 0x000F8354
		[Token(Token = "0x60028F4")]
		[Address(RVA = "0x2C47A14", Offset = "0x2C47A14", VA = "0x2C47A14")]
		private Quaternion \u0872\u0873\u088Cܩ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028F5 RID: 10485 RVA: 0x000FA16C File Offset: 0x000F836C
		[Token(Token = "0x60028F5")]
		[Address(RVA = "0x2C47AB4", Offset = "0x2C47AB4", VA = "0x2C47AB4")]
		private void Ӊ\u088D\u066B\u06EB()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.ռӡܖԏ();
				float num5 = this.height;
				float num6 = this.\u058Fݬ\u070A\u05AB();
				Vector3 vector2 = this.ࠕڨ\u0741\u05B6();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.\u05B7\u0838Դڬ();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060028F6 RID: 10486 RVA: 0x000FA28C File Offset: 0x000F848C
		[Token(Token = "0x60028F6")]
		[Address(RVA = "0x2C47D50", Offset = "0x2C47D50", VA = "0x2C47D50")]
		private void ࢯٮܤ\u061F()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060028F7 RID: 10487 RVA: 0x000FA2C0 File Offset: 0x000F84C0
		[Token(Token = "0x60028F7")]
		[Address(RVA = "0x2C43290", Offset = "0x2C43290", VA = "0x2C43290")]
		private float \u05B7\u0838Դڬ()
		{
			float num = this.proceduralAnimation.ՍӮ\u07FDٲ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x060028F8 RID: 10488 RVA: 0x000FA2E8 File Offset: 0x000F84E8
		[Token(Token = "0x60028F8")]
		[Address(RVA = "0x2C47D9C", Offset = "0x2C47D9C", VA = "0x2C47D9C")]
		private void \u05C8\u05BFࠁف()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x060028F9 RID: 10489 RVA: 0x000FA310 File Offset: 0x000F8510
		[Token(Token = "0x60028F9")]
		[Address(RVA = "0x2C47DE8", Offset = "0x2C47DE8", VA = "0x2C47DE8")]
		private void וࡪךӧ()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x060028FA RID: 10490 RVA: 0x000FA338 File Offset: 0x000F8538
		[Token(Token = "0x60028FA")]
		[Address(RVA = "0x2C47E34", Offset = "0x2C47E34", VA = "0x2C47E34")]
		private Quaternion \u07EB\u0891ٳߢ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028FB RID: 10491 RVA: 0x000FA350 File Offset: 0x000F8550
		[Token(Token = "0x60028FB")]
		[Address(RVA = "0x2C45678", Offset = "0x2C45678", VA = "0x2C45678")]
		private Quaternion ߃\u058Cۊ\u0899(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028FC RID: 10492 RVA: 0x000FA368 File Offset: 0x000F8568
		[Token(Token = "0x60028FC")]
		[Address(RVA = "0x2C47ED4", Offset = "0x2C47ED4", VA = "0x2C47ED4")]
		private void \u081Dܢࡓ\u06E9()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x060028FD RID: 10493 RVA: 0x000FA3E0 File Offset: 0x000F85E0
		[Token(Token = "0x60028FD")]
		[Address(RVA = "0x2C48048", Offset = "0x2C48048", VA = "0x2C48048")]
		private void ӅӁܞ\u089C()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.մӔٳࠈ();
				float num5 = this.height;
				float num6 = this.\u085E\u065Fֈ\u0823();
				Vector3 vector2 = this.\u061F\u059DӼ\u085A();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.\u058Fݬ\u070A\u05AB();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060028FE RID: 10494 RVA: 0x000FA500 File Offset: 0x000F8700
		[Token(Token = "0x60028FE")]
		[Address(RVA = "0x2C44720", Offset = "0x2C44720", VA = "0x2C44720")]
		private Quaternion ࡤڳچ\u061D(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060028FF RID: 10495 RVA: 0x000FA518 File Offset: 0x000F8718
		[Token(Token = "0x60028FF")]
		[Address(RVA = "0x2C431EC", Offset = "0x2C431EC", VA = "0x2C431EC")]
		private Vector3 ࠕڨ\u0741\u05B6()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x06002900 RID: 10496 RVA: 0x000FA550 File Offset: 0x000F8750
		[Token(Token = "0x6002900")]
		[Address(RVA = "0x2C482E4", Offset = "0x2C482E4", VA = "0x2C482E4")]
		private void Start()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x06002901 RID: 10497 RVA: 0x000FA578 File Offset: 0x000F8778
		[Token(Token = "0x6002901")]
		[Address(RVA = "0x2C48330", Offset = "0x2C48330", VA = "0x2C48330")]
		private void Ҿ\u065EՀݜ()
		{
			this.\u0733ߡ\u0894Ԅ();
			if (this.bodyOrientation)
			{
				this.\u0594\u0705Ҽܜ();
				return;
			}
		}

		// Token: 0x06002902 RID: 10498 RVA: 0x000FA59C File Offset: 0x000F879C
		[Token(Token = "0x6002902")]
		[Address(RVA = "0x2C48368", Offset = "0x2C48368", VA = "0x2C48368")]
		private void ض\u064Fޢշ()
		{
			this.\u0828ܚߪߐ();
			if (this.bodyOrientation)
			{
				this.\u0594\u0705Ҽܜ();
				return;
			}
		}

		// Token: 0x06002903 RID: 10499 RVA: 0x000FA5C0 File Offset: 0x000F87C0
		[Token(Token = "0x6002903")]
		[Address(RVA = "0x2C423B0", Offset = "0x2C423B0", VA = "0x2C423B0")]
		private void ܡܣօ\u0888()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.ܦ\u087A\u0881ݐ();
				float num5 = this.height;
				float num6 = this.ڐ\u087A\u05BFޘ();
				Vector3 vector2 = this.\u05CC\u0821ג\u0559();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.ו\u06D9ٻ\u082E();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x06002904 RID: 10500 RVA: 0x000FA6E0 File Offset: 0x000F88E0
		[Token(Token = "0x6002904")]
		[Address(RVA = "0x2C4875C", Offset = "0x2C4875C", VA = "0x2C4875C")]
		private void \u05C1ԵԩԱ()
		{
			this.\u0828ܚߪߐ();
			if (this.bodyOrientation)
			{
				this.\u06D7\u085CԳӵ();
				return;
			}
		}

		// Token: 0x06002905 RID: 10501 RVA: 0x000FA704 File Offset: 0x000F8904
		[Token(Token = "0x6002905")]
		[Address(RVA = "0x2C48794", Offset = "0x2C48794", VA = "0x2C48794")]
		private void ܘ\u0655ࢦ\u0823()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.ռӡܖԏ();
				float num5 = this.height;
				Vector3 vector2 = this.ࢦ\u083A\u086C\u0834();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num6 = this.height;
			float num7 = this.\u058Fݬ\u070A\u05AB();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num8 = this.bodySpeed;
			float num9 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x06002906 RID: 10502 RVA: 0x000FA81C File Offset: 0x000F8A1C
		[Token(Token = "0x6002906")]
		[Address(RVA = "0x2C434AC", Offset = "0x2C434AC", VA = "0x2C434AC")]
		private Vector3 ࢦ\u083A\u086C\u0834()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x06002907 RID: 10503 RVA: 0x000FA854 File Offset: 0x000F8A54
		[Token(Token = "0x6002907")]
		[Address(RVA = "0x2C47758", Offset = "0x2C47758", VA = "0x2C47758")]
		private void ҿӗۏࢲ()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x06002908 RID: 10504 RVA: 0x000FA920 File Offset: 0x000F8B20
		[Token(Token = "0x6002908")]
		[Address(RVA = "0x2C48A30", Offset = "0x2C48A30", VA = "0x2C48A30")]
		private void ࡏ\u061Aէߒ()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x06002909 RID: 10505 RVA: 0x000FA998 File Offset: 0x000F8B98
		[Token(Token = "0x6002909")]
		[Address(RVA = "0x2C48BA4", Offset = "0x2C48BA4", VA = "0x2C48BA4")]
		private void ٤\u0888ࡦ\u0702()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x0600290A RID: 10506 RVA: 0x000FA9CC File Offset: 0x000F8BCC
		[Token(Token = "0x600290A")]
		[Address(RVA = "0x2C48BF0", Offset = "0x2C48BF0", VA = "0x2C48BF0")]
		private Quaternion \u0654\u0743\u089Bސ(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600290B RID: 10507 RVA: 0x000FA9E4 File Offset: 0x000F8BE4
		[Token(Token = "0x600290B")]
		[Address(RVA = "0x2C48C90", Offset = "0x2C48C90", VA = "0x2C48C90")]
		private void գӦثӳ()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.\u0614ࢠ\u07BF\u073B();
				float num5 = this.height;
				float num6 = this.ԓࢬڋ\u083F();
				Vector3 vector2 = this.ࠕڨ\u0741\u05B6();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.ו\u06D9ٻ\u082E();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x0600290C RID: 10508 RVA: 0x000FAB04 File Offset: 0x000F8D04
		[Token(Token = "0x600290C")]
		[Address(RVA = "0x2C48724", Offset = "0x2C48724", VA = "0x2C48724")]
		private float ו\u06D9ٻ\u082E()
		{
			float num = this.proceduralAnimation.\u05F4מ\u061Fݶ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x0600290D RID: 10509 RVA: 0x000FAB2C File Offset: 0x000F8D2C
		[Token(Token = "0x600290D")]
		[Address(RVA = "0x2C48F2C", Offset = "0x2C48F2C", VA = "0x2C48F2C")]
		private void LateUpdate()
		{
			this.ࡆ\u05A0\u06FE\u0745();
			if (this.bodyOrientation)
			{
				this.ࢨӟۼӱ();
				return;
			}
		}

		// Token: 0x0600290E RID: 10510 RVA: 0x000FAB50 File Offset: 0x000F8D50
		[Token(Token = "0x600290E")]
		[Address(RVA = "0x2C49200", Offset = "0x2C49200", VA = "0x2C49200")]
		private void \u0891Ԓچࢥ()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x0600290F RID: 10511 RVA: 0x000FAB84 File Offset: 0x000F8D84
		[Token(Token = "0x600290F")]
		[Address(RVA = "0x2C43CCC", Offset = "0x2C43CCC", VA = "0x2C43CCC")]
		private void \u0820ݜԧޅ()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x06002910 RID: 10512 RVA: 0x000FAC50 File Offset: 0x000F8E50
		[Token(Token = "0x6002910")]
		[Address(RVA = "0x2C4924C", Offset = "0x2C4924C", VA = "0x2C4924C")]
		private void ݾߥࠍ߄()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x06002911 RID: 10513 RVA: 0x000FACC8 File Offset: 0x000F8EC8
		[Token(Token = "0x6002911")]
		[Address(RVA = "0x2C4863C", Offset = "0x2C4863C", VA = "0x2C4863C")]
		private Vector3 ܦ\u087A\u0881ݐ()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x06002912 RID: 10514 RVA: 0x000FAD04 File Offset: 0x000F8F04
		[Token(Token = "0x6002912")]
		[Address(RVA = "0x2C432C8", Offset = "0x2C432C8", VA = "0x2C432C8")]
		private Vector3 ڰӌ\u0879\u0656()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x06002913 RID: 10515 RVA: 0x000FAD3C File Offset: 0x000F8F3C
		[Token(Token = "0x6002913")]
		[Address(RVA = "0x2C44B34", Offset = "0x2C44B34", VA = "0x2C44B34")]
		private Vector3 \u0891ܖժێ()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x06002914 RID: 10516 RVA: 0x000FAD74 File Offset: 0x000F8F74
		[Token(Token = "0x6002914")]
		[Address(RVA = "0x2C4354C", Offset = "0x2C4354C", VA = "0x2C4354C")]
		private Vector3 סӌ\u0659\u05F7()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x06002915 RID: 10517 RVA: 0x000FADAC File Offset: 0x000F8FAC
		[Token(Token = "0x6002915")]
		[Address(RVA = "0x2C493C0", Offset = "0x2C493C0", VA = "0x2C493C0")]
		private void Ԓ\u07ED\u0657ࢶ()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.ٮࢫ\u061Eԉ();
				float num5 = this.height;
				float num6 = this.ԓࢬڋ\u083F();
				Vector3 vector2 = this.ռӡܖԏ();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.\u05B0\u05A4ࠐߙ();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x06002916 RID: 10518 RVA: 0x000FAECC File Offset: 0x000F90CC
		[Token(Token = "0x6002916")]
		[Address(RVA = "0x2C462C4", Offset = "0x2C462C4", VA = "0x2C462C4")]
		private Quaternion \u089B\u0617\u055E\u0889(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002917 RID: 10519 RVA: 0x000FAEE4 File Offset: 0x000F90E4
		[Token(Token = "0x6002917")]
		[Address(RVA = "0x2C4738C", Offset = "0x2C4738C", VA = "0x2C4738C")]
		private void \u0594\u0705Ҽܜ()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x06002918 RID: 10520 RVA: 0x000FAFB0 File Offset: 0x000F91B0
		[Token(Token = "0x6002918")]
		[Address(RVA = "0x2C46600", Offset = "0x2C46600", VA = "0x2C46600")]
		private Vector3 մӔٳࠈ()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x06002919 RID: 10521 RVA: 0x000FAFE8 File Offset: 0x000F91E8
		[Token(Token = "0x6002919")]
		[Address(RVA = "0x2C4965C", Offset = "0x2C4965C", VA = "0x2C4965C")]
		private void ١ۏ\u05C4ӝ()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x0600291A RID: 10522 RVA: 0x000FB010 File Offset: 0x000F9210
		[Token(Token = "0x600291A")]
		[Address(RVA = "0x2C496A8", Offset = "0x2C496A8", VA = "0x2C496A8")]
		private void ۊո\u0612\u0595()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x0600291B RID: 10523 RVA: 0x000FB038 File Offset: 0x000F9238
		[Token(Token = "0x600291B")]
		[Address(RVA = "0x2C44EAC", Offset = "0x2C44EAC", VA = "0x2C44EAC")]
		private Vector3 ݷ\u0886\u0817ڜ()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x0600291C RID: 10524 RVA: 0x000FB070 File Offset: 0x000F9270
		[Token(Token = "0x600291C")]
		[Address(RVA = "0x2C496F4", Offset = "0x2C496F4", VA = "0x2C496F4")]
		private void Պ۸\u0886ࠂ()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x0600291D RID: 10525 RVA: 0x000FB0E8 File Offset: 0x000F92E8
		[Token(Token = "0x600291D")]
		[Address(RVA = "0x2C43A30", Offset = "0x2C43A30", VA = "0x2C43A30")]
		private void ش\u0835ډࡏ()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.סӌ\u0659\u05F7();
				float num5 = this.height;
				float num6 = this.\u05B7\u0838Դڬ();
				Vector3 vector2 = this.\u05CC\u0821ג\u0559();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.ԓࢬڋ\u083F();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x0600291E RID: 10526 RVA: 0x000FB208 File Offset: 0x000F9408
		[Token(Token = "0x600291E")]
		[Address(RVA = "0x2C49868", Offset = "0x2C49868", VA = "0x2C49868")]
		private void \u0731ݐ\u0654ࡡ()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.\u058E\u05F9ࡔࢲ = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x0600291F RID: 10527 RVA: 0x000FB23C File Offset: 0x000F943C
		[Token(Token = "0x600291F")]
		[Address(RVA = "0x2C483A0", Offset = "0x2C483A0", VA = "0x2C483A0")]
		private void \u0828ܚߪߐ()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.ࢦ\u083A\u086C\u0834();
				float num5 = this.height;
				float num6 = this.ڐ\u087A\u05BFޘ();
				Vector3 vector2 = this.ࢦ\u083A\u086C\u0834();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.\u085E\u065Fֈ\u0823();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x06002920 RID: 10528 RVA: 0x000FB35C File Offset: 0x000F955C
		[Token(Token = "0x6002920")]
		[Address(RVA = "0x2C498B4", Offset = "0x2C498B4", VA = "0x2C498B4")]
		private void Ӈ\u07F7ӻ\u064C()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x06002921 RID: 10529 RVA: 0x000FB3D4 File Offset: 0x000F95D4
		[Token(Token = "0x6002921")]
		[Address(RVA = "0x2C49A28", Offset = "0x2C49A28", VA = "0x2C49A28")]
		private void \u088Bߑ\u087Eت()
		{
			this.\u0708\u082Cܒ٩();
			if (this.bodyOrientation)
			{
				this.\u0612\u060A\u065Aװ();
				return;
			}
		}

		// Token: 0x06002922 RID: 10530 RVA: 0x000FB3F8 File Offset: 0x000F95F8
		[Token(Token = "0x6002922")]
		[Address(RVA = "0x2C49A60", Offset = "0x2C49A60", VA = "0x2C49A60")]
		private void \u0655٤\u0605ժ()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x06002923 RID: 10531 RVA: 0x000FB4C4 File Offset: 0x000F96C4
		[Token(Token = "0x6002923")]
		[Address(RVA = "0x2C486EC", Offset = "0x2C486EC", VA = "0x2C486EC")]
		private float ڐ\u087A\u05BFޘ()
		{
			float num = this.proceduralAnimation.ݗܝ\u0879ڒ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x06002924 RID: 10532 RVA: 0x000FB4EC File Offset: 0x000F96EC
		[Token(Token = "0x6002924")]
		[Address(RVA = "0x2C48F64", Offset = "0x2C48F64", VA = "0x2C48F64")]
		private void ࡆ\u05A0\u06FE\u0745()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.\u0614ࢠ\u07BF\u073B();
				float num5 = this.height;
				float num6 = this.ڐ\u087A\u05BFޘ();
				Vector3 vector2 = this.\u0614ࢠ\u07BF\u073B();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.ڐ\u087A\u05BFޘ();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x06002925 RID: 10533 RVA: 0x000FB60C File Offset: 0x000F980C
		[Token(Token = "0x6002925")]
		[Address(RVA = "0x2C49D0C", Offset = "0x2C49D0C", VA = "0x2C49D0C")]
		private void \u05FD\u0736\u05F9\u05BE()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				float num = this.racastOffset;
				Vector3 up2 = Vector3.up;
				float num2 = this.raycastRange;
				Color green = Color.green;
				if (typeof(Debug).TypeHandle == null)
				{
				}
				Vector3 position2 = base.transform.position;
				float num3 = this.sphereCastRadius;
				return;
			}
		}

		// Token: 0x06002926 RID: 10534 RVA: 0x000FB684 File Offset: 0x000F9884
		[Token(Token = "0x6002926")]
		[Address(RVA = "0x2C44BD8", Offset = "0x2C44BD8", VA = "0x2C44BD8")]
		private float ߍݐحڍ()
		{
			float num = this.proceduralAnimation.ՍӮ\u07FDٲ();
			float num2 = this.legsImpact;
			throw new NullReferenceException();
		}

		// Token: 0x06002927 RID: 10535 RVA: 0x000FB6AC File Offset: 0x000F98AC
		[Token(Token = "0x6002927")]
		[Address(RVA = "0x2C49E80", Offset = "0x2C49E80", VA = "0x2C49E80")]
		private void \u07BFլܛڠ()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			float num = this.sphereCastRadius;
			float num2 = this.racastOffset;
			Vector3 up2 = Vector3.up;
			LayerMask u058E_u05F9ࡔࢲ = this.\u058E\u05F9ࡔࢲ;
			float num3 = this.raycastRange;
			int num4 = u058E_u05F9ࡔࢲ;
			if (this.smartBodyPosition)
			{
				Vector3 vector = this.ײࢧց\u0617();
				float num5 = this.height;
				float num6 = this.\u085E\u065Fֈ\u0823();
				Vector3 vector2 = this.ࢦ\u083A\u086C\u0834();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			float num7 = this.height;
			float num8 = this.ࢭ\u0701ڔع();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			float x = this.bodyOffset.x;
			float y = this.bodyOffset.y;
			float z = this.bodyOffset.z;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			float num9 = this.bodySpeed;
			float num10 = Mathf.Clamp01(deltaTime);
		}

		// Token: 0x06002928 RID: 10536 RVA: 0x000FB7CC File Offset: 0x000F99CC
		[Token(Token = "0x6002928")]
		[Address(RVA = "0x2C443D8", Offset = "0x2C443D8", VA = "0x2C443D8")]
		private Quaternion \u07F0ࡢ\u065F\u06E8(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06002929 RID: 10537 RVA: 0x000FB7E4 File Offset: 0x000F99E4
		[Token(Token = "0x6002929")]
		[Address(RVA = "0x2C470B0", Offset = "0x2C470B0", VA = "0x2C470B0")]
		private Quaternion ٢ࠇڸ\u064F(Vector3 \u06E8Ԥ\u0885۸, Vector3 ٥ܪ\u085Dճ)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x0600292A RID: 10538 RVA: 0x000FB7FC File Offset: 0x000F99FC
		[Token(Token = "0x600292A")]
		[Address(RVA = "0x2C4A11C", Offset = "0x2C4A11C", VA = "0x2C4A11C")]
		public ProceduralBodyController()
		{
			long num = 1065353216L;
			this.height = (float)num;
			long num2 = 1L;
			this.bodyRotationSpeed = (float)16840;
			this.smartBodyPosition = (num2 != 0L);
			this.showGizmos = (num2 != 0L);
			this.raycastRange = (float)16576;
			base..ctor();
		}

		// Token: 0x0600292B RID: 10539 RVA: 0x000FB844 File Offset: 0x000F9A44
		[Token(Token = "0x600292B")]
		[Address(RVA = "0x2C4A15C", Offset = "0x2C4A15C", VA = "0x2C4A15C")]
		private void גۉࡈר()
		{
			Vector3 zero = Vector3.zero;
			int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			int num = this.\u058E\u05F9ࡔࢲ;
			int ӏ_u089D_u05C5ؼ2 = this.Ӏ\u089D\u05C5ؼ;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float num2 = this.bodyRotationSpeed;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.ޗ\u0748\u0816\u07F2.y = y;
		}

		// Token: 0x0600292C RID: 10540 RVA: 0x000FB914 File Offset: 0x000F9B14
		[Token(Token = "0x600292C")]
		[Address(RVA = "0x2C4A414", Offset = "0x2C4A414", VA = "0x2C4A414")]
		private void \u066D\u05BDې߃()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.ࡤ\u058Aߥޝ = legIktargets;
		}

		// Token: 0x0600292D RID: 10541 RVA: 0x000FB93C File Offset: 0x000F9B3C
		[Token(Token = "0x600292D")]
		[Address(RVA = "0x2C47634", Offset = "0x2C47634", VA = "0x2C47634")]
		private Vector3 \u061F\u059DӼ\u085A()
		{
			do
			{
				Vector3 zero = Vector3.zero;
				Transform[] ࡤ_u058Aߥޝ = this.ࡤ\u058Aߥޝ;
				int ӏ_u089D_u05C5ؼ = this.Ӏ\u089D\u05C5ؼ;
			}
			while (this.ࡤ\u058Aߥޝ != null);
			throw new NullReferenceException();
		}

		// Token: 0x0400052C RID: 1324
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400052C")]
		[SerializeField]
		private proceduralAnimation proceduralAnimation;

		// Token: 0x0400052D RID: 1325
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400052D")]
		[SerializeField]
		private Vector3 bodyOffset;

		// Token: 0x0400052E RID: 1326
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x400052E")]
		[SerializeField]
		private float bodySpeed;

		// Token: 0x0400052F RID: 1327
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400052F")]
		[SerializeField]
		[Tooltip("How much legs affect body position")]
		private float legsImpact;

		// Token: 0x04000530 RID: 1328
		[FieldOffset(Offset = "0x34")]
		[Token(Token = "0x4000530")]
		[SerializeField]
		private float height;

		// Token: 0x04000531 RID: 1329
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000531")]
		[SerializeField]
		[Tooltip("Calculates body position based on average leg positions, use body offset vector to set desired body position")]
		private bool smartBodyPosition;

		// Token: 0x04000532 RID: 1330
		[FieldOffset(Offset = "0x39")]
		[Token(Token = "0x4000532")]
		[SerializeField]
		[Tooltip("rotates body towards the ground with speed of bodyRotationSpeed")]
		private bool bodyOrientation;

		// Token: 0x04000533 RID: 1331
		[FieldOffset(Offset = "0x3C")]
		[Token(Token = "0x4000533")]
		[SerializeField]
		private float bodyRotationSpeed;

		// Token: 0x04000534 RID: 1332
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000534")]
		[SerializeField]
		[Header("Raycasts")]
		private bool showGizmos;

		// Token: 0x04000535 RID: 1333
		[FieldOffset(Offset = "0x44")]
		[Token(Token = "0x4000535")]
		[SerializeField]
		[Tooltip("body ground check range")]
		private float sphereCastRadius;

		// Token: 0x04000536 RID: 1334
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000536")]
		[SerializeField]
		private float racastOffset;

		// Token: 0x04000537 RID: 1335
		[FieldOffset(Offset = "0x4C")]
		[Token(Token = "0x4000537")]
		[SerializeField]
		private float raycastRange;

		// Token: 0x04000538 RID: 1336
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000538")]
		private LayerMask \u058E\u05F9ࡔࢲ;

		// Token: 0x04000539 RID: 1337
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000539")]
		private Transform[] ࡤ\u058Aߥޝ;

		// Token: 0x0400053A RID: 1338
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x400053A")]
		private int Ӏ\u089D\u05C5ؼ;

		// Token: 0x0400053B RID: 1339
		[FieldOffset(Offset = "0x64")]
		[Token(Token = "0x400053B")]
		private Vector3 ޗ\u0748\u0816\u07F2;
	}
}
