﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x02000101 RID: 257
	[Token(Token = "0x2000101")]
	public class follow : MonoBehaviour
	{
		// Token: 0x060027EF RID: 10223 RVA: 0x000EAA44 File Offset: 0x000E8C44
		[Token(Token = "0x60027EF")]
		[Address(RVA = "0x2AFD7C0", Offset = "0x2AFD7C0", VA = "0x2AFD7C0")]
		private void ӻӒݝ߃()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x060027F0 RID: 10224 RVA: 0x000EAC40 File Offset: 0x000E8E40
		[Token(Token = "0x60027F0")]
		[Address(RVA = "0x2AFDBEC", Offset = "0x2AFDBEC", VA = "0x2AFDBEC")]
		private void Update()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x060027F1 RID: 10225 RVA: 0x000EAE3C File Offset: 0x000E903C
		[Token(Token = "0x60027F1")]
		[Address(RVA = "0x2AFE01C", Offset = "0x2AFE01C", VA = "0x2AFE01C")]
		private void \u05F7ԝߠӱ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x060027F2 RID: 10226 RVA: 0x000EB038 File Offset: 0x000E9238
		[Token(Token = "0x60027F2")]
		[Address(RVA = "0x2AFE448", Offset = "0x2AFE448", VA = "0x2AFE448")]
		private void ۵ܐԎࠆ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x060027F3 RID: 10227 RVA: 0x000EB228 File Offset: 0x000E9428
		[Token(Token = "0x60027F3")]
		[Address(RVA = "0x2AFE87C", Offset = "0x2AFE87C", VA = "0x2AFE87C")]
		private void \u081Cߌ\u0876Բ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x060027F4 RID: 10228 RVA: 0x000EB424 File Offset: 0x000E9624
		[Token(Token = "0x60027F4")]
		[Address(RVA = "0x2AFECA4", Offset = "0x2AFECA4", VA = "0x2AFECA4")]
		private void ڏי\u06E6\u070A()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x060027F5 RID: 10229 RVA: 0x000EB620 File Offset: 0x000E9820
		[Token(Token = "0x60027F5")]
		[Address(RVA = "0x2AFF0D0", Offset = "0x2AFF0D0", VA = "0x2AFF0D0")]
		private void \u0886ܬԗ\u05C0()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x060027F6 RID: 10230 RVA: 0x000EB81C File Offset: 0x000E9A1C
		[Token(Token = "0x60027F6")]
		[Address(RVA = "0x2AFF4F8", Offset = "0x2AFF4F8", VA = "0x2AFF4F8")]
		private void \u07FE\u0882Զ\u066D()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x060027F7 RID: 10231 RVA: 0x000EBA18 File Offset: 0x000E9C18
		[Token(Token = "0x60027F7")]
		[Address(RVA = "0x2AFF924", Offset = "0x2AFF924", VA = "0x2AFF924")]
		private void Ҿ\u065EՀݜ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x060027F8 RID: 10232 RVA: 0x000EBC14 File Offset: 0x000E9E14
		[Token(Token = "0x60027F8")]
		[Address(RVA = "0x2AFFD50", Offset = "0x2AFFD50", VA = "0x2AFFD50")]
		private void FixedUpdate()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x060027F9 RID: 10233 RVA: 0x000EBE04 File Offset: 0x000EA004
		[Token(Token = "0x60027F9")]
		[Address(RVA = "0x2B00184", Offset = "0x2B00184", VA = "0x2B00184")]
		private void ࡉے\u0893ػ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x060027FA RID: 10234 RVA: 0x000EBFF4 File Offset: 0x000EA1F4
		[Token(Token = "0x60027FA")]
		[Address(RVA = "0x2B005B4", Offset = "0x2B005B4", VA = "0x2B005B4")]
		private void ֆؼࢹߖ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x060027FB RID: 10235 RVA: 0x000EC1E4 File Offset: 0x000EA3E4
		[Token(Token = "0x60027FB")]
		[Address(RVA = "0x2B009E0", Offset = "0x2B009E0", VA = "0x2B009E0")]
		private void ݔ߄ޱۓ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x060027FC RID: 10236 RVA: 0x000EC3D4 File Offset: 0x000EA5D4
		[Token(Token = "0x60027FC")]
		[Address(RVA = "0x2B00E14", Offset = "0x2B00E14", VA = "0x2B00E14")]
		private void Ղڑߧ\u07BC()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x060027FD RID: 10237 RVA: 0x000EC5CC File Offset: 0x000EA7CC
		[Token(Token = "0x60027FD")]
		[Address(RVA = "0x2B01240", Offset = "0x2B01240", VA = "0x2B01240")]
		private void ޞۊաݛ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x060027FE RID: 10238 RVA: 0x000EC7C8 File Offset: 0x000EA9C8
		[Token(Token = "0x60027FE")]
		[Address(RVA = "0x2B0166C", Offset = "0x2B0166C", VA = "0x2B0166C")]
		private void ӎ\u07F2Ֆ\u05CA()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x060027FF RID: 10239 RVA: 0x000EC9B8 File Offset: 0x000EABB8
		[Token(Token = "0x60027FF")]
		[Address(RVA = "0x2B01A98", Offset = "0x2B01A98", VA = "0x2B01A98")]
		private void ࢺ\u0599\u07A6\u0650()
		{
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002800 RID: 10240 RVA: 0x000ECBA0 File Offset: 0x000EADA0
		[Token(Token = "0x6002800")]
		[Address(RVA = "0x2B01EC8", Offset = "0x2B01EC8", VA = "0x2B01EC8")]
		private void Կשܐӵ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002801 RID: 10241 RVA: 0x000ECD90 File Offset: 0x000EAF90
		[Token(Token = "0x6002801")]
		[Address(RVA = "0x2B022F8", Offset = "0x2B022F8", VA = "0x2B022F8")]
		private void \u0877قո\u0707()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002802 RID: 10242 RVA: 0x000ECF8C File Offset: 0x000EB18C
		[Token(Token = "0x6002802")]
		[Address(RVA = "0x2B02728", Offset = "0x2B02728", VA = "0x2B02728")]
		private void \u05C5ګ٢Ԣ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002803 RID: 10243 RVA: 0x000ED17C File Offset: 0x000EB37C
		[Token(Token = "0x6002803")]
		[Address(RVA = "0x2B02B5C", Offset = "0x2B02B5C", VA = "0x2B02B5C")]
		private void ԅ\u073Fڥ\u0839()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002804 RID: 10244 RVA: 0x000ED378 File Offset: 0x000EB578
		[Token(Token = "0x6002804")]
		[Address(RVA = "0x2B02F88", Offset = "0x2B02F88", VA = "0x2B02F88")]
		private void څࡣڐ\u0657()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002805 RID: 10245 RVA: 0x000ED574 File Offset: 0x000EB774
		[Token(Token = "0x6002805")]
		[Address(RVA = "0x2B033B0", Offset = "0x2B033B0", VA = "0x2B033B0")]
		private void ޛ\u0822\u05AFݎ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002806 RID: 10246 RVA: 0x000ED770 File Offset: 0x000EB970
		[Token(Token = "0x6002806")]
		[Address(RVA = "0x2B037E0", Offset = "0x2B037E0", VA = "0x2B037E0")]
		private void \u05EDց\u081Cت()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002807 RID: 10247 RVA: 0x000ED96C File Offset: 0x000EBB6C
		[Token(Token = "0x6002807")]
		[Address(RVA = "0x2B03C10", Offset = "0x2B03C10", VA = "0x2B03C10")]
		private void Րۼئ\u0897()
		{
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002808 RID: 10248 RVA: 0x000EDB54 File Offset: 0x000EBD54
		[Token(Token = "0x6002808")]
		[Address(RVA = "0x2B04040", Offset = "0x2B04040", VA = "0x2B04040")]
		private void ڃրӢԖ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002809 RID: 10249 RVA: 0x000EDD50 File Offset: 0x000EBF50
		[Token(Token = "0x6002809")]
		[Address(RVA = "0x2B04468", Offset = "0x2B04468", VA = "0x2B04468")]
		private void ࢫ\u0876չՍ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600280A RID: 10250 RVA: 0x000EDF50 File Offset: 0x000EC150
		[Token(Token = "0x600280A")]
		[Address(RVA = "0x2B04898", Offset = "0x2B04898", VA = "0x2B04898")]
		private void \u07B0ԝ\u07ACߪ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600280B RID: 10251 RVA: 0x000EE140 File Offset: 0x000EC340
		[Token(Token = "0x600280B")]
		[Address(RVA = "0x2B04CC8", Offset = "0x2B04CC8", VA = "0x2B04CC8")]
		private void \u0702Ӣݧޑ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600280C RID: 10252 RVA: 0x000EE330 File Offset: 0x000EC530
		[Token(Token = "0x600280C")]
		[Address(RVA = "0x2B050F4", Offset = "0x2B050F4", VA = "0x2B050F4")]
		private void \u0704زք٥()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600280D RID: 10253 RVA: 0x000EE520 File Offset: 0x000EC720
		[Token(Token = "0x600280D")]
		[Address(RVA = "0x2B05528", Offset = "0x2B05528", VA = "0x2B05528")]
		private void \u05B9Ջԇݪ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600280E RID: 10254 RVA: 0x000EE718 File Offset: 0x000EC918
		[Token(Token = "0x600280E")]
		[Address(RVA = "0x2B05950", Offset = "0x2B05950", VA = "0x2B05950")]
		private void \u070B\u05BCߢࡌ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600280F RID: 10255 RVA: 0x000EE914 File Offset: 0x000ECB14
		[Token(Token = "0x600280F")]
		[Address(RVA = "0x2B05D7C", Offset = "0x2B05D7C", VA = "0x2B05D7C")]
		private void ࡋձغӜ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002810 RID: 10256 RVA: 0x000EEB10 File Offset: 0x000ECD10
		[Token(Token = "0x6002810")]
		[Address(RVA = "0x2B061A8", Offset = "0x2B061A8", VA = "0x2B061A8")]
		private void ڌӬ\u088C\u087B()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002811 RID: 10257 RVA: 0x000EED00 File Offset: 0x000ECF00
		[Token(Token = "0x6002811")]
		[Address(RVA = "0x2B065D8", Offset = "0x2B065D8", VA = "0x2B065D8")]
		private void ޞؽ\u06EDս()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002812 RID: 10258 RVA: 0x000EEEF0 File Offset: 0x000ED0F0
		[Token(Token = "0x6002812")]
		[Address(RVA = "0x2B06A0C", Offset = "0x2B06A0C", VA = "0x2B06A0C")]
		private void ޝ\u088Dނپ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002813 RID: 10259 RVA: 0x000EF0EC File Offset: 0x000ED2EC
		[Token(Token = "0x6002813")]
		[Address(RVA = "0x2B06E3C", Offset = "0x2B06E3C", VA = "0x2B06E3C")]
		private void \u070Aәޣے()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002814 RID: 10260 RVA: 0x000EF2E8 File Offset: 0x000ED4E8
		[Token(Token = "0x6002814")]
		[Address(RVA = "0x2B07268", Offset = "0x2B07268", VA = "0x2B07268")]
		private void Ӎ\u070BԤߓ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002815 RID: 10261 RVA: 0x000EF4E4 File Offset: 0x000ED6E4
		[Token(Token = "0x6002815")]
		[Address(RVA = "0x2B07694", Offset = "0x2B07694", VA = "0x2B07694")]
		private void \u0838ӆڛӑ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002816 RID: 10262 RVA: 0x000EF6E0 File Offset: 0x000ED8E0
		[Token(Token = "0x6002816")]
		[Address(RVA = "0x2B07AC4", Offset = "0x2B07AC4", VA = "0x2B07AC4")]
		private void \u07A7ࡐ\u0818ܭ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002817 RID: 10263 RVA: 0x000EF8DC File Offset: 0x000EDADC
		[Token(Token = "0x6002817")]
		[Address(RVA = "0x2B07EEC", Offset = "0x2B07EEC", VA = "0x2B07EEC")]
		private void Ԧ\u0876ծՎ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002818 RID: 10264 RVA: 0x000EFACC File Offset: 0x000EDCCC
		[Token(Token = "0x6002818")]
		[Address(RVA = "0x2B0831C", Offset = "0x2B0831C", VA = "0x2B0831C")]
		private void \u089Aۆ\u0887\u05C0()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002819 RID: 10265 RVA: 0x000EFCC8 File Offset: 0x000EDEC8
		[Token(Token = "0x6002819")]
		[Address(RVA = "0x2B08748", Offset = "0x2B08748", VA = "0x2B08748")]
		private void բצؽӴ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600281A RID: 10266 RVA: 0x000EFEC4 File Offset: 0x000EE0C4
		[Token(Token = "0x600281A")]
		[Address(RVA = "0x2B08B74", Offset = "0x2B08B74", VA = "0x2B08B74")]
		private void \u07ABג\u07F4ւ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600281B RID: 10267 RVA: 0x000F00B4 File Offset: 0x000EE2B4
		[Token(Token = "0x600281B")]
		[Address(RVA = "0x2B08FA4", Offset = "0x2B08FA4", VA = "0x2B08FA4")]
		private void Ԯԇݯԃ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600281C RID: 10268 RVA: 0x000F02A4 File Offset: 0x000EE4A4
		[Token(Token = "0x600281C")]
		[Address(RVA = "0x2B093D4", Offset = "0x2B093D4", VA = "0x2B093D4")]
		private void LateUpdate()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600281D RID: 10269 RVA: 0x000F0494 File Offset: 0x000EE694
		[Token(Token = "0x600281D")]
		[Address(RVA = "0x2B09808", Offset = "0x2B09808", VA = "0x2B09808")]
		private void ӷ\u0747\u087Fڹ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600281E RID: 10270 RVA: 0x000F0684 File Offset: 0x000EE884
		[Token(Token = "0x600281E")]
		[Address(RVA = "0x2B09C3C", Offset = "0x2B09C3C", VA = "0x2B09C3C")]
		private void ى߁ٱՏ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600281F RID: 10271 RVA: 0x000F0880 File Offset: 0x000EEA80
		[Token(Token = "0x600281F")]
		[Address(RVA = "0x2B0A068", Offset = "0x2B0A068", VA = "0x2B0A068")]
		private void ӡݶէԽ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002820 RID: 10272 RVA: 0x000F0A7C File Offset: 0x000EEC7C
		[Token(Token = "0x6002820")]
		[Address(RVA = "0x2B0A490", Offset = "0x2B0A490", VA = "0x2B0A490")]
		private void ڔӈӋڤ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002821 RID: 10273 RVA: 0x000F0C6C File Offset: 0x000EEE6C
		[Token(Token = "0x6002821")]
		[Address(RVA = "0x2B0A8C4", Offset = "0x2B0A8C4", VA = "0x2B0A8C4")]
		private void Ҿࢹؼס()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002822 RID: 10274 RVA: 0x000F0E68 File Offset: 0x000EF068
		[Token(Token = "0x6002822")]
		[Address(RVA = "0x2B0ACEC", Offset = "0x2B0ACEC", VA = "0x2B0ACEC")]
		private void ҽגٻ\u05B7()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002823 RID: 10275 RVA: 0x000F1058 File Offset: 0x000EF258
		[Token(Token = "0x6002823")]
		[Address(RVA = "0x2B0B120", Offset = "0x2B0B120", VA = "0x2B0B120")]
		private void Ԃڏݏ\u086D()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002824 RID: 10276 RVA: 0x000F1254 File Offset: 0x000EF454
		[Token(Token = "0x6002824")]
		[Address(RVA = "0x2B0B550", Offset = "0x2B0B550", VA = "0x2B0B550")]
		private void \u06E3תثԸ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002825 RID: 10277 RVA: 0x000F1450 File Offset: 0x000EF650
		[Token(Token = "0x6002825")]
		[Address(RVA = "0x2B0B97C", Offset = "0x2B0B97C", VA = "0x2B0B97C")]
		private void ٴݵۃ\u05AF()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002826 RID: 10278 RVA: 0x000F164C File Offset: 0x000EF84C
		[Token(Token = "0x6002826")]
		[Address(RVA = "0x2B0BDAC", Offset = "0x2B0BDAC", VA = "0x2B0BDAC")]
		private void ߆۰\u05BFߍ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002827 RID: 10279 RVA: 0x000F183C File Offset: 0x000EFA3C
		[Token(Token = "0x6002827")]
		[Address(RVA = "0x2B0C1D8", Offset = "0x2B0C1D8", VA = "0x2B0C1D8")]
		private void չւت\u061E()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002828 RID: 10280 RVA: 0x000F1A38 File Offset: 0x000EFC38
		[Token(Token = "0x6002828")]
		[Address(RVA = "0x2B0C604", Offset = "0x2B0C604", VA = "0x2B0C604")]
		private void ߪձԛމ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002829 RID: 10281 RVA: 0x000F1C34 File Offset: 0x000EFE34
		[Token(Token = "0x6002829")]
		[Address(RVA = "0x2B0CA30", Offset = "0x2B0CA30", VA = "0x2B0CA30")]
		private void ݲ\u06E6ҽࡩ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600282A RID: 10282 RVA: 0x000F1E30 File Offset: 0x000F0030
		[Token(Token = "0x600282A")]
		[Address(RVA = "0x2B0CE60", Offset = "0x2B0CE60", VA = "0x2B0CE60")]
		private void \u05AC\u07F0\u07EEࡥ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600282B RID: 10283 RVA: 0x000F202C File Offset: 0x000F022C
		[Token(Token = "0x600282B")]
		[Address(RVA = "0x2B0D290", Offset = "0x2B0D290", VA = "0x2B0D290")]
		private void \u0559\u05FEפ\u05CD()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600282C RID: 10284 RVA: 0x000F2218 File Offset: 0x000F0418
		[Token(Token = "0x600282C")]
		[Address(RVA = "0x2B0D6BC", Offset = "0x2B0D6BC", VA = "0x2B0D6BC")]
		private void \u0886Ҽ\u058Dߛ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600282D RID: 10285 RVA: 0x000F2414 File Offset: 0x000F0614
		[Token(Token = "0x600282D")]
		[Address(RVA = "0x2B0DAE8", Offset = "0x2B0DAE8", VA = "0x2B0DAE8")]
		private void \u07BFޥ٧\u073B()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600282E RID: 10286 RVA: 0x000F2610 File Offset: 0x000F0810
		[Token(Token = "0x600282E")]
		[Address(RVA = "0x2B0DF10", Offset = "0x2B0DF10", VA = "0x2B0DF10")]
		private void ޤ\u0610\u087A\u05AF()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600282F RID: 10287 RVA: 0x000F280C File Offset: 0x000F0A0C
		[Token(Token = "0x600282F")]
		[Address(RVA = "0x2B0E33C", Offset = "0x2B0E33C", VA = "0x2B0E33C")]
		private void ڽ\u0894ىޡ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002830 RID: 10288 RVA: 0x000F2A08 File Offset: 0x000F0C08
		[Token(Token = "0x6002830")]
		[Address(RVA = "0x2B0E764", Offset = "0x2B0E764", VA = "0x2B0E764")]
		private void \u05F8ڶ\u070Aө()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002831 RID: 10289 RVA: 0x000F2BF8 File Offset: 0x000F0DF8
		[Token(Token = "0x6002831")]
		[Address(RVA = "0x2B0EB98", Offset = "0x2B0EB98", VA = "0x2B0EB98")]
		private void ڷԟ\u087D\u05B9()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002832 RID: 10290 RVA: 0x000F2DF4 File Offset: 0x000F0FF4
		[Token(Token = "0x6002832")]
		[Address(RVA = "0x2B0EFC4", Offset = "0x2B0EFC4", VA = "0x2B0EFC4")]
		private void \u089E\u0608ޗش()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002833 RID: 10291 RVA: 0x000F2FE4 File Offset: 0x000F11E4
		[Token(Token = "0x6002833")]
		[Address(RVA = "0x2B0F3F8", Offset = "0x2B0F3F8", VA = "0x2B0F3F8")]
		private void ԛ\u07EFӶ\u065A()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002834 RID: 10292 RVA: 0x000F31D4 File Offset: 0x000F13D4
		[Token(Token = "0x6002834")]
		[Address(RVA = "0x2B0F824", Offset = "0x2B0F824", VA = "0x2B0F824")]
		private void ࠇ\u087DػՏ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002835 RID: 10293 RVA: 0x000F33C4 File Offset: 0x000F15C4
		[Token(Token = "0x6002835")]
		[Address(RVA = "0x2B0FC58", Offset = "0x2B0FC58", VA = "0x2B0FC58")]
		private void ݪԧ\u05F3Ӝ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002836 RID: 10294 RVA: 0x000F35C0 File Offset: 0x000F17C0
		[Token(Token = "0x6002836")]
		[Address(RVA = "0x2B10084", Offset = "0x2B10084", VA = "0x2B10084")]
		private void Ԡݘעࠀ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002837 RID: 10295 RVA: 0x000F37BC File Offset: 0x000F19BC
		[Token(Token = "0x6002837")]
		[Address(RVA = "0x2B104B0", Offset = "0x2B104B0", VA = "0x2B104B0")]
		private void ڸՔ\u0594ԭ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002838 RID: 10296 RVA: 0x000F39B8 File Offset: 0x000F1BB8
		[Token(Token = "0x6002838")]
		[Address(RVA = "0x2B108D8", Offset = "0x2B108D8", VA = "0x2B108D8")]
		private void ւ\u06E9\u06DA\u06EB()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002839 RID: 10297 RVA: 0x000F3BB4 File Offset: 0x000F1DB4
		[Token(Token = "0x6002839")]
		[Address(RVA = "0x2B10D08", Offset = "0x2B10D08", VA = "0x2B10D08")]
		private void ӊ\u05BA\u0590ࢳ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600283A RID: 10298 RVA: 0x000F3DB0 File Offset: 0x000F1FB0
		[Token(Token = "0x600283A")]
		[Address(RVA = "0x2B11134", Offset = "0x2B11134", VA = "0x2B11134")]
		private void ބܝۄ\u0703()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600283B RID: 10299 RVA: 0x000F3FA0 File Offset: 0x000F21A0
		[Token(Token = "0x600283B")]
		[Address(RVA = "0x2B11564", Offset = "0x2B11564", VA = "0x2B11564")]
		private void ۍ\u05CAۋݿ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600283C RID: 10300 RVA: 0x000F4190 File Offset: 0x000F2390
		[Token(Token = "0x600283C")]
		[Address(RVA = "0x2B11990", Offset = "0x2B11990", VA = "0x2B11990")]
		public follow()
		{
		}

		// Token: 0x0600283D RID: 10301 RVA: 0x000F41A4 File Offset: 0x000F23A4
		[Token(Token = "0x600283D")]
		[Address(RVA = "0x2B11998", Offset = "0x2B11998", VA = "0x2B11998")]
		private void \u082Eכ\u0640ܮ()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x0600283E RID: 10302 RVA: 0x000F4394 File Offset: 0x000F2594
		[Token(Token = "0x600283E")]
		[Address(RVA = "0x2B11DCC", Offset = "0x2B11DCC", VA = "0x2B11DCC")]
		private void \u0590\u0882\u0883ࡦ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0600283F RID: 10303 RVA: 0x000F4590 File Offset: 0x000F2790
		[Token(Token = "0x600283F")]
		[Address(RVA = "0x2B121F4", Offset = "0x2B121F4", VA = "0x2B121F4")]
		private void \u0607\u0747\u058Aף()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002840 RID: 10304 RVA: 0x000F4780 File Offset: 0x000F2980
		[Token(Token = "0x6002840")]
		[Address(RVA = "0x2B12624", Offset = "0x2B12624", VA = "0x2B12624")]
		private void \u0877ԇ\u083D\u0738()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002841 RID: 10305 RVA: 0x000F497C File Offset: 0x000F2B7C
		[Token(Token = "0x6002841")]
		[Address(RVA = "0x2B12A50", Offset = "0x2B12A50", VA = "0x2B12A50")]
		private void ٧ؠԬט()
		{
			follow.\u066Cޢә\u07EB տڤڒ_u06D = this.տڤڒ\u06D9;
			follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
		}

		// Token: 0x06002842 RID: 10306 RVA: 0x000F4B6C File Offset: 0x000F2D6C
		[Token(Token = "0x6002842")]
		[Address(RVA = "0x2B12E7C", Offset = "0x2B12E7C", VA = "0x2B12E7C")]
		private void ࢶ٠\u086D\u0708()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x06002843 RID: 10307 RVA: 0x000F4D68 File Offset: 0x000F2F68
		[Token(Token = "0x6002843")]
		[Address(RVA = "0x2B132A8", Offset = "0x2B132A8", VA = "0x2B132A8")]
		private void Ӌ\u089C\u0700ܧ()
		{
			if (this.տڤڒ\u06D9 == follow.\u066Cޢә\u07EB.߃\u065BԧӇ)
			{
				follow.ӧ\u089EԦ\u0701 u0817ت_u0749ٽ = this.\u0817ت\u0749ٽ;
				return;
			}
		}

		// Token: 0x0400050C RID: 1292
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400050C")]
		public Transform ࠔؼࡏݥ;

		// Token: 0x0400050D RID: 1293
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400050D")]
		public float ݔࢺةט;

		// Token: 0x0400050E RID: 1294
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x400050E")]
		public float پࡑӗ\u087B;

		// Token: 0x0400050F RID: 1295
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400050F")]
		public float ڀԲؿ\u0609;

		// Token: 0x04000510 RID: 1296
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000510")]
		public follow.\u066Cޢә\u07EB տڤڒ\u06D9;

		// Token: 0x04000511 RID: 1297
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000511")]
		public follow.ӧ\u089EԦ\u0701 \u0817ت\u0749ٽ;

		// Token: 0x04000512 RID: 1298
		[FieldOffset(Offset = "0x34")]
		[Token(Token = "0x4000512")]
		public follow.ܭڅӠ\u0659 \u055C\u055FӼނ;

		// Token: 0x02000102 RID: 258
		[Token(Token = "0x2000102")]
		public enum \u066Cޢә\u07EB
		{
			// Token: 0x04000514 RID: 1300
			[Token(Token = "0x4000514")]
			߃\u065BԧӇ,
			// Token: 0x04000515 RID: 1301
			[Token(Token = "0x4000515")]
			ԡࡍࢥނ,
			// Token: 0x04000516 RID: 1302
			[Token(Token = "0x4000516")]
			ࡊעࡕ\u083C
		}

		// Token: 0x02000103 RID: 259
		[Token(Token = "0x2000103")]
		public enum ӧ\u089EԦ\u0701
		{
			// Token: 0x04000518 RID: 1304
			[Token(Token = "0x4000518")]
			ՃޙӚ\u083F,
			// Token: 0x04000519 RID: 1305
			[Token(Token = "0x4000519")]
			\u089Fߍࢡࠀ,
			// Token: 0x0400051A RID: 1306
			[Token(Token = "0x400051A")]
			ڴ\u064D\u083AӨ,
			// Token: 0x0400051B RID: 1307
			[Token(Token = "0x400051B")]
			\u0708ܜࠇՓ,
			// Token: 0x0400051C RID: 1308
			[Token(Token = "0x400051C")]
			\u05AFߪԩԭ,
			// Token: 0x0400051D RID: 1309
			[Token(Token = "0x400051D")]
			\u082B߃خٻ
		}

		// Token: 0x02000104 RID: 260
		[Token(Token = "0x2000104")]
		public enum ܭڅӠ\u0659
		{
			// Token: 0x0400051F RID: 1311
			[Token(Token = "0x400051F")]
			ՃޙӚ\u083F,
			// Token: 0x04000520 RID: 1312
			[Token(Token = "0x4000520")]
			ޢ\u07AFյ\u087E,
			// Token: 0x04000521 RID: 1313
			[Token(Token = "0x4000521")]
			Ԙԙ\u065Aࢣ,
			// Token: 0x04000522 RID: 1314
			[Token(Token = "0x4000522")]
			߉ڲ\u06E4ߍ,
			// Token: 0x04000523 RID: 1315
			[Token(Token = "0x4000523")]
			ࡩ\u073A\u06ECՏ
		}
	}
}
