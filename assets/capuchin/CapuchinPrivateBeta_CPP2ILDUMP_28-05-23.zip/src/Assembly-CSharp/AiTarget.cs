﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000064 RID: 100
[Token(Token = "0x2000064")]
public class AiTarget : MonoBehaviour
{
	// Token: 0x06000E44 RID: 3652 RVA: 0x000536C8 File Offset: 0x000518C8
	[Token(Token = "0x6000E44")]
	[Address(RVA = "0x2A4C0B0", Offset = "0x2A4C0B0", VA = "0x2A4C0B0")]
	public void ࠁ\u06E0ߔ\u0601()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E45 RID: 3653 RVA: 0x000536FC File Offset: 0x000518FC
	[Token(Token = "0x6000E45")]
	[Address(RVA = "0x2A4C12C", Offset = "0x2A4C12C", VA = "0x2A4C12C")]
	public void \u05A0\u060C\u05BFܞ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E46 RID: 3654 RVA: 0x00053730 File Offset: 0x00051930
	[Token(Token = "0x6000E46")]
	[Address(RVA = "0x2A4C1A8", Offset = "0x2A4C1A8", VA = "0x2A4C1A8")]
	public void ݞشٽٮ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E47 RID: 3655 RVA: 0x00053764 File Offset: 0x00051964
	[Token(Token = "0x6000E47")]
	[Address(RVA = "0x2A4C224", Offset = "0x2A4C224", VA = "0x2A4C224")]
	private void \u0886Ҽ\u058Dߛ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.Փ\u083D\u0898\u07F3();
	}

	// Token: 0x06000E48 RID: 3656 RVA: 0x000537B4 File Offset: 0x000519B4
	[Token(Token = "0x6000E48")]
	[Address(RVA = "0x2A4C35C", Offset = "0x2A4C35C", VA = "0x2A4C35C")]
	public void ࡍހԯ\u081C()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E49 RID: 3657 RVA: 0x000537E8 File Offset: 0x000519E8
	[Token(Token = "0x6000E49")]
	[Address(RVA = "0x2A4C3D8", Offset = "0x2A4C3D8", VA = "0x2A4C3D8")]
	public void \u055E\u05A5ېع()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E4A RID: 3658 RVA: 0x0005381C File Offset: 0x00051A1C
	[Token(Token = "0x6000E4A")]
	[Address(RVA = "0x2A4C454", Offset = "0x2A4C454", VA = "0x2A4C454")]
	public void ݕӳ\u0742դ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E4B RID: 3659 RVA: 0x00053850 File Offset: 0x00051A50
	[Token(Token = "0x6000E4B")]
	[Address(RVA = "0x2A4C4D0", Offset = "0x2A4C4D0", VA = "0x2A4C4D0")]
	public void چ߅ۏ\u070E()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E4C RID: 3660 RVA: 0x00053884 File Offset: 0x00051A84
	[Token(Token = "0x6000E4C")]
	[Address(RVA = "0x2A4C54C", Offset = "0x2A4C54C", VA = "0x2A4C54C")]
	public void ࠏ\u05BBԋߞ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E4D RID: 3661 RVA: 0x000538B8 File Offset: 0x00051AB8
	[Token(Token = "0x6000E4D")]
	[Address(RVA = "0x2A4C5C8", Offset = "0x2A4C5C8", VA = "0x2A4C5C8")]
	private void \u07BDއڸ\u0834()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ݺ\u07FD\u0829ܩ();
	}

	// Token: 0x06000E4E RID: 3662 RVA: 0x00053904 File Offset: 0x00051B04
	[Token(Token = "0x6000E4E")]
	[Address(RVA = "0x2A4C700", Offset = "0x2A4C700", VA = "0x2A4C700")]
	private void ݫࢷࠃ\u0820()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.Փ\u083D\u0898\u07F3();
	}

	// Token: 0x06000E4F RID: 3663 RVA: 0x00053954 File Offset: 0x00051B54
	[Token(Token = "0x6000E4F")]
	[Address(RVA = "0x2A4C7BC", Offset = "0x2A4C7BC", VA = "0x2A4C7BC")]
	private void ԣԭՋࠏ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ݧ\u05F9ࢡڵ();
	}

	// Token: 0x06000E50 RID: 3664 RVA: 0x000539A4 File Offset: 0x00051BA4
	[Token(Token = "0x6000E50")]
	[Address(RVA = "0x2A4C8F4", Offset = "0x2A4C8F4", VA = "0x2A4C8F4")]
	private void Ԉ۴ࡉࢬ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ڤڲ\u06E8ߦ();
	}

	// Token: 0x06000E51 RID: 3665 RVA: 0x000539F4 File Offset: 0x00051BF4
	[Token(Token = "0x6000E51")]
	[Address(RVA = "0x2A4CA2C", Offset = "0x2A4CA2C", VA = "0x2A4CA2C")]
	private void \u05F7ԝߠӱ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.٦\u0703ݣԕ();
	}

	// Token: 0x06000E52 RID: 3666 RVA: 0x00053A44 File Offset: 0x00051C44
	[Token(Token = "0x6000E52")]
	[Address(RVA = "0x2A4CB60", Offset = "0x2A4CB60", VA = "0x2A4CB60")]
	public void ژݖ\u07B6ؾ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E53 RID: 3667 RVA: 0x00053A78 File Offset: 0x00051C78
	[Token(Token = "0x6000E53")]
	[Address(RVA = "0x2A4CBDC", Offset = "0x2A4CBDC", VA = "0x2A4CBDC")]
	private void څࡣڐ\u0657()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.\u055E\u05A5ېع();
	}

	// Token: 0x06000E54 RID: 3668 RVA: 0x00053AC8 File Offset: 0x00051CC8
	[Token(Token = "0x6000E54")]
	[Address(RVA = "0x2A4CC98", Offset = "0x2A4CC98", VA = "0x2A4CC98")]
	public void Ӕ\u05C0ݾޏ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E55 RID: 3669 RVA: 0x00053AFC File Offset: 0x00051CFC
	[Token(Token = "0x6000E55")]
	[Address(RVA = "0x2A4CD14", Offset = "0x2A4CD14", VA = "0x2A4CD14")]
	public void ܗط\u0834\u0651()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E56 RID: 3670 RVA: 0x00053B30 File Offset: 0x00051D30
	[Token(Token = "0x6000E56")]
	[Address(RVA = "0x2A4CD90", Offset = "0x2A4CD90", VA = "0x2A4CD90")]
	public void \u0745ڪ\u0594Ӻ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E57 RID: 3671 RVA: 0x00053B5C File Offset: 0x00051D5C
	[Token(Token = "0x6000E57")]
	[Address(RVA = "0x2A4CE0C", Offset = "0x2A4CE0C", VA = "0x2A4CE0C")]
	public void \u085D\u0894\u05B0ܛ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E58 RID: 3672 RVA: 0x00053B90 File Offset: 0x00051D90
	[Token(Token = "0x6000E58")]
	[Address(RVA = "0x2A4CE88", Offset = "0x2A4CE88", VA = "0x2A4CE88")]
	public void ܦ\u089Cࡦڰ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E59 RID: 3673 RVA: 0x00053BC4 File Offset: 0x00051DC4
	[Token(Token = "0x6000E59")]
	[Address(RVA = "0x2A4CF04", Offset = "0x2A4CF04", VA = "0x2A4CF04")]
	public void \u07F9\u07F7\u05FD\u05B5()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
	}

	// Token: 0x06000E5A RID: 3674 RVA: 0x00053BF0 File Offset: 0x00051DF0
	[Token(Token = "0x6000E5A")]
	[Address(RVA = "0x2A4CF80", Offset = "0x2A4CF80", VA = "0x2A4CF80")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ࡍހԯ\u081C();
	}

	// Token: 0x06000E5B RID: 3675 RVA: 0x00053C40 File Offset: 0x00051E40
	[Token(Token = "0x6000E5B")]
	[Address(RVA = "0x2A4D03C", Offset = "0x2A4D03C", VA = "0x2A4D03C")]
	public void \u06E9ӷݯޝ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E5C RID: 3676 RVA: 0x00053C74 File Offset: 0x00051E74
	[Token(Token = "0x6000E5C")]
	[Address(RVA = "0x2A4D0B8", Offset = "0x2A4D0B8", VA = "0x2A4D0B8")]
	public void ݗ\u086C٨ڍ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E5D RID: 3677 RVA: 0x00053CA8 File Offset: 0x00051EA8
	[Token(Token = "0x6000E5D")]
	[Address(RVA = "0x2A4D134", Offset = "0x2A4D134", VA = "0x2A4D134")]
	public void ն\u064D\u0704\u07BA()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E5E RID: 3678 RVA: 0x00053CD4 File Offset: 0x00051ED4
	[Token(Token = "0x6000E5E")]
	[Address(RVA = "0x2A4D1B0", Offset = "0x2A4D1B0", VA = "0x2A4D1B0")]
	public void գځ\u089Fܛ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
	}

	// Token: 0x06000E5F RID: 3679 RVA: 0x00053CF8 File Offset: 0x00051EF8
	[Token(Token = "0x6000E5F")]
	[Address(RVA = "0x2A4D22C", Offset = "0x2A4D22C", VA = "0x2A4D22C")]
	public void \u05CBւ٠\u07B9()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E60 RID: 3680 RVA: 0x00053D2C File Offset: 0x00051F2C
	[Token(Token = "0x6000E60")]
	[Address(RVA = "0x2A4D2A8", Offset = "0x2A4D2A8", VA = "0x2A4D2A8")]
	private void ࢶ٠\u086D\u0708()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = this.\u0604\u05A2ݎԪ.position;
		this.ࡍހԯ\u081C();
	}

	// Token: 0x06000E61 RID: 3681 RVA: 0x00053D6C File Offset: 0x00051F6C
	[Token(Token = "0x6000E61")]
	[Address(RVA = "0x2A4D364", Offset = "0x2A4D364", VA = "0x2A4D364")]
	private void \u0838ӆڛӑ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ࠏ\u05BBԋߞ();
	}

	// Token: 0x06000E62 RID: 3682 RVA: 0x00053DBC File Offset: 0x00051FBC
	[Token(Token = "0x6000E62")]
	[Address(RVA = "0x2A4D420", Offset = "0x2A4D420", VA = "0x2A4D420")]
	private void ژךՈ\u0597()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.٦\u0703ݣԕ();
	}

	// Token: 0x06000E63 RID: 3683 RVA: 0x00053E0C File Offset: 0x0005200C
	[Token(Token = "0x6000E63")]
	[Address(RVA = "0x2A4D4DC", Offset = "0x2A4D4DC", VA = "0x2A4D4DC")]
	public void \u058Bࢫ\u05EDӢ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E64 RID: 3684 RVA: 0x00053E40 File Offset: 0x00052040
	[Token(Token = "0x6000E64")]
	[Address(RVA = "0x2A4D558", Offset = "0x2A4D558", VA = "0x2A4D558")]
	private void \u05ABࡡ\u07ABݾ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ն\u064D\u0704\u07BA();
	}

	// Token: 0x06000E65 RID: 3685 RVA: 0x00053E90 File Offset: 0x00052090
	[Token(Token = "0x6000E65")]
	[Address(RVA = "0x2A4C684", Offset = "0x2A4C684", VA = "0x2A4C684")]
	public void ݺ\u07FD\u0829ܩ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E66 RID: 3686 RVA: 0x00053EC4 File Offset: 0x000520C4
	[Token(Token = "0x6000E66")]
	[Address(RVA = "0x2A4D614", Offset = "0x2A4D614", VA = "0x2A4D614")]
	public void \u06E4ࡀ\u06EDޠ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E67 RID: 3687 RVA: 0x00053EF8 File Offset: 0x000520F8
	[Token(Token = "0x6000E67")]
	[Address(RVA = "0x2A4D690", Offset = "0x2A4D690", VA = "0x2A4D690")]
	private void \u055Cࢯܯ\u0898()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		this.\u083Cԓ\u07EFӞ();
	}

	// Token: 0x06000E68 RID: 3688 RVA: 0x00053F3C File Offset: 0x0005213C
	[Token(Token = "0x6000E68")]
	[Address(RVA = "0x2A4D7C8", Offset = "0x2A4D7C8", VA = "0x2A4D7C8")]
	public void \u0828\u07FE\u0612ܧ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E69 RID: 3689 RVA: 0x00053F70 File Offset: 0x00052170
	[Token(Token = "0x6000E69")]
	[Address(RVA = "0x2A4D844", Offset = "0x2A4D844", VA = "0x2A4D844")]
	public void \u070F\u0734\u064C\u07A6()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E6A RID: 3690 RVA: 0x00053FA4 File Offset: 0x000521A4
	[Token(Token = "0x6000E6A")]
	[Address(RVA = "0x2A4D8C0", Offset = "0x2A4D8C0", VA = "0x2A4D8C0")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ࠕ\u05FAռࠑ();
	}

	// Token: 0x06000E6B RID: 3691 RVA: 0x00053FF4 File Offset: 0x000521F4
	[Token(Token = "0x6000E6B")]
	[Address(RVA = "0x2A4D9F8", Offset = "0x2A4D9F8", VA = "0x2A4D9F8")]
	private void ٴݵۃ\u05AF()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.գځ\u089Fܛ();
	}

	// Token: 0x06000E6C RID: 3692 RVA: 0x00054044 File Offset: 0x00052244
	[Token(Token = "0x6000E6C")]
	[Address(RVA = "0x2A4C2E0", Offset = "0x2A4C2E0", VA = "0x2A4C2E0")]
	public void Փ\u083D\u0898\u07F3()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E6D RID: 3693 RVA: 0x00054078 File Offset: 0x00052278
	[Token(Token = "0x6000E6D")]
	[Address(RVA = "0x2A4DAB4", Offset = "0x2A4DAB4", VA = "0x2A4DAB4")]
	public void ݯ\u059Fߩ\u0882()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E6E RID: 3694 RVA: 0x000540AC File Offset: 0x000522AC
	[Token(Token = "0x6000E6E")]
	[Address(RVA = "0x2A4DB30", Offset = "0x2A4DB30", VA = "0x2A4DB30")]
	public void ܣࢮ\u073D\u0832()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E6F RID: 3695 RVA: 0x000540E0 File Offset: 0x000522E0
	[Token(Token = "0x6000E6F")]
	[Address(RVA = "0x2A4DBAC", Offset = "0x2A4DBAC", VA = "0x2A4DBAC")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ژݖ\u07B6ؾ();
	}

	// Token: 0x06000E70 RID: 3696 RVA: 0x00054130 File Offset: 0x00052330
	[Token(Token = "0x6000E70")]
	[Address(RVA = "0x2A4DC68", Offset = "0x2A4DC68", VA = "0x2A4DC68")]
	private void طӏܙࢺ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int num = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
	}

	// Token: 0x06000E71 RID: 3697 RVA: 0x00054158 File Offset: 0x00052358
	[Token(Token = "0x6000E71")]
	[Address(RVA = "0x2A4DD24", Offset = "0x2A4DD24", VA = "0x2A4DD24")]
	public AiTarget()
	{
	}

	// Token: 0x06000E72 RID: 3698 RVA: 0x0005416C File Offset: 0x0005236C
	[Token(Token = "0x6000E72")]
	[Address(RVA = "0x2A4DD2C", Offset = "0x2A4DD2C", VA = "0x2A4DD2C")]
	public void \u0816\u087Cܜܭ()
	{
	}

	// Token: 0x06000E73 RID: 3699 RVA: 0x00054188 File Offset: 0x00052388
	[Token(Token = "0x6000E73")]
	[Address(RVA = "0x2A4DDA8", Offset = "0x2A4DDA8", VA = "0x2A4DDA8")]
	private void \u0590\u0882\u0883ࡦ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.Ӕ\u05C0ݾޏ();
	}

	// Token: 0x06000E74 RID: 3700 RVA: 0x000541D8 File Offset: 0x000523D8
	[Token(Token = "0x6000E74")]
	[Address(RVA = "0x2A4C9B0", Offset = "0x2A4C9B0", VA = "0x2A4C9B0")]
	public void ڤڲ\u06E8ߦ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E75 RID: 3701 RVA: 0x0005420C File Offset: 0x0005240C
	[Token(Token = "0x6000E75")]
	[Address(RVA = "0x2A4DE64", Offset = "0x2A4DE64", VA = "0x2A4DE64")]
	private void יԠ\u07EDԺ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		int u073Aߘࡄ_u;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.Փ\u083D\u0898\u07F3();
	}

	// Token: 0x06000E76 RID: 3702 RVA: 0x00054254 File Offset: 0x00052454
	[Token(Token = "0x6000E76")]
	[Address(RVA = "0x2A4DF20", Offset = "0x2A4DF20", VA = "0x2A4DF20")]
	public void ߒخࡃӽ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E77 RID: 3703 RVA: 0x00054288 File Offset: 0x00052488
	[Token(Token = "0x6000E77")]
	[Address(RVA = "0x2A4DF9C", Offset = "0x2A4DF9C", VA = "0x2A4DF9C")]
	public void ލӴނݺ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E78 RID: 3704 RVA: 0x000542BC File Offset: 0x000524BC
	[Token(Token = "0x6000E78")]
	[Address(RVA = "0x2A4E018", Offset = "0x2A4E018", VA = "0x2A4E018")]
	private void \u0732ڙԒࢺ()
	{
	}

	// Token: 0x06000E79 RID: 3705 RVA: 0x000542D8 File Offset: 0x000524D8
	[Token(Token = "0x6000E79")]
	[Address(RVA = "0x2A4E0D4", Offset = "0x2A4E0D4", VA = "0x2A4E0D4")]
	private void Update()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ܗط\u0834\u0651();
	}

	// Token: 0x06000E7A RID: 3706 RVA: 0x00054328 File Offset: 0x00052528
	[Token(Token = "0x6000E7A")]
	[Address(RVA = "0x2A4E18C", Offset = "0x2A4E18C", VA = "0x2A4E18C")]
	public void զ\u0874ێ\u06EA()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
	}

	// Token: 0x06000E7B RID: 3707 RVA: 0x0005434C File Offset: 0x0005254C
	[Token(Token = "0x6000E7B")]
	[Address(RVA = "0x2A4E208", Offset = "0x2A4E208", VA = "0x2A4E208")]
	public void \u0879ޗ\u073Cӈ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E7C RID: 3708 RVA: 0x00054380 File Offset: 0x00052580
	[Token(Token = "0x6000E7C")]
	[Address(RVA = "0x2A4E284", Offset = "0x2A4E284", VA = "0x2A4E284")]
	public void ߣڍԀ\u059C()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E7D RID: 3709 RVA: 0x000543B4 File Offset: 0x000525B4
	[Token(Token = "0x6000E7D")]
	[Address(RVA = "0x2A4D97C", Offset = "0x2A4D97C", VA = "0x2A4D97C")]
	public void ࠕ\u05FAռࠑ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E7E RID: 3710 RVA: 0x000543E8 File Offset: 0x000525E8
	[Token(Token = "0x6000E7E")]
	[Address(RVA = "0x2A4CAE4", Offset = "0x2A4CAE4", VA = "0x2A4CAE4")]
	public void ٦\u0703ݣԕ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E7F RID: 3711 RVA: 0x0005441C File Offset: 0x0005261C
	[Token(Token = "0x6000E7F")]
	[Address(RVA = "0x2A4E300", Offset = "0x2A4E300", VA = "0x2A4E300")]
	private void \u073Fߗބݝ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.\u055E\u05A5ېع();
	}

	// Token: 0x06000E80 RID: 3712 RVA: 0x0005446C File Offset: 0x0005266C
	[Token(Token = "0x6000E80")]
	[Address(RVA = "0x2A4E3BC", Offset = "0x2A4E3BC", VA = "0x2A4E3BC")]
	private void \u07FE\u0882Զ\u066D()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ࠑٽڒۂ();
	}

	// Token: 0x06000E81 RID: 3713 RVA: 0x000544BC File Offset: 0x000526BC
	[Token(Token = "0x6000E81")]
	[Address(RVA = "0x2A4E4F4", Offset = "0x2A4E4F4", VA = "0x2A4E4F4")]
	public void ۸զ\u0656Ӿ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E82 RID: 3714 RVA: 0x000544F0 File Offset: 0x000526F0
	[Token(Token = "0x6000E82")]
	[Address(RVA = "0x2A4E570", Offset = "0x2A4E570", VA = "0x2A4E570")]
	private void ߊ\u066A\u05CFԉ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ܣࢮ\u073D\u0832();
	}

	// Token: 0x06000E83 RID: 3715 RVA: 0x00054540 File Offset: 0x00052740
	[Token(Token = "0x6000E83")]
	[Address(RVA = "0x2A4E62C", Offset = "0x2A4E62C", VA = "0x2A4E62C")]
	private void \u0832ࢳޤ\u07B5()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.զ\u0874ێ\u06EA();
	}

	// Token: 0x06000E84 RID: 3716 RVA: 0x00054590 File Offset: 0x00052790
	[Token(Token = "0x6000E84")]
	[Address(RVA = "0x2A4E6E8", Offset = "0x2A4E6E8", VA = "0x2A4E6E8")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ܦ\u089Cࡦڰ();
	}

	// Token: 0x06000E85 RID: 3717 RVA: 0x000545E0 File Offset: 0x000527E0
	[Token(Token = "0x6000E85")]
	[Address(RVA = "0x2A4E7A4", Offset = "0x2A4E7A4", VA = "0x2A4E7A4")]
	private void Ҽ\u08B5ځ\u0658()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.\u0816\u087Cܜܭ();
	}

	// Token: 0x06000E86 RID: 3718 RVA: 0x00054630 File Offset: 0x00052830
	[Token(Token = "0x6000E86")]
	[Address(RVA = "0x2A4E860", Offset = "0x2A4E860", VA = "0x2A4E860")]
	private void \u070Aәޣے()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.۸զ\u0656Ӿ();
	}

	// Token: 0x06000E87 RID: 3719 RVA: 0x00054680 File Offset: 0x00052880
	[Token(Token = "0x6000E87")]
	[Address(RVA = "0x2A4D74C", Offset = "0x2A4D74C", VA = "0x2A4D74C")]
	public void \u083Cԓ\u07EFӞ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E88 RID: 3720 RVA: 0x000546B4 File Offset: 0x000528B4
	[Token(Token = "0x6000E88")]
	[Address(RVA = "0x2A4E91C", Offset = "0x2A4E91C", VA = "0x2A4E91C")]
	public void Ӭ\u088Fߒٺ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E89 RID: 3721 RVA: 0x000546E8 File Offset: 0x000528E8
	[Token(Token = "0x6000E89")]
	[Address(RVA = "0x2A4E998", Offset = "0x2A4E998", VA = "0x2A4E998")]
	private void \u05B3ࢹߧ\u07AA()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int num = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
	}

	// Token: 0x06000E8A RID: 3722 RVA: 0x00054710 File Offset: 0x00052910
	[Token(Token = "0x6000E8A")]
	[Address(RVA = "0x2A4EA54", Offset = "0x2A4EA54", VA = "0x2A4EA54")]
	public void ڭծߪࠀ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E8B RID: 3723 RVA: 0x00054744 File Offset: 0x00052944
	[Token(Token = "0x6000E8B")]
	[Address(RVA = "0x2A4E478", Offset = "0x2A4E478", VA = "0x2A4E478")]
	public void ࠑٽڒۂ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E8C RID: 3724 RVA: 0x00054778 File Offset: 0x00052978
	[Token(Token = "0x6000E8C")]
	[Address(RVA = "0x2A4EAD0", Offset = "0x2A4EAD0", VA = "0x2A4EAD0")]
	private void ࢫ\u0876չՍ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(0, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.ݺ\u07FD\u0829ܩ();
	}

	// Token: 0x06000E8D RID: 3725 RVA: 0x000547C8 File Offset: 0x000529C8
	[Token(Token = "0x6000E8D")]
	[Address(RVA = "0x2A4C878", Offset = "0x2A4C878", VA = "0x2A4C878")]
	public void ݧ\u05F9ࢡڵ()
	{
		Transform[] ߍՓ_u065Aԇ = this.ߍՓ\u065Aԇ;
		Transform[] ߍՓ_u065Aԇ2 = this.ߍՓ\u065Aԇ;
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
	}

	// Token: 0x06000E8E RID: 3726 RVA: 0x000547FC File Offset: 0x000529FC
	[Token(Token = "0x6000E8E")]
	[Address(RVA = "0x2A4EB8C", Offset = "0x2A4EB8C", VA = "0x2A4EB8C")]
	private void \u087BӦןݩ()
	{
		int يԘࡠ_u07FF = this.يԘࡠ\u07FF;
		int u073Aߘࡄ_u = UnityEngine.Random.Range(1, يԘࡠ_u07FF);
		Transform ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		this.\u073Aߘࡄ\u0596 = u073Aߘࡄ_u;
		Vector3 position = ӱӤ_u073Aސ.position;
		Vector3 position2 = this.\u0604\u05A2ݎԪ.position;
		this.\u070F\u0734\u064C\u07A6();
	}

	// Token: 0x04000205 RID: 517
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000205")]
	public Transform[] ߍՓ\u065Aԇ;

	// Token: 0x04000206 RID: 518
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000206")]
	public Transform ӱӤ\u073Aސ;

	// Token: 0x04000207 RID: 519
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000207")]
	public Transform \u0604\u05A2ݎԪ;

	// Token: 0x04000208 RID: 520
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000208")]
	public Transform \u081B\u070Aߢࡁ;

	// Token: 0x04000209 RID: 521
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000209")]
	public int يԘࡠ\u07FF;

	// Token: 0x0400020A RID: 522
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x400020A")]
	private int \u073Aߘࡄ\u0596;

	// Token: 0x0400020B RID: 523
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400020B")]
	public float פ߈ک\u0732;
}
