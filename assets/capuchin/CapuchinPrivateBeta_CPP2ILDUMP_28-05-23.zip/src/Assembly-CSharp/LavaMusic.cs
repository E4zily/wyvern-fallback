﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000C5 RID: 197
[Token(Token = "0x20000C5")]
public class LavaMusic : MonoBehaviour
{
	// Token: 0x06001D2C RID: 7468 RVA: 0x00098AAC File Offset: 0x00096CAC
	[Token(Token = "0x6001D2C")]
	[Address(RVA = "0x2AE27D0", Offset = "0x2AE27D0", VA = "0x2AE27D0")]
	private void \u061B\u05EEوۈ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D2D RID: 7469 RVA: 0x00098B24 File Offset: 0x00096D24
	[Token(Token = "0x6001D2D")]
	[Address(RVA = "0x2AE290C", Offset = "0x2AE290C", VA = "0x2AE290C")]
	private void ں٢ࡡ\u05EC()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D2E RID: 7470 RVA: 0x00098B9C File Offset: 0x00096D9C
	[Token(Token = "0x6001D2E")]
	[Address(RVA = "0x2AE2A44", Offset = "0x2AE2A44", VA = "0x2AE2A44")]
	private void \u0881ݗӟ\u07BD()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D2F RID: 7471 RVA: 0x00098C14 File Offset: 0x00096E14
	[Token(Token = "0x6001D2F")]
	[Address(RVA = "0x2AE2B80", Offset = "0x2AE2B80", VA = "0x2AE2B80")]
	private void \u0614ࢥӴ\u086C()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D30 RID: 7472 RVA: 0x00098C80 File Offset: 0x00096E80
	[Token(Token = "0x6001D30")]
	[Address(RVA = "0x2AE2CBC", Offset = "0x2AE2CBC", VA = "0x2AE2CBC")]
	private void ւࡂ\u0883\u0872()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D31 RID: 7473 RVA: 0x00098CF8 File Offset: 0x00096EF8
	[Token(Token = "0x6001D31")]
	[Address(RVA = "0x2AE2DF4", Offset = "0x2AE2DF4", VA = "0x2AE2DF4")]
	private void ӻӒݝ߃()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D32 RID: 7474 RVA: 0x00098D70 File Offset: 0x00096F70
	[Token(Token = "0x6001D32")]
	[Address(RVA = "0x2AE2F2C", Offset = "0x2AE2F2C", VA = "0x2AE2F2C")]
	private void \u05EDց\u081Cت()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D33 RID: 7475 RVA: 0x00098DE8 File Offset: 0x00096FE8
	[Token(Token = "0x6001D33")]
	[Address(RVA = "0x2AE3068", Offset = "0x2AE3068", VA = "0x2AE3068")]
	private void ڃրӢԖ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D34 RID: 7476 RVA: 0x00098E60 File Offset: 0x00097060
	[Token(Token = "0x6001D34")]
	[Address(RVA = "0x2AE31A4", Offset = "0x2AE31A4", VA = "0x2AE31A4")]
	private void \u0870\u05B3Ց\u066A()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D35 RID: 7477 RVA: 0x00098ED8 File Offset: 0x000970D8
	[Token(Token = "0x6001D35")]
	[Address(RVA = "0x2AE32DC", Offset = "0x2AE32DC", VA = "0x2AE32DC")]
	private void \u0732ڙԒࢺ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D36 RID: 7478 RVA: 0x00098F50 File Offset: 0x00097150
	[Token(Token = "0x6001D36")]
	[Address(RVA = "0x2AE3418", Offset = "0x2AE3418", VA = "0x2AE3418")]
	private void ފՖߢ\u059B()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D37 RID: 7479 RVA: 0x00098FC8 File Offset: 0x000971C8
	[Token(Token = "0x6001D37")]
	[Address(RVA = "0x2AE3550", Offset = "0x2AE3550", VA = "0x2AE3550")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D38 RID: 7480 RVA: 0x00099040 File Offset: 0x00097240
	[Token(Token = "0x6001D38")]
	[Address(RVA = "0x2AE3688", Offset = "0x2AE3688", VA = "0x2AE3688")]
	private void Ӌ\u089C\u0700ܧ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D39 RID: 7481 RVA: 0x000990B8 File Offset: 0x000972B8
	[Token(Token = "0x6001D39")]
	[Address(RVA = "0x2AE37C0", Offset = "0x2AE37C0", VA = "0x2AE37C0")]
	private void \u07FE\u0882Զ\u066D()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D3A RID: 7482 RVA: 0x00099130 File Offset: 0x00097330
	[Token(Token = "0x6001D3A")]
	[Address(RVA = "0x2AE38FC", Offset = "0x2AE38FC", VA = "0x2AE38FC")]
	private void ո\u07AA\u05BDࠕ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D3B RID: 7483 RVA: 0x000991A8 File Offset: 0x000973A8
	[Token(Token = "0x6001D3B")]
	[Address(RVA = "0x2AE3A38", Offset = "0x2AE3A38", VA = "0x2AE3A38")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D3C RID: 7484 RVA: 0x00099220 File Offset: 0x00097420
	[Token(Token = "0x6001D3C")]
	[Address(RVA = "0x2AE3B74", Offset = "0x2AE3B74", VA = "0x2AE3B74")]
	private void ڑߒجވ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D3D RID: 7485 RVA: 0x00099298 File Offset: 0x00097498
	[Token(Token = "0x6001D3D")]
	[Address(RVA = "0x2AE3CB0", Offset = "0x2AE3CB0", VA = "0x2AE3CB0")]
	private void ࢫ\u0876չՍ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D3E RID: 7486 RVA: 0x0009930C File Offset: 0x0009750C
	[Token(Token = "0x6001D3E")]
	[Address(RVA = "0x2AE3DEC", Offset = "0x2AE3DEC", VA = "0x2AE3DEC")]
	private void \u0838ӆڛӑ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D3F RID: 7487 RVA: 0x00099384 File Offset: 0x00097584
	[Token(Token = "0x6001D3F")]
	[Address(RVA = "0x2AE3F24", Offset = "0x2AE3F24", VA = "0x2AE3F24")]
	private void צ\u0874ڵ\u059A()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D40 RID: 7488 RVA: 0x000993FC File Offset: 0x000975FC
	[Token(Token = "0x6001D40")]
	[Address(RVA = "0x2AE4060", Offset = "0x2AE4060", VA = "0x2AE4060")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D41 RID: 7489 RVA: 0x00099474 File Offset: 0x00097674
	[Token(Token = "0x6001D41")]
	[Address(RVA = "0x2AE419C", Offset = "0x2AE419C", VA = "0x2AE419C")]
	private void Update()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D42 RID: 7490 RVA: 0x000994EC File Offset: 0x000976EC
	[Token(Token = "0x6001D42")]
	[Address(RVA = "0x2AE42B0", Offset = "0x2AE42B0", VA = "0x2AE42B0")]
	private void \u05F7ԝߠӱ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D43 RID: 7491 RVA: 0x00099564 File Offset: 0x00097764
	[Token(Token = "0x6001D43")]
	[Address(RVA = "0x2AE43EC", Offset = "0x2AE43EC", VA = "0x2AE43EC")]
	private void \u05F8ݑ\u06ECߞ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D44 RID: 7492 RVA: 0x000995DC File Offset: 0x000977DC
	[Token(Token = "0x6001D44")]
	[Address(RVA = "0x2AE4524", Offset = "0x2AE4524", VA = "0x2AE4524")]
	public LavaMusic()
	{
	}

	// Token: 0x06001D45 RID: 7493 RVA: 0x000995F0 File Offset: 0x000977F0
	[Token(Token = "0x6001D45")]
	[Address(RVA = "0x2AE452C", Offset = "0x2AE452C", VA = "0x2AE452C")]
	private void Ҿࢹؼס()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D46 RID: 7494 RVA: 0x00099668 File Offset: 0x00097868
	[Token(Token = "0x6001D46")]
	[Address(RVA = "0x2AE4668", Offset = "0x2AE4668", VA = "0x2AE4668")]
	private void \u0832ࢳޤ\u07B5()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D47 RID: 7495 RVA: 0x000996E0 File Offset: 0x000978E0
	[Token(Token = "0x6001D47")]
	[Address(RVA = "0x2AE47A4", Offset = "0x2AE47A4", VA = "0x2AE47A4")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D48 RID: 7496 RVA: 0x00099758 File Offset: 0x00097958
	[Token(Token = "0x6001D48")]
	[Address(RVA = "0x2AE48E0", Offset = "0x2AE48E0", VA = "0x2AE48E0")]
	private void \u0821\u059Fӕ\u0607()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D49 RID: 7497 RVA: 0x000997D0 File Offset: 0x000979D0
	[Token(Token = "0x6001D49")]
	[Address(RVA = "0x2AE4A1C", Offset = "0x2AE4A1C", VA = "0x2AE4A1C")]
	private void ԣԭՋࠏ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D4A RID: 7498 RVA: 0x00099848 File Offset: 0x00097A48
	[Token(Token = "0x6001D4A")]
	[Address(RVA = "0x2AE4B58", Offset = "0x2AE4B58", VA = "0x2AE4B58")]
	private void չւت\u061E()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D4B RID: 7499 RVA: 0x000998C0 File Offset: 0x00097AC0
	[Token(Token = "0x6001D4B")]
	[Address(RVA = "0x2AE4C90", Offset = "0x2AE4C90", VA = "0x2AE4C90")]
	private void ٴݵۃ\u05AF()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D4C RID: 7500 RVA: 0x00099938 File Offset: 0x00097B38
	[Token(Token = "0x6001D4C")]
	[Address(RVA = "0x2AE4DC8", Offset = "0x2AE4DC8", VA = "0x2AE4DC8")]
	private void \u0599ږࠆ\u065F()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D4D RID: 7501 RVA: 0x000999B0 File Offset: 0x00097BB0
	[Token(Token = "0x6001D4D")]
	[Address(RVA = "0x2AE4F04", Offset = "0x2AE4F04", VA = "0x2AE4F04")]
	private void طӏܙࢺ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D4E RID: 7502 RVA: 0x00099A28 File Offset: 0x00097C28
	[Token(Token = "0x6001D4E")]
	[Address(RVA = "0x2AE5040", Offset = "0x2AE5040", VA = "0x2AE5040")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D4F RID: 7503 RVA: 0x00099AA0 File Offset: 0x00097CA0
	[Token(Token = "0x6001D4F")]
	[Address(RVA = "0x2AE5178", Offset = "0x2AE5178", VA = "0x2AE5178")]
	private void ԟ\u086Cޣ\u055E()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D50 RID: 7504 RVA: 0x00099B18 File Offset: 0x00097D18
	[Token(Token = "0x6001D50")]
	[Address(RVA = "0x2AE52B4", Offset = "0x2AE52B4", VA = "0x2AE52B4")]
	private void \u0654ޛ\u07FAذ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D51 RID: 7505 RVA: 0x00099B90 File Offset: 0x00097D90
	[Token(Token = "0x6001D51")]
	[Address(RVA = "0x2AE53E4", Offset = "0x2AE53E4", VA = "0x2AE53E4")]
	private void Ҽ\u08B5ځ\u0658()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D52 RID: 7506 RVA: 0x00099C08 File Offset: 0x00097E08
	[Token(Token = "0x6001D52")]
	[Address(RVA = "0x2AE551C", Offset = "0x2AE551C", VA = "0x2AE551C")]
	private void ژךՈ\u0597()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D53 RID: 7507 RVA: 0x00099C80 File Offset: 0x00097E80
	[Token(Token = "0x6001D53")]
	[Address(RVA = "0x2AE5658", Offset = "0x2AE5658", VA = "0x2AE5658")]
	private void \u087BӦןݩ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D54 RID: 7508 RVA: 0x00099CF8 File Offset: 0x00097EF8
	[Token(Token = "0x6001D54")]
	[Address(RVA = "0x2AE5794", Offset = "0x2AE5794", VA = "0x2AE5794")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D55 RID: 7509 RVA: 0x00099D70 File Offset: 0x00097F70
	[Token(Token = "0x6001D55")]
	[Address(RVA = "0x2AE58D0", Offset = "0x2AE58D0", VA = "0x2AE58D0")]
	private void Ӣ\u0592ߨׯ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D56 RID: 7510 RVA: 0x00099DE8 File Offset: 0x00097FE8
	[Token(Token = "0x6001D56")]
	[Address(RVA = "0x2AE5A0C", Offset = "0x2AE5A0C", VA = "0x2AE5A0C")]
	private void יԠ\u07EDԺ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D57 RID: 7511 RVA: 0x00099E60 File Offset: 0x00098060
	[Token(Token = "0x6001D57")]
	[Address(RVA = "0x2AE5B48", Offset = "0x2AE5B48", VA = "0x2AE5B48")]
	private void څࡣڐ\u0657()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D58 RID: 7512 RVA: 0x00099ED8 File Offset: 0x000980D8
	[Token(Token = "0x6001D58")]
	[Address(RVA = "0x2AE5C84", Offset = "0x2AE5C84", VA = "0x2AE5C84")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D59 RID: 7513 RVA: 0x00099F50 File Offset: 0x00098150
	[Token(Token = "0x6001D59")]
	[Address(RVA = "0x2AE5DC0", Offset = "0x2AE5DC0", VA = "0x2AE5DC0")]
	private void \u073Fߗބݝ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D5A RID: 7514 RVA: 0x00099FC8 File Offset: 0x000981C8
	[Token(Token = "0x6001D5A")]
	[Address(RVA = "0x2AE5EFC", Offset = "0x2AE5EFC", VA = "0x2AE5EFC")]
	private void \u0590\u0882\u0883ࡦ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D5B RID: 7515 RVA: 0x0009A040 File Offset: 0x00098240
	[Token(Token = "0x6001D5B")]
	[Address(RVA = "0x2AE6038", Offset = "0x2AE6038", VA = "0x2AE6038")]
	private void \u0886Ҽ\u058Dߛ()
	{
		Vector3 position = this.Ա\u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume;
		audioSource.volume = volume;
	}

	// Token: 0x06001D5C RID: 7516 RVA: 0x0009A0A8 File Offset: 0x000982A8
	[Token(Token = "0x6001D5C")]
	[Address(RVA = "0x2AE6174", Offset = "0x2AE6174", VA = "0x2AE6174")]
	private void ժ\u065Dԯࡘ()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x06001D5D RID: 7517 RVA: 0x0009A120 File Offset: 0x00098320
	[Token(Token = "0x6001D5D")]
	[Address(RVA = "0x2AE62B0", Offset = "0x2AE62B0", VA = "0x2AE62B0")]
	private void \u070Aәޣے()
	{
		Transform ա_u05F6ݣݠ = this.Ա\u05F6ݣݠ;
		AudioSource u05F8_u0598߀ԥ = this.\u05F8\u0598߀ԥ;
		Vector3 position = ա_u05F6ݣݠ.position;
		Vector3 position2 = this.ل\u0826\u0703\u055E.position;
		float volume;
		u05F8_u0598߀ԥ.volume = volume;
		Transform ա_u05F6ݣݠ2 = this.Ա\u05F6ݣݠ;
		AudioSource audioSource = this.ݺڂڴԐ;
		Vector3 position3 = ա_u05F6ݣݠ2.position;
		Vector3 position4 = this.ل\u0826\u0703\u055E.position;
		float volume2;
		audioSource.volume = volume2;
	}

	// Token: 0x040003E8 RID: 1000
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003E8")]
	public AudioSource \u05F8\u0598߀ԥ;

	// Token: 0x040003E9 RID: 1001
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003E9")]
	public AudioSource ݺڂڴԐ;

	// Token: 0x040003EA RID: 1002
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003EA")]
	public Transform Ա\u05F6ݣݠ;

	// Token: 0x040003EB RID: 1003
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003EB")]
	public Transform ل\u0826\u0703\u055E;
}
