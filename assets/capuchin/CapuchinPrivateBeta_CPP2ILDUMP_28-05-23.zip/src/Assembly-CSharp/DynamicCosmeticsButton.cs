﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x02000056 RID: 86
[Token(Token = "0x2000056")]
public class DynamicCosmeticsButton : MonoBehaviour
{
	// Token: 0x06000BCE RID: 3022 RVA: 0x0003ECDC File Offset: 0x0003CEDC
	[Token(Token = "0x6000BCE")]
	[Address(RVA = "0x28D0FC4", Offset = "0x28D0FC4", VA = "0x28D0FC4")]
	private void ޙߍ\u081A\u0651()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BCF RID: 3023 RVA: 0x0003ED04 File Offset: 0x0003CF04
	[Token(Token = "0x6000BCF")]
	[Address(RVA = "0x28D1004", Offset = "0x28D1004", VA = "0x28D1004")]
	private void \u0834\u0817ރࡔ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BD0 RID: 3024 RVA: 0x0003ED2C File Offset: 0x0003CF2C
	[Token(Token = "0x6000BD0")]
	[Address(RVA = "0x28D1044", Offset = "0x28D1044", VA = "0x28D1044")]
	private void Update()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BD1 RID: 3025 RVA: 0x0003EDA8 File Offset: 0x0003CFA8
	[Token(Token = "0x6000BD1")]
	[Address(RVA = "0x28D1210", Offset = "0x28D1210", VA = "0x28D1210")]
	private void ࡥշӞھ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BD2 RID: 3026 RVA: 0x0003EE24 File Offset: 0x0003D024
	[Token(Token = "0x6000BD2")]
	[Address(RVA = "0x28D13E0", Offset = "0x28D13E0", VA = "0x28D13E0")]
	private void \u0886Ҽ\u058Dߛ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BD3 RID: 3027 RVA: 0x0003EEB0 File Offset: 0x0003D0B0
	[Token(Token = "0x6000BD3")]
	[Address(RVA = "0x28D15B0", Offset = "0x28D15B0", VA = "0x28D15B0")]
	private void \u0827ߜ\u07FD\u07F4()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BD4 RID: 3028 RVA: 0x0003EF3C File Offset: 0x0003D13C
	[Token(Token = "0x6000BD4")]
	[Address(RVA = "0x28D1780", Offset = "0x28D1780", VA = "0x28D1780")]
	private void \u0656ӺմՁ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BD5 RID: 3029 RVA: 0x0003EF64 File Offset: 0x0003D164
	[Token(Token = "0x6000BD5")]
	[Address(RVA = "0x28D17C0", Offset = "0x28D17C0", VA = "0x28D17C0")]
	private void \u05F7ԝߠӱ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BD6 RID: 3030 RVA: 0x0003EFE0 File Offset: 0x0003D1E0
	[Token(Token = "0x6000BD6")]
	[Address(RVA = "0x28D1990", Offset = "0x28D1990", VA = "0x28D1990")]
	private void \u05FD\u06E1\u064Cԕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.\u0670\u06E6ښ\u0613(this);
	}

	// Token: 0x06000BD7 RID: 3031 RVA: 0x0003F014 File Offset: 0x0003D214
	[Token(Token = "0x6000BD7")]
	[Address(RVA = "0x28D1A60", Offset = "0x28D1A60", VA = "0x28D1A60")]
	private void \u06D6ې\u083Bࠉ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BD8 RID: 3032 RVA: 0x0003F03C File Offset: 0x0003D23C
	[Token(Token = "0x6000BD8")]
	[Address(RVA = "0x28D1AA0", Offset = "0x28D1AA0", VA = "0x28D1AA0")]
	private void \u07B6կպ߃()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BD9 RID: 3033 RVA: 0x0003F0B8 File Offset: 0x0003D2B8
	[Token(Token = "0x6000BD9")]
	[Address(RVA = "0x28D1C6C", Offset = "0x28D1C6C", VA = "0x28D1C6C")]
	private void ࠈ\u07A9\u05B3Ծ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BDA RID: 3034 RVA: 0x0003F134 File Offset: 0x0003D334
	[Token(Token = "0x6000BDA")]
	[Address(RVA = "0x28D1E38", Offset = "0x28D1E38", VA = "0x28D1E38")]
	private void Ԁוև\u065B()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BDB RID: 3035 RVA: 0x0003F15C File Offset: 0x0003D35C
	[Token(Token = "0x6000BDB")]
	[Address(RVA = "0x28D1E78", Offset = "0x28D1E78", VA = "0x28D1E78")]
	private void ہݕ\u07EFԒ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BDC RID: 3036 RVA: 0x0003F1E8 File Offset: 0x0003D3E8
	[Token(Token = "0x6000BDC")]
	[Address(RVA = "0x28D2048", Offset = "0x28D2048", VA = "0x28D2048")]
	private void \u07A8Ӥթݠ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BDD RID: 3037 RVA: 0x0003F210 File Offset: 0x0003D410
	[Token(Token = "0x6000BDD")]
	[Address(RVA = "0x28D2088", Offset = "0x28D2088", VA = "0x28D2088")]
	private void ԅ\u073Fڥ\u0839()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BDE RID: 3038 RVA: 0x0003F28C File Offset: 0x0003D48C
	[Token(Token = "0x6000BDE")]
	[Address(RVA = "0x28D2254", Offset = "0x28D2254", VA = "0x28D2254")]
	private void Ԃ\u058Aܫջ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ޢ\u05A8\u07FF\u0881(this);
	}

	// Token: 0x06000BDF RID: 3039 RVA: 0x0003F2C0 File Offset: 0x0003D4C0
	[Token(Token = "0x6000BDF")]
	[Address(RVA = "0x28D2324", Offset = "0x28D2324", VA = "0x28D2324")]
	private void ߑ\u0885\u05BBߕ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BE0 RID: 3040 RVA: 0x0003F33C File Offset: 0x0003D53C
	[Token(Token = "0x6000BE0")]
	[Address(RVA = "0x28D24F0", Offset = "0x28D24F0", VA = "0x28D24F0")]
	private void ڣֆ\u07F4ڌ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BE1 RID: 3041 RVA: 0x0003F364 File Offset: 0x0003D564
	[Token(Token = "0x6000BE1")]
	[Address(RVA = "0x28D2530", Offset = "0x28D2530", VA = "0x28D2530")]
	private void ں٢ࡡ\u05EC()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BE2 RID: 3042 RVA: 0x0003F3E0 File Offset: 0x0003D5E0
	[Token(Token = "0x6000BE2")]
	[Address(RVA = "0x28D26FC", Offset = "0x28D26FC", VA = "0x28D26FC")]
	private void \u089Aࡆժߏ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BE3 RID: 3043 RVA: 0x0003F408 File Offset: 0x0003D608
	[Token(Token = "0x6000BE3")]
	[Address(RVA = "0x28D273C", Offset = "0x28D273C", VA = "0x28D273C")]
	private void ߠ\u07AAߚթ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BE4 RID: 3044 RVA: 0x0003F430 File Offset: 0x0003D630
	[Token(Token = "0x6000BE4")]
	[Address(RVA = "0x28D277C", Offset = "0x28D277C", VA = "0x28D277C")]
	private void յߪؾՀ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BE5 RID: 3045 RVA: 0x0003F4AC File Offset: 0x0003D6AC
	[Token(Token = "0x6000BE5")]
	[Address(RVA = "0x28D2948", Offset = "0x28D2948", VA = "0x28D2948")]
	private void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ࢱݺ٥ե(this);
	}

	// Token: 0x06000BE6 RID: 3046 RVA: 0x0003F4E0 File Offset: 0x0003D6E0
	[Token(Token = "0x6000BE6")]
	[Address(RVA = "0x28D2A18", Offset = "0x28D2A18", VA = "0x28D2A18")]
	private void ݤۅࢦӃ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BE7 RID: 3047 RVA: 0x0003F508 File Offset: 0x0003D708
	[Token(Token = "0x6000BE7")]
	[Address(RVA = "0x28D2A58", Offset = "0x28D2A58", VA = "0x28D2A58")]
	private void يօӇ\u070D(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ޢ\u05A8\u07FF\u0881(this);
	}

	// Token: 0x06000BE8 RID: 3048 RVA: 0x0003F534 File Offset: 0x0003D734
	[Token(Token = "0x6000BE8")]
	[Address(RVA = "0x28D2B28", Offset = "0x28D2B28", VA = "0x28D2B28")]
	private void ԗ\u05F9ҿ\u0834(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.\u0670\u06E6ښ\u0613(this);
	}

	// Token: 0x06000BE9 RID: 3049 RVA: 0x0003F568 File Offset: 0x0003D768
	[Token(Token = "0x6000BE9")]
	[Address(RVA = "0x28D2BF8", Offset = "0x28D2BF8", VA = "0x28D2BF8")]
	private void \u0882צ\u0821\u05B4()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BEA RID: 3050 RVA: 0x0003F590 File Offset: 0x0003D790
	[Token(Token = "0x6000BEA")]
	[Address(RVA = "0x28D2C38", Offset = "0x28D2C38", VA = "0x28D2C38")]
	private void ڃրӢԖ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BEB RID: 3051 RVA: 0x0003F60C File Offset: 0x0003D80C
	[Token(Token = "0x6000BEB")]
	[Address(RVA = "0x28D2E08", Offset = "0x28D2E08", VA = "0x28D2E08")]
	private void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ޢ\u05A8\u07FF\u0881(this);
	}

	// Token: 0x06000BEC RID: 3052 RVA: 0x0003F640 File Offset: 0x0003D840
	[Token(Token = "0x6000BEC")]
	[Address(RVA = "0x28D2ED8", Offset = "0x28D2ED8", VA = "0x28D2ED8")]
	private void \u0705خڃ\u059B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.\u0670\u06E6ښ\u0613(this);
	}

	// Token: 0x06000BED RID: 3053 RVA: 0x0003F674 File Offset: 0x0003D874
	[Token(Token = "0x6000BED")]
	[Address(RVA = "0x28D2FA8", Offset = "0x28D2FA8", VA = "0x28D2FA8")]
	private void ۆڛߟ\u05A0()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BEE RID: 3054 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000BEE")]
	[Address(RVA = "0x28D2FE8", Offset = "0x28D2FE8", VA = "0x28D2FE8")]
	private void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BEF RID: 3055 RVA: 0x0003F69C File Offset: 0x0003D89C
	[Token(Token = "0x6000BEF")]
	[Address(RVA = "0x28D30B8", Offset = "0x28D30B8", VA = "0x28D30B8")]
	private void Ջއٵյ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BF0 RID: 3056 RVA: 0x0003F6C4 File Offset: 0x0003D8C4
	[Token(Token = "0x6000BF0")]
	[Address(RVA = "0x28D30F8", Offset = "0x28D30F8", VA = "0x28D30F8")]
	private void ފԅ\u0881ݾ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		bool flag = \u07FEל\u05AC\u0877;
		this.װ٠\u05EDӒ.ࢱݺ٥ե(this);
	}

	// Token: 0x06000BF1 RID: 3057 RVA: 0x0003F6F8 File Offset: 0x0003D8F8
	[Token(Token = "0x6000BF1")]
	[Address(RVA = "0x28D31C8", Offset = "0x28D31C8", VA = "0x28D31C8")]
	private void ռտܙߗ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BF2 RID: 3058 RVA: 0x0003F720 File Offset: 0x0003D920
	[Token(Token = "0x6000BF2")]
	[Address(RVA = "0x28D3208", Offset = "0x28D3208", VA = "0x28D3208")]
	private void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ޢ\u05A8\u07FF\u0881(this);
	}

	// Token: 0x06000BF3 RID: 3059 RVA: 0x0003F754 File Offset: 0x0003D954
	[Token(Token = "0x6000BF3")]
	[Address(RVA = "0x28D32D8", Offset = "0x28D32D8", VA = "0x28D32D8")]
	private void څࡣڐ\u0657()
	{
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BF4 RID: 3060 RVA: 0x0003F7C8 File Offset: 0x0003D9C8
	[Token(Token = "0x6000BF4")]
	[Address(RVA = "0x28D34A4", Offset = "0x28D34A4", VA = "0x28D34A4")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BF5 RID: 3061 RVA: 0x0003F854 File Offset: 0x0003DA54
	[Token(Token = "0x6000BF5")]
	[Address(RVA = "0x28D3674", Offset = "0x28D3674", VA = "0x28D3674")]
	private void Start()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BF6 RID: 3062 RVA: 0x0003F87C File Offset: 0x0003DA7C
	[Token(Token = "0x6000BF6")]
	[Address(RVA = "0x28D36B4", Offset = "0x28D36B4", VA = "0x28D36B4")]
	private void \u081Dڵޕ\u0658()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BF7 RID: 3063 RVA: 0x0003F8F8 File Offset: 0x0003DAF8
	[Token(Token = "0x6000BF7")]
	[Address(RVA = "0x28D3880", Offset = "0x28D3880", VA = "0x28D3880")]
	private void եݚۆ\u0890(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.\u0670\u06E6ښ\u0613(this);
	}

	// Token: 0x06000BF8 RID: 3064 RVA: 0x0003F92C File Offset: 0x0003DB2C
	[Token(Token = "0x6000BF8")]
	[Address(RVA = "0x28D3950", Offset = "0x28D3950", VA = "0x28D3950")]
	private void ى߁ٱՏ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BF9 RID: 3065 RVA: 0x0003F9B8 File Offset: 0x0003DBB8
	[Token(Token = "0x6000BF9")]
	[Address(RVA = "0x28D3B20", Offset = "0x28D3B20", VA = "0x28D3B20")]
	private void \u05EDց\u081Cت()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BFA RID: 3066 RVA: 0x0003FA34 File Offset: 0x0003DC34
	[Token(Token = "0x6000BFA")]
	[Address(RVA = "0x28D3CEC", Offset = "0x28D3CEC", VA = "0x28D3CEC")]
	private void \u0599ږࠆ\u065F()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BFB RID: 3067 RVA: 0x0003FAC0 File Offset: 0x0003DCC0
	[Token(Token = "0x6000BFB")]
	[Address(RVA = "0x28D3EBC", Offset = "0x28D3EBC", VA = "0x28D3EBC")]
	private void \u0652\u058Bک\u061C()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BFC RID: 3068 RVA: 0x0003FAE8 File Offset: 0x0003DCE8
	[Token(Token = "0x6000BFC")]
	[Address(RVA = "0x28D3EFC", Offset = "0x28D3EFC", VA = "0x28D3EFC")]
	private void \u086Bԍࡊڭ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000BFD RID: 3069 RVA: 0x0003FB10 File Offset: 0x0003DD10
	[Token(Token = "0x6000BFD")]
	[Address(RVA = "0x28D3F3C", Offset = "0x28D3F3C", VA = "0x28D3F3C")]
	private void ࢺճ\u05A0ڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ޢ\u05A8\u07FF\u0881(this);
	}

	// Token: 0x06000BFE RID: 3070 RVA: 0x0003FB44 File Offset: 0x0003DD44
	[Token(Token = "0x6000BFE")]
	[Address(RVA = "0x28D400C", Offset = "0x28D400C", VA = "0x28D400C")]
	private void ݫࢷࠃ\u0820()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		GameObject u088Cԋݏ_u058F = this.ߠނࢤࢹ.\u088Cԋݏ\u058F;
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000BFF RID: 3071 RVA: 0x0003FBB8 File Offset: 0x0003DDB8
	[Token(Token = "0x6000BFF")]
	[Address(RVA = "0x28D41D8", Offset = "0x28D41D8", VA = "0x28D41D8")]
	private void ժ\u065Dԯࡘ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C00 RID: 3072 RVA: 0x0003FC44 File Offset: 0x0003DE44
	[Token(Token = "0x6000C00")]
	[Address(RVA = "0x28D43A8", Offset = "0x28D43A8", VA = "0x28D43A8")]
	private void \u05ABࡡ\u07ABݾ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C01 RID: 3073 RVA: 0x0003FCC0 File Offset: 0x0003DEC0
	[Token(Token = "0x6000C01")]
	[Address(RVA = "0x28D4574", Offset = "0x28D4574", VA = "0x28D4574")]
	private void \u07F5\u0657\u055Aߍ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C02 RID: 3074 RVA: 0x0003FD3C File Offset: 0x0003DF3C
	[Token(Token = "0x6000C02")]
	[Address(RVA = "0x28D4740", Offset = "0x28D4740", VA = "0x28D4740")]
	private void \u0829\u05FDژտ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C03 RID: 3075 RVA: 0x0003FDB8 File Offset: 0x0003DFB8
	[Token(Token = "0x6000C03")]
	[Address(RVA = "0x28D490C", Offset = "0x28D490C", VA = "0x28D490C")]
	private void ࡕߕ\u0707ݩ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C04 RID: 3076 RVA: 0x0003FE34 File Offset: 0x0003E034
	[Token(Token = "0x6000C04")]
	[Address(RVA = "0x28D4AD8", Offset = "0x28D4AD8", VA = "0x28D4AD8")]
	private void ә\u0730\u0839\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ࢱݺ٥ե(this);
	}

	// Token: 0x06000C05 RID: 3077 RVA: 0x0003FE68 File Offset: 0x0003E068
	[Token(Token = "0x6000C05")]
	[Address(RVA = "0x28D4BA8", Offset = "0x28D4BA8", VA = "0x28D4BA8")]
	private void ݞߒࢸڢ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C06 RID: 3078 RVA: 0x0003FEE4 File Offset: 0x0003E0E4
	[Token(Token = "0x6000C06")]
	[Address(RVA = "0x28D4D74", Offset = "0x28D4D74", VA = "0x28D4D74")]
	private void Ԡݘעࠀ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C07 RID: 3079 RVA: 0x0003FF60 File Offset: 0x0003E160
	[Token(Token = "0x6000C07")]
	[Address(RVA = "0x28D4F40", Offset = "0x28D4F40", VA = "0x28D4F40")]
	private void ڄ߃ԇӶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ޢ\u05A8\u07FF\u0881(this);
	}

	// Token: 0x06000C08 RID: 3080 RVA: 0x0003FF94 File Offset: 0x0003E194
	[Token(Token = "0x6000C08")]
	[Address(RVA = "0x28D5010", Offset = "0x28D5010", VA = "0x28D5010")]
	private void \u073Bݲձݕ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C09 RID: 3081 RVA: 0x0003FFBC File Offset: 0x0003E1BC
	[Token(Token = "0x6000C09")]
	[Address(RVA = "0x28D5050", Offset = "0x28D5050", VA = "0x28D5050")]
	private void \u066A\u059Eټ\u085A()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C0A RID: 3082 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C0A")]
	[Address(RVA = "0x28D5090", Offset = "0x28D5090", VA = "0x28D5090")]
	private void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C0B RID: 3083 RVA: 0x0003FFE4 File Offset: 0x0003E1E4
	[Token(Token = "0x6000C0B")]
	[Address(RVA = "0x28D5160", Offset = "0x28D5160", VA = "0x28D5160")]
	private void \u058EԸس\u0819()
	{
		string name = base.gameObject.name;
	}

	// Token: 0x06000C0C RID: 3084 RVA: 0x00040004 File Offset: 0x0003E204
	[Token(Token = "0x6000C0C")]
	[Address(RVA = "0x28D51A0", Offset = "0x28D51A0", VA = "0x28D51A0")]
	private void ݶߔ\u081Aպ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C0D RID: 3085 RVA: 0x0004002C File Offset: 0x0003E22C
	[Token(Token = "0x6000C0D")]
	[Address(RVA = "0x28D51E0", Offset = "0x28D51E0", VA = "0x28D51E0")]
	private void \u07FE\u0882Զ\u066D()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C0E RID: 3086 RVA: 0x000400B8 File Offset: 0x0003E2B8
	[Token(Token = "0x6000C0E")]
	[Address(RVA = "0x28D53B0", Offset = "0x28D53B0", VA = "0x28D53B0")]
	private void \u07B4\u0594ԁڇ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ޢ\u05A8\u07FF\u0881(this);
	}

	// Token: 0x06000C0F RID: 3087 RVA: 0x000400EC File Offset: 0x0003E2EC
	[Token(Token = "0x6000C0F")]
	[Address(RVA = "0x28D5480", Offset = "0x28D5480", VA = "0x28D5480")]
	private void \u05C8\u05BFࠁف()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C10 RID: 3088 RVA: 0x00040114 File Offset: 0x0003E314
	[Token(Token = "0x6000C10")]
	[Address(RVA = "0x28D54C0", Offset = "0x28D54C0", VA = "0x28D54C0")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C11 RID: 3089 RVA: 0x000401A0 File Offset: 0x0003E3A0
	[Token(Token = "0x6000C11")]
	[Address(RVA = "0x28D5690", Offset = "0x28D5690", VA = "0x28D5690")]
	private void \u085Dۍ\u0659Ӂ()
	{
		if (!true)
		{
		}
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent.\u088Cԋݏ\u058F;
		if (dynamicParent == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C12 RID: 3090 RVA: 0x00040210 File Offset: 0x0003E410
	[Token(Token = "0x6000C12")]
	[Address(RVA = "0x28D585C", Offset = "0x28D585C", VA = "0x28D585C")]
	private void ԣԭՋࠏ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C13 RID: 3091 RVA: 0x0004028C File Offset: 0x0003E48C
	[Token(Token = "0x6000C13")]
	[Address(RVA = "0x28D5A28", Offset = "0x28D5A28", VA = "0x28D5A28")]
	private void \u0590\u0882\u0883ࡦ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		if (num == 0L)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C14 RID: 3092 RVA: 0x000402F4 File Offset: 0x0003E4F4
	[Token(Token = "0x6000C14")]
	[Address(RVA = "0x28D5BF4", Offset = "0x28D5BF4", VA = "0x28D5BF4")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if ("IsLowSurrogates" == null)
		{
		}
		GameObject u088Cԋݏ_u058F = this.ߠނࢤࢹ.\u088Cԋݏ\u058F;
		if ("IsLowSurrogates" == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C15 RID: 3093 RVA: 0x00040374 File Offset: 0x0003E574
	[Token(Token = "0x6000C15")]
	[Address(RVA = "0x28D5DC0", Offset = "0x28D5DC0", VA = "0x28D5DC0")]
	private void ڷԲ\u0618ރ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C16 RID: 3094 RVA: 0x000403F0 File Offset: 0x0003E5F0
	[Token(Token = "0x6000C16")]
	[Address(RVA = "0x28D5F8C", Offset = "0x28D5F8C", VA = "0x28D5F8C")]
	private void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ޢ\u05A8\u07FF\u0881(this);
	}

	// Token: 0x06000C17 RID: 3095 RVA: 0x00040424 File Offset: 0x0003E624
	[Token(Token = "0x6000C17")]
	[Address(RVA = "0x28D605C", Offset = "0x28D605C", VA = "0x28D605C")]
	private void \u0821\u059Fӕ\u0607()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		if (num == 0L)
		{
		}
	}

	// Token: 0x06000C18 RID: 3096 RVA: 0x00040440 File Offset: 0x0003E640
	[Token(Token = "0x6000C18")]
	[Address(RVA = "0x28D622C", Offset = "0x28D622C", VA = "0x28D622C")]
	private void \u070Aәޣے()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C19 RID: 3097 RVA: 0x000404CC File Offset: 0x0003E6CC
	[Token(Token = "0x6000C19")]
	[Address(RVA = "0x28D63FC", Offset = "0x28D63FC", VA = "0x28D63FC")]
	private void \u0732ڙԒࢺ()
	{
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if ("IsLowSurrogates" == null)
		{
		}
		GameObject u088Cԋݏ_u058F = this.ߠނࢤࢹ.\u088Cԋݏ\u058F;
		if ("IsLowSurrogates" == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C1A RID: 3098 RVA: 0x0004054C File Offset: 0x0003E74C
	[Token(Token = "0x6000C1A")]
	[Address(RVA = "0x28D65C8", Offset = "0x28D65C8", VA = "0x28D65C8")]
	private void ߖհݣ߀()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C1B RID: 3099 RVA: 0x00040574 File Offset: 0x0003E774
	[Token(Token = "0x6000C1B")]
	[Address(RVA = "0x28D6608", Offset = "0x28D6608", VA = "0x28D6608")]
	private void ճ\u0828Ԓհ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ޢ\u05A8\u07FF\u0881(this);
	}

	// Token: 0x06000C1C RID: 3100 RVA: 0x000405A8 File Offset: 0x0003E7A8
	[Token(Token = "0x6000C1C")]
	[Address(RVA = "0x28D66D8", Offset = "0x28D66D8", VA = "0x28D66D8")]
	private void \u065D\u070Aٶࢰ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C1D RID: 3101 RVA: 0x000405D0 File Offset: 0x0003E7D0
	[Token(Token = "0x6000C1D")]
	[Address(RVA = "0x28D6718", Offset = "0x28D6718", VA = "0x28D6718")]
	private void ߓ\u06E3\u05C7ۋ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C1E RID: 3102 RVA: 0x000405F8 File Offset: 0x0003E7F8
	[Token(Token = "0x6000C1E")]
	[Address(RVA = "0x28D6758", Offset = "0x28D6758", VA = "0x28D6758")]
	private void ۿࢹ\u0705\u0825()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C1F RID: 3103 RVA: 0x00040620 File Offset: 0x0003E820
	[Token(Token = "0x6000C1F")]
	[Address(RVA = "0x28D6798", Offset = "0x28D6798", VA = "0x28D6798")]
	private void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ࢱݺ٥ե(this);
	}

	// Token: 0x06000C20 RID: 3104 RVA: 0x00040654 File Offset: 0x0003E854
	[Token(Token = "0x6000C20")]
	[Address(RVA = "0x28D6868", Offset = "0x28D6868", VA = "0x28D6868")]
	private void Ԯ\u0883\u0591\u066C()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C21 RID: 3105 RVA: 0x0004067C File Offset: 0x0003E87C
	[Token(Token = "0x6000C21")]
	[Address(RVA = "0x28D68A8", Offset = "0x28D68A8", VA = "0x28D68A8")]
	private void ԟ\u086Cޣ\u055E()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C22 RID: 3106 RVA: 0x00040708 File Offset: 0x0003E908
	[Token(Token = "0x6000C22")]
	[Address(RVA = "0x28D6A78", Offset = "0x28D6A78", VA = "0x28D6A78")]
	private void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ࢱݺ٥ե(this);
	}

	// Token: 0x06000C23 RID: 3107 RVA: 0x0004073C File Offset: 0x0003E93C
	[Token(Token = "0x6000C23")]
	[Address(RVA = "0x28D6B48", Offset = "0x28D6B48", VA = "0x28D6B48")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C24 RID: 3108 RVA: 0x000407C8 File Offset: 0x0003E9C8
	[Token(Token = "0x6000C24")]
	[Address(RVA = "0x28D6D18", Offset = "0x28D6D18", VA = "0x28D6D18")]
	private void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ޢ\u05A8\u07FF\u0881(this);
	}

	// Token: 0x06000C25 RID: 3109 RVA: 0x000407FC File Offset: 0x0003E9FC
	[Token(Token = "0x6000C25")]
	[Address(RVA = "0x28D6DE8", Offset = "0x28D6DE8", VA = "0x28D6DE8")]
	private void ࢢ٧\u085DԀ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.\u0670\u06E6ښ\u0613(this);
	}

	// Token: 0x06000C26 RID: 3110 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C26")]
	[Address(RVA = "0x28D6EB8", Offset = "0x28D6EB8", VA = "0x28D6EB8")]
	private void \u0884ٿ\u0659ԫ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C27 RID: 3111 RVA: 0x00040830 File Offset: 0x0003EA30
	[Token(Token = "0x6000C27")]
	[Address(RVA = "0x28D6F88", Offset = "0x28D6F88", VA = "0x28D6F88")]
	private void ٠ӄ\u087Cٸ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C28 RID: 3112 RVA: 0x000408B8 File Offset: 0x0003EAB8
	[Token(Token = "0x6000C28")]
	[Address(RVA = "0x28D7158", Offset = "0x28D7158", VA = "0x28D7158")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C29 RID: 3113 RVA: 0x00040934 File Offset: 0x0003EB34
	[Token(Token = "0x6000C29")]
	[Address(RVA = "0x28D7324", Offset = "0x28D7324", VA = "0x28D7324")]
	private void פۈيݤ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C2A RID: 3114 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000C2A")]
	[Address(RVA = "0x28D74F0", Offset = "0x28D74F0", VA = "0x28D74F0")]
	private void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C2B RID: 3115 RVA: 0x000409B0 File Offset: 0x0003EBB0
	[Token(Token = "0x6000C2B")]
	[Address(RVA = "0x28D75C0", Offset = "0x28D75C0", VA = "0x28D75C0")]
	private void ד\u073C\u0613چ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C2C RID: 3116 RVA: 0x00040A2C File Offset: 0x0003EC2C
	[Token(Token = "0x6000C2C")]
	[Address(RVA = "0x28D778C", Offset = "0x28D778C", VA = "0x28D778C")]
	private void ڈՓ\u0652\u0871()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics װ٠_u05EDӒ = this.װ٠\u05EDӒ;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C2D RID: 3117 RVA: 0x00040AB0 File Offset: 0x0003ECB0
	[Token(Token = "0x6000C2D")]
	[Address(RVA = "0x28D795C", Offset = "0x28D795C", VA = "0x28D795C")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C2E RID: 3118 RVA: 0x00040AD8 File Offset: 0x0003ECD8
	[Token(Token = "0x6000C2E")]
	[Address(RVA = "0x28D799C", Offset = "0x28D799C", VA = "0x28D799C")]
	private void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.\u0670\u06E6ښ\u0613(this);
	}

	// Token: 0x06000C2F RID: 3119 RVA: 0x00040B0C File Offset: 0x0003ED0C
	[Token(Token = "0x6000C2F")]
	[Address(RVA = "0x28D7A6C", Offset = "0x28D7A6C", VA = "0x28D7A6C")]
	private void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.\u0670\u06E6ښ\u0613(this);
	}

	// Token: 0x06000C30 RID: 3120 RVA: 0x00040B40 File Offset: 0x0003ED40
	[Token(Token = "0x6000C30")]
	[Address(RVA = "0x28D7B3C", Offset = "0x28D7B3C", VA = "0x28D7B3C")]
	private void \u0739߉ڵݞ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C31 RID: 3121 RVA: 0x00040B68 File Offset: 0x0003ED68
	[Token(Token = "0x6000C31")]
	[Address(RVA = "0x28D7B7C", Offset = "0x28D7B7C", VA = "0x28D7B7C")]
	private void ޥ\u089Dڢ\u06E3()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C32 RID: 3122 RVA: 0x00040B90 File Offset: 0x0003ED90
	[Token(Token = "0x6000C32")]
	[Address(RVA = "0x28D7BBC", Offset = "0x28D7BBC", VA = "0x28D7BBC")]
	private void ݱ\u0832ݥ\u08B5()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C33 RID: 3123 RVA: 0x00040BB8 File Offset: 0x0003EDB8
	[Token(Token = "0x6000C33")]
	[Address(RVA = "0x28D7BFC", Offset = "0x28D7BFC", VA = "0x28D7BFC")]
	private void ࢫ\u0876չՍ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C34 RID: 3124 RVA: 0x00040C34 File Offset: 0x0003EE34
	[Token(Token = "0x6000C34")]
	[Address(RVA = "0x28D7DC8", Offset = "0x28D7DC8", VA = "0x28D7DC8")]
	private void ߁\u0829\u073E\u081A()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C35 RID: 3125 RVA: 0x00040C5C File Offset: 0x0003EE5C
	[Token(Token = "0x6000C35")]
	[Address(RVA = "0x28D7E08", Offset = "0x28D7E08", VA = "0x28D7E08")]
	private void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.\u0670\u06E6ښ\u0613(this);
	}

	// Token: 0x06000C36 RID: 3126 RVA: 0x00040C90 File Offset: 0x0003EE90
	[Token(Token = "0x6000C36")]
	[Address(RVA = "0x28D7ED8", Offset = "0x28D7ED8", VA = "0x28D7ED8")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ࢱݺ٥ե(this);
	}

	// Token: 0x06000C37 RID: 3127 RVA: 0x00040CC4 File Offset: 0x0003EEC4
	[Token(Token = "0x6000C37")]
	[Address(RVA = "0x28D7FA8", Offset = "0x28D7FA8", VA = "0x28D7FA8")]
	public DynamicCosmeticsButton()
	{
	}

	// Token: 0x06000C38 RID: 3128 RVA: 0x00040CD8 File Offset: 0x0003EED8
	[Token(Token = "0x6000C38")]
	[Address(RVA = "0x28D7FB0", Offset = "0x28D7FB0", VA = "0x28D7FB0")]
	private void ߗࠊ\u05CAܝ()
	{
		string name = base.gameObject.name;
		this.\u061Aոԕע = name;
	}

	// Token: 0x06000C39 RID: 3129 RVA: 0x00040D00 File Offset: 0x0003EF00
	[Token(Token = "0x6000C39")]
	[Address(RVA = "0x28D7FF0", Offset = "0x28D7FF0", VA = "0x28D7FF0")]
	private void Ӧد\u060Eࡏ()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		DynamicCosmetics װ٠_u05EDӒ = this.װ٠\u05EDӒ;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C3A RID: 3130 RVA: 0x00040D78 File Offset: 0x0003EF78
	[Token(Token = "0x6000C3A")]
	[Address(RVA = "0x28D81BC", Offset = "0x28D81BC", VA = "0x28D81BC")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
		long num = 1L;
		DynamicParent dynamicParent = this.ߠނࢤࢹ;
		if (num == 0L)
		{
		}
		DynamicParent dynamicParent2 = this.ߠނࢤࢹ;
		GameObject u088Cԋݏ_u058F = dynamicParent2.\u088Cԋݏ\u058F;
		if (dynamicParent2 == null)
		{
		}
		List<DynamicCosmetics.CosmeticItem> ݜߍٴע = this.װ٠\u05EDӒ.ݜߍٴע;
		string name = this.ߠނࢤࢹ.\u088Cԋݏ\u058F.name;
		DynamicCosmetics.ԟ\u0825\u07EF߅ u05B0Ӄ_u081D_u07A = this.װ٠\u05EDӒ.\u05B0Ӄ\u081D\u07A7;
		TMP_Text u05A8ޖޔ_u = this.\u05A8ޖޔ\u0891;
	}

	// Token: 0x06000C3B RID: 3131 RVA: 0x00040DF0 File Offset: 0x0003EFF0
	[Token(Token = "0x6000C3B")]
	[Address(RVA = "0x28D8388", Offset = "0x28D8388", VA = "0x28D8388")]
	private void ے\u059Fࢰس(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<HandColliders>();
		this.װ٠\u05EDӒ.ࢱݺ٥ե(this);
	}

	// Token: 0x040001BC RID: 444
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001BC")]
	public TMP_Text \u05A8ޖޔ\u0891;

	// Token: 0x040001BD RID: 445
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001BD")]
	[HideInInspector]
	public string \u061Aոԕע;

	// Token: 0x040001BE RID: 446
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001BE")]
	public DynamicParent ߠނࢤࢹ;

	// Token: 0x040001BF RID: 447
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40001BF")]
	[HideInInspector]
	public bool \u0593գࢡӼ;

	// Token: 0x040001C0 RID: 448
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40001C0")]
	public DynamicCosmetics װ٠\u05EDӒ;
}
