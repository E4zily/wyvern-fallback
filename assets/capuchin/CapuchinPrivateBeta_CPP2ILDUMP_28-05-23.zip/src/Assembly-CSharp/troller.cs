﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000FE RID: 254
[Token(Token = "0x20000FE")]
public class troller : MonoBehaviour
{
	// Token: 0x0600275E RID: 10078 RVA: 0x000E5690 File Offset: 0x000E3890
	[Token(Token = "0x600275E")]
	[Address(RVA = "0x2120154", Offset = "0x2120154", VA = "0x2120154")]
	public void \u06EAӠՑ\u05BF(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		long minInclusive = -125L;
		long maxExclusive = 1L;
		int num = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		int minInclusive2 = 86;
		long maxExclusive2 = 2L;
		int num2 = UnityEngine.Random.Range(minInclusive2, (int)maxExclusive2);
	}

	// Token: 0x0600275F RID: 10079 RVA: 0x000E56EC File Offset: 0x000E38EC
	[Token(Token = "0x600275F")]
	[Address(RVA = "0x2120288", Offset = "0x2120288", VA = "0x2120288")]
	public void \u05B8\u0610ۯ\u06DD(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		int minInclusive = 58;
		long maxExclusive = 1L;
		int minInclusive2 = UnityEngine.Random.Range(minInclusive, (int)maxExclusive);
		long maxExclusive2 = 1L;
		int num = UnityEngine.Random.Range(minInclusive2, (int)maxExclusive2);
	}

	// Token: 0x06002760 RID: 10080 RVA: 0x000E5744 File Offset: 0x000E3944
	[Token(Token = "0x6002760")]
	[Address(RVA = "0x21203BC", Offset = "0x21203BC", VA = "0x21203BC")]
	public void مլԙ\u05BC(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		long maxExclusive = 2L;
		int minInclusive;
		int num = UnityEngine.Random.Range(minInclusive, (int)maxExclusive);
	}

	// Token: 0x06002761 RID: 10081 RVA: 0x000E578C File Offset: 0x000E398C
	[Token(Token = "0x6002761")]
	[Address(RVA = "0x21204EC", Offset = "0x21204EC", VA = "0x21204EC")]
	public void \u05A4ࢧՂ\u06DD(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		int minInclusive = 115;
		long maxExclusive = 2L;
		int minInclusive2 = UnityEngine.Random.Range(minInclusive, (int)maxExclusive);
		int maxExclusive2 = 5;
		int num = UnityEngine.Random.Range(minInclusive2, maxExclusive2);
	}

	// Token: 0x06002762 RID: 10082 RVA: 0x000E57E4 File Offset: 0x000E39E4
	[Token(Token = "0x6002762")]
	[Address(RVA = "0x2120620", Offset = "0x2120620", VA = "0x2120620")]
	[PunRPC]
	public void Fling(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		long minInclusive = -5L;
		int maxExclusive = 5;
		int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
		long minInclusive2 = -5L;
		int maxExclusive2 = 5;
		int num2 = UnityEngine.Random.Range((int)minInclusive2, maxExclusive2);
	}

	// Token: 0x06002763 RID: 10083 RVA: 0x000E5840 File Offset: 0x000E3A40
	[Token(Token = "0x6002763")]
	[Address(RVA = "0x2120750", Offset = "0x2120750", VA = "0x2120750")]
	public troller()
	{
	}

	// Token: 0x06002764 RID: 10084 RVA: 0x000E5854 File Offset: 0x000E3A54
	[Token(Token = "0x6002764")]
	[Address(RVA = "0x2120758", Offset = "0x2120758", VA = "0x2120758")]
	public void ܩࠔ\u05C2ޝ(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		long maxExclusive = 2L;
		int minInclusive;
		int num = UnityEngine.Random.Range(minInclusive, (int)maxExclusive);
	}

	// Token: 0x06002765 RID: 10085 RVA: 0x000E589C File Offset: 0x000E3A9C
	[Token(Token = "0x6002765")]
	[Address(RVA = "0x2120888", Offset = "0x2120888", VA = "0x2120888")]
	public void Ւ\u074Aࢨࡤ(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		long maxExclusive = 6L;
		int num = UnityEngine.Random.Range(0, (int)maxExclusive);
	}

	// Token: 0x06002766 RID: 10086 RVA: 0x000E58E4 File Offset: 0x000E3AE4
	[Token(Token = "0x6002766")]
	[Address(RVA = "0x21209BC", Offset = "0x21209BC", VA = "0x21209BC")]
	public void ځࢣ۹ӄ(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		int minInclusive = 98;
		long maxExclusive = 6L;
		int num = UnityEngine.Random.Range(minInclusive, (int)maxExclusive);
		int minInclusive2 = 73;
		long maxExclusive2 = 3L;
		int num2 = UnityEngine.Random.Range(minInclusive2, (int)maxExclusive2);
	}

	// Token: 0x06002767 RID: 10087 RVA: 0x000E5940 File Offset: 0x000E3B40
	[Token(Token = "0x6002767")]
	[Address(RVA = "0x2120AF0", Offset = "0x2120AF0", VA = "0x2120AF0")]
	public void \u066Cࡒࠒރ(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		long minInclusive = 6L;
		long maxExclusive = 3L;
		int num = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
	}

	// Token: 0x06002768 RID: 10088 RVA: 0x000E598C File Offset: 0x000E3B8C
	[Token(Token = "0x6002768")]
	[Address(RVA = "0x2120C24", Offset = "0x2120C24", VA = "0x2120C24")]
	public void ݟ\u0732ٹ۵(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		long minInclusive = 15L;
		long maxExclusive = 2L;
		int num = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		long minInclusive2 = 12L;
		long maxExclusive2 = 7L;
		int num2 = UnityEngine.Random.Range((int)minInclusive2, (int)maxExclusive2);
	}

	// Token: 0x06002769 RID: 10089 RVA: 0x000E59E8 File Offset: 0x000E3BE8
	[Token(Token = "0x6002769")]
	[Address(RVA = "0x2120D54", Offset = "0x2120D54", VA = "0x2120D54")]
	public void ފ٧ք\u0822(string ࠔؼࡏݥ, float ݣԄ\u085E\u05B7)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool flag = PhotonNetwork.LocalPlayer.nickName == ࠔؼࡏݥ;
		Vector3 position = this.\u06EA\u0530\u07BE\u083F.position;
		long minInclusive = 48L;
		long maxExclusive = 2L;
		int num = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		int minInclusive2 = 27;
		long maxExclusive2 = 6L;
		int num2 = UnityEngine.Random.Range(minInclusive2, (int)maxExclusive2);
	}

	// Token: 0x040004FF RID: 1279
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004FF")]
	public Rigidbody \u06EA\u0530\u07BE\u083F;

	// Token: 0x04000500 RID: 1280
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000500")]
	public GameObject \u07FC\u0703\u05AE߀;

	// Token: 0x04000501 RID: 1281
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000501")]
	public PhotonView Ӆ\u07A6ࡓ\u086D;
}
