﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200000D RID: 13
[Token(Token = "0x200000D")]
public class References : MonoBehaviour
{
	// Token: 0x060001F8 RID: 504 RVA: 0x0001076C File Offset: 0x0000E96C
	[Token(Token = "0x60001F8")]
	[Address(RVA = "0x2FA63F4", Offset = "0x2FA63F4", VA = "0x2FA63F4")]
	public References()
	{
	}

	// Token: 0x0400003B RID: 59
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400003B")]
	public TagManager ޠӦ\u073B\u0741;

	// Token: 0x0400003C RID: 60
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400003C")]
	public PhotonView \u06EBسىڙ;
}
