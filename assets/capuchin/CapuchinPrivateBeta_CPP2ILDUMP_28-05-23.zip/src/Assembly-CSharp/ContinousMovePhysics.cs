﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200008C RID: 140
[Token(Token = "0x200008C")]
public class ContinousMovePhysics : MonoBehaviour
{
	// Token: 0x060014A0 RID: 5280 RVA: 0x000748E0 File Offset: 0x00072AE0
	[Token(Token = "0x60014A0")]
	[Address(RVA = "0x2936F04", Offset = "0x2936F04", VA = "0x2936F04")]
	private void \u0599ږࠆ\u065F()
	{
	}

	// Token: 0x060014A1 RID: 5281 RVA: 0x000748F0 File Offset: 0x00072AF0
	[Token(Token = "0x60014A1")]
	[Address(RVA = "0x2936F08", Offset = "0x2936F08", VA = "0x2936F08")]
	private void \u0608\u0598կص()
	{
		long num = 1L;
		bool flag = this.ߙ\u05B1\u0596ժ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014A2 RID: 5282 RVA: 0x00074940 File Offset: 0x00072B40
	[Token(Token = "0x60014A2")]
	[Address(RVA = "0x29371A0", Offset = "0x29371A0", VA = "0x29371A0")]
	private void ݸԲ\u0616Ԫ()
	{
	}

	// Token: 0x060014A3 RID: 5283 RVA: 0x00074950 File Offset: 0x00072B50
	[Token(Token = "0x60014A3")]
	[Address(RVA = "0x29371A4", Offset = "0x29371A4", VA = "0x29371A4")]
	public bool ӢԨشԯ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014A4 RID: 5284 RVA: 0x000749BC File Offset: 0x00072BBC
	[Token(Token = "0x60014A4")]
	[Address(RVA = "0x29372E8", Offset = "0x29372E8", VA = "0x29372E8")]
	private void ۀ߅Ա\u0654()
	{
		long num = 1L;
		bool flag = this.ӞހࡢԳ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014A5 RID: 5285 RVA: 0x00074A0C File Offset: 0x00072C0C
	[Token(Token = "0x60014A5")]
	[Address(RVA = "0x2937580", Offset = "0x2937580", VA = "0x2937580")]
	private void ߑ\u0885\u05BBߕ()
	{
	}

	// Token: 0x060014A6 RID: 5286 RVA: 0x00074A1C File Offset: 0x00072C1C
	[Token(Token = "0x60014A6")]
	[Address(RVA = "0x2937584", Offset = "0x2937584", VA = "0x2937584")]
	private void ۰\u087DՂ\u085F()
	{
		long num = 1L;
		bool flag = this.Լػԁڒ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014A7 RID: 5287 RVA: 0x00074A6C File Offset: 0x00072C6C
	[Token(Token = "0x60014A7")]
	[Address(RVA = "0x2937818", Offset = "0x2937818", VA = "0x2937818")]
	private void Ԯ\u0883\u0591\u066C()
	{
	}

	// Token: 0x060014A8 RID: 5288 RVA: 0x00074A7C File Offset: 0x00072C7C
	[Token(Token = "0x60014A8")]
	[Address(RVA = "0x293781C", Offset = "0x293781C", VA = "0x293781C")]
	public bool ښ\u0890\u05C7ߐ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014A9 RID: 5289 RVA: 0x00074AE8 File Offset: 0x00072CE8
	[Token(Token = "0x60014A9")]
	[Address(RVA = "0x2937960", Offset = "0x2937960", VA = "0x2937960")]
	private void \u0654ޛ\u07FAذ()
	{
	}

	// Token: 0x060014AA RID: 5290 RVA: 0x00074AF8 File Offset: 0x00072CF8
	[Token(Token = "0x60014AA")]
	[Address(RVA = "0x2937964", Offset = "0x2937964", VA = "0x2937964")]
	private void \u07F7ܙײ\u05B5()
	{
	}

	// Token: 0x060014AB RID: 5291 RVA: 0x00074B08 File Offset: 0x00072D08
	[Token(Token = "0x60014AB")]
	[Address(RVA = "0x2937968", Offset = "0x2937968", VA = "0x2937968")]
	public ContinousMovePhysics()
	{
		long u05B9ߎܩ_u = 1065353216L;
		this.\u05B9ߎܩ\u0613 = (float)u05B9ߎܩ_u;
		base..ctor();
	}

	// Token: 0x060014AC RID: 5292 RVA: 0x00074B28 File Offset: 0x00072D28
	[Token(Token = "0x60014AC")]
	[Address(RVA = "0x2937978", Offset = "0x2937978", VA = "0x2937978")]
	private void \u0652\u058Bک\u061C()
	{
	}

	// Token: 0x060014AD RID: 5293 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014AD")]
	[Address(RVA = "0x293797C", Offset = "0x293797C", VA = "0x293797C")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014AE RID: 5294 RVA: 0x00074B38 File Offset: 0x00072D38
	[Token(Token = "0x60014AE")]
	[Address(RVA = "0x2937A78", Offset = "0x2937A78", VA = "0x2937A78")]
	private void \u0881ݗӟ\u07BD()
	{
	}

	// Token: 0x060014AF RID: 5295 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014AF")]
	[Address(RVA = "0x2937A7C", Offset = "0x2937A7C", VA = "0x2937A7C")]
	public void Ԯԇݯԃ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014B0 RID: 5296 RVA: 0x00074B48 File Offset: 0x00072D48
	[Token(Token = "0x60014B0")]
	[Address(RVA = "0x2937B78", Offset = "0x2937B78", VA = "0x2937B78")]
	public bool Ӈڦࠊݼ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014B1 RID: 5297 RVA: 0x00074BB4 File Offset: 0x00072DB4
	[Token(Token = "0x60014B1")]
	[Address(RVA = "0x2937CBC", Offset = "0x2937CBC", VA = "0x2937CBC")]
	public bool ӗ۱םކ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014B2 RID: 5298 RVA: 0x00074C20 File Offset: 0x00072E20
	[Token(Token = "0x60014B2")]
	[Address(RVA = "0x2937E00", Offset = "0x2937E00", VA = "0x2937E00")]
	private void Update()
	{
	}

	// Token: 0x060014B3 RID: 5299 RVA: 0x00074C30 File Offset: 0x00072E30
	[Token(Token = "0x60014B3")]
	[Address(RVA = "0x2937E04", Offset = "0x2937E04", VA = "0x2937E04")]
	private void ԟ\u086Cޣ\u055E()
	{
	}

	// Token: 0x060014B4 RID: 5300 RVA: 0x00074C40 File Offset: 0x00072E40
	[Token(Token = "0x60014B4")]
	[Address(RVA = "0x2937E08", Offset = "0x2937E08", VA = "0x2937E08")]
	private void Ҿࢹؼס()
	{
	}

	// Token: 0x060014B5 RID: 5301 RVA: 0x00074C50 File Offset: 0x00072E50
	[Token(Token = "0x60014B5")]
	[Address(RVA = "0x2937E0C", Offset = "0x2937E0C", VA = "0x2937E0C")]
	private void ߄Ӄ\u0613ھ()
	{
	}

	// Token: 0x060014B6 RID: 5302 RVA: 0x00074C60 File Offset: 0x00072E60
	[Token(Token = "0x60014B6")]
	[Address(RVA = "0x2937E10", Offset = "0x2937E10", VA = "0x2937E10")]
	private void ԣ\u0731\u0879ܕ()
	{
		long num = 1L;
		bool flag = this.\u086Cׯڸպ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014B7 RID: 5303 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014B7")]
	[Address(RVA = "0x29380A8", Offset = "0x29380A8", VA = "0x29380A8")]
	public void Ӄ\u07BAࡌՅ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014B8 RID: 5304 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014B8")]
	[Address(RVA = "0x29381B0", Offset = "0x29381B0", VA = "0x29381B0")]
	public void \u081Cߌ\u0876Բ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014B9 RID: 5305 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014B9")]
	[Address(RVA = "0x29382AC", Offset = "0x29382AC", VA = "0x29382AC")]
	public void \u0603\u0593\u05B3\u0886()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014BA RID: 5306 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014BA")]
	[Address(RVA = "0x29383A8", Offset = "0x29383A8", VA = "0x29383A8")]
	public void ࡖקӒݾ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014BB RID: 5307 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014BB")]
	[Address(RVA = "0x29384B0", Offset = "0x29384B0", VA = "0x29384B0")]
	public void ӭࡢࢬ\u0703()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014BC RID: 5308 RVA: 0x00074CB0 File Offset: 0x00072EB0
	[Token(Token = "0x60014BC")]
	[Address(RVA = "0x29385AC", Offset = "0x29385AC", VA = "0x29385AC")]
	private void ޤ\u0610\u087A\u05AF()
	{
		long num = 1L;
		bool flag = this.ӢԨشԯ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014BD RID: 5309 RVA: 0x00074D00 File Offset: 0x00072F00
	[Token(Token = "0x60014BD")]
	[Address(RVA = "0x2938700", Offset = "0x2938700", VA = "0x2938700")]
	private void \u07F5\u0657\u055Aߍ()
	{
	}

	// Token: 0x060014BE RID: 5310 RVA: 0x00074D10 File Offset: 0x00072F10
	[Token(Token = "0x60014BE")]
	[Address(RVA = "0x2938704", Offset = "0x2938704", VA = "0x2938704")]
	private void ࠏޤݳ\u06DD()
	{
	}

	// Token: 0x060014BF RID: 5311 RVA: 0x00074D20 File Offset: 0x00072F20
	[Token(Token = "0x60014BF")]
	[Address(RVA = "0x2938708", Offset = "0x2938708", VA = "0x2938708")]
	private void طӏܙࢺ()
	{
	}

	// Token: 0x060014C0 RID: 5312 RVA: 0x00074D30 File Offset: 0x00072F30
	[Token(Token = "0x60014C0")]
	[Address(RVA = "0x293870C", Offset = "0x293870C", VA = "0x293870C")]
	public bool ܯӞ߅ࠓ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014C1 RID: 5313 RVA: 0x00074D9C File Offset: 0x00072F9C
	[Token(Token = "0x60014C1")]
	[Address(RVA = "0x2938850", Offset = "0x2938850", VA = "0x2938850")]
	public bool ڬءӜپ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014C2 RID: 5314 RVA: 0x00074E08 File Offset: 0x00073008
	[Token(Token = "0x60014C2")]
	[Address(RVA = "0x2938994", Offset = "0x2938994", VA = "0x2938994")]
	public bool ߖٸ\u0595\u0604()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014C3 RID: 5315 RVA: 0x00074E74 File Offset: 0x00073074
	[Token(Token = "0x60014C3")]
	[Address(RVA = "0x2938AD8", Offset = "0x2938AD8", VA = "0x2938AD8")]
	private void \u0821\u059Fӕ\u0607()
	{
	}

	// Token: 0x060014C4 RID: 5316 RVA: 0x00074E84 File Offset: 0x00073084
	[Token(Token = "0x60014C4")]
	[Address(RVA = "0x2938ADC", Offset = "0x2938ADC", VA = "0x2938ADC")]
	private void \u089Aۆ\u0887\u05C0()
	{
		long num = 1L;
		bool flag = this.\u06DC\u05EBࢦՇ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014C5 RID: 5317 RVA: 0x00074ED4 File Offset: 0x000730D4
	[Token(Token = "0x60014C5")]
	[Address(RVA = "0x2938D74", Offset = "0x2938D74", VA = "0x2938D74")]
	private void \u055Cࢯܯ\u0898()
	{
	}

	// Token: 0x060014C6 RID: 5318 RVA: 0x00074EE4 File Offset: 0x000730E4
	[Token(Token = "0x60014C6")]
	[Address(RVA = "0x2938D78", Offset = "0x2938D78", VA = "0x2938D78")]
	public bool \u05EDآ\u07EFն()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014C7 RID: 5319 RVA: 0x00074F50 File Offset: 0x00073150
	[Token(Token = "0x60014C7")]
	[Address(RVA = "0x293743C", Offset = "0x293743C", VA = "0x293743C")]
	public bool ӞހࡢԳ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014C8 RID: 5320 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014C8")]
	[Address(RVA = "0x2938EBC", Offset = "0x2938EBC", VA = "0x2938EBC")]
	public void Ԍ\u0878\u0898ڽ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014C9 RID: 5321 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014C9")]
	[Address(RVA = "0x2938FD0", Offset = "0x2938FD0", VA = "0x2938FD0")]
	public void ݔ߄ޱۓ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014CA RID: 5322 RVA: 0x00074FBC File Offset: 0x000731BC
	[Token(Token = "0x60014CA")]
	[Address(RVA = "0x29390CC", Offset = "0x29390CC", VA = "0x29390CC")]
	private void \u081E١Ӕࢦ()
	{
		if (!true)
		{
		}
		float fixedDeltaTime = Time.fixedDeltaTime;
	}

	// Token: 0x060014CB RID: 5323 RVA: 0x00074FE0 File Offset: 0x000731E0
	[Token(Token = "0x60014CB")]
	[Address(RVA = "0x2939364", Offset = "0x2939364", VA = "0x2939364")]
	private void FixedUpdate()
	{
		long num = 1L;
		bool flag = this.Լػԁڒ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014CC RID: 5324 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014CC")]
	[Address(RVA = "0x29394AC", Offset = "0x29394AC", VA = "0x29394AC")]
	public void \u0559\u05FEפ\u05CD()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014CD RID: 5325 RVA: 0x00075030 File Offset: 0x00073230
	[Token(Token = "0x60014CD")]
	[Address(RVA = "0x29395A8", Offset = "0x29395A8", VA = "0x29395A8")]
	private void \u058EԸس\u0819()
	{
	}

	// Token: 0x060014CE RID: 5326 RVA: 0x00075040 File Offset: 0x00073240
	[Token(Token = "0x60014CE")]
	[Address(RVA = "0x29395AC", Offset = "0x29395AC", VA = "0x29395AC")]
	private void چ\u05AEךڰ()
	{
	}

	// Token: 0x060014CF RID: 5327 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014CF")]
	[Address(RVA = "0x29395B0", Offset = "0x29395B0", VA = "0x29395B0")]
	public void \u05F8ࡂࡧ\u07FA()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014D0 RID: 5328 RVA: 0x00075050 File Offset: 0x00073250
	[Token(Token = "0x60014D0")]
	[Address(RVA = "0x29396AC", Offset = "0x29396AC", VA = "0x29396AC")]
	private void \u089F\u085Fէ\u059A()
	{
	}

	// Token: 0x060014D1 RID: 5329 RVA: 0x00075060 File Offset: 0x00073260
	[Token(Token = "0x60014D1")]
	[Address(RVA = "0x29396B0", Offset = "0x29396B0", VA = "0x29396B0")]
	public bool ؽݖ\u07FAҾ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014D2 RID: 5330 RVA: 0x000750CC File Offset: 0x000732CC
	[Token(Token = "0x60014D2")]
	[Address(RVA = "0x29397F4", Offset = "0x29397F4", VA = "0x29397F4")]
	private void Ԉ۴ࡉࢬ()
	{
	}

	// Token: 0x060014D3 RID: 5331 RVA: 0x000750DC File Offset: 0x000732DC
	[Token(Token = "0x60014D3")]
	[Address(RVA = "0x29397F8", Offset = "0x29397F8", VA = "0x29397F8")]
	private void ࡩݮڢՠ()
	{
	}

	// Token: 0x060014D4 RID: 5332 RVA: 0x000750EC File Offset: 0x000732EC
	[Token(Token = "0x60014D4")]
	[Address(RVA = "0x29397FC", Offset = "0x29397FC", VA = "0x29397FC")]
	private void ࢫ\u0876չՍ()
	{
	}

	// Token: 0x060014D5 RID: 5333 RVA: 0x000750FC File Offset: 0x000732FC
	[Token(Token = "0x60014D5")]
	[Address(RVA = "0x2939220", Offset = "0x2939220", VA = "0x2939220")]
	public bool Լ\u06DCޡࡐ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014D6 RID: 5334 RVA: 0x00075168 File Offset: 0x00073368
	[Token(Token = "0x60014D6")]
	[Address(RVA = "0x2939800", Offset = "0x2939800", VA = "0x2939800")]
	public bool \u0749ڐڜޙ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014D7 RID: 5335 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014D7")]
	[Address(RVA = "0x2939944", Offset = "0x2939944", VA = "0x2939944")]
	public void \u0702Ӣݧޑ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014D8 RID: 5336 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014D8")]
	[Address(RVA = "0x2939A40", Offset = "0x2939A40", VA = "0x2939A40")]
	public void ދܐضړ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014D9 RID: 5337 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014D9")]
	[Address(RVA = "0x2939B3C", Offset = "0x2939B3C", VA = "0x2939B3C")]
	public void ࢺ\u0599\u07A6\u0650()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014DA RID: 5338 RVA: 0x000751D4 File Offset: 0x000733D4
	[Token(Token = "0x60014DA")]
	[Address(RVA = "0x2939C38", Offset = "0x2939C38", VA = "0x2939C38")]
	private void יԠ\u07EDԺ()
	{
	}

	// Token: 0x060014DB RID: 5339 RVA: 0x000751E4 File Offset: 0x000733E4
	[Token(Token = "0x60014DB")]
	[Address(RVA = "0x29376D8", Offset = "0x29376D8", VA = "0x29376D8")]
	public bool Լػԁڒ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014DC RID: 5340 RVA: 0x00075250 File Offset: 0x00073450
	[Token(Token = "0x60014DC")]
	[Address(RVA = "0x2939C3C", Offset = "0x2939C3C", VA = "0x2939C3C")]
	public bool ߩԱޔխ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014DD RID: 5341 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014DD")]
	[Address(RVA = "0x2939D80", Offset = "0x2939D80", VA = "0x2939D80")]
	public void \u0595ժջܥ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014DE RID: 5342 RVA: 0x000752BC File Offset: 0x000734BC
	[Token(Token = "0x60014DE")]
	[Address(RVA = "0x2939E88", Offset = "0x2939E88", VA = "0x2939E88")]
	private void ܬԛ٣\u07FF()
	{
	}

	// Token: 0x060014DF RID: 5343 RVA: 0x000752CC File Offset: 0x000734CC
	[Token(Token = "0x60014DF")]
	[Address(RVA = "0x2939E8C", Offset = "0x2939E8C", VA = "0x2939E8C")]
	private void չւت\u061E()
	{
	}

	// Token: 0x060014E0 RID: 5344 RVA: 0x000752DC File Offset: 0x000734DC
	[Token(Token = "0x60014E0")]
	[Address(RVA = "0x2939E90", Offset = "0x2939E90", VA = "0x2939E90")]
	private void Start()
	{
	}

	// Token: 0x060014E1 RID: 5345 RVA: 0x000752EC File Offset: 0x000734EC
	[Token(Token = "0x60014E1")]
	[Address(RVA = "0x2939E94", Offset = "0x2939E94", VA = "0x2939E94")]
	private void ӭࡖݲ\u05BD()
	{
	}

	// Token: 0x060014E2 RID: 5346 RVA: 0x000752FC File Offset: 0x000734FC
	[Token(Token = "0x60014E2")]
	[Address(RVA = "0x2939E98", Offset = "0x2939E98", VA = "0x2939E98")]
	private void نո\u0599\u0589()
	{
	}

	// Token: 0x060014E3 RID: 5347 RVA: 0x0007530C File Offset: 0x0007350C
	[Token(Token = "0x60014E3")]
	[Address(RVA = "0x2939E9C", Offset = "0x2939E9C", VA = "0x2939E9C")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
	}

	// Token: 0x060014E4 RID: 5348 RVA: 0x0007531C File Offset: 0x0007351C
	[Token(Token = "0x60014E4")]
	[Address(RVA = "0x2939EA0", Offset = "0x2939EA0", VA = "0x2939EA0")]
	private void \u0827ߜ\u07FD\u07F4()
	{
	}

	// Token: 0x060014E5 RID: 5349 RVA: 0x0007532C File Offset: 0x0007352C
	[Token(Token = "0x60014E5")]
	[Address(RVA = "0x2939EA4", Offset = "0x2939EA4", VA = "0x2939EA4")]
	private void \u07AC١\u0711\u0742()
	{
		long num = 1L;
		bool flag = this.\u05A6\u05AB\u05FEխ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014E6 RID: 5350 RVA: 0x0007537C File Offset: 0x0007357C
	[Token(Token = "0x60014E6")]
	[Address(RVA = "0x293A13C", Offset = "0x293A13C", VA = "0x293A13C")]
	private void ӽރࠊݤ()
	{
		long num = 1L;
		bool flag = this.ؽݖ\u07FAҾ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014E7 RID: 5351 RVA: 0x000753CC File Offset: 0x000735CC
	[Token(Token = "0x60014E7")]
	[Address(RVA = "0x293A290", Offset = "0x293A290", VA = "0x293A290")]
	public bool \u0592ݬفڊ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014E8 RID: 5352 RVA: 0x00075438 File Offset: 0x00073638
	[Token(Token = "0x60014E8")]
	[Address(RVA = "0x293A3D4", Offset = "0x293A3D4", VA = "0x293A3D4")]
	public bool ԧՇ\u061C\u0821()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014E9 RID: 5353 RVA: 0x000754A4 File Offset: 0x000736A4
	[Token(Token = "0x60014E9")]
	[Address(RVA = "0x293A518", Offset = "0x293A518", VA = "0x293A518")]
	public bool چݩԾۀ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014EA RID: 5354 RVA: 0x00075510 File Offset: 0x00073710
	[Token(Token = "0x60014EA")]
	[Address(RVA = "0x293A65C", Offset = "0x293A65C", VA = "0x293A65C")]
	private void ם\u06FDւԋ()
	{
		long num = 1L;
		bool flag = this.۲ࡧխݔ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014EB RID: 5355 RVA: 0x00075560 File Offset: 0x00073760
	[Token(Token = "0x60014EB")]
	[Address(RVA = "0x293A8F4", Offset = "0x293A8F4", VA = "0x293A8F4")]
	private void Տ\u0896ܜݬ()
	{
		long num = 1L;
		bool flag = this.ծӋ\u0817ࢧ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
	}

	// Token: 0x060014EC RID: 5356 RVA: 0x000755A8 File Offset: 0x000737A8
	[Token(Token = "0x60014EC")]
	[Address(RVA = "0x2937F64", Offset = "0x2937F64", VA = "0x2937F64")]
	public bool \u086Cׯڸպ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014ED RID: 5357 RVA: 0x00075614 File Offset: 0x00073814
	[Token(Token = "0x60014ED")]
	[Address(RVA = "0x293AB8C", Offset = "0x293AB8C", VA = "0x293AB8C")]
	public bool \u05B9ܢݿڄ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014EE RID: 5358 RVA: 0x00075680 File Offset: 0x00073880
	[Token(Token = "0x60014EE")]
	[Address(RVA = "0x293ACD0", Offset = "0x293ACD0", VA = "0x293ACD0")]
	private void ېߌբ\u0896()
	{
		long num = 1L;
		bool flag = this.ӞހࡢԳ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014EF RID: 5359 RVA: 0x000756D0 File Offset: 0x000738D0
	[Token(Token = "0x60014EF")]
	[Address(RVA = "0x293AE24", Offset = "0x293AE24", VA = "0x293AE24")]
	public bool \u06EDق\u06ECۺ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014F0 RID: 5360 RVA: 0x0007573C File Offset: 0x0007393C
	[Token(Token = "0x60014F0")]
	[Address(RVA = "0x293AF68", Offset = "0x293AF68", VA = "0x293AF68")]
	private void \u0890ؤߪފ()
	{
		long num = 1L;
		bool flag = this.ծӋ\u0817ࢧ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014F1 RID: 5361 RVA: 0x0007578C File Offset: 0x0007398C
	[Token(Token = "0x60014F1")]
	[Address(RVA = "0x293705C", Offset = "0x293705C", VA = "0x293705C")]
	public bool ߙ\u05B1\u0596ժ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014F2 RID: 5362 RVA: 0x000757F8 File Offset: 0x000739F8
	[Token(Token = "0x60014F2")]
	[Address(RVA = "0x293A7B0", Offset = "0x293A7B0", VA = "0x293A7B0")]
	public bool ۲ࡧխݔ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014F3 RID: 5363 RVA: 0x00075864 File Offset: 0x00073A64
	[Token(Token = "0x60014F3")]
	[Address(RVA = "0x293B0BC", Offset = "0x293B0BC", VA = "0x293B0BC")]
	private void ۲ڂ\u05B1ڨ()
	{
	}

	// Token: 0x060014F4 RID: 5364 RVA: 0x00075874 File Offset: 0x00073A74
	[Token(Token = "0x60014F4")]
	[Address(RVA = "0x293B0C0", Offset = "0x293B0C0", VA = "0x293B0C0")]
	private void Ա\u07B9ߒݗ()
	{
		long num = 1L;
		bool flag = this.ߩԱޔխ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014F5 RID: 5365 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014F5")]
	[Address(RVA = "0x293B214", Offset = "0x293B214", VA = "0x293B214")]
	public void ݭ\u0708ݹࡖ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014F6 RID: 5366 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014F6")]
	[Address(RVA = "0x293B328", Offset = "0x293B328", VA = "0x293B328")]
	public void ݳ\u060E\u06FE\u065D()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014F7 RID: 5367 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60014F7")]
	[Address(RVA = "0x293B424", Offset = "0x293B424", VA = "0x293B424")]
	public void Ҿ\u065EՀݜ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014F8 RID: 5368 RVA: 0x000758C4 File Offset: 0x00073AC4
	[Token(Token = "0x60014F8")]
	[Address(RVA = "0x293B520", Offset = "0x293B520", VA = "0x293B520")]
	private void ޞۊաݛ()
	{
		long num = 1L;
		bool flag = this.Լػԁڒ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x060014F9 RID: 5369 RVA: 0x00075914 File Offset: 0x00073B14
	[Token(Token = "0x60014F9")]
	[Address(RVA = "0x293B674", Offset = "0x293B674", VA = "0x293B674")]
	private void \u07A8Ӥթݠ()
	{
	}

	// Token: 0x060014FA RID: 5370 RVA: 0x00075924 File Offset: 0x00073B24
	[Token(Token = "0x60014FA")]
	[Address(RVA = "0x293B678", Offset = "0x293B678", VA = "0x293B678")]
	public bool ۱\u089CפӘ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014FB RID: 5371 RVA: 0x00075990 File Offset: 0x00073B90
	[Token(Token = "0x60014FB")]
	[Address(RVA = "0x293B7BC", Offset = "0x293B7BC", VA = "0x293B7BC")]
	public bool ٣\u0705ڏݼ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014FC RID: 5372 RVA: 0x000759FC File Offset: 0x00073BFC
	[Token(Token = "0x60014FC")]
	[Address(RVA = "0x293AA48", Offset = "0x293AA48", VA = "0x293AA48")]
	public bool ծӋ\u0817ࢧ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014FD RID: 5373 RVA: 0x00075A68 File Offset: 0x00073C68
	[Token(Token = "0x60014FD")]
	[Address(RVA = "0x2938C30", Offset = "0x2938C30", VA = "0x2938C30")]
	public bool \u06DC\u05EBࢦՇ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x060014FE RID: 5374 RVA: 0x00075AD4 File Offset: 0x00073CD4
	[Token(Token = "0x60014FE")]
	[Address(RVA = "0x293B900", Offset = "0x293B900", VA = "0x293B900")]
	private void \u086Bԍࡊڭ()
	{
	}

	// Token: 0x060014FF RID: 5375 RVA: 0x00075AE4 File Offset: 0x00073CE4
	[Token(Token = "0x60014FF")]
	[Address(RVA = "0x293B904", Offset = "0x293B904", VA = "0x293B904")]
	private void \u081Cәࡃ۵()
	{
	}

	// Token: 0x06001500 RID: 5376 RVA: 0x00075AF4 File Offset: 0x00073CF4
	[Token(Token = "0x6001500")]
	[Address(RVA = "0x293B908", Offset = "0x293B908", VA = "0x293B908")]
	private void \u06E3תثԸ()
	{
		long num = 1L;
		bool flag = this.\u086Cׯڸպ();
		if (num == 0L)
		{
		}
		Vector3 eulerAngles = this.\u060Cئࢳݱ.eulerAngles;
		Vector3 position = this.نڻӷڃ.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x06001501 RID: 5377 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001501")]
	[Address(RVA = "0x293BA5C", Offset = "0x293BA5C", VA = "0x293BA5C")]
	public void ڔӈӋڤ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001502 RID: 5378 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001502")]
	[Address(RVA = "0x293BB64", Offset = "0x293BB64", VA = "0x293BB64")]
	public void إݩ\u0886ԟ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001503 RID: 5379 RVA: 0x00075B44 File Offset: 0x00073D44
	[Token(Token = "0x6001503")]
	[Address(RVA = "0x2939FF8", Offset = "0x2939FF8", VA = "0x2939FF8")]
	public bool \u05A6\u05AB\u05FEխ()
	{
		Transform transform = this.\u0747Աخࢢ.transform;
		Vector3 center = this.\u0747Աخࢢ.center;
		float height = this.\u0747Աخࢢ.height;
		float radius = this.\u0747Աخࢢ.radius;
		float radius2 = this.\u0747Աخࢢ.radius;
		Vector3 down = Vector3.down;
		int num = this.ۏ\u07BD\u06ECԢ;
		bool result;
		return result;
	}

	// Token: 0x06001504 RID: 5380 RVA: 0x00075BB0 File Offset: 0x00073DB0
	[Token(Token = "0x6001504")]
	[Address(RVA = "0x293BC60", Offset = "0x293BC60", VA = "0x293BC60")]
	private void \u060B\u0614\u0821ע()
	{
	}

	// Token: 0x0400029A RID: 666
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400029A")]
	public float \u05B9ߎܩ\u0613;

	// Token: 0x0400029B RID: 667
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400029B")]
	public Rigidbody نڻӷڃ;

	// Token: 0x0400029C RID: 668
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400029C")]
	private InputDevice ࠊފ\u064FӪ;

	// Token: 0x0400029D RID: 669
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400029D")]
	private InputDevice ߌԙՏޚ;

	// Token: 0x0400029E RID: 670
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400029E")]
	public Transform \u060Cئࢳݱ;

	// Token: 0x0400029F RID: 671
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400029F")]
	public CapsuleCollider \u0747Աخࢢ;

	// Token: 0x040002A0 RID: 672
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40002A0")]
	public LayerMask ۏ\u07BD\u06ECԢ;

	// Token: 0x040002A1 RID: 673
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x40002A1")]
	private Vector2 Ը\u0619\u085Eܕ;
}
