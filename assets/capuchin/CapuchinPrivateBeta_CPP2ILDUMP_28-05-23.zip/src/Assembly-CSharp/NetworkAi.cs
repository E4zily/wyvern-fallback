﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.AI;

// Token: 0x02000065 RID: 101
[Token(Token = "0x2000065")]
public class NetworkAi : MonoBehaviour
{
	// Token: 0x06000E8F RID: 3727 RVA: 0x0005484C File Offset: 0x00052A4C
	[Token(Token = "0x6000E8F")]
	[Address(RVA = "0x23C077C", Offset = "0x23C077C", VA = "0x23C077C")]
	private void ժ\u065Dԯࡘ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E90 RID: 3728 RVA: 0x00054898 File Offset: 0x00052A98
	[Token(Token = "0x6000E90")]
	[Address(RVA = "0x23C07D8", Offset = "0x23C07D8", VA = "0x23C07D8")]
	private void \u0599ږࠆ\u065F()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E91 RID: 3729 RVA: 0x000548E0 File Offset: 0x00052AE0
	[Token(Token = "0x6000E91")]
	[Address(RVA = "0x23C0834", Offset = "0x23C0834", VA = "0x23C0834")]
	private void \u0881ݗӟ\u07BD()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E92 RID: 3730 RVA: 0x0005492C File Offset: 0x00052B2C
	[Token(Token = "0x6000E92")]
	[Address(RVA = "0x23C0890", Offset = "0x23C0890", VA = "0x23C0890")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E93 RID: 3731 RVA: 0x00054978 File Offset: 0x00052B78
	[Token(Token = "0x6000E93")]
	[Address(RVA = "0x23C08EC", Offset = "0x23C08EC", VA = "0x23C08EC")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E94 RID: 3732 RVA: 0x000549C4 File Offset: 0x00052BC4
	[Token(Token = "0x6000E94")]
	[Address(RVA = "0x23C0948", Offset = "0x23C0948", VA = "0x23C0948")]
	private void \u0614ࢥӴ\u086C()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 0L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 1L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000E95 RID: 3733 RVA: 0x00054A20 File Offset: 0x00052C20
	[Token(Token = "0x6000E95")]
	[Address(RVA = "0x23C09B8", Offset = "0x23C09B8", VA = "0x23C09B8")]
	private void \u0821\u059Fӕ\u0607()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E96 RID: 3734 RVA: 0x00054A5C File Offset: 0x00052C5C
	[Token(Token = "0x6000E96")]
	[Address(RVA = "0x23C0A04", Offset = "0x23C0A04", VA = "0x23C0A04")]
	private void \u05EDց\u081Cت()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E97 RID: 3735 RVA: 0x00054AA8 File Offset: 0x00052CA8
	[Token(Token = "0x6000E97")]
	[Address(RVA = "0x23C0A60", Offset = "0x23C0A60", VA = "0x23C0A60")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E98 RID: 3736 RVA: 0x00054AE4 File Offset: 0x00052CE4
	[Token(Token = "0x6000E98")]
	[Address(RVA = "0x23C0AAC", Offset = "0x23C0AAC", VA = "0x23C0AAC")]
	private void չւت\u061E()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E99 RID: 3737 RVA: 0x00054B30 File Offset: 0x00052D30
	[Token(Token = "0x6000E99")]
	[Address(RVA = "0x23C0B08", Offset = "0x23C0B08", VA = "0x23C0B08")]
	private void ڑߒجވ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E9A RID: 3738 RVA: 0x00054B6C File Offset: 0x00052D6C
	[Token(Token = "0x6000E9A")]
	[Address(RVA = "0x23C0B54", Offset = "0x23C0B54", VA = "0x23C0B54")]
	private void ո\u07AA\u05BDࠕ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 1L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 1L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000E9B RID: 3739 RVA: 0x00054BC8 File Offset: 0x00052DC8
	[Token(Token = "0x6000E9B")]
	[Address(RVA = "0x23C0BC4", Offset = "0x23C0BC4", VA = "0x23C0BC4")]
	private void יԠ\u07EDԺ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E9C RID: 3740 RVA: 0x00054C10 File Offset: 0x00052E10
	[Token(Token = "0x6000E9C")]
	[Address(RVA = "0x23C0C20", Offset = "0x23C0C20", VA = "0x23C0C20")]
	private void ژךՈ\u0597()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 1L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 1L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000E9D RID: 3741 RVA: 0x00054C6C File Offset: 0x00052E6C
	[Token(Token = "0x6000E9D")]
	[Address(RVA = "0x23C0C90", Offset = "0x23C0C90", VA = "0x23C0C90")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E9E RID: 3742 RVA: 0x00054CB8 File Offset: 0x00052EB8
	[Token(Token = "0x6000E9E")]
	[Address(RVA = "0x23C0CEC", Offset = "0x23C0CEC", VA = "0x23C0CEC")]
	private void \u061B\u05EEوۈ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 0L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 1L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000E9F RID: 3743 RVA: 0x00054D14 File Offset: 0x00052F14
	[Token(Token = "0x6000E9F")]
	[Address(RVA = "0x23C0D5C", Offset = "0x23C0D5C", VA = "0x23C0D5C")]
	private void ԟ\u086Cޣ\u055E()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 1L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 1L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000EA0 RID: 3744 RVA: 0x00054D70 File Offset: 0x00052F70
	[Token(Token = "0x6000EA0")]
	[Address(RVA = "0x23C0DCC", Offset = "0x23C0DCC", VA = "0x23C0DCC")]
	private void \u0705\u0816\u0739դ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		this.\u05B4\u070Aפڷ.enabled = (enabled != 0L);
	}

	// Token: 0x06000EA1 RID: 3745 RVA: 0x00054DB0 File Offset: 0x00052FB0
	[Token(Token = "0x6000EA1")]
	[Address(RVA = "0x23C0E28", Offset = "0x23C0E28", VA = "0x23C0E28")]
	private void ԣԭՋࠏ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EA2 RID: 3746 RVA: 0x00054DEC File Offset: 0x00052FEC
	[Token(Token = "0x6000EA2")]
	[Address(RVA = "0x23C0E74", Offset = "0x23C0E74", VA = "0x23C0E74")]
	private void Ҿࢹؼס()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 0L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 1L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000EA3 RID: 3747 RVA: 0x00054E48 File Offset: 0x00053048
	[Token(Token = "0x6000EA3")]
	[Address(RVA = "0x23C0EE4", Offset = "0x23C0EE4", VA = "0x23C0EE4")]
	private void \u0732ڙԒࢺ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EA4 RID: 3748 RVA: 0x00054E94 File Offset: 0x00053094
	[Token(Token = "0x6000EA4")]
	[Address(RVA = "0x23C0F40", Offset = "0x23C0F40", VA = "0x23C0F40")]
	private void \u0590\u0882\u0883ࡦ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EA5 RID: 3749 RVA: 0x00054ED0 File Offset: 0x000530D0
	[Token(Token = "0x6000EA5")]
	[Address(RVA = "0x23C0F8C", Offset = "0x23C0F8C", VA = "0x23C0F8C")]
	private void \u0838ӆڛӑ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EA6 RID: 3750 RVA: 0x00054F1C File Offset: 0x0005311C
	[Token(Token = "0x6000EA6")]
	[Address(RVA = "0x23C0FE8", Offset = "0x23C0FE8", VA = "0x23C0FE8")]
	private void ӻӒݝ߃()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EA7 RID: 3751 RVA: 0x00054F58 File Offset: 0x00053158
	[Token(Token = "0x6000EA7")]
	[Address(RVA = "0x23C1034", Offset = "0x23C1034", VA = "0x23C1034")]
	private void ٴݵۃ\u05AF()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EA8 RID: 3752 RVA: 0x00054F94 File Offset: 0x00053194
	[Token(Token = "0x6000EA8")]
	[Address(RVA = "0x23C1080", Offset = "0x23C1080", VA = "0x23C1080")]
	private void Ӣ\u0592ߨׯ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EA9 RID: 3753 RVA: 0x00054FD0 File Offset: 0x000531D0
	[Token(Token = "0x6000EA9")]
	[Address(RVA = "0x23C10CC", Offset = "0x23C10CC", VA = "0x23C10CC")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EAA RID: 3754 RVA: 0x0005500C File Offset: 0x0005320C
	[Token(Token = "0x6000EAA")]
	[Address(RVA = "0x23C1118", Offset = "0x23C1118", VA = "0x23C1118")]
	private void \u0886Ҽ\u058Dߛ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EAB RID: 3755 RVA: 0x00055058 File Offset: 0x00053258
	[Token(Token = "0x6000EAB")]
	[Address(RVA = "0x23C1174", Offset = "0x23C1174", VA = "0x23C1174")]
	private void \u07FE\u0882Զ\u066D()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EAC RID: 3756 RVA: 0x00055094 File Offset: 0x00053294
	[Token(Token = "0x6000EAC")]
	[Address(RVA = "0x23C11C0", Offset = "0x23C11C0", VA = "0x23C11C0")]
	private void \u0870\u05B3Ց\u066A()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled = 1L;
		u05B4_u070Aפڷ.enabled = (enabled != 0L);
	}

	// Token: 0x06000EAD RID: 3757 RVA: 0x000550C8 File Offset: 0x000532C8
	[Token(Token = "0x6000EAD")]
	[Address(RVA = "0x23C120C", Offset = "0x23C120C", VA = "0x23C120C")]
	private void \u073Fߗބݝ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EAE RID: 3758 RVA: 0x00055114 File Offset: 0x00053314
	[Token(Token = "0x6000EAE")]
	[Address(RVA = "0x23C1268", Offset = "0x23C1268", VA = "0x23C1268")]
	private void طӏܙࢺ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled;
		if (u07AE_u05AF_u064FԖ != null)
		{
			enabled = 0L;
			return;
		}
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		long enabled2 = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EAF RID: 3759 RVA: 0x0005514C File Offset: 0x0005334C
	[Token(Token = "0x6000EAF")]
	[Address(RVA = "0x23C12C4", Offset = "0x23C12C4", VA = "0x23C12C4")]
	private void \u087BӦןݩ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 0L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 1L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000EB0 RID: 3760 RVA: 0x000551A8 File Offset: 0x000533A8
	[Token(Token = "0x6000EB0")]
	[Address(RVA = "0x23C1334", Offset = "0x23C1334", VA = "0x23C1334")]
	private void ڃրӢԖ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 1L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 1L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000EB1 RID: 3761 RVA: 0x00055204 File Offset: 0x00053404
	[Token(Token = "0x6000EB1")]
	[Address(RVA = "0x23C13A4", Offset = "0x23C13A4", VA = "0x23C13A4")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EB2 RID: 3762 RVA: 0x00055250 File Offset: 0x00053450
	[Token(Token = "0x6000EB2")]
	[Address(RVA = "0x23C1400", Offset = "0x23C1400", VA = "0x23C1400")]
	private void Ӌ\u089C\u0700ܧ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 1L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 1L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000EB3 RID: 3763 RVA: 0x000552AC File Offset: 0x000534AC
	[Token(Token = "0x6000EB3")]
	[Address(RVA = "0x23C1470", Offset = "0x23C1470", VA = "0x23C1470")]
	private void Update()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 1L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 0L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000EB4 RID: 3764 RVA: 0x00055308 File Offset: 0x00053508
	[Token(Token = "0x6000EB4")]
	[Address(RVA = "0x23C14E0", Offset = "0x23C14E0", VA = "0x23C14E0")]
	private void Ҽ\u08B5ځ\u0658()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EB5 RID: 3765 RVA: 0x00055350 File Offset: 0x00053550
	[Token(Token = "0x6000EB5")]
	[Address(RVA = "0x23C153C", Offset = "0x23C153C", VA = "0x23C153C")]
	private void \u05F7ԝߠӱ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EB6 RID: 3766 RVA: 0x0005539C File Offset: 0x0005359C
	[Token(Token = "0x6000EB6")]
	[Address(RVA = "0x23C1598", Offset = "0x23C1598", VA = "0x23C1598")]
	private void ࢫ\u0876չՍ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 0L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 1L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000EB7 RID: 3767 RVA: 0x000553F8 File Offset: 0x000535F8
	[Token(Token = "0x6000EB7")]
	[Address(RVA = "0x23C1608", Offset = "0x23C1608", VA = "0x23C1608")]
	private void \u05F8ݑ\u06ECߞ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EB8 RID: 3768 RVA: 0x00055438 File Offset: 0x00053638
	[Token(Token = "0x6000EB8")]
	[Address(RVA = "0x23C1664", Offset = "0x23C1664", VA = "0x23C1664")]
	private void \u070Aәޣے()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EB9 RID: 3769 RVA: 0x00055474 File Offset: 0x00053674
	[Token(Token = "0x6000EB9")]
	[Address(RVA = "0x23C16B0", Offset = "0x23C16B0", VA = "0x23C16B0")]
	private void ފՖߢ\u059B()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 0L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 0L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000EBA RID: 3770 RVA: 0x000554D0 File Offset: 0x000536D0
	[Token(Token = "0x6000EBA")]
	[Address(RVA = "0x23C1720", Offset = "0x23C1720", VA = "0x23C1720")]
	public NetworkAi()
	{
	}

	// Token: 0x06000EBB RID: 3771 RVA: 0x000554E4 File Offset: 0x000536E4
	[Token(Token = "0x6000EBB")]
	[Address(RVA = "0x23C1728", Offset = "0x23C1728", VA = "0x23C1728")]
	private void \u0654ޛ\u07FAذ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		long enabled2 = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EBC RID: 3772 RVA: 0x00055518 File Offset: 0x00053718
	[Token(Token = "0x6000EBC")]
	[Address(RVA = "0x23C1774", Offset = "0x23C1774", VA = "0x23C1774")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EBD RID: 3773 RVA: 0x00055564 File Offset: 0x00053764
	[Token(Token = "0x6000EBD")]
	[Address(RVA = "0x23C17D0", Offset = "0x23C17D0", VA = "0x23C17D0")]
	private void څࡣڐ\u0657()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EBE RID: 3774 RVA: 0x000555A0 File Offset: 0x000537A0
	[Token(Token = "0x6000EBE")]
	[Address(RVA = "0x23C181C", Offset = "0x23C181C", VA = "0x23C181C")]
	private void \u0832ࢳޤ\u07B5()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 1L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EBF RID: 3775 RVA: 0x000555DC File Offset: 0x000537DC
	[Token(Token = "0x6000EBF")]
	[Address(RVA = "0x23C1868", Offset = "0x23C1868", VA = "0x23C1868")]
	private void צ\u0874ڵ\u059A()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		NavMeshAgent u05B4_u070Aפڷ;
		if (u07AE_u05AF_u064FԖ.<IsMine>k__BackingField)
		{
			long enabled = 0L;
			u05C3չ_u088Eܮ.enabled = (enabled != 0L);
			u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
			return;
		}
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
		NavMeshAgent u05B4_u070Aפڷ2 = this.\u05B4\u070Aפڷ;
		long enabled3 = 0L;
		u05B4_u070Aפڷ2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000EC0 RID: 3776 RVA: 0x00055638 File Offset: 0x00053838
	[Token(Token = "0x6000EC0")]
	[Address(RVA = "0x23C18D8", Offset = "0x23C18D8", VA = "0x23C18D8")]
	private void ւࡂ\u0883\u0872()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000EC1 RID: 3777 RVA: 0x00055684 File Offset: 0x00053884
	[Token(Token = "0x6000EC1")]
	[Address(RVA = "0x23C1934", Offset = "0x23C1934", VA = "0x23C1934")]
	private void ں٢ࡡ\u05EC()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		PatrolAI u05C3չ_u088Eܮ = this.\u05C3չ\u088Eܮ;
		long enabled = 0L;
		u05C3չ_u088Eܮ.enabled = (enabled != 0L);
		NavMeshAgent u05B4_u070Aפڷ = this.\u05B4\u070Aפڷ;
		long enabled2 = 1L;
		u05B4_u070Aפڷ.enabled = (enabled2 != 0L);
	}

	// Token: 0x0400020C RID: 524
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400020C")]
	public PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x0400020D RID: 525
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400020D")]
	public NavMeshAgent \u05B4\u070Aפڷ;

	// Token: 0x0400020E RID: 526
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400020E")]
	public PatrolAI \u05C3չ\u088Eܮ;
}
