﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace SizeChanging
{
	// Token: 0x020000FF RID: 255
	[Token(Token = "0x20000FF")]
	public class sizeChanger : MonoBehaviour
	{
		// Token: 0x0600276A RID: 10090 RVA: 0x000E5A44 File Offset: 0x000E3C44
		[Token(Token = "0x600276A")]
		[Address(RVA = "0x2E41354", Offset = "0x2E41354", VA = "0x2E41354")]
		private void \u07B2߆Ժࡄ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(", ");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600276B RID: 10091 RVA: 0x000E5B00 File Offset: 0x000E3D00
		[Token(Token = "0x600276B")]
		[Address(RVA = "0x2E41564", Offset = "0x2E41564", VA = "0x2E41564")]
		private void \u05B3ࢹߧ\u07AA()
		{
			float num = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x0600276C RID: 10092 RVA: 0x000E5B48 File Offset: 0x000E3D48
		[Token(Token = "0x600276C")]
		[Address(RVA = "0x2E41614", Offset = "0x2E41614", VA = "0x2E41614")]
		private void \u05AC\u07F0\u07EEࡥ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x0600276D RID: 10093 RVA: 0x000E5BA0 File Offset: 0x000E3DA0
		[Token(Token = "0x600276D")]
		[Address(RVA = "0x2E416C4", Offset = "0x2E416C4", VA = "0x2E416C4")]
		private void މ\u06EAԅܚ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Diffuse");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600276E RID: 10094 RVA: 0x000E5C5C File Offset: 0x000E3E5C
		[Token(Token = "0x600276E")]
		[Address(RVA = "0x2E418D4", Offset = "0x2E418D4", VA = "0x2E418D4")]
		private void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("RainAndThunderWeather");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x0600276F RID: 10095 RVA: 0x000E5D14 File Offset: 0x000E3F14
		[Token(Token = "0x600276F")]
		[Address(RVA = "0x2E41ABC", Offset = "0x2E41ABC", VA = "0x2E41ABC")]
		private void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Display Name Changed!");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002770 RID: 10096 RVA: 0x000E5DD0 File Offset: 0x000E3FD0
		[Token(Token = "0x6002770")]
		[Address(RVA = "0x2E41CCC", Offset = "0x2E41CCC", VA = "0x2E41CCC")]
		private void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Calling success callback. baking meshes");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002771 RID: 10097 RVA: 0x000E5E8C File Offset: 0x000E408C
		[Token(Token = "0x6002771")]
		[Address(RVA = "0x2E41EDC", Offset = "0x2E41EDC", VA = "0x2E41EDC")]
		private void ࠍ\u06E5\u055Eئ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002772 RID: 10098 RVA: 0x000E5F48 File Offset: 0x000E4148
		[Token(Token = "0x6002772")]
		[Address(RVA = "0x2E420EC", Offset = "0x2E420EC", VA = "0x2E420EC")]
		private void ԛۻ\u081C\u07B5(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Added Winner Money");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002773 RID: 10099 RVA: 0x000E6004 File Offset: 0x000E4204
		[Token(Token = "0x6002773")]
		[Address(RVA = "0x2E422FC", Offset = "0x2E422FC", VA = "0x2E422FC")]
		private void \u07FAۯضߙ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002774 RID: 10100 RVA: 0x000E605C File Offset: 0x000E425C
		[Token(Token = "0x6002774")]
		[Address(RVA = "0x2E423AC", Offset = "0x2E423AC", VA = "0x2E423AC")]
		private void \u0881ݗӟ\u07BD()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002775 RID: 10101 RVA: 0x000E60B4 File Offset: 0x000E42B4
		[Token(Token = "0x6002775")]
		[Address(RVA = "0x2E4245C", Offset = "0x2E4245C", VA = "0x2E4245C")]
		private void \u061B\u05EEوۈ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002776 RID: 10102 RVA: 0x000E610C File Offset: 0x000E430C
		[Token(Token = "0x6002776")]
		[Address(RVA = "0x2E4250C", Offset = "0x2E4250C", VA = "0x2E4250C")]
		private void եݚۆ\u0890(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Tagging");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x06002777 RID: 10103 RVA: 0x000E61C4 File Offset: 0x000E43C4
		[Token(Token = "0x6002777")]
		[Address(RVA = "0x2E426F4", Offset = "0x2E426F4", VA = "0x2E426F4")]
		private void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Mesh");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002778 RID: 10104 RVA: 0x000E6280 File Offset: 0x000E4480
		[Token(Token = "0x6002778")]
		[Address(RVA = "0x2E42904", Offset = "0x2E42904", VA = "0x2E42904")]
		private void ࡤ\u0658ډ\u05B4(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x06002779 RID: 10105 RVA: 0x000E6338 File Offset: 0x000E4538
		[Token(Token = "0x6002779")]
		[Address(RVA = "0x2E42AEC", Offset = "0x2E42AEC", VA = "0x2E42AEC")]
		private void ڃրӢԖ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x0600277A RID: 10106 RVA: 0x000E6390 File Offset: 0x000E4590
		[Token(Token = "0x600277A")]
		[Address(RVA = "0x2E42B9C", Offset = "0x2E42B9C", VA = "0x2E42B9C")]
		private void Ոڷد\u05F5(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Error");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600277B RID: 10107 RVA: 0x000E644C File Offset: 0x000E464C
		[Token(Token = "0x600277B")]
		[Address(RVA = "0x2E42DAC", Offset = "0x2E42DAC", VA = "0x2E42DAC")]
		private void \u05FD\u06E1\u064Cԕ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("got funky mone");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float num = Mathf.Clamp01(u058Bދثح2.Evaluate(time));
		}

		// Token: 0x0600277C RID: 10108 RVA: 0x000E6500 File Offset: 0x000E4700
		[Token(Token = "0x600277C")]
		[Address(RVA = "0x2E42FBC", Offset = "0x2E42FBC", VA = "0x2E42FBC")]
		private void Ӛ\u055D\u0651Խ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x0600277D RID: 10109 RVA: 0x000E65B8 File Offset: 0x000E47B8
		[Token(Token = "0x600277D")]
		[Address(RVA = "0x2E431A4", Offset = "0x2E431A4", VA = "0x2E431A4")]
		private void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x0600277E RID: 10110 RVA: 0x000E6670 File Offset: 0x000E4870
		[Token(Token = "0x600277E")]
		[Address(RVA = "0x2E4338C", Offset = "0x2E4338C", VA = "0x2E4338C")]
		private void \u05BA\u087AܘҾ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x0600277F RID: 10111 RVA: 0x000E66C8 File Offset: 0x000E48C8
		[Token(Token = "0x600277F")]
		[Address(RVA = "0x2E4343C", Offset = "0x2E4343C", VA = "0x2E4343C")]
		private void ࡩ\u07FF\u0833ࠆ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002780 RID: 10112 RVA: 0x000E6780 File Offset: 0x000E4980
		[Token(Token = "0x6002780")]
		[Address(RVA = "0x2E4364C", Offset = "0x2E4364C", VA = "0x2E4364C")]
		private void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("We don't need this electrical box");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x06002781 RID: 10113 RVA: 0x000E6828 File Offset: 0x000E4A28
		[Token(Token = "0x6002781")]
		[Address(RVA = "0x2E43834", Offset = "0x2E43834", VA = "0x2E43834")]
		private void ڷԲ\u0618ރ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002782 RID: 10114 RVA: 0x000E6880 File Offset: 0x000E4A80
		[Token(Token = "0x6002782")]
		[Address(RVA = "0x2E438E4", Offset = "0x2E438E4", VA = "0x2E438E4")]
		private void ࡊ\u0592\u07AB\u05B2()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002783 RID: 10115 RVA: 0x000E68D8 File Offset: 0x000E4AD8
		[Token(Token = "0x6002783")]
		[Address(RVA = "0x2E43994", Offset = "0x2E43994", VA = "0x2E43994")]
		private void ژךՈ\u0597()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002784 RID: 10116 RVA: 0x000E6930 File Offset: 0x000E4B30
		[Token(Token = "0x6002784")]
		[Address(RVA = "0x2E43A3C", Offset = "0x2E43A3C", VA = "0x2E43A3C")]
		private void ցڴ\u0823ٿ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("All audio clips have been played.");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002785 RID: 10117 RVA: 0x000E69EC File Offset: 0x000E4BEC
		[Token(Token = "0x6002785")]
		[Address(RVA = "0x2E43C4C", Offset = "0x2E43C4C", VA = "0x2E43C4C")]
		private void سܠӛ\u07AA()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002786 RID: 10118 RVA: 0x000E6A44 File Offset: 0x000E4C44
		[Token(Token = "0x6002786")]
		[Address(RVA = "0x2E43CFC", Offset = "0x2E43CFC", VA = "0x2E43CFC")]
		private void ߂ӹ\u05C6\u07F9(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(" ");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x06002787 RID: 10119 RVA: 0x000E6AFC File Offset: 0x000E4CFC
		[Token(Token = "0x6002787")]
		[Address(RVA = "0x2E43EE4", Offset = "0x2E43EE4", VA = "0x2E43EE4")]
		private void ڨ۵ތ\u06D8()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002788 RID: 10120 RVA: 0x000E6B54 File Offset: 0x000E4D54
		[Token(Token = "0x6002788")]
		[Address(RVA = "0x2E43F94", Offset = "0x2E43F94", VA = "0x2E43F94")]
		private void יԠ\u07EDԺ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002789 RID: 10121 RVA: 0x000E6BAC File Offset: 0x000E4DAC
		[Token(Token = "0x6002789")]
		[Address(RVA = "0x2E44044", Offset = "0x2E44044", VA = "0x2E44044")]
		private void ԗ\u05F9ҿ\u0834(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("You Look Like Butt");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600278A RID: 10122 RVA: 0x000E6C68 File Offset: 0x000E4E68
		[Token(Token = "0x600278A")]
		[Address(RVA = "0x2E44254", Offset = "0x2E44254", VA = "0x2E44254")]
		private void տ\u06D9ܭࠊ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("TurnAmount");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600278B RID: 10123 RVA: 0x000E6D24 File Offset: 0x000E4F24
		[Token(Token = "0x600278B")]
		[Address(RVA = "0x2E44464", Offset = "0x2E44464", VA = "0x2E44464")]
		private void Ԍڏ\u0879թ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("/");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600278C RID: 10124 RVA: 0x000E6DE0 File Offset: 0x000E4FE0
		[Token(Token = "0x600278C")]
		[Address(RVA = "0x2E44674", Offset = "0x2E44674", VA = "0x2E44674")]
		private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600278D RID: 10125 RVA: 0x000E6E9C File Offset: 0x000E509C
		[Token(Token = "0x600278D")]
		[Address(RVA = "0x2E44884", Offset = "0x2E44884", VA = "0x2E44884")]
		private void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("TurnAmount");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600278E RID: 10126 RVA: 0x000E6F58 File Offset: 0x000E5158
		[Token(Token = "0x600278E")]
		[Address(RVA = "0x2E44A94", Offset = "0x2E44A94", VA = "0x2E44A94")]
		private void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("NGNNoSound");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600278F RID: 10127 RVA: 0x000E7014 File Offset: 0x000E5214
		[Token(Token = "0x600278F")]
		[Address(RVA = "0x2E44CA4", Offset = "0x2E44CA4", VA = "0x2E44CA4")]
		private void ڿ\u07ADݠڧ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PRESS AGAIN TO CONFIRM");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x06002790 RID: 10128 RVA: 0x000E70CC File Offset: 0x000E52CC
		[Token(Token = "0x6002790")]
		[Address(RVA = "0x2E44E8C", Offset = "0x2E44E8C", VA = "0x2E44E8C")]
		private void әݓ\u0610ժ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("1BN");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x06002791 RID: 10129 RVA: 0x000E7180 File Offset: 0x000E5380
		[Token(Token = "0x6002791")]
		[Address(RVA = "0x2E45074", Offset = "0x2E45074", VA = "0x2E45074")]
		private void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("true");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002792 RID: 10130 RVA: 0x000E723C File Offset: 0x000E543C
		[Token(Token = "0x6002792")]
		[Address(RVA = "0x2E45284", Offset = "0x2E45284", VA = "0x2E45284")]
		private void \u06D4ڟڎޜ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002793 RID: 10131 RVA: 0x000E7294 File Offset: 0x000E5494
		[Token(Token = "0x6002793")]
		[Address(RVA = "0x2E45334", Offset = "0x2E45334", VA = "0x2E45334")]
		private void \u0870߀ڿߔ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Bare Torso");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002794 RID: 10132 RVA: 0x000E7350 File Offset: 0x000E5550
		[Token(Token = "0x6002794")]
		[Address(RVA = "0x2E45544", Offset = "0x2E45544", VA = "0x2E45544")]
		private void ߊ\u066A\u05CFԉ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002795 RID: 10133 RVA: 0x000E73A8 File Offset: 0x000E55A8
		[Token(Token = "0x6002795")]
		[Address(RVA = "0x2E455F4", Offset = "0x2E455F4", VA = "0x2E455F4")]
		private void ے\u059Fࢰس(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PLAYER IS BANNED");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002796 RID: 10134 RVA: 0x000E7464 File Offset: 0x000E5664
		[Token(Token = "0x6002796")]
		[Address(RVA = "0x2E45804", Offset = "0x2E45804", VA = "0x2E45804")]
		private void ࡅڑկئ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("On");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x06002797 RID: 10135 RVA: 0x000E7520 File Offset: 0x000E5720
		[Token(Token = "0x6002797")]
		[Address(RVA = "0x2E45A14", Offset = "0x2E45A14", VA = "0x2E45A14")]
		private void ԙضփӌ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002798 RID: 10136 RVA: 0x000E7578 File Offset: 0x000E5778
		[Token(Token = "0x6002798")]
		[Address(RVA = "0x2E45AC4", Offset = "0x2E45AC4", VA = "0x2E45AC4")]
		private void \u05AEӥӺۓ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("INSIGNIFICANT CURRENCY");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x06002799 RID: 10137 RVA: 0x000E7630 File Offset: 0x000E5830
		[Token(Token = "0x6002799")]
		[Address(RVA = "0x2E45CAC", Offset = "0x2E45CAC", VA = "0x2E45CAC")]
		private void \u0879\u0748ߙݥ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x0600279A RID: 10138 RVA: 0x000E76E0 File Offset: 0x000E58E0
		[Token(Token = "0x600279A")]
		[Address(RVA = "0x2E45E94", Offset = "0x2E45E94", VA = "0x2E45E94")]
		private void \u07F5\u0657\u055Aߍ()
		{
			float num = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x0600279B RID: 10139 RVA: 0x000E7728 File Offset: 0x000E5928
		[Token(Token = "0x600279B")]
		[Address(RVA = "0x2E45F44", Offset = "0x2E45F44", VA = "0x2E45F44")]
		private void ӳڣܟޖ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("M/d/yyyy");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x0600279C RID: 10140 RVA: 0x000E77E0 File Offset: 0x000E59E0
		[Token(Token = "0x600279C")]
		[Address(RVA = "0x2E4612C", Offset = "0x2E4612C", VA = "0x2E4612C")]
		private void ޚݒ٩ݼ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("A new Player joined a Room.");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600279D RID: 10141 RVA: 0x000E7890 File Offset: 0x000E5A90
		[Token(Token = "0x600279D")]
		[Address(RVA = "0x2E4633C", Offset = "0x2E4633C", VA = "0x2E4633C")]
		private void Update()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x0600279E RID: 10142 RVA: 0x000E78E8 File Offset: 0x000E5AE8
		[Token(Token = "0x600279E")]
		[Address(RVA = "0x2E463E4", Offset = "0x2E463E4", VA = "0x2E463E4")]
		private void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x0600279F RID: 10143 RVA: 0x000E79A4 File Offset: 0x000E5BA4
		[Token(Token = "0x600279F")]
		[Address(RVA = "0x2E465F4", Offset = "0x2E465F4", VA = "0x2E465F4")]
		private void ފՖߢ\u059B()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027A0 RID: 10144 RVA: 0x000E79FC File Offset: 0x000E5BFC
		[Token(Token = "0x60027A0")]
		[Address(RVA = "0x2E466A4", Offset = "0x2E466A4", VA = "0x2E466A4")]
		private void \u07F3\u0876ߗ\u06FD(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027A1 RID: 10145 RVA: 0x000E7AB8 File Offset: 0x000E5CB8
		[Token(Token = "0x60027A1")]
		[Address(RVA = "0x2E468B4", Offset = "0x2E468B4", VA = "0x2E468B4")]
		private void \u083FԤթ\u07B2(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("True");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027A2 RID: 10146 RVA: 0x000E7B70 File Offset: 0x000E5D70
		[Token(Token = "0x60027A2")]
		[Address(RVA = "0x2E46A9C", Offset = "0x2E46A9C", VA = "0x2E46A9C")]
		private void בӵܪә(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("HandL");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027A3 RID: 10147 RVA: 0x000E7C2C File Offset: 0x000E5E2C
		[Token(Token = "0x60027A3")]
		[Address(RVA = "0x2E46CAC", Offset = "0x2E46CAC", VA = "0x2E46CAC")]
		private void د\u085Fٹ\u05F3(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Reason: ");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027A4 RID: 10148 RVA: 0x000E7CE4 File Offset: 0x000E5EE4
		[Token(Token = "0x60027A4")]
		[Address(RVA = "0x2E46EBC", Offset = "0x2E46EBC", VA = "0x2E46EBC")]
		private void \u05BAנۍ\u070C(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PURCHASED!");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027A5 RID: 10149 RVA: 0x000E7D9C File Offset: 0x000E5F9C
		[Token(Token = "0x60027A5")]
		[Address(RVA = "0x2E470A4", Offset = "0x2E470A4", VA = "0x2E470A4")]
		private void \u083Eܙ\u07FD\u0706(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeToRegular");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027A6 RID: 10150 RVA: 0x000E7E58 File Offset: 0x000E6058
		[Token(Token = "0x60027A6")]
		[Address(RVA = "0x2E472B4", Offset = "0x2E472B4", VA = "0x2E472B4")]
		private void \u06DEӸԏ\u07BF(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Date: ");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027A7 RID: 10151 RVA: 0x000E7F0C File Offset: 0x000E610C
		[Token(Token = "0x60027A7")]
		[Address(RVA = "0x2E4749C", Offset = "0x2E4749C", VA = "0x2E4749C")]
		private void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027A8 RID: 10152 RVA: 0x000E7FC8 File Offset: 0x000E61C8
		[Token(Token = "0x60027A8")]
		[Address(RVA = "0x2E476AC", Offset = "0x2E476AC", VA = "0x2E476AC")]
		private void ࠏڐ\u088Bօ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(" hour. You were banned because of ");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027A9 RID: 10153 RVA: 0x000E8080 File Offset: 0x000E6280
		[Token(Token = "0x60027A9")]
		[Address(RVA = "0x2E47894", Offset = "0x2E47894", VA = "0x2E47894")]
		private void \u0609ۯ\u05B4ؼ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027AA RID: 10154 RVA: 0x000E8138 File Offset: 0x000E6338
		[Token(Token = "0x60027AA")]
		[Address(RVA = "0x2E47A7C", Offset = "0x2E47A7C", VA = "0x2E47A7C")]
		private void գ\u0657\u0611\u0829(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("HandL");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027AB RID: 10155 RVA: 0x000E81F4 File Offset: 0x000E63F4
		[Token(Token = "0x60027AB")]
		[Address(RVA = "0x2E47C8C", Offset = "0x2E47C8C", VA = "0x2E47C8C")]
		private void ۅ\u05A6\u05A4ӵ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PRESS AGAIN TO CONFIRM");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027AC RID: 10156 RVA: 0x000E82A8 File Offset: 0x000E64A8
		[Token(Token = "0x60027AC")]
		[Address(RVA = "0x2E47E74", Offset = "0x2E47E74", VA = "0x2E47E74")]
		private void ܫ\u070Fۃ\u07F2()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027AD RID: 10157 RVA: 0x000E8300 File Offset: 0x000E6500
		[Token(Token = "0x60027AD")]
		[Address(RVA = "0x2E47F24", Offset = "0x2E47F24", VA = "0x2E47F24")]
		private void ҽײֈ\u082C(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Target");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027AE RID: 10158 RVA: 0x000E83AC File Offset: 0x000E65AC
		[Token(Token = "0x60027AE")]
		[Address(RVA = "0x2E4810C", Offset = "0x2E4810C", VA = "0x2E4810C")]
		private void \u05F7ԝߠӱ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027AF RID: 10159 RVA: 0x000E8404 File Offset: 0x000E6604
		[Token(Token = "0x60027AF")]
		[Address(RVA = "0x2E481BC", Offset = "0x2E481BC", VA = "0x2E481BC")]
		private void \u070C\u05FD\u07F9ܬ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Faild To Add Winner Money: ");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027B0 RID: 10160 RVA: 0x000E84BC File Offset: 0x000E66BC
		[Token(Token = "0x60027B0")]
		[Address(RVA = "0x2E483A4", Offset = "0x2E483A4", VA = "0x2E483A4")]
		private void Ӝ\u0558ө\u070C(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027B1 RID: 10161 RVA: 0x000E8574 File Offset: 0x000E6774
		[Token(Token = "0x60027B1")]
		[Address(RVA = "0x2E4858C", Offset = "0x2E4858C", VA = "0x2E4858C")]
		private void \u05A0ڵ\u0823ڈ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Game Started");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027B2 RID: 10162 RVA: 0x000E862C File Offset: 0x000E682C
		[Token(Token = "0x60027B2")]
		[Address(RVA = "0x2E48774", Offset = "0x2E48774", VA = "0x2E48774")]
		private void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("NetworkPlayer");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027B3 RID: 10163 RVA: 0x000E86E8 File Offset: 0x000E68E8
		[Token(Token = "0x60027B3")]
		[Address(RVA = "0x2E48984", Offset = "0x2E48984", VA = "0x2E48984")]
		private void Ӣ\u0592ߨׯ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027B4 RID: 10164 RVA: 0x000E8740 File Offset: 0x000E6940
		[Token(Token = "0x60027B4")]
		[Address(RVA = "0x2E48A34", Offset = "0x2E48A34", VA = "0x2E48A34")]
		private void ل\u0732ߍӒ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("True");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027B5 RID: 10165 RVA: 0x000E87FC File Offset: 0x000E69FC
		[Token(Token = "0x60027B5")]
		[Address(RVA = "0x2E48C44", Offset = "0x2E48C44", VA = "0x2E48C44")]
		private void ࢳ\u06D8Ԙ\u05FD(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Regular");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027B6 RID: 10166 RVA: 0x000E88B8 File Offset: 0x000E6AB8
		[Token(Token = "0x60027B6")]
		[Address(RVA = "0x2E48E54", Offset = "0x2E48E54", VA = "0x2E48E54")]
		private void \u05C4ݳ\u05BCࡂ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027B7 RID: 10167 RVA: 0x000E8910 File Offset: 0x000E6B10
		[Token(Token = "0x60027B7")]
		[Address(RVA = "0x2E48F04", Offset = "0x2E48F04", VA = "0x2E48F04")]
		private void \u05C1ؽԜࡥ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027B8 RID: 10168 RVA: 0x000E89C8 File Offset: 0x000E6BC8
		[Token(Token = "0x60027B8")]
		[Address(RVA = "0x2E490EC", Offset = "0x2E490EC", VA = "0x2E490EC")]
		private void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("got funky mone");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027B9 RID: 10169 RVA: 0x000E8A84 File Offset: 0x000E6C84
		[Token(Token = "0x60027B9")]
		[Address(RVA = "0x2E492FC", Offset = "0x2E492FC", VA = "0x2E492FC")]
		private void ࠈ\u07A9\u05B3Ծ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027BA RID: 10170 RVA: 0x000E8ADC File Offset: 0x000E6CDC
		[Token(Token = "0x60027BA")]
		[Address(RVA = "0x2E493AC", Offset = "0x2E493AC", VA = "0x2E493AC")]
		private void سࡕԞ߆(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("monke is not my monke");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027BB RID: 10171 RVA: 0x000E8B98 File Offset: 0x000E6D98
		[Token(Token = "0x60027BB")]
		[Address(RVA = "0x2E495BC", Offset = "0x2E495BC", VA = "0x2E495BC")]
		private void ݛ\u0599\u05C2ڒ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027BC RID: 10172 RVA: 0x000E8BF0 File Offset: 0x000E6DF0
		[Token(Token = "0x60027BC")]
		[Address(RVA = "0x2E4966C", Offset = "0x2E4966C", VA = "0x2E4966C")]
		private void ݫࢷࠃ\u0820()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Physics.gravity = transform.localScale;
		}

		// Token: 0x060027BD RID: 10173 RVA: 0x000E8C48 File Offset: 0x000E6E48
		[Token(Token = "0x60027BD")]
		[Address(RVA = "0x2E4971C", Offset = "0x2E4971C", VA = "0x2E4971C")]
		private void ݫ\u086Dثآ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027BE RID: 10174 RVA: 0x000E8D00 File Offset: 0x000E6F00
		[Token(Token = "0x60027BE")]
		[Address(RVA = "0x2E49904", Offset = "0x2E49904", VA = "0x2E49904")]
		private void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Add/Remove Glasses");
		}

		// Token: 0x060027BF RID: 10175 RVA: 0x000E8DAC File Offset: 0x000E6FAC
		[Token(Token = "0x60027BF")]
		[Address(RVA = "0x2E49AEC", Offset = "0x2E49AEC", VA = "0x2E49AEC")]
		private void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("MetaAuth");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027C0 RID: 10176 RVA: 0x000E8E60 File Offset: 0x000E7060
		[Token(Token = "0x60027C0")]
		[Address(RVA = "0x2E49CFC", Offset = "0x2E49CFC", VA = "0x2E49CFC")]
		private void ࢲ\u061C\u0817ݽ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ENABLE");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027C1 RID: 10177 RVA: 0x000E8F1C File Offset: 0x000E711C
		[Token(Token = "0x60027C1")]
		[Address(RVA = "0x2E49F0C", Offset = "0x2E49F0C", VA = "0x2E49F0C")]
		private void \u0825\u05CEݍ\u083C(Collider \u07FEל\u05AC\u0877)
		{
			GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027C2 RID: 10178 RVA: 0x000E8FCC File Offset: 0x000E71CC
		[Token(Token = "0x60027C2")]
		[Address(RVA = "0x2E4A0F4", Offset = "0x2E4A0F4", VA = "0x2E4A0F4")]
		private void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027C3 RID: 10179 RVA: 0x000E9084 File Offset: 0x000E7284
		[Token(Token = "0x60027C3")]
		[Address(RVA = "0x2E4A2DC", Offset = "0x2E4A2DC", VA = "0x2E4A2DC")]
		private void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Is Colliding");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027C4 RID: 10180 RVA: 0x000E913C File Offset: 0x000E733C
		[Token(Token = "0x60027C4")]
		[Address(RVA = "0x2E4A4C4", Offset = "0x2E4A4C4", VA = "0x2E4A4C4")]
		public sizeChanger()
		{
		}

		// Token: 0x060027C5 RID: 10181 RVA: 0x000E9150 File Offset: 0x000E7350
		[Token(Token = "0x60027C5")]
		[Address(RVA = "0x2E4A4D8", Offset = "0x2E4A4D8", VA = "0x2E4A4D8")]
		private void ڷ\u0826ӹڥ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Thumb");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027C6 RID: 10182 RVA: 0x000E9204 File Offset: 0x000E7404
		[Token(Token = "0x60027C6")]
		[Address(RVA = "0x2E4A6C0", Offset = "0x2E4A6C0", VA = "0x2E4A6C0")]
		private void \u05C1ޔӃ۸()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027C7 RID: 10183 RVA: 0x000E925C File Offset: 0x000E745C
		[Token(Token = "0x60027C7")]
		[Address(RVA = "0x2E4A770", Offset = "0x2E4A770", VA = "0x2E4A770")]
		private void \u07FB\u07BC\u0887ӟ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027C8 RID: 10184 RVA: 0x000E92B4 File Offset: 0x000E74B4
		[Token(Token = "0x60027C8")]
		[Address(RVA = "0x2E4A820", Offset = "0x2E4A820", VA = "0x2E4A820")]
		private void ࡘ\u0891ࢥ\u07ED(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027C9 RID: 10185 RVA: 0x000E936C File Offset: 0x000E756C
		[Token(Token = "0x60027C9")]
		[Address(RVA = "0x2E4AA08", Offset = "0x2E4AA08", VA = "0x2E4AA08")]
		private void Ӧد\u060Eࡏ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027CA RID: 10186 RVA: 0x000E93AC File Offset: 0x000E75AC
		[Token(Token = "0x60027CA")]
		[Address(RVA = "0x2E4AAB8", Offset = "0x2E4AAB8", VA = "0x2E4AAB8")]
		private void ݹ\u082Cلտ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("DisableCosmetic");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027CB RID: 10187 RVA: 0x000E944C File Offset: 0x000E764C
		[Token(Token = "0x60027CB")]
		[Address(RVA = "0x2E4ACA0", Offset = "0x2E4ACA0", VA = "0x2E4ACA0")]
		private void ی\u0823ڇݔ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027CC RID: 10188 RVA: 0x000E94A4 File Offset: 0x000E76A4
		[Token(Token = "0x60027CC")]
		[Address(RVA = "0x2E4AD50", Offset = "0x2E4AD50", VA = "0x2E4AD50")]
		private void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("amongus");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027CD RID: 10189 RVA: 0x000E955C File Offset: 0x000E775C
		[Token(Token = "0x60027CD")]
		[Address(RVA = "0x2E4AF38", Offset = "0x2E4AF38", VA = "0x2E4AF38")]
		private void \u07FE߆לى(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Combine textures & build combined mesh all at once");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027CE RID: 10190 RVA: 0x000E9618 File Offset: 0x000E7818
		[Token(Token = "0x60027CE")]
		[Address(RVA = "0x2E4B148", Offset = "0x2E4B148", VA = "0x2E4B148")]
		private void \u07B3\u07BD\u05FF\u0859(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PLAYER IS BANNED");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027CF RID: 10191 RVA: 0x000E96D4 File Offset: 0x000E78D4
		[Token(Token = "0x60027CF")]
		[Address(RVA = "0x2E4B358", Offset = "0x2E4B358", VA = "0x2E4B358")]
		private void ڇ۹ժד(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027D0 RID: 10192 RVA: 0x000E9790 File Offset: 0x000E7990
		[Token(Token = "0x60027D0")]
		[Address(RVA = "0x2E4B568", Offset = "0x2E4B568", VA = "0x2E4B568")]
		private void \u0589\u0740\u05C6ӧ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Try Connect To Server...");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027D1 RID: 10193 RVA: 0x000E984C File Offset: 0x000E7A4C
		[Token(Token = "0x60027D1")]
		[Address(RVA = "0x2E4B778", Offset = "0x2E4B778", VA = "0x2E4B778")]
		private void ԜӞ\u05AD\u088C()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027D2 RID: 10194 RVA: 0x000E98A4 File Offset: 0x000E7AA4
		[Token(Token = "0x60027D2")]
		[Address(RVA = "0x2E4B828", Offset = "0x2E4B828", VA = "0x2E4B828")]
		private void ࡕߕ\u0707ݩ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027D3 RID: 10195 RVA: 0x000E98FC File Offset: 0x000E7AFC
		[Token(Token = "0x60027D3")]
		[Address(RVA = "0x2E4B8D8", Offset = "0x2E4B8D8", VA = "0x2E4B8D8")]
		private void \u085Dۍ\u0659Ӂ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027D4 RID: 10196 RVA: 0x000E9954 File Offset: 0x000E7B54
		[Token(Token = "0x60027D4")]
		[Address(RVA = "0x2E4B988", Offset = "0x2E4B988", VA = "0x2E4B988")]
		private void ࡥշӞھ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027D5 RID: 10197 RVA: 0x000E99AC File Offset: 0x000E7BAC
		[Token(Token = "0x60027D5")]
		[Address(RVA = "0x2E4BA38", Offset = "0x2E4BA38", VA = "0x2E4BA38")]
		private void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ErrorScreen");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027D6 RID: 10198 RVA: 0x000E9A58 File Offset: 0x000E7C58
		[Token(Token = "0x60027D6")]
		[Address(RVA = "0x2E4BC20", Offset = "0x2E4BC20", VA = "0x2E4BC20")]
		private void \u0819Փٲࡪ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Hats");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027D7 RID: 10199 RVA: 0x000E9B10 File Offset: 0x000E7D10
		[Token(Token = "0x60027D7")]
		[Address(RVA = "0x2E4BE08", Offset = "0x2E4BE08", VA = "0x2E4BE08")]
		private void ք\u05FEؽ\u061E(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("sound play play");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027D8 RID: 10200 RVA: 0x000E9BC8 File Offset: 0x000E7DC8
		[Token(Token = "0x60027D8")]
		[Address(RVA = "0x2E4BFF0", Offset = "0x2E4BFF0", VA = "0x2E4BFF0")]
		private void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Date: ");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027D9 RID: 10201 RVA: 0x000E9C80 File Offset: 0x000E7E80
		[Token(Token = "0x60027D9")]
		[Address(RVA = "0x2E4C1D8", Offset = "0x2E4C1D8", VA = "0x2E4C1D8")]
		private void \u0833ٮڒՄ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("This is the 1000 Bananas button, and it was just clicked");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027DA RID: 10202 RVA: 0x000E9D38 File Offset: 0x000E7F38
		[Token(Token = "0x60027DA")]
		[Address(RVA = "0x2E4C3C0", Offset = "0x2E4C3C0", VA = "0x2E4C3C0")]
		private void ٳךߧع(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Connected to Server.");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027DB RID: 10203 RVA: 0x000E9DF4 File Offset: 0x000E7FF4
		[Token(Token = "0x60027DB")]
		[Address(RVA = "0x2E4C5D0", Offset = "0x2E4C5D0", VA = "0x2E4C5D0")]
		private void ࡀڮӌߕ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027DC RID: 10204 RVA: 0x000E9E4C File Offset: 0x000E804C
		[Token(Token = "0x60027DC")]
		[Address(RVA = "0x2E4C680", Offset = "0x2E4C680", VA = "0x2E4C680")]
		private void \u0607յ\u061C\u083D(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027DD RID: 10205 RVA: 0x000E9F04 File Offset: 0x000E8104
		[Token(Token = "0x60027DD")]
		[Address(RVA = "0x2E4C868", Offset = "0x2E4C868", VA = "0x2E4C868")]
		private void \u07FF\u05BCޥڡ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Body");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027DE RID: 10206 RVA: 0x000E9FBC File Offset: 0x000E81BC
		[Token(Token = "0x60027DE")]
		[Address(RVA = "0x2E4CA50", Offset = "0x2E4CA50", VA = "0x2E4CA50")]
		private void ד\u073C\u0613چ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027DF RID: 10207 RVA: 0x000EA014 File Offset: 0x000E8214
		[Token(Token = "0x60027DF")]
		[Address(RVA = "0x2E4CB00", Offset = "0x2E4CB00", VA = "0x2E4CB00")]
		private void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("typesOfTalk");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027E0 RID: 10208 RVA: 0x000EA0D0 File Offset: 0x000E82D0
		[Token(Token = "0x60027E0")]
		[Address(RVA = "0x2E4CD10", Offset = "0x2E4CD10", VA = "0x2E4CD10")]
		private void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027E1 RID: 10209 RVA: 0x000EA18C File Offset: 0x000E838C
		[Token(Token = "0x60027E1")]
		[Address(RVA = "0x2E4CF20", Offset = "0x2E4CF20", VA = "0x2E4CF20")]
		private void ߃\u0602\u0891߇(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayWave");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027E2 RID: 10210 RVA: 0x000EA248 File Offset: 0x000E8448
		[Token(Token = "0x60027E2")]
		[Address(RVA = "0x2E4D130", Offset = "0x2E4D130", VA = "0x2E4D130")]
		private void \u066A\u0603Ӥܔ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Tagging");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027E3 RID: 10211 RVA: 0x000EA300 File Offset: 0x000E8500
		[Token(Token = "0x60027E3")]
		[Address(RVA = "0x2E4D318", Offset = "0x2E4D318", VA = "0x2E4D318")]
		private void ԣԭՋࠏ()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027E4 RID: 10212 RVA: 0x000EA358 File Offset: 0x000E8558
		[Token(Token = "0x60027E4")]
		[Address(RVA = "0x2E4D3C8", Offset = "0x2E4D3C8", VA = "0x2E4D3C8")]
		private void ࢷࢯ\u05B2ݸ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Connected to Server.");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027E5 RID: 10213 RVA: 0x000EA410 File Offset: 0x000E8610
		[Token(Token = "0x60027E5")]
		[Address(RVA = "0x2E4D5B0", Offset = "0x2E4D5B0", VA = "0x2E4D5B0")]
		private void \u0670Ր\u0741Ӵ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("User has been reported for: ");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027E6 RID: 10214 RVA: 0x000EA4CC File Offset: 0x000E86CC
		[Token(Token = "0x60027E6")]
		[Address(RVA = "0x2E4D7C0", Offset = "0x2E4D7C0", VA = "0x2E4D7C0")]
		private void \u059B\u081F\u05FEڂ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027E7 RID: 10215 RVA: 0x000EA584 File Offset: 0x000E8784
		[Token(Token = "0x60027E7")]
		[Address(RVA = "0x2E4D9A8", Offset = "0x2E4D9A8", VA = "0x2E4D9A8")]
		private void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ = this.ݕ\u05A3ܙࢺ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float ݕ_u05A3ܙࢺ2 = this.ݕ\u05A3ܙࢺ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027E8 RID: 10216 RVA: 0x000EA640 File Offset: 0x000E8840
		[Token(Token = "0x60027E8")]
		[Address(RVA = "0x2E4DBB8", Offset = "0x2E4DBB8", VA = "0x2E4DBB8")]
		private void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Reason: ");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027E9 RID: 10217 RVA: 0x000EA6F8 File Offset: 0x000E88F8
		[Token(Token = "0x60027E9")]
		[Address(RVA = "0x2E4DDA0", Offset = "0x2E4DDA0", VA = "0x2E4DDA0")]
		private void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("On");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027EA RID: 10218 RVA: 0x000EA7B0 File Offset: 0x000E89B0
		[Token(Token = "0x60027EA")]
		[Address(RVA = "0x2E4DF88", Offset = "0x2E4DF88", VA = "0x2E4DF88")]
		private void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("isLava");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve u058Bދثح2 = this.\u058Bދثح;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2 = u058Bދثح2.Evaluate(time);
			float num = Mathf.Clamp01(value2);
		}

		// Token: 0x060027EB RID: 10219 RVA: 0x000EA86C File Offset: 0x000E8A6C
		[Token(Token = "0x60027EB")]
		[Address(RVA = "0x2E4E198", Offset = "0x2E4E198", VA = "0x2E4E198")]
		private void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(" and the correct version is ");
			if (this.ہ\u064C\u0886\u089E == null)
			{
				return;
			}
		}

		// Token: 0x060027EC RID: 10220 RVA: 0x000EA924 File Offset: 0x000E8B24
		[Token(Token = "0x60027EC")]
		[Address(RVA = "0x2E4E380", Offset = "0x2E4E380", VA = "0x2E4E380")]
		private void ޒ\u0816Ӑ۱()
		{
			float տݞ٤վ = this.Տݞ٤վ;
			float num = this.ࠔؼࡏݥ;
			float num2 = this.speedChanging;
			float deltaTime = Time.deltaTime;
			GameObject u05EEݠ_u05FFը = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը;
			this.ܗ۷\u0896\u0884 = u05EEݠ_u05FFը;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060027ED RID: 10221 RVA: 0x000EA97C File Offset: 0x000E8B7C
		[Token(Token = "0x60027ED")]
		[Address(RVA = "0x2E4E430", Offset = "0x2E4E430", VA = "0x2E4E430")]
		private void Ԣݳفٴ(Collider \u07FEל\u05AC\u0877)
		{
			bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("A new Player joined a Room.");
			GameObject[] ہ_u064C_u0886_u089E = this.ہ\u064C\u0886\u089E;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			AnimationCurve u058Bދثح = this.\u058Bދثح;
			float տݞ٤վ = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ = this.\u06E1\u07BC\u081CӜ;
			float value;
			float num = Mathf.Clamp01(value);
			Transform transform = this.ܗ۷\u0896\u0884.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			float տݞ٤վ2 = this.Տݞ٤վ;
			float u06E1_u07BC_u081CӜ2 = this.\u06E1\u07BC\u081CӜ;
			float value2;
			float num2 = Mathf.Clamp01(value2);
		}

		// Token: 0x04000502 RID: 1282
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000502")]
		public GameObject[] ہ\u064C\u0886\u089E;

		// Token: 0x04000503 RID: 1283
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000503")]
		public float ݕ\u05A3ܙࢺ;

		// Token: 0x04000504 RID: 1284
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4000504")]
		private float \u06E1\u07BC\u081CӜ;

		// Token: 0x04000505 RID: 1285
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000505")]
		[SerializeField]
		[Header("How fast shall it change?")]
		private float speedChanging;

		// Token: 0x04000506 RID: 1286
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000506")]
		public AnimationCurve \u058Bދثح;

		// Token: 0x04000507 RID: 1287
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000507")]
		public NetworkPlayerSpawner ݺ\u05F9פݵ;

		// Token: 0x04000508 RID: 1288
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000508")]
		public GameObject ܗ۷\u0896\u0884;

		// Token: 0x04000509 RID: 1289
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000509")]
		[HideInInspector]
		private float Տݞ٤վ;

		// Token: 0x0400050A RID: 1290
		[FieldOffset(Offset = "0x4C")]
		[Token(Token = "0x400050A")]
		[HideInInspector]
		private float ࠔؼࡏݥ;
	}
}
