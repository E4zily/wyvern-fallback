﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000076 RID: 118
[Token(Token = "0x2000076")]
public class MB_SwapShirts : MonoBehaviour
{
	// Token: 0x060011DF RID: 4575 RVA: 0x0006884C File Offset: 0x00066A4C
	[Token(Token = "0x60011DF")]
	[Address(RVA = "0x2C679A4", Offset = "0x2C679A4", VA = "0x2C679A4")]
	private void \u066D\u05BDې߃()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_47;
			}
			if (typeof(GameObject[]).TypeHandle == null)
			{
				goto IL_41;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_41:
		throw new IndexOutOfRangeException();
		IL_47:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011E0 RID: 4576 RVA: 0x000688A8 File Offset: 0x00066AA8
	[Token(Token = "0x60011E0")]
	[Address(RVA = "0x2C67ADC", Offset = "0x2C67ADC", VA = "0x2C67ADC")]
	private void \u082E\u06EBݼڏ()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_33;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_33:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011E1 RID: 4577 RVA: 0x000688F0 File Offset: 0x00066AF0
	[Token(Token = "0x60011E1")]
	[Address(RVA = "0x2C67C3C", Offset = "0x2C67C3C", VA = "0x2C67C3C")]
	private void OnGUI()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.ژ\u06FD\u0595\u088A(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.ژ\u06FD\u0595\u088A(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.ژ\u06FD\u0595\u088A(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x060011E2 RID: 4578 RVA: 0x00068938 File Offset: 0x00066B38
	[Token(Token = "0x60011E2")]
	[Address(RVA = "0x2C6843C", Offset = "0x2C6843C", VA = "0x2C6843C")]
	private void \u0656ӺմՁ()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_3B;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_3B:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011E3 RID: 4579 RVA: 0x00068988 File Offset: 0x00066B88
	[Token(Token = "0x60011E3")]
	[Address(RVA = "0x2C67EB0", Offset = "0x2C67EB0", VA = "0x2C67EB0")]
	private void ژ\u06FD\u0595\u088A(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x060011E4 RID: 4580 RVA: 0x00068A2C File Offset: 0x00066C2C
	[Token(Token = "0x60011E4")]
	[Address(RVA = "0x2C68578", Offset = "0x2C68578", VA = "0x2C68578")]
	private void ۃ\u087EڴՊ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.ࢳ\u061B\u082Eث(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.ۋ\u0598\u07F7ف(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.\u05B2עٺ\u06DF(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x060011E5 RID: 4581 RVA: 0x00068A74 File Offset: 0x00066C74
	[Token(Token = "0x60011E5")]
	[Address(RVA = "0x2C69718", Offset = "0x2C69718", VA = "0x2C69718")]
	private void Ӻא\u059Bڭ(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x060011E6 RID: 4582 RVA: 0x00068AEC File Offset: 0x00066CEC
	[Token(Token = "0x60011E6")]
	[Address(RVA = "0x2C69B80", Offset = "0x2C69B80", VA = "0x2C69B80")]
	private void ى\u05F4ڷ߉()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.\u05CA\u07EBք\u07A6(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.\u088A\u0616Ԗࢬ(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
	}

	// Token: 0x060011E7 RID: 4583 RVA: 0x00068B24 File Offset: 0x00066D24
	[Token(Token = "0x60011E7")]
	[Address(RVA = "0x2C6AE4C", Offset = "0x2C6AE4C", VA = "0x2C6AE4C")]
	private void \u070Fߨ\u05B0ۈ()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_40;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_40:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011E8 RID: 4584 RVA: 0x00068B78 File Offset: 0x00066D78
	[Token(Token = "0x60011E8")]
	[Address(RVA = "0x2C6AFAC", Offset = "0x2C6AFAC", VA = "0x2C6AFAC")]
	public MB_SwapShirts()
	{
	}

	// Token: 0x060011E9 RID: 4585 RVA: 0x00068B8C File Offset: 0x00066D8C
	[Token(Token = "0x60011E9")]
	[Address(RVA = "0x2C6AFB4", Offset = "0x2C6AFB4", VA = "0x2C6AFB4")]
	private void \u0859\u0895ӇԚ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.\u07AF\u082E\u085Bࢹ(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.\u083Bࡩ\u0890\u05C8(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.\u083Bࡩ\u0890\u05C8(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x060011EA RID: 4586 RVA: 0x00068BD4 File Offset: 0x00066DD4
	[Token(Token = "0x60011EA")]
	[Address(RVA = "0x2C6BD24", Offset = "0x2C6BD24", VA = "0x2C6BD24")]
	private void ܡӯ\u06E8\u07B0()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.\u07AF\u082E\u085Bࢹ(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.\u05B2עٺ\u06DF(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.\u083Bࡩ\u0890\u05C8(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x060011EB RID: 4587 RVA: 0x00068C1C File Offset: 0x00066E1C
	[Token(Token = "0x60011EB")]
	[Address(RVA = "0x2C6BF98", Offset = "0x2C6BF98", VA = "0x2C6BF98")]
	private void \u07F7ե\u081Fܗ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.\u07AF\u082E\u085Bࢹ(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.\u07AF\u082E\u085Bࢹ(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.\u083Bࡩ\u0890\u05C8(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x060011EC RID: 4588 RVA: 0x00068C64 File Offset: 0x00066E64
	[Token(Token = "0x60011EC")]
	[Address(RVA = "0x2C6C20C", Offset = "0x2C6C20C", VA = "0x2C6C20C")]
	private void ݤۅࢦӃ()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_47;
			}
			if (typeof(GameObject[]).TypeHandle == null)
			{
				goto IL_41;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_41:
		throw new IndexOutOfRangeException();
		IL_47:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011ED RID: 4589 RVA: 0x00068CC0 File Offset: 0x00066EC0
	[Token(Token = "0x60011ED")]
	[Address(RVA = "0x2C6C344", Offset = "0x2C6C344", VA = "0x2C6C344")]
	private void ݴ٦\u0872\u0703(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
	}

	// Token: 0x060011EE RID: 4590 RVA: 0x00068D88 File Offset: 0x00066F88
	[Token(Token = "0x60011EE")]
	[Address(RVA = "0x2C6C8C4", Offset = "0x2C6C8C4", VA = "0x2C6C8C4")]
	private void ןٮ\u061FԺ()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_43;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_43:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011EF RID: 4591 RVA: 0x00068DE0 File Offset: 0x00066FE0
	[Token(Token = "0x60011EF")]
	[Address(RVA = "0x2C6CA24", Offset = "0x2C6CA24", VA = "0x2C6CA24")]
	private void ࢥ\u081CՕࡋ()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_40;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_40:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011F0 RID: 4592 RVA: 0x00068E34 File Offset: 0x00067034
	[Token(Token = "0x60011F0")]
	[Address(RVA = "0x2C6CB60", Offset = "0x2C6CB60", VA = "0x2C6CB60")]
	private void \u0834\u0817ރࡔ()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_40;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_40:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011F1 RID: 4593 RVA: 0x00068E88 File Offset: 0x00067088
	[Token(Token = "0x60011F1")]
	[Address(RVA = "0x2C6CCC0", Offset = "0x2C6CCC0", VA = "0x2C6CCC0")]
	private void چאӣک()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.ݴ٦\u0872\u0703(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.ۋ\u0598\u07F7ف(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.\u05CA\u07EBք\u07A6(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x060011F2 RID: 4594 RVA: 0x00068ED0 File Offset: 0x000670D0
	[Token(Token = "0x60011F2")]
	[Address(RVA = "0x2C6CF34", Offset = "0x2C6CF34", VA = "0x2C6CF34")]
	private void ҿ\u07BBҽ\u0599()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.ࢨ\u085D\u0859ՠ(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.\u083Bࡩ\u0890\u05C8(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.\u083Bࡩ\u0890\u05C8(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x060011F3 RID: 4595 RVA: 0x00068F18 File Offset: 0x00067118
	[Token(Token = "0x60011F3")]
	[Address(RVA = "0x2C6D6EC", Offset = "0x2C6D6EC", VA = "0x2C6D6EC")]
	private void Ӄۇރࡑ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.Ӻא\u059Bڭ(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.ޝԳ\u05FC٦(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.\u05B2עٺ\u06DF(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x060011F4 RID: 4596 RVA: 0x00068F60 File Offset: 0x00067160
	[Token(Token = "0x60011F4")]
	[Address(RVA = "0x2C6A908", Offset = "0x2C6A908", VA = "0x2C6A908")]
	private void ޝԳ\u05FC٦(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x060011F5 RID: 4597 RVA: 0x00068FF0 File Offset: 0x000671F0
	[Token(Token = "0x60011F5")]
	[Address(RVA = "0x2C6B7A0", Offset = "0x2C6B7A0", VA = "0x2C6B7A0")]
	private void \u083Bࡩ\u0890\u05C8(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
	}

	// Token: 0x060011F6 RID: 4598 RVA: 0x00069090 File Offset: 0x00067290
	[Token(Token = "0x60011F6")]
	[Address(RVA = "0x2C687EC", Offset = "0x2C687EC", VA = "0x2C687EC")]
	private void ࢳ\u061B\u082Eث(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
	}

	// Token: 0x060011F7 RID: 4599 RVA: 0x00069108 File Offset: 0x00067308
	[Token(Token = "0x60011F7")]
	[Address(RVA = "0x2C6D960", Offset = "0x2C6D960", VA = "0x2C6D960")]
	private void ہډࠉӥ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.Ӻא\u059Bڭ(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.\u07AF\u082E\u085Bࢹ(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.ࢨ\u085D\u0859ՠ(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x060011F8 RID: 4600 RVA: 0x00069150 File Offset: 0x00067350
	[Token(Token = "0x60011F8")]
	[Address(RVA = "0x2C69DF4", Offset = "0x2C69DF4", VA = "0x2C69DF4")]
	private void \u05CA\u07EBք\u07A6(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
	}

	// Token: 0x060011F9 RID: 4601 RVA: 0x00069214 File Offset: 0x00067414
	[Token(Token = "0x60011F9")]
	[Address(RVA = "0x2C6DBD4", Offset = "0x2C6DBD4", VA = "0x2C6DBD4")]
	private void ӛ\u082Eؿڕ()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_40;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_40:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011FA RID: 4602 RVA: 0x00069268 File Offset: 0x00067468
	[Token(Token = "0x60011FA")]
	[Address(RVA = "0x2C6DD10", Offset = "0x2C6DD10", VA = "0x2C6DD10")]
	private void نո\u0599\u0589()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_43;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_43:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011FB RID: 4603 RVA: 0x000692C0 File Offset: 0x000674C0
	[Token(Token = "0x60011FB")]
	[Address(RVA = "0x2C6DE70", Offset = "0x2C6DE70", VA = "0x2C6DE70")]
	private void ۆڛߟ\u05A0()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_40;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_40:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011FC RID: 4604 RVA: 0x00069314 File Offset: 0x00067514
	[Token(Token = "0x60011FC")]
	[Address(RVA = "0x2C6DFD0", Offset = "0x2C6DFD0", VA = "0x2C6DFD0")]
	private void \u05ABݿࡋ\u06E9()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_43;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_43:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011FD RID: 4605 RVA: 0x0006936C File Offset: 0x0006756C
	[Token(Token = "0x60011FD")]
	[Address(RVA = "0x2C6B228", Offset = "0x2C6B228", VA = "0x2C6B228")]
	private void \u07AF\u082E\u085Bࢹ(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x060011FE RID: 4606 RVA: 0x00069408 File Offset: 0x00067608
	[Token(Token = "0x60011FE")]
	[Address(RVA = "0x2C6E130", Offset = "0x2C6E130", VA = "0x2C6E130")]
	private void ࡩݮڢՠ()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_47;
			}
			if (typeof(GameObject[]).TypeHandle == null)
			{
				goto IL_41;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_41:
		throw new IndexOutOfRangeException();
		IL_47:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060011FF RID: 4607 RVA: 0x00069464 File Offset: 0x00067664
	[Token(Token = "0x60011FF")]
	[Address(RVA = "0x2C6E268", Offset = "0x2C6E268", VA = "0x2C6E268")]
	private void ܩ\u06E2߈ջ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.\u07AF\u082E\u085Bࢹ(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.ݴ٦\u0872\u0703(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.Ӻא\u059Bڭ(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x06001200 RID: 4608 RVA: 0x000694AC File Offset: 0x000676AC
	[Token(Token = "0x6001200")]
	[Address(RVA = "0x2C6E4DC", Offset = "0x2C6E4DC", VA = "0x2C6E4DC")]
	private void \u05CAө\u0872\u058F()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		Renderer[] u05CF_u065Aի_u = this.\u05CF\u065Aի\u0741;
		this.\u083Bࡩ\u0890\u05C8(u05CF_u065Aի_u);
		if (num == 0L)
		{
		}
		Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
		this.ޝԳ\u05FC٦(u0831ق_u070D_u);
		if (num == 0L)
		{
		}
		Renderer[] u07F8_u070C_u0889Ճ = this.\u07F8\u070C\u0889Ճ;
		this.\u083Bࡩ\u0890\u05C8(u07F8_u070C_u0889Ճ);
	}

	// Token: 0x06001201 RID: 4609 RVA: 0x000694F4 File Offset: 0x000676F4
	[Token(Token = "0x6001201")]
	[Address(RVA = "0x2C68C54", Offset = "0x2C68C54", VA = "0x2C68C54")]
	private void ۋ\u0598\u07F7ف(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001202 RID: 4610 RVA: 0x00069590 File Offset: 0x00067790
	[Token(Token = "0x6001202")]
	[Address(RVA = "0x2C6E750", Offset = "0x2C6E750", VA = "0x2C6E750")]
	private void Start()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_43;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_43:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001203 RID: 4611 RVA: 0x000695E8 File Offset: 0x000677E8
	[Token(Token = "0x6001203")]
	[Address(RVA = "0x2C691D4", Offset = "0x2C691D4", VA = "0x2C691D4")]
	private void \u05B2עٺ\u06DF(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001204 RID: 4612 RVA: 0x00069678 File Offset: 0x00067878
	[Token(Token = "0x6001204")]
	[Address(RVA = "0x2C6D1A0", Offset = "0x2C6D1A0", VA = "0x2C6D1A0")]
	private void ࢨ\u085D\u0859ՠ(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001205 RID: 4613 RVA: 0x00069734 File Offset: 0x00067934
	[Token(Token = "0x6001205")]
	[Address(RVA = "0x2C6A37C", Offset = "0x2C6A37C", VA = "0x2C6A37C")]
	private void \u088A\u0616Ԗࢬ(Renderer[] آࡓڦ߁)
	{
		List<GameObject> list = new List();
		MB3_MeshBaker ݽ_u06E2ս_u06D = this.ݽ\u06E2ս\u06D7;
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		if (typeof(Debug).TypeHandle == null)
		{
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001206 RID: 4614 RVA: 0x000697D8 File Offset: 0x000679D8
	[Token(Token = "0x6001206")]
	[Address(RVA = "0x2C6E8B0", Offset = "0x2C6E8B0", VA = "0x2C6E8B0")]
	private void ݸԲ\u0616Ԫ()
	{
		do
		{
			Renderer[] u0831ق_u070D_u = this.\u0831ق\u070D\u0870;
			Renderer[] u0831ق_u070D_u2 = this.\u0831ق\u070D\u0870;
			GameObject gameObject;
			if (gameObject != null && gameObject == null)
			{
				goto IL_43;
			}
		}
		while (this.\u0831ق\u070D\u0870 != null);
		throw new NullReferenceException();
		IL_43:
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0400024F RID: 591
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400024F")]
	public MB3_MeshBaker ݽ\u06E2ս\u06D7;

	// Token: 0x04000250 RID: 592
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000250")]
	public Renderer[] \u0831ق\u070D\u0870;

	// Token: 0x04000251 RID: 593
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000251")]
	public Renderer[] \u07F8\u070C\u0889Ճ;

	// Token: 0x04000252 RID: 594
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000252")]
	public Renderer[] \u05CF\u065Aի\u0741;
}
