﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x020000AF RID: 175
[Token(Token = "0x20000AF")]
public class DisplayLogsToText : MonoBehaviour
{
	// Token: 0x060019DB RID: 6619 RVA: 0x0008B4D8 File Offset: 0x000896D8
	[Token(Token = "0x60019DB")]
	[Address(RVA = "0x28A7B18", Offset = "0x28A7B18", VA = "0x28A7B18")]
	private void \u06D4ڟڎޜ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u05B5ԁ\u055Aࢢ(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x060019DC RID: 6620 RVA: 0x0008B4F8 File Offset: 0x000896F8
	[Token(Token = "0x60019DC")]
	[Address(RVA = "0x28A7B4C", Offset = "0x28A7B4C", VA = "0x28A7B4C")]
	private void \u0739߉ڵݞ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019DD RID: 6621 RVA: 0x0008B50C File Offset: 0x0008970C
	[Token(Token = "0x60019DD")]
	[Address(RVA = "0x28A7BA0", Offset = "0x28A7BA0", VA = "0x28A7BA0")]
	private void ݤۅࢦӃ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019DE RID: 6622 RVA: 0x0008B520 File Offset: 0x00089720
	[Token(Token = "0x60019DE")]
	[Address(RVA = "0x28A7BF4", Offset = "0x28A7BF4", VA = "0x28A7BF4")]
	private void Ԯ\u0883\u0591\u066C()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019DF RID: 6623 RVA: 0x0008B534 File Offset: 0x00089734
	[Token(Token = "0x60019DF")]
	[Address(RVA = "0x28A7C48", Offset = "0x28A7C48", VA = "0x28A7C48")]
	private void ࢫ\u0876չՍ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u05B5\u0878\u085EԂ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x060019E0 RID: 6624 RVA: 0x0008B560 File Offset: 0x00089760
	[Token(Token = "0x60019E0")]
	[Address(RVA = "0x28A7C80", Offset = "0x28A7C80", VA = "0x28A7C80")]
	private void \u0821\u059Fӕ\u0607()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڒ\u0833\u066Bձ(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x060019E1 RID: 6625 RVA: 0x0008B580 File Offset: 0x00089780
	[Token(Token = "0x60019E1")]
	[Address(RVA = "0x28A7CB4", Offset = "0x28A7CB4", VA = "0x28A7CB4")]
	private void \u070Fߨ\u05B0ۈ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019E2 RID: 6626 RVA: 0x0008B594 File Offset: 0x00089794
	[Token(Token = "0x60019E2")]
	[Address(RVA = "0x28A7D08", Offset = "0x28A7D08", VA = "0x28A7D08")]
	private void \u0558ݕݤݮ()
	{
	}

	// Token: 0x060019E3 RID: 6627 RVA: 0x0008B5A4 File Offset: 0x000897A4
	[Token(Token = "0x60019E3")]
	[Address(RVA = "0x28A7D5C", Offset = "0x28A7D5C", VA = "0x28A7D5C")]
	private void ӧ\u0608\u086Cճ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019E4 RID: 6628 RVA: 0x0008B5B8 File Offset: 0x000897B8
	[Token(Token = "0x60019E4")]
	[Address(RVA = "0x28A7DB0", Offset = "0x28A7DB0", VA = "0x28A7DB0")]
	private void \u0654ޛ\u07FAذ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڒ\u0833\u066Bձ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x060019E5 RID: 6629 RVA: 0x0008B5E4 File Offset: 0x000897E4
	[Token(Token = "0x60019E5")]
	[Address(RVA = "0x28A7DE8", Offset = "0x28A7DE8", VA = "0x28A7DE8")]
	private void \u05A5Ԇࠇޏ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019E6 RID: 6630 RVA: 0x0008B5F8 File Offset: 0x000897F8
	[Token(Token = "0x60019E6")]
	[Address(RVA = "0x28A7E3C", Offset = "0x28A7E3C", VA = "0x28A7E3C")]
	private void \u065F\u0839ܤ\u073C()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019E7 RID: 6631 RVA: 0x0008B60C File Offset: 0x0008980C
	[Token(Token = "0x60019E7")]
	[Address(RVA = "0x28A7E90", Offset = "0x28A7E90", VA = "0x28A7E90")]
	private void \u0593\u05A4Ӣ\u0602()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019E8 RID: 6632 RVA: 0x0008B620 File Offset: 0x00089820
	[Token(Token = "0x60019E8")]
	[Address(RVA = "0x28A7EE4", Offset = "0x28A7EE4", VA = "0x28A7EE4")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.މܝ\u0654ޙ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x060019E9 RID: 6633 RVA: 0x0008B64C File Offset: 0x0008984C
	[Token(Token = "0x60019E9")]
	[Address(RVA = "0x28A7F1C", Offset = "0x28A7F1C", VA = "0x28A7F1C")]
	private void Ջއٵյ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019EA RID: 6634 RVA: 0x0008B660 File Offset: 0x00089860
	[Token(Token = "0x60019EA")]
	[Address(RVA = "0x28A7F70", Offset = "0x28A7F70", VA = "0x28A7F70")]
	private void \u0825ӆا\u07BE()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019EB RID: 6635 RVA: 0x0008B674 File Offset: 0x00089874
	[Token(Token = "0x60019EB")]
	[Address(RVA = "0x28A7FC4", Offset = "0x28A7FC4", VA = "0x28A7FC4")]
	private void ࢭ\u0589\u0892\u058A()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڣ\u05F6\u0874\u0830(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x060019EC RID: 6636 RVA: 0x0008B6A0 File Offset: 0x000898A0
	[Token(Token = "0x60019EC")]
	[Address(RVA = "0x28A7FFC", Offset = "0x28A7FFC", VA = "0x28A7FFC")]
	private void \u073Fߗބݝ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u07EF\u061Aޞ\u0608(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x060019ED RID: 6637 RVA: 0x0008B6C0 File Offset: 0x000898C0
	[Token(Token = "0x60019ED")]
	[Address(RVA = "0x28A8030", Offset = "0x28A8030", VA = "0x28A8030")]
	private void ۊո\u0612\u0595()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019EE RID: 6638 RVA: 0x0008B6D4 File Offset: 0x000898D4
	[Token(Token = "0x60019EE")]
	[Address(RVA = "0x28A8084", Offset = "0x28A8084", VA = "0x28A8084")]
	private void ӭࡖݲ\u05BD()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019EF RID: 6639 RVA: 0x0008B6E8 File Offset: 0x000898E8
	[Token(Token = "0x60019EF")]
	[Address(RVA = "0x28A80D8", Offset = "0x28A80D8", VA = "0x28A80D8")]
	private void \u07A8Ӥթݠ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019F0 RID: 6640 RVA: 0x0008B6FC File Offset: 0x000898FC
	[Token(Token = "0x60019F0")]
	[Address(RVA = "0x28A812C", Offset = "0x28A812C", VA = "0x28A812C")]
	private void \u081FڰՂإ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019F1 RID: 6641 RVA: 0x0008B710 File Offset: 0x00089910
	[Token(Token = "0x60019F1")]
	[Address(RVA = "0x28A8180", Offset = "0x28A8180", VA = "0x28A8180")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.މܝ\u0654ޙ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x060019F2 RID: 6642 RVA: 0x0008B73C File Offset: 0x0008993C
	[Token(Token = "0x60019F2")]
	[Address(RVA = "0x28A81B8", Offset = "0x28A81B8", VA = "0x28A81B8")]
	private void \u07F7ܙײ\u05B5()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ײݰ\u06D7ى(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x060019F3 RID: 6643 RVA: 0x0008B75C File Offset: 0x0008995C
	[Token(Token = "0x60019F3")]
	[Address(RVA = "0x28A81EC", Offset = "0x28A81EC", VA = "0x28A81EC")]
	private void \u05F8ݑ\u06ECߞ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u089BӔڑۋ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x060019F4 RID: 6644 RVA: 0x0008B788 File Offset: 0x00089988
	[Token(Token = "0x60019F4")]
	[Address(RVA = "0x28A8224", Offset = "0x28A8224", VA = "0x28A8224")]
	private void ߊ\u066A\u05CFԉ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڣ\u05F6\u0874\u0830(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x060019F5 RID: 6645 RVA: 0x0008B7B4 File Offset: 0x000899B4
	[Token(Token = "0x60019F5")]
	[Address(RVA = "0x28A825C", Offset = "0x28A825C", VA = "0x28A825C")]
	private void \u0827ߜ\u07FD\u07F4()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڀޡ\u07A6\u065A(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x060019F6 RID: 6646 RVA: 0x0008B7D4 File Offset: 0x000899D4
	[Token(Token = "0x60019F6")]
	[Address(RVA = "0x28A8290", Offset = "0x28A8290", VA = "0x28A8290")]
	private void աؾێړ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019F7 RID: 6647 RVA: 0x0008B7E8 File Offset: 0x000899E8
	[Token(Token = "0x60019F7")]
	[Address(RVA = "0x28A82E4", Offset = "0x28A82E4", VA = "0x28A82E4")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019F8 RID: 6648 RVA: 0x0008B7FC File Offset: 0x000899FC
	[Token(Token = "0x60019F8")]
	[Address(RVA = "0x28A8338", Offset = "0x28A8338", VA = "0x28A8338")]
	private void \u06E1ԁՈڄ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019F9 RID: 6649 RVA: 0x0008B810 File Offset: 0x00089A10
	[Token(Token = "0x60019F9")]
	[Address(RVA = "0x28A838C", Offset = "0x28A838C", VA = "0x28A838C")]
	private void ۿࢹ\u0705\u0825()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019FA RID: 6650 RVA: 0x0008B824 File Offset: 0x00089A24
	[Token(Token = "0x60019FA")]
	[Address(RVA = "0x28A83E0", Offset = "0x28A83E0", VA = "0x28A83E0")]
	private void \u082E\u06EBݼڏ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019FB RID: 6651 RVA: 0x0008B838 File Offset: 0x00089A38
	[Token(Token = "0x60019FB")]
	[Address(RVA = "0x28A8434", Offset = "0x28A8434", VA = "0x28A8434")]
	private void \u05F7ԝߠӱ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڀޡ\u07A6\u065A(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x060019FC RID: 6652 RVA: 0x0008B864 File Offset: 0x00089A64
	[Token(Token = "0x60019FC")]
	[Address(RVA = "0x28A846C", Offset = "0x28A846C", VA = "0x28A846C")]
	private void ؤ\u05C8ԛ\u083F()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.މܝ\u0654ޙ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x060019FD RID: 6653 RVA: 0x0008B890 File Offset: 0x00089A90
	[Token(Token = "0x60019FD")]
	[Address(RVA = "0x28A84A4", Offset = "0x28A84A4", VA = "0x28A84A4")]
	private void Ӧد\u060Eࡏ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ײݰ\u06D7ى(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x060019FE RID: 6654 RVA: 0x0008B8BC File Offset: 0x00089ABC
	[Token(Token = "0x60019FE")]
	[Address(RVA = "0x28A84DC", Offset = "0x28A84DC", VA = "0x28A84DC")]
	private void הԥ\u05B5ݴ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060019FF RID: 6655 RVA: 0x0008B8D0 File Offset: 0x00089AD0
	[Token(Token = "0x60019FF")]
	[Address(RVA = "0x28A8530", Offset = "0x28A8530", VA = "0x28A8530")]
	private void ԅ\u073Fڥ\u0839()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڒ\u0833\u066Bձ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A00 RID: 6656 RVA: 0x0008B8FC File Offset: 0x00089AFC
	[Token(Token = "0x6001A00")]
	[Address(RVA = "0x28A8568", Offset = "0x28A8568", VA = "0x28A8568")]
	private void \u059AՏ\u0600\u0872()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A01 RID: 6657 RVA: 0x0008B910 File Offset: 0x00089B10
	[Token(Token = "0x6001A01")]
	[Address(RVA = "0x28A85BC", Offset = "0x28A85BC", VA = "0x28A85BC")]
	private void \u0838ӆڛӑ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڒ\u0833\u066Bձ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A02 RID: 6658 RVA: 0x0008B93C File Offset: 0x00089B3C
	[Token(Token = "0x6001A02")]
	[Address(RVA = "0x28A85F4", Offset = "0x28A85F4", VA = "0x28A85F4")]
	private void ڦکӁ\u06E2()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u05B5\u0878\u085EԂ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A03 RID: 6659 RVA: 0x0008B968 File Offset: 0x00089B68
	[Token(Token = "0x6001A03")]
	[Address(RVA = "0x28A862C", Offset = "0x28A862C", VA = "0x28A862C")]
	private void ןٮ\u061FԺ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A04 RID: 6660 RVA: 0x0008B97C File Offset: 0x00089B7C
	[Token(Token = "0x6001A04")]
	[Address(RVA = "0x28A8680", Offset = "0x28A8680", VA = "0x28A8680")]
	private void \u05C8\u05BFࠁف()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A05 RID: 6661 RVA: 0x0008B990 File Offset: 0x00089B90
	[Token(Token = "0x6001A05")]
	[Address(RVA = "0x28A86D4", Offset = "0x28A86D4", VA = "0x28A86D4")]
	private void \u07BDއڸ\u0834()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u089BӔڑۋ(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x06001A06 RID: 6662 RVA: 0x0008B9B0 File Offset: 0x00089BB0
	[Token(Token = "0x6001A06")]
	[Address(RVA = "0x28A8708", Offset = "0x28A8708", VA = "0x28A8708")]
	private void ۮߝڪڐ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A07 RID: 6663 RVA: 0x0008B9C4 File Offset: 0x00089BC4
	[Token(Token = "0x6001A07")]
	[Address(RVA = "0x28A875C", Offset = "0x28A875C", VA = "0x28A875C")]
	private void ١ۏ\u05C4ӝ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A08 RID: 6664 RVA: 0x0008B9D8 File Offset: 0x00089BD8
	[Token(Token = "0x6001A08")]
	[Address(RVA = "0x28A87B0", Offset = "0x28A87B0", VA = "0x28A87B0")]
	private void چ\u05AEךڰ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A09 RID: 6665 RVA: 0x0008B9EC File Offset: 0x00089BEC
	[Token(Token = "0x6001A09")]
	[Address(RVA = "0x28A8804", Offset = "0x28A8804", VA = "0x28A8804")]
	private void Update()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڀޡ\u07A6\u065A(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x06001A0A RID: 6666 RVA: 0x0008BA0C File Offset: 0x00089C0C
	[Token(Token = "0x6001A0A")]
	[Address(RVA = "0x28A8838", Offset = "0x28A8838", VA = "0x28A8838")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u089BӔڑۋ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A0B RID: 6667 RVA: 0x0008BA38 File Offset: 0x00089C38
	[Token(Token = "0x6001A0B")]
	[Address(RVA = "0x28A8870", Offset = "0x28A8870", VA = "0x28A8870")]
	private void \u087BӦןݩ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u05B5ԁ\u055Aࢢ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A0C RID: 6668 RVA: 0x0008BA64 File Offset: 0x00089C64
	[Token(Token = "0x6001A0C")]
	[Address(RVA = "0x28A88A8", Offset = "0x28A88A8", VA = "0x28A88A8")]
	private void ࠏޤݳ\u06DD()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A0D RID: 6669 RVA: 0x0008BA78 File Offset: 0x00089C78
	[Token(Token = "0x6001A0D")]
	[Address(RVA = "0x28A88FC", Offset = "0x28A88FC", VA = "0x28A88FC")]
	private void ࡥ\u07A7\u065Eӽ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A0E RID: 6670 RVA: 0x0008BA8C File Offset: 0x00089C8C
	[Token(Token = "0x6001A0E")]
	[Address(RVA = "0x28A8950", Offset = "0x28A8950", VA = "0x28A8950")]
	private void \u058EԸس\u0819()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A0F RID: 6671 RVA: 0x0008BAA0 File Offset: 0x00089CA0
	[Token(Token = "0x6001A0F")]
	[Address(RVA = "0x28A89A4", Offset = "0x28A89A4", VA = "0x28A89A4")]
	private void \u0881ݗӟ\u07BD()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڀޡ\u07A6\u065A(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A10 RID: 6672 RVA: 0x0008BACC File Offset: 0x00089CCC
	[Token(Token = "0x6001A10")]
	[Address(RVA = "0x28A89DC", Offset = "0x28A89DC", VA = "0x28A89DC")]
	private void \u0733ߜܣԻ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A11 RID: 6673 RVA: 0x0008BAE0 File Offset: 0x00089CE0
	[Token(Token = "0x6001A11")]
	[Address(RVA = "0x28A8A30", Offset = "0x28A8A30", VA = "0x28A8A30")]
	private void \u05AC\u07F0\u07EEࡥ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڣ\u05F6\u0874\u0830(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A12 RID: 6674 RVA: 0x0008BB0C File Offset: 0x00089D0C
	[Token(Token = "0x6001A12")]
	[Address(RVA = "0x28A8A68", Offset = "0x28A8A68", VA = "0x28A8A68")]
	private void ӛ\u082Eؿڕ()
	{
	}

	// Token: 0x06001A13 RID: 6675 RVA: 0x0008BB1C File Offset: 0x00089D1C
	[Token(Token = "0x6001A13")]
	[Address(RVA = "0x28A8ABC", Offset = "0x28A8ABC", VA = "0x28A8ABC")]
	private void ߒ\u065EՎࡖ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A14 RID: 6676 RVA: 0x0008BB30 File Offset: 0x00089D30
	[Token(Token = "0x6001A14")]
	[Address(RVA = "0x28A8B10", Offset = "0x28A8B10", VA = "0x28A8B10")]
	private void ߄Ӄ\u0613ھ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A15 RID: 6677 RVA: 0x0008BB44 File Offset: 0x00089D44
	[Token(Token = "0x6001A15")]
	[Address(RVA = "0x28A8B64", Offset = "0x28A8B64", VA = "0x28A8B64")]
	private void յߪؾՀ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ײݰ\u06D7ى(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A16 RID: 6678 RVA: 0x0008BB70 File Offset: 0x00089D70
	[Token(Token = "0x6001A16")]
	[Address(RVA = "0x28A8B9C", Offset = "0x28A8B9C", VA = "0x28A8B9C")]
	private void \u05FEօ\u06D7ࡁ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A17 RID: 6679 RVA: 0x0008BB84 File Offset: 0x00089D84
	[Token(Token = "0x6001A17")]
	[Address(RVA = "0x28A8BF0", Offset = "0x28A8BF0", VA = "0x28A8BF0")]
	private void יԠ\u07EDԺ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ײݰ\u06D7ى(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A18 RID: 6680 RVA: 0x0008BBB0 File Offset: 0x00089DB0
	[Token(Token = "0x6001A18")]
	[Address(RVA = "0x28A8C28", Offset = "0x28A8C28", VA = "0x28A8C28")]
	private void ܩחݵޔ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A19 RID: 6681 RVA: 0x0008BBC4 File Offset: 0x00089DC4
	[Token(Token = "0x6001A19")]
	[Address(RVA = "0x28A8C7C", Offset = "0x28A8C7C", VA = "0x28A8C7C")]
	private void \u07B6կպ߃()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u05B5ԁ\u055Aࢢ(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x06001A1A RID: 6682 RVA: 0x0008BBE4 File Offset: 0x00089DE4
	[Token(Token = "0x6001A1A")]
	[Address(RVA = "0x28A8CB0", Offset = "0x28A8CB0", VA = "0x28A8CB0")]
	private void ࡅݐ\u082Dք()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A1B RID: 6683 RVA: 0x0008BBF8 File Offset: 0x00089DF8
	[Token(Token = "0x6001A1B")]
	[Address(RVA = "0x28A8D04", Offset = "0x28A8D04", VA = "0x28A8D04")]
	private void \u0652\u058Bک\u061C()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A1C RID: 6684 RVA: 0x0008BC0C File Offset: 0x00089E0C
	[Token(Token = "0x6001A1C")]
	[Address(RVA = "0x28A8D58", Offset = "0x28A8D58", VA = "0x28A8D58")]
	private void ڷԲ\u0618ރ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڀޡ\u07A6\u065A(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A1D RID: 6685 RVA: 0x0008BC38 File Offset: 0x00089E38
	[Token(Token = "0x6001A1D")]
	[Address(RVA = "0x28A8D90", Offset = "0x28A8D90", VA = "0x28A8D90")]
	private void ࠈ\u07A9\u05B3Ծ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.މܝ\u0654ޙ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A1E RID: 6686 RVA: 0x0008BC64 File Offset: 0x00089E64
	[Token(Token = "0x6001A1E")]
	[Address(RVA = "0x28A8DC8", Offset = "0x28A8DC8", VA = "0x28A8DC8")]
	private void Ҽ\u08B5ځ\u0658()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u07EF\u061Aޞ\u0608(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A1F RID: 6687 RVA: 0x0008BC90 File Offset: 0x00089E90
	[Token(Token = "0x6001A1F")]
	[Address(RVA = "0x28A8E00", Offset = "0x28A8E00", VA = "0x28A8E00")]
	private void ݫࢷࠃ\u0820()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ײݰ\u06D7ى(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x06001A20 RID: 6688 RVA: 0x0008BCB0 File Offset: 0x00089EB0
	[Token(Token = "0x6001A20")]
	[Address(RVA = "0x28A8E34", Offset = "0x28A8E34", VA = "0x28A8E34")]
	private void ࡎ\u05C2սࠇ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A21 RID: 6689 RVA: 0x0008BCC4 File Offset: 0x00089EC4
	[Token(Token = "0x6001A21")]
	[Address(RVA = "0x28A8E88", Offset = "0x28A8E88", VA = "0x28A8E88")]
	private void \u055E\u0703\u0700ܠ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A22 RID: 6690 RVA: 0x0008BCD8 File Offset: 0x00089ED8
	[Token(Token = "0x6001A22")]
	[Address(RVA = "0x28A8EDC", Offset = "0x28A8EDC", VA = "0x28A8EDC")]
	private void قӮևݛ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A23 RID: 6691 RVA: 0x0008BCEC File Offset: 0x00089EEC
	[Token(Token = "0x6001A23")]
	[Address(RVA = "0x28A8F30", Offset = "0x28A8F30", VA = "0x28A8F30")]
	private void \u066D\u05BDې߃()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A24 RID: 6692 RVA: 0x0008BD00 File Offset: 0x00089F00
	[Token(Token = "0x6001A24")]
	[Address(RVA = "0x28A8F84", Offset = "0x28A8F84", VA = "0x28A8F84")]
	private void ߓ\u06E3\u05C7ۋ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A25 RID: 6693 RVA: 0x0008BD14 File Offset: 0x00089F14
	[Token(Token = "0x6001A25")]
	[Address(RVA = "0x28A8FD8", Offset = "0x28A8FD8", VA = "0x28A8FD8")]
	private void \u086Bԍࡊڭ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A26 RID: 6694 RVA: 0x0008BD28 File Offset: 0x00089F28
	[Token(Token = "0x6001A26")]
	[Address(RVA = "0x28A902C", Offset = "0x28A902C", VA = "0x28A902C")]
	private void Start()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A27 RID: 6695 RVA: 0x0008BD3C File Offset: 0x00089F3C
	[Token(Token = "0x6001A27")]
	[Address(RVA = "0x28A9080", Offset = "0x28A9080", VA = "0x28A9080")]
	private void \u05ABݿࡋ\u06E9()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A28 RID: 6696 RVA: 0x0008BD50 File Offset: 0x00089F50
	[Token(Token = "0x6001A28")]
	[Address(RVA = "0x28A90D4", Offset = "0x28A90D4", VA = "0x28A90D4")]
	private void \u073BօӁ\u059A()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A29 RID: 6697 RVA: 0x0008BD64 File Offset: 0x00089F64
	[Token(Token = "0x6001A29")]
	[Address(RVA = "0x28A9128", Offset = "0x28A9128", VA = "0x28A9128")]
	private void ࡩݮڢՠ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A2A RID: 6698 RVA: 0x0008BD78 File Offset: 0x00089F78
	[Token(Token = "0x6001A2A")]
	[Address(RVA = "0x28A917C", Offset = "0x28A917C", VA = "0x28A917C")]
	public DisplayLogsToText()
	{
		int ٶޖߛ_u = 100;
		this.ٶޖߛ\u0607 = ٶޖߛ_u;
		List<string> list = new List();
		this.ܦ߈ࢷՋ = list;
		Dictionary<string, int> u082Aӫݗߥ;
		this.\u082Aӫݗߥ = u082Aӫݗߥ;
		base..ctor();
	}

	// Token: 0x06001A2B RID: 6699 RVA: 0x0008BDAC File Offset: 0x00089FAC
	[Token(Token = "0x6001A2B")]
	[Address(RVA = "0x28A9254", Offset = "0x28A9254", VA = "0x28A9254")]
	private void \u0836\u089Dی\u0735()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u089BӔڑۋ(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x06001A2C RID: 6700 RVA: 0x0008BDCC File Offset: 0x00089FCC
	[Token(Token = "0x6001A2C")]
	[Address(RVA = "0x28A9288", Offset = "0x28A9288", VA = "0x28A9288")]
	private void ژךՈ\u0597()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u07EF\u061Aޞ\u0608(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A2D RID: 6701 RVA: 0x0008BDF8 File Offset: 0x00089FF8
	[Token(Token = "0x6001A2D")]
	[Address(RVA = "0x28A92C0", Offset = "0x28A92C0", VA = "0x28A92C0")]
	private void \u0892ܒܬޓ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڀޡ\u07A6\u065A(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A2E RID: 6702 RVA: 0x0008BE24 File Offset: 0x0008A024
	[Token(Token = "0x6001A2E")]
	[Address(RVA = "0x28A92F8", Offset = "0x28A92F8", VA = "0x28A92F8")]
	private void Ҿࢹؼס()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڒ\u0833\u066Bձ(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x06001A2F RID: 6703 RVA: 0x0008BE44 File Offset: 0x0008A044
	[Token(Token = "0x6001A2F")]
	[Address(RVA = "0x28A932C", Offset = "0x28A932C", VA = "0x28A932C")]
	private void ժ\u065Dԯࡘ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u05B5\u0878\u085EԂ(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x06001A30 RID: 6704 RVA: 0x0008BE64 File Offset: 0x0008A064
	[Token(Token = "0x6001A30")]
	[Address(RVA = "0x28A9360", Offset = "0x28A9360", VA = "0x28A9360")]
	private void ݱ\u0832ݥ\u08B5()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A31 RID: 6705 RVA: 0x0008BE78 File Offset: 0x0008A078
	[Token(Token = "0x6001A31")]
	[Address(RVA = "0x28A93B4", Offset = "0x28A93B4", VA = "0x28A93B4")]
	private void \u061B\u05EEوۈ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ڣ\u05F6\u0874\u0830(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A32 RID: 6706 RVA: 0x0008BEA4 File Offset: 0x0008A0A4
	[Token(Token = "0x6001A32")]
	[Address(RVA = "0x28A93EC", Offset = "0x28A93EC", VA = "0x28A93EC")]
	private void ո\u07AA\u05BDࠕ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u05B5\u0878\u085EԂ(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x06001A33 RID: 6707 RVA: 0x0008BEC4 File Offset: 0x0008A0C4
	[Token(Token = "0x6001A33")]
	[Address(RVA = "0x28A9420", Offset = "0x28A9420", VA = "0x28A9420")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ײݰ\u06D7ى(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x06001A34 RID: 6708 RVA: 0x0008BEE4 File Offset: 0x0008A0E4
	[Token(Token = "0x6001A34")]
	[Address(RVA = "0x28A9454", Offset = "0x28A9454", VA = "0x28A9454")]
	private void ی\u0823ڇݔ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.ײݰ\u06D7ى(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A35 RID: 6709 RVA: 0x0008BF10 File Offset: 0x0008A110
	[Token(Token = "0x6001A35")]
	[Address(RVA = "0x28A948C", Offset = "0x28A948C", VA = "0x28A948C")]
	private void ہݕ\u07EFԒ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u05B5ԁ\u055Aࢢ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A36 RID: 6710 RVA: 0x0008BF3C File Offset: 0x0008A13C
	[Token(Token = "0x6001A36")]
	[Address(RVA = "0x28A94C4", Offset = "0x28A94C4", VA = "0x28A94C4")]
	private void \u07B2\u0823ծݠ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u05B5ԁ\u055Aࢢ(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x06001A37 RID: 6711 RVA: 0x0008BF5C File Offset: 0x0008A15C
	[Token(Token = "0x6001A37")]
	[Address(RVA = "0x28A94F8", Offset = "0x28A94F8", VA = "0x28A94F8")]
	private void \u06D6ې\u083Bࠉ()
	{
		DisplayLogsToText.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06001A38 RID: 6712 RVA: 0x0008BF70 File Offset: 0x0008A170
	[Token(Token = "0x6001A38")]
	[Address(RVA = "0x28A954C", Offset = "0x28A954C", VA = "0x28A954C")]
	private void פۈيݤ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.މܝ\u0654ޙ(this.\u066Cڴޔ\u070B);
			long u086B_u06EB_u0825_u05AF = 1L;
			this.\u086B\u06EB\u0825\u05AF = (u086B_u06EB_u0825_u05AF != 0L);
		}
	}

	// Token: 0x06001A39 RID: 6713 RVA: 0x0008BF9C File Offset: 0x0008A19C
	[Token(Token = "0x6001A39")]
	[Address(RVA = "0x28A9584", Offset = "0x28A9584", VA = "0x28A9584")]
	private void ى߁ٱՏ()
	{
		if (this.\u086B\u06EB\u0825\u05AF)
		{
			ޖՇՎ\u0838.\u089BӔڑۋ(this.\u066Cڴޔ\u070B);
		}
	}

	// Token: 0x0400032A RID: 810
	[Token(Token = "0x400032A")]
	public static DisplayLogsToText كݕ\u05F3\u0589;

	// Token: 0x0400032B RID: 811
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400032B")]
	public TMP_Text ۶\u066Aޡ\u070F;

	// Token: 0x0400032C RID: 812
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400032C")]
	public int ٶޖߛ\u0607;

	// Token: 0x0400032D RID: 813
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400032D")]
	[HideInInspector]
	public List<string> ܦ߈ࢷՋ;

	// Token: 0x0400032E RID: 814
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400032E")]
	public Dictionary<string, int> \u082Aӫݗߥ;

	// Token: 0x0400032F RID: 815
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400032F")]
	public bool \u086B\u06EB\u0825\u05AF;

	// Token: 0x04000330 RID: 816
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000330")]
	public string \u066Cڴޔ\u070B;
}
