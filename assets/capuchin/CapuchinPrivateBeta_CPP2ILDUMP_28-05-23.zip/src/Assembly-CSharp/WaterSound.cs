﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000044 RID: 68
[Token(Token = "0x2000044")]
public class WaterSound : MonoBehaviour
{
	// Token: 0x0600095A RID: 2394 RVA: 0x000321DC File Offset: 0x000303DC
	[Token(Token = "0x600095A")]
	[Address(RVA = "0x2C85E58", Offset = "0x2C85E58", VA = "0x2C85E58")]
	private void ݲ\u06E6ҽࡩ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x0600095B RID: 2395 RVA: 0x0003229C File Offset: 0x0003049C
	[Token(Token = "0x600095B")]
	[Address(RVA = "0x2C86038", Offset = "0x2C86038", VA = "0x2C86038")]
	private void ۊո\u0612\u0595()
	{
		long initialized = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.\u05BFڥ\u0596ࡏ = deviceAtXRNode;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600095C RID: 2396 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600095C")]
	[Address(RVA = "0x2C86074", Offset = "0x2C86074", VA = "0x2C86074")]
	public void ߒࠅߝ۹()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600095D RID: 2397 RVA: 0x000322E0 File Offset: 0x000304E0
	[Token(Token = "0x600095D")]
	[Address(RVA = "0x2C86170", Offset = "0x2C86170", VA = "0x2C86170")]
	private void ࢥ\u081CՕࡋ()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600095E RID: 2398 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600095E")]
	[Address(RVA = "0x2C861AC", Offset = "0x2C861AC", VA = "0x2C861AC")]
	public void ٷ\u05F5Ԗ\u0595()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600095F RID: 2399 RVA: 0x00032320 File Offset: 0x00030520
	[Token(Token = "0x600095F")]
	[Address(RVA = "0x2C862A8", Offset = "0x2C862A8", VA = "0x2C862A8")]
	private void \u0890ؤߪފ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x06000960 RID: 2400 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000960")]
	[Address(RVA = "0x2C86488", Offset = "0x2C86488", VA = "0x2C86488")]
	public void \u05A1ߡࡅࢮ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000961 RID: 2401 RVA: 0x000323E0 File Offset: 0x000305E0
	[Token(Token = "0x6000961")]
	[Address(RVA = "0x2C86584", Offset = "0x2C86584", VA = "0x2C86584")]
	private void \u089Bځԯԝ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x06000962 RID: 2402 RVA: 0x0003249C File Offset: 0x0003069C
	[Token(Token = "0x6000962")]
	[Address(RVA = "0x2C86764", Offset = "0x2C86764", VA = "0x2C86764")]
	private void \u0892\u061B\u0606\u06D8()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x06000963 RID: 2403 RVA: 0x0003255C File Offset: 0x0003075C
	[Token(Token = "0x6000963")]
	[Address(RVA = "0x2C86944", Offset = "0x2C86944", VA = "0x2C86944")]
	private void \u065F\u0839ܤ\u073C()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.өՆԉ\u065C = deviceAtXRNode;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000964 RID: 2404 RVA: 0x000325A0 File Offset: 0x000307A0
	[Token(Token = "0x6000964")]
	[Address(RVA = "0x2C86980", Offset = "0x2C86980", VA = "0x2C86980")]
	private void Կשܐӵ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		float volume2 = this.ػտ\u065A\u0870.volume;
		float deltaTime = Time.deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x06000965 RID: 2405 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000965")]
	[Address(RVA = "0x2C86B60", Offset = "0x2C86B60", VA = "0x2C86B60")]
	public void ւࢢدࠈ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000966 RID: 2406 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000966")]
	[Address(RVA = "0x2C86C5C", Offset = "0x2C86C5C", VA = "0x2C86C5C")]
	public void ߆۰\u05BFߍ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000967 RID: 2407 RVA: 0x00032650 File Offset: 0x00030850
	[Token(Token = "0x6000967")]
	[Address(RVA = "0x2C86D58", Offset = "0x2C86D58", VA = "0x2C86D58")]
	private void \u06EDٵ۶\u06DB()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000968 RID: 2408 RVA: 0x00032690 File Offset: 0x00030890
	[Token(Token = "0x6000968")]
	[Address(RVA = "0x2C86D94", Offset = "0x2C86D94", VA = "0x2C86D94")]
	public void Ա\u05F9\u05BDܫ()
	{
	}

	// Token: 0x06000969 RID: 2409 RVA: 0x000326A4 File Offset: 0x000308A4
	[Token(Token = "0x6000969")]
	[Address(RVA = "0x2C86E90", Offset = "0x2C86E90", VA = "0x2C86E90")]
	private void ܩחݵޔ()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600096A RID: 2410 RVA: 0x000326E4 File Offset: 0x000308E4
	[Token(Token = "0x600096A")]
	[Address(RVA = "0x2C86ECC", Offset = "0x2C86ECC", VA = "0x2C86ECC")]
	private void ࢧӾڈց()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600096B RID: 2411 RVA: 0x00032724 File Offset: 0x00030924
	[Token(Token = "0x600096B")]
	[Address(RVA = "0x2C86F08", Offset = "0x2C86F08", VA = "0x2C86F08")]
	private void FixedUpdate()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x0600096C RID: 2412 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600096C")]
	[Address(RVA = "0x2C870D8", Offset = "0x2C870D8", VA = "0x2C870D8")]
	public void شԚ\u0650\u05BC()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600096D RID: 2413 RVA: 0x000327E4 File Offset: 0x000309E4
	[Token(Token = "0x600096D")]
	[Address(RVA = "0x2C871D4", Offset = "0x2C871D4", VA = "0x2C871D4")]
	private void ޤ\u0610\u087A\u05AF()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x0600096E RID: 2414 RVA: 0x000328A4 File Offset: 0x00030AA4
	[Token(Token = "0x600096E")]
	[Address(RVA = "0x2C873B4", Offset = "0x2C873B4", VA = "0x2C873B4")]
	private void ࠆ߆ۀפ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x0600096F RID: 2415 RVA: 0x00032964 File Offset: 0x00030B64
	[Token(Token = "0x600096F")]
	[Address(RVA = "0x2C87594", Offset = "0x2C87594", VA = "0x2C87594")]
	private void \u0736\u06E0\u06E0څ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x06000970 RID: 2416 RVA: 0x00032A24 File Offset: 0x00030C24
	[Token(Token = "0x6000970")]
	[Address(RVA = "0x2C87774", Offset = "0x2C87774", VA = "0x2C87774")]
	private void \u081E١Ӕࢦ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		if (this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ػտ_u065A_u2.volume;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ.volume = deltaTime2;
	}

	// Token: 0x06000971 RID: 2417 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000971")]
	[Address(RVA = "0x2C87954", Offset = "0x2C87954", VA = "0x2C87954")]
	public void \u0559\u05FEפ\u05CD()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000972 RID: 2418 RVA: 0x00032AD8 File Offset: 0x00030CD8
	[Token(Token = "0x6000972")]
	[Address(RVA = "0x2C87A50", Offset = "0x2C87A50", VA = "0x2C87A50")]
	private void סࡓࢤࢻ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x06000973 RID: 2419 RVA: 0x00032B98 File Offset: 0x00030D98
	[Token(Token = "0x6000973")]
	[Address(RVA = "0x2C87C30", Offset = "0x2C87C30", VA = "0x2C87C30")]
	private void \u089Fکߦݭ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		float volume4 = this.ݻ\u0559թՉ.volume;
		float deltaTime2 = Time.deltaTime;
	}

	// Token: 0x06000974 RID: 2420 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000974")]
	[Address(RVA = "0x2C87E10", Offset = "0x2C87E10", VA = "0x2C87E10")]
	public void \u0704زք٥()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000975 RID: 2421 RVA: 0x00032C48 File Offset: 0x00030E48
	[Token(Token = "0x6000975")]
	[Address(RVA = "0x2C87F18", Offset = "0x2C87F18", VA = "0x2C87F18")]
	private void ם\u06FDւԋ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
		float ԥӿնӲ = this.ԤӿնӲ;
	}

	// Token: 0x06000976 RID: 2422 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000976")]
	[Address(RVA = "0x2C880F8", Offset = "0x2C880F8", VA = "0x2C880F8")]
	public void Ձߎࢺ\u060D()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000977 RID: 2423 RVA: 0x00032D04 File Offset: 0x00030F04
	[Token(Token = "0x6000977")]
	[Address(RVA = "0x2C88200", Offset = "0x2C88200", VA = "0x2C88200")]
	private void Ԯ\u0883\u0591\u066C()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.өՆԉ\u065C = deviceAtXRNode;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000978 RID: 2424 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000978")]
	[Address(RVA = "0x2C8823C", Offset = "0x2C8823C", VA = "0x2C8823C")]
	public void ؠࡒࢢԃ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000979 RID: 2425 RVA: 0x00032D48 File Offset: 0x00030F48
	[Token(Token = "0x6000979")]
	[Address(RVA = "0x2C88344", Offset = "0x2C88344", VA = "0x2C88344")]
	private void \u0609ݢ\u05F7\u0744()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x0600097A RID: 2426 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600097A")]
	[Address(RVA = "0x2C88524", Offset = "0x2C88524", VA = "0x2C88524")]
	public void \u0705\u083EԪڸ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600097B RID: 2427 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600097B")]
	[Address(RVA = "0x2C88620", Offset = "0x2C88620", VA = "0x2C88620")]
	public void ےؠպ\u05FC()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600097C RID: 2428 RVA: 0x00032E08 File Offset: 0x00031008
	[Token(Token = "0x600097C")]
	[Address(RVA = "0x2C8871C", Offset = "0x2C8871C", VA = "0x2C8871C")]
	private void \u070EࢣԀ\u07A9()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x0600097D RID: 2429 RVA: 0x00032EC8 File Offset: 0x000310C8
	[Token(Token = "0x600097D")]
	[Address(RVA = "0x2C888FC", Offset = "0x2C888FC", VA = "0x2C888FC")]
	private void ӭࡖݲ\u05BD()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.өՆԉ\u065C = deviceAtXRNode;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600097E RID: 2430 RVA: 0x00032F08 File Offset: 0x00031108
	[Token(Token = "0x600097E")]
	[Address(RVA = "0x2C88938", Offset = "0x2C88938", VA = "0x2C88938")]
	private void \u064Cޔաӕ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x0600097F RID: 2431 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600097F")]
	[Address(RVA = "0x2C88B18", Offset = "0x2C88B18", VA = "0x2C88B18")]
	public void ڽ\u0894ىޡ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000980 RID: 2432 RVA: 0x00032FC8 File Offset: 0x000311C8
	[Token(Token = "0x6000980")]
	[Address(RVA = "0x2C88C14", Offset = "0x2C88C14", VA = "0x2C88C14")]
	private void ࠇ\u087DػՏ()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x06000981 RID: 2433 RVA: 0x00033088 File Offset: 0x00031288
	[Token(Token = "0x6000981")]
	[Address(RVA = "0x2C88DF0", Offset = "0x2C88DF0", VA = "0x2C88DF0")]
	private void Start()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.өՆԉ\u065C = deviceAtXRNode;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000982 RID: 2434 RVA: 0x000330CC File Offset: 0x000312CC
	[Token(Token = "0x6000982")]
	[Address(RVA = "0x2C88E2C", Offset = "0x2C88E2C", VA = "0x2C88E2C")]
	private void \u07BFޥ٧\u073B()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		float volume2 = this.ػտ\u065A\u0870.volume;
		float deltaTime = Time.deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x06000983 RID: 2435 RVA: 0x0003317C File Offset: 0x0003137C
	[Token(Token = "0x6000983")]
	[Address(RVA = "0x2C8900C", Offset = "0x2C8900C", VA = "0x2C8900C")]
	private void \u0656ӺմՁ()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.өՆԉ\u065C = deviceAtXRNode;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000984 RID: 2436 RVA: 0x000331C0 File Offset: 0x000313C0
	[Token(Token = "0x6000984")]
	[Address(RVA = "0x2C89048", Offset = "0x2C89048", VA = "0x2C89048")]
	private void ڣֆ\u07F4ڌ()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000985 RID: 2437 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000985")]
	[Address(RVA = "0x2C89084", Offset = "0x2C89084", VA = "0x2C89084")]
	public void րࢢ\u0830Ӥ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000986 RID: 2438 RVA: 0x00033200 File Offset: 0x00031400
	[Token(Token = "0x6000986")]
	[Address(RVA = "0x2C89180", Offset = "0x2C89180", VA = "0x2C89180")]
	private void Ԁוև\u065B()
	{
		long initialized = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.\u05BFڥ\u0596ࡏ = deviceAtXRNode;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000987 RID: 2439 RVA: 0x00033244 File Offset: 0x00031444
	[Token(Token = "0x6000987")]
	[Address(RVA = "0x2C891BC", Offset = "0x2C891BC", VA = "0x2C891BC")]
	private void ןأ\u05C0ب()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x06000988 RID: 2440 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000988")]
	[Address(RVA = "0x2C8939C", Offset = "0x2C8939C", VA = "0x2C8939C")]
	public void \u0613\u05CBݠۇ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000989 RID: 2441 RVA: 0x00033304 File Offset: 0x00031504
	[Token(Token = "0x6000989")]
	[Address(RVA = "0x2C89498", Offset = "0x2C89498", VA = "0x2C89498")]
	public WaterSound()
	{
	}

	// Token: 0x0600098A RID: 2442 RVA: 0x00033318 File Offset: 0x00031518
	[Token(Token = "0x600098A")]
	[Address(RVA = "0x2C894A0", Offset = "0x2C894A0", VA = "0x2C894A0")]
	private void ۮߝڪڐ()
	{
		long initialized = 0L;
		InputDevice u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ = u05BFڥ_u0596ࡏ;
		this.\u05BFڥ\u0596ࡏ.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice өՆԉ_u065C;
		this.өՆԉ\u065C = өՆԉ_u065C;
		this.өՆԉ\u065C.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600098B RID: 2443 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600098B")]
	[Address(RVA = "0x2C894DC", Offset = "0x2C894DC", VA = "0x2C894DC")]
	public void Ԁ\u05EB\u085Eՠ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600098C RID: 2444 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600098C")]
	[Address(RVA = "0x2C895D8", Offset = "0x2C895D8", VA = "0x2C895D8")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600098D RID: 2445 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600098D")]
	[Address(RVA = "0x2C896D4", Offset = "0x2C896D4", VA = "0x2C896D4")]
	public void \u0607\u0747\u058Aף()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600098E RID: 2446 RVA: 0x00033358 File Offset: 0x00031558
	[Token(Token = "0x600098E")]
	[Address(RVA = "0x2C897E8", Offset = "0x2C897E8", VA = "0x2C897E8")]
	private void ڿ\u06E6\u088E\u06FD()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x0600098F RID: 2447 RVA: 0x00033418 File Offset: 0x00031618
	[Token(Token = "0x600098F")]
	[Address(RVA = "0x2C899C8", Offset = "0x2C899C8", VA = "0x2C899C8")]
	private void կսҾ\u06E4()
	{
		if (!true)
		{
		}
		bool צ_u0886٨ߤ = this.\u0559ݹՈ\u055F.צ\u0886٨ߤ;
		AudioSource ػտ_u065A_u = this.ػտ\u065A\u0870;
		if (צ_u0886٨ߤ)
		{
			float ԕݗޜ_u = this.ԕݗޜ\u0656;
			return;
		}
		float volume = ػտ_u065A_u.volume;
		AudioSource ػտ_u065A_u2 = this.ػտ\u065A\u0870;
		float volume2 = ػտ_u065A_u2.volume;
		float deltaTime = Time.deltaTime;
		ػտ_u065A_u2.volume = deltaTime;
		bool ܝ_u07BAԢԀ = this.\u0559ݹՈ\u055F.ܝ\u07BAԢԀ;
		AudioSource ݻ_u0559թՉ = this.ݻ\u0559թՉ;
		if (ܝ_u07BAԢԀ)
		{
			float ԕݗޜ_u2 = this.ԕݗޜ\u0656;
			float ԥӿնӲ = this.ԤӿնӲ;
			return;
		}
		float volume3 = ݻ_u0559թՉ.volume;
		AudioSource ݻ_u0559թՉ2 = this.ݻ\u0559թՉ;
		float volume4 = ݻ_u0559թՉ2.volume;
		float deltaTime2 = Time.deltaTime;
		ݻ_u0559թՉ2.volume = deltaTime2;
	}

	// Token: 0x06000990 RID: 2448 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000990")]
	[Address(RVA = "0x2C89BA8", Offset = "0x2C89BA8", VA = "0x2C89BA8")]
	public void ࡖקӒݾ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000991 RID: 2449 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000991")]
	[Address(RVA = "0x2C89CA4", Offset = "0x2C89CA4", VA = "0x2C89CA4")]
	public void \u07F7\u0651ӽ\u0557()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x04000156 RID: 342
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000156")]
	private InputDevice \u05BFڥ\u0596ࡏ;

	// Token: 0x04000157 RID: 343
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000157")]
	private InputDevice өՆԉ\u065C;

	// Token: 0x04000158 RID: 344
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000158")]
	public Vector3 ࠍ\u07FEݽ\u070C;

	// Token: 0x04000159 RID: 345
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000159")]
	public Vector3 \u089F\u06DCՐࡐ;

	// Token: 0x0400015A RID: 346
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400015A")]
	private InputDevice ڵ\u05A3\u0894ࠑ;

	// Token: 0x0400015B RID: 347
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400015B")]
	private InputDevice ݙޢغކ;

	// Token: 0x0400015C RID: 348
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x400015C")]
	public Transform ڣխծ\u07B2;

	// Token: 0x0400015D RID: 349
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x400015D")]
	public Transform \u07F1\u05A4ֈ\u085A;

	// Token: 0x0400015E RID: 350
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x400015E")]
	public float ԤӿնӲ;

	// Token: 0x0400015F RID: 351
	[FieldOffset(Offset = "0x84")]
	[Token(Token = "0x400015F")]
	public float ߂ؽڵ\u07B9;

	// Token: 0x04000160 RID: 352
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x4000160")]
	public float ԕݗޜ\u0656;

	// Token: 0x04000161 RID: 353
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x4000161")]
	public AudioSource ݻ\u0559թՉ;

	// Token: 0x04000162 RID: 354
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x4000162")]
	public AudioSource ػտ\u065A\u0870;

	// Token: 0x04000163 RID: 355
	[FieldOffset(Offset = "0xA0")]
	[Token(Token = "0x4000163")]
	public SwimmyV2 \u0559ݹՈ\u055F;
}
