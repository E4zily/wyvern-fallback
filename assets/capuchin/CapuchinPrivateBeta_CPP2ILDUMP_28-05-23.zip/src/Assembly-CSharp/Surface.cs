﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000023 RID: 35
[Token(Token = "0x2000023")]
public class Surface : MonoBehaviour
{
	// Token: 0x06000439 RID: 1081 RVA: 0x00018768 File Offset: 0x00016968
	[Token(Token = "0x6000439")]
	[Address(RVA = "0x2F7B030", Offset = "0x2F7B030", VA = "0x2F7B030")]
	public Surface()
	{
	}

	// Token: 0x040000AA RID: 170
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000AA")]
	public זߍս\u05A0 \u07FC\u086BՀ\u0615;

	// Token: 0x040000AB RID: 171
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x40000AB")]
	public bool ա\u07FF\u0835ڙ;
}
