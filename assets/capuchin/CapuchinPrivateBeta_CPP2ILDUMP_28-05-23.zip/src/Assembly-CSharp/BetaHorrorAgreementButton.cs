﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000004 RID: 4
[Token(Token = "0x2000004")]
public class BetaHorrorAgreementButton : MonoBehaviour
{
	// Token: 0x06000067 RID: 103 RVA: 0x000036D0 File Offset: 0x000018D0
	[Token(Token = "0x6000067")]
	[Address(RVA = "0x2C0FAD4", Offset = "0x2C0FAD4", VA = "0x2C0FAD4")]
	public void ل\u0732ߍӒ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000068 RID: 104 RVA: 0x000036FC File Offset: 0x000018FC
	[Token(Token = "0x6000068")]
	[Address(RVA = "0x2C0FBD4", Offset = "0x2C0FBD4", VA = "0x2C0FBD4")]
	public void نո\u0599\u0589()
	{
		bool flag = PlayerPrefs.GetString("_Tint") == "Players In Room: ";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00003738 File Offset: 0x00001938
	[Token(Token = "0x6000069")]
	[Address(RVA = "0x2C0FC6C", Offset = "0x2C0FC6C", VA = "0x2C0FC6C")]
	public void ࡩݮڢՠ()
	{
		bool flag = PlayerPrefs.GetString("Player") == "You struck apon an error. ";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00003774 File Offset: 0x00001974
	[Token(Token = "0x600006A")]
	[Address(RVA = "0x2C0FD04", Offset = "0x2C0FD04", VA = "0x2C0FD04")]
	public void ފԅ\u0881ݾ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("containsStaff", "Failed To Join Public Room Successfully. The error is: ");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600006B RID: 107 RVA: 0x000037B4 File Offset: 0x000019B4
	[Token(Token = "0x600006B")]
	[Address(RVA = "0x2C0FE04", Offset = "0x2C0FE04", VA = "0x2C0FE04")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("You are on an outdated version of Capuchin. Your version is ", "DISABLE");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600006C RID: 108 RVA: 0x000037F4 File Offset: 0x000019F4
	[Token(Token = "0x600006C")]
	[Address(RVA = "0x2C0FF04", Offset = "0x2C0FF04", VA = "0x2C0FF04")]
	public void ۲ڂ\u05B1ڨ()
	{
		bool flag = PlayerPrefs.GetString("Combine textures & build combined mesh all at once") == "QuickStatic";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600006D RID: 109 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600006D")]
	[Address(RVA = "0x2C0FF88", Offset = "0x2C0FF88", VA = "0x2C0FF88")]
	public void \u05C1ؽԜࡥ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600006E RID: 110 RVA: 0x0000382C File Offset: 0x00001A2C
	[Token(Token = "0x600006E")]
	[Address(RVA = "0x2C10088", Offset = "0x2C10088", VA = "0x2C10088")]
	public void ة\u066Dࡏԫ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Player", "Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600006F RID: 111 RVA: 0x0000386C File Offset: 0x00001A6C
	[Token(Token = "0x600006F")]
	[Address(RVA = "0x2C10188", Offset = "0x2C10188", VA = "0x2C10188")]
	public void \u065F\u0839ܤ\u073C()
	{
		bool flag = PlayerPrefs.GetString("PRESS AGAIN TO CONFIRM") == "Skelechin";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000070 RID: 112 RVA: 0x000038A4 File Offset: 0x00001AA4
	[Token(Token = "0x6000070")]
	[Address(RVA = "0x2C1020C", Offset = "0x2C1020C", VA = "0x2C1020C")]
	public void ݍ\u05F4ߓ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("This is the 5000 Bananas button, and it was just clicked", "spooky guy true");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000071 RID: 113 RVA: 0x000038E4 File Offset: 0x00001AE4
	[Token(Token = "0x6000071")]
	[Address(RVA = "0x2C1030C", Offset = "0x2C1030C", VA = "0x2C1030C")]
	public void ہۼآԄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Start Gamemode", "Failed To Join Public Room Successfully. The error is: ");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000072 RID: 114 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000072")]
	[Address(RVA = "0x2C1040C", Offset = "0x2C1040C", VA = "0x2C1040C")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("CapuchinStore", "StartGamemode");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000073 RID: 115 RVA: 0x00003964 File Offset: 0x00001B64
	[Token(Token = "0x6000073")]
	[Address(RVA = "0x2C1050C", Offset = "0x2C1050C", VA = "0x2C1050C")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("PlayWave", "PRESS AGAIN TO CONFIRM");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000074 RID: 116 RVA: 0x000039A4 File Offset: 0x00001BA4
	[Token(Token = "0x6000074")]
	[Address(RVA = "0x2C1060C", Offset = "0x2C1060C", VA = "0x2C1060C")]
	public void \u066Dӝߏآ()
	{
		bool flag = PlayerPrefs.GetString("Reason: ") == "amongus";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000075 RID: 117 RVA: 0x000039DC File Offset: 0x00001BDC
	[Token(Token = "0x6000075")]
	[Address(RVA = "0x2C10690", Offset = "0x2C10690", VA = "0x2C10690")]
	public void ӛ\u082Eؿڕ()
	{
		bool flag = PlayerPrefs.GetString("gamemode") == "BN";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x06000076 RID: 118 RVA: 0x00003A18 File Offset: 0x00001C18
	[Token(Token = "0x6000076")]
	[Address(RVA = "0x2C10728", Offset = "0x2C10728", VA = "0x2C10728")]
	public void \u0656ӺմՁ()
	{
		bool flag = PlayerPrefs.GetString("FLSPTLT") == "PURCHASE";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x06000077 RID: 119 RVA: 0x00003A54 File Offset: 0x00001C54
	[Token(Token = "0x6000077")]
	[Address(RVA = "0x2C107C0", Offset = "0x2C107C0", VA = "0x2C107C0")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("RainAndThunderWeather", "Vector1_d371bd24217449349bd747533d51af6b");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00003A94 File Offset: 0x00001C94
	[Token(Token = "0x6000078")]
	[Address(RVA = "0x2C108C0", Offset = "0x2C108C0", VA = "0x2C108C0")]
	public void ճ\u0828Ԓհ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Name Changing Error. Error: ", "Joined a Room.");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000079 RID: 121 RVA: 0x00003AD4 File Offset: 0x00001CD4
	[Token(Token = "0x6000079")]
	[Address(RVA = "0x2C109C0", Offset = "0x2C109C0", VA = "0x2C109C0")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("M/d/yyyy", "Trying Getting Entilement...");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600007A RID: 122 RVA: 0x00003B14 File Offset: 0x00001D14
	[Token(Token = "0x600007A")]
	[Address(RVA = "0x2C10AC0", Offset = "0x2C10AC0", VA = "0x2C10AC0")]
	public void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("RightHandAttachPoint", "_Tint");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00003B54 File Offset: 0x00001D54
	[Token(Token = "0x600007B")]
	[Address(RVA = "0x2C10BC0", Offset = "0x2C10BC0", VA = "0x2C10BC0")]
	public void Start()
	{
		bool flag = PlayerPrefs.GetString("HorrorAgreement") == "Agreed";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x0600007C RID: 124 RVA: 0x00003B90 File Offset: 0x00001D90
	[Token(Token = "0x600007C")]
	[Address(RVA = "0x2C10C58", Offset = "0x2C10C58", VA = "0x2C10C58")]
	public void ߖհݣ߀()
	{
		bool flag = PlayerPrefs.GetString("DisableCosmetic") == "Player";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00003BC8 File Offset: 0x00001DC8
	[Token(Token = "0x600007D")]
	[Address(RVA = "0x2C10CDC", Offset = "0x2C10CDC", VA = "0x2C10CDC")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("HorrorAgreement", "Agreed");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00003C08 File Offset: 0x00001E08
	[Token(Token = "0x600007E")]
	[Address(RVA = "0x2C10DDC", Offset = "0x2C10DDC", VA = "0x2C10DDC")]
	public void Փ\u06DF\u0839ԟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("closeToObject", "got funky mone");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00003C48 File Offset: 0x00001E48
	[Token(Token = "0x600007F")]
	[Address(RVA = "0x2C10EDC", Offset = "0x2C10EDC", VA = "0x2C10EDC")]
	public void ࢺճ\u05A0ڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("SetColor", "Player");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00003C88 File Offset: 0x00001E88
	[Token(Token = "0x6000080")]
	[Address(RVA = "0x2C10FDC", Offset = "0x2C10FDC", VA = "0x2C10FDC")]
	public void حتݻ\u05B0()
	{
		bool flag = PlayerPrefs.GetString("PRESS AGAIN TO CONFIRM") == "Hate Speech";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00003CC4 File Offset: 0x00001EC4
	[Token(Token = "0x6000081")]
	[Address(RVA = "0x2C11074", Offset = "0x2C11074", VA = "0x2C11074")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("StartGamemode", "BN");
	}

	// Token: 0x06000082 RID: 130 RVA: 0x00003CF8 File Offset: 0x00001EF8
	[Token(Token = "0x6000082")]
	[Address(RVA = "0x2C11174", Offset = "0x2C11174", VA = "0x2C11174")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("TurnAmount", "Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000083 RID: 131 RVA: 0x00003D38 File Offset: 0x00001F38
	[Token(Token = "0x6000083")]
	[Address(RVA = "0x2C11274", Offset = "0x2C11274", VA = "0x2C11274")]
	public void ١ۏ\u05C4ӝ()
	{
		bool flag = PlayerPrefs.GetString("HandL") == "TurnAmount";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x06000084 RID: 132 RVA: 0x00003D74 File Offset: 0x00001F74
	[Token(Token = "0x6000084")]
	[Address(RVA = "0x2C1130C", Offset = "0x2C1130C", VA = "0x2C1130C")]
	public void Ԇܥډݑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("", "sound play stopped");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000085 RID: 133 RVA: 0x00003DB4 File Offset: 0x00001FB4
	[Token(Token = "0x6000085")]
	[Address(RVA = "0x2C1140C", Offset = "0x2C1140C", VA = "0x2C1140C")]
	public void \u0818ՠש\u0731()
	{
		bool flag = PlayerPrefs.GetString("ScoreCounter") == "typesOfTalk";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000086 RID: 134 RVA: 0x00003DEC File Offset: 0x00001FEC
	[Token(Token = "0x6000086")]
	[Address(RVA = "0x2C11490", Offset = "0x2C11490", VA = "0x2C11490")]
	public void \u073BօӁ\u059A()
	{
		string a;
		bool flag = a == "containsStaff";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000087 RID: 135 RVA: 0x00003E1C File Offset: 0x0000201C
	[Token(Token = "0x6000087")]
	[Address(RVA = "0x2C11514", Offset = "0x2C11514", VA = "0x2C11514")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("DisableCosmetic", "HOLY MOLY THE STICK IS ON FIRE!!!!!!");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000088 RID: 136 RVA: 0x00003E5C File Offset: 0x0000205C
	[Token(Token = "0x6000088")]
	[Address(RVA = "0x2C11614", Offset = "0x2C11614", VA = "0x2C11614")]
	public void ۊո\u0612\u0595()
	{
		bool flag = PlayerPrefs.GetString("Body") == "SetColor";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x06000089 RID: 137 RVA: 0x00003E98 File Offset: 0x00002098
	[Token(Token = "0x6000089")]
	[Address(RVA = "0x2C116AC", Offset = "0x2C116AC", VA = "0x2C116AC")]
	public void ۮߝڪڐ()
	{
		bool flag = PlayerPrefs.GetString("Found Gameobject: ") == "Display Name Changed!";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x0600008A RID: 138 RVA: 0x00003ED4 File Offset: 0x000020D4
	[Token(Token = "0x600008A")]
	[Address(RVA = "0x2C11744", Offset = "0x2C11744", VA = "0x2C11744")]
	public void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("got funky mone", "/");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600008B RID: 139 RVA: 0x00003F14 File Offset: 0x00002114
	[Token(Token = "0x600008B")]
	[Address(RVA = "0x2C11844", Offset = "0x2C11844", VA = "0x2C11844")]
	public void چ\u05AEךڰ()
	{
		string @string = PlayerPrefs.GetString("Date: ");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x0600008C RID: 140 RVA: 0x00003F44 File Offset: 0x00002144
	[Token(Token = "0x600008C")]
	[Address(RVA = "0x2C118DC", Offset = "0x2C118DC", VA = "0x2C118DC")]
	public void ۓݳۯ٨()
	{
		bool flag = PlayerPrefs.GetString("TurnAmount") == "ORGTARG";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600008D RID: 141 RVA: 0x00003F7C File Offset: 0x0000217C
	[Token(Token = "0x600008D")]
	[Address(RVA = "0x2C11960", Offset = "0x2C11960", VA = "0x2C11960")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600008E RID: 142 RVA: 0x00003FAC File Offset: 0x000021AC
	[Token(Token = "0x600008E")]
	[Address(RVA = "0x2C11A60", Offset = "0x2C11A60", VA = "0x2C11A60")]
	public void ࢰחڵࡓ()
	{
		bool flag = PlayerPrefs.GetString("TurnAmount") == "DISABLE";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600008F RID: 143 RVA: 0x00003FE4 File Offset: 0x000021E4
	[Token(Token = "0x600008F")]
	[Address(RVA = "0x2C11AE4", Offset = "0x2C11AE4", VA = "0x2C11AE4")]
	public void \u05AD\u0881ࡆݡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("ErrorScreen", "username");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000090 RID: 144 RVA: 0x00004024 File Offset: 0x00002224
	[Token(Token = "0x6000090")]
	[Address(RVA = "0x2C11BE4", Offset = "0x2C11BE4", VA = "0x2C11BE4")]
	public void ۷ޞ\u07AFߍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString(", ", "False");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000091 RID: 145 RVA: 0x00004064 File Offset: 0x00002264
	[Token(Token = "0x6000091")]
	[Address(RVA = "0x2C11CE4", Offset = "0x2C11CE4", VA = "0x2C11CE4")]
	public void \u0652\u058Bک\u061C()
	{
		bool flag = PlayerPrefs.GetString("Horizontal") == "FingerTip";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000092 RID: 146 RVA: 0x0000409C File Offset: 0x0000229C
	[Token(Token = "0x6000092")]
	[Address(RVA = "0x2C11D68", Offset = "0x2C11D68", VA = "0x2C11D68")]
	public void Գӿېչ()
	{
		bool flag = PlayerPrefs.GetString("Horizontal") == "hh:mm:sstt";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000093 RID: 147 RVA: 0x000040D4 File Offset: 0x000022D4
	[Token(Token = "0x6000093")]
	[Address(RVA = "0x2C11DEC", Offset = "0x2C11DEC", VA = "0x2C11DEC")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("typesOfTalk", "A new Player joined a Room.");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000094 RID: 148 RVA: 0x00004114 File Offset: 0x00002314
	[Token(Token = "0x6000094")]
	[Address(RVA = "0x2C11EEC", Offset = "0x2C11EEC", VA = "0x2C11EEC")]
	public void ߉ې\u07F6Ӭ()
	{
		bool flag = PlayerPrefs.GetString("Player") == " and the correct version is ";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000095 RID: 149 RVA: 0x0000414C File Offset: 0x0000234C
	[Token(Token = "0x6000095")]
	[Address(RVA = "0x2C11F70", Offset = "0x2C11F70", VA = "0x2C11F70")]
	public void ࢢ٧\u085DԀ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Player", "hh:mm:sstt");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000096 RID: 150 RVA: 0x0000418C File Offset: 0x0000238C
	[Token(Token = "0x6000096")]
	[Address(RVA = "0x2C12070", Offset = "0x2C12070", VA = "0x2C12070")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString(" ", "TurnAmount");
	}

	// Token: 0x06000097 RID: 151 RVA: 0x000041C0 File Offset: 0x000023C0
	[Token(Token = "0x6000097")]
	[Address(RVA = "0x2C12170", Offset = "0x2C12170", VA = "0x2C12170")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Player", "BLUPORT");
	}

	// Token: 0x06000098 RID: 152 RVA: 0x000041F4 File Offset: 0x000023F4
	[Token(Token = "0x6000098")]
	[Address(RVA = "0x2C12270", Offset = "0x2C12270", VA = "0x2C12270")]
	public void \u05F5ߪތӝ()
	{
		string @string = PlayerPrefs.GetString("waited for your bullshit unity grrr");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x06000099 RID: 153 RVA: 0x00004224 File Offset: 0x00002424
	[Token(Token = "0x6000099")]
	[Address(RVA = "0x2C122F4", Offset = "0x2C122F4", VA = "0x2C122F4")]
	public void سࡕԞ߆(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("jump char false", "TurnAmount");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600009A RID: 154 RVA: 0x00004264 File Offset: 0x00002464
	[Token(Token = "0x600009A")]
	[Address(RVA = "0x2C123F4", Offset = "0x2C123F4", VA = "0x2C123F4")]
	public void ۿࢹ\u0705\u0825()
	{
		bool flag = PlayerPrefs.GetString("Open") == "clickLol";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x0600009B RID: 155 RVA: 0x000042A0 File Offset: 0x000024A0
	[Token(Token = "0x600009B")]
	[Address(RVA = "0x2C1248C", Offset = "0x2C1248C", VA = "0x2C1248C")]
	public void \u066A\u059Eټ\u085A()
	{
		bool flag = PlayerPrefs.GetString("BLUPORT") == "PURCHASED!";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600009C RID: 156 RVA: 0x000042D8 File Offset: 0x000024D8
	[Token(Token = "0x600009C")]
	[Address(RVA = "0x2C12510", Offset = "0x2C12510", VA = "0x2C12510")]
	public void ڍ\u058Bݗࡣ()
	{
		bool flag = PlayerPrefs.GetString("ORGPORT") == "Players: ";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600009D RID: 157 RVA: 0x00004310 File Offset: 0x00002510
	[Token(Token = "0x600009D")]
	[Address(RVA = "0x2C12594", Offset = "0x2C12594", VA = "0x2C12594")]
	public void ࡅݐ\u082Dք()
	{
		bool flag = PlayerPrefs.GetString("Key") == "Player";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x0600009E RID: 158 RVA: 0x00004348 File Offset: 0x00002548
	[Token(Token = "0x600009E")]
	[Address(RVA = "0x2C12618", Offset = "0x2C12618", VA = "0x2C12618")]
	public void \u0882צ\u0821\u05B4()
	{
		string @string = PlayerPrefs.GetString("");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x0600009F RID: 159 RVA: 0x00004378 File Offset: 0x00002578
	[Token(Token = "0x600009F")]
	[Address(RVA = "0x2C126B0", Offset = "0x2C126B0", VA = "0x2C126B0")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Player", "FingerTip");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000A0 RID: 160 RVA: 0x000043B8 File Offset: 0x000025B8
	[Token(Token = "0x60000A0")]
	[Address(RVA = "0x2C127B0", Offset = "0x2C127B0", VA = "0x2C127B0")]
	public void ܩחݵޔ()
	{
		bool flag = PlayerPrefs.GetString("Not connected to room") == "Not connected to room";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x000043F0 File Offset: 0x000025F0
	[Token(Token = "0x60000A1")]
	[Address(RVA = "0x2C12834", Offset = "0x2C12834", VA = "0x2C12834")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x00004420 File Offset: 0x00002620
	[Token(Token = "0x60000A2")]
	[Address(RVA = "0x2C12934", Offset = "0x2C12934", VA = "0x2C12934")]
	public void \u055E\u0703\u0700ܠ()
	{
		bool flag = PlayerPrefs.GetString("You Already Own This Item") == "TurnAmount";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x0000445C File Offset: 0x0000265C
	[Token(Token = "0x60000A3")]
	[Address(RVA = "0x2C129CC", Offset = "0x2C129CC", VA = "0x2C129CC")]
	public void ࡎ\u05C2սࠇ()
	{
		bool flag = PlayerPrefs.GetString("Calling success callback. baking meshes") == "Game Started";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x00004494 File Offset: 0x00002694
	[Token(Token = "0x60000A4")]
	[Address(RVA = "0x2C12A50", Offset = "0x2C12A50", VA = "0x2C12A50")]
	public void \u0834\u0817ރࡔ()
	{
		bool flag = PlayerPrefs.GetString("Vector1_d371bd24217449349bd747533d51af6b") == "\tExpires: ";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x000044CC File Offset: 0x000026CC
	[Token(Token = "0x60000A5")]
	[Address(RVA = "0x2C12AD4", Offset = "0x2C12AD4", VA = "0x2C12AD4")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if ("IsLowSurrogates" == null)
		{
		}
		bool flag = component;
		PlayerPrefs.SetString("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:", "CapuchinRemade");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x00004514 File Offset: 0x00002714
	[Token(Token = "0x60000A6")]
	[Address(RVA = "0x2C12BD4", Offset = "0x2C12BD4", VA = "0x2C12BD4")]
	public void Ԯ\u0883\u0591\u066C()
	{
		bool flag = PlayerPrefs.GetString("friend") == "gameMode";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x00004550 File Offset: 0x00002750
	[Token(Token = "0x60000A7")]
	[Address(RVA = "0x2C12C6C", Offset = "0x2C12C6C", VA = "0x2C12C6C")]
	public BetaHorrorAgreementButton()
	{
	}

	// Token: 0x060000A8 RID: 168 RVA: 0x00004564 File Offset: 0x00002764
	[Token(Token = "0x60000A8")]
	[Address(RVA = "0x2C12C74", Offset = "0x2C12C74", VA = "0x2C12C74")]
	public void ݸԲ\u0616Ԫ()
	{
		bool flag = PlayerPrefs.GetString("TurnAmount") == "Round end";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x060000A9 RID: 169 RVA: 0x000045A0 File Offset: 0x000027A0
	[Token(Token = "0x60000A9")]
	[Address(RVA = "0x2C12D0C", Offset = "0x2C12D0C", VA = "0x2C12D0C")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Target", "tutorialCheck");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000AA RID: 170 RVA: 0x000045E0 File Offset: 0x000027E0
	[Token(Token = "0x60000AA")]
	[Address(RVA = "0x2C12E0C", Offset = "0x2C12E0C", VA = "0x2C12E0C")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("run", "Room Name: ");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000AB RID: 171 RVA: 0x00004620 File Offset: 0x00002820
	[Token(Token = "0x60000AB")]
	[Address(RVA = "0x2C12F0C", Offset = "0x2C12F0C", VA = "0x2C12F0C")]
	public void \u059B\u081F\u05FEڂ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("1BN", "Muted");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000AC RID: 172 RVA: 0x00004660 File Offset: 0x00002860
	[Token(Token = "0x60000AC")]
	[Address(RVA = "0x2C1300C", Offset = "0x2C1300C", VA = "0x2C1300C")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("token", "gamemode");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000AD RID: 173 RVA: 0x000046A0 File Offset: 0x000028A0
	[Token(Token = "0x60000AD")]
	[Address(RVA = "0x2C1310C", Offset = "0x2C1310C", VA = "0x2C1310C")]
	public void ԉՔӸ\u06DC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Purchased: ", "PRESS AGAIN TO CONFIRM");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000AE RID: 174 RVA: 0x000046E0 File Offset: 0x000028E0
	[Token(Token = "0x60000AE")]
	[Address(RVA = "0x2C1320C", Offset = "0x2C1320C", VA = "0x2C1320C")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("PlayWave", "Failed to login, please restart");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000AF RID: 175 RVA: 0x00004720 File Offset: 0x00002920
	[Token(Token = "0x60000AF")]
	[Address(RVA = "0x2C1330C", Offset = "0x2C1330C", VA = "0x2C1330C")]
	public void \u081FԘں\u07B2(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("We don't need this electrical box", "META");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000B0 RID: 176 RVA: 0x00004760 File Offset: 0x00002960
	[Token(Token = "0x60000B0")]
	[Address(RVA = "0x2C1340C", Offset = "0x2C1340C", VA = "0x2C1340C")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		PlayerPrefs.SetString("isLava", "True");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000B1 RID: 177 RVA: 0x0000479C File Offset: 0x0000299C
	[Token(Token = "0x60000B1")]
	[Address(RVA = "0x2C1350C", Offset = "0x2C1350C", VA = "0x2C1350C")]
	public void \u05C1ܡԘޘ()
	{
		bool flag = PlayerPrefs.GetString("Player") == "hand 1";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x060000B2 RID: 178 RVA: 0x000047D8 File Offset: 0x000029D8
	[Token(Token = "0x60000B2")]
	[Address(RVA = "0x2C135A4", Offset = "0x2C135A4", VA = "0x2C135A4")]
	public void \u06EDٵ۶\u06DB()
	{
		bool flag = PlayerPrefs.GetString("Name Changing Error. Error: ") == "RainAndThunderWeather";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000B3 RID: 179 RVA: 0x00004810 File Offset: 0x00002A10
	[Token(Token = "0x60000B3")]
	[Address(RVA = "0x2C13628", Offset = "0x2C13628", VA = "0x2C13628")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Player", "Faild To Add Winner Money: ");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000B4 RID: 180 RVA: 0x00004850 File Offset: 0x00002A50
	[Token(Token = "0x60000B4")]
	[Address(RVA = "0x2C13728", Offset = "0x2C13728", VA = "0x2C13728")]
	public void \u070Fߨ\u05B0ۈ()
	{
		bool flag = PlayerPrefs.GetString("Added Winner Money") == "Player";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000B5 RID: 181 RVA: 0x00004888 File Offset: 0x00002A88
	[Token(Token = "0x60000B5")]
	[Address(RVA = "0x2C137AC", Offset = "0x2C137AC", VA = "0x2C137AC")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.", "Player");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000B6 RID: 182 RVA: 0x000048C8 File Offset: 0x00002AC8
	[Token(Token = "0x60000B6")]
	[Address(RVA = "0x2C138AC", Offset = "0x2C138AC", VA = "0x2C138AC")]
	public void ןٮ\u061FԺ()
	{
		bool flag = PlayerPrefs.GetString("ChangePlayerSize") == "clickLol";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000B7 RID: 183 RVA: 0x00004900 File Offset: 0x00002B00
	[Token(Token = "0x60000B7")]
	[Address(RVA = "0x2C13930", Offset = "0x2C13930", VA = "0x2C13930")]
	public void \u07B4\u0594ԁڇ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("typesOfTalk", "Vector1_d371bd24217449349bd747533d51af6b");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000B8 RID: 184 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60000B8")]
	[Address(RVA = "0x2C13A30", Offset = "0x2C13A30", VA = "0x2C13A30")]
	public void ܯר\u05C7ڗ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060000B9 RID: 185 RVA: 0x00004940 File Offset: 0x00002B40
	[Token(Token = "0x60000B9")]
	[Address(RVA = "0x2C13B30", Offset = "0x2C13B30", VA = "0x2C13B30")]
	public void \u0705خڃ\u059B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Player", "Is Colliding");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000BA RID: 186 RVA: 0x00004980 File Offset: 0x00002B80
	[Token(Token = "0x60000BA")]
	[Address(RVA = "0x2C13C30", Offset = "0x2C13C30", VA = "0x2C13C30")]
	public void ܘݱ\u083CԲ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if ("IsLowSurrogates" == null)
		{
		}
		bool flag = component;
		PlayerPrefs.SetString("ENABLE", "User has been reported for: ");
	}

	// Token: 0x060000BB RID: 187 RVA: 0x000049BC File Offset: 0x00002BBC
	[Token(Token = "0x60000BB")]
	[Address(RVA = "0x2C13D30", Offset = "0x2C13D30", VA = "0x2C13D30")]
	public void ޠۋ\u0530\u073E()
	{
		bool flag = PlayerPrefs.GetString("_Tint") == "Purchase For ";
	}

	// Token: 0x060000BC RID: 188 RVA: 0x000049E8 File Offset: 0x00002BE8
	[Token(Token = "0x60000BC")]
	[Address(RVA = "0x2C13DC8", Offset = "0x2C13DC8", VA = "0x2C13DC8")]
	public void ߁\u0829\u073E\u081A()
	{
		bool flag = PlayerPrefs.GetString("Did Hit") == ", ";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x060000BD RID: 189 RVA: 0x00004A24 File Offset: 0x00002C24
	[Token(Token = "0x60000BD")]
	[Address(RVA = "0x2C13E60", Offset = "0x2C13E60", VA = "0x2C13E60")]
	public void \u087DىԳܚ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("goDownRPC", "True");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 0L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000BE RID: 190 RVA: 0x00004A64 File Offset: 0x00002C64
	[Token(Token = "0x60000BE")]
	[Address(RVA = "0x2C13F60", Offset = "0x2C13F60", VA = "0x2C13F60")]
	public void րۀ\u0701ԝ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		PlayerPrefs.SetString("You are not the master of the server, you cannot start the game.", "Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
		long active = 1L;
		u0823٦כޖ.SetActive(active != 0L);
	}

	// Token: 0x060000BF RID: 191 RVA: 0x00004AA4 File Offset: 0x00002CA4
	[Token(Token = "0x60000BF")]
	[Address(RVA = "0x2C14060", Offset = "0x2C14060", VA = "0x2C14060")]
	public void \u082E\u06EBݼڏ()
	{
		bool flag = PlayerPrefs.GetString("False") == "username";
		GameObject u0823٦כޖ = this.\u0823٦כޖ;
	}

	// Token: 0x04000009 RID: 9
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000009")]
	public GameObject \u0823٦כޖ;
}
