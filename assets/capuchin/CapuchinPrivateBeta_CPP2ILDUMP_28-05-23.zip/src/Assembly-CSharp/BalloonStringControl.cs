﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000096 RID: 150
[Token(Token = "0x2000096")]
public class BalloonStringControl : MonoBehaviour
{
	// Token: 0x06001694 RID: 5780 RVA: 0x00080290 File Offset: 0x0007E490
	[Token(Token = "0x6001694")]
	[Address(RVA = "0x2C0DEF4", Offset = "0x2C0DEF4", VA = "0x2C0DEF4")]
	private void \u0654ޛ\u07FAذ()
	{
		do
		{
			Transform[] array = this.points;
			LineRenderer lineRenderer = this.نܨأݑ;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001695 RID: 5781 RVA: 0x000802C4 File Offset: 0x0007E4C4
	[Token(Token = "0x6001695")]
	[Address(RVA = "0x2C0DF80", Offset = "0x2C0DF80", VA = "0x2C0DF80")]
	private void \u05EDց\u081Cت()
	{
		do
		{
			Transform[] array = this.points;
			LineRenderer lineRenderer = this.نܨأݑ;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001696 RID: 5782 RVA: 0x000802F4 File Offset: 0x0007E4F4
	[Token(Token = "0x6001696")]
	[Address(RVA = "0x2C0E00C", Offset = "0x2C0E00C", VA = "0x2C0E00C")]
	private void ڑߒجވ()
	{
		do
		{
			Transform[] array = this.points;
			LineRenderer lineRenderer = this.نܨأݑ;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001697 RID: 5783 RVA: 0x00080324 File Offset: 0x0007E524
	[Token(Token = "0x6001697")]
	[Address(RVA = "0x2C0E098", Offset = "0x2C0E098", VA = "0x2C0E098")]
	private void \u066D\u05BDې߃()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.نܨأݑ = component;
		Transform[] array = this.points;
		LineRenderer lineRenderer = this.نܨأݑ;
	}

	// Token: 0x06001698 RID: 5784 RVA: 0x00080354 File Offset: 0x0007E554
	[Token(Token = "0x6001698")]
	[Address(RVA = "0x2C0E114", Offset = "0x2C0E114", VA = "0x2C0E114")]
	private void \u061B\u05EEوۈ()
	{
		do
		{
			Transform[] array = this.points;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001699 RID: 5785 RVA: 0x0008037C File Offset: 0x0007E57C
	[Token(Token = "0x6001699")]
	[Address(RVA = "0x2C0E1A0", Offset = "0x2C0E1A0", VA = "0x2C0E1A0")]
	private void Ԯ\u0883\u0591\u066C()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.نܨأݑ = component;
		Transform[] array = this.points;
		LineRenderer lineRenderer = this.نܨأݑ;
	}

	// Token: 0x0600169A RID: 5786 RVA: 0x000803AC File Offset: 0x0007E5AC
	[Token(Token = "0x600169A")]
	[Address(RVA = "0x2C0E21C", Offset = "0x2C0E21C", VA = "0x2C0E21C")]
	private void הԥ\u05B5ݴ()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.نܨأݑ = component;
		Transform[] array = this.points;
		LineRenderer lineRenderer = this.نܨأݑ;
	}

	// Token: 0x0600169B RID: 5787 RVA: 0x000803DC File Offset: 0x0007E5DC
	[Token(Token = "0x600169B")]
	[Address(RVA = "0x2C0E298", Offset = "0x2C0E298", VA = "0x2C0E298")]
	private void Start()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.نܨأݑ = component;
		Transform[] array = this.points;
		LineRenderer lineRenderer = this.نܨأݑ;
	}

	// Token: 0x0600169C RID: 5788 RVA: 0x0008040C File Offset: 0x0007E60C
	[Token(Token = "0x600169C")]
	[Address(RVA = "0x2C0E314", Offset = "0x2C0E314", VA = "0x2C0E314")]
	private void ԣԭՋࠏ()
	{
		do
		{
			Transform[] array = this.points;
			LineRenderer lineRenderer = this.نܨأݑ;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600169D RID: 5789 RVA: 0x0008043C File Offset: 0x0007E63C
	[Token(Token = "0x600169D")]
	[Address(RVA = "0x2C0E3A0", Offset = "0x2C0E3A0", VA = "0x2C0E3A0")]
	private void \u0881ݗӟ\u07BD()
	{
		do
		{
			Transform[] array = this.points;
			LineRenderer lineRenderer = this.نܨأݑ;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600169E RID: 5790 RVA: 0x00080470 File Offset: 0x0007E670
	[Token(Token = "0x600169E")]
	[Address(RVA = "0x2C0E42C", Offset = "0x2C0E42C", VA = "0x2C0E42C")]
	private void ࡅݐ\u082Dք()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.نܨأݑ = component;
		Transform[] array = this.points;
		LineRenderer lineRenderer = this.نܨأݑ;
	}

	// Token: 0x0600169F RID: 5791 RVA: 0x000804A0 File Offset: 0x0007E6A0
	[Token(Token = "0x600169F")]
	[Address(RVA = "0x2C0E4A8", Offset = "0x2C0E4A8", VA = "0x2C0E4A8")]
	private void Ҿࢹؼס()
	{
		do
		{
			Transform[] array = this.points;
			LineRenderer lineRenderer = this.نܨأݑ;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x060016A0 RID: 5792 RVA: 0x000804CC File Offset: 0x0007E6CC
	[Token(Token = "0x60016A0")]
	[Address(RVA = "0x2C0E50C", Offset = "0x2C0E50C", VA = "0x2C0E50C")]
	private void ԟ\u086Cޣ\u055E()
	{
		do
		{
			Transform[] array = this.points;
			LineRenderer lineRenderer = this.نܨأݑ;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x060016A1 RID: 5793 RVA: 0x000804F8 File Offset: 0x0007E6F8
	[Token(Token = "0x60016A1")]
	[Address(RVA = "0x2C0E570", Offset = "0x2C0E570", VA = "0x2C0E570")]
	private void ۮߝڪڐ()
	{
		LineRenderer lineRenderer;
		this.نܨأݑ = lineRenderer;
		Transform[] array = this.points;
		LineRenderer lineRenderer2 = this.نܨأݑ;
	}

	// Token: 0x060016A2 RID: 5794 RVA: 0x00080520 File Offset: 0x0007E720
	[Token(Token = "0x60016A2")]
	[Address(RVA = "0x2C0E5EC", Offset = "0x2C0E5EC", VA = "0x2C0E5EC")]
	private void \u05F7ԝߠӱ()
	{
		do
		{
			Transform[] array = this.points;
			LineRenderer lineRenderer = this.نܨأݑ;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x060016A3 RID: 5795 RVA: 0x00080550 File Offset: 0x0007E750
	[Token(Token = "0x60016A3")]
	[Address(RVA = "0x2C0E678", Offset = "0x2C0E678", VA = "0x2C0E678")]
	public BalloonStringControl()
	{
	}

	// Token: 0x060016A4 RID: 5796 RVA: 0x00080564 File Offset: 0x0007E764
	[Token(Token = "0x60016A4")]
	[Address(RVA = "0x2C0E680", Offset = "0x2C0E680", VA = "0x2C0E680")]
	private void Update()
	{
		do
		{
			Transform[] array = this.points;
			LineRenderer lineRenderer = this.نܨأݑ;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x060016A5 RID: 5797 RVA: 0x00080598 File Offset: 0x0007E798
	[Token(Token = "0x60016A5")]
	[Address(RVA = "0x2C0E70C", Offset = "0x2C0E70C", VA = "0x2C0E70C")]
	private void ߒ\u065EՎࡖ()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		Transform[] array = this.points;
		LineRenderer lineRenderer = this.نܨأݑ;
	}

	// Token: 0x060016A6 RID: 5798 RVA: 0x000805C0 File Offset: 0x0007E7C0
	[Token(Token = "0x60016A6")]
	[Address(RVA = "0x2C0E788", Offset = "0x2C0E788", VA = "0x2C0E788")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		do
		{
			Transform[] array = this.points;
			LineRenderer lineRenderer = this.نܨأݑ;
		}
		while (this.points != null);
		throw new NullReferenceException();
	}

	// Token: 0x040002CF RID: 719
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002CF")]
	private LineRenderer نܨأݑ;

	// Token: 0x040002D0 RID: 720
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002D0")]
	[SerializeField]
	private Transform[] points;
}
