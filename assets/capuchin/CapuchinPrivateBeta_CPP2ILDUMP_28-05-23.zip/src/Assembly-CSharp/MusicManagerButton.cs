﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000087 RID: 135
[Token(Token = "0x2000087")]
public class MusicManagerButton : MonoBehaviour
{
	// Token: 0x060013E4 RID: 5092 RVA: 0x00070090 File Offset: 0x0006E290
	[Token(Token = "0x60013E4")]
	[Address(RVA = "0x23BAEE4", Offset = "0x23BAEE4", VA = "0x23BAEE4")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ޛݡ\u0859ٶ();
	}

	// Token: 0x060013E5 RID: 5093 RVA: 0x000700BC File Offset: 0x0006E2BC
	[Token(Token = "0x60013E5")]
	[Address(RVA = "0x23BAFA4", Offset = "0x23BAFA4", VA = "0x23BAFA4")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u07F0וک\u073D();
	}

	// Token: 0x060013E6 RID: 5094 RVA: 0x000700E8 File Offset: 0x0006E2E8
	[Token(Token = "0x60013E6")]
	[Address(RVA = "0x23BB064", Offset = "0x23BB064", VA = "0x23BB064")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u07F0וک\u073D();
	}

	// Token: 0x060013E7 RID: 5095 RVA: 0x00070114 File Offset: 0x0006E314
	[Token(Token = "0x60013E7")]
	[Address(RVA = "0x23BB124", Offset = "0x23BB124", VA = "0x23BB124")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u07F0וک\u073D();
	}

	// Token: 0x060013E8 RID: 5096 RVA: 0x00070140 File Offset: 0x0006E340
	[Token(Token = "0x60013E8")]
	[Address(RVA = "0x23BB1E4", Offset = "0x23BB1E4", VA = "0x23BB1E4")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ޛݡ\u0859ٶ();
	}

	// Token: 0x060013E9 RID: 5097 RVA: 0x0007016C File Offset: 0x0006E36C
	[Token(Token = "0x60013E9")]
	[Address(RVA = "0x23BB2A4", Offset = "0x23BB2A4", VA = "0x23BB2A4")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u0749ӭ۳\u0612();
	}

	// Token: 0x060013EA RID: 5098 RVA: 0x00070198 File Offset: 0x0006E398
	[Token(Token = "0x60013EA")]
	[Address(RVA = "0x23BB364", Offset = "0x23BB364", VA = "0x23BB364")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ץ٩Ո\u064C();
	}

	// Token: 0x060013EB RID: 5099 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60013EB")]
	[Address(RVA = "0x23BB424", Offset = "0x23BB424", VA = "0x23BB424")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013EC RID: 5100 RVA: 0x000701C4 File Offset: 0x0006E3C4
	[Token(Token = "0x60013EC")]
	[Address(RVA = "0x23BB4E4", Offset = "0x23BB4E4", VA = "0x23BB4E4")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ץ٩Ո\u064C();
	}

	// Token: 0x060013ED RID: 5101 RVA: 0x000701F0 File Offset: 0x0006E3F0
	[Token(Token = "0x60013ED")]
	[Address(RVA = "0x23BB5A4", Offset = "0x23BB5A4", VA = "0x23BB5A4")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u07F0וک\u073D();
	}

	// Token: 0x060013EE RID: 5102 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60013EE")]
	[Address(RVA = "0x23BB664", Offset = "0x23BB664", VA = "0x23BB664")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013EF RID: 5103 RVA: 0x0007021C File Offset: 0x0006E41C
	[Token(Token = "0x60013EF")]
	[Address(RVA = "0x23BB724", Offset = "0x23BB724", VA = "0x23BB724")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u0749ӭ۳\u0612();
	}

	// Token: 0x060013F0 RID: 5104 RVA: 0x00070248 File Offset: 0x0006E448
	[Token(Token = "0x60013F0")]
	[Address(RVA = "0x23BB7E4", Offset = "0x23BB7E4", VA = "0x23BB7E4")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u0749ӭ۳\u0612();
	}

	// Token: 0x060013F1 RID: 5105 RVA: 0x00070274 File Offset: 0x0006E474
	[Token(Token = "0x60013F1")]
	[Address(RVA = "0x23BB8A4", Offset = "0x23BB8A4", VA = "0x23BB8A4")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		this.יԏࠓݱ.ץ٩Ո\u064C();
	}

	// Token: 0x060013F2 RID: 5106 RVA: 0x0007029C File Offset: 0x0006E49C
	[Token(Token = "0x60013F2")]
	[Address(RVA = "0x23BB964", Offset = "0x23BB964", VA = "0x23BB964")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.۰Շ\u05EB۱();
	}

	// Token: 0x060013F3 RID: 5107 RVA: 0x000702C8 File Offset: 0x0006E4C8
	[Token(Token = "0x60013F3")]
	[Address(RVA = "0x23BBA24", Offset = "0x23BBA24", VA = "0x23BBA24")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ޛݡ\u0859ٶ();
	}

	// Token: 0x060013F4 RID: 5108 RVA: 0x000702F4 File Offset: 0x0006E4F4
	[Token(Token = "0x60013F4")]
	[Address(RVA = "0x23BBAE4", Offset = "0x23BBAE4", VA = "0x23BBAE4")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ԯ\u061Bە\u05FB();
	}

	// Token: 0x060013F5 RID: 5109 RVA: 0x00070320 File Offset: 0x0006E520
	[Token(Token = "0x60013F5")]
	[Address(RVA = "0x23BBBA4", Offset = "0x23BBBA4", VA = "0x23BBBA4")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if ("IsLowSurrogates" == null)
		{
		}
		bool flag = component;
		this.יԏࠓݱ.\u0749ӭ۳\u0612();
	}

	// Token: 0x060013F6 RID: 5110 RVA: 0x00070354 File Offset: 0x0006E554
	[Token(Token = "0x60013F6")]
	[Address(RVA = "0x23BBC64", Offset = "0x23BBC64", VA = "0x23BBC64")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ԯ\u061Bە\u05FB();
	}

	// Token: 0x060013F7 RID: 5111 RVA: 0x00070380 File Offset: 0x0006E580
	[Token(Token = "0x60013F7")]
	[Address(RVA = "0x23BBD24", Offset = "0x23BBD24", VA = "0x23BBD24")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders exists;
		bool flag = exists;
		this.יԏࠓݱ.۰Շ\u05EB۱();
	}

	// Token: 0x060013F8 RID: 5112 RVA: 0x000703A8 File Offset: 0x0006E5A8
	[Token(Token = "0x60013F8")]
	[Address(RVA = "0x23BBDE4", Offset = "0x23BBDE4", VA = "0x23BBDE4")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ץ٩Ո\u064C();
	}

	// Token: 0x060013F9 RID: 5113 RVA: 0x000703D4 File Offset: 0x0006E5D4
	[Token(Token = "0x60013F9")]
	[Address(RVA = "0x23BBEA4", Offset = "0x23BBEA4", VA = "0x23BBEA4")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ץ٩Ո\u064C();
	}

	// Token: 0x060013FA RID: 5114 RVA: 0x00070400 File Offset: 0x0006E600
	[Token(Token = "0x60013FA")]
	[Address(RVA = "0x23BBF64", Offset = "0x23BBF64", VA = "0x23BBF64")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u0884ݾࠅࢠ();
	}

	// Token: 0x060013FB RID: 5115 RVA: 0x0007042C File Offset: 0x0006E62C
	[Token(Token = "0x60013FB")]
	[Address(RVA = "0x23BC024", Offset = "0x23BC024", VA = "0x23BC024")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u066B\u0607ڻ\u0703();
	}

	// Token: 0x060013FC RID: 5116 RVA: 0x00070458 File Offset: 0x0006E658
	[Token(Token = "0x60013FC")]
	[Address(RVA = "0x23BC0E4", Offset = "0x23BC0E4", VA = "0x23BC0E4")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ԯ\u061Bە\u05FB();
	}

	// Token: 0x060013FD RID: 5117 RVA: 0x00070484 File Offset: 0x0006E684
	[Token(Token = "0x60013FD")]
	[Address(RVA = "0x23BC1A4", Offset = "0x23BC1A4", VA = "0x23BC1A4")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
	}

	// Token: 0x060013FE RID: 5118 RVA: 0x000704A0 File Offset: 0x0006E6A0
	[Token(Token = "0x60013FE")]
	[Address(RVA = "0x23BC264", Offset = "0x23BC264", VA = "0x23BC264")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ץ٩Ո\u064C();
	}

	// Token: 0x060013FF RID: 5119 RVA: 0x000704CC File Offset: 0x0006E6CC
	[Token(Token = "0x60013FF")]
	[Address(RVA = "0x23BC324", Offset = "0x23BC324", VA = "0x23BC324")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ԯ\u061Bە\u05FB();
	}

	// Token: 0x06001400 RID: 5120 RVA: 0x000704F8 File Offset: 0x0006E6F8
	[Token(Token = "0x6001400")]
	[Address(RVA = "0x23BC3E4", Offset = "0x23BC3E4", VA = "0x23BC3E4")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ޛݡ\u0859ٶ();
	}

	// Token: 0x06001401 RID: 5121 RVA: 0x00070524 File Offset: 0x0006E724
	[Token(Token = "0x6001401")]
	[Address(RVA = "0x23BC4A4", Offset = "0x23BC4A4", VA = "0x23BC4A4")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ץ٩Ո\u064C();
	}

	// Token: 0x06001402 RID: 5122 RVA: 0x00070550 File Offset: 0x0006E750
	[Token(Token = "0x6001402")]
	[Address(RVA = "0x23BC564", Offset = "0x23BC564", VA = "0x23BC564")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ޛݡ\u0859ٶ();
	}

	// Token: 0x06001403 RID: 5123 RVA: 0x0007057C File Offset: 0x0006E77C
	[Token(Token = "0x6001403")]
	[Address(RVA = "0x23BC624", Offset = "0x23BC624", VA = "0x23BC624")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u07F0וک\u073D();
	}

	// Token: 0x06001404 RID: 5124 RVA: 0x000705A8 File Offset: 0x0006E7A8
	[Token(Token = "0x6001404")]
	[Address(RVA = "0x23BC6E4", Offset = "0x23BC6E4", VA = "0x23BC6E4")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.۰Շ\u05EB۱();
	}

	// Token: 0x06001405 RID: 5125 RVA: 0x000705D4 File Offset: 0x0006E7D4
	[Token(Token = "0x6001405")]
	[Address(RVA = "0x23BC7A4", Offset = "0x23BC7A4", VA = "0x23BC7A4")]
	public MusicManagerButton()
	{
	}

	// Token: 0x06001406 RID: 5126 RVA: 0x000705E8 File Offset: 0x0006E7E8
	[Token(Token = "0x6001406")]
	[Address(RVA = "0x23BC7AC", Offset = "0x23BC7AC", VA = "0x23BC7AC")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ԯ\u061Bە\u05FB();
	}

	// Token: 0x06001407 RID: 5127 RVA: 0x00070614 File Offset: 0x0006E814
	[Token(Token = "0x6001407")]
	[Address(RVA = "0x23BC86C", Offset = "0x23BC86C", VA = "0x23BC86C")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ץ٩Ո\u064C();
	}

	// Token: 0x06001408 RID: 5128 RVA: 0x00070640 File Offset: 0x0006E840
	[Token(Token = "0x6001408")]
	[Address(RVA = "0x23BC92C", Offset = "0x23BC92C", VA = "0x23BC92C")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.ץ٩Ո\u064C();
	}

	// Token: 0x06001409 RID: 5129 RVA: 0x0007066C File Offset: 0x0006E86C
	[Token(Token = "0x6001409")]
	[Address(RVA = "0x23BC9EC", Offset = "0x23BC9EC", VA = "0x23BC9EC")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u066B\u0607ڻ\u0703();
	}

	// Token: 0x0600140A RID: 5130 RVA: 0x00070698 File Offset: 0x0006E898
	[Token(Token = "0x600140A")]
	[Address(RVA = "0x23BCAAC", Offset = "0x23BCAAC", VA = "0x23BCAAC")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u066B\u0607ڻ\u0703();
	}

	// Token: 0x0600140B RID: 5131 RVA: 0x000706C4 File Offset: 0x0006E8C4
	[Token(Token = "0x600140B")]
	[Address(RVA = "0x23BCB6C", Offset = "0x23BCB6C", VA = "0x23BCB6C")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.۰Շ\u05EB۱();
	}

	// Token: 0x0600140C RID: 5132 RVA: 0x000706F0 File Offset: 0x0006E8F0
	[Token(Token = "0x600140C")]
	[Address(RVA = "0x23BCC2C", Offset = "0x23BCC2C", VA = "0x23BCC2C")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		this.יԏࠓݱ.\u066B\u0607ڻ\u0703();
	}

	// Token: 0x04000285 RID: 645
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000285")]
	public MusicManager יԏࠓݱ;
}
