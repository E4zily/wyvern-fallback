﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000072 RID: 114
[Token(Token = "0x2000072")]
public class LoadPlayerPrefs : MonoBehaviour
{
	// Token: 0x060010F2 RID: 4338 RVA: 0x00063708 File Offset: 0x00061908
	[Token(Token = "0x60010F2")]
	[Address(RVA = "0x2CDB048", Offset = "0x2CDB048", VA = "0x2CDB048")]
	private void ࡅݐ\u082Dք()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010F3 RID: 4339 RVA: 0x00063738 File Offset: 0x00061938
	[Token(Token = "0x60010F3")]
	[Address(RVA = "0x2CDB0B4", Offset = "0x2CDB0B4", VA = "0x2CDB0B4")]
	private void \u0656ӺմՁ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010F4 RID: 4340 RVA: 0x00063764 File Offset: 0x00061964
	[Token(Token = "0x60010F4")]
	[Address(RVA = "0x2CDB0F8", Offset = "0x2CDB0F8", VA = "0x2CDB0F8")]
	private void ݸԲ\u0616Ԫ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010F5 RID: 4341 RVA: 0x00063794 File Offset: 0x00061994
	[Token(Token = "0x60010F5")]
	[Address(RVA = "0x2CDB164", Offset = "0x2CDB164", VA = "0x2CDB164")]
	private void וࡪךӧ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010F6 RID: 4342 RVA: 0x000637C0 File Offset: 0x000619C0
	[Token(Token = "0x60010F6")]
	[Address(RVA = "0x2CDB1A8", Offset = "0x2CDB1A8", VA = "0x2CDB1A8")]
	private void ӭࡖݲ\u05BD()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010F7 RID: 4343 RVA: 0x000637F0 File Offset: 0x000619F0
	[Token(Token = "0x60010F7")]
	[Address(RVA = "0x2CDB214", Offset = "0x2CDB214", VA = "0x2CDB214")]
	private void ١ۏ\u05C4ӝ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010F8 RID: 4344 RVA: 0x00063820 File Offset: 0x00061A20
	[Token(Token = "0x60010F8")]
	[Address(RVA = "0x2CDB280", Offset = "0x2CDB280", VA = "0x2CDB280")]
	private void ߖհݣ߀()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010F9 RID: 4345 RVA: 0x00063850 File Offset: 0x00061A50
	[Token(Token = "0x60010F9")]
	[Address(RVA = "0x2CDB2EC", Offset = "0x2CDB2EC", VA = "0x2CDB2EC")]
	private void \u073BօӁ\u059A()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010FA RID: 4346 RVA: 0x00063880 File Offset: 0x00061A80
	[Token(Token = "0x60010FA")]
	[Address(RVA = "0x2CDB358", Offset = "0x2CDB358", VA = "0x2CDB358")]
	private void \u05F6\u05A6ӓ\u06DC()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
	}

	// Token: 0x060010FB RID: 4347 RVA: 0x000638A4 File Offset: 0x00061AA4
	[Token(Token = "0x60010FB")]
	[Address(RVA = "0x2CDB39C", Offset = "0x2CDB39C", VA = "0x2CDB39C")]
	private void \u0834\u0817ރࡔ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010FC RID: 4348 RVA: 0x000638D4 File Offset: 0x00061AD4
	[Token(Token = "0x60010FC")]
	[Address(RVA = "0x2CDB408", Offset = "0x2CDB408", VA = "0x2CDB408")]
	private void ߁\u0829\u073E\u081A()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010FD RID: 4349 RVA: 0x00063900 File Offset: 0x00061B00
	[Token(Token = "0x60010FD")]
	[Address(RVA = "0x2CDB44C", Offset = "0x2CDB44C", VA = "0x2CDB44C")]
	private void \u082E\u06EBݼڏ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010FE RID: 4350 RVA: 0x0006392C File Offset: 0x00061B2C
	[Token(Token = "0x60010FE")]
	[Address(RVA = "0x2CDB490", Offset = "0x2CDB490", VA = "0x2CDB490")]
	private void ۊո\u0612\u0595()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x060010FF RID: 4351 RVA: 0x0006395C File Offset: 0x00061B5C
	[Token(Token = "0x60010FF")]
	[Address(RVA = "0x2CDB4FC", Offset = "0x2CDB4FC", VA = "0x2CDB4FC")]
	private void ߒ\u065EՎࡖ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001100 RID: 4352 RVA: 0x0006398C File Offset: 0x00061B8C
	[Token(Token = "0x6001100")]
	[Address(RVA = "0x2CDB568", Offset = "0x2CDB568", VA = "0x2CDB568")]
	private void ڍ\u058Bݗࡣ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001101 RID: 4353 RVA: 0x000639B8 File Offset: 0x00061BB8
	[Token(Token = "0x6001101")]
	[Address(RVA = "0x2CDB5AC", Offset = "0x2CDB5AC", VA = "0x2CDB5AC")]
	private void ޡࠅ\u089Aߔ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001102 RID: 4354 RVA: 0x000639E8 File Offset: 0x00061BE8
	[Token(Token = "0x6001102")]
	[Address(RVA = "0x2CDB618", Offset = "0x2CDB618", VA = "0x2CDB618")]
	private void عۻԂ\u055E()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001103 RID: 4355 RVA: 0x00063A18 File Offset: 0x00061C18
	[Token(Token = "0x6001103")]
	[Address(RVA = "0x2CDB684", Offset = "0x2CDB684", VA = "0x2CDB684")]
	private void \u066D\u05BDې߃()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001104 RID: 4356 RVA: 0x00063A48 File Offset: 0x00061C48
	[Token(Token = "0x6001104")]
	[Address(RVA = "0x2CDB6F0", Offset = "0x2CDB6F0", VA = "0x2CDB6F0")]
	private void ޠۋ\u0530\u073E()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001105 RID: 4357 RVA: 0x00063A74 File Offset: 0x00061C74
	[Token(Token = "0x6001105")]
	[Address(RVA = "0x2CDB734", Offset = "0x2CDB734", VA = "0x2CDB734")]
	public LoadPlayerPrefs()
	{
	}

	// Token: 0x06001106 RID: 4358 RVA: 0x00063A88 File Offset: 0x00061C88
	[Token(Token = "0x6001106")]
	[Address(RVA = "0x2CDB73C", Offset = "0x2CDB73C", VA = "0x2CDB73C")]
	private void \u06EDٵ۶\u06DB()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001107 RID: 4359 RVA: 0x00063AB8 File Offset: 0x00061CB8
	[Token(Token = "0x6001107")]
	[Address(RVA = "0x2CDB7A8", Offset = "0x2CDB7A8", VA = "0x2CDB7A8")]
	private void \u070Fߨ\u05B0ۈ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001108 RID: 4360 RVA: 0x00063AE0 File Offset: 0x00061CE0
	[Token(Token = "0x6001108")]
	[Address(RVA = "0x2CDB7EC", Offset = "0x2CDB7EC", VA = "0x2CDB7EC")]
	private void حتݻ\u05B0()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001109 RID: 4361 RVA: 0x00063B10 File Offset: 0x00061D10
	[Token(Token = "0x6001109")]
	[Address(RVA = "0x2CDB858", Offset = "0x2CDB858", VA = "0x2CDB858")]
	private void ןٮ\u061FԺ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600110A RID: 4362 RVA: 0x00063B3C File Offset: 0x00061D3C
	[Token(Token = "0x600110A")]
	[Address(RVA = "0x2CDB89C", Offset = "0x2CDB89C", VA = "0x2CDB89C")]
	private void ݤۅࢦӃ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600110B RID: 4363 RVA: 0x00063B68 File Offset: 0x00061D68
	[Token(Token = "0x600110B")]
	[Address(RVA = "0x2CDB8E0", Offset = "0x2CDB8E0", VA = "0x2CDB8E0")]
	private void نո\u0599\u0589()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600110C RID: 4364 RVA: 0x00063B98 File Offset: 0x00061D98
	[Token(Token = "0x600110C")]
	[Address(RVA = "0x2CDB94C", Offset = "0x2CDB94C", VA = "0x2CDB94C")]
	private void \u05ABݿࡋ\u06E9()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600110D RID: 4365 RVA: 0x00063BC8 File Offset: 0x00061DC8
	[Token(Token = "0x600110D")]
	[Address(RVA = "0x2CDB9B8", Offset = "0x2CDB9B8", VA = "0x2CDB9B8")]
	private void ࠏޤݳ\u06DD()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600110E RID: 4366 RVA: 0x00063BF8 File Offset: 0x00061DF8
	[Token(Token = "0x600110E")]
	[Address(RVA = "0x2CDBA24", Offset = "0x2CDBA24", VA = "0x2CDBA24")]
	private void Start()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600110F RID: 4367 RVA: 0x00063C28 File Offset: 0x00061E28
	[Token(Token = "0x600110F")]
	[Address(RVA = "0x2CDBA90", Offset = "0x2CDBA90", VA = "0x2CDBA90")]
	private void Ԯ\u0883\u0591\u066C()
	{
	}

	// Token: 0x06001110 RID: 4368 RVA: 0x00063C3C File Offset: 0x00061E3C
	[Token(Token = "0x6001110")]
	[Address(RVA = "0x2CDBAD4", Offset = "0x2CDBAD4", VA = "0x2CDBAD4")]
	private void ࡩݮڢՠ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001111 RID: 4369 RVA: 0x00063C6C File Offset: 0x00061E6C
	[Token(Token = "0x6001111")]
	[Address(RVA = "0x2CDBB40", Offset = "0x2CDBB40", VA = "0x2CDBB40")]
	private void \u05C8\u05BFࠁف()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001112 RID: 4370 RVA: 0x00063C9C File Offset: 0x00061E9C
	[Token(Token = "0x6001112")]
	[Address(RVA = "0x2CDBBAC", Offset = "0x2CDBBAC", VA = "0x2CDBBAC")]
	private void הԥ\u05B5ݴ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001113 RID: 4371 RVA: 0x00063CCC File Offset: 0x00061ECC
	[Token(Token = "0x6001113")]
	[Address(RVA = "0x2CDBC18", Offset = "0x2CDBC18", VA = "0x2CDBC18")]
	private void ࢰחڵࡓ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001114 RID: 4372 RVA: 0x00063CFC File Offset: 0x00061EFC
	[Token(Token = "0x6001114")]
	[Address(RVA = "0x2CDBC84", Offset = "0x2CDBC84", VA = "0x2CDBC84")]
	private void چ\u05AEךڰ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001115 RID: 4373 RVA: 0x00063D2C File Offset: 0x00061F2C
	[Token(Token = "0x6001115")]
	[Address(RVA = "0x2CDBCF0", Offset = "0x2CDBCF0", VA = "0x2CDBCF0")]
	private void ࢥ\u081CՕࡋ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001116 RID: 4374 RVA: 0x00063D5C File Offset: 0x00061F5C
	[Token(Token = "0x6001116")]
	[Address(RVA = "0x2CDBD5C", Offset = "0x2CDBD5C", VA = "0x2CDBD5C")]
	private void ܩחݵޔ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001117 RID: 4375 RVA: 0x00063D8C File Offset: 0x00061F8C
	[Token(Token = "0x6001117")]
	[Address(RVA = "0x2CDBDC8", Offset = "0x2CDBDC8", VA = "0x2CDBDC8")]
	private void ࢧӾڈց()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001118 RID: 4376 RVA: 0x00063DB8 File Offset: 0x00061FB8
	[Token(Token = "0x6001118")]
	[Address(RVA = "0x2CDBE0C", Offset = "0x2CDBE0C", VA = "0x2CDBE0C")]
	private void \u0558ݕݤݮ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001119 RID: 4377 RVA: 0x00063DE4 File Offset: 0x00061FE4
	[Token(Token = "0x6001119")]
	[Address(RVA = "0x2CDBE50", Offset = "0x2CDBE50", VA = "0x2CDBE50")]
	private void ݱ\u0832ݥ\u08B5()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600111A RID: 4378 RVA: 0x00063E14 File Offset: 0x00062014
	[Token(Token = "0x600111A")]
	[Address(RVA = "0x2CDBEBC", Offset = "0x2CDBEBC", VA = "0x2CDBEBC")]
	private void \u07A8Ӥթݠ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600111B RID: 4379 RVA: 0x00063E40 File Offset: 0x00062040
	[Token(Token = "0x600111B")]
	[Address(RVA = "0x2CDBF00", Offset = "0x2CDBF00", VA = "0x2CDBF00")]
	private void \u086Bԍࡊڭ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600111C RID: 4380 RVA: 0x00063E6C File Offset: 0x0006206C
	[Token(Token = "0x600111C")]
	[Address(RVA = "0x2CDBF44", Offset = "0x2CDBF44", VA = "0x2CDBF44")]
	private void ۆڛߟ\u05A0()
	{
		if (this.ӧࡔࡎ\u0640 == null)
		{
			return;
		}
	}

	// Token: 0x0600111D RID: 4381 RVA: 0x00063E94 File Offset: 0x00062094
	[Token(Token = "0x600111D")]
	[Address(RVA = "0x2CDBF88", Offset = "0x2CDBF88", VA = "0x2CDBF88")]
	private void \u0739߉ڵݞ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600111E RID: 4382 RVA: 0x00063EC0 File Offset: 0x000620C0
	[Token(Token = "0x600111E")]
	[Address(RVA = "0x2CDBFCC", Offset = "0x2CDBFCC", VA = "0x2CDBFCC")]
	private void \u065F\u0839ܤ\u073C()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x0600111F RID: 4383 RVA: 0x00063EF0 File Offset: 0x000620F0
	[Token(Token = "0x600111F")]
	[Address(RVA = "0x2CDC038", Offset = "0x2CDC038", VA = "0x2CDC038")]
	private void ߉ې\u07F6Ӭ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001120 RID: 4384 RVA: 0x00063F1C File Offset: 0x0006211C
	[Token(Token = "0x6001120")]
	[Address(RVA = "0x2CDC07C", Offset = "0x2CDC07C", VA = "0x2CDC07C")]
	private void ڣֆ\u07F4ڌ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001121 RID: 4385 RVA: 0x00063F48 File Offset: 0x00062148
	[Token(Token = "0x6001121")]
	[Address(RVA = "0x2CDC0C0", Offset = "0x2CDC0C0", VA = "0x2CDC0C0")]
	private void ۮߝڪڐ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001122 RID: 4386 RVA: 0x00063F78 File Offset: 0x00062178
	[Token(Token = "0x6001122")]
	[Address(RVA = "0x2CDC12C", Offset = "0x2CDC12C", VA = "0x2CDC12C")]
	private void ӛ\u082Eؿڕ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		if (ӧࡔࡎ_u == null)
		{
			return;
		}
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x06001123 RID: 4387 RVA: 0x00063FA4 File Offset: 0x000621A4
	[Token(Token = "0x6001123")]
	[Address(RVA = "0x2CDC170", Offset = "0x2CDC170", VA = "0x2CDC170")]
	private void \u06D6ې\u083Bࠉ()
	{
		ChangeVoiceType[] ӧࡔࡎ_u = this.ӧࡔࡎ\u0640;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل = ӧࡔࡎ_u.ڰܢ\u07F6ل;
		ChangeVoiceType.\u05C4٤\u061Eݿ ڰܢ_u07F6ل2 = ӧࡔࡎ_u.ڰܢ\u07F6ل;
	}

	// Token: 0x04000240 RID: 576
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000240")]
	public ChangeVoiceType[] ӧࡔࡎ\u0640;
}
