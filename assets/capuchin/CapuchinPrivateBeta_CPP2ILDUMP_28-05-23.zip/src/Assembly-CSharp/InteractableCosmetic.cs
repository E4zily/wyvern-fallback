﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000069 RID: 105
[Token(Token = "0x2000069")]
public class InteractableCosmetic : MonoBehaviour
{
	// Token: 0x06000F7D RID: 3965 RVA: 0x00058EBC File Offset: 0x000570BC
	[Token(Token = "0x6000F7D")]
	[Address(RVA = "0x27544E4", Offset = "0x27544E4", VA = "0x27544E4")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("HOLY MOLY THE STICK IS ON FIRE!!!!!!");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F7E RID: 3966 RVA: 0x00058F1C File Offset: 0x0005711C
	[Token(Token = "0x6000F7E")]
	[Address(RVA = "0x2754618", Offset = "0x2754618", VA = "0x2754618")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("username");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F7F RID: 3967 RVA: 0x00058F7C File Offset: 0x0005717C
	[Token(Token = "0x6000F7F")]
	[Address(RVA = "0x275474C", Offset = "0x275474C", VA = "0x275474C")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F80 RID: 3968 RVA: 0x00058FDC File Offset: 0x000571DC
	[Token(Token = "0x6000F80")]
	[Address(RVA = "0x2754880", Offset = "0x2754880", VA = "0x2754880")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("HandR");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F81 RID: 3969 RVA: 0x0005903C File Offset: 0x0005723C
	[Token(Token = "0x6000F81")]
	[Address(RVA = "0x27549B4", Offset = "0x27549B4", VA = "0x27549B4")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("trol");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F82 RID: 3970 RVA: 0x0005909C File Offset: 0x0005729C
	[Token(Token = "0x6000F82")]
	[Address(RVA = "0x2754AE8", Offset = "0x2754AE8", VA = "0x2754AE8")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Mesh");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F83 RID: 3971 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000F83")]
	[Address(RVA = "0x2754C1C", Offset = "0x2754C1C", VA = "0x2754C1C")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000F84 RID: 3972 RVA: 0x000590FC File Offset: 0x000572FC
	[Token(Token = "0x6000F84")]
	[Address(RVA = "0x2754D50", Offset = "0x2754D50", VA = "0x2754D50")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("make more points bobo");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F85 RID: 3973 RVA: 0x0005915C File Offset: 0x0005735C
	[Token(Token = "0x6000F85")]
	[Address(RVA = "0x2754E84", Offset = "0x2754E84", VA = "0x2754E84")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("You struck apon an error. ");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F86 RID: 3974 RVA: 0x000591BC File Offset: 0x000573BC
	[Token(Token = "0x6000F86")]
	[Address(RVA = "0x2754FB8", Offset = "0x2754FB8", VA = "0x2754FB8")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("DisableCosmetic");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F87 RID: 3975 RVA: 0x0005921C File Offset: 0x0005741C
	[Token(Token = "0x6000F87")]
	[Address(RVA = "0x27550EC", Offset = "0x27550EC", VA = "0x27550EC")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("RainAndThunderWeather");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F88 RID: 3976 RVA: 0x0005927C File Offset: 0x0005747C
	[Token(Token = "0x6000F88")]
	[Address(RVA = "0x2755220", Offset = "0x2755220", VA = "0x2755220")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("All audio clips have been played.");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F89 RID: 3977 RVA: 0x000592DC File Offset: 0x000574DC
	[Token(Token = "0x6000F89")]
	[Address(RVA = "0x2755354", Offset = "0x2755354", VA = "0x2755354")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Platform failed to initialize due to exception.");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F8A RID: 3978 RVA: 0x0005933C File Offset: 0x0005753C
	[Token(Token = "0x6000F8A")]
	[Address(RVA = "0x2755488", Offset = "0x2755488", VA = "0x2755488")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.ܘؽԻ\u0886 != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Connected to Server.");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F8B RID: 3979 RVA: 0x0005939C File Offset: 0x0005759C
	[Token(Token = "0x6000F8B")]
	[Address(RVA = "0x27555BC", Offset = "0x27555BC", VA = "0x27555BC")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (typeof(UnityEngine.Object).TypeHandle != null)
		{
			this.ܘؽԻ\u0886.fire.Play();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("isLava");
			this.ܘؽԻ\u0886.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06000F8C RID: 3980 RVA: 0x000593FC File Offset: 0x000575FC
	[Token(Token = "0x6000F8C")]
	[Address(RVA = "0x27556F0", Offset = "0x27556F0", VA = "0x27556F0")]
	public InteractableCosmetic()
	{
	}

	// Token: 0x04000222 RID: 546
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000222")]
	public InteractableCosmetic.FireAndStick ܘؽԻ\u0886;

	// Token: 0x0200006A RID: 106
	[Token(Token = "0x200006A")]
	[Serializable]
	public struct FireAndStick
	{
		// Token: 0x04000223 RID: 547
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000223")]
		public bool isStick;

		// Token: 0x04000224 RID: 548
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4000224")]
		public ParticleSystem fire;

		// Token: 0x04000225 RID: 549
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000225")]
		public AudioSource fireCrackling;
	}
}
