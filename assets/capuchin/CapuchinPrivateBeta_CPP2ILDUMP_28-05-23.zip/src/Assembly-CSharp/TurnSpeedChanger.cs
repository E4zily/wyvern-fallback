﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

// Token: 0x020000EF RID: 239
[Token(Token = "0x20000EF")]
public class TurnSpeedChanger : MonoBehaviour
{
	// Token: 0x060024BF RID: 9407 RVA: 0x000C0ED0 File Offset: 0x000BF0D0
	[Token(Token = "0x60024BF")]
	[Address(RVA = "0x2F2B4C4", Offset = "0x2F2B4C4", VA = "0x2F2B4C4")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
		long active = 1L;
		ӫޓࢡٯ.SetActive(active != 0L);
		GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
		long active2 = 0L;
		u0888_u0705فؾ.SetActive(active2 != 0L);
		int value = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1073741824L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 0L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value2);
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16448;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 1L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 0L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value3);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16512;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 1L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 0L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value4);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 1L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active10 = 0L;
		u0888_u0705فؾ5.SetActive(active10 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value5);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active11 = 1L;
		ӫޓࢡٯ6.SetActive(active11 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active12 = 0L;
		u0888_u0705فؾ6.SetActive(active12 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value6);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active13 = 1L;
		ӫޓࢡٯ7.SetActive(active13 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active14 = 0L;
		u0888_u0705فؾ7.SetActive(active14 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value7);
		int u055B_u060Dյӣ8 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16640;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active15 = 1L;
		ӫޓࢡٯ8.SetActive(active15 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active16 = 0L;
		u0888_u0705فؾ8.SetActive(active16 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value8);
		int u055B_u060Dյӣ9 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16656;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active17 = 1L;
		ӫޓࢡٯ9.SetActive(active17 != 0L);
		this.\u0888\u0705فؾ.SetActive(active17 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value9);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active18 = 1L;
		u0888_u0705فؾ9.SetActive(active18 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long active19 = 0L;
		ӫޓࢡٯ10.SetActive(active19 != 0L);
		int value10 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value10);
	}

	// Token: 0x060024C0 RID: 9408 RVA: 0x000C1234 File Offset: 0x000BF434
	[Token(Token = "0x60024C0")]
	[Address(RVA = "0x2F2B914", Offset = "0x2F2B914", VA = "0x2F2B914")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
		long active = 0L;
		ӫޓࢡٯ.SetActive(active != 0L);
		GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
		long active2 = 0L;
		u0888_u0705فؾ.SetActive(active2 != 0L);
		int value = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1065353216L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 1L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("BLUTARG", value2);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
			long active5 = 0L;
			ӫޓࢡٯ3.SetActive(active5 != 0L);
			GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
			long active6 = 1L;
			u0888_u0705فؾ3.SetActive(active6 != 0L);
			int value3 = this.ݞظߪޡ;
			PlayerPrefs.SetInt("TurnAmount", value3);
			int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 1L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 1L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int num = this.ݞظߪޡ;
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 0L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active10 = 0L;
		u0888_u0705فؾ5.SetActive(active10 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("True", value4);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active11 = 0L;
		ӫޓࢡٯ6.SetActive(active11 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active12 = 0L;
		u0888_u0705فؾ6.SetActive(active12 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("All audio clips have been played.", value5);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA4 = this.\u089AޚӖ\u05BA;
		long turnSpeed3 = 1073741824L;
		u089AޚӖ_u05BA4.m_TurnSpeed = (float)turnSpeed3;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active13 = 0L;
		ӫޓࢡٯ7.SetActive(active13 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active14 = 0L;
		u0888_u0705فؾ7.SetActive(active14 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("containsStaff", value6);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA5 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
			long active15 = 1L;
			ӫޓࢡٯ8.SetActive(active15 != 0L);
			GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
			long active16 = 1L;
			u0888_u0705فؾ8.SetActive(active16 != 0L);
			int value7 = this.ݞظߪޡ;
			PlayerPrefs.SetInt("This is the 5000 Bananas button, and it was just clicked", value7);
			int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16816;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active17 = 0L;
		ӫޓࢡٯ9.SetActive(active17 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active18 = 1L;
		u0888_u0705فؾ9.SetActive(active18 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("_Tint", value8);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16384;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active19 = 0L;
		u0888_u0705فؾ10.SetActive(active19 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long active20 = 0L;
		ӫޓࢡٯ10.SetActive(active20 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("monkeScream", value9);
	}

	// Token: 0x060024C1 RID: 9409 RVA: 0x000C1594 File Offset: 0x000BF794
	[Token(Token = "0x60024C1")]
	[Address(RVA = "0x2F2BDC8", Offset = "0x2F2BDC8", VA = "0x2F2BDC8")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
		long active = 1L;
		ӫޓࢡٯ.SetActive(active != 0L);
		long active2 = 1L;
		ӫޓࢡٯ.SetActive(active2 != 0L);
		int value = this.ݞظߪޡ;
		PlayerPrefs.SetInt("ChangePlayerSize", value);
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
		long num = 1L;
		u0888_u0705فؾ.SetActive(num != 0L);
		PlayerPrefs.SetInt("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n", (int)num);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active4 = 1L;
		ӫޓࢡٯ3.SetActive(active4 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active5 = 0L;
		u0888_u0705فؾ2.SetActive(active5 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("ScoreCounter", value2);
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1073741824L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active6 = 0L;
		ӫޓࢡٯ4.SetActive(active6 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active7 = 0L;
		u0888_u0705فؾ3.SetActive(active7 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("FingerTip", value3);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
			long active8 = 0L;
			ӫޓࢡٯ5.SetActive(active8 != 0L);
			GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
			long active9 = 1L;
			u0888_u0705فؾ4.SetActive(active9 != 0L);
			int value4 = this.ݞظߪޡ;
			PlayerPrefs.SetInt("username", value4);
			int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active10 = 0L;
		ӫޓࢡٯ6.SetActive(active10 != 0L);
		this.\u0888\u0705فؾ.SetActive(active10 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("_Tint", value5);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active11 = 0L;
		ӫޓࢡٯ7.SetActive(active11 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active12 = 0L;
		u0888_u0705فؾ5.SetActive(active12 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("_Tint", value6);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16512;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active13 = 0L;
		ӫޓࢡٯ8.SetActive(active13 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active14 = 1L;
		u0888_u0705فؾ6.SetActive(active14 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Combine textures & build combined mesh using coroutine", value7);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)49898;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active15 = 1L;
		ӫޓࢡٯ9.SetActive(active15 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active16 = 1L;
		u0888_u0705فؾ7.SetActive(active16 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Date: ", value8);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16688;
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active17 = 1L;
		u0888_u0705فؾ8.SetActive(active17 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long active18 = 1L;
		ӫޓࢡٯ10.SetActive(active18 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("ChangeToRegular", value9);
	}

	// Token: 0x060024C2 RID: 9410 RVA: 0x000C18E0 File Offset: 0x000BFAE0
	[Token(Token = "0x60024C2")]
	[Address(RVA = "0x2F2C26C", Offset = "0x2F2C26C", VA = "0x2F2C26C")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
			long active = 1L;
			ӫޓࢡٯ.SetActive(active != 0L);
			GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
			long active2 = 1L;
			u0888_u0705فؾ.SetActive(active2 != 0L);
			int value = this.ݞظߪޡ;
			PlayerPrefs.SetInt("_BaseMap", value);
			int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		}
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 1L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Wear Hoodie", value2);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1073741824L;
		u089AޚӖ_u05BA3.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 0L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 1L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int num = this.ݞظߪޡ;
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 1L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 0L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value3);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16448;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 0L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long num2 = 0L;
		u0888_u0705فؾ5.SetActive(num2 != 0L);
		PlayerPrefs.SetInt("false", (int)num2);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA4 = this.\u089AޚӖ\u05BA;
		long turnSpeed3 = 1065353216L;
		u089AޚӖ_u05BA4.m_TurnSpeed = (float)turnSpeed3;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active10 = 1L;
		ӫޓࢡٯ6.SetActive(active10 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active11 = 1L;
		u0888_u0705فؾ6.SetActive(active11 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("monke is not my monke", value4);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16640;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active12 = 0L;
		ӫޓࢡٯ7.SetActive(active12 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active13 = 1L;
		u0888_u0705فؾ7.SetActive(active13 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Muted", value5);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active14 = 0L;
		ӫޓࢡٯ8.SetActive(active14 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active15 = 1L;
		u0888_u0705فؾ8.SetActive(active15 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("BN", value6);
		int u055B_u060Dյӣ8 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)49408;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active16 = 0L;
		ӫޓࢡٯ9.SetActive(active16 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active17 = 0L;
		u0888_u0705فؾ9.SetActive(active17 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Wear Hoodie", value7);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)17310;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active18 = 0L;
		u0888_u0705فؾ10.SetActive(active18 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long active19 = 0L;
		ӫޓࢡٯ10.SetActive(active19 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("HandL", value8);
	}

	// Token: 0x060024C3 RID: 9411 RVA: 0x000C1C40 File Offset: 0x000BFE40
	[Token(Token = "0x60024C3")]
	[Address(RVA = "0x2F2C718", Offset = "0x2F2C718", VA = "0x2F2C718")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
			long active = 1L;
			ӫޓࢡٯ.SetActive(active != 0L);
			GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
			long active2 = 0L;
			u0888_u0705فؾ.SetActive(active2 != 0L);
			int value = this.ݞظߪޡ;
			PlayerPrefs.SetInt("Adding ", value);
			int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		}
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 0L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("ErrorScreen", value2);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
			long active5 = 0L;
			ӫޓࢡٯ3.SetActive(active5 != 0L);
			GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
			long active6 = 0L;
			u0888_u0705فؾ3.SetActive(active6 != 0L);
			int value3 = this.ݞظߪޡ;
			PlayerPrefs.SetInt("On", value3);
			int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16640;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 0L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 0L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("KeyPos", value4);
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16512;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 0L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active10 = 0L;
		u0888_u0705فؾ5.SetActive(active10 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("typesOfTalk", value5);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active11 = 0L;
		ӫޓࢡٯ6.SetActive(active11 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active12 = 1L;
		u0888_u0705فؾ6.SetActive(active12 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Room Name: ", value6);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA4 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
			long active13 = 1L;
			ӫޓࢡٯ7.SetActive(active13 != 0L);
			GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
			long active14 = 1L;
			u0888_u0705فؾ7.SetActive(active14 != 0L);
			int value7 = this.ݞظߪޡ;
			PlayerPrefs.SetInt("containsStaff", value7);
			int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		}
		ContinuousTurnProviderBase u089AޚӖ_u05BA5 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1065353216L;
		u089AޚӖ_u05BA5.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active15 = 1L;
		ӫޓࢡٯ8.SetActive(active15 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active16 = 1L;
		u0888_u0705فؾ8.SetActive(active16 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("tp 2", value8);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)49864;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active17 = 1L;
		ӫޓࢡٯ9.SetActive(active17 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active18 = 1L;
		u0888_u0705فؾ9.SetActive(active18 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("tutorialCheck", value9);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)32768;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active19 = 1L;
		u0888_u0705فؾ10.SetActive(active19 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long active20 = 1L;
		ӫޓࢡٯ10.SetActive(active20 != 0L);
		int value10 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("token", value10);
	}

	// Token: 0x060024C4 RID: 9412 RVA: 0x000C1F9C File Offset: 0x000C019C
	[Token(Token = "0x60024C4")]
	[Address(RVA = "0x2F2CBC4", Offset = "0x2F2CBC4", VA = "0x2F2CBC4")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
			long active = 1L;
			ӫޓࢡٯ.SetActive(active != 0L);
			GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
			long active2 = 0L;
			u0888_u0705فؾ.SetActive(active2 != 0L);
			int value = this.ݞظߪޡ;
			PlayerPrefs.SetInt("HandL", value);
			int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 0L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Date: ", value2);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16640;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 1L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 1L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("amongus", value3);
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1073741824L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 1L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 1L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("true", value4);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1073741824L;
		u089AޚӖ_u05BA3.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 0L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active10 = 1L;
		u0888_u0705فؾ5.SetActive(active10 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("EnableCosmetic", value5);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active11 = 1L;
		ӫޓࢡٯ6.SetActive(active11 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active12 = 1L;
		u0888_u0705فؾ6.SetActive(active12 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("HandL", value6);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16448;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active13 = 0L;
		ӫޓࢡٯ7.SetActive(active13 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active14 = 1L;
		u0888_u0705فؾ7.SetActive(active14 != 0L);
		int num = this.ݞظߪޡ;
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16640;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active15 = 1L;
		ӫޓࢡٯ8.SetActive(active15 != 0L);
		this.\u0888\u0705فؾ.SetActive(active15 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("", value7);
		int u055B_u060Dյӣ8 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)49834;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active16 = 0L;
		ӫޓࢡٯ9.SetActive(active16 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active17 = 0L;
		u0888_u0705فؾ8.SetActive(active17 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt(". Please update you game to the latest version", value8);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)17273;
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active18 = 0L;
		u0888_u0705فؾ9.SetActive(active18 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long active19 = 0L;
		ӫޓࢡٯ10.SetActive(active19 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("BN", value9);
	}

	// Token: 0x060024C5 RID: 9413 RVA: 0x000C22F4 File Offset: 0x000C04F4
	[Token(Token = "0x60024C5")]
	[Address(RVA = "0x2F2D070", Offset = "0x2F2D070", VA = "0x2F2D070")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
		long active = 1L;
		ӫޓࢡٯ.SetActive(active != 0L);
		GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
		long active2 = 1L;
		u0888_u0705فؾ.SetActive(active2 != 0L);
		int value = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
			long active3 = 0L;
			ӫޓࢡٯ2.SetActive(active3 != 0L);
			GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
			long active4 = 0L;
			u0888_u0705فؾ2.SetActive(active4 != 0L);
			int value2 = this.ݞظߪޡ;
			PlayerPrefs.SetInt("HOLY MOLY THE STICK IS ON FIRE!!!!!!", value2);
			int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 0L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 1L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value3);
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16640;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 0L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 0L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("User has been reported for: ", value4);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1073741824L;
		u089AޚӖ_u05BA3.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 0L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active10 = 1L;
		u0888_u0705فؾ5.SetActive(active10 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value5);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active11 = 1L;
		ӫޓࢡٯ6.SetActive(active11 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active12 = 0L;
		u0888_u0705فؾ6.SetActive(active12 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("isLava", value6);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA4 = this.\u089AޚӖ\u05BA;
		long turnSpeed3 = 1073741824L;
		u089AޚӖ_u05BA4.m_TurnSpeed = (float)turnSpeed3;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active13 = 1L;
		ӫޓࢡٯ7.SetActive(active13 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active14 = 1L;
		u0888_u0705فؾ7.SetActive(active14 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("This is the 5000 Bananas button, and it was just clicked", value7);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active15 = 0L;
		u0888_u0705فؾ8.SetActive(active15 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("HorrorAgreement", value8);
		int u055B_u060Dյӣ8 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)49842;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active16 = 0L;
		ӫޓࢡٯ8.SetActive(active16 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active17 = 1L;
		u0888_u0705فؾ9.SetActive(active17 != 0L);
		int num = this.ݞظߪޡ;
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16384;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active18 = 0L;
		u0888_u0705فؾ10.SetActive(active18 != 0L);
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active19 = 1L;
		ӫޓࢡٯ9.SetActive(active19 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value9);
	}

	// Token: 0x060024C6 RID: 9414 RVA: 0x000C264C File Offset: 0x000C084C
	[Token(Token = "0x60024C6")]
	[Address(RVA = "0x2F2D508", Offset = "0x2F2D508", VA = "0x2F2D508")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
		long active = 0L;
		ӫޓࢡٯ.SetActive(active != 0L);
		GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
		long active2 = 1L;
		u0888_u0705فؾ.SetActive(active2 != 0L);
		int value = this.ݞظߪޡ;
		PlayerPrefs.SetInt("User has been reported for: ", value);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 1L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Tagged", value2);
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 1L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 1L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.", value3);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 1L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 1L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("sound play play", value4);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
			long active9 = 0L;
			ӫޓࢡٯ5.SetActive(active9 != 0L);
			GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
			long num = 0L;
			u0888_u0705فؾ5.SetActive(num != 0L);
			PlayerPrefs.SetInt("Removing ", (int)num);
			int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active10 = 1L;
		ӫޓࢡٯ6.SetActive(active10 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active11 = 0L;
		u0888_u0705فؾ6.SetActive(active11 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("_Tint", value5);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16640;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active12 = 1L;
		ӫޓࢡٯ7.SetActive(active12 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active13 = 1L;
		u0888_u0705فؾ7.SetActive(active13 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Updating Material to: ", value6);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16640;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active14 = 1L;
		ӫޓࢡٯ8.SetActive(active14 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active15 = 0L;
		u0888_u0705فؾ8.SetActive(active15 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("PRESS AGAIN TO CONFIRM", value7);
		int u055B_u060Dյӣ8 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16856;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active16 = 1L;
		ӫޓࢡٯ9.SetActive(active16 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active17 = 1L;
		u0888_u0705فؾ9.SetActive(active17 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value8);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)17269;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active18 = 0L;
		u0888_u0705فؾ10.SetActive(active18 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long active19 = 1L;
		ӫޓࢡٯ10.SetActive(active19 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Date: ", value9);
	}

	// Token: 0x060024C7 RID: 9415 RVA: 0x000C29A8 File Offset: 0x000C0BA8
	[Token(Token = "0x60024C7")]
	[Address(RVA = "0x2F2D9C0", Offset = "0x2F2D9C0", VA = "0x2F2D9C0")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
		long active = 1L;
		ӫޓࢡٯ.SetActive(active != 0L);
		GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
		long active2 = 0L;
		u0888_u0705فؾ.SetActive(active2 != 0L);
		int value = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1065353216L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 1L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("StartGamemode", value2);
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
		long turnSpeed3 = 1065353216L;
		u089AޚӖ_u05BA3.m_TurnSpeed = (float)turnSpeed3;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 0L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 0L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Did Hit", value3);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active7 = 1L;
		u0888_u0705فؾ4.SetActive(active7 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Added Winner Money", value4);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA4 = this.\u089AޚӖ\u05BA;
		long turnSpeed4 = 1073741824L;
		u089AޚӖ_u05BA4.m_TurnSpeed = (float)turnSpeed4;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active8 = 0L;
		ӫޓࢡٯ4.SetActive(active8 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active9 = 0L;
		u0888_u0705فؾ5.SetActive(active9 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("DisableCosmetic", value5);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active10 = 0L;
		ӫޓࢡٯ5.SetActive(active10 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active11 = 0L;
		u0888_u0705فؾ6.SetActive(active11 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("\n Time: ", value6);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA5 = this.\u089AޚӖ\u05BA;
		long turnSpeed5 = 1073741824L;
		u089AޚӖ_u05BA5.m_TurnSpeed = (float)turnSpeed5;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active12 = 0L;
		ӫޓࢡٯ6.SetActive(active12 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active13 = 1L;
		u0888_u0705فؾ7.SetActive(active13 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Version", value7);
		int u055B_u060Dյӣ8 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA6 = this.\u089AޚӖ\u05BA;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active14 = 1L;
		ӫޓࢡٯ7.SetActive(active14 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active15 = 0L;
		u0888_u0705فؾ8.SetActive(active15 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("EnableCosmetic", value8);
		int u055B_u060Dյӣ9 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16792;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active16 = 1L;
		ӫޓࢡٯ8.SetActive(active16 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active17 = 1L;
		u0888_u0705فؾ9.SetActive(active17 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("tutorialCheck", value9);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)32768;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active18 = 0L;
		u0888_u0705فؾ10.SetActive(active18 != 0L);
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active19 = 0L;
		ӫޓࢡٯ9.SetActive(active19 != 0L);
		int value10 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("_BaseColor", value10);
	}

	// Token: 0x060024C8 RID: 9416 RVA: 0x000C2D1C File Offset: 0x000C0F1C
	[Token(Token = "0x60024C8")]
	[Address(RVA = "0x2F2DE84", Offset = "0x2F2DE84", VA = "0x2F2DE84")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
		long active = 0L;
		ӫޓࢡٯ.SetActive(active != 0L);
		GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
		long active2 = 1L;
		u0888_u0705فؾ.SetActive(active2 != 0L);
		int value = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1073741824L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 0L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 0L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Holdable", value2);
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16640;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 0L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 0L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Network Player", value3);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
		long turnSpeed3 = 1073741824L;
		u089AޚӖ_u05BA3.m_TurnSpeed = (float)turnSpeed3;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 1L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 0L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Muted", value4);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 0L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active10 = 1L;
		u0888_u0705فؾ5.SetActive(active10 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("RainAndThunderWeather", value5);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA4 = this.\u089AޚӖ\u05BA;
		long turnSpeed4 = 1073741824L;
		u089AޚӖ_u05BA4.m_TurnSpeed = (float)turnSpeed4;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active11 = 0L;
		ӫޓࢡٯ6.SetActive(active11 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active12 = 0L;
		u0888_u0705فؾ6.SetActive(active12 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value6);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active13 = 0L;
		ӫޓࢡٯ7.SetActive(active13 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active14 = 0L;
		u0888_u0705فؾ7.SetActive(active14 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("EnableCosmetic", value7);
		int u055B_u060Dյӣ8 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16448;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active15 = 1L;
		ӫޓࢡٯ8.SetActive(active15 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active16 = 1L;
		u0888_u0705فؾ8.SetActive(active16 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value8);
		int u055B_u060Dյӣ9 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)49664;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active17 = 0L;
		ӫޓࢡٯ9.SetActive(active17 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active18 = 0L;
		u0888_u0705فؾ9.SetActive(active18 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("isLava", value9);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)17616;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active19 = 1L;
		u0888_u0705فؾ10.SetActive(active19 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long active20 = 1L;
		ӫޓࢡٯ10.SetActive(active20 != 0L);
		int value10 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Muted", value10);
	}

	// Token: 0x060024C9 RID: 9417 RVA: 0x000C30A0 File Offset: 0x000C12A0
	[Token(Token = "0x60024C9")]
	[Address(RVA = "0x2F2E320", Offset = "0x2F2E320", VA = "0x2F2E320")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
			long active = 1L;
			ӫޓࢡٯ.SetActive(active != 0L);
			GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
			long active2 = 1L;
			u0888_u0705فؾ.SetActive(active2 != 0L);
			int value = this.ݞظߪޡ;
			PlayerPrefs.SetInt("Name Changing Error. Error: ", value);
			int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16512;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 1L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Skelechin", value2);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
			long active5 = 1L;
			ӫޓࢡٯ3.SetActive(active5 != 0L);
			GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
			long active6 = 1L;
			u0888_u0705فؾ3.SetActive(active6 != 0L);
			int value3 = this.ݞظߪޡ;
			PlayerPrefs.SetInt("2BN", value3);
			int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 0L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 0L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Horizontal", value4);
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA3.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 1L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active10 = 0L;
		u0888_u0705فؾ5.SetActive(active10 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value5);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16448;
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active11 = 1L;
		u0888_u0705فؾ6.SetActive(active11 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value6);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16448;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active12 = 1L;
		ӫޓࢡٯ6.SetActive(active12 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active13 = 1L;
		u0888_u0705فؾ7.SetActive(active13 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Update User Inventory", value7);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16448;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active14 = 0L;
		ӫޓࢡٯ7.SetActive(active14 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active15 = 0L;
		u0888_u0705فؾ8.SetActive(active15 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("_Tint", value8);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)49808;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active16 = 1L;
		ӫޓࢡٯ8.SetActive(active16 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active17 = 0L;
		u0888_u0705فؾ9.SetActive(active17 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Added Winner Money", value9);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)49152;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active18 = 0L;
		u0888_u0705فؾ10.SetActive(active18 != 0L);
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active19 = 0L;
		ӫޓࢡٯ9.SetActive(active19 != 0L);
		int value10 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("HorrorAgreement", value10);
	}

	// Token: 0x060024CA RID: 9418 RVA: 0x000C33E8 File Offset: 0x000C15E8
	[Token(Token = "0x60024CA")]
	[Address(RVA = "0x2F2E7C8", Offset = "0x2F2E7C8", VA = "0x2F2E7C8")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
		long active = 1L;
		ӫޓࢡٯ.SetActive(active != 0L);
		GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
		long active2 = 1L;
		u0888_u0705فؾ.SetActive(active2 != 0L);
		int value = this.ݞظߪޡ;
		PlayerPrefs.SetInt("HandR", value);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 0L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 1L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int num = this.ݞظߪޡ;
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 0L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 1L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("TurnAmount", value2);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16512;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 1L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 0L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("_BumpMap", value3);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1073741824L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 1L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active10 = 1L;
		u0888_u0705فؾ5.SetActive(active10 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Regular", value4);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16640;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active11 = 0L;
		ӫޓࢡٯ6.SetActive(active11 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active12 = 1L;
		u0888_u0705فؾ6.SetActive(active12 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("ChangeToRegular", value5);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active13 = 1L;
		ӫޓࢡٯ7.SetActive(active13 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active14 = 0L;
		u0888_u0705فؾ7.SetActive(active14 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("_BaseMap", value6);
		int u055B_u060Dյӣ8 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16448;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active15 = 1L;
		ӫޓࢡٯ8.SetActive(active15 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active16 = 1L;
		u0888_u0705فؾ8.SetActive(active16 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("", value7);
		int u055B_u060Dյӣ9 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)49784;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active17 = 1L;
		ӫޓࢡٯ9.SetActive(active17 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active18 = 1L;
		u0888_u0705فؾ9.SetActive(active18 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("True", value8);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)57344;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active19 = 1L;
		u0888_u0705فؾ10.SetActive(active19 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long active20 = 0L;
		ӫޓࢡٯ10.SetActive(active20 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.", value9);
	}

	// Token: 0x060024CB RID: 9419 RVA: 0x000C3750 File Offset: 0x000C1950
	[Token(Token = "0x60024CB")]
	[Address(RVA = "0x2F2EC8C", Offset = "0x2F2EC8C", VA = "0x2F2EC8C")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
		long active = 0L;
		ӫޓࢡٯ.SetActive(active != 0L);
		GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
		long active2 = 0L;
		u0888_u0705فؾ.SetActive(active2 != 0L);
		int num = this.ݞظߪޡ;
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16512;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 0L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 1L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value = this.ݞظߪޡ;
		PlayerPrefs.SetInt("{0} ({1})", value);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
			long active5 = 0L;
			ӫޓࢡٯ3.SetActive(active5 != 0L);
			GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
			long active6 = 1L;
			u0888_u0705فؾ3.SetActive(active6 != 0L);
			int value2 = this.ݞظߪޡ;
			PlayerPrefs.SetInt("ChangePlayerSize", value2);
			int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active7 = 0L;
		ӫޓࢡٯ4.SetActive(active7 != 0L);
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active8 = 1L;
		u0888_u0705فؾ4.SetActive(active8 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Fire Stick Is Lighting...", value3);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 0L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active10 = 0L;
		u0888_u0705فؾ5.SetActive(active10 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("You Already Own This Item", value4);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1073741824L;
		u089AޚӖ_u05BA3.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active11 = 0L;
		ӫޓࢡٯ6.SetActive(active11 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active12 = 0L;
		u0888_u0705فؾ6.SetActive(active12 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("FLSPTLT", value5);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16448;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active13 = 1L;
		ӫޓࢡٯ7.SetActive(active13 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active14 = 0L;
		u0888_u0705فؾ7.SetActive(active14 != 0L);
		int num2 = this.ݞظߪޡ;
		throw new MissingMethodException();
	}

	// Token: 0x060024CC RID: 9420 RVA: 0x000C3A98 File Offset: 0x000C1C98
	[Token(Token = "0x60024CC")]
	[Address(RVA = "0x2F2F148", Offset = "0x2F2F148", VA = "0x2F2F148")]
	public TurnSpeedChanger()
	{
	}

	// Token: 0x060024CD RID: 9421 RVA: 0x000C3AAC File Offset: 0x000C1CAC
	[Token(Token = "0x60024CD")]
	[Address(RVA = "0x2F2F150", Offset = "0x2F2F150", VA = "0x2F2F150")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
			long active = 0L;
			ӫޓࢡٯ.SetActive(active != 0L);
			GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
			long active2 = 0L;
			u0888_u0705فؾ.SetActive(active2 != 0L);
			int value = this.ݞظߪޡ;
			PlayerPrefs.SetInt("NoseAttachPoint", value);
			int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		}
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 0L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("username", value2);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16608;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 1L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 0L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Tagged", value3);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
			long active7 = 1L;
			ӫޓࢡٯ4.SetActive(active7 != 0L);
			GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
			long active8 = 0L;
			u0888_u0705فؾ4.SetActive(active8 != 0L);
			int value4 = this.ݞظߪޡ;
			PlayerPrefs.SetInt("MetaId", value4);
			int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16448;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active9 = 0L;
		ӫޓࢡٯ5.SetActive(active9 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active10 = 0L;
		u0888_u0705فؾ5.SetActive(active10 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("ChangeToTagged", value5);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active11 = 1L;
		ӫޓࢡٯ6.SetActive(active11 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active12 = 1L;
		u0888_u0705فؾ6.SetActive(active12 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt(" and for the price of ", value6);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16512;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active13 = 1L;
		ӫޓࢡٯ7.SetActive(active13 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active14 = 0L;
		u0888_u0705فؾ7.SetActive(active14 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("PRESS AGAIN TO CONFIRM", value7);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16512;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active15 = 0L;
		ӫޓࢡٯ8.SetActive(active15 != 0L);
		long active16 = 0L;
		ӫޓࢡٯ8.SetActive(active16 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("username", value8);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)49692;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active17 = 0L;
		ӫޓࢡٯ9.SetActive(active17 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active18 = 1L;
		u0888_u0705فؾ8.SetActive(active18 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("PlayerHead", value9);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)40960;
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active19 = 1L;
		u0888_u0705فؾ9.SetActive(active19 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long active20 = 0L;
		ӫޓࢡٯ10.SetActive(active20 != 0L);
		int value10 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("DisableCosmetic", value10);
	}

	// Token: 0x060024CE RID: 9422 RVA: 0x000C3E00 File Offset: 0x000C2000
	[Token(Token = "0x60024CE")]
	[Address(RVA = "0x2F2F5F8", Offset = "0x2F2F5F8", VA = "0x2F2F5F8")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
			long active = 1L;
			ӫޓࢡٯ.SetActive(active != 0L);
			GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
			long active2 = 0L;
			u0888_u0705فؾ.SetActive(active2 != 0L);
			int value = this.ݞظߪޡ;
			PlayerPrefs.SetInt("Vector1_d371bd24217449349bd747533d51af6b", value);
			int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		}
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1073741824L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 0L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Player", value2);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 0L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 0L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Charged!", value3);
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
			long active7 = 0L;
			ӫޓࢡٯ4.SetActive(active7 != 0L);
			GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
			long active8 = 0L;
			u0888_u0705فؾ4.SetActive(active8 != 0L);
			int value4 = this.ݞظߪޡ;
			PlayerPrefs.SetInt("username", value4);
			if (this.\u055B\u060Dյӣ == 0)
			{
				ContinuousTurnProviderBase u089AޚӖ_u05BA4 = this.\u089AޚӖ\u05BA;
				GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
				long active9 = 0L;
				ӫޓࢡٯ5.SetActive(active9 != 0L);
				GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
				long active10 = 1L;
				u0888_u0705فؾ5.SetActive(active10 != 0L);
				int value5 = this.ݞظߪޡ;
				PlayerPrefs.SetInt("", value5);
				if (this.\u055B\u060Dյӣ == 0)
				{
					ContinuousTurnProviderBase u089AޚӖ_u05BA5 = this.\u089AޚӖ\u05BA;
					GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
					long active11 = 1L;
					ӫޓࢡٯ6.SetActive(active11 != 0L);
					GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
					long active12 = 0L;
					u0888_u0705فؾ6.SetActive(active12 != 0L);
					int value6 = this.ݞظߪޡ;
					PlayerPrefs.SetInt("Tagging", value6);
					int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
				}
			}
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16576;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active13 = 1L;
		ӫޓࢡٯ7.SetActive(active13 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active14 = 0L;
		u0888_u0705فؾ7.SetActive(active14 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Song Index: ", value7);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA6 = this.\u089AޚӖ\u05BA;
		long turnSpeed2 = 1073741824L;
		u089AޚӖ_u05BA6.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active15 = 0L;
		ӫޓࢡٯ8.SetActive(active15 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active16 = 0L;
		u0888_u0705فؾ8.SetActive(active16 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("ErrorScreen", value8);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)16544;
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active17 = 0L;
		ӫޓࢡٯ9.SetActive(active17 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active18 = 0L;
		u0888_u0705فؾ9.SetActive(active18 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("false", value9);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		this.\u089AޚӖ\u05BA.m_TurnSpeed = (float)17503;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active19 = 1L;
		u0888_u0705فؾ10.SetActive(active19 != 0L);
		GameObject ӫޓࢡٯ10 = this.Ӫޓࢡٯ;
		long num = 0L;
		ӫޓࢡٯ10.SetActive(num != 0L);
		PlayerPrefs.SetInt("PURCHASED", (int)num);
	}

	// Token: 0x060024CF RID: 9423 RVA: 0x000C4154 File Offset: 0x000C2354
	[Token(Token = "0x60024CF")]
	[Address(RVA = "0x2F2FA98", Offset = "0x2F2FA98", VA = "0x2F2FA98")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if (this.\u055B\u060Dյӣ == 0)
		{
			ContinuousTurnProviderBase u089AޚӖ_u05BA = this.\u089AޚӖ\u05BA;
			GameObject ӫޓࢡٯ = this.Ӫޓࢡٯ;
			long active = 1L;
			ӫޓࢡٯ.SetActive(active != 0L);
			GameObject u0888_u0705فؾ = this.\u0888\u0705فؾ;
			long active2 = 1L;
			u0888_u0705فؾ.SetActive(active2 != 0L);
			int value = this.ݞظߪޡ;
			PlayerPrefs.SetInt("manual footTimings length should be equal to the leg count", value);
			int u055B_u060Dյӣ = this.\u055B\u060Dյӣ;
		}
		ContinuousTurnProviderBase u089AޚӖ_u05BA2 = this.\u089AޚӖ\u05BA;
		long turnSpeed = 1065353216L;
		u089AޚӖ_u05BA2.m_TurnSpeed = (float)turnSpeed;
		GameObject ӫޓࢡٯ2 = this.Ӫޓࢡٯ;
		long active3 = 1L;
		ӫޓࢡٯ2.SetActive(active3 != 0L);
		GameObject u0888_u0705فؾ2 = this.\u0888\u0705فؾ;
		long active4 = 0L;
		u0888_u0705فؾ2.SetActive(active4 != 0L);
		int value2 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("StartSong", value2);
		int u055B_u060Dյӣ2 = this.\u055B\u060Dյӣ;
		GameObject ӫޓࢡٯ3 = this.Ӫޓࢡٯ;
		long active5 = 0L;
		ӫޓࢡٯ3.SetActive(active5 != 0L);
		GameObject u0888_u0705فؾ3 = this.\u0888\u0705فؾ;
		long active6 = 0L;
		u0888_u0705فؾ3.SetActive(active6 != 0L);
		int value3 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("PURCHASED!", value3);
		int u055B_u060Dյӣ3 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA3 = this.\u089AޚӖ\u05BA;
		GameObject u0888_u0705فؾ4 = this.\u0888\u0705فؾ;
		long active7 = 0L;
		u0888_u0705فؾ4.SetActive(active7 != 0L);
		int value4 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("isLava", value4);
		int u055B_u060Dյӣ4 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA4 = this.\u089AޚӖ\u05BA;
		int turnSpeed2 = 16640;
		u089AޚӖ_u05BA4.m_TurnSpeed = (float)turnSpeed2;
		GameObject ӫޓࢡٯ4 = this.Ӫޓࢡٯ;
		long active8 = 0L;
		ӫޓࢡٯ4.SetActive(active8 != 0L);
		GameObject u0888_u0705فؾ5 = this.\u0888\u0705فؾ;
		long active9 = 1L;
		u0888_u0705فؾ5.SetActive(active9 != 0L);
		int value5 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("sound play play", value5);
		int u055B_u060Dյӣ5 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA5 = this.\u089AޚӖ\u05BA;
		int turnSpeed3 = 16544;
		u089AޚӖ_u05BA5.m_TurnSpeed = (float)turnSpeed3;
		GameObject ӫޓࢡٯ5 = this.Ӫޓࢡٯ;
		long active10 = 0L;
		ӫޓࢡٯ5.SetActive(active10 != 0L);
		GameObject u0888_u0705فؾ6 = this.\u0888\u0705فؾ;
		long active11 = 0L;
		u0888_u0705فؾ6.SetActive(active11 != 0L);
		int value6 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("_BumpMap", value6);
		int u055B_u060Dյӣ6 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA6 = this.\u089AޚӖ\u05BA;
		int turnSpeed4 = 16512;
		u089AޚӖ_u05BA6.m_TurnSpeed = (float)turnSpeed4;
		GameObject ӫޓࢡٯ6 = this.Ӫޓࢡٯ;
		long active12 = 1L;
		ӫޓࢡٯ6.SetActive(active12 != 0L);
		GameObject u0888_u0705فؾ7 = this.\u0888\u0705فؾ;
		long active13 = 0L;
		u0888_u0705فؾ7.SetActive(active13 != 0L);
		int value7 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("HorrorAgreement", value7);
		int u055B_u060Dյӣ7 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA7 = this.\u089AޚӖ\u05BA;
		int turnSpeed5 = 16608;
		u089AޚӖ_u05BA7.m_TurnSpeed = (float)turnSpeed5;
		GameObject ӫޓࢡٯ7 = this.Ӫޓࢡٯ;
		long active14 = 0L;
		ӫޓࢡٯ7.SetActive(active14 != 0L);
		GameObject u0888_u0705فؾ8 = this.\u0888\u0705فؾ;
		long active15 = 0L;
		u0888_u0705فؾ8.SetActive(active15 != 0L);
		int value8 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Try Connect To Server...", value8);
		int u055B_u060Dյӣ8 = this.\u055B\u060Dյӣ;
		ContinuousTurnProviderBase u089AޚӖ_u05BA8 = this.\u089AޚӖ\u05BA;
		int turnSpeed6 = 17130;
		u089AޚӖ_u05BA8.m_TurnSpeed = (float)turnSpeed6;
		GameObject ӫޓࢡٯ8 = this.Ӫޓࢡٯ;
		long active16 = 0L;
		ӫޓࢡٯ8.SetActive(active16 != 0L);
		GameObject u0888_u0705فؾ9 = this.\u0888\u0705فؾ;
		long active17 = 1L;
		u0888_u0705فؾ9.SetActive(active17 != 0L);
		int value9 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("EnableCosmetic", value9);
		if (this.\u055B\u060Dյӣ != 0)
		{
			return;
		}
		ContinuousTurnProviderBase u089AޚӖ_u05BA9 = this.\u089AޚӖ\u05BA;
		int turnSpeed7 = 24576;
		u089AޚӖ_u05BA9.m_TurnSpeed = (float)turnSpeed7;
		GameObject u0888_u0705فؾ10 = this.\u0888\u0705فؾ;
		long active18 = 0L;
		u0888_u0705فؾ10.SetActive(active18 != 0L);
		GameObject ӫޓࢡٯ9 = this.Ӫޓࢡٯ;
		long active19 = 0L;
		ӫޓࢡٯ9.SetActive(active19 != 0L);
		int value10 = this.ݞظߪޡ;
		PlayerPrefs.SetInt("Add/Remove Glasses", value10);
	}

	// Token: 0x04000498 RID: 1176
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000498")]
	public int \u055B\u060Dյӣ;

	// Token: 0x04000499 RID: 1177
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4000499")]
	public int ݞظߪޡ;

	// Token: 0x0400049A RID: 1178
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400049A")]
	public GameObject Ӫޓࢡٯ;

	// Token: 0x0400049B RID: 1179
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400049B")]
	public GameObject \u0888\u0705فؾ;

	// Token: 0x0400049C RID: 1180
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400049C")]
	public ContinuousTurnProviderBase \u089AޚӖ\u05BA;
}
