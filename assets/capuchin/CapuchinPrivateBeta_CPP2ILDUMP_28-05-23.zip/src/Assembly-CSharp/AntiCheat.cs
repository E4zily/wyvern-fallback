﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000002 RID: 2
[Token(Token = "0x2000002")]
public class AntiCheat : MonoBehaviour
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	[Token(Token = "0x6000001")]
	[Address(RVA = "0x2A4EC48", Offset = "0x2A4EC48", VA = "0x2A4EC48")]
	private void Ԡݘעࠀ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000002 RID: 2 RVA: 0x000020A0 File Offset: 0x000002A0
	[Token(Token = "0x6000002")]
	[Address(RVA = "0x2A4EDCC", Offset = "0x2A4EDCC", VA = "0x2A4EDCC")]
	private void ٠ӄ\u087Cٸ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000003 RID: 3 RVA: 0x000020F0 File Offset: 0x000002F0
	[Token(Token = "0x6000003")]
	[Address(RVA = "0x2A4EF50", Offset = "0x2A4EF50", VA = "0x2A4EF50")]
	private void \u055Cࢯܯ\u0898()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000004 RID: 4 RVA: 0x00002140 File Offset: 0x00000340
	[Token(Token = "0x6000004")]
	[Address(RVA = "0x2A4F0D4", Offset = "0x2A4F0D4", VA = "0x2A4F0D4")]
	private void \u061B\u05EEوۈ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000005 RID: 5 RVA: 0x00002190 File Offset: 0x00000390
	[Token(Token = "0x6000005")]
	[Address(RVA = "0x2A4F258", Offset = "0x2A4F258", VA = "0x2A4F258")]
	private void ى߁ٱՏ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000006 RID: 6 RVA: 0x000021E0 File Offset: 0x000003E0
	[Token(Token = "0x6000006")]
	[Address(RVA = "0x2A4F3DC", Offset = "0x2A4F3DC", VA = "0x2A4F3DC")]
	private void \u070Aәޣے()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000007 RID: 7 RVA: 0x00002228 File Offset: 0x00000428
	[Token(Token = "0x6000007")]
	[Address(RVA = "0x2A4F560", Offset = "0x2A4F560", VA = "0x2A4F560")]
	private IEnumerator اࡕءض()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000008 RID: 8 RVA: 0x0000224C File Offset: 0x0000044C
	[Token(Token = "0x6000008")]
	[Address(RVA = "0x2A4F05C", Offset = "0x2A4F05C", VA = "0x2A4F05C")]
	private IEnumerator \u0594\u0889٥ճ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000009 RID: 9 RVA: 0x00002270 File Offset: 0x00000470
	[Token(Token = "0x6000009")]
	[Address(RVA = "0x2A4F5D8", Offset = "0x2A4F5D8", VA = "0x2A4F5D8")]
	private void \u05F8ݑ\u06ECߞ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000A RID: 10 RVA: 0x000022C0 File Offset: 0x000004C0
	[Token(Token = "0x600000A")]
	[Address(RVA = "0x2A4F75C", Offset = "0x2A4F75C", VA = "0x2A4F75C")]
	private void ں٢ࡡ\u05EC()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000B RID: 11 RVA: 0x00002310 File Offset: 0x00000510
	[Token(Token = "0x600000B")]
	[Address(RVA = "0x2A4F8E0", Offset = "0x2A4F8E0", VA = "0x2A4F8E0")]
	private void ࢶ٠\u086D\u0708()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00002360 File Offset: 0x00000560
	[Token(Token = "0x600000C")]
	[Address(RVA = "0x2A4FA64", Offset = "0x2A4FA64", VA = "0x2A4FA64")]
	private void ߑ\u0885\u05BBߕ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000D RID: 13 RVA: 0x000023B0 File Offset: 0x000005B0
	[Token(Token = "0x600000D")]
	[Address(RVA = "0x2A4FB70", Offset = "0x2A4FB70", VA = "0x2A4FB70")]
	private void չւت\u061E()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000E RID: 14 RVA: 0x00002400 File Offset: 0x00000600
	[Token(Token = "0x600000E")]
	[Address(RVA = "0x2A4FCF4", Offset = "0x2A4FCF4", VA = "0x2A4FCF4")]
	private void \u060B\u0614\u0821ע()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000F RID: 15 RVA: 0x00002450 File Offset: 0x00000650
	[Token(Token = "0x600000F")]
	[Address(RVA = "0x2A4FE78", Offset = "0x2A4FE78", VA = "0x2A4FE78")]
	private void Ҽ\u08B5ځ\u0658()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000010 RID: 16 RVA: 0x000024A0 File Offset: 0x000006A0
	[Token(Token = "0x6000010")]
	[Address(RVA = "0x2A4EED8", Offset = "0x2A4EED8", VA = "0x2A4EED8")]
	private IEnumerator \u07F5\u0881ڊݨ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000011 RID: 17 RVA: 0x000024C4 File Offset: 0x000006C4
	[Token(Token = "0x6000011")]
	[Address(RVA = "0x2A4FF84", Offset = "0x2A4FF84", VA = "0x2A4FF84")]
	private IEnumerator \u0816ߛէӽ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000012 RID: 18 RVA: 0x000024E8 File Offset: 0x000006E8
	[Token(Token = "0x6000012")]
	[Address(RVA = "0x2A4F868", Offset = "0x2A4F868", VA = "0x2A4F868")]
	private IEnumerator ߚܣԻ\u060E()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000013 RID: 19 RVA: 0x0000250C File Offset: 0x0000070C
	[Token(Token = "0x6000013")]
	[Address(RVA = "0x2A4FFFC", Offset = "0x2A4FFFC", VA = "0x2A4FFFC")]
	private IEnumerator \u0877\u058E\u082Aܓ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000014 RID: 20 RVA: 0x00002530 File Offset: 0x00000730
	[Token(Token = "0x6000014")]
	[Address(RVA = "0x2A50074", Offset = "0x2A50074", VA = "0x2A50074")]
	private IEnumerator ןԲށՋ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000015 RID: 21 RVA: 0x00002554 File Offset: 0x00000754
	[Token(Token = "0x6000015")]
	[Address(RVA = "0x2A500EC", Offset = "0x2A500EC", VA = "0x2A500EC")]
	private void ڑߒجވ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000016 RID: 22 RVA: 0x000025A4 File Offset: 0x000007A4
	[Token(Token = "0x6000016")]
	[Address(RVA = "0x2A50270", Offset = "0x2A50270", VA = "0x2A50270")]
	private void ی\u0823ڇݔ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000017 RID: 23 RVA: 0x000025F4 File Offset: 0x000007F4
	[Token(Token = "0x6000017")]
	[Address(RVA = "0x2A50378", Offset = "0x2A50378", VA = "0x2A50378")]
	private IEnumerator ӑ\u07ADԩࠂ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000018 RID: 24 RVA: 0x00002618 File Offset: 0x00000818
	[Token(Token = "0x6000018")]
	[Address(RVA = "0x2A503F0", Offset = "0x2A503F0", VA = "0x2A503F0")]
	public AntiCheat()
	{
	}

	// Token: 0x06000019 RID: 25 RVA: 0x0000262C File Offset: 0x0000082C
	[Token(Token = "0x6000019")]
	[Address(RVA = "0x2A503F8", Offset = "0x2A503F8", VA = "0x2A503F8")]
	private IEnumerator \u070Dࡂն\u0600()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600001A RID: 26 RVA: 0x00002650 File Offset: 0x00000850
	[Token(Token = "0x600001A")]
	[Address(RVA = "0x2A50470", Offset = "0x2A50470", VA = "0x2A50470")]
	private void ٴݵۃ\u05AF()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600001B RID: 27 RVA: 0x000026A0 File Offset: 0x000008A0
	[Token(Token = "0x600001B")]
	[Address(RVA = "0x2A505F4", Offset = "0x2A505F4", VA = "0x2A505F4")]
	private void ܫ\u070Fۃ\u07F2()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600001C RID: 28 RVA: 0x000026F0 File Offset: 0x000008F0
	[Token(Token = "0x600001C")]
	[Address(RVA = "0x2A50778", Offset = "0x2A50778", VA = "0x2A50778")]
	private void צ\u0874ڵ\u059A()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600001D RID: 29 RVA: 0x00002740 File Offset: 0x00000940
	[Token(Token = "0x600001D")]
	[Address(RVA = "0x2A50884", Offset = "0x2A50884", VA = "0x2A50884")]
	private void \u06D4ڟڎޜ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600001E RID: 30 RVA: 0x00002790 File Offset: 0x00000990
	[Token(Token = "0x600001E")]
	[Address(RVA = "0x2A50A08", Offset = "0x2A50A08", VA = "0x2A50A08")]
	private void \u0870\u05B3Ց\u066A()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600001F RID: 31 RVA: 0x000027E0 File Offset: 0x000009E0
	[Token(Token = "0x600001F")]
	[Address(RVA = "0x2A50B8C", Offset = "0x2A50B8C", VA = "0x2A50B8C")]
	private void \u05EDց\u081Cت()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000020 RID: 32 RVA: 0x00002830 File Offset: 0x00000A30
	[Token(Token = "0x6000020")]
	[Address(RVA = "0x2A50B14", Offset = "0x2A50B14", VA = "0x2A50B14")]
	private IEnumerator Ժԯ\u085Aע()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000021 RID: 33 RVA: 0x00002854 File Offset: 0x00000A54
	[Token(Token = "0x6000021")]
	[Address(RVA = "0x2A50D10", Offset = "0x2A50D10", VA = "0x2A50D10")]
	private void \u0590\u0882\u0883ࡦ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000022 RID: 34 RVA: 0x000028A4 File Offset: 0x00000AA4
	[Token(Token = "0x6000022")]
	[Address(RVA = "0x2A50E94", Offset = "0x2A50E94", VA = "0x2A50E94")]
	private void Update()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
		Vector3 vector2;
		float magnitude2 = vector2.magnitude;
		float ӿڛ_u086Fߓ = this.ӿڛ\u086Fߓ;
		IEnumerator routine = this.ӑ\u07ADԩࠂ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06000023 RID: 35 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000023")]
	[Address(RVA = "0x2A50F98", Offset = "0x2A50F98", VA = "0x2A50F98")]
	private void \u05B3ࢹߧ\u07AA()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000024 RID: 36 RVA: 0x00002900 File Offset: 0x00000B00
	[Token(Token = "0x6000024")]
	[Address(RVA = "0x2A501F8", Offset = "0x2A501F8", VA = "0x2A501F8")]
	private IEnumerator Ӈخҽߙ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000025 RID: 37 RVA: 0x00002924 File Offset: 0x00000B24
	[Token(Token = "0x6000025")]
	[Address(RVA = "0x2A50990", Offset = "0x2A50990", VA = "0x2A50990")]
	private IEnumerator س\u082Bࡉޟ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000026 RID: 38 RVA: 0x00002948 File Offset: 0x00000B48
	[Token(Token = "0x6000026")]
	[Address(RVA = "0x2A5111C", Offset = "0x2A5111C", VA = "0x2A5111C")]
	private void Ӧد\u060Eࡏ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000027 RID: 39 RVA: 0x00002998 File Offset: 0x00000B98
	[Token(Token = "0x6000027")]
	[Address(RVA = "0x2A51228", Offset = "0x2A51228", VA = "0x2A51228")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000028 RID: 40 RVA: 0x000029E8 File Offset: 0x00000BE8
	[Token(Token = "0x6000028")]
	[Address(RVA = "0x2A51334", Offset = "0x2A51334", VA = "0x2A51334")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000029 RID: 41 RVA: 0x00002A38 File Offset: 0x00000C38
	[Token(Token = "0x6000029")]
	[Address(RVA = "0x2A51440", Offset = "0x2A51440", VA = "0x2A51440")]
	private IEnumerator ܢދԝց()
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600002A RID: 42 RVA: 0x00002A4C File Offset: 0x00000C4C
	[Token(Token = "0x600002A")]
	[Address(RVA = "0x2A514B8", Offset = "0x2A514B8", VA = "0x2A514B8")]
	private IEnumerator ڬ\u0618\u073C\u0734()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600002B RID: 43 RVA: 0x00002A70 File Offset: 0x00000C70
	[Token(Token = "0x600002B")]
	[Address(RVA = "0x2A51530", Offset = "0x2A51530", VA = "0x2A51530")]
	private void \u0832ࢳޤ\u07B5()
	{
		Rigidbody հ_u066Aߝ_u;
		this.Հ\u066Aߝ\u0829 = հ_u066Aߝ_u;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600002C RID: 44 RVA: 0x00002AB4 File Offset: 0x00000CB4
	[Token(Token = "0x600002C")]
	[Address(RVA = "0x2A5163C", Offset = "0x2A5163C", VA = "0x2A5163C")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600002D RID: 45 RVA: 0x00002B04 File Offset: 0x00000D04
	[Token(Token = "0x600002D")]
	[Address(RVA = "0x2A517C0", Offset = "0x2A517C0", VA = "0x2A517C0")]
	private void ո\u07AA\u05BDࠕ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600002E RID: 46 RVA: 0x00002B54 File Offset: 0x00000D54
	[Token(Token = "0x600002E")]
	[Address(RVA = "0x2A4F4E8", Offset = "0x2A4F4E8", VA = "0x2A4F4E8")]
	private IEnumerator ۳٨ܦկ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600002F RID: 47 RVA: 0x00002B78 File Offset: 0x00000D78
	[Token(Token = "0x600002F")]
	[Address(RVA = "0x2A51944", Offset = "0x2A51944", VA = "0x2A51944")]
	private IEnumerator ݔ\u070Cݟڽ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000030 RID: 48 RVA: 0x00002B9C File Offset: 0x00000D9C
	[Token(Token = "0x6000030")]
	[Address(RVA = "0x2A519BC", Offset = "0x2A519BC", VA = "0x2A519BC")]
	private void \u0886Ҽ\u058Dߛ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000031 RID: 49 RVA: 0x00002BEC File Offset: 0x00000DEC
	[Token(Token = "0x6000031")]
	[Address(RVA = "0x2A518CC", Offset = "0x2A518CC", VA = "0x2A518CC")]
	private IEnumerator ڔ\u05A6ۋ\u06DB()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000032 RID: 50 RVA: 0x00002C10 File Offset: 0x00000E10
	[Token(Token = "0x6000032")]
	[Address(RVA = "0x2A4F6E4", Offset = "0x2A4F6E4", VA = "0x2A4F6E4")]
	private IEnumerator سի٩\u07FD()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000033 RID: 51 RVA: 0x00002C34 File Offset: 0x00000E34
	[Token(Token = "0x6000033")]
	[Address(RVA = "0x2A51AC8", Offset = "0x2A51AC8", VA = "0x2A51AC8")]
	private IEnumerator \u0612\u0741\u064Eػ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000034 RID: 52 RVA: 0x00002C58 File Offset: 0x00000E58
	[Token(Token = "0x6000034")]
	[Address(RVA = "0x2A51B40", Offset = "0x2A51B40", VA = "0x2A51B40")]
	private void \u0829\u05FDژտ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000035 RID: 53 RVA: 0x00002CA0 File Offset: 0x00000EA0
	[Token(Token = "0x6000035")]
	[Address(RVA = "0x2A51CC4", Offset = "0x2A51CC4", VA = "0x2A51CC4")]
	private IEnumerator ՎݕԿ٩()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06000036 RID: 54 RVA: 0x00002CB4 File Offset: 0x00000EB4
	[Token(Token = "0x6000036")]
	[Address(RVA = "0x2A51D3C", Offset = "0x2A51D3C", VA = "0x2A51D3C")]
	private void յߪؾՀ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000037 RID: 55 RVA: 0x00002CF4 File Offset: 0x00000EF4
	[Token(Token = "0x6000037")]
	[Address(RVA = "0x2A51E48", Offset = "0x2A51E48", VA = "0x2A51E48")]
	private void ԣԭՋࠏ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000038 RID: 56 RVA: 0x00002D44 File Offset: 0x00000F44
	[Token(Token = "0x6000038")]
	[Address(RVA = "0x2A51748", Offset = "0x2A51748", VA = "0x2A51748")]
	private IEnumerator \u07F0ݎ\u05BC\u06D7()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06000039 RID: 57 RVA: 0x00002D58 File Offset: 0x00000F58
	[Token(Token = "0x6000039")]
	[Address(RVA = "0x2A4F364", Offset = "0x2A4F364", VA = "0x2A4F364")]
	private IEnumerator \u074Bۼڪࡖ()
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600003A RID: 58 RVA: 0x00002D6C File Offset: 0x00000F6C
	[Token(Token = "0x600003A")]
	[Address(RVA = "0x2A51F54", Offset = "0x2A51F54", VA = "0x2A51F54")]
	private void ߊ\u066A\u05CFԉ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600003B RID: 59 RVA: 0x00002DBC File Offset: 0x00000FBC
	[Token(Token = "0x600003B")]
	[Address(RVA = "0x2A52060", Offset = "0x2A52060", VA = "0x2A52060")]
	private void ԙضփӌ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600003C RID: 60 RVA: 0x00002E0C File Offset: 0x0000100C
	[Token(Token = "0x600003C")]
	[Address(RVA = "0x2A4ED54", Offset = "0x2A4ED54", VA = "0x2A4ED54")]
	private IEnumerator ո\u081F۸շ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600003D RID: 61 RVA: 0x00002E30 File Offset: 0x00001030
	[Token(Token = "0x600003D")]
	[Address(RVA = "0x2A5216C", Offset = "0x2A5216C", VA = "0x2A5216C")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600003E RID: 62 RVA: 0x00002E80 File Offset: 0x00001080
	[Token(Token = "0x600003E")]
	[Address(RVA = "0x2A52278", Offset = "0x2A52278", VA = "0x2A52278")]
	private void \u07B6կպ߃()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600003F RID: 63 RVA: 0x00002ED0 File Offset: 0x000010D0
	[Token(Token = "0x600003F")]
	[Address(RVA = "0x2A52384", Offset = "0x2A52384", VA = "0x2A52384")]
	private void יԠ\u07EDԺ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000040 RID: 64 RVA: 0x00002F20 File Offset: 0x00001120
	[Token(Token = "0x6000040")]
	[Address(RVA = "0x2A52508", Offset = "0x2A52508", VA = "0x2A52508")]
	private IEnumerator ߕ\u07F8ՅԖ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000041 RID: 65 RVA: 0x00002F44 File Offset: 0x00001144
	[Token(Token = "0x6000041")]
	[Address(RVA = "0x2A52580", Offset = "0x2A52580", VA = "0x2A52580")]
	private void ފՖߢ\u059B()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000042 RID: 66 RVA: 0x00002F94 File Offset: 0x00001194
	[Token(Token = "0x6000042")]
	[Address(RVA = "0x2A5268C", Offset = "0x2A5268C", VA = "0x2A5268C")]
	private void \u05AC\u07F0\u07EEࡥ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000043 RID: 67 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000043")]
	[Address(RVA = "0x2A52798", Offset = "0x2A52798", VA = "0x2A52798")]
	private void ࢫ\u0876չՍ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000044 RID: 68 RVA: 0x00002FE4 File Offset: 0x000011E4
	[Token(Token = "0x6000044")]
	[Address(RVA = "0x2A528A4", Offset = "0x2A528A4", VA = "0x2A528A4")]
	private void \u07BDއڸ\u0834()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000045 RID: 69 RVA: 0x00003034 File Offset: 0x00001234
	[Token(Token = "0x6000045")]
	[Address(RVA = "0x2A529B0", Offset = "0x2A529B0", VA = "0x2A529B0")]
	private void ד\u073C\u0613چ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000046 RID: 70 RVA: 0x00003084 File Offset: 0x00001284
	[Token(Token = "0x6000046")]
	[Address(RVA = "0x2A52ABC", Offset = "0x2A52ABC", VA = "0x2A52ABC")]
	private void \u0836\u089Dی\u0735()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000047 RID: 71 RVA: 0x000030D4 File Offset: 0x000012D4
	[Token(Token = "0x6000047")]
	[Address(RVA = "0x2A50700", Offset = "0x2A50700", VA = "0x2A50700")]
	private IEnumerator لەՎݙ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000048 RID: 72 RVA: 0x000030F8 File Offset: 0x000012F8
	[Token(Token = "0x6000048")]
	[Address(RVA = "0x2A52BC8", Offset = "0x2A52BC8", VA = "0x2A52BC8")]
	private void \u0881ݗӟ\u07BD()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000049 RID: 73 RVA: 0x00003148 File Offset: 0x00001348
	[Token(Token = "0x6000049")]
	[Address(RVA = "0x2A4F1E0", Offset = "0x2A4F1E0", VA = "0x2A4F1E0")]
	private IEnumerator \u082BهԮࠓ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600004A RID: 74 RVA: 0x0000316C File Offset: 0x0000136C
	[Token(Token = "0x600004A")]
	[Address(RVA = "0x2A51C4C", Offset = "0x2A51C4C", VA = "0x2A51C4C")]
	private IEnumerator ޅԸݸ\u07FC()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600004B RID: 75 RVA: 0x00003190 File Offset: 0x00001390
	[Token(Token = "0x600004B")]
	[Address(RVA = "0x2A52CD4", Offset = "0x2A52CD4", VA = "0x2A52CD4")]
	private IEnumerator ࢩԐՏࡋ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600004C RID: 76 RVA: 0x000031B4 File Offset: 0x000013B4
	[Token(Token = "0x600004C")]
	[Address(RVA = "0x2A52490", Offset = "0x2A52490", VA = "0x2A52490")]
	private IEnumerator ӌݧۀժ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600004D RID: 77 RVA: 0x000031D8 File Offset: 0x000013D8
	[Token(Token = "0x600004D")]
	[Address(RVA = "0x2A52D4C", Offset = "0x2A52D4C", VA = "0x2A52D4C")]
	private void \u0821\u059Fӕ\u0607()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600004E RID: 78 RVA: 0x00003228 File Offset: 0x00001428
	[Token(Token = "0x600004E")]
	[Address(RVA = "0x2A4FE00", Offset = "0x2A4FE00", VA = "0x2A4FE00")]
	private IEnumerator ߙܜࠒࡘ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600004F RID: 79 RVA: 0x0000324C File Offset: 0x0000144C
	[Token(Token = "0x600004F")]
	[Address(RVA = "0x2A52E58", Offset = "0x2A52E58", VA = "0x2A52E58")]
	private void ؤ\u05C8ԛ\u083F()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000050 RID: 80 RVA: 0x00003298 File Offset: 0x00001498
	[Token(Token = "0x6000050")]
	[Address(RVA = "0x2A52F64", Offset = "0x2A52F64", VA = "0x2A52F64")]
	private void ԅ\u073Fڥ\u0839()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000051 RID: 81 RVA: 0x000032E8 File Offset: 0x000014E8
	[Token(Token = "0x6000051")]
	[Address(RVA = "0x2A50E1C", Offset = "0x2A50E1C", VA = "0x2A50E1C")]
	private IEnumerator Ԧ\u087E\u0592\u0822()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000052 RID: 82 RVA: 0x0000330C File Offset: 0x0000150C
	[Token(Token = "0x6000052")]
	[Address(RVA = "0x2A4F9EC", Offset = "0x2A4F9EC", VA = "0x2A4F9EC")]
	private IEnumerator \u0707յ١\u060F()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000053 RID: 83 RVA: 0x00003330 File Offset: 0x00001530
	[Token(Token = "0x6000053")]
	[Address(RVA = "0x2A510A4", Offset = "0x2A510A4", VA = "0x2A510A4")]
	private IEnumerator ۮޙ\u06DDߢ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000054 RID: 84 RVA: 0x00003354 File Offset: 0x00001554
	[Token(Token = "0x6000054")]
	[Address(RVA = "0x2A53070", Offset = "0x2A53070", VA = "0x2A53070")]
	private void \u0614ࢥӴ\u086C()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000055 RID: 85 RVA: 0x000033A4 File Offset: 0x000015A4
	[Token(Token = "0x6000055")]
	[Address(RVA = "0x2A5317C", Offset = "0x2A5317C", VA = "0x2A5317C")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000056 RID: 86 RVA: 0x000033F4 File Offset: 0x000015F4
	[Token(Token = "0x6000056")]
	[Address(RVA = "0x2A53288", Offset = "0x2A53288", VA = "0x2A53288")]
	private void Ӣ\u0592ߨׯ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000057 RID: 87 RVA: 0x00003444 File Offset: 0x00001644
	[Token(Token = "0x6000057")]
	[Address(RVA = "0x2A53394", Offset = "0x2A53394", VA = "0x2A53394")]
	private void څࡣڐ\u0657()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000058 RID: 88 RVA: 0x00003494 File Offset: 0x00001694
	[Token(Token = "0x6000058")]
	[Address(RVA = "0x2A534A0", Offset = "0x2A534A0", VA = "0x2A534A0")]
	private IEnumerator \u05B6ڋݩܙ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000059 RID: 89 RVA: 0x000034B8 File Offset: 0x000016B8
	[Token(Token = "0x6000059")]
	[Address(RVA = "0x2A4FC7C", Offset = "0x2A4FC7C", VA = "0x2A4FC7C")]
	private IEnumerator գӔ\u05FFԈ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600005A RID: 90 RVA: 0x000034DC File Offset: 0x000016DC
	[Token(Token = "0x600005A")]
	[Address(RVA = "0x2A53518", Offset = "0x2A53518", VA = "0x2A53518")]
	private void Ԉ۴ࡉࢬ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600005B RID: 91 RVA: 0x0000352C File Offset: 0x0000172C
	[Token(Token = "0x600005B")]
	[Address(RVA = "0x2A50C98", Offset = "0x2A50C98", VA = "0x2A50C98")]
	private IEnumerator ܐޣӱ\u07FB()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600005C RID: 92 RVA: 0x00003550 File Offset: 0x00001750
	[Token(Token = "0x600005C")]
	[Address(RVA = "0x2A53624", Offset = "0x2A53624", VA = "0x2A53624")]
	private IEnumerator ࡌ\u07B5\u0606\u060A()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 1L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600005D RID: 93 RVA: 0x00003574 File Offset: 0x00001774
	[Token(Token = "0x600005D")]
	[Address(RVA = "0x2A5369C", Offset = "0x2A5369C", VA = "0x2A5369C")]
	private void פۈيݤ()
	{
		Rigidbody component = this.\u081B\u070Aߢࡁ.GetComponent<Rigidbody>();
		this.Հ\u066Aߝ\u0829 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600005E RID: 94 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600005E")]
	[Address(RVA = "0x2A537A8", Offset = "0x2A537A8", VA = "0x2A537A8")]
	private void ڦکӁ\u06E2()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600005F RID: 95 RVA: 0x000035C4 File Offset: 0x000017C4
	[Token(Token = "0x600005F")]
	[Address(RVA = "0x2A538B4", Offset = "0x2A538B4", VA = "0x2A538B4")]
	private IEnumerator \u070A\u05C0\u065Bࡅ()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000060 RID: 96 RVA: 0x000035E8 File Offset: 0x000017E8
	[Token(Token = "0x6000060")]
	[Address(RVA = "0x2A5057C", Offset = "0x2A5057C", VA = "0x2A5057C")]
	private IEnumerator Դڛ٤\u0612()
	{
		long <>1__state;
		AntiCheat.\u0602Ԣ\u0747ࠔ u0602Ԣ_u0747ࠔ = new AntiCheat.\u0602Ԣ\u0747ࠔ((int)<>1__state);
		<>1__state = 0L;
		u0602Ԣ_u0747ࠔ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x04000001 RID: 1
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000001")]
	public GameObject \u081B\u070Aߢࡁ;

	// Token: 0x04000002 RID: 2
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000002")]
	private Rigidbody Հ\u066Aߝ\u0829;

	// Token: 0x04000003 RID: 3
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000003")]
	public float \u05B9ߎܩ\u0613;

	// Token: 0x04000004 RID: 4
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x4000004")]
	public float ӿڛ\u086Fߓ;

	// Token: 0x04000005 RID: 5
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000005")]
	public GameObject \u0656\u0898ر\u0896;
}
