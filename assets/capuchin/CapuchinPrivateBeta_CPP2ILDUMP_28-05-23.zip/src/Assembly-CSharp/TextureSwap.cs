﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200001D RID: 29
[Token(Token = "0x200001D")]
public class TextureSwap : MonoBehaviour
{
	// Token: 0x06000397 RID: 919 RVA: 0x000165B0 File Offset: 0x000147B0
	[Token(Token = "0x6000397")]
	[Address(RVA = "0x2F28A2C", Offset = "0x2F28A2C", VA = "0x2F28A2C")]
	public IEnumerator \u05B2\u05B3ݧࡀ()
	{
		TextureSwap.ݟڽնވ ݟڽնވ;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000398 RID: 920 RVA: 0x000165CC File Offset: 0x000147CC
	[Token(Token = "0x6000398")]
	[Address(RVA = "0x2F28AA4", Offset = "0x2F28AA4", VA = "0x2F28AA4")]
	public void Start()
	{
		IEnumerator routine = this.\u083Cܨ\u087E\u0593();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06000399 RID: 921 RVA: 0x000165E8 File Offset: 0x000147E8
	[Token(Token = "0x6000399")]
	[Address(RVA = "0x2F28B48", Offset = "0x2F28B48", VA = "0x2F28B48")]
	public void \u0558ݕݤݮ()
	{
		IEnumerator routine = this.ە\u086Fԡ\u0655();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600039A RID: 922 RVA: 0x00016604 File Offset: 0x00014804
	[Token(Token = "0x600039A")]
	[Address(RVA = "0x2F28BEC", Offset = "0x2F28BEC", VA = "0x2F28BEC")]
	public TextureSwap()
	{
	}

	// Token: 0x0600039B RID: 923 RVA: 0x00016618 File Offset: 0x00014818
	[Token(Token = "0x600039B")]
	[Address(RVA = "0x2F28BF4", Offset = "0x2F28BF4", VA = "0x2F28BF4")]
	public IEnumerator ࠕո\u05CAә()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 1L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600039C RID: 924 RVA: 0x0001663C File Offset: 0x0001483C
	[Token(Token = "0x600039C")]
	[Address(RVA = "0x2F28B74", Offset = "0x2F28B74", VA = "0x2F28B74")]
	public IEnumerator ە\u086Fԡ\u0655()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x0600039D RID: 925 RVA: 0x00016658 File Offset: 0x00014858
	[Token(Token = "0x600039D")]
	[Address(RVA = "0x2F28C6C", Offset = "0x2F28C6C", VA = "0x2F28C6C")]
	public void \u06EDٵ۶\u06DB()
	{
		IEnumerator routine = this.ڐޛ\u06DFۺ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600039E RID: 926 RVA: 0x00016674 File Offset: 0x00014874
	[Token(Token = "0x600039E")]
	[Address(RVA = "0x2F28D10", Offset = "0x2F28D10", VA = "0x2F28D10")]
	public void \u073BօӁ\u059A()
	{
		IEnumerator routine = this.\u085Dհߟ\u081E();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600039F RID: 927 RVA: 0x00016690 File Offset: 0x00014890
	[Token(Token = "0x600039F")]
	[Address(RVA = "0x2F28DB4", Offset = "0x2F28DB4", VA = "0x2F28DB4")]
	public IEnumerator \u07F2ڗݭ\u060F()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 1L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A0 RID: 928 RVA: 0x000166B4 File Offset: 0x000148B4
	[Token(Token = "0x60003A0")]
	[Address(RVA = "0x2F28E2C", Offset = "0x2F28E2C", VA = "0x2F28E2C")]
	public IEnumerator \u073D\u0885Ԁ\u059F()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 1L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A1 RID: 929 RVA: 0x000166D8 File Offset: 0x000148D8
	[Token(Token = "0x60003A1")]
	[Address(RVA = "0x2F28EA4", Offset = "0x2F28EA4", VA = "0x2F28EA4")]
	public IEnumerator ࢥڃԳࡅ()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A2 RID: 930 RVA: 0x000166FC File Offset: 0x000148FC
	[Token(Token = "0x60003A2")]
	[Address(RVA = "0x2F28F1C", Offset = "0x2F28F1C", VA = "0x2F28F1C")]
	public IEnumerator \u0611ڸޤ\u0816()
	{
		TextureSwap.ݟڽնވ ݟڽնވ;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A3 RID: 931 RVA: 0x00016718 File Offset: 0x00014918
	[Token(Token = "0x60003A3")]
	[Address(RVA = "0x2F28F94", Offset = "0x2F28F94", VA = "0x2F28F94")]
	public void ݸԲ\u0616Ԫ()
	{
		IEnumerator routine = this.ە\u086Fԡ\u0655();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003A4 RID: 932 RVA: 0x00016734 File Offset: 0x00014934
	[Token(Token = "0x60003A4")]
	[Address(RVA = "0x2F28FC0", Offset = "0x2F28FC0", VA = "0x2F28FC0")]
	public IEnumerator \u07AA\u07A7ࠎߤ()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A5 RID: 933 RVA: 0x00016758 File Offset: 0x00014958
	[Token(Token = "0x60003A5")]
	[Address(RVA = "0x2F29038", Offset = "0x2F29038", VA = "0x2F29038")]
	public IEnumerator \u065F\u0602\u0874Ӆ()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 1L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A6 RID: 934 RVA: 0x0001677C File Offset: 0x0001497C
	[Token(Token = "0x60003A6")]
	[Address(RVA = "0x2F290B0", Offset = "0x2F290B0", VA = "0x2F290B0")]
	public void הԥ\u05B5ݴ()
	{
		IEnumerator enumerator = this.ؤهݭս();
	}

	// Token: 0x060003A7 RID: 935 RVA: 0x00016790 File Offset: 0x00014990
	[Token(Token = "0x60003A7")]
	[Address(RVA = "0x2F29154", Offset = "0x2F29154", VA = "0x2F29154")]
	public IEnumerator ӮӅڑ\u06E8()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A8 RID: 936 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x60003A8")]
	[Address(RVA = "0x2F291CC", Offset = "0x2F291CC", VA = "0x2F291CC")]
	public IEnumerator ӷ\u05BDԞ\u0824()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A9 RID: 937 RVA: 0x000167D8 File Offset: 0x000149D8
	[Token(Token = "0x60003A9")]
	[Address(RVA = "0x2F29244", Offset = "0x2F29244", VA = "0x2F29244")]
	public void \u065F\u0839ܤ\u073C()
	{
		IEnumerator routine = this.٧ߦچࢫ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003AA RID: 938 RVA: 0x000167F4 File Offset: 0x000149F4
	[Token(Token = "0x60003AA")]
	[Address(RVA = "0x2F292E8", Offset = "0x2F292E8", VA = "0x2F292E8")]
	public IEnumerator \u087Bߙڻ\u05A7()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003AB RID: 939 RVA: 0x00016818 File Offset: 0x00014A18
	[Token(Token = "0x60003AB")]
	[Address(RVA = "0x2F29360", Offset = "0x2F29360", VA = "0x2F29360")]
	public void ڍ\u058Bݗࡣ()
	{
		IEnumerator routine = this.ࠕո\u05CAә();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003AC RID: 940 RVA: 0x00016834 File Offset: 0x00014A34
	[Token(Token = "0x60003AC")]
	[Address(RVA = "0x2F2938C", Offset = "0x2F2938C", VA = "0x2F2938C")]
	public void ࢥ\u081CՕࡋ()
	{
		IEnumerator routine = this.ە\u086Fԡ\u0655();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003AD RID: 941 RVA: 0x00016850 File Offset: 0x00014A50
	[Token(Token = "0x60003AD")]
	[Address(RVA = "0x2F293B8", Offset = "0x2F293B8", VA = "0x2F293B8")]
	public void ۮߝڪڐ()
	{
		IEnumerator routine = this.ࢥڃԳࡅ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003AE RID: 942 RVA: 0x0001686C File Offset: 0x00014A6C
	[Token(Token = "0x60003AE")]
	[Address(RVA = "0x2F293E4", Offset = "0x2F293E4", VA = "0x2F293E4")]
	public void ןٮ\u061FԺ()
	{
		IEnumerator routine = this.ࠕո\u05CAә();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003AF RID: 943 RVA: 0x00016888 File Offset: 0x00014A88
	[Token(Token = "0x60003AF")]
	[Address(RVA = "0x2F28AD0", Offset = "0x2F28AD0", VA = "0x2F28AD0")]
	public IEnumerator \u083Cܨ\u087E\u0593()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B0 RID: 944 RVA: 0x000168AC File Offset: 0x00014AAC
	[Token(Token = "0x60003B0")]
	[Address(RVA = "0x2F29410", Offset = "0x2F29410", VA = "0x2F29410")]
	public void نո\u0599\u0589()
	{
		IEnumerator routine = this.\u083Cܨ\u087E\u0593();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003B1 RID: 945 RVA: 0x000168C8 File Offset: 0x00014AC8
	[Token(Token = "0x60003B1")]
	[Address(RVA = "0x2F2943C", Offset = "0x2F2943C", VA = "0x2F2943C")]
	public void ۆڛߟ\u05A0()
	{
		IEnumerator routine = this.\u059Fڭࡐ\u0601();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003B2 RID: 946 RVA: 0x000168E4 File Offset: 0x00014AE4
	[Token(Token = "0x60003B2")]
	[Address(RVA = "0x2F294E0", Offset = "0x2F294E0", VA = "0x2F294E0")]
	public IEnumerator օ\u0650ࡨ\u0557()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B3 RID: 947 RVA: 0x00016908 File Offset: 0x00014B08
	[Token(Token = "0x60003B3")]
	[Address(RVA = "0x2F28C98", Offset = "0x2F28C98", VA = "0x2F28C98")]
	public IEnumerator ڐޛ\u06DFۺ()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B4 RID: 948 RVA: 0x0001692C File Offset: 0x00014B2C
	[Token(Token = "0x60003B4")]
	[Address(RVA = "0x2F29558", Offset = "0x2F29558", VA = "0x2F29558")]
	public IEnumerator ࡄԆ\u07F4ډ()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B5 RID: 949 RVA: 0x00016950 File Offset: 0x00014B50
	[Token(Token = "0x60003B5")]
	[Address(RVA = "0x2F295D0", Offset = "0x2F295D0", VA = "0x2F295D0")]
	public void ߒ\u065EՎࡖ()
	{
		IEnumerator routine = this.ӷ\u05BDԞ\u0824();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003B6 RID: 950 RVA: 0x0001696C File Offset: 0x00014B6C
	[Token(Token = "0x60003B6")]
	[Address(RVA = "0x2F295FC", Offset = "0x2F295FC", VA = "0x2F295FC")]
	public IEnumerator \u088Fߥ\u0875ԏ()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 1L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B7 RID: 951 RVA: 0x00016990 File Offset: 0x00014B90
	[Token(Token = "0x60003B7")]
	[Address(RVA = "0x2F29674", Offset = "0x2F29674", VA = "0x2F29674")]
	public IEnumerator \u089B\u083D۶ޞ()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 1L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B8 RID: 952 RVA: 0x000169B4 File Offset: 0x00014BB4
	[Token(Token = "0x60003B8")]
	[Address(RVA = "0x2F296EC", Offset = "0x2F296EC", VA = "0x2F296EC")]
	public void ࢧӾڈց()
	{
		IEnumerator routine = this.ࢥڃԳࡅ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003B9 RID: 953 RVA: 0x000169D0 File Offset: 0x00014BD0
	[Token(Token = "0x60003B9")]
	[Address(RVA = "0x2F29270", Offset = "0x2F29270", VA = "0x2F29270")]
	public IEnumerator ٧ߦچࢫ()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 1L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003BA RID: 954 RVA: 0x000169F4 File Offset: 0x00014BF4
	[Token(Token = "0x60003BA")]
	[Address(RVA = "0x2F29718", Offset = "0x2F29718", VA = "0x2F29718")]
	public IEnumerator ךӈ\u0839ݗ()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003BB RID: 955 RVA: 0x00016A18 File Offset: 0x00014C18
	[Token(Token = "0x60003BB")]
	[Address(RVA = "0x2F29468", Offset = "0x2F29468", VA = "0x2F29468")]
	public IEnumerator \u059Fڭࡐ\u0601()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x060003BC RID: 956 RVA: 0x00016A34 File Offset: 0x00014C34
	[Token(Token = "0x60003BC")]
	[Address(RVA = "0x2F290DC", Offset = "0x2F290DC", VA = "0x2F290DC")]
	public IEnumerator ؤهݭս()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003BD RID: 957 RVA: 0x00016A58 File Offset: 0x00014C58
	[Token(Token = "0x60003BD")]
	[Address(RVA = "0x2F29790", Offset = "0x2F29790", VA = "0x2F29790")]
	public IEnumerator ۮ\u05C4ݫ\u066B()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 1L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003BE RID: 958 RVA: 0x00016A7C File Offset: 0x00014C7C
	[Token(Token = "0x60003BE")]
	[Address(RVA = "0x2F29808", Offset = "0x2F29808", VA = "0x2F29808")]
	public void ܩחݵޔ()
	{
		IEnumerator routine = this.ڐޛ\u06DFۺ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060003BF RID: 959 RVA: 0x00016A98 File Offset: 0x00014C98
	[Token(Token = "0x60003BF")]
	[Address(RVA = "0x2F29834", Offset = "0x2F29834", VA = "0x2F29834")]
	public IEnumerator \u07F2\u070FՕږ()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 0L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003C0 RID: 960 RVA: 0x00016ABC File Offset: 0x00014CBC
	[Token(Token = "0x60003C0")]
	[Address(RVA = "0x2F298AC", Offset = "0x2F298AC", VA = "0x2F298AC")]
	public IEnumerator \u06E7\u05BFԧ߈()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 1L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003C1 RID: 961 RVA: 0x00016AE0 File Offset: 0x00014CE0
	[Token(Token = "0x60003C1")]
	[Address(RVA = "0x2F28D3C", Offset = "0x2F28D3C", VA = "0x2F28D3C")]
	public IEnumerator \u085Dհߟ\u081E()
	{
		long <>1__state;
		TextureSwap.ݟڽնވ ݟڽնވ = new TextureSwap.ݟڽնވ((int)<>1__state);
		<>1__state = 1L;
		ݟڽնވ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x04000079 RID: 121
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000079")]
	public Texture2D \u05F6\u0591\u0658\u0833;

	// Token: 0x0400007A RID: 122
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400007A")]
	public Texture2D ڕࡥҼ\u065C;

	// Token: 0x0400007B RID: 123
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400007B")]
	public Texture2D \u0825߀Ӕߐ;

	// Token: 0x0400007C RID: 124
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400007C")]
	public float ڦ\u060B\u081Dࡎ;

	// Token: 0x0400007D RID: 125
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x400007D")]
	public float לԔߠޓ;

	// Token: 0x0400007E RID: 126
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400007E")]
	public Material ࡄڑࠊ\u088B;
}
