﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200002D RID: 45
[Token(Token = "0x200002D")]
public class SonarBeep : MonoBehaviour
{
	// Token: 0x0600052A RID: 1322 RVA: 0x0001E16C File Offset: 0x0001C36C
	[Token(Token = "0x600052A")]
	[Address(RVA = "0x2F774D4", Offset = "0x2F774D4", VA = "0x2F774D4")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052B RID: 1323 RVA: 0x0001E1C4 File Offset: 0x0001C3C4
	[Token(Token = "0x600052B")]
	[Address(RVA = "0x2F77544", Offset = "0x2F77544", VA = "0x2F77544")]
	private void \u061B\u05EEوۈ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052C RID: 1324 RVA: 0x0001E21C File Offset: 0x0001C41C
	[Token(Token = "0x600052C")]
	[Address(RVA = "0x2F775B4", Offset = "0x2F775B4", VA = "0x2F775B4")]
	private void \u0886Ҽ\u058Dߛ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052D RID: 1325 RVA: 0x0001E274 File Offset: 0x0001C474
	[Token(Token = "0x600052D")]
	[Address(RVA = "0x2F77624", Offset = "0x2F77624", VA = "0x2F77624")]
	private void ڑߒجވ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052E RID: 1326 RVA: 0x0001E2CC File Offset: 0x0001C4CC
	[Token(Token = "0x600052E")]
	[Address(RVA = "0x2F77694", Offset = "0x2F77694", VA = "0x2F77694")]
	private void צ\u0874ڵ\u059A()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052F RID: 1327 RVA: 0x0001E324 File Offset: 0x0001C524
	[Token(Token = "0x600052F")]
	[Address(RVA = "0x2F77704", Offset = "0x2F77704", VA = "0x2F77704")]
	private void ފՖߢ\u059B()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000530 RID: 1328 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000530")]
	[Address(RVA = "0x2F77774", Offset = "0x2F77774", VA = "0x2F77774")]
	private void \u0732ڙԒࢺ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x0001E3D4 File Offset: 0x0001C5D4
	[Token(Token = "0x6000531")]
	[Address(RVA = "0x2F777E4", Offset = "0x2F777E4", VA = "0x2F777E4")]
	private void Update()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000532 RID: 1330 RVA: 0x0001E42C File Offset: 0x0001C62C
	[Token(Token = "0x6000532")]
	[Address(RVA = "0x2F77854", Offset = "0x2F77854", VA = "0x2F77854")]
	private void ں٢ࡡ\u05EC()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000533 RID: 1331 RVA: 0x0001E484 File Offset: 0x0001C684
	[Token(Token = "0x6000533")]
	[Address(RVA = "0x2F778C4", Offset = "0x2F778C4", VA = "0x2F778C4")]
	public SonarBeep()
	{
	}

	// Token: 0x06000534 RID: 1332 RVA: 0x0001E498 File Offset: 0x0001C698
	[Token(Token = "0x6000534")]
	[Address(RVA = "0x2F778CC", Offset = "0x2F778CC", VA = "0x2F778CC")]
	private void \u0599ږࠆ\u065F()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000535 RID: 1333 RVA: 0x0001E4F0 File Offset: 0x0001C6F0
	[Token(Token = "0x6000535")]
	[Address(RVA = "0x2F7793C", Offset = "0x2F7793C", VA = "0x2F7793C")]
	private void יԠ\u07EDԺ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000536 RID: 1334 RVA: 0x0001E548 File Offset: 0x0001C748
	[Token(Token = "0x6000536")]
	[Address(RVA = "0x2F779AC", Offset = "0x2F779AC", VA = "0x2F779AC")]
	private void Ҿࢹؼס()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000537 RID: 1335 RVA: 0x0001E5A0 File Offset: 0x0001C7A0
	[Token(Token = "0x6000537")]
	[Address(RVA = "0x2F77A1C", Offset = "0x2F77A1C", VA = "0x2F77A1C")]
	private void څࡣڐ\u0657()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000538 RID: 1336 RVA: 0x0001E5F8 File Offset: 0x0001C7F8
	[Token(Token = "0x6000538")]
	[Address(RVA = "0x2F77A8C", Offset = "0x2F77A8C", VA = "0x2F77A8C")]
	private void ࢫ\u0876չՍ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000539 RID: 1337 RVA: 0x0001E650 File Offset: 0x0001C850
	[Token(Token = "0x6000539")]
	[Address(RVA = "0x2F77AFC", Offset = "0x2F77AFC", VA = "0x2F77AFC")]
	private void \u05EDց\u081Cت()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600053A RID: 1338 RVA: 0x0001E6A8 File Offset: 0x0001C8A8
	[Token(Token = "0x600053A")]
	[Address(RVA = "0x2F77B6C", Offset = "0x2F77B6C", VA = "0x2F77B6C")]
	private void ژךՈ\u0597()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600053B RID: 1339 RVA: 0x0001E700 File Offset: 0x0001C900
	[Token(Token = "0x600053B")]
	[Address(RVA = "0x2F77BDC", Offset = "0x2F77BDC", VA = "0x2F77BDC")]
	private void Ҽ\u08B5ځ\u0658()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600053C RID: 1340 RVA: 0x0001E758 File Offset: 0x0001C958
	[Token(Token = "0x600053C")]
	[Address(RVA = "0x2F77C4C", Offset = "0x2F77C4C", VA = "0x2F77C4C")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600053D RID: 1341 RVA: 0x0001E7B0 File Offset: 0x0001C9B0
	[Token(Token = "0x600053D")]
	[Address(RVA = "0x2F77CBC", Offset = "0x2F77CBC", VA = "0x2F77CBC")]
	private void \u087BӦןݩ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600053E RID: 1342 RVA: 0x0001E808 File Offset: 0x0001CA08
	[Token(Token = "0x600053E")]
	[Address(RVA = "0x2F77D2C", Offset = "0x2F77D2C", VA = "0x2F77D2C")]
	private void ԟ\u086Cޣ\u055E()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x0001E860 File Offset: 0x0001CA60
	[Token(Token = "0x600053F")]
	[Address(RVA = "0x2F77D9C", Offset = "0x2F77D9C", VA = "0x2F77D9C")]
	private void ժ\u065Dԯࡘ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000540 RID: 1344 RVA: 0x0001E8B8 File Offset: 0x0001CAB8
	[Token(Token = "0x6000540")]
	[Address(RVA = "0x2F77E0C", Offset = "0x2F77E0C", VA = "0x2F77E0C")]
	private void \u0821\u059Fӕ\u0607()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000541 RID: 1345 RVA: 0x0001E910 File Offset: 0x0001CB10
	[Token(Token = "0x6000541")]
	[Address(RVA = "0x2F77E7C", Offset = "0x2F77E7C", VA = "0x2F77E7C")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000542 RID: 1346 RVA: 0x0001E968 File Offset: 0x0001CB68
	[Token(Token = "0x6000542")]
	[Address(RVA = "0x2F77EEC", Offset = "0x2F77EEC", VA = "0x2F77EEC")]
	private void ӻӒݝ߃()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000543 RID: 1347 RVA: 0x0001E9C0 File Offset: 0x0001CBC0
	[Token(Token = "0x6000543")]
	[Address(RVA = "0x2F77F5C", Offset = "0x2F77F5C", VA = "0x2F77F5C")]
	private void \u07FE\u0882Զ\u066D()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000544 RID: 1348 RVA: 0x0001EA18 File Offset: 0x0001CC18
	[Token(Token = "0x6000544")]
	[Address(RVA = "0x2F77FCC", Offset = "0x2F77FCC", VA = "0x2F77FCC")]
	private void ւࡂ\u0883\u0872()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000545 RID: 1349 RVA: 0x0001EA70 File Offset: 0x0001CC70
	[Token(Token = "0x6000545")]
	[Address(RVA = "0x2F7803C", Offset = "0x2F7803C", VA = "0x2F7803C")]
	private void \u0654ޛ\u07FAذ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000546 RID: 1350 RVA: 0x0001EAC8 File Offset: 0x0001CCC8
	[Token(Token = "0x6000546")]
	[Address(RVA = "0x2F780AC", Offset = "0x2F780AC", VA = "0x2F780AC")]
	private void طӏܙࢺ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000547 RID: 1351 RVA: 0x0001EB20 File Offset: 0x0001CD20
	[Token(Token = "0x6000547")]
	[Address(RVA = "0x2F7811C", Offset = "0x2F7811C", VA = "0x2F7811C")]
	private void \u0881ݗӟ\u07BD()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000548 RID: 1352 RVA: 0x0001EB78 File Offset: 0x0001CD78
	[Token(Token = "0x6000548")]
	[Address(RVA = "0x2F7818C", Offset = "0x2F7818C", VA = "0x2F7818C")]
	private void \u0590\u0882\u0883ࡦ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000549 RID: 1353 RVA: 0x0001EBD0 File Offset: 0x0001CDD0
	[Token(Token = "0x6000549")]
	[Address(RVA = "0x2F781FC", Offset = "0x2F781FC", VA = "0x2F781FC")]
	private void \u0614ࢥӴ\u086C()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600054A RID: 1354 RVA: 0x0001EC28 File Offset: 0x0001CE28
	[Token(Token = "0x600054A")]
	[Address(RVA = "0x2F7826C", Offset = "0x2F7826C", VA = "0x2F7826C")]
	private void ո\u07AA\u05BDࠕ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600054B RID: 1355 RVA: 0x0001EC80 File Offset: 0x0001CE80
	[Token(Token = "0x600054B")]
	[Address(RVA = "0x2F782DC", Offset = "0x2F782DC", VA = "0x2F782DC")]
	private void Ӣ\u0592ߨׯ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600054C RID: 1356 RVA: 0x0001ECD8 File Offset: 0x0001CED8
	[Token(Token = "0x600054C")]
	[Address(RVA = "0x2F7834C", Offset = "0x2F7834C", VA = "0x2F7834C")]
	private void ڃրӢԖ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600054D RID: 1357 RVA: 0x0001ED30 File Offset: 0x0001CF30
	[Token(Token = "0x600054D")]
	[Address(RVA = "0x2F783BC", Offset = "0x2F783BC", VA = "0x2F783BC")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600054E RID: 1358 RVA: 0x0001ED88 File Offset: 0x0001CF88
	[Token(Token = "0x600054E")]
	[Address(RVA = "0x2F7842C", Offset = "0x2F7842C", VA = "0x2F7842C")]
	private void ٴݵۃ\u05AF()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600054F RID: 1359 RVA: 0x0001EDE0 File Offset: 0x0001CFE0
	[Token(Token = "0x600054F")]
	[Address(RVA = "0x2F7849C", Offset = "0x2F7849C", VA = "0x2F7849C")]
	private void \u070Aәޣے()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000550 RID: 1360 RVA: 0x0001EE38 File Offset: 0x0001D038
	[Token(Token = "0x6000550")]
	[Address(RVA = "0x2F7850C", Offset = "0x2F7850C", VA = "0x2F7850C")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000551 RID: 1361 RVA: 0x0001EE90 File Offset: 0x0001D090
	[Token(Token = "0x6000551")]
	[Address(RVA = "0x2F7857C", Offset = "0x2F7857C", VA = "0x2F7857C")]
	private void \u05F7ԝߠӱ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000552 RID: 1362 RVA: 0x0001EEE8 File Offset: 0x0001D0E8
	[Token(Token = "0x6000552")]
	[Address(RVA = "0x2F785EC", Offset = "0x2F785EC", VA = "0x2F785EC")]
	private void \u0838ӆڛӑ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000553 RID: 1363 RVA: 0x0001EF40 File Offset: 0x0001D140
	[Token(Token = "0x6000553")]
	[Address(RVA = "0x2F7865C", Offset = "0x2F7865C", VA = "0x2F7865C")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000554 RID: 1364 RVA: 0x0001EF98 File Offset: 0x0001D198
	[Token(Token = "0x6000554")]
	[Address(RVA = "0x2F786CC", Offset = "0x2F786CC", VA = "0x2F786CC")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000555 RID: 1365 RVA: 0x0001EFF0 File Offset: 0x0001D1F0
	[Token(Token = "0x6000555")]
	[Address(RVA = "0x2F7873C", Offset = "0x2F7873C", VA = "0x2F7873C")]
	private void ԣԭՋࠏ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000556 RID: 1366 RVA: 0x0001F048 File Offset: 0x0001D248
	[Token(Token = "0x6000556")]
	[Address(RVA = "0x2F787AC", Offset = "0x2F787AC", VA = "0x2F787AC")]
	private void \u0870\u05B3Ց\u066A()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000557 RID: 1367 RVA: 0x0001F0A0 File Offset: 0x0001D2A0
	[Token(Token = "0x6000557")]
	[Address(RVA = "0x2F7881C", Offset = "0x2F7881C", VA = "0x2F7881C")]
	private void \u05F8ݑ\u06ECߞ()
	{
		SonarBeep.spinnyThing u05BAؤ_u07F3ޞ = this.\u05BAؤ\u07F3ޞ;
		float x = this.\u05BAؤ\u07F3ޞ.turnSpeed.x;
		float y = this.\u05BAؤ\u07F3ޞ.turnSpeed.y;
		float z = this.\u05BAؤ\u07F3ޞ.turnSpeed.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x040000DA RID: 218
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000DA")]
	public SonarBeep.spinnyThing \u05BAؤ\u07F3ޞ;

	// Token: 0x040000DB RID: 219
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40000DB")]
	public SonarBeep.display \u0657Ӷܢܒ;

	// Token: 0x0200002E RID: 46
	[Token(Token = "0x200002E")]
	[Serializable]
	public struct spinnyThing
	{
		// Token: 0x040000DC RID: 220
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40000DC")]
		public GameObject spinny;

		// Token: 0x040000DD RID: 221
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x40000DD")]
		public Vector3 turnSpeed;
	}

	// Token: 0x0200002F RID: 47
	[Token(Token = "0x200002F")]
	[Serializable]
	public struct display
	{
	}
}
