﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000C8 RID: 200
[Token(Token = "0x20000C8")]
public class LookAT : MonoBehaviour
{
	// Token: 0x06001E30 RID: 7728 RVA: 0x0009D450 File Offset: 0x0009B650
	[Token(Token = "0x6001E30")]
	[Address(RVA = "0x24CE76C", Offset = "0x24CE76C", VA = "0x24CE76C")]
	private void ժ\u065Dԯࡘ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E31 RID: 7729 RVA: 0x0009D4BC File Offset: 0x0009B6BC
	[Token(Token = "0x6001E31")]
	[Address(RVA = "0x24CE7D8", Offset = "0x24CE7D8", VA = "0x24CE7D8")]
	private void ԟ\u086Cޣ\u055E()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E32 RID: 7730 RVA: 0x0009D528 File Offset: 0x0009B728
	[Token(Token = "0x6001E32")]
	[Address(RVA = "0x24CE844", Offset = "0x24CE844", VA = "0x24CE844")]
	private void Ӌ\u089C\u0700ܧ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E33 RID: 7731 RVA: 0x0009D594 File Offset: 0x0009B794
	[Token(Token = "0x6001E33")]
	[Address(RVA = "0x24CE8B0", Offset = "0x24CE8B0", VA = "0x24CE8B0")]
	private void Ҿࢹؼס()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E34 RID: 7732 RVA: 0x0009D600 File Offset: 0x0009B800
	[Token(Token = "0x6001E34")]
	[Address(RVA = "0x24CE91C", Offset = "0x24CE91C", VA = "0x24CE91C")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E35 RID: 7733 RVA: 0x0009D66C File Offset: 0x0009B86C
	[Token(Token = "0x6001E35")]
	[Address(RVA = "0x24CE988", Offset = "0x24CE988", VA = "0x24CE988")]
	private void \u061B\u05EEوۈ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E36 RID: 7734 RVA: 0x0009D6D8 File Offset: 0x0009B8D8
	[Token(Token = "0x6001E36")]
	[Address(RVA = "0x24CE9F4", Offset = "0x24CE9F4", VA = "0x24CE9F4")]
	private void \u0881ݗӟ\u07BD()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E37 RID: 7735 RVA: 0x0009D744 File Offset: 0x0009B944
	[Token(Token = "0x6001E37")]
	[Address(RVA = "0x24CEA60", Offset = "0x24CEA60", VA = "0x24CEA60")]
	private void ո\u07AA\u05BDࠕ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E38 RID: 7736 RVA: 0x0009D7B0 File Offset: 0x0009B9B0
	[Token(Token = "0x6001E38")]
	[Address(RVA = "0x24CEACC", Offset = "0x24CEACC", VA = "0x24CEACC")]
	private void Update()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E39 RID: 7737 RVA: 0x0009D81C File Offset: 0x0009BA1C
	[Token(Token = "0x6001E39")]
	[Address(RVA = "0x24CEB38", Offset = "0x24CEB38", VA = "0x24CEB38")]
	private void \u0599ږࠆ\u065F()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E3A RID: 7738 RVA: 0x0009D888 File Offset: 0x0009BA88
	[Token(Token = "0x6001E3A")]
	[Address(RVA = "0x24CEBA4", Offset = "0x24CEBA4", VA = "0x24CEBA4")]
	private void ފՖߢ\u059B()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E3B RID: 7739 RVA: 0x0009D8F4 File Offset: 0x0009BAF4
	[Token(Token = "0x6001E3B")]
	[Address(RVA = "0x24CEC10", Offset = "0x24CEC10", VA = "0x24CEC10")]
	private void \u070Aәޣے()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E3C RID: 7740 RVA: 0x0009D960 File Offset: 0x0009BB60
	[Token(Token = "0x6001E3C")]
	[Address(RVA = "0x24CEC7C", Offset = "0x24CEC7C", VA = "0x24CEC7C")]
	private void څࡣڐ\u0657()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E3D RID: 7741 RVA: 0x0009D9CC File Offset: 0x0009BBCC
	[Token(Token = "0x6001E3D")]
	[Address(RVA = "0x24CECE8", Offset = "0x24CECE8", VA = "0x24CECE8")]
	private void \u0838ӆڛӑ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E3E RID: 7742 RVA: 0x0009DA38 File Offset: 0x0009BC38
	[Token(Token = "0x6001E3E")]
	[Address(RVA = "0x24CED54", Offset = "0x24CED54", VA = "0x24CED54")]
	private void ӻӒݝ߃()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E3F RID: 7743 RVA: 0x0009DAA4 File Offset: 0x0009BCA4
	[Token(Token = "0x6001E3F")]
	[Address(RVA = "0x24CEDC0", Offset = "0x24CEDC0", VA = "0x24CEDC0")]
	private void צ\u0874ڵ\u059A()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E40 RID: 7744 RVA: 0x0009DB10 File Offset: 0x0009BD10
	[Token(Token = "0x6001E40")]
	[Address(RVA = "0x24CEE2C", Offset = "0x24CEE2C", VA = "0x24CEE2C")]
	private void ٴݵۃ\u05AF()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E41 RID: 7745 RVA: 0x0009DB7C File Offset: 0x0009BD7C
	[Token(Token = "0x6001E41")]
	[Address(RVA = "0x24CEE98", Offset = "0x24CEE98", VA = "0x24CEE98")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E42 RID: 7746 RVA: 0x0009DBE8 File Offset: 0x0009BDE8
	[Token(Token = "0x6001E42")]
	[Address(RVA = "0x24CEF04", Offset = "0x24CEF04", VA = "0x24CEF04")]
	private void יԠ\u07EDԺ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E43 RID: 7747 RVA: 0x0009DC54 File Offset: 0x0009BE54
	[Token(Token = "0x6001E43")]
	[Address(RVA = "0x24CEF70", Offset = "0x24CEF70", VA = "0x24CEF70")]
	private void \u05F8ݑ\u06ECߞ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E44 RID: 7748 RVA: 0x0009DCC0 File Offset: 0x0009BEC0
	[Token(Token = "0x6001E44")]
	[Address(RVA = "0x24CEFDC", Offset = "0x24CEFDC", VA = "0x24CEFDC")]
	private void ࢫ\u0876չՍ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E45 RID: 7749 RVA: 0x0009DD2C File Offset: 0x0009BF2C
	[Token(Token = "0x6001E45")]
	[Address(RVA = "0x24CF048", Offset = "0x24CF048", VA = "0x24CF048")]
	private void \u087BӦןݩ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E46 RID: 7750 RVA: 0x0009DD98 File Offset: 0x0009BF98
	[Token(Token = "0x6001E46")]
	[Address(RVA = "0x24CF0B4", Offset = "0x24CF0B4", VA = "0x24CF0B4")]
	private void \u0590\u0882\u0883ࡦ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E47 RID: 7751 RVA: 0x0009DE04 File Offset: 0x0009C004
	[Token(Token = "0x6001E47")]
	[Address(RVA = "0x24CF120", Offset = "0x24CF120", VA = "0x24CF120")]
	private void \u0732ڙԒࢺ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E48 RID: 7752 RVA: 0x0009DE70 File Offset: 0x0009C070
	[Token(Token = "0x6001E48")]
	[Address(RVA = "0x24CF18C", Offset = "0x24CF18C", VA = "0x24CF18C")]
	private void \u0821\u059Fӕ\u0607()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E49 RID: 7753 RVA: 0x0009DEDC File Offset: 0x0009C0DC
	[Token(Token = "0x6001E49")]
	[Address(RVA = "0x24CF1F8", Offset = "0x24CF1F8", VA = "0x24CF1F8")]
	private void ւࡂ\u0883\u0872()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E4A RID: 7754 RVA: 0x0009DF48 File Offset: 0x0009C148
	[Token(Token = "0x6001E4A")]
	[Address(RVA = "0x24CF264", Offset = "0x24CF264", VA = "0x24CF264")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E4B RID: 7755 RVA: 0x0009DFB4 File Offset: 0x0009C1B4
	[Token(Token = "0x6001E4B")]
	[Address(RVA = "0x24CF2D0", Offset = "0x24CF2D0", VA = "0x24CF2D0")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E4C RID: 7756 RVA: 0x0009E020 File Offset: 0x0009C220
	[Token(Token = "0x6001E4C")]
	[Address(RVA = "0x24CF33C", Offset = "0x24CF33C", VA = "0x24CF33C")]
	private void طӏܙࢺ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E4D RID: 7757 RVA: 0x0009E08C File Offset: 0x0009C28C
	[Token(Token = "0x6001E4D")]
	[Address(RVA = "0x24CF3A8", Offset = "0x24CF3A8", VA = "0x24CF3A8")]
	private void \u0614ࢥӴ\u086C()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E4E RID: 7758 RVA: 0x0009E0F8 File Offset: 0x0009C2F8
	[Token(Token = "0x6001E4E")]
	[Address(RVA = "0x24CF414", Offset = "0x24CF414", VA = "0x24CF414")]
	private void Ӣ\u0592ߨׯ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E4F RID: 7759 RVA: 0x0009E164 File Offset: 0x0009C364
	[Token(Token = "0x6001E4F")]
	[Address(RVA = "0x24CF480", Offset = "0x24CF480", VA = "0x24CF480")]
	private void \u0870\u05B3Ց\u066A()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E50 RID: 7760 RVA: 0x0009E1D0 File Offset: 0x0009C3D0
	[Token(Token = "0x6001E50")]
	[Address(RVA = "0x24CF4EC", Offset = "0x24CF4EC", VA = "0x24CF4EC")]
	private void ڃրӢԖ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E51 RID: 7761 RVA: 0x0009E23C File Offset: 0x0009C43C
	[Token(Token = "0x6001E51")]
	[Address(RVA = "0x24CF558", Offset = "0x24CF558", VA = "0x24CF558")]
	private void ԣԭՋࠏ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E52 RID: 7762 RVA: 0x0009E2A8 File Offset: 0x0009C4A8
	[Token(Token = "0x6001E52")]
	[Address(RVA = "0x24CF5C4", Offset = "0x24CF5C4", VA = "0x24CF5C4")]
	private void \u07FE\u0882Զ\u066D()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E53 RID: 7763 RVA: 0x0009E314 File Offset: 0x0009C514
	[Token(Token = "0x6001E53")]
	[Address(RVA = "0x24CF630", Offset = "0x24CF630", VA = "0x24CF630")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E54 RID: 7764 RVA: 0x0009E380 File Offset: 0x0009C580
	[Token(Token = "0x6001E54")]
	[Address(RVA = "0x24CF69C", Offset = "0x24CF69C", VA = "0x24CF69C")]
	private void ژךՈ\u0597()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E55 RID: 7765 RVA: 0x0009E3EC File Offset: 0x0009C5EC
	[Token(Token = "0x6001E55")]
	[Address(RVA = "0x24CF708", Offset = "0x24CF708", VA = "0x24CF708")]
	private void ڑߒجވ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E56 RID: 7766 RVA: 0x0009E458 File Offset: 0x0009C658
	[Token(Token = "0x6001E56")]
	[Address(RVA = "0x24CF774", Offset = "0x24CF774", VA = "0x24CF774")]
	private void ں٢ࡡ\u05EC()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E57 RID: 7767 RVA: 0x0009E4C4 File Offset: 0x0009C6C4
	[Token(Token = "0x6001E57")]
	[Address(RVA = "0x24CF7E0", Offset = "0x24CF7E0", VA = "0x24CF7E0")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E58 RID: 7768 RVA: 0x0009E530 File Offset: 0x0009C730
	[Token(Token = "0x6001E58")]
	[Address(RVA = "0x24CF84C", Offset = "0x24CF84C", VA = "0x24CF84C")]
	private void Ҽ\u08B5ځ\u0658()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E59 RID: 7769 RVA: 0x0009E59C File Offset: 0x0009C79C
	[Token(Token = "0x6001E59")]
	[Address(RVA = "0x24CF8B8", Offset = "0x24CF8B8", VA = "0x24CF8B8")]
	private void \u05F7ԝߠӱ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E5A RID: 7770 RVA: 0x0009E608 File Offset: 0x0009C808
	[Token(Token = "0x6001E5A")]
	[Address(RVA = "0x24CF924", Offset = "0x24CF924", VA = "0x24CF924")]
	private void \u05EDց\u081Cت()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E5B RID: 7771 RVA: 0x0009E674 File Offset: 0x0009C874
	[Token(Token = "0x6001E5B")]
	[Address(RVA = "0x24CF990", Offset = "0x24CF990", VA = "0x24CF990")]
	private void չւت\u061E()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E5C RID: 7772 RVA: 0x0009E6E0 File Offset: 0x0009C8E0
	[Token(Token = "0x6001E5C")]
	[Address(RVA = "0x24CF9FC", Offset = "0x24CF9FC", VA = "0x24CF9FC")]
	private void \u0654ޛ\u07FAذ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E5D RID: 7773 RVA: 0x0009E74C File Offset: 0x0009C94C
	[Token(Token = "0x6001E5D")]
	[Address(RVA = "0x24CFA68", Offset = "0x24CFA68", VA = "0x24CFA68")]
	public LookAT()
	{
	}

	// Token: 0x06001E5E RID: 7774 RVA: 0x0009E760 File Offset: 0x0009C960
	[Token(Token = "0x6001E5E")]
	[Address(RVA = "0x24CFA70", Offset = "0x24CFA70", VA = "0x24CFA70")]
	private void \u0886Ҽ\u058Dߛ()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x06001E5F RID: 7775 RVA: 0x0009E7CC File Offset: 0x0009C9CC
	[Token(Token = "0x6001E5F")]
	[Address(RVA = "0x24CFADC", Offset = "0x24CFADC", VA = "0x24CFADC")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
		Transform transform = base.transform;
		Transform target = this.ࠔؼࡏݥ;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
		float x = this.\u0596ߝܫو.x;
		float y = this.\u0596ߝܫو.y;
		float z = this.\u0596ߝܫو.z;
		float w = this.\u0596ߝܫو.w;
	}

	// Token: 0x040003F4 RID: 1012
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003F4")]
	public Transform ࠔؼࡏݥ;

	// Token: 0x040003F5 RID: 1013
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003F5")]
	public Quaternion \u0596ߝܫو;
}
