﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000C9 RID: 201
[Token(Token = "0x20000C9")]
public class MirrorEnable : MonoBehaviour
{
	// Token: 0x06001E60 RID: 7776 RVA: 0x0009E838 File Offset: 0x0009CA38
	[Token(Token = "0x6001E60")]
	[Address(RVA = "0x23AF918", Offset = "0x23AF918", VA = "0x23AF918")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ChangeToTagged";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E61 RID: 7777 RVA: 0x0009E874 File Offset: 0x0009CA74
	[Token(Token = "0x6001E61")]
	[Address(RVA = "0x23AF9B8", Offset = "0x23AF9B8", VA = "0x23AF9B8")]
	public void \u0885ےܝ\u05BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_WobbleZ";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E62 RID: 7778 RVA: 0x0009E8B0 File Offset: 0x0009CAB0
	[Token(Token = "0x6001E62")]
	[Address(RVA = "0x23AFA58", Offset = "0x23AFA58", VA = "0x23AFA58")]
	public void \u0589\u0740\u05C6ӧ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E63 RID: 7779 RVA: 0x0009E8EC File Offset: 0x0009CAEC
	[Token(Token = "0x6001E63")]
	[Address(RVA = "0x23AFAF8", Offset = "0x23AFAF8", VA = "0x23AFAF8")]
	public void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "DISABLE";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E64 RID: 7780 RVA: 0x0009E928 File Offset: 0x0009CB28
	[Token(Token = "0x6001E64")]
	[Address(RVA = "0x23AFB98", Offset = "0x23AFB98", VA = "0x23AFB98")]
	public void ىރ\u0704ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E65 RID: 7781 RVA: 0x0009E964 File Offset: 0x0009CB64
	[Token(Token = "0x6001E65")]
	[Address(RVA = "0x23AFC38", Offset = "0x23AFC38", VA = "0x23AFC38")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Add/Remove Glasses";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E66 RID: 7782 RVA: 0x0009E9A0 File Offset: 0x0009CBA0
	[Token(Token = "0x6001E66")]
	[Address(RVA = "0x23AFCD8", Offset = "0x23AFCD8", VA = "0x23AFCD8")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E67 RID: 7783 RVA: 0x0009E9DC File Offset: 0x0009CBDC
	[Token(Token = "0x6001E67")]
	[Address(RVA = "0x23AFD78", Offset = "0x23AFD78", VA = "0x23AFD78")]
	public void \u07BF\u0705\u0824ڮ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E68 RID: 7784 RVA: 0x0009EA18 File Offset: 0x0009CC18
	[Token(Token = "0x6001E68")]
	[Address(RVA = "0x23AFE18", Offset = "0x23AFE18", VA = "0x23AFE18")]
	public void ٽ߆ࡑՄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E69 RID: 7785 RVA: 0x0009EA54 File Offset: 0x0009CC54
	[Token(Token = "0x6001E69")]
	[Address(RVA = "0x23AFEB8", Offset = "0x23AFEB8", VA = "0x23AFEB8")]
	public void ܮݫ߅ࡃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "User has been reported for: ";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E6A RID: 7786 RVA: 0x0009EA90 File Offset: 0x0009CC90
	[Token(Token = "0x6001E6A")]
	[Address(RVA = "0x23AFF58", Offset = "0x23AFF58", VA = "0x23AFF58")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Connected to Server.";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E6B RID: 7787 RVA: 0x0009EACC File Offset: 0x0009CCCC
	[Token(Token = "0x6001E6B")]
	[Address(RVA = "0x23AFFF8", Offset = "0x23AFFF8", VA = "0x23AFFF8")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E6C RID: 7788 RVA: 0x0009EB08 File Offset: 0x0009CD08
	[Token(Token = "0x6001E6C")]
	[Address(RVA = "0x23B0098", Offset = "0x23B0098", VA = "0x23B0098")]
	public void \u085Cݯژ\u05FA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not connected to room";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E6D RID: 7789 RVA: 0x0009EB44 File Offset: 0x0009CD44
	[Token(Token = "0x6001E6D")]
	[Address(RVA = "0x23B0138", Offset = "0x23B0138", VA = "0x23B0138")]
	public void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Tagged";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E6E RID: 7790 RVA: 0x0009EB80 File Offset: 0x0009CD80
	[Token(Token = "0x6001E6E")]
	[Address(RVA = "0x23B01D8", Offset = "0x23B01D8", VA = "0x23B01D8")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "sound play stopped";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E6F RID: 7791 RVA: 0x0009EBBC File Offset: 0x0009CDBC
	[Token(Token = "0x6001E6F")]
	[Address(RVA = "0x23B0278", Offset = "0x23B0278", VA = "0x23B0278")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E70 RID: 7792 RVA: 0x0009EBF8 File Offset: 0x0009CDF8
	[Token(Token = "0x6001E70")]
	[Address(RVA = "0x23B0318", Offset = "0x23B0318", VA = "0x23B0318")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "back";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E71 RID: 7793 RVA: 0x0009EC34 File Offset: 0x0009CE34
	[Token(Token = "0x6001E71")]
	[Address(RVA = "0x23B03B8", Offset = "0x23B03B8", VA = "0x23B03B8")]
	public void ߂ӹ\u05C6\u07F9(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E72 RID: 7794 RVA: 0x0009EC70 File Offset: 0x0009CE70
	[Token(Token = "0x6001E72")]
	[Address(RVA = "0x23B0458", Offset = "0x23B0458", VA = "0x23B0458")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "\n Time: ";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E73 RID: 7795 RVA: 0x0009ECAC File Offset: 0x0009CEAC
	[Token(Token = "0x6001E73")]
	[Address(RVA = "0x23B04F8", Offset = "0x23B04F8", VA = "0x23B04F8")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "manual footTimings length should be equal to the leg count";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E74 RID: 7796 RVA: 0x0009ECE8 File Offset: 0x0009CEE8
	[Token(Token = "0x6001E74")]
	[Address(RVA = "0x23B0598", Offset = "0x23B0598", VA = "0x23B0598")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E75 RID: 7797 RVA: 0x0009ED18 File Offset: 0x0009CF18
	[Token(Token = "0x6001E75")]
	[Address(RVA = "0x23B0638", Offset = "0x23B0638", VA = "0x23B0638")]
	public void \u086D\u089AԾ\u0881(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayNoise";
	}

	// Token: 0x06001E76 RID: 7798 RVA: 0x0009ED44 File Offset: 0x0009CF44
	[Token(Token = "0x6001E76")]
	[Address(RVA = "0x23B06D8", Offset = "0x23B06D8", VA = "0x23B06D8")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not connected to room";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E77 RID: 7799 RVA: 0x0009ED80 File Offset: 0x0009CF80
	[Token(Token = "0x6001E77")]
	[Address(RVA = "0x23B0778", Offset = "0x23B0778", VA = "0x23B0778")]
	public void \u083Eܙ\u07FD\u0706(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayWave";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E78 RID: 7800 RVA: 0x0009EDBC File Offset: 0x0009CFBC
	[Token(Token = "0x6001E78")]
	[Address(RVA = "0x23B0818", Offset = "0x23B0818", VA = "0x23B0818")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "typesOfTalk";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E79 RID: 7801 RVA: 0x0009EDF8 File Offset: 0x0009CFF8
	[Token(Token = "0x6001E79")]
	[Address(RVA = "0x23B08B8", Offset = "0x23B08B8", VA = "0x23B08B8")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E7A RID: 7802 RVA: 0x0009EE34 File Offset: 0x0009D034
	[Token(Token = "0x6001E7A")]
	[Address(RVA = "0x23B0958", Offset = "0x23B0958", VA = "0x23B0958")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayNoise";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E7B RID: 7803 RVA: 0x0009EE70 File Offset: 0x0009D070
	[Token(Token = "0x6001E7B")]
	[Address(RVA = "0x23B09F8", Offset = "0x23B09F8", VA = "0x23B09F8")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "M/d/yyyy";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E7C RID: 7804 RVA: 0x0009EEAC File Offset: 0x0009D0AC
	[Token(Token = "0x6001E7C")]
	[Address(RVA = "0x23B0A98", Offset = "0x23B0A98", VA = "0x23B0A98")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "M/d/yyyy";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E7D RID: 7805 RVA: 0x0009EEE8 File Offset: 0x0009D0E8
	[Token(Token = "0x6001E7D")]
	[Address(RVA = "0x23B0B38", Offset = "0x23B0B38", VA = "0x23B0B38")]
	public void \u05F8ڛߠ\u05BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "next";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E7E RID: 7806 RVA: 0x0009EF24 File Offset: 0x0009D124
	[Token(Token = "0x6001E7E")]
	[Address(RVA = "0x23B0BD8", Offset = "0x23B0BD8", VA = "0x23B0BD8")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E7F RID: 7807 RVA: 0x0009EF60 File Offset: 0x0009D160
	[Token(Token = "0x6001E7F")]
	[Address(RVA = "0x23B0C78", Offset = "0x23B0C78", VA = "0x23B0C78")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FLSPTLT";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E80 RID: 7808 RVA: 0x0009EF9C File Offset: 0x0009D19C
	[Token(Token = "0x6001E80")]
	[Address(RVA = "0x23B0D18", Offset = "0x23B0D18", VA = "0x23B0D18")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "friend";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E81 RID: 7809 RVA: 0x0009EFD8 File Offset: 0x0009D1D8
	[Token(Token = "0x6001E81")]
	[Address(RVA = "0x23B0DB8", Offset = "0x23B0DB8", VA = "0x23B0DB8")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayNoise";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E82 RID: 7810 RVA: 0x0009F014 File Offset: 0x0009D214
	[Token(Token = "0x6001E82")]
	[Address(RVA = "0x23B0E58", Offset = "0x23B0E58", VA = "0x23B0E58")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Horizontal";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E83 RID: 7811 RVA: 0x0009F050 File Offset: 0x0009D250
	[Token(Token = "0x6001E83")]
	[Address(RVA = "0x23B0EF8", Offset = "0x23B0EF8", VA = "0x23B0EF8")]
	public void \u07B3\u07BD\u05FF\u0859(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Muted";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E84 RID: 7812 RVA: 0x0009F08C File Offset: 0x0009D28C
	[Token(Token = "0x6001E84")]
	[Address(RVA = "0x23B0F98", Offset = "0x23B0F98", VA = "0x23B0F98")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E85 RID: 7813 RVA: 0x0009F0BC File Offset: 0x0009D2BC
	[Token(Token = "0x6001E85")]
	[Address(RVA = "0x23B1038", Offset = "0x23B1038", VA = "0x23B1038")]
	public void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "true";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E86 RID: 7814 RVA: 0x0009F0F8 File Offset: 0x0009D2F8
	[Token(Token = "0x6001E86")]
	[Address(RVA = "0x23B10D8", Offset = "0x23B10D8", VA = "0x23B10D8")]
	public MirrorEnable()
	{
	}

	// Token: 0x06001E87 RID: 7815 RVA: 0x0009F10C File Offset: 0x0009D30C
	[Token(Token = "0x6001E87")]
	[Address(RVA = "0x23B10E0", Offset = "0x23B10E0", VA = "0x23B10E0")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "A new Player joined a Room.";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E88 RID: 7816 RVA: 0x0009F148 File Offset: 0x0009D348
	[Token(Token = "0x6001E88")]
	[Address(RVA = "0x23B1180", Offset = "0x23B1180", VA = "0x23B1180")]
	public void Ԍߊٱݩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Found Gameobject: ";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001E89 RID: 7817 RVA: 0x0009F184 File Offset: 0x0009D384
	[Token(Token = "0x6001E89")]
	[Address(RVA = "0x23B1220", Offset = "0x23B1220", VA = "0x23B1220")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "EnableCosmetic";
		GameObject gameObject = this.ࢧכەࡎ;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x040003F6 RID: 1014
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003F6")]
	public GameObject ࢧכەࡎ;
}
