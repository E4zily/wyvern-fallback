﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000F1 RID: 241
[Token(Token = "0x20000F1")]
public class WardrobeStart : MonoBehaviour
{
	// Token: 0x0600251C RID: 9500 RVA: 0x000C500C File Offset: 0x000C320C
	[Token(Token = "0x600251C")]
	[Address(RVA = "0x2C7AC2C", Offset = "0x2C7AC2C", VA = "0x2C7AC2C")]
	private void ޟݔԈԭ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600251D RID: 9501 RVA: 0x000C5034 File Offset: 0x000C3234
	[Token(Token = "0x600251D")]
	[Address(RVA = "0x2C7ACAC", Offset = "0x2C7ACAC", VA = "0x2C7ACAC")]
	private void Ռ\u06EA\u05AFࡇ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600251E RID: 9502 RVA: 0x000C505C File Offset: 0x000C325C
	[Token(Token = "0x600251E")]
	[Address(RVA = "0x2C7AD2C", Offset = "0x2C7AD2C", VA = "0x2C7AD2C")]
	private void \u087A\u0740\u05A7\u085C()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600251F RID: 9503 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600251F")]
	[Address(RVA = "0x2C7ADAC", Offset = "0x2C7ADAC", VA = "0x2C7ADAC")]
	private void \u0731ݐ\u0654ࡡ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002520 RID: 9504 RVA: 0x000C5084 File Offset: 0x000C3284
	[Token(Token = "0x6002520")]
	[Address(RVA = "0x2C7AE2C", Offset = "0x2C7AE2C", VA = "0x2C7AE2C")]
	private void ֈ\u07EC\u0748ޟ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002521 RID: 9505 RVA: 0x000C50AC File Offset: 0x000C32AC
	[Token(Token = "0x6002521")]
	[Address(RVA = "0x2C7AEAC", Offset = "0x2C7AEAC", VA = "0x2C7AEAC")]
	private void ԡٮ\u05F9\u060D()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002522 RID: 9506 RVA: 0x000C50D4 File Offset: 0x000C32D4
	[Token(Token = "0x6002522")]
	[Address(RVA = "0x2C7AF2C", Offset = "0x2C7AF2C", VA = "0x2C7AF2C")]
	private void ח\u089B\u0655\u085B()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002523 RID: 9507 RVA: 0x000C50FC File Offset: 0x000C32FC
	[Token(Token = "0x6002523")]
	[Address(RVA = "0x2C7AFAC", Offset = "0x2C7AFAC", VA = "0x2C7AFAC")]
	private void Ԣࡏڬࢰ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002524 RID: 9508 RVA: 0x000C5124 File Offset: 0x000C3324
	[Token(Token = "0x6002524")]
	[Address(RVA = "0x2C7B02C", Offset = "0x2C7B02C", VA = "0x2C7B02C")]
	private void و\u07AD\u06E9٣()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002525 RID: 9509 RVA: 0x000C514C File Offset: 0x000C334C
	[Token(Token = "0x6002525")]
	[Address(RVA = "0x2C7B0AC", Offset = "0x2C7B0AC", VA = "0x2C7B0AC")]
	private void ٤\u0888ࡦ\u0702()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002526 RID: 9510 RVA: 0x000C5174 File Offset: 0x000C3374
	[Token(Token = "0x6002526")]
	[Address(RVA = "0x2C7B12C", Offset = "0x2C7B12C", VA = "0x2C7B12C")]
	private void ԫ\u0651ࠐڴ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002527 RID: 9511 RVA: 0x000C519C File Offset: 0x000C339C
	[Token(Token = "0x6002527")]
	[Address(RVA = "0x2C7B1AC", Offset = "0x2C7B1AC", VA = "0x2C7B1AC")]
	private void \u07B4\u0827םڵ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002528 RID: 9512 RVA: 0x000C51C4 File Offset: 0x000C33C4
	[Token(Token = "0x6002528")]
	[Address(RVA = "0x2C7B22C", Offset = "0x2C7B22C", VA = "0x2C7B22C")]
	private void \u0592ࡘӹޑ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002529 RID: 9513 RVA: 0x000C51EC File Offset: 0x000C33EC
	[Token(Token = "0x6002529")]
	[Address(RVA = "0x2C7B2AC", Offset = "0x2C7B2AC", VA = "0x2C7B2AC")]
	private void Ӎࡪ\u0859\u07FD()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600252A RID: 9514 RVA: 0x000C5214 File Offset: 0x000C3414
	[Token(Token = "0x600252A")]
	[Address(RVA = "0x2C7B32C", Offset = "0x2C7B32C", VA = "0x2C7B32C")]
	private void \u07F2\u07F7\u06FE\u081D()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600252B RID: 9515 RVA: 0x000C523C File Offset: 0x000C343C
	[Token(Token = "0x600252B")]
	[Address(RVA = "0x2C7B3AC", Offset = "0x2C7B3AC", VA = "0x2C7B3AC")]
	private void ߄\u07FBࡡ\u07AF()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600252C RID: 9516 RVA: 0x000C5264 File Offset: 0x000C3464
	[Token(Token = "0x600252C")]
	[Address(RVA = "0x2C7B42C", Offset = "0x2C7B42C", VA = "0x2C7B42C")]
	private void կӜӿڗ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600252D RID: 9517 RVA: 0x000C528C File Offset: 0x000C348C
	[Token(Token = "0x600252D")]
	[Address(RVA = "0x2C7B4AC", Offset = "0x2C7B4AC", VA = "0x2C7B4AC")]
	private void څ\u0705بޑ()
	{
		Transform transform;
		GameObject gameObject = transform.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600252E RID: 9518 RVA: 0x000C52B0 File Offset: 0x000C34B0
	[Token(Token = "0x600252E")]
	[Address(RVA = "0x2C7B52C", Offset = "0x2C7B52C", VA = "0x2C7B52C")]
	private void \u06DEӿ\u05C2Ӧ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600252F RID: 9519 RVA: 0x000C52D8 File Offset: 0x000C34D8
	[Token(Token = "0x600252F")]
	[Address(RVA = "0x2C7B5AC", Offset = "0x2C7B5AC", VA = "0x2C7B5AC")]
	private void ӄ\u07B7ܐو()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002530 RID: 9520 RVA: 0x000C5300 File Offset: 0x000C3500
	[Token(Token = "0x6002530")]
	[Address(RVA = "0x2C7B62C", Offset = "0x2C7B62C", VA = "0x2C7B62C")]
	private void ئ\u08B5ۂۮ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002531 RID: 9521 RVA: 0x000C5328 File Offset: 0x000C3528
	[Token(Token = "0x6002531")]
	[Address(RVA = "0x2C7B6AC", Offset = "0x2C7B6AC", VA = "0x2C7B6AC")]
	private void \u0608\u070F\u081D\u05B8()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002532 RID: 9522 RVA: 0x000C5350 File Offset: 0x000C3550
	[Token(Token = "0x6002532")]
	[Address(RVA = "0x2C7B72C", Offset = "0x2C7B72C", VA = "0x2C7B72C")]
	private void ݽ\u0706\u07ADࡇ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002533 RID: 9523 RVA: 0x000C5378 File Offset: 0x000C3578
	[Token(Token = "0x6002533")]
	[Address(RVA = "0x2C7B7AC", Offset = "0x2C7B7AC", VA = "0x2C7B7AC")]
	public WardrobeStart()
	{
	}

	// Token: 0x06002534 RID: 9524 RVA: 0x000C538C File Offset: 0x000C358C
	[Token(Token = "0x6002534")]
	[Address(RVA = "0x2C7B7B4", Offset = "0x2C7B7B4", VA = "0x2C7B7B4")]
	private void ӂߡՅר()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002535 RID: 9525 RVA: 0x000C53B4 File Offset: 0x000C35B4
	[Token(Token = "0x6002535")]
	[Address(RVA = "0x2C7B834", Offset = "0x2C7B834", VA = "0x2C7B834")]
	private void ۓࢬࢪ\u06E4()
	{
		Transform transform;
		GameObject gameObject = transform.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002536 RID: 9526 RVA: 0x000C53D8 File Offset: 0x000C35D8
	[Token(Token = "0x6002536")]
	[Address(RVA = "0x2C7B8B4", Offset = "0x2C7B8B4", VA = "0x2C7B8B4")]
	private void \u086C\u07F1\u05FCݹ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002537 RID: 9527 RVA: 0x000C5400 File Offset: 0x000C3600
	[Token(Token = "0x6002537")]
	[Address(RVA = "0x2C7B934", Offset = "0x2C7B934", VA = "0x2C7B934")]
	private void Awake()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002538 RID: 9528 RVA: 0x000C5428 File Offset: 0x000C3628
	[Token(Token = "0x6002538")]
	[Address(RVA = "0x2C7B9B4", Offset = "0x2C7B9B4", VA = "0x2C7B9B4")]
	private void \u065Cզ\u07BF\u07F5()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002539 RID: 9529 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002539")]
	[Address(RVA = "0x2C7BA34", Offset = "0x2C7BA34", VA = "0x2C7BA34")]
	private void ֈ\u088DڰԜ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600253A RID: 9530 RVA: 0x000C5450 File Offset: 0x000C3650
	[Token(Token = "0x600253A")]
	[Address(RVA = "0x2C7BAB4", Offset = "0x2C7BAB4", VA = "0x2C7BAB4")]
	private void \u064FՒײә()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600253B RID: 9531 RVA: 0x000C5478 File Offset: 0x000C3678
	[Token(Token = "0x600253B")]
	[Address(RVA = "0x2C7BB34", Offset = "0x2C7BB34", VA = "0x2C7BB34")]
	private void \u088CԳ\u05A8ݐ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600253C RID: 9532 RVA: 0x000C54A0 File Offset: 0x000C36A0
	[Token(Token = "0x600253C")]
	[Address(RVA = "0x2C7BBB4", Offset = "0x2C7BBB4", VA = "0x2C7BBB4")]
	private void ډӁ\u05B9\u05BD()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600253D RID: 9533 RVA: 0x000C54C8 File Offset: 0x000C36C8
	[Token(Token = "0x600253D")]
	[Address(RVA = "0x2C7BC34", Offset = "0x2C7BC34", VA = "0x2C7BC34")]
	private void \u05A7ݒ\u083B\u081C()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600253E RID: 9534 RVA: 0x000C54F0 File Offset: 0x000C36F0
	[Token(Token = "0x600253E")]
	[Address(RVA = "0x2C7BCB4", Offset = "0x2C7BCB4", VA = "0x2C7BCB4")]
	private void ࡒ\u070Eڻߪ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600253F RID: 9535 RVA: 0x000C5518 File Offset: 0x000C3718
	[Token(Token = "0x600253F")]
	[Address(RVA = "0x2C7BD34", Offset = "0x2C7BD34", VA = "0x2C7BD34")]
	private void \u0601ՇԮӳ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002540 RID: 9536 RVA: 0x000C5540 File Offset: 0x000C3740
	[Token(Token = "0x6002540")]
	[Address(RVA = "0x2C7BDB4", Offset = "0x2C7BDB4", VA = "0x2C7BDB4")]
	private void ߥ\u05FDرԓ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002541 RID: 9537 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002541")]
	[Address(RVA = "0x2C7BE34", Offset = "0x2C7BE34", VA = "0x2C7BE34")]
	private void ߍࠑչר()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002542 RID: 9538 RVA: 0x000C5568 File Offset: 0x000C3768
	[Token(Token = "0x6002542")]
	[Address(RVA = "0x2C7BEB4", Offset = "0x2C7BEB4", VA = "0x2C7BEB4")]
	private void ࡅ۳بڏ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002543 RID: 9539 RVA: 0x000C5590 File Offset: 0x000C3790
	[Token(Token = "0x6002543")]
	[Address(RVA = "0x2C7BF34", Offset = "0x2C7BF34", VA = "0x2C7BF34")]
	private void \u0833إ\u06DEת()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002544 RID: 9540 RVA: 0x000C55B8 File Offset: 0x000C37B8
	[Token(Token = "0x6002544")]
	[Address(RVA = "0x2C7BFB4", Offset = "0x2C7BFB4", VA = "0x2C7BFB4")]
	private void ٣\u06D6ږ\u0835()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002545 RID: 9541 RVA: 0x000C55E0 File Offset: 0x000C37E0
	[Token(Token = "0x6002545")]
	[Address(RVA = "0x2C7C034", Offset = "0x2C7C034", VA = "0x2C7C034")]
	private void ڋ۸\u088Cى()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002546 RID: 9542 RVA: 0x000C5608 File Offset: 0x000C3808
	[Token(Token = "0x6002546")]
	[Address(RVA = "0x2C7C0B4", Offset = "0x2C7C0B4", VA = "0x2C7C0B4")]
	private void \u0835\u0598ԑ\u0614()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002547 RID: 9543 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002547")]
	[Address(RVA = "0x2C7C134", Offset = "0x2C7C134", VA = "0x2C7C134")]
	private void \u07B0Ր\u05F5ࡦ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002548 RID: 9544 RVA: 0x000C5630 File Offset: 0x000C3830
	[Token(Token = "0x6002548")]
	[Address(RVA = "0x2C7C1B4", Offset = "0x2C7C1B4", VA = "0x2C7C1B4")]
	private void ԉ\u07F7דڱ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002549 RID: 9545 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002549")]
	[Address(RVA = "0x2C7C234", Offset = "0x2C7C234", VA = "0x2C7C234")]
	private void ى\u081Cޛ\u07EC()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600254A RID: 9546 RVA: 0x000C5658 File Offset: 0x000C3858
	[Token(Token = "0x600254A")]
	[Address(RVA = "0x2C7C2B4", Offset = "0x2C7C2B4", VA = "0x2C7C2B4")]
	private void ڬ\u0833غר()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600254B RID: 9547 RVA: 0x000C5680 File Offset: 0x000C3880
	[Token(Token = "0x600254B")]
	[Address(RVA = "0x2C7C334", Offset = "0x2C7C334", VA = "0x2C7C334")]
	private void ࡔޣ\u0735ޝ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600254C RID: 9548 RVA: 0x000C56A8 File Offset: 0x000C38A8
	[Token(Token = "0x600254C")]
	[Address(RVA = "0x2C7C3B4", Offset = "0x2C7C3B4", VA = "0x2C7C3B4")]
	private void ࡕկߒٹ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600254D RID: 9549 RVA: 0x000C56D0 File Offset: 0x000C38D0
	[Token(Token = "0x600254D")]
	[Address(RVA = "0x2C7C434", Offset = "0x2C7C434", VA = "0x2C7C434")]
	private void ࡣࡨݥׯ()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x0600254E RID: 9550 RVA: 0x000C56F8 File Offset: 0x000C38F8
	[Token(Token = "0x600254E")]
	[Address(RVA = "0x2C7C4B4", Offset = "0x2C7C4B4", VA = "0x2C7C4B4")]
	private void \u0859ۈ٣\u07BD()
	{
		Transform transform;
		GameObject gameObject = transform.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600254F RID: 9551 RVA: 0x000C571C File Offset: 0x000C391C
	[Token(Token = "0x600254F")]
	[Address(RVA = "0x2C7C534", Offset = "0x2C7C534", VA = "0x2C7C534")]
	private void \u0653ӟӜ\u0823()
	{
		Transform transform;
		GameObject gameObject = transform.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002550 RID: 9552 RVA: 0x000C5740 File Offset: 0x000C3940
	[Token(Token = "0x6002550")]
	[Address(RVA = "0x2C7C5B4", Offset = "0x2C7C5B4", VA = "0x2C7C5B4")]
	private void \u05F4\u0894ھ\u0820()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x06002551 RID: 9553 RVA: 0x000C5768 File Offset: 0x000C3968
	[Token(Token = "0x6002551")]
	[Address(RVA = "0x2C7C634", Offset = "0x2C7C634", VA = "0x2C7C634")]
	private void ߘ\u05AEԮ\u06DD()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.\u05BCԙࢻډ = gameObject;
	}

	// Token: 0x040004A0 RID: 1184
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004A0")]
	private GameObject \u05BCԙࢻډ;
}
