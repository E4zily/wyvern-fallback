﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x02000039 RID: 57
[Token(Token = "0x2000039")]
public class NetworkSimpleManager : MonoBehaviourPunCallbacks
{
	// Token: 0x060007B2 RID: 1970 RVA: 0x0002A7A0 File Offset: 0x000289A0
	[Token(Token = "0x60007B2")]
	[Address(RVA = "0x2D49480", Offset = "0x2D49480", VA = "0x2D49480", Slot = "41")]
	public override void OnJoinedRoom()
	{
		base.OnJoinedRoom();
		Vector3 position = base.transform.position;
		Quaternion rotation = base.transform.rotation;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		PhotonView u07AE_u05AF_u064FԖ;
		this.\u07AE\u05AF\u064FԖ = u07AE_u05AF_u064FԖ;
		Player localPlayer = PhotonNetwork.LocalPlayer;
		string str = UnityEngine.Random.Range(1, 1000).ToString();
		string nickName = "Player" + str;
		localPlayer.NickName = nickName;
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x0002A814 File Offset: 0x00028A14
	[Token(Token = "0x60007B3")]
	[Address(RVA = "0x2D4964C", Offset = "0x2D4964C", VA = "0x2D4964C")]
	public NetworkSimpleManager()
	{
	}

	// Token: 0x060007B4 RID: 1972 RVA: 0x0002A828 File Offset: 0x00028A28
	[Token(Token = "0x60007B4")]
	[Address(RVA = "0x2D49654", Offset = "0x2D49654", VA = "0x2D49654", Slot = "31")]
	public override void OnLeftRoom()
	{
		base.OnLeftRoom();
		GameObject u05EEݠ_u05FFը = this.\u05EEݠ\u05FFը;
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		PhotonNetwork.Destroy(u05EEݠ_u05FFը);
	}

	// Token: 0x04000108 RID: 264
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000108")]
	private GameObject \u05EEݠ\u05FFը;

	// Token: 0x04000109 RID: 265
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000109")]
	private PhotonView \u07AE\u05AF\u064FԖ;
}
