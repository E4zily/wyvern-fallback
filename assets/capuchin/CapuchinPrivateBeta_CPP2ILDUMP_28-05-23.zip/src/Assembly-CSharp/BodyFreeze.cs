﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200009D RID: 157
[Token(Token = "0x200009D")]
public class BodyFreeze : MonoBehaviour
{
	// Token: 0x06001766 RID: 5990 RVA: 0x00082760 File Offset: 0x00080960
	[Token(Token = "0x6001766")]
	[Address(RVA = "0x271CB48", Offset = "0x271CB48", VA = "0x271CB48")]
	private void ں٢ࡡ\u05EC()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001767 RID: 5991 RVA: 0x000827AC File Offset: 0x000809AC
	[Token(Token = "0x6001767")]
	[Address(RVA = "0x271CB80", Offset = "0x271CB80", VA = "0x271CB80")]
	private void ԣԭՋࠏ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001768 RID: 5992 RVA: 0x000827F8 File Offset: 0x000809F8
	[Token(Token = "0x6001768")]
	[Address(RVA = "0x271CBB8", Offset = "0x271CBB8", VA = "0x271CBB8")]
	private void \u0732ڙԒࢺ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001769 RID: 5993 RVA: 0x00082844 File Offset: 0x00080A44
	[Token(Token = "0x6001769")]
	[Address(RVA = "0x271CBF0", Offset = "0x271CBF0", VA = "0x271CBF0")]
	private void \u0614ࢥӴ\u086C()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600176A RID: 5994 RVA: 0x00082890 File Offset: 0x00080A90
	[Token(Token = "0x600176A")]
	[Address(RVA = "0x271CC28", Offset = "0x271CC28", VA = "0x271CC28")]
	private void \u087BӦןݩ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600176B RID: 5995 RVA: 0x000828DC File Offset: 0x00080ADC
	[Token(Token = "0x600176B")]
	[Address(RVA = "0x271CC60", Offset = "0x271CC60", VA = "0x271CC60")]
	private void \u05EDց\u081Cت()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600176C RID: 5996 RVA: 0x00082928 File Offset: 0x00080B28
	[Token(Token = "0x600176C")]
	[Address(RVA = "0x271CC98", Offset = "0x271CC98", VA = "0x271CC98")]
	private void ւࡂ\u0883\u0872()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600176D RID: 5997 RVA: 0x00082974 File Offset: 0x00080B74
	[Token(Token = "0x600176D")]
	[Address(RVA = "0x271CCD0", Offset = "0x271CCD0", VA = "0x271CCD0")]
	private void \u061B\u05EEوۈ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600176E RID: 5998 RVA: 0x000829C0 File Offset: 0x00080BC0
	[Token(Token = "0x600176E")]
	[Address(RVA = "0x271CD08", Offset = "0x271CD08", VA = "0x271CD08")]
	private void څࡣڐ\u0657()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600176F RID: 5999 RVA: 0x00082A0C File Offset: 0x00080C0C
	[Token(Token = "0x600176F")]
	[Address(RVA = "0x271CD40", Offset = "0x271CD40", VA = "0x271CD40")]
	private void Ҽ\u08B5ځ\u0658()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001770 RID: 6000 RVA: 0x00082A58 File Offset: 0x00080C58
	[Token(Token = "0x6001770")]
	[Address(RVA = "0x271CD78", Offset = "0x271CD78", VA = "0x271CD78")]
	public BodyFreeze()
	{
	}

	// Token: 0x06001771 RID: 6001 RVA: 0x00082A6C File Offset: 0x00080C6C
	[Token(Token = "0x6001771")]
	[Address(RVA = "0x271CD80", Offset = "0x271CD80", VA = "0x271CD80")]
	private void ԟ\u086Cޣ\u055E()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001772 RID: 6002 RVA: 0x00082AB8 File Offset: 0x00080CB8
	[Token(Token = "0x6001772")]
	[Address(RVA = "0x271CDB8", Offset = "0x271CDB8", VA = "0x271CDB8")]
	private void ӻӒݝ߃()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001773 RID: 6003 RVA: 0x00082B04 File Offset: 0x00080D04
	[Token(Token = "0x6001773")]
	[Address(RVA = "0x271CDF0", Offset = "0x271CDF0", VA = "0x271CDF0")]
	private void ٴݵۃ\u05AF()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001774 RID: 6004 RVA: 0x00082B50 File Offset: 0x00080D50
	[Token(Token = "0x6001774")]
	[Address(RVA = "0x271CE28", Offset = "0x271CE28", VA = "0x271CE28")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001775 RID: 6005 RVA: 0x00082B6C File Offset: 0x00080D6C
	[Token(Token = "0x6001775")]
	[Address(RVA = "0x271CE60", Offset = "0x271CE60", VA = "0x271CE60")]
	private void ڑߒجވ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001776 RID: 6006 RVA: 0x00082BB8 File Offset: 0x00080DB8
	[Token(Token = "0x6001776")]
	[Address(RVA = "0x271CE98", Offset = "0x271CE98", VA = "0x271CE98")]
	private void \u0881ݗӟ\u07BD()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001777 RID: 6007 RVA: 0x00082C04 File Offset: 0x00080E04
	[Token(Token = "0x6001777")]
	[Address(RVA = "0x271CED0", Offset = "0x271CED0", VA = "0x271CED0")]
	private void Ҿࢹؼס()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001778 RID: 6008 RVA: 0x00082C50 File Offset: 0x00080E50
	[Token(Token = "0x6001778")]
	[Address(RVA = "0x271CF08", Offset = "0x271CF08", VA = "0x271CF08")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001779 RID: 6009 RVA: 0x00082C9C File Offset: 0x00080E9C
	[Token(Token = "0x6001779")]
	[Address(RVA = "0x271CF40", Offset = "0x271CF40", VA = "0x271CF40")]
	private void \u070Aәޣے()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600177A RID: 6010 RVA: 0x00082CE8 File Offset: 0x00080EE8
	[Token(Token = "0x600177A")]
	[Address(RVA = "0x271CF78", Offset = "0x271CF78", VA = "0x271CF78")]
	private void Ӣ\u0592ߨׯ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600177B RID: 6011 RVA: 0x00082D34 File Offset: 0x00080F34
	[Token(Token = "0x600177B")]
	[Address(RVA = "0x271CFB0", Offset = "0x271CFB0", VA = "0x271CFB0")]
	private void \u05F7ԝߠӱ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600177C RID: 6012 RVA: 0x00082D80 File Offset: 0x00080F80
	[Token(Token = "0x600177C")]
	[Address(RVA = "0x271CFE8", Offset = "0x271CFE8", VA = "0x271CFE8")]
	private void ڃրӢԖ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600177D RID: 6013 RVA: 0x00082DCC File Offset: 0x00080FCC
	[Token(Token = "0x600177D")]
	[Address(RVA = "0x271D020", Offset = "0x271D020", VA = "0x271D020")]
	private void \u0654ޛ\u07FAذ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600177E RID: 6014 RVA: 0x00082E18 File Offset: 0x00081018
	[Token(Token = "0x600177E")]
	[Address(RVA = "0x271D058", Offset = "0x271D058", VA = "0x271D058")]
	private void ժ\u065Dԯࡘ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x0600177F RID: 6015 RVA: 0x00082E64 File Offset: 0x00081064
	[Token(Token = "0x600177F")]
	[Address(RVA = "0x271D090", Offset = "0x271D090", VA = "0x271D090")]
	private void ފՖߢ\u059B()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001780 RID: 6016 RVA: 0x00082EB0 File Offset: 0x000810B0
	[Token(Token = "0x6001780")]
	[Address(RVA = "0x271D0C8", Offset = "0x271D0C8", VA = "0x271D0C8")]
	private void ࢫ\u0876չՍ()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001781 RID: 6017 RVA: 0x00082EFC File Offset: 0x000810FC
	[Token(Token = "0x6001781")]
	[Address(RVA = "0x271D100", Offset = "0x271D100", VA = "0x271D100")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x06001782 RID: 6018 RVA: 0x00082F48 File Offset: 0x00081148
	[Token(Token = "0x6001782")]
	[Address(RVA = "0x271D138", Offset = "0x271D138", VA = "0x271D138")]
	private void Update()
	{
		Transform transform = base.transform;
		float x = this.ծ\u0894ݝࢲ.x;
		float y = this.ծ\u0894ݝࢲ.y;
		float z = this.ծ\u0894ݝࢲ.z;
		float w = this.ծ\u0894ݝࢲ.w;
	}

	// Token: 0x040002E7 RID: 743
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002E7")]
	public Quaternion ծ\u0894ݝࢲ;
}
