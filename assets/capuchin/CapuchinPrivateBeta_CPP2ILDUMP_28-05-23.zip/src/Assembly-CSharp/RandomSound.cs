﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200003D RID: 61
[Token(Token = "0x200003D")]
public class RandomSound : MonoBehaviour
{
	// Token: 0x0600086D RID: 2157 RVA: 0x0002E9B4 File Offset: 0x0002CBB4
	[Token(Token = "0x600086D")]
	[Address(RVA = "0x2F9EA28", Offset = "0x2F9EA28", VA = "0x2F9EA28")]
	private void Ԯ\u0883\u0591\u066C()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator routine = this.ټد\u0594ث();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x0600086E RID: 2158 RVA: 0x0002EA0C File Offset: 0x0002CC0C
	[Token(Token = "0x600086E")]
	[Address(RVA = "0x2F9EB44", Offset = "0x2F9EB44", VA = "0x2F9EB44")]
	private void ۆڛߟ\u05A0()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator enumerator = this.\u064E\u0883\u066Dے();
			return;
		}
	}

	// Token: 0x0600086F RID: 2159 RVA: 0x0002EA5C File Offset: 0x0002CC5C
	[Token(Token = "0x600086F")]
	[Address(RVA = "0x2F9EC5C", Offset = "0x2F9EC5C", VA = "0x2F9EC5C")]
	private void Start()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator routine = this.\u058C\u05F3\u081F\u0876();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000870 RID: 2160 RVA: 0x0002EAB4 File Offset: 0x0002CCB4
	[Token(Token = "0x6000870")]
	[Address(RVA = "0x2F9ED78", Offset = "0x2F9ED78", VA = "0x2F9ED78")]
	public RandomSound()
	{
	}

	// Token: 0x06000871 RID: 2161 RVA: 0x0002EAC8 File Offset: 0x0002CCC8
	[Token(Token = "0x6000871")]
	[Address(RVA = "0x2F9ED00", Offset = "0x2F9ED00", VA = "0x2F9ED00")]
	public IEnumerator \u058C\u05F3\u081F\u0876()
	{
		long <>1__state;
		RandomSound.ӭ߄\u07B7Ӳ ӭ߄_u07B7Ӳ = new RandomSound.ӭ߄\u07B7Ӳ((int)<>1__state);
		<>1__state = 0L;
		ӭ߄_u07B7Ӳ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000872 RID: 2162 RVA: 0x0002EAEC File Offset: 0x0002CCEC
	[Token(Token = "0x6000872")]
	[Address(RVA = "0x2F9ED80", Offset = "0x2F9ED80", VA = "0x2F9ED80")]
	private void ࢧӾڈց()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator routine = this.\u064E\u0883\u066Dے();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000873 RID: 2163 RVA: 0x0002EB44 File Offset: 0x0002CD44
	[Token(Token = "0x6000873")]
	[Address(RVA = "0x2F9EE20", Offset = "0x2F9EE20", VA = "0x2F9EE20")]
	private void \u05ABݿࡋ\u06E9()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator routine = this.\u0897\u082Eڳ\u06E7();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000874 RID: 2164 RVA: 0x0002EB9C File Offset: 0x0002CD9C
	[Token(Token = "0x6000874")]
	[Address(RVA = "0x2F9EF3C", Offset = "0x2F9EF3C", VA = "0x2F9EF3C")]
	private void \u082E\u06EBݼڏ()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator routine = this.ټد\u0594ث();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000875 RID: 2165 RVA: 0x0002EBF4 File Offset: 0x0002CDF4
	[Token(Token = "0x6000875")]
	[Address(RVA = "0x2F9EFE0", Offset = "0x2F9EFE0", VA = "0x2F9EFE0")]
	private void ࠏޤݳ\u06DD()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator routine = this.\u0592۵\u0557\u059B();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000876 RID: 2166 RVA: 0x0002EC4C File Offset: 0x0002CE4C
	[Token(Token = "0x6000876")]
	[Address(RVA = "0x2F9F0FC", Offset = "0x2F9F0FC", VA = "0x2F9F0FC")]
	private void ۮߝڪڐ()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		object target = pcmreaderCallback2.m_target;
		if (pcmreaderCallback2 != null)
		{
			IEnumerator routine = this.ټد\u0594ث();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000877 RID: 2167 RVA: 0x0002ECA4 File Offset: 0x0002CEA4
	[Token(Token = "0x6000877")]
	[Address(RVA = "0x2F9F1A0", Offset = "0x2F9F1A0", VA = "0x2F9F1A0")]
	private void ࢰחڵࡓ()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator routine = this.ٲԐޕӢ();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000878 RID: 2168 RVA: 0x0002ECFC File Offset: 0x0002CEFC
	[Token(Token = "0x6000878")]
	[Address(RVA = "0x2F9F2BC", Offset = "0x2F9F2BC", VA = "0x2F9F2BC")]
	private void ߒ\u065EՎࡖ()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator routine = this.\u065C\u0827\u05A8ۋ();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000879 RID: 2169 RVA: 0x0002ED54 File Offset: 0x0002CF54
	[Token(Token = "0x6000879")]
	[Address(RVA = "0x2F9EEC4", Offset = "0x2F9EEC4", VA = "0x2F9EEC4")]
	public IEnumerator \u0897\u082Eڳ\u06E7()
	{
		long <>1__state;
		RandomSound.ӭ߄\u07B7Ӳ ӭ߄_u07B7Ӳ = new RandomSound.ӭ߄\u07B7Ӳ((int)<>1__state);
		<>1__state = 1L;
		ӭ߄_u07B7Ӳ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600087A RID: 2170 RVA: 0x0002ED78 File Offset: 0x0002CF78
	[Token(Token = "0x600087A")]
	[Address(RVA = "0x2F9F3D4", Offset = "0x2F9F3D4", VA = "0x2F9F3D4")]
	public IEnumerator Ӻ\u05A1ښݦ()
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600087B RID: 2171 RVA: 0x0002ED8C File Offset: 0x0002CF8C
	[Token(Token = "0x600087B")]
	[Address(RVA = "0x2F9F244", Offset = "0x2F9F244", VA = "0x2F9F244")]
	public IEnumerator ٲԐޕӢ()
	{
		long <>1__state;
		RandomSound.ӭ߄\u07B7Ӳ ӭ߄_u07B7Ӳ = new RandomSound.ӭ߄\u07B7Ӳ((int)<>1__state);
		<>1__state = 1L;
		ӭ߄_u07B7Ӳ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600087C RID: 2172 RVA: 0x0002EDB0 File Offset: 0x0002CFB0
	[Token(Token = "0x600087C")]
	[Address(RVA = "0x2F9F44C", Offset = "0x2F9F44C", VA = "0x2F9F44C")]
	public IEnumerator ߍԎ\u0593ࢲ()
	{
		long <>1__state;
		RandomSound.ӭ߄\u07B7Ӳ ӭ߄_u07B7Ӳ = new RandomSound.ӭ߄\u07B7Ӳ((int)<>1__state);
		<>1__state = 1L;
		ӭ߄_u07B7Ӳ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600087D RID: 2173 RVA: 0x0002EDD4 File Offset: 0x0002CFD4
	[Token(Token = "0x600087D")]
	[Address(RVA = "0x2F9F35C", Offset = "0x2F9F35C", VA = "0x2F9F35C")]
	public IEnumerator \u065C\u0827\u05A8ۋ()
	{
		long <>1__state;
		RandomSound.ӭ߄\u07B7Ӳ ӭ߄_u07B7Ӳ = new RandomSound.ӭ߄\u07B7Ӳ((int)<>1__state);
		<>1__state = 0L;
		ӭ߄_u07B7Ӳ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600087E RID: 2174 RVA: 0x0002EDF8 File Offset: 0x0002CFF8
	[Token(Token = "0x600087E")]
	[Address(RVA = "0x2F9F4C4", Offset = "0x2F9F4C4", VA = "0x2F9F4C4")]
	private void הԥ\u05B5ݴ()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator routine = this.Ӻ\u05A1ښݦ();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x0600087F RID: 2175 RVA: 0x0002EE50 File Offset: 0x0002D050
	[Token(Token = "0x600087F")]
	[Address(RVA = "0x2F9EACC", Offset = "0x2F9EACC", VA = "0x2F9EACC")]
	public IEnumerator ټد\u0594ث()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06000880 RID: 2176 RVA: 0x0002EE64 File Offset: 0x0002D064
	[Token(Token = "0x6000880")]
	[Address(RVA = "0x2F9EBE4", Offset = "0x2F9EBE4", VA = "0x2F9EBE4")]
	public IEnumerator \u064E\u0883\u066Dے()
	{
		long <>1__state;
		RandomSound.ӭ߄\u07B7Ӳ ӭ߄_u07B7Ӳ = new RandomSound.ӭ߄\u07B7Ӳ((int)<>1__state);
		<>1__state = 1L;
		ӭ߄_u07B7Ӳ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000881 RID: 2177 RVA: 0x0002EE88 File Offset: 0x0002D088
	[Token(Token = "0x6000881")]
	[Address(RVA = "0x2F9F564", Offset = "0x2F9F564", VA = "0x2F9F564")]
	private void \u0558ݕݤݮ()
	{
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		if (this.\u0594٤\u0559\u0819)
		{
			IEnumerator routine = this.\u0592۵\u0557\u059B();
			Coroutine coroutine = base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000882 RID: 2178 RVA: 0x0002EEE0 File Offset: 0x0002D0E0
	[Token(Token = "0x6000882")]
	[Address(RVA = "0x2F9F604", Offset = "0x2F9F604", VA = "0x2F9F604")]
	public IEnumerator Օ\u0600\u0891\u0839()
	{
		long <>1__state;
		RandomSound.ӭ߄\u07B7Ӳ ӭ߄_u07B7Ӳ = new RandomSound.ӭ߄\u07B7Ӳ((int)<>1__state);
		<>1__state = 1L;
		ӭ߄_u07B7Ӳ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000883 RID: 2179 RVA: 0x0002EF04 File Offset: 0x0002D104
	[Token(Token = "0x6000883")]
	[Address(RVA = "0x2F9F084", Offset = "0x2F9F084", VA = "0x2F9F084")]
	public IEnumerator \u0592۵\u0557\u059B()
	{
		long <>1__state;
		RandomSound.ӭ߄\u07B7Ӳ ӭ߄_u07B7Ӳ = new RandomSound.ӭ߄\u07B7Ӳ((int)<>1__state);
		<>1__state = 0L;
		ӭ߄_u07B7Ӳ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x04000115 RID: 277
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000115")]
	public bool \u0594٤\u0559\u0819;

	// Token: 0x04000116 RID: 278
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x4000116")]
	public bool \u0658\u059Bټ\u073B;

	// Token: 0x04000117 RID: 279
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000117")]
	public AudioSource \u0617\u087Fտߎ;

	// Token: 0x04000118 RID: 280
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000118")]
	public AudioClip[] \u0891\u088D\u0656ݿ;
}
