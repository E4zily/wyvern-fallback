﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000009 RID: 9
[Token(Token = "0x2000009")]
public class BirdFling : MonoBehaviour
{
	// Token: 0x060000F2 RID: 242 RVA: 0x0000C470 File Offset: 0x0000A670
	[Token(Token = "0x60000F2")]
	[Address(RVA = "0x2715D6C", Offset = "0x2715D6C", VA = "0x2715D6C")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Target");
		Transform transform;
		Vector3 up = transform.up;
		long maxExclusive = 0L;
		int num = UnityEngine.Random.Range(0, (int)maxExclusive);
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("Purchase For ");
		Transform transform2;
		Vector3 up2 = transform2.up;
		long maxExclusive2 = 0L;
		int num2 = UnityEngine.Random.Range(0, (int)maxExclusive2);
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x0000C4D8 File Offset: 0x0000A6D8
	[Token(Token = "0x60000F3")]
	[Address(RVA = "0x2715F28", Offset = "0x2715F28", VA = "0x2715F28")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Left a room");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x0000C598 File Offset: 0x0000A798
	[Token(Token = "0x60000F4")]
	[Address(RVA = "0x27160E4", Offset = "0x27160E4", VA = "0x27160E4")]
	public BirdFling()
	{
	}

	// Token: 0x060000F5 RID: 245 RVA: 0x0000C5AC File Offset: 0x0000A7AC
	[Token(Token = "0x60000F5")]
	[Address(RVA = "0x27160EC", Offset = "0x27160EC", VA = "0x27160EC")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("HOLY MOLY THE STICK IS ON FIRE!!!!!!");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		long maxExclusive = 0L;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		int num = UnityEngine.Random.Range(1, (int)maxExclusive);
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("Joined Public Room Successfully");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x0000C678 File Offset: 0x0000A878
	[Token(Token = "0x60000F6")]
	[Address(RVA = "0x27162A8", Offset = "0x27162A8", VA = "0x27162A8")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("true");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("HandR");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060000F7 RID: 247 RVA: 0x0000C740 File Offset: 0x0000A940
	[Token(Token = "0x60000F7")]
	[Address(RVA = "0x2716464", Offset = "0x2716464", VA = "0x2716464")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("Grip");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("M/d/yyyy");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060000F8 RID: 248 RVA: 0x0000C7FC File Offset: 0x0000A9FC
	[Token(Token = "0x60000F8")]
	[Address(RVA = "0x2716620", Offset = "0x2716620", VA = "0x2716620")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x0000C8C4 File Offset: 0x0000AAC4
	[Token(Token = "0x60000F9")]
	[Address(RVA = "0x27167DC", Offset = "0x27167DC", VA = "0x27167DC")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("next");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("Add/Remove Glasses");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060000FA RID: 250 RVA: 0x0000C98C File Offset: 0x0000AB8C
	[Token(Token = "0x60000FA")]
	[Address(RVA = "0x2716998", Offset = "0x2716998", VA = "0x2716998")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060000FB RID: 251 RVA: 0x0000CA54 File Offset: 0x0000AC54
	[Token(Token = "0x60000FB")]
	[Address(RVA = "0x2716B54", Offset = "0x2716B54", VA = "0x2716B54")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Removing ");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("Players: ");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060000FC RID: 252 RVA: 0x0000CB1C File Offset: 0x0000AD1C
	[Token(Token = "0x60000FC")]
	[Address(RVA = "0x2716D10", Offset = "0x2716D10", VA = "0x2716D10")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("HeadAttachPoint");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = ڬت_u07EB_u05CD.gameObject.CompareTag("PURCHASED!");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060000FD RID: 253 RVA: 0x0000CBE4 File Offset: 0x0000ADE4
	[Token(Token = "0x60000FD")]
	[Address(RVA = "0x2716ECC", Offset = "0x2716ECC", VA = "0x2716ECC")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("StartSong");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x060000FE RID: 254 RVA: 0x0000CCAC File Offset: 0x0000AEAC
	[Token(Token = "0x60000FE")]
	[Address(RVA = "0x2717088", Offset = "0x2717088", VA = "0x2717088")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("M/d/yyyy");
		Transform transform;
		Vector3 up = transform.up;
		long maxExclusive = 0L;
		int num = UnityEngine.Random.Range(0, (int)maxExclusive);
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		Transform transform2;
		Vector3 up2 = transform2.up;
		long maxExclusive2 = 0L;
		int num2 = UnityEngine.Random.Range(0, (int)maxExclusive2);
	}

	// Token: 0x060000FF RID: 255 RVA: 0x0000CD08 File Offset: 0x0000AF08
	[Token(Token = "0x60000FF")]
	[Address(RVA = "0x2717244", Offset = "0x2717244", VA = "0x2717244")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("EnableCosmetic");
		Transform transform;
		Vector3 up = transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("A new Player joined a Room.");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06000100 RID: 256 RVA: 0x0000CDC4 File Offset: 0x0000AFC4
	[Token(Token = "0x6000100")]
	[Address(RVA = "0x2717400", Offset = "0x2717400", VA = "0x2717400")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Left a room");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("On");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06000101 RID: 257 RVA: 0x0000CE8C File Offset: 0x0000B08C
	[Token(Token = "0x6000101")]
	[Address(RVA = "0x27175BC", Offset = "0x27175BC", VA = "0x27175BC")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("typesOfTalk");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06000102 RID: 258 RVA: 0x0000CF4C File Offset: 0x0000B14C
	[Token(Token = "0x6000102")]
	[Address(RVA = "0x2717778", Offset = "0x2717778", VA = "0x2717778")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("Agreed");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06000103 RID: 259 RVA: 0x0000D014 File Offset: 0x0000B214
	[Token(Token = "0x6000103")]
	[Address(RVA = "0x2717934", Offset = "0x2717934", VA = "0x2717934")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("HandL");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("Network Player");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06000104 RID: 260 RVA: 0x0000D0DC File Offset: 0x0000B2DC
	[Token(Token = "0x6000104")]
	[Address(RVA = "0x2717AF0", Offset = "0x2717AF0", VA = "0x2717AF0")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Holdable");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("HeadAttachPoint");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06000105 RID: 261 RVA: 0x0000D1A4 File Offset: 0x0000B3A4
	[Token(Token = "0x6000105")]
	[Address(RVA = "0x2717CAC", Offset = "0x2717CAC", VA = "0x2717CAC")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06000106 RID: 262 RVA: 0x0000D26C File Offset: 0x0000B46C
	[Token(Token = "0x6000106")]
	[Address(RVA = "0x2717E68", Offset = "0x2717E68", VA = "0x2717E68")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("true");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Transform transform;
		Vector3 up2 = transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06000107 RID: 263 RVA: 0x0000D330 File Offset: 0x0000B530
	[Token(Token = "0x6000107")]
	[Address(RVA = "0x2718024", Offset = "0x2718024", VA = "0x2718024")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("DisableCosmetic");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("INSIGNIFICANT CURRENCY");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x06000108 RID: 264 RVA: 0x0000D3F8 File Offset: 0x0000B5F8
	[Token(Token = "0x6000108")]
	[Address(RVA = "0x27181E0", Offset = "0x27181E0", VA = "0x27181E0")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("username");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag(" and the correct version is ");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		AudioClip.PCMReaderCallback pcmreaderCallback3 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
	}

	// Token: 0x06000109 RID: 265 RVA: 0x0000D4B8 File Offset: 0x0000B6B8
	[Token(Token = "0x6000109")]
	[Address(RVA = "0x271839C", Offset = "0x271839C", VA = "0x271839C")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Combine textures & build combined mesh all at once");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("make more points bobo");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x0600010A RID: 266 RVA: 0x0000D580 File Offset: 0x0000B780
	[Token(Token = "0x600010A")]
	[Address(RVA = "0x2718558", Offset = "0x2718558", VA = "0x2718558")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 up = base.transform.up;
		float u059C_u083Aת_u05FA = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃ = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback = ࡂ_u07F1_u0821߃.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD = this.ڬت\u07EB\u05CD;
		object target = ࡂ_u07F1_u0821߃.m_PCMReaderCallback.m_target;
		bool flag2 = \u07FEל\u05AC\u0877.gameObject.CompareTag("True");
		Rigidbody u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
		Vector3 up2 = base.transform.up;
		float u059C_u083Aת_u05FA2 = this.\u059C\u083Aת\u05FA;
		AudioClip[] ࡂ_u07F1_u0821߃2 = this.ࡂ\u07F1\u0821߃;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback;
		AudioSource ڬت_u07EB_u05CD2 = this.ڬت\u07EB\u05CD;
		object target2 = ࡂ_u07F1_u0821߃2.m_PCMReaderCallback.m_target;
	}

	// Token: 0x04000028 RID: 40
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000028")]
	public Rigidbody \u081B\u070Aߢࡁ;

	// Token: 0x04000029 RID: 41
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000029")]
	public Transform \u055CԘࠊݞ;

	// Token: 0x0400002A RID: 42
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400002A")]
	public float \u059C\u083Aת\u05FA;

	// Token: 0x0400002B RID: 43
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400002B")]
	public AudioSource ڬت\u07EB\u05CD;

	// Token: 0x0400002C RID: 44
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400002C")]
	public AudioClip[] ࡂ\u07F1\u0821߃;
}
