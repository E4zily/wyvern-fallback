﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000028 RID: 40
[Token(Token = "0x2000028")]
public class DoorLerp : MonoBehaviour
{
	// Token: 0x0600046F RID: 1135 RVA: 0x00019A30 File Offset: 0x00017C30
	[Token(Token = "0x600046F")]
	[Address(RVA = "0x28A95B8", Offset = "0x28A95B8", VA = "0x28A95B8")]
	public void \u06FDےՄ\u06E3(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x06000470 RID: 1136 RVA: 0x00019A40 File Offset: 0x00017C40
	[Token(Token = "0x6000470")]
	[Address(RVA = "0x28A95C4", Offset = "0x28A95C4", VA = "0x28A95C4")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled = 1L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled != 0L);
	}

	// Token: 0x06000471 RID: 1137 RVA: 0x00019BB8 File Offset: 0x00017DB8
	[Token(Token = "0x6000471")]
	[Address(RVA = "0x28A98C0", Offset = "0x28A98C0", VA = "0x28A98C0")]
	private void ފՖߢ\u059B()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 1L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 0L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000472 RID: 1138 RVA: 0x00019CFC File Offset: 0x00017EFC
	[Token(Token = "0x6000472")]
	[Address(RVA = "0x28A9B54", Offset = "0x28A9B54", VA = "0x28A9B54")]
	private void ٴݵۃ\u05AF()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled = 0L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled != 0L);
	}

	// Token: 0x06000473 RID: 1139 RVA: 0x00019E50 File Offset: 0x00018050
	[Token(Token = "0x6000473")]
	[Address(RVA = "0x28A9E30", Offset = "0x28A9E30", VA = "0x28A9E30")]
	private void \u0614ࢥӴ\u086C()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled = 0L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled != 0L);
	}

	// Token: 0x06000474 RID: 1140 RVA: 0x00019F88 File Offset: 0x00018188
	[Token(Token = "0x6000474")]
	[Address(RVA = "0x28AA0BC", Offset = "0x28AA0BC", VA = "0x28AA0BC")]
	private void \u070Aәޣے()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 0L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			long u0597ࡤܯճ = 1L;
			this.\u0597ࡤܯճ = (u0597ࡤܯճ != 0L);
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 1L;
		long u0597ࡤܯճ2 = 1L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
		this.\u0597ࡤܯճ = (u0597ࡤܯճ2 != 0L);
	}

	// Token: 0x06000475 RID: 1141 RVA: 0x0001A0D8 File Offset: 0x000182D8
	[Token(Token = "0x6000475")]
	[Address(RVA = "0x28AA358", Offset = "0x28AA358", VA = "0x28AA358")]
	private void \u0881ݗӟ\u07BD()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 1L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			return;
		}
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position5 = өݒ_u05A9փ3.position;
		Vector3 position6 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 0L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000476 RID: 1142 RVA: 0x0001A24C File Offset: 0x0001844C
	[Token(Token = "0x6000476")]
	[Address(RVA = "0x28AA65C", Offset = "0x28AA65C", VA = "0x28AA65C")]
	public void ծۀےݏ(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x06000477 RID: 1143 RVA: 0x0001A25C File Offset: 0x0001845C
	[Token(Token = "0x6000477")]
	[Address(RVA = "0x28AA668", Offset = "0x28AA668", VA = "0x28AA668")]
	private void \u0838ӆڛӑ()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled = 1L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled != 0L);
	}

	// Token: 0x06000478 RID: 1144 RVA: 0x0001A3D4 File Offset: 0x000185D4
	[Token(Token = "0x6000478")]
	[Address(RVA = "0x28AA968", Offset = "0x28AA968", VA = "0x28AA968")]
	public void ةեԮ\u05B7(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x06000479 RID: 1145 RVA: 0x0001A3E4 File Offset: 0x000185E4
	[Token(Token = "0x6000479")]
	[Address(RVA = "0x28AA974", Offset = "0x28AA974", VA = "0x28AA974")]
	private void \u05F7ԝߠӱ()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float ڸ_u05AD_u073F_u = this.ڸ\u05AD\u073F\u0709;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 1L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			if (!this.\u0597ࡤܯճ)
			{
				this.ڇ\u0703ࢬԪ.Play();
				long u0597ࡤܯճ = 1L;
				this.\u0597ࡤܯճ = (u0597ࡤܯճ != 0L);
				return;
			}
		}
		else
		{
			Vector3 position5 = this.ࠃ\u064Cփߟ.position;
			Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
			Vector3 position6 = өݒ_u05A9փ3.position;
			Vector3 position7 = this.ࠃ\u064Cփߟ.position;
			float deltaTime2 = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num2 = Mathf.Clamp01(deltaTime2);
			AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
			long enabled2 = 1L;
			u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
		}
	}

	// Token: 0x0600047A RID: 1146 RVA: 0x0001A540 File Offset: 0x00018740
	[Token(Token = "0x600047A")]
	[Address(RVA = "0x28AAC20", Offset = "0x28AAC20", VA = "0x28AAC20")]
	private void ڑߒجވ()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 1L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			return;
		}
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position5 = өݒ_u05A9փ3.position;
		Vector3 position6 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 0L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600047B RID: 1147 RVA: 0x0001A678 File Offset: 0x00018878
	[Token(Token = "0x600047B")]
	[Address(RVA = "0x28AAEB4", Offset = "0x28AAEB4", VA = "0x28AAEB4")]
	private void ւࡂ\u0883\u0872()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 0L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			long u0597ࡤܯճ = 1L;
			this.\u0597ࡤܯճ = (u0597ࡤܯճ != 0L);
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 1L;
		long u0597ࡤܯճ2 = 1L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
		this.\u0597ࡤܯճ = (u0597ࡤܯճ2 != 0L);
	}

	// Token: 0x0600047C RID: 1148 RVA: 0x0001A808 File Offset: 0x00018A08
	[Token(Token = "0x600047C")]
	[Address(RVA = "0x28AB1C4", Offset = "0x28AB1C4", VA = "0x28AB1C4")]
	private void \u0886Ҽ\u058Dߛ()
	{
		do
		{
			Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
			bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
			Vector3 position = өݒ_u05A9փ.position;
			if (!ٽ_u0886ࡠԢ)
			{
				goto IL_49;
			}
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
		}
		while (this.\u07F4۲Ս\u0825 != null);
		return;
		IL_49:
		Vector3 position4 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position5 = өݒ_u05A9փ3.position;
		Vector3 position6 = this.ࠃ\u064Cփߟ.position;
		float deltaTime = Time.deltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
		float num = Mathf.Clamp01(deltaTime);
		AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
		long enabled = 1L;
		u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
	}

	// Token: 0x0600047D RID: 1149 RVA: 0x0001A914 File Offset: 0x00018B14
	[Token(Token = "0x600047D")]
	[Address(RVA = "0x28AB3D4", Offset = "0x28AB3D4", VA = "0x28AB3D4")]
	private void \u087BӦןݩ()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 1L;
			long u0597ࡤܯճ = 1L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			this.\u0597ࡤܯճ = (u0597ࡤܯճ != 0L);
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 1L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600047E RID: 1150 RVA: 0x0001AA70 File Offset: 0x00018C70
	[Token(Token = "0x600047E")]
	[Address(RVA = "0x28AB6B8", Offset = "0x28AB6B8", VA = "0x28AB6B8")]
	public void ӟڧ\u0619ݽ(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x0600047F RID: 1151 RVA: 0x0001AA80 File Offset: 0x00018C80
	[Token(Token = "0x600047F")]
	[Address(RVA = "0x28AB6C4", Offset = "0x28AB6C4", VA = "0x28AB6C4")]
	private void ژךՈ\u0597()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 1L;
			long u0597ࡤܯճ = 1L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			this.\u0597ࡤܯճ = (u0597ࡤܯճ != 0L);
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 0L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000480 RID: 1152 RVA: 0x0001AC0C File Offset: 0x00018E0C
	[Token(Token = "0x6000480")]
	[Address(RVA = "0x28AB9D0", Offset = "0x28AB9D0", VA = "0x28AB9D0")]
	private void \u0654ޛ\u07FAذ()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 0L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 0L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000481 RID: 1153 RVA: 0x0001AD6C File Offset: 0x00018F6C
	[Token(Token = "0x6000481")]
	[Address(RVA = "0x28ABCB4", Offset = "0x28ABCB4", VA = "0x28ABCB4")]
	public void ࠉ\u060Dن߅(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x06000482 RID: 1154 RVA: 0x0001AD7C File Offset: 0x00018F7C
	[Token(Token = "0x6000482")]
	[Address(RVA = "0x28ABCC0", Offset = "0x28ABCC0", VA = "0x28ABCC0")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 0L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 0L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000483 RID: 1155 RVA: 0x0001AEFC File Offset: 0x000190FC
	[Token(Token = "0x6000483")]
	[Address(RVA = "0x28ABFC4", Offset = "0x28ABFC4", VA = "0x28ABFC4")]
	public void \u083B\u0659ࡐࢥ(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x06000484 RID: 1156 RVA: 0x0001AF0C File Offset: 0x0001910C
	[Token(Token = "0x6000484")]
	[Address(RVA = "0x28ABFD0", Offset = "0x28ABFD0", VA = "0x28ABFD0")]
	private void Update()
	{
		do
		{
			Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
			bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
			Vector3 position = өݒ_u05A9փ.position;
			if (!ٽ_u0886ࡠԢ)
			{
				goto IL_49;
			}
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
		}
		while (this.\u07F4۲Ս\u0825 != null);
		return;
		IL_49:
		Vector3 position4 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position5 = өݒ_u05A9փ3.position;
		Vector3 position6 = this.ࠃ\u064Cփߟ.position;
		float deltaTime = Time.deltaTime;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
		float num = Mathf.Clamp01(deltaTime);
		AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
		long enabled = 1L;
		u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
	}

	// Token: 0x06000485 RID: 1157 RVA: 0x0001B018 File Offset: 0x00019218
	[Token(Token = "0x6000485")]
	[Address(RVA = "0x28AC1E0", Offset = "0x28AC1E0", VA = "0x28AC1E0")]
	private void ࢫ\u0876չՍ()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled = 0L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled != 0L);
	}

	// Token: 0x06000486 RID: 1158 RVA: 0x0001B184 File Offset: 0x00019384
	[Token(Token = "0x6000486")]
	[Address(RVA = "0x28AC4E0", Offset = "0x28AC4E0", VA = "0x28AC4E0")]
	public void \u059Dࢶސࢳ(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x06000487 RID: 1159 RVA: 0x0001B194 File Offset: 0x00019394
	[Token(Token = "0x6000487")]
	[Address(RVA = "0x28AC4EC", Offset = "0x28AC4EC", VA = "0x28AC4EC")]
	private void ڃրӢԖ()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 0L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			long u0597ࡤܯճ = 1L;
			this.\u0597ࡤܯճ = (u0597ࡤܯճ != 0L);
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 1L;
		long u0597ࡤܯճ2 = 1L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
		this.\u0597ࡤܯճ = (u0597ࡤܯճ2 != 0L);
	}

	// Token: 0x06000488 RID: 1160 RVA: 0x0001B320 File Offset: 0x00019520
	[Token(Token = "0x6000488")]
	[Address(RVA = "0x28AC7FC", Offset = "0x28AC7FC", VA = "0x28AC7FC")]
	public void ךս\u083Cٸ(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x06000489 RID: 1161 RVA: 0x0001B330 File Offset: 0x00019530
	[Token(Token = "0x6000489")]
	[Address(RVA = "0x28AC808", Offset = "0x28AC808", VA = "0x28AC808")]
	public void ءӰ\u083Fج(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x0600048A RID: 1162 RVA: 0x0001B340 File Offset: 0x00019540
	[Token(Token = "0x600048A")]
	[Address(RVA = "0x28AC814", Offset = "0x28AC814", VA = "0x28AC814")]
	public void \u086Dޕ\u0655Ԕ(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x0600048B RID: 1163 RVA: 0x0001B350 File Offset: 0x00019550
	[Token(Token = "0x600048B")]
	[Address(RVA = "0x28AC820", Offset = "0x28AC820", VA = "0x28AC820")]
	public void \u07A6ވܫզ(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x0600048C RID: 1164 RVA: 0x0001B360 File Offset: 0x00019560
	[Token(Token = "0x600048C")]
	[Address(RVA = "0x28AC82C", Offset = "0x28AC82C", VA = "0x28AC82C")]
	private void Ҿࢹؼס()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 0L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 1L;
		long u0597ࡤܯճ = 1L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
		this.\u0597ࡤܯճ = (u0597ࡤܯճ != 0L);
	}

	// Token: 0x0600048D RID: 1165 RVA: 0x0001B4F0 File Offset: 0x000196F0
	[Token(Token = "0x600048D")]
	[Address(RVA = "0x28ACB3C", Offset = "0x28ACB3C", VA = "0x28ACB3C")]
	public void ۸ԃӴԴ(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x0600048E RID: 1166 RVA: 0x0001B500 File Offset: 0x00019700
	[Token(Token = "0x600048E")]
	[Address(RVA = "0x28ACB48", Offset = "0x28ACB48", VA = "0x28ACB48")]
	public DoorLerp()
	{
	}

	// Token: 0x0600048F RID: 1167 RVA: 0x0001B514 File Offset: 0x00019714
	[Token(Token = "0x600048F")]
	[Address(RVA = "0x28ACB50", Offset = "0x28ACB50", VA = "0x28ACB50")]
	private void ժ\u065Dԯࡘ()
	{
		Transform өݒ_u05A9փ = this.Өݒ\u05A9փ;
		bool ٽ_u0886ࡠԢ = this.ٽ\u0886ࡠԢ;
		Vector3 position = өݒ_u05A9փ.position;
		if (ٽ_u0886ࡠԢ)
		{
			Vector3 position2 = this.\u07F4۲Ս\u0825.position;
			Transform өݒ_u05A9փ2 = this.Өݒ\u05A9փ;
			float ࡊ_u07FBڅԈ = this.ࡊ\u07FBڅԈ;
			Vector3 position3 = өݒ_u05A9փ2.position;
			Vector3 position4 = this.\u07F4۲Ս\u0825.position;
			float deltaTime = Time.deltaTime;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			float num = Mathf.Clamp01(deltaTime);
			AudioSource u06D6ࡕ_u066A_u065C = this.\u06D6ࡕ\u066A\u065C;
			long enabled = 0L;
			u06D6ࡕ_u066A_u065C.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.ࠃ\u064Cփߟ.position;
		Transform өݒ_u05A9փ3 = this.Өݒ\u05A9փ;
		float ࡊ_u07FBڅԈ2 = this.ࡊ\u07FBڅԈ;
		Vector3 position6 = өݒ_u05A9փ3.position;
		Vector3 position7 = this.ࠃ\u064Cփߟ.position;
		float deltaTime2 = Time.deltaTime;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		float num2 = Mathf.Clamp01(deltaTime2);
		AudioSource u06D6ࡕ_u066A_u065C2 = this.\u06D6ࡕ\u066A\u065C;
		long enabled2 = 1L;
		long u0597ࡤܯճ = 1L;
		u06D6ࡕ_u066A_u065C2.enabled = (enabled2 != 0L);
		this.\u0597ࡤܯճ = (u0597ࡤܯճ != 0L);
	}

	// Token: 0x06000490 RID: 1168 RVA: 0x0001B6A0 File Offset: 0x000198A0
	[Token(Token = "0x6000490")]
	[Address(RVA = "0x28ACE5C", Offset = "0x28ACE5C", VA = "0x28ACE5C")]
	public void ۴\u05F6Ԏݧ(bool ࢪࡃب\u0824)
	{
	}

	// Token: 0x040000BD RID: 189
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000BD")]
	public Transform Өݒ\u05A9փ;

	// Token: 0x040000BE RID: 190
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000BE")]
	public bool ٽ\u0886ࡠԢ;

	// Token: 0x040000BF RID: 191
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40000BF")]
	public Transform ࠃ\u064Cփߟ;

	// Token: 0x040000C0 RID: 192
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40000C0")]
	public Transform \u07F4۲Ս\u0825;

	// Token: 0x040000C1 RID: 193
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40000C1")]
	public float \u05B9ߎܩ\u0613;

	// Token: 0x040000C2 RID: 194
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x40000C2")]
	public float ڸ\u05AD\u073F\u0709;

	// Token: 0x040000C3 RID: 195
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40000C3")]
	public float ࡊ\u07FBڅԈ;

	// Token: 0x040000C4 RID: 196
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40000C4")]
	public AudioSource \u06D6ࡕ\u066A\u065C;

	// Token: 0x040000C5 RID: 197
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40000C5")]
	public AudioSource ڇ\u0703ࢬԪ;

	// Token: 0x040000C6 RID: 198
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40000C6")]
	private bool \u0597ࡤܯճ;
}
