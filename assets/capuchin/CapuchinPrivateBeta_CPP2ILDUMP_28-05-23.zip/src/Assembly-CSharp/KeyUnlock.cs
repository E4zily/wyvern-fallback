﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200006E RID: 110
[Token(Token = "0x200006E")]
public class KeyUnlock : MonoBehaviour
{
	// Token: 0x06001035 RID: 4149 RVA: 0x000601A4 File Offset: 0x0005E3A4
	[Token(Token = "0x6001035")]
	[Address(RVA = "0x2AD1654", Offset = "0x2AD1654", VA = "0x2AD1654")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Key");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001036 RID: 4150 RVA: 0x00060214 File Offset: 0x0005E414
	[Token(Token = "0x6001036")]
	[Address(RVA = "0x2AD1750", Offset = "0x2AD1750", VA = "0x2AD1750")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("A new Player joined a Room.");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001037 RID: 4151 RVA: 0x00060288 File Offset: 0x0005E488
	[Token(Token = "0x6001037")]
	[Address(RVA = "0x2AD184C", Offset = "0x2AD184C", VA = "0x2AD184C")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Stopped Colliding");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 1L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001038 RID: 4152 RVA: 0x000602F0 File Offset: 0x0005E4F0
	[Token(Token = "0x6001038")]
	[Address(RVA = "0x2AD1948", Offset = "0x2AD1948", VA = "0x2AD1948")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("sound play stopped");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001039 RID: 4153 RVA: 0x00060368 File Offset: 0x0005E568
	[Token(Token = "0x6001039")]
	[Address(RVA = "0x2AD1A44", Offset = "0x2AD1A44", VA = "0x2AD1A44")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 1L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600103A RID: 4154 RVA: 0x000603E0 File Offset: 0x0005E5E0
	[Token(Token = "0x600103A")]
	[Address(RVA = "0x2AD1B40", Offset = "0x2AD1B40", VA = "0x2AD1B40")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayNoise");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 1L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600103B RID: 4155 RVA: 0x00060458 File Offset: 0x0005E658
	[Token(Token = "0x600103B")]
	[Address(RVA = "0x2AD1C3C", Offset = "0x2AD1C3C", VA = "0x2AD1C3C")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Smoothness");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600103C RID: 4156 RVA: 0x000604D0 File Offset: 0x0005E6D0
	[Token(Token = "0x600103C")]
	[Address(RVA = "0x2AD1D38", Offset = "0x2AD1D38", VA = "0x2AD1D38")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Not connected to room");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600103D RID: 4157 RVA: 0x00060548 File Offset: 0x0005E748
	[Token(Token = "0x600103D")]
	[Address(RVA = "0x2AD1E34", Offset = "0x2AD1E34", VA = "0x2AD1E34")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("1BN");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600103E RID: 4158 RVA: 0x000605C0 File Offset: 0x0005E7C0
	[Token(Token = "0x600103E")]
	[Address(RVA = "0x2AD1F30", Offset = "0x2AD1F30", VA = "0x2AD1F30")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_BumpMap");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600103F RID: 4159 RVA: 0x00060638 File Offset: 0x0005E838
	[Token(Token = "0x600103F")]
	[Address(RVA = "0x2AD202C", Offset = "0x2AD202C", VA = "0x2AD202C")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Target");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001040 RID: 4160 RVA: 0x000606B0 File Offset: 0x0005E8B0
	[Token(Token = "0x6001040")]
	[Address(RVA = "0x2AD2128", Offset = "0x2AD2128", VA = "0x2AD2128")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Purchase For ");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001041 RID: 4161 RVA: 0x00060728 File Offset: 0x0005E928
	[Token(Token = "0x6001041")]
	[Address(RVA = "0x2AD2224", Offset = "0x2AD2224", VA = "0x2AD2224")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ErrorScreen");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
	}

	// Token: 0x06001042 RID: 4162 RVA: 0x00060790 File Offset: 0x0005E990
	[Token(Token = "0x6001042")]
	[Address(RVA = "0x2AD2320", Offset = "0x2AD2320", VA = "0x2AD2320")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Date: ");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001043 RID: 4163 RVA: 0x00060808 File Offset: 0x0005EA08
	[Token(Token = "0x6001043")]
	[Address(RVA = "0x2AD241C", Offset = "0x2AD241C", VA = "0x2AD241C")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Name Changing Error. Error: ");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001044 RID: 4164 RVA: 0x00060880 File Offset: 0x0005EA80
	[Token(Token = "0x6001044")]
	[Address(RVA = "0x2AD2518", Offset = "0x2AD2518", VA = "0x2AD2518")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("MetaId");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 1L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001045 RID: 4165 RVA: 0x000608F8 File Offset: 0x0005EAF8
	[Token(Token = "0x6001045")]
	[Address(RVA = "0x2AD2614", Offset = "0x2AD2614", VA = "0x2AD2614")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 1L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001046 RID: 4166 RVA: 0x00060970 File Offset: 0x0005EB70
	[Token(Token = "0x6001046")]
	[Address(RVA = "0x2AD2710", Offset = "0x2AD2710", VA = "0x2AD2710")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001047 RID: 4167 RVA: 0x000609D8 File Offset: 0x0005EBD8
	[Token(Token = "0x6001047")]
	[Address(RVA = "0x2AD280C", Offset = "0x2AD280C", VA = "0x2AD280C")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("HorrorAgreement");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001048 RID: 4168 RVA: 0x00060A50 File Offset: 0x0005EC50
	[Token(Token = "0x6001048")]
	[Address(RVA = "0x2AD2908", Offset = "0x2AD2908", VA = "0x2AD2908")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Failed to login, please restart");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 1L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x06001049 RID: 4169 RVA: 0x00060AC8 File Offset: 0x0005ECC8
	[Token(Token = "0x6001049")]
	[Address(RVA = "0x2AD2A04", Offset = "0x2AD2A04", VA = "0x2AD2A04")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("typesOfTalk");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 1L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600104A RID: 4170 RVA: 0x00060B40 File Offset: 0x0005ED40
	[Token(Token = "0x600104A")]
	[Address(RVA = "0x2AD2B00", Offset = "0x2AD2B00", VA = "0x2AD2B00")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ScoreCounter");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 1L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600104B RID: 4171 RVA: 0x00060BB0 File Offset: 0x0005EDB0
	[Token(Token = "0x600104B")]
	[Address(RVA = "0x2AD2BFC", Offset = "0x2AD2BFC", VA = "0x2AD2BFC")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Tagging");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600104C RID: 4172 RVA: 0x00060C28 File Offset: 0x0005EE28
	[Token(Token = "0x600104C")]
	[Address(RVA = "0x2AD2CF8", Offset = "0x2AD2CF8", VA = "0x2AD2CF8")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(\u07FEל\u05AC\u0877);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 1L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600104D RID: 4173 RVA: 0x00060C98 File Offset: 0x0005EE98
	[Token(Token = "0x600104D")]
	[Address(RVA = "0x2AD2DF4", Offset = "0x2AD2DF4", VA = "0x2AD2DF4")]
	public KeyUnlock()
	{
	}

	// Token: 0x0600104E RID: 4174 RVA: 0x00060CAC File Offset: 0x0005EEAC
	[Token(Token = "0x600104E")]
	[Address(RVA = "0x2AD2DFC", Offset = "0x2AD2DFC", VA = "0x2AD2DFC")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_WobbleX");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 0L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 1L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x0600104F RID: 4175 RVA: 0x00060D24 File Offset: 0x0005EF24
	[Token(Token = "0x600104F")]
	[Address(RVA = "0x2AD2EF8", Offset = "0x2AD2EF8", VA = "0x2AD2EF8")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.");
		GameObject մ_u05BAںۈ = this.Մ\u05BAںۈ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(մ_u05BAںۈ);
		GameObject u07EFٺӔߎ = this.\u07EFٺӔߎ;
		long active = 1L;
		u07EFٺӔߎ.SetActive(active != 0L);
		MeshRenderer ޒ_u085Fޠێ = this.ޒ\u085Fޠێ;
		Material ݰԐ_u073D_u081E = this.ݰԐ\u073D\u081E;
		ޒ_u085Fޠێ.material = ݰԐ_u073D_u081E;
		BoxCollider ԝࠌ_u059Cޣ = this.ԝࠌ\u059Cޣ;
		long enabled = 0L;
		ԝࠌ_u059Cޣ.enabled = (enabled != 0L);
	}

	// Token: 0x04000232 RID: 562
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000232")]
	public GameObject Մ\u05BAںۈ;

	// Token: 0x04000233 RID: 563
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000233")]
	public GameObject \u07EFٺӔߎ;

	// Token: 0x04000234 RID: 564
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000234")]
	public MeshRenderer ޒ\u085Fޠێ;

	// Token: 0x04000235 RID: 565
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000235")]
	public BoxCollider ԝࠌ\u059Cޣ;

	// Token: 0x04000236 RID: 566
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000236")]
	public Material \u05CBטڻݲ;

	// Token: 0x04000237 RID: 567
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000237")]
	public Material ݰԐ\u073D\u081E;
}
