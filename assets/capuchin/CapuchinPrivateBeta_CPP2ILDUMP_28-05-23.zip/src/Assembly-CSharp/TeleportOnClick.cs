﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000DE RID: 222
[Token(Token = "0x20000DE")]
public class TeleportOnClick : MonoBehaviour
{
	// Token: 0x06002270 RID: 8816 RVA: 0x000B6A8C File Offset: 0x000B4C8C
	[Token(Token = "0x6002270")]
	[Address(RVA = "0x2F20570", Offset = "0x2F20570", VA = "0x2F20570")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002271 RID: 8817 RVA: 0x000B6ACC File Offset: 0x000B4CCC
	[Token(Token = "0x6002271")]
	[Address(RVA = "0x2F20620", Offset = "0x2F20620", VA = "0x2F20620")]
	public TeleportOnClick()
	{
	}

	// Token: 0x06002272 RID: 8818 RVA: 0x000B6AE0 File Offset: 0x000B4CE0
	[Token(Token = "0x6002272")]
	[Address(RVA = "0x2F20628", Offset = "0x2F20628", VA = "0x2F20628")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002273 RID: 8819 RVA: 0x000B6B20 File Offset: 0x000B4D20
	[Token(Token = "0x6002273")]
	[Address(RVA = "0x2F206D8", Offset = "0x2F206D8", VA = "0x2F206D8")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "M/d/yyyy";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002274 RID: 8820 RVA: 0x000B6B60 File Offset: 0x000B4D60
	[Token(Token = "0x6002274")]
	[Address(RVA = "0x2F20788", Offset = "0x2F20788", VA = "0x2F20788")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002275 RID: 8821 RVA: 0x000B6BA0 File Offset: 0x000B4DA0
	[Token(Token = "0x6002275")]
	[Address(RVA = "0x2F20838", Offset = "0x2F20838", VA = "0x2F20838")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "duration done";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002276 RID: 8822 RVA: 0x000B6BE0 File Offset: 0x000B4DE0
	[Token(Token = "0x6002276")]
	[Address(RVA = "0x2F208E8", Offset = "0x2F208E8", VA = "0x2F208E8")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You are not the master of the server, you cannot start the game.";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002277 RID: 8823 RVA: 0x000B6C20 File Offset: 0x000B4E20
	[Token(Token = "0x6002277")]
	[Address(RVA = "0x2F20998", Offset = "0x2F20998", VA = "0x2F20998")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002278 RID: 8824 RVA: 0x000B6C60 File Offset: 0x000B4E60
	[Token(Token = "0x6002278")]
	[Address(RVA = "0x2F20A48", Offset = "0x2F20A48", VA = "0x2F20A48")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "A new Player joined a Room.";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002279 RID: 8825 RVA: 0x000B6CA0 File Offset: 0x000B4EA0
	[Token(Token = "0x6002279")]
	[Address(RVA = "0x2F20AF8", Offset = "0x2F20AF8", VA = "0x2F20AF8")]
	public void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600227A RID: 8826 RVA: 0x000B6CE0 File Offset: 0x000B4EE0
	[Token(Token = "0x600227A")]
	[Address(RVA = "0x2F20BA8", Offset = "0x2F20BA8", VA = "0x2F20BA8")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HandL";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600227B RID: 8827 RVA: 0x000B6D20 File Offset: 0x000B4F20
	[Token(Token = "0x600227B")]
	[Address(RVA = "0x2F20C58", Offset = "0x2F20C58", VA = "0x2F20C58")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600227C RID: 8828 RVA: 0x000B6D60 File Offset: 0x000B4F60
	[Token(Token = "0x600227C")]
	[Address(RVA = "0x2F20D08", Offset = "0x2F20D08", VA = "0x2F20D08")]
	public void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600227D RID: 8829 RVA: 0x000B6DA0 File Offset: 0x000B4FA0
	[Token(Token = "0x600227D")]
	[Address(RVA = "0x2F20DB8", Offset = "0x2F20DB8", VA = "0x2F20DB8")]
	public void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == " hour. You were banned because of ";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600227E RID: 8830 RVA: 0x000B6DE0 File Offset: 0x000B4FE0
	[Token(Token = "0x600227E")]
	[Address(RVA = "0x2F20E68", Offset = "0x2F20E68", VA = "0x2F20E68")]
	public void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
	}

	// Token: 0x0600227F RID: 8831 RVA: 0x000B6E0C File Offset: 0x000B500C
	[Token(Token = "0x600227F")]
	[Address(RVA = "0x2F20F18", Offset = "0x2F20F18", VA = "0x2F20F18")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Room Name: ";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002280 RID: 8832 RVA: 0x000B6E4C File Offset: 0x000B504C
	[Token(Token = "0x6002280")]
	[Address(RVA = "0x2F20FC8", Offset = "0x2F20FC8", VA = "0x2F20FC8")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Bare Torso";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002281 RID: 8833 RVA: 0x000B6E8C File Offset: 0x000B508C
	[Token(Token = "0x6002281")]
	[Address(RVA = "0x2F21078", Offset = "0x2F21078", VA = "0x2F21078")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002282 RID: 8834 RVA: 0x000B6ECC File Offset: 0x000B50CC
	[Token(Token = "0x6002282")]
	[Address(RVA = "0x2F21128", Offset = "0x2F21128", VA = "0x2F21128")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "hh:mmtt";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002283 RID: 8835 RVA: 0x000B6F0C File Offset: 0x000B510C
	[Token(Token = "0x6002283")]
	[Address(RVA = "0x2F211D8", Offset = "0x2F211D8", VA = "0x2F211D8")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Version";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002284 RID: 8836 RVA: 0x000B6F4C File Offset: 0x000B514C
	[Token(Token = "0x6002284")]
	[Address(RVA = "0x2F21288", Offset = "0x2F21288", VA = "0x2F21288")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "back";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002285 RID: 8837 RVA: 0x000B6F8C File Offset: 0x000B518C
	[Token(Token = "0x6002285")]
	[Address(RVA = "0x2F21338", Offset = "0x2F21338", VA = "0x2F21338")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002286 RID: 8838 RVA: 0x000B6FCC File Offset: 0x000B51CC
	[Token(Token = "0x6002286")]
	[Address(RVA = "0x2F213E8", Offset = "0x2F213E8", VA = "0x2F213E8")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HandR";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002287 RID: 8839 RVA: 0x000B700C File Offset: 0x000B520C
	[Token(Token = "0x6002287")]
	[Address(RVA = "0x2F21498", Offset = "0x2F21498", VA = "0x2F21498")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Meta Platform entitlement error: ";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002288 RID: 8840 RVA: 0x000B704C File Offset: 0x000B524C
	[Token(Token = "0x6002288")]
	[Address(RVA = "0x2F21548", Offset = "0x2F21548", VA = "0x2F21548")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Name Changing Error. Error: ";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002289 RID: 8841 RVA: 0x000B708C File Offset: 0x000B528C
	[Token(Token = "0x6002289")]
	[Address(RVA = "0x2F215F8", Offset = "0x2F215F8", VA = "0x2F215F8")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Grip";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600228A RID: 8842 RVA: 0x000B70CC File Offset: 0x000B52CC
	[Token(Token = "0x600228A")]
	[Address(RVA = "0x2F216A8", Offset = "0x2F216A8", VA = "0x2F216A8")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Add/Remove Hat";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600228B RID: 8843 RVA: 0x000B710C File Offset: 0x000B530C
	[Token(Token = "0x600228B")]
	[Address(RVA = "0x2F21758", Offset = "0x2F21758", VA = "0x2F21758")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600228C RID: 8844 RVA: 0x000B7144 File Offset: 0x000B5344
	[Token(Token = "0x600228C")]
	[Address(RVA = "0x2F21808", Offset = "0x2F21808", VA = "0x2F21808")]
	public void سࡕԞ߆(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "sound play play";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600228D RID: 8845 RVA: 0x000B7184 File Offset: 0x000B5384
	[Token(Token = "0x600228D")]
	[Address(RVA = "0x2F218B8", Offset = "0x2F218B8", VA = "0x2F218B8")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600228E RID: 8846 RVA: 0x000B71C4 File Offset: 0x000B53C4
	[Token(Token = "0x600228E")]
	[Address(RVA = "0x2F21968", Offset = "0x2F21968", VA = "0x2F21968")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PURCHASED";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600228F RID: 8847 RVA: 0x000B7204 File Offset: 0x000B5404
	[Token(Token = "0x600228F")]
	[Address(RVA = "0x2F21A18", Offset = "0x2F21A18", VA = "0x2F21A18")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "All audio clips have been played.";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002290 RID: 8848 RVA: 0x000B7244 File Offset: 0x000B5444
	[Token(Token = "0x6002290")]
	[Address(RVA = "0x2F21AC8", Offset = "0x2F21AC8", VA = "0x2F21AC8")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "monke is not my monke";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002291 RID: 8849 RVA: 0x000B7284 File Offset: 0x000B5484
	[Token(Token = "0x6002291")]
	[Address(RVA = "0x2F21B78", Offset = "0x2F21B78", VA = "0x2F21B78")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Starting to bake textures on frame ";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002292 RID: 8850 RVA: 0x000B72C4 File Offset: 0x000B54C4
	[Token(Token = "0x6002292")]
	[Address(RVA = "0x2F21C28", Offset = "0x2F21C28", VA = "0x2F21C28")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002293 RID: 8851 RVA: 0x000B7304 File Offset: 0x000B5504
	[Token(Token = "0x6002293")]
	[Address(RVA = "0x2F21CD8", Offset = "0x2F21CD8", VA = "0x2F21CD8")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002294 RID: 8852 RVA: 0x000B7344 File Offset: 0x000B5544
	[Token(Token = "0x6002294")]
	[Address(RVA = "0x2F21D88", Offset = "0x2F21D88", VA = "0x2F21D88")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Hate Speech";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002295 RID: 8853 RVA: 0x000B7384 File Offset: 0x000B5584
	[Token(Token = "0x6002295")]
	[Address(RVA = "0x2F21E38", Offset = "0x2F21E38", VA = "0x2F21E38")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Purchase For ";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002296 RID: 8854 RVA: 0x000B73C4 File Offset: 0x000B55C4
	[Token(Token = "0x6002296")]
	[Address(RVA = "0x2F21EE8", Offset = "0x2F21EE8", VA = "0x2F21EE8")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "RainAndThunderWeather";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002297 RID: 8855 RVA: 0x000B7404 File Offset: 0x000B5604
	[Token(Token = "0x6002297")]
	[Address(RVA = "0x2F21F98", Offset = "0x2F21F98", VA = "0x2F21F98")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Holdable";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002298 RID: 8856 RVA: 0x000B7444 File Offset: 0x000B5644
	[Token(Token = "0x6002298")]
	[Address(RVA = "0x2F22048", Offset = "0x2F22048", VA = "0x2F22048")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "spooky guy true";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x06002299 RID: 8857 RVA: 0x000B7484 File Offset: 0x000B5684
	[Token(Token = "0x6002299")]
	[Address(RVA = "0x2F220F8", Offset = "0x2F220F8", VA = "0x2F220F8")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Room Name: ";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600229A RID: 8858 RVA: 0x000B74C4 File Offset: 0x000B56C4
	[Token(Token = "0x600229A")]
	[Address(RVA = "0x2F221A8", Offset = "0x2F221A8", VA = "0x2F221A8")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HOLY MOLY THE STICK IS ON FIRE!!!!!!";
	}

	// Token: 0x0600229B RID: 8859 RVA: 0x000B74F0 File Offset: 0x000B56F0
	[Token(Token = "0x600229B")]
	[Address(RVA = "0x2F22258", Offset = "0x2F22258", VA = "0x2F22258")]
	public void ܘݱ\u083CԲ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600229C RID: 8860 RVA: 0x000B7530 File Offset: 0x000B5730
	[Token(Token = "0x600229C")]
	[Address(RVA = "0x2F22308", Offset = "0x2F22308", VA = "0x2F22308")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Add/Remove Glasses";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600229D RID: 8861 RVA: 0x000B7570 File Offset: 0x000B5770
	[Token(Token = "0x600229D")]
	[Address(RVA = "0x2F223B8", Offset = "0x2F223B8", VA = "0x2F223B8")]
	public void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Room1";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600229E RID: 8862 RVA: 0x000B75B0 File Offset: 0x000B57B0
	[Token(Token = "0x600229E")]
	[Address(RVA = "0x2F22468", Offset = "0x2F22468", VA = "0x2F22468")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayerHead";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0600229F RID: 8863 RVA: 0x000B75F0 File Offset: 0x000B57F0
	[Token(Token = "0x600229F")]
	[Address(RVA = "0x2F22518", Offset = "0x2F22518", VA = "0x2F22518")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Toxicity";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x060022A0 RID: 8864 RVA: 0x000B7630 File Offset: 0x000B5830
	[Token(Token = "0x60022A0")]
	[Address(RVA = "0x2F225C8", Offset = "0x2F225C8", VA = "0x2F225C8")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x060022A1 RID: 8865 RVA: 0x000B7670 File Offset: 0x000B5870
	[Token(Token = "0x60022A1")]
	[Address(RVA = "0x2F22678", Offset = "0x2F22678", VA = "0x2F22678")]
	public void ة\u066Dࡏԫ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not enough amount of currency";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x060022A2 RID: 8866 RVA: 0x000B76B0 File Offset: 0x000B58B0
	[Token(Token = "0x60022A2")]
	[Address(RVA = "0x2F22728", Offset = "0x2F22728", VA = "0x2F22728")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player was caught cheating";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x060022A3 RID: 8867 RVA: 0x000B76F0 File Offset: 0x000B58F0
	[Token(Token = "0x60022A3")]
	[Address(RVA = "0x2F227D8", Offset = "0x2F227D8", VA = "0x2F227D8")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x060022A4 RID: 8868 RVA: 0x000B7730 File Offset: 0x000B5930
	[Token(Token = "0x60022A4")]
	[Address(RVA = "0x2F22888", Offset = "0x2F22888", VA = "0x2F22888")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "token";
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x060022A5 RID: 8869 RVA: 0x000B7770 File Offset: 0x000B5970
	[Token(Token = "0x60022A5")]
	[Address(RVA = "0x2F22938", Offset = "0x2F22938", VA = "0x2F22938")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		Transform ࠊ_u061Cӳ_u05C = this.ࠊ\u061Cӳ\u05C1;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = ࠊ_u061Cӳ_u05C.position;
	}

	// Token: 0x0400046A RID: 1130
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400046A")]
	public Transform \u081B\u070Aߢࡁ;

	// Token: 0x0400046B RID: 1131
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400046B")]
	public Transform ࠊ\u061Cӳ\u05C1;
}
