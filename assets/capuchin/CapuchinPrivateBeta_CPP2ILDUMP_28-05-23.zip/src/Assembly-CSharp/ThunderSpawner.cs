﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000EE RID: 238
[Token(Token = "0x20000EE")]
public class ThunderSpawner : MonoBehaviour
{
	// Token: 0x060024A2 RID: 9378 RVA: 0x000C02C8 File Offset: 0x000BE4C8
	[Token(Token = "0x60024A2")]
	[Address(RVA = "0x2F29AEC", Offset = "0x2F29AEC", VA = "0x2F29AEC")]
	public void ذ\u0559دڪ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024A3 RID: 9379 RVA: 0x000C0338 File Offset: 0x000BE538
	[Token(Token = "0x60024A3")]
	[Address(RVA = "0x2F29BD8", Offset = "0x2F29BD8", VA = "0x2F29BD8")]
	public void ߋ\u058E\u0530\u059D()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024A4 RID: 9380 RVA: 0x000C03A8 File Offset: 0x000BE5A8
	[Token(Token = "0x60024A4")]
	[Address(RVA = "0x2F29CC4", Offset = "0x2F29CC4", VA = "0x2F29CC4")]
	public void \u0733\u0738\u0599ە()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024A5 RID: 9381 RVA: 0x000C0418 File Offset: 0x000BE618
	[Token(Token = "0x60024A5")]
	[Address(RVA = "0x2F29DB0", Offset = "0x2F29DB0", VA = "0x2F29DB0")]
	public void \u05CCވ\u05C1\u060D()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024A6 RID: 9382 RVA: 0x000C0488 File Offset: 0x000BE688
	[Token(Token = "0x60024A6")]
	[Address(RVA = "0x2F29E9C", Offset = "0x2F29E9C", VA = "0x2F29E9C")]
	public void ބࢥ\u0887տ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform;
		Vector3 position = transform.position;
		long maxExclusive = 0L;
		int num = UnityEngine.Random.Range(1, (int)maxExclusive);
	}

	// Token: 0x060024A7 RID: 9383 RVA: 0x000C04BC File Offset: 0x000BE6BC
	[Token(Token = "0x60024A7")]
	[Address(RVA = "0x2F29F88", Offset = "0x2F29F88", VA = "0x2F29F88")]
	public void \u0589ࡦ\u07AC\u061E()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024A8 RID: 9384 RVA: 0x000C052C File Offset: 0x000BE72C
	[Token(Token = "0x60024A8")]
	[Address(RVA = "0x2F2A074", Offset = "0x2F2A074", VA = "0x2F2A074")]
	public void \u088A\u06E5\u061B\u0596()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024A9 RID: 9385 RVA: 0x000C059C File Offset: 0x000BE79C
	[Token(Token = "0x60024A9")]
	[Address(RVA = "0x2F2A160", Offset = "0x2F2A160", VA = "0x2F2A160")]
	public void \u0605\u07AA\u070Aב()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024AA RID: 9386 RVA: 0x000C060C File Offset: 0x000BE80C
	[Token(Token = "0x60024AA")]
	[Address(RVA = "0x2F2A24C", Offset = "0x2F2A24C", VA = "0x2F2A24C")]
	public void ࢦՀӗ\u05FC()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024AB RID: 9387 RVA: 0x000C067C File Offset: 0x000BE87C
	[Token(Token = "0x60024AB")]
	[Address(RVA = "0x2F2A338", Offset = "0x2F2A338", VA = "0x2F2A338")]
	public void ࡋࢥت\u0617()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024AC RID: 9388 RVA: 0x000C06EC File Offset: 0x000BE8EC
	[Token(Token = "0x60024AC")]
	[Address(RVA = "0x2F2A424", Offset = "0x2F2A424", VA = "0x2F2A424")]
	public void \u05B4\u059B\u082Aթ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024AD RID: 9389 RVA: 0x000C075C File Offset: 0x000BE95C
	[Token(Token = "0x60024AD")]
	[Address(RVA = "0x2F2A510", Offset = "0x2F2A510", VA = "0x2F2A510")]
	public void աӅ\u0589Օ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024AE RID: 9390 RVA: 0x000C07CC File Offset: 0x000BE9CC
	[Token(Token = "0x60024AE")]
	[Address(RVA = "0x2F2A5FC", Offset = "0x2F2A5FC", VA = "0x2F2A5FC")]
	public void \u0700ԑ\u0593ࡤ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024AF RID: 9391 RVA: 0x000C083C File Offset: 0x000BEA3C
	[Token(Token = "0x60024AF")]
	[Address(RVA = "0x2F2A6E8", Offset = "0x2F2A6E8", VA = "0x2F2A6E8")]
	public void ࡎߐ\u05EC\u05A7()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024B0 RID: 9392 RVA: 0x000C08AC File Offset: 0x000BEAAC
	[Token(Token = "0x60024B0")]
	[Address(RVA = "0x2F2A7D4", Offset = "0x2F2A7D4", VA = "0x2F2A7D4")]
	public void ҽࡎܣࡪ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024B1 RID: 9393 RVA: 0x000C091C File Offset: 0x000BEB1C
	[Token(Token = "0x60024B1")]
	[Address(RVA = "0x2F2A8C0", Offset = "0x2F2A8C0", VA = "0x2F2A8C0")]
	public void ڴӺԲ\u064F()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024B2 RID: 9394 RVA: 0x000C098C File Offset: 0x000BEB8C
	[Token(Token = "0x60024B2")]
	[Address(RVA = "0x2F2A9AC", Offset = "0x2F2A9AC", VA = "0x2F2A9AC")]
	public void ݯࠄ\u07ADࡥ()
	{
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024B3 RID: 9395 RVA: 0x000C09F4 File Offset: 0x000BEBF4
	[Token(Token = "0x60024B3")]
	[Address(RVA = "0x2F2AA98", Offset = "0x2F2AA98", VA = "0x2F2AA98")]
	public void \u074Cܯ۷\u07B9()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024B4 RID: 9396 RVA: 0x000C0A64 File Offset: 0x000BEC64
	[Token(Token = "0x60024B4")]
	[Address(RVA = "0x2F2AB84", Offset = "0x2F2AB84", VA = "0x2F2AB84")]
	public void ࢮקתݫ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024B5 RID: 9397 RVA: 0x000C0AD4 File Offset: 0x000BECD4
	[Token(Token = "0x60024B5")]
	[Address(RVA = "0x2F2AC70", Offset = "0x2F2AC70", VA = "0x2F2AC70")]
	public ThunderSpawner()
	{
	}

	// Token: 0x060024B6 RID: 9398 RVA: 0x000C0AE8 File Offset: 0x000BECE8
	[Token(Token = "0x60024B6")]
	[Address(RVA = "0x2F2AC78", Offset = "0x2F2AC78", VA = "0x2F2AC78")]
	public void ۂ\u0618בݏ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024B7 RID: 9399 RVA: 0x000C0B58 File Offset: 0x000BED58
	[Token(Token = "0x60024B7")]
	[Address(RVA = "0x2F2AD64", Offset = "0x2F2AD64", VA = "0x2F2AD64")]
	public void ݗ\u07FFժغ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024B8 RID: 9400 RVA: 0x000C0BC8 File Offset: 0x000BEDC8
	[Token(Token = "0x60024B8")]
	[Address(RVA = "0x2F2AE50", Offset = "0x2F2AE50", VA = "0x2F2AE50")]
	public void \u0837\u06E5ٮ\u0871()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024B9 RID: 9401 RVA: 0x000C0C38 File Offset: 0x000BEE38
	[Token(Token = "0x60024B9")]
	[Address(RVA = "0x2F2AF3C", Offset = "0x2F2AF3C", VA = "0x2F2AF3C")]
	public void \u0607ֈ\u0893א()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024BA RID: 9402 RVA: 0x000C0CA8 File Offset: 0x000BEEA8
	[Token(Token = "0x60024BA")]
	[Address(RVA = "0x2F2B028", Offset = "0x2F2B028", VA = "0x2F2B028")]
	public void ԉ\u0704ܥ\u088C()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024BB RID: 9403 RVA: 0x000C0D18 File Offset: 0x000BEF18
	[Token(Token = "0x60024BB")]
	[Address(RVA = "0x2F2B114", Offset = "0x2F2B114", VA = "0x2F2B114")]
	public void \u0735ࡍ\u073Bԗ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024BC RID: 9404 RVA: 0x000C0D88 File Offset: 0x000BEF88
	[Token(Token = "0x60024BC")]
	[Address(RVA = "0x2F2B200", Offset = "0x2F2B200", VA = "0x2F2B200")]
	public void \u058BӠ\u0836ܢ()
	{
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024BD RID: 9405 RVA: 0x000C0DF0 File Offset: 0x000BEFF0
	[Token(Token = "0x60024BD")]
	[Address(RVA = "0x2F2B2EC", Offset = "0x2F2B2EC", VA = "0x2F2B2EC")]
	public void ӕޞڴ\u05A3()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x060024BE RID: 9406 RVA: 0x000C0E60 File Offset: 0x000BF060
	[Token(Token = "0x60024BE")]
	[Address(RVA = "0x2F2B3D8", Offset = "0x2F2B3D8", VA = "0x2F2B3D8")]
	public void \u065F\u05FB\u0881ݜ()
	{
		Transform[] ղԟ_u061Aۍ = this.Ղԟ\u061Aۍ;
		Transform transform = this.\u05F6ݫӋ\u0703.transform;
		Transform[] ղԟ_u061Aۍ2 = this.Ղԟ\u061Aۍ;
		Vector3 position = transform.position;
		AudioClip[] u0891_u088D_u0656ݿ = this.\u0891\u088D\u0656ݿ;
		AudioClip.PCMReaderCallback pcmreaderCallback = u0891_u088D_u0656ݿ.m_PCMReaderCallback;
		AudioSource audioSource = this.מڴӽշ;
		object target = u0891_u088D_u0656ݿ.m_PCMReaderCallback.m_target;
		this.ڧԺڗԨ.Play();
	}

	// Token: 0x04000493 RID: 1171
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000493")]
	public Transform[] Ղԟ\u061Aۍ;

	// Token: 0x04000494 RID: 1172
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000494")]
	public AudioSource מڴӽշ;

	// Token: 0x04000495 RID: 1173
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000495")]
	public AudioClip[] \u0891\u088D\u0656ݿ;

	// Token: 0x04000496 RID: 1174
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000496")]
	public ParticleSystem ڧԺڗԨ;

	// Token: 0x04000497 RID: 1175
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000497")]
	public GameObject \u05F6ݫӋ\u0703;
}
