﻿using System;
using Cpp2IlInjected;
using Mod;
using UnityEngine;

// Token: 0x020000ED RID: 237
[Token(Token = "0x20000ED")]
public class TheBigAnnouncement : MonoBehaviour
{
	// Token: 0x06002491 RID: 9361 RVA: 0x000C00B4 File Offset: 0x000BE2B4
	[Token(Token = "0x6002491")]
	[Address(RVA = "0x2F29924", Offset = "0x2F29924", VA = "0x2F29924")]
	public void \u05B4\u082Eࠔ\u05AB()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x06002492 RID: 9362 RVA: 0x000C00D4 File Offset: 0x000BE2D4
	[Token(Token = "0x6002492")]
	[Address(RVA = "0x2F29940", Offset = "0x2F29940", VA = "0x2F29940")]
	public void ݮ\u05FF\u070C\u086B()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x06002493 RID: 9363 RVA: 0x000C00F4 File Offset: 0x000BE2F4
	[Token(Token = "0x6002493")]
	[Address(RVA = "0x2F2995C", Offset = "0x2F2995C", VA = "0x2F2995C")]
	public void \u0615ضմ\u07F3()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x06002494 RID: 9364 RVA: 0x000C0114 File Offset: 0x000BE314
	[Token(Token = "0x6002494")]
	[Address(RVA = "0x2F29978", Offset = "0x2F29978", VA = "0x2F29978")]
	public void Ӓ\u0883ނ\u0835()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x06002495 RID: 9365 RVA: 0x000C0134 File Offset: 0x000BE334
	[Token(Token = "0x6002495")]
	[Address(RVA = "0x2F29994", Offset = "0x2F29994", VA = "0x2F29994")]
	public void ذڂޠ\u083F()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x06002496 RID: 9366 RVA: 0x000C0154 File Offset: 0x000BE354
	[Token(Token = "0x6002496")]
	[Address(RVA = "0x2F299B0", Offset = "0x2F299B0", VA = "0x2F299B0")]
	public void ٱӮࢦٹ()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x06002497 RID: 9367 RVA: 0x000C0174 File Offset: 0x000BE374
	[Token(Token = "0x6002497")]
	[Address(RVA = "0x2F299CC", Offset = "0x2F299CC", VA = "0x2F299CC")]
	public void մ\u05A2մ\u0705()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x06002498 RID: 9368 RVA: 0x000C0194 File Offset: 0x000BE394
	[Token(Token = "0x6002498")]
	[Address(RVA = "0x2F299E8", Offset = "0x2F299E8", VA = "0x2F299E8")]
	public void ޠԨՒߪ()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x06002499 RID: 9369 RVA: 0x000C01B4 File Offset: 0x000BE3B4
	[Token(Token = "0x6002499")]
	[Address(RVA = "0x2F29A04", Offset = "0x2F29A04", VA = "0x2F29A04")]
	public void \u0882ޟݳ\u05CE()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x0600249A RID: 9370 RVA: 0x000C01D4 File Offset: 0x000BE3D4
	[Token(Token = "0x600249A")]
	[Address(RVA = "0x2F29A20", Offset = "0x2F29A20", VA = "0x2F29A20")]
	public void ۉ۰\u06E8ӫ()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x0600249B RID: 9371 RVA: 0x000C01F4 File Offset: 0x000BE3F4
	[Token(Token = "0x600249B")]
	[Address(RVA = "0x2F29A3C", Offset = "0x2F29A3C", VA = "0x2F29A3C")]
	public void \u089FݚӢ\u05C7()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x0600249C RID: 9372 RVA: 0x000C0214 File Offset: 0x000BE414
	[Token(Token = "0x600249C")]
	[Address(RVA = "0x2F29A58", Offset = "0x2F29A58", VA = "0x2F29A58")]
	public void եۼסݓ()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x0600249D RID: 9373 RVA: 0x000C0234 File Offset: 0x000BE434
	[Token(Token = "0x600249D")]
	[Address(RVA = "0x2F29A74", Offset = "0x2F29A74", VA = "0x2F29A74")]
	public void އ٠ޖӛ()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x0600249E RID: 9374 RVA: 0x000C0254 File Offset: 0x000BE454
	[Token(Token = "0x600249E")]
	[Address(RVA = "0x2F29A90", Offset = "0x2F29A90", VA = "0x2F29A90")]
	public void \u05CBܗ\u05F4ӵ()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x0600249F RID: 9375 RVA: 0x000C0274 File Offset: 0x000BE474
	[Token(Token = "0x600249F")]
	[Address(RVA = "0x2F29AAC", Offset = "0x2F29AAC", VA = "0x2F29AAC")]
	public void ࡨڇӞԻ()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x060024A0 RID: 9376 RVA: 0x000C0294 File Offset: 0x000BE494
	[Token(Token = "0x60024A0")]
	[Address(RVA = "0x2F29AC8", Offset = "0x2F29AC8", VA = "0x2F29AC8")]
	public TheBigAnnouncement()
	{
	}

	// Token: 0x060024A1 RID: 9377 RVA: 0x000C02A8 File Offset: 0x000BE4A8
	[Token(Token = "0x60024A1")]
	[Address(RVA = "0x2F29AD0", Offset = "0x2F29AD0", VA = "0x2F29AD0")]
	public void ܕ\u0702ݳ\u0873()
	{
		this.ښ\u05FE\u07BFݨ.ITSHAPPENINGBRO();
	}

	// Token: 0x04000492 RID: 1170
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000492")]
	public TVScreenManager ښ\u05FE\u07BFݨ;
}
