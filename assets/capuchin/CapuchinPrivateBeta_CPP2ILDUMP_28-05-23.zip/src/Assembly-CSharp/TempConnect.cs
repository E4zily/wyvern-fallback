﻿using System;
using Cpp2IlInjected;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x020000EC RID: 236
[Token(Token = "0x20000EC")]
public class TempConnect : MonoBehaviourPunCallbacks
{
	// Token: 0x06002465 RID: 9317 RVA: 0x000BEFFC File Offset: 0x000BD1FC
	[Token(Token = "0x6002465")]
	[Address(RVA = "0x2F23300", Offset = "0x2F23300", VA = "0x2F23300")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 6L;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		Hashtable hashtable = new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		string[] customRoomPropertiesForLobby = new string[5];
		if ("True" != null)
		{
			if ("True" != null)
			{
				return;
			}
		}
		else
		{
			if ("Holdable" == null)
			{
				roomOptions.CustomRoomPropertiesForLobby = customRoomPropertiesForLobby;
				this.ծت\u06FE\u05EE();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long length = 3L;
				long startIndex = 0L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("Holdable" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002466 RID: 9318 RVA: 0x000BF0C4 File Offset: 0x000BD2C4
	[Token(Token = "0x6002466")]
	[Address(RVA = "0x2F23748", Offset = "0x2F23748", VA = "0x2F23748")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		UnityEngine.Object @object = new UnityEngine.Object();
		Hashtable hashtable = new Hashtable();
		Hashtable hashtable2 = new Hashtable();
		string[] array = new string[5];
		if ("Player" != null)
		{
			if ("Player" != null)
			{
				return;
			}
		}
		else
		{
			if ("Player" == null)
			{
				this.ࢱ\u0748\u05F6ࠔ();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long startIndex = 1L;
				long length = 4L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("Player" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002467 RID: 9319 RVA: 0x000BF16C File Offset: 0x000BD36C
	[Token(Token = "0x6002467")]
	[Address(RVA = "0x2F23B84", Offset = "0x2F23B84", VA = "0x2F23B84")]
	public void Ӷރݺ߅()
	{
		int maxExclusive = 102;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
		string str;
		string text = this.\u055C\u07ED\u07F6\u05A3 + str;
	}

	// Token: 0x06002468 RID: 9320 RVA: 0x000BF1A8 File Offset: 0x000BD3A8
	[Token(Token = "0x6002468")]
	[Address(RVA = "0x2F23C24", Offset = "0x2F23C24", VA = "0x2F23C24")]
	public void \u05C4ݳ\u05BCࡂ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002469 RID: 9321 RVA: 0x000BF1D0 File Offset: 0x000BD3D0
	[Token(Token = "0x6002469")]
	[Address(RVA = "0x2F23CB8", Offset = "0x2F23CB8", VA = "0x2F23CB8")]
	public void \u059E\u0708ݔࢭ()
	{
		string text2;
		string text = text2 + text2;
		throw new NullReferenceException();
	}

	// Token: 0x0600246A RID: 9322 RVA: 0x000BF1F8 File Offset: 0x000BD3F8
	[Token(Token = "0x600246A")]
	[Address(RVA = "0x2F23D50", Offset = "0x2F23D50", VA = "0x2F23D50")]
	public void Իܕރݲ()
	{
	}

	// Token: 0x0600246B RID: 9323 RVA: 0x000BF208 File Offset: 0x000BD408
	[Token(Token = "0x600246B")]
	[Address(RVA = "0x2F23D54", Offset = "0x2F23D54", VA = "0x2F23D54")]
	public void \u07BBӨ\u058D\u07FD()
	{
		long minInclusive = 1L;
		int maxExclusive = 108;
		int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
		char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
		string str;
		string text = this.\u055C\u07ED\u07F6\u05A3 + str;
	}

	// Token: 0x0600246C RID: 9324 RVA: 0x000BF244 File Offset: 0x000BD444
	[Token(Token = "0x600246C")]
	[Address(RVA = "0x2F23DF4", Offset = "0x2F23DF4", VA = "0x2F23DF4")]
	public void ࢥ\u059Bݹࠍ()
	{
	}

	// Token: 0x0600246D RID: 9325 RVA: 0x000BF254 File Offset: 0x000BD454
	[Token(Token = "0x600246D")]
	[Address(RVA = "0x2F23DF8", Offset = "0x2F23DF8", VA = "0x2F23DF8")]
	public void ࢫ\u0876չՍ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600246E RID: 9326 RVA: 0x000BF27C File Offset: 0x000BD47C
	[Token(Token = "0x600246E")]
	[Address(RVA = "0x2F23E8C", Offset = "0x2F23E8C", VA = "0x2F23E8C")]
	public void ۅڞ\u087Fࢥ()
	{
		long minInclusive = 1L;
		int maxExclusive = 106;
		int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
		char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
		string str;
		string text = this.\u055C\u07ED\u07F6\u05A3 + str;
	}

	// Token: 0x0600246F RID: 9327 RVA: 0x000BF2B8 File Offset: 0x000BD4B8
	[Token(Token = "0x600246F")]
	[Address(RVA = "0x2F23F2C", Offset = "0x2F23F2C", VA = "0x2F23F2C")]
	public void ܣ\u086E\u05CF\u06D8()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002470 RID: 9328 RVA: 0x000BF2E0 File Offset: 0x000BD4E0
	[Token(Token = "0x6002470")]
	[Address(RVA = "0x2F23FC0", Offset = "0x2F23FC0", VA = "0x2F23FC0")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		Hashtable hashtable = new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		string[] array = new string[6];
		if ("Player" != null)
		{
			if ("Player" != null)
			{
				return;
			}
		}
		else
		{
			if ("ENABLE" == null)
			{
				this.\u081Fړ\u07F0د();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long startIndex = 1L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, 5);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("ENABLE" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002471 RID: 9329 RVA: 0x000BF390 File Offset: 0x000BD590
	[Token(Token = "0x6002471")]
	[Address(RVA = "0x2F24404", Offset = "0x2F24404", VA = "0x2F24404")]
	public void ފՖߢ\u059B()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002472 RID: 9330 RVA: 0x000BF3B8 File Offset: 0x000BD5B8
	[Token(Token = "0x6002472")]
	[Address(RVA = "0x2F24498", Offset = "0x2F24498", VA = "0x2F24498")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		int maxPlayers = 5;
		long num = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (num != 0L);
		roomOptions.<PublishUserId>k__BackingField = (num != 0L);
		Hashtable customRoomProperties = new Hashtable();
		Hashtable hashtable = new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		string[] customRoomPropertiesForLobby = new string[7];
		if ("SetColor" != null)
		{
			if ("SetColor" != null)
			{
				return;
			}
		}
		else
		{
			if ("tp 2" == null)
			{
				roomOptions.CustomRoomPropertiesForLobby = customRoomPropertiesForLobby;
				this.\u082EڢרԾ();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long length = 3L;
				long startIndex = 0L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("tp 2" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002473 RID: 9331 RVA: 0x000BF488 File Offset: 0x000BD688
	[Token(Token = "0x6002473")]
	[Address(RVA = "0x2F248D8", Offset = "0x2F248D8", VA = "0x2F248D8")]
	public void ڷՋޟ\u066A()
	{
		long maxExclusive = 3L;
		int num = UnityEngine.Random.Range(0, (int)maxExclusive);
		string text2;
		string text = text2 + text2;
		long maxExclusive2 = 3L;
		int num2 = UnityEngine.Random.Range(0, (int)maxExclusive2);
		throw new NullReferenceException();
	}

	// Token: 0x06002474 RID: 9332 RVA: 0x000BF4C0 File Offset: 0x000BD6C0
	[Token(Token = "0x6002474")]
	[Address(RVA = "0x2F236A8", Offset = "0x2F236A8", VA = "0x2F236A8")]
	public void ծت\u06FE\u05EE()
	{
		long maxExclusive = -49L;
		int num = UnityEngine.Random.Range(0, (int)maxExclusive);
		char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
		string str;
		string text = this.\u055C\u07ED\u07F6\u05A3 + str;
	}

	// Token: 0x06002475 RID: 9333 RVA: 0x000BF4FC File Offset: 0x000BD6FC
	[Token(Token = "0x6002475")]
	[Address(RVA = "0x2F24970", Offset = "0x2F24970", VA = "0x2F24970")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 8L;
		int isVisible = 257;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		Hashtable hashtable = new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		string[] customRoomPropertiesForLobby = new string[2];
		if ("isLava" != null)
		{
			if ("isLava" != null)
			{
				return;
			}
		}
		else
		{
			if ("containsStaff" == null)
			{
				roomOptions.CustomRoomPropertiesForLobby = customRoomPropertiesForLobby;
				this.\u0746ۃۆ۳();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long length = 6L;
				long startIndex = 0L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("containsStaff" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002476 RID: 9334 RVA: 0x000BF5D4 File Offset: 0x000BD7D4
	[Token(Token = "0x6002476")]
	[Address(RVA = "0x2F24D9C", Offset = "0x2F24D9C", VA = "0x2F24D9C")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.MaxPlayers = typeof(RoomOptions).TypeHandle;
		roomOptions.isVisible = (typeof(RoomOptions).TypeHandle != null);
		roomOptions.<PublishUserId>k__BackingField = (typeof(RoomOptions).TypeHandle != null);
		Hashtable hashtable = new Hashtable();
		Hashtable hashtable2 = new Hashtable();
		string[] customRoomPropertiesForLobby = new string[4];
		if ("BLUPORT" != null)
		{
			if ("BLUPORT" != null)
			{
				return;
			}
		}
		else
		{
			if (".Please press the button if you would like to play alone" == null)
			{
				roomOptions.CustomRoomPropertiesForLobby = customRoomPropertiesForLobby;
				this.ࡔܕ\u0606\u07AA();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long length = 8L;
				long startIndex = 0L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if (".Please press the button if you would like to play alone" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002477 RID: 9335 RVA: 0x000BF6A0 File Offset: 0x000BD8A0
	[Token(Token = "0x6002477")]
	[Address(RVA = "0x2F251E0", Offset = "0x2F251E0", VA = "0x2F251E0")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.MaxPlayers = 5;
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		Hashtable hashtable = new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		string[] customRoomPropertiesForLobby = new string[3];
		if ("Combine textures & build combined mesh all at once" != null)
		{
			if ("Combine textures & build combined mesh all at once" != null)
			{
				return;
			}
		}
		else
		{
			if ("/" == null)
			{
				roomOptions.CustomRoomPropertiesForLobby = customRoomPropertiesForLobby;
				this.ڟڤ߁ֆ();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long startIndex = 1L;
				long length = 4L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("/" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002478 RID: 9336 RVA: 0x000BF764 File Offset: 0x000BD964
	[Token(Token = "0x6002478")]
	[Address(RVA = "0x2F25628", Offset = "0x2F25628", VA = "0x2F25628")]
	public TempConnect()
	{
		char[] ࡃܟԽ_u05FE;
		this.ࡃܟԽ\u05FE = ࡃܟԽ_u05FE;
		base..ctor();
	}

	// Token: 0x06002479 RID: 9337 RVA: 0x000BF784 File Offset: 0x000BD984
	[Token(Token = "0x6002479")]
	[Address(RVA = "0x2F25698", Offset = "0x2F25698", VA = "0x2F25698")]
	public void Ҿࢹؼס()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600247A RID: 9338 RVA: 0x000BF7A4 File Offset: 0x000BD9A4
	[Token(Token = "0x600247A")]
	[Address(RVA = "0x2F2572C", Offset = "0x2F2572C", VA = "0x2F2572C")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		if ("IsLowSurrogates" == null)
		{
		}
		bool flag = component;
		Hashtable hashtable = new Hashtable();
		Hashtable hashtable2 = new Hashtable();
		string[] array = new string[7];
		if ("ChangeToTagged" != null)
		{
			if ("ChangeToTagged" != null)
			{
				return;
			}
		}
		else
		{
			if ("Not enough amount of currency" == null)
			{
				this.ښݙࠊࢰ();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long startIndex = 1L;
				long length = 6L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("Not enough amount of currency" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600247B RID: 9339 RVA: 0x000BF84C File Offset: 0x000BDA4C
	[Token(Token = "0x600247B")]
	[Address(RVA = "0x2F25B60", Offset = "0x2F25B60", VA = "0x2F25B60")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long isVisible = 256L;
		roomOptions.MaxPlayers = 5;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		Hashtable hashtable = new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		string[] customRoomPropertiesForLobby = new string[2];
		if ("PLAYER IS BANNED" != null)
		{
			if ("PLAYER IS BANNED" != null)
			{
				return;
			}
		}
		else
		{
			if ("This is the 2500 Bananas button, and it was just clicked" == null)
			{
				roomOptions.CustomRoomPropertiesForLobby = customRoomPropertiesForLobby;
				this.Ӷރݺ߅();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long startIndex = 0L;
				long length = 0L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("This is the 2500 Bananas button, and it was just clicked" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600247C RID: 9340 RVA: 0x000BF914 File Offset: 0x000BDB14
	[Token(Token = "0x600247C")]
	[Address(RVA = "0x2F24840", Offset = "0x2F24840", VA = "0x2F24840")]
	public void \u082EڢרԾ()
	{
		do
		{
			long minInclusive = 1L;
			int maxExclusive = 9;
			int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
			char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
			string str;
			string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3 + str;
			this.\u055C\u07ED\u07F6\u05A3 = u055C_u07ED_u07F6_u05A;
			long minInclusive2 = 1L;
			int maxExclusive2 = 9;
			int num2 = UnityEngine.Random.Range((int)minInclusive2, maxExclusive2);
		}
		while (this.ࡃܟԽ\u05FE != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600247D RID: 9341 RVA: 0x000BF974 File Offset: 0x000BDB74
	[Token(Token = "0x600247D")]
	[Address(RVA = "0x2F25F14", Offset = "0x2F25F14", VA = "0x2F25F14")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
	}

	// Token: 0x0600247E RID: 9342 RVA: 0x000BFA3C File Offset: 0x000BDC3C
	[Token(Token = "0x600247E")]
	[Address(RVA = "0x2F2635C", Offset = "0x2F2635C", VA = "0x2F2635C")]
	public void ղࢺ\u0746ݭ()
	{
	}

	// Token: 0x0600247F RID: 9343 RVA: 0x000BFA4C File Offset: 0x000BDC4C
	[Token(Token = "0x600247F")]
	[Address(RVA = "0x2F26360", Offset = "0x2F26360", VA = "0x2F26360")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 4L;
		long isVisible = 256L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		Hashtable hashtable = new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		string[] customRoomPropertiesForLobby = new string[5];
		if ("Not connected to room" != null)
		{
			if ("Not connected to room" != null)
			{
				return;
			}
		}
		else
		{
			if ("DisableCosmetic" == null)
			{
				roomOptions.CustomRoomPropertiesForLobby = customRoomPropertiesForLobby;
				this.\u064Cӳރ\u065A();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long startIndex = 1L;
				long length = 3L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("DisableCosmetic" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002480 RID: 9344 RVA: 0x000BFB18 File Offset: 0x000BDD18
	[Token(Token = "0x6002480")]
	[Address(RVA = "0x2F24CFC", Offset = "0x2F24CFC", VA = "0x2F24CFC")]
	public void \u0746ۃۆ۳()
	{
		long minInclusive = 1L;
		int maxExclusive = 26;
		int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
		char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
		string str;
		string text = this.\u055C\u07ED\u07F6\u05A3 + str;
	}

	// Token: 0x06002481 RID: 9345 RVA: 0x000BFB54 File Offset: 0x000BDD54
	[Token(Token = "0x6002481")]
	[Address(RVA = "0x2F267A8", Offset = "0x2F267A8", VA = "0x2F267A8")]
	public void ڿؾӮ\u0898()
	{
	}

	// Token: 0x06002482 RID: 9346 RVA: 0x000BFB64 File Offset: 0x000BDD64
	[Token(Token = "0x6002482")]
	[Address(RVA = "0x2F24364", Offset = "0x2F24364", VA = "0x2F24364")]
	public void \u081Fړ\u07F0د()
	{
		long minInclusive = 1L;
		long maxExclusive = -15L;
		int num = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
		string str;
		string text = this.\u055C\u07ED\u07F6\u05A3 + str;
	}

	// Token: 0x06002483 RID: 9347 RVA: 0x000BFBA4 File Offset: 0x000BDDA4
	[Token(Token = "0x6002483")]
	[Address(RVA = "0x2F25AC8", Offset = "0x2F25AC8", VA = "0x2F25AC8")]
	public void ښݙࠊࢰ()
	{
		do
		{
			int maxExclusive = 66;
			int num = UnityEngine.Random.Range(0, maxExclusive);
			char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
			string str;
			string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3 + str;
			this.\u055C\u07ED\u07F6\u05A3 = u055C_u07ED_u07F6_u05A;
			int maxExclusive2 = 66;
			int num2 = UnityEngine.Random.Range(0, maxExclusive2);
		}
		while (this.ࡃܟԽ\u05FE != null);
		throw new NullReferenceException();
	}

	// Token: 0x06002484 RID: 9348 RVA: 0x000BFBFC File Offset: 0x000BDDFC
	[Token(Token = "0x6002484")]
	[Address(RVA = "0x2F262BC", Offset = "0x2F262BC", VA = "0x2F262BC")]
	public void ߥڐփࠐ()
	{
		long minInclusive = 1L;
		int maxExclusive = 20;
		int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
		char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
		string str;
		string text = this.\u055C\u07ED\u07F6\u05A3 + str;
	}

	// Token: 0x06002485 RID: 9349 RVA: 0x000BFC38 File Offset: 0x000BDE38
	[Token(Token = "0x6002485")]
	[Address(RVA = "0x2F267AC", Offset = "0x2F267AC", VA = "0x2F267AC")]
	public void طӏܙࢺ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002486 RID: 9350 RVA: 0x000BFC60 File Offset: 0x000BDE60
	[Token(Token = "0x6002486")]
	[Address(RVA = "0x2F26840", Offset = "0x2F26840", VA = "0x2F26840")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		HandColliders component = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		bool flag = \u07FEל\u05AC\u0877;
		RoomOptions roomOptions = new RoomOptions();
		long isVisible = 256L;
		roomOptions.MaxPlayers = 5;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		Hashtable hashtable = new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		string[] customRoomPropertiesForLobby = new string[8];
		if ("FingerTip" != null)
		{
			if ("FingerTip" != null)
			{
				return;
			}
		}
		else
		{
			if ("Name Changing Error. Error: " == null)
			{
				roomOptions.CustomRoomPropertiesForLobby = customRoomPropertiesForLobby;
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long length = 8L;
				long startIndex = 0L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("Name Changing Error. Error: " != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002487 RID: 9351 RVA: 0x000BFD24 File Offset: 0x000BDF24
	[Token(Token = "0x6002487")]
	[Address(RVA = "0x2F25590", Offset = "0x2F25590", VA = "0x2F25590")]
	public void ڟڤ߁ֆ()
	{
		do
		{
			long minInclusive = 1L;
			long maxExclusive = -121L;
			int num = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
			char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
			string str;
			string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3 + str;
			this.\u055C\u07ED\u07F6\u05A3 = u055C_u07ED_u07F6_u05A;
		}
		while (this.ࡃܟԽ\u05FE != null);
		throw new NullReferenceException();
	}

	// Token: 0x06002488 RID: 9352 RVA: 0x000BFD74 File Offset: 0x000BDF74
	[Token(Token = "0x6002488")]
	[Address(RVA = "0x2F26BEC", Offset = "0x2F26BEC", VA = "0x2F26BEC")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 2L;
		long isVisible = 256L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		Hashtable hashtable = new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		string[] customRoomPropertiesForLobby = new string[4];
		if ("FingerTip" != null)
		{
			if ("FingerTip" != null)
			{
				return;
			}
		}
		else
		{
			if ("Tagging" == null)
			{
				roomOptions.CustomRoomPropertiesForLobby = customRoomPropertiesForLobby;
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long length = 7L;
				long startIndex = 0L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				if (typeof(\u0820ݞ\u0877ӧ.\u05FBۑ\u085A\u07BB).TypeHandle == null)
				{
				}
				return;
			}
			if ("Tagging" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002489 RID: 9353 RVA: 0x000BFE3C File Offset: 0x000BE03C
	[Token(Token = "0x6002489")]
	[Address(RVA = "0x2F26F98", Offset = "0x2F26F98", VA = "0x2F26F98")]
	public void ҽ\u05F9ݣߢ()
	{
		long minInclusive = 1L;
		int maxExclusive = 46;
		int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
		char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
		string str;
		string text = this.\u055C\u07ED\u07F6\u05A3 + str;
	}

	// Token: 0x0600248A RID: 9354 RVA: 0x000BFE78 File Offset: 0x000BE078
	[Token(Token = "0x600248A")]
	[Address(RVA = "0x2F26710", Offset = "0x2F26710", VA = "0x2F26710")]
	public void \u064Cӳރ\u065A()
	{
		do
		{
			int maxExclusive = 116;
			int num = UnityEngine.Random.Range(0, maxExclusive);
			char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
			string str;
			string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3 + str;
			this.\u055C\u07ED\u07F6\u05A3 = u055C_u07ED_u07F6_u05A;
			int maxExclusive2 = 116;
			int num2 = UnityEngine.Random.Range(0, maxExclusive2);
		}
		while (this.ࡃܟԽ\u05FE != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600248B RID: 9355 RVA: 0x000BFED0 File Offset: 0x000BE0D0
	[Token(Token = "0x600248B")]
	[Address(RVA = "0x2F27038", Offset = "0x2F27038", VA = "0x2F27038")]
	public void \u0732ڙԒࢺ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600248C RID: 9356 RVA: 0x000BFEF8 File Offset: 0x000BE0F8
	[Token(Token = "0x600248C")]
	[Address(RVA = "0x2F25148", Offset = "0x2F25148", VA = "0x2F25148")]
	public void ࡔܕ\u0606\u07AA()
	{
		string text2;
		string text = text2 + text2;
		throw new NullReferenceException();
	}

	// Token: 0x0600248D RID: 9357 RVA: 0x000BFF20 File Offset: 0x000BE120
	[Token(Token = "0x600248D")]
	[Address(RVA = "0x2F270CC", Offset = "0x2F270CC", VA = "0x2F270CC")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.isVisible = (257 != 0);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		Hashtable hashtable = new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		if (".Please press the button if you would like to play alone" != null)
		{
			if (".Please press the button if you would like to play alone" != null)
			{
				return;
			}
		}
		else
		{
			if ("On" == null)
			{
				this.ڟڤ߁ֆ();
				string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3;
				int stringLength = u055C_u07ED_u07F6_u05A.m_stringLength;
				long startIndex = 1L;
				long length = 1L;
				string text = u055C_u07ED_u07F6_u05A.Substring((int)startIndex, (int)length);
				if (stringLength == 0)
				{
				}
				byte u0735ӎԝ_u05EB = this.\u0735ӎԝ\u05EB;
				return;
			}
			if ("On" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600248E RID: 9358 RVA: 0x000BFFD4 File Offset: 0x000BE1D4
	[Token(Token = "0x600248E")]
	[Address(RVA = "0x2F27484", Offset = "0x2F27484", VA = "0x2F27484")]
	public void Update()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600248F RID: 9359 RVA: 0x000BFFFC File Offset: 0x000BE1FC
	[Token(Token = "0x600248F")]
	[Address(RVA = "0x2F23AEC", Offset = "0x2F23AEC", VA = "0x2F23AEC")]
	public void ࢱ\u0748\u05F6ࠔ()
	{
		do
		{
			int maxExclusive = 49;
			int num = UnityEngine.Random.Range(0, maxExclusive);
			char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
			string str;
			string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3 + str;
			this.\u055C\u07ED\u07F6\u05A3 = u055C_u07ED_u07F6_u05A;
			int maxExclusive2 = 49;
			int num2 = UnityEngine.Random.Range(0, maxExclusive2);
		}
		while (this.ࡃܟԽ\u05FE != null);
		throw new NullReferenceException();
	}

	// Token: 0x06002490 RID: 9360 RVA: 0x000C0054 File Offset: 0x000BE254
	[Token(Token = "0x6002490")]
	[Address(RVA = "0x2F27518", Offset = "0x2F27518", VA = "0x2F27518")]
	public void Աߨӵ\u059F()
	{
		do
		{
			long minInclusive = 1L;
			int maxExclusive = 91;
			int num = UnityEngine.Random.Range((int)minInclusive, maxExclusive);
			char[] ࡃܟԽ_u05FE = this.ࡃܟԽ\u05FE;
			string str;
			string u055C_u07ED_u07F6_u05A = this.\u055C\u07ED\u07F6\u05A3 + str;
			this.\u055C\u07ED\u07F6\u05A3 = u055C_u07ED_u07F6_u05A;
			long minInclusive2 = 1L;
			int maxExclusive2 = 91;
			int num2 = UnityEngine.Random.Range((int)minInclusive2, maxExclusive2);
		}
		while (this.ࡃܟԽ\u05FE != null);
		throw new NullReferenceException();
	}

	// Token: 0x0400048F RID: 1167
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400048F")]
	private char[] ࡃܟԽ\u05FE;

	// Token: 0x04000490 RID: 1168
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000490")]
	private string \u055C\u07ED\u07F6\u05A3;

	// Token: 0x04000491 RID: 1169
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000491")]
	public byte \u0735ӎԝ\u05EB;
}
