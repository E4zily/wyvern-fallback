﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using ExitGames.Client.Photon;
using Oculus.Platform;
using Oculus.Platform.Models;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using PlayFab.ClientModels;
using TMPro;
using UnityEngine;

namespace CapuchinPlayFab
{
	// Token: 0x02000117 RID: 279
	[Token(Token = "0x2000117")]
	public class LoginManager : MonoBehaviourPunCallbacks
	{
		// Token: 0x06002AF6 RID: 10998 RVA: 0x0010338C File Offset: 0x0010158C
		[Token(Token = "0x6002AF6")]
		[Address(RVA = "0x24BBBBC", Offset = "0x24BBBBC", VA = "0x24BBBBC")]
		private void Ԡ\u05FFطՏ(GetTitleNewsResult ޅࢶ\u05F3ܪ)
		{
			bool flag = ޅࢶ\u05F3ܪ.News.GetEnumerator().MoveNext();
		}

		// Token: 0x06002AF7 RID: 10999 RVA: 0x001033BC File Offset: 0x001015BC
		[Token(Token = "0x6002AF7")]
		[Address(RVA = "0x24BBD1C", Offset = "0x24BBD1C", VA = "0x24BBD1C")]
		public void ղגՂێ()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (LoginManager.<>c.<>9__59_1 == null)
			{
				Action<PlayFabError> <>9__59_;
				LoginManager.<>c.<>9__59_1 = <>9__59_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002AF8 RID: 11000 RVA: 0x001033E4 File Offset: 0x001015E4
		[Token(Token = "0x6002AF8")]
		[Address(RVA = "0x24BBEE8", Offset = "0x24BBEE8", VA = "0x24BBEE8")]
		private void \u0859\u088CՁء(Message Ҿࠐ\u0708ࡂ)
		{
			bool isError = Ҿࠐ\u0708ࡂ.IsError;
			if (Ҿࠐ\u0708ࡂ != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06002AF9 RID: 11001 RVA: 0x00103418 File Offset: 0x00101618
		[Token(Token = "0x6002AF9")]
		[Address(RVA = "0x24BC064", Offset = "0x24BC064", VA = "0x24BC064")]
		private void ۹ࢱࠒӕ(GetTitleDataResult ޅࢶ\u05F3ܪ)
		{
			Dictionary<string, string> data = ޅࢶ\u05F3ܪ.Data;
			this.\u0888\u07F1\u0873ۇ = data;
			string version = UnityEngine.Application.version;
			string u0888_u07F1_u0873ۇ = this.\u0888\u07F1\u0873ۇ;
			bool flag = version != u0888_u07F1_u0873ۇ;
			GameObject ӂ_u05FFՂ_u065F = this.ӂ\u05FFՂ\u065F;
			long active = 1L;
			ӂ_u05FFՂ_u065F.SetActive(active != 0L);
			TextMeshPro textMeshPro = this.ߢصջո;
			string[] values = new string[6];
			if ("CapuchinRemade" != null)
			{
				if ("CapuchinRemade" != null)
				{
					return;
				}
			}
			else
			{
				string version2 = UnityEngine.Application.version;
				if (version2 == null || version2 != null)
				{
					if ("FingerTip" != null)
					{
						if ("FingerTip" != null)
						{
							return;
						}
					}
					else if ("_Tint" != null)
					{
						if ("_Tint" != null)
						{
							return;
						}
					}
					else
					{
						string text = string.Concat(values);
						this.ԱيՌࡢ();
						string[] values2 = new string[6];
						if ("Try Connect To Server..." != null)
						{
							if ("Try Connect To Server..." != null)
							{
								return;
							}
						}
						else
						{
							string version3 = UnityEngine.Application.version;
							if (version3 == null || version3 != null)
							{
								if (" hour. You were banned because of " != null)
								{
									if (" hour. You were banned because of " != null)
									{
										return;
									}
								}
								else
								{
									if ("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene." == null)
									{
										Debug.LogError(string.Concat(values2));
										return;
									}
									if ("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene." != null)
									{
										return;
									}
								}
							}
						}
					}
				}
			}
			throw new ArrayTypeMismatchException();
		}

		// Token: 0x06002AFA RID: 11002 RVA: 0x00103544 File Offset: 0x00101744
		[Token(Token = "0x6002AFA")]
		[Address(RVA = "0x24BC4E8", Offset = "0x24BC4E8", VA = "0x24BC4E8")]
		public void ԱيՌࡢ()
		{
			PhotonNetwork.Disconnect();
		}

		// Token: 0x06002AFB RID: 11003 RVA: 0x00103558 File Offset: 0x00101758
		[Token(Token = "0x6002AFB")]
		[Address(RVA = "0x24BC540", Offset = "0x24BC540", VA = "0x24BC540")]
		public void \u0836\u089Dی\u0735()
		{
			if (true)
			{
				float deltaTime = Time.deltaTime;
			}
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool inRoom = PhotonNetwork.InRoom;
			float deltaTime2 = Time.deltaTime;
		}

		// Token: 0x06002AFC RID: 11004 RVA: 0x00103590 File Offset: 0x00101790
		[Token(Token = "0x6002AFC")]
		[Address(RVA = "0x24BC62C", Offset = "0x24BC62C", VA = "0x24BC62C")]
		private void ݡ\u0818\u05C0ט(Message Ҿࠐ\u0708ࡂ)
		{
			bool isError = Ҿࠐ\u0708ࡂ.IsError;
			if (Ҿࠐ\u0708ࡂ != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06002AFD RID: 11005 RVA: 0x001035C4 File Offset: 0x001017C4
		[Token(Token = "0x6002AFD")]
		[Address(RVA = "0x24BC7A8", Offset = "0x24BC7A8", VA = "0x24BC7A8")]
		public void ۀ\u0885ࠔխ()
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Update User Inventory");
			if (typeof(Core).TypeHandle == null)
			{
			}
			Message.Callback callback;
			Request request = Entitlements.IsUserEntitledToApplication().OnComplete(callback);
		}

		// Token: 0x06002AFE RID: 11006 RVA: 0x0010361C File Offset: 0x0010181C
		[Token(Token = "0x6002AFE")]
		[Address(RVA = "0x24BC9B8", Offset = "0x24BC9B8", VA = "0x24BC9B8")]
		private void Ӭ\u0895Ԓ\u082F(PlayFabError ہ\u0613ܢ\u07B4)
		{
			Debug.LogError(ہ\u0613ܢ\u07B4.GenerateErrorReport());
		}

		// Token: 0x06002AFF RID: 11007 RVA: 0x0010363C File Offset: 0x0010183C
		[Token(Token = "0x6002AFF")]
		[Address(RVA = "0x24BCA38", Offset = "0x24BCA38", VA = "0x24BCA38")]
		public void \u06D8\u081Fݫ\u086E()
		{
			GetTitleDataRequest getTitleDataRequest = new GetTitleDataRequest();
			List<string> keys = new List();
			getTitleDataRequest.Keys = keys;
			if (LoginManager.<>c.<>9__56_1 == null)
			{
				Action<PlayFabError> <>9__56_;
				LoginManager.<>c.<>9__56_1 = <>9__56_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B00 RID: 11008 RVA: 0x00103678 File Offset: 0x00101878
		[Token(Token = "0x6002B00")]
		[Address(RVA = "0x24BCC94", Offset = "0x24BCC94", VA = "0x24BCC94")]
		public void \u0832ࢳޤ\u07B5()
		{
			if (this.خࡩՈӣ)
			{
				double լ_u05C9_u065F߅ = this.Լ\u05C9\u065F߅;
				float deltaTime = Time.deltaTime;
				this.Լ\u05C9\u065F߅ = (double)deltaTime;
			}
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool inRoom = PhotonNetwork.InRoom;
			NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
			if (networkPlayerSpawner.\u05C4ࡑڍۺ)
			{
				RendererDisable component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<RendererDisable>();
				this.ߝ\u0891\u05C5ӯ = component;
				IntPtr cachedPtr = this.m_CachedPtr;
				float deltaTime2 = Time.deltaTime;
			}
		}

		// Token: 0x06002B01 RID: 11009 RVA: 0x001036F4 File Offset: 0x001018F4
		[Token(Token = "0x6002B01")]
		[Address(RVA = "0x24BCD80", Offset = "0x24BCD80", VA = "0x24BCD80")]
		private void ࠎ\u0737ӍӚ(PlayFabError ہ\u0613ܢ\u07B4)
		{
			if (!true)
			{
			}
			Debug.Log(ہ\u0613ܢ\u07B4);
			BuyCosmetic[] و_u06DBچ_u064D = this.و\u06DBچ\u064D;
			float ݶՈהՇ = و_u06DBچ_u064D.ݶՈהՇ;
			float ݶՈהՇ2 = و_u06DBچ_u064D.ݶՈהՇ;
			if (ہ\u0613ܢ\u07B4.Error == PlayFabErrorCode.Success)
			{
			}
			Debug.Log("PlayerHead");
			Debug.Log(ہ\u0613ܢ\u07B4.GenerateErrorReport());
			Dictionary<string, List<string>> errorDetails = ہ\u0613ܢ\u07B4.ErrorDetails;
			ThrowHelper.ThrowArgumentOutOfRangeException();
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			DateTime d;
			double totalHours = (DateTime.Now - d).TotalHours;
			GameObject u082A_u083Dڻԥ = this.\u082A\u083Dڻԥ;
			long num = 1L;
			this.خࡩՈӣ = (num != 0L);
			this.Լ\u05C9\u065F߅ = totalHours;
			long active = 1L;
			u082A_u083Dڻԥ.SetActive(active != 0L);
			TextMeshPro u059A٣_u05C0_u = this.\u059A٣\u05C0\u0745;
			string[] values = new string[0];
			if ("We don't need this electrical box" != null)
			{
				if ("We don't need this electrical box" != null)
				{
					return;
				}
				throw new ArrayTypeMismatchException();
			}
			else
			{
				string text;
				if (text != null && text == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if ("isLava" != null)
				{
					if ("isLava" != null)
					{
						return;
					}
					throw new ArrayTypeMismatchException();
				}
				else
				{
					if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
					{
						throw new ArrayTypeMismatchException();
					}
					if ("SetColor" != null)
					{
						if ("SetColor" != null)
						{
							return;
						}
						throw new ArrayTypeMismatchException();
					}
					else
					{
						string text2 = string.Concat(values);
						ThrowHelper.ThrowArgumentOutOfRangeException();
						if ("Bruh i cannot go here you stupid L bozo" == null)
						{
						}
						string message;
						Debug.Log(message);
						TextMeshPro u059A٣_u05C0_u2 = this.\u059A٣\u05C0\u0745;
						string[] values2 = new string[2];
						if ("M/d/yyyy" != null)
						{
							if ("M/d/yyyy" != null)
							{
								return;
							}
							throw new ArrayTypeMismatchException();
						}
						else
						{
							if ("M/d/yyyy" == null)
							{
								throw new IndexOutOfRangeException();
							}
							string text3;
							if (text3 != null && text3 == null)
							{
								throw new ArrayTypeMismatchException();
							}
							if ("Player" != null)
							{
								if ("Player" != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
							else
							{
								if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
								{
									throw new ArrayTypeMismatchException();
								}
								if ("HandL" == null)
								{
									string text4 = string.Concat(values2);
									ThrowHelper.ThrowArgumentOutOfRangeException();
									if ("User has been reported for: " == null)
									{
									}
									string message2;
									Debug.Log(message2);
									GameObject ߪ_u0597ډӜ = this.ߪ\u0597ډӜ;
									if (typeof(UnityEngine.Object).TypeHandle == null)
									{
									}
									UnityEngine.Object.Destroy(ߪ_u0597ډӜ);
									UnityEngine.Object.Destroy(this.ى\u05B1ߖ\u082D);
									UnityEngine.Object.Destroy(this.٤چԊߤ);
									return;
								}
								if ("HandL" != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
						}
					}
				}
			}
		}

		// Token: 0x06002B02 RID: 11010 RVA: 0x001039D4 File Offset: 0x00101BD4
		[Token(Token = "0x6002B02")]
		[Address(RVA = "0x24BD780", Offset = "0x24BD780", VA = "0x24BD780")]
		private void ۅڃ\u0825ݙ(ulong خҽ\u0831۶, ulong ٧ۅ\u083Dݼ, string \u07F8\u0707ݿޢ)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string str;
			string customId = "TurnAmount" + str;
			loginWithCustomIDRequest.CustomId = customId;
			Dictionary<string, string> customTags;
			loginWithCustomIDRequest.CustomTags = customTags;
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			BuyCosmetic[] و_u06DBچ_u064D = UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
			this.و\u06DBچ\u064D = و_u06DBچ_u064D;
		}

		// Token: 0x06002B03 RID: 11011 RVA: 0x00103A28 File Offset: 0x00101C28
		[Token(Token = "0x6002B03")]
		[Address(RVA = "0x24BDA7C", Offset = "0x24BDA7C", VA = "0x24BDA7C")]
		public void \u05AD\u06E2ݛҽ()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (LoginManager.<>c.<>9__59_1 == null)
			{
				Action<PlayFabError> <>9__59_;
				LoginManager.<>c.<>9__59_1 = <>9__59_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B04 RID: 11012 RVA: 0x00103A50 File Offset: 0x00101C50
		[Token(Token = "0x6002B04")]
		[Address(RVA = "0x24BDC48", Offset = "0x24BDC48", VA = "0x24BDC48")]
		private void Աքݠ\u07AB(PlayFabError ہ\u0613ܢ\u07B4)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log(ہ\u0613ܢ\u07B4);
			BuyCosmetic[] و_u06DBچ_u064D = this.و\u06DBچ\u064D;
			if (و_u06DBچ_u064D == null)
			{
				return;
			}
			float ݶՈהՇ = و_u06DBچ_u064D.ݶՈהՇ;
			PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Charging...");
			Debug.Log(ہ\u0613ܢ\u07B4.GenerateErrorReport());
			Dictionary<string, List<string>> errorDetails = ہ\u0613ܢ\u07B4.ErrorDetails;
			ThrowHelper.ThrowArgumentOutOfRangeException();
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			DateTime d;
			double totalHours = (DateTime.Now - d).TotalHours;
			GameObject u082A_u083Dڻԥ = this.\u082A\u083Dڻԥ;
			long num = 1L;
			this.خࡩՈӣ = (num != 0L);
			long active = 1L;
			u082A_u083Dڻԥ.SetActive(active != 0L);
			TextMeshPro u059A٣_u05C0_u = this.\u059A٣\u05C0\u0745;
			string[] values = new string[8];
			if ("PlayerDeath" != null)
			{
				if ("PlayerDeath" != null)
				{
					return;
				}
				throw new ArrayTypeMismatchException();
			}
			else
			{
				string text;
				if (text != null && text == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if ("Push To Talk" != null)
				{
					if ("Push To Talk" != null)
					{
						return;
					}
					throw new ArrayTypeMismatchException();
				}
				else
				{
					if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
					{
						throw new ArrayTypeMismatchException();
					}
					if ("character limit reached" != null)
					{
						if ("character limit reached" != null)
						{
							return;
						}
						throw new ArrayTypeMismatchException();
					}
					else
					{
						if ("character limit reached" == null)
						{
							throw new IndexOutOfRangeException();
						}
						string text2 = string.Concat(values);
						ThrowHelper.ThrowArgumentOutOfRangeException();
						if (typeof(Debug).TypeHandle == null)
						{
						}
						string message;
						Debug.Log(message);
						TextMeshPro u059A٣_u05C0_u2 = this.\u059A٣\u05C0\u0745;
						string[] values2 = new string[0];
						if ("\n Time: " != null)
						{
							if ("\n Time: " != null)
							{
								return;
							}
							throw new ArrayTypeMismatchException();
						}
						else
						{
							string text3;
							if (text3 != null && text3 == null)
							{
								throw new ArrayTypeMismatchException();
							}
							if ("Found Gameobject: " != null)
							{
								if ("Found Gameobject: " != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
							else
							{
								if ("Found Gameobject: " == null)
								{
									throw new IndexOutOfRangeException();
								}
								if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
								{
									throw new ArrayTypeMismatchException();
								}
								if ("tutorialCheck" == null)
								{
									string text4 = string.Concat(values2);
									ThrowHelper.ThrowArgumentOutOfRangeException();
									if (typeof(Debug).TypeHandle == null)
									{
									}
									string message2;
									Debug.Log(message2);
									GameObject ߪ_u0597ډӜ = this.ߪ\u0597ډӜ;
									if (typeof(UnityEngine.Object).TypeHandle == null)
									{
									}
									UnityEngine.Object.Destroy(ߪ_u0597ډӜ);
									UnityEngine.Object.Destroy(this.ى\u05B1ߖ\u082D);
									UnityEngine.Object.Destroy(this.٤چԊߤ);
									return;
								}
								if ("tutorialCheck" != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
						}
					}
				}
			}
		}

		// Token: 0x06002B05 RID: 11013 RVA: 0x00103D38 File Offset: 0x00101F38
		[Token(Token = "0x6002B05")]
		[Address(RVA = "0x24BE61C", Offset = "0x24BE61C", VA = "0x24BE61C")]
		[CompilerGenerated]
		private void ک\u0889\u07FB\u0892(GetTitleDataResult ޅࢶ\u05F3ܪ)
		{
			Dictionary<string, string> data = ޅࢶ\u05F3ܪ.Data;
			this.\u0888\u07F1\u0873ۇ = data;
			string version = UnityEngine.Application.version;
			string u0888_u07F1_u0873ۇ = this.\u0888\u07F1\u0873ۇ;
			bool flag = version != u0888_u07F1_u0873ۇ;
			GameObject ӂ_u05FFՂ_u065F = this.ӂ\u05FFՂ\u065F;
			long active = 1L;
			ӂ_u05FFՂ_u065F.SetActive(active != 0L);
			TextMeshPro textMeshPro = this.ߢصջո;
			string[] values = new string[5];
			if ("You are on an outdated version of Capuchin. Your version is " != null)
			{
				if ("You are on an outdated version of Capuchin. Your version is " != null)
				{
					return;
				}
			}
			else
			{
				string version2 = UnityEngine.Application.version;
				if (version2 == null || version2 != null)
				{
					if (" and the correct version is " != null)
					{
						if (" and the correct version is " != null)
						{
							return;
						}
					}
					else if (". Please update you game to the latest version" != null)
					{
						if (". Please update you game to the latest version" != null)
						{
							return;
						}
					}
					else
					{
						string text = string.Concat(values);
						this.ԱيՌࡢ();
						string[] values2 = new string[5];
						if ("User is on an outdated version of Capuchin. Your version is " != null)
						{
							if ("User is on an outdated version of Capuchin. Your version is " != null)
							{
								return;
							}
						}
						else
						{
							string version3 = UnityEngine.Application.version;
							if (version3 == null || version3 != null)
							{
								if (" and the correct version is " != null)
								{
									if (" and the correct version is " != null)
									{
										return;
									}
								}
								else
								{
									if (". Please update you game to the latest version" == null)
									{
										Debug.LogError(string.Concat(values2));
										return;
									}
									if (". Please update you game to the latest version" != null)
									{
										return;
									}
								}
							}
						}
					}
				}
			}
			throw new ArrayTypeMismatchException();
		}

		// Token: 0x06002B06 RID: 11014 RVA: 0x00103E64 File Offset: 0x00102064
		[Token(Token = "0x6002B06")]
		[Address(RVA = "0x24BEA74", Offset = "0x24BEA74", VA = "0x24BEA74")]
		private void ӧ\u05F5߉\u0816(ulong خҽ\u0831۶, ulong ٧ۅ\u083Dݼ, string \u07F8\u0707ݿޢ)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string text2;
			string text = " hour. You were banned because of " + text2;
			loginWithCustomIDRequest.CustomId = text2;
			Dictionary<string, string> customTags;
			loginWithCustomIDRequest.CustomTags = customTags;
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			BuyCosmetic[] و_u06DBچ_u064D = UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
			this.و\u06DBچ\u064D = و_u06DBچ_u064D;
		}

		// Token: 0x06002B07 RID: 11015 RVA: 0x00103EB8 File Offset: 0x001020B8
		[Token(Token = "0x6002B07")]
		[Address(RVA = "0x24BED70", Offset = "0x24BED70", VA = "0x24BED70")]
		private void ԈՠԢԂ(GetPhotonAuthenticationTokenResult ւݍ\u05BA\u05FA)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Photon token acquired!");
			AuthenticationValues authValues = new AuthenticationValues();
			string ګ١կ_u = this.ګ١կ\u0875;
			string photonCustomAuthenticationToken = ւݍ\u05BA\u05FA.PhotonCustomAuthenticationToken;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.AuthValues = authValues;
			GetTitleNewsRequest getTitleNewsRequest = new GetTitleNewsRequest();
			TextureSwap ټ_u06E4_u055F_u087D = this.ټ\u06E4\u055F\u087D;
			long enabled = 0L;
			ټ_u06E4_u055F_u087D.enabled = (enabled != 0L);
			GameObject u0820ۮӺܦ = this.\u0820ۮӺܦ;
			long active = 0L;
			u0820ۮӺܦ.SetActive(active != 0L);
			GameObject ծܮ_u0874_u05F = this.ծܮ\u0874\u05F9;
			long active2 = 1L;
			ծܮ_u0874_u05F.SetActive(active2 != 0L);
			this.ղגՂێ();
			this.Ӎ\u05C2ࢩԁ();
			IEnumerator routine = this.\u06E0\u055Cӓߩ();
			Coroutine coroutine = base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("username");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if (typeof(UpdateUserTitleDisplayNameRequest).TypeHandle == null)
			{
			}
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B08 RID: 11016 RVA: 0x00103FAC File Offset: 0x001021AC
		[Token(Token = "0x6002B08")]
		[Address(RVA = "0x24BF33C", Offset = "0x24BF33C", VA = "0x24BF33C")]
		public void ڇ\u05AAקࡇ()
		{
			PhotonNetwork.Disconnect();
		}

		// Token: 0x06002B09 RID: 11017 RVA: 0x00103FC0 File Offset: 0x001021C0
		[Token(Token = "0x6002B09")]
		[Address(RVA = "0x24BF394", Offset = "0x24BF394", VA = "0x24BF394")]
		private void Ա\u0743ؾڻ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			List<ItemInstance> inventory = ޅࢶ\u05F3ܪ.Inventory;
			this.\u0738ؿࠇؠ = inventory;
		}

		// Token: 0x06002B0A RID: 11018 RVA: 0x00103FE4 File Offset: 0x001021E4
		[Token(Token = "0x6002B0A")]
		[Address(RVA = "0x24BF410", Offset = "0x24BF410", VA = "0x24BF410")]
		public void \u058Bچ\u05BB\u05A9()
		{
			GetTitleDataRequest getTitleDataRequest = new GetTitleDataRequest();
			List<string> keys = new List();
			getTitleDataRequest.Keys = keys;
			if (LoginManager.<>c.<>9__56_1 == null)
			{
				Action<PlayFabError> <>9__56_;
				LoginManager.<>c.<>9__56_1 = <>9__56_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B0B RID: 11019 RVA: 0x00104020 File Offset: 0x00102220
		[Token(Token = "0x6002B0B")]
		[Address(RVA = "0x24BF66C", Offset = "0x24BF66C", VA = "0x24BF66C")]
		private void \u06D7ܫࡡӈ(LoginResult ւݍ\u05BA\u05FA)
		{
			string playFabId = ւݍ\u05BA\u05FA.PlayFabId;
			this.ګ١կ\u0875 = playFabId;
			GetPhotonAuthenticationTokenRequest getPhotonAuthenticationTokenRequest = new GetPhotonAuthenticationTokenRequest();
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			string appIdRealtime = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime;
			getPhotonAuthenticationTokenRequest.PhotonApplicationId = appIdRealtime;
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B0C RID: 11020 RVA: 0x00104070 File Offset: 0x00102270
		[Token(Token = "0x6002B0C")]
		[Address(RVA = "0x24BF830", Offset = "0x24BF830", VA = "0x24BF830")]
		public void ڳ\u07BCԉ\u07BD()
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("false");
			if (typeof(Core).TypeHandle == null)
			{
			}
			Message.Callback callback;
			Request request = Entitlements.IsUserEntitledToApplication().OnComplete(callback);
		}

		// Token: 0x06002B0D RID: 11021 RVA: 0x001040C8 File Offset: 0x001022C8
		[Token(Token = "0x6002B0D")]
		[Address(RVA = "0x24BFA40", Offset = "0x24BFA40", VA = "0x24BFA40")]
		public void \u087Aܕ\u06E7\u07A9()
		{
			GetTitleDataRequest getTitleDataRequest = new GetTitleDataRequest();
			List<string> keys = new List();
			getTitleDataRequest.Keys = keys;
			if (LoginManager.<>c.<>9__56_1 == null)
			{
				Action<PlayFabError> <>9__56_;
				LoginManager.<>c.<>9__56_1 = <>9__56_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B0E RID: 11022 RVA: 0x00104104 File Offset: 0x00102304
		[Token(Token = "0x6002B0E")]
		[Address(RVA = "0x24BFC9C", Offset = "0x24BFC9C", VA = "0x24BFC9C")]
		public void Ԗ\u07FAچݐ()
		{
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.Disconnect();
			this.אԒ\u07F2\u086C();
		}

		// Token: 0x06002B0F RID: 11023 RVA: 0x00104128 File Offset: 0x00102328
		[Token(Token = "0x6002B0F")]
		[Address(RVA = "0x24BFD6C", Offset = "0x24BFD6C", VA = "0x24BFD6C")]
		private void ӯӖգԸ(PlayFabError ہ\u0613ܢ\u07B4)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log(ہ\u0613ܢ\u07B4);
			BuyCosmetic[] و_u06DBچ_u064D = this.و\u06DBچ\u064D;
			float ݶՈהՇ = و_u06DBچ_u064D.ݶՈהՇ;
			float ݶՈהՇ2 = و_u06DBچ_u064D.ݶՈהՇ;
			PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("PLAYER IS BANNED");
			Debug.Log(ہ\u0613ܢ\u07B4.GenerateErrorReport());
			Dictionary<string, List<string>> errorDetails = ہ\u0613ܢ\u07B4.ErrorDetails;
			ThrowHelper.ThrowArgumentOutOfRangeException();
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			DateTime d;
			double totalHours = (DateTime.Now - d).TotalHours;
			GameObject u082A_u083Dڻԥ = this.\u082A\u083Dڻԥ;
			long num = 1L;
			this.خࡩՈӣ = (num != 0L);
			this.Լ\u05C9\u065F߅ = totalHours;
			long active = 1L;
			u082A_u083Dڻԥ.SetActive(active != 0L);
			TextMeshPro u059A٣_u05C0_u = this.\u059A٣\u05C0\u0745;
			string[] values = new string[5];
			if ("You have been banned for " != null)
			{
				if ("You have been banned for " != null)
				{
					return;
				}
				throw new ArrayTypeMismatchException();
			}
			else
			{
				string text;
				if (text != null && text == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if (" hours. You were banned because of " != null)
				{
					if (" hours. You were banned because of " != null)
					{
						return;
					}
					throw new ArrayTypeMismatchException();
				}
				else
				{
					if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
					{
						throw new ArrayTypeMismatchException();
					}
					if (".Please press the button if you would like to play alone" != null)
					{
						if (".Please press the button if you would like to play alone" != null)
						{
							return;
						}
						throw new ArrayTypeMismatchException();
					}
					else
					{
						string text2 = string.Concat(values);
						ThrowHelper.ThrowArgumentOutOfRangeException();
						if (typeof(Debug).TypeHandle == null)
						{
						}
						string message;
						Debug.Log(message);
						TextMeshPro u059A٣_u05C0_u2 = this.\u059A٣\u05C0\u0745;
						string[] values2 = new string[5];
						if ("You have been banned for " != null)
						{
							if ("You have been banned for " != null)
							{
								return;
							}
							throw new ArrayTypeMismatchException();
						}
						else
						{
							string text3;
							if (text3 != null && text3 == null)
							{
								throw new ArrayTypeMismatchException();
							}
							if (" hour. You were banned because of " != null)
							{
								if (" hour. You were banned because of " != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
							else
							{
								if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
								{
									throw new ArrayTypeMismatchException();
								}
								if (".Please press the button if you would like to play alone" == null)
								{
									string text4 = string.Concat(values2);
									ThrowHelper.ThrowArgumentOutOfRangeException();
									if (typeof(Debug).TypeHandle == null)
									{
									}
									string message2;
									Debug.Log(message2);
									GameObject ߪ_u0597ډӜ = this.ߪ\u0597ډӜ;
									if ("IsLowSurrogates" == null)
									{
									}
									UnityEngine.Object.Destroy(ߪ_u0597ډӜ);
									UnityEngine.Object.Destroy(this.ى\u05B1ߖ\u082D);
									UnityEngine.Object.Destroy(this.٤چԊߤ);
									return;
								}
								if (".Please press the button if you would like to play alone" != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
						}
					}
				}
			}
		}

		// Token: 0x06002B10 RID: 11024 RVA: 0x00104404 File Offset: 0x00102604
		[Token(Token = "0x6002B10")]
		[Address(RVA = "0x24C06F8", Offset = "0x24C06F8", VA = "0x24C06F8")]
		private void ԗ\u0899\u0617٣(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("ENABLE");
			Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
			string u06D6_u0595ڤ_u073C = this.\u06D6\u0595ڤ\u073C;
			this.Bananas = virtualCurrency;
			if (typeof(Math).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B11 RID: 11025 RVA: 0x001044E4 File Offset: 0x001026E4
		[Token(Token = "0x6002B11")]
		[Address(RVA = "0x24C0AA0", Offset = "0x24C0AA0", VA = "0x24C0AA0")]
		private void \u0827ࡠ\u05AA\u05F5(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("EnableCosmetic");
			Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
			string u06D6_u0595ڤ_u073C = this.\u06D6\u0595ڤ\u073C;
			this.Bananas = virtualCurrency;
			if (typeof(Math).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B12 RID: 11026 RVA: 0x001045D8 File Offset: 0x001027D8
		[Token(Token = "0x6002B12")]
		[Address(RVA = "0x24C0E3C", Offset = "0x24C0E3C", VA = "0x24C0E3C", Slot = "42")]
		public override void OnPlayerEnteredRoom(Player \u05FB\u0610\u05F7\u065F)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("A new Player joined a Room.");
			base.OnPlayerEnteredRoom(\u05FB\u0610\u05F7\u065F);
		}

		// Token: 0x06002B13 RID: 11027 RVA: 0x00104600 File Offset: 0x00102800
		[Token(Token = "0x6002B13")]
		[Address(RVA = "0x24C0ED0", Offset = "0x24C0ED0", VA = "0x24C0ED0")]
		public void ރ\u0706ࡑڀ()
		{
			LoginManager.كݕ\u05F3\u0589 = this;
			this.\u05C7\u0707ӓޢ();
		}

		// Token: 0x06002B14 RID: 11028 RVA: 0x0010461C File Offset: 0x0010281C
		[Token(Token = "0x6002B14")]
		[Address(RVA = "0x24C113C", Offset = "0x24C113C", VA = "0x24C113C")]
		public void \u0705قۉԺ()
		{
			LoginManager.كݕ\u05F3\u0589 = this;
			this.\u05C7\u0707ӓޢ();
		}

		// Token: 0x06002B15 RID: 11029 RVA: 0x00104638 File Offset: 0x00102838
		[Token(Token = "0x6002B15")]
		[Address(RVA = "0x24C1198", Offset = "0x24C1198", VA = "0x24C1198")]
		private void ӂࢭڒܖ(GetPhotonAuthenticationTokenResult ւݍ\u05BA\u05FA)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("username");
			AuthenticationValues authenticationValues = new AuthenticationValues();
			long authType = 1L;
			authenticationValues.authType = (CustomAuthenticationType)authType;
			string ګ١կ_u = this.ګ١կ\u0875;
			string photonCustomAuthenticationToken = ւݍ\u05BA\u05FA.PhotonCustomAuthenticationToken;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.AuthValues = authenticationValues;
			GetTitleNewsRequest getTitleNewsRequest = new GetTitleNewsRequest();
			TextureSwap ټ_u06E4_u055F_u087D = this.ټ\u06E4\u055F\u087D;
			long enabled = 0L;
			ټ_u06E4_u055F_u087D.enabled = (enabled != 0L);
			GameObject u0820ۮӺܦ = this.\u0820ۮӺܦ;
			long active = 1L;
			u0820ۮӺܦ.SetActive(active != 0L);
			GameObject ծܮ_u0874_u05F = this.ծܮ\u0874\u05F9;
			long active2 = 1L;
			ծܮ_u0874_u05F.SetActive(active2 != 0L);
			this.ղגՂێ();
			this.եԜӸڨ();
			IEnumerator routine = this.\u06E0\u055Cӓߩ();
			Coroutine coroutine = base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("Purchase For ");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if ("Purchase For " == null)
			{
			}
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B16 RID: 11030 RVA: 0x00104734 File Offset: 0x00102934
		[Token(Token = "0x6002B16")]
		[Address(RVA = "0x24C1704", Offset = "0x24C1704", VA = "0x24C1704", Slot = "41")]
		public override void OnJoinedRoom()
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Joined a Room.");
			base.OnJoinedRoom();
			if ("Joined a Room." == null)
			{
			}
			Photon.Realtime.Room currentRoom = PhotonNetwork.CurrentRoom;
			if (this.\u07FB\u065Fࡄߑ)
			{
				ExitGames.Client.Photon.Hashtable customProperties = currentRoom.customProperties;
				Photon.Realtime.Room currentRoom2 = PhotonNetwork.CurrentRoom;
			}
			float ֆԬذ_u086B = this.ֆԬذ\u086B;
			RendererDisable ߝ_u0891_u05C5ӯ = this.ߝ\u0891\u05C5ӯ;
			long u065D_u06D8_u05C1ࠐ = 1L;
			ߝ_u0891_u05C5ӯ.\u065D\u06D8\u05C1ࠐ = (u065D_u06D8_u05C1ࠐ != 0L);
			GameObject ڰ_u07B2Ӳٱ = this.ڰ\u07B2Ӳٱ;
			long active = 0L;
			ڰ_u07B2Ӳٱ.SetActive(active != 0L);
			GameObject u05B0Ӯࡄ_u055E = this.\u05B0Ӯࡄ\u055E;
			long active2 = 0L;
			u05B0Ӯࡄ_u055E.SetActive(active2 != 0L);
		}

		// Token: 0x06002B17 RID: 11031 RVA: 0x001047CC File Offset: 0x001029CC
		[Token(Token = "0x6002B17")]
		[Address(RVA = "0x24C18F0", Offset = "0x24C18F0", VA = "0x24C18F0")]
		private void Ԑ\u0653ىࡒ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			List<ItemInstance> inventory = ޅࢶ\u05F3ܪ.Inventory;
			this.\u0738ؿࠇؠ = inventory;
			DynamicCosmetics.ލ\u0882ײࢲ.\u085E\u06FDݾհ();
		}

		// Token: 0x06002B18 RID: 11032 RVA: 0x001047F8 File Offset: 0x001029F8
		[Token(Token = "0x6002B18")]
		[Address(RVA = "0x24C196C", Offset = "0x24C196C", VA = "0x24C196C")]
		public void \u081FרӹԬ()
		{
			LoginManager.كݕ\u05F3\u0589 = this;
			this.ۀ\u0885ࠔխ();
		}

		// Token: 0x06002B19 RID: 11033 RVA: 0x00104814 File Offset: 0x00102A14
		[Token(Token = "0x6002B19")]
		[Address(RVA = "0x24C19C8", Offset = "0x24C19C8", VA = "0x24C19C8")]
		private void ܥիڍࡈ(Message Ҿࠐ\u0708ࡂ)
		{
			bool isError = Ҿࠐ\u0708ࡂ.IsError;
			if (Ҿࠐ\u0708ࡂ != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06002B1A RID: 11034 RVA: 0x00104848 File Offset: 0x00102A48
		[Token(Token = "0x6002B1A")]
		[Address(RVA = "0x24C165C", Offset = "0x24C165C", VA = "0x24C165C")]
		public void եԜӸڨ()
		{
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool flag = PhotonNetwork.ConnectUsingSettings();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("BN");
		}

		// Token: 0x06002B1B RID: 11035 RVA: 0x00104878 File Offset: 0x00102A78
		[Token(Token = "0x6002B1B")]
		[Address(RVA = "0x24C1B44", Offset = "0x24C1B44", VA = "0x24C1B44")]
		public void \u06E0څԚލ()
		{
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B1C RID: 11036 RVA: 0x0010488C File Offset: 0x00102A8C
		[Token(Token = "0x6002B1C")]
		[Address(RVA = "0x24C1C98", Offset = "0x24C1C98", VA = "0x24C1C98")]
		private void رӉࢪ\u05CB(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("isLava");
			Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
			string u06D6_u0595ڤ_u073C = this.\u06D6\u0595ڤ\u073C;
			this.Bananas = virtualCurrency;
			if (typeof(Math).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B1D RID: 11037 RVA: 0x00104980 File Offset: 0x00102B80
		[Token(Token = "0x6002B1D")]
		[Address(RVA = "0x24C204C", Offset = "0x24C204C", VA = "0x24C204C")]
		private void ܫԙӐߎ(GetTitleNewsResult ޅࢶ\u05F3ܪ)
		{
			bool flag = ޅࢶ\u05F3ܪ.News.GetEnumerator().MoveNext();
		}

		// Token: 0x06002B1E RID: 11038 RVA: 0x001049B4 File Offset: 0x00102BB4
		[Token(Token = "0x6002B1E")]
		[Address(RVA = "0x24C21AC", Offset = "0x24C21AC", VA = "0x24C21AC")]
		private void ڪ\u083Dօ\u066B(GetPhotonAuthenticationTokenResult ւݍ\u05BA\u05FA)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("DisableCosmetic");
			AuthenticationValues authenticationValues = new AuthenticationValues();
			long authType = 1L;
			authenticationValues.authType = (CustomAuthenticationType)authType;
			string ګ١կ_u = this.ګ١կ\u0875;
			string photonCustomAuthenticationToken = ւݍ\u05BA\u05FA.PhotonCustomAuthenticationToken;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.AuthValues = authenticationValues;
			GetTitleNewsRequest getTitleNewsRequest = new GetTitleNewsRequest();
			GameObject u0820ۮӺܦ = this.\u0820ۮӺܦ;
			long active = 0L;
			u0820ۮӺܦ.SetActive(active != 0L);
			GameObject ծܮ_u0874_u05F = this.ծܮ\u0874\u05F9;
			long active2 = 0L;
			ծܮ_u0874_u05F.SetActive(active2 != 0L);
			this.Ӈ\u0885\u0559ه();
			this.آ\u0618ؽ\u05EC();
			IEnumerator routine = this.\u06E0\u055Cӓߩ();
			Coroutine coroutine = base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("RightHandAttachPoint");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if ("RightHandAttachPoint" == null)
			{
			}
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B1F RID: 11039 RVA: 0x00104AA0 File Offset: 0x00102CA0
		[Token(Token = "0x6002B1F")]
		[Address(RVA = "0x24C28E4", Offset = "0x24C28E4", VA = "0x24C28E4")]
		private void ࠁټڂ\u0829(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Adding ");
			Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
			string u06D6_u0595ڤ_u073C = this.\u06D6\u0595ڤ\u073C;
			this.Bananas = virtualCurrency;
			if (typeof(Math).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B20 RID: 11040 RVA: 0x00104B80 File Offset: 0x00102D80
		[Token(Token = "0x6002B20")]
		[Address(RVA = "0x24C2C94", Offset = "0x24C2C94", VA = "0x24C2C94")]
		private void י\u087Aמܗ(Message<User> ࡒ۷\u0731ݕ)
		{
			Request<OrgScopedID> request2;
			Message<OrgScopedID>.Callback callback;
			Request<OrgScopedID> request = request2.OnComplete(callback);
		}

		// Token: 0x06002B21 RID: 11041 RVA: 0x00104BB4 File Offset: 0x00102DB4
		[Token(Token = "0x6002B21")]
		[Address(RVA = "0x24C2E24", Offset = "0x24C2E24", VA = "0x24C2E24")]
		public LoginManager()
		{
			long ԓտ_u0880ࡡ = 1L;
			this.Ԓտ\u0880ࡡ = (ԓտ_u0880ࡡ != 0L);
			base..ctor();
		}

		// Token: 0x06002B22 RID: 11042 RVA: 0x00104BD0 File Offset: 0x00102DD0
		[Token(Token = "0x6002B22")]
		[Address(RVA = "0x24C2E34", Offset = "0x24C2E34", VA = "0x24C2E34")]
		private void ՠߪۄࡖ(LoginResult ւݍ\u05BA\u05FA)
		{
			string playFabId = ւݍ\u05BA\u05FA.PlayFabId;
			this.ګ١կ\u0875 = playFabId;
			GetPhotonAuthenticationTokenRequest getPhotonAuthenticationTokenRequest = new GetPhotonAuthenticationTokenRequest();
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			string appIdRealtime = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime;
			getPhotonAuthenticationTokenRequest.PhotonApplicationId = appIdRealtime;
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B23 RID: 11043 RVA: 0x00104C20 File Offset: 0x00102E20
		[Token(Token = "0x6002B23")]
		[Address(RVA = "0x24C2FF8", Offset = "0x24C2FF8", VA = "0x24C2FF8")]
		private void \u0829\u089Fәࢰ(GetTitleDataResult ޅࢶ\u05F3ܪ)
		{
			Dictionary<string, string> data = ޅࢶ\u05F3ܪ.Data;
			this.\u0888\u07F1\u0873ۇ = data;
			string version = UnityEngine.Application.version;
			string u0888_u07F1_u0873ۇ = this.\u0888\u07F1\u0873ۇ;
			bool flag = version != u0888_u07F1_u0873ۇ;
			GameObject ӂ_u05FFՂ_u065F = this.ӂ\u05FFՂ\u065F;
			long active = 1L;
			ӂ_u05FFՂ_u065F.SetActive(active != 0L);
			TextMeshPro textMeshPro = this.ߢصջո;
			string[] values = new string[2];
			if ("gravThing" != null)
			{
				if ("gravThing" != null)
				{
					return;
				}
			}
			else
			{
				string version2 = UnityEngine.Application.version;
				if (version2 == null || version2 != null)
				{
					if ("_WobbleX" != null)
					{
						if ("_WobbleX" != null)
						{
							return;
						}
					}
					else if ("_Tint" != null)
					{
						if ("_Tint" != null)
						{
							return;
						}
					}
					else
					{
						string text = string.Concat(values);
						this.אԒ\u07F2\u086C();
						string[] values2 = new string[1];
						if ("typesOfTalk" != null)
						{
							if ("typesOfTalk" != null)
							{
								return;
							}
						}
						else
						{
							string version3 = UnityEngine.Application.version;
							if (version3 == null || version3 != null)
							{
								if ("True" != null)
								{
									if ("True" != null)
									{
										return;
									}
								}
								else
								{
									if ("PRESS AGAIN TO CONFIRM" == null)
									{
										Debug.LogError(string.Concat(values2));
										return;
									}
									if ("PRESS AGAIN TO CONFIRM" != null)
									{
										return;
									}
								}
							}
						}
					}
				}
			}
			throw new ArrayTypeMismatchException();
		}

		// Token: 0x06002B24 RID: 11044 RVA: 0x00104D4C File Offset: 0x00102F4C
		[Token(Token = "0x6002B24")]
		[Address(RVA = "0x24C3480", Offset = "0x24C3480", VA = "0x24C3480")]
		private void \u0893\u0652\u055Aݸ(ulong خҽ\u0831۶, ulong ٧ۅ\u083Dݼ, string \u07F8\u0707ݿޢ)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string str;
			string customId = "META" + str;
			loginWithCustomIDRequest.CustomId = customId;
			Dictionary<string, string> customTags;
			loginWithCustomIDRequest.CustomTags = customTags;
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			BuyCosmetic[] و_u06DBچ_u064D = UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
			this.و\u06DBچ\u064D = و_u06DBچ_u064D;
		}

		// Token: 0x06002B25 RID: 11045 RVA: 0x00104DA0 File Offset: 0x00102FA0
		[Token(Token = "0x6002B25")]
		[Address(RVA = "0x24C377C", Offset = "0x24C377C", VA = "0x24C377C")]
		public IEnumerator \u073A\u0590Ӎࡢ()
		{
			long <>1__state;
			LoginManager.ޢࢣށࠕ ޢࢣށࠕ = new LoginManager.ޢࢣށࠕ((int)<>1__state);
			<>1__state = 0L;
			ޢࢣށࠕ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002B26 RID: 11046 RVA: 0x00104DC4 File Offset: 0x00102FC4
		[Token(Token = "0x6002B26")]
		[Address(RVA = "0x24C37F4", Offset = "0x24C37F4", VA = "0x24C37F4")]
		public void ئ\u0739ۄڎ()
		{
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.Disconnect();
			this.אԒ\u07F2\u086C();
		}

		// Token: 0x06002B27 RID: 11047 RVA: 0x00104DE8 File Offset: 0x00102FE8
		[Token(Token = "0x6002B27")]
		[Address(RVA = "0x24C385C", Offset = "0x24C385C", VA = "0x24C385C")]
		private void ٢ࡧףٴ(Message<User> ࡒ۷\u0731ݕ)
		{
			Request<OrgScopedID> request2;
			Message<OrgScopedID>.Callback callback;
			Request<OrgScopedID> request = request2.OnComplete(callback);
		}

		// Token: 0x06002B28 RID: 11048 RVA: 0x00104E1C File Offset: 0x0010301C
		[Token(Token = "0x6002B28")]
		[Address(RVA = "0x24C39EC", Offset = "0x24C39EC", VA = "0x24C39EC")]
		private void ޝ\u0614\u073Cԉ(GetPhotonAuthenticationTokenResult ւݍ\u05BA\u05FA)
		{
			if (!true)
			{
			}
			Debug.Log("BN");
			AuthenticationValues authenticationValues = new AuthenticationValues();
			long authType = 1L;
			authenticationValues.authType = (CustomAuthenticationType)authType;
			string ګ١կ_u = this.ګ١կ\u0875;
			string photonCustomAuthenticationToken = ւݍ\u05BA\u05FA.PhotonCustomAuthenticationToken;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.AuthValues = authenticationValues;
			TextureSwap ټ_u06E4_u055F_u087D = this.ټ\u06E4\u055F\u087D;
			long enabled = 0L;
			ټ_u06E4_u055F_u087D.enabled = (enabled != 0L);
			GameObject u0820ۮӺܦ = this.\u0820ۮӺܦ;
			long active = 0L;
			u0820ۮӺܦ.SetActive(active != 0L);
			GameObject ծܮ_u0874_u05F = this.ծܮ\u0874\u05F9;
			long active2 = 0L;
			ծܮ_u0874_u05F.SetActive(active2 != 0L);
			this.Ӈ\u0885\u0559ه();
			this.եԜӸڨ();
			IEnumerator routine = this.\u073A\u0590Ӎࡢ();
			Coroutine coroutine = base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("Open");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if ("Open" == null)
			{
			}
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B29 RID: 11049 RVA: 0x00104F10 File Offset: 0x00103110
		[Token(Token = "0x6002B29")]
		[Address(RVA = "0x24C3EB0", Offset = "0x24C3EB0", VA = "0x24C3EB0")]
		[CompilerGenerated]
		private void ڎբءة(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			List<ItemInstance> inventory = ޅࢶ\u05F3ܪ.Inventory;
			this.\u0738ؿࠇؠ = inventory;
			DynamicCosmetics.ލ\u0882ײࢲ.ӿ\u05C9Ԅ\u07A8();
		}

		// Token: 0x06002B2A RID: 11050 RVA: 0x00104F3C File Offset: 0x0010313C
		[Token(Token = "0x6002B2A")]
		[Address(RVA = "0x24C0F2C", Offset = "0x24C0F2C", VA = "0x24C0F2C")]
		public void \u05C7\u0707ӓޢ()
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("PlayNoise");
			if (typeof(Core).TypeHandle == null)
			{
			}
			Request request = Entitlements.IsUserEntitledToApplication();
		}

		// Token: 0x06002B2B RID: 11051 RVA: 0x00104F8C File Offset: 0x0010318C
		[Token(Token = "0x6002B2B")]
		[Address(RVA = "0x24C3F2C", Offset = "0x24C3F2C", VA = "0x24C3F2C")]
		private void ࡓێڴټ(PlayFabError ہ\u0613ܢ\u07B4)
		{
			if (!true)
			{
			}
			Debug.Log(ہ\u0613ܢ\u07B4);
			BuyCosmetic[] و_u06DBچ_u064D = this.و\u06DBچ\u064D;
			if (و_u06DBچ_u064D == null)
			{
				return;
			}
			float ݶՈהՇ = و_u06DBچ_u064D.ݶՈהՇ;
			if (ہ\u0613ܢ\u07B4.Error == PlayFabErrorCode.Success)
			{
			}
			Debug.Log("Player");
			Debug.Log(ہ\u0613ܢ\u07B4.GenerateErrorReport());
			Dictionary<string, List<string>> errorDetails = ہ\u0613ܢ\u07B4.ErrorDetails;
			ThrowHelper.ThrowArgumentOutOfRangeException();
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			DateTime d;
			double totalHours = (DateTime.Now - d).TotalHours;
			GameObject u082A_u083Dڻԥ = this.\u082A\u083Dڻԥ;
			long num = 1L;
			this.خࡩՈӣ = (num != 0L);
			this.Լ\u05C9\u065F߅ = totalHours;
			long active = 1L;
			u082A_u083Dڻԥ.SetActive(active != 0L);
			TextMeshPro u059A٣_u05C0_u = this.\u059A٣\u05C0\u0745;
			string[] values = new string[4];
			if ("All audio clips have been played." != null)
			{
				if ("All audio clips have been played." != null)
				{
					return;
				}
				throw new ArrayTypeMismatchException();
			}
			else
			{
				string text;
				if (text != null && text == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if ("Charged!" != null)
				{
					return;
				}
				if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if ("Round end" != null)
				{
					if ("Round end" != null)
					{
						return;
					}
					throw new ArrayTypeMismatchException();
				}
				else
				{
					string text2 = string.Concat(values);
					ThrowHelper.ThrowArgumentOutOfRangeException();
					if ("Player" == null)
					{
					}
					string message;
					Debug.Log(message);
					TextMeshPro u059A٣_u05C0_u2 = this.\u059A٣\u05C0\u0745;
					string[] values2 = new string[6];
					if (" " != null)
					{
						if (" " != null)
						{
							return;
						}
						throw new ArrayTypeMismatchException();
					}
					else
					{
						string text3;
						if (text3 != null && text3 == null)
						{
							throw new ArrayTypeMismatchException();
						}
						if ("FingerTip" != null)
						{
							if ("FingerTip" != null)
							{
								return;
							}
							throw new ArrayTypeMismatchException();
						}
						else
						{
							if ("FingerTip" == null)
							{
								throw new IndexOutOfRangeException();
							}
							if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
							{
								throw new ArrayTypeMismatchException();
							}
							if ("{0} ({1})" == null)
							{
								string text4 = string.Concat(values2);
								ThrowHelper.ThrowArgumentOutOfRangeException();
								if ("isLava" == null)
								{
								}
								string message2;
								Debug.Log(message2);
								GameObject ߪ_u0597ډӜ = this.ߪ\u0597ډӜ;
								if (typeof(UnityEngine.Object).TypeHandle == null)
								{
								}
								UnityEngine.Object.Destroy(ߪ_u0597ډӜ);
								UnityEngine.Object.Destroy(this.ى\u05B1ߖ\u082D);
								UnityEngine.Object.Destroy(this.٤چԊߤ);
								return;
							}
							if ("{0} ({1})" != null)
							{
								return;
							}
							throw new ArrayTypeMismatchException();
						}
					}
				}
			}
		}

		// Token: 0x06002B2C RID: 11052 RVA: 0x00105258 File Offset: 0x00103458
		[Token(Token = "0x6002B2C")]
		[Address(RVA = "0x24C48F8", Offset = "0x24C48F8", VA = "0x24C48F8")]
		public void ߍࠑչר()
		{
			LoginManager.كݕ\u05F3\u0589 = this;
			this.ۀ\u0885ࠔխ();
		}

		// Token: 0x06002B2D RID: 11053 RVA: 0x00105274 File Offset: 0x00103474
		[Token(Token = "0x6002B2D")]
		[Address(RVA = "0x24C4954", Offset = "0x24C4954", VA = "0x24C4954")]
		private void ݺӇݪࡃ(Message Ҿࠐ\u0708ࡂ)
		{
			if (Ҿࠐ\u0708ࡂ != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06002B2E RID: 11054 RVA: 0x001052A4 File Offset: 0x001034A4
		[Token(Token = "0x6002B2E")]
		[Address(RVA = "0x24C4AD0", Offset = "0x24C4AD0", VA = "0x24C4AD0")]
		private void \u05ACչڱܞ(Message Ҿࠐ\u0708ࡂ)
		{
			if (Ҿࠐ\u0708ࡂ != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06002B2F RID: 11055 RVA: 0x001052D4 File Offset: 0x001034D4
		[Token(Token = "0x6002B2F")]
		[Address(RVA = "0x24C4C4C", Offset = "0x24C4C4C", VA = "0x24C4C4C")]
		private void Յռսع(LoginResult ւݍ\u05BA\u05FA)
		{
			string playFabId = ւݍ\u05BA\u05FA.PlayFabId;
			this.ګ١կ\u0875 = playFabId;
			GetPhotonAuthenticationTokenRequest getPhotonAuthenticationTokenRequest = new GetPhotonAuthenticationTokenRequest();
			if ("\ud9c0\udc00" == null)
			{
			}
			string appIdRealtime = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime;
			getPhotonAuthenticationTokenRequest.PhotonApplicationId = appIdRealtime;
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B30 RID: 11056 RVA: 0x00105324 File Offset: 0x00103524
		[Token(Token = "0x6002B30")]
		[Address(RVA = "0x24C283C", Offset = "0x24C283C", VA = "0x24C283C")]
		public void آ\u0618ؽ\u05EC()
		{
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool flag = PhotonNetwork.ConnectUsingSettings();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Player");
		}

		// Token: 0x06002B31 RID: 11057 RVA: 0x00105354 File Offset: 0x00103554
		[Token(Token = "0x6002B31")]
		[Address(RVA = "0x24C4E10", Offset = "0x24C4E10", VA = "0x24C4E10")]
		public void ך\u06EB\u055Fه()
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Trying Getting Entilement...");
			if (typeof(Core).TypeHandle == null)
			{
			}
			Message.Callback callback;
			Request request = Entitlements.IsUserEntitledToApplication().OnComplete(callback);
		}

		// Token: 0x06002B32 RID: 11058 RVA: 0x001053AC File Offset: 0x001035AC
		[Token(Token = "0x6002B32")]
		[Address(RVA = "0x24C5020", Offset = "0x24C5020", VA = "0x24C5020", Slot = "31")]
		public override void OnLeftRoom()
		{
			long num = 1L;
			base.OnLeftRoom();
			if (num == 0L)
			{
			}
			Photon.Realtime.Room currentRoom = PhotonNetwork.CurrentRoom;
			ExitGames.Client.Photon.Hashtable customProperties = currentRoom.customProperties;
			if (currentRoom == null)
			{
			}
			Debug.Log("Left a room");
			if (this.\u07FB\u065Fࡄߑ)
			{
				Photon.Realtime.Room currentRoom2 = PhotonNetwork.CurrentRoom;
			}
			GameObject ڰ_u07B2Ӳٱ = this.ڰ\u07B2Ӳٱ;
			long active = 1L;
			ڰ_u07B2Ӳٱ.SetActive(active != 0L);
			GameObject u05B0Ӯࡄ_u055E = this.\u05B0Ӯࡄ\u055E;
			long active2 = 1L;
			u05B0Ӯࡄ_u055E.SetActive(active2 != 0L);
			RendererDisable ߝ_u0891_u05C5ӯ = this.ߝ\u0891\u05C5ӯ;
		}

		// Token: 0x06002B33 RID: 11059 RVA: 0x00105428 File Offset: 0x00103628
		[Token(Token = "0x6002B33")]
		[Address(RVA = "0x24C51FC", Offset = "0x24C51FC", VA = "0x24C51FC")]
		private void ٱӗԏ\u0881(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			List<ItemInstance> inventory = ޅࢶ\u05F3ܪ.Inventory;
			this.\u0738ؿࠇؠ = inventory;
			DynamicCosmetics.ލ\u0882ײࢲ.\u085E\u06FDݾհ();
		}

		// Token: 0x06002B34 RID: 11060 RVA: 0x00105454 File Offset: 0x00103654
		[Token(Token = "0x6002B34")]
		[Address(RVA = "0x24C5278", Offset = "0x24C5278", VA = "0x24C5278")]
		public void ࢪ\u0618\u08B5\u0878()
		{
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool flag = PhotonNetwork.ConnectUsingSettings();
			if (typeof(Debug).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B35 RID: 11061 RVA: 0x00105478 File Offset: 0x00103678
		[Token(Token = "0x6002B35")]
		[Address(RVA = "0x24C5320", Offset = "0x24C5320", VA = "0x24C5320")]
		private void ߖ\u0839ܬؠ(PlayFabError ہ\u0613ܢ\u07B4)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log(ہ\u0613ܢ\u07B4);
			BuyCosmetic[] و_u06DBچ_u064D = this.و\u06DBچ\u064D;
			float ݶՈהՇ = و_u06DBچ_u064D.ݶՈהՇ;
			float ݶՈהՇ2 = و_u06DBچ_u064D.ݶՈהՇ;
			PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("2BN");
			Debug.Log(ہ\u0613ܢ\u07B4.GenerateErrorReport());
			Dictionary<string, List<string>> errorDetails = ہ\u0613ܢ\u07B4.ErrorDetails;
			ThrowHelper.ThrowArgumentOutOfRangeException();
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			DateTime d;
			double totalHours = (DateTime.Now - d).TotalHours;
			GameObject u082A_u083Dڻԥ = this.\u082A\u083Dڻԥ;
			this.Լ\u05C9\u065F߅ = totalHours;
			long active = 0L;
			u082A_u083Dڻԥ.SetActive(active != 0L);
			TextMeshPro u059A٣_u05C0_u = this.\u059A٣\u05C0\u0745;
			string[] values = new string[6];
			if ("PlayerHead" != null)
			{
				if ("PlayerHead" != null)
				{
					return;
				}
				throw new ArrayTypeMismatchException();
			}
			else
			{
				if ("PlayerHead" == null)
				{
					throw new IndexOutOfRangeException();
				}
				string text;
				if (text != null && text == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if ("EnableCosmetic" != null)
				{
					if ("EnableCosmetic" != null)
					{
						return;
					}
					throw new ArrayTypeMismatchException();
				}
				else
				{
					if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
					{
						throw new ArrayTypeMismatchException();
					}
					if ("Round end" != null)
					{
						if ("Round end" != null)
						{
							return;
						}
						throw new ArrayTypeMismatchException();
					}
					else
					{
						string text2 = string.Concat(values);
						ThrowHelper.ThrowArgumentOutOfRangeException();
						if (typeof(Debug).TypeHandle == null)
						{
						}
						TextMeshPro u059A٣_u05C0_u2 = this.\u059A٣\u05C0\u0745;
						string[] array = new string[6];
						if ("Not connected to room" != null)
						{
							if ("Not connected to room" != null)
							{
								return;
							}
							throw new ArrayTypeMismatchException();
						}
						else
						{
							if ("Not connected to room" == null)
							{
								throw new IndexOutOfRangeException();
							}
							string text3;
							if (text3 != null && text3 == null)
							{
								throw new ArrayTypeMismatchException();
							}
							if ("Reason: " != null)
							{
								if ("Reason: " != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
							else
							{
								if ("Reason: " == null)
								{
									throw new IndexOutOfRangeException();
								}
								if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
								{
									throw new ArrayTypeMismatchException();
								}
								if ("_Tint" == null)
								{
									string text4 = string.Concat(values);
									ThrowHelper.ThrowArgumentOutOfRangeException();
									if (typeof(Debug).TypeHandle == null)
									{
									}
									string message;
									Debug.Log(message);
									GameObject ߪ_u0597ډӜ = this.ߪ\u0597ډӜ;
									if (typeof(UnityEngine.Object).TypeHandle == null)
									{
									}
									UnityEngine.Object.Destroy(ߪ_u0597ډӜ);
									UnityEngine.Object.Destroy(this.ى\u05B1ߖ\u082D);
									UnityEngine.Object.Destroy(this.٤چԊߤ);
									return;
								}
								if ("_Tint" != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
						}
					}
				}
			}
		}

		// Token: 0x06002B36 RID: 11062 RVA: 0x00105760 File Offset: 0x00103960
		[Token(Token = "0x6002B36")]
		[Address(RVA = "0x24C5D0C", Offset = "0x24C5D0C", VA = "0x24C5D0C")]
		private void \u0885\u0711ٸ\u0889(PlayFabError ہ\u0613ܢ\u07B4)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log(ہ\u0613ܢ\u07B4);
			BuyCosmetic[] و_u06DBچ_u064D = this.و\u06DBچ\u064D;
			if (و_u06DBچ_u064D == null)
			{
				return;
			}
			float ݶՈהՇ = و_u06DBچ_u064D.ݶՈהՇ;
			PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log(ہ\u0613ܢ\u07B4.GenerateErrorReport());
			Dictionary<string, List<string>> errorDetails = ہ\u0613ܢ\u07B4.ErrorDetails;
			ThrowHelper.ThrowArgumentOutOfRangeException();
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			DateTime d;
			double totalHours = (DateTime.Now - d).TotalHours;
			GameObject u082A_u083Dڻԥ = this.\u082A\u083Dڻԥ;
			this.Լ\u05C9\u065F߅ = totalHours;
			long active = 0L;
			u082A_u083Dڻԥ.SetActive(active != 0L);
			TextMeshPro u059A٣_u05C0_u = this.\u059A٣\u05C0\u0745;
			string[] values = new string[4];
			if ("Not enough amount of currency" != null)
			{
				if ("Not enough amount of currency" != null)
				{
					return;
				}
				throw new ArrayTypeMismatchException();
			}
			else
			{
				string text;
				if (text != null && text == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if ("Skelechin" != null)
				{
					if ("Skelechin" != null)
					{
						return;
					}
					throw new ArrayTypeMismatchException();
				}
				else
				{
					if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
					{
						throw new ArrayTypeMismatchException();
					}
					if ("Player" != null)
					{
						if ("Player" != null)
						{
							return;
						}
						throw new ArrayTypeMismatchException();
					}
					else
					{
						string text2 = string.Concat(values);
						ThrowHelper.ThrowArgumentOutOfRangeException();
						if (typeof(Debug).TypeHandle == null)
						{
						}
						string message;
						Debug.Log(message);
						TextMeshPro u059A٣_u05C0_u2 = this.\u059A٣\u05C0\u0745;
						if ("Player" != null)
						{
							if ("Player" != null)
							{
								return;
							}
							throw new ArrayTypeMismatchException();
						}
						else
						{
							string text3;
							if (text3 != null && text3 == null)
							{
								throw new ArrayTypeMismatchException();
							}
							if ("isLava" != null)
							{
								if ("isLava" != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
							else
							{
								if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
								{
									throw new ArrayTypeMismatchException();
								}
								if ("All audio clips have been played." == null)
								{
									ThrowHelper.ThrowArgumentOutOfRangeException();
									if (typeof(Debug).TypeHandle == null)
									{
									}
									string message2;
									Debug.Log(message2);
									GameObject ߪ_u0597ډӜ = this.ߪ\u0597ډӜ;
									if (typeof(UnityEngine.Object).TypeHandle == null)
									{
									}
									UnityEngine.Object.Destroy(ߪ_u0597ډӜ);
									UnityEngine.Object.Destroy(this.ى\u05B1ߖ\u082D);
									UnityEngine.Object.Destroy(this.٤چԊߤ);
									return;
								}
								if ("All audio clips have been played." != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
						}
					}
				}
			}
		}

		// Token: 0x06002B37 RID: 11063 RVA: 0x00105A10 File Offset: 0x00103C10
		[Token(Token = "0x6002B37")]
		[Address(RVA = "0x24C66DC", Offset = "0x24C66DC", VA = "0x24C66DC")]
		public void ܪ\u07BB\u086Bࠆ()
		{
			if (this.خࡩՈӣ)
			{
				double լ_u05C9_u065F߅ = this.Լ\u05C9\u065F߅;
				float deltaTime = Time.deltaTime;
				this.Լ\u05C9\u065F߅ = (double)deltaTime;
			}
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool inRoom = PhotonNetwork.InRoom;
			NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
			if (networkPlayerSpawner.\u05C4ࡑڍۺ)
			{
				RendererDisable component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<RendererDisable>();
				this.ߝ\u0891\u05C5ӯ = component;
				IntPtr cachedPtr = this.m_CachedPtr;
				float deltaTime2 = Time.deltaTime;
			}
		}

		// Token: 0x06002B38 RID: 11064 RVA: 0x00105A8C File Offset: 0x00103C8C
		[Token(Token = "0x6002B38")]
		[Address(RVA = "0x24C67C8", Offset = "0x24C67C8", VA = "0x24C67C8")]
		public void \u0530\u05FDސ\u07B0()
		{
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B39 RID: 11065 RVA: 0x00105AA0 File Offset: 0x00103CA0
		[Token(Token = "0x6002B39")]
		[Address(RVA = "0x24C691C", Offset = "0x24C691C", VA = "0x24C691C")]
		public void \u0617\u0897\u087C\u0616()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B3A RID: 11066 RVA: 0x00105ABC File Offset: 0x00103CBC
		[Token(Token = "0x6002B3A")]
		[Address(RVA = "0x24C6A70", Offset = "0x24C6A70", VA = "0x24C6A70")]
		public void Awake()
		{
			LoginManager.كݕ\u05F3\u0589 = this;
			this.ך\u06EB\u055Fه();
		}

		// Token: 0x06002B3B RID: 11067 RVA: 0x00105AD8 File Offset: 0x00103CD8
		[Token(Token = "0x6002B3B")]
		[Address(RVA = "0x24C6ACC", Offset = "0x24C6ACC", VA = "0x24C6ACC")]
		public void Ҿࢹؼס()
		{
			if (this.خࡩՈӣ)
			{
				double լ_u05C9_u065F߅ = this.Լ\u05C9\u065F߅;
				float deltaTime = Time.deltaTime;
				this.Լ\u05C9\u065F߅ = (double)deltaTime;
			}
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool inRoom = PhotonNetwork.InRoom;
			NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
			if (networkPlayerSpawner.\u05C4ࡑڍۺ)
			{
				RendererDisable component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<RendererDisable>();
				this.ߝ\u0891\u05C5ӯ = component;
				IntPtr cachedPtr = this.m_CachedPtr;
				float deltaTime2 = Time.deltaTime;
			}
		}

		// Token: 0x06002B3C RID: 11068 RVA: 0x00105B54 File Offset: 0x00103D54
		[Token(Token = "0x6002B3C")]
		[Address(RVA = "0x24C6BB8", Offset = "0x24C6BB8", VA = "0x24C6BB8")]
		public void Ӛ۹\u055Aࡁ()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (LoginManager.<>c.<>9__59_1 == null)
			{
				Action<PlayFabError> <>9__59_;
				LoginManager.<>c.<>9__59_1 = <>9__59_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B3D RID: 11069 RVA: 0x00105B7C File Offset: 0x00103D7C
		[Token(Token = "0x6002B3D")]
		[Address(RVA = "0x24C6D84", Offset = "0x24C6D84", VA = "0x24C6D84")]
		public void ݑࢬ\u081Dڏ()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (LoginManager.<>c.<>9__59_1 == null)
			{
				Action<PlayFabError> <>9__59_;
				LoginManager.<>c.<>9__59_1 = <>9__59_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B3E RID: 11070 RVA: 0x00105BA4 File Offset: 0x00103DA4
		[Token(Token = "0x6002B3E")]
		[Address(RVA = "0x24C6F50", Offset = "0x24C6F50", VA = "0x24C6F50")]
		public void \u05A9ըկڲ()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B3F RID: 11071 RVA: 0x00105BC0 File Offset: 0x00103DC0
		[Token(Token = "0x6002B3F")]
		[Address(RVA = "0x24C70A4", Offset = "0x24C70A4", VA = "0x24C70A4")]
		public void ࡍޕݾܘ()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (LoginManager.<>c.<>9__59_1 == null)
			{
				Action<PlayFabError> <>9__59_;
				LoginManager.<>c.<>9__59_1 = <>9__59_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B40 RID: 11072 RVA: 0x00105BE8 File Offset: 0x00103DE8
		[Token(Token = "0x6002B40")]
		[Address(RVA = "0x24C7270", Offset = "0x24C7270", VA = "0x24C7270")]
		private void \u06E1ԅވݜ(PlayFabError ہ\u0613ܢ\u07B4)
		{
			Debug.LogError(ہ\u0613ܢ\u07B4.GenerateErrorReport());
		}

		// Token: 0x06002B41 RID: 11073 RVA: 0x00105C08 File Offset: 0x00103E08
		[Token(Token = "0x6002B41")]
		[Address(RVA = "0x24C72F0", Offset = "0x24C72F0", VA = "0x24C72F0")]
		private void ࠇ\u07A8חӣ(Message<User> ࡒ۷\u0731ݕ)
		{
			Request<OrgScopedID> request2;
			Message<OrgScopedID>.Callback callback;
			Request<OrgScopedID> request = request2.OnComplete(callback);
		}

		// Token: 0x06002B42 RID: 11074 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x6002B42")]
		[Address(RVA = "0x24C7480", Offset = "0x24C7480", VA = "0x24C7480")]
		public void Update()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002B43 RID: 11075 RVA: 0x00105C3C File Offset: 0x00103E3C
		[Token(Token = "0x6002B43")]
		[Address(RVA = "0x24C756C", Offset = "0x24C756C", VA = "0x24C756C")]
		private void \u05A4ݢ\u070Aݖ(Message<User> ࡒ۷\u0731ݕ)
		{
		}

		// Token: 0x06002B44 RID: 11076 RVA: 0x00105C68 File Offset: 0x00103E68
		[Token(Token = "0x6002B44")]
		[Address(RVA = "0x24C76FC", Offset = "0x24C76FC", VA = "0x24C76FC")]
		private void \u055D\u0590շގ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			Debug.Log("tutorialCheck");
			Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
			string u06D6_u0595ڤ_u073C = this.\u06D6\u0595ڤ\u073C;
			this.Bananas = virtualCurrency;
			if (typeof(Math).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B45 RID: 11077 RVA: 0x00105D40 File Offset: 0x00103F40
		[Token(Token = "0x6002B45")]
		[Address(RVA = "0x24C7A84", Offset = "0x24C7A84", VA = "0x24C7A84")]
		public void \u07F2߂ނ\u083F()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B46 RID: 11078 RVA: 0x00105D5C File Offset: 0x00103F5C
		[Token(Token = "0x6002B46")]
		[Address(RVA = "0x24BF2C4", Offset = "0x24BF2C4", VA = "0x24BF2C4")]
		public IEnumerator \u06E0\u055Cӓߩ()
		{
			long <>1__state;
			LoginManager.ޢࢣށࠕ ޢࢣށࠕ = new LoginManager.ޢࢣށࠕ((int)<>1__state);
			<>1__state = 0L;
			ޢࢣށࠕ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002B47 RID: 11079 RVA: 0x00105D80 File Offset: 0x00103F80
		[Token(Token = "0x6002B47")]
		[Address(RVA = "0x24C7BD8", Offset = "0x24C7BD8", VA = "0x24C7BD8")]
		private void \u07F1ԯ\u05CAࠁ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			List<ItemInstance> inventory = ޅࢶ\u05F3ܪ.Inventory;
			this.\u0738ؿࠇؠ = inventory;
			DynamicCosmetics.ލ\u0882ײࢲ.ࡉ\u0700ޣՔ();
		}

		// Token: 0x06002B48 RID: 11080 RVA: 0x00105DAC File Offset: 0x00103FAC
		[Token(Token = "0x6002B48")]
		[Address(RVA = "0x24C7C54", Offset = "0x24C7C54", VA = "0x24C7C54")]
		private void ܤ\u088C\u066Bփ(GetTitleDataResult ޅࢶ\u05F3ܪ)
		{
			Dictionary<string, string> data = ޅࢶ\u05F3ܪ.Data;
			this.\u0888\u07F1\u0873ۇ = data;
			string version = UnityEngine.Application.version;
			string u0888_u07F1_u0873ۇ = this.\u0888\u07F1\u0873ۇ;
			bool flag = version != u0888_u07F1_u0873ۇ;
			GameObject ӂ_u05FFՂ_u065F = this.ӂ\u05FFՂ\u065F;
			long active = 0L;
			ӂ_u05FFՂ_u065F.SetActive(active != 0L);
			TextMeshPro textMeshPro = this.ߢصջո;
			string[] values = new string[5];
			if ("gameMode" != null)
			{
				if ("gameMode" != null)
				{
					return;
				}
			}
			else
			{
				string version2 = UnityEngine.Application.version;
				if (version2 == null || version2 != null)
				{
					if ("CapuchinStore" != null)
					{
						if ("CapuchinStore" != null)
						{
							return;
						}
					}
					else if ("On" != null)
					{
						if ("On" != null)
						{
							return;
						}
					}
					else
					{
						string text = string.Concat(values);
						this.ڇ\u05AAקࡇ();
						string[] values2 = new string[6];
						if ("FingerTip" != null)
						{
							if ("FingerTip" != null)
							{
								return;
							}
						}
						else
						{
							string version3 = UnityEngine.Application.version;
							if (version3 == null || version3 != null)
							{
								if ("You are on an outdated version of Capuchin. Your version is " != null)
								{
									if ("You are on an outdated version of Capuchin. Your version is " != null)
									{
										return;
									}
								}
								else
								{
									if ("Joined a Room." == null)
									{
										Debug.LogError(string.Concat(values2));
										return;
									}
									if ("Joined a Room." != null)
									{
										return;
									}
								}
							}
						}
					}
				}
			}
			throw new ArrayTypeMismatchException();
		}

		// Token: 0x06002B49 RID: 11081 RVA: 0x00105ED8 File Offset: 0x001040D8
		[Token(Token = "0x6002B49")]
		[Address(RVA = "0x24C80D4", Offset = "0x24C80D4", VA = "0x24C80D4")]
		private void ݭ\u05B8ࡕ\u060B(PlayFabError ہ\u0613ܢ\u07B4)
		{
			Debug.LogError(ہ\u0613ܢ\u07B4.GenerateErrorReport());
		}

		// Token: 0x06002B4A RID: 11082 RVA: 0x00105EF8 File Offset: 0x001040F8
		[Token(Token = "0x6002B4A")]
		[Address(RVA = "0x24C8154", Offset = "0x24C8154", VA = "0x24C8154")]
		public void \u061B\u05EEوۈ()
		{
			if (true)
			{
				float deltaTime = Time.deltaTime;
			}
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool inRoom = PhotonNetwork.InRoom;
			float deltaTime2 = Time.deltaTime;
		}

		// Token: 0x06002B4B RID: 11083 RVA: 0x00105F30 File Offset: 0x00104130
		[Token(Token = "0x6002B4B")]
		[Address(RVA = "0x24C8240", Offset = "0x24C8240", VA = "0x24C8240")]
		private void אܒ\u0738\u07B8(Message Ҿࠐ\u0708ࡂ)
		{
			bool isError = Ҿࠐ\u0708ࡂ.IsError;
			if (Ҿࠐ\u0708ࡂ != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06002B4C RID: 11084 RVA: 0x00105F64 File Offset: 0x00104164
		[Token(Token = "0x6002B4C")]
		[Address(RVA = "0x24BF21C", Offset = "0x24BF21C", VA = "0x24BF21C")]
		public void Ӎ\u05C2ࢩԁ()
		{
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool flag = PhotonNetwork.ConnectUsingSettings();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Try Connect To Server...");
		}

		// Token: 0x06002B4D RID: 11085 RVA: 0x00105F94 File Offset: 0x00104194
		[Token(Token = "0x6002B4D")]
		[Address(RVA = "0x24C83BC", Offset = "0x24C83BC", VA = "0x24C83BC")]
		private void ڂ\u0830ܥӃ(GetPhotonAuthenticationTokenResult ւݍ\u05BA\u05FA)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("NoseAttachPoint");
			AuthenticationValues authValues = new AuthenticationValues();
			string ګ١կ_u = this.ګ١կ\u0875;
			string photonCustomAuthenticationToken = ւݍ\u05BA\u05FA.PhotonCustomAuthenticationToken;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.AuthValues = authValues;
			GetTitleNewsRequest getTitleNewsRequest = new GetTitleNewsRequest();
			TextureSwap ټ_u06E4_u055F_u087D = this.ټ\u06E4\u055F\u087D;
			long enabled = 1L;
			ټ_u06E4_u055F_u087D.enabled = (enabled != 0L);
			GameObject u0820ۮӺܦ = this.\u0820ۮӺܦ;
			long active = 1L;
			u0820ۮӺܦ.SetActive(active != 0L);
			GameObject ծܮ_u0874_u05F = this.ծܮ\u0874\u05F9;
			long active2 = 0L;
			ծܮ_u0874_u05F.SetActive(active2 != 0L);
			this.ࡍޕݾܘ();
			this.آ\u0618ؽ\u05EC();
			IEnumerator routine = this.\u06E0\u055Cӓߩ();
			Coroutine coroutine = base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("User has been reported for: ");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if ("User has been reported for: " == null)
			{
			}
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B4E RID: 11086 RVA: 0x00106088 File Offset: 0x00104288
		[Token(Token = "0x6002B4E")]
		[Address(RVA = "0x24C887C", Offset = "0x24C887C", VA = "0x24C887C")]
		private void \u0655ԝղߣ(Message<User> ࡒ۷\u0731ݕ)
		{
			Request<OrgScopedID> request2;
			Message<OrgScopedID>.Callback callback;
			Request<OrgScopedID> request = request2.OnComplete(callback);
		}

		// Token: 0x06002B4F RID: 11087 RVA: 0x001060BC File Offset: 0x001042BC
		[Token(Token = "0x6002B4F")]
		[Address(RVA = "0x24C8A0C", Offset = "0x24C8A0C", VA = "0x24C8A0C")]
		private void Ӂ\u0700\u0651\u05CC(GetPhotonAuthenticationTokenResult ւݍ\u05BA\u05FA)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("MetaId");
			AuthenticationValues authenticationValues = new AuthenticationValues();
			long authType = 1L;
			authenticationValues.authType = (CustomAuthenticationType)authType;
			string ګ١կ_u = this.ګ١կ\u0875;
			string photonCustomAuthenticationToken = ւݍ\u05BA\u05FA.PhotonCustomAuthenticationToken;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.AuthValues = authenticationValues;
			GetTitleNewsRequest getTitleNewsRequest = new GetTitleNewsRequest();
			TextureSwap ټ_u06E4_u055F_u087D = this.ټ\u06E4\u055F\u087D;
			long enabled = 0L;
			ټ_u06E4_u055F_u087D.enabled = (enabled != 0L);
			GameObject u0820ۮӺܦ = this.\u0820ۮӺܦ;
			long active = 0L;
			u0820ۮӺܦ.SetActive(active != 0L);
			GameObject ծܮ_u0874_u05F = this.ծܮ\u0874\u05F9;
			long active2 = 1L;
			ծܮ_u0874_u05F.SetActive(active2 != 0L);
			this.Ӈ\u0885\u0559ه();
			this.آ\u0618ؽ\u05EC();
			IEnumerator routine = this.\u06E0\u055Cӓߩ();
			Coroutine coroutine = base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("FingerTip");
			if ("FingerTip" == null)
			{
			}
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B50 RID: 11088 RVA: 0x001061B0 File Offset: 0x001043B0
		[Token(Token = "0x6002B50")]
		[Address(RVA = "0x24C8ED0", Offset = "0x24C8ED0", VA = "0x24C8ED0")]
		public void ۆ\u05C8خ\u0612()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B51 RID: 11089 RVA: 0x001061CC File Offset: 0x001043CC
		[Token(Token = "0x6002B51")]
		[Address(RVA = "0x24C9024", Offset = "0x24C9024", VA = "0x24C9024")]
		public void \u073Aڝձ\u0823()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if ("fr-FR" == null)
			{
			}
		}

		// Token: 0x06002B52 RID: 11090 RVA: 0x001061E8 File Offset: 0x001043E8
		[Token(Token = "0x6002B52")]
		[Address(RVA = "0x24C9178", Offset = "0x24C9178", VA = "0x24C9178")]
		public void \u0831\u0830ࡎө()
		{
			GetTitleDataRequest getTitleDataRequest = new GetTitleDataRequest();
			List<string> keys = new List();
			getTitleDataRequest.Keys = keys;
			if (LoginManager.<>c.<>9__56_1 == null)
			{
				Action<PlayFabError> <>9__56_;
				LoginManager.<>c.<>9__56_1 = <>9__56_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B53 RID: 11091 RVA: 0x00106224 File Offset: 0x00104424
		[Token(Token = "0x6002B53")]
		[Address(RVA = "0x24C93D4", Offset = "0x24C93D4", VA = "0x24C93D4")]
		public void \u07EE\u07EDߧխ()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (LoginManager.<>c.<>9__59_1 == null)
			{
				Action<PlayFabError> <>9__59_;
				LoginManager.<>c.<>9__59_1 = <>9__59_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B54 RID: 11092 RVA: 0x0010624C File Offset: 0x0010444C
		[Token(Token = "0x6002B54")]
		[Address(RVA = "0x24C95A0", Offset = "0x24C95A0", VA = "0x24C95A0")]
		private void վ\u07F5\u06EA\u059F(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("You are on an outdated version of Capuchin. Your version is ");
			Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
			string u06D6_u0595ڤ_u073C = this.\u06D6\u0595ڤ\u073C;
			this.Bananas = virtualCurrency;
			if (typeof(Math).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B55 RID: 11093 RVA: 0x0010632C File Offset: 0x0010452C
		[Token(Token = "0x6002B55")]
		[Address(RVA = "0x24C9928", Offset = "0x24C9928", VA = "0x24C9928")]
		private void \u0816ظ\u07B6ޤ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Update User Inventory");
			Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
			string u06D6_u0595ڤ_u073C = this.\u06D6\u0595ڤ\u073C;
			this.Bananas = virtualCurrency;
			if (typeof(Math).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B56 RID: 11094 RVA: 0x00106410 File Offset: 0x00104610
		[Token(Token = "0x6002B56")]
		[Address(RVA = "0x24C9CF4", Offset = "0x24C9CF4", VA = "0x24C9CF4")]
		public void ١\u0899\u0598Գ()
		{
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool flag = PhotonNetwork.ConnectUsingSettings();
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Room1");
		}

		// Token: 0x06002B57 RID: 11095 RVA: 0x00106440 File Offset: 0x00104640
		[Token(Token = "0x6002B57")]
		[Address(RVA = "0x24C9D9C", Offset = "0x24C9D9C", VA = "0x24C9D9C", Slot = "45")]
		public override void OnConnectedToMaster()
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Connected to Server.");
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool flag = PhotonNetwork.JoinLobby();
		}

		// Token: 0x06002B58 RID: 11096 RVA: 0x00106470 File Offset: 0x00104670
		[Token(Token = "0x6002B58")]
		[Address(RVA = "0x24C9E44", Offset = "0x24C9E44", VA = "0x24C9E44")]
		private void տԃ\u0656٣(PlayFabError ہ\u0613ܢ\u07B4)
		{
			if (!true)
			{
			}
			Debug.Log(ہ\u0613ܢ\u07B4);
			BuyCosmetic[] و_u06DBچ_u064D = this.و\u06DBچ\u064D;
			if (و_u06DBچ_u064D == null)
			{
				return;
			}
			float ݶՈהՇ = و_u06DBچ_u064D.ݶՈהՇ;
			if (ہ\u0613ܢ\u07B4.Error == PlayFabErrorCode.Success)
			{
			}
			Debug.Log("true");
			Debug.Log(ہ\u0613ܢ\u07B4.GenerateErrorReport());
			Dictionary<string, List<string>> errorDetails = ہ\u0613ܢ\u07B4.ErrorDetails;
			ThrowHelper.ThrowArgumentOutOfRangeException();
			if (typeof(DateTime).TypeHandle == null)
			{
			}
			DateTime d;
			double totalHours = (DateTime.Now - d).TotalHours;
			GameObject u082A_u083Dڻԥ = this.\u082A\u083Dڻԥ;
			long num = 1L;
			this.خࡩՈӣ = (num != 0L);
			this.Լ\u05C9\u065F߅ = totalHours;
			long active = 1L;
			u082A_u083Dڻԥ.SetActive(active != 0L);
			TextMeshPro u059A٣_u05C0_u = this.\u059A٣\u05C0\u0745;
			string[] values = new string[1];
			if ("Players Online: " != null)
			{
				if ("Players Online: " != null)
				{
					return;
				}
				throw new ArrayTypeMismatchException();
			}
			else
			{
				string text;
				if (text != null && text == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if ("Bare Torso" != null)
				{
					if ("Bare Torso" != null)
					{
						return;
					}
					throw new ArrayTypeMismatchException();
				}
				else
				{
					if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
					{
						throw new ArrayTypeMismatchException();
					}
					if ("ErrorScreen" != null)
					{
						if ("ErrorScreen" != null)
						{
							return;
						}
						throw new ArrayTypeMismatchException();
					}
					else
					{
						string text2 = string.Concat(values);
						ThrowHelper.ThrowArgumentOutOfRangeException();
						if ("username" == null)
						{
						}
						string message;
						Debug.Log(message);
						TextMeshPro u059A٣_u05C0_u2 = this.\u059A٣\u05C0\u0745;
						string[] values2 = new string[6];
						if ("Regular" != null)
						{
							if ("Regular" != null)
							{
								return;
							}
							throw new ArrayTypeMismatchException();
						}
						else
						{
							if ("Regular" == null)
							{
								throw new IndexOutOfRangeException();
							}
							string text3;
							if (text3 != null && text3 == null)
							{
								throw new ArrayTypeMismatchException();
							}
							if ("Tagging" != null)
							{
								if ("Tagging" != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
							else
							{
								if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
								{
									throw new ArrayTypeMismatchException();
								}
								if ("hand 1" == null)
								{
									string text4 = string.Concat(values2);
									ThrowHelper.ThrowArgumentOutOfRangeException();
									if ("Try Connect To Server..." == null)
									{
									}
									string message2;
									Debug.Log(message2);
									GameObject ߪ_u0597ډӜ = this.ߪ\u0597ډӜ;
									if (typeof(UnityEngine.Object).TypeHandle == null)
									{
									}
									UnityEngine.Object.Destroy(ߪ_u0597ډӜ);
									UnityEngine.Object.Destroy(this.ى\u05B1ߖ\u082D);
									UnityEngine.Object.Destroy(this.٤چԊߤ);
									return;
								}
								if ("hand 1" != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
						}
					}
				}
			}
		}

		// Token: 0x06002B59 RID: 11097 RVA: 0x00106748 File Offset: 0x00104948
		[Token(Token = "0x6002B59")]
		[Address(RVA = "0x24CA80C", Offset = "0x24CA80C", VA = "0x24CA80C")]
		private void ښۀؿ\u0659(GetPhotonAuthenticationTokenResult ւݍ\u05BA\u05FA)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("All audio clips have been played.");
			AuthenticationValues authValues = new AuthenticationValues();
			string ګ١կ_u = this.ګ١կ\u0875;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.AuthValues = authValues;
			GetTitleNewsRequest getTitleNewsRequest = new GetTitleNewsRequest();
			TextureSwap ټ_u06E4_u055F_u087D = this.ټ\u06E4\u055F\u087D;
			long enabled = 0L;
			ټ_u06E4_u055F_u087D.enabled = (enabled != 0L);
			GameObject u0820ۮӺܦ = this.\u0820ۮӺܦ;
			long active = 0L;
			u0820ۮӺܦ.SetActive(active != 0L);
			GameObject ծܮ_u0874_u05F = this.ծܮ\u0874\u05F9;
			long active2 = 0L;
			ծܮ_u0874_u05F.SetActive(active2 != 0L);
			this.ղגՂێ();
			this.١\u0899\u0598Գ();
			IEnumerator routine = this.\u073A\u0590Ӎࡢ();
			Coroutine coroutine = base.StartCoroutine(routine);
			string @string = PlayerPrefs.GetString("Diffuse");
			if ("Diffuse" == null)
			{
			}
			if (LoginManager.<>c.<>9__49_0 == null)
			{
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_;
				LoginManager.<>c.<>9__49_1 = <>9__49_;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B5A RID: 11098 RVA: 0x0010681C File Offset: 0x00104A1C
		[Token(Token = "0x6002B5A")]
		[Address(RVA = "0x24CACCC", Offset = "0x24CACCC", VA = "0x24CACCC")]
		private void م\u07ECࠌࢤ(ulong خҽ\u0831۶, ulong ٧ۅ\u083Dݼ, string \u07F8\u0707ݿޢ)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string str;
			string customId = "Player" + str;
			loginWithCustomIDRequest.CustomId = customId;
			Dictionary<string, string> customTags;
			loginWithCustomIDRequest.CustomTags = customTags;
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			BuyCosmetic[] و_u06DBچ_u064D = UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
			this.و\u06DBچ\u064D = و_u06DBچ_u064D;
		}

		// Token: 0x06002B5B RID: 11099 RVA: 0x00106870 File Offset: 0x00104A70
		[Token(Token = "0x6002B5B")]
		[Address(RVA = "0x24CAFC8", Offset = "0x24CAFC8", VA = "0x24CAFC8")]
		private void \u07BA\u074C\u07F6ז(ulong خҽ\u0831۶, ulong ٧ۅ\u083Dݼ, string \u07F8\u0707ݿޢ)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string str;
			string customId = "Toxicity" + str;
			loginWithCustomIDRequest.CustomId = customId;
			Dictionary<string, string> customTags;
			loginWithCustomIDRequest.CustomTags = customTags;
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			BuyCosmetic[] و_u06DBچ_u064D = UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
			this.و\u06DBچ\u064D = و_u06DBچ_u064D;
		}

		// Token: 0x06002B5C RID: 11100 RVA: 0x001068C4 File Offset: 0x00104AC4
		[Token(Token = "0x6002B5C")]
		[Address(RVA = "0x24CB2C4", Offset = "0x24CB2C4", VA = "0x24CB2C4")]
		private void ڈ\u0600އػ(GetPhotonAuthenticationTokenResult ւݍ\u05BA\u05FA)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("On");
			AuthenticationValues authValues = new AuthenticationValues();
			string ګ١կ_u = this.ګ١կ\u0875;
			string photonCustomAuthenticationToken = ւݍ\u05BA\u05FA.PhotonCustomAuthenticationToken;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.AuthValues = authValues;
			GetTitleNewsRequest getTitleNewsRequest = new GetTitleNewsRequest();
			TextureSwap ټ_u06E4_u055F_u087D = this.ټ\u06E4\u055F\u087D;
			long enabled = 0L;
			ټ_u06E4_u055F_u087D.enabled = (enabled != 0L);
			GameObject u0820ۮӺܦ = this.\u0820ۮӺܦ;
			long active = 1L;
			u0820ۮӺܦ.SetActive(active != 0L);
			GameObject ծܮ_u0874_u05F = this.ծܮ\u0874\u05F9;
			long active2 = 0L;
			ծܮ_u0874_u05F.SetActive(active2 != 0L);
			this.Ӈ\u0885\u0559ه();
			this.եԜӸڨ();
			IEnumerator routine = this.\u073A\u0590Ӎࡢ();
			Coroutine coroutine = base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("M/d/yyyy");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if ("M/d/yyyy" == null)
			{
			}
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				LoginManager.<>c <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B5D RID: 11101 RVA: 0x001069B8 File Offset: 0x00104BB8
		[Token(Token = "0x6002B5D")]
		[Address(RVA = "0x24CB784", Offset = "0x24CB784", VA = "0x24CB784")]
		public void ࢫ\u0876չՍ()
		{
			if (this.خࡩՈӣ)
			{
				double լ_u05C9_u065F߅ = this.Լ\u05C9\u065F߅;
				float deltaTime = Time.deltaTime;
				this.Լ\u05C9\u065F߅ = (double)deltaTime;
			}
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			bool inRoom = PhotonNetwork.InRoom;
			NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
			if (networkPlayerSpawner.\u05C4ࡑڍۺ)
			{
				RendererDisable component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<RendererDisable>();
				this.ߝ\u0891\u05C5ӯ = component;
				IntPtr cachedPtr = this.m_CachedPtr;
				float deltaTime2 = Time.deltaTime;
			}
		}

		// Token: 0x06002B5E RID: 11102 RVA: 0x00106A34 File Offset: 0x00104C34
		[Token(Token = "0x6002B5E")]
		[Address(RVA = "0x24CB870", Offset = "0x24CB870", VA = "0x24CB870")]
		private void ԡ\u07F9ࡖԧ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			List<ItemInstance> inventory = ޅࢶ\u05F3ܪ.Inventory;
			this.\u0738ؿࠇؠ = inventory;
			DynamicCosmetics.ލ\u0882ײࢲ.\u085E\u06FDݾհ();
		}

		// Token: 0x06002B5F RID: 11103 RVA: 0x00106A60 File Offset: 0x00104C60
		[Token(Token = "0x6002B5F")]
		[Address(RVA = "0x24BFD04", Offset = "0x24BFD04", VA = "0x24BFD04")]
		public void אԒ\u07F2\u086C()
		{
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.Disconnect();
			this.ئ\u0739ۄڎ();
		}

		// Token: 0x06002B60 RID: 11104 RVA: 0x00106A84 File Offset: 0x00104C84
		[Token(Token = "0x6002B60")]
		[Address(RVA = "0x24CB8EC", Offset = "0x24CB8EC", VA = "0x24CB8EC")]
		private void Ӿ\u05BEӃي(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("An error has occured while buying bananas, please restart your game and try again");
			Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
			string u06D6_u0595ڤ_u073C = this.\u06D6\u0595ڤ\u073C;
			this.Bananas = virtualCurrency;
			if (typeof(Math).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B61 RID: 11105 RVA: 0x00106B64 File Offset: 0x00104D64
		[Token(Token = "0x6002B61")]
		[Address(RVA = "0x24CBC98", Offset = "0x24CBC98", VA = "0x24CBC98")]
		private void \u0746ӵ\u06ECڂ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("isLava");
			Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
			string u06D6_u0595ڤ_u073C = this.\u06D6\u0595ڤ\u073C;
			this.Bananas = virtualCurrency;
			if (typeof(Math).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B62 RID: 11106 RVA: 0x00106C58 File Offset: 0x00104E58
		[Token(Token = "0x6002B62")]
		[Address(RVA = "0x24CC06C", Offset = "0x24CC06C", VA = "0x24CC06C")]
		private void ࡡՠކࢤ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			List<ItemInstance> inventory = ޅࢶ\u05F3ܪ.Inventory;
			this.\u0738ؿࠇؠ = inventory;
			DynamicCosmetics.ލ\u0882ײࢲ.\u085E\u06FDݾհ();
		}

		// Token: 0x06002B63 RID: 11107 RVA: 0x00106C84 File Offset: 0x00104E84
		[Token(Token = "0x6002B63")]
		[Address(RVA = "0x24CC0E8", Offset = "0x24CC0E8", VA = "0x24CC0E8")]
		private void \u066A\u0895Մݥ(GetPhotonAuthenticationTokenResult ւݍ\u05BA\u05FA)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Agreed");
			AuthenticationValues authenticationValues = new AuthenticationValues();
			long authType = 1L;
			authenticationValues.authType = (CustomAuthenticationType)authType;
			string ګ١կ_u = this.ګ١կ\u0875;
			string photonCustomAuthenticationToken = ւݍ\u05BA\u05FA.PhotonCustomAuthenticationToken;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			PhotonNetwork.AuthValues = authenticationValues;
			GetTitleNewsRequest getTitleNewsRequest = new GetTitleNewsRequest();
			TextureSwap ټ_u06E4_u055F_u087D = this.ټ\u06E4\u055F\u087D;
			long enabled = 0L;
			ټ_u06E4_u055F_u087D.enabled = (enabled != 0L);
			GameObject u0820ۮӺܦ = this.\u0820ۮӺܦ;
			long active = 1L;
			u0820ۮӺܦ.SetActive(active != 0L);
			GameObject ծܮ_u0874_u05F = this.ծܮ\u0874\u05F9;
			long active2 = 0L;
			ծܮ_u0874_u05F.SetActive(active2 != 0L);
			this.ݑࢬ\u081Dڏ();
			this.١\u0899\u0598Գ();
			IEnumerator enumerator = this.\u073A\u0590Ӎࡢ();
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n");
			this.Ӣڇפԩ = @string;
			if ("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n" == null)
			{
			}
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
			if (typeof(LoginManager.<>c).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B64 RID: 11108 RVA: 0x00106D78 File Offset: 0x00104F78
		[Token(Token = "0x6002B64")]
		[Address(RVA = "0x24CC5AC", Offset = "0x24CC5AC", VA = "0x24CC5AC")]
		private void \u073AݯՊڐ(GetTitleNewsResult ޅࢶ\u05F3ܪ)
		{
			bool flag = ޅࢶ\u05F3ܪ.News.GetEnumerator().MoveNext();
		}

		// Token: 0x06002B65 RID: 11109 RVA: 0x00106DAC File Offset: 0x00104FAC
		[Token(Token = "0x6002B65")]
		[Address(RVA = "0x24CC70C", Offset = "0x24CC70C", VA = "0x24CC70C")]
		private void \u05A1\u0739ӯն(PlayFabError ہ\u0613ܢ\u07B4)
		{
			if (!true)
			{
			}
			Debug.Log(ہ\u0613ܢ\u07B4);
			BuyCosmetic[] و_u06DBچ_u064D = this.و\u06DBچ\u064D;
			float ݶՈהՇ = و_u06DBچ_u064D.ݶՈהՇ;
			float ݶՈהՇ2 = و_u06DBچ_u064D.ݶՈהՇ;
			if (ہ\u0613ܢ\u07B4.Error == PlayFabErrorCode.Success)
			{
			}
			Debug.Log("Left a room");
			Debug.Log(ہ\u0613ܢ\u07B4.GenerateErrorReport());
			Dictionary<string, List<string>> errorDetails = ہ\u0613ܢ\u07B4.ErrorDetails;
			ThrowHelper.ThrowArgumentOutOfRangeException();
			DateTime d;
			double totalHours = (DateTime.Now - d).TotalHours;
			GameObject u082A_u083Dڻԥ = this.\u082A\u083Dڻԥ;
			long num = 1L;
			this.خࡩՈӣ = (num != 0L);
			this.Լ\u05C9\u065F߅ = totalHours;
			long active = 0L;
			u082A_u083Dڻԥ.SetActive(active != 0L);
			TextMeshPro u059A٣_u05C0_u = this.\u059A٣\u05C0\u0745;
			string[] values = new string[0];
			if ("ChangeToRegular" != null)
			{
				if ("ChangeToRegular" != null)
				{
					return;
				}
				throw new ArrayTypeMismatchException();
			}
			else
			{
				string text;
				if (text != null && text == null)
				{
					throw new ArrayTypeMismatchException();
				}
				if ("Player" != null)
				{
					if ("Player" != null)
					{
						return;
					}
					throw new ArrayTypeMismatchException();
				}
				else
				{
					if (و_u06DBچ_u064D != null)
					{
					}
					if ("CapuchinStore" != null)
					{
						if ("CapuchinStore" != null)
						{
							return;
						}
						throw new ArrayTypeMismatchException();
					}
					else
					{
						string text2 = string.Concat(values);
						ThrowHelper.ThrowArgumentOutOfRangeException();
						if (" " == null)
						{
						}
						string message;
						Debug.Log(message);
						string[] values2 = new string[2];
						if ("True" != null)
						{
							if ("True" != null)
							{
								return;
							}
							throw new ArrayTypeMismatchException();
						}
						else
						{
							if ("True" == null)
							{
								throw new IndexOutOfRangeException();
							}
							string text3;
							if (text3 != null && text3 == null)
							{
								throw new ArrayTypeMismatchException();
							}
							if ("Failed to get catalog, cosmetic name, and price. Exact error details is: " != null)
							{
								if ("Failed to get catalog, cosmetic name, and price. Exact error details is: " != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
							else
							{
								if (و_u06DBچ_u064D != null && و_u06DBچ_u064D == null)
								{
									throw new ArrayTypeMismatchException();
								}
								if ("Date: " == null)
								{
									string text4 = string.Concat(values2);
									ThrowHelper.ThrowArgumentOutOfRangeException();
									if ("User has been reported for: " == null)
									{
									}
									string message2;
									Debug.Log(message2);
									if (typeof(UnityEngine.Object).TypeHandle == null)
									{
									}
									return;
								}
								if ("Date: " != null)
								{
									return;
								}
								throw new ArrayTypeMismatchException();
							}
						}
					}
				}
			}
		}

		// Token: 0x06002B66 RID: 11110 RVA: 0x00107020 File Offset: 0x00105220
		[Token(Token = "0x6002B66")]
		[Address(RVA = "0x24CD138", Offset = "0x24CD138", VA = "0x24CD138")]
		private void ބࠆؤ\u089A(GetTitleNewsResult ޅࢶ\u05F3ܪ)
		{
			bool flag = ޅࢶ\u05F3ܪ.News.GetEnumerator().MoveNext();
		}

		// Token: 0x06002B67 RID: 11111 RVA: 0x00107054 File Offset: 0x00105254
		[Token(Token = "0x6002B67")]
		[Address(RVA = "0x24CD298", Offset = "0x24CD298", VA = "0x24CD298")]
		private void ӛ\u05BEࡠ߇(ulong خҽ\u0831۶, ulong ٧ۅ\u083Dݼ, string \u07F8\u0707ݿޢ)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string str;
			string customId = "gamemode" + str;
			loginWithCustomIDRequest.CustomId = customId;
			Dictionary<string, string> customTags;
			loginWithCustomIDRequest.CustomTags = customTags;
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			BuyCosmetic[] و_u06DBچ_u064D = UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
			this.و\u06DBچ\u064D = و_u06DBچ_u064D;
		}

		// Token: 0x06002B68 RID: 11112 RVA: 0x001070A8 File Offset: 0x001052A8
		[Token(Token = "0x6002B68")]
		[Address(RVA = "0x24CD594", Offset = "0x24CD594", VA = "0x24CD594")]
		private void ԃ\u0824غג(PlayFabError ہ\u0613ܢ\u07B4)
		{
			Debug.LogError(ہ\u0613ܢ\u07B4.GenerateErrorReport());
		}

		// Token: 0x06002B69 RID: 11113 RVA: 0x001070C8 File Offset: 0x001052C8
		[Token(Token = "0x6002B69")]
		[Address(RVA = "0x24CD614", Offset = "0x24CD614", VA = "0x24CD614")]
		public void օࠌԌլ()
		{
			if ("\ud9c0\udc00" == null)
			{
			}
			PhotonNetwork.Disconnect();
			this.ئ\u0739ۄڎ();
		}

		// Token: 0x06002B6A RID: 11114 RVA: 0x001070EC File Offset: 0x001052EC
		[Token(Token = "0x6002B6A")]
		[Address(RVA = "0x24CD67C", Offset = "0x24CD67C", VA = "0x24CD67C", Slot = "43")]
		public override void OnPlayerLeftRoom(Player ݑڋۋӈ)
		{
			Debug.Log("A Player has left the Room.");
			base.OnPlayerLeftRoom(ݑڋۋӈ);
		}

		// Token: 0x06002B6B RID: 11115 RVA: 0x0010710C File Offset: 0x0010530C
		[Token(Token = "0x6002B6B")]
		[Address(RVA = "0x24C2670", Offset = "0x24C2670", VA = "0x24C2670")]
		public void Ӈ\u0885\u0559ه()
		{
			GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
			if (LoginManager.<>c.<>9__59_1 == null)
			{
				Action<PlayFabError> <>9__59_;
				LoginManager.<>c.<>9__59_1 = <>9__59_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B6C RID: 11116 RVA: 0x00107134 File Offset: 0x00105334
		[Token(Token = "0x6002B6C")]
		[Address(RVA = "0x24CD710", Offset = "0x24CD710", VA = "0x24CD710")]
		private void \u05EEݿ߅ؤ(ulong خҽ\u0831۶, ulong ٧ۅ\u083Dݼ, string \u07F8\u0707ݿޢ)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string str;
			string customId = "Added Winner Money" + str;
			loginWithCustomIDRequest.CustomId = customId;
			Dictionary<string, string> customTags;
			loginWithCustomIDRequest.CustomTags = customTags;
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
			if (typeof(UnityEngine.Object).TypeHandle == null)
			{
			}
			BuyCosmetic[] و_u06DBچ_u064D = UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
			this.و\u06DBچ\u064D = و_u06DBچ_u064D;
		}

		// Token: 0x06002B6D RID: 11117 RVA: 0x00107188 File Offset: 0x00105388
		[Token(Token = "0x6002B6D")]
		[Address(RVA = "0x24CDA0C", Offset = "0x24CDA0C", VA = "0x24CDA0C")]
		private void \u06E1\u0590\u07BC\u07B8(Message Ҿࠐ\u0708ࡂ)
		{
			bool isError = Ҿࠐ\u0708ࡂ.IsError;
			if (Ҿࠐ\u0708ࡂ != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06002B6E RID: 11118 RVA: 0x001071BC File Offset: 0x001053BC
		[Token(Token = "0x6002B6E")]
		[Address(RVA = "0x24CDB88", Offset = "0x24CDB88", VA = "0x24CDB88")]
		private void ࡨ\u0730\u07BFՠ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("PRESS AGAIN TO CONFIRM");
			Dictionary<string, int> virtualCurrency = ޅࢶ\u05F3ܪ.VirtualCurrency;
			string u06D6_u0595ڤ_u073C = this.\u06D6\u0595ڤ\u073C;
			this.Bananas = virtualCurrency;
			if (typeof(Math).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B6F RID: 11119 RVA: 0x001072A8 File Offset: 0x001054A8
		[Token(Token = "0x6002B6F")]
		[Address(RVA = "0x24CDF44", Offset = "0x24CDF44", VA = "0x24CDF44")]
		[CompilerGenerated]
		private void ࢲۓ\u0837ץ(Message<User> ࡒ۷\u0731ݕ)
		{
		}

		// Token: 0x06002B70 RID: 11120 RVA: 0x001072D0 File Offset: 0x001054D0
		[Token(Token = "0x6002B70")]
		[Address(RVA = "0x24CE0DC", Offset = "0x24CE0DC", VA = "0x24CE0DC")]
		public void \u0877۷\u05AEك()
		{
			GetTitleDataRequest getTitleDataRequest = new GetTitleDataRequest();
			List<string> keys = new List();
			getTitleDataRequest.Keys = keys;
			if (LoginManager.<>c.<>9__56_1 == null)
			{
				Action<PlayFabError> <>9__56_;
				LoginManager.<>c.<>9__56_1 = <>9__56_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x06002B71 RID: 11121 RVA: 0x0010730C File Offset: 0x0010550C
		[Token(Token = "0x6002B71")]
		[Address(RVA = "0x24CE338", Offset = "0x24CE338", VA = "0x24CE338")]
		public IEnumerator \u0608ح\u0870ش()
		{
			long <>1__state;
			LoginManager.ޢࢣށࠕ ޢࢣށࠕ = new LoginManager.ޢࢣށࠕ((int)<>1__state);
			<>1__state = 0L;
			ޢࢣށࠕ.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002B72 RID: 11122 RVA: 0x00107330 File Offset: 0x00105530
		[Token(Token = "0x6002B72")]
		[Address(RVA = "0x24CE3B0", Offset = "0x24CE3B0", VA = "0x24CE3B0")]
		private void \u0743տޛי(GetTitleNewsResult ޅࢶ\u05F3ܪ)
		{
			bool flag = ޅࢶ\u05F3ܪ.News.GetEnumerator().MoveNext();
		}

		// Token: 0x06002B73 RID: 11123 RVA: 0x00107364 File Offset: 0x00105564
		[Token(Token = "0x6002B73")]
		[Address(RVA = "0x24CE510", Offset = "0x24CE510", VA = "0x24CE510")]
		public void \u07FEݏ\u05C9ٺ()
		{
			GetTitleDataRequest getTitleDataRequest = new GetTitleDataRequest();
			List<string> list = new List();
			if (LoginManager.<>c.<>9__56_1 == null)
			{
				Action<PlayFabError> <>9__56_;
				LoginManager.<>c.<>9__56_1 = <>9__56_;
			}
			if (typeof(PlayFabClientAPI).TypeHandle == null)
			{
			}
		}

		// Token: 0x040005C7 RID: 1479
		[Token(Token = "0x40005C7")]
		public static LoginManager كݕ\u05F3\u0589;

		// Token: 0x040005C8 RID: 1480
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40005C8")]
		public TextMeshPro Ӣڇפԩ;

		// Token: 0x040005C9 RID: 1481
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40005C9")]
		public string \u085EՒ\u07B9ӕ;

		// Token: 0x040005CA RID: 1482
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40005CA")]
		public bool ؽܨ߆\u07B5;

		// Token: 0x040005CB RID: 1483
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40005CB")]
		private string ֆ\u081AܮԷ;

		// Token: 0x040005CC RID: 1484
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40005CC")]
		public Transform \u081B\u070Aߢࡁ;

		// Token: 0x040005CD RID: 1485
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x40005CD")]
		public Transform ݞ\u07BCݮࠆ;

		// Token: 0x040005CE RID: 1486
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x40005CE")]
		public TextMeshPro \u059A٣\u05C0\u0745;

		// Token: 0x040005CF RID: 1487
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x40005CF")]
		public GameObject \u082A\u083Dڻԥ;

		// Token: 0x040005D0 RID: 1488
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x40005D0")]
		public GameObject ߪ\u0597ډӜ;

		// Token: 0x040005D1 RID: 1489
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x40005D1")]
		public GameObject ى\u05B1ߖ\u082D;

		// Token: 0x040005D2 RID: 1490
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x40005D2")]
		public GameObject ٤چԊߤ;

		// Token: 0x040005D3 RID: 1491
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x40005D3")]
		private bool خࡩՈӣ;

		// Token: 0x040005D4 RID: 1492
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x40005D4")]
		private double Լ\u05C9\u065F߅;

		// Token: 0x040005D5 RID: 1493
		[FieldOffset(Offset = "0x88")]
		[Token(Token = "0x40005D5")]
		public TextMeshPro ٦\u07B5ցܮ;

		// Token: 0x040005D6 RID: 1494
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x40005D6")]
		public TextMeshPro \u085C\u070Fݠ\u087C;

		// Token: 0x040005D7 RID: 1495
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x40005D7")]
		[SerializeField]
		public int Bananas;

		// Token: 0x040005D8 RID: 1496
		[FieldOffset(Offset = "0x9C")]
		[Token(Token = "0x40005D8")]
		[SerializeField]
		public int Pebbles;

		// Token: 0x040005D9 RID: 1497
		[FieldOffset(Offset = "0xA0")]
		[Token(Token = "0x40005D9")]
		private BuyCosmetic[] و\u06DBچ\u064D;

		// Token: 0x040005DA RID: 1498
		[FieldOffset(Offset = "0xA8")]
		[Token(Token = "0x40005DA")]
		private bool Ԓտ\u0880ࡡ;

		// Token: 0x040005DB RID: 1499
		[FieldOffset(Offset = "0xB0")]
		[Token(Token = "0x40005DB")]
		public string \u06D6\u0595ڤ\u073C;

		// Token: 0x040005DC RID: 1500
		[FieldOffset(Offset = "0xB8")]
		[Token(Token = "0x40005DC")]
		public string \u05B4Ԁ\u07AD\u07B8;

		// Token: 0x040005DD RID: 1501
		[FieldOffset(Offset = "0xC0")]
		[Token(Token = "0x40005DD")]
		public GameObject ڰ\u07B2Ӳٱ;

		// Token: 0x040005DE RID: 1502
		[FieldOffset(Offset = "0xC8")]
		[Token(Token = "0x40005DE")]
		public GameObject \u05B0Ӯࡄ\u055E;

		// Token: 0x040005DF RID: 1503
		[FieldOffset(Offset = "0xD0")]
		[Token(Token = "0x40005DF")]
		public RendererDisable ߝ\u0891\u05C5ӯ;

		// Token: 0x040005E0 RID: 1504
		[FieldOffset(Offset = "0xD8")]
		[Token(Token = "0x40005E0")]
		public NetworkPlayerSpawner ߨאߨػ;

		// Token: 0x040005E1 RID: 1505
		[FieldOffset(Offset = "0xE0")]
		[Token(Token = "0x40005E1")]
		private float ֆԬذ\u086B;

		// Token: 0x040005E2 RID: 1506
		[FieldOffset(Offset = "0xE8")]
		[Token(Token = "0x40005E2")]
		public GameObject ߜסӷ\u05BF;

		// Token: 0x040005E3 RID: 1507
		[FieldOffset(Offset = "0xF0")]
		[Token(Token = "0x40005E3")]
		public Material ل\u06E7\u0739\u0604;

		// Token: 0x040005E4 RID: 1508
		[FieldOffset(Offset = "0xF8")]
		[Token(Token = "0x40005E4")]
		public Texture2D \u061D\u05BFࡪࡆ;

		// Token: 0x040005E5 RID: 1509
		[FieldOffset(Offset = "0x100")]
		[Token(Token = "0x40005E5")]
		public GameObject ծܮ\u0874\u05F9;

		// Token: 0x040005E6 RID: 1510
		[FieldOffset(Offset = "0x108")]
		[Token(Token = "0x40005E6")]
		public GameObject \u0820ۮӺܦ;

		// Token: 0x040005E7 RID: 1511
		[FieldOffset(Offset = "0x110")]
		[Token(Token = "0x40005E7")]
		public TextureSwap ټ\u06E4\u055F\u087D;

		// Token: 0x040005E8 RID: 1512
		[FieldOffset(Offset = "0x118")]
		[Token(Token = "0x40005E8")]
		public ulong ԧ\u06E2ҿ\u0738;

		// Token: 0x040005E9 RID: 1513
		[FieldOffset(Offset = "0x120")]
		[Token(Token = "0x40005E9")]
		public ulong ܯڮࡖו;

		// Token: 0x040005EA RID: 1514
		[FieldOffset(Offset = "0x128")]
		[Token(Token = "0x40005EA")]
		public string \u0888\u07F1\u0873ۇ;

		// Token: 0x040005EB RID: 1515
		[FieldOffset(Offset = "0x130")]
		[Token(Token = "0x40005EB")]
		public GameObject ӂ\u05FFՂ\u065F;

		// Token: 0x040005EC RID: 1516
		[FieldOffset(Offset = "0x138")]
		[Token(Token = "0x40005EC")]
		public TextMeshPro ߢصջո;

		// Token: 0x040005ED RID: 1517
		[FieldOffset(Offset = "0x140")]
		[Token(Token = "0x40005ED")]
		public string \u083F\u0616\u0597ߗ;

		// Token: 0x040005EE RID: 1518
		[FieldOffset(Offset = "0x148")]
		[Token(Token = "0x40005EE")]
		public string ҼՒԻܜ;

		// Token: 0x040005EF RID: 1519
		[FieldOffset(Offset = "0x150")]
		[Token(Token = "0x40005EF")]
		public openMenu ࠊ\u07F4ۇ۳;

		// Token: 0x040005F0 RID: 1520
		[FieldOffset(Offset = "0x158")]
		[Token(Token = "0x40005F0")]
		public bool \u07FB\u065Fࡄߑ;

		// Token: 0x040005F1 RID: 1521
		[FieldOffset(Offset = "0x160")]
		[Token(Token = "0x40005F1")]
		private string ګ١կ\u0875;

		// Token: 0x040005F2 RID: 1522
		[FieldOffset(Offset = "0x168")]
		[Token(Token = "0x40005F2")]
		public List<ItemInstance> \u0738ؿࠇؠ;

		// Token: 0x02000118 RID: 280
		[Token(Token = "0x2000118")]
		[CompilerGenerated]
		private sealed class ӑӱػՎ
		{
			// Token: 0x06002B74 RID: 11124 RVA: 0x00107398 File Offset: 0x00105598
			[Token(Token = "0x6002B74")]
			[Address(RVA = "0x2132CE4", Offset = "0x2132CE4", VA = "0x2132CE4")]
			public ӑӱػՎ()
			{
			}

			// Token: 0x06002B75 RID: 11125 RVA: 0x001073AC File Offset: 0x001055AC
			[Token(Token = "0x6002B75")]
			[Address(RVA = "0x2132CEC", Offset = "0x2132CEC", VA = "0x2132CEC")]
			internal void עԜ\u0652\u083E(Message<OrgScopedID> result)
			{
				LoginManager.ٱނߎմ ٱނߎմ = new LoginManager.ٱނߎմ();
				ٱނߎմ.CS$<>8__locals1 = this;
				ٱނߎմ.result = result;
				LoginManager loginManager = this.<>4__this;
				Message<UserProof>.Callback callback;
				Request<UserProof> request = Users.GetUserProof().OnComplete(callback);
			}

			// Token: 0x040005F3 RID: 1523
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x40005F3")]
			public Message<User> m;

			// Token: 0x040005F4 RID: 1524
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x40005F4")]
			public LoginManager <>4__this;
		}

		// Token: 0x02000119 RID: 281
		[Token(Token = "0x2000119")]
		[CompilerGenerated]
		private sealed class ٱނߎմ
		{
			// Token: 0x06002B76 RID: 11126 RVA: 0x001073EC File Offset: 0x001055EC
			[Token(Token = "0x6002B76")]
			[Address(RVA = "0x2132ED0", Offset = "0x2132ED0", VA = "0x2132ED0")]
			public ٱނߎմ()
			{
			}

			// Token: 0x06002B77 RID: 11127 RVA: 0x000028F3 File Offset: 0x00000AF3
			[Token(Token = "0x6002B77")]
			[Address(RVA = "0x2132ED8", Offset = "0x2132ED8", VA = "0x2132ED8")]
			internal void \u0600\u05FF\u07ECԚ(Message<UserProof> r)
			{
				throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
			}

			// Token: 0x040005F5 RID: 1525
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x40005F5")]
			public Message<OrgScopedID> result;

			// Token: 0x040005F6 RID: 1526
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x40005F6")]
			public LoginManager.ӑӱػՎ CS$<>8__locals1;
		}
	}
}
