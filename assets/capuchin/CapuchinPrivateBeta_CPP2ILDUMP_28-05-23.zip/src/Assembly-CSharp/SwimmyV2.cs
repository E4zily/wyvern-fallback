﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000043 RID: 67
[Token(Token = "0x2000043")]
public class SwimmyV2 : MonoBehaviour
{
	// Token: 0x06000929 RID: 2345 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000929")]
	[Address(RVA = "0x2F7CDFC", Offset = "0x2F7CDFC", VA = "0x2F7CDFC")]
	public void \u0879\u0748ߙݥ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600092A RID: 2346 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600092A")]
	[Address(RVA = "0x2F7D118", Offset = "0x2F7D118", VA = "0x2F7D118")]
	public void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600092B RID: 2347 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600092B")]
	[Address(RVA = "0x2F7D484", Offset = "0x2F7D484", VA = "0x2F7D484")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600092C RID: 2348 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600092C")]
	[Address(RVA = "0x2F7D7FC", Offset = "0x2F7D7FC", VA = "0x2F7D7FC")]
	public void ք\u05FEؽ\u061E(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600092D RID: 2349 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600092D")]
	[Address(RVA = "0x2F7DB18", Offset = "0x2F7DB18", VA = "0x2F7DB18")]
	public void ؽ\u058C\u05A6\u0871(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600092E RID: 2350 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600092E")]
	[Address(RVA = "0x2F7DE3C", Offset = "0x2F7DE3C", VA = "0x2F7DE3C")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600092F RID: 2351 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600092F")]
	[Address(RVA = "0x2F7E19C", Offset = "0x2F7E19C", VA = "0x2F7E19C")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000930 RID: 2352 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000930")]
	[Address(RVA = "0x2F7E4A4", Offset = "0x2F7E4A4", VA = "0x2F7E4A4")]
	public void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000931 RID: 2353 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000931")]
	[Address(RVA = "0x2F7E7C4", Offset = "0x2F7E7C4", VA = "0x2F7E7C4")]
	public void ٽ߆ࡑՄ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000932 RID: 2354 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000932")]
	[Address(RVA = "0x2F7EAE4", Offset = "0x2F7EAE4", VA = "0x2F7EAE4")]
	public void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000933 RID: 2355 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000933")]
	[Address(RVA = "0x2F7EE04", Offset = "0x2F7EE04", VA = "0x2F7EE04")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000934 RID: 2356 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000934")]
	[Address(RVA = "0x2F7F160", Offset = "0x2F7F160", VA = "0x2F7F160")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000935 RID: 2357 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000935")]
	[Address(RVA = "0x2F7F4B4", Offset = "0x2F7F4B4", VA = "0x2F7F4B4")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000936 RID: 2358 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000936")]
	[Address(RVA = "0x2F7F828", Offset = "0x2F7F828", VA = "0x2F7F828")]
	public void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000937 RID: 2359 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000937")]
	[Address(RVA = "0x2F7FB40", Offset = "0x2F7FB40", VA = "0x2F7FB40")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000938 RID: 2360 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000938")]
	[Address(RVA = "0x2F7FEB0", Offset = "0x2F7FEB0", VA = "0x2F7FEB0")]
	public void \u0872\u0610ۅ\u06E1(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000939 RID: 2361 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000939")]
	[Address(RVA = "0x2F801CC", Offset = "0x2F801CC", VA = "0x2F801CC")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600093A RID: 2362 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600093A")]
	[Address(RVA = "0x2F80540", Offset = "0x2F80540", VA = "0x2F80540")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600093B RID: 2363 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600093B")]
	[Address(RVA = "0x2F808B4", Offset = "0x2F808B4", VA = "0x2F808B4")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600093C RID: 2364 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600093C")]
	[Address(RVA = "0x2F80C20", Offset = "0x2F80C20", VA = "0x2F80C20")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600093D RID: 2365 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600093D")]
	[Address(RVA = "0x2F80F98", Offset = "0x2F80F98", VA = "0x2F80F98")]
	public void \u0748\u05F4Նۏ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600093E RID: 2366 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600093E")]
	[Address(RVA = "0x2F812B8", Offset = "0x2F812B8", VA = "0x2F812B8")]
	public void ؽܗӊә(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600093F RID: 2367 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600093F")]
	[Address(RVA = "0x2F815D4", Offset = "0x2F815D4", VA = "0x2F815D4")]
	public void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000940 RID: 2368 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000940")]
	[Address(RVA = "0x2F81940", Offset = "0x2F81940", VA = "0x2F81940")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000941 RID: 2369 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000941")]
	[Address(RVA = "0x2F81CB4", Offset = "0x2F81CB4", VA = "0x2F81CB4")]
	public void ىރ\u0704ݟ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000942 RID: 2370 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000942")]
	[Address(RVA = "0x2F81FD0", Offset = "0x2F81FD0", VA = "0x2F81FD0")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000943 RID: 2371 RVA: 0x000321C8 File Offset: 0x000303C8
	[Token(Token = "0x6000943")]
	[Address(RVA = "0x2F8233C", Offset = "0x2F8233C", VA = "0x2F8233C")]
	public SwimmyV2()
	{
	}

	// Token: 0x06000944 RID: 2372 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000944")]
	[Address(RVA = "0x2F82344", Offset = "0x2F82344", VA = "0x2F82344")]
	public void ࢳ\u06D8Ԙ\u05FD(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000945 RID: 2373 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000945")]
	[Address(RVA = "0x2F82664", Offset = "0x2F82664", VA = "0x2F82664")]
	public void \u0885ےܝ\u05BA(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000946 RID: 2374 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000946")]
	[Address(RVA = "0x2F82988", Offset = "0x2F82988", VA = "0x2F82988")]
	public void \u0872יԁӦ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000947 RID: 2375 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000947")]
	[Address(RVA = "0x2F82CA8", Offset = "0x2F82CA8", VA = "0x2F82CA8")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000948 RID: 2376 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000948")]
	[Address(RVA = "0x2F83014", Offset = "0x2F83014", VA = "0x2F83014")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000949 RID: 2377 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000949")]
	[Address(RVA = "0x2F8336C", Offset = "0x2F8336C", VA = "0x2F8336C")]
	public void \u0609ۯ\u05B4ؼ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600094A RID: 2378 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600094A")]
	[Address(RVA = "0x2F83680", Offset = "0x2F83680", VA = "0x2F83680")]
	public void ߂ڞ\u0600\u07FB(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600094B RID: 2379 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600094B")]
	[Address(RVA = "0x2F8399C", Offset = "0x2F8399C", VA = "0x2F8399C")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600094C RID: 2380 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600094C")]
	[Address(RVA = "0x2F83D0C", Offset = "0x2F83D0C", VA = "0x2F83D0C")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600094D RID: 2381 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600094D")]
	[Address(RVA = "0x2F8407C", Offset = "0x2F8407C", VA = "0x2F8407C")]
	public void ܫ\u085Eہӝ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600094E RID: 2382 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600094E")]
	[Address(RVA = "0x2F84398", Offset = "0x2F84398", VA = "0x2F84398")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600094F RID: 2383 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600094F")]
	[Address(RVA = "0x2F84704", Offset = "0x2F84704", VA = "0x2F84704")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000950 RID: 2384 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000950")]
	[Address(RVA = "0x2F84A74", Offset = "0x2F84A74", VA = "0x2F84A74")]
	public void \u083Eܙ\u07FD\u0706(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000951 RID: 2385 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000951")]
	[Address(RVA = "0x2F84D94", Offset = "0x2F84D94", VA = "0x2F84D94")]
	public void ߃\u0602\u0891߇(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000952 RID: 2386 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000952")]
	[Address(RVA = "0x2F850B8", Offset = "0x2F850B8", VA = "0x2F850B8")]
	public void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000953 RID: 2387 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000953")]
	[Address(RVA = "0x2F85428", Offset = "0x2F85428", VA = "0x2F85428")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000954 RID: 2388 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000954")]
	[Address(RVA = "0x2F85798", Offset = "0x2F85798", VA = "0x2F85798")]
	public void ߂ӹ\u05C6\u07F9(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000955 RID: 2389 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000955")]
	[Address(RVA = "0x2F85AA0", Offset = "0x2F85AA0", VA = "0x2F85AA0")]
	public void ލ\u0892\u064B\u055B(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000956 RID: 2390 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000956")]
	[Address(RVA = "0x2F85DC4", Offset = "0x2F85DC4", VA = "0x2F85DC4")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000957 RID: 2391 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000957")]
	[Address(RVA = "0x2F86124", Offset = "0x2F86124", VA = "0x2F86124")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000958 RID: 2392 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000958")]
	[Address(RVA = "0x2F86490", Offset = "0x2F86490", VA = "0x2F86490")]
	public void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000959 RID: 2393 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000959")]
	[Address(RVA = "0x2F867B0", Offset = "0x2F867B0", VA = "0x2F867B0")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x04000147 RID: 327
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000147")]
	public Rigidbody \u081B\u070Aߢࡁ;

	// Token: 0x04000148 RID: 328
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000148")]
	public Transform \u05B0ԔӍࡧ;

	// Token: 0x04000149 RID: 329
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000149")]
	public Rigidbody ࡇ\u0592\u07EE\u07F1;

	// Token: 0x0400014A RID: 330
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400014A")]
	public Rigidbody ގ\u05BE\u085DՇ;

	// Token: 0x0400014B RID: 331
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400014B")]
	public AudioLowPassFilter ٵގޕࡍ;

	// Token: 0x0400014C RID: 332
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400014C")]
	public bool \u0747ܩ\u06DDڥ;

	// Token: 0x0400014D RID: 333
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400014D")]
	public Transform ࠀԐڙ\u0828;

	// Token: 0x0400014E RID: 334
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400014E")]
	public Swimmy ڢݕڕ\u06E8;

	// Token: 0x0400014F RID: 335
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400014F")]
	public GameObject ࡗ\u0606ևӍ;

	// Token: 0x04000150 RID: 336
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000150")]
	public GameObject ࢤٮ\u0708ߕ;

	// Token: 0x04000151 RID: 337
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000151")]
	public GameObject ࡊ\u0826ށࢮ;

	// Token: 0x04000152 RID: 338
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000152")]
	public bool \u06E9Ӧڟࡎ;

	// Token: 0x04000153 RID: 339
	[FieldOffset(Offset = "0x71")]
	[Token(Token = "0x4000153")]
	public bool ܝ\u07BAԢԀ;

	// Token: 0x04000154 RID: 340
	[FieldOffset(Offset = "0x72")]
	[Token(Token = "0x4000154")]
	public bool צ\u0886٨ߤ;

	// Token: 0x04000155 RID: 341
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000155")]
	public GameObject ࢦޜࢰՉ;
}
