﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000019 RID: 25
[Token(Token = "0x2000019")]
public class EnableAndDisable : MonoBehaviour
{
	// Token: 0x0600034D RID: 845 RVA: 0x00014B4C File Offset: 0x00012D4C
	[Token(Token = "0x600034D")]
	[Address(RVA = "0x1D851B4", Offset = "0x1D851B4", VA = "0x1D851B4")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x0600034E RID: 846 RVA: 0x00014BB4 File Offset: 0x00012DB4
	[Token(Token = "0x600034E")]
	[Address(RVA = "0x1D85240", Offset = "0x1D85240", VA = "0x1D85240")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x0600034F RID: 847 RVA: 0x00014C1C File Offset: 0x00012E1C
	[Token(Token = "0x600034F")]
	[Address(RVA = "0x1D852CC", Offset = "0x1D852CC", VA = "0x1D852CC")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000350 RID: 848 RVA: 0x00014C70 File Offset: 0x00012E70
	[Token(Token = "0x6000350")]
	[Address(RVA = "0x1D85358", Offset = "0x1D85358", VA = "0x1D85358")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000351 RID: 849 RVA: 0x00014CD8 File Offset: 0x00012ED8
	[Token(Token = "0x6000351")]
	[Address(RVA = "0x1D853E4", Offset = "0x1D853E4", VA = "0x1D853E4")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000352 RID: 850 RVA: 0x00014D40 File Offset: 0x00012F40
	[Token(Token = "0x6000352")]
	[Address(RVA = "0x1D85470", Offset = "0x1D85470", VA = "0x1D85470")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000353 RID: 851 RVA: 0x00014D94 File Offset: 0x00012F94
	[Token(Token = "0x6000353")]
	[Address(RVA = "0x1D854FC", Offset = "0x1D854FC", VA = "0x1D854FC")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000354 RID: 852 RVA: 0x00014DFC File Offset: 0x00012FFC
	[Token(Token = "0x6000354")]
	[Address(RVA = "0x1D85588", Offset = "0x1D85588", VA = "0x1D85588")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000355 RID: 853 RVA: 0x00014E64 File Offset: 0x00013064
	[Token(Token = "0x6000355")]
	[Address(RVA = "0x1D85614", Offset = "0x1D85614", VA = "0x1D85614")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000356 RID: 854 RVA: 0x00014ECC File Offset: 0x000130CC
	[Token(Token = "0x6000356")]
	[Address(RVA = "0x1D856A0", Offset = "0x1D856A0", VA = "0x1D856A0")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000357 RID: 855 RVA: 0x00014F34 File Offset: 0x00013134
	[Token(Token = "0x6000357")]
	[Address(RVA = "0x1D8572C", Offset = "0x1D8572C", VA = "0x1D8572C")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000358 RID: 856 RVA: 0x00014F9C File Offset: 0x0001319C
	[Token(Token = "0x6000358")]
	[Address(RVA = "0x1D857B8", Offset = "0x1D857B8", VA = "0x1D857B8")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000359 RID: 857 RVA: 0x00015004 File Offset: 0x00013204
	[Token(Token = "0x6000359")]
	[Address(RVA = "0x1D85844", Offset = "0x1D85844", VA = "0x1D85844")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x0600035A RID: 858 RVA: 0x0001506C File Offset: 0x0001326C
	[Token(Token = "0x600035A")]
	[Address(RVA = "0x1D858D0", Offset = "0x1D858D0", VA = "0x1D858D0")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		bool ר߄_u05C4ԗ = this.ר߄\u05C4ԗ;
		GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
		long active = 0L;
		u05AA_u0730ߥה.SetActive(active != 0L);
		if (this.ר߄\u05C4ԗ)
		{
			return;
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x0600035B RID: 859 RVA: 0x000150D4 File Offset: 0x000132D4
	[Token(Token = "0x600035B")]
	[Address(RVA = "0x1D8595C", Offset = "0x1D8595C", VA = "0x1D8595C")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = base.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x0600035C RID: 860 RVA: 0x0001513C File Offset: 0x0001333C
	[Token(Token = "0x600035C")]
	[Address(RVA = "0x1D859E8", Offset = "0x1D859E8", VA = "0x1D859E8")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x0600035D RID: 861 RVA: 0x000151A4 File Offset: 0x000133A4
	[Token(Token = "0x600035D")]
	[Address(RVA = "0x1D85A74", Offset = "0x1D85A74", VA = "0x1D85A74")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x0600035E RID: 862 RVA: 0x0001520C File Offset: 0x0001340C
	[Token(Token = "0x600035E")]
	[Address(RVA = "0x1D85B00", Offset = "0x1D85B00", VA = "0x1D85B00")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x0600035F RID: 863 RVA: 0x00015274 File Offset: 0x00013474
	[Token(Token = "0x600035F")]
	[Address(RVA = "0x1D85B8C", Offset = "0x1D85B8C", VA = "0x1D85B8C")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000360 RID: 864 RVA: 0x000152DC File Offset: 0x000134DC
	[Token(Token = "0x6000360")]
	[Address(RVA = "0x1D85C18", Offset = "0x1D85C18", VA = "0x1D85C18")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = base.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000361 RID: 865 RVA: 0x00015344 File Offset: 0x00013544
	[Token(Token = "0x6000361")]
	[Address(RVA = "0x1D85CA4", Offset = "0x1D85CA4", VA = "0x1D85CA4")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000362 RID: 866 RVA: 0x000153AC File Offset: 0x000135AC
	[Token(Token = "0x6000362")]
	[Address(RVA = "0x1D85D30", Offset = "0x1D85D30", VA = "0x1D85D30")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000363 RID: 867 RVA: 0x00015414 File Offset: 0x00013614
	[Token(Token = "0x6000363")]
	[Address(RVA = "0x1D85DBC", Offset = "0x1D85DBC", VA = "0x1D85DBC")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000364 RID: 868 RVA: 0x0001547C File Offset: 0x0001367C
	[Token(Token = "0x6000364")]
	[Address(RVA = "0x1D85E48", Offset = "0x1D85E48", VA = "0x1D85E48")]
	public EnableAndDisable()
	{
	}

	// Token: 0x06000365 RID: 869 RVA: 0x00015490 File Offset: 0x00013690
	[Token(Token = "0x6000365")]
	[Address(RVA = "0x1D85E50", Offset = "0x1D85E50", VA = "0x1D85E50")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000366 RID: 870 RVA: 0x000154F8 File Offset: 0x000136F8
	[Token(Token = "0x6000366")]
	[Address(RVA = "0x1D85EDC", Offset = "0x1D85EDC", VA = "0x1D85EDC")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 1L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 0L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x06000367 RID: 871 RVA: 0x00015560 File Offset: 0x00013760
	[Token(Token = "0x6000367")]
	[Address(RVA = "0x1D85F68", Offset = "0x1D85F68", VA = "0x1D85F68")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GameObject u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long active = 0L;
			u05AA_u0730ߥה.SetActive(active != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GameObject u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long active2 = 1L;
		u05AA_u0730ߥה2.SetActive(active2 != 0L);
	}

	// Token: 0x04000069 RID: 105
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000069")]
	public bool ר߄\u05C4ԗ;

	// Token: 0x0400006A RID: 106
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400006A")]
	public GameObject \u05AA\u0730ߥה;

	// Token: 0x0400006B RID: 107
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400006B")]
	public string \u070FӏԊӏ;
}
