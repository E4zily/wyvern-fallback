﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using CapuchinPlayFab;
using Cpp2IlInjected;
using PlayFab;
using PlayFab.ClientModels;
using UnityEngine;

// Token: 0x020000D3 RID: 211
[Token(Token = "0x20000D3")]
public class PlayFabAccountItemChecker : MonoBehaviour
{
	// Token: 0x0600200A RID: 8202 RVA: 0x000A79A4 File Offset: 0x000A5BA4
	[Token(Token = "0x600200A")]
	[Address(RVA = "0x2997FEC", Offset = "0x2997FEC", VA = "0x2997FEC")]
	private IEnumerator ۂ\u0899ԗӳ()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 1L;
		ԑ_u0615_u0876ݒ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600200B RID: 8203 RVA: 0x000A79C8 File Offset: 0x000A5BC8
	[Token(Token = "0x600200B")]
	[Address(RVA = "0x2998064", Offset = "0x2998064", VA = "0x2998064")]
	private IEnumerator ٸߠ\u086Bࢰ()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 0L;
		ԑ_u0615_u0876ݒ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600200C RID: 8204 RVA: 0x000A79EC File Offset: 0x000A5BEC
	[Token(Token = "0x600200C")]
	[Address(RVA = "0x29980DC", Offset = "0x29980DC", VA = "0x29980DC")]
	private void ӳ\u0616ޤ\u0591(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		bool flag = ޅࢶ\u05F3ܪ.Inventory.GetEnumerator().MoveNext();
		string ص_u061D_u07AAڙ = this.ص\u061D\u07AAڙ;
		string ۍշ_u07FCࢬ = this.ۍշ\u07FCࢬ;
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		long active = 0L;
		ىպ߆_u.SetActive(active != 0L);
	}

	// Token: 0x0600200D RID: 8205 RVA: 0x000A7A48 File Offset: 0x000A5C48
	[Token(Token = "0x600200D")]
	[Address(RVA = "0x2998248", Offset = "0x2998248", VA = "0x2998248")]
	private IEnumerator \u07BEػ\u07EEڿ()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 0L;
		ԑ_u0615_u0876ݒ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600200E RID: 8206 RVA: 0x000A7A6C File Offset: 0x000A5C6C
	[Token(Token = "0x600200E")]
	[Address(RVA = "0x29982C0", Offset = "0x29982C0", VA = "0x29982C0")]
	private void ࡡԼԠ\u0651(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		bool flag = ޅࢶ\u05F3ܪ.Inventory.GetEnumerator().MoveNext();
		string ص_u061D_u07AAڙ = this.ص\u061D\u07AAڙ;
		string ۍշ_u07FCࢬ = this.ۍշ\u07FCࢬ;
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		long active = 0L;
		ىպ߆_u.SetActive(active != 0L);
	}

	// Token: 0x0600200F RID: 8207 RVA: 0x000A7AC4 File Offset: 0x000A5CC4
	[Token(Token = "0x600200F")]
	[Address(RVA = "0x299842C", Offset = "0x299842C", VA = "0x299842C")]
	public PlayFabAccountItemChecker()
	{
	}

	// Token: 0x06002010 RID: 8208 RVA: 0x000A7AD8 File Offset: 0x000A5CD8
	[Token(Token = "0x6002010")]
	[Address(RVA = "0x2998434", Offset = "0x2998434", VA = "0x2998434")]
	private void ܙݏݒ\u081D(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		bool flag = ޅࢶ\u05F3ܪ.Inventory.GetEnumerator().MoveNext();
		string ص_u061D_u07AAڙ = this.ص\u061D\u07AAڙ;
		string ۍշ_u07FCࢬ = this.ۍշ\u07FCࢬ;
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		long active = 0L;
		ىպ߆_u.SetActive(active != 0L);
	}

	// Token: 0x06002011 RID: 8209 RVA: 0x000A7B30 File Offset: 0x000A5D30
	[Token(Token = "0x6002011")]
	[Address(RVA = "0x29985A0", Offset = "0x29985A0", VA = "0x29985A0")]
	public void ࡇࡊݶ\u086D()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002012 RID: 8210 RVA: 0x000A7B4C File Offset: 0x000A5D4C
	[Token(Token = "0x6002012")]
	[Address(RVA = "0x29986F4", Offset = "0x29986F4", VA = "0x29986F4")]
	private IEnumerator صݪ\u0875ޞ()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 0L;
		ԑ_u0615_u0876ݒ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002013 RID: 8211 RVA: 0x000A7B70 File Offset: 0x000A5D70
	[Token(Token = "0x6002013")]
	[Address(RVA = "0x299876C", Offset = "0x299876C", VA = "0x299876C")]
	[CompilerGenerated]
	private void ۼ\u06D8\u0702ߐ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		bool flag = ޅࢶ\u05F3ܪ.Inventory.GetEnumerator().MoveNext();
		string ص_u061D_u07AAڙ = this.ص\u061D\u07AAڙ;
		string ۍշ_u07FCࢬ = this.ۍշ\u07FCࢬ;
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		long active = 1L;
		ىպ߆_u.SetActive(active != 0L);
	}

	// Token: 0x06002014 RID: 8212 RVA: 0x000A7BC8 File Offset: 0x000A5DC8
	[Token(Token = "0x6002014")]
	[Address(RVA = "0x29988D8", Offset = "0x29988D8", VA = "0x29988D8")]
	private void ࡌݖ\u070BԎ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		bool flag = ޅࢶ\u05F3ܪ.Inventory.GetEnumerator().MoveNext();
		string ۍշ_u07FCࢬ = this.ۍշ\u07FCࢬ;
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		long active = 1L;
		ىպ߆_u.SetActive(active != 0L);
	}

	// Token: 0x06002015 RID: 8213 RVA: 0x000A7C1C File Offset: 0x000A5E1C
	[Token(Token = "0x6002015")]
	[Address(RVA = "0x2998A44", Offset = "0x2998A44", VA = "0x2998A44")]
	public void ڄދւ\u088D()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002016 RID: 8214 RVA: 0x000A7C38 File Offset: 0x000A5E38
	[Token(Token = "0x6002016")]
	[Address(RVA = "0x2998B98", Offset = "0x2998B98", VA = "0x2998B98")]
	public void ߍࠑչר()
	{
		IEnumerator routine = this.\u06DFؿԷק();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002017 RID: 8215 RVA: 0x000A7C54 File Offset: 0x000A5E54
	[Token(Token = "0x6002017")]
	[Address(RVA = "0x2998C3C", Offset = "0x2998C3C", VA = "0x2998C3C")]
	private IEnumerator Ӿݬڌ\u07F3()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 0L;
		ԑ_u0615_u0876ݒ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002018 RID: 8216 RVA: 0x000A7C78 File Offset: 0x000A5E78
	[Token(Token = "0x6002018")]
	[Address(RVA = "0x2998CB4", Offset = "0x2998CB4", VA = "0x2998CB4")]
	public void ޟݔԈԭ()
	{
		IEnumerator routine = this.صݪ\u0875ޞ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002019 RID: 8217 RVA: 0x000A7C94 File Offset: 0x000A5E94
	[Token(Token = "0x6002019")]
	[Address(RVA = "0x2998CE0", Offset = "0x2998CE0", VA = "0x2998CE0")]
	[CompilerGenerated]
	private void ݘڴ\u07AA\u087F(PlayFabError ہ\u0613ܢ\u07B4)
	{
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(ىպ߆_u);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x0600201A RID: 8218 RVA: 0x000A7CCC File Offset: 0x000A5ECC
	[Token(Token = "0x600201A")]
	[Address(RVA = "0x2998D80", Offset = "0x2998D80", VA = "0x2998D80")]
	private void ܤلڀ\u0597(PlayFabError ہ\u0613ܢ\u07B4)
	{
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(ىպ߆_u);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x0600201B RID: 8219 RVA: 0x000A7D04 File Offset: 0x000A5F04
	[Token(Token = "0x600201B")]
	[Address(RVA = "0x2998E20", Offset = "0x2998E20", VA = "0x2998E20")]
	public void \u05A0ࢮݢ\u05EC()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600201C RID: 8220 RVA: 0x000A7D20 File Offset: 0x000A5F20
	[Token(Token = "0x600201C")]
	[Address(RVA = "0x2998F74", Offset = "0x2998F74", VA = "0x2998F74")]
	public void ٤\u0888ࡦ\u0702()
	{
		IEnumerator routine = this.\u059Fצփ\u05AE();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600201D RID: 8221 RVA: 0x000A7D3C File Offset: 0x000A5F3C
	[Token(Token = "0x600201D")]
	[Address(RVA = "0x2999018", Offset = "0x2999018", VA = "0x2999018")]
	private IEnumerator ڔӖӽԈ()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 0L;
		ԑ_u0615_u0876ݒ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600201E RID: 8222 RVA: 0x000A7D60 File Offset: 0x000A5F60
	[Token(Token = "0x600201E")]
	[Address(RVA = "0x2999090", Offset = "0x2999090", VA = "0x2999090")]
	public void Awake()
	{
		IEnumerator routine = this.Ӿݬڌ\u07F3();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600201F RID: 8223 RVA: 0x000A7D7C File Offset: 0x000A5F7C
	[Token(Token = "0x600201F")]
	[Address(RVA = "0x29990BC", Offset = "0x29990BC", VA = "0x29990BC")]
	public void ࠅӎן\u05EB()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002020 RID: 8224 RVA: 0x000A7D98 File Offset: 0x000A5F98
	[Token(Token = "0x6002020")]
	[Address(RVA = "0x2999210", Offset = "0x2999210", VA = "0x2999210")]
	public void \u0835\u0598ԑ\u0614()
	{
		IEnumerator routine = this.\u06DFؿԷק();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002021 RID: 8225 RVA: 0x000A7DB4 File Offset: 0x000A5FB4
	[Token(Token = "0x6002021")]
	[Address(RVA = "0x299923C", Offset = "0x299923C", VA = "0x299923C")]
	public void جߊߒף()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002022 RID: 8226 RVA: 0x000A7DD0 File Offset: 0x000A5FD0
	[Token(Token = "0x6002022")]
	[Address(RVA = "0x2999390", Offset = "0x2999390", VA = "0x2999390")]
	public void ߘ\u05AEԮ\u06DD()
	{
		IEnumerator routine = this.ڔӖӽԈ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002023 RID: 8227 RVA: 0x000A7DEC File Offset: 0x000A5FEC
	[Token(Token = "0x6002023")]
	[Address(RVA = "0x29993BC", Offset = "0x29993BC", VA = "0x29993BC")]
	private void ࢮޒԓࠔ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
		string ص_u061D_u07AAڙ = this.ص\u061D\u07AAڙ;
		string ۍշ_u07FCࢬ = this.ۍշ\u07FCࢬ;
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		long active = 1L;
		ىպ߆_u.SetActive(active != 0L);
	}

	// Token: 0x06002024 RID: 8228 RVA: 0x000A7E3C File Offset: 0x000A603C
	[Token(Token = "0x6002024")]
	[Address(RVA = "0x2999528", Offset = "0x2999528", VA = "0x2999528")]
	public void ח\u089B\u0655\u085B()
	{
		IEnumerator routine = this.ٸߠ\u086Bࢰ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002025 RID: 8229 RVA: 0x000A7E58 File Offset: 0x000A6058
	[Token(Token = "0x6002025")]
	[Address(RVA = "0x2999554", Offset = "0x2999554", VA = "0x2999554")]
	private void ԡՓӶӤ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(ىպ߆_u);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x06002026 RID: 8230 RVA: 0x000A7E90 File Offset: 0x000A6090
	[Token(Token = "0x6002026")]
	[Address(RVA = "0x29995F4", Offset = "0x29995F4", VA = "0x29995F4")]
	private void \u05BE\u0876\u0878ޠ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		bool flag = ޅࢶ\u05F3ܪ.Inventory.GetEnumerator().MoveNext();
		string ص_u061D_u07AAڙ = this.ص\u061D\u07AAڙ;
		string ۍշ_u07FCࢬ = this.ۍշ\u07FCࢬ;
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		long active = 1L;
		ىպ߆_u.SetActive(active != 0L);
	}

	// Token: 0x06002027 RID: 8231 RVA: 0x000A7EE8 File Offset: 0x000A60E8
	[Token(Token = "0x6002027")]
	[Address(RVA = "0x2999760", Offset = "0x2999760", VA = "0x2999760")]
	private IEnumerator تࠉכۀ()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 1L;
		ԑ_u0615_u0876ݒ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002028 RID: 8232 RVA: 0x000A7F0C File Offset: 0x000A610C
	[Token(Token = "0x6002028")]
	[Address(RVA = "0x29997D8", Offset = "0x29997D8", VA = "0x29997D8")]
	private IEnumerator سעմࢹ()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 0L;
		ԑ_u0615_u0876ݒ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002029 RID: 8233 RVA: 0x000A7F30 File Offset: 0x000A6130
	[Token(Token = "0x6002029")]
	[Address(RVA = "0x2999850", Offset = "0x2999850", VA = "0x2999850")]
	public void ߄\u07FBࡡ\u07AF()
	{
		IEnumerator routine = this.\u07BEػ\u07EEڿ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600202A RID: 8234 RVA: 0x000A7F4C File Offset: 0x000A614C
	[Token(Token = "0x600202A")]
	[Address(RVA = "0x299987C", Offset = "0x299987C", VA = "0x299987C")]
	private void ࡢݓח\u066A(PlayFabError ہ\u0613ܢ\u07B4)
	{
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(ىպ߆_u);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x0600202B RID: 8235 RVA: 0x000A7F84 File Offset: 0x000A6184
	[Token(Token = "0x600202B")]
	[Address(RVA = "0x299991C", Offset = "0x299991C", VA = "0x299991C")]
	private void ۯࡒ\u0836Հ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(ىպ߆_u);
		PlayFabErrorCode error = ہ\u0613ܢ\u07B4.Error;
		Application.Quit();
	}

	// Token: 0x0600202C RID: 8236 RVA: 0x000A7FBC File Offset: 0x000A61BC
	[Token(Token = "0x600202C")]
	[Address(RVA = "0x29999BC", Offset = "0x29999BC", VA = "0x29999BC")]
	public void ڬ\u0833غר()
	{
		IEnumerator routine = this.ڔӖӽԈ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600202D RID: 8237 RVA: 0x000A7FD8 File Offset: 0x000A61D8
	[Token(Token = "0x600202D")]
	[Address(RVA = "0x29999E8", Offset = "0x29999E8", VA = "0x29999E8")]
	private void \u0829ݬ\u074Bז(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		List.Enumerator enumerator;
		bool flag = enumerator.MoveNext();
		string ص_u061D_u07AAڙ = this.ص\u061D\u07AAڙ;
		bool flag2 = this.ۍշ\u07FCࢬ == ص_u061D_u07AAڙ;
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		long active = 1L;
		ىպ߆_u.SetActive(active != 0L);
	}

	// Token: 0x0600202E RID: 8238 RVA: 0x000A8030 File Offset: 0x000A6230
	[Token(Token = "0x600202E")]
	[Address(RVA = "0x2998BC4", Offset = "0x2998BC4", VA = "0x2998BC4")]
	private IEnumerator \u06DFؿԷק()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 1L;
		throw new NullReferenceException();
	}

	// Token: 0x0600202F RID: 8239 RVA: 0x000A804C File Offset: 0x000A624C
	[Token(Token = "0x600202F")]
	[Address(RVA = "0x2999B54", Offset = "0x2999B54", VA = "0x2999B54")]
	public void ݹ\u07B8\u0601Ӊ()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002030 RID: 8240 RVA: 0x000A8068 File Offset: 0x000A6268
	[Token(Token = "0x6002030")]
	[Address(RVA = "0x2999CA8", Offset = "0x2999CA8", VA = "0x2999CA8")]
	private IEnumerator خז\u06DF\u07FD()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 1L;
		ԑ_u0615_u0876ݒ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002031 RID: 8241 RVA: 0x000A808C File Offset: 0x000A628C
	[Token(Token = "0x6002031")]
	[Address(RVA = "0x2999D20", Offset = "0x2999D20", VA = "0x2999D20")]
	private void \u07FFݰӐڵ(PlayFabError ہ\u0613ܢ\u07B4)
	{
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.Destroy(ىպ߆_u);
		Application.Quit();
	}

	// Token: 0x06002032 RID: 8242 RVA: 0x000A80BC File Offset: 0x000A62BC
	[Token(Token = "0x6002032")]
	[Address(RVA = "0x2999DC0", Offset = "0x2999DC0", VA = "0x2999DC0")]
	public void ࡥࡌ\u06E7ۿ()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x06002033 RID: 8243 RVA: 0x000A80D8 File Offset: 0x000A62D8
	[Token(Token = "0x6002033")]
	[Address(RVA = "0x2999F14", Offset = "0x2999F14", VA = "0x2999F14")]
	public void \u0608\u070F\u081D\u05B8()
	{
		IEnumerator routine = this.ٸߠ\u086Bࢰ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002034 RID: 8244 RVA: 0x000A80F4 File Offset: 0x000A62F4
	[Token(Token = "0x6002034")]
	[Address(RVA = "0x2999F40", Offset = "0x2999F40", VA = "0x2999F40")]
	public void آބԕӐ()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
	}

	// Token: 0x06002035 RID: 8245 RVA: 0x000A8110 File Offset: 0x000A6310
	[Token(Token = "0x6002035")]
	[Address(RVA = "0x2998FA0", Offset = "0x2998FA0", VA = "0x2998FA0")]
	private IEnumerator \u059Fצփ\u05AE()
	{
		long <>1__state;
		PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ ԑ_u0615_u0876ݒ = new PlayFabAccountItemChecker.Ԑ\u0615\u0876ݒ((int)<>1__state);
		<>1__state = 1L;
		ԑ_u0615_u0876ݒ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002036 RID: 8246 RVA: 0x000A8134 File Offset: 0x000A6334
	[Token(Token = "0x6002036")]
	[Address(RVA = "0x299A094", Offset = "0x299A094", VA = "0x299A094")]
	public void \u0833إ\u06DEת()
	{
		IEnumerator routine = this.سעմࢹ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002037 RID: 8247 RVA: 0x000A8150 File Offset: 0x000A6350
	[Token(Token = "0x6002037")]
	[Address(RVA = "0x299A0C0", Offset = "0x299A0C0", VA = "0x299A0C0")]
	public void Ռ\u06EA\u05AFࡇ()
	{
		IEnumerator routine = this.ٸߠ\u086Bࢰ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06002038 RID: 8248 RVA: 0x000A816C File Offset: 0x000A636C
	[Token(Token = "0x6002038")]
	[Address(RVA = "0x299A0EC", Offset = "0x299A0EC", VA = "0x299A0EC")]
	private void \u07F3ߣ\u0746ߒ(GetUserInventoryResult ޅࢶ\u05F3ܪ)
	{
		bool flag = ޅࢶ\u05F3ܪ.Inventory.GetEnumerator().MoveNext();
		string ص_u061D_u07AAڙ = this.ص\u061D\u07AAڙ;
		string ۍշ_u07FCࢬ = this.ۍշ\u07FCࢬ;
		GameObject ىպ߆_u = this.ىպ߆\u0599;
		long active = 0L;
		ىպ߆_u.SetActive(active != 0L);
	}

	// Token: 0x06002039 RID: 8249 RVA: 0x000A81C4 File Offset: 0x000A63C4
	[Token(Token = "0x6002039")]
	[Address(RVA = "0x299A258", Offset = "0x299A258", VA = "0x299A258")]
	public void ړբ٠\u088A()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600203A RID: 8250 RVA: 0x000A81E0 File Offset: 0x000A63E0
	[Token(Token = "0x600203A")]
	[Address(RVA = "0x299A3AC", Offset = "0x299A3AC", VA = "0x299A3AC")]
	public void ڐ\u05B6ޓڴ()
	{
		GetUserInventoryRequest getUserInventoryRequest = new GetUserInventoryRequest();
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x0400041D RID: 1053
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400041D")]
	public LoginManager ڐۊࠔ\u0651;

	// Token: 0x0400041E RID: 1054
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400041E")]
	public string ۍշ\u07FCࢬ;

	// Token: 0x0400041F RID: 1055
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400041F")]
	public string ص\u061D\u07AAڙ;

	// Token: 0x04000420 RID: 1056
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000420")]
	public GameObject ىպ߆\u0599;
}
