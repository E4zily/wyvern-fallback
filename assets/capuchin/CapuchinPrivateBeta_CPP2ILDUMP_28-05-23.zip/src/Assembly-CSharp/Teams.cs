﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x02000011 RID: 17
[Token(Token = "0x2000011")]
public class Teams : MonoBehaviourPunCallbacks
{
	// Token: 0x06000220 RID: 544 RVA: 0x00010E2C File Offset: 0x0000F02C
	[Token(Token = "0x6000220")]
	[Address(RVA = "0x2F1BFC8", Offset = "0x2F1BFC8", VA = "0x2F1BFC8")]
	public void ߠ\u0616\u074Cݺ()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000221 RID: 545 RVA: 0x00010E8C File Offset: 0x0000F08C
	[Token(Token = "0x6000221")]
	[Address(RVA = "0x2F1C0DC", Offset = "0x2F1C0DC", VA = "0x2F1C0DC")]
	public IEnumerator ԣڿ\u0613ܠ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000222 RID: 546 RVA: 0x00010EB0 File Offset: 0x0000F0B0
	[Token(Token = "0x6000222")]
	[Address(RVA = "0x2F1C154", Offset = "0x2F1C154", VA = "0x2F1C154")]
	public IEnumerator ݍӘԻڟ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000223 RID: 547 RVA: 0x00010ED4 File Offset: 0x0000F0D4
	[Token(Token = "0x6000223")]
	[Address(RVA = "0x2F1C1CC", Offset = "0x2F1C1CC", VA = "0x2F1C1CC")]
	public IEnumerator \u0705\u06D4ވ\u05C6()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		throw new NullReferenceException();
	}

	// Token: 0x06000224 RID: 548 RVA: 0x00010EF0 File Offset: 0x0000F0F0
	[Token(Token = "0x6000224")]
	[Address(RVA = "0x2F1C244", Offset = "0x2F1C244", VA = "0x2F1C244")]
	public IEnumerator ތՖմޱ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000225 RID: 549 RVA: 0x00010F14 File Offset: 0x0000F114
	[Token(Token = "0x6000225")]
	[Address(RVA = "0x2F1C2BC", Offset = "0x2F1C2BC", VA = "0x2F1C2BC")]
	public IEnumerator \u05AE\u06EB\u0732\u07B3()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000226 RID: 550 RVA: 0x00010F38 File Offset: 0x0000F138
	[Token(Token = "0x6000226")]
	[Address(RVA = "0x2F1C334", Offset = "0x2F1C334", VA = "0x2F1C334", Slot = "42")]
	public override void OnPlayerEnteredRoom(Player \u05FB\u0610\u05F7\u065F)
	{
		IEnumerator routine = this.\u058Fԡڶޅ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06000227 RID: 551 RVA: 0x00010F54 File Offset: 0x0000F154
	[Token(Token = "0x6000227")]
	[Address(RVA = "0x2F1C3D8", Offset = "0x2F1C3D8", VA = "0x2F1C3D8")]
	public IEnumerator ݞցن\u07FF()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000228 RID: 552 RVA: 0x00010F78 File Offset: 0x0000F178
	[Token(Token = "0x6000228")]
	[Address(RVA = "0x2F1C450", Offset = "0x2F1C450", VA = "0x2F1C450")]
	public IEnumerator סߨՐՈ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000229 RID: 553 RVA: 0x00010F9C File Offset: 0x0000F19C
	[Token(Token = "0x6000229")]
	[Address(RVA = "0x2F1C4C8", Offset = "0x2F1C4C8", VA = "0x2F1C4C8")]
	public IEnumerator ݢߞ\u06EAت()
	{
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600022A RID: 554 RVA: 0x00010FB8 File Offset: 0x0000F1B8
	[Token(Token = "0x600022A")]
	[Address(RVA = "0x2F1C540", Offset = "0x2F1C540", VA = "0x2F1C540")]
	public IEnumerator Ձھ\u0884ӕ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600022B RID: 555 RVA: 0x00010FDC File Offset: 0x0000F1DC
	[Token(Token = "0x600022B")]
	[Address(RVA = "0x2F1C5B8", Offset = "0x2F1C5B8", VA = "0x2F1C5B8", Slot = "41")]
	public override void OnJoinedRoom()
	{
		IEnumerator routine = this.\u058Fԡڶޅ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x0600022C RID: 556 RVA: 0x00010FF8 File Offset: 0x0000F1F8
	[Token(Token = "0x600022C")]
	[Address(RVA = "0x2F1C5E4", Offset = "0x2F1C5E4", VA = "0x2F1C5E4")]
	public Teams()
	{
	}

	// Token: 0x0600022D RID: 557 RVA: 0x0001100C File Offset: 0x0000F20C
	[Token(Token = "0x600022D")]
	[Address(RVA = "0x2F1C5EC", Offset = "0x2F1C5EC", VA = "0x2F1C5EC")]
	public IEnumerator ڔܜࡨտ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600022E RID: 558 RVA: 0x00011030 File Offset: 0x0000F230
	[Token(Token = "0x600022E")]
	[Address(RVA = "0x2F1C664", Offset = "0x2F1C664", VA = "0x2F1C664")]
	public IEnumerator ܡՅӂ\u05F9()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600022F RID: 559 RVA: 0x00011054 File Offset: 0x0000F254
	[Token(Token = "0x600022F")]
	[Address(RVA = "0x2F1C6DC", Offset = "0x2F1C6DC", VA = "0x2F1C6DC")]
	public IEnumerator ӎ\u0893\u07B5Ӫ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000230 RID: 560 RVA: 0x00011078 File Offset: 0x0000F278
	[Token(Token = "0x6000230")]
	[Address(RVA = "0x2F1C754", Offset = "0x2F1C754", VA = "0x2F1C754")]
	public IEnumerator \u05A5շը\u060D()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000231 RID: 561 RVA: 0x0001109C File Offset: 0x0000F29C
	[Token(Token = "0x6000231")]
	[Address(RVA = "0x2F1C7CC", Offset = "0x2F1C7CC", VA = "0x2F1C7CC")]
	public void ݧٻ\u061E\u074B()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000232 RID: 562 RVA: 0x000110FC File Offset: 0x0000F2FC
	[Token(Token = "0x6000232")]
	[Address(RVA = "0x2F1C8E0", Offset = "0x2F1C8E0", VA = "0x2F1C8E0")]
	public IEnumerator \u07B0ݟۍ\u083A()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000233 RID: 563 RVA: 0x00011120 File Offset: 0x0000F320
	[Token(Token = "0x6000233")]
	[Address(RVA = "0x2F1C958", Offset = "0x2F1C958", VA = "0x2F1C958")]
	public IEnumerator ߔ\u05AD\u05CE\u0837()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000234 RID: 564 RVA: 0x00011144 File Offset: 0x0000F344
	[Token(Token = "0x6000234")]
	[Address(RVA = "0x2F1C9D0", Offset = "0x2F1C9D0", VA = "0x2F1C9D0")]
	public void \u0834\u06D4\u0657ա()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000235 RID: 565 RVA: 0x000111A4 File Offset: 0x0000F3A4
	[Token(Token = "0x6000235")]
	[Address(RVA = "0x2F1CAE4", Offset = "0x2F1CAE4", VA = "0x2F1CAE4")]
	public void \u07EBܧڶӕ()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000236 RID: 566 RVA: 0x00011204 File Offset: 0x0000F404
	[Token(Token = "0x6000236")]
	[Address(RVA = "0x2F1CBF8", Offset = "0x2F1CBF8", VA = "0x2F1CBF8")]
	public void \u0597\u07AA\u0707Ԋ()
	{
		TagManager component;
		do
		{
			component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (!ٮ_u086B_u073Fۃ)
			{
				goto IL_34;
			}
			TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
		}
		while (this.\u05F9\u05EE\u07B4\u089F != null);
		return;
		IL_34:
		Material reg = component.ࢣԝՎڲ.Reg;
		Renderer[] u05F9_u05EE_u07B4_u089F2 = this.\u05F9\u05EE\u07B4\u089F;
		throw new NullReferenceException();
	}

	// Token: 0x06000237 RID: 567 RVA: 0x0001126C File Offset: 0x0000F46C
	[Token(Token = "0x6000237")]
	[Address(RVA = "0x2F1CD20", Offset = "0x2F1CD20", VA = "0x2F1CD20")]
	public void ڨڠ\u0591ޱ()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000238 RID: 568 RVA: 0x000112D0 File Offset: 0x0000F4D0
	[Token(Token = "0x6000238")]
	[Address(RVA = "0x2F1C360", Offset = "0x2F1C360", VA = "0x2F1C360")]
	public IEnumerator \u058Fԡڶޅ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000239 RID: 569 RVA: 0x000112F4 File Offset: 0x0000F4F4
	[Token(Token = "0x6000239")]
	[Address(RVA = "0x2F1CE34", Offset = "0x2F1CE34", VA = "0x2F1CE34")]
	public void ڎ\u0670\u0746\u05FC()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x0600023A RID: 570 RVA: 0x00011358 File Offset: 0x0000F558
	[Token(Token = "0x600023A")]
	[Address(RVA = "0x2F1CF5C", Offset = "0x2F1CF5C", VA = "0x2F1CF5C")]
	public IEnumerator Ӂݿޡۏ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600023B RID: 571 RVA: 0x0001137C File Offset: 0x0000F57C
	[Token(Token = "0x600023B")]
	[Address(RVA = "0x2F1CFD4", Offset = "0x2F1CFD4", VA = "0x2F1CFD4")]
	public IEnumerator \u05ECԸࢬץ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600023C RID: 572 RVA: 0x000113A0 File Offset: 0x0000F5A0
	[Token(Token = "0x600023C")]
	[Address(RVA = "0x2F1D04C", Offset = "0x2F1D04C", VA = "0x2F1D04C")]
	public IEnumerator ӵӧ۱\u081A()
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600023D RID: 573 RVA: 0x000113B4 File Offset: 0x0000F5B4
	[Token(Token = "0x600023D")]
	[Address(RVA = "0x2F1D0C4", Offset = "0x2F1D0C4", VA = "0x2F1D0C4")]
	public void \u0874ݥ\u0598\u0892()
	{
		TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
		if (component.ٮ\u086B\u073Fۃ)
		{
			TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
			return;
		}
		Material reg = component.ࢣԝՎڲ.Reg;
		throw new NullReferenceException();
	}

	// Token: 0x0600023E RID: 574 RVA: 0x000113FC File Offset: 0x0000F5FC
	[Token(Token = "0x600023E")]
	[Address(RVA = "0x2F1D1EC", Offset = "0x2F1D1EC", VA = "0x2F1D1EC")]
	public void ۉ\u0821\u07B4\u0607()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x0600023F RID: 575 RVA: 0x00011464 File Offset: 0x0000F664
	[Token(Token = "0x600023F")]
	[Address(RVA = "0x2F1D314", Offset = "0x2F1D314", VA = "0x2F1D314")]
	public void ו\u0613ڏډ()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000240 RID: 576 RVA: 0x000114C8 File Offset: 0x0000F6C8
	[Token(Token = "0x6000240")]
	[Address(RVA = "0x2F1D43C", Offset = "0x2F1D43C", VA = "0x2F1D43C")]
	public IEnumerator ࡃފ\u0615ࠏ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		throw new NullReferenceException();
	}

	// Token: 0x06000241 RID: 577 RVA: 0x000114E4 File Offset: 0x0000F6E4
	[Token(Token = "0x6000241")]
	[Address(RVA = "0x2F1D4B4", Offset = "0x2F1D4B4", VA = "0x2F1D4B4")]
	public IEnumerator \u06E7\u06EC\u05C8\u06E8()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000242 RID: 578 RVA: 0x00011508 File Offset: 0x0000F708
	[Token(Token = "0x6000242")]
	[Address(RVA = "0x2F1D52C", Offset = "0x2F1D52C", VA = "0x2F1D52C")]
	public IEnumerator \u0703ӆܯ\u05EC()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000243 RID: 579 RVA: 0x0001152C File Offset: 0x0000F72C
	[Token(Token = "0x6000243")]
	[Address(RVA = "0x2F1D5A4", Offset = "0x2F1D5A4", VA = "0x2F1D5A4", Slot = "32")]
	public override void OnMasterClientSwitched(Player ԆࢫԱ٠)
	{
		IEnumerator routine = this.\u058Fԡڶޅ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06000244 RID: 580 RVA: 0x00011548 File Offset: 0x0000F748
	[Token(Token = "0x6000244")]
	[Address(RVA = "0x2F1D5D0", Offset = "0x2F1D5D0", VA = "0x2F1D5D0", Slot = "43")]
	public override void OnPlayerLeftRoom(Player پ\u06DA\u07ACԅ)
	{
		IEnumerator routine = this.\u058Fԡڶޅ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x06000245 RID: 581 RVA: 0x00011564 File Offset: 0x0000F764
	[Token(Token = "0x6000245")]
	[Address(RVA = "0x2F1D5FC", Offset = "0x2F1D5FC", VA = "0x2F1D5FC")]
	public void \u07F6߀ئ\u0609()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (!ٮ_u086B_u073Fۃ)
			{
				return;
			}
			TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
		}
		while (this.\u05F9\u05EE\u07B4\u089F != null);
	}

	// Token: 0x06000246 RID: 582 RVA: 0x000115C0 File Offset: 0x0000F7C0
	[Token(Token = "0x6000246")]
	[Address(RVA = "0x2F1D6E4", Offset = "0x2F1D6E4", VA = "0x2F1D6E4")]
	public IEnumerator ۃژ\u065Aݾ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000247 RID: 583 RVA: 0x000115E4 File Offset: 0x0000F7E4
	[Token(Token = "0x6000247")]
	[Address(RVA = "0x2F1D75C", Offset = "0x2F1D75C", VA = "0x2F1D75C")]
	public void ࡀ\u089A\u066Aࡡ()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (!ٮ_u086B_u073Fۃ)
			{
				return;
			}
			TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
		}
		while (this.\u05F9\u05EE\u07B4\u089F != null);
	}

	// Token: 0x06000248 RID: 584 RVA: 0x00011640 File Offset: 0x0000F840
	[Token(Token = "0x6000248")]
	[Address(RVA = "0x2F1D844", Offset = "0x2F1D844", VA = "0x2F1D844")]
	public void ցԈߢ\u0823()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000249 RID: 585 RVA: 0x000116A4 File Offset: 0x0000F8A4
	[Token(Token = "0x6000249")]
	[Address(RVA = "0x2F1D958", Offset = "0x2F1D958", VA = "0x2F1D958")]
	public IEnumerator ࡀ\u0830Ֆڝ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600024A RID: 586 RVA: 0x000116C8 File Offset: 0x0000F8C8
	[Token(Token = "0x600024A")]
	[Address(RVA = "0x2F1D9D0", Offset = "0x2F1D9D0", VA = "0x2F1D9D0")]
	public IEnumerator \u06DC\u087Fٷܠ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600024B RID: 587 RVA: 0x000116EC File Offset: 0x0000F8EC
	[Token(Token = "0x600024B")]
	[Address(RVA = "0x2F1DA48", Offset = "0x2F1DA48", VA = "0x2F1DA48")]
	public IEnumerator ࡪ\u0872ࡊӽ()
	{
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600024C RID: 588 RVA: 0x00011708 File Offset: 0x0000F908
	[Token(Token = "0x600024C")]
	[Address(RVA = "0x2F1DAC0", Offset = "0x2F1DAC0", VA = "0x2F1DAC0")]
	public void \u0658\u0746ܩ\u0896()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x0600024D RID: 589 RVA: 0x00011768 File Offset: 0x0000F968
	[Token(Token = "0x600024D")]
	[Address(RVA = "0x2F1DBE8", Offset = "0x2F1DBE8", VA = "0x2F1DBE8")]
	public void ڏ\u0887\u07AF\u055D()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x0600024E RID: 590 RVA: 0x000117C8 File Offset: 0x0000F9C8
	[Token(Token = "0x600024E")]
	[Address(RVA = "0x2F1DCFC", Offset = "0x2F1DCFC", VA = "0x2F1DCFC")]
	public IEnumerator \u083A\u07AAإࢱ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600024F RID: 591 RVA: 0x000117EC File Offset: 0x0000F9EC
	[Token(Token = "0x600024F")]
	[Address(RVA = "0x2F1DD74", Offset = "0x2F1DD74", VA = "0x2F1DD74")]
	public IEnumerator Ն\u0878ࡒդ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000250 RID: 592 RVA: 0x00011810 File Offset: 0x0000FA10
	[Token(Token = "0x6000250")]
	[Address(RVA = "0x2F1DDEC", Offset = "0x2F1DDEC", VA = "0x2F1DDEC")]
	public void ۍࡁو\u06E5()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (!ٮ_u086B_u073Fۃ)
			{
				return;
			}
			TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
		}
		while (this.\u05F9\u05EE\u07B4\u089F != null);
	}

	// Token: 0x06000251 RID: 593 RVA: 0x0001186C File Offset: 0x0000FA6C
	[Token(Token = "0x6000251")]
	[Address(RVA = "0x2F1DED4", Offset = "0x2F1DED4", VA = "0x2F1DED4")]
	public IEnumerator \u064Cߙטݽ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000252 RID: 594 RVA: 0x00011890 File Offset: 0x0000FA90
	[Token(Token = "0x6000252")]
	[Address(RVA = "0x2F1DF4C", Offset = "0x2F1DF4C", VA = "0x2F1DF4C")]
	public void ߂\u05C0گ\u06D6()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000253 RID: 595 RVA: 0x000118F4 File Offset: 0x0000FAF4
	[Token(Token = "0x6000253")]
	[Address(RVA = "0x2F1E060", Offset = "0x2F1E060", VA = "0x2F1E060")]
	public IEnumerator פߊܠ\u087B()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000254 RID: 596 RVA: 0x00011918 File Offset: 0x0000FB18
	[Token(Token = "0x6000254")]
	[Address(RVA = "0x2F1E0D8", Offset = "0x2F1E0D8", VA = "0x2F1E0D8")]
	public IEnumerator ࡎކޘل()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000255 RID: 597 RVA: 0x0001193C File Offset: 0x0000FB3C
	[Token(Token = "0x6000255")]
	[Address(RVA = "0x2F1E150", Offset = "0x2F1E150", VA = "0x2F1E150")]
	public IEnumerator \u0871ӟ\u082Fڙ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000256 RID: 598 RVA: 0x00011960 File Offset: 0x0000FB60
	[Token(Token = "0x6000256")]
	[Address(RVA = "0x2F1E1C8", Offset = "0x2F1E1C8", VA = "0x2F1E1C8")]
	public IEnumerator \u0747ࡔڦڠ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000257 RID: 599 RVA: 0x00011984 File Offset: 0x0000FB84
	[Token(Token = "0x6000257")]
	[Address(RVA = "0x2F1E240", Offset = "0x2F1E240", VA = "0x2F1E240")]
	public IEnumerator ځ\u0824\u088Cڐ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000258 RID: 600 RVA: 0x000119A8 File Offset: 0x0000FBA8
	[Token(Token = "0x6000258")]
	[Address(RVA = "0x2F1E2B8", Offset = "0x2F1E2B8", VA = "0x2F1E2B8")]
	public IEnumerator \u07FAܐܢۃ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000259 RID: 601 RVA: 0x000119CC File Offset: 0x0000FBCC
	[Token(Token = "0x6000259")]
	[Address(RVA = "0x2F1E330", Offset = "0x2F1E330", VA = "0x2F1E330")]
	public void ԛ\u083AڱԤ()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (!ٮ_u086B_u073Fۃ)
			{
				return;
			}
			TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
		}
		while (this.\u05F9\u05EE\u07B4\u089F != null);
	}

	// Token: 0x0600025A RID: 602 RVA: 0x00011A28 File Offset: 0x0000FC28
	[Token(Token = "0x600025A")]
	[Address(RVA = "0x2F1E418", Offset = "0x2F1E418", VA = "0x2F1E418")]
	public void ݼ\u082EڽӋ()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x0600025B RID: 603 RVA: 0x00011A8C File Offset: 0x0000FC8C
	[Token(Token = "0x600025B")]
	[Address(RVA = "0x2F1E540", Offset = "0x2F1E540", VA = "0x2F1E540")]
	public IEnumerator ծࡨԟ\u083F()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600025C RID: 604 RVA: 0x00011AB0 File Offset: 0x0000FCB0
	[Token(Token = "0x600025C")]
	[Address(RVA = "0x2F1E5B8", Offset = "0x2F1E5B8", VA = "0x2F1E5B8")]
	public IEnumerator ࡤ\u0701ܓӐ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600025D RID: 605 RVA: 0x00011AD4 File Offset: 0x0000FCD4
	[Token(Token = "0x600025D")]
	[Address(RVA = "0x2F1E630", Offset = "0x2F1E630", VA = "0x2F1E630")]
	public IEnumerator ضךژࡕ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600025E RID: 606 RVA: 0x00011AF8 File Offset: 0x0000FCF8
	[Token(Token = "0x600025E")]
	[Address(RVA = "0x2F1E6A8", Offset = "0x2F1E6A8", VA = "0x2F1E6A8")]
	public void \u05BCסࢲࠁ()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (!ٮ_u086B_u073Fۃ)
			{
				return;
			}
			TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
		}
		while (this.\u05F9\u05EE\u07B4\u089F != null);
	}

	// Token: 0x0600025F RID: 607 RVA: 0x00011B54 File Offset: 0x0000FD54
	[Token(Token = "0x600025F")]
	[Address(RVA = "0x2F1E790", Offset = "0x2F1E790", VA = "0x2F1E790")]
	public void ӷ\u0885߃\u0883()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000260 RID: 608 RVA: 0x00011BBC File Offset: 0x0000FDBC
	[Token(Token = "0x6000260")]
	[Address(RVA = "0x2F1E8B8", Offset = "0x2F1E8B8", VA = "0x2F1E8B8")]
	public void \u0736ӝظ\u05FF()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000261 RID: 609 RVA: 0x00011C1C File Offset: 0x0000FE1C
	[Token(Token = "0x6000261")]
	[Address(RVA = "0x2F1E9CC", Offset = "0x2F1E9CC", VA = "0x2F1E9CC")]
	public void ՄӰݣ\u07FC()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000262 RID: 610 RVA: 0x00011C7C File Offset: 0x0000FE7C
	[Token(Token = "0x6000262")]
	[Address(RVA = "0x2F1EAE0", Offset = "0x2F1EAE0", VA = "0x2F1EAE0")]
	public IEnumerator ܤ٤\u0886\u070D()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000263 RID: 611 RVA: 0x00011CA0 File Offset: 0x0000FEA0
	[Token(Token = "0x6000263")]
	[Address(RVA = "0x2F1EB58", Offset = "0x2F1EB58", VA = "0x2F1EB58")]
	public void ӼӬ\u0591\u06E0()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000264 RID: 612 RVA: 0x00011D00 File Offset: 0x0000FF00
	[Token(Token = "0x6000264")]
	[Address(RVA = "0x2F1EC6C", Offset = "0x2F1EC6C", VA = "0x2F1EC6C")]
	public IEnumerator \u0897էۏ\u05BD()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000265 RID: 613 RVA: 0x00011D24 File Offset: 0x0000FF24
	[Token(Token = "0x6000265")]
	[Address(RVA = "0x2F1ECE4", Offset = "0x2F1ECE4", VA = "0x2F1ECE4")]
	public IEnumerator ࡣڑ\u087F\u0895()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000266 RID: 614 RVA: 0x00011D48 File Offset: 0x0000FF48
	[Token(Token = "0x6000266")]
	[Address(RVA = "0x2F1ED5C", Offset = "0x2F1ED5C", VA = "0x2F1ED5C")]
	public IEnumerator ࢠӿ\u0730ע()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000267 RID: 615 RVA: 0x00011D6C File Offset: 0x0000FF6C
	[Token(Token = "0x6000267")]
	[Address(RVA = "0x2F1EDD4", Offset = "0x2F1EDD4", VA = "0x2F1EDD4")]
	public IEnumerator \u05FD\u07F0ߤ\u05BF()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000268 RID: 616 RVA: 0x00011D90 File Offset: 0x0000FF90
	[Token(Token = "0x6000268")]
	[Address(RVA = "0x2F1EE4C", Offset = "0x2F1EE4C", VA = "0x2F1EE4C")]
	public void ߙӿߣ\u0896()
	{
		TagManager component;
		Renderer[] u05F9_u05EE_u07B4_u089F;
		for (;;)
		{
			component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				break;
			}
			Material reg = component.ࢣԝՎڲ.Reg;
			if (this.\u05F9\u05EE\u07B4\u089F == null)
			{
				goto Block_2;
			}
		}
		TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
		while (u05F9_u05EE_u07B4_u089F != null)
		{
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000269 RID: 617 RVA: 0x00011DEC File Offset: 0x0000FFEC
	[Token(Token = "0x6000269")]
	[Address(RVA = "0x2F1EF60", Offset = "0x2F1EF60", VA = "0x2F1EF60")]
	public IEnumerator \u0701چըݒ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600026A RID: 618 RVA: 0x00011E10 File Offset: 0x00010010
	[Token(Token = "0x600026A")]
	[Address(RVA = "0x2F1EFD8", Offset = "0x2F1EFD8", VA = "0x2F1EFD8")]
	public void ؠ\u06D8հݰ()
	{
		for (;;)
		{
			TagManager tagManager;
			bool ٮ_u086B_u073Fۃ = tagManager.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = tagManager.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = tagManager.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x0600026B RID: 619 RVA: 0x00011E68 File Offset: 0x00010068
	[Token(Token = "0x600026B")]
	[Address(RVA = "0x2F1F100", Offset = "0x2F1F100", VA = "0x2F1F100")]
	public IEnumerator ܖڜߎ\u05CE()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600026C RID: 620 RVA: 0x00011E8C File Offset: 0x0001008C
	[Token(Token = "0x600026C")]
	[Address(RVA = "0x2F1F178", Offset = "0x2F1F178", VA = "0x2F1F178")]
	public void ࡁӏחࢴ()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x0600026D RID: 621 RVA: 0x00011EF0 File Offset: 0x000100F0
	[Token(Token = "0x600026D")]
	[Address(RVA = "0x2F1F28C", Offset = "0x2F1F28C", VA = "0x2F1F28C")]
	public IEnumerator \u0619\u06E7\u0606ࠒ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600026E RID: 622 RVA: 0x00011F14 File Offset: 0x00010114
	[Token(Token = "0x600026E")]
	[Address(RVA = "0x2F1F304", Offset = "0x2F1F304", VA = "0x2F1F304")]
	public IEnumerator دפޥڹ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600026F RID: 623 RVA: 0x00011F38 File Offset: 0x00010138
	[Token(Token = "0x600026F")]
	[Address(RVA = "0x2F1F37C", Offset = "0x2F1F37C", VA = "0x2F1F37C")]
	public IEnumerator \u083Cۓ\u07FB\u05F4()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000270 RID: 624 RVA: 0x00011F5C File Offset: 0x0001015C
	[Token(Token = "0x6000270")]
	[Address(RVA = "0x2F1F3F4", Offset = "0x2F1F3F4", VA = "0x2F1F3F4")]
	public IEnumerator ۂܟߙࠕ()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x06000271 RID: 625 RVA: 0x00011F78 File Offset: 0x00010178
	[Token(Token = "0x6000271")]
	[Address(RVA = "0x2F1F46C", Offset = "0x2F1F46C", VA = "0x2F1F46C")]
	public void \u05A9\u06FEܡܢ()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000272 RID: 626 RVA: 0x00011FD4 File Offset: 0x000101D4
	[Token(Token = "0x6000272")]
	[Address(RVA = "0x2F1F594", Offset = "0x2F1F594", VA = "0x2F1F594")]
	public void إ\u087CԙӞ()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000273 RID: 627 RVA: 0x00012034 File Offset: 0x00010234
	[Token(Token = "0x6000273")]
	[Address(RVA = "0x2F1F6A8", Offset = "0x2F1F6A8", VA = "0x2F1F6A8")]
	public void ֈޔݻԻ()
	{
		for (;;)
		{
			TagManager tagManager;
			bool ٮ_u086B_u073Fۃ = tagManager.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = tagManager.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = tagManager.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000274 RID: 628 RVA: 0x00012084 File Offset: 0x00010284
	[Token(Token = "0x6000274")]
	[Address(RVA = "0x2F1F7D0", Offset = "0x2F1F7D0", VA = "0x2F1F7D0")]
	public IEnumerator ڧڂ٠\u0616()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 1L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000275 RID: 629 RVA: 0x000120A8 File Offset: 0x000102A8
	[Token(Token = "0x6000275")]
	[Address(RVA = "0x2F1F848", Offset = "0x2F1F848", VA = "0x2F1F848")]
	public void ߟՉش\u0593()
	{
		for (;;)
		{
			NetworkPlayerSpawner كݕ_u05F3_u = NetworkPlayerSpawner.كݕ\u05F3\u0589;
			TagManager tagManager;
			bool ٮ_u086B_u073Fۃ = tagManager.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = tagManager.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = tagManager.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000276 RID: 630 RVA: 0x00012104 File Offset: 0x00010304
	[Token(Token = "0x6000276")]
	[Address(RVA = "0x2F1F95C", Offset = "0x2F1F95C", VA = "0x2F1F95C")]
	public void \u07A6\u064Cۍސ()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000277 RID: 631 RVA: 0x00012164 File Offset: 0x00010364
	[Token(Token = "0x6000277")]
	[Address(RVA = "0x2F1FA70", Offset = "0x2F1FA70", VA = "0x2F1FA70")]
	public void װޒ\u070F\u0822()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (!ٮ_u086B_u073Fۃ)
			{
				return;
			}
			TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
		}
		while (this.\u05F9\u05EE\u07B4\u089F != null);
	}

	// Token: 0x06000278 RID: 632 RVA: 0x000121C0 File Offset: 0x000103C0
	[Token(Token = "0x6000278")]
	[Address(RVA = "0x2F1FB58", Offset = "0x2F1FB58", VA = "0x2F1FB58")]
	public void ԬکՉ\u05CA()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.كݕ\u05F3\u0589.\u05EEݠ\u05FFը.GetComponent<TagManager>();
			bool ٮ_u086B_u073Fۃ = component.ٮ\u086B\u073Fۃ;
			Renderer[] u05F9_u05EE_u07B4_u089F = this.\u05F9\u05EE\u07B4\u089F;
			if (ٮ_u086B_u073Fۃ)
			{
				TeamSettings ࢣԝՎڲ = component.ࢣԝՎڲ;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					break;
				}
			}
			else
			{
				Material reg = component.ࢣԝՎڲ.Reg;
				if (this.\u05F9\u05EE\u07B4\u089F == null)
				{
					goto Block_2;
				}
			}
		}
		return;
		Block_2:
		throw new NullReferenceException();
	}

	// Token: 0x06000279 RID: 633 RVA: 0x00012228 File Offset: 0x00010428
	[Token(Token = "0x6000279")]
	[Address(RVA = "0x2F1FC80", Offset = "0x2F1FC80", VA = "0x2F1FC80")]
	public IEnumerator ܮ\u05BAޱ\u0878()
	{
		long <>1__state;
		Teams.\u0616Օ\u065Bܣ u0616Օ_u065Bܣ = new Teams.\u0616Օ\u065Bܣ((int)<>1__state);
		<>1__state = 0L;
		u0616Օ_u065Bܣ.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x04000049 RID: 73
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000049")]
	public GameObject[] ٮ\u086B\u073Fۃ;

	// Token: 0x0400004A RID: 74
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400004A")]
	public GameObject[] ݙࡁԎݵ;

	// Token: 0x0400004B RID: 75
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400004B")]
	public Renderer[] \u05F9\u05EE\u07B4\u089F;

	// Token: 0x0400004C RID: 76
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400004C")]
	public AudioSource \u0559ײՓ\u06E8;
}
