﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;

// Token: 0x020000E3 RID: 227
[Token(Token = "0x20000E3")]
[Serializable]
public class jsonFilter
{
	// Token: 0x06002363 RID: 9059 RVA: 0x000BB07C File Offset: 0x000B927C
	[Token(Token = "0x6002363")]
	[Address(RVA = "0x2FAB0B4", Offset = "0x2FAB0B4", VA = "0x2FAB0B4")]
	public jsonFilter()
	{
	}

	// Token: 0x04000477 RID: 1143
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000477")]
	public List<filteredNamels> filteredNames;
}
