﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000DF RID: 223
[Token(Token = "0x20000DF")]
public class TutorialManager : MonoBehaviour
{
	// Token: 0x060022A6 RID: 8870 RVA: 0x000B77A8 File Offset: 0x000B59A8
	[Token(Token = "0x60022A6")]
	[Address(RVA = "0x2C77984", Offset = "0x2C77984", VA = "0x2C77984")]
	private void הԥ\u05B5ݴ()
	{
	}

	// Token: 0x060022A7 RID: 8871 RVA: 0x000B77B8 File Offset: 0x000B59B8
	[Token(Token = "0x60022A7")]
	[Address(RVA = "0x2C77988", Offset = "0x2C77988", VA = "0x2C77988")]
	private void \u06EDٵ۶\u06DB()
	{
	}

	// Token: 0x060022A8 RID: 8872 RVA: 0x000B77C8 File Offset: 0x000B59C8
	[Token(Token = "0x60022A8")]
	[Address(RVA = "0x2C7798C", Offset = "0x2C7798C", VA = "0x2C7798C")]
	private void ފՖߢ\u059B()
	{
	}

	// Token: 0x060022A9 RID: 8873 RVA: 0x000B77D8 File Offset: 0x000B59D8
	[Token(Token = "0x60022A9")]
	[Address(RVA = "0x2C77990", Offset = "0x2C77990", VA = "0x2C77990")]
	private void \u065F\u0839ܤ\u073C()
	{
	}

	// Token: 0x060022AA RID: 8874 RVA: 0x000B77E8 File Offset: 0x000B59E8
	[Token(Token = "0x60022AA")]
	[Address(RVA = "0x2C77994", Offset = "0x2C77994", VA = "0x2C77994")]
	private void \u0656ӺմՁ()
	{
	}

	// Token: 0x060022AB RID: 8875 RVA: 0x000B77F8 File Offset: 0x000B59F8
	[Token(Token = "0x60022AB")]
	[Address(RVA = "0x2C77998", Offset = "0x2C77998", VA = "0x2C77998")]
	private void Start()
	{
	}

	// Token: 0x060022AC RID: 8876 RVA: 0x000B7808 File Offset: 0x000B5A08
	[Token(Token = "0x60022AC")]
	[Address(RVA = "0x2C7799C", Offset = "0x2C7799C", VA = "0x2C7799C")]
	private void ܣ\u086E\u05CF\u06D8()
	{
	}

	// Token: 0x060022AD RID: 8877 RVA: 0x000B7818 File Offset: 0x000B5A18
	[Token(Token = "0x60022AD")]
	[Address(RVA = "0x2C779A0", Offset = "0x2C779A0", VA = "0x2C779A0")]
	private void Update()
	{
	}

	// Token: 0x060022AE RID: 8878 RVA: 0x000B7828 File Offset: 0x000B5A28
	[Token(Token = "0x60022AE")]
	[Address(RVA = "0x2C779A4", Offset = "0x2C779A4", VA = "0x2C779A4")]
	private void \u05EDց\u081Cت()
	{
	}

	// Token: 0x060022AF RID: 8879 RVA: 0x000B7838 File Offset: 0x000B5A38
	[Token(Token = "0x60022AF")]
	[Address(RVA = "0x2C779A8", Offset = "0x2C779A8", VA = "0x2C779A8")]
	private void ڑߒجވ()
	{
	}

	// Token: 0x060022B0 RID: 8880 RVA: 0x000B7848 File Offset: 0x000B5A48
	[Token(Token = "0x60022B0")]
	[Address(RVA = "0x2C779AC", Offset = "0x2C779AC", VA = "0x2C779AC")]
	private void \u05F7ԝߠӱ()
	{
	}

	// Token: 0x060022B1 RID: 8881 RVA: 0x000B7858 File Offset: 0x000B5A58
	[Token(Token = "0x60022B1")]
	[Address(RVA = "0x2C779B0", Offset = "0x2C779B0", VA = "0x2C779B0")]
	private void ࡅݐ\u082Dք()
	{
	}

	// Token: 0x060022B2 RID: 8882 RVA: 0x000B7868 File Offset: 0x000B5A68
	[Token(Token = "0x60022B2")]
	[Address(RVA = "0x2C779B4", Offset = "0x2C779B4", VA = "0x2C779B4")]
	private void ןٮ\u061FԺ()
	{
	}

	// Token: 0x060022B3 RID: 8883 RVA: 0x000B7878 File Offset: 0x000B5A78
	[Token(Token = "0x60022B3")]
	[Address(RVA = "0x2C779B8", Offset = "0x2C779B8", VA = "0x2C779B8")]
	private void \u0881ݗӟ\u07BD()
	{
	}

	// Token: 0x060022B4 RID: 8884 RVA: 0x000B7888 File Offset: 0x000B5A88
	[Token(Token = "0x60022B4")]
	[Address(RVA = "0x2C779BC", Offset = "0x2C779BC", VA = "0x2C779BC")]
	private void ݱ\u0832ݥ\u08B5()
	{
	}

	// Token: 0x060022B5 RID: 8885 RVA: 0x000B7898 File Offset: 0x000B5A98
	[Token(Token = "0x60022B5")]
	[Address(RVA = "0x2C779C0", Offset = "0x2C779C0", VA = "0x2C779C0")]
	private void Ҽ\u08B5ځ\u0658()
	{
	}

	// Token: 0x060022B6 RID: 8886 RVA: 0x000B78A8 File Offset: 0x000B5AA8
	[Token(Token = "0x60022B6")]
	[Address(RVA = "0x2C779C4", Offset = "0x2C779C4", VA = "0x2C779C4")]
	private void Ҿࢹؼס()
	{
	}

	// Token: 0x060022B7 RID: 8887 RVA: 0x000B78B8 File Offset: 0x000B5AB8
	[Token(Token = "0x60022B7")]
	[Address(RVA = "0x2C779C8", Offset = "0x2C779C8", VA = "0x2C779C8")]
	private void ժ\u065Dԯࡘ()
	{
	}

	// Token: 0x060022B8 RID: 8888 RVA: 0x000B78C8 File Offset: 0x000B5AC8
	[Token(Token = "0x60022B8")]
	[Address(RVA = "0x2C779CC", Offset = "0x2C779CC", VA = "0x2C779CC")]
	private void ۆڛߟ\u05A0()
	{
	}

	// Token: 0x060022B9 RID: 8889 RVA: 0x000B78D8 File Offset: 0x000B5AD8
	[Token(Token = "0x60022B9")]
	[Address(RVA = "0x2C779D0", Offset = "0x2C779D0", VA = "0x2C779D0")]
	private void ࡩݮڢՠ()
	{
	}

	// Token: 0x060022BA RID: 8890 RVA: 0x000B78E8 File Offset: 0x000B5AE8
	[Token(Token = "0x60022BA")]
	[Address(RVA = "0x2C779D4", Offset = "0x2C779D4", VA = "0x2C779D4")]
	private void ۮߝڪڐ()
	{
	}

	// Token: 0x060022BB RID: 8891 RVA: 0x000B78F8 File Offset: 0x000B5AF8
	[Token(Token = "0x60022BB")]
	[Address(RVA = "0x2C779D8", Offset = "0x2C779D8", VA = "0x2C779D8")]
	private void \u061Fࡆ\u086F\u07B0()
	{
	}

	// Token: 0x060022BC RID: 8892 RVA: 0x000B7908 File Offset: 0x000B5B08
	[Token(Token = "0x60022BC")]
	[Address(RVA = "0x2C779DC", Offset = "0x2C779DC", VA = "0x2C779DC")]
	private void ڃրӢԖ()
	{
	}

	// Token: 0x060022BD RID: 8893 RVA: 0x000B7918 File Offset: 0x000B5B18
	[Token(Token = "0x60022BD")]
	[Address(RVA = "0x2C779E0", Offset = "0x2C779E0", VA = "0x2C779E0")]
	private void \u070Aәޣے()
	{
	}

	// Token: 0x060022BE RID: 8894 RVA: 0x000B7928 File Offset: 0x000B5B28
	[Token(Token = "0x60022BE")]
	[Address(RVA = "0x2C779E4", Offset = "0x2C779E4", VA = "0x2C779E4")]
	private void \u066D\u05BDې߃()
	{
	}

	// Token: 0x060022BF RID: 8895 RVA: 0x000B7938 File Offset: 0x000B5B38
	[Token(Token = "0x60022BF")]
	[Address(RVA = "0x2C779E8", Offset = "0x2C779E8", VA = "0x2C779E8")]
	private void \u0558ݕݤݮ()
	{
	}

	// Token: 0x060022C0 RID: 8896 RVA: 0x000B7948 File Offset: 0x000B5B48
	[Token(Token = "0x60022C0")]
	[Address(RVA = "0x2C779EC", Offset = "0x2C779EC", VA = "0x2C779EC")]
	private void \u082E\u06EBݼڏ()
	{
	}

	// Token: 0x060022C1 RID: 8897 RVA: 0x000B7958 File Offset: 0x000B5B58
	[Token(Token = "0x60022C1")]
	[Address(RVA = "0x2C779F0", Offset = "0x2C779F0", VA = "0x2C779F0")]
	public TutorialManager()
	{
	}

	// Token: 0x060022C2 RID: 8898 RVA: 0x000B796C File Offset: 0x000B5B6C
	[Token(Token = "0x60022C2")]
	[Address(RVA = "0x2C779F8", Offset = "0x2C779F8", VA = "0x2C779F8")]
	private void \u061B\u05EEوۈ()
	{
	}

	// Token: 0x060022C3 RID: 8899 RVA: 0x000B797C File Offset: 0x000B5B7C
	[Token(Token = "0x60022C3")]
	[Address(RVA = "0x2C779FC", Offset = "0x2C779FC", VA = "0x2C779FC")]
	private void ݤۅࢦӃ()
	{
	}

	// Token: 0x060022C4 RID: 8900 RVA: 0x000B798C File Offset: 0x000B5B8C
	[Token(Token = "0x60022C4")]
	[Address(RVA = "0x2C77A00", Offset = "0x2C77A00", VA = "0x2C77A00")]
	private void ޡࠅ\u089Aߔ()
	{
	}
}
