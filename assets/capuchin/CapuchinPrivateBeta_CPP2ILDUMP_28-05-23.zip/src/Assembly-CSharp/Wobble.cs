﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000048 RID: 72
[Token(Token = "0x2000048")]
public class Wobble : MonoBehaviour
{
	// Token: 0x06000A01 RID: 2561 RVA: 0x000358AC File Offset: 0x00033AAC
	[Token(Token = "0x6000A01")]
	[Address(RVA = "0x2AFB678", Offset = "0x2AFB678", VA = "0x2AFB678")]
	private void ڑߒجވ()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("Failed to get catalog, cosmetic name, and price. Exact error details is: ", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("typesOfTalk", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E3 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x06000A02 RID: 2562 RVA: 0x00035AC8 File Offset: 0x00033CC8
	[Token(Token = "0x6000A02")]
	[Address(RVA = "0x2AFB92C", Offset = "0x2AFB92C", VA = "0x2AFB92C")]
	private void הԥ\u05B5ݴ()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.ڗ\u0897\u07BF۹ = component;
	}

	// Token: 0x06000A03 RID: 2563 RVA: 0x00035AE4 File Offset: 0x00033CE4
	[Token(Token = "0x6000A03")]
	[Address(RVA = "0x2AFB988", Offset = "0x2AFB988", VA = "0x2AFB988")]
	private void Ҿࢹؼס()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("monke screamed", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("1BN", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E3 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x06000A04 RID: 2564 RVA: 0x00035D00 File Offset: 0x00033F00
	[Token(Token = "0x6000A04")]
	[Address(RVA = "0x2AFBC3C", Offset = "0x2AFBC3C", VA = "0x2AFBC3C")]
	private void \u0881ݗӟ\u07BD()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("Player", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E3 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x06000A05 RID: 2565 RVA: 0x00035F1C File Offset: 0x0003411C
	[Token(Token = "0x6000A05")]
	[Address(RVA = "0x2AFBEF0", Offset = "0x2AFBEF0", VA = "0x2AFBEF0")]
	private void \u0558ݕݤݮ()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.ڗ\u0897\u07BF۹ = component;
	}

	// Token: 0x06000A06 RID: 2566 RVA: 0x00035F38 File Offset: 0x00034138
	[Token(Token = "0x6000A06")]
	[Address(RVA = "0x2AFBF4C", Offset = "0x2AFBF4C", VA = "0x2AFBF4C")]
	private void ࡅݐ\u082Dք()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.ڗ\u0897\u07BF۹ = component;
	}

	// Token: 0x06000A07 RID: 2567 RVA: 0x00035F54 File Offset: 0x00034154
	[Token(Token = "0x6000A07")]
	[Address(RVA = "0x2AFBFA8", Offset = "0x2AFBFA8", VA = "0x2AFBFA8")]
	private void ފՖߢ\u059B()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("clickLol", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E3 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x06000A08 RID: 2568 RVA: 0x00036170 File Offset: 0x00034370
	[Token(Token = "0x6000A08")]
	[Address(RVA = "0x2AFC25C", Offset = "0x2AFC25C", VA = "0x2AFC25C")]
	private void \u0654ޛ\u07FAذ()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("Wear Hoodie", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("Damaged Arm", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E3 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x06000A09 RID: 2569 RVA: 0x0003638C File Offset: 0x0003458C
	[Token(Token = "0x6000A09")]
	[Address(RVA = "0x2AFC510", Offset = "0x2AFC510", VA = "0x2AFC510")]
	private void \u0732ڙԒࢺ()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("Hate Speech", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("DisableCosmetic", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x06000A0A RID: 2570 RVA: 0x000365A0 File Offset: 0x000347A0
	[Token(Token = "0x6000A0A")]
	[Address(RVA = "0x2AFC7C4", Offset = "0x2AFC7C4", VA = "0x2AFC7C4")]
	private void Update()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("_WobbleX", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("_WobbleZ", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E3 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x06000A0B RID: 2571 RVA: 0x000367BC File Offset: 0x000349BC
	[Token(Token = "0x6000A0B")]
	[Address(RVA = "0x2AFCA68", Offset = "0x2AFCA68", VA = "0x2AFCA68")]
	private void \u05ABݿࡋ\u06E9()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.ڗ\u0897\u07BF۹ = component;
	}

	// Token: 0x06000A0C RID: 2572 RVA: 0x000367D8 File Offset: 0x000349D8
	[Token(Token = "0x6000A0C")]
	[Address(RVA = "0x2AFCAC4", Offset = "0x2AFCAC4", VA = "0x2AFCAC4")]
	private void Start()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.ڗ\u0897\u07BF۹ = component;
	}

	// Token: 0x06000A0D RID: 2573 RVA: 0x000367F4 File Offset: 0x000349F4
	[Token(Token = "0x6000A0D")]
	[Address(RVA = "0x2AFCB20", Offset = "0x2AFCB20", VA = "0x2AFCB20")]
	public Wobble()
	{
		long u060Cߪ_u05CAճ = 1065353216L;
		long ࡑ۳_u0596_u066C = 1056964608L;
		this.\u060Cߪ\u05CAճ = (float)u060Cߪ_u05CAճ;
		this.ࡑ۳\u0596\u066C = (float)ࡑ۳_u0596_u066C;
		base..ctor();
	}

	// Token: 0x06000A0E RID: 2574 RVA: 0x00036824 File Offset: 0x00034A24
	[Token(Token = "0x6000A0E")]
	[Address(RVA = "0x2AFCB44", Offset = "0x2AFCB44", VA = "0x2AFCB44")]
	private void ԟ\u086Cޣ\u055E()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("username", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("You Already Own This Item", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E3 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x06000A0F RID: 2575 RVA: 0x00036A40 File Offset: 0x00034C40
	[Token(Token = "0x6000A0F")]
	[Address(RVA = "0x2AFCDF8", Offset = "0x2AFCDF8", VA = "0x2AFCDF8")]
	private void \u05F7ԝߠӱ()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("NetworkPlayer", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("NormalWeather", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E3 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x06000A10 RID: 2576 RVA: 0x00036C5C File Offset: 0x00034E5C
	[Token(Token = "0x6000A10")]
	[Address(RVA = "0x2AFD0AC", Offset = "0x2AFD0AC", VA = "0x2AFD0AC")]
	private void Ӣ\u0592ߨׯ()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("amongus", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("EnableCosmetic", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E3 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x06000A11 RID: 2577 RVA: 0x00036E78 File Offset: 0x00035078
	[Token(Token = "0x6000A11")]
	[Address(RVA = "0x2AFD360", Offset = "0x2AFD360", VA = "0x2AFD360")]
	private void \u061B\u05EEوۈ()
	{
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		float deltaTime = Time.deltaTime;
		float ࡀ_u0603ޘ_u082E = this.ࡀ\u0603ޘ\u082E;
		float deltaTime2 = Time.deltaTime;
		float u060Cߪ_u05CAճ = this.\u060Cߪ\u05CAճ;
		float u0819ӷ_u0652ࡨ = this.\u0819ӷ\u0652ࡨ;
		float deltaTime3 = Time.deltaTime;
		float u060Cߪ_u05CAճ2 = this.\u060Cߪ\u05CAճ;
		float u083Dހݽ٤ = this.\u083Dހݽ٤;
		float ࡑ۳_u0596_u066C2 = this.ࡑ۳\u0596\u066C;
		float ࡀ_u0603ޘ_u082E2 = this.ࡀ\u0603ޘ\u082E;
		this.١ࢭ߆ڸ = u083Dހݽ٤;
		float num = this.١ࢭ߆ڸ;
		float ࡑ۳_u0596_u066C3 = this.ࡑ۳\u0596\u066C;
		float u0819ӷ_u0652ࡨ2 = this.\u0819ӷ\u0652ࡨ;
		Material material = this.ڗ\u0897\u07BF۹.material;
		float הࡀ_u058Cࡈ = this.הࡀ\u058Cࡈ;
		float value;
		material.SetFloat("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.", value);
		Material material2 = this.ڗ\u0897\u07BF۹.material;
		float դݍه_u06DD = this.Դݍه\u06DD;
		material2.SetFloat("Fire Stick Is Lighting...", value);
		float x = this.ݛչԍܥ.x;
		float z = this.ݛչԍܥ.z;
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.\u0737ӊٴد.z = դݍه_u06DD;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		float x2 = this.ࡢࢴߌ\u087F.x;
		float z2 = this.ࡢࢴߌ\u087F.z;
		float x3 = this.\u0737ӊٴد.x;
		float ԧ_u07B2ے_u = this.ԧ\u07B2ے\u0701;
		float ࡀ_u0603ޘ_u082E3 = this.ࡀ\u0603ޘ\u082E;
		this.ԛ\u05CC\u059CՊ.z = ࡑ۳_u0596_u066C2;
		float x4 = this.ԛ\u05CC\u059CՊ.x;
		float z3 = this.\u0737ӊٴد.z;
		float ԧ_u07B2ے_u2 = this.ԧ\u07B2ے\u0701;
		float u0819ӷ_u0652ࡨ3 = this.\u0819ӷ\u0652ࡨ;
		this.ࡀ\u0603ޘ\u082E = դݍه_u06DD;
		this.\u0819ӷ\u0652ࡨ = դݍه_u06DD;
		Vector3 position2 = base.transform.position;
		this.ݛչԍܥ.x = դݍه_u06DD;
		this.ݛչԍܥ.y = x4;
		this.ݛչԍܥ.z = ԧ_u07B2ے_u2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.ࡢࢴߌ\u087F.x = դݍه_u06DD;
		this.ࡢࢴߌ\u087F.y = x4;
		this.ࡢࢴߌ\u087F.z = ԧ_u07B2ے_u2;
	}

	// Token: 0x04000171 RID: 369
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000171")]
	private Renderer ڗ\u0897\u07BF۹;

	// Token: 0x04000172 RID: 370
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000172")]
	private Vector3 ݛչԍܥ;

	// Token: 0x04000173 RID: 371
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x4000173")]
	private Vector3 \u0737ӊٴد;

	// Token: 0x04000174 RID: 372
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000174")]
	private Vector3 ࡢࢴߌ\u087F;

	// Token: 0x04000175 RID: 373
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000175")]
	private Vector3 ԛ\u05CC\u059CՊ;

	// Token: 0x04000176 RID: 374
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000176")]
	public float ԧ\u07B2ے\u0701;

	// Token: 0x04000177 RID: 375
	[FieldOffset(Offset = "0x54")]
	[Token(Token = "0x4000177")]
	public float \u083Dހݽ٤;

	// Token: 0x04000178 RID: 376
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000178")]
	public float \u060Cߪ\u05CAճ;

	// Token: 0x04000179 RID: 377
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x4000179")]
	private float הࡀ\u058Cࡈ;

	// Token: 0x0400017A RID: 378
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400017A")]
	private float Դݍه\u06DD;

	// Token: 0x0400017B RID: 379
	[FieldOffset(Offset = "0x64")]
	[Token(Token = "0x400017B")]
	private float ࡀ\u0603ޘ\u082E;

	// Token: 0x0400017C RID: 380
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x400017C")]
	private float \u0819ӷ\u0652ࡨ;

	// Token: 0x0400017D RID: 381
	[FieldOffset(Offset = "0x6C")]
	[Token(Token = "0x400017D")]
	private float ١ࢭ߆ڸ;

	// Token: 0x0400017E RID: 382
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x400017E")]
	private float ࡑ۳\u0596\u066C;
}
