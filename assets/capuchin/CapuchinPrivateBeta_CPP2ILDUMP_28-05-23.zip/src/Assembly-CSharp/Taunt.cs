﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020000DC RID: 220
[Token(Token = "0x20000DC")]
public class Taunt : MonoBehaviour
{
	// Token: 0x06002214 RID: 8724 RVA: 0x000B5A84 File Offset: 0x000B3C84
	[Token(Token = "0x6002214")]
	[Address(RVA = "0x286BFA4", Offset = "0x286BFA4", VA = "0x286BFA4")]
	public IEnumerator ڈձ\u066C\u05BF()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002215 RID: 8725 RVA: 0x000B5AA8 File Offset: 0x000B3CA8
	[Token(Token = "0x6002215")]
	[Address(RVA = "0x286C01C", Offset = "0x286C01C", VA = "0x286C01C")]
	private void \u05AC\u07F0\u07EEࡥ()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			IEnumerator routine = this.ة\u085F\u06FDࢶ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002216 RID: 8726 RVA: 0x000B5B4C File Offset: 0x000B3D4C
	[Token(Token = "0x6002216")]
	[Address(RVA = "0x286C344", Offset = "0x286C344", VA = "0x286C344")]
	public IEnumerator \u0599\u065Eէߍ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002217 RID: 8727 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002217")]
	[Address(RVA = "0x286C3BC", Offset = "0x286C3BC", VA = "0x286C3BC")]
	public void \u05A8\u06DDӚٵ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002218 RID: 8728 RVA: 0x000B5B70 File Offset: 0x000B3D70
	[Token(Token = "0x6002218")]
	[Address(RVA = "0x286C4C4", Offset = "0x286C4C4", VA = "0x286C4C4")]
	private void Start()
	{
	}

	// Token: 0x06002219 RID: 8729 RVA: 0x000B5B80 File Offset: 0x000B3D80
	[Token(Token = "0x6002219")]
	[Address(RVA = "0x286C4C8", Offset = "0x286C4C8", VA = "0x286C4C8")]
	public IEnumerator \u06DA\u0611շݴ()
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600221A RID: 8730 RVA: 0x000B5B94 File Offset: 0x000B3D94
	[Token(Token = "0x600221A")]
	[Address(RVA = "0x286C540", Offset = "0x286C540", VA = "0x286C540")]
	private void Գӿېչ()
	{
	}

	// Token: 0x0600221B RID: 8731 RVA: 0x000B5BA4 File Offset: 0x000B3DA4
	[Token(Token = "0x600221B")]
	[Address(RVA = "0x286C544", Offset = "0x286C544", VA = "0x286C544")]
	public IEnumerator ࡢҾԦտ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600221C RID: 8732 RVA: 0x000B5BC8 File Offset: 0x000B3DC8
	[Token(Token = "0x600221C")]
	[Address(RVA = "0x286C5BC", Offset = "0x286C5BC", VA = "0x286C5BC")]
	public IEnumerator \u064B\u06D7Չ\u085C()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600221D RID: 8733 RVA: 0x000B5BEC File Offset: 0x000B3DEC
	[Token(Token = "0x600221D")]
	[Address(RVA = "0x286C634", Offset = "0x286C634", VA = "0x286C634")]
	private void ۲ڂ\u05B1ڨ()
	{
	}

	// Token: 0x0600221E RID: 8734 RVA: 0x000B5BFC File Offset: 0x000B3DFC
	[Token(Token = "0x600221E")]
	[Address(RVA = "0x286C638", Offset = "0x286C638", VA = "0x286C638")]
	public Taunt()
	{
	}

	// Token: 0x0600221F RID: 8735 RVA: 0x000B5C10 File Offset: 0x000B3E10
	[Token(Token = "0x600221F")]
	[Address(RVA = "0x286C640", Offset = "0x286C640", VA = "0x286C640")]
	public IEnumerator ӆܐեߓ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 0L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002220 RID: 8736 RVA: 0x000B5C34 File Offset: 0x000B3E34
	[Token(Token = "0x6002220")]
	[Address(RVA = "0x286C6B8", Offset = "0x286C6B8", VA = "0x286C6B8")]
	private void \u0892ܒܬޓ()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			IEnumerator routine = this.ڈձ\u066C\u05BF();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002221 RID: 8737 RVA: 0x000B5CD8 File Offset: 0x000B3ED8
	[Token(Token = "0x6002221")]
	[Address(RVA = "0x286C968", Offset = "0x286C968", VA = "0x286C968")]
	private void چ\u05AEךڰ()
	{
	}

	// Token: 0x06002222 RID: 8738 RVA: 0x000B5CE8 File Offset: 0x000B3EE8
	[Token(Token = "0x6002222")]
	[Address(RVA = "0x286C96C", Offset = "0x286C96C", VA = "0x286C96C")]
	private void \u0886Ҽ\u058Dߛ()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 1L;
			long u05B5Ջߛࡦ = 1L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			this.\u05B5Ջߛࡦ = (u05B5Ջߛࡦ != 0L);
			IEnumerator routine = this.ӱ\u0873\u0889Թ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002223 RID: 8739 RVA: 0x000B5D98 File Offset: 0x000B3F98
	[Token(Token = "0x6002223")]
	[Address(RVA = "0x286CC98", Offset = "0x286CC98", VA = "0x286CC98")]
	public IEnumerator ӗ\u07F5ػݘ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002224 RID: 8740 RVA: 0x000B5DBC File Offset: 0x000B3FBC
	[Token(Token = "0x6002224")]
	[Address(RVA = "0x286CD10", Offset = "0x286CD10", VA = "0x286CD10")]
	private void \u07B6կպ߃()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			long u05B5Ջߛࡦ = 1L;
			this.\u05B5Ջߛࡦ = (u05B5Ջߛࡦ != 0L);
			IEnumerator routine = this.ӱ\u0873\u0889Թ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002225 RID: 8741 RVA: 0x000B5E60 File Offset: 0x000B4060
	[Token(Token = "0x6002225")]
	[Address(RVA = "0x286CFC4", Offset = "0x286CFC4", VA = "0x286CFC4")]
	public IEnumerator \u0824ٽԓڔ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002226 RID: 8742 RVA: 0x000B5E84 File Offset: 0x000B4084
	[Token(Token = "0x6002226")]
	[Address(RVA = "0x286D03C", Offset = "0x286D03C", VA = "0x286D03C")]
	private void ݤۅࢦӃ()
	{
	}

	// Token: 0x06002227 RID: 8743 RVA: 0x000B5E94 File Offset: 0x000B4094
	[Token(Token = "0x6002227")]
	[Address(RVA = "0x286D040", Offset = "0x286D040", VA = "0x286D040")]
	public IEnumerator ݩࢶ\u087FՉ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002228 RID: 8744 RVA: 0x000B5EB8 File Offset: 0x000B40B8
	[Token(Token = "0x6002228")]
	[Address(RVA = "0x286D0B8", Offset = "0x286D0B8", VA = "0x286D0B8")]
	public IEnumerator \u0872ը\u060EԆ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 0L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002229 RID: 8745 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002229")]
	[Address(RVA = "0x286D130", Offset = "0x286D130", VA = "0x286D130")]
	public void شԚ\u0650\u05BC()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600222A RID: 8746 RVA: 0x000B5EDC File Offset: 0x000B40DC
	[Token(Token = "0x600222A")]
	[Address(RVA = "0x286D22C", Offset = "0x286D22C", VA = "0x286D22C")]
	private void ۆڛߟ\u05A0()
	{
	}

	// Token: 0x0600222B RID: 8747 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600222B")]
	[Address(RVA = "0x286D230", Offset = "0x286D230", VA = "0x286D230")]
	public void ݔ߄ޱۓ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600222C RID: 8748 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600222C")]
	[Address(RVA = "0x286D32C", Offset = "0x286D32C", VA = "0x286D32C")]
	public void ބܝۄ\u0703()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600222D RID: 8749 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600222D")]
	[Address(RVA = "0x286D434", Offset = "0x286D434", VA = "0x286D434")]
	public void Ա\u05F9\u05BDܫ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600222E RID: 8750 RVA: 0x000B5EEC File Offset: 0x000B40EC
	[Token(Token = "0x600222E")]
	[Address(RVA = "0x286D530", Offset = "0x286D530", VA = "0x286D530")]
	private void \u05F8ݑ\u06ECߞ()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			long u05B5Ջߛࡦ = 1L;
			this.\u05B5Ջߛࡦ = (u05B5Ջߛࡦ != 0L);
			IEnumerator routine = this.ߝޤ\u05AE\u0742();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x0600222F RID: 8751 RVA: 0x000B5F9C File Offset: 0x000B419C
	[Token(Token = "0x600222F")]
	[Address(RVA = "0x286D85C", Offset = "0x286D85C", VA = "0x286D85C")]
	public IEnumerator \u0895Ժݩ\u0749()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 0L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002230 RID: 8752 RVA: 0x000B5FC0 File Offset: 0x000B41C0
	[Token(Token = "0x6002230")]
	[Address(RVA = "0x286D8D4", Offset = "0x286D8D4", VA = "0x286D8D4")]
	public IEnumerator \u0894\u0705ֈݤ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 0L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002231 RID: 8753 RVA: 0x000B5FE4 File Offset: 0x000B41E4
	[Token(Token = "0x6002231")]
	[Address(RVA = "0x286D94C", Offset = "0x286D94C", VA = "0x286D94C")]
	private void \u073Fߗބݝ()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			IEnumerator routine = this.ڡࡠ\u05AC߂();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002232 RID: 8754 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002232")]
	[Address(RVA = "0x286DC74", Offset = "0x286DC74", VA = "0x286DC74")]
	public void ދܐضړ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002233 RID: 8755 RVA: 0x000B6088 File Offset: 0x000B4288
	[Token(Token = "0x6002233")]
	[Address(RVA = "0x286DD70", Offset = "0x286DD70", VA = "0x286DD70")]
	private void \u073BօӁ\u059A()
	{
	}

	// Token: 0x06002234 RID: 8756 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002234")]
	[Address(RVA = "0x286DD74", Offset = "0x286DD74", VA = "0x286DD74")]
	public void ףࢡלٲ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002235 RID: 8757 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002235")]
	[Address(RVA = "0x286DE7C", Offset = "0x286DE7C", VA = "0x286DE7C")]
	public void \u07B0ԝ\u07ACߪ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002236 RID: 8758 RVA: 0x000B6098 File Offset: 0x000B4298
	[Token(Token = "0x6002236")]
	[Address(RVA = "0x286D7E4", Offset = "0x286D7E4", VA = "0x286D7E4")]
	public IEnumerator ߝޤ\u05AE\u0742()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 0L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002237 RID: 8759 RVA: 0x000B60BC File Offset: 0x000B42BC
	[Token(Token = "0x6002237")]
	[Address(RVA = "0x286DF84", Offset = "0x286DF84", VA = "0x286DF84")]
	private void \u0821\u059Fӕ\u0607()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			IEnumerator routine = this.ԍװۮ\u0734();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002238 RID: 8760 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002238")]
	[Address(RVA = "0x286E2A8", Offset = "0x286E2A8", VA = "0x286E2A8")]
	public void \u064Dۿ\u07BB\u05C0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002239 RID: 8761 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002239")]
	[Address(RVA = "0x286E3A4", Offset = "0x286E3A4", VA = "0x286E3A4")]
	public void \u05F8ࡂࡧ\u07FA()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600223A RID: 8762 RVA: 0x000B6160 File Offset: 0x000B4360
	[Token(Token = "0x600223A")]
	[Address(RVA = "0x286E4A0", Offset = "0x286E4A0", VA = "0x286E4A0")]
	public IEnumerator ޓࠊժۆ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 0L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600223B RID: 8763 RVA: 0x000B6184 File Offset: 0x000B4384
	[Token(Token = "0x600223B")]
	[Address(RVA = "0x286E518", Offset = "0x286E518", VA = "0x286E518")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			long u05B5Ջߛࡦ = 1L;
			this.\u05B5Ջߛࡦ = (u05B5Ջߛࡦ != 0L);
			IEnumerator routine = this.\u0894\u0705ֈݤ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x0600223C RID: 8764 RVA: 0x000B622C File Offset: 0x000B442C
	[Token(Token = "0x600223C")]
	[Address(RVA = "0x286DBFC", Offset = "0x286DBFC", VA = "0x286DBFC")]
	public IEnumerator ڡࡠ\u05AC߂()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600223D RID: 8765 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600223D")]
	[Address(RVA = "0x286E7CC", Offset = "0x286E7CC", VA = "0x286E7CC")]
	public void Ձߎࢺ\u060D()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600223E RID: 8766 RVA: 0x000B6250 File Offset: 0x000B4450
	[Token(Token = "0x600223E")]
	[Address(RVA = "0x286E8D4", Offset = "0x286E8D4", VA = "0x286E8D4")]
	private void \u0881ݗӟ\u07BD()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			IEnumerator routine = this.Ӏࡁսې();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x0600223F RID: 8767 RVA: 0x000B62E4 File Offset: 0x000B44E4
	[Token(Token = "0x600223F")]
	[Address(RVA = "0x286EB84", Offset = "0x286EB84", VA = "0x286EB84")]
	public IEnumerator Ӏࡁսې()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002240 RID: 8768 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002240")]
	[Address(RVA = "0x286EBFC", Offset = "0x286EBFC", VA = "0x286EBFC")]
	public void \u0747ݦޖݔ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002241 RID: 8769 RVA: 0x000B6308 File Offset: 0x000B4508
	[Token(Token = "0x6002241")]
	[Address(RVA = "0x286ECF8", Offset = "0x286ECF8", VA = "0x286ECF8")]
	private void ژךՈ\u0597()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 1L;
			long u05B5Ջߛࡦ = 1L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			this.\u05B5Ջߛࡦ = (u05B5Ջߛࡦ != 0L);
			IEnumerator routine = this.\u0895Ժݩ\u0749();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002242 RID: 8770 RVA: 0x000B63B8 File Offset: 0x000B45B8
	[Token(Token = "0x6002242")]
	[Address(RVA = "0x286EFAC", Offset = "0x286EFAC", VA = "0x286EFAC")]
	public void \u0603\u0593\u05B3\u0886()
	{
		ThrowHelper.ThrowArgumentOutOfRangeException();
	}

	// Token: 0x06002243 RID: 8771 RVA: 0x000B63D4 File Offset: 0x000B45D4
	[Token(Token = "0x6002243")]
	[Address(RVA = "0x286F0B4", Offset = "0x286F0B4", VA = "0x286F0B4")]
	private void ࡎ\u05C2սࠇ()
	{
	}

	// Token: 0x06002244 RID: 8772 RVA: 0x000B63E4 File Offset: 0x000B45E4
	[Token(Token = "0x6002244")]
	[Address(RVA = "0x286F0B8", Offset = "0x286F0B8", VA = "0x286F0B8")]
	private void \u086Bԍࡊڭ()
	{
	}

	// Token: 0x06002245 RID: 8773 RVA: 0x000B63F4 File Offset: 0x000B45F4
	[Token(Token = "0x6002245")]
	[Address(RVA = "0x286F0BC", Offset = "0x286F0BC", VA = "0x286F0BC")]
	public IEnumerator \u061Eث\u07F1س()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 0L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002246 RID: 8774 RVA: 0x000B6418 File Offset: 0x000B4618
	[Token(Token = "0x6002246")]
	[Address(RVA = "0x286CC20", Offset = "0x286CC20", VA = "0x286CC20")]
	public IEnumerator ӱ\u0873\u0889Թ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 0L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002247 RID: 8775 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002247")]
	[Address(RVA = "0x286F134", Offset = "0x286F134", VA = "0x286F134")]
	public void Ҿ\u065EՀݜ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002248 RID: 8776 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002248")]
	[Address(RVA = "0x286F230", Offset = "0x286F230", VA = "0x286F230")]
	public void קܥ\u061Dߧ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002249 RID: 8777 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002249")]
	[Address(RVA = "0x286F338", Offset = "0x286F338", VA = "0x286F338")]
	public void Ӎ\u070BԤߓ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600224A RID: 8778 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600224A")]
	[Address(RVA = "0x286F434", Offset = "0x286F434", VA = "0x286F434")]
	public void ݠ\u07EBӁ\u0652()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600224B RID: 8779 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600224B")]
	[Address(RVA = "0x286F530", Offset = "0x286F530", VA = "0x286F530")]
	public void ֆؼࢹߖ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600224C RID: 8780 RVA: 0x000B643C File Offset: 0x000B463C
	[Token(Token = "0x600224C")]
	[Address(RVA = "0x286F62C", Offset = "0x286F62C", VA = "0x286F62C")]
	private void \u05C8\u05BFࠁف()
	{
	}

	// Token: 0x0600224D RID: 8781 RVA: 0x000B644C File Offset: 0x000B464C
	[Token(Token = "0x600224D")]
	[Address(RVA = "0x286F630", Offset = "0x286F630", VA = "0x286F630")]
	public IEnumerator ڨ\u06EA\u07BBԱ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600224E RID: 8782 RVA: 0x000B6470 File Offset: 0x000B4670
	[Token(Token = "0x600224E")]
	[Address(RVA = "0x286E230", Offset = "0x286E230", VA = "0x286E230")]
	public IEnumerator ԍװۮ\u0734()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 0L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600224F RID: 8783 RVA: 0x000B6494 File Offset: 0x000B4694
	[Token(Token = "0x600224F")]
	[Address(RVA = "0x286F6A8", Offset = "0x286F6A8", VA = "0x286F6A8")]
	private void Update()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			long u05B5Ջߛࡦ = 1L;
			this.\u05B5Ջߛࡦ = (u05B5Ջߛࡦ != 0L);
			IEnumerator routine = this.ߝޤ\u05AE\u0742();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002250 RID: 8784 RVA: 0x000B6524 File Offset: 0x000B4724
	[Token(Token = "0x6002250")]
	[Address(RVA = "0x286F958", Offset = "0x286F958", VA = "0x286F958")]
	private void طӏܙࢺ()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			long u05B5Ջߛࡦ = 1L;
			this.\u05B5Ջߛࡦ = (u05B5Ջߛࡦ != 0L);
			IEnumerator routine = this.ԍװۮ\u0734();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002251 RID: 8785 RVA: 0x000B65D4 File Offset: 0x000B47D4
	[Token(Token = "0x6002251")]
	[Address(RVA = "0x286C2CC", Offset = "0x286C2CC", VA = "0x286C2CC")]
	public IEnumerator ة\u085F\u06FDࢶ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002252 RID: 8786 RVA: 0x000B65F8 File Offset: 0x000B47F8
	[Token(Token = "0x6002252")]
	[Address(RVA = "0x286FC0C", Offset = "0x286FC0C", VA = "0x286FC0C")]
	private void ӛ\u082Eؿڕ()
	{
	}

	// Token: 0x06002253 RID: 8787 RVA: 0x000B6608 File Offset: 0x000B4808
	[Token(Token = "0x6002253")]
	[Address(RVA = "0x286FC10", Offset = "0x286FC10", VA = "0x286FC10")]
	public IEnumerator ࢹگ\u0730ࡅ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002254 RID: 8788 RVA: 0x000B662C File Offset: 0x000B482C
	[Token(Token = "0x6002254")]
	[Address(RVA = "0x286FC88", Offset = "0x286FC88", VA = "0x286FC88")]
	private void \u065F\u0839ܤ\u073C()
	{
	}

	// Token: 0x06002255 RID: 8789 RVA: 0x000B663C File Offset: 0x000B483C
	[Token(Token = "0x6002255")]
	[Address(RVA = "0x286FC8C", Offset = "0x286FC8C", VA = "0x286FC8C")]
	private void \u0872މࢮՃ()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			IEnumerator routine = this.ӱ\u0873\u0889Թ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002256 RID: 8790 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002256")]
	[Address(RVA = "0x286FF40", Offset = "0x286FF40", VA = "0x286FF40")]
	public void \u05F8ڶ\u070Aө()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002257 RID: 8791 RVA: 0x000B66E0 File Offset: 0x000B48E0
	[Token(Token = "0x6002257")]
	[Address(RVA = "0x2870048", Offset = "0x2870048", VA = "0x2870048")]
	public IEnumerator ه\u07F2\u081B\u07FE()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 0L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002258 RID: 8792 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002258")]
	[Address(RVA = "0x28700C0", Offset = "0x28700C0", VA = "0x28700C0")]
	public void ٷ\u05F5Ԗ\u0595()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002259 RID: 8793 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002259")]
	[Address(RVA = "0x28701C8", Offset = "0x28701C8", VA = "0x28701C8")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600225A RID: 8794 RVA: 0x000B6704 File Offset: 0x000B4904
	[Token(Token = "0x600225A")]
	[Address(RVA = "0x28702C4", Offset = "0x28702C4", VA = "0x28702C4")]
	private void ى߁ٱՏ()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 1L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			IEnumerator routine = this.ԍװۮ\u0734();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x0600225B RID: 8795 RVA: 0x000B67B0 File Offset: 0x000B49B0
	[Token(Token = "0x600225B")]
	[Address(RVA = "0x2870570", Offset = "0x2870570", VA = "0x2870570")]
	private void \u0818ՠש\u0731()
	{
	}

	// Token: 0x0600225C RID: 8796 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600225C")]
	[Address(RVA = "0x2870574", Offset = "0x2870574", VA = "0x2870574")]
	public void ӣՃ\u07FAԟ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600225D RID: 8797 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600225D")]
	[Address(RVA = "0x2870670", Offset = "0x2870670", VA = "0x2870670")]
	public void \u07BEژ\u055Fڀ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600225E RID: 8798 RVA: 0x000B67C0 File Offset: 0x000B49C0
	[Token(Token = "0x600225E")]
	[Address(RVA = "0x287076C", Offset = "0x287076C", VA = "0x287076C")]
	public IEnumerator קߜࢯߓ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600225F RID: 8799 RVA: 0x000B67E4 File Offset: 0x000B49E4
	[Token(Token = "0x600225F")]
	[Address(RVA = "0x28707E4", Offset = "0x28707E4", VA = "0x28707E4")]
	private void \u0739߉ڵݞ()
	{
	}

	// Token: 0x06002260 RID: 8800 RVA: 0x000B67F4 File Offset: 0x000B49F4
	[Token(Token = "0x6002260")]
	[Address(RVA = "0x28707E8", Offset = "0x28707E8", VA = "0x28707E8")]
	private void ߒ\u065EՎࡖ()
	{
	}

	// Token: 0x06002261 RID: 8801 RVA: 0x000B6804 File Offset: 0x000B4A04
	[Token(Token = "0x6002261")]
	[Address(RVA = "0x28707EC", Offset = "0x28707EC", VA = "0x28707EC")]
	public IEnumerator ه\u086F\u0608ڿ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002262 RID: 8802 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002262")]
	[Address(RVA = "0x2870864", Offset = "0x2870864", VA = "0x2870864")]
	public void \u087Dܠ\u07FFӴ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002263 RID: 8803 RVA: 0x000B6828 File Offset: 0x000B4A28
	[Token(Token = "0x6002263")]
	[Address(RVA = "0x287096C", Offset = "0x287096C", VA = "0x287096C")]
	private void ފՖߢ\u059B()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0616ڼށӮ.position;
			Vector3 position2 = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 1L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			IEnumerator routine = this.ڬٻ\u0704ڻ();
			Coroutine coroutine = base.StartCoroutine(routine);
		}
	}

	// Token: 0x06002264 RID: 8804 RVA: 0x000B68C8 File Offset: 0x000B4AC8
	[Token(Token = "0x6002264")]
	[Address(RVA = "0x2870C94", Offset = "0x2870C94", VA = "0x2870C94")]
	private void \u0558ݕݤݮ()
	{
	}

	// Token: 0x06002265 RID: 8805 RVA: 0x000B68D8 File Offset: 0x000B4AD8
	[Token(Token = "0x6002265")]
	[Address(RVA = "0x2870C98", Offset = "0x2870C98", VA = "0x2870C98")]
	private void \u0652\u058Bک\u061C()
	{
	}

	// Token: 0x06002266 RID: 8806 RVA: 0x000B68E8 File Offset: 0x000B4AE8
	[Token(Token = "0x6002266")]
	[Address(RVA = "0x2870C9C", Offset = "0x2870C9C", VA = "0x2870C9C")]
	private void \u05EDց\u081Cت()
	{
		if (!true)
		{
		}
		if (!this.\u05B5Ջߛࡦ)
		{
			string name = this.۴ࢯࠍۓ.name;
			Vector3 position = this.\u0880\u07A8ݠڝ.position;
			Quaternion identity = Quaternion.identity;
			if (typeof(PhotonNetwork).TypeHandle == null)
			{
			}
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.\u0880\u07A8ݠڝ.forward;
			Vector3 velocity = this.\u081B\u070Aߢࡁ.velocity;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			long isKinematic = 0L;
			u081B_u070Aߢࡁ.isKinematic = (isKinematic != 0L);
			long u05B5Ջߛࡦ = 1L;
			this.\u05B5Ջߛࡦ = (u05B5Ջߛࡦ != 0L);
			IEnumerator enumerator = this.ԍװۮ\u0734();
		}
	}

	// Token: 0x06002267 RID: 8807 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002267")]
	[Address(RVA = "0x2870F50", Offset = "0x2870F50", VA = "0x2870F50")]
	public void ࠎճ\u05F9م()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002268 RID: 8808 RVA: 0x000B6980 File Offset: 0x000B4B80
	[Token(Token = "0x6002268")]
	[Address(RVA = "0x2870C1C", Offset = "0x2870C1C", VA = "0x2870C1C")]
	public IEnumerator ڬٻ\u0704ڻ()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002269 RID: 8809 RVA: 0x000B69A4 File Offset: 0x000B4BA4
	[Token(Token = "0x6002269")]
	[Address(RVA = "0x2871064", Offset = "0x2871064", VA = "0x2871064")]
	public IEnumerator \u083Bࠄӑ\u07AD()
	{
		long <>1__state;
		Taunt.ࢭܬة\u05CD ࢭܬة_u05CD = new Taunt.ࢭܬة\u05CD((int)<>1__state);
		<>1__state = 1L;
		ࢭܬة_u05CD.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0400045F RID: 1119
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400045F")]
	public GameObject ۴ࢯࠍۓ;

	// Token: 0x04000460 RID: 1120
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000460")]
	public Rigidbody \u081B\u070Aߢࡁ;

	// Token: 0x04000461 RID: 1121
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000461")]
	public Transform \u0616ڼށӮ;

	// Token: 0x04000462 RID: 1122
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000462")]
	public Transform \u0880\u07A8ݠڝ;

	// Token: 0x04000463 RID: 1123
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000463")]
	private InputDevice ڵ\u05A3\u0894ࠑ;

	// Token: 0x04000464 RID: 1124
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000464")]
	private InputDevice ݙޢغކ;

	// Token: 0x04000465 RID: 1125
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000465")]
	private bool \u05B5Ջߛࡦ;

	// Token: 0x04000466 RID: 1126
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x4000466")]
	public Vector3 ի\u087Cޥݷ;
}
