﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000035 RID: 53
[Token(Token = "0x2000035")]
public class GravityBody : MonoBehaviour
{
	// Token: 0x06000646 RID: 1606 RVA: 0x000256E0 File Offset: 0x000238E0
	[Token(Token = "0x6000646")]
	[Address(RVA = "0x2E77B34", Offset = "0x2E77B34", VA = "0x2E77B34")]
	private void Ԯ\u0883\u0591\u066C()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)107;
	}

	// Token: 0x06000647 RID: 1607 RVA: 0x00025720 File Offset: 0x00023920
	[Token(Token = "0x6000647")]
	[Address(RVA = "0x2E77B98", Offset = "0x2E77B98", VA = "0x2E77B98")]
	private void \u070Fߨ\u05B0ۈ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)47;
	}

	// Token: 0x06000648 RID: 1608 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000648")]
	[Address(RVA = "0x2E77BFC", Offset = "0x2E77BFC", VA = "0x2E77BFC")]
	private void \u07A7\u06DFࠈޖ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000649 RID: 1609 RVA: 0x00025760 File Offset: 0x00023960
	[Token(Token = "0x6000649")]
	[Address(RVA = "0x2E77CCC", Offset = "0x2E77CCC", VA = "0x2E77CCC")]
	private void ݱ\u0832ݥ\u08B5()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x0600064A RID: 1610 RVA: 0x00025798 File Offset: 0x00023998
	[Token(Token = "0x600064A")]
	[Address(RVA = "0x2E77D30", Offset = "0x2E77D30", VA = "0x2E77D30")]
	private void \u0882צ\u0821\u05B4()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x0600064B RID: 1611 RVA: 0x000257D0 File Offset: 0x000239D0
	[Token(Token = "0x600064B")]
	[Address(RVA = "0x2E77D94", Offset = "0x2E77D94", VA = "0x2E77D94")]
	private void Ղڑߧ\u07BC()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.كմ\u06D9ۊ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600064C RID: 1612 RVA: 0x00025838 File Offset: 0x00023A38
	[Token(Token = "0x600064C")]
	[Address(RVA = "0x2E77E6C", Offset = "0x2E77E6C", VA = "0x2E77E6C")]
	private void \u066A\u059Eټ\u085A()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x0600064D RID: 1613 RVA: 0x00025870 File Offset: 0x00023A70
	[Token(Token = "0x600064D")]
	[Address(RVA = "0x2E77ED0", Offset = "0x2E77ED0", VA = "0x2E77ED0")]
	private void կսҾ\u06E4()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u06D4ڷӃצ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600064E RID: 1614 RVA: 0x000258D8 File Offset: 0x00023AD8
	[Token(Token = "0x600064E")]
	[Address(RVA = "0x2E77FA8", Offset = "0x2E77FA8", VA = "0x2E77FA8")]
	private void \u0881\u0743\u07EB\u0747()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)41;
	}

	// Token: 0x0600064F RID: 1615 RVA: 0x00025918 File Offset: 0x00023B18
	[Token(Token = "0x600064F")]
	[Address(RVA = "0x2E7800C", Offset = "0x2E7800C", VA = "0x2E7800C")]
	private void ߓ\u06E3\u05C7ۋ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000650 RID: 1616 RVA: 0x00025950 File Offset: 0x00023B50
	[Token(Token = "0x6000650")]
	[Address(RVA = "0x2E78070", Offset = "0x2E78070", VA = "0x2E78070")]
	private void FixedUpdate()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u06D4ڷӃצ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000651 RID: 1617 RVA: 0x000259B8 File Offset: 0x00023BB8
	[Token(Token = "0x6000651")]
	[Address(RVA = "0x2E78148", Offset = "0x2E78148", VA = "0x2E78148")]
	private void הԥ\u05B5ݴ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000652 RID: 1618 RVA: 0x000259F0 File Offset: 0x00023BF0
	[Token(Token = "0x6000652")]
	[Address(RVA = "0x2E781AC", Offset = "0x2E781AC", VA = "0x2E781AC")]
	private void \u073BօӁ\u059A()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)84;
	}

	// Token: 0x06000653 RID: 1619 RVA: 0x00025A30 File Offset: 0x00023C30
	[Token(Token = "0x6000653")]
	[Address(RVA = "0x2E78210", Offset = "0x2E78210", VA = "0x2E78210")]
	private void ߖհݣ߀()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)121;
	}

	// Token: 0x06000654 RID: 1620 RVA: 0x00025A70 File Offset: 0x00023C70
	[Token(Token = "0x6000654")]
	[Address(RVA = "0x2E78274", Offset = "0x2E78274", VA = "0x2E78274")]
	private void گ\u085E\u073Dڊ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000655 RID: 1621 RVA: 0x00025AA8 File Offset: 0x00023CA8
	[Token(Token = "0x6000655")]
	[Address(RVA = "0x2E782D8", Offset = "0x2E782D8", VA = "0x2E782D8")]
	private void \u0883ދ\u066C\u0859()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.كմ\u06D9ۊ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000656 RID: 1622 RVA: 0x00025B10 File Offset: 0x00023D10
	[Token(Token = "0x6000656")]
	[Address(RVA = "0x2E783AC", Offset = "0x2E783AC", VA = "0x2E783AC")]
	private void ۮߝڪڐ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000657 RID: 1623 RVA: 0x00025B48 File Offset: 0x00023D48
	[Token(Token = "0x6000657")]
	[Address(RVA = "0x2E78410", Offset = "0x2E78410", VA = "0x2E78410")]
	private void \u082E\u06EBݼڏ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)88;
	}

	// Token: 0x06000658 RID: 1624 RVA: 0x00025B88 File Offset: 0x00023D88
	[Token(Token = "0x6000658")]
	[Address(RVA = "0x2E78474", Offset = "0x2E78474", VA = "0x2E78474")]
	private void ࡎ\u05C2սࠇ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000659 RID: 1625 RVA: 0x00025BC0 File Offset: 0x00023DC0
	[Token(Token = "0x6000659")]
	[Address(RVA = "0x2E784D8", Offset = "0x2E784D8", VA = "0x2E784D8")]
	private void \u0834\u0817ރࡔ()
	{
		GravityBody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		long useGravity = 0L;
		bool enabled = u081B_u070Aߢࡁ.enabled;
		this.\u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
	}

	// Token: 0x0600065A RID: 1626 RVA: 0x00025BF8 File Offset: 0x00023DF8
	[Token(Token = "0x600065A")]
	[Address(RVA = "0x2E7853C", Offset = "0x2E7853C", VA = "0x2E7853C")]
	private void عۻԂ\u055E()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x0600065B RID: 1627 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600065B")]
	[Address(RVA = "0x2E785A0", Offset = "0x2E785A0", VA = "0x2E785A0")]
	private void \u0877ԇ\u083D\u0738()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600065C RID: 1628 RVA: 0x00025C30 File Offset: 0x00023E30
	[Token(Token = "0x600065C")]
	[Address(RVA = "0x2E78674", Offset = "0x2E78674", VA = "0x2E78674")]
	private void \u0887ࡒ\u0613\u07B8()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u0839ڠ\u0833ݲ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600065D RID: 1629 RVA: 0x00025C8C File Offset: 0x00023E8C
	[Token(Token = "0x600065D")]
	[Address(RVA = "0x2E78748", Offset = "0x2E78748", VA = "0x2E78748")]
	private void ݡز٨հ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x0600065E RID: 1630 RVA: 0x00025CC4 File Offset: 0x00023EC4
	[Token(Token = "0x600065E")]
	[Address(RVA = "0x2E787AC", Offset = "0x2E787AC", VA = "0x2E787AC")]
	private void ۆڛߟ\u05A0()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x0600065F RID: 1631 RVA: 0x00025CFC File Offset: 0x00023EFC
	[Token(Token = "0x600065F")]
	[Address(RVA = "0x2E78810", Offset = "0x2E78810", VA = "0x2E78810")]
	private void ޗٻ\u0825ڔ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u0615\u06DA\u0827ދ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000660 RID: 1632 RVA: 0x00025D64 File Offset: 0x00023F64
	[Token(Token = "0x6000660")]
	[Address(RVA = "0x2E788E8", Offset = "0x2E788E8", VA = "0x2E788E8")]
	private void حتݻ\u05B0()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000661 RID: 1633 RVA: 0x00025D9C File Offset: 0x00023F9C
	[Token(Token = "0x6000661")]
	[Address(RVA = "0x2E7894C", Offset = "0x2E7894C", VA = "0x2E7894C")]
	private void \u066Dӝߏآ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000662 RID: 1634 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000662")]
	[Address(RVA = "0x2E789B0", Offset = "0x2E789B0", VA = "0x2E789B0")]
	private void ޝ\u088Dނپ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000663 RID: 1635 RVA: 0x00025DD4 File Offset: 0x00023FD4
	[Token(Token = "0x6000663")]
	[Address(RVA = "0x2E78A84", Offset = "0x2E78A84", VA = "0x2E78A84")]
	private void աؾێړ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000664 RID: 1636 RVA: 0x00025E0C File Offset: 0x0002400C
	[Token(Token = "0x6000664")]
	[Address(RVA = "0x2E78AE8", Offset = "0x2E78AE8", VA = "0x2E78AE8")]
	private void سר\u087B\u082A()
	{
	}

	// Token: 0x06000665 RID: 1637 RVA: 0x00025E24 File Offset: 0x00024024
	[Token(Token = "0x6000665")]
	[Address(RVA = "0x2E78BBC", Offset = "0x2E78BBC", VA = "0x2E78BBC")]
	private void ݸԲ\u0616Ԫ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		u05CBݝհن.constraints = (RigidbodyConstraints)34;
	}

	// Token: 0x06000666 RID: 1638 RVA: 0x00025E5C File Offset: 0x0002405C
	[Token(Token = "0x6000666")]
	[Address(RVA = "0x2E78C20", Offset = "0x2E78C20", VA = "0x2E78C20")]
	private void \u058EԸس\u0819()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)55;
	}

	// Token: 0x06000667 RID: 1639 RVA: 0x00025E9C File Offset: 0x0002409C
	[Token(Token = "0x6000667")]
	[Address(RVA = "0x2E78C84", Offset = "0x2E78C84", VA = "0x2E78C84")]
	private void ࡋձغӜ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.كմ\u06D9ۊ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000668 RID: 1640 RVA: 0x00025F04 File Offset: 0x00024104
	[Token(Token = "0x6000668")]
	[Address(RVA = "0x2E78D5C", Offset = "0x2E78D5C", VA = "0x2E78D5C")]
	private void ݤۅࢦӃ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
	}

	// Token: 0x06000669 RID: 1641 RVA: 0x00025F28 File Offset: 0x00024128
	[Token(Token = "0x6000669")]
	[Address(RVA = "0x2E78DC0", Offset = "0x2E78DC0", VA = "0x2E78DC0")]
	private void \u07BE\u0898\u061Dә()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ࠁԚڰہ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600066A RID: 1642 RVA: 0x00025F90 File Offset: 0x00024190
	[Token(Token = "0x600066A")]
	[Address(RVA = "0x2E78E94", Offset = "0x2E78E94", VA = "0x2E78E94")]
	private void \u070EࢣԀ\u07A9()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ڛ\u05CDܜי(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600066B RID: 1643 RVA: 0x00025FEC File Offset: 0x000241EC
	[Token(Token = "0x600066B")]
	[Address(RVA = "0x2E78F68", Offset = "0x2E78F68", VA = "0x2E78F68")]
	private void \u086Bԍࡊڭ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)49;
	}

	// Token: 0x0600066C RID: 1644 RVA: 0x0002602C File Offset: 0x0002422C
	[Token(Token = "0x600066C")]
	[Address(RVA = "0x2E78FCC", Offset = "0x2E78FCC", VA = "0x2E78FCC")]
	private void ӊ\u05BA\u0590ࢳ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u087FӟӰӞ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600066D RID: 1645 RVA: 0x00026080 File Offset: 0x00024280
	[Token(Token = "0x600066D")]
	[Address(RVA = "0x2E7909C", Offset = "0x2E7909C", VA = "0x2E7909C")]
	private void \u073Bݲձݕ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x0600066E RID: 1646 RVA: 0x000260B8 File Offset: 0x000242B8
	[Token(Token = "0x600066E")]
	[Address(RVA = "0x2E79100", Offset = "0x2E79100", VA = "0x2E79100")]
	private void \u07AC١\u0711\u0742()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600066F RID: 1647 RVA: 0x00026110 File Offset: 0x00024310
	[Token(Token = "0x600066F")]
	[Address(RVA = "0x2E791D8", Offset = "0x2E791D8", VA = "0x2E791D8")]
	private void ӭࡖݲ\u05BD()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)54;
	}

	// Token: 0x06000670 RID: 1648 RVA: 0x00026150 File Offset: 0x00024350
	[Token(Token = "0x6000670")]
	[Address(RVA = "0x2E7923C", Offset = "0x2E7923C", VA = "0x2E7923C")]
	private void ڏי\u06E6\u070A()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u07EFԣ\u073F\u05A7(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000671 RID: 1649 RVA: 0x000261B8 File Offset: 0x000243B8
	[Token(Token = "0x6000671")]
	[Address(RVA = "0x2E79310", Offset = "0x2E79310", VA = "0x2E79310")]
	private void \u0892\u061B\u0606\u06D8()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.كմ\u06D9ۊ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
	}

	// Token: 0x06000672 RID: 1650 RVA: 0x0002620C File Offset: 0x0002440C
	[Token(Token = "0x6000672")]
	[Address(RVA = "0x2E793E8", Offset = "0x2E793E8", VA = "0x2E793E8")]
	private void ڍ\u058Bݗࡣ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)77;
	}

	// Token: 0x06000673 RID: 1651 RVA: 0x0002624C File Offset: 0x0002444C
	[Token(Token = "0x6000673")]
	[Address(RVA = "0x2E7944C", Offset = "0x2E7944C", VA = "0x2E7944C")]
	private void \u0595מՔ\u055F()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u0557ԯ\u081B\u0731(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000674 RID: 1652 RVA: 0x000262A0 File Offset: 0x000244A0
	[Token(Token = "0x6000674")]
	[Address(RVA = "0x2E7951C", Offset = "0x2E7951C", VA = "0x2E7951C")]
	private void \u0825ӆا\u07BE()
	{
		long useGravity = 0L;
		bool enabled = base.enabled;
		this.\u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
	}

	// Token: 0x06000675 RID: 1653 RVA: 0x000262D0 File Offset: 0x000244D0
	[Token(Token = "0x6000675")]
	[Address(RVA = "0x2E79580", Offset = "0x2E79580", VA = "0x2E79580")]
	private void Start()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000676 RID: 1654 RVA: 0x00026308 File Offset: 0x00024508
	[Token(Token = "0x6000676")]
	[Address(RVA = "0x2E795E4", Offset = "0x2E795E4", VA = "0x2E795E4")]
	private void \u05B9Ջԇݪ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ܤڮԡ\u06E9(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000677 RID: 1655 RVA: 0x00026370 File Offset: 0x00024570
	[Token(Token = "0x6000677")]
	[Address(RVA = "0x2E796BC", Offset = "0x2E796BC", VA = "0x2E796BC")]
	private void ԞԌ\u086FՇ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000678 RID: 1656 RVA: 0x000263A8 File Offset: 0x000245A8
	[Token(Token = "0x6000678")]
	[Address(RVA = "0x2E79720", Offset = "0x2E79720", VA = "0x2E79720")]
	private void \u0609ݢ\u05F7\u0744()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ڹیߢ\u0704(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000679 RID: 1657 RVA: 0x00026410 File Offset: 0x00024610
	[Token(Token = "0x6000679")]
	[Address(RVA = "0x2E797F8", Offset = "0x2E797F8", VA = "0x2E797F8")]
	private void \u06D6ې\u083Bࠉ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x0600067A RID: 1658 RVA: 0x00026448 File Offset: 0x00024648
	[Token(Token = "0x600067A")]
	[Address(RVA = "0x2E7985C", Offset = "0x2E7985C", VA = "0x2E7985C")]
	private void Ա\u07B9ߒݗ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ةԣ\u06D8\u0606(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600067B RID: 1659 RVA: 0x000264A4 File Offset: 0x000246A4
	[Token(Token = "0x600067B")]
	[Address(RVA = "0x2E7992C", Offset = "0x2E7992C", VA = "0x2E7992C")]
	private void ޙߍ\u081A\u0651()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x0600067C RID: 1660 RVA: 0x000264DC File Offset: 0x000246DC
	[Token(Token = "0x600067C")]
	[Address(RVA = "0x2E79990", Offset = "0x2E79990", VA = "0x2E79990")]
	private void ߄Ӄ\u0613ھ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600067D RID: 1661 RVA: 0x0002650C File Offset: 0x0002470C
	[Token(Token = "0x600067D")]
	[Address(RVA = "0x2E799F4", Offset = "0x2E799F4", VA = "0x2E799F4")]
	private void \u0604\u07B7ࢺݭ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.߃տ\u0731ڒ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600067E RID: 1662 RVA: 0x00026574 File Offset: 0x00024774
	[Token(Token = "0x600067E")]
	[Address(RVA = "0x2E79ACC", Offset = "0x2E79ACC", VA = "0x2E79ACC")]
	private void \u05BBږ\u060Cࡑ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u087FӟӰӞ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600067F RID: 1663 RVA: 0x000265DC File Offset: 0x000247DC
	[Token(Token = "0x600067F")]
	[Address(RVA = "0x2E79BA0", Offset = "0x2E79BA0", VA = "0x2E79BA0")]
	private void ڿ\u06E6\u088E\u06FD()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ڧ\u0593\u0732ք(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000680 RID: 1664 RVA: 0x00026638 File Offset: 0x00024838
	[Token(Token = "0x6000680")]
	[Address(RVA = "0x2E79C70", Offset = "0x2E79C70", VA = "0x2E79C70")]
	private void \u089Fکߦݭ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u085Fԩ\u0700١(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000681 RID: 1665 RVA: 0x000266A0 File Offset: 0x000248A0
	[Token(Token = "0x6000681")]
	[Address(RVA = "0x2E79D44", Offset = "0x2E79D44", VA = "0x2E79D44")]
	private void \u07BBۯ٤ࠍ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ݯܫס\u05BE(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000682 RID: 1666 RVA: 0x000266FC File Offset: 0x000248FC
	[Token(Token = "0x6000682")]
	[Address(RVA = "0x2E79E14", Offset = "0x2E79E14", VA = "0x2E79E14")]
	private void ԣ\u0731\u0879ܕ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ࡣر\u07A7օ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000683 RID: 1667 RVA: 0x00026760 File Offset: 0x00024960
	[Token(Token = "0x6000683")]
	[Address(RVA = "0x2E79EEC", Offset = "0x2E79EEC", VA = "0x2E79EEC")]
	private void \u06E3תثԸ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ڧ\u0593\u0732ք(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000684 RID: 1668 RVA: 0x000267C8 File Offset: 0x000249C8
	[Token(Token = "0x6000684")]
	[Address(RVA = "0x2E79FC4", Offset = "0x2E79FC4", VA = "0x2E79FC4")]
	private void ޞۊաݛ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u06DE\u0880ܡס(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000685 RID: 1669 RVA: 0x00026830 File Offset: 0x00024A30
	[Token(Token = "0x6000685")]
	[Address(RVA = "0x2E7A09C", Offset = "0x2E7A09C", VA = "0x2E7A09C")]
	private void \u065F\u0839ܤ\u073C()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000686 RID: 1670 RVA: 0x00026868 File Offset: 0x00024A68
	[Token(Token = "0x6000686")]
	[Address(RVA = "0x2E7A100", Offset = "0x2E7A100", VA = "0x2E7A100")]
	private void ۍ\u05CAۋݿ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ӷ߄\u0738\u0656(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000687 RID: 1671 RVA: 0x000268C4 File Offset: 0x00024AC4
	[Token(Token = "0x6000687")]
	[Address(RVA = "0x2E7A1D0", Offset = "0x2E7A1D0", VA = "0x2E7A1D0")]
	private void \u05F5ߪތӝ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)37;
	}

	// Token: 0x06000688 RID: 1672 RVA: 0x00026904 File Offset: 0x00024B04
	[Token(Token = "0x6000688")]
	[Address(RVA = "0x2E7A234", Offset = "0x2E7A234", VA = "0x2E7A234")]
	private void \u0739߉ڵݞ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)90;
	}

	// Token: 0x06000689 RID: 1673 RVA: 0x00026944 File Offset: 0x00024B44
	[Token(Token = "0x6000689")]
	[Address(RVA = "0x2E7A298", Offset = "0x2E7A298", VA = "0x2E7A298")]
	private void ۲ڂ\u05B1ڨ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)114;
	}

	// Token: 0x0600068A RID: 1674 RVA: 0x00026984 File Offset: 0x00024B84
	[Token(Token = "0x600068A")]
	[Address(RVA = "0x2E7A2FC", Offset = "0x2E7A2FC", VA = "0x2E7A2FC")]
	private void \u0655ߔژԜ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ڧ\u0593\u0732ք(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600068B RID: 1675 RVA: 0x000269EC File Offset: 0x00024BEC
	[Token(Token = "0x600068B")]
	[Address(RVA = "0x2E7A3D0", Offset = "0x2E7A3D0", VA = "0x2E7A3D0")]
	private void ա\u0731ࢺۊ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.\u05CBࡓࠏԃ(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600068C RID: 1676 RVA: 0x00026A54 File Offset: 0x00024C54
	[Token(Token = "0x600068C")]
	[Address(RVA = "0x2E7A4A8", Offset = "0x2E7A4A8", VA = "0x2E7A4A8")]
	public GravityBody()
	{
	}

	// Token: 0x0600068D RID: 1677 RVA: 0x00026A68 File Offset: 0x00024C68
	[Token(Token = "0x600068D")]
	[Address(RVA = "0x2E7A4B0", Offset = "0x2E7A4B0", VA = "0x2E7A4B0")]
	private void \u0818ՠש\u0731()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x0600068E RID: 1678 RVA: 0x00026AA0 File Offset: 0x00024CA0
	[Token(Token = "0x600068E")]
	[Address(RVA = "0x2E7A514", Offset = "0x2E7A514", VA = "0x2E7A514")]
	private void ݲ\u06E6ҽࡩ()
	{
		GravityAttractor u05F8_u05A9_u06D7ڍ = this.\u05F8\u05A9\u06D7ڍ;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		u05F8_u05A9_u06D7ڍ.ڹیߢ\u0704(u05CBݝհن);
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600068F RID: 1679 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600068F")]
	[Address(RVA = "0x2E7A5E4", Offset = "0x2E7A5E4", VA = "0x2E7A5E4")]
	private void Աࢦ\u05CAޡ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000690 RID: 1680 RVA: 0x00026AFC File Offset: 0x00024CFC
	[Token(Token = "0x6000690")]
	[Address(RVA = "0x2E7A6BC", Offset = "0x2E7A6BC", VA = "0x2E7A6BC")]
	private void ࢥ\u081CՕࡋ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000691 RID: 1681 RVA: 0x00026B34 File Offset: 0x00024D34
	[Token(Token = "0x6000691")]
	[Address(RVA = "0x2E7A720", Offset = "0x2E7A720", VA = "0x2E7A720")]
	private void ןٮ\u061FԺ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000692 RID: 1682 RVA: 0x00026B6C File Offset: 0x00024D6C
	[Token(Token = "0x6000692")]
	[Address(RVA = "0x2E7A784", Offset = "0x2E7A784", VA = "0x2E7A784")]
	private void ࡩݮڢՠ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000693 RID: 1683 RVA: 0x00026BA4 File Offset: 0x00024DA4
	[Token(Token = "0x6000693")]
	[Address(RVA = "0x2E7A7E8", Offset = "0x2E7A7E8", VA = "0x2E7A7E8")]
	private void \u05AAࢦ\u060AԞ()
	{
	}

	// Token: 0x06000694 RID: 1684 RVA: 0x00026BBC File Offset: 0x00024DBC
	[Token(Token = "0x6000694")]
	[Address(RVA = "0x2E7A8C0", Offset = "0x2E7A8C0", VA = "0x2E7A8C0")]
	private void \u05C1ܡԘޘ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000695 RID: 1685 RVA: 0x00026BF4 File Offset: 0x00024DF4
	[Token(Token = "0x6000695")]
	[Address(RVA = "0x2E7A924", Offset = "0x2E7A924", VA = "0x2E7A924")]
	private void \u07EBࠎיࡂ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000696 RID: 1686 RVA: 0x00026C2C File Offset: 0x00024E2C
	[Token(Token = "0x6000696")]
	[Address(RVA = "0x2E7A988", Offset = "0x2E7A988", VA = "0x2E7A988")]
	private void \u0733ߜܣԻ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000697 RID: 1687 RVA: 0x00026C64 File Offset: 0x00024E64
	[Token(Token = "0x6000697")]
	[Address(RVA = "0x2E7A9EC", Offset = "0x2E7A9EC", VA = "0x2E7A9EC")]
	private void \u0652\u058Bک\u061C()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000698 RID: 1688 RVA: 0x00026C9C File Offset: 0x00024E9C
	[Token(Token = "0x6000698")]
	[Address(RVA = "0x2E7AA50", Offset = "0x2E7AA50", VA = "0x2E7AA50")]
	private void ۊո\u0612\u0595()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
	}

	// Token: 0x06000699 RID: 1689 RVA: 0x00026CD4 File Offset: 0x00024ED4
	[Token(Token = "0x6000699")]
	[Address(RVA = "0x2E7AAB4", Offset = "0x2E7AAB4", VA = "0x2E7AAB4")]
	private void ߗࠊ\u05CAܝ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)34;
	}

	// Token: 0x0600069A RID: 1690 RVA: 0x00026D14 File Offset: 0x00024F14
	[Token(Token = "0x600069A")]
	[Address(RVA = "0x2E7AB18", Offset = "0x2E7AB18", VA = "0x2E7AB18")]
	private void \u0558ݕݤݮ()
	{
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		long useGravity = 1L;
		u05CBݝհن.useGravity = (useGravity != 0L);
		this.\u05CBݝհن.constraints = (RigidbodyConstraints)121;
	}

	// Token: 0x0600069B RID: 1691 RVA: 0x00026D54 File Offset: 0x00024F54
	[Token(Token = "0x600069B")]
	[Address(RVA = "0x2E7AB7C", Offset = "0x2E7AB7C", VA = "0x2E7AB7C")]
	private void ӎ\u07F2Ֆ\u05CA()
	{
		Rigidbody u05CBݝհن = this.\u05CBݝհن;
		bool enabled = this.\u081B\u070Aߢࡁ.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.\u05CBݝհن = component;
		Rigidbody u05CBݝհن2 = this.\u05CBݝհن;
		long useGravity = 0L;
		u05CBݝհن2.useGravity = (useGravity != 0L);
	}

	// Token: 0x040000F3 RID: 243
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000F3")]
	public GravityAttractor \u05F8\u05A9\u06D7ڍ;

	// Token: 0x040000F4 RID: 244
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000F4")]
	public Rigidbody \u05CBݝհن;

	// Token: 0x040000F5 RID: 245
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40000F5")]
	public GravityBody \u081B\u070Aߢࡁ;

	// Token: 0x040000F6 RID: 246
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40000F6")]
	public bool Ր\u05B9ڍݏ;
}
