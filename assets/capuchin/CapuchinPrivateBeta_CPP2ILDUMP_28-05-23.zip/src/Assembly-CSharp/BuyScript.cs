﻿using System;
using System.Collections;
using CapuchinPlayFab;
using Cpp2IlInjected;
using Oculus.Platform;
using Oculus.Platform.Models;
using PlayFab;
using PlayFab.ClientModels;
using TMPro;
using UnityEngine;

// Token: 0x020000A1 RID: 161
[Token(Token = "0x20000A1")]
public class BuyScript : MonoBehaviour
{
	// Token: 0x060017C3 RID: 6083 RVA: 0x000840E0 File Offset: 0x000822E0
	[Token(Token = "0x60017C3")]
	[Address(RVA = "0x2720A14", Offset = "0x2720A14", VA = "0x2720A14")]
	private void \u0894\u0657\u065B\u089E(Message<Purchase> Ҿࠐ\u0708ࡂ)
	{
		bool isError = Ҿࠐ\u0708ࡂ.IsError;
		IEnumerator routine = this.\u07FD\u055Fࡅݜ();
		Coroutine coroutine = base.StartCoroutine(routine);
		this.\u0899ޒؠދ();
		this.\u0605\u0733\u0829ܪ();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060017C4 RID: 6084 RVA: 0x00084128 File Offset: 0x00082328
	[Token(Token = "0x60017C4")]
	[Address(RVA = "0x2720D50", Offset = "0x2720D50", VA = "0x2720D50")]
	private void ࢧٵҽ\u06E3(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		this.ڐۊࠔ\u0651.\u0530\u05FDސ\u07B0();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060017C5 RID: 6085 RVA: 0x00084158 File Offset: 0x00082358
	[Token(Token = "0x60017C5")]
	[Address(RVA = "0x2720D90", Offset = "0x2720D90", VA = "0x2720D90")]
	private void \u05AF\u0818Պ\u05F7(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		this.ڐۊࠔ\u0651.ۆ\u05C8خ\u0612();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060017C6 RID: 6086 RVA: 0x00084188 File Offset: 0x00082388
	[Token(Token = "0x60017C6")]
	[Address(RVA = "0x2720DD0", Offset = "0x2720DD0", VA = "0x2720DD0")]
	private void ټ\u086Dދ\u07F9()
	{
		Request<PurchaseList> viewerPurchases = IAP.GetViewerPurchases(false);
		Message<PurchaseList>.Callback callback = new Message.Callback(this, typeof(Message<PurchaseList>.Callback).TypeHandle);
		Request<PurchaseList> request = viewerPurchases.OnComplete(callback);
	}

	// Token: 0x060017C7 RID: 6087 RVA: 0x000841B8 File Offset: 0x000823B8
	[Token(Token = "0x60017C7")]
	[Address(RVA = "0x2720E9C", Offset = "0x2720E9C", VA = "0x2720E9C")]
	private void ղӆ\u083Cࡠ()
	{
		Message<PurchaseList>.Callback callback;
		Request<PurchaseList> request = IAP.GetViewerPurchases(false).OnComplete(callback);
	}

	// Token: 0x060017C8 RID: 6088 RVA: 0x000841D8 File Offset: 0x000823D8
	[Token(Token = "0x60017C8")]
	[Address(RVA = "0x2720F68", Offset = "0x2720F68", VA = "0x2720F68")]
	private void \u07BE\u085Fݔݢ(Message<PurchaseList> Ҿࠐ\u0708ࡂ)
	{
		bool isError = Ҿࠐ\u0708ࡂ.IsError;
		IEnumerator routine = this.\u07FD\u055Fࡅݜ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060017C9 RID: 6089 RVA: 0x0008425C File Offset: 0x0008245C
	[Token(Token = "0x60017C9")]
	[Address(RVA = "0x2720AF8", Offset = "0x2720AF8", VA = "0x2720AF8")]
	private void \u0899ޒؠދ()
	{
		Message<PurchaseList>.Callback callback;
		Request<PurchaseList> request = IAP.GetViewerPurchases(true).OnComplete(callback);
	}

	// Token: 0x060017CA RID: 6090 RVA: 0x0008427C File Offset: 0x0008247C
	[Token(Token = "0x60017CA")]
	[Address(RVA = "0x272126C", Offset = "0x272126C", VA = "0x272126C")]
	private void ق\u0701\u06DAՉ(Message<Purchase> Ҿࠐ\u0708ࡂ)
	{
		bool isError = Ҿࠐ\u0708ࡂ.IsError;
		IEnumerator routine = this.\u07FD\u055Fࡅݜ();
		Coroutine coroutine = base.StartCoroutine(routine);
		this.\u07F2\u061Fࡕې();
		this.\u0605\u0733\u0829ܪ();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060017CB RID: 6091 RVA: 0x000842C4 File Offset: 0x000824C4
	[Token(Token = "0x60017CB")]
	[Address(RVA = "0x27213A4", Offset = "0x27213A4", VA = "0x27213A4")]
	private void יص\u07F6\u058F()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "Player";
		int u064C_u073Eوԝ = this.\u064C\u073Eوԝ;
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x060017CC RID: 6092 RVA: 0x000842F4 File Offset: 0x000824F4
	[Token(Token = "0x60017CC")]
	[Address(RVA = "0x2721530", Offset = "0x2721530", VA = "0x2721530")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		if (typeof(Core).TypeHandle == null)
		{
		}
		Core.Initialize("");
		this.ݩ\u0618\u07EC\u0651();
	}

	// Token: 0x060017CD RID: 6093 RVA: 0x00084338 File Offset: 0x00082538
	[Token(Token = "0x60017CD")]
	[Address(RVA = "0x27216EC", Offset = "0x27216EC", VA = "0x27216EC")]
	private void ࢺݤ\u06DCԩ()
	{
		Message<PurchaseList>.Callback callback;
		Request<PurchaseList> request = IAP.GetViewerPurchases(false).OnComplete(callback);
	}

	// Token: 0x060017CE RID: 6094 RVA: 0x00084358 File Offset: 0x00082558
	[Token(Token = "0x60017CE")]
	[Address(RVA = "0x27217B8", Offset = "0x27217B8", VA = "0x27217B8")]
	private void ܩ\u05BDӄ\u082F(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		this.ڐۊࠔ\u0651.\u05A9ըկڲ();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060017CF RID: 6095 RVA: 0x00084388 File Offset: 0x00082588
	[Token(Token = "0x60017CF")]
	[Address(RVA = "0x27217F8", Offset = "0x27217F8", VA = "0x27217F8")]
	private IEnumerator ٱݨӓ\u07BE()
	{
		long <>1__state;
		BuyScript.ەأל\u05B1 ەأל_u05B = new BuyScript.ەأל\u05B1((int)<>1__state);
		<>1__state = 1L;
		ەأל_u05B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060017D0 RID: 6096 RVA: 0x000843AC File Offset: 0x000825AC
	[Token(Token = "0x60017D0")]
	[Address(RVA = "0x2721870", Offset = "0x2721870", VA = "0x2721870")]
	private void \u055FݷܫӜ(Message<PurchaseList> Ҿࠐ\u0708ࡂ)
	{
		bool isError = Ҿࠐ\u0708ࡂ.IsError;
		IEnumerator enumerator = this.\u07FD\u055Fࡅݜ();
	}

	// Token: 0x060017D1 RID: 6097 RVA: 0x00084430 File Offset: 0x00082630
	[Token(Token = "0x60017D1")]
	[Address(RVA = "0x2721B74", Offset = "0x2721B74", VA = "0x2721B74")]
	public BuyScript()
	{
		string[] u074Cݖ_u086F_u05C = new string[3];
		if ("1BN" != null)
		{
			if ("1BN" != null)
			{
				return;
			}
		}
		else if ("2BN" != null)
		{
			if ("2BN" != null)
			{
				return;
			}
		}
		else
		{
			if ("5BN" == null)
			{
				this.\u074Cݖ\u086F\u05C7 = u074Cݖ_u086F_u05C;
				base..ctor();
				return;
			}
			if ("5BN" != null)
			{
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060017D2 RID: 6098 RVA: 0x00084498 File Offset: 0x00082698
	[Token(Token = "0x60017D2")]
	[Address(RVA = "0x2721CF4", Offset = "0x2721CF4", VA = "0x2721CF4")]
	private void ٢\u086Bޚݰ(Message<Purchase> Ҿࠐ\u0708ࡂ)
	{
		bool isError = Ҿࠐ\u0708ࡂ.IsError;
		IEnumerator routine = this.ٱݨӓ\u07BE();
		Coroutine coroutine = base.StartCoroutine(routine);
		this.\u07F2\u061Fࡕې();
		this.\u0605\u0733\u0829ܪ();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x060017D3 RID: 6099 RVA: 0x000844D4 File Offset: 0x000826D4
	[Token(Token = "0x60017D3")]
	[Address(RVA = "0x2721D5C", Offset = "0x2721D5C", VA = "0x2721D5C")]
	private void \u082F\u074Cڢ\u06FE(Message<PurchaseList> Ҿࠐ\u0708ࡂ)
	{
		bool isError = Ҿࠐ\u0708ࡂ.IsError;
		IEnumerator routine = this.Փࠁࠌԏ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060017D4 RID: 6100 RVA: 0x00084560 File Offset: 0x00082760
	[Token(Token = "0x60017D4")]
	[Address(RVA = "0x2722060", Offset = "0x2722060", VA = "0x2722060")]
	private IEnumerator Փࠁࠌԏ()
	{
		long <>1__state;
		BuyScript.ەأל\u05B1 ەأל_u05B = new BuyScript.ەأל\u05B1((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x060017D5 RID: 6101 RVA: 0x0008457C File Offset: 0x0008277C
	[Token(Token = "0x60017D5")]
	[Address(RVA = "0x27220D8", Offset = "0x27220D8", VA = "0x27220D8")]
	private void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Agreed";
		if (typeof(Core).TypeHandle == null)
		{
		}
		Core.Initialize("PURCHASE");
		this.\u07AD\u0707ֈ\u0640();
	}

	// Token: 0x060017D6 RID: 6102 RVA: 0x000845C0 File Offset: 0x000827C0
	[Token(Token = "0x60017D6")]
	[Address(RVA = "0x2721610", Offset = "0x2721610", VA = "0x2721610")]
	public void ݩ\u0618\u07EC\u0651()
	{
		Message<Purchase>.Callback callback;
		Request<Purchase> request = IAP.LaunchCheckoutFlow(this.Ә\u07B8ߖ\u0897).OnComplete(callback);
	}

	// Token: 0x060017D7 RID: 6103 RVA: 0x000845E8 File Offset: 0x000827E8
	[Token(Token = "0x60017D7")]
	[Address(RVA = "0x27221B8", Offset = "0x27221B8", VA = "0x27221B8")]
	public void \u07AD\u0707ֈ\u0640()
	{
		Message<Purchase>.Callback callback;
		Request<Purchase> request = IAP.LaunchCheckoutFlow(this.Ә\u07B8ߖ\u0897).OnComplete(callback);
	}

	// Token: 0x060017D8 RID: 6104 RVA: 0x00084610 File Offset: 0x00082810
	[Token(Token = "0x60017D8")]
	[Address(RVA = "0x2722294", Offset = "0x2722294", VA = "0x2722294")]
	private void ڷ\u07AF߄ٳ(ModifyUserVirtualCurrencyResult Ӌࢥ\u0876Ֆ)
	{
		this.ڐۊࠔ\u0651.\u06E0څԚލ();
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060017D9 RID: 6105 RVA: 0x00084640 File Offset: 0x00082840
	[Token(Token = "0x60017D9")]
	[Address(RVA = "0x27212D8", Offset = "0x27212D8", VA = "0x27212D8")]
	private void \u07F2\u061Fࡕې()
	{
		Message<PurchaseList>.Callback callback;
		Request<PurchaseList> request = IAP.GetViewerPurchases(false).OnComplete(callback);
	}

	// Token: 0x060017DA RID: 6106 RVA: 0x00084660 File Offset: 0x00082860
	[Token(Token = "0x60017DA")]
	[Address(RVA = "0x2720BC4", Offset = "0x2720BC4", VA = "0x2720BC4")]
	private void \u0605\u0733\u0829ܪ()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "BN";
		int u064C_u073Eوԝ = this.\u064C\u073Eوԝ;
		if (typeof(PlayFabClientAPI).TypeHandle == null)
		{
		}
	}

	// Token: 0x060017DB RID: 6107 RVA: 0x00084690 File Offset: 0x00082890
	[Token(Token = "0x60017DB")]
	[Address(RVA = "0x27222D4", Offset = "0x27222D4", VA = "0x27222D4")]
	private void ث\u0741\u07BC\u0597(PlayFabError ہ\u0613ܢ\u07B4)
	{
		IEnumerator routine = this.\u07FD\u055Fࡅݜ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060017DC RID: 6108 RVA: 0x000846AC File Offset: 0x000828AC
	[Token(Token = "0x60017DC")]
	[Address(RVA = "0x2722300", Offset = "0x2722300", VA = "0x2722300")]
	private void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You Already Own This Item";
		if (typeof(Core).TypeHandle == null)
		{
		}
		Core.Initialize("spooky guy true");
		this.ݩ\u0618\u07EC\u0651();
	}

	// Token: 0x060017DD RID: 6109 RVA: 0x000846F0 File Offset: 0x000828F0
	[Token(Token = "0x60017DD")]
	[Address(RVA = "0x2720A80", Offset = "0x2720A80", VA = "0x2720A80")]
	private IEnumerator \u07FD\u055Fࡅݜ()
	{
		long <>1__state;
		BuyScript.ەأל\u05B1 ەأל_u05B = new BuyScript.ەأל\u05B1((int)<>1__state);
		<>1__state = 0L;
		ەأל_u05B.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x040002F3 RID: 755
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002F3")]
	public string Ә\u07B8ߖ\u0897;

	// Token: 0x040002F4 RID: 756
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002F4")]
	public int \u064C\u073Eوԝ;

	// Token: 0x040002F5 RID: 757
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40002F5")]
	private string[] \u074Cݖ\u086F\u05C7;

	// Token: 0x040002F6 RID: 758
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40002F6")]
	public LoginManager ڐۊࠔ\u0651;

	// Token: 0x040002F7 RID: 759
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40002F7")]
	public DoorLerp \u0558\u0654ڄ\u087E;

	// Token: 0x040002F8 RID: 760
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40002F8")]
	public TextMeshPro \u0656\u0898ر\u0896;
}
