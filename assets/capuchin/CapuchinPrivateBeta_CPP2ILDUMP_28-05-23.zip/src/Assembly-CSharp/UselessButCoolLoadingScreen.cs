﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E1 RID: 225
[Token(Token = "0x20000E1")]
public class UselessButCoolLoadingScreen : MonoBehaviour
{
	// Token: 0x060022C6 RID: 8902 RVA: 0x000B79B0 File Offset: 0x000B5BB0
	[Token(Token = "0x60022C6")]
	[Address(RVA = "0x2C77A0C", Offset = "0x2C77A0C", VA = "0x2C77A0C")]
	public UselessButCoolLoadingScreen()
	{
	}

	// Token: 0x060022C7 RID: 8903 RVA: 0x000B79C4 File Offset: 0x000B5BC4
	[Token(Token = "0x60022C7")]
	[Address(RVA = "0x2C77A14", Offset = "0x2C77A14", VA = "0x2C77A14")]
	public void ڑߒجވ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)17443;
	}

	// Token: 0x060022C8 RID: 8904 RVA: 0x000B7A28 File Offset: 0x000B5C28
	[Token(Token = "0x60022C8")]
	[Address(RVA = "0x2C77A9C", Offset = "0x2C77A9C", VA = "0x2C77A9C")]
	public void \u0590\u0882\u0883ࡦ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
	}

	// Token: 0x060022C9 RID: 8905 RVA: 0x000B7A80 File Offset: 0x000B5C80
	[Token(Token = "0x60022C9")]
	[Address(RVA = "0x2C77B28", Offset = "0x2C77B28", VA = "0x2C77B28")]
	public void \u0614ࢥӴ\u086C()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)16384;
	}

	// Token: 0x060022CA RID: 8906 RVA: 0x000B7AE4 File Offset: 0x000B5CE4
	[Token(Token = "0x60022CA")]
	[Address(RVA = "0x2C77BB4", Offset = "0x2C77BB4", VA = "0x2C77BB4")]
	public void \u05C4ݳ\u05BCࡂ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)32768;
	}

	// Token: 0x060022CB RID: 8907 RVA: 0x000B7B48 File Offset: 0x000B5D48
	[Token(Token = "0x60022CB")]
	[Address(RVA = "0x2C77C40", Offset = "0x2C77C40", VA = "0x2C77C40")]
	public void \u061B\u05EEوۈ()
	{
		float deltaTime = Time.deltaTime;
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		int num = 32768;
		this.ݶՈהՇ = (float)num;
	}

	// Token: 0x060022CC RID: 8908 RVA: 0x000B7B88 File Offset: 0x000B5D88
	[Token(Token = "0x60022CC")]
	[Address(RVA = "0x2C77CC8", Offset = "0x2C77CC8", VA = "0x2C77CC8")]
	public void ԣԭՋࠏ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)49152;
	}

	// Token: 0x060022CD RID: 8909 RVA: 0x000B7BE0 File Offset: 0x000B5DE0
	[Token(Token = "0x60022CD")]
	[Address(RVA = "0x2C77D50", Offset = "0x2C77D50", VA = "0x2C77D50")]
	public void ӻӒݝ߃()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060022CE RID: 8910 RVA: 0x000B7C0C File Offset: 0x000B5E0C
	[Token(Token = "0x60022CE")]
	[Address(RVA = "0x2C77DDC", Offset = "0x2C77DDC", VA = "0x2C77DDC")]
	public void ܣ\u086E\u05CF\u06D8()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)49152;
	}

	// Token: 0x060022CF RID: 8911 RVA: 0x000B7C64 File Offset: 0x000B5E64
	[Token(Token = "0x60022CF")]
	[Address(RVA = "0x2C77E64", Offset = "0x2C77E64", VA = "0x2C77E64")]
	public void \u0881ݗӟ\u07BD()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)57344;
	}

	// Token: 0x060022D0 RID: 8912 RVA: 0x000B7CC8 File Offset: 0x000B5EC8
	[Token(Token = "0x60022D0")]
	[Address(RVA = "0x2C77EF0", Offset = "0x2C77EF0", VA = "0x2C77EF0")]
	public void ԟ\u086Cޣ\u055E()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)17333;
	}

	// Token: 0x060022D1 RID: 8913 RVA: 0x000B7D20 File Offset: 0x000B5F20
	[Token(Token = "0x60022D1")]
	[Address(RVA = "0x2C77F74", Offset = "0x2C77F74", VA = "0x2C77F74")]
	public void \u0654ޛ\u07FAذ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)32768;
	}

	// Token: 0x060022D2 RID: 8914 RVA: 0x000B7D84 File Offset: 0x000B5F84
	[Token(Token = "0x60022D2")]
	[Address(RVA = "0x2C78000", Offset = "0x2C78000", VA = "0x2C78000")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)17628;
	}

	// Token: 0x060022D3 RID: 8915 RVA: 0x000B7DE8 File Offset: 0x000B5FE8
	[Token(Token = "0x60022D3")]
	[Address(RVA = "0x2C78088", Offset = "0x2C78088", VA = "0x2C78088")]
	public void ژךՈ\u0597()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)32768;
	}

	// Token: 0x060022D4 RID: 8916 RVA: 0x000B7E40 File Offset: 0x000B6040
	[Token(Token = "0x60022D4")]
	[Address(RVA = "0x2C78110", Offset = "0x2C78110", VA = "0x2C78110")]
	public void \u05F7ԝߠӱ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)49152;
	}

	// Token: 0x060022D5 RID: 8917 RVA: 0x000B7E98 File Offset: 0x000B6098
	[Token(Token = "0x60022D5")]
	[Address(RVA = "0x2C78194", Offset = "0x2C78194", VA = "0x2C78194")]
	public void ࡊ\u0592\u07AB\u05B2()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)32768;
	}

	// Token: 0x060022D6 RID: 8918 RVA: 0x000B7EFC File Offset: 0x000B60FC
	[Token(Token = "0x60022D6")]
	[Address(RVA = "0x2C78220", Offset = "0x2C78220", VA = "0x2C78220")]
	public void ڃրӢԖ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)17443;
	}

	// Token: 0x060022D7 RID: 8919 RVA: 0x000B7F54 File Offset: 0x000B6154
	[Token(Token = "0x60022D7")]
	[Address(RVA = "0x2C782A4", Offset = "0x2C782A4", VA = "0x2C782A4")]
	public void \u0821\u059Fӕ\u0607()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)40960;
	}

	// Token: 0x060022D8 RID: 8920 RVA: 0x000B7FAC File Offset: 0x000B61AC
	[Token(Token = "0x60022D8")]
	[Address(RVA = "0x2C78328", Offset = "0x2C78328", VA = "0x2C78328")]
	public void ժ\u065Dԯࡘ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)16384;
	}

	// Token: 0x060022D9 RID: 8921 RVA: 0x000B8004 File Offset: 0x000B6204
	[Token(Token = "0x60022D9")]
	[Address(RVA = "0x2C783B0", Offset = "0x2C783B0", VA = "0x2C783B0")]
	public void \u0732ڙԒࢺ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)40960;
	}

	// Token: 0x060022DA RID: 8922 RVA: 0x000B805C File Offset: 0x000B625C
	[Token(Token = "0x60022DA")]
	[Address(RVA = "0x2C78438", Offset = "0x2C78438", VA = "0x2C78438")]
	public void \u061Fࡆ\u086F\u07B0()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)17126;
	}

	// Token: 0x060022DB RID: 8923 RVA: 0x000B80B0 File Offset: 0x000B62B0
	[Token(Token = "0x60022DB")]
	[Address(RVA = "0x2C784BC", Offset = "0x2C784BC", VA = "0x2C784BC")]
	public void Ҿࢹؼס()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)32768;
	}

	// Token: 0x060022DC RID: 8924 RVA: 0x000B8114 File Offset: 0x000B6314
	[Token(Token = "0x60022DC")]
	[Address(RVA = "0x2C78548", Offset = "0x2C78548", VA = "0x2C78548")]
	public void ں٢ࡡ\u05EC()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)49152;
	}

	// Token: 0x060022DD RID: 8925 RVA: 0x000B8174 File Offset: 0x000B6374
	[Token(Token = "0x60022DD")]
	[Address(RVA = "0x2C785D4", Offset = "0x2C785D4", VA = "0x2C785D4")]
	public void طӏܙࢺ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)17060;
	}

	// Token: 0x060022DE RID: 8926 RVA: 0x000B81D8 File Offset: 0x000B63D8
	[Token(Token = "0x60022DE")]
	[Address(RVA = "0x2C7865C", Offset = "0x2C7865C", VA = "0x2C7865C")]
	public void \u0870\u05B3Ց\u066A()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)32768;
	}

	// Token: 0x060022DF RID: 8927 RVA: 0x000B823C File Offset: 0x000B643C
	[Token(Token = "0x60022DF")]
	[Address(RVA = "0x2C786E8", Offset = "0x2C786E8", VA = "0x2C786E8")]
	public void צ\u0874ڵ\u059A()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)57344;
	}

	// Token: 0x060022E0 RID: 8928 RVA: 0x000B8294 File Offset: 0x000B6494
	[Token(Token = "0x60022E0")]
	[Address(RVA = "0x2C78770", Offset = "0x2C78770", VA = "0x2C78770")]
	public void ܪ\u07BB\u086Bࠆ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)ނ_u05AFՉݿ2;
	}

	// Token: 0x060022E1 RID: 8929 RVA: 0x000B82F4 File Offset: 0x000B64F4
	[Token(Token = "0x60022E1")]
	[Address(RVA = "0x2C787F8", Offset = "0x2C787F8", VA = "0x2C787F8")]
	public void \u07FE\u0882Զ\u066D()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)49152;
	}

	// Token: 0x060022E2 RID: 8930 RVA: 0x000B8358 File Offset: 0x000B6558
	[Token(Token = "0x60022E2")]
	[Address(RVA = "0x2C78884", Offset = "0x2C78884", VA = "0x2C78884")]
	public void \u07FB\u07BC\u0887ӟ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)57344;
	}

	// Token: 0x060022E3 RID: 8931 RVA: 0x000B83BC File Offset: 0x000B65BC
	[Token(Token = "0x60022E3")]
	[Address(RVA = "0x2C78910", Offset = "0x2C78910", VA = "0x2C78910")]
	public void Ҽ\u08B5ځ\u0658()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
		}
	}

	// Token: 0x060022E4 RID: 8932 RVA: 0x000B83E8 File Offset: 0x000B65E8
	[Token(Token = "0x60022E4")]
	[Address(RVA = "0x2C78998", Offset = "0x2C78998", VA = "0x2C78998")]
	public void څࡣڐ\u0657()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)49152;
	}

	// Token: 0x060022E5 RID: 8933 RVA: 0x000B8440 File Offset: 0x000B6640
	[Token(Token = "0x60022E5")]
	[Address(RVA = "0x2C78A20", Offset = "0x2C78A20", VA = "0x2C78A20")]
	public void ւࡂ\u0883\u0872()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)8192;
	}

	// Token: 0x060022E6 RID: 8934 RVA: 0x000B8498 File Offset: 0x000B6698
	[Token(Token = "0x60022E6")]
	[Address(RVA = "0x2C78AA8", Offset = "0x2C78AA8", VA = "0x2C78AA8")]
	public void \u0838ӆڛӑ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		this.ݶՈהՇ = (float)17500;
	}

	// Token: 0x060022E7 RID: 8935 RVA: 0x000B84E0 File Offset: 0x000B66E0
	[Token(Token = "0x60022E7")]
	[Address(RVA = "0x2C78B2C", Offset = "0x2C78B2C", VA = "0x2C78B2C")]
	public void Ӣ\u0592ߨׯ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)49152;
	}

	// Token: 0x060022E8 RID: 8936 RVA: 0x000B8544 File Offset: 0x000B6744
	[Token(Token = "0x60022E8")]
	[Address(RVA = "0x2C78BB8", Offset = "0x2C78BB8", VA = "0x2C78BB8")]
	public void \u087BӦןݩ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)32768;
	}

	// Token: 0x060022E9 RID: 8937 RVA: 0x000B85A8 File Offset: 0x000B67A8
	[Token(Token = "0x60022E9")]
	[Address(RVA = "0x2C78C44", Offset = "0x2C78C44", VA = "0x2C78C44")]
	public void \u0599ږࠆ\u065F()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		this.ݶՈהՇ = (float)32768;
	}

	// Token: 0x060022EA RID: 8938 RVA: 0x000B85F0 File Offset: 0x000B67F0
	[Token(Token = "0x60022EA")]
	[Address(RVA = "0x2C78CCC", Offset = "0x2C78CCC", VA = "0x2C78CCC")]
	public void \u05EDց\u081Cت()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)32768;
	}

	// Token: 0x060022EB RID: 8939 RVA: 0x000B8648 File Offset: 0x000B6848
	[Token(Token = "0x60022EB")]
	[Address(RVA = "0x2C78D54", Offset = "0x2C78D54", VA = "0x2C78D54")]
	public void \u0886Ҽ\u058Dߛ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)17396;
	}

	// Token: 0x060022EC RID: 8940 RVA: 0x000B86AC File Offset: 0x000B68AC
	[Token(Token = "0x60022EC")]
	[Address(RVA = "0x2C78DDC", Offset = "0x2C78DDC", VA = "0x2C78DDC")]
	public void Update()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)16544;
	}

	// Token: 0x060022ED RID: 8941 RVA: 0x000B8704 File Offset: 0x000B6904
	[Token(Token = "0x60022ED")]
	[Address(RVA = "0x2C78E58", Offset = "0x2C78E58", VA = "0x2C78E58")]
	public void \u05F8ݑ\u06ECߞ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)8192;
	}

	// Token: 0x060022EE RID: 8942 RVA: 0x000B875C File Offset: 0x000B695C
	[Token(Token = "0x60022EE")]
	[Address(RVA = "0x2C78EE0", Offset = "0x2C78EE0", VA = "0x2C78EE0")]
	public void ފՖߢ\u059B()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		long ނ_u05AFՉݿ2 = 1L;
		this.ނ\u05AFՉݿ = (ނ_u05AFՉݿ2 != 0L);
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)24576;
	}

	// Token: 0x060022EF RID: 8943 RVA: 0x000B87C0 File Offset: 0x000B69C0
	[Token(Token = "0x60022EF")]
	[Address(RVA = "0x2C78F6C", Offset = "0x2C78F6C", VA = "0x2C78F6C")]
	public void ࢫ\u0876չՍ()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)17418;
	}

	// Token: 0x060022F0 RID: 8944 RVA: 0x000B8818 File Offset: 0x000B6A18
	[Token(Token = "0x60022F0")]
	[Address(RVA = "0x2C78FF0", Offset = "0x2C78FF0", VA = "0x2C78FF0")]
	public void \u070Aәޣے()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)17198;
	}

	// Token: 0x060022F1 RID: 8945 RVA: 0x000B8870 File Offset: 0x000B6A70
	[Token(Token = "0x60022F1")]
	[Address(RVA = "0x2C79074", Offset = "0x2C79074", VA = "0x2C79074")]
	public void ٴݵۃ\u05AF()
	{
		bool ނ_u05AFՉݿ = this.ނ\u05AFՉݿ;
		float num = this.ݶՈהՇ;
		if (ނ_u05AFՉݿ)
		{
			float deltaTime = Time.deltaTime;
			this.ݶՈהՇ = num;
		}
		Transform u06E5ݲ_u074Aۺ = this.\u06E5ݲ\u074Aۺ;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		Vector3 position = u06E5ݲ_u074Aۺ.position;
		this.ݶՈהՇ = (float)17521;
	}

	// Token: 0x0400046F RID: 1135
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400046F")]
	public Transform \u081B\u070Aߢࡁ;

	// Token: 0x04000470 RID: 1136
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000470")]
	public Transform \u06E5ݲ\u074Aۺ;

	// Token: 0x04000471 RID: 1137
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000471")]
	public float ݶՈהՇ;

	// Token: 0x04000472 RID: 1138
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x4000472")]
	public bool ނ\u05AFՉݿ;
}
