﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000CE RID: 206
[Token(Token = "0x20000CE")]
public class NetworkPlayer : MonoBehaviour
{
	// Token: 0x06001F7F RID: 8063 RVA: 0x000A5C74 File Offset: 0x000A3E74
	[Token(Token = "0x6001F7F")]
	[Address(RVA = "0x2D3C3EC", Offset = "0x2D3C3EC", VA = "0x2D3C3EC")]
	private void ԻԳԕ\u05C1(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F80 RID: 8064 RVA: 0x000A5C9C File Offset: 0x000A3E9C
	[Token(Token = "0x6001F80")]
	[Address(RVA = "0x2D3C44C", Offset = "0x2D3C44C", VA = "0x2D3C44C")]
	private void \u0612\u0657ࡒ\u0874(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F81 RID: 8065 RVA: 0x000A5CC4 File Offset: 0x000A3EC4
	[Token(Token = "0x6001F81")]
	[Address(RVA = "0x2D3C4AC", Offset = "0x2D3C4AC", VA = "0x2D3C4AC")]
	private void ؠݭ\u0818\u07BB(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F82 RID: 8066 RVA: 0x000A5CEC File Offset: 0x000A3EEC
	[Token(Token = "0x6001F82")]
	[Address(RVA = "0x2D3C50C", Offset = "0x2D3C50C", VA = "0x2D3C50C")]
	private void ի\u058Dضࠊ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F83 RID: 8067 RVA: 0x000A5D14 File Offset: 0x000A3F14
	[Token(Token = "0x6001F83")]
	[Address(RVA = "0x2D3C56C", Offset = "0x2D3C56C", VA = "0x2D3C56C")]
	private void \u089Aչࠃ\u07AF(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F84 RID: 8068 RVA: 0x000A5D3C File Offset: 0x000A3F3C
	[Token(Token = "0x6001F84")]
	[Address(RVA = "0x2D3C5CC", Offset = "0x2D3C5CC", VA = "0x2D3C5CC")]
	private void \u0655\u083Cݼֈ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F85 RID: 8069 RVA: 0x000A5D64 File Offset: 0x000A3F64
	[Token(Token = "0x6001F85")]
	[Address(RVA = "0x2D3C62C", Offset = "0x2D3C62C", VA = "0x2D3C62C")]
	private void \u065Eࠒاן(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F86 RID: 8070 RVA: 0x000A5D8C File Offset: 0x000A3F8C
	[Token(Token = "0x6001F86")]
	[Address(RVA = "0x2D3C68C", Offset = "0x2D3C68C", VA = "0x2D3C68C")]
	[PunRPC]
	private void ChangePlayerSize(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F87 RID: 8071 RVA: 0x000A5DB4 File Offset: 0x000A3FB4
	[Token(Token = "0x6001F87")]
	[Address(RVA = "0x2D3C6EC", Offset = "0x2D3C6EC", VA = "0x2D3C6EC")]
	private void ݕӬ\u085Eٸ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F88 RID: 8072 RVA: 0x000A5DDC File Offset: 0x000A3FDC
	[Token(Token = "0x6001F88")]
	[Address(RVA = "0x2D3C74C", Offset = "0x2D3C74C", VA = "0x2D3C74C")]
	private void \u088Fޗ\u087Fࢮ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F89 RID: 8073 RVA: 0x000A5E04 File Offset: 0x000A4004
	[Token(Token = "0x6001F89")]
	[Address(RVA = "0x2D3C7AC", Offset = "0x2D3C7AC", VA = "0x2D3C7AC")]
	private void \u05CF\u07FB\u061Eغ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F8A RID: 8074 RVA: 0x000A5E2C File Offset: 0x000A402C
	[Token(Token = "0x6001F8A")]
	[Address(RVA = "0x2D3C80C", Offset = "0x2D3C80C", VA = "0x2D3C80C")]
	private void սפݲ\u058C(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F8B RID: 8075 RVA: 0x000A5E54 File Offset: 0x000A4054
	[Token(Token = "0x6001F8B")]
	[Address(RVA = "0x2D3C86C", Offset = "0x2D3C86C", VA = "0x2D3C86C")]
	private void Ӆڕڦۯ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F8C RID: 8076 RVA: 0x000A5E7C File Offset: 0x000A407C
	[Token(Token = "0x6001F8C")]
	[Address(RVA = "0x2D3C8CC", Offset = "0x2D3C8CC", VA = "0x2D3C8CC")]
	private void ގ\u086Cըߌ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F8D RID: 8077 RVA: 0x000A5EA4 File Offset: 0x000A40A4
	[Token(Token = "0x6001F8D")]
	[Address(RVA = "0x2D3C92C", Offset = "0x2D3C92C", VA = "0x2D3C92C")]
	private void \u055FݼӦ\u06D9(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F8E RID: 8078 RVA: 0x000A5ECC File Offset: 0x000A40CC
	[Token(Token = "0x6001F8E")]
	[Address(RVA = "0x2D3C98C", Offset = "0x2D3C98C", VA = "0x2D3C98C")]
	private void \u05C3Ӯۆձ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F8F RID: 8079 RVA: 0x000A5EF4 File Offset: 0x000A40F4
	[Token(Token = "0x6001F8F")]
	[Address(RVA = "0x2D3C9EC", Offset = "0x2D3C9EC", VA = "0x2D3C9EC")]
	private void ݻտڴӳ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F90 RID: 8080 RVA: 0x000A5F1C File Offset: 0x000A411C
	[Token(Token = "0x6001F90")]
	[Address(RVA = "0x2D3CA4C", Offset = "0x2D3CA4C", VA = "0x2D3CA4C")]
	public NetworkPlayer()
	{
	}

	// Token: 0x06001F91 RID: 8081 RVA: 0x000A5F30 File Offset: 0x000A4130
	[Token(Token = "0x6001F91")]
	[Address(RVA = "0x2D3CA54", Offset = "0x2D3CA54", VA = "0x2D3CA54")]
	private void ԛ\u0891ڣե(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F92 RID: 8082 RVA: 0x000A5F58 File Offset: 0x000A4158
	[Token(Token = "0x6001F92")]
	[Address(RVA = "0x2D3CAB4", Offset = "0x2D3CAB4", VA = "0x2D3CAB4")]
	private void ࠏࠕ\u088Cӊ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F93 RID: 8083 RVA: 0x000A5F80 File Offset: 0x000A4180
	[Token(Token = "0x6001F93")]
	[Address(RVA = "0x2D3CB14", Offset = "0x2D3CB14", VA = "0x2D3CB14")]
	private void \u0652ڙۑӞ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F94 RID: 8084 RVA: 0x000A5FA8 File Offset: 0x000A41A8
	[Token(Token = "0x6001F94")]
	[Address(RVA = "0x2D3CB74", Offset = "0x2D3CB74", VA = "0x2D3CB74")]
	private void פڬԠ۷(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F95 RID: 8085 RVA: 0x000A5FD0 File Offset: 0x000A41D0
	[Token(Token = "0x6001F95")]
	[Address(RVA = "0x2D3CBD4", Offset = "0x2D3CBD4", VA = "0x2D3CBD4")]
	private void \u07FBՍڂך(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F96 RID: 8086 RVA: 0x000A5FF8 File Offset: 0x000A41F8
	[Token(Token = "0x6001F96")]
	[Address(RVA = "0x2D3CC34", Offset = "0x2D3CC34", VA = "0x2D3CC34")]
	private void ݍӲ\u0820ވ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F97 RID: 8087 RVA: 0x000A6020 File Offset: 0x000A4220
	[Token(Token = "0x6001F97")]
	[Address(RVA = "0x2D3CC94", Offset = "0x2D3CC94", VA = "0x2D3CC94")]
	private void Ւ\u05A0ցӳ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F98 RID: 8088 RVA: 0x000A6048 File Offset: 0x000A4248
	[Token(Token = "0x6001F98")]
	[Address(RVA = "0x2D3CCF4", Offset = "0x2D3CCF4", VA = "0x2D3CCF4")]
	private void \u07F9ݥߌ\u0640(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F99 RID: 8089 RVA: 0x000A6070 File Offset: 0x000A4270
	[Token(Token = "0x6001F99")]
	[Address(RVA = "0x2D3CD54", Offset = "0x2D3CD54", VA = "0x2D3CD54")]
	private void \u06DB\u073Dݙܗ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F9A RID: 8090 RVA: 0x000A6098 File Offset: 0x000A4298
	[Token(Token = "0x6001F9A")]
	[Address(RVA = "0x2D3CDB4", Offset = "0x2D3CDB4", VA = "0x2D3CDB4")]
	private void ࡃ\u060DՀݓ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06001F9B RID: 8091 RVA: 0x000A60C0 File Offset: 0x000A42C0
	[Token(Token = "0x6001F9B")]
	[Address(RVA = "0x2D3CE14", Offset = "0x2D3CE14", VA = "0x2D3CE14")]
	private void \u089EՐӸԓ(float \u0619\u0749ݗ\u0650)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}
}
