﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200002C RID: 44
[Token(Token = "0x200002C")]
public class OpenVent : MonoBehaviour
{
	// Token: 0x06000510 RID: 1296 RVA: 0x0001D974 File Offset: 0x0001BB74
	[Token(Token = "0x6000510")]
	[Address(RVA = "0x2D4A120", Offset = "0x2D4A120", VA = "0x2D4A120")]
	public void ࡋڳ\u0732Ԛ()
	{
	}

	// Token: 0x06000511 RID: 1297 RVA: 0x0001D984 File Offset: 0x0001BB84
	[Token(Token = "0x6000511")]
	[Address(RVA = "0x2D4A128", Offset = "0x2D4A128", VA = "0x2D4A128")]
	public void Գࡪסמ()
	{
	}

	// Token: 0x06000512 RID: 1298 RVA: 0x0001D994 File Offset: 0x0001BB94
	[Token(Token = "0x6000512")]
	[Address(RVA = "0x2D4A130", Offset = "0x2D4A130", VA = "0x2D4A130")]
	private void \u061B\u05EEوۈ()
	{
		float ۿ_u07F0_u07F4_u = this.ۿ\u07F0\u07F4\u0830;
		Transform ࡒթ_u055C_u = this.ࡒթ\u055C\u0595;
		float z = this.ӵۊշԡ.z;
		float x = this.ٽ\u0886ࡠԢ.x;
		float z2 = this.ٽ\u0886ࡠԢ.z;
		bool ࢪࡃب_u = this.ࢪࡃب\u0824;
		float ۿ_u07F0_u07F4_u2 = this.ۿ\u07F0\u07F4\u0830;
		if (ࢪࡃب_u)
		{
			float deltaTime = Time.deltaTime;
			float կ_u055EԆފ = this.Կ\u055EԆފ;
			bool ӣ_u0703Ӽ_u = this.Ӣ\u0703Ӽ\u0818;
			return;
		}
		float deltaTime2 = Time.deltaTime;
		float կ_u055EԆފ2 = this.Կ\u055EԆފ;
		if (this.Ӣ\u0703Ӽ\u0818)
		{
			AudioSource audioSource = this.߇ޱלӺ;
			AudioClip ߨݴ_u0657_u06D = this.ߨݴ\u0657\u06D8;
			audioSource.PlayOneShot(ߨݴ_u0657_u06D);
			AudioSource u0658څՉՌ = this.\u0658څՉՌ;
			AudioClip clip = this.۷Ӂبۻ;
			u0658څՉՌ.PlayOneShot(clip);
			long ӣ_u0703Ӽ_u2 = 1L;
			this.Ӣ\u0703Ӽ\u0818 = (ӣ_u0703Ӽ_u2 != 0L);
			return;
		}
	}

	// Token: 0x06000513 RID: 1299 RVA: 0x0001DA64 File Offset: 0x0001BC64
	[Token(Token = "0x6000513")]
	[Address(RVA = "0x2D4A24C", Offset = "0x2D4A24C", VA = "0x2D4A24C")]
	private void Ӣ\u0592ߨׯ()
	{
		float ۿ_u07F0_u07F4_u = this.ۿ\u07F0\u07F4\u0830;
		Transform ࡒթ_u055C_u = this.ࡒթ\u055C\u0595;
		float z = this.ӵۊշԡ.z;
		float x = this.ٽ\u0886ࡠԢ.x;
		float z2 = this.ٽ\u0886ࡠԢ.z;
		bool ࢪࡃب_u = this.ࢪࡃب\u0824;
		float ۿ_u07F0_u07F4_u2 = this.ۿ\u07F0\u07F4\u0830;
		if (ࢪࡃب_u)
		{
			float deltaTime = Time.deltaTime;
			float կ_u055EԆފ = this.Կ\u055EԆފ;
			if (this.Ӣ\u0703Ӽ\u0818)
			{
				AudioSource audioSource = this.߇ޱלӺ;
				AudioClip ߨݴ_u0657_u06D = this.ߨݴ\u0657\u06D8;
				audioSource.PlayOneShot(ߨݴ_u0657_u06D);
				AudioSource u0658څՉՌ = this.\u0658څՉՌ;
				AudioClip clip = this.۷Ӂبۻ;
				u0658څՉՌ.PlayOneShot(clip);
				return;
			}
		}
		else
		{
			float deltaTime2 = Time.deltaTime;
			float կ_u055EԆފ2 = this.Կ\u055EԆފ;
			if (this.Ӣ\u0703Ӽ\u0818)
			{
				AudioSource audioSource2 = this.߇ޱלӺ;
				AudioClip ߨݴ_u0657_u06D2 = this.ߨݴ\u0657\u06D8;
				audioSource2.PlayOneShot(ߨݴ_u0657_u06D2);
				AudioSource u0658څՉՌ2 = this.\u0658څՉՌ;
				AudioClip clip2 = this.۷Ӂبۻ;
				u0658څՉՌ2.PlayOneShot(clip2);
				return;
			}
		}
	}

	// Token: 0x06000514 RID: 1300 RVA: 0x0001DB6C File Offset: 0x0001BD6C
	[Token(Token = "0x6000514")]
	[Address(RVA = "0x2D4A398", Offset = "0x2D4A398", VA = "0x2D4A398")]
	public OpenVent()
	{
		long ӣ_u0703Ӽ_u = 1L;
		this.Ӣ\u0703Ӽ\u0818 = (ӣ_u0703Ӽ_u != 0L);
		base..ctor();
	}

	// Token: 0x06000515 RID: 1301 RVA: 0x0001DB88 File Offset: 0x0001BD88
	[Token(Token = "0x6000515")]
	[Address(RVA = "0x2D4A3A8", Offset = "0x2D4A3A8", VA = "0x2D4A3A8")]
	public void ܐرߟײ()
	{
	}

	// Token: 0x06000516 RID: 1302 RVA: 0x0001DB98 File Offset: 0x0001BD98
	[Token(Token = "0x6000516")]
	[Address(RVA = "0x2D4A3B0", Offset = "0x2D4A3B0", VA = "0x2D4A3B0")]
	public void Ձߕӄ\u074B()
	{
	}

	// Token: 0x06000517 RID: 1303 RVA: 0x0001DBA8 File Offset: 0x0001BDA8
	[Token(Token = "0x6000517")]
	[Address(RVA = "0x2D4A3B8", Offset = "0x2D4A3B8", VA = "0x2D4A3B8")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		float ۿ_u07F0_u07F4_u = this.ۿ\u07F0\u07F4\u0830;
		Transform ࡒթ_u055C_u = this.ࡒթ\u055C\u0595;
		float z = this.ӵۊշԡ.z;
		float x = this.ٽ\u0886ࡠԢ.x;
		float z2 = this.ٽ\u0886ࡠԢ.z;
		bool ࢪࡃب_u = this.ࢪࡃب\u0824;
		float ۿ_u07F0_u07F4_u2 = this.ۿ\u07F0\u07F4\u0830;
		if (ࢪࡃب_u)
		{
			float deltaTime = Time.deltaTime;
			float կ_u055EԆފ = this.Կ\u055EԆފ;
			bool ӣ_u0703Ӽ_u = this.Ӣ\u0703Ӽ\u0818;
			return;
		}
		float deltaTime2 = Time.deltaTime;
		float կ_u055EԆފ2 = this.Կ\u055EԆފ;
		if (this.Ӣ\u0703Ӽ\u0818)
		{
			AudioSource audioSource = this.߇ޱלӺ;
			AudioClip ߨݴ_u0657_u06D = this.ߨݴ\u0657\u06D8;
			audioSource.PlayOneShot(ߨݴ_u0657_u06D);
			AudioSource u0658څՉՌ = this.\u0658څՉՌ;
			AudioClip clip = this.۷Ӂبۻ;
			u0658څՉՌ.PlayOneShot(clip);
			long ӣ_u0703Ӽ_u2 = 1L;
			this.Ӣ\u0703Ӽ\u0818 = (ӣ_u0703Ӽ_u2 != 0L);
			return;
		}
	}

	// Token: 0x06000518 RID: 1304 RVA: 0x0001DC78 File Offset: 0x0001BE78
	[Token(Token = "0x6000518")]
	[Address(RVA = "0x2D4A4D4", Offset = "0x2D4A4D4", VA = "0x2D4A4D4")]
	private void ڑߒجވ()
	{
		float ۿ_u07F0_u07F4_u = this.ۿ\u07F0\u07F4\u0830;
		Transform ࡒթ_u055C_u = this.ࡒթ\u055C\u0595;
		float z = this.ӵۊշԡ.z;
		float x = this.ٽ\u0886ࡠԢ.x;
		float z2 = this.ٽ\u0886ࡠԢ.z;
		float ۿ_u07F0_u07F4_u2 = this.ۿ\u07F0\u07F4\u0830;
		float deltaTime = Time.deltaTime;
		float կ_u055EԆފ = this.Կ\u055EԆފ;
		bool ӣ_u0703Ӽ_u = this.Ӣ\u0703Ӽ\u0818;
	}

	// Token: 0x06000519 RID: 1305 RVA: 0x0001DD3C File Offset: 0x0001BF3C
	[Token(Token = "0x6000519")]
	[Address(RVA = "0x2D4A5EC", Offset = "0x2D4A5EC", VA = "0x2D4A5EC")]
	public void ڊԚ\u055Fל()
	{
	}

	// Token: 0x0600051A RID: 1306 RVA: 0x0001DD4C File Offset: 0x0001BF4C
	[Token(Token = "0x600051A")]
	[Address(RVA = "0x2D4A5F4", Offset = "0x2D4A5F4", VA = "0x2D4A5F4")]
	public void إ\u0742ܩࡘ()
	{
	}

	// Token: 0x0600051B RID: 1307 RVA: 0x0001DD5C File Offset: 0x0001BF5C
	[Token(Token = "0x600051B")]
	[Address(RVA = "0x2D4A5FC", Offset = "0x2D4A5FC", VA = "0x2D4A5FC")]
	public void \u0891\u055Bࡇ\u088E()
	{
	}

	// Token: 0x0600051C RID: 1308 RVA: 0x0001DD6C File Offset: 0x0001BF6C
	[Token(Token = "0x600051C")]
	[Address(RVA = "0x2D4A604", Offset = "0x2D4A604", VA = "0x2D4A604")]
	public void ࢻ\u064D\u07FB\u05CA()
	{
	}

	// Token: 0x0600051D RID: 1309 RVA: 0x0001DD7C File Offset: 0x0001BF7C
	[Token(Token = "0x600051D")]
	[Address(RVA = "0x2D4A60C", Offset = "0x2D4A60C", VA = "0x2D4A60C")]
	public void \u066B\u0825\u05B9\u07F1()
	{
	}

	// Token: 0x0600051E RID: 1310 RVA: 0x0001DD8C File Offset: 0x0001BF8C
	[Token(Token = "0x600051E")]
	[Address(RVA = "0x2D4A614", Offset = "0x2D4A614", VA = "0x2D4A614")]
	private void Update()
	{
		float ۿ_u07F0_u07F4_u = this.ۿ\u07F0\u07F4\u0830;
		Transform ࡒթ_u055C_u = this.ࡒթ\u055C\u0595;
		float z = this.ӵۊշԡ.z;
		float x = this.ٽ\u0886ࡠԢ.x;
		float z2 = this.ٽ\u0886ࡠԢ.z;
		bool ࢪࡃب_u = this.ࢪࡃب\u0824;
		float ۿ_u07F0_u07F4_u2 = this.ۿ\u07F0\u07F4\u0830;
		if (ࢪࡃب_u)
		{
			float deltaTime = Time.deltaTime;
			float կ_u055EԆފ = this.Կ\u055EԆފ;
			bool ӣ_u0703Ӽ_u = this.Ӣ\u0703Ӽ\u0818;
			return;
		}
		float deltaTime2 = Time.deltaTime;
		float կ_u055EԆފ2 = this.Կ\u055EԆފ;
		bool ӣ_u0703Ӽ_u2 = this.Ӣ\u0703Ӽ\u0818;
		this.ۿ\u07F0\u07F4\u0830 = ۿ_u07F0_u07F4_u;
		if (ӣ_u0703Ӽ_u2)
		{
			AudioSource audioSource = this.߇ޱלӺ;
			AudioClip ߨݴ_u0657_u06D = this.ߨݴ\u0657\u06D8;
			audioSource.PlayOneShot(ߨݴ_u0657_u06D);
			AudioSource u0658څՉՌ = this.\u0658څՉՌ;
			AudioClip clip = this.۷Ӂبۻ;
			u0658څՉՌ.PlayOneShot(clip);
			return;
		}
	}

	// Token: 0x0600051F RID: 1311 RVA: 0x0001DE68 File Offset: 0x0001C068
	[Token(Token = "0x600051F")]
	[Address(RVA = "0x2D4A730", Offset = "0x2D4A730", VA = "0x2D4A730")]
	public void ۓ\u085E\u0743פ()
	{
	}

	// Token: 0x06000520 RID: 1312 RVA: 0x0001DE78 File Offset: 0x0001C078
	[Token(Token = "0x6000520")]
	[Address(RVA = "0x2D4A738", Offset = "0x2D4A738", VA = "0x2D4A738")]
	private void \u087BӦןݩ()
	{
		float ۿ_u07F0_u07F4_u = this.ۿ\u07F0\u07F4\u0830;
		Transform ࡒթ_u055C_u = this.ࡒթ\u055C\u0595;
		float z = this.ӵۊշԡ.z;
		float x = this.ٽ\u0886ࡠԢ.x;
		float z2 = this.ٽ\u0886ࡠԢ.z;
		bool ࢪࡃب_u = this.ࢪࡃب\u0824;
		float ۿ_u07F0_u07F4_u2 = this.ۿ\u07F0\u07F4\u0830;
		if (ࢪࡃب_u)
		{
			float deltaTime = Time.deltaTime;
			if (this.Ӣ\u0703Ӽ\u0818)
			{
				AudioSource audioSource = this.߇ޱלӺ;
				AudioClip ߨݴ_u0657_u06D = this.ߨݴ\u0657\u06D8;
				audioSource.PlayOneShot(ߨݴ_u0657_u06D);
				AudioSource u0658څՉՌ = this.\u0658څՉՌ;
				AudioClip clip = this.۷Ӂبۻ;
				u0658څՉՌ.PlayOneShot(clip);
				return;
			}
		}
		else
		{
			float deltaTime2 = Time.deltaTime;
			float կ_u055EԆފ = this.Կ\u055EԆފ;
			if (this.Ӣ\u0703Ӽ\u0818)
			{
				AudioSource audioSource2 = this.߇ޱלӺ;
				AudioClip ߨݴ_u0657_u06D2 = this.ߨݴ\u0657\u06D8;
				audioSource2.PlayOneShot(ߨݴ_u0657_u06D2);
				AudioSource u0658څՉՌ2 = this.\u0658څՉՌ;
				AudioClip clip2 = this.۷Ӂبۻ;
				u0658څՉՌ2.PlayOneShot(clip2);
				long ӣ_u0703Ӽ_u = 1L;
				this.Ӣ\u0703Ӽ\u0818 = (ӣ_u0703Ӽ_u != 0L);
			}
		}
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x0001DF74 File Offset: 0x0001C174
	[Token(Token = "0x6000521")]
	[Address(RVA = "0x2D4A880", Offset = "0x2D4A880", VA = "0x2D4A880")]
	public void ޝߢݖڏ()
	{
		long ࢪࡃب_u = 1L;
		this.ࢪࡃب\u0824 = (ࢪࡃب_u != 0L);
	}

	// Token: 0x06000522 RID: 1314 RVA: 0x0001DF8C File Offset: 0x0001C18C
	[Token(Token = "0x6000522")]
	[Address(RVA = "0x2D4A88C", Offset = "0x2D4A88C", VA = "0x2D4A88C")]
	public void ࢤ\u07F1ࢶޔ()
	{
	}

	// Token: 0x06000523 RID: 1315 RVA: 0x0001DF9C File Offset: 0x0001C19C
	[Token(Token = "0x6000523")]
	[Address(RVA = "0x2D4A894", Offset = "0x2D4A894", VA = "0x2D4A894")]
	public void Ӌࡕ\u065Eځ()
	{
		long ࢪࡃب_u = 1L;
		this.ࢪࡃب\u0824 = (ࢪࡃب_u != 0L);
	}

	// Token: 0x06000524 RID: 1316 RVA: 0x0001DFB4 File Offset: 0x0001C1B4
	[Token(Token = "0x6000524")]
	[Address(RVA = "0x2D4A8A0", Offset = "0x2D4A8A0", VA = "0x2D4A8A0")]
	public void Սޘ\u07F4ޏ()
	{
		long ࢪࡃب_u = 1L;
		this.ࢪࡃب\u0824 = (ࢪࡃب_u != 0L);
	}

	// Token: 0x06000525 RID: 1317 RVA: 0x0001DFCC File Offset: 0x0001C1CC
	[Token(Token = "0x6000525")]
	[Address(RVA = "0x2D4A8AC", Offset = "0x2D4A8AC", VA = "0x2D4A8AC")]
	public void \u06E1ޏژێ()
	{
	}

	// Token: 0x06000526 RID: 1318 RVA: 0x0001DFDC File Offset: 0x0001C1DC
	[Token(Token = "0x6000526")]
	[Address(RVA = "0x2D4A8B4", Offset = "0x2D4A8B4", VA = "0x2D4A8B4")]
	private void \u05F7ԝߠӱ()
	{
		float ۿ_u07F0_u07F4_u = this.ۿ\u07F0\u07F4\u0830;
		Transform ࡒթ_u055C_u = this.ࡒթ\u055C\u0595;
		float z = this.ӵۊշԡ.z;
		float x = this.ٽ\u0886ࡠԢ.x;
		float z2 = this.ٽ\u0886ࡠԢ.z;
		bool ࢪࡃب_u = this.ࢪࡃب\u0824;
		float ۿ_u07F0_u07F4_u2 = this.ۿ\u07F0\u07F4\u0830;
		if (ࢪࡃب_u)
		{
			float deltaTime = Time.deltaTime;
			float կ_u055EԆފ = this.Կ\u055EԆފ;
			if (this.Ӣ\u0703Ӽ\u0818)
			{
				AudioSource audioSource = this.߇ޱלӺ;
				AudioClip ߨݴ_u0657_u06D = this.ߨݴ\u0657\u06D8;
				audioSource.PlayOneShot(ߨݴ_u0657_u06D);
				AudioSource u0658څՉՌ = this.\u0658څՉՌ;
				AudioClip clip = this.۷Ӂبۻ;
				u0658څՉՌ.PlayOneShot(clip);
				return;
			}
		}
		else
		{
			float deltaTime2 = Time.deltaTime;
			float կ_u055EԆފ2 = this.Կ\u055EԆފ;
			if (this.Ӣ\u0703Ӽ\u0818)
			{
				AudioSource audioSource2 = this.߇ޱלӺ;
				AudioClip ߨݴ_u0657_u06D2 = this.ߨݴ\u0657\u06D8;
				audioSource2.PlayOneShot(ߨݴ_u0657_u06D2);
				AudioSource u0658څՉՌ2 = this.\u0658څՉՌ;
				AudioClip clip2 = this.۷Ӂبۻ;
				u0658څՉՌ2.PlayOneShot(clip2);
				return;
			}
		}
	}

	// Token: 0x06000527 RID: 1319 RVA: 0x0001E0E4 File Offset: 0x0001C2E4
	[Token(Token = "0x6000527")]
	[Address(RVA = "0x2D4AA00", Offset = "0x2D4AA00", VA = "0x2D4AA00")]
	public void \u0617\u06DE\u0733ࡋ()
	{
	}

	// Token: 0x06000528 RID: 1320 RVA: 0x0001E0F4 File Offset: 0x0001C2F4
	[Token(Token = "0x6000528")]
	[Address(RVA = "0x2D4AA08", Offset = "0x2D4AA08", VA = "0x2D4AA08")]
	public void \u0876جԀ\u088D()
	{
		long ࢪࡃب_u = 1L;
		this.ࢪࡃب\u0824 = (ࢪࡃب_u != 0L);
	}

	// Token: 0x06000529 RID: 1321 RVA: 0x0001E10C File Offset: 0x0001C30C
	[Token(Token = "0x6000529")]
	[Address(RVA = "0x2D4AA14", Offset = "0x2D4AA14", VA = "0x2D4AA14")]
	private void \u0881ݗӟ\u07BD()
	{
		float ۿ_u07F0_u07F4_u = this.ۿ\u07F0\u07F4\u0830;
		Transform ࡒթ_u055C_u = this.ࡒթ\u055C\u0595;
		float z = this.ӵۊշԡ.z;
		float x = this.ٽ\u0886ࡠԢ.x;
		float z2 = this.ٽ\u0886ࡠԢ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x040000CC RID: 204
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000CC")]
	public Transform ࡒթ\u055C\u0595;

	// Token: 0x040000CD RID: 205
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000CD")]
	public Vector3 ٽ\u0886ࡠԢ;

	// Token: 0x040000CE RID: 206
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x40000CE")]
	public Vector3 ӵۊշԡ;

	// Token: 0x040000CF RID: 207
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40000CF")]
	public bool \u0737\u05A0ݒذ;

	// Token: 0x040000D0 RID: 208
	[FieldOffset(Offset = "0x39")]
	[Token(Token = "0x40000D0")]
	public bool ՍՐՕݷ;

	// Token: 0x040000D1 RID: 209
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x40000D1")]
	public float ۿ\u07F0\u07F4\u0830;

	// Token: 0x040000D2 RID: 210
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40000D2")]
	public bool ࢪࡃب\u0824;

	// Token: 0x040000D3 RID: 211
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x40000D3")]
	public float Կ\u055EԆފ;

	// Token: 0x040000D4 RID: 212
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40000D4")]
	public AudioSource ߇ޱלӺ;

	// Token: 0x040000D5 RID: 213
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40000D5")]
	public AudioClip ߨݴ\u0657\u06D8;

	// Token: 0x040000D6 RID: 214
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40000D6")]
	private bool Ӣ\u0703Ӽ\u0818;

	// Token: 0x040000D7 RID: 215
	[FieldOffset(Offset = "0x59")]
	[Token(Token = "0x40000D7")]
	public bool ࢸݯ\u07F1\u06D4;

	// Token: 0x040000D8 RID: 216
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x40000D8")]
	public AudioSource \u0658څՉՌ;

	// Token: 0x040000D9 RID: 217
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x40000D9")]
	public AudioClip ۷Ӂبۻ;
}
