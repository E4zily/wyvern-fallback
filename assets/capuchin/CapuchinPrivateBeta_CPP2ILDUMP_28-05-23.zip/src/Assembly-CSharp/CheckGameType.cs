﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200004C RID: 76
[Token(Token = "0x200004C")]
public class CheckGameType : MonoBehaviour
{
	// Token: 0x06000A99 RID: 2713 RVA: 0x00039810 File Offset: 0x00037A10
	[Token(Token = "0x6000A99")]
	[Address(RVA = "0x2947C20", Offset = "0x2947C20", VA = "0x2947C20")]
	private void نո\u0599\u0589()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 0L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000A9A RID: 2714 RVA: 0x0003983C File Offset: 0x00037A3C
	[Token(Token = "0x6000A9A")]
	[Address(RVA = "0x2947C58", Offset = "0x2947C58", VA = "0x2947C58")]
	private void ݸԲ\u0616Ԫ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 0L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000A9B RID: 2715 RVA: 0x00039868 File Offset: 0x00037A68
	[Token(Token = "0x6000A9B")]
	[Address(RVA = "0x2947C90", Offset = "0x2947C90", VA = "0x2947C90")]
	private void ӭࡖݲ\u05BD()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000A9C RID: 2716 RVA: 0x00039894 File Offset: 0x00037A94
	[Token(Token = "0x6000A9C")]
	[Address(RVA = "0x2947CDC", Offset = "0x2947CDC", VA = "0x2947CDC")]
	private void ݤۅࢦӃ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000A9D RID: 2717 RVA: 0x000398C0 File Offset: 0x00037AC0
	[Token(Token = "0x6000A9D")]
	[Address(RVA = "0x2947D28", Offset = "0x2947D28", VA = "0x2947D28")]
	private void \u05ABݿࡋ\u06E9()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000A9E RID: 2718 RVA: 0x000398EC File Offset: 0x00037AEC
	[Token(Token = "0x6000A9E")]
	[Address(RVA = "0x2947D74", Offset = "0x2947D74", VA = "0x2947D74")]
	private void \u070Fߨ\u05B0ۈ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000A9F RID: 2719 RVA: 0x00039918 File Offset: 0x00037B18
	[Token(Token = "0x6000A9F")]
	[Address(RVA = "0x2947DC0", Offset = "0x2947DC0", VA = "0x2947DC0")]
	private void ןٮ\u061FԺ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 0L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AA0 RID: 2720 RVA: 0x00039944 File Offset: 0x00037B44
	[Token(Token = "0x6000AA0")]
	[Address(RVA = "0x2947DF8", Offset = "0x2947DF8", VA = "0x2947DF8")]
	private void ࡩݮڢՠ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AA1 RID: 2721 RVA: 0x00039970 File Offset: 0x00037B70
	[Token(Token = "0x6000AA1")]
	[Address(RVA = "0x2947E44", Offset = "0x2947E44", VA = "0x2947E44")]
	private void \u065F\u0839ܤ\u073C()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AA2 RID: 2722 RVA: 0x00039990 File Offset: 0x00037B90
	[Token(Token = "0x6000AA2")]
	[Address(RVA = "0x2947E7C", Offset = "0x2947E7C", VA = "0x2947E7C")]
	private void ࠏޤݳ\u06DD()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AA3 RID: 2723 RVA: 0x000399BC File Offset: 0x00037BBC
	[Token(Token = "0x6000AA3")]
	[Address(RVA = "0x2947EC8", Offset = "0x2947EC8", VA = "0x2947EC8")]
	private void ߒ\u065EՎࡖ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 0L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AA4 RID: 2724 RVA: 0x000399E8 File Offset: 0x00037BE8
	[Token(Token = "0x6000AA4")]
	[Address(RVA = "0x2947F00", Offset = "0x2947F00", VA = "0x2947F00")]
	private void \u0656ӺմՁ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 0L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AA5 RID: 2725 RVA: 0x00039A14 File Offset: 0x00037C14
	[Token(Token = "0x6000AA5")]
	[Address(RVA = "0x2947F38", Offset = "0x2947F38", VA = "0x2947F38")]
	private void ӛ\u082Eؿڕ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AA6 RID: 2726 RVA: 0x00039A40 File Offset: 0x00037C40
	[Token(Token = "0x6000AA6")]
	[Address(RVA = "0x2947F84", Offset = "0x2947F84", VA = "0x2947F84")]
	private void ࢧӾڈց()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 1L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AA7 RID: 2727 RVA: 0x00039A6C File Offset: 0x00037C6C
	[Token(Token = "0x6000AA7")]
	[Address(RVA = "0x2947FBC", Offset = "0x2947FBC", VA = "0x2947FBC")]
	private void הԥ\u05B5ݴ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 1L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AA8 RID: 2728 RVA: 0x00039A98 File Offset: 0x00037C98
	[Token(Token = "0x6000AA8")]
	[Address(RVA = "0x2947FF4", Offset = "0x2947FF4", VA = "0x2947FF4")]
	private void ߖհݣ߀()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AA9 RID: 2729 RVA: 0x00039AC4 File Offset: 0x00037CC4
	[Token(Token = "0x6000AA9")]
	[Address(RVA = "0x2948040", Offset = "0x2948040", VA = "0x2948040")]
	private void \u0558ݕݤݮ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AAA RID: 2730 RVA: 0x00039AE8 File Offset: 0x00037CE8
	[Token(Token = "0x6000AAA")]
	[Address(RVA = "0x2948078", Offset = "0x2948078", VA = "0x2948078")]
	private void ݱ\u0832ݥ\u08B5()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 1L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AAB RID: 2731 RVA: 0x00039B14 File Offset: 0x00037D14
	[Token(Token = "0x6000AAB")]
	[Address(RVA = "0x29480B0", Offset = "0x29480B0", VA = "0x29480B0")]
	private void \u082E\u06EBݼڏ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 1L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AAC RID: 2732 RVA: 0x00039B40 File Offset: 0x00037D40
	[Token(Token = "0x6000AAC")]
	[Address(RVA = "0x29480E8", Offset = "0x29480E8", VA = "0x29480E8")]
	private void Start()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AAD RID: 2733 RVA: 0x00039B6C File Offset: 0x00037D6C
	[Token(Token = "0x6000AAD")]
	[Address(RVA = "0x2948134", Offset = "0x2948134", VA = "0x2948134")]
	private void \u073BօӁ\u059A()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AAE RID: 2734 RVA: 0x00039B98 File Offset: 0x00037D98
	[Token(Token = "0x6000AAE")]
	[Address(RVA = "0x2948180", Offset = "0x2948180", VA = "0x2948180")]
	private void \u0834\u0817ރࡔ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AAF RID: 2735 RVA: 0x00039BC4 File Offset: 0x00037DC4
	[Token(Token = "0x6000AAF")]
	[Address(RVA = "0x29481CC", Offset = "0x29481CC", VA = "0x29481CC")]
	private void ۆڛߟ\u05A0()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AB0 RID: 2736 RVA: 0x00039BF0 File Offset: 0x00037DF0
	[Token(Token = "0x6000AB0")]
	[Address(RVA = "0x2948218", Offset = "0x2948218", VA = "0x2948218")]
	private void \u086Bԍࡊڭ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AB1 RID: 2737 RVA: 0x00039C1C File Offset: 0x00037E1C
	[Token(Token = "0x6000AB1")]
	[Address(RVA = "0x2948264", Offset = "0x2948264", VA = "0x2948264")]
	private void ࡅݐ\u082Dք()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 0L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AB2 RID: 2738 RVA: 0x00039C48 File Offset: 0x00037E48
	[Token(Token = "0x6000AB2")]
	[Address(RVA = "0x294829C", Offset = "0x294829C", VA = "0x294829C")]
	private void Ԯ\u0883\u0591\u066C()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 0L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AB3 RID: 2739 RVA: 0x00039C74 File Offset: 0x00037E74
	[Token(Token = "0x6000AB3")]
	[Address(RVA = "0x29482D4", Offset = "0x29482D4", VA = "0x29482D4")]
	private void \u066D\u05BDې߃()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AB4 RID: 2740 RVA: 0x00039CA0 File Offset: 0x00037EA0
	[Token(Token = "0x6000AB4")]
	[Address(RVA = "0x2948320", Offset = "0x2948320", VA = "0x2948320")]
	private void ۮߝڪڐ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 0L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AB5 RID: 2741 RVA: 0x00039CCC File Offset: 0x00037ECC
	[Token(Token = "0x6000AB5")]
	[Address(RVA = "0x2948358", Offset = "0x2948358", VA = "0x2948358")]
	private void \u06EDٵ۶\u06DB()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AB6 RID: 2742 RVA: 0x00039CF8 File Offset: 0x00037EF8
	[Token(Token = "0x6000AB6")]
	[Address(RVA = "0x29483A4", Offset = "0x29483A4", VA = "0x29483A4")]
	private void ޡࠅ\u089Aߔ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AB7 RID: 2743 RVA: 0x00039D24 File Offset: 0x00037F24
	[Token(Token = "0x6000AB7")]
	[Address(RVA = "0x29483F0", Offset = "0x29483F0", VA = "0x29483F0")]
	private void ࢰחڵࡓ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
	}

	// Token: 0x06000AB8 RID: 2744 RVA: 0x00039D50 File Offset: 0x00037F50
	[Token(Token = "0x6000AB8")]
	[Address(RVA = "0x294843C", Offset = "0x294843C", VA = "0x294843C")]
	private void וࡪךӧ()
	{
		bool isEditor = Application.isEditor;
		GameObject u0704_u070BԾ_u06FE = this.\u0704\u070BԾ\u06FE;
		long active = 1L;
		u0704_u070BԾ_u06FE.SetActive(active != 0L);
	}

	// Token: 0x06000AB9 RID: 2745 RVA: 0x00039D7C File Offset: 0x00037F7C
	[Token(Token = "0x6000AB9")]
	[Address(RVA = "0x2948474", Offset = "0x2948474", VA = "0x2948474")]
	public CheckGameType()
	{
	}

	// Token: 0x04000187 RID: 391
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000187")]
	public GameObject \u0704\u070BԾ\u06FE;
}
