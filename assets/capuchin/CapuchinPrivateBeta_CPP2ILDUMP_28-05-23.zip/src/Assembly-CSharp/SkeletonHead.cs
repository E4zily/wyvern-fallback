﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000E6 RID: 230
[Token(Token = "0x20000E6")]
public class SkeletonHead : MonoBehaviour
{
	// Token: 0x060023AC RID: 9132 RVA: 0x000BBF84 File Offset: 0x000BA184
	[Token(Token = "0x60023AC")]
	[Address(RVA = "0x2F7668C", Offset = "0x2F7668C", VA = "0x2F7668C")]
	public void ӀԹ\u06DA\u05C5()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023AD RID: 9133 RVA: 0x000BBFCC File Offset: 0x000BA1CC
	[Token(Token = "0x60023AD")]
	[Address(RVA = "0x2F76764", Offset = "0x2F76764", VA = "0x2F76764")]
	public void ҽגٻ\u05B7()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023AE RID: 9134 RVA: 0x000BC014 File Offset: 0x000BA214
	[Token(Token = "0x60023AE")]
	[Address(RVA = "0x2F7683C", Offset = "0x2F7683C", VA = "0x2F7683C")]
	public SkeletonHead()
	{
	}

	// Token: 0x060023AF RID: 9135 RVA: 0x000BC028 File Offset: 0x000BA228
	[Token(Token = "0x60023AF")]
	[Address(RVA = "0x2F76844", Offset = "0x2F76844", VA = "0x2F76844")]
	public void \u0613\u05CBݠۇ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023B0 RID: 9136 RVA: 0x000BC070 File Offset: 0x000BA270
	[Token(Token = "0x60023B0")]
	[Address(RVA = "0x2F7691C", Offset = "0x2F7691C", VA = "0x2F7691C")]
	public void \u0607\u0747\u058Aף()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023B1 RID: 9137 RVA: 0x000BC0B4 File Offset: 0x000BA2B4
	[Token(Token = "0x60023B1")]
	[Address(RVA = "0x2F769F4", Offset = "0x2F769F4", VA = "0x2F769F4")]
	public void ٧ؠԬט()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023B2 RID: 9138 RVA: 0x000BC0FC File Offset: 0x000BA2FC
	[Token(Token = "0x60023B2")]
	[Address(RVA = "0x2F76ACC", Offset = "0x2F76ACC", VA = "0x2F76ACC")]
	public void ה\u07F4Ց\u0889()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023B3 RID: 9139 RVA: 0x000BC144 File Offset: 0x000BA344
	[Token(Token = "0x60023B3")]
	[Address(RVA = "0x2F76BA4", Offset = "0x2F76BA4", VA = "0x2F76BA4")]
	public void \u0747ݦޖݔ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023B4 RID: 9140 RVA: 0x000BC18C File Offset: 0x000BA38C
	[Token(Token = "0x60023B4")]
	[Address(RVA = "0x2F76C7C", Offset = "0x2F76C7C", VA = "0x2F76C7C")]
	public void ԛ\u07EFӶ\u065A()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023B5 RID: 9141 RVA: 0x000BC1D4 File Offset: 0x000BA3D4
	[Token(Token = "0x60023B5")]
	[Address(RVA = "0x2F76D54", Offset = "0x2F76D54", VA = "0x2F76D54")]
	public void \u0559\u05FEפ\u05CD()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023B6 RID: 9142 RVA: 0x000BC21C File Offset: 0x000BA41C
	[Token(Token = "0x60023B6")]
	[Address(RVA = "0x2F76E2C", Offset = "0x2F76E2C", VA = "0x2F76E2C")]
	public void Ա\u05F9\u05BDܫ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023B7 RID: 9143 RVA: 0x000BC264 File Offset: 0x000BA464
	[Token(Token = "0x60023B7")]
	[Address(RVA = "0x2F76F04", Offset = "0x2F76F04", VA = "0x2F76F04")]
	public void \u05F8ࡂࡧ\u07FA()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023B8 RID: 9144 RVA: 0x000BC2AC File Offset: 0x000BA4AC
	[Token(Token = "0x60023B8")]
	[Address(RVA = "0x2F76FDC", Offset = "0x2F76FDC", VA = "0x2F76FDC")]
	public void LateUpdate()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023B9 RID: 9145 RVA: 0x000BC2F4 File Offset: 0x000BA4F4
	[Token(Token = "0x60023B9")]
	[Address(RVA = "0x2F7709C", Offset = "0x2F7709C", VA = "0x2F7709C")]
	public void \u081Cߌ\u0876Բ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023BA RID: 9146 RVA: 0x000BC33C File Offset: 0x000BA53C
	[Token(Token = "0x60023BA")]
	[Address(RVA = "0x2F77174", Offset = "0x2F77174", VA = "0x2F77174")]
	public void \u060Bݐ\u0745ࢣ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		Transform transform = this.ӵߪ\u0834ܝ.transform;
		if (this != null)
		{
			return;
		}
	}

	// Token: 0x060023BB RID: 9147 RVA: 0x000BC370 File Offset: 0x000BA570
	[Token(Token = "0x60023BB")]
	[Address(RVA = "0x2F7724C", Offset = "0x2F7724C", VA = "0x2F7724C")]
	public void \u05A1ߡࡅࢮ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023BC RID: 9148 RVA: 0x000BC3B8 File Offset: 0x000BA5B8
	[Token(Token = "0x60023BC")]
	[Address(RVA = "0x2F77324", Offset = "0x2F77324", VA = "0x2F77324")]
	public void Ԁ\u05EB\u085Eՠ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060023BD RID: 9149 RVA: 0x000BC400 File Offset: 0x000BA600
	[Token(Token = "0x60023BD")]
	[Address(RVA = "0x2F773FC", Offset = "0x2F773FC", VA = "0x2F773FC")]
	public void Ԯԇݯԃ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		GameObject ӵߪ_u0834ܝ = this.ӵߪ\u0834ܝ;
		bool <IsMine>k__BackingField = u07AE_u05AF_u064FԖ.<IsMine>k__BackingField;
		Transform transform = ӵߪ_u0834ܝ.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0400047A RID: 1146
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400047A")]
	public PhotonView \u07AE\u05AF\u064FԖ;

	// Token: 0x0400047B RID: 1147
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400047B")]
	public GameObject ӵߪ\u0834ܝ;
}
