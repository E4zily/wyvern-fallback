﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000B6 RID: 182
[Token(Token = "0x20000B6")]
public class DynamicBoneColliderBase : MonoBehaviour
{
	// Token: 0x06001A87 RID: 6791 RVA: 0x0008C90C File Offset: 0x0008AB0C
	[Token(Token = "0x6001A87")]
	[Address(RVA = "0x28C8FBC", Offset = "0x28C8FBC", VA = "0x28C8FBC", Slot = "4")]
	public virtual void \u083E\u0653ۮ\u0730()
	{
	}

	// Token: 0x06001A88 RID: 6792 RVA: 0x0008C91C File Offset: 0x0008AB1C
	[Token(Token = "0x6001A88")]
	[Address(RVA = "0x28C8FC0", Offset = "0x28C8FC0", VA = "0x28C8FC0", Slot = "5")]
	public virtual void عۻԂ\u055E()
	{
	}

	// Token: 0x06001A89 RID: 6793 RVA: 0x0008C92C File Offset: 0x0008AB2C
	[Token(Token = "0x6001A89")]
	[Address(RVA = "0x28C8FC4", Offset = "0x28C8FC4", VA = "0x28C8FC4", Slot = "6")]
	public virtual void \u0872\u089B\u082Eࡘ()
	{
	}

	// Token: 0x06001A8A RID: 6794 RVA: 0x0008C93C File Offset: 0x0008AB3C
	[Token(Token = "0x6001A8A")]
	[Address(RVA = "0x28C8FC8", Offset = "0x28C8FC8", VA = "0x28C8FC8", Slot = "7")]
	public virtual void \u0739߉ڵݞ()
	{
	}

	// Token: 0x06001A8B RID: 6795 RVA: 0x0008C94C File Offset: 0x0008AB4C
	[Token(Token = "0x6001A8B")]
	[Address(RVA = "0x28C8FCC", Offset = "0x28C8FCC", VA = "0x28C8FCC", Slot = "8")]
	public virtual void ࢰחڵࡓ()
	{
	}

	// Token: 0x06001A8C RID: 6796 RVA: 0x0008C95C File Offset: 0x0008AB5C
	[Token(Token = "0x6001A8C")]
	[Address(RVA = "0x28C8FD0", Offset = "0x28C8FD0", VA = "0x28C8FD0")]
	public void ޱܐӴӗ(int \u05FB\u05AB\u0739ڑ)
	{
		this.<\u05B4\u0873ڞӉ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x06001A8D RID: 6797 RVA: 0x0008C970 File Offset: 0x0008AB70
	[Token(Token = "0x6001A8D")]
	[Address(RVA = "0x28C8FD8", Offset = "0x28C8FD8", VA = "0x28C8FD8", Slot = "9")]
	public virtual bool ٱ\u083BӤ\u0838(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001A8E RID: 6798 RVA: 0x0008C980 File Offset: 0x0008AB80
	[Token(Token = "0x6001A8E")]
	[Address(RVA = "0x28C8FE0", Offset = "0x28C8FE0", VA = "0x28C8FE0", Slot = "10")]
	public virtual bool יڝߩԙ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001A8F RID: 6799 RVA: 0x0008C990 File Offset: 0x0008AB90
	[Token(Token = "0x6001A8F")]
	[Address(RVA = "0x28C8FE8", Offset = "0x28C8FE8", VA = "0x28C8FE8", Slot = "11")]
	public virtual void ԍ\u05BDأ\u066A()
	{
	}

	// Token: 0x06001A90 RID: 6800 RVA: 0x0008C9A0 File Offset: 0x0008ABA0
	[Token(Token = "0x6001A90")]
	[Address(RVA = "0x28C8FEC", Offset = "0x28C8FEC", VA = "0x28C8FEC", Slot = "12")]
	public virtual void Ԅ\u0598\u05B1ۆ()
	{
	}

	// Token: 0x06001A91 RID: 6801 RVA: 0x0008C9B0 File Offset: 0x0008ABB0
	[Token(Token = "0x6001A91")]
	[Address(RVA = "0x28C8FF0", Offset = "0x28C8FF0", VA = "0x28C8FF0")]
	public void \u05A4۳ڱۑ(int \u05FB\u05AB\u0739ڑ)
	{
		this.<\u05B4\u0873ڞӉ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x06001A92 RID: 6802 RVA: 0x0008C9C4 File Offset: 0x0008ABC4
	[Token(Token = "0x6001A92")]
	[Address(RVA = "0x28C8FF8", Offset = "0x28C8FF8", VA = "0x28C8FF8")]
	public void ࢨ\u0816\u070Dڅ(int \u05FB\u05AB\u0739ڑ)
	{
		this.<\u05B4\u0873ڞӉ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x06001A93 RID: 6803 RVA: 0x0008C9D8 File Offset: 0x0008ABD8
	[Token(Token = "0x6001A93")]
	[Address(RVA = "0x28C9000", Offset = "0x28C9000", VA = "0x28C9000")]
	public int ࠈ\u073DӃӄ()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001A94 RID: 6804 RVA: 0x0008C9EC File Offset: 0x0008ABEC
	[Token(Token = "0x6001A94")]
	[Address(RVA = "0x28C9008", Offset = "0x28C9008", VA = "0x28C9008", Slot = "13")]
	public virtual bool \u085EࡣԢސ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001A95 RID: 6805 RVA: 0x0008C9FC File Offset: 0x0008ABFC
	[Token(Token = "0x6001A95")]
	[Address(RVA = "0x28C9010", Offset = "0x28C9010", VA = "0x28C9010", Slot = "14")]
	public virtual bool ڙןԒے(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001A96 RID: 6806 RVA: 0x0008CA0C File Offset: 0x0008AC0C
	[Token(Token = "0x6001A96")]
	[Address(RVA = "0x28C9018", Offset = "0x28C9018", VA = "0x28C9018")]
	public void ԙ\u05F9\u05F4ڧ(int \u05FB\u05AB\u0739ڑ)
	{
		this.<\u05B4\u0873ڞӉ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x06001A97 RID: 6807 RVA: 0x0008CA20 File Offset: 0x0008AC20
	[Token(Token = "0x6001A97")]
	[Address(RVA = "0x28C9020", Offset = "0x28C9020", VA = "0x28C9020", Slot = "15")]
	public virtual bool ڊՁ\u073Fࡪ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001A98 RID: 6808 RVA: 0x0008CA30 File Offset: 0x0008AC30
	[Token(Token = "0x6001A98")]
	[Address(RVA = "0x28C9028", Offset = "0x28C9028", VA = "0x28C9028", Slot = "16")]
	public virtual bool ռם\u087Cߐ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001A99 RID: 6809 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001A99")]
	[Address(RVA = "0x28C9030", Offset = "0x28C9030", VA = "0x28C9030", Slot = "17")]
	public virtual bool ڄ\u05CAޘԯ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001A9A RID: 6810 RVA: 0x0008CA40 File Offset: 0x0008AC40
	[Token(Token = "0x6001A9A")]
	[Address(RVA = "0x28C9038", Offset = "0x28C9038", VA = "0x28C9038", Slot = "18")]
	public virtual bool ܣՌ٥ո(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001A9B RID: 6811 RVA: 0x0008CA50 File Offset: 0x0008AC50
	[Token(Token = "0x6001A9B")]
	[Address(RVA = "0x28C9040", Offset = "0x28C9040", VA = "0x28C9040")]
	public void ߔܢלה(int \u05FB\u05AB\u0739ڑ)
	{
		this.<\u05B4\u0873ڞӉ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x06001A9C RID: 6812 RVA: 0x0008CA64 File Offset: 0x0008AC64
	[Token(Token = "0x6001A9C")]
	[Address(RVA = "0x28C9048", Offset = "0x28C9048", VA = "0x28C9048", Slot = "19")]
	public virtual void ߖհݣ߀()
	{
	}

	// Token: 0x06001A9D RID: 6813 RVA: 0x0008CA74 File Offset: 0x0008AC74
	[Token(Token = "0x6001A9D")]
	[Address(RVA = "0x28C904C", Offset = "0x28C904C", VA = "0x28C904C", Slot = "20")]
	public virtual void ٵՌց\u0705()
	{
	}

	// Token: 0x06001A9E RID: 6814 RVA: 0x0008CA84 File Offset: 0x0008AC84
	[Token(Token = "0x6001A9E")]
	[Address(RVA = "0x28C9050", Offset = "0x28C9050", VA = "0x28C9050", Slot = "21")]
	public virtual bool ܖࠌ\u07B6ࡉ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001A9F RID: 6815 RVA: 0x0008CA94 File Offset: 0x0008AC94
	[Token(Token = "0x6001A9F")]
	[Address(RVA = "0x28C9058", Offset = "0x28C9058", VA = "0x28C9058")]
	public void \u07FA\u05B3ڽ\u070C(int \u05FB\u05AB\u0739ڑ)
	{
		this.<\u05B4\u0873ڞӉ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x06001AA0 RID: 6816 RVA: 0x0008CAA8 File Offset: 0x0008ACA8
	[Token(Token = "0x6001AA0")]
	[Address(RVA = "0x28C9060", Offset = "0x28C9060", VA = "0x28C9060", Slot = "22")]
	public virtual void ۊո\u0612\u0595()
	{
	}

	// Token: 0x06001AA1 RID: 6817 RVA: 0x0008CAB8 File Offset: 0x0008ACB8
	[Token(Token = "0x6001AA1")]
	[Address(RVA = "0x28C9064", Offset = "0x28C9064", VA = "0x28C9064")]
	public int \u070FԦ\u0742ࢺ()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001AA2 RID: 6818 RVA: 0x0008CACC File Offset: 0x0008ACCC
	[Token(Token = "0x6001AA2")]
	[Address(RVA = "0x28C906C", Offset = "0x28C906C", VA = "0x28C906C", Slot = "23")]
	public virtual bool ԖڣԾ\u06DB(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001AA3 RID: 6819 RVA: 0x0008CADC File Offset: 0x0008ACDC
	[Token(Token = "0x6001AA3")]
	[Address(RVA = "0x28C9074", Offset = "0x28C9074", VA = "0x28C9074")]
	public void \u05F9ӧ\u0834\u0597(int \u05FB\u05AB\u0739ڑ)
	{
		this.<\u05B4\u0873ڞӉ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x06001AA4 RID: 6820 RVA: 0x0008CAF0 File Offset: 0x0008ACF0
	[Token(Token = "0x6001AA4")]
	[Address(RVA = "0x28C907C", Offset = "0x28C907C", VA = "0x28C907C")]
	public int Ԛ\u0615գࢹ()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001AA5 RID: 6821 RVA: 0x0008CB04 File Offset: 0x0008AD04
	[Token(Token = "0x6001AA5")]
	[Address(RVA = "0x28C9084", Offset = "0x28C9084", VA = "0x28C9084")]
	public void ӡշ\u0880߃(int \u05FB\u05AB\u0739ڑ)
	{
		this.<\u05B4\u0873ڞӉ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x06001AA6 RID: 6822 RVA: 0x0008CB18 File Offset: 0x0008AD18
	[Token(Token = "0x6001AA6")]
	[Address(RVA = "0x28C908C", Offset = "0x28C908C", VA = "0x28C908C")]
	public int ࢡ\u0612٨\u0605()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001AA7 RID: 6823 RVA: 0x0008CB2C File Offset: 0x0008AD2C
	[Token(Token = "0x6001AA7")]
	[Address(RVA = "0x28C9094", Offset = "0x28C9094", VA = "0x28C9094")]
	public int \u06E5ٺ߉ߏ()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001AA8 RID: 6824 RVA: 0x0008CB40 File Offset: 0x0008AD40
	[Token(Token = "0x6001AA8")]
	[Address(RVA = "0x28C909C", Offset = "0x28C909C", VA = "0x28C909C")]
	public int ܭࠋࠓ\u07FA()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001AA9 RID: 6825 RVA: 0x0008CB54 File Offset: 0x0008AD54
	[Token(Token = "0x6001AA9")]
	[Address(RVA = "0x28C90A4", Offset = "0x28C90A4", VA = "0x28C90A4", Slot = "24")]
	public virtual bool ލӓܢև(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001AAA RID: 6826 RVA: 0x0008CB64 File Offset: 0x0008AD64
	[Token(Token = "0x6001AAA")]
	[Address(RVA = "0x28C90AC", Offset = "0x28C90AC", VA = "0x28C90AC", Slot = "25")]
	public virtual void ץߙӘ\u0816()
	{
	}

	// Token: 0x06001AAB RID: 6827 RVA: 0x0008CB74 File Offset: 0x0008AD74
	[Token(Token = "0x6001AAB")]
	[Address(RVA = "0x28C90B0", Offset = "0x28C90B0", VA = "0x28C90B0")]
	public int ނܓԂӼ()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001AAC RID: 6828 RVA: 0x0008CB88 File Offset: 0x0008AD88
	[Token(Token = "0x6001AAC")]
	[Address(RVA = "0x28C90B8", Offset = "0x28C90B8", VA = "0x28C90B8")]
	public DynamicBoneColliderBase()
	{
		long ߌع_u0702ӷ = 1L;
		this.ߌع\u0702ӷ = (DynamicBoneColliderBase.ߋڛڐ\u0659)ߌع_u0702ӷ;
		Vector3 zero = Vector3.zero;
		base..ctor();
	}

	// Token: 0x06001AAD RID: 6829 RVA: 0x0008CBAC File Offset: 0x0008ADAC
	[Token(Token = "0x6001AAD")]
	[Address(RVA = "0x28C90F4", Offset = "0x28C90F4", VA = "0x28C90F4", Slot = "26")]
	public virtual void \u0711ӿ\u08B5ܥ()
	{
	}

	// Token: 0x06001AAE RID: 6830 RVA: 0x0008CBBC File Offset: 0x0008ADBC
	[Token(Token = "0x6001AAE")]
	[Address(RVA = "0x28C90F8", Offset = "0x28C90F8", VA = "0x28C90F8")]
	public int \u0835ߔࡈ\u0657()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x06001AB7 RID: 6839 RVA: 0x0008CC44 File Offset: 0x0008AE44
	// (set) Token: 0x06001AAF RID: 6831 RVA: 0x0008CBD0 File Offset: 0x0008ADD0
	[Token(Token = "0x1700002C")]
	public int \u081C\u06D9ܣՋ { [Token(Token = "0x6001AB7")] [Address(RVA = "0x28C9130", Offset = "0x28C9130", VA = "0x28C9130")] get; [Token(Token = "0x6001AAF")] [Address(RVA = "0x28C9100", Offset = "0x28C9100", VA = "0x28C9100")] set; }

	// Token: 0x06001AB0 RID: 6832 RVA: 0x0008CBE4 File Offset: 0x0008ADE4
	[Token(Token = "0x6001AB0")]
	[Address(RVA = "0x28C9108", Offset = "0x28C9108", VA = "0x28C9108", Slot = "27")]
	public virtual void ڣ\u082B\u0816ث()
	{
	}

	// Token: 0x06001AB1 RID: 6833 RVA: 0x0008CBF4 File Offset: 0x0008ADF4
	[Token(Token = "0x6001AB1")]
	[Address(RVA = "0x28C910C", Offset = "0x28C910C", VA = "0x28C910C", Slot = "28")]
	public virtual void ԉࡍߢ\u0655()
	{
	}

	// Token: 0x06001AB2 RID: 6834 RVA: 0x0008CC04 File Offset: 0x0008AE04
	[Token(Token = "0x6001AB2")]
	[Address(RVA = "0x28C9110", Offset = "0x28C9110", VA = "0x28C9110", Slot = "29")]
	public virtual bool \u0596\u07B3\u083Bԇ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001AB3 RID: 6835 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001AB3")]
	[Address(RVA = "0x28C9118", Offset = "0x28C9118", VA = "0x28C9118")]
	public int ٥ݜԆۏ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AB4 RID: 6836 RVA: 0x0008CC14 File Offset: 0x0008AE14
	[Token(Token = "0x6001AB4")]
	[Address(RVA = "0x28C9120", Offset = "0x28C9120", VA = "0x28C9120", Slot = "30")]
	public virtual void ࡩݮڢՠ()
	{
	}

	// Token: 0x06001AB5 RID: 6837 RVA: 0x0008CC24 File Offset: 0x0008AE24
	[Token(Token = "0x6001AB5")]
	[Address(RVA = "0x28C9124", Offset = "0x28C9124", VA = "0x28C9124", Slot = "31")]
	public virtual bool ٲآڀ\u0557(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x06001AB6 RID: 6838 RVA: 0x0008CC34 File Offset: 0x0008AE34
	[Token(Token = "0x6001AB6")]
	[Address(RVA = "0x28C912C", Offset = "0x28C912C", VA = "0x28C912C", Slot = "32")]
	public virtual void Start()
	{
	}

	// Token: 0x06001AB8 RID: 6840 RVA: 0x0008CC58 File Offset: 0x0008AE58
	[Token(Token = "0x6001AB8")]
	[Address(RVA = "0x28C9138", Offset = "0x28C9138", VA = "0x28C9138", Slot = "33")]
	public virtual void \u06D6ې\u083Bࠉ()
	{
	}

	// Token: 0x06001AB9 RID: 6841 RVA: 0x0008CC68 File Offset: 0x0008AE68
	[Token(Token = "0x6001AB9")]
	[Address(RVA = "0x28C913C", Offset = "0x28C913C", VA = "0x28C913C")]
	public int \u0650اև\u05C0()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001ABA RID: 6842 RVA: 0x0008CC7C File Offset: 0x0008AE7C
	[Token(Token = "0x6001ABA")]
	[Address(RVA = "0x28C9144", Offset = "0x28C9144", VA = "0x28C9144")]
	public void ӿ\u087C\u085C߀(int \u05FB\u05AB\u0739ڑ)
	{
		this.<\u05B4\u0873ڞӉ>k__BackingField = \u05FB\u05AB\u0739ڑ;
	}

	// Token: 0x06001ABB RID: 6843 RVA: 0x0008CC90 File Offset: 0x0008AE90
	[Token(Token = "0x6001ABB")]
	[Address(RVA = "0x28C914C", Offset = "0x28C914C", VA = "0x28C914C")]
	public int Ԋݏ\u058A\u07B7()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001ABC RID: 6844 RVA: 0x0008CCA4 File Offset: 0x0008AEA4
	[Token(Token = "0x6001ABC")]
	[Address(RVA = "0x28C9154", Offset = "0x28C9154", VA = "0x28C9154", Slot = "34")]
	public virtual void \u082Aԩ\u05B4ܭ()
	{
	}

	// Token: 0x06001ABD RID: 6845 RVA: 0x0008CCB4 File Offset: 0x0008AEB4
	[Token(Token = "0x6001ABD")]
	[Address(RVA = "0x28C9158", Offset = "0x28C9158", VA = "0x28C9158", Slot = "35")]
	public virtual void \u085EӁݷ\u05A6()
	{
	}

	// Token: 0x06001ABE RID: 6846 RVA: 0x0008CCC4 File Offset: 0x0008AEC4
	[Token(Token = "0x6001ABE")]
	[Address(RVA = "0x28C915C", Offset = "0x28C915C", VA = "0x28C915C", Slot = "36")]
	public virtual void \u05C8\u05BFࠁف()
	{
	}

	// Token: 0x06001ABF RID: 6847 RVA: 0x0008CCD4 File Offset: 0x0008AED4
	[Token(Token = "0x6001ABF")]
	[Address(RVA = "0x28C9160", Offset = "0x28C9160", VA = "0x28C9160", Slot = "37")]
	public virtual void \u083E\u0611ࢡմ()
	{
	}

	// Token: 0x06001AC0 RID: 6848 RVA: 0x0008CCE4 File Offset: 0x0008AEE4
	[Token(Token = "0x6001AC0")]
	[Address(RVA = "0x28C9164", Offset = "0x28C9164", VA = "0x28C9164")]
	public int \u06E2ըࢭ\u07EB()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001AC1 RID: 6849 RVA: 0x0008CCF8 File Offset: 0x0008AEF8
	[Token(Token = "0x6001AC1")]
	[Address(RVA = "0x28C916C", Offset = "0x28C916C", VA = "0x28C916C")]
	public int \u058EࠋࢭԮ()
	{
		return this.<\u05B4\u0873ڞӉ>k__BackingField;
	}

	// Token: 0x06001AC2 RID: 6850 RVA: 0x0008CD0C File Offset: 0x0008AF0C
	[Token(Token = "0x6001AC2")]
	[Address(RVA = "0x28C9174", Offset = "0x28C9174", VA = "0x28C9174", Slot = "38")]
	public virtual bool \u086Eֆم٦(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
	}

	// Token: 0x04000385 RID: 901
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000385")]
	public DynamicBoneColliderBase.ߋڛڐ\u0659 ߌع\u0702ӷ;

	// Token: 0x04000386 RID: 902
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4000386")]
	public Vector3 \u07BEօࢡ\u05FD;

	// Token: 0x04000387 RID: 903
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000387")]
	public DynamicBoneColliderBase.Փ\u0839\u0734ߍ ٤\u058Fࢬࡓ;

	// Token: 0x020000B7 RID: 183
	[Token(Token = "0x20000B7")]
	public enum ߋڛڐ\u0659
	{
		// Token: 0x0400038A RID: 906
		[Token(Token = "0x400038A")]
		\u06DBޣݦض,
		// Token: 0x0400038B RID: 907
		[Token(Token = "0x400038B")]
		ܖյӮݠ,
		// Token: 0x0400038C RID: 908
		[Token(Token = "0x400038C")]
		م\u07F1ӯࡘ
	}

	// Token: 0x020000B8 RID: 184
	[Token(Token = "0x20000B8")]
	public enum Փ\u0839\u0734ߍ
	{
		// Token: 0x0400038E RID: 910
		[Token(Token = "0x400038E")]
		ݣ٠ࢥ\u0894,
		// Token: 0x0400038F RID: 911
		[Token(Token = "0x400038F")]
		ݟࢹ\u05A4\u0739
	}
}
