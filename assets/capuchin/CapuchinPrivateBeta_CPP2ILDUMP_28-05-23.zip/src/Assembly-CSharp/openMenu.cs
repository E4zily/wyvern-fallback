﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020000FB RID: 251
[Token(Token = "0x20000FB")]
public class openMenu : MonoBehaviour
{
	// Token: 0x060026D7 RID: 9943 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026D7")]
	[Address(RVA = "0x2E37A74", Offset = "0x2E37A74", VA = "0x2E37A74")]
	public void \u055C\u0670\u06EA\u05EC()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026D8 RID: 9944 RVA: 0x000E3D54 File Offset: 0x000E1F54
	[Token(Token = "0x60026D8")]
	[Address(RVA = "0x2E37B34", Offset = "0x2E37B34", VA = "0x2E37B34")]
	private void ԣԭՋࠏ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x060026D9 RID: 9945 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026D9")]
	[Address(RVA = "0x2E37C04", Offset = "0x2E37C04", VA = "0x2E37C04")]
	public void \u060Bݐ\u0745ࢣ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026DA RID: 9946 RVA: 0x000E3D98 File Offset: 0x000E1F98
	[Token(Token = "0x60026DA")]
	[Address(RVA = "0x2E37CB8", Offset = "0x2E37CB8", VA = "0x2E37CB8")]
	public void \u0870ԉݳԓ()
	{
	}

	// Token: 0x060026DB RID: 9947 RVA: 0x000E3DA8 File Offset: 0x000E1FA8
	[Token(Token = "0x60026DB")]
	[Address(RVA = "0x2E37CC0", Offset = "0x2E37CC0", VA = "0x2E37CC0")]
	public void ࢷߛ\u05FBӻ()
	{
	}

	// Token: 0x060026DC RID: 9948 RVA: 0x000E3DB8 File Offset: 0x000E1FB8
	[Token(Token = "0x60026DC")]
	[Address(RVA = "0x2E37CC8", Offset = "0x2E37CC8", VA = "0x2E37CC8")]
	public openMenu()
	{
	}

	// Token: 0x060026DD RID: 9949 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026DD")]
	[Address(RVA = "0x2E37CD0", Offset = "0x2E37CD0", VA = "0x2E37CD0")]
	public void بࠂռ\u05C6()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026DE RID: 9950 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026DE")]
	[Address(RVA = "0x2E37D90", Offset = "0x2E37D90", VA = "0x2E37D90")]
	public void \u05A1ߡࡅࢮ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026DF RID: 9951 RVA: 0x000E3DCC File Offset: 0x000E1FCC
	[Token(Token = "0x60026DF")]
	[Address(RVA = "0x2E37E44", Offset = "0x2E37E44", VA = "0x2E37E44")]
	public void \u088C۲\u082Dی()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("username");
	}

	// Token: 0x060026E0 RID: 9952 RVA: 0x000E3E10 File Offset: 0x000E2010
	[Token(Token = "0x60026E0")]
	[Address(RVA = "0x2E37EEC", Offset = "0x2E37EEC", VA = "0x2E37EEC")]
	public void \u086D\u0703\u05A0\u061B()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("2BN");
	}

	// Token: 0x060026E1 RID: 9953 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026E1")]
	[Address(RVA = "0x2E37F94", Offset = "0x2E37F94", VA = "0x2E37F94")]
	public void \u082Eכ\u0640ܮ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026E2 RID: 9954 RVA: 0x000E3E54 File Offset: 0x000E2054
	[Token(Token = "0x60026E2")]
	[Address(RVA = "0x2E38048", Offset = "0x2E38048", VA = "0x2E38048")]
	public void ࠄإ\u07FD\u07B7()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Thumb");
	}

	// Token: 0x060026E3 RID: 9955 RVA: 0x000E3EA4 File Offset: 0x000E20A4
	[Token(Token = "0x60026E3")]
	[Address(RVA = "0x2E380F4", Offset = "0x2E380F4", VA = "0x2E380F4")]
	public void ࢬۍظӥ()
	{
	}

	// Token: 0x060026E4 RID: 9956 RVA: 0x000E3EB4 File Offset: 0x000E20B4
	[Token(Token = "0x60026E4")]
	[Address(RVA = "0x2E380FC", Offset = "0x2E380FC", VA = "0x2E380FC")]
	public void ݒࠀ\u070D\u073B()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("NetworkPlayer");
	}

	// Token: 0x060026E5 RID: 9957 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026E5")]
	[Address(RVA = "0x2E381A4", Offset = "0x2E381A4", VA = "0x2E381A4")]
	public void ӣՃ\u07FAԟ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026E6 RID: 9958 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026E6")]
	[Address(RVA = "0x2E38258", Offset = "0x2E38258", VA = "0x2E38258")]
	public void Ա\u05F9\u05BDܫ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026E7 RID: 9959 RVA: 0x000E3EF8 File Offset: 0x000E20F8
	[Token(Token = "0x60026E7")]
	[Address(RVA = "0x2E3830C", Offset = "0x2E3830C", VA = "0x2E3830C")]
	public void ڊ\u07B3\u0836ࡥ()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("BN");
	}

	// Token: 0x060026E8 RID: 9960 RVA: 0x000E3F3C File Offset: 0x000E213C
	[Token(Token = "0x60026E8")]
	[Address(RVA = "0x2E383B4", Offset = "0x2E383B4", VA = "0x2E383B4")]
	public void ߞ\u0600ࢫԌ()
	{
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
	}

	// Token: 0x060026E9 RID: 9961 RVA: 0x000E3F54 File Offset: 0x000E2154
	[Token(Token = "0x60026E9")]
	[Address(RVA = "0x2E383C0", Offset = "0x2E383C0", VA = "0x2E383C0")]
	public void ӐӗԱ\u07FA()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
	}

	// Token: 0x060026EA RID: 9962 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026EA")]
	[Address(RVA = "0x2E38468", Offset = "0x2E38468", VA = "0x2E38468")]
	public void ה\u07F4Ց\u0889()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026EB RID: 9963 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026EB")]
	[Address(RVA = "0x2E3851C", Offset = "0x2E3851C", VA = "0x2E3851C")]
	public void \u0706\u05CDߜح()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026EC RID: 9964 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026EC")]
	[Address(RVA = "0x2E385D0", Offset = "0x2E385D0", VA = "0x2E385D0")]
	public void ߒࠅߝ۹()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026ED RID: 9965 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026ED")]
	[Address(RVA = "0x2E38684", Offset = "0x2E38684", VA = "0x2E38684")]
	public void ڽ\u07A6ԛݚ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026EE RID: 9966 RVA: 0x000E3F98 File Offset: 0x000E2198
	[Token(Token = "0x60026EE")]
	[Address(RVA = "0x2E38738", Offset = "0x2E38738", VA = "0x2E38738")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
	}

	// Token: 0x060026EF RID: 9967 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026EF")]
	[Address(RVA = "0x2E387EC", Offset = "0x2E387EC", VA = "0x2E387EC")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026F0 RID: 9968 RVA: 0x000E3FD0 File Offset: 0x000E21D0
	[Token(Token = "0x60026F0")]
	[Address(RVA = "0x2E388A0", Offset = "0x2E388A0", VA = "0x2E388A0")]
	public void \u073Bࡃץࢷ()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		long ߅Ӭ_u07AFդ = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("This is the 2500 Bananas button, and it was just clicked");
	}

	// Token: 0x060026F1 RID: 9969 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026F1")]
	[Address(RVA = "0x2E3894C", Offset = "0x2E3894C", VA = "0x2E3894C")]
	public void ӀԹ\u06DA\u05C5()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026F2 RID: 9970 RVA: 0x000E4020 File Offset: 0x000E2220
	[Token(Token = "0x60026F2")]
	[Address(RVA = "0x2E38A0C", Offset = "0x2E38A0C", VA = "0x2E38A0C")]
	public void ݖ\u05FFیԃ()
	{
	}

	// Token: 0x060026F3 RID: 9971 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026F3")]
	[Address(RVA = "0x2E38A14", Offset = "0x2E38A14", VA = "0x2E38A14")]
	public void \u06DEԍӂս()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026F4 RID: 9972 RVA: 0x000E4030 File Offset: 0x000E2230
	[Token(Token = "0x60026F4")]
	[Address(RVA = "0x2E38AC8", Offset = "0x2E38AC8", VA = "0x2E38AC8")]
	private void ڦکӁ\u06E2()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
	}

	// Token: 0x060026F5 RID: 9973 RVA: 0x000E4074 File Offset: 0x000E2274
	[Token(Token = "0x60026F5")]
	[Address(RVA = "0x2E38B94", Offset = "0x2E38B94", VA = "0x2E38B94")]
	public void ޗ߆ࢺۃ()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Game Started");
	}

	// Token: 0x060026F6 RID: 9974 RVA: 0x000E40B8 File Offset: 0x000E22B8
	[Token(Token = "0x60026F6")]
	[Address(RVA = "0x2E38C3C", Offset = "0x2E38C3C", VA = "0x2E38C3C")]
	private void \u0821\u059Fӕ\u0607()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x060026F7 RID: 9975 RVA: 0x000E4110 File Offset: 0x000E2310
	[Token(Token = "0x60026F7")]
	[Address(RVA = "0x2E38D1C", Offset = "0x2E38D1C", VA = "0x2E38D1C")]
	private void \u0836\u089Dی\u0735()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x060026F8 RID: 9976 RVA: 0x000E4154 File Offset: 0x000E2354
	[Token(Token = "0x60026F8")]
	[Address(RVA = "0x2E38DEC", Offset = "0x2E38DEC", VA = "0x2E38DEC")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x060026F9 RID: 9977 RVA: 0x000E41AC File Offset: 0x000E23AC
	[Token(Token = "0x60026F9")]
	[Address(RVA = "0x2E38ECC", Offset = "0x2E38ECC", VA = "0x2E38ECC")]
	public void ܗࢹ\u087Eܗ()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Reason: ");
	}

	// Token: 0x060026FA RID: 9978 RVA: 0x000E41F0 File Offset: 0x000E23F0
	[Token(Token = "0x60026FA")]
	[Address(RVA = "0x2E38F74", Offset = "0x2E38F74", VA = "0x2E38F74")]
	public void \u061E\u0822\u060Bګ()
	{
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
	}

	// Token: 0x060026FB RID: 9979 RVA: 0x000E4208 File Offset: 0x000E2408
	[Token(Token = "0x60026FB")]
	[Address(RVA = "0x2E38F80", Offset = "0x2E38F80", VA = "0x2E38F80")]
	private void \u07FE\u0882Զ\u066D()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x060026FC RID: 9980 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026FC")]
	[Address(RVA = "0x2E39060", Offset = "0x2E39060", VA = "0x2E39060")]
	public void \u089Fށհ\u083F()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026FD RID: 9981 RVA: 0x000E4260 File Offset: 0x000E2460
	[Token(Token = "0x60026FD")]
	[Address(RVA = "0x2E39114", Offset = "0x2E39114", VA = "0x2E39114")]
	public void ݤݻخ\u07A6()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		long ߅Ӭ_u07AFդ = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("Is Colliding");
	}

	// Token: 0x060026FE RID: 9982 RVA: 0x000E42B0 File Offset: 0x000E24B0
	[Token(Token = "0x60026FE")]
	[Address(RVA = "0x2E391C0", Offset = "0x2E391C0", VA = "0x2E391C0")]
	private void \u0732ڙԒࢺ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
	}

	// Token: 0x060026FF RID: 9983 RVA: 0x000E42E8 File Offset: 0x000E24E8
	[Token(Token = "0x60026FF")]
	[Address(RVA = "0x2E39274", Offset = "0x2E39274", VA = "0x2E39274")]
	private void չւت\u061E()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x06002700 RID: 9984 RVA: 0x000E4340 File Offset: 0x000E2540
	[Token(Token = "0x6002700")]
	[Address(RVA = "0x2E39354", Offset = "0x2E39354", VA = "0x2E39354")]
	public void Ԕ\u07AB\u0597\u0705()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("BLUTARG");
	}

	// Token: 0x06002701 RID: 9985 RVA: 0x000E4384 File Offset: 0x000E2584
	[Token(Token = "0x6002701")]
	[Address(RVA = "0x2E393FC", Offset = "0x2E393FC", VA = "0x2E393FC")]
	public void ӑ\u0876ԣԨ()
	{
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
	}

	// Token: 0x06002702 RID: 9986 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002702")]
	[Address(RVA = "0x2E39408", Offset = "0x2E39408", VA = "0x2E39408")]
	public void ԛ\u07EFӶ\u065A()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002703 RID: 9987 RVA: 0x000E439C File Offset: 0x000E259C
	[Token(Token = "0x6002703")]
	[Address(RVA = "0x2E394BC", Offset = "0x2E394BC", VA = "0x2E394BC")]
	private void ࡕߕ\u0707ݩ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x06002704 RID: 9988 RVA: 0x000E43F4 File Offset: 0x000E25F4
	[Token(Token = "0x6002704")]
	[Address(RVA = "0x2E3959C", Offset = "0x2E3959C", VA = "0x2E3959C")]
	public void إ\u0827٨\u066A()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		long ߅Ӭ_u07AFդ = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("/");
	}

	// Token: 0x06002705 RID: 9989 RVA: 0x000E4444 File Offset: 0x000E2644
	[Token(Token = "0x6002705")]
	[Address(RVA = "0x2E39648", Offset = "0x2E39648", VA = "0x2E39648")]
	private void ࢶ٠\u086D\u0708()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x06002706 RID: 9990 RVA: 0x000E4488 File Offset: 0x000E2688
	[Token(Token = "0x6002706")]
	[Address(RVA = "0x2E39718", Offset = "0x2E39718", VA = "0x2E39718")]
	public void ߋ\u0591ۓԥ()
	{
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
	}

	// Token: 0x06002707 RID: 9991 RVA: 0x000E44A0 File Offset: 0x000E26A0
	[Token(Token = "0x6002707")]
	[Address(RVA = "0x2E39724", Offset = "0x2E39724", VA = "0x2E39724")]
	public void Ӗ\u05C5\u086D\u0892()
	{
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
	}

	// Token: 0x06002708 RID: 9992 RVA: 0x000E44B8 File Offset: 0x000E26B8
	[Token(Token = "0x6002708")]
	[Address(RVA = "0x2E39730", Offset = "0x2E39730", VA = "0x2E39730")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
	}

	// Token: 0x06002709 RID: 9993 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002709")]
	[Address(RVA = "0x2E397E4", Offset = "0x2E397E4", VA = "0x2E397E4")]
	public void ק\u086DԜࡖ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600270A RID: 9994 RVA: 0x000E44F0 File Offset: 0x000E26F0
	[Token(Token = "0x600270A")]
	[Address(RVA = "0x2E39898", Offset = "0x2E39898", VA = "0x2E39898")]
	public void ࡐ\u08B5\u085E\u05A9()
	{
	}

	// Token: 0x0600270B RID: 9995 RVA: 0x000E4500 File Offset: 0x000E2700
	[Token(Token = "0x600270B")]
	[Address(RVA = "0x2E398A0", Offset = "0x2E398A0", VA = "0x2E398A0")]
	public void ԩ\u05EEփࠌ()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("You Look Like Butt");
	}

	// Token: 0x0600270C RID: 9996 RVA: 0x000E4544 File Offset: 0x000E2744
	[Token(Token = "0x600270C")]
	[Address(RVA = "0x2E39948", Offset = "0x2E39948", VA = "0x2E39948")]
	private void յߪؾՀ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
	}

	// Token: 0x0600270D RID: 9997 RVA: 0x000E457C File Offset: 0x000E277C
	[Token(Token = "0x600270D")]
	[Address(RVA = "0x2E399FC", Offset = "0x2E399FC", VA = "0x2E399FC")]
	public void \u0887ڧӤܐ()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("sound play play");
	}

	// Token: 0x0600270E RID: 9998 RVA: 0x000E45CC File Offset: 0x000E27CC
	[Token(Token = "0x600270E")]
	[Address(RVA = "0x2E39AA8", Offset = "0x2E39AA8", VA = "0x2E39AA8")]
	public void Ҿ߀ھڇ()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("run");
	}

	// Token: 0x0600270F RID: 9999 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600270F")]
	[Address(RVA = "0x2E39B50", Offset = "0x2E39B50", VA = "0x2E39B50")]
	public void ࡣؠڇڠ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002710 RID: 10000 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002710")]
	[Address(RVA = "0x2E39C04", Offset = "0x2E39C04", VA = "0x2E39C04")]
	public void ٷ\u05F5Ԗ\u0595()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002711 RID: 10001 RVA: 0x000E4610 File Offset: 0x000E2810
	[Token(Token = "0x6002711")]
	[Address(RVA = "0x2E39CB8", Offset = "0x2E39CB8", VA = "0x2E39CB8")]
	private void \u0832ࢳޤ\u07B5()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x06002712 RID: 10002 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002712")]
	[Address(RVA = "0x2E39D88", Offset = "0x2E39D88", VA = "0x2E39D88")]
	public void \u05A0\u05B4\u05F5ߣ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002713 RID: 10003 RVA: 0x000E4654 File Offset: 0x000E2854
	[Token(Token = "0x6002713")]
	[Address(RVA = "0x2E39E3C", Offset = "0x2E39E3C", VA = "0x2E39E3C")]
	public void ޥۇ\u0602\u06E8()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("");
	}

	// Token: 0x06002714 RID: 10004 RVA: 0x000E4698 File Offset: 0x000E2898
	[Token(Token = "0x6002714")]
	[Address(RVA = "0x2E39EE4", Offset = "0x2E39EE4", VA = "0x2E39EE4")]
	private void ފՖߢ\u059B()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
	}

	// Token: 0x06002715 RID: 10005 RVA: 0x000E46DC File Offset: 0x000E28DC
	[Token(Token = "0x6002715")]
	[Address(RVA = "0x2E39FB0", Offset = "0x2E39FB0", VA = "0x2E39FB0")]
	public void \u06E2ࠋظ\u05F9()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("username");
	}

	// Token: 0x06002716 RID: 10006 RVA: 0x000E4720 File Offset: 0x000E2920
	[Token(Token = "0x6002716")]
	[Address(RVA = "0x2E3A058", Offset = "0x2E3A058", VA = "0x2E3A058")]
	public void \u089Dݰԟ\u087B()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("");
	}

	// Token: 0x06002717 RID: 10007 RVA: 0x000E4764 File Offset: 0x000E2964
	[Token(Token = "0x6002717")]
	[Address(RVA = "0x2E3A100", Offset = "0x2E3A100", VA = "0x2E3A100")]
	public void ӱվ\u081Cܦ()
	{
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
	}

	// Token: 0x06002718 RID: 10008 RVA: 0x000E477C File Offset: 0x000E297C
	[Token(Token = "0x6002718")]
	[Address(RVA = "0x2E3A10C", Offset = "0x2E3A10C", VA = "0x2E3A10C")]
	private void \u0870\u05B3Ց\u066A()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x06002719 RID: 10009 RVA: 0x000E47C0 File Offset: 0x000E29C0
	[Token(Token = "0x6002719")]
	[Address(RVA = "0x2E3A1DC", Offset = "0x2E3A1DC", VA = "0x2E3A1DC")]
	private void ڑߒجވ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
	}

	// Token: 0x0600271A RID: 10010 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600271A")]
	[Address(RVA = "0x2E3A2A8", Offset = "0x2E3A2A8", VA = "0x2E3A2A8")]
	public void \u081Cߌ\u0876Բ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600271B RID: 10011 RVA: 0x000E4804 File Offset: 0x000E2A04
	[Token(Token = "0x600271B")]
	[Address(RVA = "0x2E3A35C", Offset = "0x2E3A35C", VA = "0x2E3A35C")]
	private void ی\u0823ڇݔ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x0600271C RID: 10012 RVA: 0x000E4848 File Offset: 0x000E2A48
	[Token(Token = "0x600271C")]
	[Address(RVA = "0x2E3A42C", Offset = "0x2E3A42C", VA = "0x2E3A42C")]
	public void ڻӼۉ\u0618()
	{
	}

	// Token: 0x0600271D RID: 10013 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600271D")]
	[Address(RVA = "0x2E3A434", Offset = "0x2E3A434", VA = "0x2E3A434")]
	public void ض\u064Fޢշ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600271E RID: 10014 RVA: 0x000E4858 File Offset: 0x000E2A58
	[Token(Token = "0x600271E")]
	[Address(RVA = "0x2E3A4F4", Offset = "0x2E3A4F4", VA = "0x2E3A4F4")]
	private void \u0892ܒܬޓ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
	}

	// Token: 0x0600271F RID: 10015 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600271F")]
	[Address(RVA = "0x2E3A5A8", Offset = "0x2E3A5A8", VA = "0x2E3A5A8")]
	public void ބܝۄ\u0703()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002720 RID: 10016 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002720")]
	[Address(RVA = "0x2E3A65C", Offset = "0x2E3A65C", VA = "0x2E3A65C")]
	public void \u05F8ڶ\u070Aө()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002721 RID: 10017 RVA: 0x000E4890 File Offset: 0x000E2A90
	[Token(Token = "0x6002721")]
	[Address(RVA = "0x2E3A710", Offset = "0x2E3A710", VA = "0x2E3A710")]
	public void \u07F9\u0887\u073BԤ()
	{
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
	}

	// Token: 0x06002722 RID: 10018 RVA: 0x000E48A8 File Offset: 0x000E2AA8
	[Token(Token = "0x6002722")]
	[Address(RVA = "0x2E3A71C", Offset = "0x2E3A71C", VA = "0x2E3A71C")]
	private void Update()
	{
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x06002723 RID: 10019 RVA: 0x000E48FC File Offset: 0x000E2AFC
	[Token(Token = "0x6002723")]
	[Address(RVA = "0x2E3A7FC", Offset = "0x2E3A7FC", VA = "0x2E3A7FC")]
	public void ݘ\u060FكՔ()
	{
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
	}

	// Token: 0x06002724 RID: 10020 RVA: 0x000E4914 File Offset: 0x000E2B14
	[Token(Token = "0x6002724")]
	[Address(RVA = "0x2E3A808", Offset = "0x2E3A808", VA = "0x2E3A808")]
	private void ى߁ٱՏ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x06002725 RID: 10021 RVA: 0x000E496C File Offset: 0x000E2B6C
	[Token(Token = "0x6002725")]
	[Address(RVA = "0x2E3A8E8", Offset = "0x2E3A8E8", VA = "0x2E3A8E8")]
	private void ݫࢷࠃ\u0820()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
	}

	// Token: 0x06002726 RID: 10022 RVA: 0x000E49B0 File Offset: 0x000E2BB0
	[Token(Token = "0x6002726")]
	[Address(RVA = "0x2E3A9B4", Offset = "0x2E3A9B4", VA = "0x2E3A9B4")]
	public void \u089F\u0873ԇ\u0558()
	{
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
	}

	// Token: 0x06002727 RID: 10023 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002727")]
	[Address(RVA = "0x2E3A9C0", Offset = "0x2E3A9C0", VA = "0x2E3A9C0")]
	public void \u064Dۿ\u07BB\u05C0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002728 RID: 10024 RVA: 0x000E49C8 File Offset: 0x000E2BC8
	[Token(Token = "0x6002728")]
	[Address(RVA = "0x2E3AA80", Offset = "0x2E3AA80", VA = "0x2E3AA80")]
	private void ժ\u065Dԯࡘ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x06002729 RID: 10025 RVA: 0x000E4A20 File Offset: 0x000E2C20
	[Token(Token = "0x6002729")]
	[Address(RVA = "0x2E3AB60", Offset = "0x2E3AB60", VA = "0x2E3AB60")]
	private void ࢭ\u0589\u0892\u058A()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x0600272A RID: 10026 RVA: 0x000E4A78 File Offset: 0x000E2C78
	[Token(Token = "0x600272A")]
	[Address(RVA = "0x2E3AC40", Offset = "0x2E3AC40", VA = "0x2E3AC40")]
	private void \u07B6կպ߃()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x0600272B RID: 10027 RVA: 0x000E4AD0 File Offset: 0x000E2CD0
	[Token(Token = "0x600272B")]
	[Address(RVA = "0x2E3AD20", Offset = "0x2E3AD20", VA = "0x2E3AD20")]
	private void ԅ\u073Fڥ\u0839()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 1L;
		ߧܧ٧_u.SetActive(active2 != 0L);
	}

	// Token: 0x0600272C RID: 10028 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600272C")]
	[Address(RVA = "0x2E3ADD4", Offset = "0x2E3ADD4", VA = "0x2E3ADD4")]
	public void \u0747ݦޖݔ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600272D RID: 10029 RVA: 0x000E4B08 File Offset: 0x000E2D08
	[Token(Token = "0x600272D")]
	[Address(RVA = "0x2E3AE88", Offset = "0x2E3AE88", VA = "0x2E3AE88")]
	private void ڃրӢԖ()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		long active = 1L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
		long active2 = 0L;
		ߧܧ٧_u.SetActive(active2 != 0L);
	}

	// Token: 0x0600272E RID: 10030 RVA: 0x000E4B40 File Offset: 0x000E2D40
	[Token(Token = "0x600272E")]
	[Address(RVA = "0x2E3AF3C", Offset = "0x2E3AF3C", VA = "0x2E3AF3C")]
	public void ߃ԏԢۺ()
	{
		long ߅Ӭ_u07AFդ = 1L;
		this.߅Ӭ\u07AFդ = (߅Ӭ_u07AFդ != 0L);
	}

	// Token: 0x0600272F RID: 10031 RVA: 0x000E4B58 File Offset: 0x000E2D58
	[Token(Token = "0x600272F")]
	[Address(RVA = "0x2E3AF48", Offset = "0x2E3AF48", VA = "0x2E3AF48")]
	private void ӻӒݝ߃()
	{
		if (!true)
		{
		}
		GameObject u05FA_u081Fޥࠕ = this.\u05FA\u081Fޥࠕ;
		bool ߅Ӭ_u07AFդ = this.߅Ӭ\u07AFդ;
		long active = 0L;
		u05FA_u081Fޥࠕ.SetActive(active != 0L);
		GameObject ߧܧ٧_u = this.ߧܧ٧\u0704;
	}

	// Token: 0x040004ED RID: 1261
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004ED")]
	public GameObject \u05FA\u081Fޥࠕ;

	// Token: 0x040004EE RID: 1262
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004EE")]
	public GameObject ߧܧ٧\u0704;

	// Token: 0x040004EF RID: 1263
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40004EF")]
	private InputDevice ڵ\u05A3\u0894ࠑ;

	// Token: 0x040004F0 RID: 1264
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40004F0")]
	public bool ߅Ӭ\u07AFդ;
}
