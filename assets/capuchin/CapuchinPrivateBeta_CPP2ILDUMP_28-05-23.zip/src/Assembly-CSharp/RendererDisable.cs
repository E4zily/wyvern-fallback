﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200001A RID: 26
[Token(Token = "0x200001A")]
public class RendererDisable : MonoBehaviour
{
	// Token: 0x06000368 RID: 872 RVA: 0x000155C8 File Offset: 0x000137C8
	[Token(Token = "0x6000368")]
	[Address(RVA = "0x2FA63FC", Offset = "0x2FA63FC", VA = "0x2FA63FC")]
	private void ժ\u065Dԯࡘ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000369 RID: 873 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000369")]
	[Address(RVA = "0x2FA65F0", Offset = "0x2FA65F0", VA = "0x2FA65F0")]
	private void ފՖߢ\u059B()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600036A RID: 874 RVA: 0x0001565C File Offset: 0x0001385C
	[Token(Token = "0x600036A")]
	[Address(RVA = "0x2FA6774", Offset = "0x2FA6774", VA = "0x2FA6774")]
	private void \u0732ڙԒࢺ()
	{
		if (!this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			bool u065D_u06D8_u05C1ࠐ;
			this.\u065D\u06D8\u05C1ࠐ = u065D_u06D8_u05C1ࠐ;
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.\u065D\u06D8\u05C1ࠐ)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		long enabled2 = 0L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		BoxCollider[] componentsInChildren3 = base.GetComponentsInChildren<BoxCollider>();
	}

	// Token: 0x0600036B RID: 875 RVA: 0x000156F4 File Offset: 0x000138F4
	[Token(Token = "0x600036B")]
	[Address(RVA = "0x2FA6964", Offset = "0x2FA6964", VA = "0x2FA6964")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			long enabled = 0L;
			componentsInChildren.enabled = (enabled != 0L);
			CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
			return;
		}
		int u065D_u06D8_u05C1ࠐ = 257;
		this.\u065D\u06D8\u05C1ࠐ = (u065D_u06D8_u05C1ࠐ != 0);
	}

	// Token: 0x0600036C RID: 876 RVA: 0x00015784 File Offset: 0x00013984
	[Token(Token = "0x600036C")]
	[Address(RVA = "0x2FA6B44", Offset = "0x2FA6B44", VA = "0x2FA6B44")]
	private void ԟ\u086Cޣ\u055E()
	{
		if (!this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.\u065D\u06D8\u05C1ࠐ)
		{
			return;
		}
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
	}

	// Token: 0x0600036D RID: 877 RVA: 0x0001581C File Offset: 0x00013A1C
	[Token(Token = "0x600036D")]
	[Address(RVA = "0x2FA6D60", Offset = "0x2FA6D60", VA = "0x2FA6D60")]
	private void ӻӒݝ߃()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x0600036E RID: 878 RVA: 0x000158AC File Offset: 0x00013AAC
	[Token(Token = "0x600036E")]
	[Address(RVA = "0x2FA6F34", Offset = "0x2FA6F34", VA = "0x2FA6F34")]
	private void \u070Aәޣے()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x0600036F RID: 879 RVA: 0x00015938 File Offset: 0x00013B38
	[Token(Token = "0x600036F")]
	[Address(RVA = "0x2FA7100", Offset = "0x2FA7100", VA = "0x2FA7100")]
	private void Update()
	{
		if (!this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			int u065D_u06D8_u05C1ࠐ = 257;
			long ӭ_u0890_u0747ࡔ = 1L;
			this.\u065D\u06D8\u05C1ࠐ = (u065D_u06D8_u05C1ࠐ != 0);
			this.Ӭ\u0890\u0747ࡔ = (ӭ_u0890_u0747ࡔ != 0L);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.\u065D\u06D8\u05C1ࠐ)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.հ\u0885٢տ)
		{
			return;
		}
		long enabled2 = 0L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		BoxCollider[] componentsInChildren3 = base.GetComponentsInChildren<BoxCollider>();
		if (this.Է\u0743\u083Dڝ)
		{
			return;
		}
		long enabled3 = 0L;
		componentsInChildren3.enabled = (enabled3 != 0L);
		SphereCollider[] componentsInChildren4 = base.GetComponentsInChildren<SphereCollider>();
		if (this.Ӭ\u0890\u0747ࡔ)
		{
			return;
		}
		long enabled4 = 0L;
		componentsInChildren4.enabled = (enabled4 != 0L);
	}

	// Token: 0x06000370 RID: 880 RVA: 0x000159F8 File Offset: 0x00013BF8
	[Token(Token = "0x6000370")]
	[Address(RVA = "0x2FA734C", Offset = "0x2FA734C", VA = "0x2FA734C")]
	private void \u05F7ԝߠӱ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
		long u065D_u06D8_u05C1ࠐ = 256L;
		long ӭ_u0890_u0747ࡔ = 1L;
		this.\u065D\u06D8\u05C1ࠐ = (u065D_u06D8_u05C1ࠐ != 0L);
		this.Ӭ\u0890\u0747ࡔ = (ӭ_u0890_u0747ࡔ != 0L);
	}

	// Token: 0x06000371 RID: 881 RVA: 0x00015A98 File Offset: 0x00013C98
	[Token(Token = "0x6000371")]
	[Address(RVA = "0x2FA7524", Offset = "0x2FA7524", VA = "0x2FA7524")]
	private void ٴݵۃ\u05AF()
	{
		if (true)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			long enabled = 0L;
			componentsInChildren.enabled = (enabled != 0L);
			CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
			return;
		}
	}

	// Token: 0x06000372 RID: 882 RVA: 0x00015B1C File Offset: 0x00013D1C
	[Token(Token = "0x6000372")]
	[Address(RVA = "0x2FA7714", Offset = "0x2FA7714", VA = "0x2FA7714")]
	private void \u087BӦןݩ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
		long u065D_u06D8_u05C1ࠐ = 256L;
		this.\u065D\u06D8\u05C1ࠐ = (u065D_u06D8_u05C1ࠐ != 0L);
	}

	// Token: 0x06000373 RID: 883 RVA: 0x00015BB4 File Offset: 0x00013DB4
	[Token(Token = "0x6000373")]
	[Address(RVA = "0x2FA78E8", Offset = "0x2FA78E8", VA = "0x2FA78E8")]
	private void Ҽ\u08B5ځ\u0658()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000374 RID: 884 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000374")]
	[Address(RVA = "0x2FA7AC8", Offset = "0x2FA7AC8", VA = "0x2FA7AC8")]
	private void \u05EDց\u081Cت()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000375 RID: 885 RVA: 0x00015C44 File Offset: 0x00013E44
	[Token(Token = "0x6000375")]
	[Address(RVA = "0x2FA7CAC", Offset = "0x2FA7CAC", VA = "0x2FA7CAC")]
	private void \u0881ݗӟ\u07BD()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
		this.\u065D\u06D8\u05C1ࠐ = (257 != 0);
	}

	// Token: 0x06000376 RID: 886 RVA: 0x00015CE0 File Offset: 0x00013EE0
	[Token(Token = "0x6000376")]
	[Address(RVA = "0x2FA7E70", Offset = "0x2FA7E70", VA = "0x2FA7E70")]
	private void ڑߒجވ()
	{
		if (!this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			long num = 1L;
			this.\u065D\u06D8\u05C1ࠐ = (num != 0L);
			this.Ӭ\u0890\u0747ࡔ = (num != 0L);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.\u065D\u06D8\u05C1ࠐ)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
	}

	// Token: 0x06000377 RID: 887 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000377")]
	[Address(RVA = "0x2FA808C", Offset = "0x2FA808C", VA = "0x2FA808C")]
	private void ԣԭՋࠏ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000378 RID: 888 RVA: 0x00015D88 File Offset: 0x00013F88
	[Token(Token = "0x6000378")]
	[Address(RVA = "0x2FA82B4", Offset = "0x2FA82B4", VA = "0x2FA82B4")]
	public RendererDisable()
	{
	}

	// Token: 0x06000379 RID: 889 RVA: 0x00015D9C File Offset: 0x00013F9C
	[Token(Token = "0x6000379")]
	[Address(RVA = "0x2FA82BC", Offset = "0x2FA82BC", VA = "0x2FA82BC")]
	private void Ӣ\u0592ߨׯ()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x0600037A RID: 890 RVA: 0x00015E2C File Offset: 0x0001402C
	[Token(Token = "0x600037A")]
	[Address(RVA = "0x2FA84BC", Offset = "0x2FA84BC", VA = "0x2FA84BC")]
	private void Ҿࢹؼס()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			long enabled = 1L;
			componentsInChildren.enabled = (enabled != 0L);
			CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
			long enabled2 = 1L;
			componentsInChildren2.enabled = (enabled2 != 0L);
			BoxCollider[] componentsInChildren3 = base.GetComponentsInChildren<BoxCollider>();
			return;
		}
		long u065D_u06D8_u05C1ࠐ = 256L;
		long ӭ_u0890_u0747ࡔ = 1L;
		this.\u065D\u06D8\u05C1ࠐ = (u065D_u06D8_u05C1ࠐ != 0L);
		this.Ӭ\u0890\u0747ࡔ = (ӭ_u0890_u0747ࡔ != 0L);
	}

	// Token: 0x0600037B RID: 891 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600037B")]
	[Address(RVA = "0x2FA86B0", Offset = "0x2FA86B0", VA = "0x2FA86B0")]
	private void \u0654ޛ\u07FAذ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600037C RID: 892 RVA: 0x00015ED0 File Offset: 0x000140D0
	[Token(Token = "0x600037C")]
	[Address(RVA = "0x2FA88A4", Offset = "0x2FA88A4", VA = "0x2FA88A4")]
	private void ւࡂ\u0883\u0872()
	{
		if (!this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.\u065D\u06D8\u05C1ࠐ)
		{
			return;
		}
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
	}

	// Token: 0x0600037D RID: 893 RVA: 0x00015F60 File Offset: 0x00014160
	[Token(Token = "0x600037D")]
	[Address(RVA = "0x2FA8A78", Offset = "0x2FA8A78", VA = "0x2FA8A78")]
	private void څࡣڐ\u0657()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x0600037E RID: 894 RVA: 0x00015FD8 File Offset: 0x000141D8
	[Token(Token = "0x600037E")]
	[Address(RVA = "0x2FA8C34", Offset = "0x2FA8C34", VA = "0x2FA8C34")]
	private void ں٢ࡡ\u05EC()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x0600037F RID: 895 RVA: 0x00016060 File Offset: 0x00014260
	[Token(Token = "0x600037F")]
	[Address(RVA = "0x2FA8DFC", Offset = "0x2FA8DFC", VA = "0x2FA8DFC")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000380 RID: 896 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000380")]
	[Address(RVA = "0x2FA8FEC", Offset = "0x2FA8FEC", VA = "0x2FA8FEC")]
	private void \u061B\u05EEوۈ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000381 RID: 897 RVA: 0x000160F0 File Offset: 0x000142F0
	[Token(Token = "0x6000381")]
	[Address(RVA = "0x2FA91BC", Offset = "0x2FA91BC", VA = "0x2FA91BC")]
	private void ڃրӢԖ()
	{
		if (!this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			long ӭ_u0890_u0747ࡔ = 1L;
			this.Ӭ\u0890\u0747ࡔ = (ӭ_u0890_u0747ࡔ != 0L);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.\u065D\u06D8\u05C1ࠐ)
		{
			return;
		}
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.հ\u0885٢տ)
		{
			return;
		}
		long enabled2 = 0L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		BoxCollider[] componentsInChildren3 = base.GetComponentsInChildren<BoxCollider>();
		SphereCollider[] componentsInChildren4 = base.GetComponentsInChildren<SphereCollider>();
	}

	// Token: 0x06000382 RID: 898 RVA: 0x00016184 File Offset: 0x00014384
	[Token(Token = "0x6000382")]
	[Address(RVA = "0x2FA93D8", Offset = "0x2FA93D8", VA = "0x2FA93D8")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		if (this.ޣߑԤࡩ.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			return;
		}
		long num = 1L;
		this.\u065D\u06D8\u05C1ࠐ = (num != 0L);
		this.Ӭ\u0890\u0747ࡔ = (num != 0L);
	}

	// Token: 0x0400006C RID: 108
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400006C")]
	public PhotonView ޣߑԤࡩ;

	// Token: 0x0400006D RID: 109
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400006D")]
	public bool \u065D\u06D8\u05C1ࠐ;

	// Token: 0x0400006E RID: 110
	[FieldOffset(Offset = "0x21")]
	[Token(Token = "0x400006E")]
	public bool հ\u0885٢տ;

	// Token: 0x0400006F RID: 111
	[FieldOffset(Offset = "0x22")]
	[Token(Token = "0x400006F")]
	public bool Է\u0743\u083Dڝ;

	// Token: 0x04000070 RID: 112
	[FieldOffset(Offset = "0x23")]
	[Token(Token = "0x4000070")]
	public bool Ӭ\u0890\u0747ࡔ;
}
