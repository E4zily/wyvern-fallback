﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000A3 RID: 163
[Token(Token = "0x20000A3")]
public class ChangeToLava : MonoBehaviour
{
	// Token: 0x060017E4 RID: 6116 RVA: 0x000847B4 File Offset: 0x000829B4
	[Token(Token = "0x60017E4")]
	[Address(RVA = "0x2941074", Offset = "0x2941074", VA = "0x2941074")]
	public void ԏ\u0820߇\u0557()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017E5 RID: 6117 RVA: 0x000847EC File Offset: 0x000829EC
	[Token(Token = "0x60017E5")]
	[Address(RVA = "0x29410B4", Offset = "0x29410B4", VA = "0x29410B4")]
	public void ߖۋܩކ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017E6 RID: 6118 RVA: 0x00084824 File Offset: 0x00082A24
	[Token(Token = "0x60017E6")]
	[Address(RVA = "0x29410F4", Offset = "0x29410F4", VA = "0x29410F4")]
	public void \u0592٩ٳࡕ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017E7 RID: 6119 RVA: 0x0008485C File Offset: 0x00082A5C
	[Token(Token = "0x60017E7")]
	[Address(RVA = "0x2941134", Offset = "0x2941134", VA = "0x2941134")]
	public void ߀ԆבӸ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017E8 RID: 6120 RVA: 0x00084894 File Offset: 0x00082A94
	[Token(Token = "0x60017E8")]
	[Address(RVA = "0x2941174", Offset = "0x2941174", VA = "0x2941174")]
	public void ܥ\u07FBՕۊ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
	}

	// Token: 0x060017E9 RID: 6121 RVA: 0x000848B8 File Offset: 0x00082AB8
	[Token(Token = "0x60017E9")]
	[Address(RVA = "0x29411B4", Offset = "0x29411B4", VA = "0x29411B4")]
	public void ۼӽ\u0820\u0895()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017EA RID: 6122 RVA: 0x000848F0 File Offset: 0x00082AF0
	[Token(Token = "0x60017EA")]
	[Address(RVA = "0x29411F4", Offset = "0x29411F4", VA = "0x29411F4")]
	public void \u05AA\u0741\u0836\u0833()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017EB RID: 6123 RVA: 0x00084928 File Offset: 0x00082B28
	[Token(Token = "0x60017EB")]
	[Address(RVA = "0x2941234", Offset = "0x2941234", VA = "0x2941234")]
	public void իט\u088E\u070A()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017EC RID: 6124 RVA: 0x00084960 File Offset: 0x00082B60
	[Token(Token = "0x60017EC")]
	[Address(RVA = "0x2941274", Offset = "0x2941274", VA = "0x2941274")]
	public void صޓߗ\u087D()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017ED RID: 6125 RVA: 0x00084998 File Offset: 0x00082B98
	[Token(Token = "0x60017ED")]
	[Address(RVA = "0x29412B4", Offset = "0x29412B4", VA = "0x29412B4")]
	public void \u0654\u0655Տ\u07F8()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017EE RID: 6126 RVA: 0x000849D0 File Offset: 0x00082BD0
	[Token(Token = "0x60017EE")]
	[Address(RVA = "0x29412F4", Offset = "0x29412F4", VA = "0x29412F4")]
	public void Ա\u089C\u0600\u07F0()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017EF RID: 6127 RVA: 0x00084A08 File Offset: 0x00082C08
	[Token(Token = "0x60017EF")]
	[Address(RVA = "0x2941334", Offset = "0x2941334", VA = "0x2941334")]
	public void տסא\u0590()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017F0 RID: 6128 RVA: 0x00084A40 File Offset: 0x00082C40
	[Token(Token = "0x60017F0")]
	[Address(RVA = "0x2941374", Offset = "0x2941374", VA = "0x2941374")]
	public void \u07F1߃ڝۅ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
	}

	// Token: 0x060017F1 RID: 6129 RVA: 0x00084A70 File Offset: 0x00082C70
	[Token(Token = "0x60017F1")]
	[Address(RVA = "0x29413B4", Offset = "0x29413B4", VA = "0x29413B4")]
	public void ֆ\u07FD\u086D\u089E()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
	}

	// Token: 0x060017F2 RID: 6130 RVA: 0x00084AA0 File Offset: 0x00082CA0
	[Token(Token = "0x60017F2")]
	[Address(RVA = "0x29413F4", Offset = "0x29413F4", VA = "0x29413F4")]
	public void \u066A\u0740٥د()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017F3 RID: 6131 RVA: 0x00084AD8 File Offset: 0x00082CD8
	[Token(Token = "0x60017F3")]
	[Address(RVA = "0x2941434", Offset = "0x2941434", VA = "0x2941434")]
	public void ԣ\u083A\u087Dӿ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017F4 RID: 6132 RVA: 0x00084B10 File Offset: 0x00082D10
	[Token(Token = "0x60017F4")]
	[Address(RVA = "0x2941474", Offset = "0x2941474", VA = "0x2941474")]
	public void ݒ\u05ACթࠋ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
	}

	// Token: 0x060017F5 RID: 6133 RVA: 0x00084B38 File Offset: 0x00082D38
	[Token(Token = "0x60017F5")]
	[Address(RVA = "0x29414B4", Offset = "0x29414B4", VA = "0x29414B4")]
	public void փޕןՔ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017F6 RID: 6134 RVA: 0x00084B70 File Offset: 0x00082D70
	[Token(Token = "0x60017F6")]
	[Address(RVA = "0x29414F4", Offset = "0x29414F4", VA = "0x29414F4")]
	public void ڀ\u0738\u07F4ԃ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017F7 RID: 6135 RVA: 0x00084BA8 File Offset: 0x00082DA8
	[Token(Token = "0x60017F7")]
	[Address(RVA = "0x2941534", Offset = "0x2941534", VA = "0x2941534")]
	public void ԕԇڡز()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017F8 RID: 6136 RVA: 0x00084BE0 File Offset: 0x00082DE0
	[Token(Token = "0x60017F8")]
	[Address(RVA = "0x2941574", Offset = "0x2941574", VA = "0x2941574")]
	public void \u0884ի\u086F\u05FC()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017F9 RID: 6137 RVA: 0x00084C18 File Offset: 0x00082E18
	[Token(Token = "0x60017F9")]
	[Address(RVA = "0x29415B4", Offset = "0x29415B4", VA = "0x29415B4")]
	public void Պ\u0609٣\u06E6()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017FA RID: 6138 RVA: 0x00084C50 File Offset: 0x00082E50
	[Token(Token = "0x60017FA")]
	[Address(RVA = "0x29415F4", Offset = "0x29415F4", VA = "0x29415F4")]
	public void ࠔߋ\u05A4ࢺ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017FB RID: 6139 RVA: 0x00084C88 File Offset: 0x00082E88
	[Token(Token = "0x60017FB")]
	[Address(RVA = "0x2941634", Offset = "0x2941634", VA = "0x2941634")]
	public void \u089Eܨ\u0657\u0600()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017FC RID: 6140 RVA: 0x00084CC0 File Offset: 0x00082EC0
	[Token(Token = "0x60017FC")]
	[Address(RVA = "0x2941674", Offset = "0x2941674", VA = "0x2941674")]
	public void \u0874\u07ACݳޜ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x060017FD RID: 6141 RVA: 0x00084CF8 File Offset: 0x00082EF8
	[Token(Token = "0x60017FD")]
	[Address(RVA = "0x29416B4", Offset = "0x29416B4", VA = "0x29416B4")]
	public void ט\u05B9ࠊݦ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
	}

	// Token: 0x060017FE RID: 6142 RVA: 0x00084D28 File Offset: 0x00082F28
	[Token(Token = "0x60017FE")]
	[Address(RVA = "0x29416F4", Offset = "0x29416F4", VA = "0x29416F4")]
	public void \u0878Ԉըޣ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x060017FF RID: 6143 RVA: 0x00084D60 File Offset: 0x00082F60
	[Token(Token = "0x60017FF")]
	[Address(RVA = "0x2941734", Offset = "0x2941734", VA = "0x2941734")]
	public void \u07B8תފ\u07BA()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001800 RID: 6144 RVA: 0x00084D98 File Offset: 0x00082F98
	[Token(Token = "0x6001800")]
	[Address(RVA = "0x2941774", Offset = "0x2941774", VA = "0x2941774")]
	public void Ӂ\u07EEڍࡣ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001801 RID: 6145 RVA: 0x00084DD0 File Offset: 0x00082FD0
	[Token(Token = "0x6001801")]
	[Address(RVA = "0x29417B4", Offset = "0x29417B4", VA = "0x29417B4")]
	public void ףӜܙڦ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001802 RID: 6146 RVA: 0x00084E08 File Offset: 0x00083008
	[Token(Token = "0x6001802")]
	[Address(RVA = "0x29417F4", Offset = "0x29417F4", VA = "0x29417F4")]
	public void \u07B5ࢫ\u0659ޞ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001803 RID: 6147 RVA: 0x00084E40 File Offset: 0x00083040
	[Token(Token = "0x6001803")]
	[Address(RVA = "0x2941834", Offset = "0x2941834", VA = "0x2941834")]
	public void ՒࢲӨ\u0734()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001804 RID: 6148 RVA: 0x00084E78 File Offset: 0x00083078
	[Token(Token = "0x6001804")]
	[Address(RVA = "0x2941874", Offset = "0x2941874", VA = "0x2941874")]
	public void \u0594ࢠչٷ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001805 RID: 6149 RVA: 0x00084EB0 File Offset: 0x000830B0
	[Token(Token = "0x6001805")]
	[Address(RVA = "0x29418B4", Offset = "0x29418B4", VA = "0x29418B4")]
	public void Ӈࠆ\u083Bڗ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001806 RID: 6150 RVA: 0x00084EE8 File Offset: 0x000830E8
	[Token(Token = "0x6001806")]
	[Address(RVA = "0x29418F4", Offset = "0x29418F4", VA = "0x29418F4")]
	public void \u083Dڷ\u0711\u059B()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001807 RID: 6151 RVA: 0x00084F20 File Offset: 0x00083120
	[Token(Token = "0x6001807")]
	[Address(RVA = "0x2941934", Offset = "0x2941934", VA = "0x2941934")]
	public void ࡘوӽك()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001808 RID: 6152 RVA: 0x00084F58 File Offset: 0x00083158
	[Token(Token = "0x6001808")]
	[Address(RVA = "0x2941974", Offset = "0x2941974", VA = "0x2941974")]
	public void ڴӡ\u05A4\u0745()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001809 RID: 6153 RVA: 0x00084F90 File Offset: 0x00083190
	[Token(Token = "0x6001809")]
	[Address(RVA = "0x29419B4", Offset = "0x29419B4", VA = "0x29419B4")]
	public void գӓݢࡧ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600180A RID: 6154 RVA: 0x00084FC8 File Offset: 0x000831C8
	[Token(Token = "0x600180A")]
	[Address(RVA = "0x29419F4", Offset = "0x29419F4", VA = "0x29419F4")]
	public void \u0893ࡘڒٳ()
	{
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600180B RID: 6155 RVA: 0x00084FF8 File Offset: 0x000831F8
	[Token(Token = "0x600180B")]
	[Address(RVA = "0x2941A34", Offset = "0x2941A34", VA = "0x2941A34")]
	public void \u0593ݚ\u0830\u05F6()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600180C RID: 6156 RVA: 0x00085030 File Offset: 0x00083230
	[Token(Token = "0x600180C")]
	[Address(RVA = "0x2941A74", Offset = "0x2941A74", VA = "0x2941A74")]
	public void ܖڝܐ\u06E8()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x0600180D RID: 6157 RVA: 0x00085068 File Offset: 0x00083268
	[Token(Token = "0x600180D")]
	[Address(RVA = "0x2941AB4", Offset = "0x2941AB4", VA = "0x2941AB4")]
	public void \u058B٨ݎӎ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600180E RID: 6158 RVA: 0x000850A0 File Offset: 0x000832A0
	[Token(Token = "0x600180E")]
	[Address(RVA = "0x2941AF4", Offset = "0x2941AF4", VA = "0x2941AF4")]
	public void ի\u0530ٶ\u0606()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600180F RID: 6159 RVA: 0x000850D8 File Offset: 0x000832D8
	[Token(Token = "0x600180F")]
	[Address(RVA = "0x2941B34", Offset = "0x2941B34", VA = "0x2941B34")]
	public void ࡘ\u05AD\u07F1Ԥ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001810 RID: 6160 RVA: 0x00085110 File Offset: 0x00083310
	[Token(Token = "0x6001810")]
	[Address(RVA = "0x2941B74", Offset = "0x2941B74", VA = "0x2941B74")]
	public void \u05C7ڀ\u070Aդ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001811 RID: 6161 RVA: 0x00085148 File Offset: 0x00083348
	[Token(Token = "0x6001811")]
	[Address(RVA = "0x2941BB4", Offset = "0x2941BB4", VA = "0x2941BB4")]
	public void ڰ\u060B߉ݘ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001812 RID: 6162 RVA: 0x00085180 File Offset: 0x00083380
	[Token(Token = "0x6001812")]
	[Address(RVA = "0x2941BF4", Offset = "0x2941BF4", VA = "0x2941BF4")]
	public void \u070B\u0606\u060Dߛ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001813 RID: 6163 RVA: 0x000851B8 File Offset: 0x000833B8
	[Token(Token = "0x6001813")]
	[Address(RVA = "0x2941C34", Offset = "0x2941C34", VA = "0x2941C34")]
	public void ࢯ\u05CEހ\u06D9()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001814 RID: 6164 RVA: 0x000851F0 File Offset: 0x000833F0
	[Token(Token = "0x6001814")]
	[Address(RVA = "0x2941C74", Offset = "0x2941C74", VA = "0x2941C74")]
	public ChangeToLava()
	{
	}

	// Token: 0x06001815 RID: 6165 RVA: 0x00085204 File Offset: 0x00083404
	[Token(Token = "0x6001815")]
	[Address(RVA = "0x2941C7C", Offset = "0x2941C7C", VA = "0x2941C7C")]
	public void ࢰև\u07A7ӏ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001816 RID: 6166 RVA: 0x0008523C File Offset: 0x0008343C
	[Token(Token = "0x6001816")]
	[Address(RVA = "0x2941CBC", Offset = "0x2941CBC", VA = "0x2941CBC")]
	public void ۵ܖپޒ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001817 RID: 6167 RVA: 0x00085274 File Offset: 0x00083474
	[Token(Token = "0x6001817")]
	[Address(RVA = "0x2941CFC", Offset = "0x2941CFC", VA = "0x2941CFC")]
	public void ڭԢ߉ڗ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001818 RID: 6168 RVA: 0x000852AC File Offset: 0x000834AC
	[Token(Token = "0x6001818")]
	[Address(RVA = "0x2941D3C", Offset = "0x2941D3C", VA = "0x2941D3C")]
	public void ߏ\u0827\u0739զ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001819 RID: 6169 RVA: 0x000852E4 File Offset: 0x000834E4
	[Token(Token = "0x6001819")]
	[Address(RVA = "0x2941D7C", Offset = "0x2941D7C", VA = "0x2941D7C")]
	public void \u07BCԮޝߦ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600181A RID: 6170 RVA: 0x0008531C File Offset: 0x0008351C
	[Token(Token = "0x600181A")]
	[Address(RVA = "0x2941DBC", Offset = "0x2941DBC", VA = "0x2941DBC")]
	public void آ\u089F\u0607ߑ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x0600181B RID: 6171 RVA: 0x00085354 File Offset: 0x00083554
	[Token(Token = "0x600181B")]
	[Address(RVA = "0x2941DFC", Offset = "0x2941DFC", VA = "0x2941DFC")]
	public void זࡀԌڬ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600181C RID: 6172 RVA: 0x0008538C File Offset: 0x0008358C
	[Token(Token = "0x600181C")]
	[Address(RVA = "0x2941E3C", Offset = "0x2941E3C", VA = "0x2941E3C")]
	public void ӎإ\u0654\u0655()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600181D RID: 6173 RVA: 0x000853C4 File Offset: 0x000835C4
	[Token(Token = "0x600181D")]
	[Address(RVA = "0x2941E7C", Offset = "0x2941E7C", VA = "0x2941E7C")]
	public void Ղ\u0600ف\u0589()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600181E RID: 6174 RVA: 0x000853FC File Offset: 0x000835FC
	[Token(Token = "0x600181E")]
	[Address(RVA = "0x2941EBC", Offset = "0x2941EBC", VA = "0x2941EBC")]
	public void ܠࢩ\u0872و()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600181F RID: 6175 RVA: 0x00085434 File Offset: 0x00083634
	[Token(Token = "0x600181F")]
	[Address(RVA = "0x2941EFC", Offset = "0x2941EFC", VA = "0x2941EFC")]
	public void أӘࡆ\u07B4()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001820 RID: 6176 RVA: 0x0008546C File Offset: 0x0008366C
	[Token(Token = "0x6001820")]
	[Address(RVA = "0x2941F3C", Offset = "0x2941F3C", VA = "0x2941F3C")]
	[PunRPC]
	public void ChangeMaterialToLava()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001821 RID: 6177 RVA: 0x000854A4 File Offset: 0x000836A4
	[Token(Token = "0x6001821")]
	[Address(RVA = "0x2941F7C", Offset = "0x2941F7C", VA = "0x2941F7C")]
	public void \u07FBבڷ\u0832()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001822 RID: 6178 RVA: 0x000854DC File Offset: 0x000836DC
	[Token(Token = "0x6001822")]
	[Address(RVA = "0x2941FBC", Offset = "0x2941FBC", VA = "0x2941FBC")]
	public void \u070AקՀ\u059A()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001823 RID: 6179 RVA: 0x00085514 File Offset: 0x00083714
	[Token(Token = "0x6001823")]
	[Address(RVA = "0x2941FFC", Offset = "0x2941FFC", VA = "0x2941FFC")]
	public void ܠٷێ\u05BC()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001824 RID: 6180 RVA: 0x0008554C File Offset: 0x0008374C
	[Token(Token = "0x6001824")]
	[Address(RVA = "0x294203C", Offset = "0x294203C", VA = "0x294203C")]
	public void Ԥࡑࢨ\u06EC()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001825 RID: 6181 RVA: 0x00085584 File Offset: 0x00083784
	[Token(Token = "0x6001825")]
	[Address(RVA = "0x294207C", Offset = "0x294207C", VA = "0x294207C")]
	public void \u0702ט\u0734\u074A()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001826 RID: 6182 RVA: 0x000855BC File Offset: 0x000837BC
	[Token(Token = "0x6001826")]
	[Address(RVA = "0x29420BC", Offset = "0x29420BC", VA = "0x29420BC")]
	public void صߜࡀ\u0828()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001827 RID: 6183 RVA: 0x000855F4 File Offset: 0x000837F4
	[Token(Token = "0x6001827")]
	[Address(RVA = "0x29420FC", Offset = "0x29420FC", VA = "0x29420FC")]
	public void Ӈӷܯڀ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001828 RID: 6184 RVA: 0x0008562C File Offset: 0x0008382C
	[Token(Token = "0x6001828")]
	[Address(RVA = "0x294213C", Offset = "0x294213C", VA = "0x294213C")]
	public void \u05F5خ٣ݥ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001829 RID: 6185 RVA: 0x00085664 File Offset: 0x00083864
	[Token(Token = "0x6001829")]
	[Address(RVA = "0x294217C", Offset = "0x294217C", VA = "0x294217C")]
	public void ݵԣԼݥ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600182A RID: 6186 RVA: 0x0008569C File Offset: 0x0008389C
	[Token(Token = "0x600182A")]
	[Address(RVA = "0x29421BC", Offset = "0x29421BC", VA = "0x29421BC")]
	public void ظөڂ\u083A()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600182B RID: 6187 RVA: 0x000856D4 File Offset: 0x000838D4
	[Token(Token = "0x600182B")]
	[Address(RVA = "0x29421FC", Offset = "0x29421FC", VA = "0x29421FC")]
	public void ل\u065Bցة()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x0600182C RID: 6188 RVA: 0x0008570C File Offset: 0x0008390C
	[Token(Token = "0x600182C")]
	[Address(RVA = "0x294223C", Offset = "0x294223C", VA = "0x294223C")]
	public void \u05A3ԗ\u05EE\u0830()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600182D RID: 6189 RVA: 0x00085744 File Offset: 0x00083944
	[Token(Token = "0x600182D")]
	[Address(RVA = "0x294227C", Offset = "0x294227C", VA = "0x294227C")]
	public void Պ߃ࢤވ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x0600182E RID: 6190 RVA: 0x0008577C File Offset: 0x0008397C
	[Token(Token = "0x600182E")]
	[Address(RVA = "0x29422BC", Offset = "0x29422BC", VA = "0x29422BC")]
	public void լ\u05A5\u0654ݮ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600182F RID: 6191 RVA: 0x000857B4 File Offset: 0x000839B4
	[Token(Token = "0x600182F")]
	[Address(RVA = "0x29422FC", Offset = "0x29422FC", VA = "0x29422FC")]
	public void \u05BDࡌ\u0891Ә()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001830 RID: 6192 RVA: 0x000857EC File Offset: 0x000839EC
	[Token(Token = "0x6001830")]
	[Address(RVA = "0x294233C", Offset = "0x294233C", VA = "0x294233C")]
	public void ېڌڗ\u05A4()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001831 RID: 6193 RVA: 0x00085824 File Offset: 0x00083A24
	[Token(Token = "0x6001831")]
	[Address(RVA = "0x294237C", Offset = "0x294237C", VA = "0x294237C")]
	public void ګӖӚ\u0605()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001832 RID: 6194 RVA: 0x0008585C File Offset: 0x00083A5C
	[Token(Token = "0x6001832")]
	[Address(RVA = "0x29423BC", Offset = "0x29423BC", VA = "0x29423BC")]
	public void \u070EՏ\u06E7\u06E5()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001833 RID: 6195 RVA: 0x00085894 File Offset: 0x00083A94
	[Token(Token = "0x6001833")]
	[Address(RVA = "0x29423FC", Offset = "0x29423FC", VA = "0x29423FC")]
	public void Ӿ\u07F9ۯ\u07FC()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001834 RID: 6196 RVA: 0x000858CC File Offset: 0x00083ACC
	[Token(Token = "0x6001834")]
	[Address(RVA = "0x294243C", Offset = "0x294243C", VA = "0x294243C")]
	public void ޱۇ\u0590ߚ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001835 RID: 6197 RVA: 0x00085904 File Offset: 0x00083B04
	[Token(Token = "0x6001835")]
	[Address(RVA = "0x294247C", Offset = "0x294247C", VA = "0x294247C")]
	public void ڛ\u073EӔߦ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001836 RID: 6198 RVA: 0x0008593C File Offset: 0x00083B3C
	[Token(Token = "0x6001836")]
	[Address(RVA = "0x29424BC", Offset = "0x29424BC", VA = "0x29424BC")]
	public void ߕ\u0652ࡔӖ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001837 RID: 6199 RVA: 0x00085974 File Offset: 0x00083B74
	[Token(Token = "0x6001837")]
	[Address(RVA = "0x29424FC", Offset = "0x29424FC", VA = "0x29424FC")]
	public void ࠓ\u0817\u06DD\u066B()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x06001838 RID: 6200 RVA: 0x000859AC File Offset: 0x00083BAC
	[Token(Token = "0x6001838")]
	[Address(RVA = "0x294253C", Offset = "0x294253C", VA = "0x294253C")]
	public void \u07FBޚࠁ\u0749()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x06001839 RID: 6201 RVA: 0x000859E4 File Offset: 0x00083BE4
	[Token(Token = "0x6001839")]
	[Address(RVA = "0x294257C", Offset = "0x294257C", VA = "0x294257C")]
	public void ݟԄ\u0819ԙ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x0600183A RID: 6202 RVA: 0x00085A1C File Offset: 0x00083C1C
	[Token(Token = "0x600183A")]
	[Address(RVA = "0x29425BC", Offset = "0x29425BC", VA = "0x29425BC")]
	public void Ւ\u0711ՃԳ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ل_u0826_u0703_u055E = this.ل\u0826\u0703\u055E;
		u065Aկࡑݲ.material = ل_u0826_u0703_u055E;
	}

	// Token: 0x0600183B RID: 6203 RVA: 0x00085A54 File Offset: 0x00083C54
	[Token(Token = "0x600183B")]
	[Address(RVA = "0x29425FC", Offset = "0x29425FC", VA = "0x29425FC")]
	public void \u07B5\u0559ڧߩ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x0600183C RID: 6204 RVA: 0x00085A8C File Offset: 0x00083C8C
	[Token(Token = "0x600183C")]
	[Address(RVA = "0x294263C", Offset = "0x294263C", VA = "0x294263C")]
	public void ք\u07FF\u07B0ڴ()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x0600183D RID: 6205 RVA: 0x00085AC4 File Offset: 0x00083CC4
	[Token(Token = "0x600183D")]
	[Address(RVA = "0x294267C", Offset = "0x294267C", VA = "0x294267C")]
	[PunRPC]
	public void ChangeMaterialToNormal()
	{
		bool <IsMine>k__BackingField = this.\u07AE\u05AF\u064FԖ.<IsMine>k__BackingField;
		SkinnedMeshRenderer u065Aկࡑݲ = this.\u065Aկࡑݲ;
		Material ٹ_u070BՇӽ = this.ٹ\u070BՇӽ;
		u065Aկࡑݲ.material = ٹ_u070BՇӽ;
	}

	// Token: 0x040002FC RID: 764
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002FC")]
	public SkinnedMeshRenderer \u065Aկࡑݲ;

	// Token: 0x040002FD RID: 765
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002FD")]
	public Material ٹ\u070BՇӽ;

	// Token: 0x040002FE RID: 766
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40002FE")]
	public Material ل\u0826\u0703\u055E;

	// Token: 0x040002FF RID: 767
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40002FF")]
	public PhotonView \u07AE\u05AF\u064FԖ;
}
