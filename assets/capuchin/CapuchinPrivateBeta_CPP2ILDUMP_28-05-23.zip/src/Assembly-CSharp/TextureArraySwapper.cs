﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000046 RID: 70
[Token(Token = "0x2000046")]
public class TextureArraySwapper : MonoBehaviour
{
	// Token: 0x060009AF RID: 2479 RVA: 0x00034EF8 File Offset: 0x000330F8
	[Token(Token = "0x60009AF")]
	[Address(RVA = "0x2F275B0", Offset = "0x2F275B0", VA = "0x2F275B0")]
	public IEnumerator \u05C2ՍدԐ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 0L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009B0 RID: 2480 RVA: 0x00034F1C File Offset: 0x0003311C
	[Token(Token = "0x60009B0")]
	[Address(RVA = "0x2F27628", Offset = "0x2F27628", VA = "0x2F27628")]
	public IEnumerator \u0892\u05AEՁԐ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 0L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009B1 RID: 2481 RVA: 0x00034F40 File Offset: 0x00033140
	[Token(Token = "0x60009B1")]
	[Address(RVA = "0x2F276A0", Offset = "0x2F276A0", VA = "0x2F276A0")]
	private void \u0614ࢥӴ\u086C()
	{
		int num = this.۳ԙޥހ;
		this.۳ԙޥހ = num;
	}

	// Token: 0x060009B2 RID: 2482 RVA: 0x00034F5C File Offset: 0x0003315C
	[Token(Token = "0x60009B2")]
	[Address(RVA = "0x2F276B8", Offset = "0x2F276B8", VA = "0x2F276B8")]
	private void \u0870\u05B3Ց\u066A()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009B3 RID: 2483 RVA: 0x00034F70 File Offset: 0x00033170
	[Token(Token = "0x60009B3")]
	[Address(RVA = "0x2F276CC", Offset = "0x2F276CC", VA = "0x2F276CC")]
	public IEnumerator ڞ\u0656ࠐܝ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009B4 RID: 2484 RVA: 0x00034F94 File Offset: 0x00033194
	[Token(Token = "0x60009B4")]
	[Address(RVA = "0x2F27744", Offset = "0x2F27744", VA = "0x2F27744")]
	public IEnumerator \u060E۷ށԴ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009B5 RID: 2485 RVA: 0x00034FB8 File Offset: 0x000331B8
	[Token(Token = "0x60009B5")]
	[Address(RVA = "0x2F277BC", Offset = "0x2F277BC", VA = "0x2F277BC")]
	public void ڋ۸\u088Cى()
	{
		IEnumerator routine = this.ݟӥ\u0735\u088B();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009B6 RID: 2486 RVA: 0x00034FD4 File Offset: 0x000331D4
	[Token(Token = "0x60009B6")]
	[Address(RVA = "0x2F27860", Offset = "0x2F27860", VA = "0x2F27860")]
	public IEnumerator \u088F\u081Bہة()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009B7 RID: 2487 RVA: 0x00034FF8 File Offset: 0x000331F8
	[Token(Token = "0x60009B7")]
	[Address(RVA = "0x2F278D8", Offset = "0x2F278D8", VA = "0x2F278D8")]
	public IEnumerator ڼ\u0739\u0600ߜ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009B8 RID: 2488 RVA: 0x0003501C File Offset: 0x0003321C
	[Token(Token = "0x60009B8")]
	[Address(RVA = "0x2F27950", Offset = "0x2F27950", VA = "0x2F27950")]
	private void յߪؾՀ()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009B9 RID: 2489 RVA: 0x00035030 File Offset: 0x00033230
	[Token(Token = "0x60009B9")]
	[Address(RVA = "0x2F27964", Offset = "0x2F27964", VA = "0x2F27964")]
	private void \u0886Ҽ\u058Dߛ()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009BA RID: 2490 RVA: 0x00035044 File Offset: 0x00033244
	[Token(Token = "0x60009BA")]
	[Address(RVA = "0x2F27978", Offset = "0x2F27978", VA = "0x2F27978")]
	public IEnumerator ۿ\u06FDڑ\u082B()
	{
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009BB RID: 2491 RVA: 0x00035060 File Offset: 0x00033260
	[Token(Token = "0x60009BB")]
	[Address(RVA = "0x2F279F0", Offset = "0x2F279F0", VA = "0x2F279F0")]
	public IEnumerator ٣Ӹߘԓ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009BC RID: 2492 RVA: 0x00035084 File Offset: 0x00033284
	[Token(Token = "0x60009BC")]
	[Address(RVA = "0x2F27A68", Offset = "0x2F27A68", VA = "0x2F27A68")]
	public void ރդ\u0594ӡ()
	{
		IEnumerator routine = this.ףܕ\u07BBٴ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009BD RID: 2493 RVA: 0x000350A0 File Offset: 0x000332A0
	[Token(Token = "0x60009BD")]
	[Address(RVA = "0x2F27B0C", Offset = "0x2F27B0C", VA = "0x2F27B0C")]
	public void \u0601ՇԮӳ()
	{
		IEnumerator routine = this.\u059C\u061F\u05C6\u05EE();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009BE RID: 2494 RVA: 0x000350BC File Offset: 0x000332BC
	[Token(Token = "0x60009BE")]
	[Address(RVA = "0x2F27BB0", Offset = "0x2F27BB0", VA = "0x2F27BB0")]
	public IEnumerator \u07BFײԠߞ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009BF RID: 2495 RVA: 0x000350E0 File Offset: 0x000332E0
	[Token(Token = "0x60009BF")]
	[Address(RVA = "0x2F27C28", Offset = "0x2F27C28", VA = "0x2F27C28")]
	private void \u061B\u05EEوۈ()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009C0 RID: 2496 RVA: 0x000350F4 File Offset: 0x000332F4
	[Token(Token = "0x60009C0")]
	[Address(RVA = "0x2F27C3C", Offset = "0x2F27C3C", VA = "0x2F27C3C")]
	private void \u05F7ԝߠӱ()
	{
		int num = this.۳ԙޥހ;
		long num2 = 1L;
		this.۳ԙޥހ = (int)num2;
	}

	// Token: 0x060009C1 RID: 2497 RVA: 0x00035114 File Offset: 0x00033314
	[Token(Token = "0x60009C1")]
	[Address(RVA = "0x2F27C54", Offset = "0x2F27C54", VA = "0x2F27C54")]
	public void و\u07AD\u06E9٣()
	{
		IEnumerator routine = this.ڐ\u05A1\u06D8\u0871();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009C2 RID: 2498 RVA: 0x00035130 File Offset: 0x00033330
	[Token(Token = "0x60009C2")]
	[Address(RVA = "0x2F27CF8", Offset = "0x2F27CF8", VA = "0x2F27CF8")]
	private void \u07B2\u0823ծݠ()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009C3 RID: 2499 RVA: 0x00035144 File Offset: 0x00033344
	[Token(Token = "0x60009C3")]
	[Address(RVA = "0x2F27D0C", Offset = "0x2F27D0C", VA = "0x2F27D0C")]
	public void ծߧߕ\u0605()
	{
		IEnumerator routine = this.ࢣ\u083Aࢪ\u05BC();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009C4 RID: 2500 RVA: 0x00035160 File Offset: 0x00033360
	[Token(Token = "0x60009C4")]
	[Address(RVA = "0x2F27DB0", Offset = "0x2F27DB0", VA = "0x2F27DB0")]
	private void ӻӒݝ߃()
	{
		int num = this.۳ԙޥހ;
		long num2 = 1L;
		this.۳ԙޥހ = (int)num2;
	}

	// Token: 0x060009C5 RID: 2501 RVA: 0x00035180 File Offset: 0x00033380
	[Token(Token = "0x60009C5")]
	[Address(RVA = "0x2F27DC8", Offset = "0x2F27DC8", VA = "0x2F27DC8")]
	public void \u0835ߙ\u0711Ԣ()
	{
		IEnumerator routine = this.٣Ӹߘԓ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009C6 RID: 2502 RVA: 0x0003519C File Offset: 0x0003339C
	[Token(Token = "0x60009C6")]
	[Address(RVA = "0x2F27DF4", Offset = "0x2F27DF4", VA = "0x2F27DF4")]
	private void \u0821\u059Fӕ\u0607()
	{
		int num = this.۳ԙޥހ;
		long num2 = 1L;
		this.۳ԙޥހ = (int)num2;
	}

	// Token: 0x060009C7 RID: 2503 RVA: 0x000351BC File Offset: 0x000333BC
	[Token(Token = "0x60009C7")]
	[Address(RVA = "0x2F27E0C", Offset = "0x2F27E0C", VA = "0x2F27E0C")]
	public IEnumerator Ԅ\u089D۷\u070B()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009C8 RID: 2504 RVA: 0x000351E0 File Offset: 0x000333E0
	[Token(Token = "0x60009C8")]
	[Address(RVA = "0x2F27E84", Offset = "0x2F27E84", VA = "0x2F27E84")]
	public void \u07B0Ր\u05F5ࡦ()
	{
		IEnumerator routine = this.ڐ\u05A1\u06D8\u0871();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009C9 RID: 2505 RVA: 0x000351FC File Offset: 0x000333FC
	[Token(Token = "0x60009C9")]
	[Address(RVA = "0x2F27EB0", Offset = "0x2F27EB0", VA = "0x2F27EB0")]
	public IEnumerator ࡗӘ\u082E\u0590()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009CA RID: 2506 RVA: 0x00035220 File Offset: 0x00033420
	[Token(Token = "0x60009CA")]
	[Address(RVA = "0x2F27F28", Offset = "0x2F27F28", VA = "0x2F27F28")]
	public IEnumerator ࢢܤԏܗ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 0L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009CB RID: 2507 RVA: 0x00035244 File Offset: 0x00033444
	[Token(Token = "0x60009CB")]
	[Address(RVA = "0x2F27FA0", Offset = "0x2F27FA0", VA = "0x2F27FA0")]
	private void \u07BDއڸ\u0834()
	{
		int num = this.۳ԙޥހ;
		long num2 = 1L;
		this.۳ԙޥހ = (int)num2;
	}

	// Token: 0x060009CC RID: 2508 RVA: 0x00035264 File Offset: 0x00033464
	[Token(Token = "0x60009CC")]
	[Address(RVA = "0x2F27FB8", Offset = "0x2F27FB8", VA = "0x2F27FB8")]
	public IEnumerator \u0603څպՖ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009CD RID: 2509 RVA: 0x00035288 File Offset: 0x00033488
	[Token(Token = "0x60009CD")]
	[Address(RVA = "0x2F28030", Offset = "0x2F28030", VA = "0x2F28030")]
	private void \u05EDց\u081Cت()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009CE RID: 2510 RVA: 0x0003529C File Offset: 0x0003349C
	[Token(Token = "0x60009CE")]
	[Address(RVA = "0x2F27A94", Offset = "0x2F27A94", VA = "0x2F27A94")]
	public IEnumerator ףܕ\u07BBٴ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009CF RID: 2511 RVA: 0x000352C0 File Offset: 0x000334C0
	[Token(Token = "0x60009CF")]
	[Address(RVA = "0x2F27D38", Offset = "0x2F27D38", VA = "0x2F27D38")]
	public IEnumerator ࢣ\u083Aࢪ\u05BC()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D0 RID: 2512 RVA: 0x000352E4 File Offset: 0x000334E4
	[Token(Token = "0x60009D0")]
	[Address(RVA = "0x2F27B38", Offset = "0x2F27B38", VA = "0x2F27B38")]
	public IEnumerator \u059C\u061F\u05C6\u05EE()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D1 RID: 2513 RVA: 0x00035308 File Offset: 0x00033508
	[Token(Token = "0x60009D1")]
	[Address(RVA = "0x2F28044", Offset = "0x2F28044", VA = "0x2F28044")]
	public void \u05A7ݒ\u083B\u081C()
	{
		IEnumerator routine = this.ࢣ\u083Aࢪ\u05BC();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009D2 RID: 2514 RVA: 0x00035324 File Offset: 0x00033524
	[Token(Token = "0x60009D2")]
	[Address(RVA = "0x2F28070", Offset = "0x2F28070", VA = "0x2F28070")]
	public void ى\u081Cޛ\u07EC()
	{
		IEnumerator routine = this.ࠁӣࠎڜ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009D3 RID: 2515 RVA: 0x00035340 File Offset: 0x00033540
	[Token(Token = "0x60009D3")]
	[Address(RVA = "0x2F28114", Offset = "0x2F28114", VA = "0x2F28114")]
	public IEnumerator \u05F9\u05A7ࠁࡪ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 0L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D4 RID: 2516 RVA: 0x00035364 File Offset: 0x00033564
	[Token(Token = "0x60009D4")]
	[Address(RVA = "0x2F2818C", Offset = "0x2F2818C", VA = "0x2F2818C")]
	public void Awake()
	{
		IEnumerator routine = this.ۿ\u06FDڑ\u082B();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009D5 RID: 2517 RVA: 0x00035380 File Offset: 0x00033580
	[Token(Token = "0x60009D5")]
	[Address(RVA = "0x2F281B8", Offset = "0x2F281B8", VA = "0x2F281B8")]
	private void \u0892ܒܬޓ()
	{
		int num = this.۳ԙޥހ;
		long num2 = 1L;
		this.۳ԙޥހ = (int)num2;
	}

	// Token: 0x060009D6 RID: 2518 RVA: 0x000353A0 File Offset: 0x000335A0
	[Token(Token = "0x60009D6")]
	[Address(RVA = "0x2F281D0", Offset = "0x2F281D0", VA = "0x2F281D0")]
	public void ۹\u0833\u0557ࡇ()
	{
		IEnumerator routine = this.Ԅ\u089D۷\u070B();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009D7 RID: 2519 RVA: 0x000353BC File Offset: 0x000335BC
	[Token(Token = "0x60009D7")]
	[Address(RVA = "0x2F27C80", Offset = "0x2F27C80", VA = "0x2F27C80")]
	public IEnumerator ڐ\u05A1\u06D8\u0871()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D8 RID: 2520 RVA: 0x000353E0 File Offset: 0x000335E0
	[Token(Token = "0x60009D8")]
	[Address(RVA = "0x2F281FC", Offset = "0x2F281FC", VA = "0x2F281FC")]
	public IEnumerator \u0594רݾݽ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D9 RID: 2521 RVA: 0x00035404 File Offset: 0x00033604
	[Token(Token = "0x60009D9")]
	[Address(RVA = "0x2F28274", Offset = "0x2F28274", VA = "0x2F28274")]
	public IEnumerator ٥ࡐٮ\u0559()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009DA RID: 2522 RVA: 0x00035428 File Offset: 0x00033628
	[Token(Token = "0x60009DA")]
	[Address(RVA = "0x2F282EC", Offset = "0x2F282EC", VA = "0x2F282EC")]
	public void ڬ\u0833غר()
	{
		IEnumerator routine = this.ڼ\u0739\u0600ߜ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009DB RID: 2523 RVA: 0x00035444 File Offset: 0x00033644
	[Token(Token = "0x60009DB")]
	[Address(RVA = "0x2F28318", Offset = "0x2F28318", VA = "0x2F28318")]
	public IEnumerator \u074AԲյة()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 0L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009DC RID: 2524 RVA: 0x00035468 File Offset: 0x00033668
	[Token(Token = "0x60009DC")]
	[Address(RVA = "0x2F28390", Offset = "0x2F28390", VA = "0x2F28390")]
	public void Ԃ\u0599ވց()
	{
		IEnumerator routine = this.\u074AԲյة();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009DD RID: 2525 RVA: 0x00035484 File Offset: 0x00033684
	[Token(Token = "0x60009DD")]
	[Address(RVA = "0x2F283BC", Offset = "0x2F283BC", VA = "0x2F283BC")]
	public IEnumerator ܐؿܘࠇ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x060009DE RID: 2526 RVA: 0x000354A0 File Offset: 0x000336A0
	[Token(Token = "0x60009DE")]
	[Address(RVA = "0x2F28434", Offset = "0x2F28434", VA = "0x2F28434")]
	private void طӏܙࢺ()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009DF RID: 2527 RVA: 0x000354B4 File Offset: 0x000336B4
	[Token(Token = "0x60009DF")]
	[Address(RVA = "0x2F2844C", Offset = "0x2F2844C", VA = "0x2F2844C")]
	public IEnumerator ڈݠߌ\u065D()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009E0 RID: 2528 RVA: 0x000354D8 File Offset: 0x000336D8
	[Token(Token = "0x60009E0")]
	[Address(RVA = "0x2F284C4", Offset = "0x2F284C4", VA = "0x2F284C4")]
	private void ފՖߢ\u059B()
	{
		int num = this.۳ԙޥހ;
		long num2 = 1L;
		this.۳ԙޥހ = (int)num2;
	}

	// Token: 0x060009E1 RID: 2529 RVA: 0x000354F8 File Offset: 0x000336F8
	[Token(Token = "0x60009E1")]
	[Address(RVA = "0x2F277E8", Offset = "0x2F277E8", VA = "0x2F277E8")]
	public IEnumerator ݟӥ\u0735\u088B()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 0L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009E2 RID: 2530 RVA: 0x0003551C File Offset: 0x0003371C
	[Token(Token = "0x60009E2")]
	[Address(RVA = "0x2F284DC", Offset = "0x2F284DC", VA = "0x2F284DC")]
	private void \u0838ӆڛӑ()
	{
		int num = this.۳ԙޥހ;
		long num2 = 1L;
		this.۳ԙޥހ = (int)num2;
	}

	// Token: 0x060009E3 RID: 2531 RVA: 0x0003553C File Offset: 0x0003373C
	[Token(Token = "0x60009E3")]
	[Address(RVA = "0x2F284F4", Offset = "0x2F284F4", VA = "0x2F284F4")]
	public IEnumerator Ժӳ\u06DAߦ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009E4 RID: 2532 RVA: 0x00035560 File Offset: 0x00033760
	[Token(Token = "0x60009E4")]
	[Address(RVA = "0x2F2856C", Offset = "0x2F2856C", VA = "0x2F2856C")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		int num = this.۳ԙޥހ;
		long num2 = 1L;
		this.۳ԙޥހ = (int)num2;
	}

	// Token: 0x060009E5 RID: 2533 RVA: 0x00035580 File Offset: 0x00033780
	[Token(Token = "0x60009E5")]
	[Address(RVA = "0x2F28584", Offset = "0x2F28584", VA = "0x2F28584")]
	public IEnumerator ջ\u0617ܒԉ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 0L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009E6 RID: 2534 RVA: 0x000355A4 File Offset: 0x000337A4
	[Token(Token = "0x60009E6")]
	[Address(RVA = "0x2F285FC", Offset = "0x2F285FC", VA = "0x2F285FC")]
	private void \u070Aәޣے()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009E7 RID: 2535 RVA: 0x000355B8 File Offset: 0x000337B8
	[Token(Token = "0x60009E7")]
	[Address(RVA = "0x2F28610", Offset = "0x2F28610", VA = "0x2F28610")]
	public IEnumerator ߟࡒםך()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009E8 RID: 2536 RVA: 0x000355DC File Offset: 0x000337DC
	[Token(Token = "0x60009E8")]
	[Address(RVA = "0x2F28688", Offset = "0x2F28688", VA = "0x2F28688")]
	private void Update()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009E9 RID: 2537 RVA: 0x000355F0 File Offset: 0x000337F0
	[Token(Token = "0x60009E9")]
	[Address(RVA = "0x2F2869C", Offset = "0x2F2869C", VA = "0x2F2869C")]
	public void կڦԌ\u0871()
	{
		IEnumerator routine = this.ߟࡒםך();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009EA RID: 2538 RVA: 0x0003560C File Offset: 0x0003380C
	[Token(Token = "0x60009EA")]
	[Address(RVA = "0x2F286C8", Offset = "0x2F286C8", VA = "0x2F286C8")]
	public void ݒڣپ\u07B3()
	{
		IEnumerator routine = this.\u0603څպՖ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009EB RID: 2539 RVA: 0x00035628 File Offset: 0x00033828
	[Token(Token = "0x60009EB")]
	[Address(RVA = "0x2F286F4", Offset = "0x2F286F4", VA = "0x2F286F4")]
	public void ߘ\u05AEԮ\u06DD()
	{
		IEnumerator routine = this.\u05C2ՍدԐ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009EC RID: 2540 RVA: 0x00035644 File Offset: 0x00033844
	[Token(Token = "0x60009EC")]
	[Address(RVA = "0x2F28720", Offset = "0x2F28720", VA = "0x2F28720")]
	private void \u07F7ܙײ\u05B5()
	{
		int num = this.۳ԙޥހ;
		long num2 = 1L;
		this.۳ԙޥހ = (int)num2;
	}

	// Token: 0x060009ED RID: 2541 RVA: 0x00035664 File Offset: 0x00033864
	[Token(Token = "0x60009ED")]
	[Address(RVA = "0x2F28738", Offset = "0x2F28738", VA = "0x2F28738")]
	private void ڃրӢԖ()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009EE RID: 2542 RVA: 0x00035684 File Offset: 0x00033884
	[Token(Token = "0x60009EE")]
	[Address(RVA = "0x2F28754", Offset = "0x2F28754", VA = "0x2F28754")]
	public IEnumerator ӱ\u07B9\u05BFӻ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 0L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009EF RID: 2543 RVA: 0x000356A8 File Offset: 0x000338A8
	[Token(Token = "0x60009EF")]
	[Address(RVA = "0x2F287CC", Offset = "0x2F287CC", VA = "0x2F287CC")]
	public IEnumerator ف\u07A9\u0892ࠓ()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009F0 RID: 2544 RVA: 0x000356CC File Offset: 0x000338CC
	[Token(Token = "0x60009F0")]
	[Address(RVA = "0x2F28844", Offset = "0x2F28844", VA = "0x2F28844")]
	public void ځل\u0612Չ()
	{
		IEnumerator routine = this.\u060E۷ށԴ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009F1 RID: 2545 RVA: 0x000356E8 File Offset: 0x000338E8
	[Token(Token = "0x60009F1")]
	[Address(RVA = "0x2F28870", Offset = "0x2F28870", VA = "0x2F28870")]
	private void יԠ\u07EDԺ()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x060009F2 RID: 2546 RVA: 0x000356FC File Offset: 0x000338FC
	[Token(Token = "0x60009F2")]
	[Address(RVA = "0x2F28884", Offset = "0x2F28884", VA = "0x2F28884")]
	public void \u0608\u070F\u081D\u05B8()
	{
		IEnumerator enumerator = this.\u05C2ՍدԐ();
	}

	// Token: 0x060009F3 RID: 2547 RVA: 0x00035710 File Offset: 0x00033910
	[Token(Token = "0x60009F3")]
	[Address(RVA = "0x2F288B0", Offset = "0x2F288B0", VA = "0x2F288B0")]
	public IEnumerator \u07B4ߤ\u0828\u07AB()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 0L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009F4 RID: 2548 RVA: 0x00035734 File Offset: 0x00033934
	[Token(Token = "0x60009F4")]
	[Address(RVA = "0x2F28928", Offset = "0x2F28928", VA = "0x2F28928")]
	public void \u065Cզ\u07BF\u07F5()
	{
		IEnumerator routine = this.ڼ\u0739\u0600ߜ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009F5 RID: 2549 RVA: 0x00035750 File Offset: 0x00033950
	[Token(Token = "0x60009F5")]
	[Address(RVA = "0x2F2809C", Offset = "0x2F2809C", VA = "0x2F2809C")]
	public IEnumerator ࠁӣࠎڜ()
	{
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009F6 RID: 2550 RVA: 0x0003576C File Offset: 0x0003396C
	[Token(Token = "0x60009F6")]
	[Address(RVA = "0x2F28954", Offset = "0x2F28954", VA = "0x2F28954")]
	public IEnumerator ٲ\u055D\u0731\u087F()
	{
		long <>1__state;
		TextureArraySwapper.ࡅࢧӒն ࡅࢧӒն = new TextureArraySwapper.ࡅࢧӒն((int)<>1__state);
		<>1__state = 1L;
		ࡅࢧӒն.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009F7 RID: 2551 RVA: 0x00035790 File Offset: 0x00033990
	[Token(Token = "0x60009F7")]
	[Address(RVA = "0x2F289CC", Offset = "0x2F289CC", VA = "0x2F289CC")]
	private void \u087BӦןݩ()
	{
		int num = this.۳ԙޥހ;
		long num2 = 1L;
		this.۳ԙޥހ = (int)num2;
	}

	// Token: 0x060009F8 RID: 2552 RVA: 0x000357B0 File Offset: 0x000339B0
	[Token(Token = "0x60009F8")]
	[Address(RVA = "0x2F289E4", Offset = "0x2F289E4", VA = "0x2F289E4")]
	public TextureArraySwapper()
	{
	}

	// Token: 0x060009F9 RID: 2553 RVA: 0x000357C4 File Offset: 0x000339C4
	[Token(Token = "0x60009F9")]
	[Address(RVA = "0x2F289EC", Offset = "0x2F289EC", VA = "0x2F289EC")]
	public void ݽ\u0706\u07ADࡇ()
	{
		IEnumerator routine = this.\u07BFײԠߞ();
		Coroutine coroutine = base.StartCoroutine(routine);
	}

	// Token: 0x060009FA RID: 2554 RVA: 0x000357E0 File Offset: 0x000339E0
	[Token(Token = "0x60009FA")]
	[Address(RVA = "0x2F28A18", Offset = "0x2F28A18", VA = "0x2F28A18")]
	private void ٴݵۃ\u05AF()
	{
		int num = this.۳ԙޥހ;
	}

	// Token: 0x0400016A RID: 362
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400016A")]
	public Material ࡄڑࠊ\u088B;

	// Token: 0x0400016B RID: 363
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400016B")]
	public Texture2D[] \u05ABܝ\u06EAޠ;

	// Token: 0x0400016C RID: 364
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400016C")]
	public float ٮݦٽ\u07F4;

	// Token: 0x0400016D RID: 365
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x400016D")]
	private int ۳ԙޥހ;
}
