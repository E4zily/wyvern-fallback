﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E7 RID: 231
[Token(Token = "0x20000E7")]
public class StartButton : MonoBehaviour
{
	// Token: 0x060023BE RID: 9150 RVA: 0x000BC448 File Offset: 0x000BA648
	[Token(Token = "0x60023BE")]
	[Address(RVA = "0x2F78B04", Offset = "0x2F78B04", VA = "0x2F78B04")]
	public StartButton()
	{
	}

	// Token: 0x060023BF RID: 9151 RVA: 0x000BC45C File Offset: 0x000BA65C
	[Token(Token = "0x60023BF")]
	[Address(RVA = "0x2F78B0C", Offset = "0x2F78B0C", VA = "0x2F78B0C")]
	private void ւࡂ\u0883\u0872()
	{
	}

	// Token: 0x060023C0 RID: 9152 RVA: 0x000BC46C File Offset: 0x000BA66C
	[Token(Token = "0x60023C0")]
	[Address(RVA = "0x2F78B10", Offset = "0x2F78B10", VA = "0x2F78B10")]
	private void \u05EDց\u081Cت()
	{
	}

	// Token: 0x060023C1 RID: 9153 RVA: 0x000BC47C File Offset: 0x000BA67C
	[Token(Token = "0x60023C1")]
	[Address(RVA = "0x2F78B14", Offset = "0x2F78B14", VA = "0x2F78B14")]
	private void ۮߝڪڐ()
	{
	}

	// Token: 0x060023C2 RID: 9154 RVA: 0x000BC48C File Offset: 0x000BA68C
	[Token(Token = "0x60023C2")]
	[Address(RVA = "0x2F78B18", Offset = "0x2F78B18", VA = "0x2F78B18")]
	private void ߖհݣ߀()
	{
	}

	// Token: 0x060023C3 RID: 9155 RVA: 0x000BC49C File Offset: 0x000BA69C
	[Token(Token = "0x60023C3")]
	[Address(RVA = "0x2F78B1C", Offset = "0x2F78B1C", VA = "0x2F78B1C")]
	private void \u065F\u0839ܤ\u073C()
	{
	}

	// Token: 0x060023C4 RID: 9156 RVA: 0x000BC4AC File Offset: 0x000BA6AC
	[Token(Token = "0x60023C4")]
	[Address(RVA = "0x2F78B20", Offset = "0x2F78B20", VA = "0x2F78B20")]
	private void څࡣڐ\u0657()
	{
	}

	// Token: 0x060023C5 RID: 9157 RVA: 0x000BC4BC File Offset: 0x000BA6BC
	[Token(Token = "0x60023C5")]
	[Address(RVA = "0x2F78B24", Offset = "0x2F78B24", VA = "0x2F78B24")]
	private void Update()
	{
	}

	// Token: 0x060023C6 RID: 9158 RVA: 0x000BC4CC File Offset: 0x000BA6CC
	[Token(Token = "0x60023C6")]
	[Address(RVA = "0x2F78B28", Offset = "0x2F78B28", VA = "0x2F78B28")]
	private void Ԯ\u0883\u0591\u066C()
	{
	}

	// Token: 0x060023C7 RID: 9159 RVA: 0x000BC4DC File Offset: 0x000BA6DC
	[Token(Token = "0x60023C7")]
	[Address(RVA = "0x2F78B2C", Offset = "0x2F78B2C", VA = "0x2F78B2C")]
	private void ڑߒجވ()
	{
	}

	// Token: 0x060023C8 RID: 9160 RVA: 0x000BC4EC File Offset: 0x000BA6EC
	[Token(Token = "0x60023C8")]
	[Address(RVA = "0x2F78B30", Offset = "0x2F78B30", VA = "0x2F78B30")]
	private void Start()
	{
	}

	// Token: 0x060023C9 RID: 9161 RVA: 0x000BC4FC File Offset: 0x000BA6FC
	[Token(Token = "0x60023C9")]
	[Address(RVA = "0x2F78B34", Offset = "0x2F78B34", VA = "0x2F78B34")]
	private void ԣԭՋࠏ()
	{
	}

	// Token: 0x060023CA RID: 9162 RVA: 0x000BC50C File Offset: 0x000BA70C
	[Token(Token = "0x60023CA")]
	[Address(RVA = "0x2F78B38", Offset = "0x2F78B38", VA = "0x2F78B38")]
	private void ޡࠅ\u089Aߔ()
	{
	}

	// Token: 0x060023CB RID: 9163 RVA: 0x000BC51C File Offset: 0x000BA71C
	[Token(Token = "0x60023CB")]
	[Address(RVA = "0x2F78B3C", Offset = "0x2F78B3C", VA = "0x2F78B3C")]
	private void \u05F7ԝߠӱ()
	{
	}

	// Token: 0x060023CC RID: 9164 RVA: 0x000BC52C File Offset: 0x000BA72C
	[Token(Token = "0x60023CC")]
	[Address(RVA = "0x2F78B40", Offset = "0x2F78B40", VA = "0x2F78B40")]
	private void Ҿࢹؼס()
	{
	}

	// Token: 0x060023CD RID: 9165 RVA: 0x000BC53C File Offset: 0x000BA73C
	[Token(Token = "0x60023CD")]
	[Address(RVA = "0x2F78B44", Offset = "0x2F78B44", VA = "0x2F78B44")]
	private void Ӣ\u0592ߨׯ()
	{
	}
}
