﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E5 RID: 229
[Token(Token = "0x20000E5")]
public class makeDoorGoWeeeee : MonoBehaviour
{
	// Token: 0x06002365 RID: 9061 RVA: 0x000BB0A4 File Offset: 0x000B92A4
	[Token(Token = "0x6002365")]
	[Address(RVA = "0x2E35390", Offset = "0x2E35390", VA = "0x2E35390")]
	public void ܮݫ߅ࡃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "MetaId";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002366 RID: 9062 RVA: 0x000BB0E0 File Offset: 0x000B92E0
	[Token(Token = "0x6002366")]
	[Address(RVA = "0x2E35420", Offset = "0x2E35420", VA = "0x2E35420")]
	public void ہۼآԄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "DisableCosmetic";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002367 RID: 9063 RVA: 0x000BB110 File Offset: 0x000B9310
	[Token(Token = "0x6002367")]
	[Address(RVA = "0x2E354AC", Offset = "0x2E354AC", VA = "0x2E354AC")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002368 RID: 9064 RVA: 0x000BB140 File Offset: 0x000B9340
	[Token(Token = "0x6002368")]
	[Address(RVA = "0x2E35538", Offset = "0x2E35538", VA = "0x2E35538")]
	public void ځޤקࠈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ChangeToTagged";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002369 RID: 9065 RVA: 0x000BB170 File Offset: 0x000B9370
	[Token(Token = "0x6002369")]
	[Address(RVA = "0x2E355C4", Offset = "0x2E355C4", VA = "0x2E355C4")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Vertical";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600236A RID: 9066 RVA: 0x000BB1AC File Offset: 0x000B93AC
	[Token(Token = "0x600236A")]
	[Address(RVA = "0x2E35654", Offset = "0x2E35654", VA = "0x2E35654")]
	public void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600236B RID: 9067 RVA: 0x000BB1DC File Offset: 0x000B93DC
	[Token(Token = "0x600236B")]
	[Address(RVA = "0x2E356E0", Offset = "0x2E356E0", VA = "0x2E356E0")]
	public void ەԌ\u05C7\u085D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "gamemode";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600236C RID: 9068 RVA: 0x000BB218 File Offset: 0x000B9418
	[Token(Token = "0x600236C")]
	[Address(RVA = "0x2E35770", Offset = "0x2E35770", VA = "0x2E35770")]
	public void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Open";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600236D RID: 9069 RVA: 0x000BB254 File Offset: 0x000B9454
	[Token(Token = "0x600236D")]
	[Address(RVA = "0x2E35800", Offset = "0x2E35800", VA = "0x2E35800")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Try Connect To Server...";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600236E RID: 9070 RVA: 0x000BB290 File Offset: 0x000B9490
	[Token(Token = "0x600236E")]
	[Address(RVA = "0x2E35890", Offset = "0x2E35890", VA = "0x2E35890")]
	public void ܘݱ\u083CԲ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PushToTalk";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600236F RID: 9071 RVA: 0x000BB2C0 File Offset: 0x000B94C0
	[Token(Token = "0x600236F")]
	[Address(RVA = "0x2E3591C", Offset = "0x2E3591C", VA = "0x2E3591C")]
	public void \u0748\u05F4Նۏ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "2BN";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002370 RID: 9072 RVA: 0x000BB2EC File Offset: 0x000B94EC
	[Token(Token = "0x6002370")]
	[Address(RVA = "0x2E359A8", Offset = "0x2E359A8", VA = "0x2E359A8")]
	public void ؽܗӊә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not enough amount of currency";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002371 RID: 9073 RVA: 0x000BB31C File Offset: 0x000B951C
	[Token(Token = "0x6002371")]
	[Address(RVA = "0x2E35A34", Offset = "0x2E35A34", VA = "0x2E35A34")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Joined a Room.";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002372 RID: 9074 RVA: 0x000BB34C File Offset: 0x000B954C
	[Token(Token = "0x6002372")]
	[Address(RVA = "0x2E35AC0", Offset = "0x2E35AC0", VA = "0x2E35AC0")]
	public void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Removing ";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002373 RID: 9075 RVA: 0x000BB37C File Offset: 0x000B957C
	[Token(Token = "0x6002373")]
	[Address(RVA = "0x2E35B4C", Offset = "0x2E35B4C", VA = "0x2E35B4C")]
	public void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "duration done";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002374 RID: 9076 RVA: 0x000BB3B8 File Offset: 0x000B95B8
	[Token(Token = "0x6002374")]
	[Address(RVA = "0x2E35BDC", Offset = "0x2E35BDC", VA = "0x2E35BDC")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Collided";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002375 RID: 9077 RVA: 0x000BB3E8 File Offset: 0x000B95E8
	[Token(Token = "0x6002375")]
	[Address(RVA = "0x2E35C68", Offset = "0x2E35C68", VA = "0x2E35C68")]
	public void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == ".Please press the button if you would like to play alone";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002376 RID: 9078 RVA: 0x000BB418 File Offset: 0x000B9618
	[Token(Token = "0x6002376")]
	[Address(RVA = "0x2E35CF4", Offset = "0x2E35CF4", VA = "0x2E35CF4")]
	public void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "containsStaff";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002377 RID: 9079 RVA: 0x000BB448 File Offset: 0x000B9648
	[Token(Token = "0x6002377")]
	[Address(RVA = "0x2E35D80", Offset = "0x2E35D80", VA = "0x2E35D80")]
	public void ة\u066Dࡏԫ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Failed to login, please restart";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002378 RID: 9080 RVA: 0x000BB484 File Offset: 0x000B9684
	[Token(Token = "0x6002378")]
	[Address(RVA = "0x2E35E10", Offset = "0x2E35E10", VA = "0x2E35E10")]
	public void \u085Dښ\u0611ԛ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Tagging";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002379 RID: 9081 RVA: 0x000BB4B4 File Offset: 0x000B96B4
	[Token(Token = "0x6002379")]
	[Address(RVA = "0x2E35E9C", Offset = "0x2E35E9C", VA = "0x2E35E9C")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ChangeToRegular";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600237A RID: 9082 RVA: 0x000BB4E4 File Offset: 0x000B96E4
	[Token(Token = "0x600237A")]
	[Address(RVA = "0x2E35F28", Offset = "0x2E35F28", VA = "0x2E35F28")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "goDownRPC";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600237B RID: 9083 RVA: 0x000BB520 File Offset: 0x000B9720
	[Token(Token = "0x600237B")]
	[Address(RVA = "0x2E35FB8", Offset = "0x2E35FB8", VA = "0x2E35FB8")]
	public void \u066A\u0603Ӥܔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "On";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600237C RID: 9084 RVA: 0x000BB55C File Offset: 0x000B975C
	[Token(Token = "0x600237C")]
	[Address(RVA = "0x2E36048", Offset = "0x2E36048", VA = "0x2E36048")]
	public void \u05C1ؽԜࡥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Faild To Add Winner Money: ";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600237D RID: 9085 RVA: 0x000BB58C File Offset: 0x000B978C
	[Token(Token = "0x600237D")]
	[Address(RVA = "0x2E360D4", Offset = "0x2E360D4", VA = "0x2E360D4")]
	public void ܖռ\u05C8\u089F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == ". Please update you game to the latest version";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600237E RID: 9086 RVA: 0x000BB5BC File Offset: 0x000B97BC
	[Token(Token = "0x600237E")]
	[Address(RVA = "0x2E36160", Offset = "0x2E36160", VA = "0x2E36160")]
	public void ݼڔ\u05CE\u0899(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "spooky guy true";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600237F RID: 9087 RVA: 0x000BB5EC File Offset: 0x000B97EC
	[Token(Token = "0x600237F")]
	[Address(RVA = "0x2E361EC", Offset = "0x2E361EC", VA = "0x2E361EC")]
	public void \u0836Չװߟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "monke screamed";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002380 RID: 9088 RVA: 0x000BB61C File Offset: 0x000B981C
	[Token(Token = "0x6002380")]
	[Address(RVA = "0x2E36278", Offset = "0x2E36278", VA = "0x2E36278")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Vertical";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002381 RID: 9089 RVA: 0x000BB64C File Offset: 0x000B984C
	[Token(Token = "0x6002381")]
	[Address(RVA = "0x2E36304", Offset = "0x2E36304", VA = "0x2E36304")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Adding ";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002382 RID: 9090 RVA: 0x000BB67C File Offset: 0x000B987C
	[Token(Token = "0x6002382")]
	[Address(RVA = "0x2E36390", Offset = "0x2E36390", VA = "0x2E36390")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002383 RID: 9091 RVA: 0x000BB6B8 File Offset: 0x000B98B8
	[Token(Token = "0x6002383")]
	[Address(RVA = "0x2E36420", Offset = "0x2E36420", VA = "0x2E36420")]
	public void \u06E9\u0740մ\u0746(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002384 RID: 9092 RVA: 0x000BB6F4 File Offset: 0x000B98F4
	[Token(Token = "0x6002384")]
	[Address(RVA = "0x2E364B0", Offset = "0x2E364B0", VA = "0x2E364B0")]
	public void \u07B2߆Ժࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Key";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002385 RID: 9093 RVA: 0x000BB730 File Offset: 0x000B9930
	[Token(Token = "0x6002385")]
	[Address(RVA = "0x2E36540", Offset = "0x2E36540", VA = "0x2E36540")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002386 RID: 9094 RVA: 0x000BB76C File Offset: 0x000B996C
	[Token(Token = "0x6002386")]
	[Address(RVA = "0x2E365D0", Offset = "0x2E365D0", VA = "0x2E365D0")]
	public void ފԅ\u0881ݾ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002387 RID: 9095 RVA: 0x000BB7A8 File Offset: 0x000B99A8
	[Token(Token = "0x6002387")]
	[Address(RVA = "0x2E36660", Offset = "0x2E36660", VA = "0x2E36660")]
	public void ӻڊ\u05B3ۍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Start Gamemode";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002388 RID: 9096 RVA: 0x000BB7D8 File Offset: 0x000B99D8
	[Token(Token = "0x6002388")]
	[Address(RVA = "0x2E366EC", Offset = "0x2E366EC", VA = "0x2E366EC")]
	public void \u083Eܙ\u07FD\u0706(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not enough amount of currency";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002389 RID: 9097 RVA: 0x000BB814 File Offset: 0x000B9A14
	[Token(Token = "0x6002389")]
	[Address(RVA = "0x2E3677C", Offset = "0x2E3677C", VA = "0x2E3677C")]
	public void ت\u05F9ޅ\u059A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600238A RID: 9098 RVA: 0x000BB850 File Offset: 0x000B9A50
	[Token(Token = "0x600238A")]
	[Address(RVA = "0x2E3680C", Offset = "0x2E3680C", VA = "0x2E3680C")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Is Colliding";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600238B RID: 9099 RVA: 0x000BB88C File Offset: 0x000B9A8C
	[Token(Token = "0x600238B")]
	[Address(RVA = "0x2E3689C", Offset = "0x2E3689C", VA = "0x2E3689C")]
	public void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ORGPORT";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600238C RID: 9100 RVA: 0x000BB8BC File Offset: 0x000B9ABC
	[Token(Token = "0x600238C")]
	[Address(RVA = "0x2E36928", Offset = "0x2E36928", VA = "0x2E36928")]
	public void \u06E2ڇ\u07BF߃(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600238D RID: 9101 RVA: 0x000BB8F8 File Offset: 0x000B9AF8
	[Token(Token = "0x600238D")]
	[Address(RVA = "0x2E369B8", Offset = "0x2E369B8", VA = "0x2E369B8")]
	public void سࡕԞ߆(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "jump char false";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600238E RID: 9102 RVA: 0x000BB934 File Offset: 0x000B9B34
	[Token(Token = "0x600238E")]
	[Address(RVA = "0x2E36A48", Offset = "0x2E36A48", VA = "0x2E36A48")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "On";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600238F RID: 9103 RVA: 0x000BB964 File Offset: 0x000B9B64
	[Token(Token = "0x600238F")]
	[Address(RVA = "0x2E36AD4", Offset = "0x2E36AD4", VA = "0x2E36AD4")]
	public void \u06DEӸԏ\u07BF(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Charging...";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002390 RID: 9104 RVA: 0x000BB9A0 File Offset: 0x000B9BA0
	[Token(Token = "0x6002390")]
	[Address(RVA = "0x2E36B64", Offset = "0x2E36B64", VA = "0x2E36B64")]
	public void ڎՅڤࠊ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "EnableCosmetic";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002391 RID: 9105 RVA: 0x000BB9D0 File Offset: 0x000B9BD0
	[Token(Token = "0x6002391")]
	[Address(RVA = "0x2E36BF0", Offset = "0x2E36BF0", VA = "0x2E36BF0")]
	public void ք\u05FEؽ\u061E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HorrorAgreement";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002392 RID: 9106 RVA: 0x000BBA0C File Offset: 0x000B9C0C
	[Token(Token = "0x6002392")]
	[Address(RVA = "0x2E36C80", Offset = "0x2E36C80", VA = "0x2E36C80")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "NetworkGunShoot";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002393 RID: 9107 RVA: 0x000BBA48 File Offset: 0x000B9C48
	[Token(Token = "0x6002393")]
	[Address(RVA = "0x2E36D10", Offset = "0x2E36D10", VA = "0x2E36D10")]
	public void ԗ\u05F9ҿ\u0834(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "NetworkPlayer";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002394 RID: 9108 RVA: 0x000BBA84 File Offset: 0x000B9C84
	[Token(Token = "0x6002394")]
	[Address(RVA = "0x2E36DA0", Offset = "0x2E36DA0", VA = "0x2E36DA0")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Agreed";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002395 RID: 9109 RVA: 0x000BBAC0 File Offset: 0x000B9CC0
	[Token(Token = "0x6002395")]
	[Address(RVA = "0x2E36E30", Offset = "0x2E36E30", VA = "0x2E36E30")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HDRP/Lit";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002396 RID: 9110 RVA: 0x000BBAFC File Offset: 0x000B9CFC
	[Token(Token = "0x6002396")]
	[Address(RVA = "0x2E36EC0", Offset = "0x2E36EC0", VA = "0x2E36EC0")]
	public void \u0885ےܝ\u05BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "EnableCosmetic";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002397 RID: 9111 RVA: 0x000BBB38 File Offset: 0x000B9D38
	[Token(Token = "0x6002397")]
	[Address(RVA = "0x2E36F50", Offset = "0x2E36F50", VA = "0x2E36F50")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x06002398 RID: 9112 RVA: 0x000BBB74 File Offset: 0x000B9D74
	[Token(Token = "0x6002398")]
	[Address(RVA = "0x2E36FE0", Offset = "0x2E36FE0", VA = "0x2E36FE0")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Name Changing Error. Error: ";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x06002399 RID: 9113 RVA: 0x000BBBA4 File Offset: 0x000B9DA4
	[Token(Token = "0x6002399")]
	[Address(RVA = "0x2E3706C", Offset = "0x2E3706C", VA = "0x2E3706C")]
	public void Ԍߊٱݩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PURCHASED";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600239A RID: 9114 RVA: 0x000BBBE0 File Offset: 0x000B9DE0
	[Token(Token = "0x600239A")]
	[Address(RVA = "0x2E370FC", Offset = "0x2E370FC", VA = "0x2E370FC")]
	public makeDoorGoWeeeee()
	{
	}

	// Token: 0x0600239B RID: 9115 RVA: 0x000BBBF4 File Offset: 0x000B9DF4
	[Token(Token = "0x600239B")]
	[Address(RVA = "0x2E37104", Offset = "0x2E37104", VA = "0x2E37104")]
	public void ࢲ\u061C\u0817ݽ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "TurnAmount";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600239C RID: 9116 RVA: 0x000BBC24 File Offset: 0x000B9E24
	[Token(Token = "0x600239C")]
	[Address(RVA = "0x2E37190", Offset = "0x2E37190", VA = "0x2E37190")]
	public void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ChangeToRegular";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x0600239D RID: 9117 RVA: 0x000BBC60 File Offset: 0x000B9E60
	[Token(Token = "0x600239D")]
	[Address(RVA = "0x2E37220", Offset = "0x2E37220", VA = "0x2E37220")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600239E RID: 9118 RVA: 0x000BBC90 File Offset: 0x000B9E90
	[Token(Token = "0x600239E")]
	[Address(RVA = "0x2E372AC", Offset = "0x2E372AC", VA = "0x2E372AC")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "containsStaff";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x0600239F RID: 9119 RVA: 0x000BBCC0 File Offset: 0x000B9EC0
	[Token(Token = "0x600239F")]
	[Address(RVA = "0x2E37338", Offset = "0x2E37338", VA = "0x2E37338")]
	public void \u05F8ڛߠ\u05BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Bruh i cannot go here you stupid L bozo";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x060023A0 RID: 9120 RVA: 0x000BBCF0 File Offset: 0x000B9EF0
	[Token(Token = "0x60023A0")]
	[Address(RVA = "0x2E373C4", Offset = "0x2E373C4", VA = "0x2E373C4")]
	public void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "got funky mone";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060023A1 RID: 9121 RVA: 0x000BBD2C File Offset: 0x000B9F2C
	[Token(Token = "0x60023A1")]
	[Address(RVA = "0x2E37454", Offset = "0x2E37454", VA = "0x2E37454")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Damaged Arm";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060023A2 RID: 9122 RVA: 0x000BBD68 File Offset: 0x000B9F68
	[Token(Token = "0x60023A2")]
	[Address(RVA = "0x2E374E4", Offset = "0x2E374E4", VA = "0x2E374E4")]
	public void ڗࢭ\u058D\u0733(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x060023A3 RID: 9123 RVA: 0x000BBD98 File Offset: 0x000B9F98
	[Token(Token = "0x60023A3")]
	[Address(RVA = "0x2E37570", Offset = "0x2E37570", VA = "0x2E37570")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "{0} ({1})";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x060023A4 RID: 9124 RVA: 0x000BBDC8 File Offset: 0x000B9FC8
	[Token(Token = "0x60023A4")]
	[Address(RVA = "0x2E375FC", Offset = "0x2E375FC", VA = "0x2E375FC")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060023A5 RID: 9125 RVA: 0x000BBE04 File Offset: 0x000BA004
	[Token(Token = "0x60023A5")]
	[Address(RVA = "0x2E3768C", Offset = "0x2E3768C", VA = "0x2E3768C")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Combine textures & build combined mesh all at once";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060023A6 RID: 9126 RVA: 0x000BBE40 File Offset: 0x000BA040
	[Token(Token = "0x60023A6")]
	[Address(RVA = "0x2E3771C", Offset = "0x2E3771C", VA = "0x2E3771C")]
	public void پ\u05F7\u06E6ރ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060023A7 RID: 9127 RVA: 0x000BBE70 File Offset: 0x000BA070
	[Token(Token = "0x60023A7")]
	[Address(RVA = "0x2E377AC", Offset = "0x2E377AC", VA = "0x2E377AC")]
	public void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "NetworkPlayer";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060023A8 RID: 9128 RVA: 0x000BBEAC File Offset: 0x000BA0AC
	[Token(Token = "0x60023A8")]
	[Address(RVA = "0x2E3783C", Offset = "0x2E3783C", VA = "0x2E3783C")]
	public void \u086D\u089AԾ\u0881(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HorrorAgreement";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x060023A9 RID: 9129 RVA: 0x000BBEDC File Offset: 0x000BA0DC
	[Token(Token = "0x60023A9")]
	[Address(RVA = "0x2E378C8", Offset = "0x2E378C8", VA = "0x2E378C8")]
	public void ىރ\u0704ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060023AA RID: 9130 RVA: 0x000BBF18 File Offset: 0x000BA118
	[Token(Token = "0x60023AA")]
	[Address(RVA = "0x2E37958", Offset = "0x2E37958", VA = "0x2E37958")]
	public void әݓ\u0610ժ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Skelechin";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
		long ٽ_u0886ࡠԢ = 1L;
		u0558_u0654ڄ_u087E.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
	}

	// Token: 0x060023AB RID: 9131 RVA: 0x000BBF54 File Offset: 0x000BA154
	[Token(Token = "0x60023AB")]
	[Address(RVA = "0x2E379E8", Offset = "0x2E379E8", VA = "0x2E379E8")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		DoorLerp u0558_u0654ڄ_u087E = this.\u0558\u0654ڄ\u087E;
	}

	// Token: 0x04000479 RID: 1145
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000479")]
	public DoorLerp \u0558\u0654ڄ\u087E;
}
