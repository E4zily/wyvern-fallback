﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000021 RID: 33
[Token(Token = "0x2000021")]
public class PhysicsHand : MonoBehaviour
{
	// Token: 0x060003F8 RID: 1016 RVA: 0x00017310 File Offset: 0x00015510
	[Token(Token = "0x60003F8")]
	[Address(RVA = "0x2EB3464", Offset = "0x2EB3464", VA = "0x2EB3464")]
	private void \u0835\u0872ܕ\u0740(Collision \u07FEל\u05AC\u0877)
	{
		long ٿ_u088Cފ_u = 1L;
		this.ٿ\u088Cފ\u0736 = (ٿ_u088Cފ_u != 0L);
	}

	// Token: 0x060003F9 RID: 1017 RVA: 0x00017328 File Offset: 0x00015528
	[Token(Token = "0x60003F9")]
	[Address(RVA = "0x2EB3470", Offset = "0x2EB3470", VA = "0x2EB3470")]
	public IEnumerator \u05C4\u07F9\u0598ي()
	{
		long <>1__state;
		PhysicsHand.ࢯԙࢯ\u0607 ࢯԙࢯ_u = new PhysicsHand.ࢯԙࢯ\u0607((int)<>1__state);
		<>1__state = 1L;
		ࢯԙࢯ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003FA RID: 1018 RVA: 0x0001734C File Offset: 0x0001554C
	[Token(Token = "0x60003FA")]
	[Address(RVA = "0x2EB34E8", Offset = "0x2EB34E8", VA = "0x2EB34E8")]
	private float ڱڣ\u0819\u05AD()
	{
		Vector3 localPosition = this.target.localPosition;
		float z = this.߉\u061F\u0557\u07F8.z;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x060003FB RID: 1019 RVA: 0x0001738C File Offset: 0x0001558C
	[Token(Token = "0x60003FB")]
	[Address(RVA = "0x2EB35B8", Offset = "0x2EB35B8", VA = "0x2EB35B8")]
	private void FixedUpdate()
	{
		if (!this.\u088B\u070Dל١)
		{
			Transform transform = this.ԯ\u0615ࡣ\u0895.transform;
			Vector3 position = this.target.position;
			return;
		}
		this.ץ\u073Fߙ\u070E();
		this.ޜފ\u06E0ە();
		if (this.ٿ\u088Cފ\u0736)
		{
			this.ڗ߈ޓ߉();
			return;
		}
	}

	// Token: 0x060003FC RID: 1020 RVA: 0x000173DC File Offset: 0x000155DC
	[Token(Token = "0x60003FC")]
	[Address(RVA = "0x2EB3B18", Offset = "0x2EB3B18", VA = "0x2EB3B18")]
	public IEnumerator \u05F3Ӓ۰Ԃ()
	{
		long <>1__state;
		PhysicsHand.ࢯԙࢯ\u0607 ࢯԙࢯ_u = new PhysicsHand.ࢯԙࢯ\u0607((int)<>1__state);
		<>1__state = 0L;
		ࢯԙࢯ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003FD RID: 1021 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60003FD")]
	[Address(RVA = "0x2EB3B90", Offset = "0x2EB3B90", VA = "0x2EB3B90")]
	private void ࢻԩڪࡐ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060003FE RID: 1022 RVA: 0x00017400 File Offset: 0x00015600
	[Token(Token = "0x60003FE")]
	[Address(RVA = "0x2EB3D50", Offset = "0x2EB3D50", VA = "0x2EB3D50")]
	public IEnumerator \u073E\u05B1ݓ\u0640()
	{
		long <>1__state;
		PhysicsHand.ࢯԙࢯ\u0607 ࢯԙࢯ_u = new PhysicsHand.ࢯԙࢯ\u0607((int)<>1__state);
		<>1__state = 0L;
		ࢯԙࢯ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003FF RID: 1023 RVA: 0x00017424 File Offset: 0x00015624
	[Token(Token = "0x60003FF")]
	[Address(RVA = "0x2EB3DC8", Offset = "0x2EB3DC8", VA = "0x2EB3DC8")]
	private void רՋ\u060Fݹ(Collision \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		object obj = pcmreaderCallback2.m_target;
		this.\u0617\u087Fտߎ.Play();
		IntPtr invoke_impl = pcmreaderCallback2.invoke_impl;
	}

	// Token: 0x06000400 RID: 1024 RVA: 0x00017528 File Offset: 0x00015728
	[Token(Token = "0x6000400")]
	[Address(RVA = "0x2EB3FE0", Offset = "0x2EB3FE0", VA = "0x2EB3FE0")]
	private void \u07ABࢷ\u07F1\u0597()
	{
		float num = this.rotfrequency;
		float num2 = this.rotDamping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Quaternion rotation = this.target.rotation;
		Quaternion rotation2 = base.transform.rotation;
		Vector3 angularVelocity = this.ԯ\u0615ࡣ\u0895.angularVelocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x06000401 RID: 1025 RVA: 0x000175A4 File Offset: 0x000157A4
	[Token(Token = "0x6000401")]
	[Address(RVA = "0x2EB4228", Offset = "0x2EB4228", VA = "0x2EB4228")]
	public IEnumerator ܚԑ\u05ECӑ()
	{
		long <>1__state;
		PhysicsHand.ࢯԙࢯ\u0607 ࢯԙࢯ_u = new PhysicsHand.ࢯԙࢯ\u0607((int)<>1__state);
		<>1__state = 0L;
		ࢯԙࢯ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000402 RID: 1026 RVA: 0x000175C8 File Offset: 0x000157C8
	[Token(Token = "0x6000402")]
	[Address(RVA = "0x2EB42A0", Offset = "0x2EB42A0", VA = "0x2EB42A0")]
	private void ݱ\u0832ݥ\u08B5()
	{
		Transform transform = base.transform;
		Vector3 position = this.target.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.target.rotation;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.ԯ\u0615ࡣ\u0895 = component;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
		Vector3 position2 = base.transform.position;
	}

	// Token: 0x06000403 RID: 1027 RVA: 0x00017628 File Offset: 0x00015828
	[Token(Token = "0x6000403")]
	[Address(RVA = "0x2EB43A4", Offset = "0x2EB43A4", VA = "0x2EB43A4")]
	private void \u0829\u066BԺ\u07B0()
	{
		float num = this.frequency;
		float num2 = this.damping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Vector3 position = this.target.position;
		Vector3 position2 = base.transform.position;
		Vector3 velocity = this.playerRigidbody.velocity;
		Vector3 velocity2 = this.ԯ\u0615ࡣ\u0895.velocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x000176AC File Offset: 0x000158AC
	[Token(Token = "0x6000404")]
	[Address(RVA = "0x2EB4560", Offset = "0x2EB4560", VA = "0x2EB4560")]
	public IEnumerator ޟڕ\u0749ܟ()
	{
		long <>1__state;
		PhysicsHand.ࢯԙࢯ\u0607 ࢯԙࢯ_u = new PhysicsHand.ࢯԙࢯ\u0607((int)<>1__state);
		<>1__state = 0L;
		throw new NullReferenceException();
	}

	// Token: 0x06000405 RID: 1029 RVA: 0x000176C8 File Offset: 0x000158C8
	[Token(Token = "0x6000405")]
	[Address(RVA = "0x2EB45D8", Offset = "0x2EB45D8", VA = "0x2EB45D8")]
	private void ԙ\u05BCԸ\u05BD()
	{
		float num = this.rotfrequency;
		float num2 = this.rotDamping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Quaternion rotation = this.target.rotation;
		Quaternion rotation2 = base.transform.rotation;
		Vector3 angularVelocity = this.ԯ\u0615ࡣ\u0895.angularVelocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x06000406 RID: 1030 RVA: 0x00017744 File Offset: 0x00015944
	[Token(Token = "0x6000406")]
	[Address(RVA = "0x2EB481C", Offset = "0x2EB481C", VA = "0x2EB481C")]
	private void کמ\u05F9\u086C()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.target.position;
		float num = this.climbForce;
		float num2 = this.ݪӶ\u060F߃();
		if (this.\u088B\u070Dל١)
		{
			Rigidbody rigidbody = this.playerRigidbody;
			Vector3 velocity = this.playerRigidbody.velocity;
			float num3 = this.climbDrag;
			return;
		}
	}

	// Token: 0x06000407 RID: 1031 RVA: 0x000177A4 File Offset: 0x000159A4
	[Token(Token = "0x6000407")]
	[Address(RVA = "0x2EB4A24", Offset = "0x2EB4A24", VA = "0x2EB4A24")]
	private void OnCollisionEnter(Collision \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		object obj = pcmreaderCallback2.m_target;
		this.\u0617\u087Fտߎ.Play();
		IntPtr invoke_impl = pcmreaderCallback2.invoke_impl;
	}

	// Token: 0x06000408 RID: 1032 RVA: 0x000178A4 File Offset: 0x00015AA4
	[Token(Token = "0x6000408")]
	[Address(RVA = "0x2EB4C34", Offset = "0x2EB4C34", VA = "0x2EB4C34")]
	private void ݯ\u06ECێت(Collision \u07FEל\u05AC\u0877)
	{
	}

	// Token: 0x06000409 RID: 1033 RVA: 0x000178B4 File Offset: 0x00015AB4
	[Token(Token = "0x6000409")]
	[Address(RVA = "0x2EB4C3C", Offset = "0x2EB4C3C", VA = "0x2EB4C3C")]
	private float \u0616\u06E2ӈࡕ()
	{
		Vector3 localPosition = this.target.localPosition;
		float z = this.߉\u061F\u0557\u07F8.z;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x0600040A RID: 1034 RVA: 0x000178F4 File Offset: 0x00015AF4
	[Token(Token = "0x600040A")]
	[Address(RVA = "0x2EB4D28", Offset = "0x2EB4D28", VA = "0x2EB4D28")]
	private void ڱ\u0614ݻ\u0819(Collision \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		object obj = pcmreaderCallback2.m_target;
		u0617_u087Fտߎ.Play();
		IntPtr invoke_impl = pcmreaderCallback2.invoke_impl;
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x00017A00 File Offset: 0x00015C00
	[Token(Token = "0x600040B")]
	[Address(RVA = "0x2EB510C", Offset = "0x2EB510C", VA = "0x2EB510C")]
	private float ըֆҾۅ()
	{
		Vector3 localPosition = this.target.localPosition;
		float z = this.߉\u061F\u0557\u07F8.z;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x00017A40 File Offset: 0x00015C40
	[Token(Token = "0x600040C")]
	[Address(RVA = "0x2EB51FC", Offset = "0x2EB51FC", VA = "0x2EB51FC")]
	private void ࡅݐ\u082Dք()
	{
		Transform transform = base.transform;
		Vector3 position = this.target.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.target.rotation;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.ԯ\u0615ࡣ\u0895 = component;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
		Vector3 position2 = base.transform.position;
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x00017AA0 File Offset: 0x00015CA0
	[Token(Token = "0x600040D")]
	[Address(RVA = "0x2EB5300", Offset = "0x2EB5300", VA = "0x2EB5300")]
	private void \u0883ދ\u066C\u0859()
	{
		if (!this.\u088B\u070Dל١)
		{
			Transform transform = this.ԯ\u0615ࡣ\u0895.transform;
			Vector3 position = this.target.position;
			return;
		}
		this.\u083E\u05FC\u0893ծ();
		this.آ\u0881ޅٶ();
		if (this.ٿ\u088Cފ\u0736)
		{
			this.ڗ߈ޓ߉();
			return;
		}
	}

	// Token: 0x0600040E RID: 1038 RVA: 0x00017AF0 File Offset: 0x00015CF0
	[Token(Token = "0x600040E")]
	[Address(RVA = "0x2EB5790", Offset = "0x2EB5790", VA = "0x2EB5790")]
	private void OnCollisionExit(Collision \u07FEל\u05AC\u0877)
	{
	}

	// Token: 0x0600040F RID: 1039 RVA: 0x00017B00 File Offset: 0x00015D00
	[Token(Token = "0x600040F")]
	[Address(RVA = "0x2EB5798", Offset = "0x2EB5798", VA = "0x2EB5798")]
	private void հލԷ\u05F7()
	{
		float num = this.frequency;
		float num2 = this.damping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Vector3 position = this.target.position;
		Vector3 position2 = base.transform.position;
		Vector3 velocity = this.playerRigidbody.velocity;
		Vector3 velocity2 = this.ԯ\u0615ࡣ\u0895.velocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x06000410 RID: 1040 RVA: 0x00017B84 File Offset: 0x00015D84
	[Token(Token = "0x6000410")]
	[Address(RVA = "0x2EB5958", Offset = "0x2EB5958", VA = "0x2EB5958")]
	private void Start()
	{
		Transform transform = base.transform;
		Vector3 position = this.target.position;
		Transform transform2 = base.transform;
		Transform transform3 = this.target;
		Quaternion rotation = transform2.rotation;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.ԯ\u0615ࡣ\u0895 = component;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
		Vector3 position2 = base.transform.position;
	}

	// Token: 0x06000411 RID: 1041 RVA: 0x00017BE8 File Offset: 0x00015DE8
	[Token(Token = "0x6000411")]
	[Address(RVA = "0x2EB5A5C", Offset = "0x2EB5A5C", VA = "0x2EB5A5C")]
	public PhysicsHand()
	{
	}

	// Token: 0x06000412 RID: 1042 RVA: 0x00017C08 File Offset: 0x00015E08
	[Token(Token = "0x6000412")]
	[Address(RVA = "0x2EB5A84", Offset = "0x2EB5A84", VA = "0x2EB5A84")]
	private void ԡڂӡߓ(Collision \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioSource u0617_u087Fտߎ = this.\u0617\u087Fտߎ;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		object obj = pcmreaderCallback2.m_target;
		this.\u0617\u087Fտߎ.Play();
		IntPtr invoke_impl = pcmreaderCallback2.invoke_impl;
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000413")]
	[Address(RVA = "0x2EB5E64", Offset = "0x2EB5E64", VA = "0x2EB5E64")]
	private void غ\u0749ӕ\u05CD()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x00017D0C File Offset: 0x00015F0C
	[Token(Token = "0x6000414")]
	[Address(RVA = "0x2EB602C", Offset = "0x2EB602C", VA = "0x2EB602C")]
	private float өܥࠊ\u065B()
	{
		Vector3 localPosition = this.target.localPosition;
		float z = this.߉\u061F\u0557\u07F8.z;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x00017D4C File Offset: 0x00015F4C
	[Token(Token = "0x6000415")]
	[Address(RVA = "0x2EB611C", Offset = "0x2EB611C", VA = "0x2EB611C")]
	private void صࡡ\u06FE\u05CB(Collision \u07FEל\u05AC\u0877)
	{
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x00017D5C File Offset: 0x00015F5C
	[Token(Token = "0x6000416")]
	[Address(RVA = "0x2EB6124", Offset = "0x2EB6124", VA = "0x2EB6124")]
	public IEnumerator ێࢣ\u0876\u05C6()
	{
		long <>1__state;
		PhysicsHand.ࢯԙࢯ\u0607 ࢯԙࢯ_u = new PhysicsHand.ࢯԙࢯ\u0607((int)<>1__state);
		<>1__state = 0L;
		ࢯԙࢯ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x00017D80 File Offset: 0x00015F80
	[Token(Token = "0x6000417")]
	[Address(RVA = "0x2EB619C", Offset = "0x2EB619C", VA = "0x2EB619C")]
	private void Ԃۆ\u05A5\u07B0(Collision \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		AudioClip[] ٩_u05AD_u081C_u = this.٩\u05AD\u081C\u0821;
		AudioClip.PCMReaderCallback pcmreaderCallback = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		AudioClip.PCMReaderCallback pcmreaderCallback2 = ٩_u05AD_u081C_u.m_PCMReaderCallback;
		object obj = pcmreaderCallback2.m_target;
		this.\u0617\u087Fտߎ.Play();
		IntPtr invoke_impl = pcmreaderCallback2.invoke_impl;
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x00017E88 File Offset: 0x00016088
	[Token(Token = "0x6000418")]
	[Address(RVA = "0x2EB6580", Offset = "0x2EB6580", VA = "0x2EB6580")]
	private void Ծ\u0870\u087FԹ()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.target.position;
		float num = this.climbForce;
		float num2 = this.\u0616\u06E2ӈࡕ();
		if (this.\u088B\u070Dל١)
		{
			Rigidbody rigidbody = this.playerRigidbody;
			Vector3 velocity = this.playerRigidbody.velocity;
			float num3 = this.climbDrag;
			return;
		}
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x00017EE8 File Offset: 0x000160E8
	[Token(Token = "0x6000419")]
	[Address(RVA = "0x2EB5550", Offset = "0x2EB5550", VA = "0x2EB5550")]
	private void آ\u0881ޅٶ()
	{
		float num = this.rotfrequency;
		float num2 = this.rotDamping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Quaternion rotation = this.target.rotation;
		Quaternion rotation2 = base.transform.rotation;
		Vector3 angularVelocity = this.ԯ\u0615ࡣ\u0895.angularVelocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x00017F64 File Offset: 0x00016164
	[Token(Token = "0x600041A")]
	[Address(RVA = "0x2EB6698", Offset = "0x2EB6698", VA = "0x2EB6698")]
	private void ӄ\u05BBؠז()
	{
		float num = this.rotfrequency;
		float num2 = this.rotDamping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Quaternion rotation = this.target.rotation;
		Quaternion rotation2 = base.transform.rotation;
		Vector3 angularVelocity = this.ԯ\u0615ࡣ\u0895.angularVelocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x00017FE0 File Offset: 0x000161E0
	[Token(Token = "0x600041B")]
	[Address(RVA = "0x2EB3648", Offset = "0x2EB3648", VA = "0x2EB3648")]
	private void ץ\u073Fߙ\u070E()
	{
		float num = this.frequency;
		float num2 = this.damping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Vector3 position = this.target.position;
		Vector3 position2 = base.transform.position;
		Vector3 velocity = this.playerRigidbody.velocity;
		Vector3 velocity2 = this.ԯ\u0615ࡣ\u0895.velocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x00018064 File Offset: 0x00016264
	[Token(Token = "0x600041C")]
	[Address(RVA = "0x2EB3A00", Offset = "0x2EB3A00", VA = "0x2EB3A00")]
	private void ڗ߈ޓ߉()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.target.position;
		float num = this.climbForce;
		float num2 = this.ڱڣ\u0819\u05AD();
		if (this.\u088B\u070Dל١)
		{
			Rigidbody rigidbody = this.playerRigidbody;
			Vector3 velocity = this.playerRigidbody.velocity;
			float num3 = this.climbDrag;
			return;
		}
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x000180C4 File Offset: 0x000162C4
	[Token(Token = "0x600041D")]
	[Address(RVA = "0x2EB68DC", Offset = "0x2EB68DC", VA = "0x2EB68DC")]
	private void ݸԲ\u0616Ԫ()
	{
		Transform transform = base.transform;
		Vector3 position = this.target.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.target.rotation;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.ԯ\u0615ࡣ\u0895 = component;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
		Vector3 position2 = base.transform.position;
	}

	// Token: 0x0600041E RID: 1054 RVA: 0x00018124 File Offset: 0x00016324
	[Token(Token = "0x600041E")]
	[Address(RVA = "0x2EB69E0", Offset = "0x2EB69E0", VA = "0x2EB69E0")]
	public IEnumerator \u06DDࢫ\u06D8ޒ()
	{
		long <>1__state;
		PhysicsHand.ࢯԙࢯ\u0607 ࢯԙࢯ_u = new PhysicsHand.ࢯԙࢯ\u0607((int)<>1__state);
		<>1__state = 0L;
		ࢯԙࢯ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600041F RID: 1055 RVA: 0x00018148 File Offset: 0x00016348
	[Token(Token = "0x600041F")]
	[Address(RVA = "0x2EB4934", Offset = "0x2EB4934", VA = "0x2EB4934")]
	private float ݪӶ\u060F߃()
	{
		Vector3 localPosition = this.target.localPosition;
		float z = this.߉\u061F\u0557\u07F8.z;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x06000420 RID: 1056 RVA: 0x00018188 File Offset: 0x00016388
	[Token(Token = "0x6000420")]
	[Address(RVA = "0x2EB6A58", Offset = "0x2EB6A58", VA = "0x2EB6A58")]
	private void \u070Fߨ\u05B0ۈ()
	{
		Transform transform = base.transform;
		Vector3 position = this.target.position;
		Transform transform2 = base.transform;
		Transform transform3 = this.target;
		Quaternion rotation = transform2.rotation;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.ԯ\u0615ࡣ\u0895 = component;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
		Vector3 position2 = base.transform.position;
	}

	// Token: 0x06000421 RID: 1057 RVA: 0x000181EC File Offset: 0x000163EC
	[Token(Token = "0x6000421")]
	[Address(RVA = "0x2EB6B5C", Offset = "0x2EB6B5C", VA = "0x2EB6B5C")]
	private float թ\u0600ԫ\u0640()
	{
		Vector3 localPosition = this.target.localPosition;
		float z = this.߉\u061F\u0557\u07F8.z;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x06000422 RID: 1058 RVA: 0x0001822C File Offset: 0x0001642C
	[Token(Token = "0x6000422")]
	[Address(RVA = "0x2EB6C4C", Offset = "0x2EB6C4C", VA = "0x2EB6C4C")]
	private void ڷԟ\u087D\u05B9()
	{
		if (!this.\u088B\u070Dל١)
		{
			Transform transform = this.ԯ\u0615ࡣ\u0895.transform;
			Vector3 position = this.target.position;
			return;
		}
		this.հލԷ\u05F7();
		this.ޜފ\u06E0ە();
		if (this.ٿ\u088Cފ\u0736)
		{
			this.Ծ\u0870\u087FԹ();
			return;
		}
	}

	// Token: 0x06000423 RID: 1059 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000423")]
	[Address(RVA = "0x2EB5C9C", Offset = "0x2EB5C9C", VA = "0x2EB5C9C")]
	private void ڵݰӼ\u05CE()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000424 RID: 1060 RVA: 0x0001827C File Offset: 0x0001647C
	[Token(Token = "0x6000424")]
	[Address(RVA = "0x2EB6CDC", Offset = "0x2EB6CDC", VA = "0x2EB6CDC")]
	private void ݎۯ\u07EEߪ()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.target.position;
		float num = this.climbForce;
		float num2 = this.өܥࠊ\u065B();
		if (this.\u088B\u070Dל١)
		{
			Rigidbody rigidbody = this.playerRigidbody;
			Vector3 velocity = this.playerRigidbody.velocity;
			float num3 = this.climbDrag;
			return;
		}
	}

	// Token: 0x06000425 RID: 1061 RVA: 0x000182DC File Offset: 0x000164DC
	[Token(Token = "0x6000425")]
	[Address(RVA = "0x2EB6DF4", Offset = "0x2EB6DF4", VA = "0x2EB6DF4")]
	public IEnumerator \u0741ࡨܔݷ()
	{
		long <>1__state;
		PhysicsHand.ࢯԙࢯ\u0607 ࢯԙࢯ_u = new PhysicsHand.ࢯԙࢯ\u0607((int)<>1__state);
		<>1__state = 0L;
		ࢯԙࢯ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000426 RID: 1062 RVA: 0x00018300 File Offset: 0x00016500
	[Token(Token = "0x6000426")]
	[Address(RVA = "0x2EB6E6C", Offset = "0x2EB6E6C", VA = "0x2EB6E6C")]
	private void ם\u06FDւԋ()
	{
		if (!this.\u088B\u070Dל١)
		{
			Transform transform = this.ԯ\u0615ࡣ\u0895.transform;
			Vector3 position = this.target.position;
			return;
		}
		this.հލԷ\u05F7();
		this.ޜފ\u06E0ە();
		if (this.ٿ\u088Cފ\u0736)
		{
			this.ݎۯ\u07EEߪ();
			return;
		}
	}

	// Token: 0x06000427 RID: 1063 RVA: 0x00018350 File Offset: 0x00016550
	[Token(Token = "0x6000427")]
	[Address(RVA = "0x2EB6EFC", Offset = "0x2EB6EFC", VA = "0x2EB6EFC")]
	public IEnumerator \u0744\u06DFܒ\u082F()
	{
		long <>1__state;
		PhysicsHand.ࢯԙࢯ\u0607 ࢯԙࢯ_u = new PhysicsHand.ࢯԙࢯ\u0607((int)<>1__state);
		<>1__state = 0L;
		ࢯԙࢯ_u.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000428 RID: 1064 RVA: 0x00018374 File Offset: 0x00016574
	[Token(Token = "0x6000428")]
	[Address(RVA = "0x2EB37E4", Offset = "0x2EB37E4", VA = "0x2EB37E4")]
	private void ޜފ\u06E0ە()
	{
		float num = this.rotfrequency;
		float num2 = this.rotDamping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Quaternion rotation = this.target.rotation;
		Quaternion quaternion = Quaternion.Inverse(base.transform.rotation);
		Vector3 angularVelocity = this.ԯ\u0615ࡣ\u0895.angularVelocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x06000429 RID: 1065 RVA: 0x000183F4 File Offset: 0x000165F4
	[Token(Token = "0x6000429")]
	[Address(RVA = "0x2EB6F74", Offset = "0x2EB6F74", VA = "0x2EB6F74")]
	private void ӥԞֆ\u0655(Collision \u07FEל\u05AC\u0877)
	{
		long ٿ_u088Cފ_u = 1L;
		this.ٿ\u088Cފ\u0736 = (ٿ_u088Cފ_u != 0L);
	}

	// Token: 0x0600042A RID: 1066 RVA: 0x0001840C File Offset: 0x0001660C
	[Token(Token = "0x600042A")]
	[Address(RVA = "0x2EB6F80", Offset = "0x2EB6F80", VA = "0x2EB6F80")]
	private float ܔ\u060Eӳص()
	{
		Vector3 localPosition = this.target.localPosition;
		float z = this.߉\u061F\u0557\u07F8.z;
		float fixedDeltaTime = Time.fixedDeltaTime;
		throw new MissingMethodException();
	}

	// Token: 0x0600042B RID: 1067 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600042B")]
	[Address(RVA = "0x2EB4F44", Offset = "0x2EB4F44", VA = "0x2EB4F44")]
	private void \u05B8\u073EԹԖ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600042C RID: 1068 RVA: 0x00018454 File Offset: 0x00016654
	[Token(Token = "0x600042C")]
	[Address(RVA = "0x2EB7070", Offset = "0x2EB7070", VA = "0x2EB7070")]
	private void ގԇ\u06E8ܟ(Collision \u07FEל\u05AC\u0877)
	{
	}

	// Token: 0x0600042D RID: 1069 RVA: 0x00018464 File Offset: 0x00016664
	[Token(Token = "0x600042D")]
	[Address(RVA = "0x2EB7078", Offset = "0x2EB7078", VA = "0x2EB7078")]
	private void ࢢےݙӉ()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.target.position;
		float num = this.climbForce;
		float num2 = this.ըֆҾۅ();
		if (this.\u088B\u070Dל١)
		{
			Rigidbody rigidbody = this.playerRigidbody;
			Vector3 velocity = this.playerRigidbody.velocity;
			float num3 = this.climbDrag;
			return;
		}
	}

	// Token: 0x0600042E RID: 1070 RVA: 0x000184C4 File Offset: 0x000166C4
	[Token(Token = "0x600042E")]
	[Address(RVA = "0x2EB7190", Offset = "0x2EB7190", VA = "0x2EB7190")]
	private void օ\u0744ܟۋ()
	{
		float num = this.frequency;
		float num2 = this.damping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Vector3 position = this.target.position;
		Vector3 position2 = base.transform.position;
		Vector3 velocity = this.playerRigidbody.velocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x0600042F RID: 1071 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600042F")]
	[Address(RVA = "0x2EB63B8", Offset = "0x2EB63B8", VA = "0x2EB63B8")]
	private void ثࡑڠ\u073A()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000430 RID: 1072 RVA: 0x0001853C File Offset: 0x0001673C
	[Token(Token = "0x6000430")]
	[Address(RVA = "0x2EB5390", Offset = "0x2EB5390", VA = "0x2EB5390")]
	private void \u083E\u05FC\u0893ծ()
	{
		float num = this.frequency;
		float num2 = this.damping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Vector3 position = this.target.position;
		Vector3 position2 = base.transform.position;
		Vector3 velocity = this.playerRigidbody.velocity;
		Vector3 velocity2 = this.ԯ\u0615ࡣ\u0895.velocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x06000431 RID: 1073 RVA: 0x000185C0 File Offset: 0x000167C0
	[Token(Token = "0x6000431")]
	[Address(RVA = "0x2EB7350", Offset = "0x2EB7350", VA = "0x2EB7350")]
	private void նޔבӓ()
	{
		float num = this.rotfrequency;
		float num2 = this.rotDamping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Quaternion rotation = this.target.rotation;
		Quaternion rotation2 = base.transform.rotation;
		Vector3 angularVelocity = this.ԯ\u0615ࡣ\u0895.angularVelocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x06000432 RID: 1074 RVA: 0x0001863C File Offset: 0x0001683C
	[Token(Token = "0x6000432")]
	[Address(RVA = "0x2EB7598", Offset = "0x2EB7598", VA = "0x2EB7598")]
	private void \u07BBڱ\u0878߃()
	{
		float num = this.frequency;
		float num2 = this.damping;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Vector3 position = this.target.position;
		Vector3 position2 = base.transform.position;
		Vector3 velocity = this.playerRigidbody.velocity;
		Vector3 velocity2 = this.ԯ\u0615ࡣ\u0895.velocity;
		Rigidbody ԯ_u0615ࡣ_u = this.ԯ\u0615ࡣ\u0895;
	}

	// Token: 0x0400008C RID: 140
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400008C")]
	[SerializeField]
	[Header("PID")]
	private float frequency;

	// Token: 0x0400008D RID: 141
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x400008D")]
	[SerializeField]
	private float damping;

	// Token: 0x0400008E RID: 142
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400008E")]
	[SerializeField]
	private float rotfrequency;

	// Token: 0x0400008F RID: 143
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x400008F")]
	[SerializeField]
	private float rotDamping;

	// Token: 0x04000090 RID: 144
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000090")]
	[SerializeField]
	private Rigidbody playerRigidbody;

	// Token: 0x04000091 RID: 145
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000091")]
	[SerializeField]
	private Transform target;

	// Token: 0x04000092 RID: 146
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000092")]
	[SerializeField]
	private Rigidbody Hand;

	// Token: 0x04000093 RID: 147
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000093")]
	[SerializeField]
	private float hitAmount;

	// Token: 0x04000094 RID: 148
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000094")]
	[Space]
	[SerializeField]
	[Header("Springs")]
	private float climbForce;

	// Token: 0x04000095 RID: 149
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000095")]
	[SerializeField]
	private float climbDrag;

	// Token: 0x04000096 RID: 150
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000096")]
	public AudioClip[] ݭܬࡓݒ;

	// Token: 0x04000097 RID: 151
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000097")]
	public AudioClip[] ٩\u05AD\u081C\u0821;

	// Token: 0x04000098 RID: 152
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000098")]
	public AudioClip[] Ժ\u05CD\u0882\u05AF;

	// Token: 0x04000099 RID: 153
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000099")]
	public AudioClip[] \u059B\u070B\u07BFߌ;

	// Token: 0x0400009A RID: 154
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x400009A")]
	public AudioSource \u0617\u087Fտߎ;

	// Token: 0x0400009B RID: 155
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x400009B")]
	public AudioClip[] \u0891ԽޓԾ;

	// Token: 0x0400009C RID: 156
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x400009C")]
	public AudioClip[] \u05B5\u07B8ܞٳ;

	// Token: 0x0400009D RID: 157
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x400009D")]
	public AudioClip[] ދӫӏݛ;

	// Token: 0x0400009E RID: 158
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x400009E")]
	public AudioClip[] \u05FCއܖԽ;

	// Token: 0x0400009F RID: 159
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x400009F")]
	public AudioClip[] ߢ\u0603\u085A\u05B0;

	// Token: 0x040000A0 RID: 160
	[FieldOffset(Offset = "0xA0")]
	[Token(Token = "0x40000A0")]
	public AudioClip[] \u058Aࡊ\u06EDܕ;

	// Token: 0x040000A1 RID: 161
	[FieldOffset(Offset = "0xA8")]
	[Token(Token = "0x40000A1")]
	private bool \u07EEݩڏࠉ = 257 != 0;

	// Token: 0x040000A2 RID: 162
	[FieldOffset(Offset = "0xA9")]
	[Token(Token = "0x40000A2")]
	private bool \u088B\u070Dל١;

	// Token: 0x040000A3 RID: 163
	[FieldOffset(Offset = "0xAC")]
	[Token(Token = "0x40000A3")]
	private Vector3 ߉\u061F\u0557\u07F8;

	// Token: 0x040000A4 RID: 164
	[FieldOffset(Offset = "0xB8")]
	[Token(Token = "0x40000A4")]
	private Rigidbody ԯ\u0615ࡣ\u0895;

	// Token: 0x040000A5 RID: 165
	[FieldOffset(Offset = "0xC0")]
	[Token(Token = "0x40000A5")]
	private bool ٿ\u088Cފ\u0736;

	// Token: 0x040000A6 RID: 166
	[FieldOffset(Offset = "0xC1")]
	[Token(Token = "0x40000A6")]
	public bool \u089Bݼۄ\u0875;
}
