﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020000BD RID: 189
[Token(Token = "0x20000BD")]
public class GrabbableBanana : MonoBehaviour
{
	// Token: 0x06001BF8 RID: 7160 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001BF8")]
	[Address(RVA = "0x2E6EE50", Offset = "0x2E6EE50", VA = "0x2E6EE50")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BF9 RID: 7161 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001BF9")]
	[Address(RVA = "0x2E6F168", Offset = "0x2E6F168", VA = "0x2E6F168")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BFA RID: 7162 RVA: 0x00091F40 File Offset: 0x00090140
	[Token(Token = "0x6001BFA")]
	[Address(RVA = "0x2E6F480", Offset = "0x2E6F480", VA = "0x2E6F480")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Try Connect To Server...");
	}

	// Token: 0x06001BFB RID: 7163 RVA: 0x00091F70 File Offset: 0x00090170
	[Token(Token = "0x6001BFB")]
	[Address(RVA = "0x2E6F52C", Offset = "0x2E6F52C", VA = "0x2E6F52C")]
	public void \u0619طӍ\u083D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Open");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001BFC RID: 7164 RVA: 0x00091FA0 File Offset: 0x000901A0
	[Token(Token = "0x6001BFC")]
	[Address(RVA = "0x2E6F5AC", Offset = "0x2E6F5AC", VA = "0x2E6F5AC")]
	public void ࢳ\u06D8Ԙ\u05FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("HandL");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001BFD RID: 7165 RVA: 0x00091FD0 File Offset: 0x000901D0
	[Token(Token = "0x6001BFD")]
	[Address(RVA = "0x2E6F62C", Offset = "0x2E6F62C", VA = "0x2E6F62C")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayNoise");
	}

	// Token: 0x06001BFE RID: 7166 RVA: 0x00092000 File Offset: 0x00090200
	[Token(Token = "0x6001BFE")]
	[Address(RVA = "0x2E6F6D8", Offset = "0x2E6F6D8", VA = "0x2E6F6D8")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ORGPORT");
	}

	// Token: 0x06001BFF RID: 7167 RVA: 0x00092030 File Offset: 0x00090230
	[Token(Token = "0x6001BFF")]
	[Address(RVA = "0x2E6F784", Offset = "0x2E6F784", VA = "0x2E6F784")]
	public void Ӛ\u055D\u0651Խ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Updating Material to: ");
	}

	// Token: 0x06001C00 RID: 7168 RVA: 0x00092054 File Offset: 0x00090254
	[Token(Token = "0x6001C00")]
	[Address(RVA = "0x2E6F800", Offset = "0x2E6F800", VA = "0x2E6F800")]
	public void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C01 RID: 7169 RVA: 0x00092084 File Offset: 0x00090284
	[Token(Token = "0x6001C01")]
	[Address(RVA = "0x2E6F880", Offset = "0x2E6F880", VA = "0x2E6F880")]
	public void ӳڣܟޖ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("\n Time: ");
	}

	// Token: 0x06001C02 RID: 7170 RVA: 0x000920A8 File Offset: 0x000902A8
	[Token(Token = "0x6001C02")]
	[Address(RVA = "0x2E6F8FC", Offset = "0x2E6F8FC", VA = "0x2E6F8FC")]
	public void \u086D\u089AԾ\u0881(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C03 RID: 7171 RVA: 0x000920CC File Offset: 0x000902CC
	[Token(Token = "0x6001C03")]
	[Address(RVA = "0x2E6F97C", Offset = "0x2E6F97C", VA = "0x2E6F97C")]
	public void \u07B2߆Ժࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Cheating");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C04 RID: 7172 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001C04")]
	[Address(RVA = "0x2E6F9FC", Offset = "0x2E6F9FC", VA = "0x2E6F9FC")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C05 RID: 7173 RVA: 0x000920FC File Offset: 0x000902FC
	[Token(Token = "0x6001C05")]
	[Address(RVA = "0x2E6FD14", Offset = "0x2E6FD14", VA = "0x2E6FD14")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Failed to login, please restart");
	}

	// Token: 0x06001C06 RID: 7174 RVA: 0x0009212C File Offset: 0x0009032C
	[Token(Token = "0x6001C06")]
	[Address(RVA = "0x2E6FDC0", Offset = "0x2E6FDC0", VA = "0x2E6FDC0")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("Time to bake textures: ");
	}

	// Token: 0x06001C07 RID: 7175 RVA: 0x0009214C File Offset: 0x0009034C
	[Token(Token = "0x6001C07")]
	[Address(RVA = "0x2E6FE6C", Offset = "0x2E6FE6C", VA = "0x2E6FE6C")]
	public void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C08 RID: 7176 RVA: 0x0009217C File Offset: 0x0009037C
	[Token(Token = "0x6001C08")]
	[Address(RVA = "0x2E6FEEC", Offset = "0x2E6FEEC", VA = "0x2E6FEEC")]
	public void ܯר\u05C7ڗ(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Key");
	}

	// Token: 0x06001C09 RID: 7177 RVA: 0x000921AC File Offset: 0x000903AC
	[Token(Token = "0x6001C09")]
	[Address(RVA = "0x2E6FF98", Offset = "0x2E6FF98", VA = "0x2E6FF98")]
	public GrabbableBanana()
	{
	}

	// Token: 0x06001C0A RID: 7178 RVA: 0x000921C0 File Offset: 0x000903C0
	[Token(Token = "0x6001C0A")]
	[Address(RVA = "0x2E6FFA0", Offset = "0x2E6FFA0", VA = "0x2E6FFA0")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeToTagged");
	}

	// Token: 0x06001C0B RID: 7179 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001C0B")]
	[Address(RVA = "0x2E7004C", Offset = "0x2E7004C", VA = "0x2E7004C")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C0C RID: 7180 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001C0C")]
	[Address(RVA = "0x2E70364", Offset = "0x2E70364", VA = "0x2E70364")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C0D RID: 7181 RVA: 0x000921F0 File Offset: 0x000903F0
	[Token(Token = "0x6001C0D")]
	[Address(RVA = "0x2E7067C", Offset = "0x2E7067C", VA = "0x2E7067C")]
	public void \u05F8ڛߠ\u05BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("\tExpires: ");
	}

	// Token: 0x06001C0E RID: 7182 RVA: 0x00092214 File Offset: 0x00090414
	[Token(Token = "0x6001C0E")]
	[Address(RVA = "0x2E706F8", Offset = "0x2E706F8", VA = "0x2E706F8")]
	public void \u05A0ڵ\u0823ڈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_WobbleX");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C0F RID: 7183 RVA: 0x00092244 File Offset: 0x00090444
	[Token(Token = "0x6001C0F")]
	[Address(RVA = "0x2E70778", Offset = "0x2E70778", VA = "0x2E70778")]
	public void \u06E9\u0740մ\u0746(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C10 RID: 7184 RVA: 0x00092274 File Offset: 0x00090474
	[Token(Token = "0x6001C10")]
	[Address(RVA = "0x2E707F8", Offset = "0x2E707F8", VA = "0x2E707F8")]
	public void ݼڔ\u05CE\u0899(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("closeToObject");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C11 RID: 7185 RVA: 0x000922A4 File Offset: 0x000904A4
	[Token(Token = "0x6001C11")]
	[Address(RVA = "0x2E70878", Offset = "0x2E70878", VA = "0x2E70878")]
	public void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("tutorialCheck");
	}

	// Token: 0x06001C12 RID: 7186 RVA: 0x000922C8 File Offset: 0x000904C8
	[Token(Token = "0x6001C12")]
	[Address(RVA = "0x2E70924", Offset = "0x2E70924", VA = "0x2E70924")]
	public void \u06E2ڇ\u07BF߃(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
	}

	// Token: 0x06001C13 RID: 7187 RVA: 0x000922EC File Offset: 0x000904EC
	[Token(Token = "0x6001C13")]
	[Address(RVA = "0x2E709A0", Offset = "0x2E709A0", VA = "0x2E709A0")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("KeyPos");
	}

	// Token: 0x06001C14 RID: 7188 RVA: 0x0009231C File Offset: 0x0009051C
	[Token(Token = "0x6001C14")]
	[Address(RVA = "0x2E70A4C", Offset = "0x2E70A4C", VA = "0x2E70A4C")]
	public void Պ\u07F7\u066AՅ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("hh:mm:sstt");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C15 RID: 7189 RVA: 0x0009234C File Offset: 0x0009054C
	[Token(Token = "0x6001C15")]
	[Address(RVA = "0x2E70ACC", Offset = "0x2E70ACC", VA = "0x2E70ACC")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Name Changing Error. Error: ");
	}

	// Token: 0x06001C16 RID: 7190 RVA: 0x0009237C File Offset: 0x0009057C
	[Token(Token = "0x6001C16")]
	[Address(RVA = "0x2E70B78", Offset = "0x2E70B78", VA = "0x2E70B78")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PRESS AGAIN TO CONFIRM");
	}

	// Token: 0x06001C17 RID: 7191 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001C17")]
	[Address(RVA = "0x2E70C24", Offset = "0x2E70C24", VA = "0x2E70C24")]
	public void سࡕԞ߆(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C18 RID: 7192 RVA: 0x000923AC File Offset: 0x000905AC
	[Token(Token = "0x6001C18")]
	[Address(RVA = "0x2E70F3C", Offset = "0x2E70F3C", VA = "0x2E70F3C")]
	public void \u06DEӸԏ\u07BF(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C19 RID: 7193 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001C19")]
	[Address(RVA = "0x2E70FBC", Offset = "0x2E70FBC", VA = "0x2E70FBC")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C1A RID: 7194 RVA: 0x000923DC File Offset: 0x000905DC
	[Token(Token = "0x6001C1A")]
	[Address(RVA = "0x2E712D4", Offset = "0x2E712D4", VA = "0x2E712D4")]
	public void ࢦ\u073Aӟࡆ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
	}

	// Token: 0x06001C1B RID: 7195 RVA: 0x00092400 File Offset: 0x00090600
	[Token(Token = "0x6001C1B")]
	[Address(RVA = "0x2E71350", Offset = "0x2E71350", VA = "0x2E71350")]
	public void \u07B3\u07BD\u05FF\u0859(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("\n");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C1C RID: 7196 RVA: 0x00092430 File Offset: 0x00090630
	[Token(Token = "0x6001C1C")]
	[Address(RVA = "0x2E713D0", Offset = "0x2E713D0", VA = "0x2E713D0")]
	public void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("isLava");
	}

	// Token: 0x06001C1D RID: 7197 RVA: 0x00092454 File Offset: 0x00090654
	[Token(Token = "0x6001C1D")]
	[Address(RVA = "0x2E7144C", Offset = "0x2E7144C", VA = "0x2E7144C")]
	public void ԁؼՖռ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C1E RID: 7198 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001C1E")]
	[Address(RVA = "0x2E714CC", Offset = "0x2E714CC", VA = "0x2E714CC")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C1F RID: 7199 RVA: 0x00092478 File Offset: 0x00090678
	[Token(Token = "0x6001C1F")]
	[Address(RVA = "0x2E717E4", Offset = "0x2E717E4", VA = "0x2E717E4")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("TurnAmount");
	}

	// Token: 0x06001C20 RID: 7200 RVA: 0x000924A8 File Offset: 0x000906A8
	[Token(Token = "0x6001C20")]
	[Address(RVA = "0x2E71890", Offset = "0x2E71890", VA = "0x2E71890")]
	public void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Toxicity");
		this.ڏݼ\u06E4ؿ = ("Toxicity" != null);
	}

	// Token: 0x06001C21 RID: 7201 RVA: 0x000924D8 File Offset: 0x000906D8
	[Token(Token = "0x6001C21")]
	[Address(RVA = "0x2E71910", Offset = "0x2E71910", VA = "0x2E71910")]
	public void قԙ\u0653պ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("amongus");
	}

	// Token: 0x06001C22 RID: 7202 RVA: 0x000924FC File Offset: 0x000906FC
	[Token(Token = "0x6001C22")]
	[Address(RVA = "0x2E7198C", Offset = "0x2E7198C", VA = "0x2E7198C")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Mesh");
	}

	// Token: 0x06001C23 RID: 7203 RVA: 0x0009252C File Offset: 0x0009072C
	[Token(Token = "0x6001C23")]
	[Address(RVA = "0x2E71A38", Offset = "0x2E71A38", VA = "0x2E71A38")]
	public void ڕ\u087Bա\u0893(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FLSPTLT");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C24 RID: 7204 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001C24")]
	[Address(RVA = "0x2E71AB8", Offset = "0x2E71AB8", VA = "0x2E71AB8")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C25 RID: 7205 RVA: 0x0009255C File Offset: 0x0009075C
	[Token(Token = "0x6001C25")]
	[Address(RVA = "0x2E71DD0", Offset = "0x2E71DD0", VA = "0x2E71DD0")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
	}

	// Token: 0x06001C26 RID: 7206 RVA: 0x00092580 File Offset: 0x00090780
	[Token(Token = "0x6001C26")]
	[Address(RVA = "0x2E71E4C", Offset = "0x2E71E4C", VA = "0x2E71E4C")]
	public void ލ\u0892\u064B\u055B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("RainAndThunderWeather");
	}

	// Token: 0x06001C27 RID: 7207 RVA: 0x000925A4 File Offset: 0x000907A4
	[Token(Token = "0x6001C27")]
	[Address(RVA = "0x2E71EC8", Offset = "0x2E71EC8", VA = "0x2E71EC8")]
	public void ࡅڑկئ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("User has been reported for: ");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C28 RID: 7208 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001C28")]
	[Address(RVA = "0x2E71F48", Offset = "0x2E71F48", VA = "0x2E71F48")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C29 RID: 7209 RVA: 0x000925D4 File Offset: 0x000907D4
	[Token(Token = "0x6001C29")]
	[Address(RVA = "0x2E72260", Offset = "0x2E72260", VA = "0x2E72260")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
	}

	// Token: 0x06001C2A RID: 7210 RVA: 0x00092604 File Offset: 0x00090804
	[Token(Token = "0x6001C2A")]
	[Address(RVA = "0x2E7230C", Offset = "0x2E7230C", VA = "0x2E7230C")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Not connected to room");
	}

	// Token: 0x06001C2B RID: 7211 RVA: 0x00092634 File Offset: 0x00090834
	[Token(Token = "0x6001C2B")]
	[Address(RVA = "0x2E723B8", Offset = "0x2E723B8", VA = "0x2E723B8")]
	public void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("NetworkPlayer");
	}

	// Token: 0x06001C2C RID: 7212 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001C2C")]
	[Address(RVA = "0x2E72434", Offset = "0x2E72434", VA = "0x2E72434")]
	public void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C2D RID: 7213 RVA: 0x00092658 File Offset: 0x00090858
	[Token(Token = "0x6001C2D")]
	[Address(RVA = "0x2E7274C", Offset = "0x2E7274C", VA = "0x2E7274C")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayerHead");
	}

	// Token: 0x06001C2E RID: 7214 RVA: 0x00092688 File Offset: 0x00090888
	[Token(Token = "0x6001C2E")]
	[Address(RVA = "0x2E727F8", Offset = "0x2E727F8", VA = "0x2E727F8")]
	public void \u0609ۯ\u05B4ؼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Charged!");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C2F RID: 7215 RVA: 0x000926B8 File Offset: 0x000908B8
	[Token(Token = "0x6001C2F")]
	[Address(RVA = "0x2E72878", Offset = "0x2E72878", VA = "0x2E72878")]
	public void \u0872יԁӦ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C30 RID: 7216 RVA: 0x000926DC File Offset: 0x000908DC
	[Token(Token = "0x6001C30")]
	[Address(RVA = "0x2E728F8", Offset = "0x2E728F8", VA = "0x2E728F8")]
	public void \u0879\u0748ߙݥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("tp 2");
	}

	// Token: 0x06001C31 RID: 7217 RVA: 0x00092700 File Offset: 0x00090900
	[Token(Token = "0x6001C31")]
	[Address(RVA = "0x2E72974", Offset = "0x2E72974", VA = "0x2E72974")]
	public void ք\u05FEؽ\u061E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Not connected to room");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C32 RID: 7218 RVA: 0x00092730 File Offset: 0x00090930
	[Token(Token = "0x6001C32")]
	[Address(RVA = "0x2E729F4", Offset = "0x2E729F4", VA = "0x2E729F4")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Failed To Join Public Room Successfully. The error is: ");
	}

	// Token: 0x06001C33 RID: 7219 RVA: 0x00092760 File Offset: 0x00090960
	[Token(Token = "0x6001C33")]
	[Address(RVA = "0x2E72AA0", Offset = "0x2E72AA0", VA = "0x2E72AA0")]
	public void \u0836Չװߟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
	}

	// Token: 0x06001C34 RID: 7220 RVA: 0x00092784 File Offset: 0x00090984
	[Token(Token = "0x6001C34")]
	[Address(RVA = "0x2E72B1C", Offset = "0x2E72B1C", VA = "0x2E72B1C")]
	public void \u085Cݯژ\u05FA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("true");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x06001C35 RID: 7221 RVA: 0x000927B4 File Offset: 0x000909B4
	[Token(Token = "0x6001C35")]
	[Address(RVA = "0x2E72B9C", Offset = "0x2E72B9C", VA = "0x2E72B9C")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Left a room");
	}

	// Token: 0x06001C36 RID: 7222 RVA: 0x000927E4 File Offset: 0x000909E4
	[Token(Token = "0x6001C36")]
	[Address(RVA = "0x2E72C48", Offset = "0x2E72C48", VA = "0x2E72C48")]
	public void \u07F3\u0876ߗ\u06FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("CapuchinStore");
		long ڏݼ_u06E4ؿ = 1L;
		this.ڏݼ\u06E4ؿ = (ڏݼ_u06E4ؿ != 0L);
	}

	// Token: 0x0400039F RID: 927
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400039F")]
	public bool Ծࢷ\u0608\u05FD;

	// Token: 0x040003A0 RID: 928
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x40003A0")]
	public bool \u05F7ܛ\u0820դ;

	// Token: 0x040003A1 RID: 929
	[FieldOffset(Offset = "0x1A")]
	[Token(Token = "0x40003A1")]
	public bool ثآࢯԽ;

	// Token: 0x040003A2 RID: 930
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003A2")]
	public GameObject \u0836\u07F3\u073FԠ;

	// Token: 0x040003A3 RID: 931
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003A3")]
	public GameObject Ԫԅו\u05AB;

	// Token: 0x040003A4 RID: 932
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003A4")]
	public GameObject ࢸࢺࡀؤ;

	// Token: 0x040003A5 RID: 933
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40003A5")]
	public bool ڏݼ\u06E4ؿ;

	// Token: 0x040003A6 RID: 934
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x40003A6")]
	public XRNode ࢳҾپݳ;
}
