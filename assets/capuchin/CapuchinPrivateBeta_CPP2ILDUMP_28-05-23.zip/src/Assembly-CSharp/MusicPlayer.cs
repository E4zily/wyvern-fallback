﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000088 RID: 136
[Token(Token = "0x2000088")]
public class MusicPlayer : MonoBehaviour
{
	// Token: 0x0600140D RID: 5133 RVA: 0x0007071C File Offset: 0x0006E91C
	[Token(Token = "0x600140D")]
	[Address(RVA = "0x23BCCEC", Offset = "0x23BCCEC", VA = "0x23BCCEC")]
	public void ԟ\u086Cޣ\u055E()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Joined Public Room Successfully");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ޤ\u058BӀކ();
	}

	// Token: 0x0600140E RID: 5134 RVA: 0x00070750 File Offset: 0x0006E950
	[Token(Token = "0x600140E")]
	[Address(RVA = "0x23BCE78", Offset = "0x23BCE78", VA = "0x23BCE78")]
	public void \u0838ӆڛӑ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("gravThing");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.\u05A3ࠍ\u05BEز();
	}

	// Token: 0x0600140F RID: 5135 RVA: 0x00070784 File Offset: 0x0006E984
	[Token(Token = "0x600140F")]
	[Address(RVA = "0x23BCFF0", Offset = "0x23BCFF0", VA = "0x23BCFF0")]
	public void Ӌ\u089C\u0700ܧ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Not connected to room");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.\u06DFԌաԭ();
	}

	// Token: 0x06001410 RID: 5136 RVA: 0x000707B8 File Offset: 0x0006E9B8
	[Token(Token = "0x6001410")]
	[Address(RVA = "0x23BD17C", Offset = "0x23BD17C", VA = "0x23BD17C")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("ENABLE");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ޝݬ\u070A\u0822();
	}

	// Token: 0x06001411 RID: 5137 RVA: 0x000707EC File Offset: 0x0006E9EC
	[Token(Token = "0x6001411")]
	[Address(RVA = "0x23BD2F0", Offset = "0x23BD2F0", VA = "0x23BD2F0")]
	public void \u0886Ҽ\u058Dߛ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("TurnAmount");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ޖՁث\u0708();
	}

	// Token: 0x06001412 RID: 5138 RVA: 0x00070820 File Offset: 0x0006EA20
	[Token(Token = "0x6001412")]
	[Address(RVA = "0x23BD464", Offset = "0x23BD464", VA = "0x23BD464")]
	public void \u0821Ԍ\u0822ߙ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x06001413 RID: 5139 RVA: 0x00070888 File Offset: 0x0006EA88
	[Token(Token = "0x6001413")]
	[Address(RVA = "0x23BD540", Offset = "0x23BD540", VA = "0x23BD540")]
	public void ݞ\u083Fݐށ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x06001414 RID: 5140 RVA: 0x000708D8 File Offset: 0x0006EAD8
	[Token(Token = "0x6001414")]
	[Address(RVA = "0x23BD5D8", Offset = "0x23BD5D8", VA = "0x23BD5D8")]
	public void ފՖߢ\u059B()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("hh:mm:sstt");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ࡇ\u0589\u05FDޛ();
	}

	// Token: 0x06001415 RID: 5141 RVA: 0x0007090C File Offset: 0x0006EB0C
	[Token(Token = "0x6001415")]
	[Address(RVA = "0x23BD22C", Offset = "0x23BD22C", VA = "0x23BD22C")]
	public void ޝݬ\u070A\u0822()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x06001416 RID: 5142 RVA: 0x00070968 File Offset: 0x0006EB68
	[Token(Token = "0x6001416")]
	[Address(RVA = "0x23BCF28", Offset = "0x23BCF28", VA = "0x23BCF28")]
	public void \u05A3ࠍ\u05BEز()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x06001417 RID: 5143 RVA: 0x000709BC File Offset: 0x0006EBBC
	[Token(Token = "0x6001417")]
	[Address(RVA = "0x23BD688", Offset = "0x23BD688", VA = "0x23BD688")]
	public void ࡇ\u0589\u05FDޛ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x06001418 RID: 5144 RVA: 0x00070A20 File Offset: 0x0006EC20
	[Token(Token = "0x6001418")]
	[Address(RVA = "0x23BD768", Offset = "0x23BD768", VA = "0x23BD768")]
	public void ࢫ\u0876չՍ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("TurnAmount");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ࡉ\u05B9\u085Aږ();
	}

	// Token: 0x06001419 RID: 5145 RVA: 0x00070A54 File Offset: 0x0006EC54
	[Token(Token = "0x6001419")]
	[Address(RVA = "0x23BD8C8", Offset = "0x23BD8C8", VA = "0x23BD8C8")]
	public void չւت\u061E()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Diffuse");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ڛ\u06ECԴࠄ();
	}

	// Token: 0x0600141A RID: 5146 RVA: 0x00070A88 File Offset: 0x0006EC88
	[Token(Token = "0x600141A")]
	[Address(RVA = "0x23BDA10", Offset = "0x23BDA10", VA = "0x23BDA10")]
	public void ڥՐ\u0830ߥ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
	}

	// Token: 0x0600141B RID: 5147 RVA: 0x00070AB8 File Offset: 0x0006ECB8
	[Token(Token = "0x600141B")]
	[Address(RVA = "0x23BD978", Offset = "0x23BD978", VA = "0x23BD978")]
	public void ڛ\u06ECԴࠄ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x0600141C RID: 5148 RVA: 0x00070B08 File Offset: 0x0006ED08
	[Token(Token = "0x600141C")]
	[Address(RVA = "0x23BDAD4", Offset = "0x23BDAD4", VA = "0x23BDAD4")]
	public void ڐ\u07F0ݤӟ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x0600141D RID: 5149 RVA: 0x00070B58 File Offset: 0x0006ED58
	[Token(Token = "0x600141D")]
	[Address(RVA = "0x23BDB6C", Offset = "0x23BDB6C", VA = "0x23BDB6C")]
	public void ݓ\u0894ࢸב()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x0600141E RID: 5150 RVA: 0x00070BBC File Offset: 0x0006EDBC
	[Token(Token = "0x600141E")]
	[Address(RVA = "0x23BDC4C", Offset = "0x23BDC4C", VA = "0x23BDC4C")]
	public void \u05F8ݑ\u06ECߞ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Player");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.זٴݜۅ();
	}

	// Token: 0x0600141F RID: 5151 RVA: 0x00070BF0 File Offset: 0x0006EDF0
	[Token(Token = "0x600141F")]
	[Address(RVA = "0x23BDDD8", Offset = "0x23BDDD8", VA = "0x23BDDD8")]
	public void طӏܙࢺ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Player");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ࡉ\u05B9\u085Aږ();
	}

	// Token: 0x06001420 RID: 5152 RVA: 0x00070C24 File Offset: 0x0006EE24
	[Token(Token = "0x6001420")]
	[Address(RVA = "0x23BDE88", Offset = "0x23BDE88", VA = "0x23BDE88")]
	public void צ\u0874ڵ\u059A()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("DisableCosmetic");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.\u0596\u07EC\u0670\u081F();
	}

	// Token: 0x06001421 RID: 5153 RVA: 0x00070C58 File Offset: 0x0006EE58
	[Token(Token = "0x6001421")]
	[Address(RVA = "0x23BE000", Offset = "0x23BE000", VA = "0x23BE000")]
	public void \u0732ڙԒࢺ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Holdable");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.\u0821Ԍ\u0822ߙ();
	}

	// Token: 0x06001422 RID: 5154 RVA: 0x00070C8C File Offset: 0x0006EE8C
	[Token(Token = "0x6001422")]
	[Address(RVA = "0x23BE0B0", Offset = "0x23BE0B0", VA = "0x23BE0B0")]
	public void Update()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("hh:mmtt");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ԫղ\u07EF\u083F();
	}

	// Token: 0x06001423 RID: 5155 RVA: 0x00070CC0 File Offset: 0x0006EEC0
	[Token(Token = "0x6001423")]
	[Address(RVA = "0x23BE23C", Offset = "0x23BE23C", VA = "0x23BE23C")]
	public void ߀ՠԙ\u0607()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x06001424 RID: 5156 RVA: 0x00070D1C File Offset: 0x0006EF1C
	[Token(Token = "0x6001424")]
	[Address(RVA = "0x23BE2EC", Offset = "0x23BE2EC", VA = "0x23BE2EC")]
	public void ո\u07AA\u05BDࠕ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Vertical");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.זٴݜۅ();
	}

	// Token: 0x06001425 RID: 5157 RVA: 0x00070D50 File Offset: 0x0006EF50
	[Token(Token = "0x6001425")]
	[Address(RVA = "0x23BE39C", Offset = "0x23BE39C", VA = "0x23BE39C")]
	public void \u0881ݗӟ\u07BD()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("TurnAmount");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ԫղ\u07EF\u083F();
	}

	// Token: 0x06001426 RID: 5158 RVA: 0x00070D84 File Offset: 0x0006EF84
	[Token(Token = "0x6001426")]
	[Address(RVA = "0x23BE44C", Offset = "0x23BE44C", VA = "0x23BE44C")]
	public void \u070B\u0874\u06D7\u0893()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x06001427 RID: 5159 RVA: 0x00070DE0 File Offset: 0x0006EFE0
	[Token(Token = "0x6001427")]
	[Address(RVA = "0x23BE510", Offset = "0x23BE510", VA = "0x23BE510")]
	public void \u087C\u07BFآݹ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x06001428 RID: 5160 RVA: 0x00070E34 File Offset: 0x0006F034
	[Token(Token = "0x6001428")]
	[Address(RVA = "0x23BD818", Offset = "0x23BD818", VA = "0x23BD818")]
	public void ࡉ\u05B9\u085Aږ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x06001429 RID: 5161 RVA: 0x00070E90 File Offset: 0x0006F090
	[Token(Token = "0x6001429")]
	[Address(RVA = "0x23BDF38", Offset = "0x23BDF38", VA = "0x23BDF38")]
	public void \u0596\u07EC\u0670\u081F()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x0600142A RID: 5162 RVA: 0x00070EE4 File Offset: 0x0006F0E4
	[Token(Token = "0x600142A")]
	[Address(RVA = "0x23BE5D8", Offset = "0x23BE5D8", VA = "0x23BE5D8")]
	public void \u06D6ࢱݜ\u081F()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x0600142B RID: 5163 RVA: 0x00070F4C File Offset: 0x0006F14C
	[Token(Token = "0x600142B")]
	[Address(RVA = "0x23BD0A0", Offset = "0x23BD0A0", VA = "0x23BD0A0")]
	public void \u06DFԌաԭ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x0600142C RID: 5164 RVA: 0x00070FB4 File Offset: 0x0006F1B4
	[Token(Token = "0x600142C")]
	[Address(RVA = "0x23BD3A0", Offset = "0x23BD3A0", VA = "0x23BD3A0")]
	public void ޖՁث\u0708()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x0600142D RID: 5165 RVA: 0x00071010 File Offset: 0x0006F210
	[Token(Token = "0x600142D")]
	[Address(RVA = "0x23BE6B4", Offset = "0x23BE6B4", VA = "0x23BE6B4")]
	public MusicPlayer()
	{
	}

	// Token: 0x0600142E RID: 5166 RVA: 0x00071024 File Offset: 0x0006F224
	[Token(Token = "0x600142E")]
	[Address(RVA = "0x23BE160", Offset = "0x23BE160", VA = "0x23BE160")]
	public void ԫղ\u07EF\u083F()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x0600142F RID: 5167 RVA: 0x0007108C File Offset: 0x0006F28C
	[Token(Token = "0x600142F")]
	[Address(RVA = "0x23BE6BC", Offset = "0x23BE6BC", VA = "0x23BE6BC")]
	public void ٴݵۃ\u05AF()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("EnableCosmetic");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.\u05F8\u059A\u059B\u060F();
	}

	// Token: 0x06001430 RID: 5168 RVA: 0x000710C0 File Offset: 0x0006F2C0
	[Token(Token = "0x6001430")]
	[Address(RVA = "0x23BE830", Offset = "0x23BE830", VA = "0x23BE830")]
	public void \u0650\u0886\u0706ރ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x06001431 RID: 5169 RVA: 0x0007111C File Offset: 0x0006F31C
	[Token(Token = "0x6001431")]
	[Address(RVA = "0x23BE8F4", Offset = "0x23BE8F4", VA = "0x23BE8F4")]
	public void ڪ\u06E9սآ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x06001432 RID: 5170 RVA: 0x00071178 File Offset: 0x0006F378
	[Token(Token = "0x6001432")]
	[Address(RVA = "0x23BE9A4", Offset = "0x23BE9A4", VA = "0x23BE9A4")]
	public void \u05B5\u055B\u07F7ܕ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x06001433 RID: 5171 RVA: 0x000711E0 File Offset: 0x0006F3E0
	[Token(Token = "0x6001433")]
	[Address(RVA = "0x23BEA80", Offset = "0x23BEA80", VA = "0x23BEA80")]
	public void Ӣ\u0592ߨׯ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("PlayerHead");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ޤ\u058BӀކ();
	}

	// Token: 0x06001434 RID: 5172 RVA: 0x00071214 File Offset: 0x0006F414
	[Token(Token = "0x6001434")]
	[Address(RVA = "0x23BEB30", Offset = "0x23BEB30", VA = "0x23BEB30")]
	public void ېࡧշہ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x06001435 RID: 5173 RVA: 0x00071264 File Offset: 0x0006F464
	[Token(Token = "0x6001435")]
	[Address(RVA = "0x23BEBC8", Offset = "0x23BEBC8", VA = "0x23BEBC8")]
	public void \u05F7ԝߠӱ()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("closeToObject");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ڛ\u06ECԴࠄ();
	}

	// Token: 0x06001436 RID: 5174 RVA: 0x00071298 File Offset: 0x0006F498
	[Token(Token = "0x6001436")]
	[Address(RVA = "0x23BEC78", Offset = "0x23BEC78", VA = "0x23BEC78")]
	public void ہրغڭ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x06001437 RID: 5175 RVA: 0x000712E8 File Offset: 0x0006F4E8
	[Token(Token = "0x6001437")]
	[Address(RVA = "0x23BED10", Offset = "0x23BED10", VA = "0x23BED10")]
	public void \u0870\u05B3Ց\u066A()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("Player");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.זٴݜۅ();
	}

	// Token: 0x06001438 RID: 5176 RVA: 0x0007131C File Offset: 0x0006F51C
	[Token(Token = "0x6001438")]
	[Address(RVA = "0x23BEDC0", Offset = "0x23BEDC0", VA = "0x23BEDC0")]
	public void \u0614ࢥӴ\u086C()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("_BumpScale");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.ݞ\u083Fݐށ();
	}

	// Token: 0x06001439 RID: 5177 RVA: 0x00071350 File Offset: 0x0006F550
	[Token(Token = "0x6001439")]
	[Address(RVA = "0x23BEE70", Offset = "0x23BEE70", VA = "0x23BEE70")]
	public void \u0654Մڇ\u0874()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x0600143A RID: 5178 RVA: 0x000713B8 File Offset: 0x0006F5B8
	[Token(Token = "0x600143A")]
	[Address(RVA = "0x23BDCFC", Offset = "0x23BDCFC", VA = "0x23BDCFC")]
	public void זٴݜۅ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x0600143B RID: 5179 RVA: 0x00071420 File Offset: 0x0006F620
	[Token(Token = "0x600143B")]
	[Address(RVA = "0x23BEF4C", Offset = "0x23BEF4C", VA = "0x23BEF4C")]
	public void \u0559\u06E8۴\u0839()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x0600143C RID: 5180 RVA: 0x00071470 File Offset: 0x0006F670
	[Token(Token = "0x600143C")]
	[Address(RVA = "0x23BEFE4", Offset = "0x23BEFE4", VA = "0x23BEFE4")]
	public void Ҿࢹؼס()
	{
		if (typeof(DateTime).TypeHandle == null)
		{
		}
		string ӫࢡ_u06D7_u05F = DateTime.UtcNow.ToString("PURCHASE");
		this.ӫࢡ\u06D7\u05F9 = ӫࢡ_u06D7_u05F;
		this.\u0559\u06E8۴\u0839();
	}

	// Token: 0x0600143D RID: 5181 RVA: 0x000714A4 File Offset: 0x0006F6A4
	[Token(Token = "0x600143D")]
	[Address(RVA = "0x23BE76C", Offset = "0x23BE76C", VA = "0x23BE76C")]
	public void \u05F8\u059A\u059B\u060F()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
	}

	// Token: 0x0600143E RID: 5182 RVA: 0x00071500 File Offset: 0x0006F700
	[Token(Token = "0x600143E")]
	[Address(RVA = "0x23BCD9C", Offset = "0x23BCD9C", VA = "0x23BCD9C")]
	public void ޤ\u058BӀކ()
	{
		string[] u0611ܖګד = this.\u0611ܖګד;
		string ӫࢡ_u06D7_u05F = this.ӫࢡ\u06D7\u05F9;
		AudioSource ى_u0617_u0610ۼ = this.ى\u0617\u0610ۼ;
		ى_u0617_u0610ۼ.Play();
		GameObject gameObject = this.ى\u0617\u0610ۼ.gameObject;
	}

	// Token: 0x04000286 RID: 646
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000286")]
	public AudioSource ى\u0617\u0610ۼ;

	// Token: 0x04000287 RID: 647
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000287")]
	public string[] \u0611ܖګד;

	// Token: 0x04000288 RID: 648
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000288")]
	public float ࢯӆݮߣ;

	// Token: 0x04000289 RID: 649
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000289")]
	public string ӫࢡ\u06D7\u05F9;
}
