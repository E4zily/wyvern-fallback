﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200007E RID: 126
[Token(Token = "0x200007E")]
public class MB_SkinnedMeshSceneController : MonoBehaviour
{
	// Token: 0x06001301 RID: 4865 RVA: 0x0006B9AC File Offset: 0x00069BAC
	[Token(Token = "0x6001301")]
	[Address(RVA = "0x2C5E394", Offset = "0x2C5E394", VA = "0x2C5E394")]
	private void ןٮ\u061FԺ()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("BLUPORT");
		GameObject[] array = new GameObject[1];
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 == null || gameObject2 != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001302 RID: 4866 RVA: 0x0006BA20 File Offset: 0x00069C20
	[Token(Token = "0x6001302")]
	[Address(RVA = "0x2C5E59C", Offset = "0x2C5E59C", VA = "0x2C5E59C")]
	private void \u0589٣ޖԀ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		GameObject ԇߢו_u = this.ԇߢו\u0655;
		if (num == 0L)
		{
		}
		Transform transform = this.\u07A8ډ\u055Eԁ.transform;
		Transform parent = this.ܮԗݤݐ(transform, ".Please press the button if you would like to play alone");
		if ("goDownRPC" == null)
		{
		}
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		GameObject[] array = new GameObject[0];
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject == null || gameObject != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001303 RID: 4867 RVA: 0x0006BCB0 File Offset: 0x00069EB0
	[Token(Token = "0x6001303")]
	[Address(RVA = "0x2C5F564", Offset = "0x2C5F564", VA = "0x2C5F564")]
	private void Ӄۇރࡑ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		GameObject ԇߢו_u = this.ԇߢו\u0655;
		if (num == 0L)
		{
		}
		Transform transform = this.\u07A8ډ\u055Eԁ.transform;
		Transform parent = this.\u060F\u0817ށא(transform, "DISABLE");
		GameObject ٻގ_u0818Ֆ = this.ٻގ\u0818Ֆ;
		if ("_BaseColor" == null)
		{
		}
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		GameObject[] array = new GameObject[1];
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject == null || gameObject != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001304 RID: 4868 RVA: 0x0006BF3C File Offset: 0x0006A13C
	[Token(Token = "0x6001304")]
	[Address(RVA = "0x2C603FC", Offset = "0x2C603FC", VA = "0x2C603FC")]
	private void ԗӣ\u07BAߩ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		GameObject ԇߢו_u = this.ԇߢו\u0655;
		if (num == 0L)
		{
		}
		Transform transform = this.\u07A8ډ\u055Eԁ.transform;
		Transform parent = this.ؽبۀ\u059B(transform, "gravThing");
		GameObject ٻގ_u0818Ֆ = this.ٻގ\u0818Ֆ;
		if ("EnableCosmetic" == null)
		{
		}
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		GameObject[] array = new GameObject[1];
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject == null || gameObject != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001305 RID: 4869 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001305")]
	[Address(RVA = "0x2C612C0", Offset = "0x2C612C0", VA = "0x2C612C0")]
	private void OnGUI()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001306 RID: 4870 RVA: 0x0006C1DC File Offset: 0x0006A3DC
	[Token(Token = "0x6001306")]
	[Address(RVA = "0x2C602FC", Offset = "0x2C602FC", VA = "0x2C602FC")]
	public Transform ܒԯ\u059Bݣ(Transform Տݞ٤վ, string \u081Bࡪߙے)
	{
		bool flag = Տݞ٤վ.name.Equals(\u081Bࡪߙے);
		int childCount = Տݞ٤վ.childCount;
		long index = 0L;
		Transform child = Տݞ٤վ.GetChild((int)index);
		Transform transform = this.\u060F\u0817ށא(child, \u081Bࡪߙے);
		throw new NullReferenceException();
	}

	// Token: 0x06001307 RID: 4871 RVA: 0x0006C21C File Offset: 0x0006A41C
	[Token(Token = "0x6001307")]
	[Address(RVA = "0x2C61F4C", Offset = "0x2C61F4C", VA = "0x2C61F4C")]
	private void ӭࡖݲ\u05BD()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("Push To Talk");
		GameObject[] array = new GameObject[0];
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 == null || gameObject2 != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001308 RID: 4872 RVA: 0x0006C294 File Offset: 0x0006A494
	[Token(Token = "0x6001308")]
	[Address(RVA = "0x2C601FC", Offset = "0x2C601FC", VA = "0x2C601FC")]
	public Transform \u060F\u0817ށא(Transform Տݞ٤վ, string \u081Bࡪߙے)
	{
		bool flag = Տݞ٤վ.name.Equals(\u081Bࡪߙے);
		int childCount = Տݞ٤վ.childCount;
		long index = 1L;
		Transform child = Տݞ٤վ.GetChild((int)index);
		Transform transform = this.ؽبۀ\u059B(child, \u081Bࡪߙے);
		throw new NullReferenceException();
	}

	// Token: 0x06001309 RID: 4873 RVA: 0x0006C2D4 File Offset: 0x0006A4D4
	[Token(Token = "0x6001309")]
	[Address(RVA = "0x2C62150", Offset = "0x2C62150", VA = "0x2C62150")]
	private void \u070Fߨ\u05B0ۈ()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("/");
		GameObject[] array = new GameObject[1];
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 == null || gameObject2 != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			throw new NullReferenceException();
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600130A RID: 4874 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600130A")]
	[Address(RVA = "0x2C62358", Offset = "0x2C62358", VA = "0x2C62358")]
	private void Ԅڌ\u0659߀()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600130B RID: 4875 RVA: 0x0006C348 File Offset: 0x0006A548
	[Token(Token = "0x600130B")]
	[Address(RVA = "0x2C5F34C", Offset = "0x2C5F34C", VA = "0x2C5F34C")]
	public Transform ټࢲڻ\u07B8(Transform Տݞ٤վ, string \u081Bࡪߙے)
	{
		bool flag = Տݞ٤վ.name.Equals(\u081Bࡪߙے);
		int childCount = Տݞ٤վ.childCount;
		long index = 1L;
		Transform child = Տݞ٤վ.GetChild((int)index);
		Transform transform = this.խڋ\u05B5\u0612(child, \u081Bࡪߙے);
		throw new NullReferenceException();
	}

	// Token: 0x0600130C RID: 4876 RVA: 0x0006C388 File Offset: 0x0006A588
	[Token(Token = "0x600130C")]
	[Address(RVA = "0x2C630F4", Offset = "0x2C630F4", VA = "0x2C630F4")]
	private void \u065F\u0839ܤ\u073C()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("HeadAttachPoint");
		GameObject[] array = new GameObject[1];
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 == null || gameObject2 != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600130D RID: 4877 RVA: 0x0006C3FC File Offset: 0x0006A5FC
	[Token(Token = "0x600130D")]
	[Address(RVA = "0x2C632F8", Offset = "0x2C632F8", VA = "0x2C632F8")]
	private void Ԯ\u0883\u0591\u066C()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("CapuchinStore");
		GameObject[] array = new GameObject[1];
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 == null || gameObject2 != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			throw new NullReferenceException();
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600130E RID: 4878 RVA: 0x0006C470 File Offset: 0x0006A670
	[Token(Token = "0x600130E")]
	[Address(RVA = "0x2C5F44C", Offset = "0x2C5F44C", VA = "0x2C5F44C")]
	public Transform ӂ٥ކ\u0878(Transform Տݞ٤վ, string \u081Bࡪߙے)
	{
		bool flag = Տݞ٤վ.name.Equals(\u081Bࡪߙے);
		int childCount = Տݞ٤վ.childCount;
		long index = 0L;
		Transform child = Տݞ٤վ.GetChild((int)index);
		int childCount2 = Տݞ٤վ.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x0600130F RID: 4879 RVA: 0x0006C4AC File Offset: 0x0006A6AC
	[Token(Token = "0x600130F")]
	[Address(RVA = "0x2C6108C", Offset = "0x2C6108C", VA = "0x2C6108C")]
	public Transform ؽبۀ\u059B(Transform Տݞ٤վ, string \u081Bࡪߙے)
	{
		bool flag = Տݞ٤վ.name.Equals(\u081Bࡪߙے);
		int childCount = Տݞ٤վ.childCount;
		long index = 1L;
		Transform child = Տݞ٤վ.GetChild((int)index);
		Transform transform = this.ؽبۀ\u059B(child, \u081Bࡪߙے);
		int childCount2 = Տݞ٤վ.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x06001310 RID: 4880 RVA: 0x0006C4F4 File Offset: 0x0006A6F4
	[Token(Token = "0x6001310")]
	[Address(RVA = "0x2C63500", Offset = "0x2C63500", VA = "0x2C63500")]
	public MB_SkinnedMeshSceneController()
	{
	}

	// Token: 0x06001311 RID: 4881 RVA: 0x0006C508 File Offset: 0x0006A708
	[Token(Token = "0x6001311")]
	[Address(RVA = "0x2C611A8", Offset = "0x2C611A8", VA = "0x2C611A8")]
	public Transform \u05FD\u081B\u06EA\u085A(Transform Տݞ٤վ, string \u081Bࡪߙے)
	{
		bool flag = Տݞ٤վ.name.Equals(\u081Bࡪߙے);
		int childCount = Տݞ٤վ.childCount;
		long index = 0L;
		Transform child = Տݞ٤վ.GetChild((int)index);
		Transform transform = this.ܮԗݤݐ(child, \u081Bࡪߙے);
		int childCount2 = Տݞ٤վ.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x06001312 RID: 4882 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001312")]
	[Address(RVA = "0x2C63508", Offset = "0x2C63508", VA = "0x2C63508")]
	private void ࠏޤݳ\u06DD()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001313 RID: 4883 RVA: 0x0006C550 File Offset: 0x0006A750
	[Token(Token = "0x6001313")]
	[Address(RVA = "0x2C63710", Offset = "0x2C63710", VA = "0x2C63710")]
	public Transform ڄ\u0887Ӄ\u06E8(Transform Տݞ٤վ, string \u081Bࡪߙے)
	{
		bool flag = Տݞ٤վ.name.Equals(\u081Bࡪߙے);
		int childCount = Տݞ٤վ.childCount;
		long index = 1L;
		Transform child = Տݞ٤վ.GetChild((int)index);
		Transform transform = this.ڄ\u0887Ӄ\u06E8(child, \u081Bࡪߙے);
		throw new NullReferenceException();
	}

	// Token: 0x06001314 RID: 4884 RVA: 0x0006C590 File Offset: 0x0006A790
	[Token(Token = "0x6001314")]
	[Address(RVA = "0x2C63810", Offset = "0x2C63810", VA = "0x2C63810")]
	private void ۃ\u087EڴՊ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		GameObject ԇߢו_u = this.ԇߢו\u0655;
		if (num == 0L)
		{
		}
		Transform transform = this.\u07A8ډ\u055Eԁ.transform;
		Transform parent = this.\u05FD\u081B\u06EA\u085A(transform, "username");
		GameObject ٻގ_u0818Ֆ = this.ٻގ\u0818Ֆ;
		if ("containsStaff" == null)
		{
		}
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		GameObject[] array = new GameObject[0];
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (this.ٻގ\u0818Ֆ != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x06001315 RID: 4885 RVA: 0x0006C834 File Offset: 0x0006AA34
	[Token(Token = "0x6001315")]
	[Address(RVA = "0x2C644A8", Offset = "0x2C644A8", VA = "0x2C644A8")]
	private void \u066D\u05BDې߃()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("True");
		GameObject[] array = new GameObject[0];
		if (gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject == null || gameObject != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001316 RID: 4886 RVA: 0x0006C8A4 File Offset: 0x0006AAA4
	[Token(Token = "0x6001316")]
	[Address(RVA = "0x2C646A8", Offset = "0x2C646A8", VA = "0x2C646A8")]
	private void ӛ\u082Eؿڕ()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("INSIGNIFICANT CURRENCY");
		GameObject[] array = new GameObject[1];
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 == null || gameObject2 != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001317 RID: 4887 RVA: 0x0006C910 File Offset: 0x0006AB10
	[Token(Token = "0x6001317")]
	[Address(RVA = "0x2C648B0", Offset = "0x2C648B0", VA = "0x2C648B0")]
	private void וࡪךӧ()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("username");
		GameObject[] array = new GameObject[0];
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 == null || gameObject2 != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001318 RID: 4888 RVA: 0x0006C988 File Offset: 0x0006AB88
	[Token(Token = "0x6001318")]
	[Address(RVA = "0x2C64AB4", Offset = "0x2C64AB4", VA = "0x2C64AB4")]
	private void Start()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("run");
		GameObject[] array = new GameObject[1];
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 == null || gameObject2 != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001319 RID: 4889 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001319")]
	[Address(RVA = "0x2C64CB4", Offset = "0x2C64CB4", VA = "0x2C64CB4")]
	private void ޥل\u0605Ԅ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600131A RID: 4890 RVA: 0x0006C9FC File Offset: 0x0006ABFC
	[Token(Token = "0x600131A")]
	[Address(RVA = "0x2C5F234", Offset = "0x2C5F234", VA = "0x2C5F234")]
	public Transform ܮԗݤݐ(Transform Տݞ٤վ, string \u081Bࡪߙے)
	{
		bool flag = Տݞ٤վ.name.Equals(\u081Bࡪߙے);
		int childCount = Տݞ٤վ.childCount;
		long index = 0L;
		Transform child = Տݞ٤վ.GetChild((int)index);
		Transform transform = this.ܮԗݤݐ(child, \u081Bࡪߙے);
		int childCount2 = Տݞ٤վ.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x0600131B RID: 4891 RVA: 0x0006CA44 File Offset: 0x0006AC44
	[Token(Token = "0x600131B")]
	[Address(RVA = "0x2C65948", Offset = "0x2C65948", VA = "0x2C65948")]
	private void \u082E\u06EBݼڏ()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("Players: ");
		GameObject[] array = new GameObject[0];
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 == null || gameObject2 != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600131C RID: 4892 RVA: 0x0006CABC File Offset: 0x0006ACBC
	[Token(Token = "0x600131C")]
	[Address(RVA = "0x2C62FF4", Offset = "0x2C62FF4", VA = "0x2C62FF4")]
	public Transform խڋ\u05B5\u0612(Transform Տݞ٤վ, string \u081Bࡪߙے)
	{
		bool flag = Տݞ٤վ.name.Equals(\u081Bࡪߙے);
		int childCount = Տݞ٤վ.childCount;
		long index = 1L;
		Transform child = Տݞ٤վ.GetChild((int)index);
		Transform transform = this.ڄ\u0887Ӄ\u06E8(child, \u081Bࡪߙے);
		throw new NullReferenceException();
	}

	// Token: 0x0600131D RID: 4893 RVA: 0x0006CAFC File Offset: 0x0006ACFC
	[Token(Token = "0x600131D")]
	[Address(RVA = "0x2C65B4C", Offset = "0x2C65B4C", VA = "0x2C65B4C")]
	private void הԥ\u05B5ݴ()
	{
		GameObject ӝݔ_u08B5թ = this.Ӝݔ\u08B5թ;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		GameObject gameObject;
		Transform transform = gameObject.transform;
		bool flag = gameObject.GetComponent<Animation>().Play("Try Connect To Server...");
		GameObject[] array = new GameObject[0];
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 == null || gameObject2 != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600131E RID: 4894 RVA: 0x0006CB74 File Offset: 0x0006AD74
	[Token(Token = "0x600131E")]
	[Address(RVA = "0x2C65D50", Offset = "0x2C65D50", VA = "0x2C65D50")]
	public Transform ࡥԆߦތ(Transform Տݞ٤վ, string \u081Bࡪߙے)
	{
		bool flag = Տݞ٤վ.name.Equals(\u081Bࡪߙے);
		int childCount = Տݞ٤վ.childCount;
		long index = 1L;
		Transform child = Տݞ٤վ.GetChild((int)index);
		Transform transform = this.ܒԯ\u059Bݣ(child, \u081Bࡪߙے);
		int childCount2 = Տݞ٤վ.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x0600131F RID: 4895 RVA: 0x0006CBBC File Offset: 0x0006ADBC
	[Token(Token = "0x600131F")]
	[Address(RVA = "0x2C65E6C", Offset = "0x2C65E6C", VA = "0x2C65E6C")]
	private void \u0859ؤԗԧ()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		GameObject ԇߢו_u = this.ԇߢו\u0655;
		if (num == 0L)
		{
		}
		Transform transform = this.\u07A8ډ\u055Eԁ.transform;
		Transform parent = this.ܒԯ\u059Bݣ(transform, "monke is not my monke");
		GameObject ٻގ_u0818Ֆ = this.ٻގ\u0818Ֆ;
		if ("PlayerHead" == null)
		{
		}
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		GameObject[] array = new GameObject[0];
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject == null || gameObject != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001320 RID: 4896 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001320")]
	[Address(RVA = "0x2C66B08", Offset = "0x2C66B08", VA = "0x2C66B08")]
	private void ۮߝڪڐ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001321 RID: 4897 RVA: 0x0006CE4C File Offset: 0x0006B04C
	[Token(Token = "0x6001321")]
	[Address(RVA = "0x2C66D10", Offset = "0x2C66D10", VA = "0x2C66D10")]
	private void \u0594ٺԏ\u05CA()
	{
		long num = 1L;
		if (num == 0L)
		{
		}
		GameObject ԇߢו_u = this.ԇߢו\u0655;
		if (num == 0L)
		{
		}
		Transform transform = this.\u07A8ډ\u055Eԁ.transform;
		Transform parent = this.ټࢲڻ\u07B8(transform, "Player");
		GameObject ٻގ_u0818Ֆ = this.ٻގ\u0818Ֆ;
		if ("ORGTARG" == null)
		{
		}
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		GameObject[] array = new GameObject[1];
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject == null || gameObject != null)
		{
			MB3_MeshBaker גܢ_u070A_u055A = this.גܢ\u070A\u055A;
			MB3_MeshBaker גܢ_u070A_u055A2 = this.גܢ\u070A\u055A;
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0400025D RID: 605
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400025D")]
	public GameObject ٻގ\u0818Ֆ;

	// Token: 0x0400025E RID: 606
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400025E")]
	public GameObject ܕԶ٣ף;

	// Token: 0x0400025F RID: 607
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400025F")]
	public GameObject ՕӉ\u0821\u0604;

	// Token: 0x04000260 RID: 608
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000260")]
	public GameObject Ӝݔ\u08B5թ;

	// Token: 0x04000261 RID: 609
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000261")]
	public GameObject \u07A8ډ\u055Eԁ;

	// Token: 0x04000262 RID: 610
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000262")]
	public MB3_MeshBaker גܢ\u070A\u055A;

	// Token: 0x04000263 RID: 611
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000263")]
	private GameObject ԇߢו\u0655;

	// Token: 0x04000264 RID: 612
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000264")]
	private GameObject \u0701\u05BE\u081CӶ;

	// Token: 0x04000265 RID: 613
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000265")]
	private GameObject \u058Cࢮ\u089Cߏ;
}
