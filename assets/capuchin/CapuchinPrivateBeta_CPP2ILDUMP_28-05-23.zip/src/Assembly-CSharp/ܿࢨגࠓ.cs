﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000109 RID: 265
[Token(Token = "0x2000109")]
public class \u073Fࢨגࠓ
{
	// Token: 0x06002944 RID: 10564 RVA: 0x000FBB14 File Offset: 0x000F9D14
	[Token(Token = "0x6002944")]
	[Address(RVA = "0x21239D4", Offset = "0x21239D4", VA = "0x21239D4")]
	public static Vector3 \u083D\u05B7\u055Cࡘ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002945 RID: 10565 RVA: 0x000FBB4C File Offset: 0x000F9D4C
	[Token(Token = "0x6002945")]
	[Address(RVA = "0x2123B60", Offset = "0x2123B60", VA = "0x2123B60")]
	public static Vector3 ӑԮܒࢶ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002946 RID: 10566 RVA: 0x000FBB84 File Offset: 0x000F9D84
	[Token(Token = "0x6002946")]
	[Address(RVA = "0x2123CEC", Offset = "0x2123CEC", VA = "0x2123CEC")]
	public static bool ޱܗӀ\u05A5(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (06002946)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ޱܗӀ֥(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06002947 RID: 10567 RVA: 0x000FBBA4 File Offset: 0x000F9DA4
	[Token(Token = "0x6002947")]
	[Address(RVA = "0x2123DCC", Offset = "0x2123DCC", VA = "0x2123DCC")]
	public static bool ڕࡤ\u05CDԃ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06002948 RID: 10568 RVA: 0x000FBBC8 File Offset: 0x000F9DC8
	[Token(Token = "0x6002948")]
	[Address(RVA = "0x2123E74", Offset = "0x2123E74", VA = "0x2123E74")]
	public static bool ࢫԤՉՀ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002949 RID: 10569 RVA: 0x000FBBE8 File Offset: 0x000F9DE8
	[Token(Token = "0x6002949")]
	[Address(RVA = "0x2123F58", Offset = "0x2123F58", VA = "0x2123F58")]
	public static Vector3 \u05C9\u0708\u085B\u059A(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600294A RID: 10570 RVA: 0x000FBC20 File Offset: 0x000F9E20
	[Token(Token = "0x600294A")]
	[Address(RVA = "0x21240E4", Offset = "0x21240E4", VA = "0x21240E4")]
	public static Vector3 \u089Bڡܢڳ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600294B RID: 10571 RVA: 0x000FBC58 File Offset: 0x000F9E58
	[Token(Token = "0x600294B")]
	[Address(RVA = "0x2124270", Offset = "0x2124270", VA = "0x2124270")]
	public static Vector3 \u060B\u07F1ܞ\u0831(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600294C RID: 10572 RVA: 0x000FBC90 File Offset: 0x000F9E90
	[Token(Token = "0x600294C")]
	[Address(RVA = "0x21243FC", Offset = "0x21243FC", VA = "0x21243FC")]
	public static bool ܘ\u0650ࡗ\u089E(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x0600294D RID: 10573 RVA: 0x000FBCB4 File Offset: 0x000F9EB4
	[Token(Token = "0x600294D")]
	[Address(RVA = "0x21244A4", Offset = "0x21244A4", VA = "0x21244A4")]
	public static bool سܪ۸\u07F8(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x0600294E RID: 10574 RVA: 0x000FBCD4 File Offset: 0x000F9ED4
	[Token(Token = "0x600294E")]
	[Address(RVA = "0x2124588", Offset = "0x2124588", VA = "0x2124588")]
	public static bool ݧܙڊر(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (0600294E)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ݧܙڊر(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600294F RID: 10575 RVA: 0x000FBCF4 File Offset: 0x000F9EF4
	[Token(Token = "0x600294F")]
	[Address(RVA = "0x2124668", Offset = "0x2124668", VA = "0x2124668")]
	public static bool ࡕ\u0747\u0599ݗ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06002950 RID: 10576 RVA: 0x000FBD18 File Offset: 0x000F9F18
	[Token(Token = "0x6002950")]
	[Address(RVA = "0x2124710", Offset = "0x2124710", VA = "0x2124710")]
	public static Vector3 ۶\u089Fۇہ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002951 RID: 10577 RVA: 0x000FBD50 File Offset: 0x000F9F50
	[Token(Token = "0x6002951")]
	[Address(RVA = "0x212489C", Offset = "0x212489C", VA = "0x212489C")]
	public static bool Ӵ\u0871ܔࡋ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002952 RID: 10578 RVA: 0x000FBD74 File Offset: 0x000F9F74
	[Token(Token = "0x6002952")]
	[Address(RVA = "0x2124954", Offset = "0x2124954", VA = "0x2124954")]
	public static Vector3 ۲\u05BE\u0616ࠈ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002953 RID: 10579 RVA: 0x000FBDAC File Offset: 0x000F9FAC
	[Token(Token = "0x6002953")]
	[Address(RVA = "0x2124AE0", Offset = "0x2124AE0", VA = "0x2124AE0")]
	public static bool ع\u085Bߨذ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002954 RID: 10580 RVA: 0x000FBDD0 File Offset: 0x000F9FD0
	[Token(Token = "0x6002954")]
	[Address(RVA = "0x2124B94", Offset = "0x2124B94", VA = "0x2124B94")]
	public static bool ۺ\u0838\u0591ߣ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (06002954)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ۺ࠸֑ߣ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06002955 RID: 10581 RVA: 0x000FBDF0 File Offset: 0x000F9FF0
	[Token(Token = "0x6002955")]
	[Address(RVA = "0x2124C74", Offset = "0x2124C74", VA = "0x2124C74")]
	public static bool ߗԅއӾ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (06002955)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ߗԅއӾ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06002956 RID: 10582 RVA: 0x000FBE10 File Offset: 0x000FA010
	[Token(Token = "0x6002956")]
	[Address(RVA = "0x2124D54", Offset = "0x2124D54", VA = "0x2124D54")]
	public static bool פ\u05FB\u065EӸ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (06002956)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::פ׻ٞӸ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06002957 RID: 10583 RVA: 0x000FBE30 File Offset: 0x000FA030
	[Token(Token = "0x6002957")]
	[Address(RVA = "0x2124E34", Offset = "0x2124E34", VA = "0x2124E34")]
	public static bool ࢺӘݝӼ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002958 RID: 10584 RVA: 0x000FBE54 File Offset: 0x000FA054
	[Token(Token = "0x6002958")]
	[Address(RVA = "0x2124EEC", Offset = "0x2124EEC", VA = "0x2124EEC")]
	public static bool \u0658\u06D9Ր\u070A(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002959 RID: 10585 RVA: 0x000FBE78 File Offset: 0x000FA078
	[Token(Token = "0x6002959")]
	[Address(RVA = "0x2124FA0", Offset = "0x2124FA0", VA = "0x2124FA0")]
	public static bool տҾ\u05A4ױ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x0600295A RID: 10586 RVA: 0x000FBE98 File Offset: 0x000FA098
	[Token(Token = "0x600295A")]
	[Address(RVA = "0x2125080", Offset = "0x2125080", VA = "0x2125080")]
	public static bool \u073Dܬؠۋ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x0600295B RID: 10587 RVA: 0x000FBEBC File Offset: 0x000FA0BC
	[Token(Token = "0x600295B")]
	[Address(RVA = "0x2125138", Offset = "0x2125138", VA = "0x2125138")]
	public static bool ݠ\u0604\u05CDӴ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x0600295C RID: 10588 RVA: 0x000FBEDC File Offset: 0x000FA0DC
	[Token(Token = "0x600295C")]
	[Address(RVA = "0x212521C", Offset = "0x212521C", VA = "0x212521C")]
	public static Vector3 \u081C\u07B2\u055EՌ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600295D RID: 10589 RVA: 0x000FBF14 File Offset: 0x000FA114
	[Token(Token = "0x600295D")]
	[Address(RVA = "0x21253A8", Offset = "0x21253A8", VA = "0x21253A8")]
	public static Vector3 Ӟࠑ߆ր(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600295E RID: 10590 RVA: 0x000FBF4C File Offset: 0x000FA14C
	[Token(Token = "0x600295E")]
	[Address(RVA = "0x2125534", Offset = "0x2125534", VA = "0x2125534")]
	public static bool \u06E9\u05FD\u088Dۺ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x0600295F RID: 10591 RVA: 0x000FBF70 File Offset: 0x000FA170
	[Token(Token = "0x600295F")]
	[Address(RVA = "0x21255E8", Offset = "0x21255E8", VA = "0x21255E8")]
	public static Vector3 ڣݒۻէ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002960 RID: 10592 RVA: 0x000FBFA8 File Offset: 0x000FA1A8
	[Token(Token = "0x6002960")]
	[Address(RVA = "0x2125774", Offset = "0x2125774", VA = "0x2125774")]
	public static bool \u0606\u083Bߘڪ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002961 RID: 10593 RVA: 0x000FBFCC File Offset: 0x000FA1CC
	[Token(Token = "0x6002961")]
	[Address(RVA = "0x2125818", Offset = "0x2125818", VA = "0x2125818")]
	public static Vector3 \u06EDփߪࢠ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002962 RID: 10594 RVA: 0x000FC004 File Offset: 0x000FA204
	[Token(Token = "0x6002962")]
	[Address(RVA = "0x21259A4", Offset = "0x21259A4", VA = "0x21259A4")]
	public static Vector3 ݱهףԅ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002963 RID: 10595 RVA: 0x000FC03C File Offset: 0x000FA23C
	[Token(Token = "0x6002963")]
	[Address(RVA = "0x2125B30", Offset = "0x2125B30", VA = "0x2125B30")]
	public static Vector3 \u0886צ\u0829ك(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002964 RID: 10596 RVA: 0x000FC074 File Offset: 0x000FA274
	[Token(Token = "0x6002964")]
	[Address(RVA = "0x2125CBC", Offset = "0x2125CBC", VA = "0x2125CBC")]
	public static bool ڦޞ\u0829\u05B2(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002965 RID: 10597 RVA: 0x000FC098 File Offset: 0x000FA298
	[Token(Token = "0x6002965")]
	[Address(RVA = "0x2125D70", Offset = "0x2125D70", VA = "0x2125D70")]
	public static Vector3 ךעޛڪ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002966 RID: 10598 RVA: 0x000FC0D0 File Offset: 0x000FA2D0
	[Token(Token = "0x6002966")]
	[Address(RVA = "0x2125EFC", Offset = "0x2125EFC", VA = "0x2125EFC")]
	public static Vector3 \u05F4ӥ\u05C2ր(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002967 RID: 10599 RVA: 0x000FC108 File Offset: 0x000FA308
	[Token(Token = "0x6002967")]
	[Address(RVA = "0x2126088", Offset = "0x2126088", VA = "0x2126088")]
	public static Vector3 \u06DD\u0892պ\u07FA(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002968 RID: 10600 RVA: 0x000FC140 File Offset: 0x000FA340
	[Token(Token = "0x6002968")]
	[Address(RVA = "0x2126214", Offset = "0x2126214", VA = "0x2126214")]
	public static bool ӡցՔق(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002969 RID: 10601 RVA: 0x000FC160 File Offset: 0x000FA360
	[Token(Token = "0x6002969")]
	[Address(RVA = "0x21262F4", Offset = "0x21262F4", VA = "0x21262F4")]
	public static Vector3 ւ߄ސب(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600296A RID: 10602 RVA: 0x000FC198 File Offset: 0x000FA398
	[Token(Token = "0x600296A")]
	[Address(RVA = "0x2126480", Offset = "0x2126480", VA = "0x2126480")]
	public static bool \u0730\u0740ݘࢦ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (0600296A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ܰ݀ݘࢦ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600296B RID: 10603 RVA: 0x000FC1B8 File Offset: 0x000FA3B8
	[Token(Token = "0x600296B")]
	[Address(RVA = "0x2126560", Offset = "0x2126560", VA = "0x2126560")]
	public static Vector3 \u060BԢ\u0749\u0616(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600296C RID: 10604 RVA: 0x000FC1F0 File Offset: 0x000FA3F0
	[Token(Token = "0x600296C")]
	[Address(RVA = "0x21266EC", Offset = "0x21266EC", VA = "0x21266EC")]
	public static bool փࡌضࡖ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x0600296D RID: 10605 RVA: 0x000FC214 File Offset: 0x000FA414
	[Token(Token = "0x600296D")]
	[Address(RVA = "0x21267A0", Offset = "0x21267A0", VA = "0x21267A0")]
	public static Vector3 ߣ\u07F7ࢪӃ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600296E RID: 10606 RVA: 0x000FC24C File Offset: 0x000FA44C
	[Token(Token = "0x600296E")]
	[Address(RVA = "0x212692C", Offset = "0x212692C", VA = "0x212692C")]
	public static bool ࠒ\u05B8ߎ\u07B9(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (0600296E)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ࠒָߎ޹(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600296F RID: 10607 RVA: 0x000FC26C File Offset: 0x000FA46C
	[Token(Token = "0x600296F")]
	[Address(RVA = "0x2126A0C", Offset = "0x2126A0C", VA = "0x2126A0C")]
	public static bool ڂی\u083Bն(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002970 RID: 10608 RVA: 0x000FC290 File Offset: 0x000FA490
	[Token(Token = "0x6002970")]
	[Address(RVA = "0x2126AC4", Offset = "0x2126AC4", VA = "0x2126AC4")]
	public static Vector3 կ\u05CCلݤ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002971 RID: 10609 RVA: 0x000FC2C8 File Offset: 0x000FA4C8
	[Token(Token = "0x6002971")]
	[Address(RVA = "0x2126C50", Offset = "0x2126C50", VA = "0x2126C50")]
	public static bool ࠁסӈݓ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002972 RID: 10610 RVA: 0x000FC2EC File Offset: 0x000FA4EC
	[Token(Token = "0x6002972")]
	[Address(RVA = "0x2126D00", Offset = "0x2126D00", VA = "0x2126D00")]
	public static bool تࢳࢴӆ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06002973 RID: 10611 RVA: 0x000FC310 File Offset: 0x000FA510
	[Token(Token = "0x6002973")]
	[Address(RVA = "0x2126DA8", Offset = "0x2126DA8", VA = "0x2126DA8")]
	public static bool \u085Aٯࡠԣ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002974 RID: 10612 RVA: 0x000FC330 File Offset: 0x000FA530
	[Token(Token = "0x6002974")]
	[Address(RVA = "0x2126E88", Offset = "0x2126E88", VA = "0x2126E88")]
	public static Vector3 \u07A8\u070Fٿ\u05F3(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002975 RID: 10613 RVA: 0x000FC368 File Offset: 0x000FA568
	[Token(Token = "0x6002975")]
	[Address(RVA = "0x2127014", Offset = "0x2127014", VA = "0x2127014")]
	public static Vector3 Ԃ\u06FD\u05A6ޣ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002976 RID: 10614 RVA: 0x000FC3A0 File Offset: 0x000FA5A0
	[Token(Token = "0x6002976")]
	[Address(RVA = "0x21271A0", Offset = "0x21271A0", VA = "0x21271A0")]
	public static bool \u055Eߋ\u061Bڄ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (06002976)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::՞ߋ؛ڄ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06002977 RID: 10615 RVA: 0x000FC3C0 File Offset: 0x000FA5C0
	[Token(Token = "0x6002977")]
	[Address(RVA = "0x2127280", Offset = "0x2127280", VA = "0x2127280")]
	public static bool \u05FCد\u07AEԅ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (06002977)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::׼دޮԅ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06002978 RID: 10616 RVA: 0x000FC3E0 File Offset: 0x000FA5E0
	[Token(Token = "0x6002978")]
	[Address(RVA = "0x2127360", Offset = "0x2127360", VA = "0x2127360")]
	public static bool ࡄߜ\u0820\u0835(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002979 RID: 10617 RVA: 0x000FC404 File Offset: 0x000FA604
	[Token(Token = "0x6002979")]
	[Address(RVA = "0x2127418", Offset = "0x2127418", VA = "0x2127418")]
	public static bool Ԏݪԡ\u055C(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x0600297A RID: 10618 RVA: 0x000FC424 File Offset: 0x000FA624
	[Token(Token = "0x600297A")]
	[Address(RVA = "0x21274F8", Offset = "0x21274F8", VA = "0x21274F8")]
	public static bool ӻ\u0835غ\u0897(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x0600297B RID: 10619 RVA: 0x000FC444 File Offset: 0x000FA644
	[Token(Token = "0x600297B")]
	[Address(RVA = "0x21275DC", Offset = "0x21275DC", VA = "0x21275DC")]
	public static bool ࡡٹك\u0881(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (0600297B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ࡡٹكࢁ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600297C RID: 10620 RVA: 0x000FC464 File Offset: 0x000FA664
	[Token(Token = "0x600297C")]
	[Address(RVA = "0x21276BC", Offset = "0x21276BC", VA = "0x21276BC")]
	public static Vector3 \u0880ݱڴ\u0818(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600297D RID: 10621 RVA: 0x000FC49C File Offset: 0x000FA69C
	[Token(Token = "0x600297D")]
	[Address(RVA = "0x2127848", Offset = "0x2127848", VA = "0x2127848")]
	public static bool \u0884ԸӒՖ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x0600297E RID: 10622 RVA: 0x000FC4BC File Offset: 0x000FA6BC
	[Token(Token = "0x600297E")]
	[Address(RVA = "0x2127928", Offset = "0x2127928", VA = "0x2127928")]
	public static Vector3 ٯ\u085Dݱۋ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600297F RID: 10623 RVA: 0x000FC4F4 File Offset: 0x000FA6F4
	[Token(Token = "0x600297F")]
	[Address(RVA = "0x2127AB4", Offset = "0x2127AB4", VA = "0x2127AB4")]
	public static bool ࢣڜ\u0604ࠎ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (0600297F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ࢣڜ؄ࠎ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06002980 RID: 10624 RVA: 0x000FC514 File Offset: 0x000FA714
	[Token(Token = "0x6002980")]
	[Address(RVA = "0x2127B94", Offset = "0x2127B94", VA = "0x2127B94")]
	public static bool ٲ۳ޠ\u082E(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002981 RID: 10625 RVA: 0x000FC534 File Offset: 0x000FA734
	[Token(Token = "0x6002981")]
	[Address(RVA = "0x2127C74", Offset = "0x2127C74", VA = "0x2127C74")]
	public static Vector3 \u088FӔ\u0651ڂ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002982 RID: 10626 RVA: 0x000FC56C File Offset: 0x000FA76C
	[Token(Token = "0x6002982")]
	[Address(RVA = "0x2127E00", Offset = "0x2127E00", VA = "0x2127E00")]
	public static bool ձࠔԞن(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002983 RID: 10627 RVA: 0x000FC590 File Offset: 0x000FA790
	[Token(Token = "0x6002983")]
	[Address(RVA = "0x2127EB8", Offset = "0x2127EB8", VA = "0x2127EB8")]
	public static bool ڙװݟڎ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (06002983)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ڙװݟڎ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06002984 RID: 10628 RVA: 0x000FC5B0 File Offset: 0x000FA7B0
	[Token(Token = "0x6002984")]
	[Address(RVA = "0x2127F98", Offset = "0x2127F98", VA = "0x2127F98")]
	public static bool \u073Fࢷ\u06E3ࢲ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002985 RID: 10629 RVA: 0x000FC5D0 File Offset: 0x000FA7D0
	[Token(Token = "0x6002985")]
	[Address(RVA = "0x2128078", Offset = "0x2128078", VA = "0x2128078")]
	public static Vector3 ҽڝӽ\u05BD(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002986 RID: 10630 RVA: 0x000FC608 File Offset: 0x000FA808
	[Token(Token = "0x6002986")]
	[Address(RVA = "0x2128204", Offset = "0x2128204", VA = "0x2128204")]
	public static bool ԥ\u07BF\u06DFց(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06002987 RID: 10631 RVA: 0x000FC62C File Offset: 0x000FA82C
	[Token(Token = "0x6002987")]
	[Address(RVA = "0x21282A8", Offset = "0x21282A8", VA = "0x21282A8")]
	public static Vector3 ࠁՑ\u074B\u0744(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002988 RID: 10632 RVA: 0x000FC664 File Offset: 0x000FA864
	[Token(Token = "0x6002988")]
	[Address(RVA = "0x2128434", Offset = "0x2128434", VA = "0x2128434")]
	public static bool ߐ\u05F5\u07B5ر(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002989 RID: 10633 RVA: 0x000FC688 File Offset: 0x000FA888
	[Token(Token = "0x6002989")]
	[Address(RVA = "0x21284EC", Offset = "0x21284EC", VA = "0x21284EC")]
	public static bool \u074A\u07BEۈڪ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x0600298A RID: 10634 RVA: 0x000FC6AC File Offset: 0x000FA8AC
	[Token(Token = "0x600298A")]
	[Address(RVA = "0x2128594", Offset = "0x2128594", VA = "0x2128594")]
	public \u073Fࢨגࠓ()
	{
	}

	// Token: 0x0600298B RID: 10635 RVA: 0x000FC6C0 File Offset: 0x000FA8C0
	[Token(Token = "0x600298B")]
	[Address(RVA = "0x212859C", Offset = "0x212859C", VA = "0x212859C")]
	public static bool \u05C8ࠐࢩ\u05A0(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (0600298B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::׈ࠐࢩ֠(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600298C RID: 10636 RVA: 0x000FC6E0 File Offset: 0x000FA8E0
	[Token(Token = "0x600298C")]
	[Address(RVA = "0x212867C", Offset = "0x212867C", VA = "0x212867C")]
	public static Vector3 \u0657ޚӞה(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600298D RID: 10637 RVA: 0x000FC718 File Offset: 0x000FA918
	[Token(Token = "0x600298D")]
	[Address(RVA = "0x2128808", Offset = "0x2128808", VA = "0x2128808")]
	public static Vector3 ڰӞࡓߤ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600298E RID: 10638 RVA: 0x000FC750 File Offset: 0x000FA950
	[Token(Token = "0x600298E")]
	[Address(RVA = "0x2128994", Offset = "0x2128994", VA = "0x2128994")]
	public static bool \u07EFӬ\u0898\u0821(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x0600298F RID: 10639 RVA: 0x000FC774 File Offset: 0x000FA974
	[Token(Token = "0x600298F")]
	[Address(RVA = "0x2128A3C", Offset = "0x2128A3C", VA = "0x2128A3C")]
	public static bool \u0884\u088Fڂښ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002990 RID: 10640 RVA: 0x000FC794 File Offset: 0x000FA994
	[Token(Token = "0x6002990")]
	[Address(RVA = "0x2128B1C", Offset = "0x2128B1C", VA = "0x2128B1C")]
	public static bool ߝߋ\u0897Ւ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06002991 RID: 10641 RVA: 0x000FC7B8 File Offset: 0x000FA9B8
	[Token(Token = "0x6002991")]
	[Address(RVA = "0x2128BC4", Offset = "0x2128BC4", VA = "0x2128BC4")]
	public static Vector3 \u07FEࡦߑ\u07F3(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002992 RID: 10642 RVA: 0x000FC7F0 File Offset: 0x000FA9F0
	[Token(Token = "0x6002992")]
	[Address(RVA = "0x2128D50", Offset = "0x2128D50", VA = "0x2128D50")]
	public static bool Ӭ\u088Aࢮן(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002993 RID: 10643 RVA: 0x000FC810 File Offset: 0x000FAA10
	[Token(Token = "0x6002993")]
	[Address(RVA = "0x2128E30", Offset = "0x2128E30", VA = "0x2128E30")]
	public static bool \u082EӬݱ\u06E3(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (06002993)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::࠮Ӭݱۣ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06002994 RID: 10644 RVA: 0x000FC830 File Offset: 0x000FAA30
	[Token(Token = "0x6002994")]
	[Address(RVA = "0x2128F10", Offset = "0x2128F10", VA = "0x2128F10")]
	public static bool ܗՈڜܡ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002995 RID: 10645 RVA: 0x000FC850 File Offset: 0x000FAA50
	[Token(Token = "0x6002995")]
	[Address(RVA = "0x2128FF4", Offset = "0x2128FF4", VA = "0x2128FF4")]
	public static bool މ\u05CEࠄ\u0732(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002996 RID: 10646 RVA: 0x000FC870 File Offset: 0x000FAA70
	[Token(Token = "0x6002996")]
	[Address(RVA = "0x21290D8", Offset = "0x21290D8", VA = "0x21290D8")]
	public static Vector3 \u0593ࡇٵࡐ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002997 RID: 10647 RVA: 0x000FC8A8 File Offset: 0x000FAAA8
	[Token(Token = "0x6002997")]
	[Address(RVA = "0x2129264", Offset = "0x2129264", VA = "0x2129264")]
	public static bool ӗ\u0557\u0818ۇ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x06002998 RID: 10648 RVA: 0x000FC8CC File Offset: 0x000FAACC
	[Token(Token = "0x6002998")]
	[Address(RVA = "0x212931C", Offset = "0x212931C", VA = "0x212931C")]
	public static Vector3 \u0859ؠࡃ\u06E9(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06002999 RID: 10649 RVA: 0x000FC904 File Offset: 0x000FAB04
	[Token(Token = "0x6002999")]
	[Address(RVA = "0x21294A8", Offset = "0x21294A8", VA = "0x21294A8")]
	public static bool \u082Dߩࡋ\u0612(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (06002999)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::࠭ߩࡋؒ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600299A RID: 10650 RVA: 0x000FC924 File Offset: 0x000FAB24
	[Token(Token = "0x600299A")]
	[Address(RVA = "0x2129588", Offset = "0x2129588", VA = "0x2129588")]
	public static bool ߈ݸۻԍ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (0600299A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::߈ݸۻԍ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600299B RID: 10651 RVA: 0x000FC944 File Offset: 0x000FAB44
	[Token(Token = "0x600299B")]
	[Address(RVA = "0x2129668", Offset = "0x2129668", VA = "0x2129668")]
	public static Vector3 ك\u0891\u070F\u05A9(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x0600299C RID: 10652 RVA: 0x000FC97C File Offset: 0x000FAB7C
	[Token(Token = "0x600299C")]
	[Address(RVA = "0x21297F4", Offset = "0x21297F4", VA = "0x21297F4")]
	public static bool \u0734\u07EB\u05FEӬ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x0600299D RID: 10653 RVA: 0x000FC9A0 File Offset: 0x000FABA0
	[Token(Token = "0x600299D")]
	[Address(RVA = "0x2129894", Offset = "0x2129894", VA = "0x2129894")]
	public static bool ݠڞӘԐ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x0600299E RID: 10654 RVA: 0x000FC9C4 File Offset: 0x000FABC4
	[Token(Token = "0x600299E")]
	[Address(RVA = "0x212994C", Offset = "0x212994C", VA = "0x212994C")]
	public static bool ܟ\u0604߇\u07AF(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (0600299E)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ܟ؄߇ޯ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600299F RID: 10655 RVA: 0x000FC9E4 File Offset: 0x000FABE4
	[Token(Token = "0x600299F")]
	[Address(RVA = "0x2129A2C", Offset = "0x2129A2C", VA = "0x2129A2C")]
	public static Vector3 Ԡބ۸\u0640(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029A0 RID: 10656 RVA: 0x000FCA1C File Offset: 0x000FAC1C
	[Token(Token = "0x60029A0")]
	[Address(RVA = "0x2129BB8", Offset = "0x2129BB8", VA = "0x2129BB8")]
	public static bool \u064E٠ܥ\u05AA(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x060029A1 RID: 10657 RVA: 0x000FCA3C File Offset: 0x000FAC3C
	[Token(Token = "0x60029A1")]
	[Address(RVA = "0x2129C98", Offset = "0x2129C98", VA = "0x2129C98")]
	public static Vector3 \u05ED\u05C0ࡋٳ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029A2 RID: 10658 RVA: 0x000FCA74 File Offset: 0x000FAC74
	[Token(Token = "0x60029A2")]
	[Address(RVA = "0x2129E24", Offset = "0x2129E24", VA = "0x2129E24")]
	public static bool ېԗצ\u088D(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x060029A3 RID: 10659 RVA: 0x000FCA94 File Offset: 0x000FAC94
	[Token(Token = "0x60029A3")]
	[Address(RVA = "0x2129F04", Offset = "0x2129F04", VA = "0x2129F04")]
	public static bool \u0830\u07A9\u07ADܘ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (060029A3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::࠰ީޭܘ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060029A4 RID: 10660 RVA: 0x000FCAB4 File Offset: 0x000FACB4
	[Token(Token = "0x60029A4")]
	[Address(RVA = "0x2129FE4", Offset = "0x2129FE4", VA = "0x2129FE4")]
	public static Vector3 ԩ\u087EӶ٣(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029A5 RID: 10661 RVA: 0x000FCAEC File Offset: 0x000FACEC
	[Token(Token = "0x60029A5")]
	[Address(RVA = "0x212A170", Offset = "0x212A170", VA = "0x212A170")]
	public static bool ӥڰ߉ޑ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x060029A6 RID: 10662 RVA: 0x000FCB0C File Offset: 0x000FAD0C
	[Token(Token = "0x60029A6")]
	[Address(RVA = "0x212A250", Offset = "0x212A250", VA = "0x212A250")]
	public static bool \u087D١ܟ\u0701(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x060029A7 RID: 10663 RVA: 0x000FCB2C File Offset: 0x000FAD2C
	[Token(Token = "0x60029A7")]
	[Address(RVA = "0x212A334", Offset = "0x212A334", VA = "0x212A334")]
	public static Vector3 ࢠ\u070Fࡗٿ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029A8 RID: 10664 RVA: 0x000FCB64 File Offset: 0x000FAD64
	[Token(Token = "0x60029A8")]
	[Address(RVA = "0x212A4C0", Offset = "0x212A4C0", VA = "0x212A4C0")]
	public static Vector3 Ӱޒܝ\u0701(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029A9 RID: 10665 RVA: 0x000FCB9C File Offset: 0x000FAD9C
	[Token(Token = "0x60029A9")]
	[Address(RVA = "0x212A64C", Offset = "0x212A64C", VA = "0x212A64C")]
	public static Vector3 ֆԚԀݷ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029AA RID: 10666 RVA: 0x000FCBD4 File Offset: 0x000FADD4
	[Token(Token = "0x60029AA")]
	[Address(RVA = "0x212A7D8", Offset = "0x212A7D8", VA = "0x212A7D8")]
	public static bool \u0859ࡦ\u083F\u065C(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x060029AB RID: 10667 RVA: 0x000FCBF8 File Offset: 0x000FADF8
	[Token(Token = "0x60029AB")]
	[Address(RVA = "0x212A880", Offset = "0x212A880", VA = "0x212A880")]
	public static Vector3 \u07EEݎ߇\u07AF(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029AC RID: 10668 RVA: 0x000FCC30 File Offset: 0x000FAE30
	[Token(Token = "0x60029AC")]
	[Address(RVA = "0x212AA0C", Offset = "0x212AA0C", VA = "0x212AA0C")]
	public static bool ࡡ\u05A8\u0615Ԭ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x060029AD RID: 10669 RVA: 0x000FCC54 File Offset: 0x000FAE54
	[Token(Token = "0x60029AD")]
	[Address(RVA = "0x212AAB4", Offset = "0x212AAB4", VA = "0x212AAB4")]
	public static bool ՠ\u065E\u0656Ց(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x060029AE RID: 10670 RVA: 0x000FCC78 File Offset: 0x000FAE78
	[Token(Token = "0x60029AE")]
	[Address(RVA = "0x212AB5C", Offset = "0x212AB5C", VA = "0x212AB5C")]
	public static bool \u07F8\u066Dռ\u082F(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (060029AE)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::߸٭ռ࠯(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060029AF RID: 10671 RVA: 0x000FCC98 File Offset: 0x000FAE98
	[Token(Token = "0x60029AF")]
	[Address(RVA = "0x212AC3C", Offset = "0x212AC3C", VA = "0x212AC3C")]
	public static Vector3 \u059AӦٺٷ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029B0 RID: 10672 RVA: 0x000FCCD0 File Offset: 0x000FAED0
	[Token(Token = "0x60029B0")]
	[Address(RVA = "0x212ADC8", Offset = "0x212ADC8", VA = "0x212ADC8")]
	public static bool \u086C\u06D6\u085Aئ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (060029B0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::࡬࡚ۖئ(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060029B1 RID: 10673 RVA: 0x000FCCF0 File Offset: 0x000FAEF0
	[Token(Token = "0x60029B1")]
	[Address(RVA = "0x212AEA8", Offset = "0x212AEA8", VA = "0x212AEA8")]
	public static Vector3 \u0899ࠑՍ\u073D(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029B2 RID: 10674 RVA: 0x000FCD28 File Offset: 0x000FAF28
	[Token(Token = "0x60029B2")]
	[Address(RVA = "0x212B034", Offset = "0x212B034", VA = "0x212B034")]
	public static bool ࠋ\u07EDտ٦(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (060029B2)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ࠋ߭տ٦(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060029B3 RID: 10675 RVA: 0x000FCD48 File Offset: 0x000FAF48
	[Token(Token = "0x60029B3")]
	[Address(RVA = "0x212B114", Offset = "0x212B114", VA = "0x212B114")]
	public static bool \u0610ࢯݙ\u07B9(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (060029B3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ؐࢯݙ޹(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060029B4 RID: 10676 RVA: 0x000FCD68 File Offset: 0x000FAF68
	[Token(Token = "0x60029B4")]
	[Address(RVA = "0x212B1F4", Offset = "0x212B1F4", VA = "0x212B1F4")]
	public static Vector3 ࠉߟ\u07BEߒ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029B5 RID: 10677 RVA: 0x000FCDA0 File Offset: 0x000FAFA0
	[Token(Token = "0x60029B5")]
	[Address(RVA = "0x212B380", Offset = "0x212B380", VA = "0x212B380")]
	public static bool ء\u06E6ۏӗ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x060029B6 RID: 10678 RVA: 0x000FCDC4 File Offset: 0x000FAFC4
	[Token(Token = "0x60029B6")]
	[Address(RVA = "0x212B428", Offset = "0x212B428", VA = "0x212B428")]
	public static bool ӥվۅߒ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x060029B7 RID: 10679 RVA: 0x000FCDE8 File Offset: 0x000FAFE8
	[Token(Token = "0x60029B7")]
	[Address(RVA = "0x212B4D0", Offset = "0x212B4D0", VA = "0x212B4D0")]
	public static bool ڢ\u07F2\u061Bӫ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x060029B8 RID: 10680 RVA: 0x000FCE0C File Offset: 0x000FB00C
	[Token(Token = "0x60029B8")]
	[Address(RVA = "0x212B584", Offset = "0x212B584", VA = "0x212B584")]
	public static bool ڥګ\u059DՋ(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x060029B9 RID: 10681 RVA: 0x000FCE2C File Offset: 0x000FB02C
	[Token(Token = "0x60029B9")]
	[Address(RVA = "0x212B664", Offset = "0x212B664", VA = "0x212B664")]
	public static bool \u0590۹ӏ\u05C0(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x060029BA RID: 10682 RVA: 0x000FCE50 File Offset: 0x000FB050
	[Token(Token = "0x60029BA")]
	[Address(RVA = "0x212B70C", Offset = "0x212B70C", VA = "0x212B70C")]
	public static bool ࡊ\u059B\u064D\u0749(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		/*
An exception occurred when decompiling this method (060029BA)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean ܿࢨגࠓ::ࡊٍ֛݉(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(var_1_07, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(var_3_0F, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060029BB RID: 10683 RVA: 0x000FCE70 File Offset: 0x000FB070
	[Token(Token = "0x60029BB")]
	[Address(RVA = "0x212B7EC", Offset = "0x212B7EC", VA = "0x212B7EC")]
	public static bool \u07BBՂ\u06D7ވ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x060029BC RID: 10684 RVA: 0x000FCE94 File Offset: 0x000FB094
	[Token(Token = "0x60029BC")]
	[Address(RVA = "0x212B894", Offset = "0x212B894", VA = "0x212B894")]
	public static bool \u0610ԥ\u086Dۄ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x060029BD RID: 10685 RVA: 0x000FCEB8 File Offset: 0x000FB0B8
	[Token(Token = "0x60029BD")]
	[Address(RVA = "0x212B948", Offset = "0x212B948", VA = "0x212B948")]
	public static bool ۵\u089Cթ\u05B9(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x060029BE RID: 10686 RVA: 0x000FCEDC File Offset: 0x000FB0DC
	[Token(Token = "0x60029BE")]
	[Address(RVA = "0x212B9F0", Offset = "0x212B9F0", VA = "0x212B9F0")]
	public static bool ܒ\u07B4ەӽ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}

	// Token: 0x060029BF RID: 10687 RVA: 0x000FCF00 File Offset: 0x000FB100
	[Token(Token = "0x60029BF")]
	[Address(RVA = "0x212BAA4", Offset = "0x212BAA4", VA = "0x212BAA4")]
	public static bool ԑ\u060A\u082E\u086D(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x060029C0 RID: 10688 RVA: 0x000FCF24 File Offset: 0x000FB124
	[Token(Token = "0x60029C0")]
	[Address(RVA = "0x212BB4C", Offset = "0x212BB4C", VA = "0x212BB4C")]
	public static bool ࡐՐ\u087Bࢳ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x060029C1 RID: 10689 RVA: 0x000FCF48 File Offset: 0x000FB148
	[Token(Token = "0x60029C1")]
	[Address(RVA = "0x212BBF4", Offset = "0x212BBF4", VA = "0x212BBF4")]
	public static Vector3 ڀݒՎ\u0658(Vector3 \u06D8ԥ\u07ABӣ, LayerMask \u058E\u05F9ࡔࢲ, float ࡥڝԜ\u05B1, float \u088B\u0557ԍ\u055A, float ݴՠߎӀ)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x060029C2 RID: 10690 RVA: 0x000FCF80 File Offset: 0x000FB180
	[Token(Token = "0x60029C2")]
	[Address(RVA = "0x212BD80", Offset = "0x212BD80", VA = "0x212BD80")]
	public static bool ݘى\u05FAԎ(Vector3 \u07AC\u061EԿ\u0701)
	{
		Vector3 up = Vector3.up;
		bool result;
		return result;
	}
}
