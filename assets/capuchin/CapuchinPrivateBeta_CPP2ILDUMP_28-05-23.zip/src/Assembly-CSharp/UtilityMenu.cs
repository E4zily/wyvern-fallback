﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

// Token: 0x020000F0 RID: 240
[Token(Token = "0x20000F0")]
public class UtilityMenu : MonoBehaviour
{
	// Token: 0x060024D0 RID: 9424 RVA: 0x000C44D0 File Offset: 0x000C26D0
	[Token(Token = "0x60024D0")]
	[Address(RVA = "0x2C790F8", Offset = "0x2C790F8", VA = "0x2C790F8")]
	public void ثࡊߎ\u061E()
	{
	}

	// Token: 0x060024D1 RID: 9425 RVA: 0x000C44E0 File Offset: 0x000C26E0
	[Token(Token = "0x60024D1")]
	[Address(RVA = "0x2C790FC", Offset = "0x2C790FC", VA = "0x2C790FC")]
	public void ޛأࡒ\u059B(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "Player";
			return;
		}
	}

	// Token: 0x060024D2 RID: 9426 RVA: 0x000C450C File Offset: 0x000C270C
	[Token(Token = "0x60024D2")]
	[Address(RVA = "0x2C7916C", Offset = "0x2C7916C", VA = "0x2C7916C")]
	public void \u06D8\u07B0ݓݖ()
	{
	}

	// Token: 0x060024D3 RID: 9427 RVA: 0x000C451C File Offset: 0x000C271C
	[Token(Token = "0x60024D3")]
	[Address(RVA = "0x2C79170", Offset = "0x2C79170", VA = "0x2C79170")]
	public void \u085E\u070B\u06E1\u05FC()
	{
	}

	// Token: 0x060024D4 RID: 9428 RVA: 0x000C452C File Offset: 0x000C272C
	[Token(Token = "0x60024D4")]
	[Address(RVA = "0x2C79174", Offset = "0x2C79174", VA = "0x2C79174")]
	public void ӻ۶Ӭ\u07BD()
	{
	}

	// Token: 0x060024D5 RID: 9429 RVA: 0x000C453C File Offset: 0x000C273C
	[Token(Token = "0x60024D5")]
	[Address(RVA = "0x2C79178", Offset = "0x2C79178", VA = "0x2C79178")]
	public void ՠ٨ݨհ()
	{
	}

	// Token: 0x060024D6 RID: 9430 RVA: 0x000C454C File Offset: 0x000C274C
	[Token(Token = "0x60024D6")]
	[Address(RVA = "0x2C7917C", Offset = "0x2C7917C", VA = "0x2C7917C")]
	public void \u0816ڂږࡍ(int ࠊ\u082Bࡠ\u05A7)
	{
		this.\u081Bݹڐڄ = ࠊ\u082Bࡠ\u05A7;
	}

	// Token: 0x060024D7 RID: 9431 RVA: 0x000C4560 File Offset: 0x000C2760
	[Token(Token = "0x60024D7")]
	[Address(RVA = "0x2C79184", Offset = "0x2C79184", VA = "0x2C79184")]
	private void \u07FE\u0882Զ\u066D()
	{
		if (!true)
		{
		}
		string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x060024D8 RID: 9432 RVA: 0x000C45EC File Offset: 0x000C27EC
	[Token(Token = "0x60024D8")]
	[Address(RVA = "0x2C7935C", Offset = "0x2C7935C", VA = "0x2C7935C")]
	public void ܦ\u086E\u0599Ӊ()
	{
	}

	// Token: 0x060024D9 RID: 9433 RVA: 0x000C45FC File Offset: 0x000C27FC
	[Token(Token = "0x60024D9")]
	[Address(RVA = "0x2C79360", Offset = "0x2C79360", VA = "0x2C79360")]
	public void תޟس\u06D4()
	{
	}

	// Token: 0x060024DA RID: 9434 RVA: 0x000C460C File Offset: 0x000C280C
	[Token(Token = "0x60024DA")]
	[Address(RVA = "0x2C79364", Offset = "0x2C79364", VA = "0x2C79364")]
	public void ٿ\u07A6ӥߒ(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "You have been banned for ";
			return;
		}
	}

	// Token: 0x060024DB RID: 9435 RVA: 0x000C4638 File Offset: 0x000C2838
	[Token(Token = "0x60024DB")]
	[Address(RVA = "0x2C793D4", Offset = "0x2C793D4", VA = "0x2C793D4")]
	public void \u05F5\u055Eࡩ\u06E1()
	{
	}

	// Token: 0x060024DC RID: 9436 RVA: 0x000C4648 File Offset: 0x000C2848
	[Token(Token = "0x60024DC")]
	[Address(RVA = "0x2C793D8", Offset = "0x2C793D8", VA = "0x2C793D8")]
	private void \u05F7ԝߠӱ()
	{
		if (!true)
		{
		}
		string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x060024DD RID: 9437 RVA: 0x000C46DC File Offset: 0x000C28DC
	[Token(Token = "0x60024DD")]
	[Address(RVA = "0x2C79598", Offset = "0x2C79598", VA = "0x2C79598")]
	public void ܚ\u0652Հߟ()
	{
	}

	// Token: 0x060024DE RID: 9438 RVA: 0x000C46EC File Offset: 0x000C28EC
	[Token(Token = "0x60024DE")]
	[Address(RVA = "0x2C7959C", Offset = "0x2C7959C", VA = "0x2C7959C")]
	public void ٥ތܐۀ()
	{
	}

	// Token: 0x060024DF RID: 9439 RVA: 0x000C46FC File Offset: 0x000C28FC
	[Token(Token = "0x60024DF")]
	[Address(RVA = "0x2C795A0", Offset = "0x2C795A0", VA = "0x2C795A0")]
	public void \u0828ࠐԩۃ(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "BN";
			return;
		}
	}

	// Token: 0x060024E0 RID: 9440 RVA: 0x000C4728 File Offset: 0x000C2928
	[Token(Token = "0x60024E0")]
	[Address(RVA = "0x2C79610", Offset = "0x2C79610", VA = "0x2C79610")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		if (!true)
		{
		}
		string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x060024E1 RID: 9441 RVA: 0x000C47A8 File Offset: 0x000C29A8
	[Token(Token = "0x60024E1")]
	[Address(RVA = "0x2C797E8", Offset = "0x2C797E8", VA = "0x2C797E8")]
	private void ߄Ӄ\u0613ھ()
	{
		UtilityMenu.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060024E2 RID: 9442 RVA: 0x000C47BC File Offset: 0x000C29BC
	[Token(Token = "0x60024E2")]
	[Address(RVA = "0x2C7983C", Offset = "0x2C7983C", VA = "0x2C7983C")]
	public void \u0590ࢥ\u0748Ԥ()
	{
	}

	// Token: 0x060024E3 RID: 9443 RVA: 0x000C47CC File Offset: 0x000C29CC
	[Token(Token = "0x60024E3")]
	[Address(RVA = "0x2C79840", Offset = "0x2C79840", VA = "0x2C79840")]
	public void ԐٲࠈՔ()
	{
	}

	// Token: 0x060024E4 RID: 9444 RVA: 0x000C47DC File Offset: 0x000C29DC
	[Token(Token = "0x60024E4")]
	[Address(RVA = "0x2C79844", Offset = "0x2C79844", VA = "0x2C79844")]
	public UtilityMenu()
	{
	}

	// Token: 0x060024E5 RID: 9445 RVA: 0x000C47F0 File Offset: 0x000C29F0
	[Token(Token = "0x60024E5")]
	[Address(RVA = "0x2C7984C", Offset = "0x2C7984C", VA = "0x2C7984C")]
	public void \u070E\u07FE\u0836\u06DF(int ࠊ\u082Bࡠ\u05A7)
	{
		this.\u081Bݹڐڄ = ࠊ\u082Bࡠ\u05A7;
	}

	// Token: 0x060024E6 RID: 9446 RVA: 0x000C4804 File Offset: 0x000C2A04
	[Token(Token = "0x60024E6")]
	[Address(RVA = "0x2C79854", Offset = "0x2C79854", VA = "0x2C79854")]
	private void Update()
	{
		if (!true)
		{
		}
		string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x060024E7 RID: 9447 RVA: 0x000C4884 File Offset: 0x000C2A84
	[Token(Token = "0x60024E7")]
	[Address(RVA = "0x2C79A2C", Offset = "0x2C79A2C", VA = "0x2C79A2C")]
	private void צ\u0874ڵ\u059A()
	{
		if (!true)
		{
		}
		string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x060024E8 RID: 9448 RVA: 0x000C4910 File Offset: 0x000C2B10
	[Token(Token = "0x60024E8")]
	[Address(RVA = "0x2C79BEC", Offset = "0x2C79BEC", VA = "0x2C79BEC")]
	private void ١ۏ\u05C4ӝ()
	{
		UtilityMenu.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060024E9 RID: 9449 RVA: 0x000C4924 File Offset: 0x000C2B24
	[Token(Token = "0x60024E9")]
	[Address(RVA = "0x2C79C40", Offset = "0x2C79C40", VA = "0x2C79C40")]
	public void ۱ߨܨ٩(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "Diffuse";
			return;
		}
	}

	// Token: 0x060024EA RID: 9450 RVA: 0x000C4950 File Offset: 0x000C2B50
	[Token(Token = "0x60024EA")]
	[Address(RVA = "0x2C79CB0", Offset = "0x2C79CB0", VA = "0x2C79CB0")]
	public void ڝڋک\u0607()
	{
	}

	// Token: 0x060024EB RID: 9451 RVA: 0x000C4960 File Offset: 0x000C2B60
	[Token(Token = "0x60024EB")]
	[Address(RVA = "0x2C79CB4", Offset = "0x2C79CB4", VA = "0x2C79CB4")]
	public void ۈե\u061Cڼ(int ࠊ\u082Bࡠ\u05A7)
	{
		this.\u081Bݹڐڄ = ࠊ\u082Bࡠ\u05A7;
	}

	// Token: 0x060024EC RID: 9452 RVA: 0x000C4974 File Offset: 0x000C2B74
	[Token(Token = "0x60024EC")]
	[Address(RVA = "0x2C79CBC", Offset = "0x2C79CBC", VA = "0x2C79CBC")]
	public void \u07F2\u07B3\u087B\u088C(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "False";
			return;
		}
	}

	// Token: 0x060024ED RID: 9453 RVA: 0x000C49A0 File Offset: 0x000C2BA0
	[Token(Token = "0x60024ED")]
	[Address(RVA = "0x2C79D2C", Offset = "0x2C79D2C", VA = "0x2C79D2C")]
	private void ޡࠅ\u089Aߔ()
	{
	}

	// Token: 0x060024EE RID: 9454 RVA: 0x000C49B0 File Offset: 0x000C2BB0
	[Token(Token = "0x60024EE")]
	[Address(RVA = "0x2C79D80", Offset = "0x2C79D80", VA = "0x2C79D80")]
	public void ࢤ\u05B8ޱސ()
	{
	}

	// Token: 0x060024EF RID: 9455 RVA: 0x000C49C0 File Offset: 0x000C2BC0
	[Token(Token = "0x60024EF")]
	[Address(RVA = "0x2C79D84", Offset = "0x2C79D84", VA = "0x2C79D84")]
	public void ضۺեګ(int ࠊ\u082Bࡠ\u05A7)
	{
		this.\u081Bݹڐڄ = ࠊ\u082Bࡠ\u05A7;
	}

	// Token: 0x060024F0 RID: 9456 RVA: 0x000C49D4 File Offset: 0x000C2BD4
	[Token(Token = "0x60024F0")]
	[Address(RVA = "0x2C79D8C", Offset = "0x2C79D8C", VA = "0x2C79D8C")]
	public void Ԫ\u061Aݠج()
	{
	}

	// Token: 0x060024F1 RID: 9457 RVA: 0x000C49E4 File Offset: 0x000C2BE4
	[Token(Token = "0x60024F1")]
	[Address(RVA = "0x2C79D90", Offset = "0x2C79D90", VA = "0x2C79D90")]
	public void շ\u061A\u07ED\u081C(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "CASUAL";
			return;
		}
	}

	// Token: 0x060024F2 RID: 9458 RVA: 0x000C4A10 File Offset: 0x000C2C10
	[Token(Token = "0x60024F2")]
	[Address(RVA = "0x2C79E00", Offset = "0x2C79E00", VA = "0x2C79E00")]
	public void ӛהԔӶ()
	{
	}

	// Token: 0x060024F3 RID: 9459 RVA: 0x000C4A20 File Offset: 0x000C2C20
	[Token(Token = "0x60024F3")]
	[Address(RVA = "0x2C79E04", Offset = "0x2C79E04", VA = "0x2C79E04")]
	public void ދթ\u05B1ޣ(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "friend";
			return;
		}
	}

	// Token: 0x060024F4 RID: 9460 RVA: 0x000C4A4C File Offset: 0x000C2C4C
	[Token(Token = "0x60024F4")]
	[Address(RVA = "0x2C79E74", Offset = "0x2C79E74", VA = "0x2C79E74")]
	public void ڴࡍڡ\u0608()
	{
	}

	// Token: 0x060024F5 RID: 9461 RVA: 0x000C4A5C File Offset: 0x000C2C5C
	[Token(Token = "0x60024F5")]
	[Address(RVA = "0x2C79E78", Offset = "0x2C79E78", VA = "0x2C79E78")]
	public void פطثԱ()
	{
	}

	// Token: 0x060024F6 RID: 9462 RVA: 0x000C4A6C File Offset: 0x000C2C6C
	[Token(Token = "0x60024F6")]
	[Address(RVA = "0x2C79E7C", Offset = "0x2C79E7C", VA = "0x2C79E7C")]
	public void \u07F4\u07BB\u061C\u05B9()
	{
	}

	// Token: 0x060024F7 RID: 9463 RVA: 0x000C4A7C File Offset: 0x000C2C7C
	[Token(Token = "0x60024F7")]
	[Address(RVA = "0x2C79E80", Offset = "0x2C79E80", VA = "0x2C79E80")]
	private void ފՖߢ\u059B()
	{
		if (!true)
		{
		}
		string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x060024F8 RID: 9464 RVA: 0x000C4B08 File Offset: 0x000C2D08
	[Token(Token = "0x60024F8")]
	[Address(RVA = "0x2C7A034", Offset = "0x2C7A034", VA = "0x2C7A034")]
	private void Ӣ\u0592ߨׯ()
	{
		if (!true)
		{
		}
		string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x060024F9 RID: 9465 RVA: 0x000C4B94 File Offset: 0x000C2D94
	[Token(Token = "0x60024F9")]
	[Address(RVA = "0x2C7A20C", Offset = "0x2C7A20C", VA = "0x2C7A20C")]
	public void ڵ\u07B2ߦӚ()
	{
	}

	// Token: 0x060024FA RID: 9466 RVA: 0x000C4BA4 File Offset: 0x000C2DA4
	[Token(Token = "0x60024FA")]
	[Address(RVA = "0x2C7A210", Offset = "0x2C7A210", VA = "0x2C7A210")]
	public void ښ٨בࡦ(GameObject \u05F7\u0882ս\u05FB)
	{
		string text;
		if (text != null)
		{
			bool flag = text == "tutorialCheck";
			return;
		}
	}

	// Token: 0x060024FB RID: 9467 RVA: 0x000C4BC8 File Offset: 0x000C2DC8
	[Token(Token = "0x60024FB")]
	[Address(RVA = "0x2C7A280", Offset = "0x2C7A280", VA = "0x2C7A280")]
	private void Start()
	{
		UtilityMenu.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060024FC RID: 9468 RVA: 0x000C4BDC File Offset: 0x000C2DDC
	[Token(Token = "0x60024FC")]
	[Address(RVA = "0x2C7A2D4", Offset = "0x2C7A2D4", VA = "0x2C7A2D4")]
	public void ٲՖ\u06D9ࡣ()
	{
	}

	// Token: 0x060024FD RID: 9469 RVA: 0x000C4BEC File Offset: 0x000C2DEC
	[Token(Token = "0x60024FD")]
	[Address(RVA = "0x2C7A2D8", Offset = "0x2C7A2D8", VA = "0x2C7A2D8")]
	public void әڏ\u06D9ד(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "EnableCosmetic";
			return;
		}
	}

	// Token: 0x060024FE RID: 9470 RVA: 0x000C4C18 File Offset: 0x000C2E18
	[Token(Token = "0x60024FE")]
	[Address(RVA = "0x2C7A348", Offset = "0x2C7A348", VA = "0x2C7A348")]
	private void ݸԲ\u0616Ԫ()
	{
		UtilityMenu.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x060024FF RID: 9471 RVA: 0x000C4C2C File Offset: 0x000C2E2C
	[Token(Token = "0x60024FF")]
	[Address(RVA = "0x2C7A39C", Offset = "0x2C7A39C", VA = "0x2C7A39C")]
	private void ؤ\u05C8ԛ\u083F()
	{
		if (!true)
		{
		}
		string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x06002500 RID: 9472 RVA: 0x000C4CB8 File Offset: 0x000C2EB8
	[Token(Token = "0x6002500")]
	[Address(RVA = "0x2C7A574", Offset = "0x2C7A574", VA = "0x2C7A574")]
	public void ܮ\u0738\u085F\u0871()
	{
	}

	// Token: 0x06002501 RID: 9473 RVA: 0x000C4CC8 File Offset: 0x000C2EC8
	[Token(Token = "0x6002501")]
	[Address(RVA = "0x2C7A578", Offset = "0x2C7A578", VA = "0x2C7A578")]
	private void ߉ې\u07F6Ӭ()
	{
		UtilityMenu.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06002502 RID: 9474 RVA: 0x000C4CDC File Offset: 0x000C2EDC
	[Token(Token = "0x6002502")]
	[Address(RVA = "0x2C7A5CC", Offset = "0x2C7A5CC", VA = "0x2C7A5CC")]
	public void ԤࡖՉ\u0890(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "Joined a Room.";
			return;
		}
	}

	// Token: 0x06002503 RID: 9475 RVA: 0x000C4D08 File Offset: 0x000C2F08
	[Token(Token = "0x6002503")]
	[Address(RVA = "0x2C7A63C", Offset = "0x2C7A63C", VA = "0x2C7A63C")]
	public void ࡤھՆ\u07F3()
	{
	}

	// Token: 0x06002504 RID: 9476 RVA: 0x000C4D18 File Offset: 0x000C2F18
	[Token(Token = "0x6002504")]
	[Address(RVA = "0x2C7A640", Offset = "0x2C7A640", VA = "0x2C7A640")]
	public void \u086Dܔ\u06D4\u0611()
	{
	}

	// Token: 0x06002505 RID: 9477 RVA: 0x000C4D28 File Offset: 0x000C2F28
	[Token(Token = "0x6002505")]
	[Address(RVA = "0x2C7A644", Offset = "0x2C7A644", VA = "0x2C7A644")]
	public void Ԙչލ\u058A()
	{
	}

	// Token: 0x06002506 RID: 9478 RVA: 0x000C4D38 File Offset: 0x000C2F38
	[Token(Token = "0x6002506")]
	[Address(RVA = "0x2C7A648", Offset = "0x2C7A648", VA = "0x2C7A648")]
	public void ۋӌݙס(int ࠊ\u082Bࡠ\u05A7)
	{
		this.\u081Bݹڐڄ = ࠊ\u082Bࡠ\u05A7;
	}

	// Token: 0x06002507 RID: 9479 RVA: 0x000C4D4C File Offset: 0x000C2F4C
	[Token(Token = "0x6002507")]
	[Address(RVA = "0x2C7A650", Offset = "0x2C7A650", VA = "0x2C7A650")]
	public void ࠔՆڪԩ()
	{
	}

	// Token: 0x06002508 RID: 9480 RVA: 0x000C4D5C File Offset: 0x000C2F5C
	[Token(Token = "0x6002508")]
	[Address(RVA = "0x2C7A654", Offset = "0x2C7A654", VA = "0x2C7A654")]
	public void գ٥\u0742\u0707(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "2BN";
			return;
		}
	}

	// Token: 0x06002509 RID: 9481 RVA: 0x000C4D88 File Offset: 0x000C2F88
	[Token(Token = "0x6002509")]
	[Address(RVA = "0x2C7A6C4", Offset = "0x2C7A6C4", VA = "0x2C7A6C4")]
	private void \u0739߉ڵݞ()
	{
		UtilityMenu.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x0600250A RID: 9482 RVA: 0x000C4D9C File Offset: 0x000C2F9C
	[Token(Token = "0x600250A")]
	[Address(RVA = "0x2C7A718", Offset = "0x2C7A718", VA = "0x2C7A718")]
	private void \u05EDց\u081Cت()
	{
		if (!true)
		{
		}
		string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x0600250B RID: 9483 RVA: 0x000C4E28 File Offset: 0x000C3028
	[Token(Token = "0x600250B")]
	[Address(RVA = "0x2C7A8F0", Offset = "0x2C7A8F0", VA = "0x2C7A8F0")]
	public void \u05F7ޑٻ٣()
	{
	}

	// Token: 0x0600250C RID: 9484 RVA: 0x000C4E38 File Offset: 0x000C3038
	[Token(Token = "0x600250C")]
	[Address(RVA = "0x2C7A8F4", Offset = "0x2C7A8F4", VA = "0x2C7A8F4")]
	public void تࢠԛԜ()
	{
	}

	// Token: 0x0600250D RID: 9485 RVA: 0x000C4E48 File Offset: 0x000C3048
	[Token(Token = "0x600250D")]
	[Address(RVA = "0x2C7A8F8", Offset = "0x2C7A8F8", VA = "0x2C7A8F8")]
	public void އ\u05F8ߒ\u05C6()
	{
	}

	// Token: 0x0600250E RID: 9486 RVA: 0x000C4E58 File Offset: 0x000C3058
	[Token(Token = "0x600250E")]
	[Address(RVA = "0x2C7A8FC", Offset = "0x2C7A8FC", VA = "0x2C7A8FC")]
	public void \u05FE\u0899\u058Aԭ()
	{
	}

	// Token: 0x0600250F RID: 9487 RVA: 0x000C4E68 File Offset: 0x000C3068
	[Token(Token = "0x600250F")]
	[Address(RVA = "0x2C7A900", Offset = "0x2C7A900", VA = "0x2C7A900")]
	private void ࢥ\u081CՕࡋ()
	{
		UtilityMenu.كݕ\u05F3\u0589 = this;
	}

	// Token: 0x06002510 RID: 9488 RVA: 0x000C4E7C File Offset: 0x000C307C
	[Token(Token = "0x6002510")]
	[Address(RVA = "0x2C7A954", Offset = "0x2C7A954", VA = "0x2C7A954")]
	public void صیܔ\u0611()
	{
	}

	// Token: 0x06002511 RID: 9489 RVA: 0x000C4E8C File Offset: 0x000C308C
	[Token(Token = "0x6002511")]
	[Address(RVA = "0x2C7A958", Offset = "0x2C7A958", VA = "0x2C7A958")]
	public void \u088Cࢮӻࢱ()
	{
	}

	// Token: 0x06002512 RID: 9490 RVA: 0x000C4E9C File Offset: 0x000C309C
	[Token(Token = "0x6002512")]
	[Address(RVA = "0x2C7A95C", Offset = "0x2C7A95C", VA = "0x2C7A95C")]
	public void \u083D\u0651Դ\u07F2(int ࠊ\u082Bࡠ\u05A7)
	{
		this.\u081Bݹڐڄ = ࠊ\u082Bࡠ\u05A7;
	}

	// Token: 0x06002513 RID: 9491 RVA: 0x000C4EB0 File Offset: 0x000C30B0
	[Token(Token = "0x6002513")]
	[Address(RVA = "0x2C7A964", Offset = "0x2C7A964", VA = "0x2C7A964")]
	private void \u07B2\u0823ծݠ()
	{
		if (!true)
		{
		}
		string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x06002514 RID: 9492 RVA: 0x000C4F44 File Offset: 0x000C3144
	[Token(Token = "0x6002514")]
	[Address(RVA = "0x2C7AB24", Offset = "0x2C7AB24", VA = "0x2C7AB24")]
	public void إհՇۀ(int ࠊ\u082Bࡠ\u05A7)
	{
		this.\u081Bݹڐڄ = ࠊ\u082Bࡠ\u05A7;
	}

	// Token: 0x06002515 RID: 9493 RVA: 0x000C4F58 File Offset: 0x000C3158
	[Token(Token = "0x6002515")]
	[Address(RVA = "0x2C7AB2C", Offset = "0x2C7AB2C", VA = "0x2C7AB2C")]
	public void ӧחٮӆ(int ࠊ\u082Bࡠ\u05A7)
	{
		this.\u081Bݹڐڄ = ࠊ\u082Bࡠ\u05A7;
	}

	// Token: 0x06002516 RID: 9494 RVA: 0x000C4F6C File Offset: 0x000C316C
	[Token(Token = "0x6002516")]
	[Address(RVA = "0x2C7AB34", Offset = "0x2C7AB34", VA = "0x2C7AB34")]
	public void ࡦӒࡣد(int ࠊ\u082Bࡠ\u05A7)
	{
		this.\u081Bݹڐڄ = ࠊ\u082Bࡠ\u05A7;
	}

	// Token: 0x06002517 RID: 9495 RVA: 0x000C4F80 File Offset: 0x000C3180
	[Token(Token = "0x6002517")]
	[Address(RVA = "0x2C7AB3C", Offset = "0x2C7AB3C", VA = "0x2C7AB3C")]
	public void \u083E۳\u0735Ӓ(int ࠊ\u082Bࡠ\u05A7)
	{
		this.\u081Bݹڐڄ = ࠊ\u082Bࡠ\u05A7;
	}

	// Token: 0x06002518 RID: 9496 RVA: 0x000C4F94 File Offset: 0x000C3194
	[Token(Token = "0x6002518")]
	[Address(RVA = "0x2C7AB44", Offset = "0x2C7AB44", VA = "0x2C7AB44")]
	public void \u07F3\u0833ࢡ\u0708()
	{
	}

	// Token: 0x06002519 RID: 9497 RVA: 0x000C4FA4 File Offset: 0x000C31A4
	[Token(Token = "0x6002519")]
	[Address(RVA = "0x2C7AB48", Offset = "0x2C7AB48", VA = "0x2C7AB48")]
	public void \u060Fہ\u064Fݧ(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "KeyPos";
			return;
		}
	}

	// Token: 0x0600251A RID: 9498 RVA: 0x000C4FD0 File Offset: 0x000C31D0
	[Token(Token = "0x600251A")]
	[Address(RVA = "0x2C7ABB8", Offset = "0x2C7ABB8", VA = "0x2C7ABB8")]
	public void ڥٳ\u0609\u05CE()
	{
	}

	// Token: 0x0600251B RID: 9499 RVA: 0x000C4FE0 File Offset: 0x000C31E0
	[Token(Token = "0x600251B")]
	[Address(RVA = "0x2C7ABBC", Offset = "0x2C7ABBC", VA = "0x2C7ABBC")]
	public void \u081E߇Ӽ\u0602(GameObject \u05F7\u0882ս\u05FB)
	{
		string name = \u05F7\u0882ս\u05FB.name;
		if (name != null)
		{
			bool flag = name == "PRESS AGAIN TO CONFIRM";
			return;
		}
	}

	// Token: 0x0400049D RID: 1181
	[Token(Token = "0x400049D")]
	public static UtilityMenu كݕ\u05F3\u0589;

	// Token: 0x0400049E RID: 1182
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400049E")]
	private int \u081Bݹڐڄ;

	// Token: 0x0400049F RID: 1183
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400049F")]
	public TMP_Text[] \u088Eࡪܧӯ;
}
