﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.Rendering;

// Token: 0x02000080 RID: 128
[Token(Token = "0x2000080")]
public class MeshMerger : MonoBehaviour
{
	// Token: 0x0600137C RID: 4988 RVA: 0x0006E7DC File Offset: 0x0006C9DC
	[Token(Token = "0x600137C")]
	[Address(RVA = "0x2AA2C58", Offset = "0x2AA2C58", VA = "0x2AA2C58")]
	private Vector3 Վ\u06E7ݧ\u05CD(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600137D RID: 4989 RVA: 0x0006E7EC File Offset: 0x0006C9EC
	[Token(Token = "0x600137D")]
	[Address(RVA = "0x2AA2CD0", Offset = "0x2AA2CD0", VA = "0x2AA2CD0")]
	private Transform[] \u082Eۂ\u060F\u07B5(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600137E RID: 4990 RVA: 0x0006E83C File Offset: 0x0006CA3C
	[Token(Token = "0x600137E")]
	[Address(RVA = "0x2AA31D0", Offset = "0x2AA31D0", VA = "0x2AA31D0")]
	private Transform[] ۿ\u073Cԅ\u07EB(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600137F RID: 4991 RVA: 0x0006E88C File Offset: 0x0006CA8C
	[Token(Token = "0x600137F")]
	[Address(RVA = "0x2AA36E0", Offset = "0x2AA36E0", VA = "0x2AA36E0")]
	private Transform[] Ԇ\u05F6ݖࢠ(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001380 RID: 4992 RVA: 0x0006E8DC File Offset: 0x0006CADC
	[Token(Token = "0x6001380")]
	[Address(RVA = "0x2AA3BB4", Offset = "0x2AA3BB4", VA = "0x2AA3BB4")]
	private Vector3 \u0709\u086D\u059Eո(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001381 RID: 4993 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001381")]
	[Address(RVA = "0x2AA3BC4", Offset = "0x2AA3BC4", VA = "0x2AA3BC4")]
	public void \u0880߇ԝ\u05AA()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001382 RID: 4994 RVA: 0x0006E8EC File Offset: 0x0006CAEC
	[Token(Token = "0x6001382")]
	[Address(RVA = "0x2AA52F4", Offset = "0x2AA52F4", VA = "0x2AA52F4")]
	private Transform[] \u05BAޑݱٷ(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001383 RID: 4995 RVA: 0x0006E93C File Offset: 0x0006CB3C
	[Token(Token = "0x6001383")]
	[Address(RVA = "0x2AA57F4", Offset = "0x2AA57F4", VA = "0x2AA57F4")]
	private Vector3 ٩\u07BFԚێ(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001384 RID: 4996 RVA: 0x0006E94C File Offset: 0x0006CB4C
	[Token(Token = "0x6001384")]
	[Address(RVA = "0x2AA5804", Offset = "0x2AA5804", VA = "0x2AA5804")]
	private Mesh Ӹ\u06ECԼԵ(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "Not connected to room";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001385 RID: 4997 RVA: 0x0006E9C4 File Offset: 0x0006CBC4
	[Token(Token = "0x6001385")]
	[Address(RVA = "0x2AA5988", Offset = "0x2AA5988", VA = "0x2AA5988")]
	private Vector3 צޢݗي(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001386 RID: 4998 RVA: 0x0006E9D4 File Offset: 0x0006CBD4
	[Token(Token = "0x6001386")]
	[Address(RVA = "0x2AA5998", Offset = "0x2AA5998", VA = "0x2AA5998")]
	public void ۄ\u06DAࢨԜ()
	{
		new MeshMerger.\u0656ߤ\u0702ӳ().<>4__this = this;
		Transform[] mergeObjects = this._mergeObjects;
		Transform[] array = this.Ԇ\u05F6ݖࢠ(mergeObjects);
		Mesh[] array2 = new Mesh[0];
		if (typeof(Mesh[]).TypeHandle == null)
		{
		}
		Func<Transform, Mesh> func;
		if (MeshMerger.<>c.<>9__3_0 == null)
		{
			MeshMerger.<>c <> = MeshMerger.<>c.<>9;
			MeshMerger.<>c.<>9__3_0 = func;
		}
		IEnumerable<Mesh> enumerable = Enumerable.Select(array, func);
		Vector3[] array3 = new Vector3[0];
		int[] array4 = new int[0];
		Vector2[] array5 = new Vector2[0];
		Vector4[] array6 = new Vector4[1];
		Vector3[] array7 = new Vector3[1];
		long num = 48L;
		long num2 = 0L;
		MeshMerger.\u0656ߤ\u0702ӳ CS$<>8__locals1 = num2;
		Transform currentTransform = num2;
		MeshRenderer meshRenderer;
		Material[] sharedMaterials = meshRenderer.sharedMaterials;
		Material[] meshMaterials = sharedMaterials;
		Transform currentTransform2 = currentTransform;
		int num3;
		SubMeshDescriptor[] subMeshDescriptors2 = new SubMeshDescriptor[num3];
		SubMeshDescriptor[] subMeshDescriptors = subMeshDescriptors2;
		if (num == 0L)
		{
		}
		MeshMerger.ࢦӊԪڦ CS$<>8__locals3;
		int size = CS$<>8__locals3.CS$<>8__locals2.CS$<>8__locals1.subMeshesInfo._size;
		ThrowHelper.ThrowArgumentOutOfRangeException();
		ThrowHelper.ThrowArgumentOutOfRangeException();
		ThrowHelper.ThrowArgumentOutOfRangeException();
		ThrowHelper.ThrowArgumentOutOfRangeException();
		MeshMerger.ࢦӊԪڦ cs$<>8__locals = CS$<>8__locals3;
		ThrowHelper.ThrowArgumentOutOfRangeException();
		int subMeshInfoIndex;
		int subMeshInfoIndex2 = subMeshInfoIndex;
	}

	// Token: 0x06001387 RID: 4999 RVA: 0x0006EB98 File Offset: 0x0006CD98
	[Token(Token = "0x6001387")]
	[Address(RVA = "0x2AA7120", Offset = "0x2AA7120", VA = "0x2AA7120")]
	private Vector3 ޟ\u05A3ߚԷ(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001388 RID: 5000 RVA: 0x0006EBA8 File Offset: 0x0006CDA8
	[Token(Token = "0x6001388")]
	[Address(RVA = "0x2AA7130", Offset = "0x2AA7130", VA = "0x2AA7130")]
	private Mesh ۹\u073C߆ߓ(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "Platform failed to initialize due to exception.";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001389 RID: 5001 RVA: 0x0006EC18 File Offset: 0x0006CE18
	[Token(Token = "0x6001389")]
	[Address(RVA = "0x2AA72B4", Offset = "0x2AA72B4", VA = "0x2AA72B4")]
	private Transform[] ࢻՃݫն(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600138A RID: 5002 RVA: 0x0006EC68 File Offset: 0x0006CE68
	[Token(Token = "0x600138A")]
	[Address(RVA = "0x2AA5094", Offset = "0x2AA5094", VA = "0x2AA5094")]
	private Mesh ӌٳ\u0650\u07EF(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name;
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600138B RID: 5003 RVA: 0x0006ECD0 File Offset: 0x0006CED0
	[Token(Token = "0x600138B")]
	[Address(RVA = "0x2AA77A0", Offset = "0x2AA77A0", VA = "0x2AA77A0")]
	public void ڐ\u0859\u0656ԑ()
	{
		new MeshMerger.\u0656ߤ\u0702ӳ().<>4__this = this;
		Transform[] mergeObjects = this._mergeObjects;
		Transform[] array = this.\u05BAޑݱٷ(mergeObjects);
		Mesh[] array2 = new Mesh[0];
		if (typeof(Mesh[]).TypeHandle == null)
		{
		}
		if (MeshMerger.<>c.<>9__3_0 == null)
		{
			if (array == null)
			{
			}
			MeshMerger.<>c <> = MeshMerger.<>c.<>9;
			Func<Transform, Mesh> <>9__3_;
			MeshMerger.<>c.<>9__3_0 = <>9__3_;
		}
		Vector3[] array3 = new Vector3[0];
		int[] array4 = new int[1];
		Vector2[] array5 = new Vector2[0];
		Vector4[] array6 = new Vector4[1];
		Vector3[] array7 = new Vector3[0];
		MeshMerger.\u0838Ӑ\u0594\u0882 u0838Ӑ_u0594_u = new MeshMerger.\u0838Ӑ\u0594\u0882();
		long num = 0L;
		u0838Ӑ_u0594_u.CS$<>8__locals1 = num;
		if (typeof(MeshMerger.\u0838Ӑ\u0594\u0882).TypeHandle != null && typeof(MeshMerger.\u0838Ӑ\u0594\u0882).TypeHandle != null)
		{
			u0838Ӑ_u0594_u.currentTransform = num;
			if (typeof(MeshMerger.\u0838Ӑ\u0594\u0882).TypeHandle != null)
			{
				MeshRenderer meshRenderer;
				Material[] sharedMaterials = meshRenderer.sharedMaterials;
				u0838Ӑ_u0594_u.meshMaterials = sharedMaterials;
				Vector3 position = this._meshPivot.position;
				Transform currentTransform = u0838Ӑ_u0594_u.currentTransform;
				Vector3 vector = this.\u0889էہڗ(currentTransform);
				MeshMerger.ࢦӊԪڦ ࢦӊԪڦ = new MeshMerger.ࢦӊԪڦ();
				ࢦӊԪڦ.CS$<>8__locals2 = u0838Ӑ_u0594_u;
				if (u0838Ӑ_u0594_u.<>9__1 == null)
				{
					Func<Vector3, Vector3> <>9__;
					u0838Ӑ_u0594_u.<>9__1 = <>9__;
				}
				if (u0838Ӑ_u0594_u.<>9__2 == null)
				{
					Func<Vector4, Vector4> <>9__2;
					u0838Ӑ_u0594_u.<>9__2 = <>9__2;
				}
				if (u0838Ӑ_u0594_u.<>9__3 == null)
				{
					Func<Vector3, Vector3> <>9__3;
					u0838Ӑ_u0594_u.<>9__3 = <>9__3;
				}
				MeshMerger.ࢦӊԪڦ cs$<>8__locals = ࢦӊԪڦ;
				Func<int, int> subMeshInfoIndex2;
				int subMeshInfoIndex = subMeshInfoIndex2;
				MeshMerger.\u0838Ӑ\u0594\u0882 cs$<>8__locals2 = cs$<>8__locals.CS$<>8__locals2;
				Vector3 globalScale = cs$<>8__locals2.globalScale;
				ThrowHelper.ThrowArgumentOutOfRangeException();
				Transform currentTransform2 = cs$<>8__locals2.currentTransform;
				Vector3 globalScale2 = cs$<>8__locals2.globalScale;
				ThrowHelper.ThrowArgumentOutOfRangeException();
				Transform currentTransform3 = cs$<>8__locals2.currentTransform;
				Vector3 globalScale3 = cs$<>8__locals2.globalScale;
				ThrowHelper.ThrowArgumentOutOfRangeException();
				Transform currentTransform4 = cs$<>8__locals2.currentTransform;
				Vector3 globalScale4 = cs$<>8__locals2.globalScale;
				ThrowHelper.ThrowArgumentOutOfRangeException();
				Transform currentTransform5 = cs$<>8__locals2.currentTransform;
				Vector3 globalScale5 = cs$<>8__locals2.globalScale;
				ThrowHelper.ThrowArgumentOutOfRangeException();
				Transform currentTransform6 = cs$<>8__locals2.currentTransform;
				return;
			}
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x0600138C RID: 5004 RVA: 0x0006EF38 File Offset: 0x0006D138
	[Token(Token = "0x600138C")]
	[Address(RVA = "0x2AA8C48", Offset = "0x2AA8C48", VA = "0x2AA8C48")]
	private Transform[] տԯ\u0830ے(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600138D RID: 5005 RVA: 0x0006EF84 File Offset: 0x0006D184
	[Token(Token = "0x600138D")]
	[Address(RVA = "0x2AA8EBC", Offset = "0x2AA8EBC", VA = "0x2AA8EBC")]
	private Vector3 ڧވԣس(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600138E RID: 5006 RVA: 0x0006EF94 File Offset: 0x0006D194
	[Token(Token = "0x600138E")]
	[Address(RVA = "0x2AA8ECC", Offset = "0x2AA8ECC", VA = "0x2AA8ECC")]
	private Vector3 Ժؤ\u081Cݙ(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600138F RID: 5007 RVA: 0x0006EFA4 File Offset: 0x0006D1A4
	[Token(Token = "0x600138F")]
	[Address(RVA = "0x2AA8F44", Offset = "0x2AA8F44", VA = "0x2AA8F44")]
	private Vector3 ٲ\u07B5\u07F7ӑ(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001390 RID: 5008 RVA: 0x0006EFB4 File Offset: 0x0006D1B4
	[Token(Token = "0x6001390")]
	[Address(RVA = "0x2AA8FBC", Offset = "0x2AA8FBC", VA = "0x2AA8FBC")]
	private Vector3 עӣ\u073Cڄ(Transform \u07B6\u060E\u06FD\u087C)
	{
		Transform parent = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 localScale = \u07B6\u060E\u06FD\u087C.localScale;
		Transform parent2 = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 vector = this.ݱ٤\u082Fط(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001391 RID: 5009 RVA: 0x0006EFEC File Offset: 0x0006D1EC
	[Token(Token = "0x6001391")]
	[Address(RVA = "0x2AA91A4", Offset = "0x2AA91A4", VA = "0x2AA91A4")]
	private Vector3 ݽ١ܙݔ(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001392 RID: 5010 RVA: 0x0006EFFC File Offset: 0x0006D1FC
	[Token(Token = "0x6001392")]
	[Address(RVA = "0x2AA921C", Offset = "0x2AA921C", VA = "0x2AA921C")]
	private Vector3 \u088Dࡩ\u06EDԊ(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001393 RID: 5011 RVA: 0x0006F00C File Offset: 0x0006D20C
	[Token(Token = "0x6001393")]
	[Address(RVA = "0x2AA9294", Offset = "0x2AA9294", VA = "0x2AA9294")]
	private Transform[] ف\u061Aࢸࠋ(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001394 RID: 5012 RVA: 0x0006F058 File Offset: 0x0006D258
	[Token(Token = "0x6001394")]
	[Address(RVA = "0x2AA9780", Offset = "0x2AA9780", VA = "0x2AA9780")]
	public void ࠈڹդ\u0619()
	{
		Mesh[] array = new Mesh[0];
		if (typeof(Mesh[]).TypeHandle == null)
		{
		}
		if (MeshMerger.<>c.<>9__3_0 == null)
		{
			Transform[] array2;
			if (array2 == null)
			{
			}
			MeshMerger.<>c <> = MeshMerger.<>c.<>9;
			Func<Transform, Mesh> <>9__3_;
			MeshMerger.<>c.<>9__3_0 = <>9__3_;
		}
		Vector3[] vertices2 = new Vector3[0];
		Vector3[] vertices = vertices2;
		int[] array3 = new int[1];
		Vector2[] array4 = new Vector2[1];
		Vector4[] array5 = new Vector4[0];
		Vector3[] array6 = new Vector3[1];
		MeshMerger.\u0838Ӑ\u0594\u0882 u0838Ӑ_u0594_u = new MeshMerger.\u0838Ӑ\u0594\u0882();
		long num = 0L;
		u0838Ӑ_u0594_u.CS$<>8__locals1 = num;
		if (typeof(MeshMerger.\u0838Ӑ\u0594\u0882).TypeHandle != null && typeof(MeshMerger.\u0838Ӑ\u0594\u0882).TypeHandle != null)
		{
			u0838Ӑ_u0594_u.currentTransform = num;
			if (typeof(MeshMerger.\u0838Ӑ\u0594\u0882).TypeHandle != null)
			{
				MeshRenderer meshRenderer;
				Material[] sharedMaterials = meshRenderer.sharedMaterials;
				u0838Ӑ_u0594_u.meshMaterials = sharedMaterials;
				float z = u0838Ӑ_u0594_u.globalScale.z;
				Transform currentTransform = u0838Ӑ_u0594_u.currentTransform;
				int num2;
				SubMeshDescriptor[] subMeshDescriptors = new SubMeshDescriptor[num2];
				u0838Ӑ_u0594_u.subMeshDescriptors = subMeshDescriptors;
				u0838Ӑ_u0594_u.globalScale = u0838Ӑ_u0594_u;
				Transform currentTransform2 = u0838Ӑ_u0594_u.currentTransform;
				u0838Ӑ_u0594_u.globalScale = u0838Ӑ_u0594_u;
				if (u0838Ӑ_u0594_u.<>9__1 == null)
				{
				}
				ThrowHelper.ThrowArgumentOutOfRangeException();
				ThrowHelper.ThrowArgumentOutOfRangeException();
				ThrowHelper.ThrowArgumentOutOfRangeException();
				ThrowHelper.ThrowArgumentOutOfRangeException();
				ThrowHelper.ThrowArgumentOutOfRangeException();
				return;
			}
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x06001395 RID: 5013 RVA: 0x0006F214 File Offset: 0x0006D414
	[Token(Token = "0x6001395")]
	[Address(RVA = "0x2AA557C", Offset = "0x2AA557C", VA = "0x2AA557C")]
	private Transform[] ߙԂހ\u07F2(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001396 RID: 5014 RVA: 0x0006F264 File Offset: 0x0006D464
	[Token(Token = "0x6001396")]
	[Address(RVA = "0x2AAABF8", Offset = "0x2AAABF8", VA = "0x2AAABF8")]
	public MeshMerger()
	{
	}

	// Token: 0x06001397 RID: 5015 RVA: 0x0006F284 File Offset: 0x0006D484
	[Token(Token = "0x6001397")]
	[Address(RVA = "0x2AA4FA0", Offset = "0x2AA4FA0", VA = "0x2AA4FA0")]
	private Vector3 ࢧֈ\u07F2ի(Transform \u07B6\u060E\u06FD\u087C)
	{
		Vector3 localScale = \u07B6\u060E\u06FD\u087C.localScale;
		Transform parent = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 vector = this.ࢧֈ\u07F2ի(parent);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001398 RID: 5016 RVA: 0x0006F2B4 File Offset: 0x0006D4B4
	[Token(Token = "0x6001398")]
	[Address(RVA = "0x2AAAC54", Offset = "0x2AAAC54", VA = "0x2AAAC54")]
	private Vector3 ࡖ\u07B6ݧ\u0655(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001399 RID: 5017 RVA: 0x0006F2C4 File Offset: 0x0006D4C4
	[Token(Token = "0x6001399")]
	[Address(RVA = "0x2AAACCC", Offset = "0x2AAACCC", VA = "0x2AAACCC")]
	private Vector3 \u059Cաؤև(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600139A RID: 5018 RVA: 0x0006F2D4 File Offset: 0x0006D4D4
	[Token(Token = "0x600139A")]
	[Address(RVA = "0x2AAACDC", Offset = "0x2AAACDC", VA = "0x2AAACDC")]
	private Mesh ۼ\u0708ߛࡨ(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "Player";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		IntPtr cachedPtr = this.m_CachedPtr;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600139B RID: 5019 RVA: 0x0006F35C File Offset: 0x0006D55C
	[Token(Token = "0x600139B")]
	[Address(RVA = "0x2AAAE80", Offset = "0x2AAAE80", VA = "0x2AAAE80")]
	private Mesh \u05C1\u05BD\u064Eݕ(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "Version";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600139C RID: 5020 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600139C")]
	[Address(RVA = "0x2AAB004", Offset = "0x2AAB004", VA = "0x2AAB004")]
	public void թ\u07B6ޅԃ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600139D RID: 5021 RVA: 0x0006F3D4 File Offset: 0x0006D5D4
	[Token(Token = "0x600139D")]
	[Address(RVA = "0x2AAC634", Offset = "0x2AAC634", VA = "0x2AAC634")]
	private Mesh ߆ئ\u0823ӹ(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string objectName = this._objectName;
		string name;
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600139E RID: 5022 RVA: 0x0006F444 File Offset: 0x0006D644
	[Token(Token = "0x600139E")]
	[Address(RVA = "0x2AAC7B8", Offset = "0x2AAC7B8", VA = "0x2AAC7B8")]
	private Vector3 Ԛࠐࢸ\u07F7(Transform \u07B6\u060E\u06FD\u087C)
	{
		Transform u07B6_u060E_u06FD_u087C;
		Vector3 vector = this.Ԛࠐࢸ\u07F7(u07B6_u060E_u06FD_u087C);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x0600139F RID: 5023 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600139F")]
	[Address(RVA = "0x2AAC8AC", Offset = "0x2AAC8AC", VA = "0x2AAC8AC")]
	public void \u0820\u07FEաۺ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013A0 RID: 5024 RVA: 0x0006F468 File Offset: 0x0006D668
	[Token(Token = "0x60013A0")]
	[Address(RVA = "0x2AAE01C", Offset = "0x2AAE01C", VA = "0x2AAE01C")]
	private Vector3 \u06D8\u064BӒ\u06DA(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013A1 RID: 5025 RVA: 0x0006F478 File Offset: 0x0006D678
	[Token(Token = "0x60013A1")]
	[Address(RVA = "0x2AAE02C", Offset = "0x2AAE02C", VA = "0x2AAE02C")]
	private Vector3 \u05A5ע\u070B\u07F5(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013A2 RID: 5026 RVA: 0x0006F488 File Offset: 0x0006D688
	[Token(Token = "0x60013A2")]
	[Address(RVA = "0x2AAE03C", Offset = "0x2AAE03C", VA = "0x2AAE03C")]
	private Vector3 ޙԐڪࢥ(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013A3 RID: 5027 RVA: 0x0006F498 File Offset: 0x0006D698
	[Token(Token = "0x60013A3")]
	[Address(RVA = "0x2AAE04C", Offset = "0x2AAE04C", VA = "0x2AAE04C")]
	private Transform[] \u07FC\u05A2ײӽ(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060013A4 RID: 5028 RVA: 0x0006F4E8 File Offset: 0x0006D6E8
	[Token(Token = "0x60013A4")]
	[Address(RVA = "0x2AAE2D4", Offset = "0x2AAE2D4", VA = "0x2AAE2D4")]
	private Vector3 ڣ\u05F9ٻԫ(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013A5 RID: 5029 RVA: 0x0006F4F8 File Offset: 0x0006D6F8
	[Token(Token = "0x60013A5")]
	[Address(RVA = "0x2AAE2E4", Offset = "0x2AAE2E4", VA = "0x2AAE2E4")]
	private Mesh \u0894ԓ\u087F\u074B(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "username";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		IntPtr cachedPtr = this.m_CachedPtr;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x060013A6 RID: 5030 RVA: 0x0006F580 File Offset: 0x0006D780
	[Token(Token = "0x60013A6")]
	[Address(RVA = "0x2AAE488", Offset = "0x2AAE488", VA = "0x2AAE488")]
	private Transform[] \u06FDތ\u05B9ӷ(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060013A7 RID: 5031 RVA: 0x0006F5CC File Offset: 0x0006D7CC
	[Token(Token = "0x60013A7")]
	[Address(RVA = "0x2AA7044", Offset = "0x2AA7044", VA = "0x2AA7044")]
	private GameObject ޢ\u05CF\u07AB۰(Mesh Ӽו\u065Aߠ, Material[] ڋح\u05B6\u06E9)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = Ӽו\u065Aߠ;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = ڋح\u05B6\u06E9;
		return gameObject;
	}

	// Token: 0x060013A8 RID: 5032 RVA: 0x0006F604 File Offset: 0x0006D804
	[Token(Token = "0x60013A8")]
	[Address(RVA = "0x2AA3458", Offset = "0x2AA3458", VA = "0x2AA3458")]
	private Transform[] \u0592ڽӎճ(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060013A9 RID: 5033 RVA: 0x0006F654 File Offset: 0x0006D854
	[Token(Token = "0x60013A9")]
	[Address(RVA = "0x2AA5218", Offset = "0x2AA5218", VA = "0x2AA5218")]
	private GameObject ݼ\u07B7ܬࢮ(Mesh Ӽו\u065Aߠ, Material[] ڋح\u05B6\u06E9)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = Ӽו\u065Aߠ;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = ڋح\u05B6\u06E9;
		return gameObject;
	}

	// Token: 0x060013AA RID: 5034 RVA: 0x0006F68C File Offset: 0x0006D88C
	[Token(Token = "0x60013AA")]
	[Address(RVA = "0x2AA2F48", Offset = "0x2AA2F48", VA = "0x2AA2F48")]
	private Transform[] ڟكع\u06DD(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060013AB RID: 5035 RVA: 0x0006F6DC File Offset: 0x0006D8DC
	[Token(Token = "0x60013AB")]
	[Address(RVA = "0x2AAE6FC", Offset = "0x2AAE6FC", VA = "0x2AAE6FC")]
	private Vector3 ӑ\u0747Ռۿ(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013AC RID: 5036 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60013AC")]
	[Address(RVA = "0x2AAE774", Offset = "0x2AAE774", VA = "0x2AAE774")]
	public void קԶܐ\u0897()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013AD RID: 5037 RVA: 0x0006F6EC File Offset: 0x0006D8EC
	[Token(Token = "0x60013AD")]
	[Address(RVA = "0x2AAFBBC", Offset = "0x2AAFBBC", VA = "0x2AAFBBC")]
	private Vector3 ݍࢡߌߝ(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013AE RID: 5038 RVA: 0x0006F6FC File Offset: 0x0006D8FC
	[Token(Token = "0x60013AE")]
	[Address(RVA = "0x2AAFC34", Offset = "0x2AAFC34", VA = "0x2AAFC34")]
	private Vector3 \u05BCڣ\u05ACߘ(Transform \u07B6\u060E\u06FD\u087C)
	{
		Transform parent = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 localScale = \u07B6\u060E\u06FD\u087C.localScale;
		Transform parent2 = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 vector = this.Ԛࠐࢸ\u07F7(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x060013AF RID: 5039 RVA: 0x0006F734 File Offset: 0x0006D934
	[Token(Token = "0x60013AF")]
	[Address(RVA = "0x2AAFD28", Offset = "0x2AAFD28", VA = "0x2AAFD28")]
	private Vector3 \u06E5\u05AEש\u05F4(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013B0 RID: 5040 RVA: 0x0006F744 File Offset: 0x0006D944
	[Token(Token = "0x60013B0")]
	[Address(RVA = "0x2AAFDA0", Offset = "0x2AAFDA0", VA = "0x2AAFDA0")]
	private Vector3 \u066DӸܓԲ(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013B1 RID: 5041 RVA: 0x0006F754 File Offset: 0x0006D954
	[Token(Token = "0x60013B1")]
	[Address(RVA = "0x2AAFDB0", Offset = "0x2AAFDB0", VA = "0x2AAFDB0")]
	private Vector3 ࡘ\u0818ք\u0670(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013B2 RID: 5042 RVA: 0x0006F764 File Offset: 0x0006D964
	[Token(Token = "0x60013B2")]
	[Address(RVA = "0x2AAFE28", Offset = "0x2AAFE28", VA = "0x2AAFE28")]
	private Vector3 ؿڴڍ\u0883(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013B3 RID: 5043 RVA: 0x0006F774 File Offset: 0x0006D974
	[Token(Token = "0x60013B3")]
	[Address(RVA = "0x2AAC4B0", Offset = "0x2AAC4B0", VA = "0x2AAC4B0")]
	private Mesh څ\u0530ߋ\u0883(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "Thumb";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x060013B4 RID: 5044 RVA: 0x0006F7EC File Offset: 0x0006D9EC
	[Token(Token = "0x60013B4")]
	[Address(RVA = "0x2AAFE38", Offset = "0x2AAFE38", VA = "0x2AAFE38")]
	private Vector3 \u0731\u083Aք\u089A(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013B5 RID: 5045 RVA: 0x0006F7FC File Offset: 0x0006D9FC
	[Token(Token = "0x60013B5")]
	[Address(RVA = "0x2AA3954", Offset = "0x2AA3954", VA = "0x2AA3954")]
	private Transform[] \u055A\u089D\u0657\u0890(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		if (typeof(Transform[]).TypeHandle != null)
		{
			int childCount = array.childCount;
			if (typeof(Transform[]).TypeHandle != null)
			{
				Transform transform;
				if (transform == null || transform != null)
				{
					return transform;
				}
				throw new ArrayTypeMismatchException();
			}
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x060013B6 RID: 5046 RVA: 0x0006F854 File Offset: 0x0006DA54
	[Token(Token = "0x60013B6")]
	[Address(RVA = "0x2AAFE48", Offset = "0x2AAFE48", VA = "0x2AAFE48")]
	private Transform[] ڗ\u06E0ࢪޥ(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060013B7 RID: 5047 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60013B7")]
	[Address(RVA = "0x2AB00D0", Offset = "0x2AB00D0", VA = "0x2AB00D0")]
	public void փӖ\u0591ࡄ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013B8 RID: 5048 RVA: 0x0006F8A4 File Offset: 0x0006DAA4
	[Token(Token = "0x60013B8")]
	[Address(RVA = "0x2AB1654", Offset = "0x2AB1654", VA = "0x2AB1654")]
	private Transform[] ظࢻߎݔ(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060013B9 RID: 5049 RVA: 0x0006F8F0 File Offset: 0x0006DAF0
	[Token(Token = "0x60013B9")]
	[Address(RVA = "0x2AADCB8", Offset = "0x2AADCB8", VA = "0x2AADCB8")]
	private Transform[] \u0600\u0610ࡏ\u066C(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060013BA RID: 5050 RVA: 0x0006F934 File Offset: 0x0006DB34
	[Token(Token = "0x60013BA")]
	[Address(RVA = "0x2AB18B8", Offset = "0x2AB18B8", VA = "0x2AB18B8")]
	private GameObject ࢦޜࠄߔ(Mesh Ӽו\u065Aߠ, Material[] ڋح\u05B6\u06E9)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = Ӽו\u065Aߠ;
		MeshRenderer meshRenderer = gameObject.AddComponent<MeshRenderer>();
		return gameObject;
	}

	// Token: 0x060013BB RID: 5051 RVA: 0x0006F968 File Offset: 0x0006DB68
	[Token(Token = "0x60013BB")]
	[Address(RVA = "0x2AB1994", Offset = "0x2AB1994", VA = "0x2AB1994")]
	private Vector3 \u064Bӹߎࡒ(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013BC RID: 5052 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60013BC")]
	[Address(RVA = "0x2AB1A0C", Offset = "0x2AB1A0C", VA = "0x2AB1A0C")]
	public void Ԋ\u05C2\u05F3Ա()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013BD RID: 5053 RVA: 0x0006F978 File Offset: 0x0006DB78
	[Token(Token = "0x60013BD")]
	[Address(RVA = "0x2AB2E2C", Offset = "0x2AB2E2C", VA = "0x2AB2E2C")]
	private Vector3 ࠉ\u066CԽڅ(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013BE RID: 5054 RVA: 0x0006F988 File Offset: 0x0006DB88
	[Token(Token = "0x60013BE")]
	[Address(RVA = "0x2AB2EA4", Offset = "0x2AB2EA4", VA = "0x2AB2EA4")]
	private Mesh ޟܟգ\u061D(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "hh:mmtt";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x060013BF RID: 5055 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60013BF")]
	[Address(RVA = "0x2AB3028", Offset = "0x2AB3028", VA = "0x2AB3028")]
	public void زԠۍ\u0703()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013C0 RID: 5056 RVA: 0x0006FA00 File Offset: 0x0006DC00
	[Token(Token = "0x60013C0")]
	[Address(RVA = "0x2AB4404", Offset = "0x2AB4404", VA = "0x2AB4404")]
	private Vector3 ԝۯܔݽ(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013C1 RID: 5057 RVA: 0x0006FA10 File Offset: 0x0006DC10
	[Token(Token = "0x60013C1")]
	[Address(RVA = "0x2AA7528", Offset = "0x2AA7528", VA = "0x2AA7528")]
	private Transform[] ԢڽܪԆ(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060013C2 RID: 5058 RVA: 0x0006FA60 File Offset: 0x0006DC60
	[Token(Token = "0x60013C2")]
	[Address(RVA = "0x2AA94F8", Offset = "0x2AA94F8", VA = "0x2AA94F8")]
	private Transform[] كࡧٶՒ(Transform[] \u0835\u0835\u074A\u0659)
	{
		List<Transform> list = new List();
		int num;
		Transform[] array = new Transform[num];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null || transform != null)
		{
			return transform;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060013C3 RID: 5059 RVA: 0x0006FAB0 File Offset: 0x0006DCB0
	[Token(Token = "0x60013C3")]
	[Address(RVA = "0x2AADF40", Offset = "0x2AADF40", VA = "0x2AADF40")]
	private GameObject ࢺࡢࢦۅ(Mesh Ӽו\u065Aߠ, Material[] ڋح\u05B6\u06E9)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = Ӽו\u065Aߠ;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = ڋح\u05B6\u06E9;
		return gameObject;
	}

	// Token: 0x060013C4 RID: 5060 RVA: 0x0006FAE8 File Offset: 0x0006DCE8
	[Token(Token = "0x60013C4")]
	[Address(RVA = "0x2AB447C", Offset = "0x2AB447C", VA = "0x2AB447C")]
	private Vector3 \u0819ٺ\u06E5ԙ(Vector3 \u05CF\u074Cࢤӓ, Quaternion ց\u058Fڷࠏ, Vector3 \u0619\u0749ݗ\u0650, Vector3 ԣࡅڣ\u0651)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013C5 RID: 5061 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60013C5")]
	[Address(RVA = "0x2AB44F4", Offset = "0x2AB44F4", VA = "0x2AB44F4")]
	public void ݲ\u07F9زݛ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013C6 RID: 5062 RVA: 0x0006FAF8 File Offset: 0x0006DCF8
	[Token(Token = "0x60013C6")]
	[Address(RVA = "0x2AB5940", Offset = "0x2AB5940", VA = "0x2AB5940")]
	private GameObject \u065E\u07F3ط\u0879(Mesh Ӽו\u065Aߠ, Material[] ڋح\u05B6\u06E9)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = Ӽו\u065Aߠ;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = ڋح\u05B6\u06E9;
		return gameObject;
	}

	// Token: 0x060013C7 RID: 5063 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60013C7")]
	[Address(RVA = "0x2AAAB1C", Offset = "0x2AAAB1C", VA = "0x2AAAB1C")]
	private GameObject \u0640թդ\u07F3(Mesh Ӽו\u065Aߠ, Material[] ڋح\u05B6\u06E9)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013C8 RID: 5064 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60013C8")]
	[Address(RVA = "0x2AB5A1C", Offset = "0x2AB5A1C", VA = "0x2AB5A1C")]
	public void \u05A7ࢠڙ\u083F()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013C9 RID: 5065 RVA: 0x0006FB30 File Offset: 0x0006DD30
	[Token(Token = "0x60013C9")]
	[Address(RVA = "0x2AA6DCC", Offset = "0x2AA6DCC", VA = "0x2AA6DCC")]
	private Vector3 \u0889էہڗ(Transform \u07B6\u060E\u06FD\u087C)
	{
		Transform parent = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 localScale = \u07B6\u060E\u06FD\u087C.localScale;
		Transform parent2 = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 vector = this.\u0889էہڗ(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x060013CA RID: 5066 RVA: 0x0006FB68 File Offset: 0x0006DD68
	[Token(Token = "0x60013CA")]
	[Address(RVA = "0x2AB6E28", Offset = "0x2AB6E28", VA = "0x2AB6E28")]
	private Mesh ԦՋءӒ(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "typesOfTalk";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x060013CB RID: 5067 RVA: 0x0006FBE0 File Offset: 0x0006DDE0
	[Token(Token = "0x60013CB")]
	[Address(RVA = "0x2AB6FAC", Offset = "0x2AB6FAC", VA = "0x2AB6FAC")]
	private Mesh \u0618\u065DԺӇ(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "Mesh";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		IntPtr cachedPtr = this.m_CachedPtr;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x060013CC RID: 5068 RVA: 0x0006FC68 File Offset: 0x0006DE68
	[Token(Token = "0x60013CC")]
	[Address(RVA = "0x2AAC3BC", Offset = "0x2AAC3BC", VA = "0x2AAC3BC")]
	private Vector3 \u05B7ݰޡս(Transform \u07B6\u060E\u06FD\u087C)
	{
		Transform parent = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 localScale = \u07B6\u060E\u06FD\u087C.localScale;
		Transform parent2 = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 vector = this.עӣ\u073Cڄ(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x060013CD RID: 5069 RVA: 0x0006FCA0 File Offset: 0x0006DEA0
	[Token(Token = "0x60013CD")]
	[Address(RVA = "0x2AB7150", Offset = "0x2AB7150", VA = "0x2AB7150")]
	private Vector3 ӶՉ\u0609\u07BF(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013CE RID: 5070 RVA: 0x0006FCB0 File Offset: 0x0006DEB0
	[Token(Token = "0x60013CE")]
	[Address(RVA = "0x2AB7160", Offset = "0x2AB7160", VA = "0x2AB7160")]
	private Vector3 \u055Cݹ\u0828ࠈ(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060013CF RID: 5071 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60013CF")]
	[Address(RVA = "0x2AB7170", Offset = "0x2AB7170", VA = "0x2AB7170")]
	public void \u058D\u0837\u07A9ߙ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013D0 RID: 5072 RVA: 0x0006FCC0 File Offset: 0x0006DEC0
	[Token(Token = "0x60013D0")]
	[Address(RVA = "0x2AB85D0", Offset = "0x2AB85D0", VA = "0x2AB85D0")]
	private GameObject ޞ\u05EEӑܓ(Mesh Ӽו\u065Aߠ, Material[] ڋح\u05B6\u06E9)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = Ӽו\u065Aߠ;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = ڋح\u05B6\u06E9;
		return gameObject;
	}

	// Token: 0x060013D1 RID: 5073 RVA: 0x0006FCF8 File Offset: 0x0006DEF8
	[Token(Token = "0x60013D1")]
	[Address(RVA = "0x2AA6EC0", Offset = "0x2AA6EC0", VA = "0x2AA6EC0")]
	private Mesh \u083Bۃܔ\u0606(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "Starting to bake textures on frame ";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x060013D2 RID: 5074 RVA: 0x0006FD70 File Offset: 0x0006DF70
	[Token(Token = "0x60013D2")]
	[Address(RVA = "0x2AA90B0", Offset = "0x2AA90B0", VA = "0x2AA90B0")]
	private Vector3 ݱ٤\u082Fط(Transform \u07B6\u060E\u06FD\u087C)
	{
		Transform parent = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 localScale = \u07B6\u060E\u06FD\u087C.localScale;
		Transform parent2 = \u07B6\u060E\u06FD\u087C.parent;
		Vector3 vector = this.Ԛࠐࢸ\u07F7(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x060013D3 RID: 5075 RVA: 0x0006FDA8 File Offset: 0x0006DFA8
	[Token(Token = "0x60013D3")]
	[Address(RVA = "0x2AA8B6C", Offset = "0x2AA8B6C", VA = "0x2AA8B6C")]
	private GameObject \u065Aա\u059D\u087B(Mesh Ӽו\u065Aߠ, Material[] ڋح\u05B6\u06E9)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = Ӽו\u065Aߠ;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = ڋح\u05B6\u06E9;
		return gameObject;
	}

	// Token: 0x060013D4 RID: 5076 RVA: 0x0006FDE0 File Offset: 0x0006DFE0
	[Token(Token = "0x60013D4")]
	[Address(RVA = "0x2AB14D0", Offset = "0x2AB14D0", VA = "0x2AB14D0")]
	private Mesh \u07ADޠכچ(Vector3[] ࢸܒәܔ, int[] \u0601ܟݑհ, Vector2[] ތދӯԝ, Vector4[] \u06DAהԫݙ, Vector3[] ڑөԟӰ, SubMeshDescriptor[] ڨԬڿٴ)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = ࢸܒәܔ;
		mesh.triangles = \u0601ܟݑհ;
		mesh.uv = ތދӯԝ;
		mesh.tangents = \u06DAהԫݙ;
		mesh.normals = ڑөԟӰ;
		string name = this._objectName + "Starting to bake textures on frame ";
		mesh.name = name;
		MeshTopology <topology>k__BackingField = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField2 = ڨԬڿٴ.<topology>k__BackingField;
		MeshTopology <topology>k__BackingField3 = ڨԬڿٴ.<topology>k__BackingField;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x060013D5 RID: 5077 RVA: 0x0006FE58 File Offset: 0x0006E058
	[Token(Token = "0x60013D5")]
	[Address(RVA = "0x2AB86AC", Offset = "0x2AB86AC", VA = "0x2AB86AC")]
	private Vector3 ݢ\u06E9\u0737ԇ(Vector3 \u0891Ӈ\u074Cࡣ)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x04000269 RID: 617
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000269")]
	[SerializeField]
	private Transform[] _mergeObjects;

	// Token: 0x0400026A RID: 618
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400026A")]
	[SerializeField]
	private Transform _meshPivot;

	// Token: 0x0400026B RID: 619
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400026B")]
	[SerializeField]
	[Header("Save properties")]
	private string _objectName = "MergedObject";

	// Token: 0x02000081 RID: 129
	[Token(Token = "0x2000081")]
	private struct \u06EB\u089Aߠܝ
	{
		// Token: 0x0400026C RID: 620
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400026C")]
		public List<Vector3> Ճ٩\u07A8צ;

		// Token: 0x0400026D RID: 621
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x400026D")]
		public List<Vector2> էއۋ\u088F;

		// Token: 0x0400026E RID: 622
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400026E")]
		public List<Vector4> հ\u0605\u089Dڱ;

		// Token: 0x0400026F RID: 623
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400026F")]
		public List<Vector3> ࢹש\u05A4ࡒ;

		// Token: 0x04000270 RID: 624
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000270")]
		public List<int> \u06D6Փӽ\u0615;

		// Token: 0x04000271 RID: 625
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000271")]
		public Material \u07BA\u0879ࢱס;
	}

	// Token: 0x02000082 RID: 130
	[Token(Token = "0x2000082")]
	[CompilerGenerated]
	private sealed class \u0656ߤ\u0702ӳ
	{
		// Token: 0x060013D6 RID: 5078 RVA: 0x0006FE6C File Offset: 0x0006E06C
		[Token(Token = "0x60013D6")]
		[Address(RVA = "0x213346C", Offset = "0x213346C", VA = "0x213346C")]
		public \u0656ߤ\u0702ӳ()
		{
		}

		// Token: 0x060013D7 RID: 5079 RVA: 0x0006FE80 File Offset: 0x0006E080
		[Token(Token = "0x60013D7")]
		[Address(RVA = "0x2133474", Offset = "0x2133474", VA = "0x2133474")]
		internal int ࡨޗࢫ\u06D9(int index)
		{
			Vector3[] array = this.vertices;
			throw new NullReferenceException();
		}

		// Token: 0x04000272 RID: 626
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000272")]
		public MeshMerger <>4__this;

		// Token: 0x04000273 RID: 627
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000273")]
		public List<MeshMerger.\u06EB\u089Aߠܝ> subMeshesInfo;

		// Token: 0x04000274 RID: 628
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000274")]
		public Vector3[] vertices;

		// Token: 0x04000275 RID: 629
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000275")]
		public Func<int, int> <>9__7;
	}

	// Token: 0x02000083 RID: 131
	[Token(Token = "0x2000083")]
	[CompilerGenerated]
	private sealed class \u0838Ӑ\u0594\u0882
	{
		// Token: 0x060013D8 RID: 5080 RVA: 0x0006FE9C File Offset: 0x0006E09C
		[Token(Token = "0x60013D8")]
		[Address(RVA = "0x2133494", Offset = "0x2133494", VA = "0x2133494")]
		public \u0838Ӑ\u0594\u0882()
		{
		}

		// Token: 0x060013D9 RID: 5081 RVA: 0x0006FEB0 File Offset: 0x0006E0B0
		[Token(Token = "0x60013D9")]
		[Address(RVA = "0x213349C", Offset = "0x213349C", VA = "0x213349C")]
		internal Vector3 \u0654ӗ\u0839ԓ(Vector3 verticle)
		{
			MeshMerger.\u0656ߤ\u0702ӳ cs$<>8__locals = this.CS$<>8__locals1;
			Transform transform = this.currentTransform;
			MeshMerger <>4__this = cs$<>8__locals.<>4__this;
			Quaternion rotation = transform.rotation;
			float x = this.globalScale.x;
			float y = this.globalScale.y;
			float z = this.globalScale.z;
			Vector3 zero = Vector3.zero;
			float x2 = this.meshLocalPosition.x;
			float y2 = this.meshLocalPosition.y;
			float z2 = this.meshLocalPosition.z;
			throw new NullReferenceException();
		}

		// Token: 0x060013DA RID: 5082 RVA: 0x0006FF38 File Offset: 0x0006E138
		[Token(Token = "0x60013DA")]
		[Address(RVA = "0x2133574", Offset = "0x2133574", VA = "0x2133574")]
		internal Vector4 ވԫ\u073D\u081D(Vector4 tangent)
		{
			MeshMerger <>4__this = this.CS$<>8__locals1.<>4__this;
			Quaternion rotation = this.currentTransform.rotation;
			Vector3 one = Vector3.one;
			Vector3 zero = Vector3.zero;
			throw new NullReferenceException();
		}

		// Token: 0x060013DB RID: 5083 RVA: 0x0006FF7C File Offset: 0x0006E17C
		[Token(Token = "0x60013DB")]
		[Address(RVA = "0x213365C", Offset = "0x213365C", VA = "0x213365C")]
		internal Vector3 ղ\u0589پߔ(Vector3 normal)
		{
			MeshMerger.\u0656ߤ\u0702ӳ cs$<>8__locals = this.CS$<>8__locals1;
			Transform transform = this.currentTransform;
			MeshMerger <>4__this = cs$<>8__locals.<>4__this;
			Quaternion rotation = transform.rotation;
			Vector3 one = Vector3.one;
			Vector3 zero = Vector3.zero;
			throw new NullReferenceException();
		}

		// Token: 0x04000276 RID: 630
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000276")]
		public Transform currentTransform;

		// Token: 0x04000277 RID: 631
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000277")]
		public Vector3 globalScale;

		// Token: 0x04000278 RID: 632
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4000278")]
		public Vector3 meshLocalPosition;

		// Token: 0x04000279 RID: 633
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000279")]
		public SubMeshDescriptor[] subMeshDescriptors;

		// Token: 0x0400027A RID: 634
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x400027A")]
		public Material[] meshMaterials;

		// Token: 0x0400027B RID: 635
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x400027B")]
		public MeshMerger.\u0656ߤ\u0702ӳ CS$<>8__locals1;

		// Token: 0x0400027C RID: 636
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x400027C")]
		public Func<Vector3, Vector3> <>9__1;

		// Token: 0x0400027D RID: 637
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x400027D")]
		public Func<Vector4, Vector4> <>9__2;

		// Token: 0x0400027E RID: 638
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x400027E")]
		public Func<Vector3, Vector3> <>9__3;
	}

	// Token: 0x02000084 RID: 132
	[Token(Token = "0x2000084")]
	[CompilerGenerated]
	private sealed class ࢦӊԪڦ
	{
		// Token: 0x060013DC RID: 5084 RVA: 0x0006FFC0 File Offset: 0x0006E1C0
		[Token(Token = "0x60013DC")]
		[Address(RVA = "0x2133728", Offset = "0x2133728", VA = "0x2133728")]
		public ࢦӊԪڦ()
		{
		}

		// Token: 0x060013DD RID: 5085 RVA: 0x0006FFD4 File Offset: 0x0006E1D4
		[Token(Token = "0x60013DD")]
		[Address(RVA = "0x2133730", Offset = "0x2133730", VA = "0x2133730")]
		internal int ࢻޜ\u05CEݪ(int index)
		{
			MeshTopology <topology>k__BackingField = this.CS$<>8__locals2.subMeshDescriptors.<topology>k__BackingField;
			throw new NullReferenceException();
		}

		// Token: 0x060013DE RID: 5086 RVA: 0x00070000 File Offset: 0x0006E200
		[Token(Token = "0x60013DE")]
		[Address(RVA = "0x2133780", Offset = "0x2133780", VA = "0x2133780")]
		internal bool ڎ\u0701\u0838Ҽ(MeshMerger.\u06EB\u089Aߠܝ subMeshInfo)
		{
			Material[] meshMaterials = this.CS$<>8__locals2.meshMaterials;
			Material u07BA_u0879ࢱס = subMeshInfo.\u07BA\u0879ࢱס;
			if (meshMaterials == null)
			{
			}
			bool result;
			return result;
		}

		// Token: 0x0400027F RID: 639
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400027F")]
		public int i;

		// Token: 0x04000280 RID: 640
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000280")]
		public MeshMerger.\u0838Ӑ\u0594\u0882 CS$<>8__locals2;
	}

	// Token: 0x02000085 RID: 133
	[Token(Token = "0x2000085")]
	[CompilerGenerated]
	private sealed class ӜבࢯՖ
	{
		// Token: 0x060013DF RID: 5087 RVA: 0x00070030 File Offset: 0x0006E230
		[Token(Token = "0x60013DF")]
		[Address(RVA = "0x21333B8", Offset = "0x21333B8", VA = "0x21333B8")]
		public ӜבࢯՖ()
		{
		}

		// Token: 0x060013E0 RID: 5088 RVA: 0x000028F3 File Offset: 0x00000AF3
		[Token(Token = "0x60013E0")]
		[Address(RVA = "0x21333C0", Offset = "0x21333C0", VA = "0x21333C0")]
		internal int \u06DDܔࠆڋ(int index)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x04000281 RID: 641
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000281")]
		public int subMeshInfoIndex;

		// Token: 0x04000282 RID: 642
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000282")]
		public MeshMerger.ࢦӊԪڦ CS$<>8__locals3;
	}
}
