﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000041 RID: 65
[Token(Token = "0x2000041")]
public class Rope : MonoBehaviour
{
	// Token: 0x060008DF RID: 2271 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60008DF")]
	[Address(RVA = "0x2B649E4", Offset = "0x2B649E4", VA = "0x2B649E4")]
	private Vector3 ۰Ӄڤ\u05C4(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008E0 RID: 2272 RVA: 0x00030118 File Offset: 0x0002E318
	[Token(Token = "0x60008E0")]
	[Address(RVA = "0x2B64C5C", Offset = "0x2B64C5C", VA = "0x2B64C5C")]
	private void ޛөࠎ\u059F()
	{
		Color red = Color.red;
		Vector3 position = this.ࡐբغ\u0830.position;
		Vector3 position2 = this.ԕܫղԴ.position;
		Vector3 position3 = this.ࡐբغ\u0830.position;
		Vector3 position4 = this.ԕܫղԴ.position;
		float x = this.ڋӪ\u065E\u059C.x;
		float y = this.ڋӪ\u065E\u059C.y;
		float z = this.ڋӪ\u065E\u059C.z;
		float x2 = this.ڋӪ\u065E\u059C.x;
		float y2 = this.ڋӪ\u065E\u059C.y;
		float z2 = this.ڋӪ\u065E\u059C.z;
		Color yellow = Color.yellow;
		float x3 = this.ڋӪ\u065E\u059C.x;
		float y3 = this.ڋӪ\u065E\u059C.y;
		float z3 = this.ڋӪ\u065E\u059C.z;
		float x4 = this.ٿں\u0604ՠ.x;
		float y4 = this.ٿں\u0604ՠ.y;
		float z4 = this.ٿں\u0604ՠ.z;
		float x5 = this.ٿں\u0604ՠ.x;
		float y5 = this.ٿں\u0604ՠ.y;
		float z5 = this.ٿں\u0604ՠ.z;
	}

	// Token: 0x060008E1 RID: 2273 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60008E1")]
	[Address(RVA = "0x2B64DC0", Offset = "0x2B64DC0", VA = "0x2B64DC0")]
	private Vector3 \u0816ՇײӮ(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008E2 RID: 2274 RVA: 0x0003024C File Offset: 0x0002E44C
	[Token(Token = "0x60008E2")]
	[Address(RVA = "0x2B65028", Offset = "0x2B65028", VA = "0x2B65028")]
	private void ࢫ\u0876չՍ()
	{
		float u05B2ӽՉ_u060B = this.\u05B2ӽՉ\u060B;
		float deltaTime = Time.deltaTime;
		float num = this.ࢴۻݐԧ;
		bool ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		List<Vector3> ց_u06D8ڋڜ = this.Ց\u06D8ڋڜ;
		Transform ࡐբغ_u = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ2 = this.Ց\u06D8ڋڜ;
		Vector3 position = ࡐբغ_u.position;
		Vector3 position2 = this.ࡐբغ\u0830.position;
		Vector3 position3 = this.ԕܫղԴ.position;
		float u060Cկ_u0896_u07F = this.\u060Cկ\u0896\u07F1;
		float num2 = this.ԯտߐࡄ;
		Transform ࡐբغ_u2 = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ3 = this.Ց\u06D8ڋڜ;
		Vector3 position4 = ࡐբغ_u2.position;
		Vector3 position5 = this.ࡐբغ\u0830.position;
		Transform ࡐբغ_u3 = this.ࡐբغ\u0830;
		float u085EӶۯӴ = this.\u085EӶۯӴ;
		Vector3 position6 = ࡐբغ_u3.position;
		Vector3 position7 = this.ԕܫղԴ.position;
		Vector3 position8 = this.ԕܫղԴ.position;
		Transform transform = this.ԕܫղԴ;
		float u085EӶۯӴ2 = this.\u085EӶۯӴ;
		Vector3 position9 = transform.position;
		float value;
		float num3 = Mathf.Clamp01(value);
		Transform transform2 = this.ԕܫղԴ;
		List<Vector3> ց_u06D8ڋڜ4 = this.Ց\u06D8ڋڜ;
		Vector3 position10 = transform2.position;
		List<Vector3> ց_u06D8ڋڜ5 = this.Ց\u06D8ڋڜ;
		this.ӻࡤ\u05B6י = u085EӶۯӴ;
		float deltaTime2 = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float x = this.ࠂࡦԈل.x;
		float z = this.Ծ\u06FEࢷࡘ.z;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		float z2 = this.ࠂࡦԈل.z;
		float z3 = this.\u05AF\u06D9ܬ\u0705.z;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		Transform ࡐբغ_u4 = this.ࡐբغ\u0830;
		this.ڗٽ\u05BDմ.z = u05B2ӽՉ_u060B;
		this.ࠂࡦԈل.x = x;
		Vector3 position11 = ࡐբغ_u4.position;
		Vector3 position12 = this.ԕܫղԴ.position;
		this.\u05B2ӽՉ\u060B = (float)8192;
	}

	// Token: 0x060008E3 RID: 2275 RVA: 0x00030420 File Offset: 0x0002E620
	[Token(Token = "0x60008E3")]
	[Address(RVA = "0x2B65880", Offset = "0x2B65880", VA = "0x2B65880")]
	private void ժ\u065Dԯࡘ()
	{
		float u05B2ӽՉ_u060B = this.\u05B2ӽՉ\u060B;
		float deltaTime = Time.deltaTime;
		float num = this.ࢴۻݐԧ;
		bool ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		List<Vector3> ց_u06D8ڋڜ = this.Ց\u06D8ڋڜ;
		Transform ࡐբغ_u = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ2 = this.Ց\u06D8ڋڜ;
		Vector3 position = ࡐբغ_u.position;
		Vector3 position2 = this.ࡐբغ\u0830.position;
		Vector3 position3 = this.ԕܫղԴ.position;
		float u060Cկ_u0896_u07F = this.\u060Cկ\u0896\u07F1;
		float num2 = this.ԯտߐࡄ;
		Transform ࡐբغ_u2 = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ3 = this.Ց\u06D8ڋڜ;
		Vector3 position4 = ࡐբغ_u2.position;
		Vector3 position5 = this.ࡐբغ\u0830.position;
		Transform ࡐբغ_u3 = this.ࡐբغ\u0830;
		float u085EӶۯӴ = this.\u085EӶۯӴ;
		Vector3 position6 = ࡐբغ_u3.position;
		Vector3 position7 = this.ԕܫղԴ.position;
		Vector3 position8 = this.ԕܫղԴ.position;
		Transform transform = this.ԕܫղԴ;
		float u085EӶۯӴ2 = this.\u085EӶۯӴ;
		Vector3 position9 = transform.position;
		float value;
		float num3 = Mathf.Clamp01(value);
		Transform transform2 = this.ԕܫղԴ;
		List<Vector3> ց_u06D8ڋڜ4 = this.Ց\u06D8ڋڜ;
		Vector3 position10 = transform2.position;
		List<Vector3> ց_u06D8ڋڜ5 = this.Ց\u06D8ڋڜ;
		float deltaTime2 = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float x = this.ࠂࡦԈل.x;
		float z = this.Ծ\u06FEࢷࡘ.z;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		float z2 = this.ࠂࡦԈل.z;
		float z3 = this.\u05AF\u06D9ܬ\u0705.z;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		Transform ࡐբغ_u4 = this.ࡐբغ\u0830;
		this.ڗٽ\u05BDմ.z = u085EӶۯӴ2;
		this.ࠂࡦԈل.x = x;
		Vector3 position11 = ࡐբغ_u4.position;
		Vector3 position12 = this.ԕܫղԴ.position;
		int u05B2ӽՉ_u060B2 = 16384;
		this.\u05B2ӽՉ\u060B = (float)u05B2ӽՉ_u060B2;
	}

	// Token: 0x060008E4 RID: 2276 RVA: 0x000305F4 File Offset: 0x0002E7F4
	[Token(Token = "0x60008E4")]
	[Address(RVA = "0x2B65E0C", Offset = "0x2B65E0C", VA = "0x2B65E0C")]
	private void \u0654ޛ\u07FAذ()
	{
		float u05B2ӽՉ_u060B = this.\u05B2ӽՉ\u060B;
		float deltaTime = Time.deltaTime;
		float num = this.ࢴۻݐԧ;
		bool ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		List<Vector3> ց_u06D8ڋڜ = this.Ց\u06D8ڋڜ;
		Transform ࡐբغ_u = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ2 = this.Ց\u06D8ڋڜ;
		Vector3 position = ࡐբغ_u.position;
		Vector3 position2 = this.ࡐբغ\u0830.position;
		Vector3 position3 = this.ԕܫղԴ.position;
		float u060Cկ_u0896_u07F = this.\u060Cկ\u0896\u07F1;
		float num2 = this.ԯտߐࡄ;
		Transform ࡐբغ_u2 = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ3 = this.Ց\u06D8ڋڜ;
		Vector3 position4 = ࡐբغ_u2.position;
		Vector3 position5 = this.ࡐբغ\u0830.position;
		Transform ࡐբغ_u3 = this.ࡐբغ\u0830;
		float u085EӶۯӴ = this.\u085EӶۯӴ;
		Vector3 position6 = ࡐբغ_u3.position;
		Vector3 position7 = this.ԕܫղԴ.position;
		Vector3 position8 = this.ԕܫղԴ.position;
		Transform transform = this.ԕܫղԴ;
		float u085EӶۯӴ2 = this.\u085EӶۯӴ;
		Vector3 position9 = transform.position;
		float value;
		float num3 = Mathf.Clamp01(value);
		Transform transform2 = this.ԕܫղԴ;
		List<Vector3> ց_u06D8ڋڜ4 = this.Ց\u06D8ڋڜ;
		Vector3 position10 = transform2.position;
		List<Vector3> ց_u06D8ڋڜ5 = this.Ց\u06D8ڋڜ;
		this.ӻࡤ\u05B6י = u085EӶۯӴ;
		float deltaTime2 = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float z = this.Ծ\u06FEࢷࡘ.z;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		float z2 = this.ࠂࡦԈل.z;
		float z3 = this.\u05AF\u06D9ܬ\u0705.z;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		Transform ࡐբغ_u4 = this.ࡐբغ\u0830;
		this.ڗٽ\u05BDմ.z = u05B2ӽՉ_u060B;
		Vector3 position11 = ࡐբغ_u4.position;
		Vector3 position12 = this.ԕܫղԴ.position;
		this.\u05B2ӽՉ\u060B = (float)49152;
	}

	// Token: 0x060008E5 RID: 2277 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60008E5")]
	[Address(RVA = "0x2B6638C", Offset = "0x2B6638C", VA = "0x2B6638C")]
	private Vector3 ߩӕ\u05C9۷(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008E6 RID: 2278 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60008E6")]
	[Address(RVA = "0x2B6667C", Offset = "0x2B6667C", VA = "0x2B6667C")]
	private Vector3 ࡥӈܞࡔ(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008E7 RID: 2279 RVA: 0x000307B0 File Offset: 0x0002E9B0
	[Token(Token = "0x60008E7")]
	[Address(RVA = "0x2B65CA0", Offset = "0x2B65CA0", VA = "0x2B65CA0")]
	private void ࢥ\u073Fݩۀ(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			int positionCount2 = u089A_u0875Աގ.positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008E8 RID: 2280 RVA: 0x00030800 File Offset: 0x0002EA00
	[Token(Token = "0x60008E8")]
	[Address(RVA = "0x2B66964", Offset = "0x2B66964", VA = "0x2B66964")]
	private void Update()
	{
		float u05B2ӽՉ_u060B = this.\u05B2ӽՉ\u060B;
		float deltaTime = Time.deltaTime;
		float num = this.ࢴۻݐԧ;
		bool ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		List<Vector3> ց_u06D8ڋڜ = this.Ց\u06D8ڋڜ;
		Transform ࡐբغ_u = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ2 = this.Ց\u06D8ڋڜ;
		Vector3 position = ࡐբغ_u.position;
		Vector3 position2 = this.ࡐբغ\u0830.position;
		Vector3 position3 = this.ԕܫղԴ.position;
		float u060Cկ_u0896_u07F = this.\u060Cկ\u0896\u07F1;
		float y = this.ԯտߐࡄ;
		Transform ࡐբغ_u2 = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ3 = this.Ց\u06D8ڋڜ;
		Vector3 position4 = ࡐբغ_u2.position;
		Vector3 position5 = this.ࡐբغ\u0830.position;
		Transform ࡐբغ_u3 = this.ࡐբغ\u0830;
		float u085EӶۯӴ = this.\u085EӶۯӴ;
		Vector3 position6 = ࡐբغ_u3.position;
		Vector3 position7 = this.ԕܫղԴ.position;
		Vector3 position8 = this.ԕܫղԴ.position;
		Transform transform = this.ԕܫղԴ;
		float u085EӶۯӴ2 = this.\u085EӶۯӴ;
		Vector3 position9 = transform.position;
		float value;
		float num2 = Mathf.Clamp01(value);
		Transform transform2 = this.ԕܫղԴ;
		List<Vector3> ց_u06D8ڋڜ4 = this.Ց\u06D8ڋڜ;
		Vector3 position10 = transform2.position;
		List<Vector3> ց_u06D8ڋڜ5 = this.Ց\u06D8ڋڜ;
		this.ڋӪ\u065E\u059C.y = y;
		this.ڋӪ\u065E\u059C.z = u060Cկ_u0896_u07F;
		float deltaTime2 = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		float z = this.\u05AF\u06D9ܬ\u0705.z;
		float x = this.ࠂࡦԈل.x;
		float z2 = this.Ծ\u06FEࢷࡘ.z;
		float z3 = this.ࠂࡦԈل.z;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		Vector3 position11 = this.ࡐբغ\u0830.position;
		Vector3 position12 = this.ԕܫղԴ.position;
	}

	// Token: 0x060008E9 RID: 2281 RVA: 0x000309C0 File Offset: 0x0002EBC0
	[Token(Token = "0x60008E9")]
	[Address(RVA = "0x2B67164", Offset = "0x2B67164", VA = "0x2B67164")]
	private void \u07B3\u05B3\u06EBࠈ(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount2 = u089A_u0875Աގ2.positionCount;
			LineRenderer u089A_u0875Աގ3 = this.\u089A\u0875Աގ;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008EA RID: 2282 RVA: 0x00030A18 File Offset: 0x0002EC18
	[Token(Token = "0x60008EA")]
	[Address(RVA = "0x2B65728", Offset = "0x2B65728", VA = "0x2B65728")]
	private void \u065E\u0653ܭܚ(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			int positionCount2 = this.\u089A\u0875Աގ.positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008EB RID: 2283 RVA: 0x00030A68 File Offset: 0x0002EC68
	[Token(Token = "0x60008EB")]
	[Address(RVA = "0x2B672D0", Offset = "0x2B672D0", VA = "0x2B672D0")]
	private void Սԑ۷\u0832()
	{
		Color red = Color.red;
		Vector3 position = this.ࡐբغ\u0830.position;
		Vector3 position2 = this.ԕܫղԴ.position;
		Vector3 position3 = this.ࡐբغ\u0830.position;
		Vector3 position4 = this.ԕܫղԴ.position;
		float x = this.ڋӪ\u065E\u059C.x;
		float y = this.ڋӪ\u065E\u059C.y;
		float z = this.ڋӪ\u065E\u059C.z;
		float x2 = this.ڋӪ\u065E\u059C.x;
		float y2 = this.ڋӪ\u065E\u059C.y;
		float z2 = this.ڋӪ\u065E\u059C.z;
		Color yellow = Color.yellow;
		float x3 = this.ڋӪ\u065E\u059C.x;
		float y3 = this.ڋӪ\u065E\u059C.y;
		float z3 = this.ڋӪ\u065E\u059C.z;
		float x4 = this.ٿں\u0604ՠ.x;
		float y4 = this.ٿں\u0604ՠ.y;
		float z4 = this.ٿں\u0604ՠ.z;
		float x5 = this.ٿں\u0604ՠ.x;
		float y5 = this.ٿں\u0604ՠ.y;
		float z5 = this.ٿں\u0604ՠ.z;
	}

	// Token: 0x060008EC RID: 2284 RVA: 0x00030B9C File Offset: 0x0002ED9C
	[Token(Token = "0x60008EC")]
	[Address(RVA = "0x2B67434", Offset = "0x2B67434", VA = "0x2B67434")]
	private void ا۱Օࡨ()
	{
		Color red = Color.red;
		Vector3 position = this.ࡐբغ\u0830.position;
		Vector3 position2 = this.ԕܫղԴ.position;
		Vector3 position3 = this.ࡐբغ\u0830.position;
		Vector3 position4 = this.ԕܫղԴ.position;
		float x = this.ڋӪ\u065E\u059C.x;
		float y = this.ڋӪ\u065E\u059C.y;
		float z = this.ڋӪ\u065E\u059C.z;
		float x2 = this.ڋӪ\u065E\u059C.x;
		float y2 = this.ڋӪ\u065E\u059C.y;
		float z2 = this.ڋӪ\u065E\u059C.z;
		Color yellow = Color.yellow;
		float x3 = this.ڋӪ\u065E\u059C.x;
		float y3 = this.ڋӪ\u065E\u059C.y;
		float z3 = this.ڋӪ\u065E\u059C.z;
		float x4 = this.ٿں\u0604ՠ.x;
		float y4 = this.ٿں\u0604ՠ.y;
		float z4 = this.ٿں\u0604ՠ.z;
		float x5 = this.ٿں\u0604ՠ.x;
		float y5 = this.ٿں\u0604ՠ.y;
		float z5 = this.ٿں\u0604ՠ.z;
	}

	// Token: 0x060008ED RID: 2285 RVA: 0x00030CD0 File Offset: 0x0002EED0
	[Token(Token = "0x60008ED")]
	[Address(RVA = "0x2B67594", Offset = "0x2B67594", VA = "0x2B67594")]
	private void Է\u06DC\u089Dࢰ()
	{
		Color red = Color.red;
		Vector3 position = this.ࡐբغ\u0830.position;
		Vector3 position2 = this.ԕܫղԴ.position;
		Vector3 position3 = this.ࡐբغ\u0830.position;
		Vector3 position4 = this.ԕܫղԴ.position;
		float x = this.ڋӪ\u065E\u059C.x;
		float y = this.ڋӪ\u065E\u059C.y;
		float z = this.ڋӪ\u065E\u059C.z;
		float x2 = this.ڋӪ\u065E\u059C.x;
		float y2 = this.ڋӪ\u065E\u059C.y;
		float z2 = this.ڋӪ\u065E\u059C.z;
		Color yellow = Color.yellow;
		float x3 = this.ڋӪ\u065E\u059C.x;
		float y3 = this.ڋӪ\u065E\u059C.y;
		float z3 = this.ڋӪ\u065E\u059C.z;
		float x4 = this.ٿں\u0604ՠ.x;
		float y4 = this.ٿں\u0604ՠ.y;
		float z4 = this.ٿں\u0604ՠ.z;
		float x5 = this.ٿں\u0604ՠ.x;
		float y5 = this.ٿں\u0604ՠ.y;
		float z5 = this.ٿں\u0604ՠ.z;
	}

	// Token: 0x060008EE RID: 2286 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60008EE")]
	[Address(RVA = "0x2B66D48", Offset = "0x2B66D48", VA = "0x2B66D48")]
	private Vector3 Ӭ\u05AC\u0897ف(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008EF RID: 2287 RVA: 0x00030E04 File Offset: 0x0002F004
	[Token(Token = "0x60008EF")]
	[Address(RVA = "0x2B676F8", Offset = "0x2B676F8", VA = "0x2B676F8")]
	private void OnDrawGizmos()
	{
		Color red = Color.red;
		Vector3 position = this.ࡐբغ\u0830.position;
		Vector3 position2 = this.ԕܫղԴ.position;
		Vector3 position3 = this.ࡐբغ\u0830.position;
		Vector3 position4 = this.ԕܫղԴ.position;
		float x = this.ڋӪ\u065E\u059C.x;
		float y = this.ڋӪ\u065E\u059C.y;
		float z = this.ڋӪ\u065E\u059C.z;
		float x2 = this.ڋӪ\u065E\u059C.x;
		float y2 = this.ڋӪ\u065E\u059C.y;
		float z2 = this.ڋӪ\u065E\u059C.z;
		Color yellow = Color.yellow;
		float x3 = this.ڋӪ\u065E\u059C.x;
		float y3 = this.ڋӪ\u065E\u059C.y;
		float z3 = this.ڋӪ\u065E\u059C.z;
		float x4 = this.ٿں\u0604ՠ.x;
		float y4 = this.ٿں\u0604ՠ.y;
		float z4 = this.ٿں\u0604ՠ.z;
		float x5 = this.ٿں\u0604ՠ.x;
		float y5 = this.ٿں\u0604ՠ.y;
		float z5 = this.ٿں\u0604ՠ.z;
	}

	// Token: 0x060008F0 RID: 2288 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60008F0")]
	[Address(RVA = "0x2B65444", Offset = "0x2B65444", VA = "0x2B65444")]
	private Vector3 \u087Cԇ\u07FD\u05B0(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008F1 RID: 2289 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60008F1")]
	[Address(RVA = "0x2B67858", Offset = "0x2B67858", VA = "0x2B67858")]
	private Vector3 ӣ\u055E\u05A9\u059E(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008F2 RID: 2290 RVA: 0x00030F38 File Offset: 0x0002F138
	[Token(Token = "0x60008F2")]
	[Address(RVA = "0x2B67ADC", Offset = "0x2B67ADC", VA = "0x2B67ADC")]
	private void \u085F\u05AE\u0603ڌ(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			int positionCount2 = this.\u089A\u0875Աގ.positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008F3 RID: 2291 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60008F3")]
	[Address(RVA = "0x2B67C40", Offset = "0x2B67C40", VA = "0x2B67C40")]
	private Vector3 ޡڃԻۀ(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008F4 RID: 2292 RVA: 0x00030F88 File Offset: 0x0002F188
	[Token(Token = "0x60008F4")]
	[Address(RVA = "0x2B67EB0", Offset = "0x2B67EB0", VA = "0x2B67EB0")]
	private void ࡥݧ\u0594\u05B1()
	{
		Color red = Color.red;
		Vector3 position = this.ࡐբغ\u0830.position;
		Vector3 position2 = this.ԕܫղԴ.position;
		Vector3 position3 = this.ࡐբغ\u0830.position;
		Vector3 position4 = this.ԕܫղԴ.position;
		float x = this.ڋӪ\u065E\u059C.x;
		float y = this.ڋӪ\u065E\u059C.y;
		float z = this.ڋӪ\u065E\u059C.z;
		float x2 = this.ڋӪ\u065E\u059C.x;
		float y2 = this.ڋӪ\u065E\u059C.y;
		float z2 = this.ڋӪ\u065E\u059C.z;
		Color yellow = Color.yellow;
		float x3 = this.ڋӪ\u065E\u059C.x;
		float y3 = this.ڋӪ\u065E\u059C.y;
		float z3 = this.ڋӪ\u065E\u059C.z;
		float x4 = this.ٿں\u0604ՠ.x;
		float y4 = this.ٿں\u0604ՠ.y;
		float z4 = this.ٿں\u0604ՠ.z;
		float x5 = this.ٿں\u0604ՠ.x;
		float y5 = this.ٿں\u0604ՠ.y;
		float z5 = this.ٿں\u0604ՠ.z;
	}

	// Token: 0x060008F5 RID: 2293 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60008F5")]
	[Address(RVA = "0x2B68014", Offset = "0x2B68014", VA = "0x2B68014")]
	private Vector3 ڜٸژ\u05AE(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008F6 RID: 2294 RVA: 0x000310BC File Offset: 0x0002F2BC
	[Token(Token = "0x60008F6")]
	[Address(RVA = "0x2B682F8", Offset = "0x2B682F8", VA = "0x2B682F8")]
	private void ըӳࠎڴ(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount2 = u089A_u0875Աގ2.positionCount;
			LineRenderer u089A_u0875Աގ3 = this.\u089A\u0875Աގ;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008F7 RID: 2295 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60008F7")]
	[Address(RVA = "0x2B68464", Offset = "0x2B68464", VA = "0x2B68464")]
	private Vector3 Ԁࡄۼ\u05B0(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008F8 RID: 2296 RVA: 0x00031114 File Offset: 0x0002F314
	[Token(Token = "0x60008F8")]
	[Address(RVA = "0x2B66228", Offset = "0x2B66228", VA = "0x2B66228")]
	private void ܩޢ\u089D\u06E9(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			int positionCount2 = this.\u089A\u0875Աގ.positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008F9 RID: 2297 RVA: 0x00031164 File Offset: 0x0002F364
	[Token(Token = "0x60008F9")]
	[Address(RVA = "0x2B68750", Offset = "0x2B68750", VA = "0x2B68750")]
	private void \u0821\u059Fӕ\u0607()
	{
		float u05B2ӽՉ_u060B = this.\u05B2ӽՉ\u060B;
		float deltaTime = Time.deltaTime;
		float num = this.ࢴۻݐԧ;
		bool ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		List<Vector3> ց_u06D8ڋڜ = this.Ց\u06D8ڋڜ;
		Transform ࡐբغ_u = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ2 = this.Ց\u06D8ڋڜ;
		Vector3 position = ࡐբغ_u.position;
		Vector3 position2 = this.ࡐբغ\u0830.position;
		Vector3 position3 = this.ԕܫղԴ.position;
		float u060Cկ_u0896_u07F = this.\u060Cկ\u0896\u07F1;
		float num2 = this.ԯտߐࡄ;
		Transform ࡐբغ_u2 = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ3 = this.Ց\u06D8ڋڜ;
		Vector3 position4 = ࡐբغ_u2.position;
		Vector3 position5 = this.ࡐբغ\u0830.position;
		Transform ࡐբغ_u3 = this.ࡐբغ\u0830;
		float u085EӶۯӴ = this.\u085EӶۯӴ;
		Vector3 position6 = ࡐբغ_u3.position;
		Vector3 position7 = this.ԕܫղԴ.position;
		Vector3 position8 = this.ԕܫղԴ.position;
		Transform transform = this.ԕܫղԴ;
		float u085EӶۯӴ2 = this.\u085EӶۯӴ;
		Vector3 position9 = transform.position;
		float value;
		float num3 = Mathf.Clamp01(value);
		Transform transform2 = this.ԕܫղԴ;
		List<Vector3> ց_u06D8ڋڜ4 = this.Ց\u06D8ڋڜ;
		Vector3 position10 = transform2.position;
		List<Vector3> ց_u06D8ڋڜ5 = this.Ց\u06D8ڋڜ;
		this.ӻࡤ\u05B6י = u085EӶۯӴ;
		float deltaTime2 = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float x = this.ࠂࡦԈل.x;
		float z = this.Ծ\u06FEࢷࡘ.z;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		float z2 = this.ࠂࡦԈل.z;
		float z3 = this.\u05AF\u06D9ܬ\u0705.z;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		Transform ࡐբغ_u4 = this.ࡐբغ\u0830;
		this.ࠂࡦԈل.z = u085EӶۯӴ2;
		this.ٿں\u0604ՠ.z = u085EӶۯӴ2;
		Vector3 position11 = ࡐբغ_u4.position;
		Vector3 position12 = this.ԕܫղԴ.position;
		this.\u05B2ӽՉ\u060B = (float)24576;
	}

	// Token: 0x060008FA RID: 2298 RVA: 0x0003133C File Offset: 0x0002F53C
	[Token(Token = "0x60008FA")]
	[Address(RVA = "0x2B68CD4", Offset = "0x2B68CD4", VA = "0x2B68CD4")]
	private void ڟӲࡓ\u0877()
	{
		Color red = Color.red;
		Vector3 position = this.ࡐբغ\u0830.position;
		Vector3 position2 = this.ԕܫղԴ.position;
		Vector3 position3 = this.ࡐբغ\u0830.position;
		Vector3 position4 = this.ԕܫղԴ.position;
		float x = this.ڋӪ\u065E\u059C.x;
		float y = this.ڋӪ\u065E\u059C.y;
		float z = this.ڋӪ\u065E\u059C.z;
		float x2 = this.ڋӪ\u065E\u059C.x;
		float y2 = this.ڋӪ\u065E\u059C.y;
		float z2 = this.ڋӪ\u065E\u059C.z;
		Color yellow = Color.yellow;
		float x3 = this.ڋӪ\u065E\u059C.x;
		float y3 = this.ڋӪ\u065E\u059C.y;
		float z3 = this.ڋӪ\u065E\u059C.z;
		float x4 = this.ٿں\u0604ՠ.x;
		float y4 = this.ٿں\u0604ՠ.y;
		float z4 = this.ٿں\u0604ՠ.z;
		float x5 = this.ٿں\u0604ՠ.x;
		float y5 = this.ٿں\u0604ՠ.y;
		float z5 = this.ٿں\u0604ՠ.z;
	}

	// Token: 0x060008FB RID: 2299 RVA: 0x00031470 File Offset: 0x0002F670
	[Token(Token = "0x60008FB")]
	[Address(RVA = "0x2B68E34", Offset = "0x2B68E34", VA = "0x2B68E34")]
	private void ըࠂԵڮ(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount2 = u089A_u0875Աގ2.positionCount;
			LineRenderer u089A_u0875Աގ3 = this.\u089A\u0875Աގ;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008FC RID: 2300 RVA: 0x000314C8 File Offset: 0x0002F6C8
	[Token(Token = "0x60008FC")]
	[Address(RVA = "0x2B68FA0", Offset = "0x2B68FA0", VA = "0x2B68FA0")]
	private void צ\u0874ڵ\u059A()
	{
		float u05B2ӽՉ_u060B = this.\u05B2ӽՉ\u060B;
		float deltaTime = Time.deltaTime;
		float num = this.ࢴۻݐԧ;
		bool ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		List<Vector3> ց_u06D8ڋڜ = this.Ց\u06D8ڋڜ;
		Transform ࡐբغ_u = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ2 = this.Ց\u06D8ڋڜ;
		Vector3 position = ࡐբغ_u.position;
		Vector3 position2 = this.ࡐբغ\u0830.position;
		Vector3 position3 = this.ԕܫղԴ.position;
		float u060Cկ_u0896_u07F = this.\u060Cկ\u0896\u07F1;
		float num2 = this.ԯտߐࡄ;
		Transform ࡐբغ_u2 = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ3 = this.Ց\u06D8ڋڜ;
		Vector3 position4 = ࡐբغ_u2.position;
		Vector3 position5 = this.ࡐբغ\u0830.position;
		Transform ࡐբغ_u3 = this.ࡐբغ\u0830;
		float u085EӶۯӴ = this.\u085EӶۯӴ;
		Vector3 position6 = ࡐբغ_u3.position;
		Vector3 position7 = this.ԕܫղԴ.position;
		Vector3 position8 = this.ԕܫղԴ.position;
		Transform transform = this.ԕܫղԴ;
		float u085EӶۯӴ2 = this.\u085EӶۯӴ;
		Vector3 position9 = transform.position;
		float value;
		float num3 = Mathf.Clamp01(value);
		Transform transform2 = this.ԕܫղԴ;
		List<Vector3> ց_u06D8ڋڜ4 = this.Ց\u06D8ڋڜ;
		Vector3 position10 = transform2.position;
		List<Vector3> ց_u06D8ڋڜ5 = this.Ց\u06D8ڋڜ;
		this.ӻࡤ\u05B6י = u085EӶۯӴ;
		float deltaTime2 = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float x = this.ࠂࡦԈل.x;
		float z = this.Ծ\u06FEࢷࡘ.z;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		float z2 = this.ࠂࡦԈل.z;
		float z3 = this.\u05AF\u06D9ܬ\u0705.z;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		Transform ࡐբغ_u4 = this.ࡐբغ\u0830;
		this.ڗٽ\u05BDմ.z = u05B2ӽՉ_u060B;
		this.ࠂࡦԈل.x = x;
		Vector3 position11 = ࡐբغ_u4.position;
		Vector3 position12 = this.ԕܫղԴ.position;
		this.\u05B2ӽՉ\u060B = (float)17160;
	}

	// Token: 0x060008FD RID: 2301 RVA: 0x0003169C File Offset: 0x0002F89C
	[Token(Token = "0x60008FD")]
	[Address(RVA = "0x2B6951C", Offset = "0x2B6951C", VA = "0x2B6951C")]
	private void ոӴٻԎ()
	{
		Color red = Color.red;
		Vector3 position = this.ࡐբغ\u0830.position;
		Vector3 position2 = this.ԕܫղԴ.position;
		Vector3 position3 = this.ԕܫղԴ.position;
		float x = this.ڋӪ\u065E\u059C.x;
		float y = this.ڋӪ\u065E\u059C.y;
		float z = this.ڋӪ\u065E\u059C.z;
		float x2 = this.ڋӪ\u065E\u059C.x;
		float y2 = this.ڋӪ\u065E\u059C.y;
		float z2 = this.ڋӪ\u065E\u059C.z;
		Color yellow = Color.yellow;
		float x3 = this.ڋӪ\u065E\u059C.x;
		float y3 = this.ڋӪ\u065E\u059C.y;
		float z3 = this.ڋӪ\u065E\u059C.z;
		float x4 = this.ٿں\u0604ՠ.x;
		float y4 = this.ٿں\u0604ՠ.y;
		float z4 = this.ٿں\u0604ՠ.z;
		float x5 = this.ٿں\u0604ՠ.x;
		float y5 = this.ٿں\u0604ՠ.y;
		float z5 = this.ٿں\u0604ՠ.z;
	}

	// Token: 0x060008FE RID: 2302 RVA: 0x000317C4 File Offset: 0x0002F9C4
	[Token(Token = "0x60008FE")]
	[Address(RVA = "0x2B69680", Offset = "0x2B69680", VA = "0x2B69680")]
	private void ژךՈ\u0597()
	{
		float u05B2ӽՉ_u060B = this.\u05B2ӽՉ\u060B;
		float deltaTime = Time.deltaTime;
		float num = this.ࢴۻݐԧ;
		bool ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		List<Vector3> ց_u06D8ڋڜ = this.Ց\u06D8ڋڜ;
		Transform ࡐբغ_u = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ2 = this.Ց\u06D8ڋڜ;
		Vector3 position = ࡐբغ_u.position;
		Vector3 position2 = this.ࡐբغ\u0830.position;
		Vector3 position3 = this.ԕܫղԴ.position;
		float u060Cկ_u0896_u07F = this.\u060Cկ\u0896\u07F1;
		float num2 = this.ԯտߐࡄ;
		Transform ࡐբغ_u2 = this.ࡐբغ\u0830;
		List<Vector3> ց_u06D8ڋڜ3 = this.Ց\u06D8ڋڜ;
		Vector3 position4 = ࡐբغ_u2.position;
		Vector3 position5 = this.ࡐբغ\u0830.position;
		Transform ࡐբغ_u3 = this.ࡐբغ\u0830;
		float u085EӶۯӴ = this.\u085EӶۯӴ;
		Vector3 position6 = ࡐբغ_u3.position;
		Vector3 position7 = this.ԕܫղԴ.position;
		Vector3 position8 = this.ԕܫղԴ.position;
		Transform transform = this.ԕܫղԴ;
		float u085EӶۯӴ2 = this.\u085EӶۯӴ;
		Vector3 position9 = transform.position;
		float value;
		float num3 = Mathf.Clamp01(value);
		Transform transform2 = this.ԕܫղԴ;
		List<Vector3> ց_u06D8ڋڜ4 = this.Ց\u06D8ڋڜ;
		Vector3 position10 = transform2.position;
		List<Vector3> ց_u06D8ڋڜ5 = this.Ց\u06D8ڋڜ;
		this.ӻࡤ\u05B6י = u085EӶۯӴ;
		float deltaTime2 = Time.deltaTime;
		float ڼ_u07B9_u083Dݯ = this.ڼ\u07B9\u083Dݯ;
		float ࢲ_u0833_u059BԌ = this.ࢲ\u0833\u059BԌ;
		float x = this.ࠂࡦԈل.x;
		float z = this.Ծ\u06FEࢷࡘ.z;
		float ӫ_u0830_u07B9ګ = this.Ӫ\u0830\u07B9ګ;
		float z2 = this.ࠂࡦԈل.z;
		float z3 = this.\u05AF\u06D9ܬ\u0705.z;
		this.١դގݝ = ڼ_u07B9_u083Dݯ;
		this.\u06FD\u0740\u081Fࠃ = ࢲ_u0833_u059BԌ;
		Transform ࡐբغ_u4 = this.ࡐբغ\u0830;
		this.ڗٽ\u05BDմ.z = u05B2ӽՉ_u060B;
		this.ࠂࡦԈل.x = x;
		Vector3 position11 = ࡐբغ_u4.position;
		Vector3 position12 = this.ԕܫղԴ.position;
		this.\u05B2ӽՉ\u060B = (float)49152;
	}

	// Token: 0x060008FF RID: 2303 RVA: 0x00031998 File Offset: 0x0002FB98
	[Token(Token = "0x60008FF")]
	[Address(RVA = "0x2B69A9C", Offset = "0x2B69A9C", VA = "0x2B69A9C")]
	public Rope()
	{
	}

	// Token: 0x06000900 RID: 2304 RVA: 0x000319B8 File Offset: 0x0002FBB8
	[Token(Token = "0x6000900")]
	[Address(RVA = "0x2B69AAC", Offset = "0x2B69AAC", VA = "0x2B69AAC")]
	private void ہڨԧߛ(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount2 = u089A_u0875Աގ2.positionCount;
			LineRenderer u089A_u0875Աގ3 = this.\u089A\u0875Աގ;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000901 RID: 2305 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6000901")]
	[Address(RVA = "0x2B69C18", Offset = "0x2B69C18", VA = "0x2B69C18")]
	private Vector3 Ԏ\u074Bߍٳ(List<Vector3> Ց\u06D8ڋڜ, float \u07B2ݪ\u082Dե)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000902 RID: 2306 RVA: 0x00031A10 File Offset: 0x0002FC10
	[Token(Token = "0x6000902")]
	[Address(RVA = "0x2B693B8", Offset = "0x2B693B8", VA = "0x2B693B8")]
	private void \u05BCܜ\u066Bձ(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			int positionCount2 = u089A_u0875Աގ.positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000903 RID: 2307 RVA: 0x00031A5C File Offset: 0x0002FC5C
	[Token(Token = "0x6000903")]
	[Address(RVA = "0x2B69F00", Offset = "0x2B69F00", VA = "0x2B69F00")]
	private void ݏރߣࢮ()
	{
		Color red = Color.red;
		Vector3 position = this.ࡐբغ\u0830.position;
		Vector3 position2 = this.ԕܫղԴ.position;
		Vector3 position3 = this.ࡐբغ\u0830.position;
		Vector3 position4 = this.ԕܫղԴ.position;
		float x = this.ڋӪ\u065E\u059C.x;
		float y = this.ڋӪ\u065E\u059C.y;
		float z = this.ڋӪ\u065E\u059C.z;
		float x2 = this.ڋӪ\u065E\u059C.x;
		float y2 = this.ڋӪ\u065E\u059C.y;
		float z2 = this.ڋӪ\u065E\u059C.z;
		Color yellow = Color.yellow;
		float x3 = this.ڋӪ\u065E\u059C.x;
		float y3 = this.ڋӪ\u065E\u059C.y;
		float z3 = this.ڋӪ\u065E\u059C.z;
		float x4 = this.ٿں\u0604ՠ.x;
		float y4 = this.ٿں\u0604ՠ.y;
		float z4 = this.ٿں\u0604ՠ.z;
		float x5 = this.ٿں\u0604ՠ.x;
		float y5 = this.ٿں\u0604ՠ.y;
		float z5 = this.ٿں\u0604ՠ.z;
	}

	// Token: 0x06000904 RID: 2308 RVA: 0x00031B90 File Offset: 0x0002FD90
	[Token(Token = "0x6000904")]
	[Address(RVA = "0x2B68B68", Offset = "0x2B68B68", VA = "0x2B68B68")]
	private void \u07B7۶\u0708\u070D(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount2 = u089A_u0875Աގ2.positionCount;
			LineRenderer u089A_u0875Աގ3 = this.\u089A\u0875Աގ;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000905 RID: 2309 RVA: 0x00031BE8 File Offset: 0x0002FDE8
	[Token(Token = "0x6000905")]
	[Address(RVA = "0x2B67030", Offset = "0x2B67030", VA = "0x2B67030")]
	private void ކ\u06EDࢦࠑ(Vector3 ࡐբغ\u0830, Vector3 ԕܫղԴ, Vector3 \u0616ܠࢻ\u05AA)
	{
		do
		{
			LineRenderer u089A_u0875Աގ = this.\u089A\u0875Աގ;
			int positionCount = this.ڌܥӄצ;
			u089A_u0875Աގ.positionCount = positionCount;
			LineRenderer u089A_u0875Աގ2 = this.\u089A\u0875Աގ;
			int positionCount2 = u089A_u0875Աގ2.positionCount;
			int positionCount3 = this.\u089A\u0875Աގ.positionCount;
		}
		while (this.\u089A\u0875Աގ != null);
		throw new NullReferenceException();
	}

	// Token: 0x04000122 RID: 290
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000122")]
	public Transform ࡐբغ\u0830;

	// Token: 0x04000123 RID: 291
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000123")]
	public Transform ԕܫղԴ;

	// Token: 0x04000124 RID: 292
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000124")]
	public LineRenderer \u089A\u0875Աގ;

	// Token: 0x04000125 RID: 293
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000125")]
	public List<Vector3> Ց\u06D8ڋڜ;

	// Token: 0x04000126 RID: 294
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000126")]
	public float \u085EӶۯӴ;

	// Token: 0x04000127 RID: 295
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x4000127")]
	public float \u060Cկ\u0896\u07F1;

	// Token: 0x04000128 RID: 296
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000128")]
	public float ԯտߐࡄ;

	// Token: 0x04000129 RID: 297
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000129")]
	private Vector3 \u06E8ޱ\u089F\u082A;

	// Token: 0x0400012A RID: 298
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400012A")]
	private Vector3 ڗٽ\u05BDմ;

	// Token: 0x0400012B RID: 299
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x400012B")]
	private Vector3 \u05AF\u06D9ܬ\u0705;

	// Token: 0x0400012C RID: 300
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x400012C")]
	private Vector3 ࠂࡦԈل;

	// Token: 0x0400012D RID: 301
	[FieldOffset(Offset = "0x74")]
	[Token(Token = "0x400012D")]
	private Vector3 Ծ\u06FEࢷࡘ;

	// Token: 0x0400012E RID: 302
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x400012E")]
	private float ޔӊڰڏ;

	// Token: 0x0400012F RID: 303
	[FieldOffset(Offset = "0x84")]
	[Token(Token = "0x400012F")]
	private float \u06FD\u0740\u081Fࠃ;

	// Token: 0x04000130 RID: 304
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x4000130")]
	private float \u06E4ߧهݥ;

	// Token: 0x04000131 RID: 305
	[FieldOffset(Offset = "0x8C")]
	[Token(Token = "0x4000131")]
	private float ١դގݝ;

	// Token: 0x04000132 RID: 306
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x4000132")]
	public float ڼ\u07B9\u083Dݯ;

	// Token: 0x04000133 RID: 307
	[FieldOffset(Offset = "0x94")]
	[Token(Token = "0x4000133")]
	public float ࢲ\u0833\u059BԌ;

	// Token: 0x04000134 RID: 308
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x4000134")]
	public float Ӫ\u0830\u07B9ګ;

	// Token: 0x04000135 RID: 309
	[FieldOffset(Offset = "0x9C")]
	[Token(Token = "0x4000135")]
	public int ڌܥӄצ = 200;

	// Token: 0x04000136 RID: 310
	[FieldOffset(Offset = "0xA0")]
	[Token(Token = "0x4000136")]
	public bool ࡑ۳\u0596\u066C;

	// Token: 0x04000137 RID: 311
	[FieldOffset(Offset = "0xA4")]
	[Token(Token = "0x4000137")]
	public float ࢴۻݐԧ;

	// Token: 0x04000138 RID: 312
	[FieldOffset(Offset = "0xA8")]
	[Token(Token = "0x4000138")]
	public float ӻࡤ\u05B6י;

	// Token: 0x04000139 RID: 313
	[FieldOffset(Offset = "0xAC")]
	[Token(Token = "0x4000139")]
	private float \u05B2ӽՉ\u060B;

	// Token: 0x0400013A RID: 314
	[FieldOffset(Offset = "0xB0")]
	[Token(Token = "0x400013A")]
	private Vector3 ڋӪ\u065E\u059C;

	// Token: 0x0400013B RID: 315
	[FieldOffset(Offset = "0xBC")]
	[Token(Token = "0x400013B")]
	private Vector3 ٿں\u0604ՠ;
}
