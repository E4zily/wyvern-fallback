﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000075 RID: 117
[Token(Token = "0x2000075")]
public class MB_BatchPrepareObjectsForDynamicBatchingDescription : MonoBehaviour
{
	// Token: 0x060011B0 RID: 4528 RVA: 0x00068558 File Offset: 0x00066758
	[Token(Token = "0x60011B0")]
	[Address(RVA = "0x24CFB48", Offset = "0x24CFB48", VA = "0x24CFB48")]
	private void \u0880ݚވԿ()
	{
	}

	// Token: 0x060011B1 RID: 4529 RVA: 0x00068568 File Offset: 0x00066768
	[Token(Token = "0x60011B1")]
	[Address(RVA = "0x24CFC28", Offset = "0x24CFC28", VA = "0x24CFC28")]
	private void \u0598ڂ\u088AՋ()
	{
	}

	// Token: 0x060011B2 RID: 4530 RVA: 0x00068578 File Offset: 0x00066778
	[Token(Token = "0x60011B2")]
	[Address(RVA = "0x24CFD08", Offset = "0x24CFD08", VA = "0x24CFD08")]
	private void ٯب٧\u05FC()
	{
	}

	// Token: 0x060011B3 RID: 4531 RVA: 0x00068588 File Offset: 0x00066788
	[Token(Token = "0x60011B3")]
	[Address(RVA = "0x24CFDE8", Offset = "0x24CFDE8", VA = "0x24CFDE8")]
	private void ۰\u0615ԛ\u086B()
	{
	}

	// Token: 0x060011B4 RID: 4532 RVA: 0x00068598 File Offset: 0x00066798
	[Token(Token = "0x60011B4")]
	[Address(RVA = "0x24CFEC8", Offset = "0x24CFEC8", VA = "0x24CFEC8")]
	public MB_BatchPrepareObjectsForDynamicBatchingDescription()
	{
	}

	// Token: 0x060011B5 RID: 4533 RVA: 0x000685AC File Offset: 0x000667AC
	[Token(Token = "0x60011B5")]
	[Address(RVA = "0x24CFED0", Offset = "0x24CFED0", VA = "0x24CFED0")]
	private void ҿ\u07BBҽ\u0599()
	{
	}

	// Token: 0x060011B6 RID: 4534 RVA: 0x000685BC File Offset: 0x000667BC
	[Token(Token = "0x60011B6")]
	[Address(RVA = "0x24CFFB0", Offset = "0x24CFFB0", VA = "0x24CFFB0")]
	private void \u07F7ե\u081Fܗ()
	{
	}

	// Token: 0x060011B7 RID: 4535 RVA: 0x000685CC File Offset: 0x000667CC
	[Token(Token = "0x60011B7")]
	[Address(RVA = "0x24D0090", Offset = "0x24D0090", VA = "0x24D0090")]
	private void ى\u05F4ڷ߉()
	{
	}

	// Token: 0x060011B8 RID: 4536 RVA: 0x000685DC File Offset: 0x000667DC
	[Token(Token = "0x60011B8")]
	[Address(RVA = "0x24D0170", Offset = "0x24D0170", VA = "0x24D0170")]
	private void OnGUI()
	{
	}

	// Token: 0x060011B9 RID: 4537 RVA: 0x000685EC File Offset: 0x000667EC
	[Token(Token = "0x60011B9")]
	[Address(RVA = "0x24D0250", Offset = "0x24D0250", VA = "0x24D0250")]
	private void Ӄۇރࡑ()
	{
	}

	// Token: 0x060011BA RID: 4538 RVA: 0x000685FC File Offset: 0x000667FC
	[Token(Token = "0x60011BA")]
	[Address(RVA = "0x24D0330", Offset = "0x24D0330", VA = "0x24D0330")]
	private void ԗӣ\u07BAߩ()
	{
	}

	// Token: 0x060011BB RID: 4539 RVA: 0x0006860C File Offset: 0x0006680C
	[Token(Token = "0x60011BB")]
	[Address(RVA = "0x24D0410", Offset = "0x24D0410", VA = "0x24D0410")]
	private void ܩ\u06E2߈ջ()
	{
	}

	// Token: 0x060011BC RID: 4540 RVA: 0x0006861C File Offset: 0x0006681C
	[Token(Token = "0x60011BC")]
	[Address(RVA = "0x24D04F0", Offset = "0x24D04F0", VA = "0x24D04F0")]
	private void ߐ߁\u05CE\u0733()
	{
	}

	// Token: 0x060011BD RID: 4541 RVA: 0x0006862C File Offset: 0x0006682C
	[Token(Token = "0x60011BD")]
	[Address(RVA = "0x24D05D0", Offset = "0x24D05D0", VA = "0x24D05D0")]
	private void ڄ\u0734ԛ\u05C8()
	{
	}

	// Token: 0x060011BE RID: 4542 RVA: 0x0006863C File Offset: 0x0006683C
	[Token(Token = "0x60011BE")]
	[Address(RVA = "0x24D06B0", Offset = "0x24D06B0", VA = "0x24D06B0")]
	private void \u05CAө\u0872\u058F()
	{
	}

	// Token: 0x060011BF RID: 4543 RVA: 0x0006864C File Offset: 0x0006684C
	[Token(Token = "0x60011BF")]
	[Address(RVA = "0x24D0790", Offset = "0x24D0790", VA = "0x24D0790")]
	private void ޒӠۅߐ()
	{
	}

	// Token: 0x060011C0 RID: 4544 RVA: 0x0006865C File Offset: 0x0006685C
	[Token(Token = "0x60011C0")]
	[Address(RVA = "0x24D0870", Offset = "0x24D0870", VA = "0x24D0870")]
	private void ہډࠉӥ()
	{
	}

	// Token: 0x060011C1 RID: 4545 RVA: 0x0006866C File Offset: 0x0006686C
	[Token(Token = "0x60011C1")]
	[Address(RVA = "0x24D0950", Offset = "0x24D0950", VA = "0x24D0950")]
	private void ࡉࡡܡߕ()
	{
	}

	// Token: 0x060011C2 RID: 4546 RVA: 0x0006867C File Offset: 0x0006687C
	[Token(Token = "0x60011C2")]
	[Address(RVA = "0x24D0A30", Offset = "0x24D0A30", VA = "0x24D0A30")]
	private void Ԁߚޘٴ()
	{
	}

	// Token: 0x060011C3 RID: 4547 RVA: 0x0006868C File Offset: 0x0006688C
	[Token(Token = "0x60011C3")]
	[Address(RVA = "0x24D0B10", Offset = "0x24D0B10", VA = "0x24D0B10")]
	private void ޤչ߉\u0702()
	{
	}

	// Token: 0x060011C4 RID: 4548 RVA: 0x0006869C File Offset: 0x0006689C
	[Token(Token = "0x60011C4")]
	[Address(RVA = "0x24D0BF0", Offset = "0x24D0BF0", VA = "0x24D0BF0")]
	private void ߌڟ\u07EEҼ()
	{
	}

	// Token: 0x060011C5 RID: 4549 RVA: 0x000686AC File Offset: 0x000668AC
	[Token(Token = "0x60011C5")]
	[Address(RVA = "0x24D0CD0", Offset = "0x24D0CD0", VA = "0x24D0CD0")]
	private void ߅\u070Fޑ\u0876()
	{
	}

	// Token: 0x060011C6 RID: 4550 RVA: 0x000686BC File Offset: 0x000668BC
	[Token(Token = "0x60011C6")]
	[Address(RVA = "0x24D0DB0", Offset = "0x24D0DB0", VA = "0x24D0DB0")]
	private void \u0594ٺԏ\u05CA()
	{
	}

	// Token: 0x060011C7 RID: 4551 RVA: 0x000686CC File Offset: 0x000668CC
	[Token(Token = "0x60011C7")]
	[Address(RVA = "0x24D0E90", Offset = "0x24D0E90", VA = "0x24D0E90")]
	private void \u05C4עڻ\u0732()
	{
	}

	// Token: 0x060011C8 RID: 4552 RVA: 0x000686DC File Offset: 0x000668DC
	[Token(Token = "0x60011C8")]
	[Address(RVA = "0x24D0F70", Offset = "0x24D0F70", VA = "0x24D0F70")]
	private void \u05BA\u0893ހՎ()
	{
	}

	// Token: 0x060011C9 RID: 4553 RVA: 0x000686EC File Offset: 0x000668EC
	[Token(Token = "0x60011C9")]
	[Address(RVA = "0x24D1050", Offset = "0x24D1050", VA = "0x24D1050")]
	private void ܞݗ\u0743Ӽ()
	{
	}

	// Token: 0x060011CA RID: 4554 RVA: 0x000686FC File Offset: 0x000668FC
	[Token(Token = "0x60011CA")]
	[Address(RVA = "0x24D1130", Offset = "0x24D1130", VA = "0x24D1130")]
	private void \u064Bࢮ\u0589\u05FF()
	{
	}

	// Token: 0x060011CB RID: 4555 RVA: 0x0006870C File Offset: 0x0006690C
	[Token(Token = "0x60011CB")]
	[Address(RVA = "0x24D1210", Offset = "0x24D1210", VA = "0x24D1210")]
	private void و߂\u06DBڅ()
	{
	}

	// Token: 0x060011CC RID: 4556 RVA: 0x0006871C File Offset: 0x0006691C
	[Token(Token = "0x60011CC")]
	[Address(RVA = "0x24D12F0", Offset = "0x24D12F0", VA = "0x24D12F0")]
	private void \u0859\u0895ӇԚ()
	{
	}

	// Token: 0x060011CD RID: 4557 RVA: 0x0006872C File Offset: 0x0006692C
	[Token(Token = "0x60011CD")]
	[Address(RVA = "0x24D13D0", Offset = "0x24D13D0", VA = "0x24D13D0")]
	private void ۵\u05EEߑچ()
	{
	}

	// Token: 0x060011CE RID: 4558 RVA: 0x0006873C File Offset: 0x0006693C
	[Token(Token = "0x60011CE")]
	[Address(RVA = "0x24D14B0", Offset = "0x24D14B0", VA = "0x24D14B0")]
	private void \u05AE\u05B6\u055A\u05B1()
	{
	}

	// Token: 0x060011CF RID: 4559 RVA: 0x0006874C File Offset: 0x0006694C
	[Token(Token = "0x60011CF")]
	[Address(RVA = "0x24D1590", Offset = "0x24D1590", VA = "0x24D1590")]
	private void \u0614\u055A\u0895۷()
	{
	}

	// Token: 0x060011D0 RID: 4560 RVA: 0x0006875C File Offset: 0x0006695C
	[Token(Token = "0x60011D0")]
	[Address(RVA = "0x24D1670", Offset = "0x24D1670", VA = "0x24D1670")]
	private void ܡӯ\u06E8\u07B0()
	{
	}

	// Token: 0x060011D1 RID: 4561 RVA: 0x0006876C File Offset: 0x0006696C
	[Token(Token = "0x60011D1")]
	[Address(RVA = "0x24D1750", Offset = "0x24D1750", VA = "0x24D1750")]
	private void \u0741\u07A7\u0749ݧ()
	{
	}

	// Token: 0x060011D2 RID: 4562 RVA: 0x0006877C File Offset: 0x0006697C
	[Token(Token = "0x60011D2")]
	[Address(RVA = "0x24D1830", Offset = "0x24D1830", VA = "0x24D1830")]
	private void \u055E\u064E\u073Dࢷ()
	{
	}

	// Token: 0x060011D3 RID: 4563 RVA: 0x0006878C File Offset: 0x0006698C
	[Token(Token = "0x60011D3")]
	[Address(RVA = "0x24D1910", Offset = "0x24D1910", VA = "0x24D1910")]
	private void \u07FBع߉ٶ()
	{
	}

	// Token: 0x060011D4 RID: 4564 RVA: 0x0006879C File Offset: 0x0006699C
	[Token(Token = "0x60011D4")]
	[Address(RVA = "0x24D19F0", Offset = "0x24D19F0", VA = "0x24D19F0")]
	private void ٧ص\u073FӜ()
	{
	}

	// Token: 0x060011D5 RID: 4565 RVA: 0x000687AC File Offset: 0x000669AC
	[Token(Token = "0x60011D5")]
	[Address(RVA = "0x24D1AD0", Offset = "0x24D1AD0", VA = "0x24D1AD0")]
	private void \u060Eװ\u085Cࢶ()
	{
	}

	// Token: 0x060011D6 RID: 4566 RVA: 0x000687BC File Offset: 0x000669BC
	[Token(Token = "0x60011D6")]
	[Address(RVA = "0x24D1BB0", Offset = "0x24D1BB0", VA = "0x24D1BB0")]
	private void \u0859ؤԗԧ()
	{
	}

	// Token: 0x060011D7 RID: 4567 RVA: 0x000687CC File Offset: 0x000669CC
	[Token(Token = "0x60011D7")]
	[Address(RVA = "0x24D1C90", Offset = "0x24D1C90", VA = "0x24D1C90")]
	private void چאӣک()
	{
	}

	// Token: 0x060011D8 RID: 4568 RVA: 0x000687DC File Offset: 0x000669DC
	[Token(Token = "0x60011D8")]
	[Address(RVA = "0x24D1D70", Offset = "0x24D1D70", VA = "0x24D1D70")]
	private void ۃ\u087EڴՊ()
	{
	}

	// Token: 0x060011D9 RID: 4569 RVA: 0x000687EC File Offset: 0x000669EC
	[Token(Token = "0x60011D9")]
	[Address(RVA = "0x24D1E50", Offset = "0x24D1E50", VA = "0x24D1E50")]
	private void \u07AFࡓݣ\u06E9()
	{
	}

	// Token: 0x060011DA RID: 4570 RVA: 0x000687FC File Offset: 0x000669FC
	[Token(Token = "0x60011DA")]
	[Address(RVA = "0x24D1F30", Offset = "0x24D1F30", VA = "0x24D1F30")]
	private void Ӯޱ\u0703ࢪ()
	{
	}

	// Token: 0x060011DB RID: 4571 RVA: 0x0006880C File Offset: 0x00066A0C
	[Token(Token = "0x60011DB")]
	[Address(RVA = "0x24D2010", Offset = "0x24D2010", VA = "0x24D2010")]
	private void ޥل\u0605Ԅ()
	{
	}

	// Token: 0x060011DC RID: 4572 RVA: 0x0006881C File Offset: 0x00066A1C
	[Token(Token = "0x60011DC")]
	[Address(RVA = "0x24D20F0", Offset = "0x24D20F0", VA = "0x24D20F0")]
	private void Ԅڌ\u0659߀()
	{
	}

	// Token: 0x060011DD RID: 4573 RVA: 0x0006882C File Offset: 0x00066A2C
	[Token(Token = "0x60011DD")]
	[Address(RVA = "0x24D21D0", Offset = "0x24D21D0", VA = "0x24D21D0")]
	private void \u07EB\u0597ࢳڪ()
	{
	}

	// Token: 0x060011DE RID: 4574 RVA: 0x0006883C File Offset: 0x00066A3C
	[Token(Token = "0x60011DE")]
	[Address(RVA = "0x24D22B0", Offset = "0x24D22B0", VA = "0x24D22B0")]
	private void \u0589٣ޖԀ()
	{
	}
}
