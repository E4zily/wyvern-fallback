﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000090 RID: 144
[Token(Token = "0x2000090")]
public class PortalGun : MonoBehaviour
{
	// Token: 0x060015C0 RID: 5568 RVA: 0x0007A008 File Offset: 0x00078208
	[Token(Token = "0x60015C0")]
	[Address(RVA = "0x29A5130", Offset = "0x29A5130", VA = "0x29A5130")]
	public void Կשܐӵ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Updating Material to: ");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("True");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("tutorialCheck");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("This is the 2500 Bananas button, and it was just clicked");
	}

	// Token: 0x060015C1 RID: 5569 RVA: 0x0007A048 File Offset: 0x00078248
	[Token(Token = "0x60015C1")]
	[Address(RVA = "0x29A521C", Offset = "0x29A521C", VA = "0x29A521C")]
	public void ޝ\u088Dނپ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("character limit reached");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Add/Remove Hat");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("username");
	}

	// Token: 0x060015C2 RID: 5570 RVA: 0x0007A080 File Offset: 0x00078280
	[Token(Token = "0x60015C2")]
	[Address(RVA = "0x29A5308", Offset = "0x29A5308", VA = "0x29A5308")]
	public void ޤ\u0610\u087A\u05AF()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("NetworkPlayer");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("username");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("isLava");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("FLSPTLT");
	}

	// Token: 0x060015C3 RID: 5571 RVA: 0x0007A0C0 File Offset: 0x000782C0
	[Token(Token = "0x60015C3")]
	[Address(RVA = "0x29A53F4", Offset = "0x29A53F4", VA = "0x29A53F4")]
	public void Ծ\u0700ࡏմ()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("StartGamemode");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("hh:mmtt");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("containsStaff");
		GameObject gameObject4 = GameObject.FindGameObjectWithTag("You Already Own This Item");
	}

	// Token: 0x060015C4 RID: 5572 RVA: 0x0007A0FC File Offset: 0x000782FC
	[Token(Token = "0x60015C4")]
	[Address(RVA = "0x29A54E0", Offset = "0x29A54E0", VA = "0x29A54E0")]
	public void \u0736\u06E0\u06E0څ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("isLava");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("_Smoothness");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("ChangeToTagged");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("false");
	}

	// Token: 0x060015C5 RID: 5573 RVA: 0x0007A13C File Offset: 0x0007833C
	[Token(Token = "0x60015C5")]
	[Address(RVA = "0x29A55CC", Offset = "0x29A55CC", VA = "0x29A55CC")]
	public void \u0604\u07B7ࢺݭ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("isLava");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("HandR");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("_BaseMap");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Player");
	}

	// Token: 0x060015C6 RID: 5574 RVA: 0x0007A17C File Offset: 0x0007837C
	[Token(Token = "0x60015C6")]
	[Address(RVA = "0x29A56B8", Offset = "0x29A56B8", VA = "0x29A56B8")]
	public void \u0883ދ\u066C\u0859()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("username");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Error");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Left a room");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("tp 2");
	}

	// Token: 0x060015C7 RID: 5575 RVA: 0x0007A1BC File Offset: 0x000783BC
	[Token(Token = "0x60015C7")]
	[Address(RVA = "0x29A57A4", Offset = "0x29A57A4", VA = "0x29A57A4")]
	public void ڸՔ\u0594ԭ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("NetworkPlayer");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Collided");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("containsStaff");
	}

	// Token: 0x060015C8 RID: 5576 RVA: 0x0007A1F4 File Offset: 0x000783F4
	[Token(Token = "0x60015C8")]
	[Address(RVA = "0x29A5890", Offset = "0x29A5890", VA = "0x29A5890")]
	public void Աࢦ\u05CAޡ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("typesOfTalk");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("\tExpires: ");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("username");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("CapuchinRemade");
	}

	// Token: 0x060015C9 RID: 5577 RVA: 0x0007A234 File Offset: 0x00078434
	[Token(Token = "0x60015C9")]
	[Address(RVA = "0x29A597C", Offset = "0x29A597C", VA = "0x29A597C")]
	public void ڇӪࢰࡔ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("EnableCosmetic");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("BLUPORT");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Players Online: ");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Player");
	}

	// Token: 0x060015CA RID: 5578 RVA: 0x0007A274 File Offset: 0x00078474
	[Token(Token = "0x60015CA")]
	[Address(RVA = "0x29A5A68", Offset = "0x29A5A68", VA = "0x29A5A68")]
	public void \u089Aۆ\u0887\u05C0()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("You Already Own This Item");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("You Look Like Butt");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("amongus");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag(", ");
	}

	// Token: 0x060015CB RID: 5579 RVA: 0x0007A2B4 File Offset: 0x000784B4
	[Token(Token = "0x60015CB")]
	[Address(RVA = "0x29A5B54", Offset = "0x29A5B54", VA = "0x29A5B54")]
	public void FixedUpdate()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("ORGTARG");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("BLUTARG");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("BLUPORT");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("ORGPORT");
	}

	// Token: 0x060015CC RID: 5580 RVA: 0x0007A2F4 File Offset: 0x000784F4
	[Token(Token = "0x60015CC")]
	[Address(RVA = "0x29A5C40", Offset = "0x29A5C40", VA = "0x29A5C40")]
	public void \u089Fکߦݭ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("1BN");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("PURCHASE");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag(" ");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("ChangeMaterialToNormal");
	}

	// Token: 0x060015CD RID: 5581 RVA: 0x0007A334 File Offset: 0x00078534
	[Token(Token = "0x60015CD")]
	[Address(RVA = "0x29A5D2C", Offset = "0x29A5D2C", VA = "0x29A5D2C")]
	public void Ԃڏݏ\u086D()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Push To Talk");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("True");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("hh:mmtt");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("hh:mmtt");
	}

	// Token: 0x060015CE RID: 5582 RVA: 0x0007A374 File Offset: 0x00078574
	[Token(Token = "0x60015CE")]
	[Address(RVA = "0x29A5E18", Offset = "0x29A5E18", VA = "0x29A5E18")]
	public void ࡇ\u0559یՒ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("true");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag(".Please press the button if you would like to play alone");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("button");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("false");
	}

	// Token: 0x060015CF RID: 5583 RVA: 0x0007A3B4 File Offset: 0x000785B4
	[Token(Token = "0x60015CF")]
	[Address(RVA = "0x29A5F04", Offset = "0x29A5F04", VA = "0x29A5F04")]
	public void \u05AAࢦ\u060AԞ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("PlayerHead");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("FLSPTLT");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("META");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("User has been reported for: ");
	}

	// Token: 0x060015D0 RID: 5584 RVA: 0x0007A3F4 File Offset: 0x000785F4
	[Token(Token = "0x60015D0")]
	[Address(RVA = "0x29A5FF0", Offset = "0x29A5FF0", VA = "0x29A5FF0")]
	public void ޗٻ\u0825ڔ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("isLava");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("button");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("PlayNoise");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n");
	}

	// Token: 0x060015D1 RID: 5585 RVA: 0x0007A434 File Offset: 0x00078634
	[Token(Token = "0x60015D1")]
	[Address(RVA = "0x29A60DC", Offset = "0x29A60DC", VA = "0x29A60DC")]
	public void \u081E١Ӕࢦ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("PlayNoise");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("True");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Failed To Join Public Room Successfully. The error is: ");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("button");
	}

	// Token: 0x060015D2 RID: 5586 RVA: 0x0007A474 File Offset: 0x00078674
	[Token(Token = "0x60015D2")]
	[Address(RVA = "0x29A61C8", Offset = "0x29A61C8", VA = "0x29A61C8")]
	public void \u0892\u061B\u0606\u06D8()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag(" hours. You were banned because of ");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Room Name: ");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("PushToTalk");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("On");
	}

	// Token: 0x060015D3 RID: 5587 RVA: 0x0007A4B4 File Offset: 0x000786B4
	[Token(Token = "0x60015D3")]
	[Address(RVA = "0x29A62B4", Offset = "0x29A62B4", VA = "0x29A62B4")]
	public void ࡋձغӜ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("\n Time: ");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("got funky mone");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("next");
	}

	// Token: 0x060015D4 RID: 5588 RVA: 0x0007A4F4 File Offset: 0x000786F4
	[Token(Token = "0x60015D4")]
	[Address(RVA = "0x29A63A0", Offset = "0x29A63A0", VA = "0x29A63A0")]
	public void ڷԟ\u087D\u05B9()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Muted");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("TurnAmount");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("EnableCosmetic");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("MetaId");
	}

	// Token: 0x060015D5 RID: 5589 RVA: 0x0007A534 File Offset: 0x00078734
	[Token(Token = "0x60015D5")]
	[Address(RVA = "0x29A648C", Offset = "0x29A648C", VA = "0x29A648C")]
	public void \u07A7\u06DFࠈޖ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("PlayNoise");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag(". Please update you game to the latest version");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("StartSong");
	}

	// Token: 0x060015D6 RID: 5590 RVA: 0x0007A574 File Offset: 0x00078774
	[Token(Token = "0x60015D6")]
	[Address(RVA = "0x29A6578", Offset = "0x29A6578", VA = "0x29A6578")]
	public void ڿ\u06E6\u088E\u06FD()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Player");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("PURCHASED");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("typesOfTalk");
	}

	// Token: 0x060015D7 RID: 5591 RVA: 0x0007A5AC File Offset: 0x000787AC
	[Token(Token = "0x60015D7")]
	[Address(RVA = "0x29A6650", Offset = "0x29A6650", VA = "0x29A6650")]
	public void Ԧ\u0876ծՎ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Room1");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("false");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("This is the 5000 Bananas button, and it was just clicked");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Combine textures & build combined mesh all at once");
	}

	// Token: 0x060015D8 RID: 5592 RVA: 0x0007A5EC File Offset: 0x000787EC
	[Token(Token = "0x60015D8")]
	[Address(RVA = "0x29A673C", Offset = "0x29A673C", VA = "0x29A673C")]
	public void \u0609ݢ\u05F7\u0744()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Vector1_d371bd24217449349bd747533d51af6b");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("True");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Name Changing Error. Error: ");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Regular");
	}

	// Token: 0x060015D9 RID: 5593 RVA: 0x0007A62C File Offset: 0x0007882C
	[Token(Token = "0x60015D9")]
	[Address(RVA = "0x29A6828", Offset = "0x29A6828", VA = "0x29A6828")]
	public void \u07AAح\u087Fܩ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Player");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag(" ");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("ChangeMaterialToNormal");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("FingerTip");
	}

	// Token: 0x060015DA RID: 5594 RVA: 0x0007A66C File Offset: 0x0007886C
	[Token(Token = "0x60015DA")]
	[Address(RVA = "0x29A6914", Offset = "0x29A6914", VA = "0x29A6914")]
	public void \u0886ܬԗ\u05C0()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("_BumpMap");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("HandL");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("PRESS AGAIN TO CONFIRM");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("FingerTip");
	}

	// Token: 0x060015DB RID: 5595 RVA: 0x0007A6AC File Offset: 0x000788AC
	[Token(Token = "0x60015DB")]
	[Address(RVA = "0x29A6A00", Offset = "0x29A6A00", VA = "0x29A6A00")]
	public void \u07BBۯ٤ࠍ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("next");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("KeyPos");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("KeyPos");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("PURCHASED");
	}

	// Token: 0x060015DC RID: 5596 RVA: 0x0007A6EC File Offset: 0x000788EC
	[Token(Token = "0x60015DC")]
	[Address(RVA = "0x29A6AEC", Offset = "0x29A6AEC", VA = "0x29A6AEC")]
	public void \u089Bځԯԝ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("You are on an outdated version of Capuchin. Your version is ");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Left Hand");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("TurnAmount");
	}

	// Token: 0x060015DD RID: 5597 RVA: 0x0007A72C File Offset: 0x0007892C
	[Token(Token = "0x60015DD")]
	[Address(RVA = "0x29A6BD8", Offset = "0x29A6BD8", VA = "0x29A6BD8")]
	public void ןأ\u05C0ب()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Date: ");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Try Connect To Server...");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("DisableCosmetic");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("true");
	}

	// Token: 0x060015DE RID: 5598 RVA: 0x0007A76C File Offset: 0x0007896C
	[Token(Token = "0x60015DE")]
	[Address(RVA = "0x29A6CC4", Offset = "0x29A6CC4", VA = "0x29A6CC4")]
	public void \u05BBږ\u060Cࡑ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Network Player");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("_BaseColor");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Mesh");
	}

	// Token: 0x060015DF RID: 5599 RVA: 0x0007A7AC File Offset: 0x000789AC
	[Token(Token = "0x60015DF")]
	[Address(RVA = "0x29A6DB0", Offset = "0x29A6DB0", VA = "0x29A6DB0")]
	public void \u07BFޥ٧\u073B()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Hate Speech");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("_Tint");
	}

	// Token: 0x060015E0 RID: 5600 RVA: 0x0007A7E4 File Offset: 0x000789E4
	[Token(Token = "0x60015E0")]
	[Address(RVA = "0x29A6E9C", Offset = "0x29A6E9C", VA = "0x29A6E9C")]
	public void ם\u06FDւԋ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Player");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("containsStaff");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("procedural animation script required on ");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Holdable");
	}

	// Token: 0x060015E1 RID: 5601 RVA: 0x0007A824 File Offset: 0x00078A24
	[Token(Token = "0x60015E1")]
	[Address(RVA = "0x29A6F88", Offset = "0x29A6F88", VA = "0x29A6F88")]
	public void ࠆ߆ۀפ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Player");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Name Changing Error. Error: ");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Name Changing Error. Error: ");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Player");
	}

	// Token: 0x060015E2 RID: 5602 RVA: 0x0007A864 File Offset: 0x00078A64
	[Token(Token = "0x60015E2")]
	[Address(RVA = "0x29A7054", Offset = "0x29A7054", VA = "0x29A7054")]
	public void \u064Cޔաӕ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("FLSPTLT");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Stopped Colliding");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("_Tint");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("_Tint");
	}

	// Token: 0x060015E3 RID: 5603 RVA: 0x0007A8A4 File Offset: 0x00078AA4
	[Token(Token = "0x60015E3")]
	[Address(RVA = "0x29A712C", Offset = "0x29A712C", VA = "0x29A712C")]
	public void \u070EࢣԀ\u07A9()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("CASUAL");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("2BN");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Reason: ");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("CapuchinStore");
	}

	// Token: 0x060015E4 RID: 5604 RVA: 0x0007A8E4 File Offset: 0x00078AE4
	[Token(Token = "0x60015E4")]
	[Address(RVA = "0x29A7218", Offset = "0x29A7218", VA = "0x29A7218")]
	public void \u0890ؤߪފ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Not enough amount of currency");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("hh:mmtt");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("HandL");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Version");
	}

	// Token: 0x060015E5 RID: 5605 RVA: 0x0007A924 File Offset: 0x00078B24
	[Token(Token = "0x60015E5")]
	[Address(RVA = "0x29A7304", Offset = "0x29A7304", VA = "0x29A7304")]
	public void ԣ\u0731\u0879ܕ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Players In Room: ");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Players Online: ");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Collided");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Thumb");
	}

	// Token: 0x060015E6 RID: 5606 RVA: 0x0007A964 File Offset: 0x00078B64
	[Token(Token = "0x60015E6")]
	[Address(RVA = "0x29A73F0", Offset = "0x29A73F0", VA = "0x29A73F0")]
	public void ڏי\u06E6\u070A()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("PushToTalk");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("{0} ({1})");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("sound play stopped");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("_BumpMap");
	}

	// Token: 0x060015E7 RID: 5607 RVA: 0x0007A9A4 File Offset: 0x00078BA4
	[Token(Token = "0x60015E7")]
	[Address(RVA = "0x29A74DC", Offset = "0x29A74DC", VA = "0x29A74DC")]
	public void ߪձԛމ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("BN");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("{0} ({1})");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Tagging");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("CapuchinStore");
	}

	// Token: 0x060015E8 RID: 5608 RVA: 0x0007A9E4 File Offset: 0x00078BE4
	[Token(Token = "0x60015E8")]
	[Address(RVA = "0x29A75C8", Offset = "0x29A75C8", VA = "0x29A75C8")]
	public void ݲ\u06E6ҽࡩ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("BN");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("_Tint");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Regular");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("_Smoothness");
	}

	// Token: 0x060015E9 RID: 5609 RVA: 0x0007AA24 File Offset: 0x00078C24
	[Token(Token = "0x60015E9")]
	[Address(RVA = "0x29A76B4", Offset = "0x29A76B4", VA = "0x29A76B4")]
	public void կսҾ\u06E4()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("An error has occured while buying bananas, please restart your game and try again");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("NetworkGunShoot");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Player");
		GameObject gameObject4 = GameObject.FindGameObjectWithTag("Joined Public Room Successfully");
	}

	// Token: 0x060015EA RID: 5610 RVA: 0x0007AA60 File Offset: 0x00078C60
	[Token(Token = "0x60015EA")]
	[Address(RVA = "0x29A77A0", Offset = "0x29A77A0", VA = "0x29A77A0")]
	public void ࠇ\u087DػՏ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("NetworkPlayer");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("containsStaff");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("HandL");
	}

	// Token: 0x060015EB RID: 5611 RVA: 0x0007AAA0 File Offset: 0x00078CA0
	[Token(Token = "0x60015EB")]
	[Address(RVA = "0x29A788C", Offset = "0x29A788C", VA = "0x29A788C")]
	public void ۍ\u05CAۋݿ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("gamemode");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("FingerTip");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("DISABLE");
	}

	// Token: 0x060015EC RID: 5612 RVA: 0x0007AAD8 File Offset: 0x00078CD8
	[Token(Token = "0x60015EC")]
	[Address(RVA = "0x29A7978", Offset = "0x29A7978", VA = "0x29A7978")]
	public PortalGun()
	{
	}

	// Token: 0x060015ED RID: 5613 RVA: 0x0007AAEC File Offset: 0x00078CEC
	[Token(Token = "0x60015ED")]
	[Address(RVA = "0x29A7980", Offset = "0x29A7980", VA = "0x29A7980")]
	public void סࡓࢤࢻ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Tagging");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Removing ");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Thumb");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Player");
	}

	// Token: 0x060015EE RID: 5614 RVA: 0x0007AB2C File Offset: 0x00078D2C
	[Token(Token = "0x60015EE")]
	[Address(RVA = "0x29A7A6C", Offset = "0x29A7A6C", VA = "0x29A7A6C")]
	public void ޛ\u0822\u05AFݎ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("containsStaff");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("HandL");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Player");
	}

	// Token: 0x060015EF RID: 5615 RVA: 0x0007AB64 File Offset: 0x00078D64
	[Token(Token = "0x60015EF")]
	[Address(RVA = "0x29A7B58", Offset = "0x29A7B58", VA = "0x29A7B58")]
	public void \u055F\u073C\u05F9Ԟ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Key");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Name Changing Error. Error: ");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("Player");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("SetColor");
	}

	// Token: 0x060015F0 RID: 5616 RVA: 0x0007ABA4 File Offset: 0x00078DA4
	[Token(Token = "0x60015F0")]
	[Address(RVA = "0x29A7C44", Offset = "0x29A7C44", VA = "0x29A7C44")]
	public void ޞؽ\u06EDս()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("username");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Charged!");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("sound play stopped");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("run");
	}

	// Token: 0x060015F1 RID: 5617 RVA: 0x0007ABE4 File Offset: 0x00078DE4
	[Token(Token = "0x60015F1")]
	[Address(RVA = "0x29A7D30", Offset = "0x29A7D30", VA = "0x29A7D30")]
	public void \u0887ࡒ\u0613\u07B8()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Not connected to room");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Head");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("ChangeToTagged");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("ChangeToTagged");
	}

	// Token: 0x060015F2 RID: 5618 RVA: 0x0007AC24 File Offset: 0x00078E24
	[Token(Token = "0x60015F2")]
	[Address(RVA = "0x29A7E1C", Offset = "0x29A7E1C", VA = "0x29A7E1C")]
	public void ա\u0731ࢺۊ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("5BN");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Cheating");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("monke screamed");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("User has been reported for: ");
	}

	// Token: 0x060015F3 RID: 5619 RVA: 0x0007AC64 File Offset: 0x00078E64
	[Token(Token = "0x60015F3")]
	[Address(RVA = "0x29A7F08", Offset = "0x29A7F08", VA = "0x29A7F08")]
	public void ݪԧ\u05F3Ӝ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("FingerTip");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("_BaseColor");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("Purchase For ");
	}

	// Token: 0x060015F4 RID: 5620 RVA: 0x0007ACA4 File Offset: 0x00078EA4
	[Token(Token = "0x60015F4")]
	[Address(RVA = "0x29A7FF4", Offset = "0x29A7FF4", VA = "0x29A7FF4")]
	public void Ա\u07B9ߒݗ()
	{
		GameObject ېԨ_u0870_u = GameObject.FindGameObjectWithTag("Head");
		this.ېԨ\u0870\u0742 = ېԨ_u0870_u;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		GameObject gameObject2 = GameObject.FindGameObjectWithTag("QuickStatic");
		GameObject gameObject3 = GameObject.FindGameObjectWithTag("friend");
	}

	// Token: 0x040002B9 RID: 697
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002B9")]
	public GameObject ڮ\u05B6ࢨԠ;

	// Token: 0x040002BA RID: 698
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002BA")]
	public GameObject ףࢦݫս;

	// Token: 0x040002BB RID: 699
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40002BB")]
	public GameObject ٵࡃյࠂ;

	// Token: 0x040002BC RID: 700
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40002BC")]
	public GameObject ܤࢷ\u0655\u0655;

	// Token: 0x040002BD RID: 701
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40002BD")]
	private GameObject ؽ\u05B0إࡨ;

	// Token: 0x040002BE RID: 702
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40002BE")]
	private GameObject ېԨ\u0870\u0742;
}
