﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000F8 RID: 248
[Token(Token = "0x20000F8")]
public class lerpScaleAndPos : MonoBehaviour
{
	// Token: 0x06002651 RID: 9809 RVA: 0x000D9048 File Offset: 0x000D7248
	[Token(Token = "0x6002651")]
	[Address(RVA = "0x2FAB0BC", Offset = "0x2FAB0BC", VA = "0x2FAB0BC")]
	public void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("User is on an outdated version of Capuchin. Your version is ");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002652 RID: 9810 RVA: 0x000D9078 File Offset: 0x000D7278
	[Token(Token = "0x6002652")]
	[Address(RVA = "0x2FAB13C", Offset = "0x2FAB13C", VA = "0x2FAB13C")]
	public void د\u085Fٹ\u05F3(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002653 RID: 9811 RVA: 0x000D90A8 File Offset: 0x000D72A8
	[Token(Token = "0x6002653")]
	[Address(RVA = "0x2FAB1BC", Offset = "0x2FAB1BC", VA = "0x2FAB1BC")]
	public void \u06D4ڟڎޜ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("ChangePlayerSize");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Agreed").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002654 RID: 9812 RVA: 0x000D93CC File Offset: 0x000D75CC
	[Token(Token = "0x6002654")]
	[Address(RVA = "0x2FAB5F0", Offset = "0x2FAB5F0", VA = "0x2FAB5F0")]
	public void ߥࠂ\u066Cࢷ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
	}

	// Token: 0x06002655 RID: 9813 RVA: 0x000D93F0 File Offset: 0x000D75F0
	[Token(Token = "0x6002655")]
	[Address(RVA = "0x2FAB66C", Offset = "0x2FAB66C", VA = "0x2FAB66C")]
	public void \u0746\u05B3ԅࡉ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("HOLY MOLY THE STICK IS ON FIRE!!!!!!");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002656 RID: 9814 RVA: 0x000D9420 File Offset: 0x000D7620
	[Token(Token = "0x6002656")]
	[Address(RVA = "0x2FAB6EC", Offset = "0x2FAB6EC", VA = "0x2FAB6EC")]
	public void \u083FԤթ\u07B2(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("true");
	}

	// Token: 0x06002657 RID: 9815 RVA: 0x000D9444 File Offset: 0x000D7644
	[Token(Token = "0x6002657")]
	[Address(RVA = "0x2FAB768", Offset = "0x2FAB768", VA = "0x2FAB768")]
	public void \u07FE߆לى(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Wear Hoodie");
	}

	// Token: 0x06002658 RID: 9816 RVA: 0x000D9468 File Offset: 0x000D7668
	[Token(Token = "0x6002658")]
	[Address(RVA = "0x2FAB7E4", Offset = "0x2FAB7E4", VA = "0x2FAB7E4")]
	public void \u0821\u059Fӕ\u0607()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("FingerTip");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("NoseAttachPoint").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002659 RID: 9817 RVA: 0x000D978C File Offset: 0x000D798C
	[Token(Token = "0x6002659")]
	[Address(RVA = "0x2FABC18", Offset = "0x2FABC18", VA = "0x2FABC18")]
	public void Օ\u0888\u05EE\u0747(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
	}

	// Token: 0x0600265A RID: 9818 RVA: 0x000D97B0 File Offset: 0x000D79B0
	[Token(Token = "0x600265A")]
	[Address(RVA = "0x2FABC94", Offset = "0x2FABC94", VA = "0x2FABC94")]
	public void ڷ\u0826ӹڥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Joined a Room.");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x0600265B RID: 9819 RVA: 0x000D97E0 File Offset: 0x000D79E0
	[Token(Token = "0x600265B")]
	[Address(RVA = "0x2FABD14", Offset = "0x2FABD14", VA = "0x2FABD14")]
	public void צ\u0874ڵ\u059A()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Purchase For ");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Right Hand").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x0600265C RID: 9820 RVA: 0x000D9B04 File Offset: 0x000D7D04
	[Token(Token = "0x600265C")]
	[Address(RVA = "0x2FAC148", Offset = "0x2FAC148", VA = "0x2FAC148")]
	public void \u0705\u0816\u0739դ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("HandL");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("User has been reported for: ").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x0600265D RID: 9821 RVA: 0x000D9E28 File Offset: 0x000D8028
	[Token(Token = "0x600265D")]
	[Address(RVA = "0x2FAC57C", Offset = "0x2FAC57C", VA = "0x2FAC57C")]
	public void ڦکӁ\u06E2()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("typesOfTalk");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("run").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x0600265E RID: 9822 RVA: 0x000DA14C File Offset: 0x000D834C
	[Token(Token = "0x600265E")]
	[Address(RVA = "0x2FAC9B0", Offset = "0x2FAC9B0", VA = "0x2FAC9B0")]
	public void \u061DՁ\u070Eթ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Combine textures & build combined mesh using coroutine");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("FingerTip").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x0600265F RID: 9823 RVA: 0x000DA470 File Offset: 0x000D8670
	[Token(Token = "0x600265F")]
	[Address(RVA = "0x2FACDE4", Offset = "0x2FACDE4", VA = "0x2FACDE4")]
	public void \u0829\u05FDژտ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		long ܗ۷_u0896_u = 0L;
		GameObject gameObject = GameObject.FindGameObjectWithTag("TurnAmount");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Collided").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002660 RID: 9824 RVA: 0x000DA798 File Offset: 0x000D8998
	[Token(Token = "0x6002660")]
	[Address(RVA = "0x2FAD218", Offset = "0x2FAD218", VA = "0x2FAD218")]
	public void \u0838ӆڛӑ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("_Tint");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("On").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002661 RID: 9825 RVA: 0x000DAABC File Offset: 0x000D8CBC
	[Token(Token = "0x6002661")]
	[Address(RVA = "0x2FAD64C", Offset = "0x2FAD64C", VA = "0x2FAD64C")]
	public void ߂ӹ\u05C6\u07F9(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("5BN");
	}

	// Token: 0x06002662 RID: 9826 RVA: 0x000DAAE0 File Offset: 0x000D8CE0
	[Token(Token = "0x6002662")]
	[Address(RVA = "0x2FAD6C8", Offset = "0x2FAD6C8", VA = "0x2FAD6C8")]
	public void \u0872\u0610ۅ\u06E1(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002663 RID: 9827 RVA: 0x000DAB10 File Offset: 0x000D8D10
	[Token(Token = "0x6002663")]
	[Address(RVA = "0x2FAD748", Offset = "0x2FAD748", VA = "0x2FAD748")]
	public void ԙضփӌ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Version");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("typesOfTalk").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002664 RID: 9828 RVA: 0x000DAE34 File Offset: 0x000D9034
	[Token(Token = "0x6002664")]
	[Address(RVA = "0x2FADB7C", Offset = "0x2FADB7C", VA = "0x2FADB7C")]
	public void ӹӼӂӄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Network Player");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002665 RID: 9829 RVA: 0x000DAE64 File Offset: 0x000D9064
	[Token(Token = "0x6002665")]
	[Address(RVA = "0x2FADBFC", Offset = "0x2FADBFC", VA = "0x2FADBFC")]
	public void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Players Online: ");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002666 RID: 9830 RVA: 0x000DAE94 File Offset: 0x000D9094
	[Token(Token = "0x6002666")]
	[Address(RVA = "0x2FADC7C", Offset = "0x2FADC7C", VA = "0x2FADC7C")]
	public void \u0670Ր\u0741Ӵ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002667 RID: 9831 RVA: 0x000DAEC4 File Offset: 0x000D90C4
	[Token(Token = "0x6002667")]
	[Address(RVA = "0x2FADCFC", Offset = "0x2FADCFC", VA = "0x2FADCFC")]
	public void \u0589\u0740\u05C6ӧ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("got funky mone");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002668 RID: 9832 RVA: 0x000DAEF4 File Offset: 0x000D90F4
	[Token(Token = "0x6002668")]
	[Address(RVA = "0x2FADD7C", Offset = "0x2FADD7C", VA = "0x2FADD7C")]
	public void Өכ\u0873ݩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Players In Room: ");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002669 RID: 9833 RVA: 0x000DAF24 File Offset: 0x000D9124
	[Token(Token = "0x6002669")]
	[Address(RVA = "0x2FADDFC", Offset = "0x2FADDFC", VA = "0x2FADDFC")]
	public void \u05AB\u05BEӞނ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("On");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x0600266A RID: 9834 RVA: 0x000DAF54 File Offset: 0x000D9154
	[Token(Token = "0x600266A")]
	[Address(RVA = "0x2FADE7C", Offset = "0x2FADE7C", VA = "0x2FADE7C")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Song Index: ");
	}

	// Token: 0x0600266B RID: 9835 RVA: 0x000DAF78 File Offset: 0x000D9178
	[Token(Token = "0x600266B")]
	[Address(RVA = "0x2FADEF8", Offset = "0x2FADEF8", VA = "0x2FADEF8")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("You Look Like Butt");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x0600266C RID: 9836 RVA: 0x000DAFA8 File Offset: 0x000D91A8
	[Token(Token = "0x600266C")]
	[Address(RVA = "0x2FADF78", Offset = "0x2FADF78", VA = "0x2FADF78")]
	public void \u05AD\u0881ࡆݡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Regular");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x0600266D RID: 9837 RVA: 0x000DAFD8 File Offset: 0x000D91D8
	[Token(Token = "0x600266D")]
	[Address(RVA = "0x2FADFF8", Offset = "0x2FADFF8", VA = "0x2FADFF8")]
	public void \u0884ٿ\u0659ԫ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ORGTARG");
	}

	// Token: 0x0600266E RID: 9838 RVA: 0x000DAFFC File Offset: 0x000D91FC
	[Token(Token = "0x600266E")]
	[Address(RVA = "0x2FAE074", Offset = "0x2FAE074", VA = "0x2FAE074")]
	public void ࠆ\u058BࢳԼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Agreed");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x0600266F RID: 9839 RVA: 0x000DB02C File Offset: 0x000D922C
	[Token(Token = "0x600266F")]
	[Address(RVA = "0x2FAE0F4", Offset = "0x2FAE0F4", VA = "0x2FAE0F4")]
	public void Ӣ\u0592ߨׯ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("PushToTalk");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("PURCHASED").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002670 RID: 9840 RVA: 0x000DB350 File Offset: 0x000D9550
	[Token(Token = "0x6002670")]
	[Address(RVA = "0x2FAE528", Offset = "0x2FAE528", VA = "0x2FAE528")]
	public void ڃրӢԖ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		long ܗ۷_u0896_u = 0L;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Player").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002671 RID: 9841 RVA: 0x000DB678 File Offset: 0x000D9878
	[Token(Token = "0x6002671")]
	[Address(RVA = "0x2FAE948", Offset = "0x2FAE948", VA = "0x2FAE948")]
	public void \u07A7ࡐ\u0818ܭ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Combine textures & build combined mesh using coroutine");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("5BN").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002672 RID: 9842 RVA: 0x000DB99C File Offset: 0x000D9B9C
	[Token(Token = "0x6002672")]
	[Address(RVA = "0x2FAED7C", Offset = "0x2FAED7C", VA = "0x2FAED7C")]
	public void \u05B1ܨ\u083Bշ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Is Colliding");
	}

	// Token: 0x06002673 RID: 9843 RVA: 0x000DB9C0 File Offset: 0x000D9BC0
	[Token(Token = "0x6002673")]
	[Address(RVA = "0x2FAEDF8", Offset = "0x2FAEDF8", VA = "0x2FAEDF8")]
	public void ޒ\u0816Ӑ۱()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("FingerTip");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("HandL").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002674 RID: 9844 RVA: 0x000DBCE4 File Offset: 0x000D9EE4
	[Token(Token = "0x6002674")]
	[Address(RVA = "0x2FAF22C", Offset = "0x2FAF22C", VA = "0x2FAF22C")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("spooky guy true");
	}

	// Token: 0x06002675 RID: 9845 RVA: 0x000DBD08 File Offset: 0x000D9F08
	[Token(Token = "0x6002675")]
	[Address(RVA = "0x2FAF2A8", Offset = "0x2FAF2A8", VA = "0x2FAF2A8")]
	public void ۶ٯڄػ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("ORGTARG");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Player").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002676 RID: 9846 RVA: 0x000DC02C File Offset: 0x000DA22C
	[Token(Token = "0x6002676")]
	[Address(RVA = "0x2FAF6DC", Offset = "0x2FAF6DC", VA = "0x2FAF6DC")]
	public void ؤ\u05C8ԛ\u083F()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("A Player has left the Room.");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("StartGamemode").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002677 RID: 9847 RVA: 0x000DC350 File Offset: 0x000DA550
	[Token(Token = "0x6002677")]
	[Address(RVA = "0x2FAFB10", Offset = "0x2FAFB10", VA = "0x2FAFB10")]
	public void ք\u05FEؽ\u061E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("DisableCosmetic");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002678 RID: 9848 RVA: 0x000DC380 File Offset: 0x000DA580
	[Token(Token = "0x6002678")]
	[Address(RVA = "0x2FAFB90", Offset = "0x2FAFB90", VA = "0x2FAFB90")]
	public void \u0732\u089Fࢦߣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ORGPORT");
	}

	// Token: 0x06002679 RID: 9849 RVA: 0x000DC3A4 File Offset: 0x000DA5A4
	[Token(Token = "0x6002679")]
	[Address(RVA = "0x2FAFC0C", Offset = "0x2FAFC0C", VA = "0x2FAFC0C")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("MetaAuth");
	}

	// Token: 0x0600267A RID: 9850 RVA: 0x000DC3C8 File Offset: 0x000DA5C8
	[Token(Token = "0x600267A")]
	[Address(RVA = "0x2FAFC88", Offset = "0x2FAFC88", VA = "0x2FAFC88")]
	public void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("BLUPORT");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x0600267B RID: 9851 RVA: 0x000DC3F8 File Offset: 0x000DA5F8
	[Token(Token = "0x600267B")]
	[Address(RVA = "0x2FAFD08", Offset = "0x2FAFD08", VA = "0x2FAFD08")]
	public void ل\u0732ߍӒ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Diffuse");
	}

	// Token: 0x0600267C RID: 9852 RVA: 0x000DC41C File Offset: 0x000DA61C
	[Token(Token = "0x600267C")]
	[Address(RVA = "0x2FAFD84", Offset = "0x2FAFD84", VA = "0x2FAFD84")]
	public void \u07EEډӲ۵()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Players Online: ");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Player was caught cheating").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x0600267D RID: 9853 RVA: 0x000DC740 File Offset: 0x000DA940
	[Token(Token = "0x600267D")]
	[Address(RVA = "0x2FB01B8", Offset = "0x2FB01B8", VA = "0x2FB01B8")]
	public void ࢺճ\u05A0ڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x0600267E RID: 9854 RVA: 0x000DC770 File Offset: 0x000DA970
	[Token(Token = "0x600267E")]
	[Address(RVA = "0x2FB0238", Offset = "0x2FB0238", VA = "0x2FB0238")]
	public void \u089F\u085Fէ\u059A()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("username");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("isLava").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x0600267F RID: 9855 RVA: 0x000DCA94 File Offset: 0x000DAC94
	[Token(Token = "0x600267F")]
	[Address(RVA = "0x2FB066C", Offset = "0x2FB066C", VA = "0x2FB066C")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
	}

	// Token: 0x06002680 RID: 9856 RVA: 0x000DCAB8 File Offset: 0x000DACB8
	[Token(Token = "0x6002680")]
	[Address(RVA = "0x2FB06E8", Offset = "0x2FB06E8", VA = "0x2FB06E8")]
	public void ڇ۹ժד(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("hand 2");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002681 RID: 9857 RVA: 0x000DCAE8 File Offset: 0x000DACE8
	[Token(Token = "0x6002681")]
	[Address(RVA = "0x2FB0768", Offset = "0x2FB0768", VA = "0x2FB0768")]
	public void ځޤקࠈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Version");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002682 RID: 9858 RVA: 0x000DCB18 File Offset: 0x000DAD18
	[Token(Token = "0x6002682")]
	[Address(RVA = "0x2FB07E8", Offset = "0x2FB07E8", VA = "0x2FB07E8")]
	public void \u065F\u0597ծܡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Key");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002683 RID: 9859 RVA: 0x000DCB48 File Offset: 0x000DAD48
	[Token(Token = "0x6002683")]
	[Address(RVA = "0x2FB0868", Offset = "0x2FB0868", VA = "0x2FB0868")]
	public void \u0614ࢥӴ\u086C()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("On");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("HandR").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002684 RID: 9860 RVA: 0x000DCE6C File Offset: 0x000DB06C
	[Token(Token = "0x6002684")]
	[Address(RVA = "0x2FB0C9C", Offset = "0x2FB0C9C", VA = "0x2FB0C9C")]
	public void \u05EDց\u081Cت()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("TurnAmount");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("NetworkPlayer").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002685 RID: 9861 RVA: 0x000DD190 File Offset: 0x000DB390
	[Token(Token = "0x6002685")]
	[Address(RVA = "0x2FB10D0", Offset = "0x2FB10D0", VA = "0x2FB10D0")]
	public void דڳߡࠇ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Tagging");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("procedural animation script required on ").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		float value3;
		if (this.ӈ\u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale4 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale5 = u081B_u070Aߢࡁ3.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale7 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002686 RID: 9862 RVA: 0x000DD4A0 File Offset: 0x000DB6A0
	[Token(Token = "0x6002686")]
	[Address(RVA = "0x2FB1504", Offset = "0x2FB1504", VA = "0x2FB1504")]
	public void ԜӞ\u05AD\u088C()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("You are not the master of the server, you cannot start the game.");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("ErrorScreen").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002687 RID: 9863 RVA: 0x000DD7C4 File Offset: 0x000DB9C4
	[Token(Token = "0x6002687")]
	[Address(RVA = "0x2FB1938", Offset = "0x2FB1938", VA = "0x2FB1938")]
	public void \u086D\u089AԾ\u0881(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("containsStaff");
	}

	// Token: 0x06002688 RID: 9864 RVA: 0x000DD7E8 File Offset: 0x000DB9E8
	[Token(Token = "0x6002688")]
	[Address(RVA = "0x2FB19B4", Offset = "0x2FB19B4", VA = "0x2FB19B4")]
	public void \u05ABࡡ\u07ABݾ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Player");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("username").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002689 RID: 9865 RVA: 0x000DDB0C File Offset: 0x000DBD0C
	[Token(Token = "0x6002689")]
	[Address(RVA = "0x2FB1DE8", Offset = "0x2FB1DE8", VA = "0x2FB1DE8")]
	public void ԕ\u05CAطٱ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("CapuchinStore");
	}

	// Token: 0x0600268A RID: 9866 RVA: 0x000DDB30 File Offset: 0x000DBD30
	[Token(Token = "0x600268A")]
	[Address(RVA = "0x2FB1E64", Offset = "0x2FB1E64", VA = "0x2FB1E64")]
	public void ޤԒݟ\u065A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Did Hit");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x0600268B RID: 9867 RVA: 0x000DDB60 File Offset: 0x000DBD60
	[Token(Token = "0x600268B")]
	[Address(RVA = "0x2FB1EE4", Offset = "0x2FB1EE4", VA = "0x2FB1EE4")]
	public void \u070Aәޣے()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("clickLol");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("BloodKill").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x0600268C RID: 9868 RVA: 0x000DDE84 File Offset: 0x000DC084
	[Token(Token = "0x600268C")]
	[Address(RVA = "0x2FB2318", Offset = "0x2FB2318", VA = "0x2FB2318")]
	public void ࢨݫۮݛ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("DISABLE");
	}

	// Token: 0x0600268D RID: 9869 RVA: 0x000DDEA8 File Offset: 0x000DC0A8
	[Token(Token = "0x600268D")]
	[Address(RVA = "0x2FB2394", Offset = "0x2FB2394", VA = "0x2FB2394")]
	public void \u05C1ؽԜࡥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Completed baking textures on frame ");
	}

	// Token: 0x0600268E RID: 9870 RVA: 0x000DDECC File Offset: 0x000DC0CC
	[Token(Token = "0x600268E")]
	[Address(RVA = "0x2FB2410", Offset = "0x2FB2410", VA = "0x2FB2410")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(".Please press the button if you would like to play alone");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x0600268F RID: 9871 RVA: 0x000DDEFC File Offset: 0x000DC0FC
	[Token(Token = "0x600268F")]
	[Address(RVA = "0x2FB2490", Offset = "0x2FB2490", VA = "0x2FB2490")]
	public void ߊ\u066A\u05CFԉ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u;
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		GameObject gameObject;
		PhotonView component = gameObject.GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002690 RID: 9872 RVA: 0x000DE210 File Offset: 0x000DC410
	[Token(Token = "0x6002690")]
	[Address(RVA = "0x2FB28AC", Offset = "0x2FB28AC", VA = "0x2FB28AC")]
	public void ࠍ\u06E5\u055Eئ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayerHead");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002691 RID: 9873 RVA: 0x000DE240 File Offset: 0x000DC440
	[Token(Token = "0x6002691")]
	[Address(RVA = "0x2FB292C", Offset = "0x2FB292C", VA = "0x2FB292C")]
	public void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Head");
	}

	// Token: 0x06002692 RID: 9874 RVA: 0x000DE264 File Offset: 0x000DC464
	[Token(Token = "0x6002692")]
	[Address(RVA = "0x2FB29A8", Offset = "0x2FB29A8", VA = "0x2FB29A8")]
	public void \u085Cݯژ\u05FA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("A new Player joined a Room.");
	}

	// Token: 0x06002693 RID: 9875 RVA: 0x000DE288 File Offset: 0x000DC488
	[Token(Token = "0x6002693")]
	[Address(RVA = "0x2FB2A24", Offset = "0x2FB2A24", VA = "0x2FB2A24")]
	public void \u061B\u05EEوۈ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Display Name Changed!");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("You have been banned for ").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x06002694 RID: 9876 RVA: 0x000DE5AC File Offset: 0x000DC7AC
	[Token(Token = "0x6002694")]
	[Address(RVA = "0x2FB2E58", Offset = "0x2FB2E58", VA = "0x2FB2E58")]
	public void پնԎ\u087A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("friend");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002695 RID: 9877 RVA: 0x000DE5DC File Offset: 0x000DC7DC
	[Token(Token = "0x6002695")]
	[Address(RVA = "0x2FB2ED8", Offset = "0x2FB2ED8", VA = "0x2FB2ED8")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Players In Room: ");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002696 RID: 9878 RVA: 0x000DE60C File Offset: 0x000DC80C
	[Token(Token = "0x6002696")]
	[Address(RVA = "0x2FB2F58", Offset = "0x2FB2F58", VA = "0x2FB2F58")]
	public void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("StartGamemode");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x06002697 RID: 9879 RVA: 0x000DE63C File Offset: 0x000DC83C
	[Token(Token = "0x6002697")]
	[Address(RVA = "0x2FB2FD8", Offset = "0x2FB2FD8", VA = "0x2FB2FD8")]
	public void \u07B4\u0594ԁڇ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Tagged");
	}

	// Token: 0x06002698 RID: 9880 RVA: 0x000DE660 File Offset: 0x000DC860
	[Token(Token = "0x6002698")]
	[Address(RVA = "0x2FB3054", Offset = "0x2FB3054", VA = "0x2FB3054")]
	public void \u0870߀ڿߔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
	}

	// Token: 0x06002699 RID: 9881 RVA: 0x000DE684 File Offset: 0x000DC884
	[Token(Token = "0x6002699")]
	[Address(RVA = "0x2FB30D0", Offset = "0x2FB30D0", VA = "0x2FB30D0")]
	public void \u05FD\u06E1\u064Cԕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
	}

	// Token: 0x0600269A RID: 9882 RVA: 0x000DE6A8 File Offset: 0x000DC8A8
	[Token(Token = "0x600269A")]
	[Address(RVA = "0x2FB314C", Offset = "0x2FB314C", VA = "0x2FB314C")]
	public void \u061Fࡆ\u086F\u07B0()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Meta Platform entitlement error: ");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("QuickStatic").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x0600269B RID: 9883 RVA: 0x000DE9C0 File Offset: 0x000DCBC0
	[Token(Token = "0x600269B")]
	[Address(RVA = "0x2FB3580", Offset = "0x2FB3580", VA = "0x2FB3580")]
	public void א\u087A\u0607ݸ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("This is the 5000 Bananas button, and it was just clicked");
	}

	// Token: 0x0600269C RID: 9884 RVA: 0x000DE9E4 File Offset: 0x000DCBE4
	[Token(Token = "0x600269C")]
	[Address(RVA = "0x2FB35FC", Offset = "0x2FB35FC", VA = "0x2FB35FC")]
	public void ٮ\u05C5ࡢה(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PRESS AGAIN TO CONFIRM");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x0600269D RID: 9885 RVA: 0x000DEA14 File Offset: 0x000DCC14
	[Token(Token = "0x600269D")]
	[Address(RVA = "0x2FB367C", Offset = "0x2FB367C", VA = "0x2FB367C")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("DisableCosmetic");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("isLava").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x0600269E RID: 9886 RVA: 0x000DED38 File Offset: 0x000DCF38
	[Token(Token = "0x600269E")]
	[Address(RVA = "0x2FB3AB0", Offset = "0x2FB3AB0", VA = "0x2FB3AB0")]
	public void \u05C4ݳ\u05BCࡂ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Player");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("isLava").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x0600269F RID: 9887 RVA: 0x000DF05C File Offset: 0x000DD25C
	[Token(Token = "0x600269F")]
	[Address(RVA = "0x2FB3EE4", Offset = "0x2FB3EE4", VA = "0x2FB3EE4")]
	public void \u0892ܒܬޓ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("User has been reported for: ");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Player").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026A0 RID: 9888 RVA: 0x000DF380 File Offset: 0x000DD580
	[Token(Token = "0x60026A0")]
	[Address(RVA = "0x2FB4318", Offset = "0x2FB4318", VA = "0x2FB4318")]
	public lerpScaleAndPos()
	{
	}

	// Token: 0x060026A1 RID: 9889 RVA: 0x000DF394 File Offset: 0x000DD594
	[Token(Token = "0x60026A1")]
	[Address(RVA = "0x2FB4320", Offset = "0x2FB4320", VA = "0x2FB4320")]
	public void \u087BӦןݩ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("goDownRPC");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("duration done").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026A2 RID: 9890 RVA: 0x000DF6B8 File Offset: 0x000DD8B8
	[Token(Token = "0x60026A2")]
	[Address(RVA = "0x2FB4754", Offset = "0x2FB4754", VA = "0x2FB4754")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("containsStaff");
	}

	// Token: 0x060026A3 RID: 9891 RVA: 0x000DF6DC File Offset: 0x000DD8DC
	[Token(Token = "0x60026A3")]
	[Address(RVA = "0x2FB47D0", Offset = "0x2FB47D0", VA = "0x2FB47D0")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("\n Time: ");
	}

	// Token: 0x060026A4 RID: 9892 RVA: 0x000DF700 File Offset: 0x000DD900
	[Token(Token = "0x60026A4")]
	[Address(RVA = "0x2FB484C", Offset = "0x2FB484C", VA = "0x2FB484C")]
	public void Update()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("NetworkPlayer");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("NetworkPlayer").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026A5 RID: 9893 RVA: 0x000DFA24 File Offset: 0x000DDC24
	[Token(Token = "0x60026A5")]
	[Address(RVA = "0x2FB4C64", Offset = "0x2FB4C64", VA = "0x2FB4C64")]
	public void \u070C\u05FD\u07F9ܬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("TurnAmount");
	}

	// Token: 0x060026A6 RID: 9894 RVA: 0x000DFA48 File Offset: 0x000DDC48
	[Token(Token = "0x60026A6")]
	[Address(RVA = "0x2FB4CE0", Offset = "0x2FB4CE0", VA = "0x2FB4CE0")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("HOLY MOLY THE STICK IS ON FIRE!!!!!!");
	}

	// Token: 0x060026A7 RID: 9895 RVA: 0x000DFA68 File Offset: 0x000DDC68
	[Token(Token = "0x60026A7")]
	[Address(RVA = "0x2FB4D5C", Offset = "0x2FB4D5C", VA = "0x2FB4D5C")]
	public void \u0619طӍ\u083D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Count of rooms ");
	}

	// Token: 0x060026A8 RID: 9896 RVA: 0x000DFA8C File Offset: 0x000DDC8C
	[Token(Token = "0x60026A8")]
	[Address(RVA = "0x2FB4DD8", Offset = "0x2FB4DD8", VA = "0x2FB4DD8")]
	public void \u073Bٿ\u0835\u085C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("M/d/yyyy");
	}

	// Token: 0x060026A9 RID: 9897 RVA: 0x000DFAB0 File Offset: 0x000DDCB0
	[Token(Token = "0x60026A9")]
	[Address(RVA = "0x2FB4E54", Offset = "0x2FB4E54", VA = "0x2FB4E54")]
	public void پ\u05F7\u06E6ރ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("duration done");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026AA RID: 9898 RVA: 0x000DFAE0 File Offset: 0x000DDCE0
	[Token(Token = "0x60026AA")]
	[Address(RVA = "0x2FB4ED4", Offset = "0x2FB4ED4", VA = "0x2FB4ED4")]
	public void יԠ\u07EDԺ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("TurnAmount");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Not connected to room").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026AB RID: 9899 RVA: 0x000DFE04 File Offset: 0x000DE004
	[Token(Token = "0x60026AB")]
	[Address(RVA = "0x2FB5308", Offset = "0x2FB5308", VA = "0x2FB5308")]
	public void \u07F3\u0876ߗ\u06FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("RainAndThunderWeather");
	}

	// Token: 0x060026AC RID: 9900 RVA: 0x000DFE28 File Offset: 0x000DE028
	[Token(Token = "0x60026AC")]
	[Address(RVA = "0x2FB5384", Offset = "0x2FB5384", VA = "0x2FB5384")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026AD RID: 9901 RVA: 0x000DFE58 File Offset: 0x000DE058
	[Token(Token = "0x60026AD")]
	[Address(RVA = "0x2FB5404", Offset = "0x2FB5404", VA = "0x2FB5404")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeToTagged");
	}

	// Token: 0x060026AE RID: 9902 RVA: 0x000DFE7C File Offset: 0x000DE07C
	[Token(Token = "0x60026AE")]
	[Address(RVA = "0x2FB5480", Offset = "0x2FB5480", VA = "0x2FB5480")]
	public void ࢷࢯ\u05B2ݸ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("HandL");
	}

	// Token: 0x060026AF RID: 9903 RVA: 0x000DFEA0 File Offset: 0x000DE0A0
	[Token(Token = "0x60026AF")]
	[Address(RVA = "0x2FB54FC", Offset = "0x2FB54FC", VA = "0x2FB54FC")]
	public void ԋߍҼԒ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Updating Material to: ");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026B0 RID: 9904 RVA: 0x000DFED0 File Offset: 0x000DE0D0
	[Token(Token = "0x60026B0")]
	[Address(RVA = "0x2FB557C", Offset = "0x2FB557C", VA = "0x2FB557C")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026B1 RID: 9905 RVA: 0x000DFF00 File Offset: 0x000DE100
	[Token(Token = "0x60026B1")]
	[Address(RVA = "0x2FB55FC", Offset = "0x2FB55FC", VA = "0x2FB55FC")]
	public void ࡘ\u0891ࢥ\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Tagged");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026B2 RID: 9906 RVA: 0x000DFF30 File Offset: 0x000DE130
	[Token(Token = "0x60026B2")]
	[Address(RVA = "0x2FB567C", Offset = "0x2FB567C", VA = "0x2FB567C")]
	public void \u085Dۍ\u0659Ӂ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Toxicity");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("You have been banned for ").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026B3 RID: 9907 RVA: 0x000E0254 File Offset: 0x000DE454
	[Token(Token = "0x60026B3")]
	[Address(RVA = "0x2FB5AB0", Offset = "0x2FB5AB0", VA = "0x2FB5AB0")]
	public void ڎՅڤࠊ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Open");
	}

	// Token: 0x060026B4 RID: 9908 RVA: 0x000E0278 File Offset: 0x000DE478
	[Token(Token = "0x60026B4")]
	[Address(RVA = "0x2FB5B2C", Offset = "0x2FB5B2C", VA = "0x2FB5B2C")]
	public void \u05F8ݑ\u06ECߞ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("DisableCosmetic");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Left a room").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026B5 RID: 9909 RVA: 0x000E059C File Offset: 0x000DE79C
	[Token(Token = "0x60026B5")]
	[Address(RVA = "0x2FB5F60", Offset = "0x2FB5F60", VA = "0x2FB5F60")]
	public void ی\u0823ڇݔ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Add/Remove Glasses");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("ErrorScreen").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026B6 RID: 9910 RVA: 0x000E08C0 File Offset: 0x000DEAC0
	[Token(Token = "0x60026B6")]
	[Address(RVA = "0x2FB6394", Offset = "0x2FB6394", VA = "0x2FB6394")]
	public void ފՖߢ\u059B()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("hh:mm:sstt");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("SetColor").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026B7 RID: 9911 RVA: 0x000E0BE0 File Offset: 0x000DEDE0
	[Token(Token = "0x60026B7")]
	[Address(RVA = "0x2FB67C8", Offset = "0x2FB67C8", VA = "0x2FB67C8")]
	public void \u066B\u0733ܥ\u086B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PushToTalk");
	}

	// Token: 0x060026B8 RID: 9912 RVA: 0x000E0C04 File Offset: 0x000DEE04
	[Token(Token = "0x60026B8")]
	[Address(RVA = "0x2FB6844", Offset = "0x2FB6844", VA = "0x2FB6844")]
	public void \u05F7ԝߠӱ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("spooky guy true");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Collided").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026B9 RID: 9913 RVA: 0x000E0F28 File Offset: 0x000DF128
	[Token(Token = "0x60026B9")]
	[Address(RVA = "0x2FB6C78", Offset = "0x2FB6C78", VA = "0x2FB6C78")]
	public void \u0832ࢳޤ\u07B5()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("duration done");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("ErrorScreen").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026BA RID: 9914 RVA: 0x000E124C File Offset: 0x000DF44C
	[Token(Token = "0x60026BA")]
	[Address(RVA = "0x2FB70AC", Offset = "0x2FB70AC", VA = "0x2FB70AC")]
	public void ہݕ\u07EFԒ()
	{
		if ("\ud9c0\udc00" == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("ORGTARG");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("run").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		Transform u081B_u070Aߢࡁ4;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
			Vector3 localScale5 = u081B_u070Aߢࡁ4.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ6 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ6.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026BB RID: 9915 RVA: 0x000E1570 File Offset: 0x000DF770
	[Token(Token = "0x60026BB")]
	[Address(RVA = "0x2FB74E0", Offset = "0x2FB74E0", VA = "0x2FB74E0")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
	}

	// Token: 0x060026BC RID: 9916 RVA: 0x000E1594 File Offset: 0x000DF794
	[Token(Token = "0x60026BC")]
	[Address(RVA = "0x2FB755C", Offset = "0x2FB755C", VA = "0x2FB755C")]
	public void ࠈ\u07A9\u05B3Ծ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Vector1_d371bd24217449349bd747533d51af6b");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("ChangeToTagged").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026BD RID: 9917 RVA: 0x000E188C File Offset: 0x000DFA8C
	[Token(Token = "0x60026BD")]
	[Address(RVA = "0x2FB7990", Offset = "0x2FB7990", VA = "0x2FB7990")]
	public void ލ\u0892\u064B\u055B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("/");
	}

	// Token: 0x060026BE RID: 9918 RVA: 0x000E18B0 File Offset: 0x000DFAB0
	[Token(Token = "0x60026BE")]
	[Address(RVA = "0x2FB7A0C", Offset = "0x2FB7A0C", VA = "0x2FB7A0C")]
	public void \u055A\u08B5\u0733ӡ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Collided");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("isLava").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		float value3;
		if (this.ӈ\u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale2 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale3 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale4 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale5 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale6 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale7 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026BF RID: 9919 RVA: 0x000E1BC8 File Offset: 0x000DFDC8
	[Token(Token = "0x60026BF")]
	[Address(RVA = "0x2FB7E40", Offset = "0x2FB7E40", VA = "0x2FB7E40")]
	public void ܖռ\u05C8\u089F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Agreed");
	}

	// Token: 0x060026C0 RID: 9920 RVA: 0x000E1BEC File Offset: 0x000DFDEC
	[Token(Token = "0x60026C0")]
	[Address(RVA = "0x2FB7EBC", Offset = "0x2FB7EBC", VA = "0x2FB7EBC")]
	public void ٳךߧع(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("This is the 2500 Bananas button, and it was just clicked");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026C1 RID: 9921 RVA: 0x000E1C1C File Offset: 0x000DFE1C
	[Token(Token = "0x60026C1")]
	[Address(RVA = "0x2FB7F3C", Offset = "0x2FB7F3C", VA = "0x2FB7F3C")]
	public void յߪؾՀ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("PURCHASED!");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("False").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026C2 RID: 9922 RVA: 0x000E1F40 File Offset: 0x000E0140
	[Token(Token = "0x60026C2")]
	[Address(RVA = "0x2FB8370", Offset = "0x2FB8370", VA = "0x2FB8370")]
	public void ࢫ\u0876չՍ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("EnableCosmetic");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("HandR").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026C3 RID: 9923 RVA: 0x000E2264 File Offset: 0x000E0464
	[Token(Token = "0x60026C3")]
	[Address(RVA = "0x2FB87A4", Offset = "0x2FB87A4", VA = "0x2FB87A4")]
	public void މ\u06EAԅܚ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("RightHandAttachPoint");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026C4 RID: 9924 RVA: 0x000E2294 File Offset: 0x000E0494
	[Token(Token = "0x60026C4")]
	[Address(RVA = "0x2FB8824", Offset = "0x2FB8824", VA = "0x2FB8824")]
	public void \u07FE\u0882Զ\u066D()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Calling success callback. baking meshes");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("token").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026C5 RID: 9925 RVA: 0x000E25B8 File Offset: 0x000E07B8
	[Token(Token = "0x60026C5")]
	[Address(RVA = "0x2FB8C58", Offset = "0x2FB8C58", VA = "0x2FB8C58")]
	public void ت\u05F9ޅ\u059A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("procedural animation script required on ");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026C6 RID: 9926 RVA: 0x000E25E8 File Offset: 0x000E07E8
	[Token(Token = "0x60026C6")]
	[Address(RVA = "0x2FB8CD8", Offset = "0x2FB8CD8", VA = "0x2FB8CD8")]
	public void ٠ӄ\u087Cٸ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("make more points bobo");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("Vector1_d371bd24217449349bd747533d51af6b").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Vector3 localScale3 = this.\u081B\u070Aߢࡁ.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ3.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026C7 RID: 9927 RVA: 0x000E2900 File Offset: 0x000E0B00
	[Token(Token = "0x60026C7")]
	[Address(RVA = "0x2FB910C", Offset = "0x2FB910C", VA = "0x2FB910C")]
	public void ەԌ\u05C7\u085D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeToTagged");
	}

	// Token: 0x060026C8 RID: 9928 RVA: 0x000E2924 File Offset: 0x000E0B24
	[Token(Token = "0x60026C8")]
	[Address(RVA = "0x2FB9188", Offset = "0x2FB9188", VA = "0x2FB9188")]
	public void \u0607յ\u061C\u083D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(" hour. You were banned because of ");
	}

	// Token: 0x060026C9 RID: 9929 RVA: 0x000E2948 File Offset: 0x000E0B48
	[Token(Token = "0x60026C9")]
	[Address(RVA = "0x2FB9204", Offset = "0x2FB9204", VA = "0x2FB9204")]
	public void \u060AԨصݚ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("NGNNoSound");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("gamemode").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026CA RID: 9930 RVA: 0x000E2C6C File Offset: 0x000E0E6C
	[Token(Token = "0x60026CA")]
	[Address(RVA = "0x2FB9638", Offset = "0x2FB9638", VA = "0x2FB9638")]
	public void ד\u073C\u0613چ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		long ܗ۷_u0896_u = 0L;
		GameObject gameObject = GameObject.FindGameObjectWithTag("monke is not my monke");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		GameObject gameObject2;
		PhotonView component = gameObject2.GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026CB RID: 9931 RVA: 0x000E2F8C File Offset: 0x000E118C
	[Token(Token = "0x60026CB")]
	[Address(RVA = "0x2FB9A6C", Offset = "0x2FB9A6C", VA = "0x2FB9A6C")]
	public void ݫԨՉ\u07B7(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Joined Public Room Successfully");
	}

	// Token: 0x060026CC RID: 9932 RVA: 0x000E2FB0 File Offset: 0x000E11B0
	[Token(Token = "0x60026CC")]
	[Address(RVA = "0x2FB9AE8", Offset = "0x2FB9AE8", VA = "0x2FB9AE8")]
	public void سܠӛ\u07AA()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("Completed baking textures on frame ");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("{0} ({1})").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026CD RID: 9933 RVA: 0x000E32D4 File Offset: 0x000E14D4
	[Token(Token = "0x60026CD")]
	[Address(RVA = "0x2FB9F1C", Offset = "0x2FB9F1C", VA = "0x2FB9F1C")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("typesOfTalk");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026CE RID: 9934 RVA: 0x000E3304 File Offset: 0x000E1504
	[Token(Token = "0x60026CE")]
	[Address(RVA = "0x2FB9F9C", Offset = "0x2FB9F9C", VA = "0x2FB9F9C")]
	public void \u05AC\u07F0\u07EEࡥ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("PlayerDeath");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("gravThing").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026CF RID: 9935 RVA: 0x000E3628 File Offset: 0x000E1828
	[Token(Token = "0x60026CF")]
	[Address(RVA = "0x2FBA3D0", Offset = "0x2FBA3D0", VA = "0x2FBA3D0")]
	public void \u0590\u0882\u0883ࡦ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("RightHandAttachPoint");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("RightHandAttachPoint").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026D0 RID: 9936 RVA: 0x000E394C File Offset: 0x000E1B4C
	[Token(Token = "0x60026D0")]
	[Address(RVA = "0x2FBA804", Offset = "0x2FBA804", VA = "0x2FBA804")]
	public void \u0819Փٲࡪ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("This is the 5000 Bananas button, and it was just clicked");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026D1 RID: 9937 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x60026D1")]
	[Address(RVA = "0x2FBA884", Offset = "0x2FBA884", VA = "0x2FBA884")]
	public void \u0599ږࠆ\u065F()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060026D2 RID: 9938 RVA: 0x000E397C File Offset: 0x000E1B7C
	[Token(Token = "0x60026D2")]
	[Address(RVA = "0x2FBACB8", Offset = "0x2FBACB8", VA = "0x2FBACB8")]
	public void Ԫߑࠌ\u064C()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject ܗ۷_u0896_u = GameObject.FindGameObjectWithTag("_Tint");
		this.ܗ۷\u0896\u0884 = ܗ۷_u0896_u;
		PhotonView component = GameObject.FindGameObjectWithTag("_BumpMap").GetComponent<PhotonView>();
		this.ӱӤ\u073Aސ = component;
		Vector3 localScale = this.\u081B\u070Aߢࡁ.localScale;
		Transform u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		bool ӈ_u058Bؽڥ = this.ӈ\u058Bؽڥ;
		Vector3 localScale2 = u081B_u070Aߢࡁ.localScale;
		float value3;
		if (ӈ_u058Bؽڥ)
		{
			float lerpSpeed = this.\u061Dܘԉӫ.lerpSpeed;
			float x = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			Transform u081B_u070Aߢࡁ2 = this.\u081B\u070Aߢࡁ;
			Transform ޑډӼ_u064D = this.ޑډӼ\u064D;
			Vector3 localScale3 = u081B_u070Aߢࡁ2.localScale;
			float lerpSpeed2 = this.\u061Dܘԉӫ.lerpSpeed;
			float x2 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y2 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z2 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform u081B_u070Aߢࡁ3 = this.\u081B\u070Aߢࡁ;
			Transform transform = this.ޖڹࡉࢶ;
			Vector3 localScale4 = u081B_u070Aߢࡁ3.localScale;
			float lerpSpeed3 = this.\u061Dܘԉӫ.lerpSpeed;
			float x3 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y3 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z3 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			value3 = Mathf.Clamp01(value);
			Transform transform2 = this.ܗ۷\u0896\u0884.transform;
			Vector3 localScale5 = this.\u081B\u070Aߢࡁ.localScale;
			float x4 = this.\u061Dܘԉӫ.ScaleData.smallSize.x;
			float y4 = this.\u061Dܘԉӫ.ScaleData.smallSize.y;
			float z4 = this.\u061Dܘԉӫ.ScaleData.smallSize.z;
			float lerpSpeed4 = this.\u061Dܘԉӫ.lerpSpeed;
			return;
		}
		float lerpSpeed5 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value4 = Mathf.Clamp01(value3);
		Transform u081B_u070Aߢࡁ4 = this.\u081B\u070Aߢࡁ;
		Transform ޑډӼ_u064D2 = this.ޑډӼ\u064D;
		Vector3 localScale6 = u081B_u070Aߢࡁ4.localScale;
		float lerpSpeed6 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize2 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value5 = Mathf.Clamp01(value4);
		Transform u081B_u070Aߢࡁ5 = this.\u081B\u070Aߢࡁ;
		Transform transform3 = this.ޖڹࡉࢶ;
		Vector3 localScale7 = u081B_u070Aߢࡁ5.localScale;
		float lerpSpeed7 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize3 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float value6 = Mathf.Clamp01(value5);
		Transform transform4 = this.ܗ۷\u0896\u0884.transform;
		Vector3 localScale8 = this.\u081B\u070Aߢࡁ.localScale;
		float lerpSpeed8 = this.\u061Dܘԉӫ.lerpSpeed;
		Vector3 standardSize4 = this.\u061Dܘԉӫ.ScaleData.standardSize;
		float num = Mathf.Clamp01(value6);
	}

	// Token: 0x060026D3 RID: 9939 RVA: 0x000E3CA0 File Offset: 0x000E1EA0
	[Token(Token = "0x60026D3")]
	[Address(RVA = "0x2FBB0EC", Offset = "0x2FBB0EC", VA = "0x2FBB0EC")]
	public void ࡇۑիԗ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeMaterialToNormal");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026D4 RID: 9940 RVA: 0x000E3CD0 File Offset: 0x000E1ED0
	[Token(Token = "0x60026D4")]
	[Address(RVA = "0x2FBB16C", Offset = "0x2FBB16C", VA = "0x2FBB16C")]
	public void ב\u07AFࡩ\u07FB(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("DISABLE");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x060026D5 RID: 9941 RVA: 0x000E3D00 File Offset: 0x000E1F00
	[Token(Token = "0x60026D5")]
	[Address(RVA = "0x2FBB1EC", Offset = "0x2FBB1EC", VA = "0x2FBB1EC")]
	public void ԛۻ\u081C\u07B5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("next");
	}

	// Token: 0x060026D6 RID: 9942 RVA: 0x000E3D24 File Offset: 0x000E1F24
	[Token(Token = "0x60026D6")]
	[Address(RVA = "0x2FBB268", Offset = "0x2FBB268", VA = "0x2FBB268")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("clickLol");
		long ӈ_u058Bؽڥ = 1L;
		this.ӈ\u058Bؽڥ = (ӈ_u058Bؽڥ != 0L);
	}

	// Token: 0x040004E1 RID: 1249
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004E1")]
	public Transform \u081B\u070Aߢࡁ;

	// Token: 0x040004E2 RID: 1250
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004E2")]
	public Transform ޑډӼ\u064D;

	// Token: 0x040004E3 RID: 1251
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40004E3")]
	public Transform ޖڹࡉࢶ;

	// Token: 0x040004E4 RID: 1252
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40004E4")]
	public GameObject ܗ۷\u0896\u0884;

	// Token: 0x040004E5 RID: 1253
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40004E5")]
	public PhotonView ӱӤ\u073Aސ;

	// Token: 0x040004E6 RID: 1254
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40004E6")]
	public bool ӈ\u058Bؽڥ;

	// Token: 0x040004E7 RID: 1255
	[FieldOffset(Offset = "0x41")]
	[Token(Token = "0x40004E7")]
	public bool Ԣ\u07A8ܝؼ;

	// Token: 0x040004E8 RID: 1256
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x40004E8")]
	public lerpScaleAndPos.Lerp \u061Dܘԉӫ;

	// Token: 0x020000F9 RID: 249
	[Token(Token = "0x20000F9")]
	[Serializable]
	public struct Lerp
	{
		// Token: 0x040004E9 RID: 1257
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40004E9")]
		public float lerpSpeed;

		// Token: 0x040004EA RID: 1258
		[FieldOffset(Offset = "0x4")]
		[Token(Token = "0x40004EA")]
		public lerpScaleAndPos.Lerp.Scale ScaleData;

		// Token: 0x020000FA RID: 250
		[Token(Token = "0x20000FA")]
		[Serializable]
		public struct Scale
		{
			// Token: 0x040004EB RID: 1259
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x40004EB")]
			public Vector3 standardSize;

			// Token: 0x040004EC RID: 1260
			[FieldOffset(Offset = "0xC")]
			[Token(Token = "0x40004EC")]
			public Vector3 smallSize;
		}
	}
}
