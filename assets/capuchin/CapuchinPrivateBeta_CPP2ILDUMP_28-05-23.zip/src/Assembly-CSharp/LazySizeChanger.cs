﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000C6 RID: 198
[Token(Token = "0x20000C6")]
public class LazySizeChanger : MonoBehaviourPunCallbacks
{
	// Token: 0x06001D5E RID: 7518 RVA: 0x0009A198 File Offset: 0x00098398
	[Token(Token = "0x6001D5E")]
	[Address(RVA = "0x2CD048C", Offset = "0x2CD048C", VA = "0x2CD048C")]
	public void \u0619طӍ\u083D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You have been banned for ";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.آսՐ\u06E5();
	}

	// Token: 0x06001D5F RID: 7519 RVA: 0x0009A1D8 File Offset: 0x000983D8
	[Token(Token = "0x6001D5F")]
	[Address(RVA = "0x2CD067C", Offset = "0x2CD067C", VA = "0x2CD067C")]
	public void \u06DEӸԏ\u07BF(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Display Name Changed!";
		this.\u07BD\u061E\u061D\u0883();
	}

	// Token: 0x06001D60 RID: 7520 RVA: 0x0009A208 File Offset: 0x00098408
	[Token(Token = "0x6001D60")]
	[Address(RVA = "0x2CD0864", Offset = "0x2CD0864", VA = "0x2CD0864")]
	public void \u0594ڠڪل()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D61 RID: 7521 RVA: 0x0009A254 File Offset: 0x00098454
	[Token(Token = "0x6001D61")]
	[Address(RVA = "0x2CD09B8", Offset = "0x2CD09B8", VA = "0x2CD09B8")]
	public void ܞࠉעڂ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D62 RID: 7522 RVA: 0x0009A2A0 File Offset: 0x000984A0
	[Token(Token = "0x6001D62")]
	[Address(RVA = "0x2CD0B08", Offset = "0x2CD0B08", VA = "0x2CD0B08")]
	public void \u059B\u081F\u05FEڂ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ࡍࢸ\u06E7ࡖ();
	}

	// Token: 0x06001D63 RID: 7523 RVA: 0x0009A2E0 File Offset: 0x000984E0
	[Token(Token = "0x6001D63")]
	[Address(RVA = "0x2CD0CF8", Offset = "0x2CD0CF8", VA = "0x2CD0CF8")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u05A8\u0876\u07ACࠉ();
	}

	// Token: 0x06001D64 RID: 7524 RVA: 0x0009A31C File Offset: 0x0009851C
	[Token(Token = "0x6001D64")]
	[Address(RVA = "0x2CD0EE4", Offset = "0x2CD0EE4", VA = "0x2CD0EE4")]
	public void \u05C3ԅ\u07AA\u0875()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D65 RID: 7525 RVA: 0x0009A368 File Offset: 0x00098568
	[Token(Token = "0x6001D65")]
	[Address(RVA = "0x2CD1034", Offset = "0x2CD1034", VA = "0x2CD1034")]
	public void \u06D4ڟڎޜ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D66 RID: 7526 RVA: 0x0009A41C File Offset: 0x0009861C
	[Token(Token = "0x6001D66")]
	[Address(RVA = "0x2CD1100", Offset = "0x2CD1100", VA = "0x2CD1100")]
	public void \u065F\u0597ծܡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HeadAttachPoint";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ࡋࢸەࡓ();
	}

	// Token: 0x06001D67 RID: 7527 RVA: 0x0009A45C File Offset: 0x0009865C
	[Token(Token = "0x6001D67")]
	[Address(RVA = "0x2CD12EC", Offset = "0x2CD12EC", VA = "0x2CD12EC")]
	public void \u085F\u085CԠڭ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Platform failed to initialize due to exception.";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.ࢥܧܓ\u05C7();
	}

	// Token: 0x06001D68 RID: 7528 RVA: 0x0009A498 File Offset: 0x00098698
	[Token(Token = "0x6001D68")]
	[Address(RVA = "0x2CD14DC", Offset = "0x2CD14DC", VA = "0x2CD14DC")]
	public void ࡇۑիԗ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayerHead";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.߈\u07BFӣٱ();
	}

	// Token: 0x06001D69 RID: 7529 RVA: 0x0009A4D4 File Offset: 0x000986D4
	[Token(Token = "0x6001D69")]
	[Address(RVA = "0x2CD16CC", Offset = "0x2CD16CC", VA = "0x2CD16CC")]
	public void \u05BA\u087AܘҾ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D6A RID: 7530 RVA: 0x0009A588 File Offset: 0x00098788
	[Token(Token = "0x6001D6A")]
	[Address(RVA = "0x2CD1798", Offset = "0x2CD1798", VA = "0x2CD1798")]
	public void ޚݒ٩ݼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ԅاޝܕ();
	}

	// Token: 0x06001D6B RID: 7531 RVA: 0x0009A5C8 File Offset: 0x000987C8
	[Token(Token = "0x6001D6B")]
	[Address(RVA = "0x2CD1984", Offset = "0x2CD1984", VA = "0x2CD1984")]
	public void \u0819Փٲࡪ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.߈\u07BFӣٱ();
	}

	// Token: 0x06001D6C RID: 7532 RVA: 0x0009A604 File Offset: 0x00098804
	[Token(Token = "0x6001D6C")]
	[Address(RVA = "0x2CD1A20", Offset = "0x2CD1A20", VA = "0x2CD1A20")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "DisableCosmetic";
	}

	// Token: 0x06001D6D RID: 7533 RVA: 0x0009A630 File Offset: 0x00098830
	[Token(Token = "0x6001D6D")]
	[Address(RVA = "0x2CD1C0C", Offset = "0x2CD1C0C", VA = "0x2CD1C0C")]
	public void ۿ\u0898Թ\u05A3()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D6E RID: 7534 RVA: 0x0009A678 File Offset: 0x00098878
	[Token(Token = "0x6001D6E")]
	[Address(RVA = "0x2CD1D5C", Offset = "0x2CD1D5C", VA = "0x2CD1D5C")]
	public void \u0832ࢳޤ\u07B5()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D6F RID: 7535 RVA: 0x0009A72C File Offset: 0x0009892C
	[Token(Token = "0x6001D6F")]
	[Address(RVA = "0x2CD1E28", Offset = "0x2CD1E28", VA = "0x2CD1E28")]
	public void ځޤקࠈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "amongus";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u058B\u0896ڢ\u060B();
	}

	// Token: 0x06001D70 RID: 7536 RVA: 0x0009A76C File Offset: 0x0009896C
	[Token(Token = "0x6001D70")]
	[Address(RVA = "0x2CD2014", Offset = "0x2CD2014", VA = "0x2CD2014")]
	public void Ӱ\u061Cإ\u06E1(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u0877\u0816\u07B2ص();
	}

	// Token: 0x06001D71 RID: 7537 RVA: 0x0009A7A8 File Offset: 0x000989A8
	[Token(Token = "0x6001D71")]
	[Address(RVA = "0x2CD2204", Offset = "0x2CD2204", VA = "0x2CD2204")]
	public void \u05B1ܨ\u083Bշ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Thumb";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u058FӠ\u05FDո();
	}

	// Token: 0x06001D72 RID: 7538 RVA: 0x0009A7E8 File Offset: 0x000989E8
	[Token(Token = "0x6001D72")]
	[Address(RVA = "0x2CD22A0", Offset = "0x2CD22A0", VA = "0x2CD22A0")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Start Gamemode";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.څӭ\u06E0ܒ();
	}

	// Token: 0x06001D73 RID: 7539 RVA: 0x0009A824 File Offset: 0x00098A24
	[Token(Token = "0x6001D73")]
	[Address(RVA = "0x2CD248C", Offset = "0x2CD248C", VA = "0x2CD248C")]
	public void Օ\u0888\u05EE\u0747(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Try Connect To Server...";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ڽ\u085Dԓӄ();
	}

	// Token: 0x06001D74 RID: 7540 RVA: 0x0009A864 File Offset: 0x00098A64
	[Token(Token = "0x6001D74")]
	[Address(RVA = "0x2CD1578", Offset = "0x2CD1578", VA = "0x2CD1578")]
	public void ߈\u07BFӣٱ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D75 RID: 7541 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001D75")]
	[Address(RVA = "0x2CD1ABC", Offset = "0x2CD1ABC", VA = "0x2CD1ABC")]
	public void \u058FӠ\u05FDո()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D76 RID: 7542 RVA: 0x0009A8B4 File Offset: 0x00098AB4
	[Token(Token = "0x6001D76")]
	[Address(RVA = "0x2CD2678", Offset = "0x2CD2678", VA = "0x2CD2678")]
	public void \u0654ޛ\u07FAذ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D77 RID: 7543 RVA: 0x0009A968 File Offset: 0x00098B68
	[Token(Token = "0x6001D77")]
	[Address(RVA = "0x2CD2744", Offset = "0x2CD2744", VA = "0x2CD2744")]
	public void ә\u0730\u0839\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "true";
		this.\u06E8ւբޛ();
	}

	// Token: 0x06001D78 RID: 7544 RVA: 0x0009A998 File Offset: 0x00098B98
	[Token(Token = "0x6001D78")]
	[Address(RVA = "0x2CD292C", Offset = "0x2CD292C", VA = "0x2CD292C")]
	public void \u055A\u07ACԁ\u0589()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D79 RID: 7545 RVA: 0x0009A9E4 File Offset: 0x00098BE4
	[Token(Token = "0x6001D79")]
	[Address(RVA = "0x2CD2A80", Offset = "0x2CD2A80", VA = "0x2CD2A80")]
	public void ފՖߢ\u059B()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D7A RID: 7546 RVA: 0x0009AA98 File Offset: 0x00098C98
	[Token(Token = "0x6001D7A")]
	[Address(RVA = "0x2CD2B4C", Offset = "0x2CD2B4C", VA = "0x2CD2B4C")]
	public void ئأԵߑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Left a room";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.\u05A8\u0876\u07ACࠉ();
	}

	// Token: 0x06001D7B RID: 7547 RVA: 0x0009AAD4 File Offset: 0x00098CD4
	[Token(Token = "0x6001D7B")]
	[Address(RVA = "0x2CD2BE8", Offset = "0x2CD2BE8", VA = "0x2CD2BE8")]
	public void ݞߒࢸڢ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D7C RID: 7548 RVA: 0x0009AB88 File Offset: 0x00098D88
	[Token(Token = "0x6001D7C")]
	[Address(RVA = "0x2CD2CB4", Offset = "0x2CD2CB4", VA = "0x2CD2CB4")]
	public LazySizeChanger()
	{
	}

	// Token: 0x06001D7D RID: 7549 RVA: 0x0009AB9C File Offset: 0x00098D9C
	[Token(Token = "0x6001D7D")]
	[Address(RVA = "0x2CD2CBC", Offset = "0x2CD2CBC", VA = "0x2CD2CBC")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.";
		this.\u0707ի\u05FFӸ();
	}

	// Token: 0x06001D7E RID: 7550 RVA: 0x0009ABCC File Offset: 0x00098DCC
	[Token(Token = "0x6001D7E")]
	[Address(RVA = "0x2CD2EA8", Offset = "0x2CD2EA8", VA = "0x2CD2EA8")]
	public void ӻڊ\u05B3ۍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Skelechin";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ࡍࢸ\u06E7ࡖ();
	}

	// Token: 0x06001D7F RID: 7551 RVA: 0x0009AC08 File Offset: 0x00098E08
	[Token(Token = "0x6001D7F")]
	[Address(RVA = "0x2CD2F44", Offset = "0x2CD2F44", VA = "0x2CD2F44")]
	public void ߃\u0602\u0891߇(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HOLY MOLY THE STICK IS ON FIRE!!!!!!";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.آսՐ\u06E5();
	}

	// Token: 0x06001D80 RID: 7552 RVA: 0x0009AC44 File Offset: 0x00098E44
	[Token(Token = "0x6001D80")]
	[Address(RVA = "0x2CD2FE0", Offset = "0x2CD2FE0", VA = "0x2CD2FE0")]
	public void \u0871ࢫֆ\u0899(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u0745\u06E9ٶע();
	}

	// Token: 0x06001D81 RID: 7553 RVA: 0x0009AC84 File Offset: 0x00098E84
	[Token(Token = "0x6001D81")]
	[Address(RVA = "0x2CD1EC4", Offset = "0x2CD1EC4", VA = "0x2CD1EC4")]
	public void \u058B\u0896ڢ\u060B()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D82 RID: 7554 RVA: 0x0009ACD4 File Offset: 0x00098ED4
	[Token(Token = "0x6001D82")]
	[Address(RVA = "0x2CD31D0", Offset = "0x2CD31D0", VA = "0x2CD31D0")]
	public void \u0897ޝߕݰ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D83 RID: 7555 RVA: 0x0009AD20 File Offset: 0x00098F20
	[Token(Token = "0x6001D83")]
	[Address(RVA = "0x2CD3320", Offset = "0x2CD3320", VA = "0x2CD3320")]
	public void \u086Dט\u0898ޑ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D84 RID: 7556 RVA: 0x0009AD6C File Offset: 0x00098F6C
	[Token(Token = "0x6001D84")]
	[Address(RVA = "0x2CD3474", Offset = "0x2CD3474", VA = "0x2CD3474")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "hh:mmtt";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u058FӠ\u05FDո();
	}

	// Token: 0x06001D85 RID: 7557 RVA: 0x0009ADA8 File Offset: 0x00098FA8
	[Token(Token = "0x6001D85")]
	[Address(RVA = "0x2CD3510", Offset = "0x2CD3510", VA = "0x2CD3510")]
	public void ժݮݜՏ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D86 RID: 7558 RVA: 0x0009ADF8 File Offset: 0x00098FF8
	[Token(Token = "0x6001D86")]
	[Address(RVA = "0x2CD3664", Offset = "0x2CD3664", VA = "0x2CD3664")]
	public void ބԺ\u0734ۺ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D87 RID: 7559 RVA: 0x0009AE44 File Offset: 0x00099044
	[Token(Token = "0x6001D87")]
	[Address(RVA = "0x2CD37B8", Offset = "0x2CD37B8", VA = "0x2CD37B8")]
	public void ے\u059Fࢰس(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ܮԜإޟ();
	}

	// Token: 0x06001D88 RID: 7560 RVA: 0x0009AE84 File Offset: 0x00099084
	[Token(Token = "0x6001D88")]
	[Address(RVA = "0x2CD39A4", Offset = "0x2CD39A4", VA = "0x2CD39A4")]
	public void \u05AEӥӺۓ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		this.\u0897ޝߕݰ();
	}

	// Token: 0x06001D89 RID: 7561 RVA: 0x0009AEB4 File Offset: 0x000990B4
	[Token(Token = "0x6001D89")]
	[Address(RVA = "0x2CD2D54", Offset = "0x2CD2D54", VA = "0x2CD2D54")]
	public void \u0707ի\u05FFӸ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D8A RID: 7562 RVA: 0x0009AF04 File Offset: 0x00099104
	[Token(Token = "0x6001D8A")]
	[Address(RVA = "0x2CD0BA4", Offset = "0x2CD0BA4", VA = "0x2CD0BA4")]
	public void ࡍࢸ\u06E7ࡖ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D8B RID: 7563 RVA: 0x0009AF50 File Offset: 0x00099150
	[Token(Token = "0x6001D8B")]
	[Address(RVA = "0x2CD3A3C", Offset = "0x2CD3A3C", VA = "0x2CD3A3C")]
	public void سࡕԞ߆(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ChangeToTagged";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ۿ\u0898Թ\u05A3();
	}

	// Token: 0x06001D8C RID: 7564 RVA: 0x0009AF8C File Offset: 0x0009918C
	[Token(Token = "0x6001D8C")]
	[Address(RVA = "0x2CD3AD8", Offset = "0x2CD3AD8", VA = "0x2CD3AD8")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "QuickStatic";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u086Dט\u0898ޑ();
	}

	// Token: 0x06001D8D RID: 7565 RVA: 0x0009AFCC File Offset: 0x000991CC
	[Token(Token = "0x6001D8D")]
	[Address(RVA = "0x2CD3B74", Offset = "0x2CD3B74", VA = "0x2CD3B74")]
	public void \u05AB\u05BEӞނ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		this.ժݮݜՏ();
	}

	// Token: 0x06001D8E RID: 7566 RVA: 0x0009AFFC File Offset: 0x000991FC
	[Token(Token = "0x6001D8E")]
	[Address(RVA = "0x2CD3C0C", Offset = "0x2CD3C0C", VA = "0x2CD3C0C")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "DISABLE";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ܮԜإޟ();
	}

	// Token: 0x06001D8F RID: 7567 RVA: 0x0009B038 File Offset: 0x00099238
	[Token(Token = "0x6001D8F")]
	[Address(RVA = "0x2CD3CA8", Offset = "0x2CD3CA8", VA = "0x2CD3CA8")]
	public void ࢷࢯ\u05B2ݸ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.\u086Dט\u0898ޑ();
	}

	// Token: 0x06001D90 RID: 7568 RVA: 0x0009B074 File Offset: 0x00099274
	[Token(Token = "0x6001D90")]
	[Address(RVA = "0x2CD3D44", Offset = "0x2CD3D44", VA = "0x2CD3D44")]
	public void ߏ\u07AFٷՂ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "INSIGNIFICANT CURRENCY";
		this.\u0707ի\u05FFӸ();
	}

	// Token: 0x06001D91 RID: 7569 RVA: 0x0009B0A4 File Offset: 0x000992A4
	[Token(Token = "0x6001D91")]
	[Address(RVA = "0x2CD3DDC", Offset = "0x2CD3DDC", VA = "0x2CD3DDC")]
	public void יԠ\u07EDԺ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D92 RID: 7570 RVA: 0x0009B158 File Offset: 0x00099358
	[Token(Token = "0x6001D92")]
	[Address(RVA = "0x2CD3EA8", Offset = "0x2CD3EA8", VA = "0x2CD3EA8")]
	public void ӨӒࡉٽ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D93 RID: 7571 RVA: 0x0009B1A8 File Offset: 0x000993A8
	[Token(Token = "0x6001D93")]
	[Address(RVA = "0x2CD3FF8", Offset = "0x2CD3FF8", VA = "0x2CD3FF8")]
	public void ٶԭ\u07BAن()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D94 RID: 7572 RVA: 0x0009B25C File Offset: 0x0009945C
	[Token(Token = "0x6001D94")]
	[Address(RVA = "0x2CD307C", Offset = "0x2CD307C", VA = "0x2CD307C")]
	public void \u0745\u06E9ٶע()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D95 RID: 7573 RVA: 0x0009B2A8 File Offset: 0x000994A8
	[Token(Token = "0x6001D95")]
	[Address(RVA = "0x2CD40C4", Offset = "0x2CD40C4", VA = "0x2CD40C4")]
	public void Օ\u07A7ࡃࢷ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "BN";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.څӭ\u06E0ܒ();
	}

	// Token: 0x06001D96 RID: 7574 RVA: 0x0009B2E8 File Offset: 0x000994E8
	[Token(Token = "0x6001D96")]
	[Address(RVA = "0x2CD4160", Offset = "0x2CD4160", VA = "0x2CD4160")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "closeToObject";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.څӭ\u06E0ܒ();
	}

	// Token: 0x06001D97 RID: 7575 RVA: 0x0009B324 File Offset: 0x00099524
	[Token(Token = "0x6001D97")]
	[Address(RVA = "0x2CD41FC", Offset = "0x2CD41FC", VA = "0x2CD41FC")]
	public void ࢴ\u087A\u07B9ࢢ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D98 RID: 7576 RVA: 0x0009B3D8 File Offset: 0x000995D8
	[Token(Token = "0x6001D98")]
	[Address(RVA = "0x2CD42C8", Offset = "0x2CD42C8", VA = "0x2CD42C8")]
	public void Վࡧ\u06FDܕ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D99 RID: 7577 RVA: 0x0009B48C File Offset: 0x0009968C
	[Token(Token = "0x6001D99")]
	[Address(RVA = "0x2CD1388", Offset = "0x2CD1388", VA = "0x2CD1388")]
	public void ࢥܧܓ\u05C7()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001D9A RID: 7578 RVA: 0x0009B4D8 File Offset: 0x000996D8
	[Token(Token = "0x6001D9A")]
	[Address(RVA = "0x2CD4394", Offset = "0x2CD4394", VA = "0x2CD4394")]
	public void ࢳ\u06D8Ԙ\u05FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Smoothness";
		this.\u0897ޝߕݰ();
	}

	// Token: 0x06001D9B RID: 7579 RVA: 0x0009B508 File Offset: 0x00099708
	[Token(Token = "0x6001D9B")]
	[Address(RVA = "0x2CD442C", Offset = "0x2CD442C", VA = "0x2CD442C")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayWave";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u058FӠ\u05FDո();
	}

	// Token: 0x06001D9C RID: 7580 RVA: 0x0009B548 File Offset: 0x00099748
	[Token(Token = "0x6001D9C")]
	[Address(RVA = "0x2CD44C8", Offset = "0x2CD44C8", VA = "0x2CD44C8")]
	public void ࠆ\u058BࢳԼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "CapuchinStore";
		this.\u055A\u07ACԁ\u0589();
	}

	// Token: 0x06001D9D RID: 7581 RVA: 0x0009B578 File Offset: 0x00099778
	[Token(Token = "0x6001D9D")]
	[Address(RVA = "0x2CD4560", Offset = "0x2CD4560", VA = "0x2CD4560")]
	public void \u0732ڙԒࢺ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001D9E RID: 7582 RVA: 0x0009B62C File Offset: 0x0009982C
	[Token(Token = "0x6001D9E")]
	[Address(RVA = "0x2CD4628", Offset = "0x2CD4628", VA = "0x2CD4628")]
	public void \u070C\u05FD\u07F9ܬ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u055A\u07ACԁ\u0589();
	}

	// Token: 0x06001D9F RID: 7583 RVA: 0x0009B66C File Offset: 0x0009986C
	[Token(Token = "0x6001D9F")]
	[Address(RVA = "0x2CD46C4", Offset = "0x2CD46C4", VA = "0x2CD46C4")]
	public void ہݕ\u07EFԒ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DA0 RID: 7584 RVA: 0x0009B720 File Offset: 0x00099920
	[Token(Token = "0x6001DA0")]
	[Address(RVA = "0x2CD4790", Offset = "0x2CD4790", VA = "0x2CD4790")]
	public void ݨ\u065A\u065A\u087D()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DA1 RID: 7585 RVA: 0x0009B76C File Offset: 0x0009996C
	[Token(Token = "0x6001DA1")]
	[Address(RVA = "0x2CD48E4", Offset = "0x2CD48E4", VA = "0x2CD48E4")]
	public void Ӻ\u0828\u07BD\u06ED()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DA2 RID: 7586 RVA: 0x0009B820 File Offset: 0x00099A20
	[Token(Token = "0x6001DA2")]
	[Address(RVA = "0x2CD49B0", Offset = "0x2CD49B0", VA = "0x2CD49B0")]
	public void \u061EܩӾݡ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DA3 RID: 7587 RVA: 0x0009B86C File Offset: 0x00099A6C
	[Token(Token = "0x6001DA3")]
	[Address(RVA = "0x2CD4B04", Offset = "0x2CD4B04", VA = "0x2CD4B04")]
	public void ܫ\u085Eہӝ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		this.\u085F\u0744ࡒ\u074B();
	}

	// Token: 0x06001DA4 RID: 7588 RVA: 0x0009B89C File Offset: 0x00099A9C
	[Token(Token = "0x6001DA4")]
	[Address(RVA = "0x2CD4CF0", Offset = "0x2CD4CF0", VA = "0x2CD4CF0")]
	public void ؽ\u058C\u05A6\u0871(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Right Hand";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.٠\u082Cں\u05F5();
	}

	// Token: 0x06001DA5 RID: 7589 RVA: 0x0009B8D8 File Offset: 0x00099AD8
	[Token(Token = "0x6001DA5")]
	[Address(RVA = "0x2CD4EDC", Offset = "0x2CD4EDC", VA = "0x2CD4EDC")]
	public void ڿ\u07ADݠڧ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "/";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ժݮݜՏ();
	}

	// Token: 0x06001DA6 RID: 7590 RVA: 0x0009B918 File Offset: 0x00099B18
	[Token(Token = "0x6001DA6")]
	[Address(RVA = "0x2CD4F78", Offset = "0x2CD4F78", VA = "0x2CD4F78")]
	public void ࡊ\u0592\u07AB\u05B2()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DA7 RID: 7591 RVA: 0x0009B9CC File Offset: 0x00099BCC
	[Token(Token = "0x6001DA7")]
	[Address(RVA = "0x2CD5044", Offset = "0x2CD5044", VA = "0x2CD5044")]
	public void ݳՂݝ\u07B8(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HandR";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.\u055A\u07ACԁ\u0589();
	}

	// Token: 0x06001DA8 RID: 7592 RVA: 0x0009BA08 File Offset: 0x00099C08
	[Token(Token = "0x6001DA8")]
	[Address(RVA = "0x2CD50E0", Offset = "0x2CD50E0", VA = "0x2CD50E0")]
	public void ԙضփӌ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DA9 RID: 7593 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001DA9")]
	[Address(RVA = "0x2CD51AC", Offset = "0x2CD51AC", VA = "0x2CD51AC")]
	public void Աԛ\u07ADك()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001DAA RID: 7594 RVA: 0x0009BABC File Offset: 0x00099CBC
	[Token(Token = "0x6001DAA")]
	[Address(RVA = "0x2CD5300", Offset = "0x2CD5300", VA = "0x2CD5300")]
	public void Ӝ\u0558ө\u070C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ӨӒࡉٽ();
	}

	// Token: 0x06001DAB RID: 7595 RVA: 0x0009BAFC File Offset: 0x00099CFC
	[Token(Token = "0x6001DAB")]
	[Address(RVA = "0x2CD0528", Offset = "0x2CD0528", VA = "0x2CD0528")]
	public void آսՐ\u06E5()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DAC RID: 7596 RVA: 0x0009BB4C File Offset: 0x00099D4C
	[Token(Token = "0x6001DAC")]
	[Address(RVA = "0x2CD233C", Offset = "0x2CD233C", VA = "0x2CD233C")]
	public void څӭ\u06E0ܒ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DAD RID: 7597 RVA: 0x0009BB98 File Offset: 0x00099D98
	[Token(Token = "0x6001DAD")]
	[Address(RVA = "0x2CD0714", Offset = "0x2CD0714", VA = "0x2CD0714")]
	public void \u07BD\u061E\u061D\u0883()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DAE RID: 7598 RVA: 0x0009BBE8 File Offset: 0x00099DE8
	[Token(Token = "0x6001DAE")]
	[Address(RVA = "0x2CD539C", Offset = "0x2CD539C", VA = "0x2CD539C")]
	public void يօӇ\u070D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ܮԜإޟ();
	}

	// Token: 0x06001DAF RID: 7599 RVA: 0x0009BC28 File Offset: 0x00099E28
	[Token(Token = "0x6001DAF")]
	[Address(RVA = "0x2CD5438", Offset = "0x2CD5438", VA = "0x2CD5438")]
	public void \u06E9\u0740մ\u0746(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Bare Torso";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ڽ\u085Dԓӄ();
	}

	// Token: 0x06001DB0 RID: 7600 RVA: 0x0009BC64 File Offset: 0x00099E64
	[Token(Token = "0x6001DB0")]
	[Address(RVA = "0x2CD54D4", Offset = "0x2CD54D4", VA = "0x2CD54D4")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u05A8\u0876\u07ACࠉ();
	}

	// Token: 0x06001DB1 RID: 7601 RVA: 0x0009BCA4 File Offset: 0x00099EA4
	[Token(Token = "0x6001DB1")]
	[Address(RVA = "0x2CD5570", Offset = "0x2CD5570", VA = "0x2CD5570")]
	public void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "BLUPORT";
		this.ࢥܧܓ\u05C7();
	}

	// Token: 0x06001DB2 RID: 7602 RVA: 0x0009BCD4 File Offset: 0x00099ED4
	[Token(Token = "0x6001DB2")]
	[Address(RVA = "0x2CD5608", Offset = "0x2CD5608", VA = "0x2CD5608")]
	public void ۓڿ\u087Eݓ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.\u061EܩӾݡ();
	}

	// Token: 0x06001DB3 RID: 7603 RVA: 0x0009BD10 File Offset: 0x00099F10
	[Token(Token = "0x6001DB3")]
	[Address(RVA = "0x2CD56A4", Offset = "0x2CD56A4", VA = "0x2CD56A4")]
	public void յߪؾՀ()
	{
		bool ࠈւ_u074Aڡ = this.ࠈւ\u074Aڡ;
		SizeChecker sizeChecker = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
		sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
		SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
		SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DB4 RID: 7604 RVA: 0x0009BDC4 File Offset: 0x00099FC4
	[Token(Token = "0x6001DB4")]
	[Address(RVA = "0x2CD4D8C", Offset = "0x2CD4D8C", VA = "0x2CD4D8C")]
	public void ٠\u082Cں\u05F5()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DB5 RID: 7605 RVA: 0x0009BE14 File Offset: 0x0009A014
	[Token(Token = "0x6001DB5")]
	[Address(RVA = "0x2CD5770", Offset = "0x2CD5770", VA = "0x2CD5770")]
	public void ڦکӁ\u06E2()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DB6 RID: 7606 RVA: 0x0009BEC8 File Offset: 0x0009A0C8
	[Token(Token = "0x6001DB6")]
	[Address(RVA = "0x2CD583C", Offset = "0x2CD583C", VA = "0x2CD583C")]
	public void ԗ\u05F9ҿ\u0834(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "True";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ӨӒࡉٽ();
	}

	// Token: 0x06001DB7 RID: 7607 RVA: 0x0009BF08 File Offset: 0x0009A108
	[Token(Token = "0x6001DB7")]
	[Address(RVA = "0x2CD58D8", Offset = "0x2CD58D8", VA = "0x2CD58D8")]
	public void քӆ٨ڰ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DB8 RID: 7608 RVA: 0x0009BFBC File Offset: 0x0009A1BC
	[Token(Token = "0x6001DB8")]
	[Address(RVA = "0x2CD2528", Offset = "0x2CD2528", VA = "0x2CD2528")]
	public void ڽ\u085Dԓӄ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DB9 RID: 7609 RVA: 0x0009C00C File Offset: 0x0009A20C
	[Token(Token = "0x6001DB9")]
	[Address(RVA = "0x2CD59A4", Offset = "0x2CD59A4", VA = "0x2CD59A4")]
	public void \u0827ߜ\u07FD\u07F4()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DBA RID: 7610 RVA: 0x0009C0C0 File Offset: 0x0009A2C0
	[Token(Token = "0x6001DBA")]
	[Address(RVA = "0x2CD5A6C", Offset = "0x2CD5A6C", VA = "0x2CD5A6C")]
	public void ڗࢭ\u058D\u0733(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Joined a Room.";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ࢥܧܓ\u05C7();
	}

	// Token: 0x06001DBB RID: 7611 RVA: 0x0009C100 File Offset: 0x0009A300
	[Token(Token = "0x6001DBB")]
	[Address(RVA = "0x2CD5B08", Offset = "0x2CD5B08", VA = "0x2CD5B08")]
	public void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.\u085F\u0744ࡒ\u074B();
	}

	// Token: 0x06001DBC RID: 7612 RVA: 0x0009C13C File Offset: 0x0009A33C
	[Token(Token = "0x6001DBC")]
	[Address(RVA = "0x2CD20B0", Offset = "0x2CD20B0", VA = "0x2CD20B0")]
	public void \u0877\u0816\u07B2ص()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DBD RID: 7613 RVA: 0x0009C18C File Offset: 0x0009A38C
	[Token(Token = "0x6001DBD")]
	[Address(RVA = "0x2CD5BA4", Offset = "0x2CD5BA4", VA = "0x2CD5BA4")]
	public void Ӛ\u055D\u0651Խ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayWave";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ބԺ\u0734ۺ();
	}

	// Token: 0x06001DBE RID: 7614 RVA: 0x0009C1C8 File Offset: 0x0009A3C8
	[Token(Token = "0x6001DBE")]
	[Address(RVA = "0x2CD5C40", Offset = "0x2CD5C40", VA = "0x2CD5C40")]
	public void ޑܠԪ\u058F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HorrorAgreement";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.ܞࠉעڂ();
	}

	// Token: 0x06001DBF RID: 7615 RVA: 0x0009C204 File Offset: 0x0009A404
	[Token(Token = "0x6001DBF")]
	[Address(RVA = "0x2CD5CDC", Offset = "0x2CD5CDC", VA = "0x2CD5CDC")]
	public void دٴࡉ\u0816(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FLSPTLT";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u0707ի\u05FFӸ();
	}

	// Token: 0x06001DC0 RID: 7616 RVA: 0x0009C244 File Offset: 0x0009A444
	[Token(Token = "0x6001DC0")]
	[Address(RVA = "0x2CD5D78", Offset = "0x2CD5D78", VA = "0x2CD5D78")]
	public void \u07FF\u05BCޥڡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Skelechin";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.ࡍࢸ\u06E7ࡖ();
	}

	// Token: 0x06001DC1 RID: 7617 RVA: 0x0009C280 File Offset: 0x0009A480
	[Token(Token = "0x6001DC1")]
	[Address(RVA = "0x2CD5E14", Offset = "0x2CD5E14", VA = "0x2CD5E14")]
	public void ւࡂ\u0883\u0872()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DC2 RID: 7618 RVA: 0x0009C334 File Offset: 0x0009A534
	[Token(Token = "0x6001DC2")]
	[Address(RVA = "0x2CD5EE0", Offset = "0x2CD5EE0", VA = "0x2CD5EE0")]
	public void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Muted";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.ݚӇߣߪ();
	}

	// Token: 0x06001DC3 RID: 7619 RVA: 0x0009C370 File Offset: 0x0009A570
	[Token(Token = "0x6001DC3")]
	[Address(RVA = "0x2CD60CC", Offset = "0x2CD60CC", VA = "0x2CD60CC")]
	public void צ\u0874ڵ\u059A()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DC4 RID: 7620 RVA: 0x0009C424 File Offset: 0x0009A624
	[Token(Token = "0x6001DC4")]
	[Address(RVA = "0x2CD6198", Offset = "0x2CD6198", VA = "0x2CD6198")]
	public void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.٠\u082Cں\u05F5();
	}

	// Token: 0x06001DC5 RID: 7621 RVA: 0x0009C464 File Offset: 0x0009A664
	[Token(Token = "0x6001DC5")]
	[Address(RVA = "0x2CD6234", Offset = "0x2CD6234", VA = "0x2CD6234")]
	public void ښمݷ\u0559()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DC6 RID: 7622 RVA: 0x0009C510 File Offset: 0x0009A710
	[Token(Token = "0x6001DC6")]
	[Address(RVA = "0x2CD6300", Offset = "0x2CD6300", VA = "0x2CD6300")]
	public void ވ߄٥ڽ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DC7 RID: 7623 RVA: 0x0009C55C File Offset: 0x0009A75C
	[Token(Token = "0x6001DC7")]
	[Address(RVA = "0x2CD6450", Offset = "0x2CD6450", VA = "0x2CD6450")]
	public void ںآܥ\u06E1()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DC8 RID: 7624 RVA: 0x0009C5A8 File Offset: 0x0009A7A8
	[Token(Token = "0x6001DC8")]
	[Address(RVA = "0x2CD65A4", Offset = "0x2CD65A4", VA = "0x2CD65A4")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_WobbleX";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.\u05C3ԅ\u07AA\u0875();
	}

	// Token: 0x06001DC9 RID: 7625 RVA: 0x0009C5E4 File Offset: 0x0009A7E4
	[Token(Token = "0x6001DC9")]
	[Address(RVA = "0x2CD6640", Offset = "0x2CD6640", VA = "0x2CD6640")]
	public void \u061B\u05EEوۈ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DCA RID: 7626 RVA: 0x0009C698 File Offset: 0x0009A898
	[Token(Token = "0x6001DCA")]
	[Address(RVA = "0x2CD670C", Offset = "0x2CD670C", VA = "0x2CD670C")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "RainAndThunderWeather";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.\u058B\u0896ڢ\u060B();
	}

	// Token: 0x06001DCB RID: 7627 RVA: 0x0009C6D4 File Offset: 0x0009A8D4
	[Token(Token = "0x6001DCB")]
	[Address(RVA = "0x2CD67A8", Offset = "0x2CD67A8", VA = "0x2CD67A8")]
	public void \u0836Չװߟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		this.ӨӒࡉٽ();
	}

	// Token: 0x06001DCC RID: 7628 RVA: 0x0009C704 File Offset: 0x0009A904
	[Token(Token = "0x6001DCC")]
	[Address(RVA = "0x2CD119C", Offset = "0x2CD119C", VA = "0x2CD119C")]
	public void ࡋࢸەࡓ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DCD RID: 7629 RVA: 0x0009C750 File Offset: 0x0009A950
	[Token(Token = "0x6001DCD")]
	[Address(RVA = "0x2CD6840", Offset = "0x2CD6840", VA = "0x2CD6840")]
	public void \u0650ޙߓݘ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.ބԺ\u0734ۺ();
	}

	// Token: 0x06001DCE RID: 7630 RVA: 0x0009C78C File Offset: 0x0009A98C
	[Token(Token = "0x6001DCE")]
	[Address(RVA = "0x2CD27DC", Offset = "0x2CD27DC", VA = "0x2CD27DC")]
	public void \u06E8ւբޛ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DCF RID: 7631 RVA: 0x0009C7DC File Offset: 0x0009A9DC
	[Token(Token = "0x6001DCF")]
	[Address(RVA = "0x2CD68DC", Offset = "0x2CD68DC", VA = "0x2CD68DC")]
	public void \u05EDց\u081Cت()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DD0 RID: 7632 RVA: 0x0009C890 File Offset: 0x0009AA90
	[Token(Token = "0x6001DD0")]
	[Address(RVA = "0x2CD69A4", Offset = "0x2CD69A4", VA = "0x2CD69A4")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ԅاޝܕ();
	}

	// Token: 0x06001DD1 RID: 7633 RVA: 0x0009C8D0 File Offset: 0x0009AAD0
	[Token(Token = "0x6001DD1")]
	[Address(RVA = "0x2CD1834", Offset = "0x2CD1834", VA = "0x2CD1834")]
	public void ԅاޝܕ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (array == null || array != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DD2 RID: 7634 RVA: 0x0009C914 File Offset: 0x0009AB14
	[Token(Token = "0x6001DD2")]
	[Address(RVA = "0x2CD6A40", Offset = "0x2CD6A40", VA = "0x2CD6A40")]
	public void \u0872މࢮՃ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DD3 RID: 7635 RVA: 0x0009C9C8 File Offset: 0x0009ABC8
	[Token(Token = "0x6001DD3")]
	[Address(RVA = "0x2CD6B0C", Offset = "0x2CD6B0C", VA = "0x2CD6B0C")]
	public void \u0870߀ڿߔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ChangeToTagged";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.\u085F\u0744ࡒ\u074B();
	}

	// Token: 0x06001DD4 RID: 7636 RVA: 0x0009CA04 File Offset: 0x0009AC04
	[Token(Token = "0x6001DD4")]
	[Address(RVA = "0x2CD6BA8", Offset = "0x2CD6BA8", VA = "0x2CD6BA8")]
	public void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Joined a Room.";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ժݮݜՏ();
	}

	// Token: 0x06001DD5 RID: 7637 RVA: 0x0009CA40 File Offset: 0x0009AC40
	[Token(Token = "0x6001DD5")]
	[Address(RVA = "0x2CD5F7C", Offset = "0x2CD5F7C", VA = "0x2CD5F7C")]
	public void ݚӇߣߪ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DD6 RID: 7638 RVA: 0x0009CA8C File Offset: 0x0009AC8C
	[Token(Token = "0x6001DD6")]
	[Address(RVA = "0x2CD6C44", Offset = "0x2CD6C44", VA = "0x2CD6C44")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ChangeToTagged";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.ڱࡨىࡊ();
	}

	// Token: 0x06001DD7 RID: 7639 RVA: 0x0009CAC8 File Offset: 0x0009ACC8
	[Token(Token = "0x6001DD7")]
	[Address(RVA = "0x2CD6E30", Offset = "0x2CD6E30", VA = "0x2CD6E30")]
	public void ܟӃ\u059Dࡑ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "A new Player joined a Room.";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u086Dט\u0898ޑ();
	}

	// Token: 0x06001DD8 RID: 7640 RVA: 0x0009CB04 File Offset: 0x0009AD04
	[Token(Token = "0x6001DD8")]
	[Address(RVA = "0x2CD6ECC", Offset = "0x2CD6ECC", VA = "0x2CD6ECC")]
	public void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "CapuchinRemade";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.ԅاޝܕ();
	}

	// Token: 0x06001DD9 RID: 7641 RVA: 0x0009CB44 File Offset: 0x0009AD44
	[Token(Token = "0x6001DD9")]
	[Address(RVA = "0x2CD6F68", Offset = "0x2CD6F68", VA = "0x2CD6F68")]
	public void \u066A\u0603Ӥܔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "";
		this.ڽ\u085Dԓӄ();
	}

	// Token: 0x06001DDA RID: 7642 RVA: 0x0009CB74 File Offset: 0x0009AD74
	[Token(Token = "0x6001DDA")]
	[Address(RVA = "0x2CD7000", Offset = "0x2CD7000", VA = "0x2CD7000")]
	public void ӒԂࡩࡓ()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DDB RID: 7643 RVA: 0x0009CC28 File Offset: 0x0009AE28
	[Token(Token = "0x6001DDB")]
	[Address(RVA = "0x2CD4B9C", Offset = "0x2CD4B9C", VA = "0x2CD4B9C")]
	public void \u085F\u0744ࡒ\u074B()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DDC RID: 7644 RVA: 0x0009CC74 File Offset: 0x0009AE74
	[Token(Token = "0x6001DDC")]
	[Address(RVA = "0x2CD70CC", Offset = "0x2CD70CC", VA = "0x2CD70CC")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "RainAndThunderWeather";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u055A\u07ACԁ\u0589();
	}

	// Token: 0x06001DDD RID: 7645 RVA: 0x0009CCB0 File Offset: 0x0009AEB0
	[Token(Token = "0x6001DDD")]
	[Address(RVA = "0x2CD7168", Offset = "0x2CD7168", VA = "0x2CD7168")]
	public void Update()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
	}

	// Token: 0x06001DDE RID: 7646 RVA: 0x0009CD50 File Offset: 0x0009AF50
	[Token(Token = "0x6001DDE")]
	[Address(RVA = "0x2CD720C", Offset = "0x2CD720C", VA = "0x2CD720C")]
	public void ڷ\u0826ӹڥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		this.ࠈւ\u074Aڡ = (257 != 0);
		this.߈\u07BFӣٱ();
	}

	// Token: 0x06001DDF RID: 7647 RVA: 0x0009CD8C File Offset: 0x0009AF8C
	[Token(Token = "0x6001DDF")]
	[Address(RVA = "0x2CD72A8", Offset = "0x2CD72A8", VA = "0x2CD72A8")]
	public void \u0879\u0748ߙݥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Tagged";
		long ࠈւ_u074Aڡ = 256L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u05A8\u0876\u07ACࠉ();
	}

	// Token: 0x06001DE0 RID: 7648 RVA: 0x0009CDCC File Offset: 0x0009AFCC
	[Token(Token = "0x6001DE0")]
	[Address(RVA = "0x2CD6CE0", Offset = "0x2CD6CE0", VA = "0x2CD6CE0")]
	public void ڱࡨىࡊ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DE1 RID: 7649 RVA: 0x0009CE18 File Offset: 0x0009B018
	[Token(Token = "0x6001DE1")]
	[Address(RVA = "0x2CD7344", Offset = "0x2CD7344", VA = "0x2CD7344")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "_Tint";
		long ࠈւ_u074Aڡ = 1L;
		this.ࠈւ\u074Aڡ = (ࠈւ_u074Aڡ != 0L);
		this.\u058B\u0896ڢ\u060B();
	}

	// Token: 0x06001DE2 RID: 7650 RVA: 0x0009CE4C File Offset: 0x0009B04C
	[Token(Token = "0x6001DE2")]
	[Address(RVA = "0x2CD73E0", Offset = "0x2CD73E0", VA = "0x2CD73E0")]
	public void \u055Cࢯܯ\u0898()
	{
		if (this.ࠈւ\u074Aڡ)
		{
			SizeChecker sizeChecker = this.ࢭӶڵޒ;
			float u05B9ߎܩ_u = this.\u05B9ߎܩ\u0613;
			sizeChecker.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u;
			SizeChecker u07F3ݲ_u05A6_u = this.\u07F3ݲ\u05A6\u0611;
			float u05B9ߎܩ_u2 = this.\u05B9ߎܩ\u0613;
			u07F3ݲ_u05A6_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u2;
			SizeChecker u058AӒՓ_u = this.\u058AӒՓ\u0874;
			float u05B9ߎܩ_u3 = this.\u05B9ߎܩ\u0613;
			u058AӒՓ_u.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u3;
		}
		bool ܤ_u06FDܜ٤ = this.ܤ\u06FDܜ٤;
		SizeChecker sizeChecker2 = this.ࢭӶڵޒ;
		float u05B9ߎܩ_u4 = this.\u05B9ߎܩ\u0613;
		sizeChecker2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u4;
		SizeChecker u07F3ݲ_u05A6_u2 = this.\u07F3ݲ\u05A6\u0611;
		float u05B9ߎܩ_u5 = this.\u05B9ߎܩ\u0613;
		u07F3ݲ_u05A6_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u5;
		SizeChecker u058AӒՓ_u2 = this.\u058AӒՓ\u0874;
		float u05B9ߎܩ_u6 = this.\u05B9ߎܩ\u0613;
		u058AӒՓ_u2.\u0619\u0749ݗ\u0650 = u05B9ߎܩ_u6;
	}

	// Token: 0x06001DE3 RID: 7651 RVA: 0x0009CF00 File Offset: 0x0009B100
	[Token(Token = "0x6001DE3")]
	[Address(RVA = "0x2CD3854", Offset = "0x2CD3854", VA = "0x2CD3854")]
	public void ܮԜإޟ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[0];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001DE4 RID: 7652 RVA: 0x0009CF50 File Offset: 0x0009B150
	[Token(Token = "0x6001DE4")]
	[Address(RVA = "0x2CD0D94", Offset = "0x2CD0D94", VA = "0x2CD0D94")]
	public void \u05A8\u0876\u07ACࠉ()
	{
		PhotonView component = this.ݺ\u05F9פݵ.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
		this.\u07AE\u05AF\u064FԖ = component;
		object[] array = new object[1];
		if (typeof(float).TypeHandle == null || typeof(float).TypeHandle != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x040003EC RID: 1004
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003EC")]
	public SizeChecker ࢭӶڵޒ;

	// Token: 0x040003ED RID: 1005
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003ED")]
	public SizeChecker \u07F3ݲ\u05A6\u0611;

	// Token: 0x040003EE RID: 1006
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003EE")]
	public SizeChecker \u058AӒՓ\u0874;

	// Token: 0x040003EF RID: 1007
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40003EF")]
	public bool ࠈւ\u074Aڡ;

	// Token: 0x040003F0 RID: 1008
	[FieldOffset(Offset = "0x39")]
	[Token(Token = "0x40003F0")]
	public bool ܤ\u06FDܜ٤;

	// Token: 0x040003F1 RID: 1009
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x40003F1")]
	public float \u05B9ߎܩ\u0613;

	// Token: 0x040003F2 RID: 1010
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40003F2")]
	public NetworkPlayerSpawner ݺ\u05F9פݵ;

	// Token: 0x040003F3 RID: 1011
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40003F3")]
	private PhotonView \u07AE\u05AF\u064FԖ;
}
