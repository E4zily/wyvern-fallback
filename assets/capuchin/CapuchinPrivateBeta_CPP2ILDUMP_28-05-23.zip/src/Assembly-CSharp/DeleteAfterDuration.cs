﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000027 RID: 39
[Token(Token = "0x2000027")]
public class DeleteAfterDuration : MonoBehaviour
{
	// Token: 0x06000462 RID: 1122 RVA: 0x00019870 File Offset: 0x00017A70
	[Token(Token = "0x6000462")]
	[Address(RVA = "0x289CF78", Offset = "0x289CF78", VA = "0x289CF78")]
	public void הԥ\u05B5ݴ()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000463 RID: 1123 RVA: 0x00019894 File Offset: 0x00017A94
	[Token(Token = "0x6000463")]
	[Address(RVA = "0x289CFF0", Offset = "0x289CFF0", VA = "0x289CFF0")]
	public void ߖհݣ߀()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000464 RID: 1124 RVA: 0x000198B8 File Offset: 0x00017AB8
	[Token(Token = "0x6000464")]
	[Address(RVA = "0x289D068", Offset = "0x289D068", VA = "0x289D068")]
	public void Start()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000465 RID: 1125 RVA: 0x000198DC File Offset: 0x00017ADC
	[Token(Token = "0x6000465")]
	[Address(RVA = "0x289D0E0", Offset = "0x289D0E0", VA = "0x289D0E0")]
	public void Ԯ\u0883\u0591\u066C()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000466 RID: 1126 RVA: 0x00019900 File Offset: 0x00017B00
	[Token(Token = "0x6000466")]
	[Address(RVA = "0x289D158", Offset = "0x289D158", VA = "0x289D158")]
	public void \u065F\u0839ܤ\u073C()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000467 RID: 1127 RVA: 0x00019924 File Offset: 0x00017B24
	[Token(Token = "0x6000467")]
	[Address(RVA = "0x289D1D0", Offset = "0x289D1D0", VA = "0x289D1D0")]
	public DeleteAfterDuration()
	{
	}

	// Token: 0x06000468 RID: 1128 RVA: 0x00019938 File Offset: 0x00017B38
	[Token(Token = "0x6000468")]
	[Address(RVA = "0x289D1D8", Offset = "0x289D1D8", VA = "0x289D1D8")]
	public void \u086Bԍࡊڭ()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x06000469 RID: 1129 RVA: 0x0001995C File Offset: 0x00017B5C
	[Token(Token = "0x6000469")]
	[Address(RVA = "0x289D250", Offset = "0x289D250", VA = "0x289D250")]
	public void \u05ABݿࡋ\u06E9()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600046A RID: 1130 RVA: 0x00019980 File Offset: 0x00017B80
	[Token(Token = "0x600046A")]
	[Address(RVA = "0x289D2C8", Offset = "0x289D2C8", VA = "0x289D2C8")]
	public void ࡅݐ\u082Dք()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600046B RID: 1131 RVA: 0x000199A4 File Offset: 0x00017BA4
	[Token(Token = "0x600046B")]
	[Address(RVA = "0x289D340", Offset = "0x289D340", VA = "0x289D340")]
	public void \u066D\u05BDې߃()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600046C RID: 1132 RVA: 0x000199C8 File Offset: 0x00017BC8
	[Token(Token = "0x600046C")]
	[Address(RVA = "0x289D3B8", Offset = "0x289D3B8", VA = "0x289D3B8")]
	public void ۮߝڪڐ()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600046D RID: 1133 RVA: 0x000199EC File Offset: 0x00017BEC
	[Token(Token = "0x600046D")]
	[Address(RVA = "0x289D430", Offset = "0x289D430", VA = "0x289D430")]
	public void וࡪךӧ()
	{
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
	}

	// Token: 0x0600046E RID: 1134 RVA: 0x00019A10 File Offset: 0x00017C10
	[Token(Token = "0x600046E")]
	[Address(RVA = "0x289D4A8", Offset = "0x289D4A8", VA = "0x289D4A8")]
	public void ࢧӾڈց()
	{
		long num = 1L;
		GameObject ӱӤ_u073Aސ = this.ӱӤ\u073Aސ;
		float ࡑ۳_u0596_u066C = this.ࡑ۳\u0596\u066C;
		if (num == 0L)
		{
		}
	}

	// Token: 0x040000BB RID: 187
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000BB")]
	public GameObject ӱӤ\u073Aސ;

	// Token: 0x040000BC RID: 188
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000BC")]
	public float ࡑ۳\u0596\u066C;
}
