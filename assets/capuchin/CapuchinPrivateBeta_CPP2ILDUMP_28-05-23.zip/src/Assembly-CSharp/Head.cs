﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000BE RID: 190
[Token(Token = "0x20000BE")]
public class Head : MonoBehaviour
{
	// Token: 0x06001C37 RID: 7223 RVA: 0x00092814 File Offset: 0x00090A14
	[Token(Token = "0x6001C37")]
	[Address(RVA = "0x27533EC", Offset = "0x27533EC", VA = "0x27533EC")]
	private void Update()
	{
		Transform transform = base.transform;
		Vector3 position = this.Ԏڽڲݳ.position;
		Vector3 position2 = this.Ԏڽڲݳ.position;
		Transform ԏڽڲݳ = this.Ԏڽڲݳ;
		float ދ_u08B5ڄࠄ = this.ދ\u08B5ڄࠄ;
		Vector3 position3 = ԏڽڲݳ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.Ԏڽڲݳ.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001C38 RID: 7224 RVA: 0x0009288C File Offset: 0x00090A8C
	[Token(Token = "0x6001C38")]
	[Address(RVA = "0x2753514", Offset = "0x2753514", VA = "0x2753514")]
	private void \u061B\u05EEوۈ()
	{
		Transform transform = base.transform;
		Vector3 position = this.Ԏڽڲݳ.position;
		Vector3 position2 = this.Ԏڽڲݳ.position;
		Transform ԏڽڲݳ = this.Ԏڽڲݳ;
		float ދ_u08B5ڄࠄ = this.ދ\u08B5ڄࠄ;
		Vector3 position3 = ԏڽڲݳ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.Ԏڽڲݳ.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001C39 RID: 7225 RVA: 0x00092904 File Offset: 0x00090B04
	[Token(Token = "0x6001C39")]
	[Address(RVA = "0x2753640", Offset = "0x2753640", VA = "0x2753640")]
	private void Ӣ\u0592ߨׯ()
	{
		Transform transform = base.transform;
		Vector3 position = this.Ԏڽڲݳ.position;
		Vector3 position2 = this.Ԏڽڲݳ.position;
		Transform ԏڽڲݳ = this.Ԏڽڲݳ;
		float ދ_u08B5ڄࠄ = this.ދ\u08B5ڄࠄ;
		Vector3 position3 = ԏڽڲݳ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.Ԏڽڲݳ.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001C3A RID: 7226 RVA: 0x0009297C File Offset: 0x00090B7C
	[Token(Token = "0x6001C3A")]
	[Address(RVA = "0x275376C", Offset = "0x275376C", VA = "0x275376C")]
	private void \u0558ݕݤݮ()
	{
	}

	// Token: 0x06001C3B RID: 7227 RVA: 0x0009298C File Offset: 0x00090B8C
	[Token(Token = "0x6001C3B")]
	[Address(RVA = "0x2753770", Offset = "0x2753770", VA = "0x2753770")]
	private void ࢰחڵࡓ()
	{
	}

	// Token: 0x06001C3C RID: 7228 RVA: 0x0009299C File Offset: 0x00090B9C
	[Token(Token = "0x6001C3C")]
	[Address(RVA = "0x2753774", Offset = "0x2753774", VA = "0x2753774")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		Transform transform = base.transform;
		Vector3 position = this.Ԏڽڲݳ.position;
		Vector3 position2 = this.Ԏڽڲݳ.position;
		Transform ԏڽڲݳ = this.Ԏڽڲݳ;
		float ދ_u08B5ڄࠄ = this.ދ\u08B5ڄࠄ;
		Vector3 position3 = ԏڽڲݳ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.Ԏڽڲݳ.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001C3D RID: 7229 RVA: 0x00092A14 File Offset: 0x00090C14
	[Token(Token = "0x6001C3D")]
	[Address(RVA = "0x27538A0", Offset = "0x27538A0", VA = "0x27538A0")]
	private void ڑߒجވ()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.Ԏڽڲݳ.position;
		Transform ԏڽڲݳ = this.Ԏڽڲݳ;
		float ދ_u08B5ڄࠄ = this.ދ\u08B5ڄࠄ;
		Vector3 position3 = ԏڽڲݳ.position;
		Transform transform = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.Ԏڽڲݳ.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001C3E RID: 7230 RVA: 0x00092A84 File Offset: 0x00090C84
	[Token(Token = "0x6001C3E")]
	[Address(RVA = "0x27539CC", Offset = "0x27539CC", VA = "0x27539CC")]
	public Head()
	{
	}

	// Token: 0x06001C3F RID: 7231 RVA: 0x00092A98 File Offset: 0x00090C98
	[Token(Token = "0x6001C3F")]
	[Address(RVA = "0x27539D4", Offset = "0x27539D4", VA = "0x27539D4")]
	private void ޡࠅ\u089Aߔ()
	{
	}

	// Token: 0x06001C40 RID: 7232 RVA: 0x00092AA8 File Offset: 0x00090CA8
	[Token(Token = "0x6001C40")]
	[Address(RVA = "0x27539D8", Offset = "0x27539D8", VA = "0x27539D8")]
	private void וࡪךӧ()
	{
	}

	// Token: 0x06001C41 RID: 7233 RVA: 0x00092AB8 File Offset: 0x00090CB8
	[Token(Token = "0x6001C41")]
	[Address(RVA = "0x27539DC", Offset = "0x27539DC", VA = "0x27539DC")]
	private void \u065F\u0839ܤ\u073C()
	{
	}

	// Token: 0x06001C42 RID: 7234 RVA: 0x00092AC8 File Offset: 0x00090CC8
	[Token(Token = "0x6001C42")]
	[Address(RVA = "0x27539E0", Offset = "0x27539E0", VA = "0x27539E0")]
	private void څࡣڐ\u0657()
	{
		Transform transform = base.transform;
		Vector3 position = this.Ԏڽڲݳ.position;
		Vector3 position2 = this.Ԏڽڲݳ.position;
		Transform ԏڽڲݳ = this.Ԏڽڲݳ;
		float ދ_u08B5ڄࠄ = this.ދ\u08B5ڄࠄ;
		Vector3 position3 = ԏڽڲݳ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.Ԏڽڲݳ.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001C43 RID: 7235 RVA: 0x00092B40 File Offset: 0x00090D40
	[Token(Token = "0x6001C43")]
	[Address(RVA = "0x2753B0C", Offset = "0x2753B0C", VA = "0x2753B0C")]
	private void Ԯ\u0883\u0591\u066C()
	{
	}

	// Token: 0x06001C44 RID: 7236 RVA: 0x00092B50 File Offset: 0x00090D50
	[Token(Token = "0x6001C44")]
	[Address(RVA = "0x2753B10", Offset = "0x2753B10", VA = "0x2753B10")]
	private void Start()
	{
	}

	// Token: 0x06001C45 RID: 7237 RVA: 0x00092B60 File Offset: 0x00090D60
	[Token(Token = "0x6001C45")]
	[Address(RVA = "0x2753B14", Offset = "0x2753B14", VA = "0x2753B14")]
	private void ۮߝڪڐ()
	{
	}

	// Token: 0x06001C46 RID: 7238 RVA: 0x00092B70 File Offset: 0x00090D70
	[Token(Token = "0x6001C46")]
	[Address(RVA = "0x2753B18", Offset = "0x2753B18", VA = "0x2753B18")]
	private void ߒ\u065EՎࡖ()
	{
	}

	// Token: 0x06001C47 RID: 7239 RVA: 0x00092B80 File Offset: 0x00090D80
	[Token(Token = "0x6001C47")]
	[Address(RVA = "0x2753B1C", Offset = "0x2753B1C", VA = "0x2753B1C")]
	private void ࡅݐ\u082Dք()
	{
	}

	// Token: 0x06001C48 RID: 7240 RVA: 0x00092B90 File Offset: 0x00090D90
	[Token(Token = "0x6001C48")]
	[Address(RVA = "0x2753B20", Offset = "0x2753B20", VA = "0x2753B20")]
	private void \u05ABݿࡋ\u06E9()
	{
	}

	// Token: 0x06001C49 RID: 7241 RVA: 0x00092BA0 File Offset: 0x00090DA0
	[Token(Token = "0x6001C49")]
	[Address(RVA = "0x2753B24", Offset = "0x2753B24", VA = "0x2753B24")]
	private void \u05F7ԝߠӱ()
	{
		Transform transform = base.transform;
		Vector3 position = this.Ԏڽڲݳ.position;
		Vector3 position2 = this.Ԏڽڲݳ.position;
		Transform ԏڽڲݳ = this.Ԏڽڲݳ;
		float ދ_u08B5ڄࠄ = this.ދ\u08B5ڄࠄ;
		Vector3 position3 = ԏڽڲݳ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.Ԏڽڲݳ.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x040003A7 RID: 935
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003A7")]
	public Transform Ԏڽڲݳ;

	// Token: 0x040003A8 RID: 936
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003A8")]
	public float ދ\u08B5ڄࠄ;
}
