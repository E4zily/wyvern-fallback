﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200007D RID: 125
[Token(Token = "0x200007D")]
[ExecuteInEditMode]
public class MB_MigrateMaterialsToDifferentPipeline : MonoBehaviour
{
	// Token: 0x06001300 RID: 4864 RVA: 0x0006B998 File Offset: 0x00069B98
	[Token(Token = "0x6001300")]
	[Address(RVA = "0x2C5B364", Offset = "0x2C5B364", VA = "0x2C5B364")]
	public MB_MigrateMaterialsToDifferentPipeline()
	{
	}
}
