﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000071 RID: 113
[Token(Token = "0x2000071")]
public class Level1MapSystem : MonoBehaviour
{
	// Token: 0x060010C0 RID: 4288 RVA: 0x00062C3C File Offset: 0x00060E3C
	[Token(Token = "0x60010C0")]
	[Address(RVA = "0x2CD74AC", Offset = "0x2CD74AC", VA = "0x2CD74AC")]
	public void ؽܗӊә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("hh:mmtt");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010C1 RID: 4289 RVA: 0x00062C74 File Offset: 0x00060E74
	[Token(Token = "0x60010C1")]
	[Address(RVA = "0x2CD7544", Offset = "0x2CD7544", VA = "0x2CD7544")]
	public void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ORGTARG");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010C2 RID: 4290 RVA: 0x00062CAC File Offset: 0x00060EAC
	[Token(Token = "0x60010C2")]
	[Address(RVA = "0x2CD75DC", Offset = "0x2CD75DC", VA = "0x2CD75DC")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Push To Talk");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010C3 RID: 4291 RVA: 0x00062CE4 File Offset: 0x00060EE4
	[Token(Token = "0x60010C3")]
	[Address(RVA = "0x2CD7674", Offset = "0x2CD7674", VA = "0x2CD7674")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PRESS AGAIN TO CONFIRM");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010C4 RID: 4292 RVA: 0x00062D1C File Offset: 0x00060F1C
	[Token(Token = "0x60010C4")]
	[Address(RVA = "0x2CD770C", Offset = "0x2CD770C", VA = "0x2CD770C")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Stopped Colliding");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010C5 RID: 4293 RVA: 0x00062D54 File Offset: 0x00060F54
	[Token(Token = "0x60010C5")]
	[Address(RVA = "0x2CD77A4", Offset = "0x2CD77A4", VA = "0x2CD77A4")]
	public void ت\u05F9ޅ\u059A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("jump char false");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010C6 RID: 4294 RVA: 0x00062D8C File Offset: 0x00060F8C
	[Token(Token = "0x60010C6")]
	[Address(RVA = "0x2CD783C", Offset = "0x2CD783C", VA = "0x2CD783C")]
	public void \u05A0ڵ\u0823ڈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ErrorScreen");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010C7 RID: 4295 RVA: 0x00062DC4 File Offset: 0x00060FC4
	[Token(Token = "0x60010C7")]
	[Address(RVA = "0x2CD78D4", Offset = "0x2CD78D4", VA = "0x2CD78D4")]
	public void \u0872יԁӦ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Players In Room: ");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010C8 RID: 4296 RVA: 0x00062DFC File Offset: 0x00060FFC
	[Token(Token = "0x60010C8")]
	[Address(RVA = "0x2CD796C", Offset = "0x2CD796C", VA = "0x2CD796C")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010C9 RID: 4297 RVA: 0x00062E34 File Offset: 0x00061034
	[Token(Token = "0x60010C9")]
	[Address(RVA = "0x2CD7A04", Offset = "0x2CD7A04", VA = "0x2CD7A04")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PURCHASED");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010CA RID: 4298 RVA: 0x00062E6C File Offset: 0x0006106C
	[Token(Token = "0x60010CA")]
	[Address(RVA = "0x2CD7A9C", Offset = "0x2CD7A9C", VA = "0x2CD7A9C")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("DISABLE");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010CB RID: 4299 RVA: 0x00062EA4 File Offset: 0x000610A4
	[Token(Token = "0x60010CB")]
	[Address(RVA = "0x2CD7B34", Offset = "0x2CD7B34", VA = "0x2CD7B34")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FLSPTLT");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010CC RID: 4300 RVA: 0x00062EDC File Offset: 0x000610DC
	[Token(Token = "0x60010CC")]
	[Address(RVA = "0x2CD7BCC", Offset = "0x2CD7BCC", VA = "0x2CD7BCC")]
	public Level1MapSystem()
	{
	}

	// Token: 0x060010CD RID: 4301 RVA: 0x00062EF0 File Offset: 0x000610F0
	[Token(Token = "0x60010CD")]
	[Address(RVA = "0x2CD7BD4", Offset = "0x2CD7BD4", VA = "0x2CD7BD4")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010CE RID: 4302 RVA: 0x00062F28 File Offset: 0x00061128
	[Token(Token = "0x60010CE")]
	[Address(RVA = "0x2CD7C6C", Offset = "0x2CD7C6C", VA = "0x2CD7C6C")]
	public void \u0836Չװߟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Adding ");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010CF RID: 4303 RVA: 0x00062F60 File Offset: 0x00061160
	[Token(Token = "0x60010CF")]
	[Address(RVA = "0x2CD7D04", Offset = "0x2CD7D04", VA = "0x2CD7D04")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010D0 RID: 4304 RVA: 0x00062F98 File Offset: 0x00061198
	[Token(Token = "0x60010D0")]
	[Address(RVA = "0x2CD7D9C", Offset = "0x2CD7D9C", VA = "0x2CD7D9C")]
	public void \u086D\u089AԾ\u0881(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("hand 1");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010D1 RID: 4305 RVA: 0x00062FD0 File Offset: 0x000611D0
	[Token(Token = "0x60010D1")]
	[Address(RVA = "0x2CD7E34", Offset = "0x2CD7E34", VA = "0x2CD7E34")]
	public void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010D2 RID: 4306 RVA: 0x00063008 File Offset: 0x00061208
	[Token(Token = "0x60010D2")]
	[Address(RVA = "0x2CD7ECC", Offset = "0x2CD7ECC", VA = "0x2CD7ECC")]
	public void \u085Cݯژ\u05FA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010D3 RID: 4307 RVA: 0x00063040 File Offset: 0x00061240
	[Token(Token = "0x60010D3")]
	[Address(RVA = "0x2CD7F64", Offset = "0x2CD7F64", VA = "0x2CD7F64")]
	public void ލ\u0892\u064B\u055B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayerDeath");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010D4 RID: 4308 RVA: 0x00063078 File Offset: 0x00061278
	[Token(Token = "0x60010D4")]
	[Address(RVA = "0x2CD7FFC", Offset = "0x2CD7FFC", VA = "0x2CD7FFC")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("amongus");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010D5 RID: 4309 RVA: 0x000630B0 File Offset: 0x000612B0
	[Token(Token = "0x60010D5")]
	[Address(RVA = "0x2CD8094", Offset = "0x2CD8094", VA = "0x2CD8094")]
	public void ىރ\u0704ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("sound play play");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010D6 RID: 4310 RVA: 0x000630E8 File Offset: 0x000612E8
	[Token(Token = "0x60010D6")]
	[Address(RVA = "0x2CD812C", Offset = "0x2CD812C", VA = "0x2CD812C")]
	public void پ\u05F7\u06E6ރ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("All audio clips have been played.");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010D7 RID: 4311 RVA: 0x00063120 File Offset: 0x00061320
	[Token(Token = "0x60010D7")]
	[Address(RVA = "0x2CD81C4", Offset = "0x2CD81C4", VA = "0x2CD81C4")]
	public void ߃\u0602\u0891߇(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Error");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010D8 RID: 4312 RVA: 0x00063158 File Offset: 0x00061358
	[Token(Token = "0x60010D8")]
	[Address(RVA = "0x2CD825C", Offset = "0x2CD825C", VA = "0x2CD825C")]
	public void \u0872\u0610ۅ\u06E1(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("A Player has left the Room.");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010D9 RID: 4313 RVA: 0x00063190 File Offset: 0x00061390
	[Token(Token = "0x60010D9")]
	[Address(RVA = "0x2CD82F4", Offset = "0x2CD82F4", VA = "0x2CD82F4")]
	public void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("sound play stopped");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010DA RID: 4314 RVA: 0x000631C8 File Offset: 0x000613C8
	[Token(Token = "0x60010DA")]
	[Address(RVA = "0x2CD838C", Offset = "0x2CD838C", VA = "0x2CD838C")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("CapuchinRemade");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010DB RID: 4315 RVA: 0x00063200 File Offset: 0x00061400
	[Token(Token = "0x60010DB")]
	[Address(RVA = "0x2CD8424", Offset = "0x2CD8424", VA = "0x2CD8424")]
	public void ٽ߆ࡑՄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Update User Inventory");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010DC RID: 4316 RVA: 0x00063238 File Offset: 0x00061438
	[Token(Token = "0x60010DC")]
	[Address(RVA = "0x2CD84BC", Offset = "0x2CD84BC", VA = "0x2CD84BC")]
	public void ߂ڞ\u0600\u07FB(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("StartGamemode");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010DD RID: 4317 RVA: 0x00063270 File Offset: 0x00061470
	[Token(Token = "0x60010DD")]
	[Address(RVA = "0x2CD8554", Offset = "0x2CD8554", VA = "0x2CD8554")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("/");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010DE RID: 4318 RVA: 0x000632A8 File Offset: 0x000614A8
	[Token(Token = "0x60010DE")]
	[Address(RVA = "0x2CD85EC", Offset = "0x2CD85EC", VA = "0x2CD85EC")]
	public void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Game Started");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010DF RID: 4319 RVA: 0x000632E0 File Offset: 0x000614E0
	[Token(Token = "0x60010DF")]
	[Address(RVA = "0x2CD8684", Offset = "0x2CD8684", VA = "0x2CD8684")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Reason: ");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010E0 RID: 4320 RVA: 0x00063318 File Offset: 0x00061518
	[Token(Token = "0x60010E0")]
	[Address(RVA = "0x2CD871C", Offset = "0x2CD871C", VA = "0x2CD871C")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010E1 RID: 4321 RVA: 0x00063350 File Offset: 0x00061550
	[Token(Token = "0x60010E1")]
	[Address(RVA = "0x2CD87B4", Offset = "0x2CD87B4", VA = "0x2CD87B4")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("waited for your bullshit unity grrr");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010E2 RID: 4322 RVA: 0x00063388 File Offset: 0x00061588
	[Token(Token = "0x60010E2")]
	[Address(RVA = "0x2CD884C", Offset = "0x2CD884C", VA = "0x2CD884C")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("run");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010E3 RID: 4323 RVA: 0x000633C0 File Offset: 0x000615C0
	[Token(Token = "0x60010E3")]
	[Address(RVA = "0x2CD88E4", Offset = "0x2CD88E4", VA = "0x2CD88E4")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Players Online: ");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010E4 RID: 4324 RVA: 0x000633F8 File Offset: 0x000615F8
	[Token(Token = "0x60010E4")]
	[Address(RVA = "0x2CD897C", Offset = "0x2CD897C", VA = "0x2CD897C")]
	public void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010E5 RID: 4325 RVA: 0x00063430 File Offset: 0x00061630
	[Token(Token = "0x60010E5")]
	[Address(RVA = "0x2CD8A14", Offset = "0x2CD8A14", VA = "0x2CD8A14")]
	public void ܮݫ߅ࡃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("False");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010E6 RID: 4326 RVA: 0x00063468 File Offset: 0x00061668
	[Token(Token = "0x60010E6")]
	[Address(RVA = "0x2CD8AAC", Offset = "0x2CD8AAC", VA = "0x2CD8AAC")]
	public void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("This is the 2500 Bananas button, and it was just clicked");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010E7 RID: 4327 RVA: 0x000634A0 File Offset: 0x000616A0
	[Token(Token = "0x60010E7")]
	[Address(RVA = "0x2CD8B44", Offset = "0x2CD8B44", VA = "0x2CD8B44")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010E8 RID: 4328 RVA: 0x000634D8 File Offset: 0x000616D8
	[Token(Token = "0x60010E8")]
	[Address(RVA = "0x2CD8BDC", Offset = "0x2CD8BDC", VA = "0x2CD8BDC")]
	public void ԁؼՖռ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayWave");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010E9 RID: 4329 RVA: 0x00063510 File Offset: 0x00061710
	[Token(Token = "0x60010E9")]
	[Address(RVA = "0x2CD8C74", Offset = "0x2CD8C74", VA = "0x2CD8C74")]
	public void \u0609ۯ\u05B4ؼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Joined a Room.");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010EA RID: 4330 RVA: 0x00063548 File Offset: 0x00061748
	[Token(Token = "0x60010EA")]
	[Address(RVA = "0x2CD8D0C", Offset = "0x2CD8D0C", VA = "0x2CD8D0C")]
	public void ڎՅڤࠊ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Agreed");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010EB RID: 4331 RVA: 0x00063580 File Offset: 0x00061780
	[Token(Token = "0x60010EB")]
	[Address(RVA = "0x2CD8DA4", Offset = "0x2CD8DA4", VA = "0x2CD8DA4")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("containsStaff");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010EC RID: 4332 RVA: 0x000635B8 File Offset: 0x000617B8
	[Token(Token = "0x60010EC")]
	[Address(RVA = "0x2CD8E3C", Offset = "0x2CD8E3C", VA = "0x2CD8E3C")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("true");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010ED RID: 4333 RVA: 0x000635F0 File Offset: 0x000617F0
	[Token(Token = "0x60010ED")]
	[Address(RVA = "0x2CD8ED4", Offset = "0x2CD8ED4", VA = "0x2CD8ED4")]
	public void \u06E9\u0740մ\u0746(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayerDeath");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010EE RID: 4334 RVA: 0x00063628 File Offset: 0x00061828
	[Token(Token = "0x60010EE")]
	[Address(RVA = "0x2CD8F6C", Offset = "0x2CD8F6C", VA = "0x2CD8F6C")]
	public void ࢳ\u06FDԷ\u058E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Muted");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010EF RID: 4335 RVA: 0x00063660 File Offset: 0x00061860
	[Token(Token = "0x60010EF")]
	[Address(RVA = "0x2CD9004", Offset = "0x2CD9004", VA = "0x2CD9004")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010F0 RID: 4336 RVA: 0x00063698 File Offset: 0x00061898
	[Token(Token = "0x60010F0")]
	[Address(RVA = "0x2CD909C", Offset = "0x2CD909C", VA = "0x2CD909C")]
	public void Ԍߊٱݩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("False");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 0L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x060010F1 RID: 4337 RVA: 0x000636D0 File Offset: 0x000618D0
	[Token(Token = "0x60010F1")]
	[Address(RVA = "0x2CD9134", Offset = "0x2CD9134", VA = "0x2CD9134")]
	public void \u0885ےܝ\u05BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
		GameObject u06E6ޝݥӻ = this.\u06E6ޝݥӻ;
		long active = 1L;
		u06E6ޝݥӻ.SetActive(active != 0L);
	}

	// Token: 0x0400023F RID: 575
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400023F")]
	public GameObject \u06E6ޝݥӻ;
}
