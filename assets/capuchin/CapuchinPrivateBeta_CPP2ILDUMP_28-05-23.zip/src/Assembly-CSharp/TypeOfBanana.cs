﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E0 RID: 224
[Token(Token = "0x20000E0")]
public class TypeOfBanana : MonoBehaviour
{
	// Token: 0x060022C5 RID: 8901 RVA: 0x000B799C File Offset: 0x000B5B9C
	[Token(Token = "0x60022C5")]
	[Address(RVA = "0x2C77A04", Offset = "0x2C77A04", VA = "0x2C77A04")]
	public TypeOfBanana()
	{
	}

	// Token: 0x0400046C RID: 1132
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400046C")]
	public bool Ծࢷ\u0608\u05FD;

	// Token: 0x0400046D RID: 1133
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x400046D")]
	public bool \u05F7ܛ\u0820դ;

	// Token: 0x0400046E RID: 1134
	[FieldOffset(Offset = "0x1A")]
	[Token(Token = "0x400046E")]
	public bool ثآࢯԽ;
}
