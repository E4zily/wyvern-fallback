﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x02000094 RID: 148
[Token(Token = "0x2000094")]
public class AddBananasToCart : MonoBehaviour
{
	// Token: 0x06001668 RID: 5736 RVA: 0x0007D7C8 File Offset: 0x0007B9C8
	[Token(Token = "0x6001668")]
	[Address(RVA = "0x2A44614", Offset = "0x2A44614", VA = "0x2A44614")]
	public AddBananasToCart()
	{
	}

	// Token: 0x06001669 RID: 5737 RVA: 0x0007D7DC File Offset: 0x0007B9DC
	[Token(Token = "0x6001669")]
	[Address(RVA = "0x2A4461C", Offset = "0x2A4461C", VA = "0x2A4461C")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		AddBananasToCart.ض\u058F\u081Aӯ ࡅ_u0706_u07F3ࡘ = this.ࡅ\u0706\u07F3ࡘ;
		if (ࡅ_u0706_u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (ࡅ_u0706_u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
			{
			}
			Debug.Log("This is the 1000 Bananas button, and it was just clicked");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "1BN";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600166A RID: 5738 RVA: 0x0007D8C4 File Offset: 0x0007BAC4
	[Token(Token = "0x600166A")]
	[Address(RVA = "0x2A448EC", Offset = "0x2A448EC", VA = "0x2A448EC")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("waited for your bullshit unity grrr");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("ChangePlayerSize");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "BN";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600166B RID: 5739 RVA: 0x0007D9C8 File Offset: 0x0007BBC8
	[Token(Token = "0x600166B")]
	[Address(RVA = "0x2A44BC4", Offset = "0x2A44BC4", VA = "0x2A44BC4")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("PlayerHead");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600166C RID: 5740 RVA: 0x0007DACC File Offset: 0x0007BCCC
	[Token(Token = "0x600166C")]
	[Address(RVA = "0x2A44EA8", Offset = "0x2A44EA8", VA = "0x2A44EA8")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Horizontal");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("This is the 1000 Bananas button, and it was just clicked");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "NetworkPlayer";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600166D RID: 5741 RVA: 0x0007DBD4 File Offset: 0x0007BDD4
	[Token(Token = "0x600166D")]
	[Address(RVA = "0x2A4518C", Offset = "0x2A4518C", VA = "0x2A4518C")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("goDownRPC");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Name Changing Error. Error: ");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			BuyScript ך_u0604Ӱߣ2 = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600166E RID: 5742 RVA: 0x0007DCCC File Offset: 0x0007BECC
	[Token(Token = "0x600166E")]
	[Address(RVA = "0x2A4543C", Offset = "0x2A4543C", VA = "0x2A4543C")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Key");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("FingerTip");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "CapuchinStore";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600166F RID: 5743 RVA: 0x0007DDD8 File Offset: 0x0007BFD8
	[Token(Token = "0x600166F")]
	[Address(RVA = "0x2A45720", Offset = "0x2A45720", VA = "0x2A45720")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("hh:mmtt");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("containsStaff");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Key";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001670 RID: 5744 RVA: 0x0007DEE0 File Offset: 0x0007C0E0
	[Token(Token = "0x6001670")]
	[Address(RVA = "0x2A45A04", Offset = "0x2A45A04", VA = "0x2A45A04")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Round end");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Grip";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001671 RID: 5745 RVA: 0x0007DFD4 File Offset: 0x0007C1D4
	[Token(Token = "0x6001671")]
	[Address(RVA = "0x2A45CE8", Offset = "0x2A45CE8", VA = "0x2A45CE8")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Add/Remove Sword");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Faild To Add Winner Money: ");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "PRESS AGAIN TO CONFIRM";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001672 RID: 5746 RVA: 0x0007E0C8 File Offset: 0x0007C2C8
	[Token(Token = "0x6001672")]
	[Address(RVA = "0x2A45FB8", Offset = "0x2A45FB8", VA = "0x2A45FB8")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Add/Remove Glasses");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log(".Please press the button if you would like to play alone");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Head";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001673 RID: 5747 RVA: 0x0007E1CC File Offset: 0x0007C3CC
	[Token(Token = "0x6001673")]
	[Address(RVA = "0x2A4629C", Offset = "0x2A4629C", VA = "0x2A4629C")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("5BN");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Agreed");
			this.Ԧܯٽݖ.Play();
			this.իࢬطӤ.m_Material = "User has been reported for: ";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001674 RID: 5748 RVA: 0x0007E2CC File Offset: 0x0007C4CC
	[Token(Token = "0x6001674")]
	[Address(RVA = "0x2A46560", Offset = "0x2A46560", VA = "0x2A46560")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayWave");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Start Gamemode");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Connected to Server.";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001675 RID: 5749 RVA: 0x0007E3C4 File Offset: 0x0007C5C4
	[Token(Token = "0x6001675")]
	[Address(RVA = "0x2A46830", Offset = "0x2A46830", VA = "0x2A46830")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("On");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("_Tint");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Player";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001676 RID: 5750 RVA: 0x0007E4D0 File Offset: 0x0007C6D0
	[Token(Token = "0x6001676")]
	[Address(RVA = "0x2A46B14", Offset = "0x2A46B14", VA = "0x2A46B14")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("A Player has left the Room.");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "true";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001677 RID: 5751 RVA: 0x0007E5E0 File Offset: 0x0007C7E0
	[Token(Token = "0x6001677")]
	[Address(RVA = "0x2A46DF8", Offset = "0x2A46DF8", VA = "0x2A46DF8")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("BN");
		if ("BN" == null)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Target");
			return;
		}
	}

	// Token: 0x06001678 RID: 5752 RVA: 0x0007E638 File Offset: 0x0007C838
	[Token(Token = "0x6001678")]
	[Address(RVA = "0x2A470D0", Offset = "0x2A470D0", VA = "0x2A470D0")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "On";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001679 RID: 5753 RVA: 0x0007E740 File Offset: 0x0007C940
	[Token(Token = "0x6001679")]
	[Address(RVA = "0x2A473B4", Offset = "0x2A473B4", VA = "0x2A473B4")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("On");
		if ("On" == null)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "hh:mm:sstt";
			this.ך\u0604Ӱߣ.\u064C\u073Eوԝ = 134;
			DoorLerp ڔ_u082Bھࢩ = this.ڔ\u082Bھࢩ;
			return;
		}
	}

	// Token: 0x0600167A RID: 5754 RVA: 0x0007E830 File Offset: 0x0007CA30
	[Token(Token = "0x600167A")]
	[Address(RVA = "0x2A47698", Offset = "0x2A47698", VA = "0x2A47698")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("containsStaff");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("You struck apon an error. ");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Reason: ";
			this.ך\u0604Ӱߣ.\u064C\u073Eوԝ = "Adding ";
			DoorLerp ڔ_u082Bھࢩ = this.ڔ\u082Bھࢩ;
			return;
		}
	}

	// Token: 0x0600167B RID: 5755 RVA: 0x0007E938 File Offset: 0x0007CB38
	[Token(Token = "0x600167B")]
	[Address(RVA = "0x2A4797C", Offset = "0x2A4797C", VA = "0x2A4797C")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Date: ");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("HandR");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "PRESS AGAIN TO CONFIRM";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600167C RID: 5756 RVA: 0x0007EA38 File Offset: 0x0007CC38
	[Token(Token = "0x600167C")]
	[Address(RVA = "0x2A47C50", Offset = "0x2A47C50", VA = "0x2A47C50")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("gamemode");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Vector1_d371bd24217449349bd747533d51af6b";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600167D RID: 5757 RVA: 0x0007EB28 File Offset: 0x0007CD28
	[Token(Token = "0x600167D")]
	[Address(RVA = "0x2A47F20", Offset = "0x2A47F20", VA = "0x2A47F20")]
	public void \u0705ߔࠈՍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Charging...");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = " and the correct version is ";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			long u064C_u073Eوԝ = -13L;
			ך_u0604Ӱߣ.\u064C\u073Eوԝ = (int)u064C_u073Eوԝ;
			DoorLerp ڔ_u082Bھࢩ = this.ڔ\u082Bھࢩ;
			long ٽ_u0886ࡠԢ = 1L;
			ڔ_u082Bھࢩ.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
			return;
		}
	}

	// Token: 0x0600167E RID: 5758 RVA: 0x0007EC38 File Offset: 0x0007CE38
	[Token(Token = "0x600167E")]
	[Address(RVA = "0x2A48204", Offset = "0x2A48204", VA = "0x2A48204")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Failed to login, please restart");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Right Hand");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600167F RID: 5759 RVA: 0x0007ED4C File Offset: 0x0007CF4C
	[Token(Token = "0x600167F")]
	[Address(RVA = "0x2A484E8", Offset = "0x2A484E8", VA = "0x2A484E8")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Charging...");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "CapuchinStore";
			this.ך\u0604Ӱߣ.\u064C\u073Eوԝ = "ChangePlayerSize";
			DoorLerp ڔ_u082Bھࢩ = this.ڔ\u082Bھࢩ;
			return;
		}
	}

	// Token: 0x06001680 RID: 5760 RVA: 0x0007EE50 File Offset: 0x0007D050
	[Token(Token = "0x6001680")]
	[Address(RVA = "0x2A487CC", Offset = "0x2A487CC", VA = "0x2A487CC")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("gamemode");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			this.ך\u0604Ӱߣ.\u064C\u073Eوԝ = 93;
			DoorLerp ڔ_u082Bھࢩ = this.ڔ\u082Bھࢩ;
			long ٽ_u0886ࡠԢ = 1L;
			ڔ_u082Bھࢩ.ٽ\u0886ࡠԢ = (ٽ_u0886ࡠԢ != 0L);
			return;
		}
	}

	// Token: 0x06001681 RID: 5761 RVA: 0x0007EF48 File Offset: 0x0007D148
	[Token(Token = "0x6001681")]
	[Address(RVA = "0x2A48AB0", Offset = "0x2A48AB0", VA = "0x2A48AB0")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("EnableCosmetic");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("PURCHASE");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "PlayerHead";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001682 RID: 5762 RVA: 0x0007F038 File Offset: 0x0007D238
	[Token(Token = "0x6001682")]
	[Address(RVA = "0x2A48D84", Offset = "0x2A48D84", VA = "0x2A48D84")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Update User Inventory");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Display Name Changed!");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Charging...";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001683 RID: 5763 RVA: 0x0007F13C File Offset: 0x0007D33C
	[Token(Token = "0x6001683")]
	[Address(RVA = "0x2A4904C", Offset = "0x2A4904C", VA = "0x2A4904C")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("sound play stopped");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("PlayWave");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Vector1_d371bd24217449349bd747533d51af6b";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001684 RID: 5764 RVA: 0x0007F248 File Offset: 0x0007D448
	[Token(Token = "0x6001684")]
	[Address(RVA = "0x2A49330", Offset = "0x2A49330", VA = "0x2A49330")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Debug.Log("BN");
		this.Ԧܯٽݖ.Play();
		TextMeshPro textMeshPro = this.իࢬطӤ;
		this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "";
		BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
	}

	// Token: 0x06001685 RID: 5765 RVA: 0x0007F32C File Offset: 0x0007D52C
	[Token(Token = "0x6001685")]
	[Address(RVA = "0x2A49614", Offset = "0x2A49614", VA = "0x2A49614")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_BaseColor");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("run");
			this.Ԧܯٽݖ.Play();
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "EnableCosmetic";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001686 RID: 5766 RVA: 0x0007F434 File Offset: 0x0007D634
	[Token(Token = "0x6001686")]
	[Address(RVA = "0x2A498F8", Offset = "0x2A498F8", VA = "0x2A498F8")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PURCHASED");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("2BN");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Not enough amount of currency";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001687 RID: 5767 RVA: 0x0007F534 File Offset: 0x0007D734
	[Token(Token = "0x6001687")]
	[Address(RVA = "0x2A49BD0", Offset = "0x2A49BD0", VA = "0x2A49BD0")]
	public void عߎӑ٤(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("You Already Own This Item");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("FingerTip");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "true";
			this.ך\u0604Ӱߣ.\u064C\u073Eوԝ = 142;
			DoorLerp ڔ_u082Bھࢩ = this.ڔ\u082Bھࢩ;
			return;
		}
	}

	// Token: 0x06001688 RID: 5768 RVA: 0x0007F640 File Offset: 0x0007D840
	[Token(Token = "0x6001688")]
	[Address(RVA = "0x2A49EB4", Offset = "0x2A49EB4", VA = "0x2A49EB4")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("jump char false");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Player";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001689 RID: 5769 RVA: 0x0007F72C File Offset: 0x0007D92C
	[Token(Token = "0x6001689")]
	[Address(RVA = "0x2A4A184", Offset = "0x2A4A184", VA = "0x2A4A184")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("gravThing");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Player");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "PRESS AGAIN TO CONFIRM";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600168A RID: 5770 RVA: 0x0007F830 File Offset: 0x0007DA30
	[Token(Token = "0x600168A")]
	[Address(RVA = "0x2A4A45C", Offset = "0x2A4A45C", VA = "0x2A4A45C")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Display Name Changed!");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("closeToObject");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "HOLY MOLY THE STICK IS ON FIRE!!!!!!";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600168B RID: 5771 RVA: 0x0007F93C File Offset: 0x0007DB3C
	[Token(Token = "0x600168B")]
	[Address(RVA = "0x2A4A734", Offset = "0x2A4A734", VA = "0x2A4A734")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("TurnAmount");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("NGNNoSound");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "BN";
			this.ך\u0604Ӱߣ.\u064C\u073Eوԝ = "PRESS AGAIN TO CONFIRM";
			DoorLerp ڔ_u082Bھࢩ = this.ڔ\u082Bھࢩ;
			return;
		}
	}

	// Token: 0x0600168C RID: 5772 RVA: 0x0007FA40 File Offset: 0x0007DC40
	[Token(Token = "0x600168C")]
	[Address(RVA = "0x2A4AA04", Offset = "0x2A4AA04", VA = "0x2A4AA04")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("You have been banned for ");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Collided");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "ENABLE";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600168D RID: 5773 RVA: 0x0007FB54 File Offset: 0x0007DD54
	[Token(Token = "0x600168D")]
	[Address(RVA = "0x2A4ACE8", Offset = "0x2A4ACE8", VA = "0x2A4ACE8")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(" and the correct version is ");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Try Connect To Server...");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "CapuchinStore";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600168E RID: 5774 RVA: 0x0007FC60 File Offset: 0x0007DE60
	[Token(Token = "0x600168E")]
	[Address(RVA = "0x2A4AFCC", Offset = "0x2A4AFCC", VA = "0x2A4AFCC")]
	public void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("2BN");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("User has been reported for: ");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "ErrorScreen";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x0600168F RID: 5775 RVA: 0x0007FD50 File Offset: 0x0007DF50
	[Token(Token = "0x600168F")]
	[Address(RVA = "0x2A4B288", Offset = "0x2A4B288", VA = "0x2A4B288")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("TurnAmount");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Player");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Bruh i cannot go here you stupid L bozo";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001690 RID: 5776 RVA: 0x0007FE50 File Offset: 0x0007E050
	[Token(Token = "0x6001690")]
	[Address(RVA = "0x2A4B56C", Offset = "0x2A4B56C", VA = "0x2A4B56C")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			Debug.Log("Completed baking textures on frame ");
			this.Ԧܯٽݖ.Play();
			this.իࢬطӤ.m_Material = "_Tint";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001691 RID: 5777 RVA: 0x0007FF58 File Offset: 0x0007E158
	[Token(Token = "0x6001691")]
	[Address(RVA = "0x2A4B828", Offset = "0x2A4B828", VA = "0x2A4B828")]
	public void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayWave");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Try Connect To Server...");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			this.ך\u0604Ӱߣ.\u064C\u073Eوԝ = " and the correct version is ";
			DoorLerp ڔ_u082Bھࢩ = this.ڔ\u082Bھࢩ;
			return;
		}
	}

	// Token: 0x06001692 RID: 5778 RVA: 0x00080064 File Offset: 0x0007E264
	[Token(Token = "0x6001692")]
	[Address(RVA = "0x2A4BAF4", Offset = "0x2A4BAF4", VA = "0x2A4BAF4")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeToRegular");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("CASUAL");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "Player";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x06001693 RID: 5779 RVA: 0x00080178 File Offset: 0x0007E378
	[Token(Token = "0x6001693")]
	[Address(RVA = "0x2A4BDCC", Offset = "0x2A4BDCC", VA = "0x2A4BDCC")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.CompareTag("True");
		if (this.ࡅ\u0706\u07F3ࡘ == AddBananasToCart.ض\u058F\u081Aӯ.ۻԲժ\u0650)
		{
			if (typeof(Debug).TypeHandle == null)
			{
			}
			Debug.Log("Tagged");
			this.Ԧܯٽݖ.Play();
			TextMeshPro textMeshPro = this.իࢬطӤ;
			this.ך\u0604Ӱߣ.Ә\u07B8ߖ\u0897 = "hh:mmtt";
			BuyScript ך_u0604Ӱߣ = this.ך\u0604Ӱߣ;
			return;
		}
	}

	// Token: 0x040002C6 RID: 710
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002C6")]
	public AddBananasToCart.ض\u058F\u081Aӯ ࡅ\u0706\u07F3ࡘ;

	// Token: 0x040002C7 RID: 711
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002C7")]
	public DoorLerp ڔ\u082Bھࢩ;

	// Token: 0x040002C8 RID: 712
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40002C8")]
	public ParticleSystem Ԧܯٽݖ;

	// Token: 0x040002C9 RID: 713
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40002C9")]
	public TextMeshPro իࢬطӤ;

	// Token: 0x040002CA RID: 714
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40002CA")]
	public BuyScript ך\u0604Ӱߣ;

	// Token: 0x02000095 RID: 149
	[Token(Token = "0x2000095")]
	public enum ض\u058F\u081Aӯ
	{
		// Token: 0x040002CC RID: 716
		[Token(Token = "0x40002CC")]
		ۻԲժ\u0650,
		// Token: 0x040002CD RID: 717
		[Token(Token = "0x40002CD")]
		\u05BD\u0870ܜތ,
		// Token: 0x040002CE RID: 718
		[Token(Token = "0x40002CE")]
		\u085D\u05AB߀\u05C8
	}
}
