﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000034 RID: 52
[Token(Token = "0x2000034")]
public class GravityAttractor : MonoBehaviour
{
	// Token: 0x06000619 RID: 1561 RVA: 0x000245D4 File Offset: 0x000227D4
	[Token(Token = "0x6000619")]
	[Address(RVA = "0x2E72CC8", Offset = "0x2E72CC8", VA = "0x2E72CC8")]
	public void ڐ߂ܨٯ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600061A RID: 1562 RVA: 0x00024634 File Offset: 0x00022834
	[Token(Token = "0x600061A")]
	[Address(RVA = "0x2E72E90", Offset = "0x2E72E90", VA = "0x2E72E90")]
	public GravityAttractor()
	{
	}

	// Token: 0x0600061B RID: 1563 RVA: 0x00024654 File Offset: 0x00022854
	[Token(Token = "0x600061B")]
	[Address(RVA = "0x2E72EA4", Offset = "0x2E72EA4", VA = "0x2E72EA4")]
	public void \u0615\u06DA\u0827ދ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Transform transform;
		Vector3 normalized = transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600061C RID: 1564 RVA: 0x000246B4 File Offset: 0x000228B4
	[Token(Token = "0x600061C")]
	[Address(RVA = "0x2E7306C", Offset = "0x2E7306C", VA = "0x2E7306C")]
	public void ٷ۴\u085EӨ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600061D RID: 1565 RVA: 0x00024718 File Offset: 0x00022918
	[Token(Token = "0x600061D")]
	[Address(RVA = "0x2E73234", Offset = "0x2E73234", VA = "0x2E73234")]
	public void كմ\u06D9ۊ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600061E RID: 1566 RVA: 0x0002477C File Offset: 0x0002297C
	[Token(Token = "0x600061E")]
	[Address(RVA = "0x2E733FC", Offset = "0x2E733FC", VA = "0x2E733FC")]
	public void ںԭڋإ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x000247D8 File Offset: 0x000229D8
	[Token(Token = "0x600061F")]
	[Address(RVA = "0x2E735C4", Offset = "0x2E735C4", VA = "0x2E735C4")]
	public void ߨىݭԯ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000620 RID: 1568 RVA: 0x00024834 File Offset: 0x00022A34
	[Token(Token = "0x6000620")]
	[Address(RVA = "0x2E7378C", Offset = "0x2E7378C", VA = "0x2E7378C")]
	public void \u065D\u083Eݐ\u059E(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000621 RID: 1569 RVA: 0x00024898 File Offset: 0x00022A98
	[Token(Token = "0x6000621")]
	[Address(RVA = "0x2E73954", Offset = "0x2E73954", VA = "0x2E73954")]
	public void \u0839ڠ\u0833ݲ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000622 RID: 1570 RVA: 0x000248FC File Offset: 0x00022AFC
	[Token(Token = "0x6000622")]
	[Address(RVA = "0x2E73B1C", Offset = "0x2E73B1C", VA = "0x2E73B1C")]
	public void ݾ\u06E0ބࠏ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000623 RID: 1571 RVA: 0x00024960 File Offset: 0x00022B60
	[Token(Token = "0x6000623")]
	[Address(RVA = "0x2E73CE4", Offset = "0x2E73CE4", VA = "0x2E73CE4")]
	public void ռڊ\u07F6س(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000624 RID: 1572 RVA: 0x000249C4 File Offset: 0x00022BC4
	[Token(Token = "0x6000624")]
	[Address(RVA = "0x2E73EAC", Offset = "0x2E73EAC", VA = "0x2E73EAC")]
	public void \u05CBࡓࠏԃ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000625 RID: 1573 RVA: 0x00024A28 File Offset: 0x00022C28
	[Token(Token = "0x6000625")]
	[Address(RVA = "0x2E74074", Offset = "0x2E74074", VA = "0x2E74074")]
	public void ࡣر\u07A7օ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000626 RID: 1574 RVA: 0x00024A8C File Offset: 0x00022C8C
	[Token(Token = "0x6000626")]
	[Address(RVA = "0x2E7423C", Offset = "0x2E7423C", VA = "0x2E7423C")]
	public void ݑߡԣي(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000627 RID: 1575 RVA: 0x00024AF0 File Offset: 0x00022CF0
	[Token(Token = "0x6000627")]
	[Address(RVA = "0x2E74404", Offset = "0x2E74404", VA = "0x2E74404")]
	public void ڛ\u05CDܜי(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000628 RID: 1576 RVA: 0x00024B54 File Offset: 0x00022D54
	[Token(Token = "0x6000628")]
	[Address(RVA = "0x2E745CC", Offset = "0x2E745CC", VA = "0x2E745CC")]
	public void \u0654Պؾࢫ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000629 RID: 1577 RVA: 0x00024BB8 File Offset: 0x00022DB8
	[Token(Token = "0x6000629")]
	[Address(RVA = "0x2E74794", Offset = "0x2E74794", VA = "0x2E74794")]
	public void ӄܮۂ\u05B3(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Transform transform;
		Vector3 up = transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600062A RID: 1578 RVA: 0x00024C18 File Offset: 0x00022E18
	[Token(Token = "0x600062A")]
	[Address(RVA = "0x2E7495C", Offset = "0x2E7495C", VA = "0x2E7495C")]
	public void \u07EFԣ\u073F\u05A7(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600062B RID: 1579 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x600062B")]
	[Address(RVA = "0x2E74B24", Offset = "0x2E74B24", VA = "0x2E74B24")]
	public void \u07A9ԣ۵ޠ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600062C RID: 1580 RVA: 0x00024CDC File Offset: 0x00022EDC
	[Token(Token = "0x600062C")]
	[Address(RVA = "0x2E74CEC", Offset = "0x2E74CEC", VA = "0x2E74CEC")]
	public void \u087FӟӰӞ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600062D RID: 1581 RVA: 0x00024D40 File Offset: 0x00022F40
	[Token(Token = "0x600062D")]
	[Address(RVA = "0x2E74EB4", Offset = "0x2E74EB4", VA = "0x2E74EB4")]
	public void ࡁࢫ\u05A1\u0741(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x00024DA4 File Offset: 0x00022FA4
	[Token(Token = "0x600062E")]
	[Address(RVA = "0x2E7507C", Offset = "0x2E7507C", VA = "0x2E7507C")]
	public void գӯݽ\u0822(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600062F RID: 1583 RVA: 0x00024E08 File Offset: 0x00023008
	[Token(Token = "0x600062F")]
	[Address(RVA = "0x2E75244", Offset = "0x2E75244", VA = "0x2E75244")]
	public void ڧ\u0593\u0732ք(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000630 RID: 1584 RVA: 0x00024E6C File Offset: 0x0002306C
	[Token(Token = "0x6000630")]
	[Address(RVA = "0x2E7540C", Offset = "0x2E7540C", VA = "0x2E7540C")]
	public void ڒ۱ࠔ\u07B6(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000631 RID: 1585 RVA: 0x00024ED0 File Offset: 0x000230D0
	[Token(Token = "0x6000631")]
	[Address(RVA = "0x2E755D4", Offset = "0x2E755D4", VA = "0x2E755D4")]
	public void ࡆվچ\u07A7(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000632 RID: 1586 RVA: 0x00024F34 File Offset: 0x00023134
	[Token(Token = "0x6000632")]
	[Address(RVA = "0x2E7579C", Offset = "0x2E7579C", VA = "0x2E7579C")]
	public void ࢤݘٱݺ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000633 RID: 1587 RVA: 0x00024F98 File Offset: 0x00023198
	[Token(Token = "0x6000633")]
	[Address(RVA = "0x2E75964", Offset = "0x2E75964", VA = "0x2E75964")]
	public void ԥۯӮࡏ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000634 RID: 1588 RVA: 0x00024FFC File Offset: 0x000231FC
	[Token(Token = "0x6000634")]
	[Address(RVA = "0x2E75B2C", Offset = "0x2E75B2C", VA = "0x2E75B2C")]
	public void \u085Fԩ\u0700١(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000635 RID: 1589 RVA: 0x00025060 File Offset: 0x00023260
	[Token(Token = "0x6000635")]
	[Address(RVA = "0x2E75CF4", Offset = "0x2E75CF4", VA = "0x2E75CF4")]
	public void \u06DE\u0880ܡס(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000636 RID: 1590 RVA: 0x000250C4 File Offset: 0x000232C4
	[Token(Token = "0x6000636")]
	[Address(RVA = "0x2E75EBC", Offset = "0x2E75EBC", VA = "0x2E75EBC")]
	public void ةԣ\u06D8\u0606(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000637 RID: 1591 RVA: 0x00025124 File Offset: 0x00023324
	[Token(Token = "0x6000637")]
	[Address(RVA = "0x2E76084", Offset = "0x2E76084", VA = "0x2E76084")]
	public void ܤڮԡ\u06E9(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000638 RID: 1592 RVA: 0x00025188 File Offset: 0x00023388
	[Token(Token = "0x6000638")]
	[Address(RVA = "0x2E7624C", Offset = "0x2E7624C", VA = "0x2E7624C")]
	public void ӆ\u05AC\u0607ࠑ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000639 RID: 1593 RVA: 0x000251E4 File Offset: 0x000233E4
	[Token(Token = "0x6000639")]
	[Address(RVA = "0x2E76414", Offset = "0x2E76414", VA = "0x2E76414")]
	public void ؽ\u059Eࠈ\u0838(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600063A RID: 1594 RVA: 0x00025248 File Offset: 0x00023448
	[Token(Token = "0x600063A")]
	[Address(RVA = "0x2E765DC", Offset = "0x2E765DC", VA = "0x2E765DC")]
	public void \u06D4ڷӃצ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600063B RID: 1595 RVA: 0x000252AC File Offset: 0x000234AC
	[Token(Token = "0x600063B")]
	[Address(RVA = "0x2E7679C", Offset = "0x2E7679C", VA = "0x2E7679C")]
	public void \u0557ԯ\u081B\u0731(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600063C RID: 1596 RVA: 0x00025310 File Offset: 0x00023510
	[Token(Token = "0x600063C")]
	[Address(RVA = "0x2E76964", Offset = "0x2E76964", VA = "0x2E76964")]
	public void ࠁԚڰہ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600063D RID: 1597 RVA: 0x00025374 File Offset: 0x00023574
	[Token(Token = "0x600063D")]
	[Address(RVA = "0x2E76B2C", Offset = "0x2E76B2C", VA = "0x2E76B2C")]
	public void ӷ߄\u0738\u0656(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600063E RID: 1598 RVA: 0x000253D8 File Offset: 0x000235D8
	[Token(Token = "0x600063E")]
	[Address(RVA = "0x2E76CF4", Offset = "0x2E76CF4", VA = "0x2E76CF4")]
	public void ފӘہԷ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600063F RID: 1599 RVA: 0x0002543C File Offset: 0x0002363C
	[Token(Token = "0x600063F")]
	[Address(RVA = "0x2E76EBC", Offset = "0x2E76EBC", VA = "0x2E76EBC")]
	public void ݲՐ\u05A0ࠄ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000640 RID: 1600 RVA: 0x000254A0 File Offset: 0x000236A0
	[Token(Token = "0x6000640")]
	[Address(RVA = "0x2E77084", Offset = "0x2E77084", VA = "0x2E77084")]
	public void ڹیߢ\u0704(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Transform transform;
		Vector3 up = transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000641 RID: 1601 RVA: 0x00025500 File Offset: 0x00023700
	[Token(Token = "0x6000641")]
	[Address(RVA = "0x2E7724C", Offset = "0x2E7724C", VA = "0x2E7724C")]
	public void \u074B\u07F4Ԧ\u074C(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000642 RID: 1602 RVA: 0x00025564 File Offset: 0x00023764
	[Token(Token = "0x6000642")]
	[Address(RVA = "0x2E77414", Offset = "0x2E77414", VA = "0x2E77414")]
	public void ݯܫס\u05BE(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Transform transform;
		Vector3 normalized = transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000643 RID: 1603 RVA: 0x000255B8 File Offset: 0x000237B8
	[Token(Token = "0x6000643")]
	[Address(RVA = "0x2E775DC", Offset = "0x2E775DC", VA = "0x2E775DC")]
	public void \u05AB\u058B\u0876ݗ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000644 RID: 1604 RVA: 0x0002561C File Offset: 0x0002381C
	[Token(Token = "0x6000644")]
	[Address(RVA = "0x2E777A4", Offset = "0x2E777A4", VA = "0x2E777A4")]
	public void Ԏب\u05C3\u0708(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000645 RID: 1605 RVA: 0x00025680 File Offset: 0x00023880
	[Token(Token = "0x6000645")]
	[Address(RVA = "0x2E7796C", Offset = "0x2E7796C", VA = "0x2E7796C")]
	public void ߃տ\u0731ڒ(Rigidbody ԁ\u0884\u070Fࢯ)
	{
		Vector3 position = ԁ\u0884\u070Fࢯ.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = ԁ\u0884\u070Fࢯ.transform.up;
		float u05B6ࠇ_u0559ߖ = this.\u05B6ࠇ\u0559ߖ;
		Quaternion rotation = ԁ\u0884\u070Fࢯ.rotation;
		Quaternion rotation2 = ԁ\u0884\u070Fࢯ.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x040000F2 RID: 242
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000F2")]
	public float \u05B6ࠇ\u0559ߖ = (float)52429;
}
