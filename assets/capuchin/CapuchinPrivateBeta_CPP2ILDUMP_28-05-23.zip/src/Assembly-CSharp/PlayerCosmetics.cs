﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000D6 RID: 214
[Token(Token = "0x20000D6")]
public class PlayerCosmetics : MonoBehaviour
{
	// Token: 0x0600205B RID: 8283 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600205B")]
	[Address(RVA = "0x299F750", Offset = "0x299F750", VA = "0x299F750")]
	private void \u0595ࡌ\u0828ڥ(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600205C RID: 8284 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600205C")]
	[Address(RVA = "0x299F840", Offset = "0x299F840", VA = "0x299F840")]
	[PunRPC]
	private void DisableCosmetic(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600205D RID: 8285 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600205D")]
	[Address(RVA = "0x299F930", Offset = "0x299F930", VA = "0x299F930")]
	private void ࡦٱҼ\u059C(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600205E RID: 8286 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600205E")]
	[Address(RVA = "0x299F9F8", Offset = "0x299F9F8", VA = "0x299F9F8")]
	private void ցӃנ\u0618(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600205F RID: 8287 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600205F")]
	[Address(RVA = "0x299FAE8", Offset = "0x299FAE8", VA = "0x299FAE8")]
	private void \u0897\u066Dد\u0619(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002060 RID: 8288 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002060")]
	[Address(RVA = "0x299FBB0", Offset = "0x299FBB0", VA = "0x299FBB0")]
	private void ڱزԡڷ(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002061 RID: 8289 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002061")]
	[Address(RVA = "0x299FCA0", Offset = "0x299FCA0", VA = "0x299FCA0")]
	private void ԃࢭࠄ\u05FD(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002062 RID: 8290 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002062")]
	[Address(RVA = "0x299FD68", Offset = "0x299FD68", VA = "0x299FD68")]
	private void \u0734ۼࡘڮ(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002063 RID: 8291 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002063")]
	[Address(RVA = "0x299FE30", Offset = "0x299FE30", VA = "0x299FE30")]
	private void ޞ\u089Bر\u0616(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002064 RID: 8292 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002064")]
	[Address(RVA = "0x299FF20", Offset = "0x299FF20", VA = "0x299FF20")]
	private void ڿݜ\u0530\u05AF(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002065 RID: 8293 RVA: 0x000A8698 File Offset: 0x000A6898
	[Token(Token = "0x6002065")]
	[Address(RVA = "0x29A0010", Offset = "0x29A0010", VA = "0x29A0010")]
	public PlayerCosmetics()
	{
	}

	// Token: 0x06002066 RID: 8294 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002066")]
	[Address(RVA = "0x29A0018", Offset = "0x29A0018", VA = "0x29A0018")]
	private void ٽ\u05C7ࠓޠ(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002067 RID: 8295 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002067")]
	[Address(RVA = "0x29A0108", Offset = "0x29A0108", VA = "0x29A0108")]
	[PunRPC]
	private void EnableCosmetic(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002068 RID: 8296 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002068")]
	[Address(RVA = "0x29A01F8", Offset = "0x29A01F8", VA = "0x29A01F8")]
	private void \u0889ࡧ٥Ԏ(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002069 RID: 8297 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6002069")]
	[Address(RVA = "0x29A02BC", Offset = "0x29A02BC", VA = "0x29A02BC")]
	private void \u059Dۀ\u05A8פ(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600206A RID: 8298 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x600206A")]
	[Address(RVA = "0x29A0380", Offset = "0x29A0380", VA = "0x29A0380")]
	private void ӼՂڪ\u0600(string ظݓ\u0897\u05B4)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x04000426 RID: 1062
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000426")]
	public List<GameObject> \u07F9\u05A1ࠌח;
}
