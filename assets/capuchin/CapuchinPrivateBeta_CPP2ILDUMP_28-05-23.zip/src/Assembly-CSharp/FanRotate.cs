﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000029 RID: 41
[Token(Token = "0x2000029")]
public class FanRotate : MonoBehaviour
{
	// Token: 0x06000491 RID: 1169 RVA: 0x0001B6B0 File Offset: 0x000198B0
	[Token(Token = "0x6000491")]
	[Address(RVA = "0x1D8AACC", Offset = "0x1D8AACC", VA = "0x1D8AACC")]
	private void ژךՈ\u0597()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000492 RID: 1170 RVA: 0x0001B6F8 File Offset: 0x000198F8
	[Token(Token = "0x6000492")]
	[Address(RVA = "0x1D8AB34", Offset = "0x1D8AB34", VA = "0x1D8AB34")]
	private void Update()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000493 RID: 1171 RVA: 0x0001B740 File Offset: 0x00019940
	[Token(Token = "0x6000493")]
	[Address(RVA = "0x1D8AB9C", Offset = "0x1D8AB9C", VA = "0x1D8AB9C")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000494 RID: 1172 RVA: 0x0001B788 File Offset: 0x00019988
	[Token(Token = "0x6000494")]
	[Address(RVA = "0x1D8AC04", Offset = "0x1D8AC04", VA = "0x1D8AC04")]
	private void ފՖߢ\u059B()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000495 RID: 1173 RVA: 0x0001B7D0 File Offset: 0x000199D0
	[Token(Token = "0x6000495")]
	[Address(RVA = "0x1D8AC6C", Offset = "0x1D8AC6C", VA = "0x1D8AC6C")]
	private void צ\u0874ڵ\u059A()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000496 RID: 1174 RVA: 0x0001B818 File Offset: 0x00019A18
	[Token(Token = "0x6000496")]
	[Address(RVA = "0x1D8ACD4", Offset = "0x1D8ACD4", VA = "0x1D8ACD4")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000497 RID: 1175 RVA: 0x0001B860 File Offset: 0x00019A60
	[Token(Token = "0x6000497")]
	[Address(RVA = "0x1D8AD3C", Offset = "0x1D8AD3C", VA = "0x1D8AD3C")]
	private void \u061B\u05EEوۈ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000498 RID: 1176 RVA: 0x0001B8A8 File Offset: 0x00019AA8
	[Token(Token = "0x6000498")]
	[Address(RVA = "0x1D8ADA4", Offset = "0x1D8ADA4", VA = "0x1D8ADA4")]
	private void \u0881ݗӟ\u07BD()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000499 RID: 1177 RVA: 0x0001B8F0 File Offset: 0x00019AF0
	[Token(Token = "0x6000499")]
	[Address(RVA = "0x1D8AE0C", Offset = "0x1D8AE0C", VA = "0x1D8AE0C")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600049A RID: 1178 RVA: 0x0001B938 File Offset: 0x00019B38
	[Token(Token = "0x600049A")]
	[Address(RVA = "0x1D8AE74", Offset = "0x1D8AE74", VA = "0x1D8AE74")]
	private void \u05EDց\u081Cت()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600049B RID: 1179 RVA: 0x0001B980 File Offset: 0x00019B80
	[Token(Token = "0x600049B")]
	[Address(RVA = "0x1D8AEDC", Offset = "0x1D8AEDC", VA = "0x1D8AEDC")]
	private void \u05F7ԝߠӱ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600049C RID: 1180 RVA: 0x0001B9C8 File Offset: 0x00019BC8
	[Token(Token = "0x600049C")]
	[Address(RVA = "0x1D8AF44", Offset = "0x1D8AF44", VA = "0x1D8AF44")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600049D RID: 1181 RVA: 0x0001BA10 File Offset: 0x00019C10
	[Token(Token = "0x600049D")]
	[Address(RVA = "0x1D8AFAC", Offset = "0x1D8AFAC", VA = "0x1D8AFAC")]
	private void \u0886Ҽ\u058Dߛ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600049E RID: 1182 RVA: 0x0001BA58 File Offset: 0x00019C58
	[Token(Token = "0x600049E")]
	[Address(RVA = "0x1D8B014", Offset = "0x1D8B014", VA = "0x1D8B014")]
	private void ժ\u065Dԯࡘ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600049F RID: 1183 RVA: 0x0001BAA0 File Offset: 0x00019CA0
	[Token(Token = "0x600049F")]
	[Address(RVA = "0x1D8B07C", Offset = "0x1D8B07C", VA = "0x1D8B07C")]
	private void Ҿࢹؼס()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004A0 RID: 1184 RVA: 0x0001BAE8 File Offset: 0x00019CE8
	[Token(Token = "0x60004A0")]
	[Address(RVA = "0x1D8B0E4", Offset = "0x1D8B0E4", VA = "0x1D8B0E4")]
	private void ڑߒجވ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004A1 RID: 1185 RVA: 0x0001BB30 File Offset: 0x00019D30
	[Token(Token = "0x60004A1")]
	[Address(RVA = "0x1D8B14C", Offset = "0x1D8B14C", VA = "0x1D8B14C")]
	private void \u087BӦןݩ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004A2 RID: 1186 RVA: 0x0001BB78 File Offset: 0x00019D78
	[Token(Token = "0x60004A2")]
	[Address(RVA = "0x1D8B1B4", Offset = "0x1D8B1B4", VA = "0x1D8B1B4")]
	private void ւࡂ\u0883\u0872()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004A3 RID: 1187 RVA: 0x0001BBC0 File Offset: 0x00019DC0
	[Token(Token = "0x60004A3")]
	[Address(RVA = "0x1D8B21C", Offset = "0x1D8B21C", VA = "0x1D8B21C")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004A4 RID: 1188 RVA: 0x0001BC08 File Offset: 0x00019E08
	[Token(Token = "0x60004A4")]
	[Address(RVA = "0x1D8B284", Offset = "0x1D8B284", VA = "0x1D8B284")]
	private void \u0732ڙԒࢺ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004A5 RID: 1189 RVA: 0x0001BC50 File Offset: 0x00019E50
	[Token(Token = "0x60004A5")]
	[Address(RVA = "0x1D8B2EC", Offset = "0x1D8B2EC", VA = "0x1D8B2EC")]
	private void ӻӒݝ߃()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004A6 RID: 1190 RVA: 0x0001BC98 File Offset: 0x00019E98
	[Token(Token = "0x60004A6")]
	[Address(RVA = "0x1D8B354", Offset = "0x1D8B354", VA = "0x1D8B354")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004A7 RID: 1191 RVA: 0x0001BCE0 File Offset: 0x00019EE0
	[Token(Token = "0x60004A7")]
	[Address(RVA = "0x1D8B3BC", Offset = "0x1D8B3BC", VA = "0x1D8B3BC")]
	private void \u0838ӆڛӑ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004A8 RID: 1192 RVA: 0x0001BD28 File Offset: 0x00019F28
	[Token(Token = "0x60004A8")]
	[Address(RVA = "0x1D8B424", Offset = "0x1D8B424", VA = "0x1D8B424")]
	private void ٴݵۃ\u05AF()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004A9 RID: 1193 RVA: 0x0001BD70 File Offset: 0x00019F70
	[Token(Token = "0x60004A9")]
	[Address(RVA = "0x1D8B48C", Offset = "0x1D8B48C", VA = "0x1D8B48C")]
	public FanRotate()
	{
	}

	// Token: 0x060004AA RID: 1194 RVA: 0x0001BD84 File Offset: 0x00019F84
	[Token(Token = "0x60004AA")]
	[Address(RVA = "0x1D8B494", Offset = "0x1D8B494", VA = "0x1D8B494")]
	private void ں٢ࡡ\u05EC()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004AB RID: 1195 RVA: 0x0001BDCC File Offset: 0x00019FCC
	[Token(Token = "0x60004AB")]
	[Address(RVA = "0x1D8B4FC", Offset = "0x1D8B4FC", VA = "0x1D8B4FC")]
	private void \u07FE\u0882Զ\u066D()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004AC RID: 1196 RVA: 0x0001BE14 File Offset: 0x0001A014
	[Token(Token = "0x60004AC")]
	[Address(RVA = "0x1D8B564", Offset = "0x1D8B564", VA = "0x1D8B564")]
	private void ڃրӢԖ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004AD RID: 1197 RVA: 0x0001BE5C File Offset: 0x0001A05C
	[Token(Token = "0x60004AD")]
	[Address(RVA = "0x1D8B5CC", Offset = "0x1D8B5CC", VA = "0x1D8B5CC")]
	private void ԟ\u086Cޣ\u055E()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004AE RID: 1198 RVA: 0x0001BEA4 File Offset: 0x0001A0A4
	[Token(Token = "0x60004AE")]
	[Address(RVA = "0x1D8B634", Offset = "0x1D8B634", VA = "0x1D8B634")]
	private void \u0654ޛ\u07FAذ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004AF RID: 1199 RVA: 0x0001BEEC File Offset: 0x0001A0EC
	[Token(Token = "0x60004AF")]
	[Address(RVA = "0x1D8B69C", Offset = "0x1D8B69C", VA = "0x1D8B69C")]
	private void ࢫ\u0876չՍ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004B0 RID: 1200 RVA: 0x0001BF34 File Offset: 0x0001A134
	[Token(Token = "0x60004B0")]
	[Address(RVA = "0x1D8B704", Offset = "0x1D8B704", VA = "0x1D8B704")]
	private void ԣԭՋࠏ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004B1 RID: 1201 RVA: 0x0001BF7C File Offset: 0x0001A17C
	[Token(Token = "0x60004B1")]
	[Address(RVA = "0x1D8B76C", Offset = "0x1D8B76C", VA = "0x1D8B76C")]
	private void څࡣڐ\u0657()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004B2 RID: 1202 RVA: 0x0001BFC4 File Offset: 0x0001A1C4
	[Token(Token = "0x60004B2")]
	[Address(RVA = "0x1D8B7D4", Offset = "0x1D8B7D4", VA = "0x1D8B7D4")]
	private void Ӣ\u0592ߨׯ()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004B3 RID: 1203 RVA: 0x0001C00C File Offset: 0x0001A20C
	[Token(Token = "0x60004B3")]
	[Address(RVA = "0x1D8B83C", Offset = "0x1D8B83C", VA = "0x1D8B83C")]
	private void \u070Aәޣے()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004B4 RID: 1204 RVA: 0x0001C054 File Offset: 0x0001A254
	[Token(Token = "0x60004B4")]
	[Address(RVA = "0x1D8B8A4", Offset = "0x1D8B8A4", VA = "0x1D8B8A4")]
	private void \u0614ࢥӴ\u086C()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004B5 RID: 1205 RVA: 0x0001C09C File Offset: 0x0001A29C
	[Token(Token = "0x60004B5")]
	[Address(RVA = "0x1D8B90C", Offset = "0x1D8B90C", VA = "0x1D8B90C")]
	private void Ҽ\u08B5ځ\u0658()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004B6 RID: 1206 RVA: 0x0001C0E4 File Offset: 0x0001A2E4
	[Token(Token = "0x60004B6")]
	[Address(RVA = "0x1D8B974", Offset = "0x1D8B974", VA = "0x1D8B974")]
	private void \u0599ږࠆ\u065F()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060004B7 RID: 1207 RVA: 0x0001C12C File Offset: 0x0001A32C
	[Token(Token = "0x60004B7")]
	[Address(RVA = "0x1D8B9DC", Offset = "0x1D8B9DC", VA = "0x1D8B9DC")]
	private void \u0821\u059Fӕ\u0607()
	{
		Transform transform = base.transform;
		float x = this.ց\u058Fڷࠏ.x;
		float y = this.ց\u058Fڷࠏ.y;
		float z = this.ց\u058Fڷࠏ.z;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x040000C7 RID: 199
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000C7")]
	public Vector3 ց\u058Fڷࠏ;
}
