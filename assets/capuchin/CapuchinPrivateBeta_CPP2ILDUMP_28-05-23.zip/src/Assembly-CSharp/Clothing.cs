﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000A5 RID: 165
[Token(Token = "0x20000A5")]
public class Clothing : MonoBehaviour
{
	// Token: 0x060018DB RID: 6363 RVA: 0x00087F88 File Offset: 0x00086188
	[Token(Token = "0x60018DB")]
	[Address(RVA = "0x292317C", Offset = "0x292317C", VA = "0x292317C")]
	private void Ӣ\u0592ߨׯ()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018DC RID: 6364 RVA: 0x00087FC4 File Offset: 0x000861C4
	[Token(Token = "0x60018DC")]
	[Address(RVA = "0x29231FC", Offset = "0x29231FC", VA = "0x29231FC")]
	private void ւࡂ\u0883\u0872()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018DD RID: 6365 RVA: 0x00088000 File Offset: 0x00086200
	[Token(Token = "0x60018DD")]
	[Address(RVA = "0x292327C", Offset = "0x292327C", VA = "0x292327C")]
	private void \u05F7ԝߠӱ()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018DE RID: 6366 RVA: 0x0008803C File Offset: 0x0008623C
	[Token(Token = "0x60018DE")]
	[Address(RVA = "0x29232FC", Offset = "0x29232FC", VA = "0x29232FC")]
	private void ފՖߢ\u059B()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018DF RID: 6367 RVA: 0x00088078 File Offset: 0x00086278
	[Token(Token = "0x60018DF")]
	[Address(RVA = "0x292337C", Offset = "0x292337C", VA = "0x292337C")]
	private void \u0881ݗӟ\u07BD()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018E0 RID: 6368 RVA: 0x000880B4 File Offset: 0x000862B4
	[Token(Token = "0x60018E0")]
	[Address(RVA = "0x29233FC", Offset = "0x29233FC", VA = "0x29233FC")]
	private void ժ\u065Dԯࡘ()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018E1 RID: 6369 RVA: 0x000880F0 File Offset: 0x000862F0
	[Token(Token = "0x60018E1")]
	[Address(RVA = "0x292347C", Offset = "0x292347C", VA = "0x292347C")]
	private void ԣԭՋࠏ()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018E2 RID: 6370 RVA: 0x0008812C File Offset: 0x0008632C
	[Token(Token = "0x60018E2")]
	[Address(RVA = "0x29234FC", Offset = "0x29234FC", VA = "0x29234FC")]
	private void \u087BӦןݩ()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018E3 RID: 6371 RVA: 0x00088168 File Offset: 0x00086368
	[Token(Token = "0x60018E3")]
	[Address(RVA = "0x292357C", Offset = "0x292357C", VA = "0x292357C")]
	private void \u0732ڙԒࢺ()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018E4 RID: 6372 RVA: 0x000881A4 File Offset: 0x000863A4
	[Token(Token = "0x60018E4")]
	[Address(RVA = "0x29235FC", Offset = "0x29235FC", VA = "0x29235FC")]
	private void ԟ\u086Cޣ\u055E()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018E5 RID: 6373 RVA: 0x000881E0 File Offset: 0x000863E0
	[Token(Token = "0x60018E5")]
	[Address(RVA = "0x292367C", Offset = "0x292367C", VA = "0x292367C")]
	private void \u05EDց\u081Cت()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018E6 RID: 6374 RVA: 0x0008821C File Offset: 0x0008641C
	[Token(Token = "0x60018E6")]
	[Address(RVA = "0x29236FC", Offset = "0x29236FC", VA = "0x29236FC")]
	private void ڃրӢԖ()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018E7 RID: 6375 RVA: 0x00088258 File Offset: 0x00086458
	[Token(Token = "0x60018E7")]
	[Address(RVA = "0x292377C", Offset = "0x292377C", VA = "0x292377C")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018E8 RID: 6376 RVA: 0x00088294 File Offset: 0x00086494
	[Token(Token = "0x60018E8")]
	[Address(RVA = "0x29237FC", Offset = "0x29237FC", VA = "0x29237FC")]
	private void Update()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018E9 RID: 6377 RVA: 0x000882D0 File Offset: 0x000864D0
	[Token(Token = "0x60018E9")]
	[Address(RVA = "0x292387C", Offset = "0x292387C", VA = "0x292387C")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		Transform transform = base.transform;
		Vector3 position = transform.position;
		Quaternion rotation = transform.transform.rotation;
	}

	// Token: 0x060018EA RID: 6378 RVA: 0x00088300 File Offset: 0x00086500
	[Token(Token = "0x60018EA")]
	[Address(RVA = "0x29238FC", Offset = "0x29238FC", VA = "0x29238FC")]
	private void ٴݵۃ\u05AF()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018EB RID: 6379 RVA: 0x0008833C File Offset: 0x0008653C
	[Token(Token = "0x60018EB")]
	[Address(RVA = "0x292397C", Offset = "0x292397C", VA = "0x292397C")]
	private void ڑߒجވ()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018EC RID: 6380 RVA: 0x00088378 File Offset: 0x00086578
	[Token(Token = "0x60018EC")]
	[Address(RVA = "0x29239FC", Offset = "0x29239FC", VA = "0x29239FC")]
	private void ں٢ࡡ\u05EC()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018ED RID: 6381 RVA: 0x000883B4 File Offset: 0x000865B4
	[Token(Token = "0x60018ED")]
	[Address(RVA = "0x2923A7C", Offset = "0x2923A7C", VA = "0x2923A7C")]
	public Clothing()
	{
	}

	// Token: 0x060018EE RID: 6382 RVA: 0x000883C8 File Offset: 0x000865C8
	[Token(Token = "0x60018EE")]
	[Address(RVA = "0x2923A84", Offset = "0x2923A84", VA = "0x2923A84")]
	private void \u0654ޛ\u07FAذ()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018EF RID: 6383 RVA: 0x00088404 File Offset: 0x00086604
	[Token(Token = "0x60018EF")]
	[Address(RVA = "0x2923B04", Offset = "0x2923B04", VA = "0x2923B04")]
	private void څࡣڐ\u0657()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018F0 RID: 6384 RVA: 0x00088438 File Offset: 0x00086638
	[Token(Token = "0x60018F0")]
	[Address(RVA = "0x2923B84", Offset = "0x2923B84", VA = "0x2923B84")]
	private void \u061B\u05EEوۈ()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018F1 RID: 6385 RVA: 0x00088474 File Offset: 0x00086674
	[Token(Token = "0x60018F1")]
	[Address(RVA = "0x2923C04", Offset = "0x2923C04", VA = "0x2923C04")]
	private void \u070Aәޣے()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x060018F2 RID: 6386 RVA: 0x000884B0 File Offset: 0x000866B0
	[Token(Token = "0x60018F2")]
	[Address(RVA = "0x2923C84", Offset = "0x2923C84", VA = "0x2923C84")]
	private void Ҿࢹؼס()
	{
		Transform transform = base.transform;
		Vector3 position = this.\u083Eڻ\u073Cٲ.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.\u083Eڻ\u073Cٲ.rotation;
	}

	// Token: 0x0400030C RID: 780
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400030C")]
	public Transform \u083Eڻ\u073Cٲ;
}
