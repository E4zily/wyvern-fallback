﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200002B RID: 43
[Token(Token = "0x200002B")]
public class HandScriptNetwork : MonoBehaviour
{
	// Token: 0x060004F0 RID: 1264 RVA: 0x0001D314 File Offset: 0x0001B514
	[Token(Token = "0x60004F0")]
	[Address(RVA = "0x2752CA0", Offset = "0x2752CA0", VA = "0x2752CA0")]
	public void \u0558ݕݤݮ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004F1 RID: 1265 RVA: 0x0001D348 File Offset: 0x0001B548
	[Token(Token = "0x60004F1")]
	[Address(RVA = "0x2752CDC", Offset = "0x2752CDC", VA = "0x2752CDC")]
	public void ࡩݮڢՠ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004F2 RID: 1266 RVA: 0x0001D37C File Offset: 0x0001B57C
	[Token(Token = "0x60004F2")]
	[Address(RVA = "0x2752D18", Offset = "0x2752D18", VA = "0x2752D18")]
	public void ݤۅࢦӃ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004F3 RID: 1267 RVA: 0x0001D3B0 File Offset: 0x0001B5B0
	[Token(Token = "0x60004F3")]
	[Address(RVA = "0x2752D54", Offset = "0x2752D54", VA = "0x2752D54")]
	public void ۆڛߟ\u05A0()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004F4 RID: 1268 RVA: 0x0001D3E4 File Offset: 0x0001B5E4
	[Token(Token = "0x60004F4")]
	[Address(RVA = "0x2752D90", Offset = "0x2752D90", VA = "0x2752D90")]
	public void ݱ\u0832ݥ\u08B5()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004F5 RID: 1269 RVA: 0x0001D418 File Offset: 0x0001B618
	[Token(Token = "0x60004F5")]
	[Address(RVA = "0x2752DCC", Offset = "0x2752DCC", VA = "0x2752DCC")]
	public void ݸԲ\u0616Ԫ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004F6 RID: 1270 RVA: 0x0001D44C File Offset: 0x0001B64C
	[Token(Token = "0x60004F6")]
	[Address(RVA = "0x2752E08", Offset = "0x2752E08", VA = "0x2752E08")]
	public void \u065F\u0839ܤ\u073C()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004F7 RID: 1271 RVA: 0x0001D480 File Offset: 0x0001B680
	[Token(Token = "0x60004F7")]
	[Address(RVA = "0x2752E44", Offset = "0x2752E44", VA = "0x2752E44")]
	public void ࢰחڵࡓ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004F8 RID: 1272 RVA: 0x0001D4B4 File Offset: 0x0001B6B4
	[Token(Token = "0x60004F8")]
	[Address(RVA = "0x2752E80", Offset = "0x2752E80", VA = "0x2752E80")]
	public void Start()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004F9 RID: 1273 RVA: 0x0001D4E8 File Offset: 0x0001B6E8
	[Token(Token = "0x60004F9")]
	[Address(RVA = "0x2752EBC", Offset = "0x2752EBC", VA = "0x2752EBC")]
	public void הԥ\u05B5ݴ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004FA RID: 1274 RVA: 0x0001D51C File Offset: 0x0001B71C
	[Token(Token = "0x60004FA")]
	[Address(RVA = "0x2752EF8", Offset = "0x2752EF8", VA = "0x2752EF8")]
	public void וࡪךӧ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004FB RID: 1275 RVA: 0x0001D550 File Offset: 0x0001B750
	[Token(Token = "0x60004FB")]
	[Address(RVA = "0x2752F34", Offset = "0x2752F34", VA = "0x2752F34")]
	public void \u05ABݿࡋ\u06E9()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004FC RID: 1276 RVA: 0x0001D584 File Offset: 0x0001B784
	[Token(Token = "0x60004FC")]
	[Address(RVA = "0x2752F70", Offset = "0x2752F70", VA = "0x2752F70")]
	public void \u0656ӺմՁ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004FD RID: 1277 RVA: 0x0001D5B8 File Offset: 0x0001B7B8
	[Token(Token = "0x60004FD")]
	[Address(RVA = "0x2752FAC", Offset = "0x2752FAC", VA = "0x2752FAC")]
	public void \u086Bԍࡊڭ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004FE RID: 1278 RVA: 0x0001D5EC File Offset: 0x0001B7EC
	[Token(Token = "0x60004FE")]
	[Address(RVA = "0x2752FE8", Offset = "0x2752FE8", VA = "0x2752FE8")]
	public void ןٮ\u061FԺ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x060004FF RID: 1279 RVA: 0x0001D620 File Offset: 0x0001B820
	[Token(Token = "0x60004FF")]
	[Address(RVA = "0x2753024", Offset = "0x2753024", VA = "0x2753024")]
	public void \u06EDٵ۶\u06DB()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000500 RID: 1280 RVA: 0x0001D654 File Offset: 0x0001B854
	[Token(Token = "0x6000500")]
	[Address(RVA = "0x2753060", Offset = "0x2753060", VA = "0x2753060")]
	public void ࢧӾڈց()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000501 RID: 1281 RVA: 0x0001D688 File Offset: 0x0001B888
	[Token(Token = "0x6000501")]
	[Address(RVA = "0x275309C", Offset = "0x275309C", VA = "0x275309C")]
	public void Ԯ\u0883\u0591\u066C()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000502 RID: 1282 RVA: 0x0001D6BC File Offset: 0x0001B8BC
	[Token(Token = "0x6000502")]
	[Address(RVA = "0x27530D8", Offset = "0x27530D8", VA = "0x27530D8")]
	public void ࡅݐ\u082Dք()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x0001D6F0 File Offset: 0x0001B8F0
	[Token(Token = "0x6000503")]
	[Address(RVA = "0x2753114", Offset = "0x2753114", VA = "0x2753114")]
	public void ۮߝڪڐ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x0001D724 File Offset: 0x0001B924
	[Token(Token = "0x6000504")]
	[Address(RVA = "0x2753150", Offset = "0x2753150", VA = "0x2753150")]
	public void ࠏޤݳ\u06DD()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x0001D758 File Offset: 0x0001B958
	[Token(Token = "0x6000505")]
	[Address(RVA = "0x275318C", Offset = "0x275318C", VA = "0x275318C")]
	public void نո\u0599\u0589()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000506 RID: 1286 RVA: 0x0001D78C File Offset: 0x0001B98C
	[Token(Token = "0x6000506")]
	[Address(RVA = "0x27531C8", Offset = "0x27531C8", VA = "0x27531C8")]
	public void \u073BօӁ\u059A()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000507 RID: 1287 RVA: 0x0001D7C0 File Offset: 0x0001B9C0
	[Token(Token = "0x6000507")]
	[Address(RVA = "0x2753204", Offset = "0x2753204", VA = "0x2753204")]
	public HandScriptNetwork()
	{
	}

	// Token: 0x06000508 RID: 1288 RVA: 0x0001D7D4 File Offset: 0x0001B9D4
	[Token(Token = "0x6000508")]
	[Address(RVA = "0x275320C", Offset = "0x275320C", VA = "0x275320C")]
	public void ӭࡖݲ\u05BD()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000509 RID: 1289 RVA: 0x0001D808 File Offset: 0x0001BA08
	[Token(Token = "0x6000509")]
	[Address(RVA = "0x2753248", Offset = "0x2753248", VA = "0x2753248")]
	public void \u070Fߨ\u05B0ۈ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x0001D83C File Offset: 0x0001BA3C
	[Token(Token = "0x600050A")]
	[Address(RVA = "0x2753284", Offset = "0x2753284", VA = "0x2753284")]
	public void \u066D\u05BDې߃()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600050B RID: 1291 RVA: 0x0001D870 File Offset: 0x0001BA70
	[Token(Token = "0x600050B")]
	[Address(RVA = "0x27532C0", Offset = "0x27532C0", VA = "0x27532C0")]
	public void ߖհݣ߀()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x0001D8A4 File Offset: 0x0001BAA4
	[Token(Token = "0x600050C")]
	[Address(RVA = "0x27532FC", Offset = "0x27532FC", VA = "0x27532FC")]
	public void ӛ\u082Eؿڕ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x0001D8D8 File Offset: 0x0001BAD8
	[Token(Token = "0x600050D")]
	[Address(RVA = "0x2753338", Offset = "0x2753338", VA = "0x2753338")]
	public void ߒ\u065EՎࡖ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600050E RID: 1294 RVA: 0x0001D90C File Offset: 0x0001BB0C
	[Token(Token = "0x600050E")]
	[Address(RVA = "0x2753374", Offset = "0x2753374", VA = "0x2753374")]
	public void ޡࠅ\u089Aߔ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600050F RID: 1295 RVA: 0x0001D940 File Offset: 0x0001BB40
	[Token(Token = "0x600050F")]
	[Address(RVA = "0x27533B0", Offset = "0x27533B0", VA = "0x27533B0")]
	public void \u082E\u06EBݼڏ()
	{
		if (this.\u0619\u0881Ԗո.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.ھչձӬ;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x040000CA RID: 202
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000CA")]
	public HandScript ھչձӬ;

	// Token: 0x040000CB RID: 203
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000CB")]
	public PhotonView \u0619\u0881Ԗո;
}
