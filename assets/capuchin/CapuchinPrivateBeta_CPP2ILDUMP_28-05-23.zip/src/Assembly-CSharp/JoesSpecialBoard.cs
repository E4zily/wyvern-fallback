﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x020000C1 RID: 193
[Token(Token = "0x20000C1")]
public class JoesSpecialBoard : MonoBehaviour
{
	// Token: 0x06001C63 RID: 7267 RVA: 0x00092F7C File Offset: 0x0009117C
	[Token(Token = "0x6001C63")]
	[Address(RVA = "0x2757878", Offset = "0x2757878", VA = "0x2757878")]
	public void ߨױ\u083Bӵ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C64 RID: 7268 RVA: 0x00092FE0 File Offset: 0x000911E0
	[Token(Token = "0x6001C64")]
	[Address(RVA = "0x2757944", Offset = "0x2757944", VA = "0x2757944")]
	private void ژךՈ\u0597()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ڈ\u07EF\u074Bࢮ();
			long ի߆_u0591ԥ = 1L;
			this.ի߆\u0591ԥ = (ի߆_u0591ԥ != 0L);
		}
	}

	// Token: 0x06001C65 RID: 7269 RVA: 0x00093004 File Offset: 0x00091204
	[Token(Token = "0x6001C65")]
	[Address(RVA = "0x2757A40", Offset = "0x2757A40", VA = "0x2757A40")]
	private void \u0590\u0882\u0883ࡦ()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ۺ\u07B4\u070D\u0605();
			long ի߆_u0591ԥ = 1L;
			this.ի߆\u0591ԥ = (ի߆_u0591ԥ != 0L);
		}
	}

	// Token: 0x06001C66 RID: 7270 RVA: 0x00093028 File Offset: 0x00091228
	[Token(Token = "0x6001C66")]
	[Address(RVA = "0x2757B3C", Offset = "0x2757B3C", VA = "0x2757B3C")]
	private void \u066A\u059Eټ\u085A()
	{
		this.ڈ\u07EF\u074Bࢮ();
	}

	// Token: 0x06001C67 RID: 7271 RVA: 0x0009303C File Offset: 0x0009123C
	[Token(Token = "0x6001C67")]
	[Address(RVA = "0x2757974", Offset = "0x2757974", VA = "0x2757974")]
	public void ڈ\u07EF\u074Bࢮ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C68 RID: 7272 RVA: 0x000930A0 File Offset: 0x000912A0
	[Token(Token = "0x6001C68")]
	[Address(RVA = "0x2757B40", Offset = "0x2757B40", VA = "0x2757B40")]
	private void \u082E\u06EBݼڏ()
	{
		this.\u06E3\u05FE\u065Cԗ();
	}

	// Token: 0x06001C69 RID: 7273 RVA: 0x000930B4 File Offset: 0x000912B4
	[Token(Token = "0x6001C69")]
	[Address(RVA = "0x2757C10", Offset = "0x2757C10", VA = "0x2757C10")]
	private void Start()
	{
		this.Ӕڴԯߑ();
	}

	// Token: 0x06001C6A RID: 7274 RVA: 0x000930C8 File Offset: 0x000912C8
	[Token(Token = "0x6001C6A")]
	[Address(RVA = "0x2757CE0", Offset = "0x2757CE0", VA = "0x2757CE0")]
	public JoesSpecialBoard()
	{
	}

	// Token: 0x06001C6B RID: 7275 RVA: 0x000930DC File Offset: 0x000912DC
	[Token(Token = "0x6001C6B")]
	[Address(RVA = "0x2757CE8", Offset = "0x2757CE8", VA = "0x2757CE8")]
	public void ӄߪ\u070Eߐ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C6C RID: 7276 RVA: 0x00093128 File Offset: 0x00091328
	[Token(Token = "0x6001C6C")]
	[Address(RVA = "0x2757DB4", Offset = "0x2757DB4", VA = "0x2757DB4")]
	private void \u07B2\u0823ծݠ()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.נ\u0701\u086C\u05AC();
			long ի߆_u0591ԥ = 1L;
			this.ի߆\u0591ԥ = (ի߆_u0591ԥ != 0L);
		}
	}

	// Token: 0x06001C6D RID: 7277 RVA: 0x0009314C File Offset: 0x0009134C
	[Token(Token = "0x6001C6D")]
	[Address(RVA = "0x2757EB0", Offset = "0x2757EB0", VA = "0x2757EB0")]
	private void ࢶ٠\u086D\u0708()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ۑ\u0655އࡧ();
			long ի߆_u0591ԥ = 1L;
			this.ի߆\u0591ԥ = (ի߆_u0591ԥ != 0L);
		}
	}

	// Token: 0x06001C6E RID: 7278 RVA: 0x00093170 File Offset: 0x00091370
	[Token(Token = "0x6001C6E")]
	[Address(RVA = "0x2757FAC", Offset = "0x2757FAC", VA = "0x2757FAC")]
	private void ߁\u0829\u073E\u081A()
	{
		this.ߣ\u082Dࡃس();
	}

	// Token: 0x06001C6F RID: 7279 RVA: 0x00093184 File Offset: 0x00091384
	[Token(Token = "0x6001C6F")]
	[Address(RVA = "0x275807C", Offset = "0x275807C", VA = "0x275807C")]
	private void \u065F\u0839ܤ\u073C()
	{
		this.٥\u07AA۹ࡗ();
	}

	// Token: 0x06001C70 RID: 7280 RVA: 0x00093198 File Offset: 0x00091398
	[Token(Token = "0x6001C70")]
	[Address(RVA = "0x275814C", Offset = "0x275814C", VA = "0x275814C")]
	private void \u05C1ܡԘޘ()
	{
		this.\u05AB\u065Fӡ\u089D();
	}

	// Token: 0x06001C71 RID: 7281 RVA: 0x000931AC File Offset: 0x000913AC
	[Token(Token = "0x6001C71")]
	[Address(RVA = "0x275821C", Offset = "0x275821C", VA = "0x275821C")]
	public void ࢡ\u05C9ڢޖ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C72 RID: 7282 RVA: 0x00093210 File Offset: 0x00091410
	[Token(Token = "0x6001C72")]
	[Address(RVA = "0x27582E8", Offset = "0x27582E8", VA = "0x27582E8")]
	private void \u05ABݿࡋ\u06E9()
	{
		this.ߗݎ\u0833ࡃ();
	}

	// Token: 0x06001C73 RID: 7283 RVA: 0x00093224 File Offset: 0x00091424
	[Token(Token = "0x6001C73")]
	[Address(RVA = "0x27583B8", Offset = "0x27583B8", VA = "0x27583B8")]
	private void ւࡂ\u0883\u0872()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ӄߪ\u070Eߐ();
		}
	}

	// Token: 0x06001C74 RID: 7284 RVA: 0x00093240 File Offset: 0x00091440
	[Token(Token = "0x6001C74")]
	[Address(RVA = "0x27583E4", Offset = "0x27583E4", VA = "0x27583E4")]
	private void \u06EDٵ۶\u06DB()
	{
		this.נ\u0701\u086C\u05AC();
	}

	// Token: 0x06001C75 RID: 7285 RVA: 0x00093254 File Offset: 0x00091454
	[Token(Token = "0x6001C75")]
	[Address(RVA = "0x27583E8", Offset = "0x27583E8", VA = "0x27583E8")]
	private void ؤ\u05C8ԛ\u083F()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ۺ\u07B4\u070D\u0605();
			long ի߆_u0591ԥ = 1L;
			this.ի߆\u0591ԥ = (ի߆_u0591ԥ != 0L);
		}
	}

	// Token: 0x06001C76 RID: 7286 RVA: 0x000028F3 File Offset: 0x00000AF3
	[Token(Token = "0x6001C76")]
	[Address(RVA = "0x2757B44", Offset = "0x2757B44", VA = "0x2757B44")]
	public void \u06E3\u05FE\u065Cԗ()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C77 RID: 7287 RVA: 0x00093278 File Offset: 0x00091478
	[Token(Token = "0x6001C77")]
	[Address(RVA = "0x2758418", Offset = "0x2758418", VA = "0x2758418")]
	public void إٸޚӣ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C78 RID: 7288 RVA: 0x000932DC File Offset: 0x000914DC
	[Token(Token = "0x6001C78")]
	[Address(RVA = "0x27582EC", Offset = "0x27582EC", VA = "0x27582EC")]
	public void ߗݎ\u0833ࡃ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C79 RID: 7289 RVA: 0x0009333C File Offset: 0x0009153C
	[Token(Token = "0x6001C79")]
	[Address(RVA = "0x27584E4", Offset = "0x27584E4", VA = "0x27584E4")]
	private void \u070Aәޣے()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.Ԛ\u082F\u0606ݴ();
		}
	}

	// Token: 0x06001C7A RID: 7290 RVA: 0x00093358 File Offset: 0x00091558
	[Token(Token = "0x6001C7A")]
	[Address(RVA = "0x27585DC", Offset = "0x27585DC", VA = "0x27585DC")]
	private void Ԯ\u0883\u0591\u066C()
	{
		this.ۺ\u07B4\u070D\u0605();
	}

	// Token: 0x06001C7B RID: 7291 RVA: 0x0009336C File Offset: 0x0009156C
	[Token(Token = "0x6001C7B")]
	[Address(RVA = "0x27585E0", Offset = "0x27585E0", VA = "0x27585E0")]
	private void \u058EԸس\u0819()
	{
		this.ӯ\u083AӚ\u088A();
	}

	// Token: 0x06001C7C RID: 7292 RVA: 0x00093380 File Offset: 0x00091580
	[Token(Token = "0x6001C7C")]
	[Address(RVA = "0x27586B0", Offset = "0x27586B0", VA = "0x27586B0")]
	private void \u0656ӺմՁ()
	{
		this.ۉ\u085Eڭپ();
	}

	// Token: 0x06001C7D RID: 7293 RVA: 0x00093394 File Offset: 0x00091594
	[Token(Token = "0x6001C7D")]
	[Address(RVA = "0x2758780", Offset = "0x2758780", VA = "0x2758780")]
	private void ݫࢷࠃ\u0820()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ۺ\u07B4\u070D\u0605();
			long ի߆_u0591ԥ = 1L;
			this.ի߆\u0591ԥ = (ի߆_u0591ԥ != 0L);
		}
	}

	// Token: 0x06001C7E RID: 7294 RVA: 0x000933B8 File Offset: 0x000915B8
	[Token(Token = "0x6001C7E")]
	[Address(RVA = "0x27587B0", Offset = "0x27587B0", VA = "0x27587B0")]
	public void Մ\u05F6ݴ\u0830()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
	}

	// Token: 0x06001C7F RID: 7295 RVA: 0x00093414 File Offset: 0x00091614
	[Token(Token = "0x6001C7F")]
	[Address(RVA = "0x275887C", Offset = "0x275887C", VA = "0x275887C")]
	public void Եۿӟԧ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C80 RID: 7296 RVA: 0x00093478 File Offset: 0x00091678
	[Token(Token = "0x6001C80")]
	[Address(RVA = "0x2758948", Offset = "0x2758948", VA = "0x2758948")]
	private void Ӌ\u089C\u0700ܧ()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ߣ\u082Dࡃس();
			long ի߆_u0591ԥ = 1L;
			this.ի߆\u0591ԥ = (ի߆_u0591ԥ != 0L);
		}
	}

	// Token: 0x06001C81 RID: 7297 RVA: 0x0009349C File Offset: 0x0009169C
	[Token(Token = "0x6001C81")]
	[Address(RVA = "0x2758978", Offset = "0x2758978", VA = "0x2758978")]
	private void ࢥ\u081CՕࡋ()
	{
		this.\u089EخԿԟ();
	}

	// Token: 0x06001C82 RID: 7298 RVA: 0x000934B0 File Offset: 0x000916B0
	[Token(Token = "0x6001C82")]
	[Address(RVA = "0x2758A48", Offset = "0x2758A48", VA = "0x2758A48")]
	public void \u082Cݪࠑڈ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
	}

	// Token: 0x06001C83 RID: 7299 RVA: 0x0009350C File Offset: 0x0009170C
	[Token(Token = "0x6001C83")]
	[Address(RVA = "0x2757DE4", Offset = "0x2757DE4", VA = "0x2757DE4")]
	public void נ\u0701\u086C\u05AC()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C84 RID: 7300 RVA: 0x00093570 File Offset: 0x00091770
	[Token(Token = "0x6001C84")]
	[Address(RVA = "0x27586B4", Offset = "0x27586B4", VA = "0x27586B4")]
	public void ۉ\u085Eڭپ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C85 RID: 7301 RVA: 0x000935D4 File Offset: 0x000917D4
	[Token(Token = "0x6001C85")]
	[Address(RVA = "0x2758B14", Offset = "0x2758B14", VA = "0x2758B14")]
	private void ڍ\u058Bݗࡣ()
	{
		this.ߨױ\u083Bӵ();
	}

	// Token: 0x06001C86 RID: 7302 RVA: 0x000935E8 File Offset: 0x000917E8
	[Token(Token = "0x6001C86")]
	[Address(RVA = "0x2758B18", Offset = "0x2758B18", VA = "0x2758B18")]
	private void ݤۅࢦӃ()
	{
		this.א\u083Dܚڼ();
	}

	// Token: 0x06001C87 RID: 7303 RVA: 0x000935FC File Offset: 0x000917FC
	[Token(Token = "0x6001C87")]
	[Address(RVA = "0x2758BE8", Offset = "0x2758BE8", VA = "0x2758BE8")]
	public void է\u0824Ԯ۳()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C88 RID: 7304 RVA: 0x00093660 File Offset: 0x00091860
	[Token(Token = "0x6001C88")]
	[Address(RVA = "0x2758CB4", Offset = "0x2758CB4", VA = "0x2758CB4")]
	public void ԭըځԿ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C89 RID: 7305 RVA: 0x000936C4 File Offset: 0x000918C4
	[Token(Token = "0x6001C89")]
	[Address(RVA = "0x2758D80", Offset = "0x2758D80", VA = "0x2758D80")]
	private void \u0832ࢳޤ\u07B5()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ڈ\u07EF\u074Bࢮ();
		}
	}

	// Token: 0x06001C8A RID: 7306 RVA: 0x000936E0 File Offset: 0x000918E0
	[Token(Token = "0x6001C8A")]
	[Address(RVA = "0x2757A70", Offset = "0x2757A70", VA = "0x2757A70")]
	public void ۺ\u07B4\u070D\u0605()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C8B RID: 7307 RVA: 0x00093744 File Offset: 0x00091944
	[Token(Token = "0x6001C8B")]
	[Address(RVA = "0x2758150", Offset = "0x2758150", VA = "0x2758150")]
	public void \u05AB\u065Fӡ\u089D()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C8C RID: 7308 RVA: 0x000937A8 File Offset: 0x000919A8
	[Token(Token = "0x6001C8C")]
	[Address(RVA = "0x2758DAC", Offset = "0x2758DAC", VA = "0x2758DAC")]
	private void \u070Fߨ\u05B0ۈ()
	{
		this.ߨױ\u083Bӵ();
	}

	// Token: 0x06001C8D RID: 7309 RVA: 0x000937BC File Offset: 0x000919BC
	[Token(Token = "0x6001C8D")]
	[Address(RVA = "0x2758DB0", Offset = "0x2758DB0", VA = "0x2758DB0")]
	public void ޞواڑ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C8E RID: 7310 RVA: 0x00093820 File Offset: 0x00091A20
	[Token(Token = "0x6001C8E")]
	[Address(RVA = "0x2758B1C", Offset = "0x2758B1C", VA = "0x2758B1C")]
	public void א\u083Dܚڼ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C8F RID: 7311 RVA: 0x0009387C File Offset: 0x00091A7C
	[Token(Token = "0x6001C8F")]
	[Address(RVA = "0x2758E7C", Offset = "0x2758E7C", VA = "0x2758E7C")]
	private void ӻӒݝ߃()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ԭըځԿ();
		}
	}

	// Token: 0x06001C90 RID: 7312 RVA: 0x00093898 File Offset: 0x00091A98
	[Token(Token = "0x6001C90")]
	[Address(RVA = "0x2758EA8", Offset = "0x2758EA8", VA = "0x2758EA8")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ߗݎ\u0833ࡃ();
			long ի߆_u0591ԥ = 1L;
			this.ի߆\u0591ԥ = (ի߆_u0591ԥ != 0L);
		}
	}

	// Token: 0x06001C91 RID: 7313 RVA: 0x000938BC File Offset: 0x00091ABC
	[Token(Token = "0x6001C91")]
	[Address(RVA = "0x2758ED8", Offset = "0x2758ED8", VA = "0x2758ED8")]
	private void Ҽ\u08B5ځ\u0658()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ٳޜ\u0896ࠌ();
		}
	}

	// Token: 0x06001C92 RID: 7314 RVA: 0x000938D8 File Offset: 0x00091AD8
	[Token(Token = "0x6001C92")]
	[Address(RVA = "0x2757EE0", Offset = "0x2757EE0", VA = "0x2757EE0")]
	public void ۑ\u0655އࡧ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C93 RID: 7315 RVA: 0x0009393C File Offset: 0x00091B3C
	[Token(Token = "0x6001C93")]
	[Address(RVA = "0x2758FD0", Offset = "0x2758FD0", VA = "0x2758FD0")]
	private void \u0870\u05B3Ց\u066A()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ԭըځԿ();
		}
	}

	// Token: 0x06001C94 RID: 7316 RVA: 0x00093958 File Offset: 0x00091B58
	[Token(Token = "0x6001C94")]
	[Address(RVA = "0x2758FFC", Offset = "0x2758FFC", VA = "0x2758FFC")]
	private void حتݻ\u05B0()
	{
		this.ӯ\u083AӚ\u088A();
	}

	// Token: 0x06001C95 RID: 7317 RVA: 0x0009396C File Offset: 0x00091B6C
	[Token(Token = "0x6001C95")]
	[Address(RVA = "0x2759000", Offset = "0x2759000", VA = "0x2759000")]
	private void ڃրӢԖ()
	{
		this.Ԛ\u082F\u0606ݴ();
	}

	// Token: 0x06001C96 RID: 7318 RVA: 0x00093980 File Offset: 0x00091B80
	[Token(Token = "0x6001C96")]
	[Address(RVA = "0x275902C", Offset = "0x275902C", VA = "0x275902C")]
	private void ߉ې\u07F6Ӭ()
	{
		this.\u06E3\u05FE\u065Cԗ();
	}

	// Token: 0x06001C97 RID: 7319 RVA: 0x00093994 File Offset: 0x00091B94
	[Token(Token = "0x6001C97")]
	[Address(RVA = "0x275897C", Offset = "0x275897C", VA = "0x275897C")]
	public void \u089EخԿԟ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C98 RID: 7320 RVA: 0x000939F8 File Offset: 0x00091BF8
	[Token(Token = "0x6001C98")]
	[Address(RVA = "0x27585E4", Offset = "0x27585E4", VA = "0x27585E4")]
	public void ӯ\u083AӚ\u088A()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C99 RID: 7321 RVA: 0x00093A5C File Offset: 0x00091C5C
	[Token(Token = "0x6001C99")]
	[Address(RVA = "0x2759030", Offset = "0x2759030", VA = "0x2759030")]
	private void չւت\u061E()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.Ӕڴԯߑ();
			long ի߆_u0591ԥ = 1L;
			this.ի߆\u0591ԥ = (ի߆_u0591ԥ != 0L);
		}
	}

	// Token: 0x06001C9A RID: 7322 RVA: 0x00093A80 File Offset: 0x00091C80
	[Token(Token = "0x6001C9A")]
	[Address(RVA = "0x2759060", Offset = "0x2759060", VA = "0x2759060")]
	public void \u05A1ۉ\u07AFߔ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
	}

	// Token: 0x06001C9B RID: 7323 RVA: 0x00093ADC File Offset: 0x00091CDC
	[Token(Token = "0x6001C9B")]
	[Address(RVA = "0x275912C", Offset = "0x275912C", VA = "0x275912C")]
	public void \u07FDڳء\u0557()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C9C RID: 7324 RVA: 0x00093B40 File Offset: 0x00091D40
	[Token(Token = "0x6001C9C")]
	[Address(RVA = "0x27591F8", Offset = "0x27591F8", VA = "0x27591F8")]
	private void \u060B\u0614\u0821ע()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ԭըځԿ();
		}
	}

	// Token: 0x06001C9D RID: 7325 RVA: 0x00093B5C File Offset: 0x00091D5C
	[Token(Token = "0x6001C9D")]
	[Address(RVA = "0x2758510", Offset = "0x2758510", VA = "0x2758510")]
	public void Ԛ\u082F\u0606ݴ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001C9E RID: 7326 RVA: 0x00093BC0 File Offset: 0x00091DC0
	[Token(Token = "0x6001C9E")]
	[Address(RVA = "0x2759224", Offset = "0x2759224", VA = "0x2759224")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.ߨױ\u083Bӵ();
		}
	}

	// Token: 0x06001C9F RID: 7327 RVA: 0x00093BDC File Offset: 0x00091DDC
	[Token(Token = "0x6001C9F")]
	[Address(RVA = "0x2759250", Offset = "0x2759250", VA = "0x2759250")]
	private void ߄Ӄ\u0613ھ()
	{
		this.ޞواڑ();
	}

	// Token: 0x06001CA0 RID: 7328 RVA: 0x00093BF0 File Offset: 0x00091DF0
	[Token(Token = "0x6001CA0")]
	[Address(RVA = "0x2759254", Offset = "0x2759254", VA = "0x2759254")]
	public void ӥ\u07B2\u07B4ԕ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001CA1 RID: 7329 RVA: 0x00093C54 File Offset: 0x00091E54
	[Token(Token = "0x6001CA1")]
	[Address(RVA = "0x2757C14", Offset = "0x2757C14", VA = "0x2757C14")]
	public void Ӕڴԯߑ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001CA2 RID: 7330 RVA: 0x00093CB0 File Offset: 0x00091EB0
	[Token(Token = "0x6001CA2")]
	[Address(RVA = "0x2757FB0", Offset = "0x2757FB0", VA = "0x2757FB0")]
	public void ߣ\u082Dࡃس()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001CA3 RID: 7331 RVA: 0x00093D10 File Offset: 0x00091F10
	[Token(Token = "0x6001CA3")]
	[Address(RVA = "0x2758F04", Offset = "0x2758F04", VA = "0x2758F04")]
	public void ٳޜ\u0896ࠌ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x06001CA4 RID: 7332 RVA: 0x00093D74 File Offset: 0x00091F74
	[Token(Token = "0x6001CA4")]
	[Address(RVA = "0x2759320", Offset = "0x2759320", VA = "0x2759320")]
	private void Update()
	{
		if (this.ի߆\u0591ԥ)
		{
			this.Ӕڴԯߑ();
		}
	}

	// Token: 0x06001CA5 RID: 7333 RVA: 0x00093D90 File Offset: 0x00091F90
	[Token(Token = "0x6001CA5")]
	[Address(RVA = "0x275934C", Offset = "0x275934C", VA = "0x275934C")]
	private void ޠۋ\u0530\u073E()
	{
		this.ԭըځԿ();
	}

	// Token: 0x06001CA6 RID: 7334 RVA: 0x00093DA4 File Offset: 0x00091FA4
	[Token(Token = "0x6001CA6")]
	[Address(RVA = "0x2758080", Offset = "0x2758080", VA = "0x2758080")]
	public void ٥\u07AA۹ࡗ()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.ؤ\u0655Ӆ\u06E1 = component;
		float ࢦ_u070Fݦۀ = this.ࢦ\u070Fݦۀ;
		float u05C7_u05CEԝ_u07FB = this.\u05C7\u05CEԝ\u07FB;
		this.\u07B4ސࠊմ = u05C7_u05CEԝ_u07FB;
		float f;
		int u05C0ӆӍش = Mathf.RoundToInt(f);
		string[] array = this.ӏ߁۳ڋ;
		this.\u05C0ӆӍش = u05C0ӆӍش;
		this.ݼԧӦӆ = component;
	}

	// Token: 0x040003B1 RID: 945
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003B1")]
	public string[] ӏ߁۳ڋ;

	// Token: 0x040003B2 RID: 946
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003B2")]
	public float \u07B4ސࠊմ;

	// Token: 0x040003B3 RID: 947
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x40003B3")]
	public int \u05C0ӆӍش;

	// Token: 0x040003B4 RID: 948
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003B4")]
	public float ࢦ\u070Fݦۀ;

	// Token: 0x040003B5 RID: 949
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x40003B5")]
	public float \u05C7\u05CEԝ\u07FB;

	// Token: 0x040003B6 RID: 950
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003B6")]
	public string ݼԧӦӆ;

	// Token: 0x040003B7 RID: 951
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40003B7")]
	private TextMeshPro ؤ\u0655Ӆ\u06E1;

	// Token: 0x040003B8 RID: 952
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40003B8")]
	public bool ի߆\u0591ԥ;
}
