﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200003C RID: 60
[Token(Token = "0x200003C")]
public class Push : MonoBehaviour
{
	// Token: 0x06000811 RID: 2065 RVA: 0x0002C134 File Offset: 0x0002A334
	[Token(Token = "0x6000811")]
	[Address(RVA = "0x2F96FAC", Offset = "0x2F96FAC", VA = "0x2F96FAC")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You are not the master of the server, you cannot start the game.";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000812 RID: 2066 RVA: 0x0002C1AC File Offset: 0x0002A3AC
	[Token(Token = "0x6000812")]
	[Address(RVA = "0x2F970A4", Offset = "0x2F970A4", VA = "0x2F970A4")]
	public void \u0732ڙԒࢺ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000813 RID: 2067 RVA: 0x0002C220 File Offset: 0x0002A420
	[Token(Token = "0x6000813")]
	[Address(RVA = "0x2F9713C", Offset = "0x2F9713C", VA = "0x2F9713C")]
	public void յߪؾՀ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000814 RID: 2068 RVA: 0x0002C294 File Offset: 0x0002A494
	[Token(Token = "0x6000814")]
	[Address(RVA = "0x2F971DC", Offset = "0x2F971DC", VA = "0x2F971DC")]
	public void \u05F7ԝߠӱ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x06000815 RID: 2069 RVA: 0x0002C2FC File Offset: 0x0002A4FC
	[Token(Token = "0x6000815")]
	[Address(RVA = "0x2F9726C", Offset = "0x2F9726C", VA = "0x2F9726C")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ChangeToTagged";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x06000816 RID: 2070 RVA: 0x0002C36C File Offset: 0x0002A56C
	[Token(Token = "0x6000816")]
	[Address(RVA = "0x2F97364", Offset = "0x2F97364", VA = "0x2F97364")]
	public void \u0821\u059Fӕ\u0607()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x06000817 RID: 2071 RVA: 0x0002C3D4 File Offset: 0x0002A5D4
	[Token(Token = "0x6000817")]
	[Address(RVA = "0x2F973F8", Offset = "0x2F973F8", VA = "0x2F973F8")]
	public void \u0838ӆڛӑ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000818 RID: 2072 RVA: 0x0002C448 File Offset: 0x0002A648
	[Token(Token = "0x6000818")]
	[Address(RVA = "0x2F9748C", Offset = "0x2F9748C", VA = "0x2F9748C")]
	public void ࡦݢݚԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Game Started";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000819 RID: 2073 RVA: 0x0002C4C0 File Offset: 0x0002A6C0
	[Token(Token = "0x6000819")]
	[Address(RVA = "0x2F97584", Offset = "0x2F97584", VA = "0x2F97584")]
	public void \u070Aәޣے()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600081A RID: 2074 RVA: 0x0002C534 File Offset: 0x0002A734
	[Token(Token = "0x600081A")]
	[Address(RVA = "0x2F9761C", Offset = "0x2F9761C", VA = "0x2F9761C")]
	public void \u07F7ܙײ\u05B5()
	{
		if (this.\u082AյڲӺ)
		{
			if (this.\u07AFշ\u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600081B RID: 2075 RVA: 0x0002C59C File Offset: 0x0002A79C
	[Token(Token = "0x600081B")]
	[Address(RVA = "0x2F976B0", Offset = "0x2F976B0", VA = "0x2F976B0")]
	public void \u05B3ࢹߧ\u07AA()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x0600081C RID: 2076 RVA: 0x0002C604 File Offset: 0x0002A804
	[Token(Token = "0x600081C")]
	[Address(RVA = "0x2F97740", Offset = "0x2F97740", VA = "0x2F97740")]
	public void ԟ\u086Cޣ\u055E()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600081D RID: 2077 RVA: 0x0002C678 File Offset: 0x0002A878
	[Token(Token = "0x600081D")]
	[Address(RVA = "0x2F977D8", Offset = "0x2F977D8", VA = "0x2F977D8")]
	public void ࡕߕ\u0707ݩ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600081E RID: 2078 RVA: 0x0002C6EC File Offset: 0x0002A8EC
	[Token(Token = "0x600081E")]
	[Address(RVA = "0x2F97870", Offset = "0x2F97870", VA = "0x2F97870")]
	public void ى߁ٱՏ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600081F RID: 2079 RVA: 0x0002C760 File Offset: 0x0002A960
	[Token(Token = "0x600081F")]
	[Address(RVA = "0x2F97910", Offset = "0x2F97910", VA = "0x2F97910")]
	public void \u0872މࢮՃ()
	{
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		long u082AյڲӺ = 0L;
		this.\u082AյڲӺ = (u082AյڲӺ != 0L);
	}

	// Token: 0x06000820 RID: 2080 RVA: 0x0002C7CC File Offset: 0x0002A9CC
	[Token(Token = "0x6000820")]
	[Address(RVA = "0x2F979B0", Offset = "0x2F979B0", VA = "0x2F979B0")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000821 RID: 2081 RVA: 0x0002C844 File Offset: 0x0002AA44
	[Token(Token = "0x6000821")]
	[Address(RVA = "0x2F97AA8", Offset = "0x2F97AA8", VA = "0x2F97AA8")]
	public Push()
	{
	}

	// Token: 0x06000822 RID: 2082 RVA: 0x0002C858 File Offset: 0x0002AA58
	[Token(Token = "0x6000822")]
	[Address(RVA = "0x2F97AB0", Offset = "0x2F97AB0", VA = "0x2F97AB0")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000823 RID: 2083 RVA: 0x0002C8D0 File Offset: 0x0002AAD0
	[Token(Token = "0x6000823")]
	[Address(RVA = "0x2F97BA8", Offset = "0x2F97BA8", VA = "0x2F97BA8")]
	public void ڑߒجވ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000824 RID: 2084 RVA: 0x0002C944 File Offset: 0x0002AB44
	[Token(Token = "0x6000824")]
	[Address(RVA = "0x2F97C40", Offset = "0x2F97C40", VA = "0x2F97C40")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "typesOfTalk";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000825 RID: 2085 RVA: 0x0002C9BC File Offset: 0x0002ABBC
	[Token(Token = "0x6000825")]
	[Address(RVA = "0x2F97D38", Offset = "0x2F97D38", VA = "0x2F97D38")]
	public void \u07A7ࡐ\u0818ܭ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000826 RID: 2086 RVA: 0x0002CA30 File Offset: 0x0002AC30
	[Token(Token = "0x6000826")]
	[Address(RVA = "0x2F97DD0", Offset = "0x2F97DD0", VA = "0x2F97DD0")]
	public void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == " and for the price of ";
		if (" and for the price of " != null)
		{
			return;
		}
		Vector3 up = \u07FEל\u05AC\u0877.transform.up;
	}

	// Token: 0x06000827 RID: 2087 RVA: 0x0002CA70 File Offset: 0x0002AC70
	[Token(Token = "0x6000827")]
	[Address(RVA = "0x2F97EC8", Offset = "0x2F97EC8", VA = "0x2F97EC8")]
	public void צ\u0874ڵ\u059A()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000828 RID: 2088 RVA: 0x0002CAE4 File Offset: 0x0002ACE4
	[Token(Token = "0x6000828")]
	[Address(RVA = "0x2F97F5C", Offset = "0x2F97F5C", VA = "0x2F97F5C")]
	public void Update()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x06000829 RID: 2089 RVA: 0x0002CB4C File Offset: 0x0002AD4C
	[Token(Token = "0x6000829")]
	[Address(RVA = "0x2F97FEC", Offset = "0x2F97FEC", VA = "0x2F97FEC")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600082A RID: 2090 RVA: 0x0002CBC4 File Offset: 0x0002ADC4
	[Token(Token = "0x600082A")]
	[Address(RVA = "0x2F980E4", Offset = "0x2F980E4", VA = "0x2F980E4")]
	public void \u061Fࡆ\u086F\u07B0()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600082B RID: 2091 RVA: 0x0002CC38 File Offset: 0x0002AE38
	[Token(Token = "0x600082B")]
	[Address(RVA = "0x2F98184", Offset = "0x2F98184", VA = "0x2F98184")]
	public void ڦکӁ\u06E2()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600082C RID: 2092 RVA: 0x0002CCAC File Offset: 0x0002AEAC
	[Token(Token = "0x600082C")]
	[Address(RVA = "0x2F98218", Offset = "0x2F98218", VA = "0x2F98218")]
	public void \u0886Ҽ\u058Dߛ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600082D RID: 2093 RVA: 0x0002CD20 File Offset: 0x0002AF20
	[Token(Token = "0x600082D")]
	[Address(RVA = "0x2F982B0", Offset = "0x2F982B0", VA = "0x2F982B0")]
	public void ؤ\u05C8ԛ\u083F()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x0600082E RID: 2094 RVA: 0x0002CD88 File Offset: 0x0002AF88
	[Token(Token = "0x600082E")]
	[Address(RVA = "0x2F98340", Offset = "0x2F98340", VA = "0x2F98340")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600082F RID: 2095 RVA: 0x0002CE00 File Offset: 0x0002B000
	[Token(Token = "0x600082F")]
	[Address(RVA = "0x2F98438", Offset = "0x2F98438", VA = "0x2F98438")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000830 RID: 2096 RVA: 0x0002CE78 File Offset: 0x0002B078
	[Token(Token = "0x6000830")]
	[Address(RVA = "0x2F98530", Offset = "0x2F98530", VA = "0x2F98530")]
	public void פۈيݤ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000831 RID: 2097 RVA: 0x0002CEEC File Offset: 0x0002B0EC
	[Token(Token = "0x6000831")]
	[Address(RVA = "0x2F985C8", Offset = "0x2F985C8", VA = "0x2F985C8")]
	public void ފՖߢ\u059B()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000832 RID: 2098 RVA: 0x0002CF60 File Offset: 0x0002B160
	[Token(Token = "0x6000832")]
	[Address(RVA = "0x2F98660", Offset = "0x2F98660", VA = "0x2F98660")]
	public void ܪ\u07BB\u086Bࠆ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x06000833 RID: 2099 RVA: 0x0002CFC8 File Offset: 0x0002B1C8
	[Token(Token = "0x6000833")]
	[Address(RVA = "0x2F986F4", Offset = "0x2F986F4", VA = "0x2F986F4")]
	public void ւࡂ\u0883\u0872()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000834 RID: 2100 RVA: 0x0002D03C File Offset: 0x0002B23C
	[Token(Token = "0x6000834")]
	[Address(RVA = "0x2F9878C", Offset = "0x2F9878C", VA = "0x2F9878C")]
	public void ԅ\u073Fڥ\u0839()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000835 RID: 2101 RVA: 0x0002D0B0 File Offset: 0x0002B2B0
	[Token(Token = "0x6000835")]
	[Address(RVA = "0x2F98824", Offset = "0x2F98824", VA = "0x2F98824")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "NetworkPlayer";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000836 RID: 2102 RVA: 0x0002D128 File Offset: 0x0002B328
	[Token(Token = "0x6000836")]
	[Address(RVA = "0x2F9891C", Offset = "0x2F9891C", VA = "0x2F9891C")]
	public void ۅ\u05A6\u05A4ӵ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Not connected to room";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000837 RID: 2103 RVA: 0x0002D1A0 File Offset: 0x0002B3A0
	[Token(Token = "0x6000837")]
	[Address(RVA = "0x2F98A14", Offset = "0x2F98A14", VA = "0x2F98A14")]
	public void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000838 RID: 2104 RVA: 0x0002D218 File Offset: 0x0002B418
	[Token(Token = "0x6000838")]
	[Address(RVA = "0x2F98B0C", Offset = "0x2F98B0C", VA = "0x2F98B0C")]
	public void \u0892ܒܬޓ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000839 RID: 2105 RVA: 0x0002D28C File Offset: 0x0002B48C
	[Token(Token = "0x6000839")]
	[Address(RVA = "0x2F98BA4", Offset = "0x2F98BA4", VA = "0x2F98BA4")]
	public void ࢭ\u0589\u0892\u058A()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x0600083A RID: 2106 RVA: 0x0002D2F4 File Offset: 0x0002B4F4
	[Token(Token = "0x600083A")]
	[Address(RVA = "0x2F98C3C", Offset = "0x2F98C3C", VA = "0x2F98C3C")]
	public void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Player";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600083B RID: 2107 RVA: 0x0002D36C File Offset: 0x0002B56C
	[Token(Token = "0x600083B")]
	[Address(RVA = "0x2F98D34", Offset = "0x2F98D34", VA = "0x2F98D34")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ENABLE";
		if (this.\u07AFշ\u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600083C RID: 2108 RVA: 0x0002D3D8 File Offset: 0x0002B5D8
	[Token(Token = "0x600083C")]
	[Address(RVA = "0x2F98E2C", Offset = "0x2F98E2C", VA = "0x2F98E2C")]
	public void \u07B6կպ߃()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600083D RID: 2109 RVA: 0x0002D44C File Offset: 0x0002B64C
	[Token(Token = "0x600083D")]
	[Address(RVA = "0x2F98EC4", Offset = "0x2F98EC4", VA = "0x2F98EC4")]
	public void \u059Cݝ\u058E۳(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == " and for the price of ";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600083E RID: 2110 RVA: 0x0002D4C4 File Offset: 0x0002B6C4
	[Token(Token = "0x600083E")]
	[Address(RVA = "0x2F98FBC", Offset = "0x2F98FBC", VA = "0x2F98FBC")]
	public void ڷԲ\u0618ރ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600083F RID: 2111 RVA: 0x0002D538 File Offset: 0x0002B738
	[Token(Token = "0x600083F")]
	[Address(RVA = "0x2F99050", Offset = "0x2F99050", VA = "0x2F99050")]
	public void \u06D4ڟڎޜ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000840 RID: 2112 RVA: 0x0002D5A0 File Offset: 0x0002B7A0
	[Token(Token = "0x6000840")]
	[Address(RVA = "0x2F990E8", Offset = "0x2F990E8", VA = "0x2F990E8")]
	public void \u0599ږࠆ\u065F()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000841 RID: 2113 RVA: 0x0002D614 File Offset: 0x0002B814
	[Token(Token = "0x6000841")]
	[Address(RVA = "0x2F99180", Offset = "0x2F99180", VA = "0x2F99180")]
	public void \u05AC\u07F0\u07EEࡥ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000842 RID: 2114 RVA: 0x0002D680 File Offset: 0x0002B880
	[Token(Token = "0x6000842")]
	[Address(RVA = "0x2F99218", Offset = "0x2F99218", VA = "0x2F99218")]
	public void ܫ\u070Fۃ\u07F2()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000843 RID: 2115 RVA: 0x0002D6F4 File Offset: 0x0002B8F4
	[Token(Token = "0x6000843")]
	[Address(RVA = "0x2F992B8", Offset = "0x2F992B8", VA = "0x2F992B8")]
	public void ժ\u065Dԯࡘ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000844 RID: 2116 RVA: 0x0002D768 File Offset: 0x0002B968
	[Token(Token = "0x6000844")]
	[Address(RVA = "0x2F9934C", Offset = "0x2F9934C", VA = "0x2F9934C")]
	public void \u0832ࢳޤ\u07B5()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x06000845 RID: 2117 RVA: 0x0002D7D0 File Offset: 0x0002B9D0
	[Token(Token = "0x6000845")]
	[Address(RVA = "0x2F993DC", Offset = "0x2F993DC", VA = "0x2F993DC")]
	public void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "back";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000846 RID: 2118 RVA: 0x0002D83C File Offset: 0x0002BA3C
	[Token(Token = "0x6000846")]
	[Address(RVA = "0x2F994D4", Offset = "0x2F994D4", VA = "0x2F994D4")]
	public void ԣԭՋࠏ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000847 RID: 2119 RVA: 0x0002D8B0 File Offset: 0x0002BAB0
	[Token(Token = "0x6000847")]
	[Address(RVA = "0x2F99568", Offset = "0x2F99568", VA = "0x2F99568")]
	public void ڰݰ\u060Bۃ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_BumpScale";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000848 RID: 2120 RVA: 0x0002D928 File Offset: 0x0002BB28
	[Token(Token = "0x6000848")]
	[Address(RVA = "0x2F99660", Offset = "0x2F99660", VA = "0x2F99660")]
	public void ࢢ٧\u085DԀ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Wear Hoodie";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000849 RID: 2121 RVA: 0x0002D9A0 File Offset: 0x0002BBA0
	[Token(Token = "0x6000849")]
	[Address(RVA = "0x2F99758", Offset = "0x2F99758", VA = "0x2F99758")]
	public void \u05ABࡡ\u07ABݾ()
	{
		if (this.\u082AյڲӺ)
		{
			if (this.\u07AFշ\u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600084A RID: 2122 RVA: 0x0002DA08 File Offset: 0x0002BC08
	[Token(Token = "0x600084A")]
	[Address(RVA = "0x2F997F8", Offset = "0x2F997F8", VA = "0x2F997F8")]
	public void ߑ\u0885\u05BBߕ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600084B RID: 2123 RVA: 0x0002DA7C File Offset: 0x0002BC7C
	[Token(Token = "0x600084B")]
	[Address(RVA = "0x2F99898", Offset = "0x2F99898", VA = "0x2F99898")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "containsStaff";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600084C RID: 2124 RVA: 0x0002DAF4 File Offset: 0x0002BCF4
	[Token(Token = "0x600084C")]
	[Address(RVA = "0x2F99990", Offset = "0x2F99990", VA = "0x2F99990")]
	public void ٠ӄ\u087Cٸ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600084D RID: 2125 RVA: 0x0002DB68 File Offset: 0x0002BD68
	[Token(Token = "0x600084D")]
	[Address(RVA = "0x2F99A24", Offset = "0x2F99A24", VA = "0x2F99A24")]
	public void ܯר\u05C7ڗ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Holdable";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600084E RID: 2126 RVA: 0x0002DBE0 File Offset: 0x0002BDE0
	[Token(Token = "0x600084E")]
	[Address(RVA = "0x2F99B1C", Offset = "0x2F99B1C", VA = "0x2F99B1C")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "HOLY MOLY THE STICK IS ON FIRE!!!!!!";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600084F RID: 2127 RVA: 0x0002DC58 File Offset: 0x0002BE58
	[Token(Token = "0x600084F")]
	[Address(RVA = "0x2F99C14", Offset = "0x2F99C14", VA = "0x2F99C14")]
	public void \u07F5\u0657\u055Aߍ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000850 RID: 2128 RVA: 0x0002DCCC File Offset: 0x0002BECC
	[Token(Token = "0x6000850")]
	[Address(RVA = "0x2F99CAC", Offset = "0x2F99CAC", VA = "0x2F99CAC")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "DISABLE";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000851 RID: 2129 RVA: 0x0002DD44 File Offset: 0x0002BF44
	[Token(Token = "0x6000851")]
	[Address(RVA = "0x2F99DA4", Offset = "0x2F99DA4", VA = "0x2F99DA4")]
	public void \u07B2\u0823ծݠ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000852 RID: 2130 RVA: 0x0002DDB8 File Offset: 0x0002BFB8
	[Token(Token = "0x6000852")]
	[Address(RVA = "0x2F99E44", Offset = "0x2F99E44", VA = "0x2F99E44")]
	public void Ԉ۴ࡉࢬ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000853 RID: 2131 RVA: 0x0002DE2C File Offset: 0x0002C02C
	[Token(Token = "0x6000853")]
	[Address(RVA = "0x2F99EDC", Offset = "0x2F99EDC", VA = "0x2F99EDC")]
	public void \u074C\u0830\u0594ԡ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000854 RID: 2132 RVA: 0x0002DEA4 File Offset: 0x0002C0A4
	[Token(Token = "0x6000854")]
	[Address(RVA = "0x2F99FD4", Offset = "0x2F99FD4", VA = "0x2F99FD4")]
	public void ࡑ\u086Bߊࢤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Photon token acquired!";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000855 RID: 2133 RVA: 0x0002DF1C File Offset: 0x0002C11C
	[Token(Token = "0x6000855")]
	[Address(RVA = "0x2F9A0CC", Offset = "0x2F9A0CC", VA = "0x2F9A0CC")]
	public void \u073Fߗބݝ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
	}

	// Token: 0x06000856 RID: 2134 RVA: 0x0002DF80 File Offset: 0x0002C180
	[Token(Token = "0x6000856")]
	[Address(RVA = "0x2F9A15C", Offset = "0x2F9A15C", VA = "0x2F9A15C")]
	public void Ԡݘעࠀ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000857 RID: 2135 RVA: 0x0002DFF4 File Offset: 0x0002C1F4
	[Token(Token = "0x6000857")]
	[Address(RVA = "0x2F9A1F4", Offset = "0x2F9A1F4", VA = "0x2F9A1F4")]
	public void \u0705\u0816\u0739դ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000858 RID: 2136 RVA: 0x0002E068 File Offset: 0x0002C268
	[Token(Token = "0x6000858")]
	[Address(RVA = "0x2F9A28C", Offset = "0x2F9A28C", VA = "0x2F9A28C")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayWave";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000859 RID: 2137 RVA: 0x0002E0E0 File Offset: 0x0002C2E0
	[Token(Token = "0x6000859")]
	[Address(RVA = "0x2F9A384", Offset = "0x2F9A384", VA = "0x2F9A384")]
	public void \u05F8ݑ\u06ECߞ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600085A RID: 2138 RVA: 0x0002E154 File Offset: 0x0002C354
	[Token(Token = "0x600085A")]
	[Address(RVA = "0x2F9A418", Offset = "0x2F9A418", VA = "0x2F9A418")]
	public void طӏܙࢺ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600085B RID: 2139 RVA: 0x0002E1C8 File Offset: 0x0002C3C8
	[Token(Token = "0x600085B")]
	[Address(RVA = "0x2F9A4AC", Offset = "0x2F9A4AC", VA = "0x2F9A4AC")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600085C RID: 2140 RVA: 0x0002E240 File Offset: 0x0002C440
	[Token(Token = "0x600085C")]
	[Address(RVA = "0x2F9A5A4", Offset = "0x2F9A5A4", VA = "0x2F9A5A4")]
	public void Ԃ\u058Aܫջ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "NetworkPlayer";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600085D RID: 2141 RVA: 0x0002E2B8 File Offset: 0x0002C4B8
	[Token(Token = "0x600085D")]
	[Address(RVA = "0x2F9A69C", Offset = "0x2F9A69C", VA = "0x2F9A69C")]
	public void \u0614ࢥӴ\u086C()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x0600085E RID: 2142 RVA: 0x0002E320 File Offset: 0x0002C520
	[Token(Token = "0x600085E")]
	[Address(RVA = "0x2F9A72C", Offset = "0x2F9A72C", VA = "0x2F9A72C")]
	public void \u07FB\u07BC\u0887ӟ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x0600085F RID: 2143 RVA: 0x0002E388 File Offset: 0x0002C588
	[Token(Token = "0x600085F")]
	[Address(RVA = "0x2F9A7BC", Offset = "0x2F9A7BC", VA = "0x2F9A7BC")]
	public void ӻӒݝ߃()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000860 RID: 2144 RVA: 0x0002E3FC File Offset: 0x0002C5FC
	[Token(Token = "0x6000860")]
	[Address(RVA = "0x2F9A850", Offset = "0x2F9A850", VA = "0x2F9A850")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000861 RID: 2145 RVA: 0x0002E470 File Offset: 0x0002C670
	[Token(Token = "0x6000861")]
	[Address(RVA = "0x2F9A8E4", Offset = "0x2F9A8E4", VA = "0x2F9A8E4")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "Failed to login, please restart";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = u081B_u070Aߢࡁ.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000862 RID: 2146 RVA: 0x0002E4E4 File Offset: 0x0002C6E4
	[Token(Token = "0x6000862")]
	[Address(RVA = "0x2F9A9DC", Offset = "0x2F9A9DC", VA = "0x2F9A9DC")]
	public void \u0590\u0882\u0883ࡦ()
	{
		if (this.\u082AյڲӺ)
		{
			if (this.\u07AFշ\u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000863 RID: 2147 RVA: 0x0002E54C File Offset: 0x0002C74C
	[Token(Token = "0x6000863")]
	[Address(RVA = "0x2F9AA74", Offset = "0x2F9AA74", VA = "0x2F9AA74")]
	public void ճ\u0828Ԓհ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "ORGPORT";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000864 RID: 2148 RVA: 0x0002E5C4 File Offset: 0x0002C7C4
	[Token(Token = "0x6000864")]
	[Address(RVA = "0x2F9AB6C", Offset = "0x2F9AB6C", VA = "0x2F9AB6C")]
	public void ד\u073C\u0613چ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = u081B_u070Aߢࡁ.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000865 RID: 2149 RVA: 0x0002E61C File Offset: 0x0002C81C
	[Token(Token = "0x6000865")]
	[Address(RVA = "0x2F9AC04", Offset = "0x2F9AC04", VA = "0x2F9AC04")]
	public void \u0827ߜ\u07FD\u07F4()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000866 RID: 2150 RVA: 0x0002E690 File Offset: 0x0002C890
	[Token(Token = "0x6000866")]
	[Address(RVA = "0x2F9AC98", Offset = "0x2F9AC98", VA = "0x2F9AC98")]
	public void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x06000867 RID: 2151 RVA: 0x0002E700 File Offset: 0x0002C900
	[Token(Token = "0x6000867")]
	[Address(RVA = "0x2F9AD90", Offset = "0x2F9AD90", VA = "0x2F9AD90")]
	public void ࢫ\u0876չՍ()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000868 RID: 2152 RVA: 0x0002E774 File Offset: 0x0002C974
	[Token(Token = "0x6000868")]
	[Address(RVA = "0x2F9AE30", Offset = "0x2F9AE30", VA = "0x2F9AE30")]
	public void \u0836\u089Dی\u0735()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 1L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x06000869 RID: 2153 RVA: 0x0002E7E8 File Offset: 0x0002C9E8
	[Token(Token = "0x6000869")]
	[Address(RVA = "0x2F9AEC4", Offset = "0x2F9AEC4", VA = "0x2F9AEC4")]
	public void يօӇ\u070D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Players Online: ";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600086A RID: 2154 RVA: 0x0002E860 File Offset: 0x0002CA60
	[Token(Token = "0x600086A")]
	[Address(RVA = "0x2F9AFBC", Offset = "0x2F9AFBC", VA = "0x2F9AFBC")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayWave";
		bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
		Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
		if (u07AFշ_u0530۰)
		{
			float x = this.ߚݼ\u05BDע.x;
			float y = this.ߚݼ\u05BDע.y;
			float z = this.ߚݼ\u05BDע.z;
			return;
		}
		Vector3 up = base.transform.up;
		float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
	}

	// Token: 0x0600086B RID: 2155 RVA: 0x0002E8D8 File Offset: 0x0002CAD8
	[Token(Token = "0x600086B")]
	[Address(RVA = "0x2F9B0B4", Offset = "0x2F9B0B4", VA = "0x2F9B0B4")]
	public void ژךՈ\u0597()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
			long u082AյڲӺ = 0L;
			this.\u082AյڲӺ = (u082AյڲӺ != 0L);
		}
	}

	// Token: 0x0600086C RID: 2156 RVA: 0x0002E94C File Offset: 0x0002CB4C
	[Token(Token = "0x600086C")]
	[Address(RVA = "0x2F9B14C", Offset = "0x2F9B14C", VA = "0x2F9B14C")]
	public void \u060B\u0614\u0821ע()
	{
		if (this.\u082AյڲӺ)
		{
			bool u07AFշ_u0530۰ = this.\u07AFշ\u0530۰;
			Rigidbody u081B_u070Aߢࡁ = this.\u081B\u070Aߢࡁ;
			if (u07AFշ_u0530۰)
			{
				float x = this.ߚݼ\u05BDע.x;
				float y = this.ߚݼ\u05BDע.y;
				float z = this.ߚݼ\u05BDע.z;
				return;
			}
			Vector3 up = base.transform.up;
			float չ_u0606ۀޤ = this.չ\u0606ۀޤ;
		}
	}

	// Token: 0x04000110 RID: 272
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000110")]
	public Rigidbody \u081B\u070Aߢࡁ;

	// Token: 0x04000111 RID: 273
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000111")]
	public Vector3 ߚݼ\u05BDע;

	// Token: 0x04000112 RID: 274
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x4000112")]
	public bool \u07AFշ\u0530۰;

	// Token: 0x04000113 RID: 275
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000113")]
	public float չ\u0606ۀޤ;

	// Token: 0x04000114 RID: 276
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x4000114")]
	public bool \u082AյڲӺ;
}
