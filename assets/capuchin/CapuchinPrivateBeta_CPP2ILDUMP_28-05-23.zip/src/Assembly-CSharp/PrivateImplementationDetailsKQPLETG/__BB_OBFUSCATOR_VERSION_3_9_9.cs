﻿using System;
using System.Runtime.InteropServices;
using Cpp2IlInjected;

namespace PrivateImplementationDetailsKQPLETG
{
	// Token: 0x02000133 RID: 307
	[Token(Token = "0x2000133")]
	[StructLayout(3, CharSet = CharSet.Auto)]
	public class __BB_OBFUSCATOR_VERSION_3_9_9
	{
	}
}
