﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200002A RID: 42
[Token(Token = "0x200002A")]
public class HandScript : MonoBehaviour
{
	// Token: 0x060004B8 RID: 1208 RVA: 0x0001C174 File Offset: 0x0001A374
	[Token(Token = "0x60004B8")]
	[Address(RVA = "0x274D538", Offset = "0x274D538", VA = "0x274D538")]
	private void \u0870\u05B3Ց\u066A()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("\tExpires: " == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("tutorialCheck" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Add/Remove Hat", value != 0L);
	}

	// Token: 0x060004B9 RID: 1209 RVA: 0x0001C1C8 File Offset: 0x0001A3C8
	[Token(Token = "0x60004B9")]
	[Address(RVA = "0x274D6D0", Offset = "0x274D6D0", VA = "0x274D6D0")]
	private void \u0654ޛ\u07FAذ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Platform failed to initialize due to exception." == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Player" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Player", value != 0L);
	}

	// Token: 0x060004BA RID: 1210 RVA: 0x0001C21C File Offset: 0x0001A41C
	[Token(Token = "0x60004BA")]
	[Address(RVA = "0x274D85C", Offset = "0x274D85C", VA = "0x274D85C")]
	private void ժ\u065Dԯࡘ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("sound play stopped" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Vector1_d371bd24217449349bd747533d51af6b" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("PURCHASED!", value != 0L);
	}

	// Token: 0x060004BB RID: 1211 RVA: 0x0001C270 File Offset: 0x0001A470
	[Token(Token = "0x60004BB")]
	[Address(RVA = "0x274D9F4", Offset = "0x274D9F4", VA = "0x274D9F4")]
	private void \u0881ݗӟ\u07BD()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("NetworkPlayer" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Add/Remove Sword" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Start Gamemode", value != 0L);
	}

	// Token: 0x060004BC RID: 1212 RVA: 0x0001C2C4 File Offset: 0x0001A4C4
	[Token(Token = "0x60004BC")]
	[Address(RVA = "0x274DB8C", Offset = "0x274DB8C", VA = "0x274DB8C")]
	private void \u05EDց\u081Cت()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Vector1_d371bd24217449349bd747533d51af6b" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("hand 2" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Player", value != 0L);
	}

	// Token: 0x060004BD RID: 1213 RVA: 0x0001C318 File Offset: 0x0001A518
	[Token(Token = "0x60004BD")]
	[Address(RVA = "0x274DD24", Offset = "0x274DD24", VA = "0x274DD24")]
	private void \u0599ږࠆ\u065F()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Player" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Player" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("INSIGNIFICANT CURRENCY", value != 0L);
	}

	// Token: 0x060004BE RID: 1214 RVA: 0x0001C36C File Offset: 0x0001A56C
	[Token(Token = "0x60004BE")]
	[Address(RVA = "0x274DEB0", Offset = "0x274DEB0", VA = "0x274DEB0")]
	private void ފՖߢ\u059B()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Adding " == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("_BumpMap" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Universal Render Pipeline/Lit", value != 0L);
	}

	// Token: 0x060004BF RID: 1215 RVA: 0x0001C3C0 File Offset: 0x0001A5C0
	[Token(Token = "0x60004BF")]
	[Address(RVA = "0x274E048", Offset = "0x274E048", VA = "0x274E048")]
	private void \u061B\u05EEوۈ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Calling success callback. baking meshes" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("FingerTip" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Player", value != 0L);
	}

	// Token: 0x060004C0 RID: 1216 RVA: 0x0001C414 File Offset: 0x0001A614
	[Token(Token = "0x60004C0")]
	[Address(RVA = "0x274E1E0", Offset = "0x274E1E0", VA = "0x274E1E0")]
	private void \u07FE\u0882Զ\u066D()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("gamemode" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Version" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Not connected to room", value != 0L);
	}

	// Token: 0x060004C1 RID: 1217 RVA: 0x0001C468 File Offset: 0x0001A668
	[Token(Token = "0x60004C1")]
	[Address(RVA = "0x274E378", Offset = "0x274E378", VA = "0x274E378")]
	private void \u0821\u059Fӕ\u0607()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example." == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("CapuchinStore" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("back", value != 0L);
	}

	// Token: 0x060004C2 RID: 1218 RVA: 0x0001C4BC File Offset: 0x0001A6BC
	[Token(Token = "0x60004C2")]
	[Address(RVA = "0x274E510", Offset = "0x274E510", VA = "0x274E510")]
	private void ԣԭՋࠏ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("_BumpMap" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		if ("containsStaff" == null)
		{
		}
	}

	// Token: 0x060004C3 RID: 1219 RVA: 0x0001C4FC File Offset: 0x0001A6FC
	[Token(Token = "0x60004C3")]
	[Address(RVA = "0x274E6A8", Offset = "0x274E6A8", VA = "0x274E6A8")]
	private void չւت\u061E()
	{
		InputDevice inputDevice;
		if (inputDevice == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("hand 2" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		if ("" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ3 = this.\u0736\u058A\u07B7ݏ;
	}

	// Token: 0x060004C4 RID: 1220 RVA: 0x0001C538 File Offset: 0x0001A738
	[Token(Token = "0x60004C4")]
	[Address(RVA = "0x274E840", Offset = "0x274E840", VA = "0x274E840")]
	private void Update()
	{
		InputDevice inputDevice;
		if (inputDevice == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Trigger" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Grip" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Thumb", value != 0L);
	}

	// Token: 0x060004C5 RID: 1221 RVA: 0x0001C580 File Offset: 0x0001A780
	[Token(Token = "0x60004C5")]
	[Address(RVA = "0x274E9D8", Offset = "0x274E9D8", VA = "0x274E9D8")]
	private void ԟ\u086Cޣ\u055E()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Body" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("1BN" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("This is the 2500 Bananas button, and it was just clicked", value != 0L);
	}

	// Token: 0x060004C6 RID: 1222 RVA: 0x0001C5D4 File Offset: 0x0001A7D4
	[Token(Token = "0x60004C6")]
	[Address(RVA = "0x274EB70", Offset = "0x274EB70", VA = "0x274EB70")]
	private void \u07B2\u0823ծݠ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("TurnAmount" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("EnableCosmetic" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Player", value != 0L);
	}

	// Token: 0x060004C7 RID: 1223 RVA: 0x0001C628 File Offset: 0x0001A828
	[Token(Token = "0x60004C7")]
	[Address(RVA = "0x274ED08", Offset = "0x274ED08", VA = "0x274ED08")]
	private void \u061Fࡆ\u086F\u07B0()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("PlayerHead" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("HOLY MOLY THE STICK IS ON FIRE!!!!!!" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Combine textures & build combined mesh all at once", value != 0L);
	}

	// Token: 0x060004C8 RID: 1224 RVA: 0x0001C67C File Offset: 0x0001A87C
	[Token(Token = "0x60004C8")]
	[Address(RVA = "0x274EEA0", Offset = "0x274EEA0", VA = "0x274EEA0")]
	private void Ҿࢹؼס()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("You have been banned for " == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("PushToTalk" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("PlayWave", value != 0L);
	}

	// Token: 0x060004C9 RID: 1225 RVA: 0x0001C6D0 File Offset: 0x0001A8D0
	[Token(Token = "0x60004C9")]
	[Address(RVA = "0x274F038", Offset = "0x274F038", VA = "0x274F038")]
	private void \u060B\u0614\u0821ע()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Target" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Connected to Server." == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("HeadAttachPoint", value != 0L);
	}

	// Token: 0x060004CA RID: 1226 RVA: 0x0001C724 File Offset: 0x0001A924
	[Token(Token = "0x60004CA")]
	[Address(RVA = "0x274F1D0", Offset = "0x274F1D0", VA = "0x274F1D0")]
	private void Ӣ\u0592ߨׯ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Player" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Not connected to room" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Did Hit", value != 0L);
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x0001C778 File Offset: 0x0001A978
	[Token(Token = "0x60004CB")]
	[Address(RVA = "0x274F368", Offset = "0x274F368", VA = "0x274F368")]
	private void Ҽ\u08B5ځ\u0658()
	{
		long num = 1L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		if (num == 0L)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("tutorialCheck" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("DisableCosmetic", value != 0L);
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x0001C7C8 File Offset: 0x0001A9C8
	[Token(Token = "0x60004CC")]
	[Address(RVA = "0x274F500", Offset = "0x274F500", VA = "0x274F500")]
	private void צ\u0874ڵ\u059A()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("HandL" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Player" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Body", value != 0L);
	}

	// Token: 0x060004CD RID: 1229 RVA: 0x0001C81C File Offset: 0x0001AA1C
	[Token(Token = "0x60004CD")]
	[Address(RVA = "0x274F698", Offset = "0x274F698", VA = "0x274F698")]
	private void ژךՈ\u0597()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("monke screamed" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Purchased: " == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("jump char false", value != 0L);
	}

	// Token: 0x060004CE RID: 1230 RVA: 0x0001C870 File Offset: 0x0001AA70
	[Token(Token = "0x60004CE")]
	[Address(RVA = "0x274F830", Offset = "0x274F830", VA = "0x274F830")]
	private void ࡊ\u0592\u07AB\u05B2()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("TurnAmount" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Room Name: " == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("MetaId", value != 0L);
	}

	// Token: 0x060004CF RID: 1231 RVA: 0x0001C8C4 File Offset: 0x0001AAC4
	[Token(Token = "0x60004CF")]
	[Address(RVA = "0x274F9C8", Offset = "0x274F9C8", VA = "0x274F9C8")]
	private void څࡣڐ\u0657()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if (" and for the price of " == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("button" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool(" and for the price of ", value != 0L);
	}

	// Token: 0x060004D0 RID: 1232 RVA: 0x0001C918 File Offset: 0x0001AB18
	[Token(Token = "0x60004D0")]
	[Address(RVA = "0x274FB54", Offset = "0x274FB54", VA = "0x274FB54")]
	private void ࢫ\u0876չՍ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("username" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("ENABLE" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Added Winner Money", value != 0L);
	}

	// Token: 0x060004D1 RID: 1233 RVA: 0x0001C96C File Offset: 0x0001AB6C
	[Token(Token = "0x60004D1")]
	[Address(RVA = "0x274FCEC", Offset = "0x274FCEC", VA = "0x274FCEC")]
	private void \u073Fߗބݝ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("M/d/yyyy" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Thumb" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Player", value != 0L);
	}

	// Token: 0x060004D2 RID: 1234 RVA: 0x0001C9C0 File Offset: 0x0001ABC0
	[Token(Token = "0x60004D2")]
	[Address(RVA = "0x274FE84", Offset = "0x274FE84", VA = "0x274FE84")]
	private void طӏܙࢺ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("username" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe." == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("username", value != 0L);
	}

	// Token: 0x060004D3 RID: 1235 RVA: 0x0001CA14 File Offset: 0x0001AC14
	[Token(Token = "0x60004D3")]
	[Address(RVA = "0x2750010", Offset = "0x2750010", VA = "0x2750010")]
	private void ո\u07AA\u05BDࠕ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("ErrorScreen" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Players Online: " == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.", value != 0L);
	}

	// Token: 0x060004D4 RID: 1236 RVA: 0x0001CA68 File Offset: 0x0001AC68
	[Token(Token = "0x60004D4")]
	[Address(RVA = "0x27501A8", Offset = "0x27501A8", VA = "0x27501A8")]
	private void \u0838ӆڛӑ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("FingerTip" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("FingerTip" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("BN", value != 0L);
	}

	// Token: 0x060004D5 RID: 1237 RVA: 0x0001CABC File Offset: 0x0001ACBC
	[Token(Token = "0x60004D5")]
	[Address(RVA = "0x2750334", Offset = "0x2750334", VA = "0x2750334")]
	private void ւ\u06E9\u06DA\u06EB()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Horizontal" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Muted" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Charged!", value != 0L);
	}

	// Token: 0x060004D6 RID: 1238 RVA: 0x0001CB10 File Offset: 0x0001AD10
	[Token(Token = "0x60004D6")]
	[Address(RVA = "0x27504CC", Offset = "0x27504CC", VA = "0x27504CC")]
	private void \u070Aәޣے()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("hh:mmtt" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("TurnAmount" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("DisableCosmetic", value != 0L);
	}

	// Token: 0x060004D7 RID: 1239 RVA: 0x0001CB64 File Offset: 0x0001AD64
	[Token(Token = "0x60004D7")]
	[Address(RVA = "0x2750664", Offset = "0x2750664", VA = "0x2750664")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Vector1_d371bd24217449349bd747533d51af6b" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
	}

	// Token: 0x060004D8 RID: 1240 RVA: 0x0001CB9C File Offset: 0x0001AD9C
	[Token(Token = "0x60004D8")]
	[Address(RVA = "0x27507FC", Offset = "0x27507FC", VA = "0x27507FC")]
	private void \u0872މࢮՃ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Universal Render Pipeline/Lit" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("NoseAttachPoint" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Player", value != 0L);
	}

	// Token: 0x060004D9 RID: 1241 RVA: 0x0001CBF0 File Offset: 0x0001ADF0
	[Token(Token = "0x60004D9")]
	[Address(RVA = "0x2750994", Offset = "0x2750994", VA = "0x2750994")]
	private void Ӌ\u089C\u0700ܧ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Purchase For " == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		if (" and the correct version is " == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ3 = this.\u0736\u058A\u07B7ݏ;
	}

	// Token: 0x060004DA RID: 1242 RVA: 0x0001CC34 File Offset: 0x0001AE34
	[Token(Token = "0x60004DA")]
	[Address(RVA = "0x2750B2C", Offset = "0x2750B2C", VA = "0x2750B2C")]
	private void ڑߒجވ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Platform failed to initialize due to exception." == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("INSIGNIFICANT CURRENCY" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Did Hit", value != 0L);
	}

	// Token: 0x060004DB RID: 1243 RVA: 0x0001CC88 File Offset: 0x0001AE88
	[Token(Token = "0x60004DB")]
	[Address(RVA = "0x2750CC4", Offset = "0x2750CC4", VA = "0x2750CC4")]
	private void \u0614ࢥӴ\u086C()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("containsStaff" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if (". Please update you game to the latest version" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("_Tint", value != 0L);
	}

	// Token: 0x060004DC RID: 1244 RVA: 0x0001CCDC File Offset: 0x0001AEDC
	[Token(Token = "0x60004DC")]
	[Address(RVA = "0x2750E5C", Offset = "0x2750E5C", VA = "0x2750E5C")]
	private void \u0705\u0816\u0739դ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("ORGTARG" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Song Index: " == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Skelechin", value != 0L);
	}

	// Token: 0x060004DD RID: 1245 RVA: 0x0001CD30 File Offset: 0x0001AF30
	[Token(Token = "0x60004DD")]
	[Address(RVA = "0x2750FF4", Offset = "0x2750FF4", VA = "0x2750FF4")]
	private void ӻӒݝ߃()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("username" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("PlayerHead" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("You have been banned for ", value != 0L);
	}

	// Token: 0x060004DE RID: 1246 RVA: 0x0001CD84 File Offset: 0x0001AF84
	[Token(Token = "0x60004DE")]
	[Address(RVA = "0x275118C", Offset = "0x275118C", VA = "0x275118C")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("gameMode" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		if ("SetColor" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ3 = this.\u0736\u058A\u07B7ݏ;
	}

	// Token: 0x060004DF RID: 1247 RVA: 0x0001CDC8 File Offset: 0x0001AFC8
	[Token(Token = "0x60004DF")]
	[Address(RVA = "0x2751324", Offset = "0x2751324", VA = "0x2751324")]
	private void \u0892ܒܬޓ()
	{
		long num = 1L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		if (num == 0L)
		{
		}
		if ("Tagging" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("CapuchinRemade" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("FingerTip", value != 0L);
	}

	// Token: 0x060004E0 RID: 1248 RVA: 0x0001CE18 File Offset: 0x0001B018
	[Token(Token = "0x60004E0")]
	[Address(RVA = "0x27514BC", Offset = "0x27514BC", VA = "0x27514BC")]
	private void \u0886Ҽ\u058Dߛ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if (", " == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Game Started" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Player", value != 0L);
	}

	// Token: 0x060004E1 RID: 1249 RVA: 0x0001CE6C File Offset: 0x0001B06C
	[Token(Token = "0x60004E1")]
	[Address(RVA = "0x2751654", Offset = "0x2751654", VA = "0x2751654")]
	private void \u087BӦןݩ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("FingerTip" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Add/Remove Sword" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("EnableCosmetic", value != 0L);
	}

	// Token: 0x060004E2 RID: 1250 RVA: 0x0001CEC0 File Offset: 0x0001B0C0
	[Token(Token = "0x60004E2")]
	[Address(RVA = "0x27517EC", Offset = "0x27517EC", VA = "0x27517EC")]
	public HandScript()
	{
	}

	// Token: 0x060004E3 RID: 1251 RVA: 0x0001CED4 File Offset: 0x0001B0D4
	[Token(Token = "0x60004E3")]
	[Address(RVA = "0x27517F4", Offset = "0x27517F4", VA = "0x27517F4")]
	private void ւࡂ\u0883\u0872()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("/" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Starting to bake textures on frame " == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("username", value != 0L);
	}

	// Token: 0x060004E4 RID: 1252 RVA: 0x0001CF28 File Offset: 0x0001B128
	[Token(Token = "0x60004E4")]
	[Address(RVA = "0x275198C", Offset = "0x275198C", VA = "0x275198C")]
	private void \u0590\u0882\u0883ࡦ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Body" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("META" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("MetaId", value != 0L);
	}

	// Token: 0x060004E5 RID: 1253 RVA: 0x0001CF7C File Offset: 0x0001B17C
	[Token(Token = "0x60004E5")]
	[Address(RVA = "0x2751B24", Offset = "0x2751B24", VA = "0x2751B24")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Open" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Player" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("username", value != 0L);
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x0001CFD0 File Offset: 0x0001B1D0
	[Token(Token = "0x60004E6")]
	[Address(RVA = "0x2751CBC", Offset = "0x2751CBC", VA = "0x2751CBC")]
	private void \u0832ࢳޤ\u07B5()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Tagged" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Head" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("/", value != 0L);
	}

	// Token: 0x060004E7 RID: 1255 RVA: 0x0001D024 File Offset: 0x0001B224
	[Token(Token = "0x60004E7")]
	[Address(RVA = "0x2751E54", Offset = "0x2751E54", VA = "0x2751E54")]
	private void ܪ\u07BB\u086Bࠆ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("trol" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Adding " == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("ENABLE", value != 0L);
	}

	// Token: 0x060004E8 RID: 1256 RVA: 0x0001D078 File Offset: 0x0001B278
	[Token(Token = "0x60004E8")]
	[Address(RVA = "0x2751FEC", Offset = "0x2751FEC", VA = "0x2751FEC")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("INSIGNIFICANT CURRENCY" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Player" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Player", value != 0L);
	}

	// Token: 0x060004E9 RID: 1257 RVA: 0x0001D0CC File Offset: 0x0001B2CC
	[Token(Token = "0x60004E9")]
	[Address(RVA = "0x2752178", Offset = "0x2752178", VA = "0x2752178")]
	private void ٴݵۃ\u05AF()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh." == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		if ("Left Hand" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("HOLY MOLY THE STICK IS ON FIRE!!!!!!", value != 0L);
	}

	// Token: 0x060004EA RID: 1258 RVA: 0x0001D11C File Offset: 0x0001B31C
	[Token(Token = "0x60004EA")]
	[Address(RVA = "0x2752310", Offset = "0x2752310", VA = "0x2752310")]
	private void \u0732ڙԒࢺ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("You are not the master of the server, you cannot start the game." == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("BN" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("QuickStatic", value != 0L);
	}

	// Token: 0x060004EB RID: 1259 RVA: 0x0001D170 File Offset: 0x0001B370
	[Token(Token = "0x60004EB")]
	[Address(RVA = "0x27524A8", Offset = "0x27524A8", VA = "0x27524A8")]
	private void ں٢ࡡ\u05EC()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("containsStaff" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("closeToObject" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("Vector1_d371bd24217449349bd747533d51af6b", value != 0L);
	}

	// Token: 0x060004EC RID: 1260 RVA: 0x0001D1C4 File Offset: 0x0001B3C4
	[Token(Token = "0x60004EC")]
	[Address(RVA = "0x2752640", Offset = "0x2752640", VA = "0x2752640")]
	private void ڃրӢԖ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("On" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Hate Speech" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("duration done", value != 0L);
	}

	// Token: 0x060004ED RID: 1261 RVA: 0x0001D218 File Offset: 0x0001B418
	[Token(Token = "0x60004ED")]
	[Address(RVA = "0x27527D8", Offset = "0x27527D8", VA = "0x27527D8")]
	private void יԠ\u07EDԺ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Player" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("HorrorAgreement" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("NetworkPlayer", value != 0L);
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x0001D26C File Offset: 0x0001B46C
	[Token(Token = "0x60004EE")]
	[Address(RVA = "0x2752970", Offset = "0x2752970", VA = "0x2752970")]
	private void \u05F7ԝߠӱ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Player was caught cheating" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("Vector1_d371bd24217449349bd747533d51af6b" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("EnableCosmetic", value != 0L);
	}

	// Token: 0x060004EF RID: 1263 RVA: 0x0001D2C0 File Offset: 0x0001B4C0
	[Token(Token = "0x60004EF")]
	[Address(RVA = "0x2752B08", Offset = "0x2752B08", VA = "0x2752B08")]
	private void \u05F8ݑ\u06ECߞ()
	{
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ = this.\u0736\u058A\u07B7ݏ;
		if ("Update User Inventory" == null)
		{
		}
		Animator u0736_u058A_u07B7ݏ2 = this.\u0736\u058A\u07B7ݏ;
		long value = 0L;
		if ("_Tint" == null)
		{
		}
		this.\u0736\u058A\u07B7ݏ.SetBool("PURCHASED", value != 0L);
	}

	// Token: 0x040000C8 RID: 200
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000C8")]
	public XRNode ࢳҾپݳ;

	// Token: 0x040000C9 RID: 201
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000C9")]
	public Animator \u0736\u058A\u07B7ݏ;
}
