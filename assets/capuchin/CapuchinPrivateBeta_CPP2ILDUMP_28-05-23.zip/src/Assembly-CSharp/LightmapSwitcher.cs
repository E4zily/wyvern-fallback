﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000030 RID: 48
[Token(Token = "0x2000030")]
public class LightmapSwitcher : MonoBehaviour
{
	// Token: 0x06000558 RID: 1368 RVA: 0x0001F0F8 File Offset: 0x0001D2F8
	[Token(Token = "0x6000558")]
	[Address(RVA = "0x2CD91CC", Offset = "0x2CD91CC", VA = "0x2CD91CC")]
	private void \u0599ږࠆ\u065F()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
			long ڟߕ_u087Fމ = 1L;
			this.ڟߕ\u087Fމ = (ڟߕ_u087Fމ != 0L);
		}
	}

	// Token: 0x06000559 RID: 1369 RVA: 0x0001F134 File Offset: 0x0001D334
	[Token(Token = "0x6000559")]
	[Address(RVA = "0x2CD9368", Offset = "0x2CD9368", VA = "0x2CD9368")]
	private void \u0746ց\u0745\u0817(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x0600055A RID: 1370 RVA: 0x0001F164 File Offset: 0x0001D364
	[Token(Token = "0x600055A")]
	[Address(RVA = "0x2CD94B0", Offset = "0x2CD94B0", VA = "0x2CD94B0")]
	private void \u05F8ݑ\u06ECߞ()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
		}
	}

	// Token: 0x0600055B RID: 1371 RVA: 0x0001F194 File Offset: 0x0001D394
	[Token(Token = "0x600055B")]
	[Address(RVA = "0x2CD9668", Offset = "0x2CD9668", VA = "0x2CD9668")]
	private void մ\u088Bߏ\u05CA(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x0600055C RID: 1372 RVA: 0x0001F1C4 File Offset: 0x0001D3C4
	[Token(Token = "0x600055C")]
	[Address(RVA = "0x2CD97B0", Offset = "0x2CD97B0", VA = "0x2CD97B0")]
	private void ٳڨړփ(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x0600055D RID: 1373 RVA: 0x0001F1F4 File Offset: 0x0001D3F4
	[Token(Token = "0x600055D")]
	[Address(RVA = "0x2CD98F8", Offset = "0x2CD98F8", VA = "0x2CD98F8")]
	private void ԣࠑࡊࡅ(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x0600055E RID: 1374 RVA: 0x0001F224 File Offset: 0x0001D424
	[Token(Token = "0x600055E")]
	[Address(RVA = "0x2CD9A40", Offset = "0x2CD9A40", VA = "0x2CD9A40")]
	private void \u0654ޛ\u07FAذ()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
		}
	}

	// Token: 0x0600055F RID: 1375 RVA: 0x0001F254 File Offset: 0x0001D454
	[Token(Token = "0x600055F")]
	[Address(RVA = "0x2CD9520", Offset = "0x2CD9520", VA = "0x2CD9520")]
	private void ܨԾ\u05B1ޅ(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000560 RID: 1376 RVA: 0x0001F284 File Offset: 0x0001D484
	[Token(Token = "0x6000560")]
	[Address(RVA = "0x2CD9BD8", Offset = "0x2CD9BD8", VA = "0x2CD9BD8")]
	private void قו\u06EAل(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000561 RID: 1377 RVA: 0x0001F2B4 File Offset: 0x0001D4B4
	[Token(Token = "0x6000561")]
	[Address(RVA = "0x2CD9D20", Offset = "0x2CD9D20", VA = "0x2CD9D20")]
	private void \u06D6ې\u083Bࠉ()
	{
		long ۹ࡎԬ_u058E = 1L;
		this.߉ܠࢴڙ((int)۹ࡎԬ_u058E);
	}

	// Token: 0x06000562 RID: 1378 RVA: 0x0001F2CC File Offset: 0x0001D4CC
	[Token(Token = "0x6000562")]
	[Address(RVA = "0x2CD9E4C", Offset = "0x2CD9E4C", VA = "0x2CD9E4C")]
	private void ۍӈ\u05AFے(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000563 RID: 1379 RVA: 0x0001F2FC File Offset: 0x0001D4FC
	[Token(Token = "0x6000563")]
	[Address(RVA = "0x2CD9F94", Offset = "0x2CD9F94", VA = "0x2CD9F94")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
		}
	}

	// Token: 0x06000564 RID: 1380 RVA: 0x0001F32C File Offset: 0x0001D52C
	[Token(Token = "0x6000564")]
	[Address(RVA = "0x2CDA004", Offset = "0x2CDA004", VA = "0x2CDA004")]
	private void ࢥ\u081CՕࡋ()
	{
		long ۹ࡎԬ_u058E = 0L;
		this.մ\u088Bߏ\u05CA((int)۹ࡎԬ_u058E);
	}

	// Token: 0x06000565 RID: 1381 RVA: 0x0001F344 File Offset: 0x0001D544
	[Token(Token = "0x6000565")]
	[Address(RVA = "0x2CDA00C", Offset = "0x2CDA00C", VA = "0x2CDA00C")]
	private void ܣ\u086E\u05CF\u06D8()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
		}
	}

	// Token: 0x06000566 RID: 1382 RVA: 0x0001F374 File Offset: 0x0001D574
	[Token(Token = "0x6000566")]
	[Address(RVA = "0x2CD9D28", Offset = "0x2CD9D28", VA = "0x2CD9D28")]
	private void ߉ܠࢴڙ(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000567 RID: 1383 RVA: 0x0001F3A4 File Offset: 0x0001D5A4
	[Token(Token = "0x6000567")]
	[Address(RVA = "0x2CD9AB0", Offset = "0x2CD9AB0", VA = "0x2CD9AB0")]
	private void \u05A2ڲمד(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000568 RID: 1384 RVA: 0x0001F3CC File Offset: 0x0001D5CC
	[Token(Token = "0x6000568")]
	[Address(RVA = "0x2CDA07C", Offset = "0x2CDA07C", VA = "0x2CDA07C")]
	private void عۻԂ\u055E()
	{
		long ۹ࡎԬ_u058E = 0L;
		this.մ\u088Bߏ\u05CA((int)۹ࡎԬ_u058E);
	}

	// Token: 0x06000569 RID: 1385 RVA: 0x0001F3E4 File Offset: 0x0001D5E4
	[Token(Token = "0x6000569")]
	[Address(RVA = "0x2CDA084", Offset = "0x2CDA084", VA = "0x2CDA084")]
	private void މ\u05A0\u087C\u074A(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x0600056A RID: 1386 RVA: 0x0001F40C File Offset: 0x0001D60C
	[Token(Token = "0x600056A")]
	[Address(RVA = "0x2CDA1AC", Offset = "0x2CDA1AC", VA = "0x2CDA1AC")]
	private void ژךՈ\u0597()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
		}
	}

	// Token: 0x0600056B RID: 1387 RVA: 0x0001F43C File Offset: 0x0001D63C
	[Token(Token = "0x600056B")]
	[Address(RVA = "0x2CDA21C", Offset = "0x2CDA21C", VA = "0x2CDA21C")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
			long ڟߕ_u087Fމ = 1L;
			this.ڟߕ\u087Fމ = (ڟߕ_u087Fމ != 0L);
		}
	}

	// Token: 0x0600056C RID: 1388 RVA: 0x0001F478 File Offset: 0x0001D678
	[Token(Token = "0x600056C")]
	[Address(RVA = "0x2CDA28C", Offset = "0x2CDA28C", VA = "0x2CDA28C")]
	private void \u07FE\u0882Զ\u066D()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
		}
	}

	// Token: 0x0600056D RID: 1389 RVA: 0x0001F4A8 File Offset: 0x0001D6A8
	[Token(Token = "0x600056D")]
	[Address(RVA = "0x2CDA424", Offset = "0x2CDA424", VA = "0x2CDA424")]
	private void \u0881ݗӟ\u07BD()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
			long ڟߕ_u087Fމ = 1L;
			this.ڟߕ\u087Fމ = (ڟߕ_u087Fމ != 0L);
		}
	}

	// Token: 0x0600056E RID: 1390 RVA: 0x0001F4E4 File Offset: 0x0001D6E4
	[Token(Token = "0x600056E")]
	[Address(RVA = "0x2CDA494", Offset = "0x2CDA494", VA = "0x2CDA494")]
	private void ݱ\u0832ݥ\u08B5()
	{
		long ۹ࡎԬ_u058E = 1L;
		this.ԣࠑࡊࡅ((int)۹ࡎԬ_u058E);
	}

	// Token: 0x0600056F RID: 1391 RVA: 0x0001F4FC File Offset: 0x0001D6FC
	[Token(Token = "0x600056F")]
	[Address(RVA = "0x2CDA49C", Offset = "0x2CDA49C", VA = "0x2CDA49C")]
	private void ں٢ࡡ\u05EC()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
		}
	}

	// Token: 0x06000570 RID: 1392 RVA: 0x0001F52C File Offset: 0x0001D72C
	[Token(Token = "0x6000570")]
	[Address(RVA = "0x2CDA508", Offset = "0x2CDA508", VA = "0x2CDA508")]
	private void ڧ\u073EՐԁ(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000571 RID: 1393 RVA: 0x0001F55C File Offset: 0x0001D75C
	[Token(Token = "0x6000571")]
	[Address(RVA = "0x2CD9240", Offset = "0x2CD9240", VA = "0x2CD9240")]
	private void ޞ\u0896ܒؾ(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000572 RID: 1394 RVA: 0x0001F584 File Offset: 0x0001D784
	[Token(Token = "0x6000572")]
	[Address(RVA = "0x2CDA650", Offset = "0x2CDA650", VA = "0x2CDA650")]
	private void ۓӴ\u0558ب(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000573 RID: 1395 RVA: 0x0001F5AC File Offset: 0x0001D7AC
	[Token(Token = "0x6000573")]
	[Address(RVA = "0x2CDA778", Offset = "0x2CDA778", VA = "0x2CDA778")]
	private void צ\u0874ڵ\u059A()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
			long ڟߕ_u087Fމ = 1L;
			this.ڟߕ\u087Fމ = (ڟߕ_u087Fމ != 0L);
		}
	}

	// Token: 0x06000574 RID: 1396 RVA: 0x0001F5E8 File Offset: 0x0001D7E8
	[Token(Token = "0x6000574")]
	[Address(RVA = "0x2CDA7E8", Offset = "0x2CDA7E8", VA = "0x2CDA7E8")]
	public LightmapSwitcher()
	{
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x0001F5FC File Offset: 0x0001D7FC
	[Token(Token = "0x6000575")]
	[Address(RVA = "0x2CDA7F0", Offset = "0x2CDA7F0", VA = "0x2CDA7F0")]
	private void ӛ\u082Eؿڕ()
	{
		long ۹ࡎԬ_u058E = 1L;
		this.\u0746ց\u0745\u0817((int)۹ࡎԬ_u058E);
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x0001F614 File Offset: 0x0001D814
	[Token(Token = "0x6000576")]
	[Address(RVA = "0x2CDA7F8", Offset = "0x2CDA7F8", VA = "0x2CDA7F8")]
	private void ڑߒجވ()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
		}
	}

	// Token: 0x06000577 RID: 1399 RVA: 0x0001F644 File Offset: 0x0001D844
	[Token(Token = "0x6000577")]
	[Address(RVA = "0x2CDA9AC", Offset = "0x2CDA9AC", VA = "0x2CDA9AC")]
	private void \u05C8\u05BFࠁف()
	{
		long ۹ࡎԬ_u058E = 0L;
		this.ࠏ\u0670\u0741\u0749((int)۹ࡎԬ_u058E);
	}

	// Token: 0x06000578 RID: 1400 RVA: 0x0001F65C File Offset: 0x0001D85C
	[Token(Token = "0x6000578")]
	[Address(RVA = "0x2CDA9B4", Offset = "0x2CDA9B4", VA = "0x2CDA9B4")]
	private void \u0896ރ\u05F8\u055D(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000579 RID: 1401 RVA: 0x0001F684 File Offset: 0x0001D884
	[Token(Token = "0x6000579")]
	[Address(RVA = "0x2CDAADC", Offset = "0x2CDAADC", VA = "0x2CDAADC")]
	private void ڰߘࠂ\u07F5(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x0600057A RID: 1402 RVA: 0x0001F6B4 File Offset: 0x0001D8B4
	[Token(Token = "0x600057A")]
	[Address(RVA = "0x2CDAC24", Offset = "0x2CDAC24", VA = "0x2CDAC24")]
	private void \u05EDց\u081Cت()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
			long ڟߕ_u087Fމ = 1L;
			this.ڟߕ\u087Fމ = (ڟߕ_u087Fމ != 0L);
		}
	}

	// Token: 0x0600057B RID: 1403 RVA: 0x0001F6F0 File Offset: 0x0001D8F0
	[Token(Token = "0x600057B")]
	[Address(RVA = "0x2CDAC94", Offset = "0x2CDAC94", VA = "0x2CDAC94")]
	private void ࢫ\u0876չՍ()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
			long ڟߕ_u087Fމ = 1L;
			this.ڟߕ\u087Fމ = (ڟߕ_u087Fމ != 0L);
		}
	}

	// Token: 0x0600057C RID: 1404 RVA: 0x0001F72C File Offset: 0x0001D92C
	[Token(Token = "0x600057C")]
	[Address(RVA = "0x2CDAD08", Offset = "0x2CDAD08", VA = "0x2CDAD08")]
	private void ݸԲ\u0616Ԫ()
	{
		long ۹ࡎԬ_u058E = 0L;
		this.ޞ\u0896ܒؾ((int)۹ࡎԬ_u058E);
	}

	// Token: 0x0600057D RID: 1405 RVA: 0x0001F744 File Offset: 0x0001D944
	[Token(Token = "0x600057D")]
	[Address(RVA = "0x2CDAD10", Offset = "0x2CDAD10", VA = "0x2CDAD10")]
	private void יԠ\u07EDԺ()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
			long ڟߕ_u087Fމ = 1L;
			this.ڟߕ\u087Fމ = (ڟߕ_u087Fމ != 0L);
		}
	}

	// Token: 0x0600057E RID: 1406 RVA: 0x0001F780 File Offset: 0x0001D980
	[Token(Token = "0x600057E")]
	[Address(RVA = "0x2CDAD84", Offset = "0x2CDAD84", VA = "0x2CDAD84")]
	private void Ҿࢹؼס()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
			long ڟߕ_u087Fމ = 1L;
			this.ڟߕ\u087Fމ = (ڟߕ_u087Fމ != 0L);
		}
	}

	// Token: 0x0600057F RID: 1407 RVA: 0x0001F7BC File Offset: 0x0001D9BC
	[Token(Token = "0x600057F")]
	[Address(RVA = "0x2CDADF8", Offset = "0x2CDADF8", VA = "0x2CDADF8")]
	private void \u087BӦןݩ()
	{
		if (this.ڟߕ\u087Fމ)
		{
			List<Texture2D> u05BFבۂ_u = this.\u05BFבۂ\u0878;
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
			int size = u05BFבۂ_u._size;
			long ڟߕ_u087Fމ = 1L;
			this.ڟߕ\u087Fމ = (ڟߕ_u087Fމ != 0L);
		}
	}

	// Token: 0x06000580 RID: 1408 RVA: 0x0001F7F8 File Offset: 0x0001D9F8
	[Token(Token = "0x6000580")]
	[Address(RVA = "0x2CDAE68", Offset = "0x2CDAE68", VA = "0x2CDAE68")]
	private void \u0614\u0818ܤ\u0887(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000581 RID: 1409 RVA: 0x0001F828 File Offset: 0x0001DA28
	[Token(Token = "0x6000581")]
	[Address(RVA = "0x2CDAFB0", Offset = "0x2CDAFB0", VA = "0x2CDAFB0")]
	private void Update()
	{
		if (this.ڟߕ\u087Fމ)
		{
			int ܠ_u060D_u087Eݴ = this.ܠ\u060D\u087Eݴ;
		}
	}

	// Token: 0x06000582 RID: 1410 RVA: 0x0001F84C File Offset: 0x0001DA4C
	[Token(Token = "0x6000582")]
	[Address(RVA = "0x2CDB020", Offset = "0x2CDB020", VA = "0x2CDB020")]
	private void ןٮ\u061FԺ()
	{
		long ۹ࡎԬ_u058E = 1L;
		this.\u07F3\u0821\u073C\u083D((int)۹ࡎԬ_u058E);
	}

	// Token: 0x06000583 RID: 1411 RVA: 0x0001F864 File Offset: 0x0001DA64
	[Token(Token = "0x6000583")]
	[Address(RVA = "0x2CDB028", Offset = "0x2CDB028", VA = "0x2CDB028")]
	private void Start()
	{
		long ۹ࡎԬ_u058E = 0L;
		this.߉ܠࢴڙ((int)۹ࡎԬ_u058E);
	}

	// Token: 0x06000584 RID: 1412 RVA: 0x0001F87C File Offset: 0x0001DA7C
	[Token(Token = "0x6000584")]
	[Address(RVA = "0x2CDB030", Offset = "0x2CDB030", VA = "0x2CDB030")]
	private void הԥ\u05B5ݴ()
	{
		long ۹ࡎԬ_u058E = 0L;
		this.߉ܠࢴڙ((int)۹ࡎԬ_u058E);
	}

	// Token: 0x06000585 RID: 1413 RVA: 0x0001F894 File Offset: 0x0001DA94
	[Token(Token = "0x6000585")]
	[Address(RVA = "0x2CDB038", Offset = "0x2CDB038", VA = "0x2CDB038")]
	private void Ԯ\u0883\u0591\u066C()
	{
		long ۹ࡎԬ_u058E = 0L;
		this.ۓӴ\u0558ب((int)۹ࡎԬ_u058E);
	}

	// Token: 0x06000586 RID: 1414 RVA: 0x0001F8AC File Offset: 0x0001DAAC
	[Token(Token = "0x6000586")]
	[Address(RVA = "0x2CDA2FC", Offset = "0x2CDA2FC", VA = "0x2CDA2FC")]
	private void \u07F3\u0821\u073C\u083D(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x06000587 RID: 1415 RVA: 0x0001F8D4 File Offset: 0x0001DAD4
	[Token(Token = "0x6000587")]
	[Address(RVA = "0x2CDB040", Offset = "0x2CDB040", VA = "0x2CDB040")]
	private void ۊո\u0612\u0595()
	{
		long ۹ࡎԬ_u058E = 1L;
		this.ٳڨړփ((int)۹ࡎԬ_u058E);
	}

	// Token: 0x06000588 RID: 1416 RVA: 0x0001F8EC File Offset: 0x0001DAEC
	[Token(Token = "0x6000588")]
	[Address(RVA = "0x2CDA864", Offset = "0x2CDA864", VA = "0x2CDA864")]
	private void ࠏ\u0670\u0741\u0749(int ۹ࡎԬ\u058E)
	{
		if (typeof(UnityEngine.Object).TypeHandle == null)
		{
		}
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = ۹ࡎԬ\u058E;
	}

	// Token: 0x040000DE RID: 222
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000DE")]
	public List<Texture2D> \u05BFבۂ\u0878;

	// Token: 0x040000DF RID: 223
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000DF")]
	private int ܠ\u060D\u087Eݴ;

	// Token: 0x040000E0 RID: 224
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x40000E0")]
	public bool ڟߕ\u087Fމ;
}
