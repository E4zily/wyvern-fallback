﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200005A RID: 90
[Token(Token = "0x200005A")]
public class DeleteAndroidDebugger : MonoBehaviour
{
	// Token: 0x06000CD9 RID: 3289 RVA: 0x0004369C File Offset: 0x0004189C
	[Token(Token = "0x6000CD9")]
	[Address(RVA = "0x289D520", Offset = "0x289D520", VA = "0x289D520")]
	private void ࡇ\u0559یՒ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("A new Player joined a Room.");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CDA RID: 3290 RVA: 0x00043738 File Offset: 0x00041938
	[Token(Token = "0x6000CDA")]
	[Address(RVA = "0x289D828", Offset = "0x289D828", VA = "0x289D828")]
	private void \u0892\u061B\u0606\u06D8()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("PURCHASED");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			return;
		}
	}

	// Token: 0x06000CDB RID: 3291 RVA: 0x000437E0 File Offset: 0x000419E0
	[Token(Token = "0x6000CDB")]
	[Address(RVA = "0x289DB3C", Offset = "0x289DB3C", VA = "0x289DB3C")]
	private void \u0883ދ\u066C\u0859()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ);
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CDC RID: 3292 RVA: 0x00043874 File Offset: 0x00041A74
	[Token(Token = "0x6000CDC")]
	[Address(RVA = "0x289DE44", Offset = "0x289DE44", VA = "0x289DE44")]
	private void ם\u06FDւԋ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("Thumb");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
			return;
		}
	}

	// Token: 0x06000CDD RID: 3293 RVA: 0x0004391C File Offset: 0x00041B1C
	[Token(Token = "0x6000CDD")]
	[Address(RVA = "0x289E158", Offset = "0x289E158", VA = "0x289E158")]
	private void ա\u0731ࢺۊ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("Error");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
			return;
		}
	}

	// Token: 0x06000CDE RID: 3294 RVA: 0x000439C4 File Offset: 0x00041BC4
	[Token(Token = "0x6000CDE")]
	[Address(RVA = "0x289E46C", Offset = "0x289E46C", VA = "0x289E46C")]
	private void \u070EࢣԀ\u07A9()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("Player");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
		}
	}

	// Token: 0x06000CDF RID: 3295 RVA: 0x00043A6C File Offset: 0x00041C6C
	[Token(Token = "0x6000CDF")]
	[Address(RVA = "0x289E778", Offset = "0x289E778", VA = "0x289E778")]
	private void \u05BBږ\u060Cࡑ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("This is the 1000 Bananas button, and it was just clicked");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			return;
		}
	}

	// Token: 0x06000CE0 RID: 3296 RVA: 0x00043B14 File Offset: 0x00041D14
	[Token(Token = "0x6000CE0")]
	[Address(RVA = "0x289EA8C", Offset = "0x289EA8C", VA = "0x289EA8C")]
	private void FixedUpdate()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("Did Hit");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
			return;
		}
	}

	// Token: 0x06000CE1 RID: 3297 RVA: 0x00043BBC File Offset: 0x00041DBC
	[Token(Token = "0x6000CE1")]
	[Address(RVA = "0x289ED9C", Offset = "0x289ED9C", VA = "0x289ED9C")]
	public DeleteAndroidDebugger()
	{
	}

	// Token: 0x06000CE2 RID: 3298 RVA: 0x00043BD0 File Offset: 0x00041DD0
	[Token(Token = "0x6000CE2")]
	[Address(RVA = "0x289EDA4", Offset = "0x289EDA4", VA = "0x289EDA4")]
	private void \u0890ؤߪފ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("Room Name: ");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
			return;
		}
	}

	// Token: 0x06000CE3 RID: 3299 RVA: 0x00043C78 File Offset: 0x00041E78
	[Token(Token = "0x6000CE3")]
	[Address(RVA = "0x289F0B8", Offset = "0x289F0B8", VA = "0x289F0B8")]
	private void \u081E١Ӕࢦ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("hh:mmtt");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
		}
	}

	// Token: 0x06000CE4 RID: 3300 RVA: 0x00043D20 File Offset: 0x00041F20
	[Token(Token = "0x6000CE4")]
	[Address(RVA = "0x289F3C4", Offset = "0x289F3C4", VA = "0x289F3C4")]
	private void \u0887ࡒ\u0613\u07B8()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Transform transform3;
		Vector3 position3 = transform3.position;
		Debug.Log(".Please press the button if you would like to play alone");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform4;
			UnityEngine.Object.Destroy(transform4.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
			return;
		}
	}

	// Token: 0x06000CE5 RID: 3301 RVA: 0x00043DC4 File Offset: 0x00041FC4
	[Token(Token = "0x6000CE5")]
	[Address(RVA = "0x289F6D8", Offset = "0x289F6D8", VA = "0x289F6D8")]
	private void Ա\u07B9ߒݗ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Transform transform3;
		Vector3 position3 = transform3.position;
		Debug.Log("Open");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform4;
			UnityEngine.Object.Destroy(transform4.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
			return;
		}
	}

	// Token: 0x06000CE6 RID: 3302 RVA: 0x00043E68 File Offset: 0x00042068
	[Token(Token = "0x6000CE6")]
	[Address(RVA = "0x289F9EC", Offset = "0x289F9EC", VA = "0x289F9EC")]
	private void \u064Cޔաӕ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("username");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			GameObject gameObject = transform3.gameObject;
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
		}
	}

	// Token: 0x06000CE7 RID: 3303 RVA: 0x00043F0C File Offset: 0x0004210C
	[Token(Token = "0x6000CE7")]
	[Address(RVA = "0x289FCF8", Offset = "0x289FCF8", VA = "0x289FCF8")]
	private void \u07A7\u06DFࠈޖ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("{0} ({1})");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
			return;
		}
	}

	// Token: 0x06000CE8 RID: 3304 RVA: 0x00043FB4 File Offset: 0x000421B4
	[Token(Token = "0x6000CE8")]
	[Address(RVA = "0x28A000C", Offset = "0x28A000C", VA = "0x28A000C")]
	private void ڸՔ\u0594ԭ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("spooky guy true");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CE9 RID: 3305 RVA: 0x00044050 File Offset: 0x00042250
	[Token(Token = "0x6000CE9")]
	[Address(RVA = "0x28A0314", Offset = "0x28A0314", VA = "0x28A0314")]
	private void ۍ\u05CAۋݿ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("HDRP/Lit");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CEA RID: 3306 RVA: 0x000440EC File Offset: 0x000422EC
	[Token(Token = "0x6000CEA")]
	[Address(RVA = "0x28A061C", Offset = "0x28A061C", VA = "0x28A061C")]
	private void \u07AAح\u087Fܩ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("PushToTalk");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
			return;
		}
	}

	// Token: 0x06000CEB RID: 3307 RVA: 0x00044194 File Offset: 0x00042394
	[Token(Token = "0x6000CEB")]
	[Address(RVA = "0x28A0930", Offset = "0x28A0930", VA = "0x28A0930")]
	private void ޤ\u0610\u087A\u05AF()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("Diffuse");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CEC RID: 3308 RVA: 0x00044230 File Offset: 0x00042430
	[Token(Token = "0x6000CEC")]
	[Address(RVA = "0x28A0C38", Offset = "0x28A0C38", VA = "0x28A0C38")]
	private void Աࢦ\u05CAޡ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("_WobbleX");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
			return;
		}
	}

	// Token: 0x06000CED RID: 3309 RVA: 0x000442D8 File Offset: 0x000424D8
	[Token(Token = "0x6000CED")]
	[Address(RVA = "0x28A0F4C", Offset = "0x28A0F4C", VA = "0x28A0F4C")]
	private void \u07BFޥ٧\u073B()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("/");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
		}
	}

	// Token: 0x06000CEE RID: 3310 RVA: 0x00044380 File Offset: 0x00042580
	[Token(Token = "0x6000CEE")]
	[Address(RVA = "0x28A1258", Offset = "0x28A1258", VA = "0x28A1258")]
	private void Ԃڏݏ\u086D()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("Muted");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CEF RID: 3311 RVA: 0x0004441C File Offset: 0x0004261C
	[Token(Token = "0x6000CEF")]
	[Address(RVA = "0x28A1560", Offset = "0x28A1560", VA = "0x28A1560")]
	private void ߪձԛމ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("An error has occured while buying bananas, please restart your game and try again");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
			return;
		}
	}

	// Token: 0x06000CF0 RID: 3312 RVA: 0x000444C4 File Offset: 0x000426C4
	[Token(Token = "0x6000CF0")]
	[Address(RVA = "0x28A1874", Offset = "0x28A1874", VA = "0x28A1874")]
	private void \u089Fکߦݭ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("username");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CF1 RID: 3313 RVA: 0x00044560 File Offset: 0x00042760
	[Token(Token = "0x6000CF1")]
	[Address(RVA = "0x28A1B7C", Offset = "0x28A1B7C", VA = "0x28A1B7C")]
	private void ןأ\u05C0ب()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("5BN");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			return;
		}
	}

	// Token: 0x06000CF2 RID: 3314 RVA: 0x00044608 File Offset: 0x00042808
	[Token(Token = "0x6000CF2")]
	[Address(RVA = "0x28A1E90", Offset = "0x28A1E90", VA = "0x28A1E90")]
	private void \u0736\u06E0\u06E0څ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("containsStaff");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long ޓࡍ_u07FAܨ = 1L;
			this.ޓࡍ\u07FAܨ = (ޓࡍ_u07FAܨ != 0L);
		}
	}

	// Token: 0x06000CF3 RID: 3315 RVA: 0x000446B0 File Offset: 0x000428B0
	[Token(Token = "0x6000CF3")]
	[Address(RVA = "0x28A219C", Offset = "0x28A219C", VA = "0x28A219C")]
	private void Ԧ\u0876ծՎ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("Player");
		InputDevice inputDevice;
		if (inputDevice == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			return;
		}
	}

	// Token: 0x06000CF4 RID: 3316 RVA: 0x00044750 File Offset: 0x00042950
	[Token(Token = "0x6000CF4")]
	[Address(RVA = "0x28A24B0", Offset = "0x28A24B0", VA = "0x28A24B0")]
	private void \u05AAࢦ\u060AԞ()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		if (typeof(Debug).TypeHandle == null)
		{
		}
		Vector3 position3 = base.transform.position;
		Debug.Log("Thumb");
		if (InputDevices.GetDeviceAtXRNode(this.ࢳҾپݳ) == null)
		{
		}
		if (!this.ޓࡍ\u07FAܨ)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			return;
		}
	}

	// Token: 0x040001D3 RID: 467
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001D3")]
	public XRNode ࢳҾپݳ;

	// Token: 0x040001D4 RID: 468
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40001D4")]
	private bool ޓࡍ\u07FAܨ;
}
