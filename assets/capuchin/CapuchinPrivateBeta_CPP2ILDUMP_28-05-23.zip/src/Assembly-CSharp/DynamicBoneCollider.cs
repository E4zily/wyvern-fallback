﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200000C RID: 12
[Token(Token = "0x200000C")]
[AddComponentMenu("Dynamic Bone/Dynamic Bone Collider")]
public class DynamicBoneCollider : DynamicBoneColliderBase
{
	// Token: 0x06000162 RID: 354 RVA: 0x0000E95C File Offset: 0x0000CB5C
	[Token(Token = "0x6000162")]
	[Address(RVA = "0x2FD174C", Offset = "0x2FD174C", VA = "0x2FD174C")]
	private static bool ՠӳۏڴ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000162)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ՠӳۏڴ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000163 RID: 355 RVA: 0x0000E980 File Offset: 0x0000CB80
	[Token(Token = "0x6000163")]
	[Address(RVA = "0x2FD19B8", Offset = "0x2FD19B8", VA = "0x2FD19B8")]
	private static bool \u066Cؾ\u0608ӵ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x06000164 RID: 356 RVA: 0x0000E990 File Offset: 0x0000CB90
	[Token(Token = "0x6000164")]
	[Address(RVA = "0x2FD1A74", Offset = "0x2FD1A74", VA = "0x2FD1A74")]
	private static void \u07F6ߜ\u07F0ذ(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x06000165 RID: 357 RVA: 0x0000E9A4 File Offset: 0x0000CBA4
	[Token(Token = "0x6000165")]
	[Address(RVA = "0x2FD1AF8", Offset = "0x2FD1AF8", VA = "0x2FD1AF8")]
	private static bool ݣ\u060Aظߙ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000165)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ݣ؊ظߙ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000166 RID: 358 RVA: 0x0000E9C8 File Offset: 0x0000CBC8
	[Token(Token = "0x6000166")]
	[Address(RVA = "0x2FD1D60", Offset = "0x2FD1D60", VA = "0x2FD1D60")]
	private void Ԧե\u088A\u0838()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x06000167 RID: 359 RVA: 0x0000EA08 File Offset: 0x0000CC08
	[Token(Token = "0x6000167")]
	[Address(RVA = "0x2FD1DCC", Offset = "0x2FD1DCC", VA = "0x2FD1DCC")]
	private static void \u0734גޣڰ(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x06000168 RID: 360 RVA: 0x0000EA1C File Offset: 0x0000CC1C
	[Token(Token = "0x6000168")]
	[Address(RVA = "0x2FD1E50", Offset = "0x2FD1E50", VA = "0x2FD1E50")]
	private static bool ࠆ\u058Fݵޢ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x06000169 RID: 361 RVA: 0x0000EA2C File Offset: 0x0000CC2C
	[Token(Token = "0x6000169")]
	[Address(RVA = "0x2FD1F20", Offset = "0x2FD1F20", VA = "0x2FD1F20")]
	private static bool ܟ\u059Eݕތ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x0600016A RID: 362 RVA: 0x0000EA3C File Offset: 0x0000CC3C
	[Token(Token = "0x600016A")]
	[Address(RVA = "0x2FD1FF0", Offset = "0x2FD1FF0", VA = "0x2FD1FF0")]
	private static bool ݙࠄ߆\u0748(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (0600016A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ݙࠄ߆݈(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600016B RID: 363 RVA: 0x0000EA60 File Offset: 0x0000CC60
	[Token(Token = "0x600016B")]
	[Address(RVA = "0x2FD2264", Offset = "0x2FD2264", VA = "0x2FD2264")]
	private void ޒࡐ\u07B3أ()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x0600016C RID: 364 RVA: 0x0000EAA0 File Offset: 0x0000CCA0
	[Token(Token = "0x600016C")]
	[Address(RVA = "0x2FD22CC", Offset = "0x2FD22CC", VA = "0x2FD22CC")]
	private static bool \u07A8\u0558ݴ\u07AE(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x0600016D RID: 365 RVA: 0x0000EAB0 File Offset: 0x0000CCB0
	[Token(Token = "0x600016D")]
	[Address(RVA = "0x2FD24DC", Offset = "0x2FD24DC", VA = "0x2FD24DC")]
	private void \u05F3\u0590تࢥ()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x0600016E RID: 366 RVA: 0x0000EAF0 File Offset: 0x0000CCF0
	[Token(Token = "0x600016E")]
	[Address(RVA = "0x2FD2548", Offset = "0x2FD2548", VA = "0x2FD2548")]
	private static bool ץ\u0605\u05EE\u065E(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (0600016E)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ץ؅׮ٞ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600016F RID: 367 RVA: 0x0000EB14 File Offset: 0x0000CD14
	[Token(Token = "0x600016F")]
	[Address(RVA = "0x2FD27DC", Offset = "0x2FD27DC", VA = "0x2FD27DC")]
	private static bool ߘ\u05A0ӑ٦(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x06000170 RID: 368 RVA: 0x0000EB24 File Offset: 0x0000CD24
	[Token(Token = "0x6000170")]
	[Address(RVA = "0x2FD2898", Offset = "0x2FD2898", VA = "0x2FD2898")]
	private static void މڝ٠\u0650(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x06000171 RID: 369 RVA: 0x0000EB38 File Offset: 0x0000CD38
	[Token(Token = "0x6000171")]
	[Address(RVA = "0x2FD291C", Offset = "0x2FD291C", VA = "0x2FD291C")]
	private static void ࠎ\u05AEٲޱ(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x06000172 RID: 370 RVA: 0x0000EB4C File Offset: 0x0000CD4C
	[Token(Token = "0x6000172")]
	[Address(RVA = "0x2FD29A0", Offset = "0x2FD29A0", VA = "0x2FD29A0")]
	private static bool נղ\u0746ޛ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x06000173 RID: 371 RVA: 0x0000EB60 File Offset: 0x0000CD60
	[Token(Token = "0x6000173")]
	[Address(RVA = "0x2FD2BCC", Offset = "0x2FD2BCC", VA = "0x2FD2BCC")]
	private static bool \u05CEܣڼܤ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000173)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::׎ܣڼܤ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000174 RID: 372 RVA: 0x0000EB84 File Offset: 0x0000CD84
	[Token(Token = "0x6000174")]
	[Address(RVA = "0x2FD2E70", Offset = "0x2FD2E70", VA = "0x2FD2E70")]
	private static bool Ҽ\u07B5ڢࡆ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000174)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::Ҽ޵ڢࡆ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000175 RID: 373 RVA: 0x0000EBA8 File Offset: 0x0000CDA8
	[Token(Token = "0x6000175")]
	[Address(RVA = "0x2FD3110", Offset = "0x2FD3110", VA = "0x2FD3110")]
	private static bool ٹڃߠ٨(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000175)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ٹڃߠ٨(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000176 RID: 374 RVA: 0x0000EBC8 File Offset: 0x0000CDC8
	[Token(Token = "0x6000176")]
	[Address(RVA = "0x2FD336C", Offset = "0x2FD336C", VA = "0x2FD336C")]
	private static bool \u06E0בւ\u0706(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x06000177 RID: 375 RVA: 0x0000EBDC File Offset: 0x0000CDDC
	[Token(Token = "0x6000177")]
	[Address(RVA = "0x2FD355C", Offset = "0x2FD355C", VA = "0x2FD355C")]
	private static bool \u087Bԫӂ\u0872(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x06000178 RID: 376 RVA: 0x0000EBF0 File Offset: 0x0000CDF0
	[Token(Token = "0x6000178")]
	[Address(RVA = "0x2FD3784", Offset = "0x2FD3784", VA = "0x2FD3784")]
	private static bool ݴԲ\u061Cޝ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x06000179 RID: 377 RVA: 0x0000EC00 File Offset: 0x0000CE00
	[Token(Token = "0x6000179")]
	[Address(RVA = "0x2FD3854", Offset = "0x2FD3854", VA = "0x2FD3854")]
	private static bool ކ\u0822ߎע(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x0600017A RID: 378 RVA: 0x0000EC14 File Offset: 0x0000CE14
	[Token(Token = "0x600017A")]
	[Address(RVA = "0x2FD3A54", Offset = "0x2FD3A54", VA = "0x2FD3A54")]
	private static bool \u0889\u0833զݱ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x0600017B RID: 379 RVA: 0x0000EC24 File Offset: 0x0000CE24
	[Token(Token = "0x600017B")]
	[Address(RVA = "0x2FD3C68", Offset = "0x2FD3C68", VA = "0x2FD3C68", Slot = "26")]
	public override void \u0711ӿ\u08B5ܥ()
	{
		Vector3 lossyScale = base.transform.lossyScale;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		this.چԒڈ\u085F = u081E_u07F5ݑ_u082E;
		DynamicBoneColliderBase.ߋڛڐ\u0659 ߌع_u0702ӷ = this.ߌع\u0702ӷ;
		float x = this.\u07BEօࢡ\u05FD.x;
		float y = this.\u07BEօࢡ\u05FD.y;
		float z = this.\u07BEօࢡ\u05FD.z;
		if (ߌع_u0702ӷ == DynamicBoneColliderBase.ߋڛڐ\u0659.\u06DBޣݦض)
		{
			return;
		}
		Transform transform = base.transform;
		float num;
		this.ر\u0604ࡩ\u0817.x = num;
		float y2;
		this.ر\u0604ࡩ\u0817.y = y2;
		float z2;
		this.ر\u0604ࡩ\u0817.z = z2;
		Transform transform2 = base.transform;
		float z3 = this.ر\u0604ࡩ\u0817.z;
		this.Ӽډ\u0591\u0826.x = num;
		this.Ӽډ\u0591\u0826.y = y2;
		this.Ӽډ\u0591\u0826.z = z2;
		Vector3 vector;
		float magnitude = vector.magnitude;
		DynamicBoneColliderBase.Փ\u0839\u0734ߍ ٤_u058Fࢬࡓ = this.٤\u058Fࢬࡓ;
		this.\u081CӄӤࠈ = num;
	}

	// Token: 0x0600017C RID: 380 RVA: 0x0000EE70 File Offset: 0x0000D070
	[Token(Token = "0x600017C")]
	[Address(RVA = "0x2FD3F80", Offset = "0x2FD3F80", VA = "0x2FD3F80")]
	private void شݞ\u0610ԧ()
	{
		bool enabled = base.enabled;
		if (this.٤\u058Fࢬࡓ != DynamicBoneColliderBase.Փ\u0839\u0734ߍ.ݣ٠ࢥ\u0894)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
		int u05A9ۈӌ_u = this.\u05A9ۈӌ\u0874;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		float x = this.ر\u0604ࡩ\u0817.x;
		float y = this.ر\u0604ࡩ\u0817.y;
		float z = this.ر\u0604ࡩ\u0817.z;
		float x2 = this.Ӽډ\u0591\u0826.x;
		float y2 = this.Ӽډ\u0591\u0826.y;
		float z2 = this.Ӽډ\u0591\u0826.z;
	}

	// Token: 0x0600017D RID: 381 RVA: 0x0000EF94 File Offset: 0x0000D194
	[Token(Token = "0x600017D")]
	[Address(RVA = "0x2FD4164", Offset = "0x2FD4164", VA = "0x2FD4164")]
	private static bool \u086Bࡣر\u086D(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (0600017D)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::࡫ࡣر࡭(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600017E RID: 382 RVA: 0x0000EFB8 File Offset: 0x0000D1B8
	[Token(Token = "0x600017E")]
	[Address(RVA = "0x2FD43CC", Offset = "0x2FD43CC", VA = "0x2FD43CC")]
	private void ߞٿۋڊ()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x0600017F RID: 383 RVA: 0x0000EFF8 File Offset: 0x0000D1F8
	[Token(Token = "0x600017F")]
	[Address(RVA = "0x2FD4438", Offset = "0x2FD4438", VA = "0x2FD4438")]
	private void \u081Dә\u0828կ()
	{
		bool enabled = base.enabled;
		if (this.٤\u058Fࢬࡓ != DynamicBoneColliderBase.Փ\u0839\u0734ߍ.ݣ٠ࢥ\u0894)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
		int u05A9ۈӌ_u = this.\u05A9ۈӌ\u0874;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		float x = this.ر\u0604ࡩ\u0817.x;
		float y = this.ر\u0604ࡩ\u0817.y;
		float z = this.ر\u0604ࡩ\u0817.z;
		float x2 = this.Ӽډ\u0591\u0826.x;
		float y2 = this.Ӽډ\u0591\u0826.y;
		float z2 = this.Ӽډ\u0591\u0826.z;
	}

	// Token: 0x06000180 RID: 384 RVA: 0x0000F11C File Offset: 0x0000D31C
	[Token(Token = "0x6000180")]
	[Address(RVA = "0x2FD4618", Offset = "0x2FD4618", VA = "0x2FD4618")]
	private static bool ٤ݷӯӽ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x06000181 RID: 385 RVA: 0x0000F134 File Offset: 0x0000D334
	[Token(Token = "0x6000181")]
	[Address(RVA = "0x2FD481C", Offset = "0x2FD481C", VA = "0x2FD481C")]
	private void OnDrawGizmosSelected()
	{
		bool enabled = base.enabled;
		if (this.٤\u058Fࢬࡓ != DynamicBoneColliderBase.Փ\u0839\u0734ߍ.ݣ٠ࢥ\u0894)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
		int u05A9ۈӌ_u = this.\u05A9ۈӌ\u0874;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		float x = this.ر\u0604ࡩ\u0817.x;
		float y = this.ر\u0604ࡩ\u0817.y;
		float z = this.ر\u0604ࡩ\u0817.z;
		float x2 = this.Ӽډ\u0591\u0826.x;
		float y2 = this.Ӽډ\u0591\u0826.y;
		float z2 = this.Ӽډ\u0591\u0826.z;
	}

	// Token: 0x06000182 RID: 386 RVA: 0x0000F23C File Offset: 0x0000D43C
	[Token(Token = "0x6000182")]
	[Address(RVA = "0x2FD40E0", Offset = "0x2FD40E0", VA = "0x2FD40E0")]
	private static void ۸\u061A\u070B\u06D7(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x06000183 RID: 387 RVA: 0x0000F250 File Offset: 0x0000D450
	[Token(Token = "0x6000183")]
	[Address(RVA = "0x2FD4974", Offset = "0x2FD4974", VA = "0x2FD4974")]
	private void \u0887ېՑ\u0871()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x06000184 RID: 388 RVA: 0x0000F290 File Offset: 0x0000D490
	[Token(Token = "0x6000184")]
	[Address(RVA = "0x2FD49E0", Offset = "0x2FD49E0", VA = "0x2FD49E0")]
	private static bool \u0653ڕ\u05C3ߔ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000184)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ٓڕ׃ߔ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000185 RID: 389 RVA: 0x0000F2B0 File Offset: 0x0000D4B0
	[Token(Token = "0x6000185")]
	[Address(RVA = "0x2FD4C3C", Offset = "0x2FD4C3C", VA = "0x2FD4C3C")]
	private static bool \u05A7ࠔ\u0817\u070F(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x06000186 RID: 390 RVA: 0x0000F2C4 File Offset: 0x0000D4C4
	[Token(Token = "0x6000186")]
	[Address(RVA = "0x2FD4E60", Offset = "0x2FD4E60", VA = "0x2FD4E60")]
	private static bool \u0734ءܠ\u05BB(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000186)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ܴءܠֻ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000187 RID: 391 RVA: 0x0000F2E4 File Offset: 0x0000D4E4
	[Token(Token = "0x6000187")]
	[Address(RVA = "0x2FD5100", Offset = "0x2FD5100", VA = "0x2FD5100")]
	private static bool \u07A7ߡ\u0653\u055C(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x06000188 RID: 392 RVA: 0x0000F2F4 File Offset: 0x0000D4F4
	[Token(Token = "0x6000188")]
	[Address(RVA = "0x2FD51B4", Offset = "0x2FD51B4", VA = "0x2FD51B4", Slot = "31")]
	public override bool ٲآڀ\u0557(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828)
	{
		int u05A9ۈӌ_u = this.\u05A9ۈӌ\u0874;
		float x = this.ر\u0604ࡩ\u0817.x;
		float y = this.ر\u0604ࡩ\u0817.y;
		float z = this.ر\u0604ࡩ\u0817.z;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		bool result;
		return result;
	}

	// Token: 0x06000189 RID: 393 RVA: 0x0000F348 File Offset: 0x0000D548
	[Token(Token = "0x6000189")]
	[Address(RVA = "0x2FD57E4", Offset = "0x2FD57E4", VA = "0x2FD57E4")]
	private static bool ݰڬࠑۄ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000189)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ݰڬࠑۄ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600018A RID: 394 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x600018A")]
	[Address(RVA = "0x2FD5A48", Offset = "0x2FD5A48", VA = "0x2FD5A48")]
	private static bool פٸۋ\u05B5(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x0600018B RID: 395 RVA: 0x0000F384 File Offset: 0x0000D584
	[Token(Token = "0x600018B")]
	[Address(RVA = "0x2FD5C54", Offset = "0x2FD5C54", VA = "0x2FD5C54")]
	private static bool ےڠӜ\u0601(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x0600018C RID: 396 RVA: 0x0000F394 File Offset: 0x0000D594
	[Token(Token = "0x600018C")]
	[Address(RVA = "0x2FD5D10", Offset = "0x2FD5D10", VA = "0x2FD5D10")]
	private void ࠃ۴ࢨ\u06E4()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x0600018D RID: 397 RVA: 0x0000F3D4 File Offset: 0x0000D5D4
	[Token(Token = "0x600018D")]
	[Address(RVA = "0x2FD5D7C", Offset = "0x2FD5D7C", VA = "0x2FD5D7C")]
	private void ݚو\u0825ف()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x0600018E RID: 398 RVA: 0x0000F414 File Offset: 0x0000D614
	[Token(Token = "0x600018E")]
	[Address(RVA = "0x2FD5DE8", Offset = "0x2FD5DE8", VA = "0x2FD5DE8")]
	private static bool \u089F\u070Fӱ\u07AD(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x0600018F RID: 399 RVA: 0x0000F424 File Offset: 0x0000D624
	[Token(Token = "0x600018F")]
	[Address(RVA = "0x2FD52C4", Offset = "0x2FD52C4", VA = "0x2FD52C4")]
	private static bool \u089C\u061CԔ\u066A(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x06000190 RID: 400 RVA: 0x0000F434 File Offset: 0x0000D634
	[Token(Token = "0x6000190")]
	[Address(RVA = "0x2FD5FD8", Offset = "0x2FD5FD8", VA = "0x2FD5FD8")]
	private void \u058CԲ\u06D9ت()
	{
		bool enabled = base.enabled;
		if (this.٤\u058Fࢬࡓ != DynamicBoneColliderBase.Փ\u0839\u0734ߍ.ݣ٠ࢥ\u0894)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
		int u05A9ۈӌ_u = this.\u05A9ۈӌ\u0874;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		float z = this.ر\u0604ࡩ\u0817.z;
		float x = this.Ӽډ\u0591\u0826.x;
	}

	// Token: 0x06000191 RID: 401 RVA: 0x0000F524 File Offset: 0x0000D724
	[Token(Token = "0x6000191")]
	[Address(RVA = "0x2FD60B0", Offset = "0x2FD60B0", VA = "0x2FD60B0")]
	private static bool \u0709گޱ\u083E(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x06000192 RID: 402 RVA: 0x0000F534 File Offset: 0x0000D734
	[Token(Token = "0x6000192")]
	[Address(RVA = "0x2FD6164", Offset = "0x2FD6164", VA = "0x2FD6164")]
	private static bool \u082Eןمߖ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000192)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::࠮ןمߖ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000193 RID: 403 RVA: 0x0000F558 File Offset: 0x0000D758
	[Token(Token = "0x6000193")]
	[Address(RVA = "0x2FD63D0", Offset = "0x2FD63D0", VA = "0x2FD63D0")]
	private static bool ߗ\u05A6\u0618ۊ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x06000194 RID: 404 RVA: 0x0000F56C File Offset: 0x0000D76C
	[Token(Token = "0x6000194")]
	[Address(RVA = "0x2FD65D8", Offset = "0x2FD65D8", VA = "0x2FD65D8")]
	private static bool ךԊ\u0823א(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x06000195 RID: 405 RVA: 0x0000F580 File Offset: 0x0000D780
	[Token(Token = "0x6000195")]
	[Address(RVA = "0x2FD67D4", Offset = "0x2FD67D4", VA = "0x2FD67D4")]
	private static bool ة\u0604ܨپ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000195)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ة؄ܨپ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000196 RID: 406 RVA: 0x0000F5A4 File Offset: 0x0000D7A4
	[Token(Token = "0x6000196")]
	[Address(RVA = "0x2FD6A40", Offset = "0x2FD6A40", VA = "0x2FD6A40")]
	private void ࢪߝ\u073B\u05A2()
	{
		bool enabled = base.enabled;
		if (this.٤\u058Fࢬࡓ != DynamicBoneColliderBase.Փ\u0839\u0734ߍ.ݣ٠ࢥ\u0894)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
		int u05A9ۈӌ_u = this.\u05A9ۈӌ\u0874;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		float x = this.ر\u0604ࡩ\u0817.x;
		float y = this.ر\u0604ࡩ\u0817.y;
		float z = this.ر\u0604ࡩ\u0817.z;
		float x2 = this.Ӽډ\u0591\u0826.x;
		float y2 = this.Ӽډ\u0591\u0826.y;
		float z2 = this.Ӽډ\u0591\u0826.z;
	}

	// Token: 0x06000197 RID: 407 RVA: 0x0000F6C8 File Offset: 0x0000D8C8
	[Token(Token = "0x6000197")]
	[Address(RVA = "0x2FD6BA0", Offset = "0x2FD6BA0", VA = "0x2FD6BA0")]
	private static bool \u060Eիߎࢢ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000197)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::؎իߎࢢ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000198 RID: 408 RVA: 0x0000F6EC File Offset: 0x0000D8EC
	[Token(Token = "0x6000198")]
	[Address(RVA = "0x2FD6E44", Offset = "0x2FD6E44", VA = "0x2FD6E44")]
	private static bool Ծր\u07BE\u0612(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x06000199 RID: 409 RVA: 0x0000F6FC File Offset: 0x0000D8FC
	[Token(Token = "0x6000199")]
	[Address(RVA = "0x2FD6EF8", Offset = "0x2FD6EF8", VA = "0x2FD6EF8")]
	private static bool ږ\u07FFځӲ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (06000199)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ږ߿ځӲ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600019A RID: 410 RVA: 0x0000F720 File Offset: 0x0000D920
	[Token(Token = "0x600019A")]
	[Address(RVA = "0x2FD719C", Offset = "0x2FD719C", VA = "0x2FD719C")]
	private static bool ם\u05C7ࡘ\u06FE(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x0600019B RID: 411 RVA: 0x0000F734 File Offset: 0x0000D934
	[Token(Token = "0x600019B")]
	[Address(RVA = "0x2FD73CC", Offset = "0x2FD73CC", VA = "0x2FD73CC")]
	private void ޕԡӭؼ()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x0600019C RID: 412 RVA: 0x0000F770 File Offset: 0x0000D970
	[Token(Token = "0x600019C")]
	[Address(RVA = "0x2FD7438", Offset = "0x2FD7438", VA = "0x2FD7438")]
	private static bool ڳԦߊࠇ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x0600019D RID: 413 RVA: 0x0000F780 File Offset: 0x0000D980
	[Token(Token = "0x600019D")]
	[Address(RVA = "0x2FD74EC", Offset = "0x2FD74EC", VA = "0x2FD74EC")]
	private static bool ޚ\u074Bࡈӱ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (0600019D)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ޚ݋ࡈӱ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600019E RID: 414 RVA: 0x0000F7A4 File Offset: 0x0000D9A4
	[Token(Token = "0x600019E")]
	[Address(RVA = "0x2FD7754", Offset = "0x2FD7754", VA = "0x2FD7754")]
	private static bool ײ\u05CD\u070Dࡢ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x0600019F RID: 415 RVA: 0x0000F7B8 File Offset: 0x0000D9B8
	[Token(Token = "0x600019F")]
	[Address(RVA = "0x2FD7978", Offset = "0x2FD7978", VA = "0x2FD7978")]
	private static bool ࡗܬࡐ\u086F(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x0000F7CC File Offset: 0x0000D9CC
	[Token(Token = "0x60001A0")]
	[Address(RVA = "0x2FD7BA8", Offset = "0x2FD7BA8", VA = "0x2FD7BA8")]
	private static bool Ӛࡄ\u055Dࠌ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x0000F7DC File Offset: 0x0000D9DC
	[Token(Token = "0x60001A1")]
	[Address(RVA = "0x2FD7C78", Offset = "0x2FD7C78", VA = "0x2FD7C78")]
	private static bool \u05FCڃٻځ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001A2 RID: 418 RVA: 0x0000F7F0 File Offset: 0x0000D9F0
	[Token(Token = "0x60001A2")]
	[Address(RVA = "0x2FD538C", Offset = "0x2FD538C", VA = "0x2FD538C")]
	private static bool عԚժݛ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001A3 RID: 419 RVA: 0x0000F804 File Offset: 0x0000DA04
	[Token(Token = "0x60001A3")]
	[Address(RVA = "0x2FD7EA8", Offset = "0x2FD7EA8", VA = "0x2FD7EA8")]
	private static bool \u070Bࢦ\u06EB۴(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001A4 RID: 420 RVA: 0x0000F818 File Offset: 0x0000DA18
	[Token(Token = "0x60001A4")]
	[Address(RVA = "0x2FD80C8", Offset = "0x2FD80C8", VA = "0x2FD80C8")]
	private static bool Ջڭ\u059Fڌ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001A4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::Ջڭ֟ڌ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001A5 RID: 421 RVA: 0x0000F83C File Offset: 0x0000DA3C
	[Token(Token = "0x60001A5")]
	[Address(RVA = "0x2FD8368", Offset = "0x2FD8368", VA = "0x2FD8368")]
	private static bool թ\u085B߀\u0615(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001A6 RID: 422 RVA: 0x0000F84C File Offset: 0x0000DA4C
	[Token(Token = "0x60001A6")]
	[Address(RVA = "0x2FD8568", Offset = "0x2FD8568", VA = "0x2FD8568")]
	private static void ڛࠓ\u089C\u073D(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x060001A7 RID: 423 RVA: 0x0000F860 File Offset: 0x0000DA60
	[Token(Token = "0x60001A7")]
	[Address(RVA = "0x2FD85EC", Offset = "0x2FD85EC", VA = "0x2FD85EC")]
	private static bool ࡩפ\u07B0\u0877(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001A8 RID: 424 RVA: 0x0000F870 File Offset: 0x0000DA70
	[Token(Token = "0x60001A8")]
	[Address(RVA = "0x2FD86A0", Offset = "0x2FD86A0", VA = "0x2FD86A0")]
	private void զԴԒՁ()
	{
		bool enabled = base.enabled;
		if (this.٤\u058Fࢬࡓ != DynamicBoneColliderBase.Փ\u0839\u0734ߍ.ݣ٠ࢥ\u0894)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
		int u05A9ۈӌ_u = this.\u05A9ۈӌ\u0874;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		float x = this.ر\u0604ࡩ\u0817.x;
		float y = this.ر\u0604ࡩ\u0817.y;
		float z = this.ر\u0604ࡩ\u0817.z;
		float x2 = this.Ӽډ\u0591\u0826.x;
		float y2 = this.Ӽډ\u0591\u0826.y;
		float z2 = this.Ӽډ\u0591\u0826.z;
	}

	// Token: 0x060001A9 RID: 425 RVA: 0x0000F978 File Offset: 0x0000DB78
	[Token(Token = "0x60001A9")]
	[Address(RVA = "0x2FD877C", Offset = "0x2FD877C", VA = "0x2FD877C")]
	private static bool Էց\u07AEࡧ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001AA RID: 426 RVA: 0x0000F988 File Offset: 0x0000DB88
	[Token(Token = "0x60001AA")]
	[Address(RVA = "0x2FD8830", Offset = "0x2FD8830", VA = "0x2FD8830")]
	private static bool ک\u082D\u058FԷ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001AB RID: 427 RVA: 0x0000F998 File Offset: 0x0000DB98
	[Token(Token = "0x60001AB")]
	[Address(RVA = "0x2FD88E4", Offset = "0x2FD88E4", VA = "0x2FD88E4")]
	private static bool Րٷڶ\u088D(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001AB)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::Րٷڶࢍ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001AC RID: 428 RVA: 0x0000F9BC File Offset: 0x0000DBBC
	[Token(Token = "0x60001AC")]
	[Address(RVA = "0x2FD8B50", Offset = "0x2FD8B50", VA = "0x2FD8B50")]
	private static bool ࠈצԝ\u0659(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001AD RID: 429 RVA: 0x0000F9CC File Offset: 0x0000DBCC
	[Token(Token = "0x60001AD")]
	[Address(RVA = "0x2FD8C1C", Offset = "0x2FD8C1C", VA = "0x2FD8C1C")]
	private static bool ק\u073C\u0592ܨ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001AD)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::קܼ֒ܨ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001AE RID: 430 RVA: 0x0000F9F0 File Offset: 0x0000DBF0
	[Token(Token = "0x60001AE")]
	[Address(RVA = "0x2FD8EC0", Offset = "0x2FD8EC0", VA = "0x2FD8EC0")]
	private static void ڬܣޟտ(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x060001AF RID: 431 RVA: 0x0000FA04 File Offset: 0x0000DC04
	[Token(Token = "0x60001AF")]
	[Address(RVA = "0x2FD8F44", Offset = "0x2FD8F44", VA = "0x2FD8F44")]
	private void \u06E3\u058Bػԟ()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x060001B0 RID: 432 RVA: 0x0000FA44 File Offset: 0x0000DC44
	[Token(Token = "0x60001B0")]
	[Address(RVA = "0x2FD8FB0", Offset = "0x2FD8FB0", VA = "0x2FD8FB0")]
	private static bool \u05B9ސ٠\u05BC(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001B0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ֹސ٠ּ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_0A, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001B1 RID: 433 RVA: 0x0000FA60 File Offset: 0x0000DC60
	[Token(Token = "0x60001B1")]
	[Address(RVA = "0x2FD9208", Offset = "0x2FD9208", VA = "0x2FD9208")]
	private static bool ڐڽӫݕ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001B2 RID: 434 RVA: 0x0000FA74 File Offset: 0x0000DC74
	[Token(Token = "0x60001B2")]
	[Address(RVA = "0x2FD9430", Offset = "0x2FD9430", VA = "0x2FD9430")]
	private void \u0597\u05FFՆࡄ()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x060001B3 RID: 435 RVA: 0x0000FAB4 File Offset: 0x0000DCB4
	[Token(Token = "0x60001B3")]
	[Address(RVA = "0x2FD949C", Offset = "0x2FD949C", VA = "0x2FD949C")]
	private static bool ڗֈ\u07BAޔ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001B3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ڗֈ޺ޔ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001B4 RID: 436 RVA: 0x0000FAD8 File Offset: 0x0000DCD8
	[Token(Token = "0x60001B4")]
	[Address(RVA = "0x2FD9740", Offset = "0x2FD9740", VA = "0x2FD9740")]
	private static bool \u07EEڀٿՐ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001B5 RID: 437 RVA: 0x0000FAEC File Offset: 0x0000DCEC
	[Token(Token = "0x60001B5")]
	[Address(RVA = "0x2FD993C", Offset = "0x2FD993C", VA = "0x2FD993C")]
	private static bool \u07AFԜ\u0600ך(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001B5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ޯԜ؀ך(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001B6 RID: 438 RVA: 0x0000FB10 File Offset: 0x0000DD10
	[Token(Token = "0x60001B6")]
	[Address(RVA = "0x2FD9BA0", Offset = "0x2FD9BA0", VA = "0x2FD9BA0")]
	private static bool ۏԿۉ\u0593(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001B7 RID: 439 RVA: 0x0000FB20 File Offset: 0x0000DD20
	[Token(Token = "0x60001B7")]
	[Address(RVA = "0x2FD9C5C", Offset = "0x2FD9C5C", VA = "0x2FD9C5C")]
	private static bool ࠃ\u0599\u05A6ؤ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001B7)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ࠃ֦֙ؤ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001B8 RID: 440 RVA: 0x0000FB3C File Offset: 0x0000DD3C
	[Token(Token = "0x60001B8")]
	[Address(RVA = "0x2FD9EB4", Offset = "0x2FD9EB4", VA = "0x2FD9EB4")]
	private static bool لࢪۆڰ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001B8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::لࢪۆڰ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001B9 RID: 441 RVA: 0x0000FB60 File Offset: 0x0000DD60
	[Token(Token = "0x60001B9")]
	[Address(RVA = "0x2FDA154", Offset = "0x2FDA154", VA = "0x2FDA154")]
	private void \u088Bࡃוݔ()
	{
		bool enabled = base.enabled;
		Color magenta = Color.magenta;
	}

	// Token: 0x060001BA RID: 442 RVA: 0x0000FC7C File Offset: 0x0000DE7C
	[Token(Token = "0x60001BA")]
	[Address(RVA = "0x2FDA2B4", Offset = "0x2FDA2B4", VA = "0x2FDA2B4")]
	private static bool \u065A\u06ED\u0825Ӟ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001BB RID: 443 RVA: 0x0000FC8C File Offset: 0x0000DE8C
	[Token(Token = "0x60001BB")]
	[Address(RVA = "0x2FD405C", Offset = "0x2FD405C", VA = "0x2FD405C")]
	private static void ڳ٩\u0837\u07A9(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x060001BC RID: 444 RVA: 0x0000FCA0 File Offset: 0x0000DEA0
	[Token(Token = "0x60001BC")]
	[Address(RVA = "0x2FDA368", Offset = "0x2FDA368", VA = "0x2FDA368")]
	private static bool \u059Fԟ\u05FD\u0705(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001BD RID: 445 RVA: 0x0000FCB8 File Offset: 0x0000DEB8
	[Token(Token = "0x60001BD")]
	[Address(RVA = "0x2FDA56C", Offset = "0x2FDA56C", VA = "0x2FDA56C")]
	public DynamicBoneCollider()
	{
		long u07FE_u05F7ۿب = 1056964608L;
		this.\u07FE\u05F7ۿب = (float)u07FE_u05F7ۿب;
		base..ctor();
	}

	// Token: 0x060001BE RID: 446 RVA: 0x0000FCD8 File Offset: 0x0000DED8
	[Token(Token = "0x60001BE")]
	[Address(RVA = "0x2FDA57C", Offset = "0x2FDA57C", VA = "0x2FDA57C")]
	private void Ֆ\u07F9ܝݟ()
	{
		bool enabled = base.enabled;
		if (this.٤\u058Fࢬࡓ != DynamicBoneColliderBase.Փ\u0839\u0734ߍ.ݣ٠ࢥ\u0894)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		float x = this.ر\u0604ࡩ\u0817.x;
		float y = this.ر\u0604ࡩ\u0817.y;
		float z = this.ر\u0604ࡩ\u0817.z;
		float x2 = this.Ӽډ\u0591\u0826.x;
		float y2 = this.Ӽډ\u0591\u0826.y;
		float z2 = this.Ӽډ\u0591\u0826.z;
	}

	// Token: 0x060001BF RID: 447 RVA: 0x0000FDF0 File Offset: 0x0000DFF0
	[Token(Token = "0x60001BF")]
	[Address(RVA = "0x2FDA650", Offset = "0x2FDA650", VA = "0x2FDA650")]
	private static bool ڜࢣނ\u055F(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001C0 RID: 448 RVA: 0x0000FE04 File Offset: 0x0000E004
	[Token(Token = "0x60001C0")]
	[Address(RVA = "0x2FD6B1C", Offset = "0x2FD6B1C", VA = "0x2FD6B1C")]
	private static void ߨٱՔӺ(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x060001C1 RID: 449 RVA: 0x0000FE18 File Offset: 0x0000E018
	[Token(Token = "0x60001C1")]
	[Address(RVA = "0x2FDA850", Offset = "0x2FDA850", VA = "0x2FDA850")]
	private static bool ݭ\u0883ڀݯ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001C1)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ݭࢃڀݯ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x0000FE34 File Offset: 0x0000E034
	[Token(Token = "0x60001C2")]
	[Address(RVA = "0x2FDAAA8", Offset = "0x2FDAAA8", VA = "0x2FDAAA8")]
	private static bool \u0742ࡨޚ\u0705(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001C2)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::݂ࡨޚ܅(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001C3 RID: 451 RVA: 0x0000FE58 File Offset: 0x0000E058
	[Token(Token = "0x60001C3")]
	[Address(RVA = "0x2FDAD10", Offset = "0x2FDAD10", VA = "0x2FDAD10")]
	private static bool Ԓޘߊػ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001C3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::Ԓޘߊػ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001C4 RID: 452 RVA: 0x0000FE7C File Offset: 0x0000E07C
	[Token(Token = "0x60001C4")]
	[Address(RVA = "0x2FDAFAC", Offset = "0x2FDAFAC", VA = "0x2FDAFAC")]
	private static bool ڐݗޡڽ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001C4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ڐݗޡڽ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001C5 RID: 453 RVA: 0x0000FEA0 File Offset: 0x0000E0A0
	[Token(Token = "0x60001C5")]
	[Address(RVA = "0x2FDB210", Offset = "0x2FDB210", VA = "0x2FDB210")]
	private static bool \u07BCյӶշ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001C6 RID: 454 RVA: 0x0000FEB8 File Offset: 0x0000E0B8
	[Token(Token = "0x60001C6")]
	[Address(RVA = "0x2FDB414", Offset = "0x2FDB414", VA = "0x2FDB414")]
	private static bool ܚݖמ\u085C(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001C6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ܚݖמ࡜(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001C7 RID: 455 RVA: 0x0000FED4 File Offset: 0x0000E0D4
	[Token(Token = "0x60001C7")]
	[Address(RVA = "0x2FDB66C", Offset = "0x2FDB66C", VA = "0x2FDB66C")]
	private static bool ݦԅ\u05A9Ԩ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001C7)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ݦԅ֩Ԩ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001C8 RID: 456 RVA: 0x0000FEF4 File Offset: 0x0000E0F4
	[Token(Token = "0x60001C8")]
	[Address(RVA = "0x2FDB8D4", Offset = "0x2FDB8D4", VA = "0x2FDB8D4")]
	private void ࢬӱ\u074C\u07BB()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x060001C9 RID: 457 RVA: 0x0000FF34 File Offset: 0x0000E134
	[Token(Token = "0x60001C9")]
	[Address(RVA = "0x2FDB940", Offset = "0x2FDB940", VA = "0x2FDB940")]
	private static bool ןԪٺދ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001C9)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ןԪٺދ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001CA RID: 458 RVA: 0x0000FF58 File Offset: 0x0000E158
	[Token(Token = "0x60001CA")]
	[Address(RVA = "0x2FDBBA4", Offset = "0x2FDBBA4", VA = "0x2FDBBA4")]
	private static bool \u07F3\u0818Ԟر(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001CB RID: 459 RVA: 0x0000FF6C File Offset: 0x0000E16C
	[Token(Token = "0x60001CB")]
	[Address(RVA = "0x2FDBDC8", Offset = "0x2FDBDC8", VA = "0x2FDBDC8")]
	private static bool ލࠌࢳ\u07EF(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001CC RID: 460 RVA: 0x0000FF80 File Offset: 0x0000E180
	[Token(Token = "0x60001CC")]
	[Address(RVA = "0x2FDBFF0", Offset = "0x2FDBFF0", VA = "0x2FDBFF0")]
	private void מ\u088DӺ\u06DF()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
	}

	// Token: 0x060001CD RID: 461 RVA: 0x0000FFC4 File Offset: 0x0000E1C4
	[Token(Token = "0x60001CD")]
	[Address(RVA = "0x2FDC05C", Offset = "0x2FDC05C", VA = "0x2FDC05C")]
	private static bool ߔڎ\u06ECֈ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001CE RID: 462 RVA: 0x0000FFD8 File Offset: 0x0000E1D8
	[Token(Token = "0x60001CE")]
	[Address(RVA = "0x2FD4594", Offset = "0x2FD4594", VA = "0x2FD4594")]
	private static void ءࡘڲԐ(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x060001CF RID: 463 RVA: 0x0000FFEC File Offset: 0x0000E1EC
	[Token(Token = "0x60001CF")]
	[Address(RVA = "0x2FDC288", Offset = "0x2FDC288", VA = "0x2FDC288")]
	private void \u089Fߓࡁޜ()
	{
		bool enabled = base.enabled;
		if (this.٤\u058Fࢬࡓ != DynamicBoneColliderBase.Փ\u0839\u0734ߍ.ݣ٠ࢥ\u0894)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
		int u05A9ۈӌ_u = this.\u05A9ۈӌ\u0874;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		float x = this.ر\u0604ࡩ\u0817.x;
		float y = this.ر\u0604ࡩ\u0817.y;
		float z = this.ر\u0604ࡩ\u0817.z;
		float x2 = this.Ӽډ\u0591\u0826.x;
		float y2 = this.Ӽډ\u0591\u0826.y;
		float z2 = this.Ӽډ\u0591\u0826.z;
	}

	// Token: 0x060001D0 RID: 464 RVA: 0x00010110 File Offset: 0x0000E310
	[Token(Token = "0x60001D0")]
	[Address(RVA = "0x2FDC364", Offset = "0x2FDC364", VA = "0x2FDC364")]
	private static bool ࢦ۶خԋ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001D0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ࢦ۶خԋ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001D1 RID: 465 RVA: 0x00010134 File Offset: 0x0000E334
	[Token(Token = "0x60001D1")]
	[Address(RVA = "0x2FDC5D4", Offset = "0x2FDC5D4", VA = "0x2FDC5D4")]
	private static bool \u055Aӯ\u07AB\u05FB(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001D2 RID: 466 RVA: 0x00010144 File Offset: 0x0000E344
	[Token(Token = "0x60001D2")]
	[Address(RVA = "0x2FDC688", Offset = "0x2FDC688", VA = "0x2FDC688")]
	private void OnValidate()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		float u060Fكհ_u058B = this.\u060Fكհ\u058B;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x060001D3 RID: 467 RVA: 0x00010184 File Offset: 0x0000E384
	[Token(Token = "0x60001D3")]
	[Address(RVA = "0x2FDC6E8", Offset = "0x2FDC6E8", VA = "0x2FDC6E8")]
	private static bool ێ\u0605ҽ\u07FC(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001D4 RID: 468 RVA: 0x00010194 File Offset: 0x0000E394
	[Token(Token = "0x60001D4")]
	[Address(RVA = "0x2FDC7B4", Offset = "0x2FDC7B4", VA = "0x2FDC7B4")]
	private static bool \u05B2ޏԿݣ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001D5 RID: 469 RVA: 0x000101A8 File Offset: 0x0000E3A8
	[Token(Token = "0x60001D5")]
	[Address(RVA = "0x2FDC9E4", Offset = "0x2FDC9E4", VA = "0x2FDC9E4")]
	private static bool \u05C9\u074Aݿ\u073C(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001D6 RID: 470 RVA: 0x000101BC File Offset: 0x0000E3BC
	[Token(Token = "0x60001D6")]
	[Address(RVA = "0x2FDCC0C", Offset = "0x2FDCC0C", VA = "0x2FDCC0C")]
	private static bool \u0872߄\u06E4Ӷ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001D7 RID: 471 RVA: 0x000101CC File Offset: 0x0000E3CC
	[Token(Token = "0x60001D7")]
	[Address(RVA = "0x2FDCCC8", Offset = "0x2FDCCC8", VA = "0x2FDCCC8")]
	private void \u089Aڳ߁ش()
	{
		bool enabled = base.enabled;
		if (this.٤\u058Fࢬࡓ != DynamicBoneColliderBase.Փ\u0839\u0734ߍ.ݣ٠ࢥ\u0894)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
		int u05A9ۈӌ_u = this.\u05A9ۈӌ\u0874;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		float x = this.ر\u0604ࡩ\u0817.x;
		float y = this.ر\u0604ࡩ\u0817.y;
		float z = this.ر\u0604ࡩ\u0817.z;
		float x2 = this.Ӽډ\u0591\u0826.x;
		float y2 = this.Ӽډ\u0591\u0826.y;
		float z2 = this.Ӽډ\u0591\u0826.z;
	}

	// Token: 0x060001D8 RID: 472 RVA: 0x000102F0 File Offset: 0x0000E4F0
	[Token(Token = "0x60001D8")]
	[Address(RVA = "0x2FDCDA4", Offset = "0x2FDCDA4", VA = "0x2FDCDA4")]
	private static bool ؼࡔ\u06D8\u06EC(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001D8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ؼࡔۘ۬(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001D9 RID: 473 RVA: 0x00010314 File Offset: 0x0000E514
	[Token(Token = "0x60001D9")]
	[Address(RVA = "0x2FD558C", Offset = "0x2FD558C", VA = "0x2FD558C")]
	private static bool ԉ\u05EEڿٽ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001D9)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ԉ׮ڿٽ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001DA RID: 474 RVA: 0x00010334 File Offset: 0x0000E534
	[Token(Token = "0x60001DA")]
	[Address(RVA = "0x2FDD044", Offset = "0x2FDD044", VA = "0x2FDD044")]
	private static bool Օߐߖ\u089F(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001DB RID: 475 RVA: 0x00010348 File Offset: 0x0000E548
	[Token(Token = "0x60001DB")]
	[Address(RVA = "0x2FDD244", Offset = "0x2FDD244", VA = "0x2FDD244")]
	private void ׯࡤ\u05C5\u0590()
	{
		float u07FE_u05F7ۿب = this.\u07FE\u05F7ۿب;
		this.\u07FE\u05F7ۿب = u07FE_u05F7ۿب;
		float u081E_u07F5ݑ_u082E = this.\u081E\u07F5ݑ\u082E;
		this.\u060Fكհ\u058B = u07FE_u05F7ۿب;
		this.\u081E\u07F5ݑ\u082E = u07FE_u05F7ۿب;
	}

	// Token: 0x060001DC RID: 476 RVA: 0x00010380 File Offset: 0x0000E580
	[Token(Token = "0x60001DC")]
	[Address(RVA = "0x2FDD2B0", Offset = "0x2FDD2B0", VA = "0x2FDD2B0")]
	private static bool וզփ\u05F4(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001DD RID: 477 RVA: 0x00010394 File Offset: 0x0000E594
	[Token(Token = "0x60001DD")]
	[Address(RVA = "0x2FDD4B0", Offset = "0x2FDD4B0", VA = "0x2FDD4B0")]
	private static bool \u0896בܠ\u0829(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001DE RID: 478 RVA: 0x000103A4 File Offset: 0x0000E5A4
	[Token(Token = "0x60001DE")]
	[Address(RVA = "0x2FDD6C4", Offset = "0x2FDD6C4", VA = "0x2FDD6C4")]
	private static bool ݜٮޤ\u05B5(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001DF RID: 479 RVA: 0x000103B8 File Offset: 0x0000E5B8
	[Token(Token = "0x60001DF")]
	[Address(RVA = "0x2FDD8F0", Offset = "0x2FDD8F0", VA = "0x2FDD8F0")]
	private static bool \u061Bݣ\u0559ӈ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001DF)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::؛ݣՙӈ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001E0 RID: 480 RVA: 0x000103DC File Offset: 0x0000E5DC
	[Token(Token = "0x60001E0")]
	[Address(RVA = "0x2FDDB60", Offset = "0x2FDDB60", VA = "0x2FDDB60")]
	private static bool יԳӱڹ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001E1 RID: 481 RVA: 0x000103EC File Offset: 0x0000E5EC
	[Token(Token = "0x60001E1")]
	[Address(RVA = "0x2FD4510", Offset = "0x2FD4510", VA = "0x2FD4510")]
	private static void נՎݑ\u05C1(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x060001E2 RID: 482 RVA: 0x00010400 File Offset: 0x0000E600
	[Token(Token = "0x60001E2")]
	[Address(RVA = "0x2FDDC2C", Offset = "0x2FDDC2C", VA = "0x2FDDC2C")]
	private static bool ߕ\u07F0\u060Bޡ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001E2)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ߕ߰؋ޡ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001E3 RID: 483 RVA: 0x0001041C File Offset: 0x0000E61C
	[Token(Token = "0x60001E3")]
	[Address(RVA = "0x2FDDE84", Offset = "0x2FDDE84", VA = "0x2FDDE84")]
	private static bool ݩ\u05C2ٺӾ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001E3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ݩׂٺӾ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001E4 RID: 484 RVA: 0x00010440 File Offset: 0x0000E640
	[Token(Token = "0x60001E4")]
	[Address(RVA = "0x2FDE124", Offset = "0x2FDE124", VA = "0x2FDE124")]
	private static bool \u07F3ӄ\u089Bݢ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001E5 RID: 485 RVA: 0x00010450 File Offset: 0x0000E650
	[Token(Token = "0x60001E5")]
	[Address(RVA = "0x2FDE1F4", Offset = "0x2FDE1F4", VA = "0x2FDE1F4")]
	private static bool \u05FF\u061E\u087A\u0898(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001E5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::׿؞ࡺ࢘(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001E6 RID: 486 RVA: 0x00010474 File Offset: 0x0000E674
	[Token(Token = "0x60001E6")]
	[Address(RVA = "0x2FDE460", Offset = "0x2FDE460", VA = "0x2FDE460")]
	private static bool \u066Cࠔ\u06D8ܗ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001E6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::٬ࠔۘܗ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001E7 RID: 487 RVA: 0x00010498 File Offset: 0x0000E698
	[Token(Token = "0x60001E7")]
	[Address(RVA = "0x2FDE6CC", Offset = "0x2FDE6CC", VA = "0x2FDE6CC")]
	private static void ӿݼ\u060C\u081C(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x060001E8 RID: 488 RVA: 0x000104AC File Offset: 0x0000E6AC
	[Token(Token = "0x60001E8")]
	[Address(RVA = "0x2FDE750", Offset = "0x2FDE750", VA = "0x2FDE750")]
	private void ވ\u065F\u083FԌ()
	{
		bool enabled = base.enabled;
		if (this.٤\u058Fࢬࡓ != DynamicBoneColliderBase.Փ\u0839\u0734ߍ.ݣ٠ࢥ\u0894)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
		int u05A9ۈӌ_u = this.\u05A9ۈӌ\u0874;
		float چԒڈ_u085F = this.چԒڈ\u085F;
		float x = this.ر\u0604ࡩ\u0817.x;
		float y = this.ر\u0604ࡩ\u0817.y;
		float z = this.ر\u0604ࡩ\u0817.z;
		float x2 = this.Ӽډ\u0591\u0826.x;
		float y2 = this.Ӽډ\u0591\u0826.y;
		float z2 = this.Ӽډ\u0591\u0826.z;
	}

	// Token: 0x060001E9 RID: 489 RVA: 0x000105D0 File Offset: 0x0000E7D0
	[Token(Token = "0x60001E9")]
	[Address(RVA = "0x2FDE82C", Offset = "0x2FDE82C", VA = "0x2FDE82C")]
	private void ࠍߘԮ\u0898()
	{
		bool enabled = base.enabled;
		Color magenta = Color.magenta;
	}

	// Token: 0x060001EA RID: 490 RVA: 0x00010600 File Offset: 0x0000E800
	[Token(Token = "0x60001EA")]
	[Address(RVA = "0x2FD48F0", Offset = "0x2FD48F0", VA = "0x2FD48F0")]
	private static void Ӥ\u0610\u0875ܘ(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x060001EB RID: 491 RVA: 0x00010614 File Offset: 0x0000E814
	[Token(Token = "0x60001EB")]
	[Address(RVA = "0x2FDE904", Offset = "0x2FDE904", VA = "0x2FDE904")]
	private static bool Ԥ\u07AD\u059Fܓ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001EC RID: 492 RVA: 0x00010624 File Offset: 0x0000E824
	[Token(Token = "0x60001EC")]
	[Address(RVA = "0x2FDA230", Offset = "0x2FDA230", VA = "0x2FDA230")]
	private static void ؿ\u0883ԟݵ(Vector3 ێ\u07B5Ԑࡁ, Vector3 ࠏ\u07F4נ\u05A1, float \u0730ݪӵݭ, float ݼց\u05A7ݤ)
	{
	}

	// Token: 0x060001ED RID: 493 RVA: 0x00010638 File Offset: 0x0000E838
	[Token(Token = "0x60001ED")]
	[Address(RVA = "0x2FDE9D4", Offset = "0x2FDE9D4", VA = "0x2FDE9D4")]
	private static bool \u0823\u07F8\u06E7ۃ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001EE RID: 494 RVA: 0x0001064C File Offset: 0x0000E84C
	[Token(Token = "0x60001EE")]
	[Address(RVA = "0x2FDEBD0", Offset = "0x2FDEBD0", VA = "0x2FDEBD0")]
	private static bool ݪ\u0739ࢯߎ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001EE)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ݪܹࢯߎ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001EF RID: 495 RVA: 0x00010670 File Offset: 0x0000E870
	[Token(Token = "0x60001EF")]
	[Address(RVA = "0x2FDEE38", Offset = "0x2FDEE38", VA = "0x2FDEE38")]
	private static bool ףӣצ\u05CC(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001EF)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ףӣצ׌(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001F0 RID: 496 RVA: 0x00010694 File Offset: 0x0000E894
	[Token(Token = "0x60001F0")]
	[Address(RVA = "0x2FDF0D8", Offset = "0x2FDF0D8", VA = "0x2FDF0D8")]
	private static bool ݷټ\u0670ࡁ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001F0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ݷټٰࡁ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001F1 RID: 497 RVA: 0x000106B8 File Offset: 0x0000E8B8
	[Token(Token = "0x60001F1")]
	[Address(RVA = "0x2FDF370", Offset = "0x2FDF370", VA = "0x2FDF370")]
	private static bool ࡄߤԤ\u058B(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x000106CC File Offset: 0x0000E8CC
	[Token(Token = "0x60001F2")]
	[Address(RVA = "0x2FDF570", Offset = "0x2FDF570", VA = "0x2FDF570")]
	private static bool \u05B2\u0871ࢰԨ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001F2)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ֲࡱࢰԨ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001F3 RID: 499 RVA: 0x000106F0 File Offset: 0x0000E8F0
	[Token(Token = "0x60001F3")]
	[Address(RVA = "0x2FDF7D4", Offset = "0x2FDF7D4", VA = "0x2FDF7D4")]
	private static bool ӎӉ\u0879\u05A9(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001F3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::ӎӉࡹ֩(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x00010714 File Offset: 0x0000E914
	[Token(Token = "0x60001F4")]
	[Address(RVA = "0x2FDFA70", Offset = "0x2FDFA70", VA = "0x2FDFA70")]
	private static bool \u05CEہ\u065Cࢨ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x00010724 File Offset: 0x0000E924
	[Token(Token = "0x60001F5")]
	[Address(RVA = "0x2FDFB3C", Offset = "0x2FDFB3C", VA = "0x2FDFB3C")]
	private static bool Ө\u081Fٻ\u0870(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߧۓރ\u073B, float \u07B4\u0559\u07AFԿ, float \u07FAރژ\u0601)
	{
		/*
An exception occurred when decompiling this method (060001F5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::Өࠟٻࡰ(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_2_0C, call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(ߺރژ؁), ldloc:float32(޴ՙޯԿ))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001F6 RID: 502 RVA: 0x00010744 File Offset: 0x0000E944
	[Token(Token = "0x60001F6")]
	[Address(RVA = "0x2FDFD9C", Offset = "0x2FDFD9C", VA = "0x2FDFD9C")]
	private static bool ࠎ\u07B4\u05ADپ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 Ӧ\u086Bݏ\u0602, float \u073Fչ\u05EE\u059E)
	{
	}

	// Token: 0x060001F7 RID: 503 RVA: 0x00010754 File Offset: 0x0000E954
	[Token(Token = "0x60001F7")]
	[Address(RVA = "0x2FDFE58", Offset = "0x2FDFE58", VA = "0x2FDFE58")]
	private static bool \u0708\u0892\u0708ޥ(ref Vector3 \u0589Ӓԛࡠ, float ӐӅࠐ\u0828, Vector3 \u0736ԗڕࠊ, Vector3 ӂ\u0604ߚט, float ߥࡋܔ\u07AE, float \u07FAރژ\u0601)
	{
	}

	// Token: 0x04000032 RID: 50
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000032")]
	public float \u07FE\u05F7ۿب;

	// Token: 0x04000033 RID: 51
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x4000033")]
	public float \u060Fكհ\u058B;

	// Token: 0x04000034 RID: 52
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000034")]
	public float \u081E\u07F5ݑ\u082E;

	// Token: 0x04000035 RID: 53
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x4000035")]
	private float چԒڈ\u085F;

	// Token: 0x04000036 RID: 54
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000036")]
	private float \u0831٨ӏܧ;

	// Token: 0x04000037 RID: 55
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000037")]
	private Vector3 ر\u0604ࡩ\u0817;

	// Token: 0x04000038 RID: 56
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000038")]
	private Vector3 Ӽډ\u0591\u0826;

	// Token: 0x04000039 RID: 57
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x4000039")]
	private float \u081CӄӤࠈ;

	// Token: 0x0400003A RID: 58
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400003A")]
	private int \u05A9ۈӌ\u0874;
}
