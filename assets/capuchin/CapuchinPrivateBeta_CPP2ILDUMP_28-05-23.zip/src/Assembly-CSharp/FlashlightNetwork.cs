﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000BB RID: 187
[Token(Token = "0x20000BB")]
public class FlashlightNetwork : MonoBehaviour
{
	// Token: 0x06001B95 RID: 7061 RVA: 0x0008FC9C File Offset: 0x0008DE9C
	[Token(Token = "0x6001B95")]
	[Address(RVA = "0x2E68FE4", Offset = "0x2E68FE4", VA = "0x2E68FE4")]
	private void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001B96 RID: 7062 RVA: 0x0008FCFC File Offset: 0x0008DEFC
	[Token(Token = "0x6001B96")]
	[Address(RVA = "0x2E6914C", Offset = "0x2E6914C", VA = "0x2E6914C")]
	private void \u07F7ܙײ\u05B5()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001B97 RID: 7063 RVA: 0x0008FD44 File Offset: 0x0008DF44
	[Token(Token = "0x6001B97")]
	[Address(RVA = "0x2E69204", Offset = "0x2E69204", VA = "0x2E69204")]
	private void ڣࡒէԬ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("HOLY MOLY THE STICK IS ON FIRE!!!!!!");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001B98 RID: 7064 RVA: 0x0008FD9C File Offset: 0x0008DF9C
	[Token(Token = "0x6001B98")]
	[Address(RVA = "0x2E69368", Offset = "0x2E69368", VA = "0x2E69368")]
	private void Ӛ\u055D\u0651Խ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Count of rooms ");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001B99 RID: 7065 RVA: 0x0008FE00 File Offset: 0x0008E000
	[Token(Token = "0x6001B99")]
	[Address(RVA = "0x2E694D0", Offset = "0x2E694D0", VA = "0x2E694D0")]
	private void \u05F8ݑ\u06ECߞ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001B9A RID: 7066 RVA: 0x0008FE48 File Offset: 0x0008E048
	[Token(Token = "0x6001B9A")]
	[Address(RVA = "0x2E69588", Offset = "0x2E69588", VA = "0x2E69588")]
	private void \u06E2ڇ\u07BF߃(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ScoreCounter");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] parameters = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			u07AE_u05AF_u064FԖ.RPC("hh:mmtt", RpcTarget.AllViaServer, parameters);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001B9B RID: 7067 RVA: 0x0008FEB8 File Offset: 0x0008E0B8
	[Token(Token = "0x6001B9B")]
	[Address(RVA = "0x2E696F0", Offset = "0x2E696F0", VA = "0x2E696F0")]
	private void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001B9C RID: 7068 RVA: 0x0008FF18 File Offset: 0x0008E118
	[Token(Token = "0x6001B9C")]
	[Address(RVA = "0x2E69844", Offset = "0x2E69844", VA = "0x2E69844")]
	private void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001B9D RID: 7069 RVA: 0x0008FF78 File Offset: 0x0008E178
	[Token(Token = "0x6001B9D")]
	[Address(RVA = "0x2E699A8", Offset = "0x2E699A8", VA = "0x2E699A8")]
	private void Պ\u07F7\u066AՅ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("\n");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001B9E RID: 7070 RVA: 0x0008FFDC File Offset: 0x0008E1DC
	[Token(Token = "0x6001B9E")]
	[Address(RVA = "0x2E69B10", Offset = "0x2E69B10", VA = "0x2E69B10")]
	private void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001B9F RID: 7071 RVA: 0x0009003C File Offset: 0x0008E23C
	[Token(Token = "0x6001B9F")]
	[Address(RVA = "0x2E69C74", Offset = "0x2E69C74", VA = "0x2E69C74")]
	private void \u073Fߗބݝ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BA0 RID: 7072 RVA: 0x00090084 File Offset: 0x0008E284
	[Token(Token = "0x6001BA0")]
	[Address(RVA = "0x2E69D2C", Offset = "0x2E69D2C", VA = "0x2E69D2C")]
	private void \u0609ۯ\u05B4ؼ(Collider \u07FEל\u05AC\u0877)
	{
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("False");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BA1 RID: 7073 RVA: 0x000900DC File Offset: 0x0008E2DC
	[Token(Token = "0x6001BA1")]
	[Address(RVA = "0x2E69E90", Offset = "0x2E69E90", VA = "0x2E69E90")]
	private void OnTriggerExit(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Player");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BA2 RID: 7074 RVA: 0x0009013C File Offset: 0x0008E33C
	[Token(Token = "0x6001BA2")]
	[Address(RVA = "0x2E69FF4", Offset = "0x2E69FF4", VA = "0x2E69FF4")]
	private void Ҿࢹؼס()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BA3 RID: 7075 RVA: 0x00090184 File Offset: 0x0008E384
	[Token(Token = "0x6001BA3")]
	[Address(RVA = "0x2E6A0AC", Offset = "0x2E6A0AC", VA = "0x2E6A0AC")]
	private void չւت\u061E()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BA4 RID: 7076 RVA: 0x000901CC File Offset: 0x0008E3CC
	[Token(Token = "0x6001BA4")]
	[Address(RVA = "0x2E6A164", Offset = "0x2E6A164", VA = "0x2E6A164")]
	private void \u083Eܙ\u07FD\u0706(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject;
		bool flag = gameObject.CompareTag("True");
		if (new object[0] != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BA5 RID: 7077 RVA: 0x00090214 File Offset: 0x0008E414
	[Token(Token = "0x6001BA5")]
	[Address(RVA = "0x2E6A2CC", Offset = "0x2E6A2CC", VA = "0x2E6A2CC")]
	private void ࢦ\u073Aӟࡆ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] parameters = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			u07AE_u05AF_u064FԖ.RPC(".Please press the button if you would like to play alone", RpcTarget.AllViaServer, parameters);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BA6 RID: 7078 RVA: 0x0009027C File Offset: 0x0008E47C
	[Token(Token = "0x6001BA6")]
	[Address(RVA = "0x2E6A430", Offset = "0x2E6A430", VA = "0x2E6A430")]
	private void \u0897өלբ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Purchased: ");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BA7 RID: 7079 RVA: 0x000902E0 File Offset: 0x0008E4E0
	[Token(Token = "0x6001BA7")]
	[Address(RVA = "0x2E6A594", Offset = "0x2E6A594", VA = "0x2E6A594")]
	private void ߂ӹ\u05C6\u07F9(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayerHead");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] parameters = new object[0];
		if (this.\u07AE\u0615\u088C\u07ED != null)
		{
			u07AE_u05AF_u064FԖ.RPC("Name Changing Error. Error: ", RpcTarget.AllViaServer, parameters);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BA8 RID: 7080 RVA: 0x00090348 File Offset: 0x0008E548
	[Token(Token = "0x6001BA8")]
	[Address(RVA = "0x2E6A6FC", Offset = "0x2E6A6FC", VA = "0x2E6A6FC")]
	private void ؽܗӊә(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("sound play play");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] parameters = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			u07AE_u05AF_u064FԖ.RPC("You Already Own This Item", RpcTarget.AllViaServer, parameters);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BA9 RID: 7081 RVA: 0x000903B8 File Offset: 0x0008E5B8
	[Token(Token = "0x6001BA9")]
	[Address(RVA = "0x2E6A864", Offset = "0x2E6A864", VA = "0x2E6A864")]
	private void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("\tExpires: ");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BAA RID: 7082 RVA: 0x0009041C File Offset: 0x0008E61C
	[Token(Token = "0x6001BAA")]
	[Address(RVA = "0x2E6A9CC", Offset = "0x2E6A9CC", VA = "0x2E6A9CC")]
	private void ӻӒݝ߃()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BAB RID: 7083 RVA: 0x00090464 File Offset: 0x0008E664
	[Token(Token = "0x6001BAB")]
	[Address(RVA = "0x2E6AA84", Offset = "0x2E6AA84", VA = "0x2E6AA84")]
	private void \u0619طӍ\u083D(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Charged!");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BAC RID: 7084 RVA: 0x000904C4 File Offset: 0x0008E6C4
	[Token(Token = "0x6001BAC")]
	[Address(RVA = "0x2E6ABE8", Offset = "0x2E6ABE8", VA = "0x2E6ABE8")]
	private void \u05A0ڵ\u0823ڈ(Collider \u07FEל\u05AC\u0877)
	{
		if ("\ud9c0\udc00" == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BAD RID: 7085 RVA: 0x0009051C File Offset: 0x0008E71C
	[Token(Token = "0x6001BAD")]
	[Address(RVA = "0x2E6AD50", Offset = "0x2E6AD50", VA = "0x2E6AD50")]
	private void ԚӘ\u074Bՠ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("TurnAmount");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BAE RID: 7086 RVA: 0x00090580 File Offset: 0x0008E780
	[Token(Token = "0x6001BAE")]
	[Address(RVA = "0x2E6AEB8", Offset = "0x2E6AEB8", VA = "0x2E6AEB8")]
	private void څࡣڐ\u0657()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			return;
		}
	}

	// Token: 0x06001BAF RID: 7087 RVA: 0x000905C0 File Offset: 0x0008E7C0
	[Token(Token = "0x6001BAF")]
	[Address(RVA = "0x2E6AF70", Offset = "0x2E6AF70", VA = "0x2E6AF70")]
	private void ܪ\u0818ը\u066B(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("ChangeMaterialToNormal");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BB0 RID: 7088 RVA: 0x00090620 File Offset: 0x0008E820
	[Token(Token = "0x6001BB0")]
	[Address(RVA = "0x2E6B0D8", Offset = "0x2E6B0D8", VA = "0x2E6B0D8")]
	private void ܘݱ\u083CԲ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("5BN");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BB1 RID: 7089 RVA: 0x00090684 File Offset: 0x0008E884
	[Token(Token = "0x6001BB1")]
	[Address(RVA = "0x2E6B240", Offset = "0x2E6B240", VA = "0x2E6B240")]
	private void \u0825\u05CEݍ\u083C(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("isLava");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BB2 RID: 7090 RVA: 0x000906E8 File Offset: 0x0008E8E8
	[Token(Token = "0x6001BB2")]
	[Address(RVA = "0x2E6B3A8", Offset = "0x2E6B3A8", VA = "0x2E6B3A8")]
	private void \u0892ܒܬޓ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BB3 RID: 7091 RVA: 0x00090730 File Offset: 0x0008E930
	[Token(Token = "0x6001BB3")]
	[Address(RVA = "0x2E6B460", Offset = "0x2E6B460", VA = "0x2E6B460")]
	private void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("PlayerDeath");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BB4 RID: 7092 RVA: 0x00090788 File Offset: 0x0008E988
	[Token(Token = "0x6001BB4")]
	[Address(RVA = "0x2E6B5C8", Offset = "0x2E6B5C8", VA = "0x2E6B5C8")]
	private void \u060B\u0614\u0821ע()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BB5 RID: 7093 RVA: 0x000907D0 File Offset: 0x0008E9D0
	[Token(Token = "0x6001BB5")]
	[Address(RVA = "0x2E6B680", Offset = "0x2E6B680", VA = "0x2E6B680")]
	private void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject;
		bool flag = gameObject.CompareTag("User has been reported for: ");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BB6 RID: 7094 RVA: 0x0009082C File Offset: 0x0008EA2C
	[Token(Token = "0x6001BB6")]
	[Address(RVA = "0x2E6B7E8", Offset = "0x2E6B7E8", VA = "0x2E6B7E8")]
	private void \u0886Ҽ\u058Dߛ()
	{
		if ("\ud9c0\udc00" == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BB7 RID: 7095 RVA: 0x00090874 File Offset: 0x0008EA74
	[Token(Token = "0x6001BB7")]
	[Address(RVA = "0x2E6B8A0", Offset = "0x2E6B8A0", VA = "0x2E6B8A0")]
	private void \u0885ےܝ\u05BA(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("hh:mm:sstt");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BB8 RID: 7096 RVA: 0x000908D8 File Offset: 0x0008EAD8
	[Token(Token = "0x6001BB8")]
	[Address(RVA = "0x2E6BA04", Offset = "0x2E6BA04", VA = "0x2E6BA04")]
	private void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("monkeScream");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (this.\u07AE\u0615\u088C\u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BB9 RID: 7097 RVA: 0x00090930 File Offset: 0x0008EB30
	[Token(Token = "0x6001BB9")]
	[Address(RVA = "0x2E6BB68", Offset = "0x2E6BB68", VA = "0x2E6BB68")]
	private void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Start Gamemode");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BBA RID: 7098 RVA: 0x00090994 File Offset: 0x0008EB94
	[Token(Token = "0x6001BBA")]
	[Address(RVA = "0x2E6BCCC", Offset = "0x2E6BCCC", VA = "0x2E6BCCC")]
	private void \u07A7ډ\u089D\u07ED(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag(" and the correct version is ");
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BBB RID: 7099 RVA: 0x000909F0 File Offset: 0x0008EBF0
	[Token(Token = "0x6001BBB")]
	[Address(RVA = "0x2E6BE30", Offset = "0x2E6BE30", VA = "0x2E6BE30")]
	public FlashlightNetwork()
	{
	}

	// Token: 0x06001BBC RID: 7100 RVA: 0x00090A04 File Offset: 0x0008EC04
	[Token(Token = "0x6001BBC")]
	[Address(RVA = "0x2E6BE38", Offset = "0x2E6BE38", VA = "0x2E6BE38")]
	private void ݣࢨ\u0740ԣ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BBD RID: 7101 RVA: 0x00090A68 File Offset: 0x0008EC68
	[Token(Token = "0x6001BBD")]
	[Address(RVA = "0x2E6BF9C", Offset = "0x2E6BF9C", VA = "0x2E6BF9C")]
	private void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		throw new MissingMethodException();
	}

	// Token: 0x06001BBE RID: 7102 RVA: 0x00090AD0 File Offset: 0x0008ECD0
	[Token(Token = "0x6001BBE")]
	[Address(RVA = "0x2E6C104", Offset = "0x2E6C104", VA = "0x2E6C104")]
	private void \u085Dښ\u0611ԛ(Collider \u07FEל\u05AC\u0877)
	{
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Found Gameobject: ");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		if (this.\u07AE\u0615\u088C\u07ED != null)
		{
		}
	}

	// Token: 0x06001BBF RID: 7103 RVA: 0x00090B20 File Offset: 0x0008ED20
	[Token(Token = "0x6001BBF")]
	[Address(RVA = "0x2E6C268", Offset = "0x2E6C268", VA = "0x2E6C268")]
	private void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("EnableCosmetic");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BC0 RID: 7104 RVA: 0x00090B80 File Offset: 0x0008ED80
	[Token(Token = "0x6001BC0")]
	[Address(RVA = "0x2E6C3D0", Offset = "0x2E6C3D0", VA = "0x2E6C3D0")]
	private void \u0872\u0610ۅ\u06E1(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("hh:mmtt");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BC1 RID: 7105 RVA: 0x00090BE0 File Offset: 0x0008EDE0
	[Token(Token = "0x6001BC1")]
	[Address(RVA = "0x2E6C538", Offset = "0x2E6C538", VA = "0x2E6C538")]
	private void \u0589\u0740\u05C6ӧ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("True");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BC2 RID: 7106 RVA: 0x00090C40 File Offset: 0x0008EE40
	[Token(Token = "0x6001BC2")]
	[Address(RVA = "0x2E6C6A0", Offset = "0x2E6C6A0", VA = "0x2E6C6A0")]
	private void יԠ\u07EDԺ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BC3 RID: 7107 RVA: 0x00090C88 File Offset: 0x0008EE88
	[Token(Token = "0x6001BC3")]
	[Address(RVA = "0x2E6C758", Offset = "0x2E6C758", VA = "0x2E6C758")]
	private void ࡅڑկئ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("username");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] parameters = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			u07AE_u05AF_u064FԖ.RPC("Player", RpcTarget.AllViaServer, parameters);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BC4 RID: 7108 RVA: 0x00090CF8 File Offset: 0x0008EEF8
	[Token(Token = "0x6001BC4")]
	[Address(RVA = "0x2E6C8C0", Offset = "0x2E6C8C0", VA = "0x2E6C8C0")]
	private void ࢲ\u061C\u0817ݽ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("A Player has left the Room.");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BC5 RID: 7109 RVA: 0x00090D5C File Offset: 0x0008EF5C
	[Token(Token = "0x6001BC5")]
	[Address(RVA = "0x2E6CA28", Offset = "0x2E6CA28", VA = "0x2E6CA28")]
	private void ժ\u065Dԯࡘ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BC6 RID: 7110 RVA: 0x00090DA4 File Offset: 0x0008EFA4
	[Token(Token = "0x6001BC6")]
	[Address(RVA = "0x2E6CAE0", Offset = "0x2E6CAE0", VA = "0x2E6CAE0")]
	private void \u070Aәޣے()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BC7 RID: 7111 RVA: 0x00090DEC File Offset: 0x0008EFEC
	[Token(Token = "0x6001BC7")]
	[Address(RVA = "0x2E6CB98", Offset = "0x2E6CB98", VA = "0x2E6CB98")]
	private void \u07B4\u0594ԁڇ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("gamemode");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BC8 RID: 7112 RVA: 0x00090E4C File Offset: 0x0008F04C
	[Token(Token = "0x6001BC8")]
	[Address(RVA = "0x2E6CD00", Offset = "0x2E6CD00", VA = "0x2E6CD00")]
	private void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Damaged Arm");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BC9 RID: 7113 RVA: 0x00090EB0 File Offset: 0x0008F0B0
	[Token(Token = "0x6001BC9")]
	[Address(RVA = "0x2E6CE64", Offset = "0x2E6CE64", VA = "0x2E6CE64")]
	private void \u07F3\u0876ߗ\u06FD(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("User has been reported for: ");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BCA RID: 7114 RVA: 0x00090F10 File Offset: 0x0008F110
	[Token(Token = "0x6001BCA")]
	[Address(RVA = "0x2E6CFC8", Offset = "0x2E6CFC8", VA = "0x2E6CFC8")]
	private void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BCB RID: 7115 RVA: 0x00090F74 File Offset: 0x0008F174
	[Token(Token = "0x6001BCB")]
	[Address(RVA = "0x2E6D130", Offset = "0x2E6D130", VA = "0x2E6D130")]
	private void \u05F7ԝߠӱ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BCC RID: 7116 RVA: 0x00090FBC File Offset: 0x0008F1BC
	[Token(Token = "0x6001BCC")]
	[Address(RVA = "0x2E6D1E8", Offset = "0x2E6D1E8", VA = "0x2E6D1E8")]
	private void ܖռ\u05C8\u089F(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("FingerTip");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BCD RID: 7117 RVA: 0x00091020 File Offset: 0x0008F220
	[Token(Token = "0x6001BCD")]
	[Address(RVA = "0x2E6D34C", Offset = "0x2E6D34C", VA = "0x2E6D34C")]
	private void \u0881ݗӟ\u07BD()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BCE RID: 7118 RVA: 0x00091068 File Offset: 0x0008F268
	[Token(Token = "0x6001BCE")]
	[Address(RVA = "0x2E6D404", Offset = "0x2E6D404", VA = "0x2E6D404")]
	private void Update()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BCF RID: 7119 RVA: 0x000910B0 File Offset: 0x0008F2B0
	[Token(Token = "0x6001BCF")]
	[Address(RVA = "0x2E6D4BC", Offset = "0x2E6D4BC", VA = "0x2E6D4BC")]
	private void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject;
		bool flag = gameObject.CompareTag("Purchased: ");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BD0 RID: 7120 RVA: 0x00091108 File Offset: 0x0008F308
	[Token(Token = "0x6001BD0")]
	[Address(RVA = "0x2E6D620", Offset = "0x2E6D620", VA = "0x2E6D620")]
	private void \u0557Ӧگӷ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("Open");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BD1 RID: 7121 RVA: 0x0009116C File Offset: 0x0008F36C
	[Token(Token = "0x6001BD1")]
	[Address(RVA = "0x2E6D784", Offset = "0x2E6D784", VA = "0x2E6D784")]
	private void \u0614ࢥӴ\u086C()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BD2 RID: 7122 RVA: 0x000911B4 File Offset: 0x0008F3B4
	[Token(Token = "0x6001BD2")]
	[Address(RVA = "0x2E6D83C", Offset = "0x2E6D83C", VA = "0x2E6D83C")]
	private void ո\u07AA\u05BDࠕ()
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.ߨאߨػ;
		if (networkPlayerSpawner.\u05C4ࡑڍۺ)
		{
			PhotonView component = networkPlayerSpawner.\u05EEݠ\u05FFը.GetComponent<PhotonView>();
			this.\u07AE\u05AF\u064FԖ = component;
			return;
		}
	}

	// Token: 0x06001BD3 RID: 7123 RVA: 0x000911FC File Offset: 0x0008F3FC
	[Token(Token = "0x6001BD3")]
	[Address(RVA = "0x2E6D8F4", Offset = "0x2E6D8F4", VA = "0x2E6D8F4")]
	private void \u07B3\u07BD\u05FF\u0859(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("\n Time: ");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BD4 RID: 7124 RVA: 0x00091260 File Offset: 0x0008F460
	[Token(Token = "0x6001BD4")]
	[Address(RVA = "0x2E6DA5C", Offset = "0x2E6DA5C", VA = "0x2E6DA5C")]
	private void ԁؼՖռ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("_Tint");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[1];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BD5 RID: 7125 RVA: 0x000912C0 File Offset: 0x0008F4C0
	[Token(Token = "0x6001BD5")]
	[Address(RVA = "0x2E6DBC0", Offset = "0x2E6DBC0", VA = "0x2E6DBC0")]
	private void ӻڊ\u05B3ۍ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] array = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BD6 RID: 7126 RVA: 0x0009131C File Offset: 0x0008F51C
	[Token(Token = "0x6001BD6")]
	[Address(RVA = "0x2E6DD28", Offset = "0x2E6DD28", VA = "0x2E6DD28")]
	private void տӿך\u064D(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = \u07FEל\u05AC\u0877.gameObject;
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		object[] parameters = new object[0];
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			u07AE_u05AF_u064FԖ.RPC("goUpRPC", RpcTarget.AllViaServer, parameters);
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001BD7 RID: 7127 RVA: 0x00091384 File Offset: 0x0008F584
	[Token(Token = "0x6001BD7")]
	[Address(RVA = "0x2E6DE8C", Offset = "0x2E6DE8C", VA = "0x2E6DE8C")]
	private void ܮݫ߅ࡃ(Collider \u07FEל\u05AC\u0877)
	{
		if (typeof(PhotonNetwork).TypeHandle == null)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		bool flag = \u07FEל\u05AC\u0877.gameObject.CompareTag("TurnAmount");
		PhotonView u07AE_u05AF_u064FԖ = this.\u07AE\u05AF\u064FԖ;
		string u07AE_u0615_u088C_u07ED = this.\u07AE\u0615\u088C\u07ED;
		if (u07AE_u0615_u088C_u07ED == null || u07AE_u0615_u088C_u07ED != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x04000399 RID: 921
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000399")]
	public string \u07AE\u0615\u088C\u07ED;

	// Token: 0x0400039A RID: 922
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400039A")]
	public NetworkPlayerSpawner ߨאߨػ;

	// Token: 0x0400039B RID: 923
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400039B")]
	private PhotonView \u07AE\u05AF\u064FԖ;
}
