﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200003B RID: 59
[Token(Token = "0x200003B")]
public class PositionToPosition : MonoBehaviour
{
	// Token: 0x060007F5 RID: 2037 RVA: 0x0002BCE8 File Offset: 0x00029EE8
	[Token(Token = "0x60007F5")]
	[Address(RVA = "0x2C41A24", Offset = "0x2C41A24", VA = "0x2C41A24")]
	public void ڃրӢԖ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x060007F6 RID: 2038 RVA: 0x0002BD10 File Offset: 0x00029F10
	[Token(Token = "0x60007F6")]
	[Address(RVA = "0x2C41A64", Offset = "0x2C41A64", VA = "0x2C41A64")]
	public void Update()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x060007F7 RID: 2039 RVA: 0x0002BD38 File Offset: 0x00029F38
	[Token(Token = "0x60007F7")]
	[Address(RVA = "0x2C41AA4", Offset = "0x2C41AA4", VA = "0x2C41AA4")]
	public void Ҿࢹؼס()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x060007F8 RID: 2040 RVA: 0x0002BD60 File Offset: 0x00029F60
	[Token(Token = "0x60007F8")]
	[Address(RVA = "0x2C41AE4", Offset = "0x2C41AE4", VA = "0x2C41AE4")]
	public void ފՖߢ\u059B()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x060007F9 RID: 2041 RVA: 0x0002BD88 File Offset: 0x00029F88
	[Token(Token = "0x60007F9")]
	[Address(RVA = "0x2C41B24", Offset = "0x2C41B24", VA = "0x2C41B24")]
	public void \u0881ݗӟ\u07BD()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x060007FA RID: 2042 RVA: 0x0002BDB0 File Offset: 0x00029FB0
	[Token(Token = "0x60007FA")]
	[Address(RVA = "0x2C41B64", Offset = "0x2C41B64", VA = "0x2C41B64")]
	public void څࡣڐ\u0657()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x060007FB RID: 2043 RVA: 0x0002BDD8 File Offset: 0x00029FD8
	[Token(Token = "0x60007FB")]
	[Address(RVA = "0x2C41BA4", Offset = "0x2C41BA4", VA = "0x2C41BA4")]
	public void ں٢ࡡ\u05EC()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x060007FC RID: 2044 RVA: 0x0002BE00 File Offset: 0x0002A000
	[Token(Token = "0x60007FC")]
	[Address(RVA = "0x2C41BE4", Offset = "0x2C41BE4", VA = "0x2C41BE4")]
	public void \u0654ޛ\u07FAذ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x060007FD RID: 2045 RVA: 0x0002BE28 File Offset: 0x0002A028
	[Token(Token = "0x60007FD")]
	[Address(RVA = "0x2C41C24", Offset = "0x2C41C24", VA = "0x2C41C24")]
	public void ܣ\u086E\u05CF\u06D8()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x060007FE RID: 2046 RVA: 0x0002BE50 File Offset: 0x0002A050
	[Token(Token = "0x60007FE")]
	[Address(RVA = "0x2C41C64", Offset = "0x2C41C64", VA = "0x2C41C64")]
	public void \u061B\u05EEوۈ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x060007FF RID: 2047 RVA: 0x0002BE78 File Offset: 0x0002A078
	[Token(Token = "0x60007FF")]
	[Address(RVA = "0x2C41CA4", Offset = "0x2C41CA4", VA = "0x2C41CA4")]
	public void Ҽ\u08B5ځ\u0658()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x06000800 RID: 2048 RVA: 0x0002BEA0 File Offset: 0x0002A0A0
	[Token(Token = "0x6000800")]
	[Address(RVA = "0x2C41CE4", Offset = "0x2C41CE4", VA = "0x2C41CE4")]
	public void ٴݵۃ\u05AF()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x06000801 RID: 2049 RVA: 0x0002BEC8 File Offset: 0x0002A0C8
	[Token(Token = "0x6000801")]
	[Address(RVA = "0x2C41D24", Offset = "0x2C41D24", VA = "0x2C41D24")]
	public void \u070Aәޣے()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x06000802 RID: 2050 RVA: 0x0002BEF0 File Offset: 0x0002A0F0
	[Token(Token = "0x6000802")]
	[Address(RVA = "0x2C41D64", Offset = "0x2C41D64", VA = "0x2C41D64")]
	public void \u05F7ԝߠӱ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x06000803 RID: 2051 RVA: 0x0002BF18 File Offset: 0x0002A118
	[Token(Token = "0x6000803")]
	[Address(RVA = "0x2C41DA4", Offset = "0x2C41DA4", VA = "0x2C41DA4")]
	public void ࢫ\u0876չՍ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x06000804 RID: 2052 RVA: 0x0002BF40 File Offset: 0x0002A140
	[Token(Token = "0x6000804")]
	[Address(RVA = "0x2C41DE4", Offset = "0x2C41DE4", VA = "0x2C41DE4")]
	public void ԣԭՋࠏ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x06000805 RID: 2053 RVA: 0x0002BF68 File Offset: 0x0002A168
	[Token(Token = "0x6000805")]
	[Address(RVA = "0x2C41E24", Offset = "0x2C41E24", VA = "0x2C41E24")]
	public void ւ\u06E9\u06DA\u06EB()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x06000806 RID: 2054 RVA: 0x0002BF90 File Offset: 0x0002A190
	[Token(Token = "0x6000806")]
	[Address(RVA = "0x2C41E64", Offset = "0x2C41E64", VA = "0x2C41E64")]
	public void Ӣ\u0592ߨׯ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x06000807 RID: 2055 RVA: 0x0002BFB8 File Offset: 0x0002A1B8
	[Token(Token = "0x6000807")]
	[Address(RVA = "0x2C41EA4", Offset = "0x2C41EA4", VA = "0x2C41EA4")]
	public void ӻӒݝ߃()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x06000808 RID: 2056 RVA: 0x0002BFE0 File Offset: 0x0002A1E0
	[Token(Token = "0x6000808")]
	[Address(RVA = "0x2C41EE4", Offset = "0x2C41EE4", VA = "0x2C41EE4")]
	public void ւࡂ\u0883\u0872()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x06000809 RID: 2057 RVA: 0x0002C008 File Offset: 0x0002A208
	[Token(Token = "0x6000809")]
	[Address(RVA = "0x2C41F24", Offset = "0x2C41F24", VA = "0x2C41F24")]
	public void \u061Fࡆ\u086F\u07B0()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x0600080A RID: 2058 RVA: 0x0002C030 File Offset: 0x0002A230
	[Token(Token = "0x600080A")]
	[Address(RVA = "0x2C41F64", Offset = "0x2C41F64", VA = "0x2C41F64")]
	public void ժ\u065Dԯࡘ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x0600080B RID: 2059 RVA: 0x0002C058 File Offset: 0x0002A258
	[Token(Token = "0x600080B")]
	[Address(RVA = "0x2C41FA4", Offset = "0x2C41FA4", VA = "0x2C41FA4")]
	public void \u05EDց\u081Cت()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x0600080C RID: 2060 RVA: 0x0002C080 File Offset: 0x0002A280
	[Token(Token = "0x600080C")]
	[Address(RVA = "0x2C41FE4", Offset = "0x2C41FE4", VA = "0x2C41FE4")]
	public void \u087BӦןݩ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x0600080D RID: 2061 RVA: 0x0002C0A8 File Offset: 0x0002A2A8
	[Token(Token = "0x600080D")]
	[Address(RVA = "0x2C42024", Offset = "0x2C42024", VA = "0x2C42024")]
	public void ԟ\u086Cޣ\u055E()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x0600080E RID: 2062 RVA: 0x0002C0D0 File Offset: 0x0002A2D0
	[Token(Token = "0x600080E")]
	[Address(RVA = "0x2C42064", Offset = "0x2C42064", VA = "0x2C42064")]
	public void ڑߒجވ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x0600080F RID: 2063 RVA: 0x0002C0F8 File Offset: 0x0002A2F8
	[Token(Token = "0x600080F")]
	[Address(RVA = "0x2C420A4", Offset = "0x2C420A4", VA = "0x2C420A4")]
	public PositionToPosition()
	{
	}

	// Token: 0x06000810 RID: 2064 RVA: 0x0002C10C File Offset: 0x0002A30C
	[Token(Token = "0x6000810")]
	[Address(RVA = "0x2C420AC", Offset = "0x2C420AC", VA = "0x2C420AC")]
	public void \u0732ڙԒࢺ()
	{
		Transform ږ_u0878_u073Bܮ = this.ږ\u0878\u073Bܮ;
		Transform ޙ_u05A6_u05FFܐ = this.ޙ\u05A6\u05FFܐ;
		Vector3 position = ږ_u0878_u073Bܮ.position;
	}

	// Token: 0x0400010E RID: 270
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400010E")]
	public Transform ޙ\u05A6\u05FFܐ;

	// Token: 0x0400010F RID: 271
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400010F")]
	public Transform ږ\u0878\u073Bܮ;
}
