﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000033 RID: 51
[Token(Token = "0x2000033")]
public class EnableMoonGrav : MonoBehaviour
{
	// Token: 0x060005F2 RID: 1522 RVA: 0x0002366C File Offset: 0x0002186C
	[Token(Token = "0x60005F2")]
	[Address(RVA = "0x1D85FF4", Offset = "0x1D85FF4", VA = "0x1D85FF4")]
	public void ړإٳ\u065C(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005F3 RID: 1523 RVA: 0x000236D4 File Offset: 0x000218D4
	[Token(Token = "0x60005F3")]
	[Address(RVA = "0x1D86080", Offset = "0x1D86080", VA = "0x1D86080")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005F4 RID: 1524 RVA: 0x0002373C File Offset: 0x0002193C
	[Token(Token = "0x60005F4")]
	[Address(RVA = "0x1D8610C", Offset = "0x1D8610C", VA = "0x1D8610C")]
	public void ߣސӤ\u0741(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		long enabled;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		this.\u05AA\u0730ߥה.enabled = (enabled != 0L);
	}

	// Token: 0x060005F5 RID: 1525 RVA: 0x0002379C File Offset: 0x0002199C
	[Token(Token = "0x60005F5")]
	[Address(RVA = "0x1D86198", Offset = "0x1D86198", VA = "0x1D86198")]
	public void Ӆ\u064EԸ\u089A(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005F6 RID: 1526 RVA: 0x00023804 File Offset: 0x00021A04
	[Token(Token = "0x60005F6")]
	[Address(RVA = "0x1D86224", Offset = "0x1D86224", VA = "0x1D86224")]
	public EnableMoonGrav()
	{
	}

	// Token: 0x060005F7 RID: 1527 RVA: 0x00023818 File Offset: 0x00021A18
	[Token(Token = "0x60005F7")]
	[Address(RVA = "0x1D8622C", Offset = "0x1D8622C", VA = "0x1D8622C")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x00023880 File Offset: 0x00021A80
	[Token(Token = "0x60005F8")]
	[Address(RVA = "0x1D862B8", Offset = "0x1D862B8", VA = "0x1D862B8")]
	public void ۋյݖ\u070E(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x000238E8 File Offset: 0x00021AE8
	[Token(Token = "0x60005F9")]
	[Address(RVA = "0x1D86344", Offset = "0x1D86344", VA = "0x1D86344")]
	public void ࠃ\u0595\u0737\u0732(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005FA RID: 1530 RVA: 0x00023950 File Offset: 0x00021B50
	[Token(Token = "0x60005FA")]
	[Address(RVA = "0x1D863D0", Offset = "0x1D863D0", VA = "0x1D863D0")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005FB RID: 1531 RVA: 0x000239B8 File Offset: 0x00021BB8
	[Token(Token = "0x60005FB")]
	[Address(RVA = "0x1D8645C", Offset = "0x1D8645C", VA = "0x1D8645C")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005FC RID: 1532 RVA: 0x00023A20 File Offset: 0x00021C20
	[Token(Token = "0x60005FC")]
	[Address(RVA = "0x1D864E8", Offset = "0x1D864E8", VA = "0x1D864E8")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005FD RID: 1533 RVA: 0x00023A88 File Offset: 0x00021C88
	[Token(Token = "0x60005FD")]
	[Address(RVA = "0x1D86574", Offset = "0x1D86574", VA = "0x1D86574")]
	public void މԦӊߤ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005FE RID: 1534 RVA: 0x00023AF0 File Offset: 0x00021CF0
	[Token(Token = "0x60005FE")]
	[Address(RVA = "0x1D86600", Offset = "0x1D86600", VA = "0x1D86600")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060005FF RID: 1535 RVA: 0x00023B58 File Offset: 0x00021D58
	[Token(Token = "0x60005FF")]
	[Address(RVA = "0x1D8668C", Offset = "0x1D8668C", VA = "0x1D8668C")]
	public void \u074CԾݱߤ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x00023BC0 File Offset: 0x00021DC0
	[Token(Token = "0x6000600")]
	[Address(RVA = "0x1D86718", Offset = "0x1D86718", VA = "0x1D86718")]
	public void \u055F\u061F\u05BF\u07BA(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000601 RID: 1537 RVA: 0x00023C28 File Offset: 0x00021E28
	[Token(Token = "0x6000601")]
	[Address(RVA = "0x1D867A4", Offset = "0x1D867A4", VA = "0x1D867A4")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000602 RID: 1538 RVA: 0x00023C90 File Offset: 0x00021E90
	[Token(Token = "0x6000602")]
	[Address(RVA = "0x1D86830", Offset = "0x1D86830", VA = "0x1D86830")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000603 RID: 1539 RVA: 0x00023CF8 File Offset: 0x00021EF8
	[Token(Token = "0x6000603")]
	[Address(RVA = "0x1D868BC", Offset = "0x1D868BC", VA = "0x1D868BC")]
	public void يࢧөԈ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000604 RID: 1540 RVA: 0x00023D60 File Offset: 0x00021F60
	[Token(Token = "0x6000604")]
	[Address(RVA = "0x1D86948", Offset = "0x1D86948", VA = "0x1D86948")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000605 RID: 1541 RVA: 0x00023DC8 File Offset: 0x00021FC8
	[Token(Token = "0x6000605")]
	[Address(RVA = "0x1D869D4", Offset = "0x1D869D4", VA = "0x1D869D4")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000606 RID: 1542 RVA: 0x00023E30 File Offset: 0x00022030
	[Token(Token = "0x6000606")]
	[Address(RVA = "0x1D86A60", Offset = "0x1D86A60", VA = "0x1D86A60")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000607 RID: 1543 RVA: 0x00023E98 File Offset: 0x00022098
	[Token(Token = "0x6000607")]
	[Address(RVA = "0x1D86AEC", Offset = "0x1D86AEC", VA = "0x1D86AEC")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000608 RID: 1544 RVA: 0x00023F00 File Offset: 0x00022100
	[Token(Token = "0x6000608")]
	[Address(RVA = "0x1D86B78", Offset = "0x1D86B78", VA = "0x1D86B78")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000609 RID: 1545 RVA: 0x00023F68 File Offset: 0x00022168
	[Token(Token = "0x6000609")]
	[Address(RVA = "0x1D86C04", Offset = "0x1D86C04", VA = "0x1D86C04")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600060A RID: 1546 RVA: 0x00023FD0 File Offset: 0x000221D0
	[Token(Token = "0x600060A")]
	[Address(RVA = "0x1D86C90", Offset = "0x1D86C90", VA = "0x1D86C90")]
	public void \u085Aܒیݕ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600060B RID: 1547 RVA: 0x00024038 File Offset: 0x00022238
	[Token(Token = "0x600060B")]
	[Address(RVA = "0x1D86D1C", Offset = "0x1D86D1C", VA = "0x1D86D1C")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600060C RID: 1548 RVA: 0x000240A0 File Offset: 0x000222A0
	[Token(Token = "0x600060C")]
	[Address(RVA = "0x1D86DA8", Offset = "0x1D86DA8", VA = "0x1D86DA8")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600060D RID: 1549 RVA: 0x00024108 File Offset: 0x00022308
	[Token(Token = "0x600060D")]
	[Address(RVA = "0x1D86E34", Offset = "0x1D86E34", VA = "0x1D86E34")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600060E RID: 1550 RVA: 0x00024170 File Offset: 0x00022370
	[Token(Token = "0x600060E")]
	[Address(RVA = "0x1D86EC0", Offset = "0x1D86EC0", VA = "0x1D86EC0")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600060F RID: 1551 RVA: 0x000241D8 File Offset: 0x000223D8
	[Token(Token = "0x600060F")]
	[Address(RVA = "0x1D86F4C", Offset = "0x1D86F4C", VA = "0x1D86F4C")]
	public void \u0888\u05C4ޟڿ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000610 RID: 1552 RVA: 0x00024240 File Offset: 0x00022440
	[Token(Token = "0x6000610")]
	[Address(RVA = "0x1D86FD8", Offset = "0x1D86FD8", VA = "0x1D86FD8")]
	public void \u0874\u061BӵՑ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000611 RID: 1553 RVA: 0x000242A8 File Offset: 0x000224A8
	[Token(Token = "0x6000611")]
	[Address(RVA = "0x1D87064", Offset = "0x1D87064", VA = "0x1D87064")]
	public void ءڹޝ\u06DD(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000612 RID: 1554 RVA: 0x000242FC File Offset: 0x000224FC
	[Token(Token = "0x6000612")]
	[Address(RVA = "0x1D870F0", Offset = "0x1D870F0", VA = "0x1D870F0")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000613 RID: 1555 RVA: 0x00024364 File Offset: 0x00022564
	[Token(Token = "0x6000613")]
	[Address(RVA = "0x1D8717C", Offset = "0x1D8717C", VA = "0x1D8717C")]
	public void \u081B\u0604ࢬҼ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000614 RID: 1556 RVA: 0x000243CC File Offset: 0x000225CC
	[Token(Token = "0x6000614")]
	[Address(RVA = "0x1D87208", Offset = "0x1D87208", VA = "0x1D87208")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 0L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000615 RID: 1557 RVA: 0x00024434 File Offset: 0x00022634
	[Token(Token = "0x6000615")]
	[Address(RVA = "0x1D87294", Offset = "0x1D87294", VA = "0x1D87294")]
	public void \u0596ࡓԻ\u06EA(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000616 RID: 1558 RVA: 0x0002449C File Offset: 0x0002269C
	[Token(Token = "0x6000616")]
	[Address(RVA = "0x1D87320", Offset = "0x1D87320", VA = "0x1D87320")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000617 RID: 1559 RVA: 0x00024504 File Offset: 0x00022704
	[Token(Token = "0x6000617")]
	[Address(RVA = "0x1D873AC", Offset = "0x1D873AC", VA = "0x1D873AC")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 1L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000618 RID: 1560 RVA: 0x0002456C File Offset: 0x0002276C
	[Token(Token = "0x6000618")]
	[Address(RVA = "0x1D87438", Offset = "0x1D87438", VA = "0x1D87438")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = base.gameObject.tag;
		string u070FӏԊӏ = this.\u070FӏԊӏ;
		bool flag = tag == u070FӏԊӏ;
		if (this.ר߄\u05C4ԗ)
		{
			GravityBody u05AA_u0730ߥה = this.\u05AA\u0730ߥה;
			long enabled = 0L;
			u05AA_u0730ߥה.enabled = (enabled != 0L);
			if (this.ר߄\u05C4ԗ)
			{
				return;
			}
		}
		GravityBody u05AA_u0730ߥה2 = this.\u05AA\u0730ߥה;
		long enabled2 = 1L;
		u05AA_u0730ߥה2.enabled = (enabled2 != 0L);
	}

	// Token: 0x040000EF RID: 239
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000EF")]
	public bool ר߄\u05C4ԗ;

	// Token: 0x040000F0 RID: 240
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000F0")]
	public GravityBody \u05AA\u0730ߥה;

	// Token: 0x040000F1 RID: 241
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40000F1")]
	public string \u070FӏԊӏ;
}
