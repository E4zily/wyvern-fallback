﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000D8 RID: 216
[Token(Token = "0x20000D8")]
public class Report : MonoBehaviour
{
	// Token: 0x06002080 RID: 8320 RVA: 0x000A8CB4 File Offset: 0x000A6EB4
	[Token(Token = "0x6002080")]
	[Address(RVA = "0x2DE83BC", Offset = "0x2DE83BC", VA = "0x2DE83BC")]
	private void ԟ\u086Cޣ\u055E()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002081 RID: 8321 RVA: 0x000A8D0C File Offset: 0x000A6F0C
	[Token(Token = "0x6002081")]
	[Address(RVA = "0x2DE8428", Offset = "0x2DE8428", VA = "0x2DE8428")]
	private void طӏܙࢺ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002082 RID: 8322 RVA: 0x000A8D64 File Offset: 0x000A6F64
	[Token(Token = "0x6002082")]
	[Address(RVA = "0x2DE8494", Offset = "0x2DE8494", VA = "0x2DE8494")]
	public void Պࢧ\u0659\u07FD(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "friend";
		if ("friend" != null)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if ("friend" != null)
			{
				goto IL_EE;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Player";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "username";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "KeyPos";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B2 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_EE:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x06002083 RID: 8323 RVA: 0x000A8E84 File Offset: 0x000A7084
	[Token(Token = "0x6002083")]
	[Address(RVA = "0x2DE8768", Offset = "0x2DE8768", VA = "0x2DE8768")]
	private void \u05F8ݑ\u06ECߞ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002084 RID: 8324 RVA: 0x000A8EDC File Offset: 0x000A70DC
	[Token(Token = "0x6002084")]
	[Address(RVA = "0x2DE87D4", Offset = "0x2DE87D4", VA = "0x2DE87D4")]
	private void ݫࢷࠃ\u0820()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002085 RID: 8325 RVA: 0x000A8F34 File Offset: 0x000A7134
	[Token(Token = "0x6002085")]
	[Address(RVA = "0x2DE8840", Offset = "0x2DE8840", VA = "0x2DE8840")]
	private void \u07FB\u07BC\u0887ӟ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002086 RID: 8326 RVA: 0x000A8F7C File Offset: 0x000A717C
	[Token(Token = "0x6002086")]
	[Address(RVA = "0x2DE88AC", Offset = "0x2DE88AC", VA = "0x2DE88AC")]
	private void \u0732ڙԒࢺ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002087 RID: 8327 RVA: 0x000A8FD4 File Offset: 0x000A71D4
	[Token(Token = "0x6002087")]
	[Address(RVA = "0x2DE8918", Offset = "0x2DE8918", VA = "0x2DE8918")]
	public void בӵܪә(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Adding ";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "false";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "Player";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Player";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x06002088 RID: 8328 RVA: 0x000A90EC File Offset: 0x000A72EC
	[Token(Token = "0x6002088")]
	[Address(RVA = "0x2DE8BDC", Offset = "0x2DE8BDC", VA = "0x2DE8BDC")]
	public void يօӇ\u070D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "{0} ({1})";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_C9;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "True";
			long active = 0L;
			string message;
			Debug.Log(message);
			this.ޝ\u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "Connected to Server.";
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active2 = 1L;
			ޝ_u0875٥ײ.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "HandL";
			string message2;
			Debug.Log(message2);
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
		}
		IL_C9:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ2.SetActive(active3 != 0L);
			return;
		}
	}

	// Token: 0x06002089 RID: 8329 RVA: 0x000A91E8 File Offset: 0x000A73E8
	[Token(Token = "0x6002089")]
	[Address(RVA = "0x2DE8EAC", Offset = "0x2DE8EAC", VA = "0x2DE8EAC")]
	public void ܤ\u065BݜԶ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == ". Please update you game to the latest version";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_F0;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "token";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "BN";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			this.ࡨ\u0608\u070D\u066B = (typeof(Debug).TypeHandle != null);
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x0600208A RID: 8330 RVA: 0x000A9308 File Offset: 0x000A7508
	[Token(Token = "0x600208A")]
	[Address(RVA = "0x2DE9184", Offset = "0x2DE9184", VA = "0x2DE9184")]
	public void ہۼآԄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == " and the correct version is ";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_D3;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "2BN";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = ".Please press the button if you would like to play alone";
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_D3:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x0600208B RID: 8331 RVA: 0x000A940C File Offset: 0x000A760C
	[Token(Token = "0x600208B")]
	[Address(RVA = "0x2DE9450", Offset = "0x2DE9450", VA = "0x2DE9450")]
	public void ٣ݸӔժ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "NetworkPlayer";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_DE;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Player";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "Vertical";
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "username";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_DE:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x0600208C RID: 8332 RVA: 0x000A951C File Offset: 0x000A771C
	[Token(Token = "0x600208C")]
	[Address(RVA = "0x2DE9720", Offset = "0x2DE9720", VA = "0x2DE9720")]
	private void \u0872މࢮՃ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x0600208D RID: 8333 RVA: 0x000A9574 File Offset: 0x000A7774
	[Token(Token = "0x600208D")]
	[Address(RVA = "0x2DE978C", Offset = "0x2DE978C", VA = "0x2DE978C")]
	public void OnTriggerEnter(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_F0;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Cheating";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "Hate Speech";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B2 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Toxicity";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x0600208E RID: 8334 RVA: 0x000A9694 File Offset: 0x000A7894
	[Token(Token = "0x600208E")]
	[Address(RVA = "0x2DE9A4C", Offset = "0x2DE9A4C", VA = "0x2DE9A4C")]
	private void \u07A7ࡐ\u0818ܭ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x0600208F RID: 8335 RVA: 0x000A96EC File Offset: 0x000A78EC
	[Token(Token = "0x600208F")]
	[Address(RVA = "0x2DE9AB8", Offset = "0x2DE9AB8", VA = "0x2DE9AB8")]
	public void ފԅ\u0881ݾ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Platform failed to initialize due to exception.";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_FD;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "TurnAmount";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "CapuchinRemade";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Players Online: ";
			Debug.Log("Diffuse" + "Players Online: ");
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B2 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_FD:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x06002090 RID: 8336 RVA: 0x000A981C File Offset: 0x000A7A1C
	[Token(Token = "0x6002090")]
	[Address(RVA = "0x2DE9D8C", Offset = "0x2DE9D8C", VA = "0x2DE9D8C")]
	private void \u07B2\u0823ծݠ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002091 RID: 8337 RVA: 0x000A9874 File Offset: 0x000A7A74
	[Token(Token = "0x6002091")]
	[Address(RVA = "0x2DE9DF8", Offset = "0x2DE9DF8", VA = "0x2DE9DF8")]
	public void ا\u082C\u0601\u05F5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "User has been reported for: ";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Version";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "FingerTip";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "_Tint";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x06002092 RID: 8338 RVA: 0x000A998C File Offset: 0x000A7B8C
	[Token(Token = "0x6002092")]
	[Address(RVA = "0x2DEA0C8", Offset = "0x2DEA0C8", VA = "0x2DEA0C8")]
	private void Ӌ\u089C\u0700ܧ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002093 RID: 8339 RVA: 0x000A99E4 File Offset: 0x000A7BE4
	[Token(Token = "0x6002093")]
	[Address(RVA = "0x2DEA134", Offset = "0x2DEA134", VA = "0x2DEA134")]
	private void \u070Aәޣے()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002094 RID: 8340 RVA: 0x000A9A3C File Offset: 0x000A7C3C
	[Token(Token = "0x6002094")]
	[Address(RVA = "0x2DEA1A0", Offset = "0x2DEA1A0", VA = "0x2DEA1A0")]
	private void \u0881ݗӟ\u07BD()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002095 RID: 8341 RVA: 0x000A9A94 File Offset: 0x000A7C94
	[Token(Token = "0x6002095")]
	[Address(RVA = "0x2DEA20C", Offset = "0x2DEA20C", VA = "0x2DEA20C")]
	private void \u087BӦןݩ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002096 RID: 8342 RVA: 0x000A9AEC File Offset: 0x000A7CEC
	[Token(Token = "0x6002096")]
	[Address(RVA = "0x2DEA278", Offset = "0x2DEA278", VA = "0x2DEA278")]
	public void ݓرܪܤ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Charging...";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "EnableCosmetic";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "containsStaff";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Player";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x06002097 RID: 8343 RVA: 0x000A9C04 File Offset: 0x000A7E04
	[Token(Token = "0x6002097")]
	[Address(RVA = "0x2DEA53C", Offset = "0x2DEA53C", VA = "0x2DEA53C")]
	private void \u07F7ܙײ\u05B5()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x06002098 RID: 8344 RVA: 0x000A9C5C File Offset: 0x000A7E5C
	[Token(Token = "0x6002098")]
	[Address(RVA = "0x2DEA5A8", Offset = "0x2DEA5A8", VA = "0x2DEA5A8")]
	public void Ԩ\u07B6\u0659Ӿ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_DA;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "typesOfTalk";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "NetworkGunShoot";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Start Gamemode";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_DA:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x06002099 RID: 8345 RVA: 0x000A9D68 File Offset: 0x000A7F68
	[Token(Token = "0x6002099")]
	[Address(RVA = "0x2DEA874", Offset = "0x2DEA874", VA = "0x2DEA874")]
	public void ەԌ\u05C7\u085D(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_BumpScale";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "username";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "HandR";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "A new Player joined a Room.";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x0600209A RID: 8346 RVA: 0x000A9E80 File Offset: 0x000A8080
	[Token(Token = "0x600209A")]
	[Address(RVA = "0x2DEAB2C", Offset = "0x2DEAB2C", VA = "0x2DEAB2C")]
	public void އܣٵ٨(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		string tag = gameObject.tag;
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_D6;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Combine textures & build combined mesh using coroutine";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		bool ݫ_u0882ݮ_u = this.ݫ\u0882ݮ\u0896;
		long active2 = 0L;
		string message2;
		Debug.Log(message2);
		this.ޝ\u0875٥ײ.SetActive(active2 != 0L);
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Player";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B2 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
			long active3 = 1L;
			ޝ_u0875٥ײ2.SetActive(active3 != 0L);
		}
		IL_D6:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ3.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x0600209B RID: 8347 RVA: 0x000A9F88 File Offset: 0x000A8188
	[Token(Token = "0x600209B")]
	[Address(RVA = "0x2DEAE00", Offset = "0x2DEAE00", VA = "0x2DEAE00")]
	public void \u0737ٱއ\u0879(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E7;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
			Debug.Log("Calling success callback. baking meshes" + "Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "TurnAmount";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E7:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x0600209C RID: 8348 RVA: 0x000AA0A0 File Offset: 0x000A82A0
	[Token(Token = "0x600209C")]
	[Address(RVA = "0x2DEB0D0", Offset = "0x2DEB0D0", VA = "0x2DEB0D0")]
	public void ئԈ\u0740ݟ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_CF;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "username";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = " ";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "typesOfTalk";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_CF:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x0600209D RID: 8349 RVA: 0x000AA1A0 File Offset: 0x000A83A0
	[Token(Token = "0x600209D")]
	[Address(RVA = "0x2DEB39C", Offset = "0x2DEB39C", VA = "0x2DEB39C")]
	private void Ӣ\u0592ߨׯ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x0600209E RID: 8350 RVA: 0x000AA1F8 File Offset: 0x000A83F8
	[Token(Token = "0x600209E")]
	[Address(RVA = "0x2DEB408", Offset = "0x2DEB408", VA = "0x2DEB408")]
	private void Ҽ\u08B5ځ\u0658()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x0600209F RID: 8351 RVA: 0x000AA250 File Offset: 0x000A8450
	[Token(Token = "0x600209F")]
	[Address(RVA = "0x2DEB474", Offset = "0x2DEB474", VA = "0x2DEB474")]
	public void \u060A\u06DE\u061B\u083F(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "DISABLE";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_F0;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Reason: ";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			this.ࡨ\u0608\u070D\u066B = (typeof(Debug).TypeHandle != null);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "A new Player joined a Room.";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "CapuchinStore";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020A0 RID: 8352 RVA: 0x000AA370 File Offset: 0x000A8570
	[Token(Token = "0x60020A0")]
	[Address(RVA = "0x2DEB748", Offset = "0x2DEB748", VA = "0x2DEB748")]
	public Report()
	{
	}

	// Token: 0x060020A1 RID: 8353 RVA: 0x000AA384 File Offset: 0x000A8584
	[Token(Token = "0x60020A1")]
	[Address(RVA = "0x2DEB750", Offset = "0x2DEB750", VA = "0x2DEB750")]
	public void \u07BD\u0745\u08B5ڞ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_DA;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "isLava";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "_BumpScale";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_DA:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020A2 RID: 8354 RVA: 0x000AA490 File Offset: 0x000A8690
	[Token(Token = "0x60020A2")]
	[Address(RVA = "0x2DEBA1C", Offset = "0x2DEBA1C", VA = "0x2DEBA1C")]
	public void \u087Aܪ\u087Bٯ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_DF;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "You struck apon an error. ";
			string message;
			Debug.Log(message);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "_Tint";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = ". Please update you game to the latest version";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B2 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		IL_DF:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
			return;
		}
	}

	// Token: 0x060020A3 RID: 8355 RVA: 0x000AA5A0 File Offset: 0x000A87A0
	[Token(Token = "0x60020A3")]
	[Address(RVA = "0x2DEBCF0", Offset = "0x2DEBCF0", VA = "0x2DEBCF0")]
	private void Update()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020A4 RID: 8356 RVA: 0x000AA5F8 File Offset: 0x000A87F8
	[Token(Token = "0x60020A4")]
	[Address(RVA = "0x2DEBD5C", Offset = "0x2DEBD5C", VA = "0x2DEBD5C")]
	private void \u05ABࡡ\u07ABݾ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020A5 RID: 8357 RVA: 0x000AA650 File Offset: 0x000A8850
	[Token(Token = "0x60020A5")]
	[Address(RVA = "0x2DEBDC8", Offset = "0x2DEBDC8", VA = "0x2DEBDC8")]
	public void ևעԨԍ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Name Changing Error. Error: ";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_DA;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "M/d/yyyy";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "Failed to login, please restart";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Not connected to room";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_DA:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020A6 RID: 8358 RVA: 0x000AA75C File Offset: 0x000A895C
	[Token(Token = "0x60020A6")]
	[Address(RVA = "0x2DEC094", Offset = "0x2DEC094", VA = "0x2DEC094")]
	private void \u0870\u05B3Ց\u066A()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020A7 RID: 8359 RVA: 0x000AA7B4 File Offset: 0x000A89B4
	[Token(Token = "0x60020A7")]
	[Address(RVA = "0x2DEC100", Offset = "0x2DEC100", VA = "0x2DEC100")]
	public void \u07B9ࢯهڰ(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "Agreed";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E2;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "ChangeMaterialToNormal";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Joined Public Room Successfully";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E2:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020A8 RID: 8360 RVA: 0x000AA8C8 File Offset: 0x000A8AC8
	[Token(Token = "0x60020A8")]
	[Address(RVA = "0x2DEC3D0", Offset = "0x2DEC3D0", VA = "0x2DEC3D0")]
	private void \u0832ࢳޤ\u07B5()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020A9 RID: 8361 RVA: 0x000AA920 File Offset: 0x000A8B20
	[Token(Token = "0x60020A9")]
	[Address(RVA = "0x2DEC43C", Offset = "0x2DEC43C", VA = "0x2DEC43C")]
	private void ں٢ࡡ\u05EC()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020AA RID: 8362 RVA: 0x000AA978 File Offset: 0x000A8B78
	[Token(Token = "0x60020AA")]
	[Address(RVA = "0x2DEC4A8", Offset = "0x2DEC4A8", VA = "0x2DEC4A8")]
	public void ٨\u0819\u0601\u07BC(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "You struck apon an error. ";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "PlayerDeath";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "PlayNoise";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Players Online: ";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020AB RID: 8363 RVA: 0x000AAA90 File Offset: 0x000A8C90
	[Token(Token = "0x60020AB")]
	[Address(RVA = "0x2DEC778", Offset = "0x2DEC778", VA = "0x2DEC778")]
	public void \u05C1ؽԜࡥ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "A new Player joined a Room.";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "FingerTip";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		long num;
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "BN";
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			num = 1L;
			this.ࡨ\u0608\u070D\u066B = (num != 0L);
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		long active3;
		if (num != 0L)
		{
			this.ջܜק\u07AA = "Add/Remove Glasses";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			this.ޝ\u0875٥ײ.SetActive(active3 != 0L);
			return;
		}
	}

	// Token: 0x060020AC RID: 8364 RVA: 0x000AABA0 File Offset: 0x000A8DA0
	[Token(Token = "0x60020AC")]
	[Address(RVA = "0x2DECA38", Offset = "0x2DECA38", VA = "0x2DECA38")]
	private void \u0821\u059Fӕ\u0607()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020AD RID: 8365 RVA: 0x000AABF8 File Offset: 0x000A8DF8
	[Token(Token = "0x60020AD")]
	[Address(RVA = "0x2DECAA4", Offset = "0x2DECAA4", VA = "0x2DECAA4")]
	private void \u05C4ݳ\u05BCࡂ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020AE RID: 8366 RVA: 0x000AAC50 File Offset: 0x000A8E50
	[Token(Token = "0x60020AE")]
	[Address(RVA = "0x2DECB10", Offset = "0x2DECB10", VA = "0x2DECB10")]
	public void \u081FԘں\u07B2(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "isLava";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_ED;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "False";
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "Combine textures & build combined mesh using coroutine";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B2 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Failed to get catalog, cosmetic name, and price. Exact error details is: ";
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B3 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B3 != 0L);
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_ED:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020AF RID: 8367 RVA: 0x000AAD70 File Offset: 0x000A8F70
	[Token(Token = "0x60020AF")]
	[Address(RVA = "0x2DECDE8", Offset = "0x2DECDE8", VA = "0x2DECDE8")]
	private void ڃրӢԖ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			return;
		}
	}

	// Token: 0x060020B0 RID: 8368 RVA: 0x000AADA8 File Offset: 0x000A8FA8
	[Token(Token = "0x60020B0")]
	[Address(RVA = "0x2DECE54", Offset = "0x2DECE54", VA = "0x2DECE54")]
	public void \u087DىԳܚ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "FingerTip";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_DB;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Tagged";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "Player";
			return;
		}
		if (this.\u060D\u0824ۏص)
		{
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		IL_DB:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
			return;
		}
	}

	// Token: 0x060020B1 RID: 8369 RVA: 0x000AAEB4 File Offset: 0x000A90B4
	[Token(Token = "0x60020B1")]
	[Address(RVA = "0x2DED124", Offset = "0x2DED124", VA = "0x2DED124")]
	private void ؤ\u05C8ԛ\u083F()
	{
		BoxCollider boxCollider = this.ڜՎࠋا;
		MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
		Material u05CBטڻݲ = this.\u05CBטڻݲ;
		ה_u07A7ࡢڋ.material = u05CBטڻݲ;
		GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
		long active = 0L;
		ޝ_u0875٥ײ.SetActive(active != 0L);
	}

	// Token: 0x060020B2 RID: 8370 RVA: 0x000AAEF8 File Offset: 0x000A90F8
	[Token(Token = "0x60020B2")]
	[Address(RVA = "0x2DED190", Offset = "0x2DED190", VA = "0x2DED190")]
	public void ݗࡡ\u06D8ԩ(Collider \u07FEל\u05AC\u0877)
	{
		string tag = \u07FEל\u05AC\u0877.gameObject.tag;
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_DA;
			}
		}
		long num;
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "ChangeToTagged";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			num = 1L;
			ޝ_u0875٥ײ.SetActive(num != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = num;
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 1L;
			ޝ_u0875٥ײ2.SetActive(active != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "User has been reported for: ";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ3.SetActive(active2 != 0L);
		}
		IL_DA:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ4.SetActive(active3 != 0L);
			return;
		}
	}

	// Token: 0x060020B3 RID: 8371 RVA: 0x000AB004 File Offset: 0x000A9204
	[Token(Token = "0x60020B3")]
	[Address(RVA = "0x2DED460", Offset = "0x2DED460", VA = "0x2DED460")]
	public void ۏ\u083C\u05BFࡄ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == " hours. You were banned because of ";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_DA;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "_WobbleX";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "spooky guy true";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_DA:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020B4 RID: 8372 RVA: 0x000AB110 File Offset: 0x000A9310
	[Token(Token = "0x60020B4")]
	[Address(RVA = "0x2DED730", Offset = "0x2DED730", VA = "0x2DED730")]
	public void \u05AB\u05BEӞނ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "BloodKill";
		if ("BloodKill" == null || "BloodKill" == null)
		{
			if ("BloodKill" != null)
			{
				string message;
				Debug.Log(message);
			}
			if (typeof(Debug).TypeHandle != null)
			{
				string message2;
				Debug.Log(message2);
			}
			if (typeof(Debug).TypeHandle != null)
			{
				string message3;
				Debug.Log(message3);
			}
		}
		if (typeof(Debug).TypeHandle != null)
		{
			return;
		}
	}

	// Token: 0x060020B5 RID: 8373 RVA: 0x000AB184 File Offset: 0x000A9384
	[Token(Token = "0x60020B5")]
	[Address(RVA = "0x2DED9FC", Offset = "0x2DED9FC", VA = "0x2DED9FC")]
	public void \u0594\u0873\u0707\u0817(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "EnableCosmetic";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Vector1_d371bd24217449349bd747533d51af6b";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "_Smoothness";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "_BumpMap";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020B6 RID: 8374 RVA: 0x000AB29C File Offset: 0x000A949C
	[Token(Token = "0x60020B6")]
	[Address(RVA = "0x2DEDCCC", Offset = "0x2DEDCCC", VA = "0x2DEDCCC")]
	private void ո\u07AA\u05BDࠕ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020B7 RID: 8375 RVA: 0x000AB2F4 File Offset: 0x000A94F4
	[Token(Token = "0x60020B7")]
	[Address(RVA = "0x2DEDD38", Offset = "0x2DEDD38", VA = "0x2DEDD38")]
	public void \u087C٨ڔ\u0617(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Found Gameobject: ";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_D3;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Vector1_d371bd24217449349bd747533d51af6b";
			string message;
			Debug.Log(message);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "typesOfTalk";
			Debug.Log(this);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Player";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		IL_D3:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
			return;
		}
	}

	// Token: 0x060020B8 RID: 8376 RVA: 0x000AB3F8 File Offset: 0x000A95F8
	[Token(Token = "0x60020B8")]
	[Address(RVA = "0x2DEE008", Offset = "0x2DEE008", VA = "0x2DEE008")]
	public void ࠑࠑڮ\u06E6(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "SetColor";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_F0;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "All audio clips have been played.";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "Reason: ";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "true";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B2 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020B9 RID: 8377 RVA: 0x000AB518 File Offset: 0x000A9718
	[Token(Token = "0x60020B9")]
	[Address(RVA = "0x2DEE2DC", Offset = "0x2DEE2DC", VA = "0x2DEE2DC")]
	public void նݙӋ\u0600(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Body";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "BLUPORT";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "TurnAmount";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Player";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020BA RID: 8378 RVA: 0x000AB630 File Offset: 0x000A9830
	[Token(Token = "0x60020BA")]
	[Address(RVA = "0x2DEE5A0", Offset = "0x2DEE5A0", VA = "0x2DEE5A0")]
	public void ࢦ\u066Cբ\u05C5(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PlayerHead";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "jump char false";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		bool ݫ_u0882ݮ_u = this.ݫ\u0882ݮ\u0896;
		string message2;
		Debug.Log(message2);
		GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
		long ࡨ_u0608_u070D_u066B2 = 1L;
		this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
		long active2 = 1L;
		ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "On";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B3 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B3 != 0L);
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020BB RID: 8379 RVA: 0x000AB748 File Offset: 0x000A9948
	[Token(Token = "0x60020BB")]
	[Address(RVA = "0x2DEE878", Offset = "0x2DEE878", VA = "0x2DEE878")]
	public void ԇދӨ\u060B(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "PURCHASED";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "character limit reached";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "tp 2";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "DISABLE";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020BC RID: 8380 RVA: 0x000AB860 File Offset: 0x000A9A60
	[Token(Token = "0x60020BC")]
	[Address(RVA = "0x2DEEB48", Offset = "0x2DEEB48", VA = "0x2DEEB48")]
	private void ւࡂ\u0883\u0872()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020BD RID: 8381 RVA: 0x000AB8B8 File Offset: 0x000A9AB8
	[Token(Token = "0x60020BD")]
	[Address(RVA = "0x2DEEBB4", Offset = "0x2DEEBB4", VA = "0x2DEEBB4")]
	private void \u0892ܒܬޓ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020BE RID: 8382 RVA: 0x000AB910 File Offset: 0x000A9B10
	[Token(Token = "0x60020BE")]
	[Address(RVA = "0x2DEEC20", Offset = "0x2DEEC20", VA = "0x2DEEC20")]
	public void ࡊڛܟ\u0882(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "Completed baking textures on frame ";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_F0;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "SetColor";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			this.ࡨ\u0608\u070D\u066B = (typeof(Debug).TypeHandle != null);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "KeyPos";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Purchased: ";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020BF RID: 8383 RVA: 0x000ABA30 File Offset: 0x000A9C30
	[Token(Token = "0x60020BF")]
	[Address(RVA = "0x2DEEEF4", Offset = "0x2DEEEF4", VA = "0x2DEEEF4")]
	private void \u060B\u0614\u0821ע()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020C0 RID: 8384 RVA: 0x000ABA88 File Offset: 0x000A9C88
	[Token(Token = "0x60020C0")]
	[Address(RVA = "0x2DEEF60", Offset = "0x2DEEF60", VA = "0x2DEEF60")]
	public void Ӂ\u0742Ԃԁ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "_Tint";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_E5;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "ChangePlayerSize";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = " hour. You were banned because of ";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "hh:mmtt";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020C1 RID: 8385 RVA: 0x000ABBA0 File Offset: 0x000A9DA0
	[Token(Token = "0x60020C1")]
	[Address(RVA = "0x2DEF230", Offset = "0x2DEF230", VA = "0x2DEF230")]
	private void չւت\u061E()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020C2 RID: 8386 RVA: 0x000ABBF8 File Offset: 0x000A9DF8
	[Token(Token = "0x60020C2")]
	[Address(RVA = "0x2DEF29C", Offset = "0x2DEF29C", VA = "0x2DEF29C")]
	private void צ\u0874ڵ\u059A()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			return;
		}
	}

	// Token: 0x060020C3 RID: 8387 RVA: 0x000ABC44 File Offset: 0x000A9E44
	[Token(Token = "0x60020C3")]
	[Address(RVA = "0x2DEF308", Offset = "0x2DEF308", VA = "0x2DEF308")]
	public void ݻޢՍ\u055D(Collider \u07FEל\u05AC\u0877)
	{
		GameObject gameObject;
		bool flag = gameObject.tag == "Player";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_FA;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "_WobbleZ";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "NetworkPlayer";
			Debug.Log("TurnAmount" + "NetworkPlayer");
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B2 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "User has been reported for: ";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_FA:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020C4 RID: 8388 RVA: 0x000ABD70 File Offset: 0x000A9F70
	[Token(Token = "0x60020C4")]
	[Address(RVA = "0x2DEF5DC", Offset = "0x2DEF5DC", VA = "0x2DEF5DC")]
	private void יԠ\u07EDԺ()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			return;
		}
	}

	// Token: 0x060020C5 RID: 8389 RVA: 0x000ABDB4 File Offset: 0x000A9FB4
	[Token(Token = "0x60020C5")]
	[Address(RVA = "0x2DEF648", Offset = "0x2DEF648", VA = "0x2DEF648")]
	public void נ\u07EB\u05B8ߜ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "gravThing";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_F0;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "Toxicity";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "Player";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long active2 = 0L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
			string message3;
			Debug.Log(message3);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B2 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
			long active3 = 0L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 1L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060020C6 RID: 8390 RVA: 0x000ABED4 File Offset: 0x000AA0D4
	[Token(Token = "0x60020C6")]
	[Address(RVA = "0x2DEF91C", Offset = "0x2DEF91C", VA = "0x2DEF91C")]
	private void \u0614ࢥӴ\u086C()
	{
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long active = 0L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060020C7 RID: 8391 RVA: 0x000ABF2C File Offset: 0x000AA12C
	[Token(Token = "0x60020C7")]
	[Address(RVA = "0x2DEF988", Offset = "0x2DEF988", VA = "0x2DEF988")]
	public void \u06E1ٷܭݔ(Collider \u07FEל\u05AC\u0877)
	{
		bool flag = \u07FEל\u05AC\u0877.gameObject.tag == "username";
		if (this.ࡨ\u0608\u070D\u066B)
		{
			BoxCollider boxCollider = this.ڜՎࠋا;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer ה_u07A7ࡢڋ = this.ה\u07A7ࡢڋ;
			Material u05CBטڻݲ = this.\u05CBטڻݲ;
			ה_u07A7ࡢڋ.material = u05CBטڻݲ;
			if (this.ࡨ\u0608\u070D\u066B)
			{
				goto IL_FA;
			}
		}
		if (this.\u061Bڒٲࡡ)
		{
			this.ջܜק\u07AA = "\n";
			Debug.Log(this);
			GameObject ޝ_u0875٥ײ = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B != 0L);
			long active = 1L;
			ޝ_u0875٥ײ.SetActive(active != 0L);
		}
		if (this.ݫ\u0882ݮ\u0896)
		{
			this.ջܜק\u07AA = "PlayerHead";
			string message;
			Debug.Log(message);
			GameObject ޝ_u0875٥ײ2 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B2 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B2 != 0L);
			long active2 = 1L;
			ޝ_u0875٥ײ2.SetActive(active2 != 0L);
		}
		if (this.\u060D\u0824ۏص)
		{
			this.ջܜק\u07AA = "You are on an outdated version of Capuchin. Your version is ";
			string message2;
			Debug.Log(message2);
			GameObject ޝ_u0875٥ײ3 = this.ޝ\u0875٥ײ;
			long ࡨ_u0608_u070D_u066B3 = 1L;
			this.ࡨ\u0608\u070D\u066B = (ࡨ_u0608_u070D_u066B3 != 0L);
			long active3 = 1L;
			ޝ_u0875٥ײ3.SetActive(active3 != 0L);
		}
		IL_FA:
		if (this.لهࡃݗ)
		{
			GameObject ޝ_u0875٥ײ4 = this.ޝ\u0875٥ײ;
			long active4 = 0L;
			ޝ_u0875٥ײ4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x04000429 RID: 1065
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000429")]
	public bool ࡨ\u0608\u070D\u066B;

	// Token: 0x0400042A RID: 1066
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x400042A")]
	public bool لهࡃݗ;

	// Token: 0x0400042B RID: 1067
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400042B")]
	public BoxCollider ڜՎࠋا;

	// Token: 0x0400042C RID: 1068
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400042C")]
	public MeshRenderer ה\u07A7ࡢڋ;

	// Token: 0x0400042D RID: 1069
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400042D")]
	public Material \u05CBטڻݲ;

	// Token: 0x0400042E RID: 1070
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400042E")]
	public Material ࡣ\u05CBޞ\u06D8;

	// Token: 0x0400042F RID: 1071
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400042F")]
	public bool \u061Bڒٲࡡ;

	// Token: 0x04000430 RID: 1072
	[FieldOffset(Offset = "0x41")]
	[Token(Token = "0x4000430")]
	public bool ݫ\u0882ݮ\u0896;

	// Token: 0x04000431 RID: 1073
	[FieldOffset(Offset = "0x42")]
	[Token(Token = "0x4000431")]
	public bool \u060D\u0824ۏص;

	// Token: 0x04000432 RID: 1074
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000432")]
	public BoxCollider \u082Fԕࡄۇ;

	// Token: 0x04000433 RID: 1075
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000433")]
	public BoxCollider ހ\u06EBףޒ;

	// Token: 0x04000434 RID: 1076
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000434")]
	public BoxCollider ࠂܙ߅ࡩ;

	// Token: 0x04000435 RID: 1077
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000435")]
	public MeshRenderer ࢣࡢ\u085Dն;

	// Token: 0x04000436 RID: 1078
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000436")]
	public MeshRenderer \u0590ղ\u0816Ӡ;

	// Token: 0x04000437 RID: 1079
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000437")]
	public MeshRenderer өճլן;

	// Token: 0x04000438 RID: 1080
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000438")]
	private string ջܜק\u07AA;

	// Token: 0x04000439 RID: 1081
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4000439")]
	public GameObject ޝ\u0875٥ײ;
}
