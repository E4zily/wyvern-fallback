﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000004 RID: 4
[Token(Token = "0x2000004")]
public class BetaGameAgreement : MonoBehaviour
{
	// Token: 0x06000067 RID: 103 RVA: 0x00003A8C File Offset: 0x00001C8C
	[Token(Token = "0x6000067")]
	[Address(RVA = "0x3662BDC", Offset = "0x3662BDC", VA = "0x3662BDC")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Player", "Combine textures & build combined mesh using coroutine");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000068 RID: 104 RVA: 0x00003ACC File Offset: 0x00001CCC
	[Address(RVA = "0x3662CE8", Offset = "0x3662CE8", VA = "0x3662CE8")]
	[Token(Token = "0x6000068")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("containsStaff", "Hate Speech");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00003B0C File Offset: 0x00001D0C
	[Address(RVA = "0x3662DF4", Offset = "0x3662DF4", VA = "0x3662DF4")]
	[Token(Token = "0x6000069")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("_Tint", "You struck apon an error. ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00003B4C File Offset: 0x00001D4C
	[Address(RVA = "0x3662F00", Offset = "0x3662F00", VA = "0x3662F00")]
	[Token(Token = "0x600006A")]
	public void method_3()
	{
		PlayerPrefs.GetString("TurnAmount") == " and the correct version is ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600006B RID: 107 RVA: 0x00003B80 File Offset: 0x00001D80
	[Token(Token = "0x600006B")]
	[Address(RVA = "0x3662F84", Offset = "0x3662F84", VA = "0x3662F84")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Damaged Arm", "gravThing");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600006C RID: 108 RVA: 0x00003BC0 File Offset: 0x00001DC0
	[Address(RVA = "0x3663090", Offset = "0x3663090", VA = "0x3663090")]
	[Token(Token = "0x600006C")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Joined Public Room Successfully", "Player");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600006D RID: 109 RVA: 0x00003C00 File Offset: 0x00001E00
	[Token(Token = "0x600006D")]
	[Address(RVA = "0x366319C", Offset = "0x366319C", VA = "0x366319C")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("lock unlocked!", "Adding ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600006E RID: 110 RVA: 0x00003C40 File Offset: 0x00001E40
	[Address(RVA = "0x36632A8", Offset = "0x36632A8", VA = "0x36632A8")]
	[Token(Token = "0x600006E")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Room Name: ", "'s Grabber is not assigned.");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600006F RID: 111 RVA: 0x00003C80 File Offset: 0x00001E80
	[Token(Token = "0x600006F")]
	[Address(RVA = "0x36633B4", Offset = "0x36633B4", VA = "0x36633B4")]
	public void method_8()
	{
		PlayerPrefs.GetString("Display Name Changed!") == "Key";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000070 RID: 112 RVA: 0x00003CB4 File Offset: 0x00001EB4
	[Token(Token = "0x6000070")]
	[Address(RVA = "0x3663438", Offset = "0x3663438", VA = "0x3663438")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("NoseAttachPoint", " and for the price of ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000071 RID: 113 RVA: 0x00003CF4 File Offset: 0x00001EF4
	[Token(Token = "0x6000071")]
	[Address(RVA = "0x3663544", Offset = "0x3663544", VA = "0x3663544")]
	public void method_10()
	{
		PlayerPrefs.GetString("NormalWeather") == "Diffuse";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000072 RID: 114 RVA: 0x00003D28 File Offset: 0x00001F28
	[Address(RVA = "0x36635C8", Offset = "0x36635C8", VA = "0x36635C8")]
	[Token(Token = "0x6000072")]
	public void method_11()
	{
		PlayerPrefs.GetString("Downloading image") == "got funky mone";
	}

	// Token: 0x06000073 RID: 115 RVA: 0x00003D4C File Offset: 0x00001F4C
	[Address(RVA = "0x3663660", Offset = "0x3663660", VA = "0x3663660")]
	[Token(Token = "0x6000073")]
	public void method_12()
	{
		PlayerPrefs.GetString(".Please press the button if you would like to play alone") == "Thumb";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000074 RID: 116 RVA: 0x00003D80 File Offset: 0x00001F80
	[Token(Token = "0x6000074")]
	[Address(RVA = "0x36636E4", Offset = "0x36636E4", VA = "0x36636E4")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("_WobbleX", "Try Connect To Server...");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000075 RID: 117 RVA: 0x00003DC0 File Offset: 0x00001FC0
	[Token(Token = "0x6000075")]
	[Address(RVA = "0x36637F0", Offset = "0x36637F0", VA = "0x36637F0")]
	public void Start()
	{
		PlayerPrefs.GetString("betaAgree") == "true";
	}

	// Token: 0x06000076 RID: 118 RVA: 0x00003DE4 File Offset: 0x00001FE4
	[Address(RVA = "0x3663888", Offset = "0x3663888", VA = "0x3663888")]
	[Token(Token = "0x6000076")]
	public void method_14()
	{
		PlayerPrefs.GetString("QuickStatic") == "ENABLE";
	}

	// Token: 0x06000077 RID: 119 RVA: 0x00003E08 File Offset: 0x00002008
	[Token(Token = "0x6000077")]
	[Address(RVA = "0x3663920", Offset = "0x3663920", VA = "0x3663920")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("betaAgree", "true");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00003E48 File Offset: 0x00002048
	[Token(Token = "0x6000078")]
	[Address(RVA = "0x3663A2C", Offset = "0x3663A2C", VA = "0x3663A2C")]
	public void method_15()
	{
		PlayerPrefs.GetString("clickLol") == "ORGTARG";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000079 RID: 121 RVA: 0x00003E7C File Offset: 0x0000207C
	[Address(RVA = "0x3663AB0", Offset = "0x3663AB0", VA = "0x3663AB0")]
	[Token(Token = "0x6000079")]
	public void method_16()
	{
		PlayerPrefs.GetString("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n") == "lock unlocked!";
	}

	// Token: 0x0600007A RID: 122 RVA: 0x00003EA0 File Offset: 0x000020A0
	[Token(Token = "0x600007A")]
	[Address(RVA = "0x3663B48", Offset = "0x3663B48", VA = "0x3663B48")]
	public void method_17()
	{
		PlayerPrefs.GetString("Damaged Arm") == "typesOfTalk";
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00003EC4 File Offset: 0x000020C4
	[Token(Token = "0x600007B")]
	[Address(RVA = "0x3663BCC", Offset = "0x3663BCC", VA = "0x3663BCC")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Player", "'s Grabber is not assigned.");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600007C RID: 124 RVA: 0x00003F04 File Offset: 0x00002104
	[Address(RVA = "0x3663CD8", Offset = "0x3663CD8", VA = "0x3663CD8")]
	[Token(Token = "0x600007C")]
	public void method_19(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Tagged", "Name Changing Error. Error: ");
		GameObject gameObject2 = this.gameObject_0;
		long active = 1L;
		gameObject2.SetActive(active != 0L);
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00003F3C File Offset: 0x0000213C
	[Address(RVA = "0x3663DE4", Offset = "0x3663DE4", VA = "0x3663DE4")]
	[Token(Token = "0x600007D")]
	public void method_20()
	{
		PlayerPrefs.GetString("Players: ") == "PURCHASED!";
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00003F60 File Offset: 0x00002160
	[Address(RVA = "0x3663E68", Offset = "0x3663E68", VA = "0x3663E68")]
	[Token(Token = "0x600007E")]
	public void method_21()
	{
		PlayerPrefs.GetString("Combine textures & build combined mesh all at once") == "Downloading image";
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00003F84 File Offset: 0x00002184
	[Address(RVA = "0x3663F00", Offset = "0x3663F00", VA = "0x3663F00")]
	[Token(Token = "0x600007F")]
	public void method_22()
	{
		PlayerPrefs.GetString("Date: ") == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00003FB8 File Offset: 0x000021B8
	[Token(Token = "0x6000080")]
	[Address(RVA = "0x3663F84", Offset = "0x3663F84", VA = "0x3663F84")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("true", "Date: ");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00003FF8 File Offset: 0x000021F8
	[Token(Token = "0x6000081")]
	[Address(RVA = "0x3664090", Offset = "0x3664090", VA = "0x3664090")]
	public void method_24()
	{
		PlayerPrefs.GetString("Player") == "XR Usage";
	}

	// Token: 0x06000082 RID: 130 RVA: 0x0000401C File Offset: 0x0000221C
	[Address(RVA = "0x3664128", Offset = "0x3664128", VA = "0x3664128")]
	[Token(Token = "0x6000082")]
	public void method_25()
	{
		PlayerPrefs.GetString("betaAgree") == "Count of rooms ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000083 RID: 131 RVA: 0x00004050 File Offset: 0x00002250
	[Address(RVA = "0x36641AC", Offset = "0x36641AC", VA = "0x36641AC")]
	[Token(Token = "0x6000083")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000084 RID: 132 RVA: 0x00004080 File Offset: 0x00002280
	[Address(RVA = "0x36642B8", Offset = "0x36642B8", VA = "0x36642B8")]
	[Token(Token = "0x6000084")]
	public void method_27()
	{
		PlayerPrefs.GetString("HandR") == "Player";
	}

	// Token: 0x06000085 RID: 133 RVA: 0x000040A4 File Offset: 0x000022A4
	[Token(Token = "0x6000085")]
	[Address(RVA = "0x3664350", Offset = "0x3664350", VA = "0x3664350")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Camera movement detected, calibrating height.", "ErrorScreen");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000086 RID: 134 RVA: 0x000040E4 File Offset: 0x000022E4
	[Token(Token = "0x6000086")]
	[Address(RVA = "0x366445C", Offset = "0x366445C", VA = "0x366445C")]
	public void method_29()
	{
		PlayerPrefs.GetString("PlayWave") == "Bare Torso";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000087 RID: 135 RVA: 0x00004118 File Offset: 0x00002318
	[Token(Token = "0x6000087")]
	[Address(RVA = "0x36644E0", Offset = "0x36644E0", VA = "0x36644E0")]
	public void method_30()
	{
		PlayerPrefs.GetString("Diffuse") == "liftoff failed!";
	}

	// Token: 0x06000088 RID: 136 RVA: 0x0000413C File Offset: 0x0000233C
	[Token(Token = "0x6000088")]
	[Address(RVA = "0x3664578", Offset = "0x3664578", VA = "0x3664578")]
	public void method_31()
	{
		PlayerPrefs.GetString("Cannot take elements from an empty buffer.") == "_WobbleZ";
	}

	// Token: 0x06000089 RID: 137 RVA: 0x00004160 File Offset: 0x00002360
	[Token(Token = "0x6000089")]
	[Address(RVA = "0x3664610", Offset = "0x3664610", VA = "0x3664610")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("DisableCosmetic", "");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600008A RID: 138 RVA: 0x000041A0 File Offset: 0x000023A0
	[Token(Token = "0x600008A")]
	[Address(RVA = "0x366471C", Offset = "0x366471C", VA = "0x366471C")]
	public void method_33()
	{
		PlayerPrefs.GetString("\tExpires: ") == "NetworkPlayer";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600008B RID: 139 RVA: 0x000041D4 File Offset: 0x000023D4
	[Address(RVA = "0x36647A0", Offset = "0x36647A0", VA = "0x36647A0")]
	[Token(Token = "0x600008B")]
	public void method_34()
	{
		string a;
		a == "spatial";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600008C RID: 140 RVA: 0x00004200 File Offset: 0x00002400
	[Token(Token = "0x600008C")]
	[Address(RVA = "0x3664824", Offset = "0x3664824", VA = "0x3664824")]
	public void method_35()
	{
		PlayerPrefs.GetString("typesOfTalk") == "On";
	}

	// Token: 0x0600008D RID: 141 RVA: 0x00004224 File Offset: 0x00002424
	[Address(RVA = "0x36648BC", Offset = "0x36648BC", VA = "0x36648BC")]
	[Token(Token = "0x600008D")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("retract broken", "EnableCosmetic");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600008E RID: 142 RVA: 0x00004264 File Offset: 0x00002464
	[Address(RVA = "0x36649C8", Offset = "0x36649C8", VA = "0x36649C8")]
	[Token(Token = "0x600008E")]
	public void method_37()
	{
		PlayerPrefs.GetString("Connected to Server.") == "PlayerHead";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600008F RID: 143 RVA: 0x00004298 File Offset: 0x00002498
	[Token(Token = "0x600008F")]
	[Address(RVA = "0x3664A4C", Offset = "0x3664A4C", VA = "0x3664A4C")]
	public void method_38()
	{
		PlayerPrefs.GetString("Vector1_d371bd24217449349bd747533d51af6b") == "Grip";
	}

	// Token: 0x06000090 RID: 144 RVA: 0x000042BC File Offset: 0x000024BC
	[Address(RVA = "0x3664AE4", Offset = "0x3664AE4", VA = "0x3664AE4")]
	[Token(Token = "0x6000090")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("liftoff failed!", "HandL");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000091 RID: 145 RVA: 0x000042FC File Offset: 0x000024FC
	[Address(RVA = "0x3664BF0", Offset = "0x3664BF0", VA = "0x3664BF0")]
	[Token(Token = "0x6000091")]
	public void method_40()
	{
		PlayerPrefs.GetString("lock unlocked!") == "Room Name: ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000092 RID: 146 RVA: 0x00004330 File Offset: 0x00002530
	[Token(Token = "0x6000092")]
	[Address(RVA = "0x3664C74", Offset = "0x3664C74", VA = "0x3664C74")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("liftoff failed!", "cheese");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000093 RID: 147 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3664D80", Offset = "0x3664D80", VA = "0x3664D80")]
	[Token(Token = "0x6000093")]
	public void method_42(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000094 RID: 148 RVA: 0x00004370 File Offset: 0x00002570
	[Token(Token = "0x6000094")]
	[Address(RVA = "0x3664E8C", Offset = "0x3664E8C", VA = "0x3664E8C")]
	public void method_43(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("User is on an outdated version of Capuchin. Your version is ", "False");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000095 RID: 149 RVA: 0x000043B0 File Offset: 0x000025B0
	[Address(RVA = "0x3664F98", Offset = "0x3664F98", VA = "0x3664F98")]
	[Token(Token = "0x6000095")]
	public void method_44()
	{
		PlayerPrefs.GetString("typesOfTalk") == "TurnAmount";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000096 RID: 150 RVA: 0x000043E4 File Offset: 0x000025E4
	[Token(Token = "0x6000096")]
	[Address(RVA = "0x366501C", Offset = "0x366501C", VA = "0x366501C")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("PlayerHead", "forced knee");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000097 RID: 151 RVA: 0x00004424 File Offset: 0x00002624
	[Token(Token = "0x6000097")]
	[Address(RVA = "0x3665128", Offset = "0x3665128", VA = "0x3665128")]
	public void method_46()
	{
		PlayerPrefs.GetString("Date: ") == "CapuchinStore";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000098 RID: 152 RVA: 0x00004458 File Offset: 0x00002658
	[Address(RVA = "0x36651AC", Offset = "0x36651AC", VA = "0x36651AC")]
	[Token(Token = "0x6000098")]
	public void method_47()
	{
		PlayerPrefs.GetString("closeToObject") == "GET";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000099 RID: 153 RVA: 0x0000448C File Offset: 0x0000268C
	[Address(RVA = "0x3665230", Offset = "0x3665230", VA = "0x3665230")]
	[Token(Token = "0x6000099")]
	public void method_48(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("DISABLE", "retract broken");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600009A RID: 154 RVA: 0x000044CC File Offset: 0x000026CC
	[Token(Token = "0x600009A")]
	[Address(RVA = "0x366533C", Offset = "0x366533C", VA = "0x366533C")]
	public void method_49(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("next", "Camera movement detected, calibrating height.");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600009B RID: 155 RVA: 0x0000450C File Offset: 0x0000270C
	[Address(RVA = "0x3665448", Offset = "0x3665448", VA = "0x3665448")]
	[Token(Token = "0x600009B")]
	public void method_50()
	{
		PlayerPrefs.GetString("typesOfTalk") == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600009C RID: 156 RVA: 0x00004540 File Offset: 0x00002740
	[Address(RVA = "0x36654CC", Offset = "0x36654CC", VA = "0x36654CC")]
	[Token(Token = "0x600009C")]
	public void method_51(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Squeeze", "");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600009D RID: 157 RVA: 0x00004580 File Offset: 0x00002780
	[Token(Token = "0x600009D")]
	[Address(RVA = "0x36655D8", Offset = "0x36655D8", VA = "0x36655D8")]
	public void method_52(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("ChangeToTagged", "HandL");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600009E RID: 158 RVA: 0x000045C0 File Offset: 0x000027C0
	[Token(Token = "0x600009E")]
	[Address(RVA = "0x36656E4", Offset = "0x36656E4", VA = "0x36656E4")]
	public void method_53(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("spooky guy true", "betaAgree");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600009F RID: 159 RVA: 0x00004600 File Offset: 0x00002800
	[Token(Token = "0x600009F")]
	[Address(RVA = "0x36657F0", Offset = "0x36657F0", VA = "0x36657F0")]
	public void method_54(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("PlayerHead", "Version");
	}

	// Token: 0x060000A0 RID: 160 RVA: 0x00004630 File Offset: 0x00002830
	[Token(Token = "0x60000A0")]
	[Address(RVA = "0x36658FC", Offset = "0x36658FC", VA = "0x36658FC")]
	public void method_55()
	{
		PlayerPrefs.GetString("Player") == "Muted";
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3665994", Offset = "0x3665994", VA = "0x3665994")]
	[Token(Token = "0x60000A1")]
	public BetaGameAgreement()
	{
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x00004654 File Offset: 0x00002854
	[Address(RVA = "0x366599C", Offset = "0x366599C", VA = "0x366599C")]
	[Token(Token = "0x60000A2")]
	public void method_56()
	{
		PlayerPrefs.GetString("Universal Render Pipeline/Lit") == "";
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x00004678 File Offset: 0x00002878
	[Token(Token = "0x60000A3")]
	[Address(RVA = "0x3665A34", Offset = "0x3665A34", VA = "0x3665A34")]
	public void method_57()
	{
		PlayerPrefs.GetString("Regular") == "Completed baking textures on frame ";
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x0000469C File Offset: 0x0000289C
	[Token(Token = "0x60000A4")]
	[Address(RVA = "0x3665ACC", Offset = "0x3665ACC", VA = "0x3665ACC")]
	public void method_58(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Date: ", "{0}/{1:f0}");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x000046DC File Offset: 0x000028DC
	[Token(Token = "0x60000A5")]
	[Address(RVA = "0x3665BD8", Offset = "0x3665BD8", VA = "0x3665BD8")]
	public void method_59(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Version", "Song Index: ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x0000471C File Offset: 0x0000291C
	[Address(RVA = "0x3665CE4", Offset = "0x3665CE4", VA = "0x3665CE4")]
	[Token(Token = "0x60000A6")]
	public void method_60(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Version", "You struck apon an error. ");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x0000475C File Offset: 0x0000295C
	[Address(RVA = "0x3665DF0", Offset = "0x3665DF0", VA = "0x3665DF0")]
	[Token(Token = "0x60000A7")]
	public void method_61()
	{
		PlayerPrefs.GetString(" and for the price of ") == "duration done";
	}

	// Token: 0x060000A8 RID: 168 RVA: 0x00004050 File Offset: 0x00002250
	[Token(Token = "0x60000A8")]
	[Address(RVA = "0x3665E88", Offset = "0x3665E88", VA = "0x3665E88")]
	public void method_62(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000A9 RID: 169 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3665F94", Offset = "0x3665F94", VA = "0x3665F94")]
	[Token(Token = "0x60000A9")]
	public void method_63(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060000AA RID: 170 RVA: 0x00004780 File Offset: 0x00002980
	[Token(Token = "0x60000AA")]
	[Address(RVA = "0x36660A0", Offset = "0x36660A0", VA = "0x36660A0")]
	public void method_64()
	{
		PlayerPrefs.GetString("Purchased: ") == "Name Changing Error. Error: ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000AB RID: 171 RVA: 0x000047B4 File Offset: 0x000029B4
	[Address(RVA = "0x3666124", Offset = "0x3666124", VA = "0x3666124")]
	[Token(Token = "0x60000AB")]
	public void method_65()
	{
		PlayerPrefs.GetString("/") == "/";
	}

	// Token: 0x060000AC RID: 172 RVA: 0x000047D8 File Offset: 0x000029D8
	[Token(Token = "0x60000AC")]
	[Address(RVA = "0x36661BC", Offset = "0x36661BC", VA = "0x36661BC")]
	public void method_66()
	{
		PlayerPrefs.GetString("Tagging") == "You are not the master of the server, you cannot start the game.";
	}

	// Token: 0x060000AD RID: 173 RVA: 0x000047FC File Offset: 0x000029FC
	[Address(RVA = "0x3666254", Offset = "0x3666254", VA = "0x3666254")]
	[Token(Token = "0x60000AD")]
	public void method_67()
	{
		PlayerPrefs.GetString("Horizontal") == "All audio clips have been played.";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000AE RID: 174 RVA: 0x00004830 File Offset: 0x00002A30
	[Token(Token = "0x60000AE")]
	[Address(RVA = "0x36662D8", Offset = "0x36662D8", VA = "0x36662D8")]
	public void method_68(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("/", "SaveHeight");
	}

	// Token: 0x060000AF RID: 175 RVA: 0x00004860 File Offset: 0x00002A60
	[Token(Token = "0x60000AF")]
	[Address(RVA = "0x36663E4", Offset = "0x36663E4", VA = "0x36663E4")]
	public void method_69(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("gravThing", "Vertical");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000B0 RID: 176 RVA: 0x000048A0 File Offset: 0x00002AA0
	[Address(RVA = "0x36664F0", Offset = "0x36664F0", VA = "0x36664F0")]
	[Token(Token = "0x60000B0")]
	public void method_70(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("User has been reported for: ", "DisableCosmetic");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000B1 RID: 177 RVA: 0x000048E0 File Offset: 0x00002AE0
	[Address(RVA = "0x36665FC", Offset = "0x36665FC", VA = "0x36665FC")]
	[Token(Token = "0x60000B1")]
	public void method_71(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("FLSPTLT", "_Tint");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000B2 RID: 178 RVA: 0x00004920 File Offset: 0x00002B20
	[Token(Token = "0x60000B2")]
	[Address(RVA = "0x3666708", Offset = "0x3666708", VA = "0x3666708")]
	public void method_72()
	{
		PlayerPrefs.GetString("Left Hand") == "Left Hand";
	}

	// Token: 0x060000B3 RID: 179 RVA: 0x00004944 File Offset: 0x00002B44
	[Token(Token = "0x60000B3")]
	[Address(RVA = "0x36667A0", Offset = "0x36667A0", VA = "0x36667A0")]
	public void method_73()
	{
		PlayerPrefs.GetString("forced knee retract") == "INSIGNIFICANT CURRENCY";
	}

	// Token: 0x060000B4 RID: 180 RVA: 0x00004968 File Offset: 0x00002B68
	[Address(RVA = "0x3666838", Offset = "0x3666838", VA = "0x3666838")]
	[Token(Token = "0x60000B4")]
	public void method_74()
	{
		PlayerPrefs.GetString("") == "Joined a Room.";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000B5 RID: 181 RVA: 0x0000499C File Offset: 0x00002B9C
	[Address(RVA = "0x36668BC", Offset = "0x36668BC", VA = "0x36668BC")]
	[Token(Token = "0x60000B5")]
	public void method_75()
	{
		PlayerPrefs.GetString("False") == "true";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000B6 RID: 182 RVA: 0x000049D0 File Offset: 0x00002BD0
	[Token(Token = "0x60000B6")]
	[Address(RVA = "0x3666940", Offset = "0x3666940", VA = "0x3666940")]
	public void method_76(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Players Online: ", "/");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000B7 RID: 183 RVA: 0x00004A10 File Offset: 0x00002C10
	[Address(RVA = "0x3666A4C", Offset = "0x3666A4C", VA = "0x3666A4C")]
	[Token(Token = "0x60000B7")]
	public void method_77()
	{
		PlayerPrefs.GetString("true") == " and the correct version is ";
	}

	// Token: 0x060000B8 RID: 184 RVA: 0x00004A34 File Offset: 0x00002C34
	[Address(RVA = "0x3666AE4", Offset = "0x3666AE4", VA = "0x3666AE4")]
	[Token(Token = "0x60000B8")]
	public void method_78()
	{
		PlayerPrefs.GetString("DisableCosmetic") == "DISABLE";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000B9 RID: 185 RVA: 0x00004A68 File Offset: 0x00002C68
	[Address(RVA = "0x3666B68", Offset = "0x3666B68", VA = "0x3666B68")]
	[Token(Token = "0x60000B9")]
	public void method_79(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("sound play stopped", "friend");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000BA RID: 186 RVA: 0x00004AA8 File Offset: 0x00002CA8
	[Address(RVA = "0x3666C74", Offset = "0x3666C74", VA = "0x3666C74")]
	[Token(Token = "0x60000BA")]
	public void method_80(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("\n", "TurnAmount");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000BB RID: 187 RVA: 0x00004AE8 File Offset: 0x00002CE8
	[Address(RVA = "0x3666D80", Offset = "0x3666D80", VA = "0x3666D80")]
	[Token(Token = "0x60000BB")]
	public void method_81()
	{
		PlayerPrefs.GetString("MetaId") == "Player";
	}

	// Token: 0x060000BC RID: 188 RVA: 0x00004B0C File Offset: 0x00002D0C
	[Address(RVA = "0x3666E18", Offset = "0x3666E18", VA = "0x3666E18")]
	[Token(Token = "0x60000BC")]
	public void method_82()
	{
		PlayerPrefs.GetString("\n Time: ") == "User is on an outdated version of Capuchin. Your version is ";
	}

	// Token: 0x060000BD RID: 189 RVA: 0x00004B30 File Offset: 0x00002D30
	[Token(Token = "0x60000BD")]
	[Address(RVA = "0x3666EB0", Offset = "0x3666EB0", VA = "0x3666EB0")]
	public void method_83(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Player", "containsStaff");
		GameObject gameObject2 = this.gameObject_0;
		long active = 1L;
		gameObject2.SetActive(active != 0L);
	}

	// Token: 0x060000BE RID: 190 RVA: 0x00004B68 File Offset: 0x00002D68
	[Address(RVA = "0x3666FBC", Offset = "0x3666FBC", VA = "0x3666FBC")]
	[Token(Token = "0x60000BE")]
	public void method_84(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Vector1_d371bd24217449349bd747533d51af6b", "Player");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000BF RID: 191 RVA: 0x00004BA8 File Offset: 0x00002DA8
	[Token(Token = "0x60000BF")]
	[Address(RVA = "0x36670C8", Offset = "0x36670C8", VA = "0x36670C8")]
	public void method_85()
	{
		PlayerPrefs.GetString("TurnAmount") == "FingerTip";
	}

	// Token: 0x04000009 RID: 9
	[Token(Token = "0x4000009")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;
}
