﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000F6 RID: 246
[Token(Token = "0x20000F6")]
public class makeDoorGoWeeeee : MonoBehaviour
{
	// Token: 0x060024E6 RID: 9446 RVA: 0x0004543C File Offset: 0x0004363C
	[Address(RVA = "0x3536464", Offset = "0x3536464", VA = "0x3536464")]
	[Token(Token = "0x60024E6")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "Left Hand";
	}

	// Token: 0x060024E7 RID: 9447 RVA: 0x00045460 File Offset: 0x00043660
	[Address(RVA = "0x35364F0", Offset = "0x35364F0", VA = "0x35364F0")]
	[Token(Token = "0x60024E7")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.tag == "_Tint";
	}

	// Token: 0x060024E8 RID: 9448 RVA: 0x00045484 File Offset: 0x00043684
	[Address(RVA = "0x353657C", Offset = "0x353657C", VA = "0x353657C")]
	[Token(Token = "0x60024E8")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.tag == "username";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024E9 RID: 9449 RVA: 0x000454B8 File Offset: 0x000436B8
	[Address(RVA = "0x353660C", Offset = "0x353660C", VA = "0x353660C")]
	[Token(Token = "0x60024E9")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.tag == "true";
	}

	// Token: 0x060024EA RID: 9450 RVA: 0x000454DC File Offset: 0x000436DC
	[Address(RVA = "0x3536698", Offset = "0x3536698", VA = "0x3536698")]
	[Token(Token = "0x60024EA")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024EB RID: 9451 RVA: 0x00045510 File Offset: 0x00043710
	[Address(RVA = "0x3536728", Offset = "0x3536728", VA = "0x3536728")]
	[Token(Token = "0x60024EB")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.tag == "true";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024EC RID: 9452 RVA: 0x00045544 File Offset: 0x00043744
	[Address(RVA = "0x35367B8", Offset = "0x35367B8", VA = "0x35367B8")]
	[Token(Token = "0x60024EC")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
	}

	// Token: 0x060024ED RID: 9453 RVA: 0x00045568 File Offset: 0x00043768
	[Address(RVA = "0x3536844", Offset = "0x3536844", VA = "0x3536844")]
	[Token(Token = "0x60024ED")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024EE RID: 9454 RVA: 0x0004559C File Offset: 0x0004379C
	[Address(RVA = "0x35368D4", Offset = "0x35368D4", VA = "0x35368D4")]
	[Token(Token = "0x60024EE")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cannot access index {0}. Buffer is empty";
	}

	// Token: 0x060024EF RID: 9455 RVA: 0x000455C0 File Offset: 0x000437C0
	[Address(RVA = "0x3536960", Offset = "0x3536960", VA = "0x3536960")]
	[Token(Token = "0x60024EF")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.tag == "You have been banned for ";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024F0 RID: 9456 RVA: 0x00045544 File Offset: 0x00043744
	[Address(RVA = "0x35369F0", Offset = "0x35369F0", VA = "0x35369F0")]
	[Token(Token = "0x60024F0")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
	}

	// Token: 0x060024F1 RID: 9457 RVA: 0x000454DC File Offset: 0x000436DC
	[Address(RVA = "0x3536A7C", Offset = "0x3536A7C", VA = "0x3536A7C")]
	[Token(Token = "0x60024F1")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024F2 RID: 9458 RVA: 0x000455F4 File Offset: 0x000437F4
	[Address(RVA = "0x3536B0C", Offset = "0x3536B0C", VA = "0x3536B0C")]
	[Token(Token = "0x60024F2")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.tag == "Display Name Changed!";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024F3 RID: 9459 RVA: 0x00045628 File Offset: 0x00043828
	[Address(RVA = "0x3536B9C", Offset = "0x3536B9C", VA = "0x3536B9C")]
	[Token(Token = "0x60024F3")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "Add/Remove Sword";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024F4 RID: 9460 RVA: 0x0004565C File Offset: 0x0004385C
	[Address(RVA = "0x3536C2C", Offset = "0x3536C2C", VA = "0x3536C2C")]
	[Token(Token = "0x60024F4")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.tag == "Mesh";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024F5 RID: 9461 RVA: 0x00045690 File Offset: 0x00043890
	[Address(RVA = "0x3536CBC", Offset = "0x3536CBC", VA = "0x3536CBC")]
	[Token(Token = "0x60024F5")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.tag == " and for the price of ";
	}

	// Token: 0x060024F6 RID: 9462 RVA: 0x000456B4 File Offset: 0x000438B4
	[Address(RVA = "0x3536D48", Offset = "0x3536D48", VA = "0x3536D48")]
	[Token(Token = "0x60024F6")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.tag == "You are on an outdated version of Capuchin. Your version is ";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024F7 RID: 9463 RVA: 0x000456E8 File Offset: 0x000438E8
	[Address(RVA = "0x3536DD8", Offset = "0x3536DD8", VA = "0x3536DD8")]
	[Token(Token = "0x60024F7")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.tag == "ErrorScreen";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024F8 RID: 9464 RVA: 0x0004571C File Offset: 0x0004391C
	[Address(RVA = "0x3536E68", Offset = "0x3536E68", VA = "0x3536E68")]
	[Token(Token = "0x60024F8")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.tag == "token";
	}

	// Token: 0x060024F9 RID: 9465 RVA: 0x00045740 File Offset: 0x00043940
	[Address(RVA = "0x3536EF4", Offset = "0x3536EF4", VA = "0x3536EF4")]
	[Token(Token = "0x60024F9")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cheating";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024FA RID: 9466 RVA: 0x00045774 File Offset: 0x00043974
	[Address(RVA = "0x3536F84", Offset = "0x3536F84", VA = "0x3536F84")]
	[Token(Token = "0x60024FA")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024FB RID: 9467 RVA: 0x000457A8 File Offset: 0x000439A8
	[Address(RVA = "0x3537014", Offset = "0x3537014", VA = "0x3537014")]
	[Token(Token = "0x60024FB")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.tag == "Joined Public Room Successfully";
	}

	// Token: 0x060024FC RID: 9468 RVA: 0x000457CC File Offset: 0x000439CC
	[Address(RVA = "0x35370A0", Offset = "0x35370A0", VA = "0x35370A0")]
	[Token(Token = "0x60024FC")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.tag == "\n Time: ";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024FD RID: 9469 RVA: 0x00045800 File Offset: 0x00043A00
	[Address(RVA = "0x3537130", Offset = "0x3537130", VA = "0x3537130")]
	[Token(Token = "0x60024FD")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "Name Changing Error. Error: ";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x060024FE RID: 9470 RVA: 0x00045834 File Offset: 0x00043A34
	[Address(RVA = "0x35371C0", Offset = "0x35371C0", VA = "0x35371C0")]
	[Token(Token = "0x60024FE")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.tag == ".Please press the button if you would like to play alone";
	}

	// Token: 0x060024FF RID: 9471 RVA: 0x000454DC File Offset: 0x000436DC
	[Address(RVA = "0x353724C", Offset = "0x353724C", VA = "0x353724C")]
	[Token(Token = "0x60024FF")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002500 RID: 9472 RVA: 0x00045858 File Offset: 0x00043A58
	[Address(RVA = "0x35372DC", Offset = "0x35372DC", VA = "0x35372DC")]
	[Token(Token = "0x6002500")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.tag == "Squeeze";
	}

	// Token: 0x06002501 RID: 9473 RVA: 0x000457CC File Offset: 0x000439CC
	[Address(RVA = "0x3537368", Offset = "0x3537368", VA = "0x3537368")]
	[Token(Token = "0x6002501")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "\n Time: ";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002502 RID: 9474 RVA: 0x0004587C File Offset: 0x00043A7C
	[Address(RVA = "0x35373F8", Offset = "0x35373F8", VA = "0x35373F8")]
	[Token(Token = "0x6002502")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.tag == "Connected to Server.";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002503 RID: 9475 RVA: 0x000458B0 File Offset: 0x00043AB0
	[Address(RVA = "0x3537488", Offset = "0x3537488", VA = "0x3537488")]
	[Token(Token = "0x6002503")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayerHead";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002504 RID: 9476 RVA: 0x000458E4 File Offset: 0x00043AE4
	[Address(RVA = "0x3537518", Offset = "0x3537518", VA = "0x3537518")]
	[Token(Token = "0x6002504")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.tag == "Open";
	}

	// Token: 0x06002505 RID: 9477 RVA: 0x00045908 File Offset: 0x00043B08
	[Address(RVA = "0x35375A4", Offset = "0x35375A4", VA = "0x35375A4")]
	[Token(Token = "0x6002505")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.tag == "_BumpScale";
	}

	// Token: 0x06002506 RID: 9478 RVA: 0x00045510 File Offset: 0x00043710
	[Address(RVA = "0x3537630", Offset = "0x3537630", VA = "0x3537630")]
	[Token(Token = "0x6002506")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.tag == "true";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002507 RID: 9479 RVA: 0x0004592C File Offset: 0x00043B2C
	[Address(RVA = "0x35376C0", Offset = "0x35376C0", VA = "0x35376C0")]
	[Token(Token = "0x6002507")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.tag == "{0}/{1:f0}";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002508 RID: 9480 RVA: 0x00045960 File Offset: 0x00043B60
	[Address(RVA = "0x3537750", Offset = "0x3537750", VA = "0x3537750")]
	[Token(Token = "0x6002508")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.tag == "Removing ";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002509 RID: 9481 RVA: 0x00045994 File Offset: 0x00043B94
	[Address(RVA = "0x35377E0", Offset = "0x35377E0", VA = "0x35377E0")]
	[Token(Token = "0x6002509")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "Meta Platform entitlement error: ";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600250A RID: 9482 RVA: 0x000459C8 File Offset: 0x00043BC8
	[Address(RVA = "0x3537870", Offset = "0x3537870", VA = "0x3537870")]
	[Token(Token = "0x600250A")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.tag == "Faild To Add Winner Money: ";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600250B RID: 9483 RVA: 0x000459FC File Offset: 0x00043BFC
	[Address(RVA = "0x3537900", Offset = "0x3537900", VA = "0x3537900")]
	[Token(Token = "0x600250B")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.tag == "Update User Inventory";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600250C RID: 9484 RVA: 0x000457CC File Offset: 0x000439CC
	[Address(RVA = "0x3537990", Offset = "0x3537990", VA = "0x3537990")]
	[Token(Token = "0x600250C")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.tag == "\n Time: ";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600250D RID: 9485 RVA: 0x00045A30 File Offset: 0x00043C30
	[Address(RVA = "0x3537A20", Offset = "0x3537A20", VA = "0x3537A20")]
	[Token(Token = "0x600250D")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.tag == "User has been reported for: ";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600250E RID: 9486 RVA: 0x00045774 File Offset: 0x00043974
	[Address(RVA = "0x3537AB0", Offset = "0x3537AB0", VA = "0x3537AB0")]
	[Token(Token = "0x600250E")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600250F RID: 9487 RVA: 0x00045A64 File Offset: 0x00043C64
	[Address(RVA = "0x3537B40", Offset = "0x3537B40", VA = "0x3537B40")]
	[Token(Token = "0x600250F")]
	public void method_40(Collider collider_0)
	{
		collider_0.gameObject.tag == "poweredup!";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002510 RID: 9488 RVA: 0x00045A98 File Offset: 0x00043C98
	[Address(RVA = "0x3537BD0", Offset = "0x3537BD0", VA = "0x3537BD0")]
	[Token(Token = "0x6002510")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.tag == "Regular";
	}

	// Token: 0x06002511 RID: 9489 RVA: 0x00045ABC File Offset: 0x00043CBC
	[Address(RVA = "0x3537C5C", Offset = "0x3537C5C", VA = "0x3537C5C")]
	[Token(Token = "0x6002511")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.tag == "ENABLE";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002512 RID: 9490 RVA: 0x00045AF0 File Offset: 0x00043CF0
	[Address(RVA = "0x3537CEC", Offset = "0x3537CEC", VA = "0x3537CEC")]
	[Token(Token = "0x6002512")]
	public void method_43(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "oculus";
	}

	// Token: 0x06002513 RID: 9491 RVA: 0x00045B10 File Offset: 0x00043D10
	[Address(RVA = "0x3537D78", Offset = "0x3537D78", VA = "0x3537D78")]
	[Token(Token = "0x6002513")]
	public void method_44(Collider collider_0)
	{
		collider_0.gameObject.tag == "Push To Talk";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002514 RID: 9492 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3537E08", Offset = "0x3537E08", VA = "0x3537E08")]
	[Token(Token = "0x6002514")]
	public makeDoorGoWeeeee()
	{
	}

	// Token: 0x06002515 RID: 9493 RVA: 0x00045B44 File Offset: 0x00043D44
	[Address(RVA = "0x3537E10", Offset = "0x3537E10", VA = "0x3537E10")]
	[Token(Token = "0x6002515")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002516 RID: 9494 RVA: 0x00045774 File Offset: 0x00043974
	[Address(RVA = "0x3537EA0", Offset = "0x3537EA0", VA = "0x3537EA0")]
	[Token(Token = "0x6002516")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002517 RID: 9495 RVA: 0x00045B78 File Offset: 0x00043D78
	[Address(RVA = "0x3537F30", Offset = "0x3537F30", VA = "0x3537F30")]
	[Token(Token = "0x6002517")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.tag == "GET";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002518 RID: 9496 RVA: 0x00045BAC File Offset: 0x00043DAC
	[Address(RVA = "0x3537FC0", Offset = "0x3537FC0", VA = "0x3537FC0")]
	[Token(Token = "0x6002518")]
	public void method_48(Collider collider_0)
	{
		collider_0.gameObject.tag == "EnableCosmetic";
	}

	// Token: 0x06002519 RID: 9497 RVA: 0x00045BD0 File Offset: 0x00043DD0
	[Address(RVA = "0x353804C", Offset = "0x353804C", VA = "0x353804C")]
	[Token(Token = "0x6002519")]
	public void method_49(Collider collider_0)
	{
		collider_0.gameObject.tag == "Head";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600251A RID: 9498 RVA: 0x00045774 File Offset: 0x00043974
	[Address(RVA = "0x35380DC", Offset = "0x35380DC", VA = "0x35380DC")]
	[Token(Token = "0x600251A")]
	public void method_50(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600251B RID: 9499 RVA: 0x00045858 File Offset: 0x00043A58
	[Address(RVA = "0x353816C", Offset = "0x353816C", VA = "0x353816C")]
	[Token(Token = "0x600251B")]
	public void method_51(Collider collider_0)
	{
		collider_0.gameObject.tag == "Squeeze";
	}

	// Token: 0x0600251C RID: 9500 RVA: 0x00045C04 File Offset: 0x00043E04
	[Address(RVA = "0x35381F8", Offset = "0x35381F8", VA = "0x35381F8")]
	[Token(Token = "0x600251C")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
	}

	// Token: 0x0600251D RID: 9501 RVA: 0x00045C28 File Offset: 0x00043E28
	[Address(RVA = "0x3538284", Offset = "0x3538284", VA = "0x3538284")]
	[Token(Token = "0x600251D")]
	public void method_52(Collider collider_0)
	{
		collider_0.gameObject.tag == "Platform failed to initialize due to exception.";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600251E RID: 9502 RVA: 0x00045C5C File Offset: 0x00043E5C
	[Address(RVA = "0x3538314", Offset = "0x3538314", VA = "0x3538314")]
	[Token(Token = "0x600251E")]
	public void method_53(Collider collider_0)
	{
		collider_0.gameObject.tag == "INSIGNIFICANT CURRENCY";
	}

	// Token: 0x0600251F RID: 9503 RVA: 0x00045C80 File Offset: 0x00043E80
	[Address(RVA = "0x35383A0", Offset = "0x35383A0", VA = "0x35383A0")]
	[Token(Token = "0x600251F")]
	public void method_54(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cannot access index {0}. Buffer size is {1}";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002520 RID: 9504 RVA: 0x00045CB4 File Offset: 0x00043EB4
	[Address(RVA = "0x3538430", Offset = "0x3538430", VA = "0x3538430")]
	[Token(Token = "0x6002520")]
	public void method_55(Collider collider_0)
	{
		collider_0.gameObject.tag == "false";
	}

	// Token: 0x06002521 RID: 9505 RVA: 0x00045CD8 File Offset: 0x00043ED8
	[Address(RVA = "0x35384BC", Offset = "0x35384BC", VA = "0x35384BC")]
	[Token(Token = "0x6002521")]
	public void method_56(Collider collider_0)
	{
		collider_0.gameObject.tag == "containsStaff";
	}

	// Token: 0x06002522 RID: 9506 RVA: 0x00045CFC File Offset: 0x00043EFC
	[Address(RVA = "0x3538548", Offset = "0x3538548", VA = "0x3538548")]
	[Token(Token = "0x6002522")]
	public void method_57(Collider collider_0)
	{
		collider_0.gameObject.tag == "ChangeToRegular";
	}

	// Token: 0x06002523 RID: 9507 RVA: 0x00045D20 File Offset: 0x00043F20
	[Address(RVA = "0x35385D8", Offset = "0x35385D8", VA = "0x35385D8")]
	[Token(Token = "0x6002523")]
	public void method_58(Collider collider_0)
	{
		GameObject gameObject;
		string tag = gameObject.tag;
	}

	// Token: 0x06002524 RID: 9508 RVA: 0x00045D34 File Offset: 0x00043F34
	[Address(RVA = "0x3538664", Offset = "0x3538664", VA = "0x3538664")]
	[Token(Token = "0x6002524")]
	public void method_59(Collider collider_0)
	{
		collider_0.gameObject.tag == "BLUPORT";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06002525 RID: 9509 RVA: 0x00045D68 File Offset: 0x00043F68
	[Address(RVA = "0x35386F4", Offset = "0x35386F4", VA = "0x35386F4")]
	[Token(Token = "0x6002525")]
	public void method_60(Collider collider_0)
	{
		collider_0.gameObject.tag == "Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.";
	}

	// Token: 0x06002526 RID: 9510 RVA: 0x00045D8C File Offset: 0x00043F8C
	[Address(RVA = "0x3538780", Offset = "0x3538780", VA = "0x3538780")]
	[Token(Token = "0x6002526")]
	public void method_61(Collider collider_0)
	{
		collider_0.gameObject.tag == "You Look Like Butt";
	}

	// Token: 0x06002527 RID: 9511 RVA: 0x00045DB0 File Offset: 0x00043FB0
	[Address(RVA = "0x353880C", Offset = "0x353880C", VA = "0x353880C")]
	[Token(Token = "0x6002527")]
	public void method_62(Collider collider_0)
	{
		collider_0.gameObject.tag == "SetColor";
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x040004D2 RID: 1234
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004D2")]
	public DoorLerp doorLerp_0;
}
