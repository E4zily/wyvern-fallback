﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000111 RID: 273
[Token(Token = "0x2000111")]
public class GAttribute0 : PropertyAttribute
{
	// Token: 0x06002923 RID: 10531 RVA: 0x00002DD9 File Offset: 0x00000FD9
	[Token(Token = "0x6002923")]
	[Address(RVA = "0x217A1F8", Offset = "0x217A1F8", VA = "0x217A1F8")]
	public GAttribute0(Type type_1)
	{
		this.type_0 = type_1;
	}

	// Token: 0x04000564 RID: 1380
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000564")]
	public readonly Type type_0;
}
