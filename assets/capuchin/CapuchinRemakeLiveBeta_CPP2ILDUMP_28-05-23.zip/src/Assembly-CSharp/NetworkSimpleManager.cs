﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x0200003A RID: 58
[Token(Token = "0x200003A")]
public class NetworkSimpleManager : MonoBehaviourPunCallbacks
{
	// Token: 0x06000786 RID: 1926 RVA: 0x0000208D File Offset: 0x0000028D
	[Token(Token = "0x6000786")]
	[Address(RVA = "0x2D554A8", Offset = "0x2D554A8", VA = "0x2D554A8")]
	public NetworkSimpleManager()
	{
	}

	// Token: 0x06000787 RID: 1927 RVA: 0x00011D64 File Offset: 0x0000FF64
	[Token(Token = "0x6000787")]
	[Address(RVA = "0x2D554B0", Offset = "0x2D554B0", VA = "0x2D554B0", Slot = "31")]
	public override void OnLeftRoom()
	{
		base.OnLeftRoom();
		GameObject targetGo = this.gameObject_0;
		PhotonNetwork.Destroy(targetGo);
	}

	// Token: 0x06000788 RID: 1928 RVA: 0x00011D84 File Offset: 0x0000FF84
	[Address(RVA = "0x2D55524", Offset = "0x2D55524", VA = "0x2D55524", Slot = "41")]
	[Token(Token = "0x6000788")]
	public override void OnJoinedRoom()
	{
		base.OnJoinedRoom();
		Vector3 position = base.transform.position;
		Quaternion rotation = base.transform.rotation;
		GameObject gameObject;
		this.gameObject_0 = gameObject;
		PhotonView photonView;
		this.photonView_0 = photonView;
		Player localPlayer = PhotonNetwork.LocalPlayer;
		string str = UnityEngine.Random.Range(1, 1000).ToString();
		string nickName = "Player" + str;
		localPlayer.NickName = nickName;
	}

	// Token: 0x04000109 RID: 265
	[Token(Token = "0x4000109")]
	[FieldOffset(Offset = "0x20")]
	private GameObject gameObject_0;

	// Token: 0x0400010A RID: 266
	[Token(Token = "0x400010A")]
	[FieldOffset(Offset = "0x28")]
	private PhotonView photonView_0;
}
