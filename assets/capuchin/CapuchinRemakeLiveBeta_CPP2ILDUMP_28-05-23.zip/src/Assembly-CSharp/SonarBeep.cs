﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200002E RID: 46
[Token(Token = "0x200002E")]
public class SonarBeep : MonoBehaviour
{
	// Token: 0x06000595 RID: 1429 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97294", Offset = "0x2B97294", VA = "0x2B97294")]
	[Token(Token = "0x6000595")]
	private void method_0()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000596 RID: 1430 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x6000596")]
	[Address(RVA = "0x2B97304", Offset = "0x2B97304", VA = "0x2B97304")]
	private void method_1()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000597 RID: 1431 RVA: 0x0000F6CC File Offset: 0x0000D8CC
	[Address(RVA = "0x2B97374", Offset = "0x2B97374", VA = "0x2B97374")]
	[Token(Token = "0x6000597")]
	private void method_2()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000598 RID: 1432 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x6000598")]
	[Address(RVA = "0x2B973E4", Offset = "0x2B973E4", VA = "0x2B973E4")]
	private void method_3()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000599 RID: 1433 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97454", Offset = "0x2B97454", VA = "0x2B97454")]
	[Token(Token = "0x6000599")]
	private void method_4()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600059A RID: 1434 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x600059A")]
	[Address(RVA = "0x2B974C4", Offset = "0x2B974C4", VA = "0x2B974C4")]
	private void method_5()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600059B RID: 1435 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97534", Offset = "0x2B97534", VA = "0x2B97534")]
	[Token(Token = "0x600059B")]
	private void method_6()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600059C RID: 1436 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B975A4", Offset = "0x2B975A4", VA = "0x2B975A4")]
	[Token(Token = "0x600059C")]
	private void method_7()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600059D RID: 1437 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97614", Offset = "0x2B97614", VA = "0x2B97614")]
	[Token(Token = "0x600059D")]
	private void method_8()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600059E RID: 1438 RVA: 0x0000F6E0 File Offset: 0x0000D8E0
	[Token(Token = "0x600059E")]
	[Address(RVA = "0x2B97684", Offset = "0x2B97684", VA = "0x2B97684")]
	private void Update()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600059F RID: 1439 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B976F4", Offset = "0x2B976F4", VA = "0x2B976F4")]
	[Token(Token = "0x600059F")]
	private void method_9()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005A0 RID: 1440 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97764", Offset = "0x2B97764", VA = "0x2B97764")]
	[Token(Token = "0x60005A0")]
	private void method_10()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005A1 RID: 1441 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B977D4", Offset = "0x2B977D4", VA = "0x2B977D4")]
	[Token(Token = "0x60005A1")]
	private void method_11()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005A2 RID: 1442 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x60005A2")]
	[Address(RVA = "0x2B97844", Offset = "0x2B97844", VA = "0x2B97844")]
	private void method_12()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x0000F6F4 File Offset: 0x0000D8F4
	[Token(Token = "0x60005A3")]
	[Address(RVA = "0x2B978B4", Offset = "0x2B978B4", VA = "0x2B978B4")]
	private void method_13()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005A4 RID: 1444 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x60005A4")]
	[Address(RVA = "0x2B97924", Offset = "0x2B97924", VA = "0x2B97924")]
	private void method_14()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005A5 RID: 1445 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x60005A5")]
	[Address(RVA = "0x2B97994", Offset = "0x2B97994", VA = "0x2B97994")]
	private void method_15()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005A6 RID: 1446 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97A04", Offset = "0x2B97A04", VA = "0x2B97A04")]
	[Token(Token = "0x60005A6")]
	private void method_16()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005A7 RID: 1447 RVA: 0x0000F6E0 File Offset: 0x0000D8E0
	[Token(Token = "0x60005A7")]
	[Address(RVA = "0x2B97A74", Offset = "0x2B97A74", VA = "0x2B97A74")]
	private void method_17()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005A8 RID: 1448 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x60005A8")]
	[Address(RVA = "0x2B97AE4", Offset = "0x2B97AE4", VA = "0x2B97AE4")]
	private void method_18()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005A9 RID: 1449 RVA: 0x0000F6F4 File Offset: 0x0000D8F4
	[Token(Token = "0x60005A9")]
	[Address(RVA = "0x2B97B54", Offset = "0x2B97B54", VA = "0x2B97B54")]
	private void method_19()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005AA RID: 1450 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97BC4", Offset = "0x2B97BC4", VA = "0x2B97BC4")]
	[Token(Token = "0x60005AA")]
	private void method_20()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005AB RID: 1451 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x60005AB")]
	[Address(RVA = "0x2B97C34", Offset = "0x2B97C34", VA = "0x2B97C34")]
	private void method_21()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005AC RID: 1452 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97CA4", Offset = "0x2B97CA4", VA = "0x2B97CA4")]
	[Token(Token = "0x60005AC")]
	private void method_22()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005AD RID: 1453 RVA: 0x0000F708 File Offset: 0x0000D908
	[Token(Token = "0x60005AD")]
	[Address(RVA = "0x2B97D14", Offset = "0x2B97D14", VA = "0x2B97D14")]
	private void method_23()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005AE RID: 1454 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97D84", Offset = "0x2B97D84", VA = "0x2B97D84")]
	[Token(Token = "0x60005AE")]
	private void method_24()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005AF RID: 1455 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x60005AF")]
	[Address(RVA = "0x2B97DF4", Offset = "0x2B97DF4", VA = "0x2B97DF4")]
	private void method_25()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005B0 RID: 1456 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97E64", Offset = "0x2B97E64", VA = "0x2B97E64")]
	[Token(Token = "0x60005B0")]
	private void method_26()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005B1 RID: 1457 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x60005B1")]
	[Address(RVA = "0x2B97ED4", Offset = "0x2B97ED4", VA = "0x2B97ED4")]
	private void method_27()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005B2 RID: 1458 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Token(Token = "0x60005B2")]
	[Address(RVA = "0x2B97F44", Offset = "0x2B97F44", VA = "0x2B97F44")]
	private void method_28()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x060005B3 RID: 1459 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2B97FB4", Offset = "0x2B97FB4", VA = "0x2B97FB4")]
	[Token(Token = "0x60005B3")]
	public SonarBeep()
	{
	}

	// Token: 0x060005B4 RID: 1460 RVA: 0x0000F6B8 File Offset: 0x0000D8B8
	[Address(RVA = "0x2B97FBC", Offset = "0x2B97FBC", VA = "0x2B97FBC")]
	[Token(Token = "0x60005B4")]
	private void method_29()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x040000DB RID: 219
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000DB")]
	public SonarBeep.spinnyThing spinnyThing_0;

	// Token: 0x040000DC RID: 220
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40000DC")]
	public SonarBeep.display display_0;

	// Token: 0x0200002F RID: 47
	[Token(Token = "0x200002F")]
	[Serializable]
	public struct spinnyThing
	{
		// Token: 0x040000DD RID: 221
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40000DD")]
		public GameObject spinny;

		// Token: 0x040000DE RID: 222
		[Token(Token = "0x40000DE")]
		[FieldOffset(Offset = "0x8")]
		public Vector3 turnSpeed;
	}

	// Token: 0x02000030 RID: 48
	[Token(Token = "0x2000030")]
	[Serializable]
	public struct display
	{
	}
}
