﻿using System;
using Cpp2IlInjected;
using Locomotion;
using UnityEngine;

// Token: 0x02000095 RID: 149
[Token(Token = "0x2000095")]
public class Pet : MonoBehaviour
{
	// Token: 0x06001571 RID: 5489 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3462240", Offset = "0x3462240", VA = "0x3462240")]
	[Token(Token = "0x6001571")]
	private void method_0()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x06001572 RID: 5490 RVA: 0x000025FA File Offset: 0x000007FA
	[Token(Token = "0x6001572")]
	[Address(RVA = "0x34622DC", Offset = "0x34622DC", VA = "0x34622DC")]
	private void method_1()
	{
		this.method_77();
	}

	// Token: 0x06001573 RID: 5491 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x346283C", Offset = "0x346283C", VA = "0x346283C")]
	[Token(Token = "0x6001573")]
	private void method_2()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x06001574 RID: 5492 RVA: 0x00002602 File Offset: 0x00000802
	[Address(RVA = "0x34628D8", Offset = "0x34628D8", VA = "0x34628D8")]
	[Token(Token = "0x6001574")]
	private void method_3()
	{
		this.method_49();
	}

	// Token: 0x06001575 RID: 5493 RVA: 0x00029E70 File Offset: 0x00028070
	[Token(Token = "0x6001575")]
	[Address(RVA = "0x3462E38", Offset = "0x3462E38", VA = "0x3462E38")]
	private void method_4()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x06001576 RID: 5494 RVA: 0x0000260A File Offset: 0x0000080A
	[Token(Token = "0x6001576")]
	[Address(RVA = "0x3463394", Offset = "0x3463394", VA = "0x3463394")]
	private void method_5()
	{
		this.method_114();
	}

	// Token: 0x06001577 RID: 5495 RVA: 0x00002612 File Offset: 0x00000812
	[Token(Token = "0x6001577")]
	[Address(RVA = "0x34638F4", Offset = "0x34638F4", VA = "0x34638F4")]
	private void method_6()
	{
		this.method_48();
	}

	// Token: 0x06001578 RID: 5496 RVA: 0x00002602 File Offset: 0x00000802
	[Address(RVA = "0x3463E50", Offset = "0x3463E50", VA = "0x3463E50")]
	[Token(Token = "0x6001578")]
	private void method_7()
	{
		this.method_49();
	}

	// Token: 0x06001579 RID: 5497 RVA: 0x00029ED8 File Offset: 0x000280D8
	[Address(RVA = "0x3463E54", Offset = "0x3463E54", VA = "0x3463E54")]
	[Token(Token = "0x6001579")]
	private void method_8()
	{
		Transform transform;
		Vector3 position = transform.position;
		Vector3 down = Vector3.down;
		Transform transform2;
		Vector3 position2 = transform2.transform.position;
		Transform transform3;
		Vector3 position3 = transform3.position;
		Vector3 position4 = transform2.position;
		Color blue = Color.blue;
	}

	// Token: 0x0600157A RID: 5498 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x600157A")]
	[Address(RVA = "0x34643B0", Offset = "0x34643B0", VA = "0x34643B0")]
	private void method_9()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x0600157B RID: 5499 RVA: 0x0000261A File Offset: 0x0000081A
	[Address(RVA = "0x3464908", Offset = "0x3464908", VA = "0x3464908")]
	[Token(Token = "0x600157B")]
	private void method_10()
	{
		this.method_59();
	}

	// Token: 0x0600157C RID: 5500 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3464E68", Offset = "0x3464E68", VA = "0x3464E68")]
	[Token(Token = "0x600157C")]
	public Pet()
	{
	}

	// Token: 0x0600157D RID: 5501 RVA: 0x00002622 File Offset: 0x00000822
	[Address(RVA = "0x3464E84", Offset = "0x3464E84", VA = "0x3464E84")]
	[Token(Token = "0x600157D")]
	private void Update()
	{
		this.method_46();
	}

	// Token: 0x0600157E RID: 5502 RVA: 0x00029F80 File Offset: 0x00028180
	[Address(RVA = "0x34653D4", Offset = "0x34653D4", VA = "0x34653D4")]
	[Token(Token = "0x600157E")]
	private void method_11()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x0600157F RID: 5503 RVA: 0x00029FE8 File Offset: 0x000281E8
	[Address(RVA = "0x3465930", Offset = "0x3465930", VA = "0x3465930")]
	[Token(Token = "0x600157F")]
	private void method_12()
	{
		Transform transform;
		Vector3 position = transform.position;
		Vector3 down = Vector3.down;
		Transform transform2;
		Vector3 position2 = transform2.transform.position;
		Transform transform3;
		Vector3 position3 = transform3.position;
		Vector3 position4 = transform2.position;
		Color blue = Color.blue;
	}

	// Token: 0x06001580 RID: 5504 RVA: 0x0000260A File Offset: 0x0000080A
	[Address(RVA = "0x3465E8C", Offset = "0x3465E8C", VA = "0x3465E8C")]
	[Token(Token = "0x6001580")]
	private void method_13()
	{
		this.method_114();
	}

	// Token: 0x06001581 RID: 5505 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3465E90", Offset = "0x3465E90", VA = "0x3465E90")]
	[Token(Token = "0x6001581")]
	private void method_14()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x06001582 RID: 5506 RVA: 0x00002622 File Offset: 0x00000822
	[Token(Token = "0x6001582")]
	[Address(RVA = "0x3465F2C", Offset = "0x3465F2C", VA = "0x3465F2C")]
	private void method_15()
	{
		this.method_46();
	}

	// Token: 0x06001583 RID: 5507 RVA: 0x0002A028 File Offset: 0x00028228
	[Address(RVA = "0x3465F30", Offset = "0x3465F30", VA = "0x3465F30")]
	[Token(Token = "0x6001583")]
	private void method_16()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x06001584 RID: 5508 RVA: 0x0002A090 File Offset: 0x00028290
	[Token(Token = "0x6001584")]
	[Address(RVA = "0x3466484", Offset = "0x3466484", VA = "0x3466484")]
	private void method_17()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x06001585 RID: 5509 RVA: 0x00029F80 File Offset: 0x00028180
	[Address(RVA = "0x34669E0", Offset = "0x34669E0", VA = "0x34669E0")]
	[Token(Token = "0x6001585")]
	private void method_18()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x06001586 RID: 5510 RVA: 0x0000262A File Offset: 0x0000082A
	[Address(RVA = "0x3466F38", Offset = "0x3466F38", VA = "0x3466F38")]
	[Token(Token = "0x6001586")]
	private void method_19()
	{
		this.method_21();
	}

	// Token: 0x06001587 RID: 5511 RVA: 0x00002632 File Offset: 0x00000832
	[Address(RVA = "0x3467498", Offset = "0x3467498", VA = "0x3467498")]
	[Token(Token = "0x6001587")]
	private void method_20()
	{
		this.method_12();
	}

	// Token: 0x06001588 RID: 5512 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x6001588")]
	[Address(RVA = "0x3466F3C", Offset = "0x3466F3C", VA = "0x3466F3C")]
	private void method_21()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x06001589 RID: 5513 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x346749C", Offset = "0x346749C", VA = "0x346749C")]
	[Token(Token = "0x6001589")]
	private void method_22()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x0600158A RID: 5514 RVA: 0x0000263A File Offset: 0x0000083A
	[Address(RVA = "0x3467538", Offset = "0x3467538", VA = "0x3467538")]
	[Token(Token = "0x600158A")]
	private void method_23()
	{
		this.method_39();
	}

	// Token: 0x0600158B RID: 5515 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3467A94", Offset = "0x3467A94", VA = "0x3467A94")]
	[Token(Token = "0x600158B")]
	private void method_24()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x0600158C RID: 5516 RVA: 0x00002642 File Offset: 0x00000842
	[Token(Token = "0x600158C")]
	[Address(RVA = "0x3467B30", Offset = "0x3467B30", VA = "0x3467B30")]
	private void method_25()
	{
		this.method_86();
	}

	// Token: 0x0600158D RID: 5517 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x600158D")]
	[Address(RVA = "0x3468090", Offset = "0x3468090", VA = "0x3468090")]
	private void method_26()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x0600158E RID: 5518 RVA: 0x0000264A File Offset: 0x0000084A
	[Address(RVA = "0x346812C", Offset = "0x346812C", VA = "0x346812C")]
	[Token(Token = "0x600158E")]
	private void method_27()
	{
		this.method_90();
	}

	// Token: 0x0600158F RID: 5519 RVA: 0x00002642 File Offset: 0x00000842
	[Address(RVA = "0x346868C", Offset = "0x346868C", VA = "0x346868C")]
	[Token(Token = "0x600158F")]
	private void method_28()
	{
		this.method_86();
	}

	// Token: 0x06001590 RID: 5520 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3468690", Offset = "0x3468690", VA = "0x3468690")]
	[Token(Token = "0x6001590")]
	private void method_29()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x06001591 RID: 5521 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x6001591")]
	[Address(RVA = "0x346872C", Offset = "0x346872C", VA = "0x346872C")]
	private void method_30()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x06001592 RID: 5522 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x6001592")]
	[Address(RVA = "0x34687C8", Offset = "0x34687C8", VA = "0x34687C8")]
	private void method_31()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x06001593 RID: 5523 RVA: 0x00002652 File Offset: 0x00000852
	[Address(RVA = "0x3468D20", Offset = "0x3468D20", VA = "0x3468D20")]
	[Token(Token = "0x6001593")]
	private void method_32()
	{
		this.method_82();
	}

	// Token: 0x06001594 RID: 5524 RVA: 0x0002A0F8 File Offset: 0x000282F8
	[Token(Token = "0x6001594")]
	[Address(RVA = "0x346927C", Offset = "0x346927C", VA = "0x346927C")]
	private void method_33()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x06001595 RID: 5525 RVA: 0x0000265A File Offset: 0x0000085A
	[Token(Token = "0x6001595")]
	[Address(RVA = "0x34697D8", Offset = "0x34697D8", VA = "0x34697D8")]
	private void method_34()
	{
		this.method_91();
	}

	// Token: 0x06001596 RID: 5526 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3469D30", Offset = "0x3469D30", VA = "0x3469D30")]
	[Token(Token = "0x6001596")]
	private void method_35()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x06001597 RID: 5527 RVA: 0x0002A15C File Offset: 0x0002835C
	[Address(RVA = "0x3469DCC", Offset = "0x3469DCC", VA = "0x3469DCC")]
	[Token(Token = "0x6001597")]
	private void method_36()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x06001598 RID: 5528 RVA: 0x0002A1C4 File Offset: 0x000283C4
	[Token(Token = "0x6001598")]
	[Address(RVA = "0x346A324", Offset = "0x346A324", VA = "0x346A324")]
	private void method_37()
	{
		Animator animator;
		this.animator_0 = animator;
	}

	// Token: 0x06001599 RID: 5529 RVA: 0x0002A1D8 File Offset: 0x000283D8
	[Token(Token = "0x6001599")]
	[Address(RVA = "0x346A3C0", Offset = "0x346A3C0", VA = "0x346A3C0")]
	private void method_38()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Vector3 position4 = base.transform.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x0600159A RID: 5530 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x600159A")]
	[Address(RVA = "0x346753C", Offset = "0x346753C", VA = "0x346753C")]
	private void method_39()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x0600159B RID: 5531 RVA: 0x0002A240 File Offset: 0x00028440
	[Token(Token = "0x600159B")]
	[Address(RVA = "0x346A91C", Offset = "0x346A91C", VA = "0x346A91C")]
	private void method_40()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x0600159C RID: 5532 RVA: 0x00002662 File Offset: 0x00000862
	[Address(RVA = "0x346AE78", Offset = "0x346AE78", VA = "0x346AE78")]
	[Token(Token = "0x600159C")]
	private void method_41()
	{
		this.method_8();
	}

	// Token: 0x0600159D RID: 5533 RVA: 0x0000266A File Offset: 0x0000086A
	[Token(Token = "0x600159D")]
	[Address(RVA = "0x346AE7C", Offset = "0x346AE7C", VA = "0x346AE7C")]
	private void method_42()
	{
		this.method_109();
	}

	// Token: 0x0600159E RID: 5534 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x346B3D8", Offset = "0x346B3D8", VA = "0x346B3D8")]
	[Token(Token = "0x600159E")]
	private void method_43()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x0600159F RID: 5535 RVA: 0x0000261A File Offset: 0x0000081A
	[Address(RVA = "0x346B474", Offset = "0x346B474", VA = "0x346B474")]
	[Token(Token = "0x600159F")]
	private void method_44()
	{
		this.method_59();
	}

	// Token: 0x060015A0 RID: 5536 RVA: 0x00002672 File Offset: 0x00000872
	[Address(RVA = "0x346B478", Offset = "0x346B478", VA = "0x346B478")]
	[Token(Token = "0x60015A0")]
	private void method_45()
	{
		this.method_11();
	}

	// Token: 0x060015A1 RID: 5537 RVA: 0x0002A2A8 File Offset: 0x000284A8
	[Address(RVA = "0x3464E88", Offset = "0x3464E88", VA = "0x3464E88")]
	[Token(Token = "0x60015A1")]
	private void method_46()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
		Transform transform2 = base.transform;
		Quaternion rotation = base.transform.rotation;
		float deltaTime = Time.deltaTime;
		Vector3 position7 = base.transform.position;
		Vector3 forward = base.transform.forward;
		float deltaTime2 = Time.deltaTime;
		Vector3 position8 = base.transform.position;
		Vector3 position9 = this.transform_0.position;
		Transform transform3 = base.transform;
		Vector3 position10 = base.transform.position;
		float deltaTime3 = Time.deltaTime;
		Mathf.Clamp01(deltaTime3);
		Vector3 position11 = base.transform.position;
		Vector3 position12 = this.transform_0.position;
		Vector3 position13 = base.transform.position;
		Vector3 normalized = base.transform.position.normalized;
		Color green = Color.green;
	}

	// Token: 0x060015A2 RID: 5538 RVA: 0x0002A3BC File Offset: 0x000285BC
	[Address(RVA = "0x346B47C", Offset = "0x346B47C", VA = "0x346B47C")]
	[Token(Token = "0x60015A2")]
	private void method_47()
	{
		base.GetComponent<Animator>();
	}

	// Token: 0x060015A3 RID: 5539 RVA: 0x00029F18 File Offset: 0x00028118
	[Address(RVA = "0x34638F8", Offset = "0x34638F8", VA = "0x34638F8")]
	[Token(Token = "0x60015A3")]
	private void method_48()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015A4 RID: 5540 RVA: 0x0002A3D0 File Offset: 0x000285D0
	[Address(RVA = "0x34628DC", Offset = "0x34628DC", VA = "0x34628DC")]
	[Token(Token = "0x60015A4")]
	private void method_49()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015A5 RID: 5541 RVA: 0x00029F18 File Offset: 0x00028118
	[Address(RVA = "0x346B518", Offset = "0x346B518", VA = "0x346B518")]
	[Token(Token = "0x60015A5")]
	private void method_50()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015A6 RID: 5542 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x346BA70", Offset = "0x346BA70", VA = "0x346BA70")]
	[Token(Token = "0x60015A6")]
	private void method_51()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015A7 RID: 5543 RVA: 0x00029F18 File Offset: 0x00028118
	[Address(RVA = "0x346BB0C", Offset = "0x346BB0C", VA = "0x346BB0C")]
	[Token(Token = "0x60015A7")]
	private void method_52()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015A8 RID: 5544 RVA: 0x0000267A File Offset: 0x0000087A
	[Address(RVA = "0x346C068", Offset = "0x346C068", VA = "0x346C068")]
	[Token(Token = "0x60015A8")]
	private void method_53()
	{
		this.method_81();
	}

	// Token: 0x060015A9 RID: 5545 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015A9")]
	[Address(RVA = "0x346C5C8", Offset = "0x346C5C8", VA = "0x346C5C8")]
	private void Start()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015AA RID: 5546 RVA: 0x0002A438 File Offset: 0x00028638
	[Token(Token = "0x60015AA")]
	[Address(RVA = "0x346C664", Offset = "0x346C664", VA = "0x346C664")]
	private void method_54()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015AB RID: 5547 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x60015AB")]
	[Address(RVA = "0x346CBC0", Offset = "0x346CBC0", VA = "0x346CBC0")]
	private void method_55()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015AC RID: 5548 RVA: 0x00002642 File Offset: 0x00000842
	[Address(RVA = "0x346D11C", Offset = "0x346D11C", VA = "0x346D11C")]
	[Token(Token = "0x60015AC")]
	private void method_56()
	{
		this.method_86();
	}

	// Token: 0x060015AD RID: 5549 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x60015AD")]
	[Address(RVA = "0x346D120", Offset = "0x346D120", VA = "0x346D120")]
	private void method_57()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015AE RID: 5550 RVA: 0x00002682 File Offset: 0x00000882
	[Address(RVA = "0x346D67C", Offset = "0x346D67C", VA = "0x346D67C")]
	[Token(Token = "0x60015AE")]
	private void method_58()
	{
		this.method_40();
	}

	// Token: 0x060015AF RID: 5551 RVA: 0x00029F18 File Offset: 0x00028118
	[Address(RVA = "0x346490C", Offset = "0x346490C", VA = "0x346490C")]
	[Token(Token = "0x60015AF")]
	private void method_59()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015B0 RID: 5552 RVA: 0x0002A4A0 File Offset: 0x000286A0
	[Address(RVA = "0x346D680", Offset = "0x346D680", VA = "0x346D680")]
	[Token(Token = "0x60015B0")]
	private void method_60()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015B1 RID: 5553 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x346DBDC", Offset = "0x346DBDC", VA = "0x346DBDC")]
	[Token(Token = "0x60015B1")]
	private void method_61()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015B2 RID: 5554 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015B2")]
	[Address(RVA = "0x346DC78", Offset = "0x346DC78", VA = "0x346DC78")]
	private void method_62()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015B3 RID: 5555 RVA: 0x00029F18 File Offset: 0x00028118
	[Address(RVA = "0x346DD14", Offset = "0x346DD14", VA = "0x346DD14")]
	[Token(Token = "0x60015B3")]
	private void method_63()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015B4 RID: 5556 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015B4")]
	[Address(RVA = "0x346E26C", Offset = "0x346E26C", VA = "0x346E26C")]
	private void method_64()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015B5 RID: 5557 RVA: 0x00029F80 File Offset: 0x00028180
	[Address(RVA = "0x346E308", Offset = "0x346E308", VA = "0x346E308")]
	[Token(Token = "0x60015B5")]
	private void method_65()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015B6 RID: 5558 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015B6")]
	[Address(RVA = "0x346E864", Offset = "0x346E864", VA = "0x346E864")]
	private void method_66()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015B7 RID: 5559 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015B7")]
	[Address(RVA = "0x346E900", Offset = "0x346E900", VA = "0x346E900")]
	private void method_67()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015B8 RID: 5560 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x60015B8")]
	[Address(RVA = "0x346E99C", Offset = "0x346E99C", VA = "0x346E99C")]
	private void method_68()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015B9 RID: 5561 RVA: 0x0002A508 File Offset: 0x00028708
	[Address(RVA = "0x346EEF4", Offset = "0x346EEF4", VA = "0x346EEF4")]
	[Token(Token = "0x60015B9")]
	private void method_69()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Vector3 position4 = base.transform.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015BA RID: 5562 RVA: 0x00029F18 File Offset: 0x00028118
	[Address(RVA = "0x346F450", Offset = "0x346F450", VA = "0x346F450")]
	[Token(Token = "0x60015BA")]
	private void method_70()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015BB RID: 5563 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x60015BB")]
	[Address(RVA = "0x346F9AC", Offset = "0x346F9AC", VA = "0x346F9AC")]
	private void method_71()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015BC RID: 5564 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x346FF08", Offset = "0x346FF08", VA = "0x346FF08")]
	[Token(Token = "0x60015BC")]
	private void method_72()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015BD RID: 5565 RVA: 0x0000268A File Offset: 0x0000088A
	[Address(RVA = "0x346FFA4", Offset = "0x346FFA4", VA = "0x346FFA4")]
	[Token(Token = "0x60015BD")]
	private void method_73()
	{
		this.method_9();
	}

	// Token: 0x060015BE RID: 5566 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x60015BE")]
	[Address(RVA = "0x346FFA8", Offset = "0x346FFA8", VA = "0x346FFA8")]
	private void method_74()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015BF RID: 5567 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3470504", Offset = "0x3470504", VA = "0x3470504")]
	[Token(Token = "0x60015BF")]
	private void method_75()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015C0 RID: 5568 RVA: 0x0000266A File Offset: 0x0000086A
	[Token(Token = "0x60015C0")]
	[Address(RVA = "0x34705A0", Offset = "0x34705A0", VA = "0x34705A0")]
	private void method_76()
	{
		this.method_109();
	}

	// Token: 0x060015C1 RID: 5569 RVA: 0x0002A570 File Offset: 0x00028770
	[Token(Token = "0x60015C1")]
	[Address(RVA = "0x34622E0", Offset = "0x34622E0", VA = "0x34622E0")]
	private void method_77()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015C2 RID: 5570 RVA: 0x00002602 File Offset: 0x00000802
	[Token(Token = "0x60015C2")]
	[Address(RVA = "0x34705A4", Offset = "0x34705A4", VA = "0x34705A4")]
	private void method_78()
	{
		this.method_49();
	}

	// Token: 0x060015C3 RID: 5571 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015C3")]
	[Address(RVA = "0x34705A8", Offset = "0x34705A8", VA = "0x34705A8")]
	private void method_79()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015C4 RID: 5572 RVA: 0x00002692 File Offset: 0x00000892
	[Token(Token = "0x60015C4")]
	[Address(RVA = "0x3470644", Offset = "0x3470644", VA = "0x3470644")]
	private void method_80()
	{
		this.method_69();
	}

	// Token: 0x060015C5 RID: 5573 RVA: 0x0002A5CC File Offset: 0x000287CC
	[Token(Token = "0x60015C5")]
	[Address(RVA = "0x346C06C", Offset = "0x346C06C", VA = "0x346C06C")]
	private void method_81()
	{
		Transform transform;
		Vector3 position = transform.position;
		Vector3 down = Vector3.down;
		Transform transform2;
		Vector3 position2 = transform2.transform.position;
		Transform transform3;
		Vector3 position3 = transform3.position;
		Vector3 position4 = transform2.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015C6 RID: 5574 RVA: 0x0002A60C File Offset: 0x0002880C
	[Token(Token = "0x60015C6")]
	[Address(RVA = "0x3468D24", Offset = "0x3468D24", VA = "0x3468D24")]
	private void method_82()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Transform transform2;
		Vector3 position5 = transform2.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015C7 RID: 5575 RVA: 0x0002A670 File Offset: 0x00028870
	[Address(RVA = "0x3470648", Offset = "0x3470648", VA = "0x3470648")]
	[Token(Token = "0x60015C7")]
	private void method_83()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015C8 RID: 5576 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015C8")]
	[Address(RVA = "0x3470BA4", Offset = "0x3470BA4", VA = "0x3470BA4")]
	private void method_84()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015C9 RID: 5577 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3470C40", Offset = "0x3470C40", VA = "0x3470C40")]
	[Token(Token = "0x60015C9")]
	private void method_85()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015CA RID: 5578 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x60015CA")]
	[Address(RVA = "0x3467B34", Offset = "0x3467B34", VA = "0x3467B34")]
	private void method_86()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015CB RID: 5579 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3470CDC", Offset = "0x3470CDC", VA = "0x3470CDC")]
	[Token(Token = "0x60015CB")]
	private void method_87()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015CC RID: 5580 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015CC")]
	[Address(RVA = "0x3470D78", Offset = "0x3470D78", VA = "0x3470D78")]
	private void method_88()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015CD RID: 5581 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015CD")]
	[Address(RVA = "0x3470E14", Offset = "0x3470E14", VA = "0x3470E14")]
	private void method_89()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015CE RID: 5582 RVA: 0x0002A6D8 File Offset: 0x000288D8
	[Token(Token = "0x60015CE")]
	[Address(RVA = "0x3468130", Offset = "0x3468130", VA = "0x3468130")]
	private void method_90()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015CF RID: 5583 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x60015CF")]
	[Address(RVA = "0x34697DC", Offset = "0x34697DC", VA = "0x34697DC")]
	private void method_91()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015D0 RID: 5584 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015D0")]
	[Address(RVA = "0x3470EB0", Offset = "0x3470EB0", VA = "0x3470EB0")]
	private void method_92()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015D1 RID: 5585 RVA: 0x0000267A File Offset: 0x0000087A
	[Address(RVA = "0x3470F4C", Offset = "0x3470F4C", VA = "0x3470F4C")]
	[Token(Token = "0x60015D1")]
	private void method_93()
	{
		this.method_81();
	}

	// Token: 0x060015D2 RID: 5586 RVA: 0x0000269A File Offset: 0x0000089A
	[Address(RVA = "0x3470F50", Offset = "0x3470F50", VA = "0x3470F50")]
	[Token(Token = "0x60015D2")]
	private void method_94()
	{
		this.method_111();
	}

	// Token: 0x060015D3 RID: 5587 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x34714B0", Offset = "0x34714B0", VA = "0x34714B0")]
	[Token(Token = "0x60015D3")]
	private void method_95()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015D4 RID: 5588 RVA: 0x0002A734 File Offset: 0x00028934
	[Token(Token = "0x60015D4")]
	[Address(RVA = "0x347154C", Offset = "0x347154C", VA = "0x347154C")]
	private void method_96()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Transform transform2;
		Vector3 position5 = transform2.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015D5 RID: 5589 RVA: 0x0000262A File Offset: 0x0000082A
	[Address(RVA = "0x3471AA8", Offset = "0x3471AA8", VA = "0x3471AA8")]
	[Token(Token = "0x60015D5")]
	private void method_97()
	{
		this.method_21();
	}

	// Token: 0x060015D6 RID: 5590 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015D6")]
	[Address(RVA = "0x3471AAC", Offset = "0x3471AAC", VA = "0x3471AAC")]
	private void method_98()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015D7 RID: 5591 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015D7")]
	[Address(RVA = "0x3471B48", Offset = "0x3471B48", VA = "0x3471B48")]
	private void method_99()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015D8 RID: 5592 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3471BE4", Offset = "0x3471BE4", VA = "0x3471BE4")]
	[Token(Token = "0x60015D8")]
	private void method_100()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015D9 RID: 5593 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60015D9")]
	[Address(RVA = "0x3471C80", Offset = "0x3471C80", VA = "0x3471C80")]
	private void method_101()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060015DA RID: 5594 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3471D1C", Offset = "0x3471D1C", VA = "0x3471D1C")]
	[Token(Token = "0x60015DA")]
	private void method_102()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015DB RID: 5595 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x60015DB")]
	[Address(RVA = "0x3471DB8", Offset = "0x3471DB8", VA = "0x3471DB8")]
	private void method_103()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015DC RID: 5596 RVA: 0x00029E44 File Offset: 0x00028044
	[Address(RVA = "0x3472314", Offset = "0x3472314", VA = "0x3472314")]
	[Token(Token = "0x60015DC")]
	private void method_104()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015DD RID: 5597 RVA: 0x00002682 File Offset: 0x00000882
	[Token(Token = "0x60015DD")]
	[Address(RVA = "0x34723B0", Offset = "0x34723B0", VA = "0x34723B0")]
	private void method_105()
	{
		this.method_40();
	}

	// Token: 0x060015DE RID: 5598 RVA: 0x0000262A File Offset: 0x0000082A
	[Address(RVA = "0x34723B4", Offset = "0x34723B4", VA = "0x34723B4")]
	[Token(Token = "0x60015DE")]
	private void method_106()
	{
		this.method_21();
	}

	// Token: 0x060015DF RID: 5599 RVA: 0x00029F18 File Offset: 0x00028118
	[Address(RVA = "0x34723B8", Offset = "0x34723B8", VA = "0x34723B8")]
	[Token(Token = "0x60015DF")]
	private void method_107()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015E0 RID: 5600 RVA: 0x00029F18 File Offset: 0x00028118
	[Token(Token = "0x60015E0")]
	[Address(RVA = "0x3472910", Offset = "0x3472910", VA = "0x3472910")]
	private void method_108()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015E1 RID: 5601 RVA: 0x0002A798 File Offset: 0x00028998
	[Token(Token = "0x60015E1")]
	[Address(RVA = "0x346AE80", Offset = "0x346AE80", VA = "0x346AE80")]
	private void method_109()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015E2 RID: 5602 RVA: 0x00029E44 File Offset: 0x00028044
	[Token(Token = "0x60015E2")]
	[Address(RVA = "0x3472E6C", Offset = "0x3472E6C", VA = "0x3472E6C")]
	private void method_110()
	{
		Vector3 position = Player.player_0.rigidbody_0.position;
		Animator component = base.GetComponent<Animator>();
		this.animator_0 = component;
	}

	// Token: 0x060015E3 RID: 5603 RVA: 0x0002A800 File Offset: 0x00028A00
	[Token(Token = "0x60015E3")]
	[Address(RVA = "0x3470F54", Offset = "0x3470F54", VA = "0x3470F54")]
	private void method_111()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x060015E4 RID: 5604 RVA: 0x000026A2 File Offset: 0x000008A2
	[Address(RVA = "0x3472F08", Offset = "0x3472F08", VA = "0x3472F08")]
	[Token(Token = "0x60015E4")]
	private void method_112()
	{
		this.method_31();
	}

	// Token: 0x060015E5 RID: 5605 RVA: 0x000026AA File Offset: 0x000008AA
	[Address(RVA = "0x3472F0C", Offset = "0x3472F0C", VA = "0x3472F0C")]
	[Token(Token = "0x60015E5")]
	private void method_113()
	{
		this.method_68();
	}

	// Token: 0x060015E6 RID: 5606 RVA: 0x0002A868 File Offset: 0x00028A68
	[Address(RVA = "0x3463398", Offset = "0x3463398", VA = "0x3463398")]
	[Token(Token = "0x60015E6")]
	private void method_114()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = this.transform_1.position;
		Vector3 down = Vector3.down;
		Transform transform = base.transform;
		Vector3 position4 = base.transform.position;
		Vector3 position5 = base.transform.position;
		Vector3 position6 = this.transform_1.position;
		Color blue = Color.blue;
	}

	// Token: 0x040002C8 RID: 712
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002C8")]
	public Transform transform_0;

	// Token: 0x040002C9 RID: 713
	[Token(Token = "0x40002C9")]
	[FieldOffset(Offset = "0x20")]
	public RaycastHit raycastHit_0;

	// Token: 0x040002CA RID: 714
	[FieldOffset(Offset = "0x4C")]
	[Token(Token = "0x40002CA")]
	public Pet.GEnum6 genum6_0;

	// Token: 0x040002CB RID: 715
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40002CB")]
	private Animator animator_0;

	// Token: 0x040002CC RID: 716
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40002CC")]
	private Vector3 vector3_0;

	// Token: 0x040002CD RID: 717
	[FieldOffset(Offset = "0x64")]
	[Token(Token = "0x40002CD")]
	public float float_0;

	// Token: 0x040002CE RID: 718
	[Token(Token = "0x40002CE")]
	[FieldOffset(Offset = "0x68")]
	public float float_1;

	// Token: 0x040002CF RID: 719
	[Token(Token = "0x40002CF")]
	[FieldOffset(Offset = "0x6C")]
	public float float_2;

	// Token: 0x040002D0 RID: 720
	[Token(Token = "0x40002D0")]
	[FieldOffset(Offset = "0x70")]
	public Transform transform_1;

	// Token: 0x040002D1 RID: 721
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x40002D1")]
	public float float_3;

	// Token: 0x040002D2 RID: 722
	[Token(Token = "0x40002D2")]
	[FieldOffset(Offset = "0x7C")]
	public float float_4;

	// Token: 0x02000096 RID: 150
	[Token(Token = "0x2000096")]
	public enum GEnum6
	{
		// Token: 0x040002D4 RID: 724
		[Token(Token = "0x40002D4")]
		const_0,
		// Token: 0x040002D5 RID: 725
		[Token(Token = "0x40002D5")]
		const_1,
		// Token: 0x040002D6 RID: 726
		[Token(Token = "0x40002D6")]
		const_2
	}
}
