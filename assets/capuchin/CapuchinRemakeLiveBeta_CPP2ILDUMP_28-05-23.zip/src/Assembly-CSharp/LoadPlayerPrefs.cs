﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200007C RID: 124
[Token(Token = "0x200007C")]
public class LoadPlayerPrefs : MonoBehaviour
{
	// Token: 0x0600116F RID: 4463 RVA: 0x00024C64 File Offset: 0x00022E64
	[Address(RVA = "0x2D92C04", Offset = "0x2D92C04", VA = "0x2D92C04")]
	[Token(Token = "0x600116F")]
	private void method_0()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001170 RID: 4464 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x6001170")]
	[Address(RVA = "0x2D92C48", Offset = "0x2D92C48", VA = "0x2D92C48")]
	private void method_1()
	{
	}

	// Token: 0x06001171 RID: 4465 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x6001171")]
	[Address(RVA = "0x2D92CB4", Offset = "0x2D92CB4", VA = "0x2D92CB4")]
	private void method_2()
	{
	}

	// Token: 0x06001172 RID: 4466 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Address(RVA = "0x2D92D20", Offset = "0x2D92D20", VA = "0x2D92D20")]
	[Token(Token = "0x6001172")]
	private void method_3()
	{
	}

	// Token: 0x06001173 RID: 4467 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x6001173")]
	[Address(RVA = "0x2D92D8C", Offset = "0x2D92D8C", VA = "0x2D92D8C")]
	private void method_4()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001174 RID: 4468 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x6001174")]
	[Address(RVA = "0x2D92DD0", Offset = "0x2D92DD0", VA = "0x2D92DD0")]
	private void method_5()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001175 RID: 4469 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6001175")]
	[Address(RVA = "0x2D92E14", Offset = "0x2D92E14", VA = "0x2D92E14")]
	public LoadPlayerPrefs()
	{
	}

	// Token: 0x06001176 RID: 4470 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Address(RVA = "0x2D92E1C", Offset = "0x2D92E1C", VA = "0x2D92E1C")]
	[Token(Token = "0x6001176")]
	private void method_6()
	{
	}

	// Token: 0x06001177 RID: 4471 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Address(RVA = "0x2D92E88", Offset = "0x2D92E88", VA = "0x2D92E88")]
	[Token(Token = "0x6001177")]
	private void method_7()
	{
	}

	// Token: 0x06001178 RID: 4472 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x6001178")]
	[Address(RVA = "0x2D92EF4", Offset = "0x2D92EF4", VA = "0x2D92EF4")]
	private void method_8()
	{
	}

	// Token: 0x06001179 RID: 4473 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x6001179")]
	[Address(RVA = "0x2D92F60", Offset = "0x2D92F60", VA = "0x2D92F60")]
	private void method_9()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600117A RID: 4474 RVA: 0x00024C64 File Offset: 0x00022E64
	[Address(RVA = "0x2D92FA4", Offset = "0x2D92FA4", VA = "0x2D92FA4")]
	[Token(Token = "0x600117A")]
	private void method_10()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600117B RID: 4475 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x600117B")]
	[Address(RVA = "0x2D92FE8", Offset = "0x2D92FE8", VA = "0x2D92FE8")]
	private void method_11()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600117C RID: 4476 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x600117C")]
	[Address(RVA = "0x2D9302C", Offset = "0x2D9302C", VA = "0x2D9302C")]
	private void Start()
	{
	}

	// Token: 0x0600117D RID: 4477 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x600117D")]
	[Address(RVA = "0x2D93098", Offset = "0x2D93098", VA = "0x2D93098")]
	private void method_12()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600117E RID: 4478 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x600117E")]
	[Address(RVA = "0x2D930DC", Offset = "0x2D930DC", VA = "0x2D930DC")]
	private void method_13()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600117F RID: 4479 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x600117F")]
	[Address(RVA = "0x2D93120", Offset = "0x2D93120", VA = "0x2D93120")]
	private void method_14()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001180 RID: 4480 RVA: 0x00024C8C File Offset: 0x00022E8C
	[Address(RVA = "0x2D93164", Offset = "0x2D93164", VA = "0x2D93164")]
	[Token(Token = "0x6001180")]
	private void method_15()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001181 RID: 4481 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Address(RVA = "0x2D931A8", Offset = "0x2D931A8", VA = "0x2D931A8")]
	[Token(Token = "0x6001181")]
	private void method_16()
	{
	}

	// Token: 0x06001182 RID: 4482 RVA: 0x00024C64 File Offset: 0x00022E64
	[Address(RVA = "0x2D93214", Offset = "0x2D93214", VA = "0x2D93214")]
	[Token(Token = "0x6001182")]
	private void method_17()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001183 RID: 4483 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Address(RVA = "0x2D93258", Offset = "0x2D93258", VA = "0x2D93258")]
	[Token(Token = "0x6001183")]
	private void method_18()
	{
	}

	// Token: 0x06001184 RID: 4484 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x6001184")]
	[Address(RVA = "0x2D932C4", Offset = "0x2D932C4", VA = "0x2D932C4")]
	private void method_19()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001185 RID: 4485 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x6001185")]
	[Address(RVA = "0x2D93308", Offset = "0x2D93308", VA = "0x2D93308")]
	private void method_20()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001186 RID: 4486 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x6001186")]
	[Address(RVA = "0x2D9334C", Offset = "0x2D9334C", VA = "0x2D9334C")]
	private void method_21()
	{
	}

	// Token: 0x06001187 RID: 4487 RVA: 0x00024C64 File Offset: 0x00022E64
	[Address(RVA = "0x2D933B8", Offset = "0x2D933B8", VA = "0x2D933B8")]
	[Token(Token = "0x6001187")]
	private void method_22()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001188 RID: 4488 RVA: 0x00024C64 File Offset: 0x00022E64
	[Address(RVA = "0x2D933FC", Offset = "0x2D933FC", VA = "0x2D933FC")]
	[Token(Token = "0x6001188")]
	private void method_23()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001189 RID: 4489 RVA: 0x00024CA4 File Offset: 0x00022EA4
	[Token(Token = "0x6001189")]
	[Address(RVA = "0x2D93440", Offset = "0x2D93440", VA = "0x2D93440")]
	private void method_24()
	{
	}

	// Token: 0x0600118A RID: 4490 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x600118A")]
	[Address(RVA = "0x2D934AC", Offset = "0x2D934AC", VA = "0x2D934AC")]
	private void method_25()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600118B RID: 4491 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x600118B")]
	[Address(RVA = "0x2D934F0", Offset = "0x2D934F0", VA = "0x2D934F0")]
	private void method_26()
	{
	}

	// Token: 0x0600118C RID: 4492 RVA: 0x00024C64 File Offset: 0x00022E64
	[Address(RVA = "0x2D9355C", Offset = "0x2D9355C", VA = "0x2D9355C")]
	[Token(Token = "0x600118C")]
	private void method_27()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600118D RID: 4493 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x600118D")]
	[Address(RVA = "0x2D935A0", Offset = "0x2D935A0", VA = "0x2D935A0")]
	private void method_28()
	{
	}

	// Token: 0x0600118E RID: 4494 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x600118E")]
	[Address(RVA = "0x2D9360C", Offset = "0x2D9360C", VA = "0x2D9360C")]
	private void method_29()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600118F RID: 4495 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x600118F")]
	[Address(RVA = "0x2D93650", Offset = "0x2D93650", VA = "0x2D93650")]
	private void method_30()
	{
	}

	// Token: 0x06001190 RID: 4496 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x6001190")]
	[Address(RVA = "0x2D936BC", Offset = "0x2D936BC", VA = "0x2D936BC")]
	private void method_31()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001191 RID: 4497 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x6001191")]
	[Address(RVA = "0x2D93700", Offset = "0x2D93700", VA = "0x2D93700")]
	private void method_32()
	{
	}

	// Token: 0x06001192 RID: 4498 RVA: 0x00024C64 File Offset: 0x00022E64
	[Address(RVA = "0x2D9376C", Offset = "0x2D9376C", VA = "0x2D9376C")]
	[Token(Token = "0x6001192")]
	private void method_33()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001193 RID: 4499 RVA: 0x00024CB4 File Offset: 0x00022EB4
	[Token(Token = "0x6001193")]
	[Address(RVA = "0x2D937B0", Offset = "0x2D937B0", VA = "0x2D937B0")]
	private void method_34()
	{
	}

	// Token: 0x06001194 RID: 4500 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Address(RVA = "0x2D9381C", Offset = "0x2D9381C", VA = "0x2D9381C")]
	[Token(Token = "0x6001194")]
	private void method_35()
	{
	}

	// Token: 0x06001195 RID: 4501 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x6001195")]
	[Address(RVA = "0x2D93888", Offset = "0x2D93888", VA = "0x2D93888")]
	private void method_36()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001196 RID: 4502 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x6001196")]
	[Address(RVA = "0x2D938CC", Offset = "0x2D938CC", VA = "0x2D938CC")]
	private void method_37()
	{
	}

	// Token: 0x06001197 RID: 4503 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Address(RVA = "0x2D93938", Offset = "0x2D93938", VA = "0x2D93938")]
	[Token(Token = "0x6001197")]
	private void method_38()
	{
	}

	// Token: 0x06001198 RID: 4504 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x6001198")]
	[Address(RVA = "0x2D939A4", Offset = "0x2D939A4", VA = "0x2D939A4")]
	private void method_39()
	{
	}

	// Token: 0x06001199 RID: 4505 RVA: 0x00024C7C File Offset: 0x00022E7C
	[Token(Token = "0x6001199")]
	[Address(RVA = "0x2D93A10", Offset = "0x2D93A10", VA = "0x2D93A10")]
	private void method_40()
	{
	}

	// Token: 0x0600119A RID: 4506 RVA: 0x00024C64 File Offset: 0x00022E64
	[Token(Token = "0x600119A")]
	[Address(RVA = "0x2D93A7C", Offset = "0x2D93A7C", VA = "0x2D93A7C")]
	private void method_41()
	{
		if (this.changeVoiceType_0 == null)
		{
			return;
		}
	}

	// Token: 0x0400027E RID: 638
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400027E")]
	public ChangeVoiceType[] changeVoiceType_0;
}
