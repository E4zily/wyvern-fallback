﻿using System;
using Cpp2IlInjected;
using Mod;
using UnityEngine;

// Token: 0x020000FE RID: 254
[Token(Token = "0x20000FE")]
public class TheBigAnnouncement : MonoBehaviour
{
	// Token: 0x060026A7 RID: 9895 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026A7")]
	[Address(RVA = "0x25CFBBC", Offset = "0x25CFBBC", VA = "0x25CFBBC")]
	public void method_0()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026A8 RID: 9896 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFBD8", Offset = "0x25CFBD8", VA = "0x25CFBD8")]
	[Token(Token = "0x60026A8")]
	public void method_1()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026A9 RID: 9897 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFBF4", Offset = "0x25CFBF4", VA = "0x25CFBF4")]
	[Token(Token = "0x60026A9")]
	public void method_2()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026AA RID: 9898 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026AA")]
	[Address(RVA = "0x25CFC10", Offset = "0x25CFC10", VA = "0x25CFC10")]
	public void method_3()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026AB RID: 9899 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFC2C", Offset = "0x25CFC2C", VA = "0x25CFC2C")]
	[Token(Token = "0x60026AB")]
	public void method_4()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026AC RID: 9900 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFC48", Offset = "0x25CFC48", VA = "0x25CFC48")]
	[Token(Token = "0x60026AC")]
	public void method_5()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026AD RID: 9901 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026AD")]
	[Address(RVA = "0x25CFC64", Offset = "0x25CFC64", VA = "0x25CFC64")]
	public void method_6()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026AE RID: 9902 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFC80", Offset = "0x25CFC80", VA = "0x25CFC80")]
	[Token(Token = "0x60026AE")]
	public void method_7()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026AF RID: 9903 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFC9C", Offset = "0x25CFC9C", VA = "0x25CFC9C")]
	[Token(Token = "0x60026AF")]
	public void method_8()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026B0 RID: 9904 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFCB8", Offset = "0x25CFCB8", VA = "0x25CFCB8")]
	[Token(Token = "0x60026B0")]
	public void method_9()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026B1 RID: 9905 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026B1")]
	[Address(RVA = "0x25CFCD4", Offset = "0x25CFCD4", VA = "0x25CFCD4")]
	public void method_10()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026B2 RID: 9906 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFCF0", Offset = "0x25CFCF0", VA = "0x25CFCF0")]
	[Token(Token = "0x60026B2")]
	public void method_11()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026B3 RID: 9907 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026B3")]
	[Address(RVA = "0x25CFD0C", Offset = "0x25CFD0C", VA = "0x25CFD0C")]
	public void method_12()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026B4 RID: 9908 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFD28", Offset = "0x25CFD28", VA = "0x25CFD28")]
	[Token(Token = "0x60026B4")]
	public void method_13()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026B5 RID: 9909 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026B5")]
	[Address(RVA = "0x25CFD44", Offset = "0x25CFD44", VA = "0x25CFD44")]
	public void method_14()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026B6 RID: 9910 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026B6")]
	[Address(RVA = "0x25CFD60", Offset = "0x25CFD60", VA = "0x25CFD60")]
	public void method_15()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026B7 RID: 9911 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026B7")]
	[Address(RVA = "0x25CFD7C", Offset = "0x25CFD7C", VA = "0x25CFD7C")]
	public void method_16()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026B8 RID: 9912 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFD98", Offset = "0x25CFD98", VA = "0x25CFD98")]
	[Token(Token = "0x60026B8")]
	public void method_17()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026B9 RID: 9913 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026B9")]
	[Address(RVA = "0x25CFDB4", Offset = "0x25CFDB4", VA = "0x25CFDB4")]
	public void method_18()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026BA RID: 9914 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026BA")]
	[Address(RVA = "0x25CFDD0", Offset = "0x25CFDD0", VA = "0x25CFDD0")]
	public void method_19()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026BB RID: 9915 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFDEC", Offset = "0x25CFDEC", VA = "0x25CFDEC")]
	[Token(Token = "0x60026BB")]
	public void method_20()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026BC RID: 9916 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFE08", Offset = "0x25CFE08", VA = "0x25CFE08")]
	[Token(Token = "0x60026BC")]
	public void method_21()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026BD RID: 9917 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFE24", Offset = "0x25CFE24", VA = "0x25CFE24")]
	[Token(Token = "0x60026BD")]
	public void method_22()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026BE RID: 9918 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026BE")]
	[Address(RVA = "0x25CFE40", Offset = "0x25CFE40", VA = "0x25CFE40")]
	public void method_23()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026BF RID: 9919 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFE5C", Offset = "0x25CFE5C", VA = "0x25CFE5C")]
	[Token(Token = "0x60026BF")]
	public void method_24()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026C0 RID: 9920 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026C0")]
	[Address(RVA = "0x25CFE78", Offset = "0x25CFE78", VA = "0x25CFE78")]
	public void method_25()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026C1 RID: 9921 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026C1")]
	[Address(RVA = "0x25CFE94", Offset = "0x25CFE94", VA = "0x25CFE94")]
	public void method_26()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026C2 RID: 9922 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFEB0", Offset = "0x25CFEB0", VA = "0x25CFEB0")]
	[Token(Token = "0x60026C2")]
	public void method_27()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026C3 RID: 9923 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFECC", Offset = "0x25CFECC", VA = "0x25CFECC")]
	[Token(Token = "0x60026C3")]
	public void method_28()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026C4 RID: 9924 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFEE8", Offset = "0x25CFEE8", VA = "0x25CFEE8")]
	[Token(Token = "0x60026C4")]
	public void method_29()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026C5 RID: 9925 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x25CFF04", Offset = "0x25CFF04", VA = "0x25CFF04")]
	[Token(Token = "0x60026C5")]
	public void method_30()
	{
	}

	// Token: 0x060026C6 RID: 9926 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x25CFF20", Offset = "0x25CFF20", VA = "0x25CFF20")]
	[Token(Token = "0x60026C6")]
	public TheBigAnnouncement()
	{
	}

	// Token: 0x060026C7 RID: 9927 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026C7")]
	[Address(RVA = "0x25CFF28", Offset = "0x25CFF28", VA = "0x25CFF28")]
	public void method_31()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026C8 RID: 9928 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFF44", Offset = "0x25CFF44", VA = "0x25CFF44")]
	[Token(Token = "0x60026C8")]
	public void method_32()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026C9 RID: 9929 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026C9")]
	[Address(RVA = "0x25CFF60", Offset = "0x25CFF60", VA = "0x25CFF60")]
	public void method_33()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026CA RID: 9930 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFF7C", Offset = "0x25CFF7C", VA = "0x25CFF7C")]
	[Token(Token = "0x60026CA")]
	public void method_34()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026CB RID: 9931 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFF98", Offset = "0x25CFF98", VA = "0x25CFF98")]
	[Token(Token = "0x60026CB")]
	public void method_35()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026CC RID: 9932 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFFB4", Offset = "0x25CFFB4", VA = "0x25CFFB4")]
	[Token(Token = "0x60026CC")]
	public void method_36()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026CD RID: 9933 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25CFFD0", Offset = "0x25CFFD0", VA = "0x25CFFD0")]
	[Token(Token = "0x60026CD")]
	public void method_37()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026CE RID: 9934 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026CE")]
	[Address(RVA = "0x25CFFEC", Offset = "0x25CFFEC", VA = "0x25CFFEC")]
	public void method_38()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026CF RID: 9935 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026CF")]
	[Address(RVA = "0x25D0008", Offset = "0x25D0008", VA = "0x25D0008")]
	public void method_39()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026D0 RID: 9936 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25D0024", Offset = "0x25D0024", VA = "0x25D0024")]
	[Token(Token = "0x60026D0")]
	public void method_40()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026D1 RID: 9937 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25D0040", Offset = "0x25D0040", VA = "0x25D0040")]
	[Token(Token = "0x60026D1")]
	public void method_41()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026D2 RID: 9938 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25D005C", Offset = "0x25D005C", VA = "0x25D005C")]
	[Token(Token = "0x60026D2")]
	public void method_42()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026D3 RID: 9939 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026D3")]
	[Address(RVA = "0x25D0078", Offset = "0x25D0078", VA = "0x25D0078")]
	public void method_43()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026D4 RID: 9940 RVA: 0x00002D92 File Offset: 0x00000F92
	[Address(RVA = "0x25D0094", Offset = "0x25D0094", VA = "0x25D0094")]
	[Token(Token = "0x60026D4")]
	public void method_44()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026D5 RID: 9941 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026D5")]
	[Address(RVA = "0x25D00B0", Offset = "0x25D00B0", VA = "0x25D00B0")]
	public void method_45()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x060026D6 RID: 9942 RVA: 0x00002D92 File Offset: 0x00000F92
	[Token(Token = "0x60026D6")]
	[Address(RVA = "0x25D00CC", Offset = "0x25D00CC", VA = "0x25D00CC")]
	public void method_46()
	{
		this.tvscreenManager_0.ITSHAPPENINGBRO();
	}

	// Token: 0x040004EB RID: 1259
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004EB")]
	public TVScreenManager tvscreenManager_0;
}
