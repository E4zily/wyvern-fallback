﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.Rendering;

// Token: 0x0200008A RID: 138
[Token(Token = "0x200008A")]
public class MeshMerger : MonoBehaviour
{
	// Token: 0x0600141D RID: 5149 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16DD888", Offset = "0x16DD888", VA = "0x16DD888")]
	[Token(Token = "0x600141D")]
	public void method_0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600141E RID: 5150 RVA: 0x00028568 File Offset: 0x00026768
	[Token(Token = "0x600141E")]
	[Address(RVA = "0x16DF1EC", Offset = "0x16DF1EC", VA = "0x16DF1EC")]
	private Vector3 method_1(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600141F RID: 5151 RVA: 0x00028568 File Offset: 0x00026768
	[Token(Token = "0x600141F")]
	[Address(RVA = "0x16DF264", Offset = "0x16DF264", VA = "0x16DF264")]
	private Vector3 method_2(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001420 RID: 5152 RVA: 0x00028578 File Offset: 0x00026778
	[Address(RVA = "0x16DF2DC", Offset = "0x16DF2DC", VA = "0x16DF2DC")]
	[Token(Token = "0x6001420")]
	private Vector3 method_3(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_121(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001421 RID: 5153 RVA: 0x000285A8 File Offset: 0x000267A8
	[Address(RVA = "0x16DF4C4", Offset = "0x16DF4C4", VA = "0x16DF4C4")]
	[Token(Token = "0x6001421")]
	private Vector3 method_4(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_17(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001422 RID: 5154 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16DF6AC", Offset = "0x16DF6AC", VA = "0x16DF6AC")]
	[Token(Token = "0x6001422")]
	private Vector3 method_5(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001423 RID: 5155 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16DF724", Offset = "0x16DF724", VA = "0x16DF724")]
	[Token(Token = "0x6001423")]
	public void method_6()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001424 RID: 5156 RVA: 0x000285D8 File Offset: 0x000267D8
	[Token(Token = "0x6001424")]
	[Address(RVA = "0x16E108C", Offset = "0x16E108C", VA = "0x16E108C")]
	private Vector3 method_7(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001425 RID: 5157 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16E109C", Offset = "0x16E109C", VA = "0x16E109C")]
	[Token(Token = "0x6001425")]
	private Vector3 method_8(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001426 RID: 5158 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001426")]
	[Address(RVA = "0x16E10AC", Offset = "0x16E10AC", VA = "0x16E10AC")]
	public void method_9()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001427 RID: 5159 RVA: 0x000285E8 File Offset: 0x000267E8
	[Address(RVA = "0x16E29CC", Offset = "0x16E29CC", VA = "0x16E29CC")]
	[Token(Token = "0x6001427")]
	private Transform[] method_10(Transform[] transform_0)
	{
		new List();
		int childCount = new Transform[0].childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001428 RID: 5160 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001428")]
	[Address(RVA = "0x16E2EA0", Offset = "0x16E2EA0", VA = "0x16E2EA0")]
	public void method_11()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001429 RID: 5161 RVA: 0x00028618 File Offset: 0x00026818
	[Token(Token = "0x6001429")]
	[Address(RVA = "0x16E4790", Offset = "0x16E4790", VA = "0x16E4790")]
	private Transform[] method_12(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x0600142A RID: 5162 RVA: 0x0002864C File Offset: 0x0002684C
	[Address(RVA = "0x16E4C68", Offset = "0x16E4C68", VA = "0x16E4C68")]
	[Token(Token = "0x600142A")]
	private Mesh method_13(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "Horizontal";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600142B RID: 5163 RVA: 0x000286A4 File Offset: 0x000268A4
	[Token(Token = "0x600142B")]
	[Address(RVA = "0x16E4E0C", Offset = "0x16E4E0C", VA = "0x16E4E0C")]
	private Vector3 method_14(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform transform_;
		this.method_30(transform_);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x0600142C RID: 5164 RVA: 0x000286CC File Offset: 0x000268CC
	[Token(Token = "0x600142C")]
	[Address(RVA = "0x16E4F00", Offset = "0x16E4F00", VA = "0x16E4F00")]
	private Transform[] method_15(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x0600142D RID: 5165 RVA: 0x00028568 File Offset: 0x00026768
	[Token(Token = "0x600142D")]
	[Address(RVA = "0x16E53E8", Offset = "0x16E53E8", VA = "0x16E53E8")]
	private Vector3 method_16(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600142E RID: 5166 RVA: 0x000286FC File Offset: 0x000268FC
	[Token(Token = "0x600142E")]
	[Address(RVA = "0x16DF5B8", Offset = "0x16DF5B8", VA = "0x16DF5B8")]
	private Vector3 method_17(Transform transform_0)
	{
		Transform transform_;
		this.method_17(transform_);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x0600142F RID: 5167 RVA: 0x00028718 File Offset: 0x00026918
	[Token(Token = "0x600142F")]
	[Address(RVA = "0x16E5460", Offset = "0x16E5460", VA = "0x16E5460")]
	private Mesh method_18(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "PURCHASED";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001430 RID: 5168 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001430")]
	[Address(RVA = "0x16E5604", Offset = "0x16E5604", VA = "0x16E5604")]
	public void method_19()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001431 RID: 5169 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16E6BAC", Offset = "0x16E6BAC", VA = "0x16E6BAC")]
	[Token(Token = "0x6001431")]
	private Vector3 method_20(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001432 RID: 5170 RVA: 0x00028770 File Offset: 0x00026970
	[Token(Token = "0x6001432")]
	[Address(RVA = "0x16E49E0", Offset = "0x16E49E0", VA = "0x16E49E0")]
	private Transform[] method_21(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001433 RID: 5171 RVA: 0x000287A4 File Offset: 0x000269A4
	[Address(RVA = "0x16E6E1C", Offset = "0x16E6E1C", VA = "0x16E6E1C")]
	[Token(Token = "0x6001433")]
	private Vector3 method_22(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_14(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001434 RID: 5172 RVA: 0x00028770 File Offset: 0x00026970
	[Address(RVA = "0x16E6F10", Offset = "0x16E6F10", VA = "0x16E6F10")]
	[Token(Token = "0x6001434")]
	private Transform[] method_23(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001435 RID: 5173 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001435")]
	[Address(RVA = "0x16E7198", Offset = "0x16E7198", VA = "0x16E7198")]
	public void method_24()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001436 RID: 5174 RVA: 0x000287D4 File Offset: 0x000269D4
	[Token(Token = "0x6001436")]
	[Address(RVA = "0x16E88BC", Offset = "0x16E88BC", VA = "0x16E88BC")]
	private Vector3 method_25(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_47(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001437 RID: 5175 RVA: 0x000285D8 File Offset: 0x000267D8
	[Token(Token = "0x6001437")]
	[Address(RVA = "0x16E8AA4", Offset = "0x16E8AA4", VA = "0x16E8AA4")]
	private Vector3 method_26(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001438 RID: 5176 RVA: 0x00028804 File Offset: 0x00026A04
	[Address(RVA = "0x16E0E0C", Offset = "0x16E0E0C", VA = "0x16E0E0C")]
	[Token(Token = "0x6001438")]
	private Mesh method_27(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "Mesh";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001439 RID: 5177 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16E8AB4", Offset = "0x16E8AB4", VA = "0x16E8AB4")]
	[Token(Token = "0x6001439")]
	private Vector3 method_28(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600143A RID: 5178 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16E8AC4", Offset = "0x16E8AC4", VA = "0x16E8AC4")]
	[Token(Token = "0x600143A")]
	public void method_29()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600143B RID: 5179 RVA: 0x0002885C File Offset: 0x00026A5C
	[Address(RVA = "0x16E2734", Offset = "0x16E2734", VA = "0x16E2734")]
	[Token(Token = "0x600143B")]
	private Vector3 method_30(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_25(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x0600143C RID: 5180 RVA: 0x0002888C File Offset: 0x00026A8C
	[Token(Token = "0x600143C")]
	[Address(RVA = "0x16EA13C", Offset = "0x16EA13C", VA = "0x16EA13C")]
	private Transform[] method_31(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x0600143D RID: 5181 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600143D")]
	[Address(RVA = "0x16EA614", Offset = "0x16EA614", VA = "0x16EA614")]
	public void method_32()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600143E RID: 5182 RVA: 0x000288C0 File Offset: 0x00026AC0
	[Token(Token = "0x600143E")]
	[Address(RVA = "0x16EBB38", Offset = "0x16EBB38", VA = "0x16EBB38")]
	private GameObject method_33(Mesh mesh_0, Material[] material_0)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = mesh_0;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = material_0;
		return gameObject;
	}

	// Token: 0x0600143F RID: 5183 RVA: 0x000288C0 File Offset: 0x00026AC0
	[Token(Token = "0x600143F")]
	[Address(RVA = "0x16E87E0", Offset = "0x16E87E0", VA = "0x16E87E0")]
	private GameObject method_34(Mesh mesh_0, Material[] material_0)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = mesh_0;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = material_0;
		return gameObject;
	}

	// Token: 0x06001440 RID: 5184 RVA: 0x00028568 File Offset: 0x00026768
	[Token(Token = "0x6001440")]
	[Address(RVA = "0x16EBC14", Offset = "0x16EBC14", VA = "0x16EBC14")]
	private Vector3 method_35(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001441 RID: 5185 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16EBC8C", Offset = "0x16EBC8C", VA = "0x16EBC8C")]
	[Token(Token = "0x6001441")]
	private Vector3 method_36(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001442 RID: 5186 RVA: 0x000288F4 File Offset: 0x00026AF4
	[Address(RVA = "0x16E6A28", Offset = "0x16E6A28", VA = "0x16E6A28")]
	[Token(Token = "0x6001442")]
	private Mesh method_37(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "Add/Remove Hat";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001443 RID: 5187 RVA: 0x0002894C File Offset: 0x00026B4C
	[Token(Token = "0x6001443")]
	[Address(RVA = "0x16EBD04", Offset = "0x16EBD04", VA = "0x16EBD04")]
	private Mesh method_38(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "NetworkGunShoot";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001444 RID: 5188 RVA: 0x00028578 File Offset: 0x00026778
	[Address(RVA = "0x16EBE88", Offset = "0x16EBE88", VA = "0x16EBE88")]
	[Token(Token = "0x6001444")]
	private Vector3 method_39(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_121(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001445 RID: 5189 RVA: 0x00028618 File Offset: 0x00026818
	[Token(Token = "0x6001445")]
	[Address(RVA = "0x16EBF7C", Offset = "0x16EBF7C", VA = "0x16EBF7C")]
	private Transform[] method_40(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001446 RID: 5190 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001446")]
	[Address(RVA = "0x16EC1CC", Offset = "0x16EC1CC", VA = "0x16EC1CC")]
	public void method_41()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001447 RID: 5191 RVA: 0x000289A4 File Offset: 0x00026BA4
	[Address(RVA = "0x16ED8A0", Offset = "0x16ED8A0", VA = "0x16ED8A0")]
	[Token(Token = "0x6001447")]
	private Mesh method_42(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "false";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001448 RID: 5192 RVA: 0x00028568 File Offset: 0x00026768
	[Token(Token = "0x6001448")]
	[Address(RVA = "0x16EDA44", Offset = "0x16EDA44", VA = "0x16EDA44")]
	private Vector3 method_43(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001449 RID: 5193 RVA: 0x000289FC File Offset: 0x00026BFC
	[Token(Token = "0x6001449")]
	[Address(RVA = "0x16EDABC", Offset = "0x16EDABC", VA = "0x16EDABC")]
	private Mesh method_44(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "Player";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600144A RID: 5194 RVA: 0x00028A54 File Offset: 0x00026C54
	[Address(RVA = "0x16EDC60", Offset = "0x16EDC60", VA = "0x16EDC60")]
	[Token(Token = "0x600144A")]
	private Vector3 method_45(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_30(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x0600144B RID: 5195 RVA: 0x00028A84 File Offset: 0x00026C84
	[Address(RVA = "0x16EDD54", Offset = "0x16EDD54", VA = "0x16EDD54")]
	[Token(Token = "0x600144B")]
	private Mesh method_46(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "_Tint";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600144C RID: 5196 RVA: 0x00028ADC File Offset: 0x00026CDC
	[Address(RVA = "0x16E89B0", Offset = "0x16E89B0", VA = "0x16E89B0")]
	[Token(Token = "0x600144C")]
	private Vector3 method_47(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_97(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x0600144D RID: 5197 RVA: 0x00028B0C File Offset: 0x00026D0C
	[Token(Token = "0x600144D")]
	[Address(RVA = "0x16E4530", Offset = "0x16E4530", VA = "0x16E4530")]
	private Mesh method_48(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "StartSong";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600144E RID: 5198 RVA: 0x00028770 File Offset: 0x00026970
	[Address(RVA = "0x16E0B84", Offset = "0x16E0B84", VA = "0x16E0B84")]
	[Token(Token = "0x600144E")]
	private Transform[] method_49(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x0600144F RID: 5199 RVA: 0x00028B64 File Offset: 0x00026D64
	[Address(RVA = "0x16ED608", Offset = "0x16ED608", VA = "0x16ED608")]
	[Token(Token = "0x600144F")]
	private Vector3 method_50(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_123(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001450 RID: 5200 RVA: 0x00028568 File Offset: 0x00026768
	[Token(Token = "0x6001450")]
	[Address(RVA = "0x16EE0E0", Offset = "0x16EE0E0", VA = "0x16EE0E0")]
	private Vector3 method_51(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001451 RID: 5201 RVA: 0x00028B94 File Offset: 0x00026D94
	[Token(Token = "0x6001451")]
	[Address(RVA = "0x16EE158", Offset = "0x16EE158", VA = "0x16EE158")]
	private Mesh method_52(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "ChangeToTagged";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001452 RID: 5202 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16EE2FC", Offset = "0x16EE2FC", VA = "0x16EE2FC")]
	[Token(Token = "0x6001452")]
	private Vector3 method_53(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001453 RID: 5203 RVA: 0x00028BEC File Offset: 0x00026DEC
	[Address(RVA = "0x16EE374", Offset = "0x16EE374", VA = "0x16EE374")]
	[Token(Token = "0x6001453")]
	private Mesh method_54(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name;
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001454 RID: 5204 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001454")]
	[Address(RVA = "0x16EE518", Offset = "0x16EE518", VA = "0x16EE518")]
	public void method_55()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001455 RID: 5205 RVA: 0x00028568 File Offset: 0x00026768
	[Token(Token = "0x6001455")]
	[Address(RVA = "0x16EFBD4", Offset = "0x16EFBD4", VA = "0x16EFBD4")]
	private Vector3 method_56(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001456 RID: 5206 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16EFC4C", Offset = "0x16EFC4C", VA = "0x16EFC4C")]
	[Token(Token = "0x6001456")]
	private Vector3 method_57(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001457 RID: 5207 RVA: 0x0002888C File Offset: 0x00026A8C
	[Token(Token = "0x6001457")]
	[Address(RVA = "0x16EFCC4", Offset = "0x16EFCC4", VA = "0x16EFCC4")]
	private Transform[] method_58(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001458 RID: 5208 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16EFF24", Offset = "0x16EFF24", VA = "0x16EFF24")]
	[Token(Token = "0x6001458")]
	public void method_59()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001459 RID: 5209 RVA: 0x00028C34 File Offset: 0x00026E34
	[Token(Token = "0x6001459")]
	[Address(RVA = "0x16F1358", Offset = "0x16F1358", VA = "0x16F1358")]
	private Vector3 method_60(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_3(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x0600145A RID: 5210 RVA: 0x00028C64 File Offset: 0x00026E64
	[Address(RVA = "0x16F144C", Offset = "0x16F144C", VA = "0x16F144C")]
	[Token(Token = "0x600145A")]
	private Mesh method_61(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		this._objectName + "Player";
		mesh.name = "Player";
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600145B RID: 5211 RVA: 0x00028618 File Offset: 0x00026818
	[Token(Token = "0x600145B")]
	[Address(RVA = "0x16E24D0", Offset = "0x16E24D0", VA = "0x16E24D0")]
	private Transform[] method_62(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x0600145C RID: 5212 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16F15D0", Offset = "0x16F15D0", VA = "0x16F15D0")]
	[Token(Token = "0x600145C")]
	public void method_63()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600145D RID: 5213 RVA: 0x00028CC0 File Offset: 0x00026EC0
	[Address(RVA = "0x16DEF8C", Offset = "0x16DEF8C", VA = "0x16DEF8C")]
	[Token(Token = "0x600145D")]
	private Mesh method_64(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name;
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600145E RID: 5214 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16F2C7C", Offset = "0x16F2C7C", VA = "0x16F2C7C")]
	[Token(Token = "0x600145E")]
	public void method_65()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600145F RID: 5215 RVA: 0x000288C0 File Offset: 0x00026AC0
	[Address(RVA = "0x16E0FB0", Offset = "0x16E0FB0", VA = "0x16E0FB0")]
	[Token(Token = "0x600145F")]
	private GameObject method_66(Mesh mesh_0, Material[] material_0)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = mesh_0;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = material_0;
		return gameObject;
	}

	// Token: 0x06001460 RID: 5216 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16F41C0", Offset = "0x16F41C0", VA = "0x16F41C0")]
	[Token(Token = "0x6001460")]
	private Vector3 method_67(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001461 RID: 5217 RVA: 0x00028D08 File Offset: 0x00026F08
	[Address(RVA = "0x16F4238", Offset = "0x16F4238", VA = "0x16F4238")]
	[Token(Token = "0x6001461")]
	private Mesh method_68(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "hand 2";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001462 RID: 5218 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16F43DC", Offset = "0x16F43DC", VA = "0x16F43DC")]
	[Token(Token = "0x6001462")]
	private Vector3 method_69(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001463 RID: 5219 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16F4454", Offset = "0x16F4454", VA = "0x16F4454")]
	[Token(Token = "0x6001463")]
	public void method_70()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001464 RID: 5220 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16F5B10", Offset = "0x16F5B10", VA = "0x16F5B10")]
	[Token(Token = "0x6001464")]
	private Vector3 method_71(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001465 RID: 5221 RVA: 0x00028C34 File Offset: 0x00026E34
	[Address(RVA = "0x16F5898", Offset = "0x16F5898", VA = "0x16F5898")]
	[Token(Token = "0x6001465")]
	private Vector3 method_72(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_3(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001466 RID: 5222 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16F5B20", Offset = "0x16F5B20", VA = "0x16F5B20")]
	[Token(Token = "0x6001466")]
	public void method_73()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001467 RID: 5223 RVA: 0x00028D60 File Offset: 0x00026F60
	[Address(RVA = "0x16F6FDC", Offset = "0x16F6FDC", VA = "0x16F6FDC")]
	[Token(Token = "0x6001467")]
	private Mesh method_74(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "typesOfTalk";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001468 RID: 5224 RVA: 0x0002888C File Offset: 0x00026A8C
	[Address(RVA = "0x16E5174", Offset = "0x16E5174", VA = "0x16E5174")]
	[Token(Token = "0x6001468")]
	private Transform[] method_75(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001469 RID: 5225 RVA: 0x00028DB8 File Offset: 0x00026FB8
	[Address(RVA = "0x16DEE98", Offset = "0x16DEE98", VA = "0x16DEE98")]
	[Token(Token = "0x6001469")]
	private Vector3 method_76(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_80(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x0600146A RID: 5226 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16F7180", Offset = "0x16F7180", VA = "0x16F7180")]
	[Token(Token = "0x600146A")]
	private Vector3 method_77(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600146B RID: 5227 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16F71F8", Offset = "0x16F71F8", VA = "0x16F71F8")]
	[Token(Token = "0x600146B")]
	private Vector3 method_78(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600146C RID: 5228 RVA: 0x00028770 File Offset: 0x00026970
	[Address(RVA = "0x16E42A8", Offset = "0x16E42A8", VA = "0x16E42A8")]
	[Token(Token = "0x600146C")]
	private Transform[] method_79(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x0600146D RID: 5229 RVA: 0x00028DE8 File Offset: 0x00026FE8
	[Address(RVA = "0x16E9EA4", Offset = "0x16E9EA4", VA = "0x16E9EA4")]
	[Token(Token = "0x600146D")]
	private Vector3 method_80(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x0600146E RID: 5230 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16F7480", Offset = "0x16F7480", VA = "0x16F7480")]
	[Token(Token = "0x600146E")]
	public void method_81()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600146F RID: 5231 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16F8C50", Offset = "0x16F8C50", VA = "0x16F8C50")]
	[Token(Token = "0x600146F")]
	public void method_82()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001470 RID: 5232 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FA218", Offset = "0x16FA218", VA = "0x16FA218")]
	[Token(Token = "0x6001470")]
	private Vector3 method_83(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001471 RID: 5233 RVA: 0x00028E10 File Offset: 0x00027010
	[Address(RVA = "0x16FA228", Offset = "0x16FA228", VA = "0x16FA228")]
	[Token(Token = "0x6001471")]
	private Mesh method_84(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		string name = this._objectName + "SaveHeight";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001472 RID: 5234 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16FA3AC", Offset = "0x16FA3AC", VA = "0x16FA3AC")]
	[Token(Token = "0x6001472")]
	private Vector3 method_85(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001473 RID: 5235 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16FA424", Offset = "0x16FA424", VA = "0x16FA424")]
	[Token(Token = "0x6001473")]
	private Vector3 method_86(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001474 RID: 5236 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16FA49C", Offset = "0x16FA49C", VA = "0x16FA49C")]
	[Token(Token = "0x6001474")]
	private Vector3 method_87(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001475 RID: 5237 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FA514", Offset = "0x16FA514", VA = "0x16FA514")]
	[Token(Token = "0x6001475")]
	private Vector3 method_88(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001476 RID: 5238 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FA524", Offset = "0x16FA524", VA = "0x16FA524")]
	[Token(Token = "0x6001476")]
	private Vector3 method_89(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001477 RID: 5239 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FA534", Offset = "0x16FA534", VA = "0x16FA534")]
	[Token(Token = "0x6001477")]
	private Vector3 method_90(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001478 RID: 5240 RVA: 0x00028A54 File Offset: 0x00026C54
	[Address(RVA = "0x16F8A80", Offset = "0x16F8A80", VA = "0x16F8A80")]
	[Token(Token = "0x6001478")]
	private Vector3 method_91(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_30(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001479 RID: 5241 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FA544", Offset = "0x16FA544", VA = "0x16FA544")]
	[Token(Token = "0x6001479")]
	private Vector3 method_92(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600147A RID: 5242 RVA: 0x00028568 File Offset: 0x00026768
	[Token(Token = "0x600147A")]
	[Address(RVA = "0x16FA554", Offset = "0x16FA554", VA = "0x16FA554")]
	private Vector3 method_93(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600147B RID: 5243 RVA: 0x00028618 File Offset: 0x00026818
	[Address(RVA = "0x16EA3B0", Offset = "0x16EA3B0", VA = "0x16EA3B0")]
	[Token(Token = "0x600147B")]
	private Transform[] method_94(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x0600147C RID: 5244 RVA: 0x00028E60 File Offset: 0x00027060
	[Address(RVA = "0x16FA094", Offset = "0x16FA094", VA = "0x16FA094")]
	[Token(Token = "0x600147C")]
	private Mesh method_95(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "Pause";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600147D RID: 5245 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16FA5CC", Offset = "0x16FA5CC", VA = "0x16FA5CC")]
	[Token(Token = "0x600147D")]
	private Vector3 method_96(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600147E RID: 5246 RVA: 0x0002885C File Offset: 0x00026A5C
	[Address(RVA = "0x16EDEF8", Offset = "0x16EDEF8", VA = "0x16EDEF8")]
	[Token(Token = "0x600147E")]
	private Vector3 method_97(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_25(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x0600147F RID: 5247 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16FA644", Offset = "0x16FA644", VA = "0x16FA644")]
	[Token(Token = "0x600147F")]
	public void method_98()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001480 RID: 5248 RVA: 0x00028EB8 File Offset: 0x000270B8
	[Address(RVA = "0x16FBBF4", Offset = "0x16FBBF4", VA = "0x16FBBF4")]
	[Token(Token = "0x6001480")]
	private Mesh method_99(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "GET";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001481 RID: 5249 RVA: 0x00028770 File Offset: 0x00026970
	[Address(RVA = "0x16EF94C", Offset = "0x16EF94C", VA = "0x16EF94C")]
	[Token(Token = "0x6001481")]
	private Transform[] method_100(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001482 RID: 5250 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FBD98", Offset = "0x16FBD98", VA = "0x16FBD98")]
	[Token(Token = "0x6001482")]
	private Vector3 method_101(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001483 RID: 5251 RVA: 0x000288C0 File Offset: 0x00026AC0
	[Address(RVA = "0x16F8B74", Offset = "0x16F8B74", VA = "0x16F8B74")]
	[Token(Token = "0x6001483")]
	private GameObject method_102(Mesh mesh_0, Material[] material_0)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = mesh_0;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = material_0;
		return gameObject;
	}

	// Token: 0x06001484 RID: 5252 RVA: 0x00028770 File Offset: 0x00026970
	[Address(RVA = "0x16FBDA8", Offset = "0x16FBDA8", VA = "0x16FBDA8")]
	[Token(Token = "0x6001484")]
	private Transform[] method_103(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001485 RID: 5253 RVA: 0x00028F10 File Offset: 0x00027110
	[Address(RVA = "0x16FC030", Offset = "0x16FC030", VA = "0x16FC030")]
	[Token(Token = "0x6001485")]
	private Mesh method_104(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "M/d/yyyy";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001486 RID: 5254 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16FC1B4", Offset = "0x16FC1B4", VA = "0x16FC1B4")]
	[Token(Token = "0x6001486")]
	private Vector3 method_105(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001487 RID: 5255 RVA: 0x00028F68 File Offset: 0x00027168
	[Address(RVA = "0x16FC22C", Offset = "0x16FC22C", VA = "0x16FC22C")]
	[Token(Token = "0x6001487")]
	private Mesh method_106(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		this._objectName + "_BumpMap";
		throw new NullReferenceException();
	}

	// Token: 0x06001488 RID: 5256 RVA: 0x00028F8C File Offset: 0x0002718C
	[Address(RVA = "0x16ED6FC", Offset = "0x16ED6FC", VA = "0x16ED6FC")]
	[Token(Token = "0x6001488")]
	private Mesh method_107(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name;
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001489 RID: 5257 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FC3B0", Offset = "0x16FC3B0", VA = "0x16FC3B0")]
	[Token(Token = "0x6001489")]
	private Vector3 method_108(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600148A RID: 5258 RVA: 0x00028F8C File Offset: 0x0002718C
	[Address(RVA = "0x16FBA50", Offset = "0x16FBA50", VA = "0x16FBA50")]
	[Token(Token = "0x600148A")]
	private Mesh method_109(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name;
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600148B RID: 5259 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16FC3C0", Offset = "0x16FC3C0", VA = "0x16FC3C0")]
	[Token(Token = "0x600148B")]
	private Vector3 method_110(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600148C RID: 5260 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FC438", Offset = "0x16FC438", VA = "0x16FC438")]
	[Token(Token = "0x600148C")]
	private Vector3 method_111(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600148D RID: 5261 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FC448", Offset = "0x16FC448", VA = "0x16FC448")]
	[Token(Token = "0x600148D")]
	private Vector3 method_112(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600148E RID: 5262 RVA: 0x00028568 File Offset: 0x00026768
	[Address(RVA = "0x16FC458", Offset = "0x16FC458", VA = "0x16FC458")]
	[Token(Token = "0x600148E")]
	private Vector3 method_113(Vector3 vector3_0, Quaternion quaternion_0, Vector3 vector3_1, Vector3 vector3_2)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x0600148F RID: 5263 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16FC4D0", Offset = "0x16FC4D0", VA = "0x16FC4D0")]
	[Token(Token = "0x600148F")]
	public void method_114()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001490 RID: 5264 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16FD864", Offset = "0x16FD864", VA = "0x16FD864")]
	[Token(Token = "0x6001490")]
	public void method_115()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001491 RID: 5265 RVA: 0x00028FD4 File Offset: 0x000271D4
	[Address(RVA = "0x16E8568", Offset = "0x16E8568", VA = "0x16E8568")]
	[Token(Token = "0x6001491")]
	private Vector3 method_116(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_60(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001492 RID: 5266 RVA: 0x00029004 File Offset: 0x00027204
	[Address(RVA = "0x16E2828", Offset = "0x16E2828", VA = "0x16E2828")]
	[Token(Token = "0x6001492")]
	private Mesh method_117(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "MetaAuth";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001493 RID: 5267 RVA: 0x00028618 File Offset: 0x00026818
	[Address(RVA = "0x16F8834", Offset = "0x16F8834", VA = "0x16F8834")]
	[Token(Token = "0x6001493")]
	private Transform[] method_118(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001494 RID: 5268 RVA: 0x00028618 File Offset: 0x00026818
	[Address(RVA = "0x16E2C40", Offset = "0x16E2C40", VA = "0x16E2C40")]
	[Token(Token = "0x6001494")]
	private Transform[] method_119(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001495 RID: 5269 RVA: 0x00029054 File Offset: 0x00027254
	[Address(RVA = "0x16FEC28", Offset = "0x16FEC28", VA = "0x16FEC28")]
	[Token(Token = "0x6001495")]
	private Mesh method_120(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "containsStaff";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x06001496 RID: 5270 RVA: 0x00028ADC File Offset: 0x00026CDC
	[Address(RVA = "0x16DF3D0", Offset = "0x16DF3D0", VA = "0x16DF3D0")]
	[Token(Token = "0x6001496")]
	private Vector3 method_121(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_97(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001497 RID: 5271 RVA: 0x000290AC File Offset: 0x000272AC
	[Address(RVA = "0x16F7208", Offset = "0x16F7208", VA = "0x16F7208")]
	[Token(Token = "0x6001497")]
	private Transform[] method_122(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x06001498 RID: 5272 RVA: 0x00028B64 File Offset: 0x00026D64
	[Address(RVA = "0x16EDFEC", Offset = "0x16EDFEC", VA = "0x16EDFEC")]
	[Token(Token = "0x6001498")]
	private Vector3 method_123(Transform transform_0)
	{
		Transform parent = transform_0.parent;
		Vector3 localScale = transform_0.localScale;
		Transform parent2 = transform_0.parent;
		this.method_123(parent2);
		return typeof(UnityEngine.Object).TypeHandle;
	}

	// Token: 0x06001499 RID: 5273 RVA: 0x000290E0 File Offset: 0x000272E0
	[Address(RVA = "0x16FEDAC", Offset = "0x16FEDAC", VA = "0x16FEDAC")]
	[Token(Token = "0x6001499")]
	private Mesh method_124(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "EnableCosmetic";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x0600149A RID: 5274 RVA: 0x000288C0 File Offset: 0x00026AC0
	[Address(RVA = "0x16F40E4", Offset = "0x16F40E4", VA = "0x16F40E4")]
	[Token(Token = "0x600149A")]
	private GameObject method_125(Mesh mesh_0, Material[] material_0)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = mesh_0;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = material_0;
		return gameObject;
	}

	// Token: 0x0600149B RID: 5275 RVA: 0x00029138 File Offset: 0x00027338
	[Address(RVA = "0x16E9F98", Offset = "0x16E9F98", VA = "0x16E9F98")]
	[Token(Token = "0x600149B")]
	private Mesh method_126(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		throw new MissingMethodException();
	}

	// Token: 0x0600149C RID: 5276 RVA: 0x00028618 File Offset: 0x00026818
	[Address(RVA = "0x16FEF50", Offset = "0x16FEF50", VA = "0x16FEF50")]
	[Token(Token = "0x600149C")]
	private Transform[] method_127(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x0600149D RID: 5277 RVA: 0x0002914C File Offset: 0x0002734C
	[Address(RVA = "0x16E6BBC", Offset = "0x16E6BBC", VA = "0x16E6BBC")]
	[Token(Token = "0x600149D")]
	private Transform[] method_128(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x0600149E RID: 5278 RVA: 0x000288C0 File Offset: 0x00026AC0
	[Address(RVA = "0x16EBA5C", Offset = "0x16EBA5C", VA = "0x16EBA5C")]
	[Token(Token = "0x600149E")]
	private GameObject method_129(Mesh mesh_0, Material[] material_0)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = mesh_0;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = material_0;
		return gameObject;
	}

	// Token: 0x0600149F RID: 5279 RVA: 0x00028770 File Offset: 0x00026970
	[Address(RVA = "0x16F29F4", Offset = "0x16F29F4", VA = "0x16F29F4")]
	[Token(Token = "0x600149F")]
	private Transform[] method_130(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x060014A0 RID: 5280 RVA: 0x00029180 File Offset: 0x00027380
	[Address(RVA = "0x16FF1B4", Offset = "0x16FF1B4", VA = "0x16FF1B4")]
	[Token(Token = "0x60014A0")]
	private Mesh method_131(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "Player";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x060014A1 RID: 5281 RVA: 0x00028618 File Offset: 0x00026818
	[Address(RVA = "0x16DEC34", Offset = "0x16DEC34", VA = "0x16DEC34")]
	[Token(Token = "0x60014A1")]
	private Transform[] method_132(Transform[] transform_0)
	{
		new List();
		Transform[] array = new Transform[0];
		int childCount = array.childCount;
		Transform transform;
		if (transform != null && transform == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return transform;
	}

	// Token: 0x060014A2 RID: 5282 RVA: 0x000288C0 File Offset: 0x00026AC0
	[Address(RVA = "0x16F6F00", Offset = "0x16F6F00", VA = "0x16F6F00")]
	[Token(Token = "0x60014A2")]
	private GameObject method_133(Mesh mesh_0, Material[] material_0)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = mesh_0;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = material_0;
		return gameObject;
	}

	// Token: 0x060014A3 RID: 5283 RVA: 0x000291D8 File Offset: 0x000273D8
	[Address(RVA = "0x16E865C", Offset = "0x16E865C", VA = "0x16E865C")]
	[Token(Token = "0x60014A3")]
	private Mesh method_134(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "retract broken";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x060014A4 RID: 5284 RVA: 0x000288C0 File Offset: 0x00026AC0
	[Address(RVA = "0x16E46B4", Offset = "0x16E46B4", VA = "0x16E46B4")]
	[Token(Token = "0x60014A4")]
	private GameObject method_135(Mesh mesh_0, Material[] material_0)
	{
		GameObject gameObject = new GameObject(this._objectName);
		gameObject.AddComponent<MeshFilter>().sharedMesh = mesh_0;
		gameObject.AddComponent<MeshRenderer>().sharedMaterials = material_0;
		return gameObject;
	}

	// Token: 0x060014A5 RID: 5285 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FF358", Offset = "0x16FF358", VA = "0x16FF358")]
	[Token(Token = "0x60014A5")]
	private Vector3 method_136(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060014A6 RID: 5286 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x16FF368", Offset = "0x16FF368", VA = "0x16FF368")]
	[Token(Token = "0x60014A6")]
	private Vector3 method_137(Vector3 vector3_0)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x060014A7 RID: 5287 RVA: 0x00029230 File Offset: 0x00027430
	[Address(RVA = "0x16F598C", Offset = "0x16F598C", VA = "0x16F598C")]
	[Token(Token = "0x60014A7")]
	private Mesh method_138(Vector3[] vector3_0, int[] int_0, Vector2[] vector2_0, Vector4[] vector4_0, Vector3[] vector3_1, SubMeshDescriptor[] subMeshDescriptor_0)
	{
		Mesh mesh = new Mesh();
		mesh.vertices = vector3_0;
		mesh.triangles = int_0;
		mesh.uv = vector2_0;
		mesh.tangents = vector4_0;
		mesh.normals = vector3_1;
		string name = this._objectName + "PlayerHead";
		mesh.name = name;
		mesh.RecalculateBounds();
		return mesh;
	}

	// Token: 0x060014A8 RID: 5288 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16DF110", Offset = "0x16DF110", VA = "0x16DF110")]
	[Token(Token = "0x60014A8")]
	private GameObject method_139(Mesh mesh_0, Material[] material_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060014A9 RID: 5289 RVA: 0x000025CE File Offset: 0x000007CE
	[Address(RVA = "0x16FF378", Offset = "0x16FF378", VA = "0x16FF378")]
	[Token(Token = "0x60014A9")]
	public MeshMerger()
	{
	}

	// Token: 0x060014AA RID: 5290 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x16FF3D4", Offset = "0x16FF3D4", VA = "0x16FF3D4")]
	[Token(Token = "0x60014AA")]
	public void method_140()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x040002A5 RID: 677
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002A5")]
	[SerializeField]
	private Transform[] _mergeObjects;

	// Token: 0x040002A6 RID: 678
	[SerializeField]
	[Token(Token = "0x40002A6")]
	[FieldOffset(Offset = "0x20")]
	private Transform _meshPivot;

	// Token: 0x040002A7 RID: 679
	[Token(Token = "0x40002A7")]
	[Header("Save properties")]
	[SerializeField]
	[FieldOffset(Offset = "0x28")]
	private string _objectName = "MergedObject";

	// Token: 0x0200008B RID: 139
	[Token(Token = "0x200008B")]
	private struct Struct0
	{
		// Token: 0x040002A8 RID: 680
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40002A8")]
		public List<Vector3> list_0;

		// Token: 0x040002A9 RID: 681
		[Token(Token = "0x40002A9")]
		[FieldOffset(Offset = "0x8")]
		public List<Vector2> list_1;

		// Token: 0x040002AA RID: 682
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40002AA")]
		public List<Vector4> list_2;

		// Token: 0x040002AB RID: 683
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40002AB")]
		public List<Vector3> list_3;

		// Token: 0x040002AC RID: 684
		[Token(Token = "0x40002AC")]
		[FieldOffset(Offset = "0x20")]
		public List<int> list_4;

		// Token: 0x040002AD RID: 685
		[Token(Token = "0x40002AD")]
		[FieldOffset(Offset = "0x28")]
		public Material material_0;
	}

	// Token: 0x0200008C RID: 140
	[CompilerGenerated]
	[Token(Token = "0x200008C")]
	private sealed class Class15
	{
		// Token: 0x060014AB RID: 5291 RVA: 0x000020B4 File Offset: 0x000002B4
		[Address(RVA = "0x1074FAC", Offset = "0x1074FAC", VA = "0x1074FAC")]
		[Token(Token = "0x60014AB")]
		public Class15()
		{
		}

		// Token: 0x060014AC RID: 5292 RVA: 0x00029288 File Offset: 0x00027488
		[Address(RVA = "0x1074FB4", Offset = "0x1074FB4", VA = "0x1074FB4")]
		[Token(Token = "0x60014AC")]
		internal int method_0(int index)
		{
			throw new NullReferenceException();
		}

		// Token: 0x040002AE RID: 686
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40002AE")]
		public MeshMerger <>4__this;

		// Token: 0x040002AF RID: 687
		[Token(Token = "0x40002AF")]
		[FieldOffset(Offset = "0x18")]
		public List<MeshMerger.Struct0> subMeshesInfo;

		// Token: 0x040002B0 RID: 688
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40002B0")]
		public Vector3[] vertices;

		// Token: 0x040002B1 RID: 689
		[Token(Token = "0x40002B1")]
		[FieldOffset(Offset = "0x28")]
		public Func<int, int> <>9__7;
	}

	// Token: 0x0200008D RID: 141
	[Token(Token = "0x200008D")]
	[CompilerGenerated]
	private sealed class Class16
	{
		// Token: 0x060014AD RID: 5293 RVA: 0x000020B4 File Offset: 0x000002B4
		[Token(Token = "0x60014AD")]
		[Address(RVA = "0x1075088", Offset = "0x1075088", VA = "0x1075088")]
		public Class16()
		{
		}

		// Token: 0x060014AE RID: 5294 RVA: 0x0002929C File Offset: 0x0002749C
		[Address(RVA = "0x1075090", Offset = "0x1075090", VA = "0x1075090")]
		[Token(Token = "0x60014AE")]
		internal Vector3 method_0(Vector3 verticle)
		{
			Transform transform = this.currentTransform;
			Quaternion rotation = transform.rotation;
			Vector3 zero = Vector3.zero;
			throw new NullReferenceException();
		}

		// Token: 0x060014AF RID: 5295 RVA: 0x000292C4 File Offset: 0x000274C4
		[Token(Token = "0x60014AF")]
		[Address(RVA = "0x1075168", Offset = "0x1075168", VA = "0x1075168")]
		internal Vector4 method_1(Vector4 tangent)
		{
			Quaternion rotation = this.currentTransform.rotation;
			Vector3 one = Vector3.one;
			Vector3 zero = Vector3.zero;
			throw new NullReferenceException();
		}

		// Token: 0x060014B0 RID: 5296 RVA: 0x000292F0 File Offset: 0x000274F0
		[Token(Token = "0x60014B0")]
		[Address(RVA = "0x1075250", Offset = "0x1075250", VA = "0x1075250")]
		internal Vector3 method_2(Vector3 normal)
		{
			Quaternion rotation = this.currentTransform.rotation;
			Vector3 one = Vector3.one;
			Vector3 zero = Vector3.zero;
			throw new NullReferenceException();
		}

		// Token: 0x040002B2 RID: 690
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40002B2")]
		public Transform currentTransform;

		// Token: 0x040002B3 RID: 691
		[Token(Token = "0x40002B3")]
		[FieldOffset(Offset = "0x18")]
		public Vector3 globalScale;

		// Token: 0x040002B4 RID: 692
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x40002B4")]
		public Vector3 meshLocalPosition;

		// Token: 0x040002B5 RID: 693
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40002B5")]
		public SubMeshDescriptor[] subMeshDescriptors;

		// Token: 0x040002B6 RID: 694
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40002B6")]
		public Material[] meshMaterials;

		// Token: 0x040002B7 RID: 695
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40002B7")]
		public MeshMerger.Class15 CS$<>8__locals1;

		// Token: 0x040002B8 RID: 696
		[Token(Token = "0x40002B8")]
		[FieldOffset(Offset = "0x48")]
		public Func<Vector3, Vector3> <>9__1;

		// Token: 0x040002B9 RID: 697
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x40002B9")]
		public Func<Vector4, Vector4> <>9__2;

		// Token: 0x040002BA RID: 698
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x40002BA")]
		public Func<Vector3, Vector3> <>9__3;
	}

	// Token: 0x0200008E RID: 142
	[CompilerGenerated]
	[Token(Token = "0x200008E")]
	private sealed class Class17
	{
		// Token: 0x060014B1 RID: 5297 RVA: 0x000020B4 File Offset: 0x000002B4
		[Address(RVA = "0x107531C", Offset = "0x107531C", VA = "0x107531C")]
		[Token(Token = "0x60014B1")]
		public Class17()
		{
		}

		// Token: 0x060014B2 RID: 5298 RVA: 0x0002931C File Offset: 0x0002751C
		[Address(RVA = "0x1075324", Offset = "0x1075324", VA = "0x1075324")]
		[Token(Token = "0x60014B2")]
		internal int method_0(int index)
		{
			throw new NullReferenceException();
		}

		// Token: 0x060014B3 RID: 5299 RVA: 0x00029330 File Offset: 0x00027530
		[Address(RVA = "0x1075374", Offset = "0x1075374", VA = "0x1075374")]
		[Token(Token = "0x60014B3")]
		internal bool method_1(MeshMerger.Struct0 subMeshInfo)
		{
			Material[] meshMaterials = this.CS$<>8__locals2.meshMaterials;
			if (meshMaterials != null)
			{
			}
			bool result;
			return result;
		}

		// Token: 0x040002BB RID: 699
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40002BB")]
		public int i;

		// Token: 0x040002BC RID: 700
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40002BC")]
		public MeshMerger.Class16 CS$<>8__locals2;
	}

	// Token: 0x0200008F RID: 143
	[Token(Token = "0x200008F")]
	[CompilerGenerated]
	private sealed class Class18
	{
		// Token: 0x060014B4 RID: 5300 RVA: 0x000020B4 File Offset: 0x000002B4
		[Token(Token = "0x60014B4")]
		[Address(RVA = "0x1074FD4", Offset = "0x1074FD4", VA = "0x1074FD4")]
		public Class18()
		{
		}

		// Token: 0x060014B5 RID: 5301 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x60014B5")]
		[Address(RVA = "0x1074FDC", Offset = "0x1074FDC", VA = "0x1074FDC")]
		internal int method_0(int index)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x040002BD RID: 701
		[Token(Token = "0x40002BD")]
		[FieldOffset(Offset = "0x10")]
		public int subMeshInfoIndex;

		// Token: 0x040002BE RID: 702
		[Token(Token = "0x40002BE")]
		[FieldOffset(Offset = "0x18")]
		public MeshMerger.Class17 CS$<>8__locals3;
	}
}
