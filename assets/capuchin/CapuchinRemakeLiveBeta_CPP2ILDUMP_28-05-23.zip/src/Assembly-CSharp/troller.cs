﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200010F RID: 271
[Token(Token = "0x200010F")]
public class troller : MonoBehaviour
{
	// Token: 0x060028DC RID: 10460 RVA: 0x00058BC0 File Offset: 0x00056DC0
	[Token(Token = "0x60028DC")]
	[Address(RVA = "0x3546CAC", Offset = "0x3546CAC", VA = "0x3546CAC")]
	public void method_0(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long minInclusive = 12L;
		long maxExclusive = 2L;
		int minInclusive2 = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		long maxExclusive2 = 6L;
		UnityEngine.Random.Range(minInclusive2, (int)maxExclusive2);
	}

	// Token: 0x060028DD RID: 10461 RVA: 0x00058C08 File Offset: 0x00056E08
	[Address(RVA = "0x3546DE0", Offset = "0x3546DE0", VA = "0x3546DE0")]
	[Token(Token = "0x60028DD")]
	public void method_1(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long maxExclusive = 2L;
		UnityEngine.Random.Range(0, (int)maxExclusive);
	}

	// Token: 0x060028DE RID: 10462 RVA: 0x00058C40 File Offset: 0x00056E40
	[Address(RVA = "0x3546F14", Offset = "0x3546F14", VA = "0x3546F14")]
	[Token(Token = "0x60028DE")]
	public void method_2(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long maxExclusive = 4L;
		UnityEngine.Random.Range(84, (int)maxExclusive);
		UnityEngine.Random.Range(50, 5);
	}

	// Token: 0x060028DF RID: 10463 RVA: 0x00058C80 File Offset: 0x00056E80
	[Address(RVA = "0x3547048", Offset = "0x3547048", VA = "0x3547048")]
	[Token(Token = "0x60028DF")]
	public void method_3(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long maxExclusive = 0L;
		UnityEngine.Random.Range(0, (int)maxExclusive);
	}

	// Token: 0x060028E0 RID: 10464 RVA: 0x00058CB8 File Offset: 0x00056EB8
	[Token(Token = "0x60028E0")]
	[Address(RVA = "0x354717C", Offset = "0x354717C", VA = "0x354717C")]
	public void method_4(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long minInclusive = -8L;
		long maxExclusive = 1L;
		int minInclusive2 = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		long maxExclusive2 = 0L;
		UnityEngine.Random.Range(minInclusive2, (int)maxExclusive2);
	}

	// Token: 0x060028E1 RID: 10465 RVA: 0x00058D00 File Offset: 0x00056F00
	[Token(Token = "0x60028E1")]
	[Address(RVA = "0x35472B0", Offset = "0x35472B0", VA = "0x35472B0")]
	public void method_5(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long minInclusive = 63L;
		long maxExclusive = 2L;
		int minInclusive2 = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		long maxExclusive2 = 3L;
		UnityEngine.Random.Range(minInclusive2, (int)maxExclusive2);
	}

	// Token: 0x060028E2 RID: 10466 RVA: 0x00058D48 File Offset: 0x00056F48
	[Address(RVA = "0x35473E0", Offset = "0x35473E0", VA = "0x35473E0")]
	[Token(Token = "0x60028E2")]
	public void method_6(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long maxExclusive = 3L;
		UnityEngine.Random.Range(0, (int)maxExclusive);
	}

	// Token: 0x060028E3 RID: 10467 RVA: 0x00058D80 File Offset: 0x00056F80
	[Address(RVA = "0x3547514", Offset = "0x3547514", VA = "0x3547514")]
	[PunRPC]
	[Token(Token = "0x60028E3")]
	public void Fling(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long minInclusive = -5L;
		UnityEngine.Random.Range((int)minInclusive, 5);
		long minInclusive2 = -5L;
		UnityEngine.Random.Range((int)minInclusive2, 5);
	}

	// Token: 0x060028E4 RID: 10468 RVA: 0x00058DC4 File Offset: 0x00056FC4
	[Address(RVA = "0x3547644", Offset = "0x3547644", VA = "0x3547644")]
	[Token(Token = "0x60028E4")]
	public void method_7(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long maxExclusive = 2L;
		UnityEngine.Random.Range(51, (int)maxExclusive);
		long minInclusive = -113L;
		long maxExclusive2 = 8L;
		UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive2);
	}

	// Token: 0x060028E5 RID: 10469 RVA: 0x00058E0C File Offset: 0x0005700C
	[Address(RVA = "0x3547778", Offset = "0x3547778", VA = "0x3547778")]
	[Token(Token = "0x60028E5")]
	public void method_8(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long minInclusive = -5L;
		long maxExclusive = 0L;
		UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		long minInclusive2 = -33L;
		UnityEngine.Random.Range((int)minInclusive2, 5);
	}

	// Token: 0x060028E6 RID: 10470 RVA: 0x00058E54 File Offset: 0x00057054
	[Token(Token = "0x60028E6")]
	[Address(RVA = "0x35478AC", Offset = "0x35478AC", VA = "0x35478AC")]
	public void method_9(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		UnityEngine.Random.Range(0, 5);
	}

	// Token: 0x060028E7 RID: 10471 RVA: 0x00058E88 File Offset: 0x00057088
	[Token(Token = "0x60028E7")]
	[Address(RVA = "0x35479E0", Offset = "0x35479E0", VA = "0x35479E0")]
	public void method_10(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long minInclusive = -57L;
		long maxExclusive = 0L;
		int minInclusive2 = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		long maxExclusive2 = 1L;
		UnityEngine.Random.Range(minInclusive2, (int)maxExclusive2);
	}

	// Token: 0x060028E8 RID: 10472 RVA: 0x00058ED0 File Offset: 0x000570D0
	[Address(RVA = "0x3547B14", Offset = "0x3547B14", VA = "0x3547B14")]
	[Token(Token = "0x60028E8")]
	public void method_11(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long maxExclusive = 7L;
		int minInclusive = UnityEngine.Random.Range(114, (int)maxExclusive);
		long maxExclusive2 = 6L;
		UnityEngine.Random.Range(minInclusive, (int)maxExclusive2);
	}

	// Token: 0x060028E9 RID: 10473 RVA: 0x00058F18 File Offset: 0x00057118
	[Address(RVA = "0x3547C48", Offset = "0x3547C48", VA = "0x3547C48")]
	[Token(Token = "0x60028E9")]
	public void method_12(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long maxExclusive = 4L;
		UnityEngine.Random.Range(0, (int)maxExclusive);
	}

	// Token: 0x060028EA RID: 10474 RVA: 0x00058E54 File Offset: 0x00057054
	[Token(Token = "0x60028EA")]
	[Address(RVA = "0x3547D7C", Offset = "0x3547D7C", VA = "0x3547D7C")]
	public void method_13(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		UnityEngine.Random.Range(0, 5);
	}

	// Token: 0x060028EB RID: 10475 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3547EB0", Offset = "0x3547EB0", VA = "0x3547EB0")]
	[Token(Token = "0x60028EB")]
	public troller()
	{
	}

	// Token: 0x060028EC RID: 10476 RVA: 0x00058F50 File Offset: 0x00057150
	[Token(Token = "0x60028EC")]
	[Address(RVA = "0x3547EB8", Offset = "0x3547EB8", VA = "0x3547EB8")]
	public void method_14(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long maxExclusive = 1L;
		UnityEngine.Random.Range(0, (int)maxExclusive);
	}

	// Token: 0x060028ED RID: 10477 RVA: 0x00058F88 File Offset: 0x00057188
	[Token(Token = "0x60028ED")]
	[Address(RVA = "0x3547FEC", Offset = "0x3547FEC", VA = "0x3547FEC")]
	public void method_15(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long maxExclusive = 8L;
		UnityEngine.Random.Range(116, (int)maxExclusive);
		long maxExclusive2 = 4L;
		UnityEngine.Random.Range(53, (int)maxExclusive2);
	}

	// Token: 0x060028EE RID: 10478 RVA: 0x00058FCC File Offset: 0x000571CC
	[Address(RVA = "0x3548120", Offset = "0x3548120", VA = "0x3548120")]
	[Token(Token = "0x60028EE")]
	public void method_16(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long maxExclusive = 8L;
		UnityEngine.Random.Range(0, (int)maxExclusive);
	}

	// Token: 0x060028EF RID: 10479 RVA: 0x00059004 File Offset: 0x00057204
	[Address(RVA = "0x3548250", Offset = "0x3548250", VA = "0x3548250")]
	[Token(Token = "0x60028EF")]
	public void method_17(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		long minInclusive = 15L;
		long maxExclusive = 7L;
		int minInclusive2 = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		long maxExclusive2 = 2L;
		UnityEngine.Random.Range(minInclusive2, (int)maxExclusive2);
	}

	// Token: 0x060028F0 RID: 10480 RVA: 0x00059044 File Offset: 0x00057244
	[Token(Token = "0x60028F0")]
	[Address(RVA = "0x3548384", Offset = "0x3548384", VA = "0x3548384")]
	public void method_18(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		int minInclusive = UnityEngine.Random.Range(11, 5);
		long maxExclusive = 8L;
		UnityEngine.Random.Range(minInclusive, (int)maxExclusive);
	}

	// Token: 0x060028F1 RID: 10481 RVA: 0x00059088 File Offset: 0x00057288
	[Address(RVA = "0x35484B8", Offset = "0x35484B8", VA = "0x35484B8")]
	[Token(Token = "0x60028F1")]
	public void method_19(string string_0, float float_0)
	{
		PhotonNetwork.LocalPlayer.nickName == string_0;
		Vector3 position = this.rigidbody_0.position;
		long minInclusive = 124L;
		long maxExclusive = 1L;
		UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
	}

	// Token: 0x04000558 RID: 1368
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000558")]
	public Rigidbody rigidbody_0;

	// Token: 0x04000559 RID: 1369
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000559")]
	public GameObject gameObject_0;

	// Token: 0x0400055A RID: 1370
	[Token(Token = "0x400055A")]
	[FieldOffset(Offset = "0x28")]
	public PhotonView photonView_0;
}
