﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

// Token: 0x020000DC RID: 220
[Token(Token = "0x20000DC")]
public class MusicManager : MonoBehaviour
{
	// Token: 0x060020BF RID: 8383 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E6E5E8", Offset = "0x2E6E5E8", VA = "0x2E6E5E8")]
	[Token(Token = "0x60020BF")]
	public void method_0()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020C0 RID: 8384 RVA: 0x0003D494 File Offset: 0x0003B694
	[Address(RVA = "0x2E6E684", Offset = "0x2E6E684", VA = "0x2E6E684")]
	[Token(Token = "0x60020C0")]
	public void Start()
	{
		AudioClip[] array = this.audioClip_0;
		if (array.m_PCMReaderCallback == null)
		{
			throw new IndexOutOfRangeException();
		}
		this.audioSource_0.Play();
	}

	// Token: 0x060020C1 RID: 8385 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E6E718", Offset = "0x2E6E718", VA = "0x2E6E718")]
	[Token(Token = "0x60020C1")]
	public void method_1()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020C2 RID: 8386 RVA: 0x0003D4C4 File Offset: 0x0003B6C4
	[Address(RVA = "0x2E6E7B4", Offset = "0x2E6E7B4", VA = "0x2E6E7B4")]
	[Token(Token = "0x60020C2")]
	public void method_2()
	{
		Debug.LogWarning("BLUTARG");
	}

	// Token: 0x060020C3 RID: 8387 RVA: 0x0003D4DC File Offset: 0x0003B6DC
	[PunRPC]
	[Address(RVA = "0x2E6E914", Offset = "0x2E6E914", VA = "0x2E6E914")]
	[Token(Token = "0x60020C3")]
	public void StartLastSong()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020C4 RID: 8388 RVA: 0x0003D504 File Offset: 0x0003B704
	[Address(RVA = "0x2E6E9BC", Offset = "0x2E6E9BC", VA = "0x2E6E9BC")]
	[Token(Token = "0x60020C4")]
	public void method_3()
	{
		if (this.bool_0)
		{
			this.method_32();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060020C5 RID: 8389 RVA: 0x0003D528 File Offset: 0x0003B728
	[Address(RVA = "0x2E6EBBC", Offset = "0x2E6EBBC", VA = "0x2E6EBBC")]
	[Token(Token = "0x60020C5")]
	public void Update()
	{
		string str;
		"Song Index: " + str;
		if (this.bool_0)
		{
			this.method_5();
		}
	}

	// Token: 0x060020C6 RID: 8390 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E6EDB8", Offset = "0x2E6EDB8", VA = "0x2E6EDB8")]
	[Token(Token = "0x60020C6")]
	public void method_4()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020C7 RID: 8391 RVA: 0x0003D550 File Offset: 0x0003B750
	[Address(RVA = "0x2E6EC58", Offset = "0x2E6EC58", VA = "0x2E6EC58")]
	[Token(Token = "0x60020C7")]
	public void method_5()
	{
		Debug.LogWarning("All audio clips have been played.");
	}

	// Token: 0x060020C8 RID: 8392 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E6EE54", Offset = "0x2E6EE54", VA = "0x2E6EE54")]
	[Token(Token = "0x60020C8")]
	public void method_6()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020C9 RID: 8393 RVA: 0x0003D568 File Offset: 0x0003B768
	[Address(RVA = "0x2E6EEF0", Offset = "0x2E6EEF0", VA = "0x2E6EEF0")]
	[Token(Token = "0x60020C9")]
	public void method_7()
	{
		AudioSource audioSource = this.audioSource_0;
		long num = 1L;
		this.byte_0 = (byte)num;
		audioSource.Play();
	}

	// Token: 0x060020CA RID: 8394 RVA: 0x0003D58C File Offset: 0x0003B78C
	[Address(RVA = "0x2E6EF8C", Offset = "0x2E6EF8C", VA = "0x2E6EF8C")]
	[Token(Token = "0x60020CA")]
	public void method_8()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020CB RID: 8395 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E6F024", Offset = "0x2E6F024", VA = "0x2E6F024")]
	[Token(Token = "0x60020CB")]
	public void method_9()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020CC RID: 8396 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E6F0C0", Offset = "0x2E6F0C0", VA = "0x2E6F0C0")]
	[Token(Token = "0x60020CC")]
	public void method_10()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020CD RID: 8397 RVA: 0x0003D4DC File Offset: 0x0003B6DC
	[Address(RVA = "0x2E6F15C", Offset = "0x2E6F15C", VA = "0x2E6F15C")]
	[Token(Token = "0x60020CD")]
	public void method_11()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020CE RID: 8398 RVA: 0x0003D5A4 File Offset: 0x0003B7A4
	[Address(RVA = "0x2E6F204", Offset = "0x2E6F204", VA = "0x2E6F204")]
	[Token(Token = "0x60020CE")]
	public void method_12()
	{
		AudioSource audioSource = this.audioSource_0;
		long num = 1L;
		this.byte_0 = (byte)num;
		audioSource.Play();
	}

	// Token: 0x060020CF RID: 8399 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E6F2A0", Offset = "0x2E6F2A0", VA = "0x2E6F2A0")]
	[Token(Token = "0x60020CF")]
	public void method_13()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020D0 RID: 8400 RVA: 0x0003D5C8 File Offset: 0x0003B7C8
	[Address(RVA = "0x2E6F33C", Offset = "0x2E6F33C", VA = "0x2E6F33C")]
	[Token(Token = "0x60020D0")]
	public void method_14()
	{
		Debug.LogWarning("Player");
	}

	// Token: 0x060020D1 RID: 8401 RVA: 0x0003D5E0 File Offset: 0x0003B7E0
	[Address(RVA = "0x2E6F49C", Offset = "0x2E6F49C", VA = "0x2E6F49C")]
	[Token(Token = "0x60020D1")]
	public void method_15()
	{
		Debug.LogWarning("Connected to Server.");
		long num = 1L;
		this.byte_0 = (byte)num;
	}

	// Token: 0x060020D2 RID: 8402 RVA: 0x0003D600 File Offset: 0x0003B800
	[Address(RVA = "0x2E6F600", Offset = "0x2E6F600", VA = "0x2E6F600")]
	[Token(Token = "0x60020D2")]
	public void method_16()
	{
		string str;
		"SaveHeight" + str;
		if (this.bool_0)
		{
			this.method_14();
		}
	}

	// Token: 0x060020D3 RID: 8403 RVA: 0x0003D4DC File Offset: 0x0003B6DC
	[Address(RVA = "0x2E6F69C", Offset = "0x2E6F69C", VA = "0x2E6F69C")]
	[Token(Token = "0x60020D3")]
	public void method_17()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020D4 RID: 8404 RVA: 0x0003D628 File Offset: 0x0003B828
	[Address(RVA = "0x2E6F744", Offset = "0x2E6F744", VA = "0x2E6F744")]
	[Token(Token = "0x60020D4")]
	public void method_18()
	{
		string str;
		"StartSong" + str;
		if (this.bool_0)
		{
			this.method_34();
		}
	}

	// Token: 0x060020D5 RID: 8405 RVA: 0x0003D650 File Offset: 0x0003B850
	[Address(RVA = "0x2E6F940", Offset = "0x2E6F940", VA = "0x2E6F940")]
	[Token(Token = "0x60020D5")]
	public void method_19()
	{
		string str;
		"ChangeToRegular" + str;
		if (this.bool_0)
		{
			this.method_36();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060020D6 RID: 8406 RVA: 0x0003D494 File Offset: 0x0003B694
	[Address(RVA = "0x2E6FB44", Offset = "0x2E6FB44", VA = "0x2E6FB44")]
	[Token(Token = "0x60020D6")]
	public void method_20()
	{
		AudioClip[] array = this.audioClip_0;
		if (array.m_PCMReaderCallback == null)
		{
			throw new IndexOutOfRangeException();
		}
		this.audioSource_0.Play();
	}

	// Token: 0x060020D7 RID: 8407 RVA: 0x0003D680 File Offset: 0x0003B880
	[Address(RVA = "0x2E6FBD8", Offset = "0x2E6FBD8", VA = "0x2E6FBD8")]
	[Token(Token = "0x60020D7")]
	public void method_21()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020D8 RID: 8408 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E6FC74", Offset = "0x2E6FC74", VA = "0x2E6FC74")]
	[Token(Token = "0x60020D8")]
	public void method_22()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020D9 RID: 8409 RVA: 0x0003D4DC File Offset: 0x0003B6DC
	[Address(RVA = "0x2E6FD10", Offset = "0x2E6FD10", VA = "0x2E6FD10")]
	[Token(Token = "0x60020D9")]
	public void method_23()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020DA RID: 8410 RVA: 0x0003D698 File Offset: 0x0003B898
	[Address(RVA = "0x2E6FDB8", Offset = "0x2E6FDB8", VA = "0x2E6FDB8")]
	[Token(Token = "0x60020DA")]
	public void method_24()
	{
		string str;
		"EnableCosmetic" + str;
		if (this.bool_0)
		{
			this.method_15();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060020DB RID: 8411 RVA: 0x0003D6C8 File Offset: 0x0003B8C8
	[Address(RVA = "0x2E6FE58", Offset = "0x2E6FE58", VA = "0x2E6FE58")]
	[Token(Token = "0x60020DB")]
	public void method_25()
	{
		Debug.LogWarning("A Player has left the Room.");
		long num = 1L;
		this.byte_0 = (byte)num;
	}

	// Token: 0x060020DC RID: 8412 RVA: 0x0003D6E8 File Offset: 0x0003B8E8
	[Address(RVA = "0x2E6FFBC", Offset = "0x2E6FFBC", VA = "0x2E6FFBC")]
	[Token(Token = "0x60020DC")]
	public void method_26()
	{
		string str;
		"Player" + str;
		if (this.bool_0)
		{
			this.method_36();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060020DD RID: 8413 RVA: 0x0003D718 File Offset: 0x0003B918
	[Address(RVA = "0x2E7005C", Offset = "0x2E7005C", VA = "0x2E7005C")]
	[Token(Token = "0x60020DD")]
	public void method_27()
	{
		AudioSource audioSource = this.audioSource_0;
		audioSource.Play();
	}

	// Token: 0x060020DE RID: 8414 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E700F8", Offset = "0x2E700F8", VA = "0x2E700F8")]
	[Token(Token = "0x60020DE")]
	public void method_28()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020DF RID: 8415 RVA: 0x0003D734 File Offset: 0x0003B934
	[Address(RVA = "0x2E70194", Offset = "0x2E70194", VA = "0x2E70194")]
	[Token(Token = "0x60020DF")]
	public void method_29()
	{
		string str;
		"An error has occured while buying bananas, please restart your game and try again" + str;
		if (this.bool_0)
		{
			this.method_14();
		}
	}

	// Token: 0x060020E0 RID: 8416 RVA: 0x0003D4DC File Offset: 0x0003B6DC
	[Address(RVA = "0x2E70230", Offset = "0x2E70230", VA = "0x2E70230")]
	[Token(Token = "0x60020E0")]
	public void method_30()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020E1 RID: 8417 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E702D8", Offset = "0x2E702D8", VA = "0x2E702D8")]
	[Token(Token = "0x60020E1")]
	public void method_31()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020E2 RID: 8418 RVA: 0x0003D5C8 File Offset: 0x0003B7C8
	[Address(RVA = "0x2E6EA5C", Offset = "0x2E6EA5C", VA = "0x2E6EA5C")]
	[Token(Token = "0x60020E2")]
	public void method_32()
	{
		Debug.LogWarning("Player");
	}

	// Token: 0x060020E3 RID: 8419 RVA: 0x0003D4DC File Offset: 0x0003B6DC
	[Address(RVA = "0x2E70374", Offset = "0x2E70374", VA = "0x2E70374")]
	[Token(Token = "0x60020E3")]
	public void method_33()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020E4 RID: 8420 RVA: 0x0003D75C File Offset: 0x0003B95C
	[Address(RVA = "0x2E6F7E0", Offset = "0x2E6F7E0", VA = "0x2E6F7E0")]
	[Token(Token = "0x60020E4")]
	public void method_34()
	{
		Debug.LogWarning("Left Hand");
	}

	// Token: 0x060020E5 RID: 8421 RVA: 0x0003D774 File Offset: 0x0003B974
	[Address(RVA = "0x2E7041C", Offset = "0x2E7041C", VA = "0x2E7041C")]
	[Token(Token = "0x60020E5")]
	public void method_35()
	{
		string str;
		"DISABLE" + str;
		if (this.bool_0)
		{
			this.method_15();
		}
	}

	// Token: 0x060020E6 RID: 8422 RVA: 0x0003D79C File Offset: 0x0003B99C
	[Address(RVA = "0x2E6F9E0", Offset = "0x2E6F9E0", VA = "0x2E6F9E0")]
	[Token(Token = "0x60020E6")]
	public void method_36()
	{
		Debug.LogWarning("You Look Like Butt");
	}

	// Token: 0x060020E7 RID: 8423 RVA: 0x0003D4DC File Offset: 0x0003B6DC
	[Address(RVA = "0x2E704B8", Offset = "0x2E704B8", VA = "0x2E704B8")]
	[Token(Token = "0x60020E7")]
	public void method_37()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020E8 RID: 8424 RVA: 0x0003D4DC File Offset: 0x0003B6DC
	[Address(RVA = "0x2E70560", Offset = "0x2E70560", VA = "0x2E70560")]
	[Token(Token = "0x60020E8")]
	public void method_38()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020E9 RID: 8425 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E70608", Offset = "0x2E70608", VA = "0x2E70608")]
	[Token(Token = "0x60020E9")]
	public void method_39()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020EA RID: 8426 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E706A4", Offset = "0x2E706A4", VA = "0x2E706A4")]
	[Token(Token = "0x60020EA")]
	public void method_40()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020EB RID: 8427 RVA: 0x0003D4DC File Offset: 0x0003B6DC
	[Address(RVA = "0x2E70740", Offset = "0x2E70740", VA = "0x2E70740")]
	[Token(Token = "0x60020EB")]
	public void method_41()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020EC RID: 8428 RVA: 0x0003D494 File Offset: 0x0003B694
	[Address(RVA = "0x2E707E8", Offset = "0x2E707E8", VA = "0x2E707E8")]
	[Token(Token = "0x60020EC")]
	public void method_42()
	{
		AudioClip[] array = this.audioClip_0;
		if (array.m_PCMReaderCallback == null)
		{
			throw new IndexOutOfRangeException();
		}
		this.audioSource_0.Play();
	}

	// Token: 0x060020ED RID: 8429 RVA: 0x0003D7B4 File Offset: 0x0003B9B4
	[Address(RVA = "0x2E7087C", Offset = "0x2E7087C", VA = "0x2E7087C")]
	[Token(Token = "0x60020ED")]
	public void method_43()
	{
		string str;
		"Combine textures & build combined mesh all at once" + str;
		if (this.bool_0)
		{
			this.method_25();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060020EE RID: 8430 RVA: 0x0003D7E4 File Offset: 0x0003B9E4
	[Address(RVA = "0x2E7091C", Offset = "0x2E7091C", VA = "0x2E7091C")]
	[Token(Token = "0x60020EE")]
	public void method_44()
	{
		Debug.LogWarning("Player");
		long num = 1L;
		this.byte_0 = (byte)num;
	}

	// Token: 0x060020EF RID: 8431 RVA: 0x0003D568 File Offset: 0x0003B768
	[Address(RVA = "0x2E70A80", Offset = "0x2E70A80", VA = "0x2E70A80")]
	[Token(Token = "0x60020EF")]
	public void method_45()
	{
		AudioSource audioSource = this.audioSource_0;
		long num = 1L;
		this.byte_0 = (byte)num;
		audioSource.Play();
	}

	// Token: 0x060020F0 RID: 8432 RVA: 0x0003D804 File Offset: 0x0003BA04
	[Address(RVA = "0x2E70B1C", Offset = "0x2E70B1C", VA = "0x2E70B1C")]
	[Token(Token = "0x60020F0")]
	public void method_46()
	{
		string str;
		"Skelechin" + str;
		if (this.bool_0)
		{
			this.method_44();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060020F1 RID: 8433 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2E70BBC", Offset = "0x2E70BBC", VA = "0x2E70BBC")]
	[Token(Token = "0x60020F1")]
	public MusicManager()
	{
	}

	// Token: 0x060020F2 RID: 8434 RVA: 0x0003D834 File Offset: 0x0003BA34
	[PunRPC]
	[Address(RVA = "0x2E70BC4", Offset = "0x2E70BC4", VA = "0x2E70BC4")]
	[Token(Token = "0x60020F2")]
	public void StartSong()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020F3 RID: 8435 RVA: 0x0003D85C File Offset: 0x0003BA5C
	[Address(RVA = "0x2E70C6C", Offset = "0x2E70C6C", VA = "0x2E70C6C")]
	[Token(Token = "0x60020F3")]
	public void method_47()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020F4 RID: 8436 RVA: 0x0003D47C File Offset: 0x0003B67C
	[Address(RVA = "0x2E70D14", Offset = "0x2E70D14", VA = "0x2E70D14")]
	[Token(Token = "0x60020F4")]
	public void method_48()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020F5 RID: 8437 RVA: 0x0003D884 File Offset: 0x0003BA84
	[Address(RVA = "0x2E70DB0", Offset = "0x2E70DB0", VA = "0x2E70DB0")]
	[Token(Token = "0x60020F5")]
	public void method_49()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		AudioSource audioSource = this.audioSource_0;
		audioSource.Play();
	}

	// Token: 0x060020F6 RID: 8438 RVA: 0x0003D4DC File Offset: 0x0003B6DC
	[Address(RVA = "0x2E70E58", Offset = "0x2E70E58", VA = "0x2E70E58")]
	[Token(Token = "0x60020F6")]
	public void method_50()
	{
		byte b = this.byte_0;
		this.byte_0 = b;
		this.audioSource_0.Play();
	}

	// Token: 0x060020F7 RID: 8439 RVA: 0x0003D568 File Offset: 0x0003B768
	[Address(RVA = "0x2E70F00", Offset = "0x2E70F00", VA = "0x2E70F00")]
	[Token(Token = "0x60020F7")]
	public void method_51()
	{
		AudioSource audioSource = this.audioSource_0;
		long num = 1L;
		this.byte_0 = (byte)num;
		audioSource.Play();
	}

	// Token: 0x04000454 RID: 1108
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000454")]
	public AudioSource audioSource_0;

	// Token: 0x04000455 RID: 1109
	[Token(Token = "0x4000455")]
	[FieldOffset(Offset = "0x20")]
	public AudioClip[] audioClip_0;

	// Token: 0x04000456 RID: 1110
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000456")]
	public string[] string_0;

	// Token: 0x04000457 RID: 1111
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000457")]
	private byte byte_0;

	// Token: 0x04000458 RID: 1112
	[FieldOffset(Offset = "0x31")]
	[Token(Token = "0x4000458")]
	public byte byte_1;

	// Token: 0x04000459 RID: 1113
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000459")]
	public PhotonView photonView_0;

	// Token: 0x0400045A RID: 1114
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400045A")]
	public TextMeshPro textMeshPro_0;

	// Token: 0x0400045B RID: 1115
	[Token(Token = "0x400045B")]
	[FieldOffset(Offset = "0x48")]
	public TextMeshPro textMeshPro_1;

	// Token: 0x0400045C RID: 1116
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400045C")]
	public bool bool_0;

	// Token: 0x0400045D RID: 1117
	[FieldOffset(Offset = "0x51")]
	[Token(Token = "0x400045D")]
	public bool bool_1;
}
