﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

// Token: 0x02000059 RID: 89
[Token(Token = "0x2000059")]
public class PurchaseCosmeticButton : MonoBehaviourPunCallbacks
{
	// Token: 0x06000C79 RID: 3193 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A833CC", Offset = "0x2A833CC", VA = "0x2A833CC")]
	[Token(Token = "0x6000C79")]
	private void method_0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C7A RID: 3194 RVA: 0x0001A964 File Offset: 0x00018B64
	[Token(Token = "0x6000C7A")]
	[Address(RVA = "0x2A835A8", Offset = "0x2A835A8", VA = "0x2A835A8")]
	private void method_1(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
		DynamicCosmetics.dynamicCosmetics_0.method_93(this);
	}

	// Token: 0x06000C7B RID: 3195 RVA: 0x0000208D File Offset: 0x0000028D
	[Token(Token = "0x6000C7B")]
	[Address(RVA = "0x2A83718", Offset = "0x2A83718", VA = "0x2A83718")]
	public PurchaseCosmeticButton()
	{
	}

	// Token: 0x06000C7C RID: 3196 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A83720", Offset = "0x2A83720", VA = "0x2A83720")]
	[Token(Token = "0x6000C7C")]
	private void method_2()
	{
	}

	// Token: 0x06000C7D RID: 3197 RVA: 0x0001A9A8 File Offset: 0x00018BA8
	[Address(RVA = "0x2A838B4", Offset = "0x2A838B4", VA = "0x2A838B4")]
	[Token(Token = "0x6000C7D")]
	private void method_3(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
		DynamicCosmetics.dynamicCosmetics_0.method_48(this);
	}

	// Token: 0x06000C7E RID: 3198 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A83A24", Offset = "0x2A83A24", VA = "0x2A83A24")]
	[Token(Token = "0x6000C7E")]
	private void method_4()
	{
	}

	// Token: 0x06000C7F RID: 3199 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A83BB8", Offset = "0x2A83BB8", VA = "0x2A83BB8")]
	[Token(Token = "0x6000C7F")]
	private void Start()
	{
	}

	// Token: 0x06000C80 RID: 3200 RVA: 0x0001A9DC File Offset: 0x00018BDC
	[Address(RVA = "0x2A83D4C", Offset = "0x2A83D4C", VA = "0x2A83D4C")]
	[Token(Token = "0x6000C80")]
	private void method_5(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
		DynamicCosmetics.dynamicCosmetics_0.method_110(this);
	}

	// Token: 0x06000C81 RID: 3201 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A83EBC", Offset = "0x2A83EBC", VA = "0x2A83EBC")]
	[Token(Token = "0x6000C81")]
	private void method_6()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C82 RID: 3202 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A840A4", Offset = "0x2A840A4", VA = "0x2A840A4")]
	[Token(Token = "0x6000C82")]
	private void method_7()
	{
	}

	// Token: 0x06000C83 RID: 3203 RVA: 0x0001A9A8 File Offset: 0x00018BA8
	[Address(RVA = "0x2A84238", Offset = "0x2A84238", VA = "0x2A84238")]
	[Token(Token = "0x6000C83")]
	private void method_8(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
		DynamicCosmetics.dynamicCosmetics_0.method_48(this);
	}

	// Token: 0x06000C84 RID: 3204 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A843A8", Offset = "0x2A843A8", VA = "0x2A843A8")]
	[Token(Token = "0x6000C84")]
	private void method_9()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C85 RID: 3205 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A84558", Offset = "0x2A84558", VA = "0x2A84558")]
	[Token(Token = "0x6000C85")]
	private void Update()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C86 RID: 3206 RVA: 0x0001A964 File Offset: 0x00018B64
	[Address(RVA = "0x2A84728", Offset = "0x2A84728", VA = "0x2A84728")]
	[Token(Token = "0x6000C86")]
	private void method_10(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
		DynamicCosmetics.dynamicCosmetics_0.method_93(this);
	}

	// Token: 0x06000C87 RID: 3207 RVA: 0x0001AA10 File Offset: 0x00018C10
	[Address(RVA = "0x2A84898", Offset = "0x2A84898", VA = "0x2A84898")]
	[Token(Token = "0x6000C87")]
	private void method_11(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
		DynamicCosmetics.dynamicCosmetics_0.method_110(this);
	}

	// Token: 0x06000C88 RID: 3208 RVA: 0x0001AA40 File Offset: 0x00018C40
	[Address(RVA = "0x2A84A08", Offset = "0x2A84A08", VA = "0x2A84A08")]
	[Token(Token = "0x6000C88")]
	private void method_12()
	{
		string b = this.string_0;
		"\tExpires: " == b;
	}

	// Token: 0x06000C89 RID: 3209 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A84B9C", Offset = "0x2A84B9C", VA = "0x2A84B9C")]
	[Token(Token = "0x6000C89")]
	private void method_13()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C8A RID: 3210 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A84D50", Offset = "0x2A84D50", VA = "0x2A84D50")]
	[Token(Token = "0x6000C8A")]
	private void method_14()
	{
	}

	// Token: 0x06000C8B RID: 3211 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A84EE4", Offset = "0x2A84EE4", VA = "0x2A84EE4")]
	[Token(Token = "0x6000C8B")]
	private void method_15()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C8C RID: 3212 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A850C8", Offset = "0x2A850C8", VA = "0x2A850C8")]
	[Token(Token = "0x6000C8C")]
	private void method_16()
	{
	}

	// Token: 0x06000C8D RID: 3213 RVA: 0x0001AA60 File Offset: 0x00018C60
	[Address(RVA = "0x2A8525C", Offset = "0x2A8525C", VA = "0x2A8525C")]
	[Token(Token = "0x6000C8D")]
	private void method_17(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
		DynamicCosmetics.dynamicCosmetics_0.method_131(this);
	}

	// Token: 0x06000C8E RID: 3214 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A853CC", Offset = "0x2A853CC", VA = "0x2A853CC")]
	[Token(Token = "0x6000C8E")]
	private void method_18()
	{
	}

	// Token: 0x06000C8F RID: 3215 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A85560", Offset = "0x2A85560", VA = "0x2A85560")]
	[Token(Token = "0x6000C8F")]
	private void method_19()
	{
	}

	// Token: 0x06000C90 RID: 3216 RVA: 0x0001AA94 File Offset: 0x00018C94
	[Address(RVA = "0x2A856F4", Offset = "0x2A856F4", VA = "0x2A856F4")]
	[Token(Token = "0x6000C90")]
	private void method_20(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
		DynamicCosmetics.dynamicCosmetics_0.method_34(this);
	}

	// Token: 0x06000C91 RID: 3217 RVA: 0x0001AAC8 File Offset: 0x00018CC8
	[Address(RVA = "0x2A85864", Offset = "0x2A85864", VA = "0x2A85864")]
	[Token(Token = "0x6000C91")]
	private void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
		DynamicCosmetics.dynamicCosmetics_0.method_55(this);
	}

	// Token: 0x06000C92 RID: 3218 RVA: 0x0001AAFC File Offset: 0x00018CFC
	[Address(RVA = "0x2A859C0", Offset = "0x2A859C0", VA = "0x2A859C0")]
	[Token(Token = "0x6000C92")]
	private void method_21(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06000C93 RID: 3219 RVA: 0x0001AB1C File Offset: 0x00018D1C
	[Address(RVA = "0x2A85B30", Offset = "0x2A85B30", VA = "0x2A85B30")]
	[Token(Token = "0x6000C93")]
	private void method_22(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
	}

	// Token: 0x06000C94 RID: 3220 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A85CA0", Offset = "0x2A85CA0", VA = "0x2A85CA0")]
	[Token(Token = "0x6000C94")]
	private void method_23()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C95 RID: 3221 RVA: 0x0001AB44 File Offset: 0x00018D44
	[Address(RVA = "0x2A85E88", Offset = "0x2A85E88", VA = "0x2A85E88")]
	[Token(Token = "0x6000C95")]
	private void method_24(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			return;
		}
		DynamicCosmetics.dynamicCosmetics_0.method_40(this);
	}

	// Token: 0x06000C96 RID: 3222 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A85FF8", Offset = "0x2A85FF8", VA = "0x2A85FF8")]
	[Token(Token = "0x6000C96")]
	private void method_25()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C97 RID: 3223 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A861A8", Offset = "0x2A861A8", VA = "0x2A861A8")]
	[Token(Token = "0x6000C97")]
	private void method_26()
	{
	}

	// Token: 0x06000C98 RID: 3224 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A8633C", Offset = "0x2A8633C", VA = "0x2A8633C")]
	[Token(Token = "0x6000C98")]
	private void method_27()
	{
	}

	// Token: 0x06000C99 RID: 3225 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A864D0", Offset = "0x2A864D0", VA = "0x2A864D0")]
	[Token(Token = "0x6000C99")]
	private void method_28()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000C9A RID: 3226 RVA: 0x0001A998 File Offset: 0x00018B98
	[Address(RVA = "0x2A866B8", Offset = "0x2A866B8", VA = "0x2A866B8")]
	[Token(Token = "0x6000C9A")]
	private void method_29()
	{
	}

	// Token: 0x040001C8 RID: 456
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001C8")]
	public TMP_Text tmp_Text_0;

	// Token: 0x040001C9 RID: 457
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001C9")]
	public string string_0;

	// Token: 0x040001CA RID: 458
	[FieldOffset(Offset = "0x30")]
	[HideInInspector]
	[Token(Token = "0x40001CA")]
	public bool bool_0;

	// Token: 0x040001CB RID: 459
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x40001CB")]
	public int int_0;

	// Token: 0x040001CC RID: 460
	[Token(Token = "0x40001CC")]
	[FieldOffset(Offset = "0x38")]
	private bool bool_1;
}
