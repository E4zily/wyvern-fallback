﻿using System;
using System.Collections;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000082 RID: 130
[Token(Token = "0x2000082")]
public class MB_DynamicAddDeleteExample : MonoBehaviour
{
	// Token: 0x06001283 RID: 4739 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x242A840", Offset = "0x242A840", VA = "0x242A840")]
	[Token(Token = "0x6001283")]
	private void method_0()
	{
	}

	// Token: 0x06001284 RID: 4740 RVA: 0x0002713C File Offset: 0x0002533C
	[Token(Token = "0x6001284")]
	[Address(RVA = "0x242A920", Offset = "0x242A920", VA = "0x242A920")]
	private IEnumerator method_1()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001285 RID: 4741 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001285")]
	[Address(RVA = "0x242A998", Offset = "0x242A998", VA = "0x242A998")]
	private void method_2()
	{
	}

	// Token: 0x06001286 RID: 4742 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x6001286")]
	[Address(RVA = "0x242AA78", Offset = "0x242AA78", VA = "0x242AA78")]
	private float method_3()
	{
	}

	// Token: 0x06001287 RID: 4743 RVA: 0x00027174 File Offset: 0x00025374
	[Address(RVA = "0x242AB6C", Offset = "0x242AB6C", VA = "0x242AB6C")]
	[Token(Token = "0x6001287")]
	private void method_4()
	{
		base.GetComponentInChildren<MB3_MultiMeshBaker>();
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
		long maxExclusive = 0L;
		Transform transform = gameObject2.transform;
		UnityEngine.Random.Range(1, (int)maxExclusive);
		Transform transform2 = gameObject2.transform;
		Vector3 one = Vector3.one;
		Vector3 one2 = Vector3.one;
		Transform transform3 = gameObject2.transform;
	}

	// Token: 0x06001288 RID: 4744 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x6001288")]
	[Address(RVA = "0x242B034", Offset = "0x242B034", VA = "0x242B034")]
	private float method_5()
	{
	}

	// Token: 0x06001289 RID: 4745 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001289")]
	[Address(RVA = "0x242B134", Offset = "0x242B134", VA = "0x242B134")]
	private void method_6()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600128A RID: 4746 RVA: 0x000271D4 File Offset: 0x000253D4
	[Address(RVA = "0x242B5BC", Offset = "0x242B5BC", VA = "0x242B5BC")]
	[Token(Token = "0x600128A")]
	private void method_7()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		this.method_44();
	}

	// Token: 0x0600128B RID: 4747 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600128B")]
	[Address(RVA = "0x242B810", Offset = "0x242B810", VA = "0x242B810")]
	private void method_8()
	{
	}

	// Token: 0x0600128C RID: 4748 RVA: 0x00027204 File Offset: 0x00025404
	[Token(Token = "0x600128C")]
	[Address(RVA = "0x242B8F0", Offset = "0x242B8F0", VA = "0x242B8F0")]
	private void method_9()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_57();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600128D RID: 4749 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x242BBAC", Offset = "0x242BBAC", VA = "0x242BBAC")]
	[Token(Token = "0x600128D")]
	private void method_10()
	{
	}

	// Token: 0x0600128E RID: 4750 RVA: 0x00027240 File Offset: 0x00025440
	[Token(Token = "0x600128E")]
	[Address(RVA = "0x242BC8C", Offset = "0x242BC8C", VA = "0x242BC8C")]
	private void method_11()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_55();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600128F RID: 4751 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x600128F")]
	[Address(RVA = "0x242BF48", Offset = "0x242BF48", VA = "0x242BF48")]
	private float method_12()
	{
	}

	// Token: 0x06001290 RID: 4752 RVA: 0x0002727C File Offset: 0x0002547C
	[Address(RVA = "0x242C048", Offset = "0x242C048", VA = "0x242C048")]
	[Token(Token = "0x6001290")]
	private void method_13()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_54();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001291 RID: 4753 RVA: 0x000272B8 File Offset: 0x000254B8
	[Token(Token = "0x6001291")]
	[Address(RVA = "0x242C304", Offset = "0x242C304", VA = "0x242C304")]
	private void method_14()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
	}

	// Token: 0x06001292 RID: 4754 RVA: 0x000272D4 File Offset: 0x000254D4
	[Address(RVA = "0x242C76C", Offset = "0x242C76C", VA = "0x242C76C")]
	[Token(Token = "0x6001292")]
	private void method_15()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
	}

	// Token: 0x06001293 RID: 4755 RVA: 0x0002713C File Offset: 0x0002533C
	[Token(Token = "0x6001293")]
	[Address(RVA = "0x242AFBC", Offset = "0x242AFBC", VA = "0x242AFBC")]
	private IEnumerator method_16()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001294 RID: 4756 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001294")]
	[Address(RVA = "0x242CAE0", Offset = "0x242CAE0", VA = "0x242CAE0")]
	private void method_17()
	{
	}

	// Token: 0x06001295 RID: 4757 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x6001295")]
	[Address(RVA = "0x242C18C", Offset = "0x242C18C", VA = "0x242C18C")]
	private float method_18()
	{
	}

	// Token: 0x06001296 RID: 4758 RVA: 0x0002727C File Offset: 0x0002547C
	[Token(Token = "0x6001296")]
	[Address(RVA = "0x242CBC0", Offset = "0x242CBC0", VA = "0x242CBC0")]
	private void method_19()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_54();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001297 RID: 4759 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x242CD04", Offset = "0x242CD04", VA = "0x242CD04")]
	[Token(Token = "0x6001297")]
	private void method_20()
	{
	}

	// Token: 0x06001298 RID: 4760 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x6001298")]
	[Address(RVA = "0x242CDE4", Offset = "0x242CDE4", VA = "0x242CDE4")]
	private float method_21()
	{
	}

	// Token: 0x06001299 RID: 4761 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x242CEE4", Offset = "0x242CEE4", VA = "0x242CEE4")]
	[Token(Token = "0x6001299")]
	private void method_22()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600129A RID: 4762 RVA: 0x0002713C File Offset: 0x0002533C
	[Token(Token = "0x600129A")]
	[Address(RVA = "0x242CA68", Offset = "0x242CA68", VA = "0x242CA68")]
	private IEnumerator method_23()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600129B RID: 4763 RVA: 0x000272F0 File Offset: 0x000254F0
	[Token(Token = "0x600129B")]
	[Address(RVA = "0x242D2AC", Offset = "0x242D2AC", VA = "0x242D2AC")]
	private void method_24()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
		Transform transform = gameObject2.transform;
		UnityEngine.Random.Range(0, 92);
		Transform transform2 = gameObject2.transform;
		Vector3 one = Vector3.one;
		Vector3 one2 = Vector3.one;
		Transform transform3 = gameObject2.transform;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_38();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600129C RID: 4764 RVA: 0x0002713C File Offset: 0x0002533C
	[Token(Token = "0x600129C")]
	[Address(RVA = "0x242D85C", Offset = "0x242D85C", VA = "0x242D85C")]
	private IEnumerator method_25()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600129D RID: 4765 RVA: 0x00027374 File Offset: 0x00025574
	[Token(Token = "0x600129D")]
	[Address(RVA = "0x242D8D4", Offset = "0x242D8D4", VA = "0x242D8D4")]
	private void method_26()
	{
		MB3_MultiMeshBaker mb3_MultiMeshBaker;
		this.mb3_MultiMeshBaker_0 = mb3_MultiMeshBaker;
	}

	// Token: 0x0600129E RID: 4766 RVA: 0x00027164 File Offset: 0x00025364
	[Address(RVA = "0x242DBD4", Offset = "0x242DBD4", VA = "0x242DBD4")]
	[Token(Token = "0x600129E")]
	private float method_27()
	{
	}

	// Token: 0x0600129F RID: 4767 RVA: 0x0002713C File Offset: 0x0002533C
	[Token(Token = "0x600129F")]
	[Address(RVA = "0x242DCD4", Offset = "0x242DCD4", VA = "0x242DCD4")]
	private IEnumerator method_28()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060012A0 RID: 4768 RVA: 0x00027388 File Offset: 0x00025588
	[Address(RVA = "0x242DD4C", Offset = "0x242DD4C", VA = "0x242DD4C")]
	[Token(Token = "0x60012A0")]
	private void method_29()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		IEnumerator routine = this.method_53();
		base.StartCoroutine(routine);
	}

	// Token: 0x060012A1 RID: 4769 RVA: 0x0002713C File Offset: 0x0002533C
	[Token(Token = "0x60012A1")]
	[Address(RVA = "0x242B544", Offset = "0x242B544", VA = "0x242B544")]
	private IEnumerator method_30()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060012A2 RID: 4770 RVA: 0x00027164 File Offset: 0x00025364
	[Address(RVA = "0x242B450", Offset = "0x242B450", VA = "0x242B450")]
	[Token(Token = "0x60012A2")]
	private float method_31()
	{
	}

	// Token: 0x060012A3 RID: 4771 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x60012A3")]
	[Address(RVA = "0x242DE90", Offset = "0x242DE90", VA = "0x242DE90")]
	private float method_32()
	{
	}

	// Token: 0x060012A4 RID: 4772 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x60012A4")]
	[Address(RVA = "0x242D6E4", Offset = "0x242D6E4", VA = "0x242D6E4")]
	private float method_33()
	{
	}

	// Token: 0x060012A5 RID: 4773 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x60012A5")]
	[Address(RVA = "0x242DF90", Offset = "0x242DF90", VA = "0x242DF90")]
	private float method_34()
	{
	}

	// Token: 0x060012A6 RID: 4774 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x242E080", Offset = "0x242E080", VA = "0x242E080")]
	[Token(Token = "0x60012A6")]
	private void method_35()
	{
	}

	// Token: 0x060012A7 RID: 4775 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x242E160", Offset = "0x242E160", VA = "0x242E160")]
	[Token(Token = "0x60012A7")]
	private void method_36()
	{
	}

	// Token: 0x060012A8 RID: 4776 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x60012A8")]
	[Address(RVA = "0x242AEBC", Offset = "0x242AEBC", VA = "0x242AEBC")]
	private float method_37()
	{
	}

	// Token: 0x060012A9 RID: 4777 RVA: 0x0002713C File Offset: 0x0002533C
	[Token(Token = "0x60012A9")]
	[Address(RVA = "0x242D7E4", Offset = "0x242D7E4", VA = "0x242D7E4")]
	private IEnumerator method_38()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060012AA RID: 4778 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60012AA")]
	[Address(RVA = "0x242E240", Offset = "0x242E240", VA = "0x242E240")]
	private void method_39()
	{
	}

	// Token: 0x060012AB RID: 4779 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x60012AB")]
	[Address(RVA = "0x242E320", Offset = "0x242E320", VA = "0x242E320")]
	private float method_40()
	{
	}

	// Token: 0x060012AC RID: 4780 RVA: 0x000273B4 File Offset: 0x000255B4
	[Address(RVA = "0x242E414", Offset = "0x242E414", VA = "0x242E414")]
	[Token(Token = "0x60012AC")]
	private void method_41()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_25();
		base.StartCoroutine(routine);
	}

	// Token: 0x060012AD RID: 4781 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60012AD")]
	[Address(RVA = "0x242E558", Offset = "0x242E558", VA = "0x242E558")]
	private void method_42()
	{
	}

	// Token: 0x060012AE RID: 4782 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x242E638", Offset = "0x242E638", VA = "0x242E638")]
	[Token(Token = "0x60012AE")]
	private void method_43()
	{
	}

	// Token: 0x060012AF RID: 4783 RVA: 0x000273F0 File Offset: 0x000255F0
	[Token(Token = "0x60012AF")]
	[Address(RVA = "0x242B798", Offset = "0x242B798", VA = "0x242B798")]
	private IEnumerator method_44()
	{
		new MB_DynamicAddDeleteExample.Class14((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x060012B0 RID: 4784 RVA: 0x00027164 File Offset: 0x00025364
	[Address(RVA = "0x242BDD0", Offset = "0x242BDD0", VA = "0x242BDD0")]
	[Token(Token = "0x60012B0")]
	private float method_45()
	{
	}

	// Token: 0x060012B1 RID: 4785 RVA: 0x00027414 File Offset: 0x00025614
	[Token(Token = "0x60012B1")]
	[Address(RVA = "0x242E718", Offset = "0x242E718", VA = "0x242E718")]
	private void method_46()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
	}

	// Token: 0x060012B2 RID: 4786 RVA: 0x0002713C File Offset: 0x0002533C
	[Token(Token = "0x60012B2")]
	[Address(RVA = "0x242EA08", Offset = "0x242EA08", VA = "0x242EA08")]
	private IEnumerator method_47()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060012B3 RID: 4787 RVA: 0x00027430 File Offset: 0x00025630
	[Token(Token = "0x60012B3")]
	[Address(RVA = "0x242EA80", Offset = "0x242EA80", VA = "0x242EA80")]
	public MB_DynamicAddDeleteExample()
	{
		List<GameObject> list = new List();
		this.list_0 = list;
		base..ctor();
	}

	// Token: 0x060012B4 RID: 4788 RVA: 0x00027164 File Offset: 0x00025364
	[Address(RVA = "0x242EB04", Offset = "0x242EB04", VA = "0x242EB04")]
	[Token(Token = "0x60012B4")]
	private float method_48()
	{
	}

	// Token: 0x060012B5 RID: 4789 RVA: 0x00027164 File Offset: 0x00025364
	[Address(RVA = "0x242EC04", Offset = "0x242EC04", VA = "0x242EC04")]
	[Token(Token = "0x60012B5")]
	private float method_49()
	{
	}

	// Token: 0x060012B6 RID: 4790 RVA: 0x00027450 File Offset: 0x00025650
	[Token(Token = "0x60012B6")]
	[Address(RVA = "0x242ED04", Offset = "0x242ED04", VA = "0x242ED04")]
	private void method_50()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_28();
		base.StartCoroutine(routine);
	}

	// Token: 0x060012B7 RID: 4791 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x242EF48", Offset = "0x242EF48", VA = "0x242EF48")]
	[Token(Token = "0x60012B7")]
	private void OnGUI()
	{
	}

	// Token: 0x060012B8 RID: 4792 RVA: 0x0002748C File Offset: 0x0002568C
	[Token(Token = "0x60012B8")]
	[Address(RVA = "0x242F028", Offset = "0x242F028", VA = "0x242F028")]
	private void method_51()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		IEnumerator routine = this.method_61();
		base.StartCoroutine(routine);
	}

	// Token: 0x060012B9 RID: 4793 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60012B9")]
	[Address(RVA = "0x242F16C", Offset = "0x242F16C", VA = "0x242F16C")]
	private void method_52()
	{
	}

	// Token: 0x060012BA RID: 4794 RVA: 0x0002713C File Offset: 0x0002533C
	[Token(Token = "0x60012BA")]
	[Address(RVA = "0x242D234", Offset = "0x242D234", VA = "0x242D234")]
	private IEnumerator method_53()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060012BB RID: 4795 RVA: 0x0002713C File Offset: 0x0002533C
	[Address(RVA = "0x242C28C", Offset = "0x242C28C", VA = "0x242C28C")]
	[Token(Token = "0x60012BB")]
	private IEnumerator method_54()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060012BC RID: 4796 RVA: 0x0002713C File Offset: 0x0002533C
	[Address(RVA = "0x242BED0", Offset = "0x242BED0", VA = "0x242BED0")]
	[Token(Token = "0x60012BC")]
	private IEnumerator method_55()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060012BD RID: 4797 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60012BD")]
	[Address(RVA = "0x242F24C", Offset = "0x242F24C", VA = "0x242F24C")]
	private void method_56()
	{
	}

	// Token: 0x060012BE RID: 4798 RVA: 0x0002713C File Offset: 0x0002533C
	[Address(RVA = "0x242BB34", Offset = "0x242BB34", VA = "0x242BB34")]
	[Token(Token = "0x60012BE")]
	private IEnumerator method_57()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060012BF RID: 4799 RVA: 0x000274B8 File Offset: 0x000256B8
	[Token(Token = "0x60012BF")]
	[Address(RVA = "0x242F32C", Offset = "0x242F32C", VA = "0x242F32C")]
	private void method_58()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
		Transform transform = gameObject2.transform;
		long minInclusive = 1L;
		UnityEngine.Random.Range((int)minInclusive, 143);
		Transform transform2 = gameObject2.transform;
		Vector3 one = Vector3.one;
		Vector3 one2 = Vector3.one;
		Transform transform3 = gameObject2.transform;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_30();
		base.StartCoroutine(routine);
	}

	// Token: 0x060012C0 RID: 4800 RVA: 0x00027540 File Offset: 0x00025740
	[Token(Token = "0x60012C0")]
	[Address(RVA = "0x242F79C", Offset = "0x242F79C", VA = "0x242F79C")]
	private void method_59()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_53();
		base.StartCoroutine(routine);
	}

	// Token: 0x060012C1 RID: 4801 RVA: 0x00027578 File Offset: 0x00025778
	[Address(RVA = "0x242F8E0", Offset = "0x242F8E0", VA = "0x242F8E0")]
	[Token(Token = "0x60012C1")]
	private void method_60()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_16();
		base.StartCoroutine(routine);
	}

	// Token: 0x060012C2 RID: 4802 RVA: 0x0002713C File Offset: 0x0002533C
	[Address(RVA = "0x242C6F4", Offset = "0x242C6F4", VA = "0x242C6F4")]
	[Token(Token = "0x60012C2")]
	private IEnumerator method_61()
	{
		MB_DynamicAddDeleteExample.Class14 @class = new MB_DynamicAddDeleteExample.Class14((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060012C3 RID: 4803 RVA: 0x000275B4 File Offset: 0x000257B4
	[Token(Token = "0x60012C3")]
	[Address(RVA = "0x242FA24", Offset = "0x242FA24", VA = "0x242FA24")]
	private void method_62()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		IEnumerator routine = this.method_23();
		base.StartCoroutine(routine);
	}

	// Token: 0x060012C4 RID: 4804 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x60012C4")]
	[Address(RVA = "0x242BA34", Offset = "0x242BA34", VA = "0x242BA34")]
	private float method_63()
	{
	}

	// Token: 0x060012C5 RID: 4805 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60012C5")]
	[Address(RVA = "0x242FB68", Offset = "0x242FB68", VA = "0x242FB68")]
	private void method_64()
	{
	}

	// Token: 0x060012C6 RID: 4806 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60012C6")]
	[Address(RVA = "0x242FC48", Offset = "0x242FC48", VA = "0x242FC48")]
	private void method_65()
	{
	}

	// Token: 0x060012C7 RID: 4807 RVA: 0x00027164 File Offset: 0x00025364
	[Address(RVA = "0x242EE48", Offset = "0x242EE48", VA = "0x242EE48")]
	[Token(Token = "0x60012C7")]
	private float method_66()
	{
	}

	// Token: 0x060012C8 RID: 4808 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x60012C8")]
	[Address(RVA = "0x242C5F4", Offset = "0x242C5F4", VA = "0x242C5F4")]
	private float method_67()
	{
	}

	// Token: 0x060012C9 RID: 4809 RVA: 0x00027164 File Offset: 0x00025364
	[Token(Token = "0x60012C9")]
	[Address(RVA = "0x242B700", Offset = "0x242B700", VA = "0x242B700")]
	private float method_68()
	{
	}

	// Token: 0x060012CA RID: 4810 RVA: 0x00027164 File Offset: 0x00025364
	[Address(RVA = "0x242FD28", Offset = "0x242FD28", VA = "0x242FD28")]
	[Token(Token = "0x60012CA")]
	private float method_69()
	{
	}

	// Token: 0x060012CB RID: 4811 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60012CB")]
	[Address(RVA = "0x242FE18", Offset = "0x242FE18", VA = "0x242FE18")]
	private void method_70()
	{
	}

	// Token: 0x060012CC RID: 4812 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x242FEF8", Offset = "0x242FEF8", VA = "0x242FEF8")]
	[Token(Token = "0x60012CC")]
	private void method_71()
	{
	}

	// Token: 0x060012CD RID: 4813 RVA: 0x000275E0 File Offset: 0x000257E0
	[Token(Token = "0x60012CD")]
	[Address(RVA = "0x242FFD8", Offset = "0x242FFD8", VA = "0x242FFD8")]
	private void Start()
	{
		MB3_MultiMeshBaker componentInChildren = base.GetComponentInChildren<MB3_MultiMeshBaker>();
		this.mb3_MultiMeshBaker_0 = componentInChildren;
		GameObject gameObject2;
		GameObject gameObject = gameObject2.GetComponentInChildren<MeshRenderer>().gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
		Transform transform = gameObject2.transform;
		UnityEngine.Random.Range(0, 360);
		Transform transform2 = gameObject2.transform;
		Vector3 one = Vector3.one;
		Vector3 one2 = Vector3.one;
		Transform transform3 = gameObject2.transform;
		List<GameObject> list = this.list_0;
		this.gameObject_1 = list;
		IEnumerator routine = this.method_38();
		base.StartCoroutine(routine);
	}

	// Token: 0x0400028F RID: 655
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400028F")]
	public GameObject gameObject_0;

	// Token: 0x04000290 RID: 656
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000290")]
	private List<GameObject> list_0;

	// Token: 0x04000291 RID: 657
	[Token(Token = "0x4000291")]
	[FieldOffset(Offset = "0x28")]
	private MB3_MultiMeshBaker mb3_MultiMeshBaker_0;

	// Token: 0x04000292 RID: 658
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000292")]
	private GameObject[] gameObject_1;
}
