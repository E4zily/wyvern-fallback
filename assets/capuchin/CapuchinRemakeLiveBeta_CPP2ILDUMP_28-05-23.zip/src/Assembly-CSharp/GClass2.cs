﻿using System;
using Cpp2IlInjected;

// Token: 0x0200015E RID: 350
[Token(Token = "0x200015E")]
public static class GClass2
{
	// Token: 0x060037A5 RID: 14245 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60037A5")]
	[Address(RVA = "0x217A11C", Offset = "0x217A11C", VA = "0x217A11C")]
	public static float smethod_0(float float_0, float float_1)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060037A6 RID: 14246 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x217A12C", Offset = "0x217A12C", VA = "0x217A12C")]
	[Token(Token = "0x60037A6")]
	public static float smethod_1(float float_0, float float_1)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060037A7 RID: 14247 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60037A7")]
	[Address(RVA = "0x217A144", Offset = "0x217A144", VA = "0x217A144")]
	public static float smethod_2(float float_0, float float_1, float float_2)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060037A8 RID: 14248 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60037A8")]
	[Address(RVA = "0x217A158", Offset = "0x217A158", VA = "0x217A158")]
	public static float smethod_3(float float_0, float float_1)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060037A9 RID: 14249 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60037A9")]
	[Address(RVA = "0x217A160", Offset = "0x217A160", VA = "0x217A160")]
	public static float smethod_4(float float_0, float float_1)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060037AA RID: 14250 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x217A180", Offset = "0x217A180", VA = "0x217A180")]
	[Token(Token = "0x60037AA")]
	public static float smethod_5(float float_0, float float_1)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060037AB RID: 14251 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x217A194", Offset = "0x217A194", VA = "0x217A194")]
	[Token(Token = "0x60037AB")]
	public static float smethod_6(float float_0, float float_1, float float_2)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060037AC RID: 14252 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x217A1B0", Offset = "0x217A1B0", VA = "0x217A1B0")]
	[Token(Token = "0x60037AC")]
	public static float smethod_7(float float_0, float float_1, float float_2)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060037AD RID: 14253 RVA: 0x0007034C File Offset: 0x0006E54C
	[Address(RVA = "0x217A1BC", Offset = "0x217A1BC", VA = "0x217A1BC")]
	[Token(Token = "0x60037AD")]
	public static void smethod_8(float float_0, float float_1, float float_2, float float_3, out bool bool_0, out bool bool_1)
	{
		long value = 1L;
		bool_0.m_value = (value != 0L);
	}
}
