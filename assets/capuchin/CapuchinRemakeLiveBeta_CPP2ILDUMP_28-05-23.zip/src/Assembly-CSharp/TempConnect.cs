﻿using System;
using Cpp2IlInjected;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x020000FD RID: 253
[Token(Token = "0x20000FD")]
public class TempConnect : MonoBehaviourPunCallbacks
{
	// Token: 0x0600262F RID: 9775 RVA: 0x00047724 File Offset: 0x00045924
	[Token(Token = "0x600262F")]
	[Address(RVA = "0x25C0794", Offset = "0x25C0794", VA = "0x25C0794")]
	public void method_0()
	{
		long num = 0L;
		string str;
		this.string_0 + str;
		while (num == 0L)
		{
		}
	}

	// Token: 0x06002630 RID: 9776 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C0834", Offset = "0x25C0834", VA = "0x25C0834")]
	[Token(Token = "0x6002630")]
	public void method_1()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002631 RID: 9777 RVA: 0x00047744 File Offset: 0x00045944
	[Token(Token = "0x6002631")]
	[Address(RVA = "0x25C08C8", Offset = "0x25C08C8", VA = "0x25C08C8")]
	public void method_2()
	{
		do
		{
			long minInclusive = 1L;
			UnityEngine.Random.Range((int)minInclusive, 69);
			string str;
			string text = this.string_0 + str;
			this.string_0 = text;
			long minInclusive2 = 1L;
			UnityEngine.Random.Range((int)minInclusive2, 69);
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06002632 RID: 9778 RVA: 0x0004778C File Offset: 0x0004598C
	[Token(Token = "0x6002632")]
	[Address(RVA = "0x25C0960", Offset = "0x25C0960", VA = "0x25C0960")]
	public void method_3(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002633 RID: 9779 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C0D9C", Offset = "0x25C0D9C", VA = "0x25C0D9C")]
	[Token(Token = "0x6002633")]
	public void method_4()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002634 RID: 9780 RVA: 0x000477C8 File Offset: 0x000459C8
	[Token(Token = "0x6002634")]
	[Address(RVA = "0x25C0E30", Offset = "0x25C0E30", VA = "0x25C0E30")]
	public void method_5(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 8L;
		long isVisible = 256L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002635 RID: 9781 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C1278", Offset = "0x25C1278", VA = "0x25C1278")]
	[Token(Token = "0x6002635")]
	public void method_6()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002636 RID: 9782 RVA: 0x00047814 File Offset: 0x00045A14
	[Token(Token = "0x6002636")]
	[Address(RVA = "0x25C11D8", Offset = "0x25C11D8", VA = "0x25C11D8")]
	public void method_7()
	{
		string str;
		this.string_0 + str;
	}

	// Token: 0x06002637 RID: 9783 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6002637")]
	[Address(RVA = "0x25C130C", Offset = "0x25C130C", VA = "0x25C130C")]
	public void method_8()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002638 RID: 9784 RVA: 0x00047830 File Offset: 0x00045A30
	[Token(Token = "0x6002638")]
	[Address(RVA = "0x25C13A0", Offset = "0x25C13A0", VA = "0x25C13A0")]
	public void method_9()
	{
		do
		{
			long maxExclusive = 112L;
			UnityEngine.Random.Range(0, (int)maxExclusive);
			string str;
			string text = this.string_0 + str;
			this.string_0 = text;
			long maxExclusive2 = 112L;
			UnityEngine.Random.Range(0, (int)maxExclusive2);
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06002639 RID: 9785 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6002639")]
	[Address(RVA = "0x25C1438", Offset = "0x25C1438", VA = "0x25C1438")]
	public void method_10()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600263A RID: 9786 RVA: 0x00047878 File Offset: 0x00045A78
	[Token(Token = "0x600263A")]
	[Address(RVA = "0x25C14CC", Offset = "0x25C14CC", VA = "0x25C14CC")]
	public TempConnect()
	{
		char[] array;
		this.char_0 = array;
		base..ctor();
	}

	// Token: 0x0600263B RID: 9787 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x600263B")]
	[Address(RVA = "0x25C153C", Offset = "0x25C153C", VA = "0x25C153C")]
	public void method_11()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600263C RID: 9788 RVA: 0x00047814 File Offset: 0x00045A14
	[Address(RVA = "0x25C15D0", Offset = "0x25C15D0", VA = "0x25C15D0")]
	[Token(Token = "0x600263C")]
	public void method_12()
	{
		string str;
		this.string_0 + str;
	}

	// Token: 0x0600263D RID: 9789 RVA: 0x00047894 File Offset: 0x00045A94
	[Token(Token = "0x600263D")]
	[Address(RVA = "0x25C1670", Offset = "0x25C1670", VA = "0x25C1670")]
	public void method_13(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 3L;
		long num = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (num != 0L);
		roomOptions.<PublishUserId>k__BackingField = (num != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600263E RID: 9790 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x600263E")]
	[Address(RVA = "0x25C1AB8", Offset = "0x25C1AB8", VA = "0x25C1AB8")]
	public void method_14()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600263F RID: 9791 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600263F")]
	[Address(RVA = "0x25C1B4C", Offset = "0x25C1B4C", VA = "0x25C1B4C")]
	public void method_15(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002640 RID: 9792 RVA: 0x000478E4 File Offset: 0x00045AE4
	[Token(Token = "0x6002640")]
	[Address(RVA = "0x25C1FA0", Offset = "0x25C1FA0", VA = "0x25C1FA0")]
	public void method_16(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.MaxPlayers = 5;
		roomOptions.isVisible = (257 != 0);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002641 RID: 9793 RVA: 0x00047928 File Offset: 0x00045B28
	[Address(RVA = "0x25C23F4", Offset = "0x25C23F4", VA = "0x25C23F4")]
	[Token(Token = "0x6002641")]
	public void method_17(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.MaxPlayers = 5;
		roomOptions.isVisible = (257 != 0);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002642 RID: 9794 RVA: 0x0004796C File Offset: 0x00045B6C
	[Token(Token = "0x6002642")]
	[Address(RVA = "0x25C27B0", Offset = "0x25C27B0", VA = "0x25C27B0")]
	public void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 2L;
		long isVisible = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002643 RID: 9795 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002643")]
	[Address(RVA = "0x25C2B58", Offset = "0x25C2B58", VA = "0x25C2B58")]
	public void method_19()
	{
	}

	// Token: 0x06002644 RID: 9796 RVA: 0x000479B4 File Offset: 0x00045BB4
	[Address(RVA = "0x25C2B5C", Offset = "0x25C2B5C", VA = "0x25C2B5C")]
	[Token(Token = "0x6002644")]
	public void method_20(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 8L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
		string[] array = new string[6];
		if (array == null)
		{
			return;
		}
		if (array != null)
		{
			return;
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06002645 RID: 9797 RVA: 0x00047A08 File Offset: 0x00045C08
	[Address(RVA = "0x25C2F8C", Offset = "0x25C2F8C", VA = "0x25C2F8C")]
	[Token(Token = "0x6002645")]
	public void method_21(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 7L;
		long num = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (num != 0L);
		roomOptions.<PublishUserId>k__BackingField = (num != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002646 RID: 9798 RVA: 0x00047A58 File Offset: 0x00045C58
	[Address(RVA = "0x25C3334", Offset = "0x25C3334", VA = "0x25C3334")]
	[Token(Token = "0x6002646")]
	public void method_22(Collider collider_0)
	{
		HandColliders handColliders;
		handColliders;
		new RoomOptions();
		long cachedPtr = 1L;
		handColliders.m_CachedPtr = (IntPtr)cachedPtr;
		new Hashtable();
		new Hashtable();
	}

	// Token: 0x06002647 RID: 9799 RVA: 0x00047A8C File Offset: 0x00045C8C
	[Address(RVA = "0x25C36D8", Offset = "0x25C36D8", VA = "0x25C36D8")]
	[Token(Token = "0x6002647")]
	public void method_23()
	{
		do
		{
			long minInclusive = 1L;
			UnityEngine.Random.Range((int)minInclusive, 69);
			string str;
			string text = this.string_0 + str;
			this.string_0 = text;
			long minInclusive2 = 1L;
			UnityEngine.Random.Range((int)minInclusive2, 69);
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06002648 RID: 9800 RVA: 0x00047AD8 File Offset: 0x00045CD8
	[Address(RVA = "0x25C3770", Offset = "0x25C3770", VA = "0x25C3770")]
	[Token(Token = "0x6002648")]
	public void method_24()
	{
		do
		{
			long minInclusive = 1L;
			long maxExclusive = 3L;
			UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
			string str;
			this.string_0 + str;
			long minInclusive2 = 1L;
			long maxExclusive2 = 3L;
			UnityEngine.Random.Range((int)minInclusive2, (int)maxExclusive2);
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06002649 RID: 9801 RVA: 0x00047B1C File Offset: 0x00045D1C
	[Address(RVA = "0x25C3808", Offset = "0x25C3808", VA = "0x25C3808")]
	[Token(Token = "0x6002649")]
	public void method_25()
	{
		long minInclusive = 1L;
		UnityEngine.Random.Range((int)minInclusive, 26);
		string str;
		this.string_0 + str;
	}

	// Token: 0x0600264A RID: 9802 RVA: 0x00047B44 File Offset: 0x00045D44
	[Address(RVA = "0x25C38A8", Offset = "0x25C38A8", VA = "0x25C38A8")]
	[Token(Token = "0x600264A")]
	public void method_26()
	{
		long minInclusive = 1L;
		long maxExclusive = -97L;
		UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		string str;
		this.string_0 + str;
	}

	// Token: 0x0600264B RID: 9803 RVA: 0x00047B6C File Offset: 0x00045D6C
	[Address(RVA = "0x25C3948", Offset = "0x25C3948", VA = "0x25C3948")]
	[Token(Token = "0x600264B")]
	public void method_27(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long isVisible = 256L;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600264C RID: 9804 RVA: 0x00047BAC File Offset: 0x00045DAC
	[Token(Token = "0x600264C")]
	[Address(RVA = "0x25C3CF4", Offset = "0x25C3CF4", VA = "0x25C3CF4")]
	public void method_28(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.MaxPlayers = 5;
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600264D RID: 9805 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C40A4", Offset = "0x25C40A4", VA = "0x25C40A4")]
	[Token(Token = "0x600264D")]
	public void method_29()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600264E RID: 9806 RVA: 0x00047BE8 File Offset: 0x00045DE8
	[Address(RVA = "0x25C1A20", Offset = "0x25C1A20", VA = "0x25C1A20")]
	[Token(Token = "0x600264E")]
	public void method_30()
	{
		do
		{
			long minInclusive = 1L;
			UnityEngine.Random.Range((int)minInclusive, 66);
			string str;
			string text = this.string_0 + str;
			this.string_0 = text;
			long minInclusive2 = 1L;
			UnityEngine.Random.Range((int)minInclusive2, 66);
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600264F RID: 9807 RVA: 0x00047C34 File Offset: 0x00045E34
	[Address(RVA = "0x25C4138", Offset = "0x25C4138", VA = "0x25C4138")]
	[Token(Token = "0x600264F")]
	public void method_31(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.isVisible = (257 != 0);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002650 RID: 9808 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6002650")]
	[Address(RVA = "0x25C44EC", Offset = "0x25C44EC", VA = "0x25C44EC")]
	public void method_32()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002651 RID: 9809 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C4580", Offset = "0x25C4580", VA = "0x25C4580")]
	[Token(Token = "0x6002651")]
	public void method_33()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002652 RID: 9810 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x25C4614", Offset = "0x25C4614", VA = "0x25C4614")]
	[Token(Token = "0x6002652")]
	public void method_34()
	{
	}

	// Token: 0x06002653 RID: 9811 RVA: 0x0004796C File Offset: 0x00045B6C
	[Address(RVA = "0x25C4618", Offset = "0x25C4618", VA = "0x25C4618")]
	[Token(Token = "0x6002653")]
	public void method_35(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 2L;
		long isVisible = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002654 RID: 9812 RVA: 0x00047C6C File Offset: 0x00045E6C
	[Address(RVA = "0x25C49C8", Offset = "0x25C49C8", VA = "0x25C49C8")]
	[Token(Token = "0x6002654")]
	public void method_36()
	{
		do
		{
			string str;
			string text = this.string_0 + str;
			this.string_0 = text;
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06002655 RID: 9813 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x25C36D4", Offset = "0x25C36D4", VA = "0x25C36D4")]
	[Token(Token = "0x6002655")]
	public void method_37()
	{
	}

	// Token: 0x06002656 RID: 9814 RVA: 0x00047C9C File Offset: 0x00045E9C
	[Token(Token = "0x6002656")]
	[Address(RVA = "0x25C4A60", Offset = "0x25C4A60", VA = "0x25C4A60")]
	public void method_38(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 6L;
		long isVisible = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002657 RID: 9815 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6002657")]
	[Address(RVA = "0x25C4E04", Offset = "0x25C4E04", VA = "0x25C4E04")]
	public void method_39()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002658 RID: 9816 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C4E98", Offset = "0x25C4E98", VA = "0x25C4E98")]
	[Token(Token = "0x6002658")]
	public void method_40()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002659 RID: 9817 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6002659")]
	[Address(RVA = "0x25C4F2C", Offset = "0x25C4F2C", VA = "0x25C4F2C")]
	public void method_41()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600265A RID: 9818 RVA: 0x00047CE4 File Offset: 0x00045EE4
	[Address(RVA = "0x25C4FC0", Offset = "0x25C4FC0", VA = "0x25C4FC0")]
	[Token(Token = "0x600265A")]
	public void Update()
	{
	}

	// Token: 0x0600265B RID: 9819 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C5054", Offset = "0x25C5054", VA = "0x25C5054")]
	[Token(Token = "0x600265B")]
	public void method_42()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600265C RID: 9820 RVA: 0x00047CF4 File Offset: 0x00045EF4
	[Token(Token = "0x600265C")]
	[Address(RVA = "0x25C50E8", Offset = "0x25C50E8", VA = "0x25C50E8")]
	public void method_43(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long isVisible = 256L;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.MaxPlayers = 5;
		roomOptions.isVisible = (isVisible != 0L);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600265D RID: 9821 RVA: 0x00047D48 File Offset: 0x00045F48
	[Token(Token = "0x600265D")]
	[Address(RVA = "0x25C5494", Offset = "0x25C5494", VA = "0x25C5494")]
	public void method_44(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 2L;
		long isVisible = 256L;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600265E RID: 9822 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x600265E")]
	[Address(RVA = "0x25C58F0", Offset = "0x25C58F0", VA = "0x25C58F0")]
	public void method_45()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600265F RID: 9823 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C5984", Offset = "0x25C5984", VA = "0x25C5984")]
	[Token(Token = "0x600265F")]
	public void method_46()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002660 RID: 9824 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x25C4E00", Offset = "0x25C4E00", VA = "0x25C4E00")]
	[Token(Token = "0x6002660")]
	public void method_47()
	{
	}

	// Token: 0x06002661 RID: 9825 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C5A18", Offset = "0x25C5A18", VA = "0x25C5A18")]
	[Token(Token = "0x6002661")]
	public void method_48()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002662 RID: 9826 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C5AAC", Offset = "0x25C5AAC", VA = "0x25C5AAC")]
	[Token(Token = "0x6002662")]
	public void method_49()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002663 RID: 9827 RVA: 0x00047DA0 File Offset: 0x00045FA0
	[Address(RVA = "0x25C5B40", Offset = "0x25C5B40", VA = "0x25C5B40")]
	[Token(Token = "0x6002663")]
	public void method_50(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.isVisible = (257 != 0);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002664 RID: 9828 RVA: 0x00047DE0 File Offset: 0x00045FE0
	[Token(Token = "0x6002664")]
	[Address(RVA = "0x25C5EE8", Offset = "0x25C5EE8", VA = "0x25C5EE8")]
	public void method_51()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002665 RID: 9829 RVA: 0x00047DF4 File Offset: 0x00045FF4
	[Token(Token = "0x6002665")]
	[Address(RVA = "0x25C5F7C", Offset = "0x25C5F7C", VA = "0x25C5F7C")]
	public void method_52(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.isVisible = (257 != 0);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002666 RID: 9830 RVA: 0x00047E34 File Offset: 0x00046034
	[Address(RVA = "0x25C63BC", Offset = "0x25C63BC", VA = "0x25C63BC")]
	[Token(Token = "0x6002666")]
	public void method_53(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 3L;
		long num = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (num != 0L);
		roomOptions.<PublishUserId>k__BackingField = (num != 0L);
		new Hashtable();
		new Hashtable();
	}

	// Token: 0x06002667 RID: 9831 RVA: 0x00047E78 File Offset: 0x00046078
	[Address(RVA = "0x25C6764", Offset = "0x25C6764", VA = "0x25C6764")]
	[Token(Token = "0x6002667")]
	public void method_54(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002668 RID: 9832 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C6B08", Offset = "0x25C6B08", VA = "0x25C6B08")]
	[Token(Token = "0x6002668")]
	public void method_55()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002669 RID: 9833 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C6B9C", Offset = "0x25C6B9C", VA = "0x25C6B9C")]
	[Token(Token = "0x6002669")]
	public void method_56()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600266A RID: 9834 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C6C30", Offset = "0x25C6C30", VA = "0x25C6C30")]
	[Token(Token = "0x600266A")]
	public void method_57()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600266B RID: 9835 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C6CC4", Offset = "0x25C6CC4", VA = "0x25C6CC4")]
	[Token(Token = "0x600266B")]
	public void method_58()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600266C RID: 9836 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C6D58", Offset = "0x25C6D58", VA = "0x25C6D58")]
	[Token(Token = "0x600266C")]
	public void method_59()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600266D RID: 9837 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600266D")]
	[Address(RVA = "0x25C6DEC", Offset = "0x25C6DEC", VA = "0x25C6DEC")]
	public void method_60(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600266E RID: 9838 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C7194", Offset = "0x25C7194", VA = "0x25C7194")]
	[Token(Token = "0x600266E")]
	public void method_61()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600266F RID: 9839 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C7228", Offset = "0x25C7228", VA = "0x25C7228")]
	[Token(Token = "0x600266F")]
	public void method_62()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002670 RID: 9840 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6002670")]
	[Address(RVA = "0x25C72BC", Offset = "0x25C72BC", VA = "0x25C72BC")]
	public void method_63()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002671 RID: 9841 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x25C7350", Offset = "0x25C7350", VA = "0x25C7350")]
	[Token(Token = "0x6002671")]
	public void method_64(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002672 RID: 9842 RVA: 0x00047EB0 File Offset: 0x000460B0
	[Address(RVA = "0x25C76FC", Offset = "0x25C76FC", VA = "0x25C76FC")]
	[Token(Token = "0x6002672")]
	public void method_65()
	{
		string str;
		this.string_0 + str;
	}

	// Token: 0x06002673 RID: 9843 RVA: 0x00047ECC File Offset: 0x000460CC
	[Token(Token = "0x6002673")]
	[Address(RVA = "0x25C779C", Offset = "0x25C779C", VA = "0x25C779C")]
	public void method_66(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 6L;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (257 != 0);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002674 RID: 9844 RVA: 0x00047F20 File Offset: 0x00046120
	[Address(RVA = "0x25C7B48", Offset = "0x25C7B48", VA = "0x25C7B48")]
	[Token(Token = "0x6002674")]
	public void method_67(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.MaxPlayers = 5;
		roomOptions.isVisible = (257 != 0);
		roomOptions.CustomRoomProperties = roomOptions;
	}

	// Token: 0x06002675 RID: 9845 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6002675")]
	[Address(RVA = "0x25C7EF0", Offset = "0x25C7EF0", VA = "0x25C7EF0")]
	public void method_68()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002676 RID: 9846 RVA: 0x00047F58 File Offset: 0x00046158
	[Token(Token = "0x6002676")]
	[Address(RVA = "0x25C2354", Offset = "0x25C2354", VA = "0x25C2354")]
	public void method_69()
	{
		UnityEngine.Random.Range(0, 88);
		string str;
		this.string_0 + str;
	}

	// Token: 0x06002677 RID: 9847 RVA: 0x00047F7C File Offset: 0x0004617C
	[Address(RVA = "0x25C7F84", Offset = "0x25C7F84", VA = "0x25C7F84")]
	[Token(Token = "0x6002677")]
	public void method_70(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 7L;
		long isVisible = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002678 RID: 9848 RVA: 0x00047FC4 File Offset: 0x000461C4
	[Address(RVA = "0x25C83C4", Offset = "0x25C83C4", VA = "0x25C83C4")]
	[Token(Token = "0x6002678")]
	public void method_71(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.MaxPlayers = 5;
		roomOptions.isVisible = (257 != 0);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002679 RID: 9849 RVA: 0x00048008 File Offset: 0x00046208
	[Token(Token = "0x6002679")]
	[Address(RVA = "0x25C876C", Offset = "0x25C876C", VA = "0x25C876C")]
	public void method_72(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 6L;
		long isVisible = 256L;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600267A RID: 9850 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C8B20", Offset = "0x25C8B20", VA = "0x25C8B20")]
	[Token(Token = "0x600267A")]
	public void method_73()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600267B RID: 9851 RVA: 0x00048060 File Offset: 0x00046260
	[Address(RVA = "0x25C8BB4", Offset = "0x25C8BB4", VA = "0x25C8BB4")]
	[Token(Token = "0x600267B")]
	public void method_74(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long num = 1L;
		roomOptions.MaxPlayers = (byte)num;
		roomOptions.isVisible = (257 != 0);
		roomOptions.<PublishUserId>k__BackingField = (num != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600267C RID: 9852 RVA: 0x000480B0 File Offset: 0x000462B0
	[Token(Token = "0x600267C")]
	[Address(RVA = "0x25C8F6C", Offset = "0x25C8F6C", VA = "0x25C8F6C")]
	public void method_75(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 4L;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (257 != 0);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600267D RID: 9853 RVA: 0x00048104 File Offset: 0x00046304
	[Address(RVA = "0x25C9318", Offset = "0x25C9318", VA = "0x25C9318")]
	[Token(Token = "0x600267D")]
	public void method_76()
	{
		long minInclusive = 1L;
		UnityEngine.Random.Range((int)minInclusive, 11);
		string str;
		this.string_0 + str;
	}

	// Token: 0x0600267E RID: 9854 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C93B8", Offset = "0x25C93B8", VA = "0x25C93B8")]
	[Token(Token = "0x600267E")]
	public void method_77()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600267F RID: 9855 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C944C", Offset = "0x25C944C", VA = "0x25C944C")]
	[Token(Token = "0x600267F")]
	public void method_78()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002680 RID: 9856 RVA: 0x0004812C File Offset: 0x0004632C
	[Address(RVA = "0x25C94E0", Offset = "0x25C94E0", VA = "0x25C94E0")]
	[Token(Token = "0x6002680")]
	public void method_79()
	{
		long minInclusive = 1L;
		UnityEngine.Random.Range((int)minInclusive, 75);
		string str;
		this.string_0 + str;
	}

	// Token: 0x06002681 RID: 9857 RVA: 0x00048154 File Offset: 0x00046354
	[Address(RVA = "0x25C9580", Offset = "0x25C9580", VA = "0x25C9580")]
	[Token(Token = "0x6002681")]
	public void method_80(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 8L;
		long isVisible = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002682 RID: 9858 RVA: 0x0004819C File Offset: 0x0004639C
	[Token(Token = "0x6002682")]
	[Address(RVA = "0x25C2F0C", Offset = "0x25C2F0C", VA = "0x25C2F0C")]
	public void method_81()
	{
		string str;
		this.string_0 + str;
	}

	// Token: 0x06002683 RID: 9859 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C9914", Offset = "0x25C9914", VA = "0x25C9914")]
	[Token(Token = "0x6002683")]
	public void method_82()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002684 RID: 9860 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C99A8", Offset = "0x25C99A8", VA = "0x25C99A8")]
	[Token(Token = "0x6002684")]
	public void method_83()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002685 RID: 9861 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6002685")]
	[Address(RVA = "0x25C9A3C", Offset = "0x25C9A3C", VA = "0x25C9A3C")]
	public void method_84()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002686 RID: 9862 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25C9AD0", Offset = "0x25C9AD0", VA = "0x25C9AD0")]
	[Token(Token = "0x6002686")]
	public void method_85()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002687 RID: 9863 RVA: 0x000481B8 File Offset: 0x000463B8
	[Token(Token = "0x6002687")]
	[Address(RVA = "0x25C9B64", Offset = "0x25C9B64", VA = "0x25C9B64")]
	public void method_86(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002688 RID: 9864 RVA: 0x00047DE0 File Offset: 0x00045FE0
	[Address(RVA = "0x25C9F18", Offset = "0x25C9F18", VA = "0x25C9F18")]
	[Token(Token = "0x6002688")]
	public void method_87()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002689 RID: 9865 RVA: 0x000481F4 File Offset: 0x000463F4
	[Token(Token = "0x6002689")]
	[Address(RVA = "0x25C9FAC", Offset = "0x25C9FAC", VA = "0x25C9FAC")]
	public void method_88(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long isVisible = 256L;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.isVisible = (isVisible != 0L);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600268A RID: 9866 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25CA364", Offset = "0x25CA364", VA = "0x25CA364")]
	[Token(Token = "0x600268A")]
	public void method_89()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600268B RID: 9867 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25CA3F8", Offset = "0x25CA3F8", VA = "0x25CA3F8")]
	[Token(Token = "0x600268B")]
	public void method_90()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600268C RID: 9868 RVA: 0x00048240 File Offset: 0x00046440
	[Address(RVA = "0x25C6324", Offset = "0x25C6324", VA = "0x25C6324")]
	[Token(Token = "0x600268C")]
	public void method_91()
	{
		do
		{
			UnityEngine.Random.Range(0, 52);
			string str;
			string text = this.string_0 + str;
			this.string_0 = text;
			UnityEngine.Random.Range(0, 52);
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600268D RID: 9869 RVA: 0x00048284 File Offset: 0x00046484
	[Token(Token = "0x600268D")]
	[Address(RVA = "0x25CA48C", Offset = "0x25CA48C", VA = "0x25CA48C")]
	public void method_92(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 3L;
		long num = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (num != 0L);
		roomOptions.<PublishUserId>k__BackingField = (num != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600268E RID: 9870 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25CA83C", Offset = "0x25CA83C", VA = "0x25CA83C")]
	[Token(Token = "0x600268E")]
	public void method_93()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600268F RID: 9871 RVA: 0x00047C6C File Offset: 0x00045E6C
	[Token(Token = "0x600268F")]
	[Address(RVA = "0x25C832C", Offset = "0x25C832C", VA = "0x25C832C")]
	public void method_94()
	{
		do
		{
			string str;
			string text = this.string_0 + str;
			this.string_0 = text;
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06002690 RID: 9872 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25CA8D0", Offset = "0x25CA8D0", VA = "0x25CA8D0")]
	[Token(Token = "0x6002690")]
	public void method_95()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002691 RID: 9873 RVA: 0x000482D4 File Offset: 0x000464D4
	[Token(Token = "0x6002691")]
	[Address(RVA = "0x25CA964", Offset = "0x25CA964", VA = "0x25CA964")]
	public void method_96(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 1L;
		long isVisible = 256L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (isVisible != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002692 RID: 9874 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6002692")]
	[Address(RVA = "0x25CAD14", Offset = "0x25CAD14", VA = "0x25CAD14")]
	public void method_97()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002693 RID: 9875 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25CADA8", Offset = "0x25CADA8", VA = "0x25CADA8")]
	[Token(Token = "0x6002693")]
	public void method_98()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002694 RID: 9876 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6002694")]
	[Address(RVA = "0x25CAE3C", Offset = "0x25CAE3C", VA = "0x25CAE3C")]
	public void method_99()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06002695 RID: 9877 RVA: 0x00048320 File Offset: 0x00046520
	[Address(RVA = "0x25C5850", Offset = "0x25C5850", VA = "0x25C5850")]
	[Token(Token = "0x6002695")]
	public void method_100()
	{
	}

	// Token: 0x06002696 RID: 9878 RVA: 0x00048330 File Offset: 0x00046530
	[Token(Token = "0x6002696")]
	[Address(RVA = "0x25CAED0", Offset = "0x25CAED0", VA = "0x25CAED0")]
	public void method_101(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long isVisible = 256L;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.isVisible = (isVisible != 0L);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x06002697 RID: 9879 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x25C3CF0", Offset = "0x25C3CF0", VA = "0x25C3CF0")]
	[Token(Token = "0x6002697")]
	public void method_102()
	{
	}

	// Token: 0x06002698 RID: 9880 RVA: 0x0004837C File Offset: 0x0004657C
	[Address(RVA = "0x25CB278", Offset = "0x25CB278", VA = "0x25CB278")]
	[Token(Token = "0x6002698")]
	public void method_103()
	{
		long minInclusive = 0L;
		long maxExclusive = 0L;
		UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive);
		string str;
		this.string_0 + str;
	}

	// Token: 0x06002699 RID: 9881 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25CB318", Offset = "0x25CB318", VA = "0x25CB318")]
	[Token(Token = "0x6002699")]
	public void method_104()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600269A RID: 9882 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25CB3AC", Offset = "0x25CB3AC", VA = "0x25CB3AC")]
	[Token(Token = "0x600269A")]
	public void method_105()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600269B RID: 9883 RVA: 0x00047C6C File Offset: 0x00045E6C
	[Address(RVA = "0x25CB440", Offset = "0x25CB440", VA = "0x25CB440")]
	[Token(Token = "0x600269B")]
	public void method_106()
	{
		do
		{
			string str;
			string text = this.string_0 + str;
			this.string_0 = text;
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600269C RID: 9884 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x600269C")]
	[Address(RVA = "0x25CB4D8", Offset = "0x25CB4D8", VA = "0x25CB4D8")]
	public void method_107()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600269D RID: 9885 RVA: 0x000483A4 File Offset: 0x000465A4
	[Token(Token = "0x600269D")]
	[Address(RVA = "0x25C1F00", Offset = "0x25C1F00", VA = "0x25C1F00")]
	public void method_108()
	{
		long minInclusive = 1L;
		UnityEngine.Random.Range((int)minInclusive, 116);
		string str;
		this.string_0 + str;
	}

	// Token: 0x0600269E RID: 9886 RVA: 0x000483CC File Offset: 0x000465CC
	[Token(Token = "0x600269E")]
	[Address(RVA = "0x25CB56C", Offset = "0x25CB56C", VA = "0x25CB56C")]
	public void method_109(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long num = 1L;
		roomOptions.MaxPlayers = 5;
		roomOptions.isVisible = (num != 0L);
		roomOptions.<PublishUserId>k__BackingField = (num != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600269F RID: 9887 RVA: 0x00048418 File Offset: 0x00046618
	[Token(Token = "0x600269F")]
	[Address(RVA = "0x25CB914", Offset = "0x25CB914", VA = "0x25CB914")]
	public void method_110()
	{
		long minInclusive = 1L;
		UnityEngine.Random.Range((int)minInclusive, 104);
		string str;
		this.string_0 + str;
	}

	// Token: 0x060026A0 RID: 9888 RVA: 0x00048440 File Offset: 0x00046640
	[Token(Token = "0x60026A0")]
	[Address(RVA = "0x25CB9B4", Offset = "0x25CB9B4", VA = "0x25CB9B4")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		RoomOptions roomOptions = new RoomOptions();
		long maxPlayers = 8L;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.MaxPlayers = (byte)maxPlayers;
		roomOptions.isVisible = (257 != 0);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x060026A1 RID: 9889 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x60026A1")]
	[Address(RVA = "0x25CBD40", Offset = "0x25CBD40", VA = "0x25CBD40")]
	public void method_111()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x060026A2 RID: 9890 RVA: 0x00048494 File Offset: 0x00046694
	[Address(RVA = "0x25CBDD4", Offset = "0x25CBDD4", VA = "0x25CBDD4")]
	[Token(Token = "0x60026A2")]
	public void method_112()
	{
		do
		{
			UnityEngine.Random.Range(0, 104);
			string str;
			string text = this.string_0 + str;
			this.string_0 = text;
			UnityEngine.Random.Range(0, 104);
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060026A3 RID: 9891 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25CBE6C", Offset = "0x25CBE6C", VA = "0x25CBE6C")]
	[Token(Token = "0x60026A3")]
	public void method_113()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x060026A4 RID: 9892 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25CBF00", Offset = "0x25CBF00", VA = "0x25CBF00")]
	[Token(Token = "0x60026A4")]
	public void method_114()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x060026A5 RID: 9893 RVA: 0x000484D8 File Offset: 0x000466D8
	[Token(Token = "0x60026A5")]
	[Address(RVA = "0x25C0D04", Offset = "0x25C0D04", VA = "0x25C0D04")]
	public void method_115()
	{
		do
		{
			string str;
			string text = this.string_0 + str;
			this.string_0 = text;
		}
		while (this.char_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060026A6 RID: 9894 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Address(RVA = "0x25CBF94", Offset = "0x25CBF94", VA = "0x25CBF94")]
	[Token(Token = "0x60026A6")]
	public void method_116()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x040004E8 RID: 1256
	[Token(Token = "0x40004E8")]
	[FieldOffset(Offset = "0x20")]
	private char[] char_0;

	// Token: 0x040004E9 RID: 1257
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40004E9")]
	private string string_0;

	// Token: 0x040004EA RID: 1258
	[Token(Token = "0x40004EA")]
	[FieldOffset(Offset = "0x30")]
	public byte byte_0;
}
