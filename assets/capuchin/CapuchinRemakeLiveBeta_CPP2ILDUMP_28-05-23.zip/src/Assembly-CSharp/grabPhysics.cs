﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000099 RID: 153
[Token(Token = "0x2000099")]
public class grabPhysics : MonoBehaviour
{
	// Token: 0x06001691 RID: 5777 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B35B0", Offset = "0x34B35B0", VA = "0x34B35B0")]
	[Token(Token = "0x6001691")]
	private void method_0()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x06001692 RID: 5778 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34B35EC", Offset = "0x34B35EC", VA = "0x34B35EC")]
	[Token(Token = "0x6001692")]
	public void method_1()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001693 RID: 5779 RVA: 0x0002AF00 File Offset: 0x00029100
	[Token(Token = "0x6001693")]
	[Address(RVA = "0x34B36F4", Offset = "0x34B36F4", VA = "0x34B36F4")]
	private void method_2()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x06001694 RID: 5780 RVA: 0x0002AF1C File Offset: 0x0002911C
	[Token(Token = "0x6001694")]
	[Address(RVA = "0x34B3730", Offset = "0x34B3730", VA = "0x34B3730")]
	private void method_3()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						long num = 0L;
						return;
					}
					throw new IndexOutOfRangeException();
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			long num;
			if (num != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x06001695 RID: 5781 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34B3AF4", Offset = "0x34B3AF4", VA = "0x34B3AF4")]
	[Token(Token = "0x6001695")]
	public void method_4()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001696 RID: 5782 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34B3BF0", Offset = "0x34B3BF0", VA = "0x34B3BF0")]
	[Token(Token = "0x6001696")]
	public void method_5()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001697 RID: 5783 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B3CF8", Offset = "0x34B3CF8", VA = "0x34B3CF8")]
	[Token(Token = "0x6001697")]
	private void method_6()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x06001698 RID: 5784 RVA: 0x0002B02C File Offset: 0x0002922C
	[Token(Token = "0x6001698")]
	[Address(RVA = "0x34B3D34", Offset = "0x34B3D34", VA = "0x34B3D34")]
	private void method_7()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long num = 1L;
					this.bool_3 = (num != 0L);
				}
			}
		}
		else if (flag4)
		{
			long num2 = 1L;
			this.bool_3 = (num2 != 0L);
			FixedJoint exists = this.fixedJoint_0;
			if (num2 != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num2 != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			return;
		}
	}

	// Token: 0x06001699 RID: 5785 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B4100", Offset = "0x34B4100", VA = "0x34B4100")]
	[Token(Token = "0x6001699")]
	private void method_8()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x0600169A RID: 5786 RVA: 0x0002B138 File Offset: 0x00029338
	[Token(Token = "0x600169A")]
	[Address(RVA = "0x34B413C", Offset = "0x34B413C", VA = "0x34B413C")]
	private void method_9()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		if (!this.bool_3)
		{
			Vector3 position = base.transform.position;
			LayerMask mask = this.layerMask_0;
			mask;
			Collider[] array;
			Rigidbody attachedRigidbody = array.attachedRigidbody;
			FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
			this.fixedJoint_0 = fixedJoint;
			attachedRigidbody;
			Transform transform = attachedRigidbody.transform;
			Vector3 position2 = base.transform.position;
			Transform transform2 = this.transform_0;
			Transform transform3 = attachedRigidbody.transform;
			transform2.SetParent(transform3);
			return;
		}
	}

	// Token: 0x0600169B RID: 5787 RVA: 0x0002B1DC File Offset: 0x000293DC
	[Token(Token = "0x600169B")]
	[Address(RVA = "0x34B450C", Offset = "0x34B450C", VA = "0x34B450C")]
	private void method_10()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
			}
		}
		else if (flag4)
		{
			long num = 1L;
			this.bool_3 = (num != 0L);
			if (num != 0L)
			{
			}
			Rigidbody attachedRigidbody;
			attachedRigidbody;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x0600169C RID: 5788 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34B48D0", Offset = "0x34B48D0", VA = "0x34B48D0")]
	[Token(Token = "0x600169C")]
	public void method_11()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600169D RID: 5789 RVA: 0x0002B2EC File Offset: 0x000294EC
	[Token(Token = "0x600169D")]
	[Address(RVA = "0x34B49CC", Offset = "0x34B49CC", VA = "0x34B49CC")]
	private void method_12()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long num = 1L;
					this.bool_3 = (num != 0L);
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			exists;
			FixedJoint obj = this.fixedJoint_0;
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x0600169E RID: 5790 RVA: 0x0002B3FC File Offset: 0x000295FC
	[Address(RVA = "0x34B4D8C", Offset = "0x34B4D8C", VA = "0x34B4D8C")]
	[Token(Token = "0x600169E")]
	private void method_13()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
			}
		}
		else if (flag4)
		{
			long num = 1L;
			this.bool_3 = (num != 0L);
			FixedJoint exists = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x0600169F RID: 5791 RVA: 0x0002B514 File Offset: 0x00029714
	[Address(RVA = "0x34B5158", Offset = "0x34B5158", VA = "0x34B5158")]
	[Token(Token = "0x600169F")]
	private void method_14()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = this.transform_0;
					Transform transform3 = attachedRigidbody.transform;
					transform2.SetParent(transform3);
					return;
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			exists;
			FixedJoint obj = this.fixedJoint_0;
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016A0 RID: 5792 RVA: 0x0002B60C File Offset: 0x0002980C
	[Token(Token = "0x60016A0")]
	[Address(RVA = "0x34B5520", Offset = "0x34B5520", VA = "0x34B5520")]
	private void method_15()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = this.transform_0;
					Transform transform3 = attachedRigidbody.transform;
					transform2.SetParent(transform3);
					return;
				}
			}
		}
		else if (flag4)
		{
			long num = 1L;
			this.bool_3 = (num != 0L);
			FixedJoint exists = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016A1 RID: 5793 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B58F0", Offset = "0x34B58F0", VA = "0x34B58F0")]
	[Token(Token = "0x60016A1")]
	private void method_16()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016A2 RID: 5794 RVA: 0x0002B718 File Offset: 0x00029918
	[Address(RVA = "0x34B592C", Offset = "0x34B592C", VA = "0x34B592C")]
	[Token(Token = "0x60016A2")]
	private void method_17()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = this.transform_0;
					Transform transform3 = attachedRigidbody.transform;
					transform2.SetParent(transform3);
					return;
				}
				long num = 1L;
				this.bool_3 = (num != 0L);
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			exists;
			FixedJoint obj = this.fixedJoint_0;
			UnityEngine.Object.Destroy(obj);
			return;
		}
	}

	// Token: 0x060016A3 RID: 5795 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B5CF4", Offset = "0x34B5CF4", VA = "0x34B5CF4")]
	[Token(Token = "0x60016A3")]
	private void method_18()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016A4 RID: 5796 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34B5D30", Offset = "0x34B5D30", VA = "0x34B5D30")]
	[Token(Token = "0x60016A4")]
	public void method_19()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016A5 RID: 5797 RVA: 0x0002B804 File Offset: 0x00029A04
	[Address(RVA = "0x34B5E2C", Offset = "0x34B5E2C", VA = "0x34B5E2C")]
	[Token(Token = "0x60016A5")]
	private void method_20()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = this.transform_0;
					Transform transform3 = attachedRigidbody.transform;
					transform2.SetParent(transform3);
					long num = 1L;
					return;
				}
				long num2 = 1L;
				this.bool_3 = (num2 != 0L);
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			long num;
			if (num != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016A6 RID: 5798 RVA: 0x0002B914 File Offset: 0x00029B14
	[Address(RVA = "0x34B61F8", Offset = "0x34B61F8", VA = "0x34B61F8")]
	[Token(Token = "0x60016A6")]
	private void method_21()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = this.transform_0;
					Transform transform3 = attachedRigidbody.transform;
					transform2.SetParent(transform3);
					long num = 1L;
					return;
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			long num;
			if (num != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016A7 RID: 5799 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60016A7")]
	[Address(RVA = "0x34B65BC", Offset = "0x34B65BC", VA = "0x34B65BC")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016A8 RID: 5800 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34B66B8", Offset = "0x34B66B8", VA = "0x34B66B8")]
	[Token(Token = "0x60016A8")]
	public void method_22()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016A9 RID: 5801 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B67B4", Offset = "0x34B67B4", VA = "0x34B67B4")]
	[Token(Token = "0x60016A9")]
	private void method_23()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016AA RID: 5802 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60016AA")]
	[Address(RVA = "0x34B67F0", Offset = "0x34B67F0", VA = "0x34B67F0")]
	public void method_24()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016AB RID: 5803 RVA: 0x0002BA1C File Offset: 0x00029C1C
	[Address(RVA = "0x34B68EC", Offset = "0x34B68EC", VA = "0x34B68EC")]
	[Token(Token = "0x60016AB")]
	private void method_25()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long num = 1L;
					this.bool_3 = (num != 0L);
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			exists;
			FixedJoint obj = this.fixedJoint_0;
			UnityEngine.Object.Destroy(obj);
			return;
		}
	}

	// Token: 0x060016AC RID: 5804 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60016AC")]
	[Address(RVA = "0x34B6CB0", Offset = "0x34B6CB0", VA = "0x34B6CB0")]
	public void method_26()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016AD RID: 5805 RVA: 0x0002BB14 File Offset: 0x00029D14
	[Token(Token = "0x60016AD")]
	[Address(RVA = "0x34B6DAC", Offset = "0x34B6DAC", VA = "0x34B6DAC")]
	private void method_27()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			exists;
			FixedJoint obj = this.fixedJoint_0;
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016AE RID: 5806 RVA: 0x0002AF00 File Offset: 0x00029100
	[Token(Token = "0x60016AE")]
	[Address(RVA = "0x34B716C", Offset = "0x34B716C", VA = "0x34B716C")]
	private void method_28()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016AF RID: 5807 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60016AF")]
	[Address(RVA = "0x34B71A8", Offset = "0x34B71A8", VA = "0x34B71A8")]
	public void method_29()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016B0 RID: 5808 RVA: 0x000026B2 File Offset: 0x000008B2
	[Address(RVA = "0x34B72A4", Offset = "0x34B72A4", VA = "0x34B72A4")]
	[Token(Token = "0x60016B0")]
	public grabPhysics()
	{
	}

	// Token: 0x060016B1 RID: 5809 RVA: 0x0002BC1C File Offset: 0x00029E1C
	[Token(Token = "0x60016B1")]
	[Address(RVA = "0x34B72B8", Offset = "0x34B72B8", VA = "0x34B72B8")]
	private void method_30()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = attachedRigidbody.transform;
					long num = 0L;
					return;
				}
				long num2 = 1L;
				this.bool_3 = (num2 != 0L);
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			long num;
			if (num != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform3 = this.transform_0;
			Transform parent = this.transform_1;
			transform3.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016B2 RID: 5810 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60016B2")]
	[Address(RVA = "0x34B7684", Offset = "0x34B7684", VA = "0x34B7684")]
	public void method_31()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016B3 RID: 5811 RVA: 0x0002BD18 File Offset: 0x00029F18
	[Address(RVA = "0x34B778C", Offset = "0x34B778C", VA = "0x34B778C")]
	[Token(Token = "0x60016B3")]
	private void method_32()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Vector3 position2 = base.transform.position;
					Transform transform = this.transform_0;
					Transform transform2 = attachedRigidbody.transform;
					transform.SetParent(transform2);
					return;
				}
				long num = 1L;
				this.bool_3 = (num != 0L);
			}
		}
		else if (flag4)
		{
			long num2 = 1L;
			this.bool_3 = (num2 != 0L);
			FixedJoint exists = this.fixedJoint_0;
			if (num2 != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num2 != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform3 = this.transform_0;
			Transform parent = this.transform_1;
			transform3.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016B4 RID: 5812 RVA: 0x0002AF00 File Offset: 0x00029100
	[Token(Token = "0x60016B4")]
	[Address(RVA = "0x34B7B54", Offset = "0x34B7B54", VA = "0x34B7B54")]
	private void method_33()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016B5 RID: 5813 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B7B90", Offset = "0x34B7B90", VA = "0x34B7B90")]
	[Token(Token = "0x60016B5")]
	private void method_34()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016B6 RID: 5814 RVA: 0x0002AF00 File Offset: 0x00029100
	[Token(Token = "0x60016B6")]
	[Address(RVA = "0x34B7BCC", Offset = "0x34B7BCC", VA = "0x34B7BCC")]
	private void method_35()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016B7 RID: 5815 RVA: 0x0002B2EC File Offset: 0x000294EC
	[Address(RVA = "0x34B7C08", Offset = "0x34B7C08", VA = "0x34B7C08")]
	[Token(Token = "0x60016B7")]
	private void method_36()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long num = 1L;
					this.bool_3 = (num != 0L);
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			exists;
			FixedJoint obj = this.fixedJoint_0;
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016B8 RID: 5816 RVA: 0x0002AF00 File Offset: 0x00029100
	[Token(Token = "0x60016B8")]
	[Address(RVA = "0x34B7FC8", Offset = "0x34B7FC8", VA = "0x34B7FC8")]
	private void OnDrawGizmos()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016B9 RID: 5817 RVA: 0x0002BE28 File Offset: 0x0002A028
	[Address(RVA = "0x34B8004", Offset = "0x34B8004", VA = "0x34B8004")]
	[Token(Token = "0x60016B9")]
	private void method_37()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016BA RID: 5818 RVA: 0x0002BE44 File Offset: 0x0002A044
	[Address(RVA = "0x34B8040", Offset = "0x34B8040", VA = "0x34B8040")]
	[Token(Token = "0x60016BA")]
	private void method_38()
	{
		bool flag;
		if (flag = this.bool_1)
		{
			if (flag)
			{
			}
			this.bool_0 = flag;
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			Vector3 position = base.transform.position;
			LayerMask mask = this.layerMask_0;
			mask;
			if (flag3)
			{
				Collider[] array;
				Rigidbody attachedRigidbody = array.attachedRigidbody;
				FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
				this.fixedJoint_0 = fixedJoint;
				attachedRigidbody;
				Transform transform = attachedRigidbody.transform;
				Vector3 position2 = base.transform.position;
				Transform transform2 = this.transform_0;
				Transform transform3 = attachedRigidbody.transform;
				transform2.SetParent(transform3);
				return;
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			exists;
			FixedJoint obj = this.fixedJoint_0;
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016BB RID: 5819 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B8408", Offset = "0x34B8408", VA = "0x34B8408")]
	[Token(Token = "0x60016BB")]
	private void method_39()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016BC RID: 5820 RVA: 0x0002AF00 File Offset: 0x00029100
	[Token(Token = "0x60016BC")]
	[Address(RVA = "0x34B8444", Offset = "0x34B8444", VA = "0x34B8444")]
	private void method_40()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016BD RID: 5821 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34B8480", Offset = "0x34B8480", VA = "0x34B8480")]
	[Token(Token = "0x60016BD")]
	public void method_41()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016BE RID: 5822 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B857C", Offset = "0x34B857C", VA = "0x34B857C")]
	[Token(Token = "0x60016BE")]
	private void method_42()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016BF RID: 5823 RVA: 0x0002BF3C File Offset: 0x0002A13C
	[Address(RVA = "0x34B85B8", Offset = "0x34B85B8", VA = "0x34B85B8")]
	[Token(Token = "0x60016BF")]
	private void method_43()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			exists;
			FixedJoint obj = this.fixedJoint_0;
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016C0 RID: 5824 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B8978", Offset = "0x34B8978", VA = "0x34B8978")]
	[Token(Token = "0x60016C0")]
	private void method_44()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016C1 RID: 5825 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34B89B4", Offset = "0x34B89B4", VA = "0x34B89B4")]
	[Token(Token = "0x60016C1")]
	public void method_45()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016C2 RID: 5826 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60016C2")]
	[Address(RVA = "0x34B8AB0", Offset = "0x34B8AB0", VA = "0x34B8AB0")]
	public void method_46()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016C3 RID: 5827 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B8BAC", Offset = "0x34B8BAC", VA = "0x34B8BAC")]
	[Token(Token = "0x60016C3")]
	private void method_47()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016C4 RID: 5828 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34B8BE8", Offset = "0x34B8BE8", VA = "0x34B8BE8")]
	[Token(Token = "0x60016C4")]
	public void method_48()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016C5 RID: 5829 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B8CF0", Offset = "0x34B8CF0", VA = "0x34B8CF0")]
	[Token(Token = "0x60016C5")]
	private void method_49()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016C6 RID: 5830 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B8D2C", Offset = "0x34B8D2C", VA = "0x34B8D2C")]
	[Token(Token = "0x60016C6")]
	private void method_50()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016C7 RID: 5831 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B8D68", Offset = "0x34B8D68", VA = "0x34B8D68")]
	[Token(Token = "0x60016C7")]
	private void method_51()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016C8 RID: 5832 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34B8DA4", Offset = "0x34B8DA4", VA = "0x34B8DA4")]
	[Token(Token = "0x60016C8")]
	private void method_52()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016C9 RID: 5833 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34B8DE0", Offset = "0x34B8DE0", VA = "0x34B8DE0")]
	[Token(Token = "0x60016C9")]
	public void method_53()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016CA RID: 5834 RVA: 0x0002C044 File Offset: 0x0002A244
	[Address(RVA = "0x34B8EE8", Offset = "0x34B8EE8", VA = "0x34B8EE8")]
	[Token(Token = "0x60016CA")]
	private void method_54()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		if (!this.bool_3)
		{
			Vector3 position = base.transform.position;
			LayerMask mask = this.layerMask_0;
			mask;
			Collider[] array;
			Rigidbody attachedRigidbody = array.attachedRigidbody;
			FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
			this.fixedJoint_0 = fixedJoint;
			attachedRigidbody;
			Transform transform = attachedRigidbody.transform;
			Vector3 position2 = base.transform.position;
			Transform transform2 = this.transform_0;
			Transform transform3 = attachedRigidbody.transform;
			transform2.SetParent(transform3);
			return;
		}
	}

	// Token: 0x060016CB RID: 5835 RVA: 0x0002C0E8 File Offset: 0x0002A2E8
	[Token(Token = "0x60016CB")]
	[Address(RVA = "0x34B92AC", Offset = "0x34B92AC", VA = "0x34B92AC")]
	private void method_55()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = this.transform_0;
					Transform transform3 = attachedRigidbody.transform;
					transform2.SetParent(transform3);
					long num = 0L;
					return;
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			long num;
			if (num != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016CC RID: 5836 RVA: 0x0002C1F0 File Offset: 0x0002A3F0
	[Address(RVA = "0x34B9678", Offset = "0x34B9678", VA = "0x34B9678")]
	[Token(Token = "0x60016CC")]
	private void method_56()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long num = 1L;
					this.bool_3 = (num != 0L);
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			exists;
			FixedJoint obj = this.fixedJoint_0;
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016CD RID: 5837 RVA: 0x0002C1F0 File Offset: 0x0002A3F0
	[Token(Token = "0x60016CD")]
	[Address(RVA = "0x34B9A40", Offset = "0x34B9A40", VA = "0x34B9A40")]
	private void FixedUpdate()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long num = 1L;
					this.bool_3 = (num != 0L);
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			exists;
			FixedJoint obj = this.fixedJoint_0;
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016CE RID: 5838 RVA: 0x0002C300 File Offset: 0x0002A500
	[Token(Token = "0x60016CE")]
	[Address(RVA = "0x34B9E08", Offset = "0x34B9E08", VA = "0x34B9E08")]
	private void method_57()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			Vector3 position = base.transform.position;
			LayerMask mask = this.layerMask_0;
			mask;
			if (flag3)
			{
				Collider[] array;
				Rigidbody attachedRigidbody = array.attachedRigidbody;
				FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
				this.fixedJoint_0 = fixedJoint;
				attachedRigidbody;
				Transform transform = attachedRigidbody.transform;
				Vector3 position2 = base.transform.position;
				Transform transform2 = this.transform_0;
				Transform transform3 = attachedRigidbody.transform;
				transform2.SetParent(transform3);
				long num = 0L;
				return;
			}
			long num2 = 1L;
			this.bool_3 = (num2 != 0L);
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			long num;
			if (num != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016CF RID: 5839 RVA: 0x0002B914 File Offset: 0x00029B14
	[Address(RVA = "0x34BA1D4", Offset = "0x34BA1D4", VA = "0x34BA1D4")]
	[Token(Token = "0x60016CF")]
	private void method_58()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = this.transform_0;
					Transform transform3 = attachedRigidbody.transform;
					transform2.SetParent(transform3);
					long num = 1L;
					return;
				}
			}
		}
		else if (flag4)
		{
			FixedJoint exists = this.fixedJoint_0;
			long num;
			if (num != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016D0 RID: 5840 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34BA59C", Offset = "0x34BA59C", VA = "0x34BA59C")]
	[Token(Token = "0x60016D0")]
	public void method_59()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016D1 RID: 5841 RVA: 0x0002C40C File Offset: 0x0002A60C
	[Token(Token = "0x60016D1")]
	[Address(RVA = "0x34BA6B0", Offset = "0x34BA6B0", VA = "0x34BA6B0")]
	private void method_60()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					if (flag3)
					{
						Collider[] array;
						Rigidbody attachedRigidbody = array.attachedRigidbody;
						FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
						this.fixedJoint_0 = fixedJoint;
						attachedRigidbody;
						Transform transform = attachedRigidbody.transform;
						Vector3 position2 = base.transform.position;
						Transform transform2 = this.transform_0;
						Transform transform3 = attachedRigidbody.transform;
						transform2.SetParent(transform3);
						return;
					}
					throw new IndexOutOfRangeException();
				}
				else
				{
					long num = 1L;
					this.bool_3 = (num != 0L);
				}
			}
		}
		else if (flag4)
		{
			long num2 = 1L;
			this.bool_3 = (num2 != 0L);
			FixedJoint exists = this.fixedJoint_0;
			if (num2 != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num2 != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016D2 RID: 5842 RVA: 0x0002AF00 File Offset: 0x00029100
	[Token(Token = "0x60016D2")]
	[Address(RVA = "0x34BAA74", Offset = "0x34BAA74", VA = "0x34BAA74")]
	private void method_61()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016D3 RID: 5843 RVA: 0x0002AF00 File Offset: 0x00029100
	[Token(Token = "0x60016D3")]
	[Address(RVA = "0x34BAAB0", Offset = "0x34BAAB0", VA = "0x34BAAB0")]
	private void method_62()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016D4 RID: 5844 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34BAAEC", Offset = "0x34BAAEC", VA = "0x34BAAEC")]
	[Token(Token = "0x60016D4")]
	public void method_63()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016D5 RID: 5845 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60016D5")]
	[Address(RVA = "0x34BABE8", Offset = "0x34BABE8", VA = "0x34BABE8")]
	public void method_64()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016D6 RID: 5846 RVA: 0x0002C530 File Offset: 0x0002A730
	[Address(RVA = "0x34BACE4", Offset = "0x34BACE4", VA = "0x34BACE4")]
	[Token(Token = "0x60016D6")]
	private void method_65()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = this.transform_0;
					Transform transform3 = attachedRigidbody.transform;
					transform2.SetParent(transform3);
					return;
				}
				long num = 1L;
				this.bool_3 = (num != 0L);
			}
		}
		else if (flag4)
		{
			long num2 = 1L;
			this.bool_3 = (num2 != 0L);
			FixedJoint exists = this.fixedJoint_0;
			if (num2 != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num2 != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016D7 RID: 5847 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60016D7")]
	[Address(RVA = "0x34BB0B0", Offset = "0x34BB0B0", VA = "0x34BB0B0")]
	public void method_66()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016D8 RID: 5848 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60016D8")]
	[Address(RVA = "0x34BB1B8", Offset = "0x34BB1B8", VA = "0x34BB1B8")]
	public void method_67()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016D9 RID: 5849 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60016D9")]
	[Address(RVA = "0x34BB2B4", Offset = "0x34BB2B4", VA = "0x34BB2B4")]
	public void method_68()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016DA RID: 5850 RVA: 0x0002C530 File Offset: 0x0002A730
	[Token(Token = "0x60016DA")]
	[Address(RVA = "0x34BB3BC", Offset = "0x34BB3BC", VA = "0x34BB3BC")]
	private void method_69()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = this.transform_0;
					Transform transform3 = attachedRigidbody.transform;
					transform2.SetParent(transform3);
					return;
				}
				long num = 1L;
				this.bool_3 = (num != 0L);
			}
		}
		else if (flag4)
		{
			long num2 = 1L;
			this.bool_3 = (num2 != 0L);
			FixedJoint exists = this.fixedJoint_0;
			if (num2 != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num2 != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016DB RID: 5851 RVA: 0x0002AF00 File Offset: 0x00029100
	[Token(Token = "0x60016DB")]
	[Address(RVA = "0x34BB788", Offset = "0x34BB788", VA = "0x34BB788")]
	private void method_70()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016DC RID: 5852 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34BB7C4", Offset = "0x34BB7C4", VA = "0x34BB7C4")]
	[Token(Token = "0x60016DC")]
	private void method_71()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x060016DD RID: 5853 RVA: 0x0002B60C File Offset: 0x0002980C
	[Address(RVA = "0x34BB800", Offset = "0x34BB800", VA = "0x34BB800")]
	[Token(Token = "0x60016DD")]
	private void method_72()
	{
		bool flag;
		if (!(flag = this.bool_1) || flag)
		{
		}
		bool flag2;
		if (flag2 = this.bool_2)
		{
			if (flag2)
			{
			}
			return;
		}
		bool flag3 = this.bool_0;
		bool flag4 = this.bool_3;
		if (flag3)
		{
			if (!flag4)
			{
				Vector3 position = base.transform.position;
				LayerMask mask = this.layerMask_0;
				mask;
				if (flag3)
				{
					Collider[] array;
					Rigidbody attachedRigidbody = array.attachedRigidbody;
					FixedJoint fixedJoint = base.gameObject.AddComponent<FixedJoint>();
					this.fixedJoint_0 = fixedJoint;
					attachedRigidbody;
					Transform transform = attachedRigidbody.transform;
					Vector3 position2 = base.transform.position;
					Transform transform2 = this.transform_0;
					Transform transform3 = attachedRigidbody.transform;
					transform2.SetParent(transform3);
					return;
				}
			}
		}
		else if (flag4)
		{
			long num = 1L;
			this.bool_3 = (num != 0L);
			FixedJoint exists = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			exists;
			FixedJoint obj = this.fixedJoint_0;
			if (num != 0L)
			{
			}
			UnityEngine.Object.Destroy(obj);
			Transform transform4 = this.transform_0;
			Transform parent = this.transform_1;
			transform4.SetParent(parent);
			return;
		}
	}

	// Token: 0x060016DE RID: 5854 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34BBBD0", Offset = "0x34BBBD0", VA = "0x34BBBD0")]
	[Token(Token = "0x60016DE")]
	public void method_73()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060016DF RID: 5855 RVA: 0x0002AF00 File Offset: 0x00029100
	[Address(RVA = "0x34BBCD8", Offset = "0x34BBCD8", VA = "0x34BBCD8")]
	[Token(Token = "0x60016DF")]
	private void method_74()
	{
		Vector3 position = base.transform.position;
	}

	// Token: 0x040002E9 RID: 745
	[Token(Token = "0x40002E9")]
	[FieldOffset(Offset = "0x18")]
	public float float_0 = (float)52429;

	// Token: 0x040002EA RID: 746
	[Token(Token = "0x40002EA")]
	[FieldOffset(Offset = "0x1C")]
	public LayerMask layerMask_0;

	// Token: 0x040002EB RID: 747
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002EB")]
	private InputDevice inputDevice_0;

	// Token: 0x040002EC RID: 748
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40002EC")]
	private InputDevice inputDevice_1;

	// Token: 0x040002ED RID: 749
	[Token(Token = "0x40002ED")]
	[FieldOffset(Offset = "0x40")]
	public bool bool_0;

	// Token: 0x040002EE RID: 750
	[Token(Token = "0x40002EE")]
	[FieldOffset(Offset = "0x41")]
	public bool bool_1;

	// Token: 0x040002EF RID: 751
	[FieldOffset(Offset = "0x42")]
	[Token(Token = "0x40002EF")]
	public bool bool_2;

	// Token: 0x040002F0 RID: 752
	[FieldOffset(Offset = "0x43")]
	[Token(Token = "0x40002F0")]
	private bool bool_3;

	// Token: 0x040002F1 RID: 753
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40002F1")]
	private FixedJoint fixedJoint_0;

	// Token: 0x040002F2 RID: 754
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40002F2")]
	private FixedJoint fixedJoint_1;

	// Token: 0x040002F3 RID: 755
	[Token(Token = "0x40002F3")]
	[FieldOffset(Offset = "0x58")]
	public Transform transform_0;

	// Token: 0x040002F4 RID: 756
	[Token(Token = "0x40002F4")]
	[FieldOffset(Offset = "0x60")]
	public Transform transform_1;
}
