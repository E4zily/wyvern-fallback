﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000043 RID: 67
[Token(Token = "0x2000043")]
public class Swimmy : MonoBehaviour
{
	// Token: 0x060008AC RID: 2220 RVA: 0x000132FC File Offset: 0x000114FC
	[Token(Token = "0x60008AC")]
	[Address(RVA = "0x3084AD0", Offset = "0x3084AD0", VA = "0x3084AD0")]
	private void method_0()
	{
	}

	// Token: 0x060008AD RID: 2221 RVA: 0x0001330C File Offset: 0x0001150C
	[Token(Token = "0x60008AD")]
	[Address(RVA = "0x3084C34", Offset = "0x3084C34", VA = "0x3084C34")]
	private void method_1()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.inputDevice_1 = deviceAtXRNode;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008AE RID: 2222 RVA: 0x0001334C File Offset: 0x0001154C
	[Token(Token = "0x60008AE")]
	[Address(RVA = "0x3084C70", Offset = "0x3084C70", VA = "0x3084C70")]
	private void method_2()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008AF RID: 2223 RVA: 0x000132FC File Offset: 0x000114FC
	[Address(RVA = "0x3084CAC", Offset = "0x3084CAC", VA = "0x3084CAC")]
	[Token(Token = "0x60008AF")]
	private void method_3()
	{
	}

	// Token: 0x060008B0 RID: 2224 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3084E10", Offset = "0x3084E10", VA = "0x3084E10")]
	[Token(Token = "0x60008B0")]
	public void method_4()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008B1 RID: 2225 RVA: 0x0001330C File Offset: 0x0001150C
	[Token(Token = "0x60008B1")]
	[Address(RVA = "0x3084F18", Offset = "0x3084F18", VA = "0x3084F18")]
	private void Start()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.inputDevice_1 = deviceAtXRNode;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008B2 RID: 2226 RVA: 0x000132FC File Offset: 0x000114FC
	[Address(RVA = "0x3084F54", Offset = "0x3084F54", VA = "0x3084F54")]
	[Token(Token = "0x60008B2")]
	private void method_5()
	{
	}

	// Token: 0x060008B3 RID: 2227 RVA: 0x0001334C File Offset: 0x0001154C
	[Token(Token = "0x60008B3")]
	[Address(RVA = "0x30850B8", Offset = "0x30850B8", VA = "0x30850B8")]
	private void method_6()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008B4 RID: 2228 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008B4")]
	[Address(RVA = "0x30850F4", Offset = "0x30850F4", VA = "0x30850F4")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008B5 RID: 2229 RVA: 0x000132FC File Offset: 0x000114FC
	[Token(Token = "0x60008B5")]
	[Address(RVA = "0x30851F0", Offset = "0x30851F0", VA = "0x30851F0")]
	private void FixedUpdate()
	{
	}

	// Token: 0x060008B6 RID: 2230 RVA: 0x000132FC File Offset: 0x000114FC
	[Address(RVA = "0x3085354", Offset = "0x3085354", VA = "0x3085354")]
	[Token(Token = "0x60008B6")]
	private void method_7()
	{
	}

	// Token: 0x060008B7 RID: 2231 RVA: 0x000132FC File Offset: 0x000114FC
	[Token(Token = "0x60008B7")]
	[Address(RVA = "0x30854B8", Offset = "0x30854B8", VA = "0x30854B8")]
	private void method_8()
	{
	}

	// Token: 0x060008B8 RID: 2232 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008B8")]
	[Address(RVA = "0x308561C", Offset = "0x308561C", VA = "0x308561C")]
	public void method_9()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008B9 RID: 2233 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008B9")]
	[Address(RVA = "0x3085718", Offset = "0x3085718", VA = "0x3085718")]
	public void method_10()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008BA RID: 2234 RVA: 0x0001334C File Offset: 0x0001154C
	[Token(Token = "0x60008BA")]
	[Address(RVA = "0x308582C", Offset = "0x308582C", VA = "0x308582C")]
	private void method_11()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008BB RID: 2235 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60008BB")]
	[Address(RVA = "0x3085868", Offset = "0x3085868", VA = "0x3085868")]
	public Swimmy()
	{
	}

	// Token: 0x060008BC RID: 2236 RVA: 0x0001334C File Offset: 0x0001154C
	[Token(Token = "0x60008BC")]
	[Address(RVA = "0x3085870", Offset = "0x3085870", VA = "0x3085870")]
	private void method_12()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008BD RID: 2237 RVA: 0x00013388 File Offset: 0x00011588
	[Address(RVA = "0x30858AC", Offset = "0x30858AC", VA = "0x30858AC")]
	[Token(Token = "0x60008BD")]
	private void method_13()
	{
	}

	// Token: 0x0400013F RID: 319
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400013F")]
	private InputDevice inputDevice_0;

	// Token: 0x04000140 RID: 320
	[Token(Token = "0x4000140")]
	[FieldOffset(Offset = "0x28")]
	private InputDevice inputDevice_1;

	// Token: 0x04000141 RID: 321
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000141")]
	public Vector3 vector3_0;

	// Token: 0x04000142 RID: 322
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000142")]
	public Vector3 vector3_1;

	// Token: 0x04000143 RID: 323
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000143")]
	private InputDevice inputDevice_2;

	// Token: 0x04000144 RID: 324
	[Token(Token = "0x4000144")]
	[FieldOffset(Offset = "0x60")]
	private InputDevice inputDevice_3;

	// Token: 0x04000145 RID: 325
	[Token(Token = "0x4000145")]
	[FieldOffset(Offset = "0x70")]
	public Rigidbody rigidbody_0;

	// Token: 0x04000146 RID: 326
	[Token(Token = "0x4000146")]
	[FieldOffset(Offset = "0x78")]
	public float float_0;

	// Token: 0x04000147 RID: 327
	[Token(Token = "0x4000147")]
	[FieldOffset(Offset = "0x7C")]
	public float float_1;

	// Token: 0x04000148 RID: 328
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4000148")]
	public float float_2;

	// Token: 0x04000149 RID: 329
	[FieldOffset(Offset = "0x84")]
	[Token(Token = "0x4000149")]
	public float float_3;
}
