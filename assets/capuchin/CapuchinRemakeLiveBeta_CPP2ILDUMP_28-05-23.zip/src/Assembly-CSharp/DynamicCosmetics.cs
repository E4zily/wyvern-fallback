﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using Photon.Pun;
using PlayFab;
using PlayFab.ClientModels;
using TMPro;
using UnityEngine;

// Token: 0x02000051 RID: 81
[Token(Token = "0x2000051")]
public class DynamicCosmetics : MonoBehaviourPunCallbacks
{
	// Token: 0x06000B32 RID: 2866 RVA: 0x000193AC File Offset: 0x000175AC
	[Token(Token = "0x6000B32")]
	[Address(RVA = "0x221CC68", Offset = "0x221CC68", VA = "0x221CC68")]
	public void method_0(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		"TurnAmount" == "Cannot take elements from an empty buffer.";
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B33 RID: 2867 RVA: 0x000193D8 File Offset: 0x000175D8
	[Token(Token = "0x6000B33")]
	[Address(RVA = "0x221D13C", Offset = "0x221D13C", VA = "0x221D13C")]
	public void method_1(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B34 RID: 2868 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x221D604", Offset = "0x221D604", VA = "0x221D604")]
	[Token(Token = "0x6000B34")]
	private void method_2(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B35 RID: 2869 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x221D6E4", Offset = "0x221D6E4", VA = "0x221D6E4")]
	[Token(Token = "0x6000B35")]
	public void method_3()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B36 RID: 2870 RVA: 0x00019410 File Offset: 0x00017610
	[Address(RVA = "0x221DA5C", Offset = "0x221DA5C", VA = "0x221DA5C")]
	[Token(Token = "0x6000B36")]
	public void method_4(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B37 RID: 2871 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x221DF38", Offset = "0x221DF38", VA = "0x221DF38")]
	[Token(Token = "0x6000B37")]
	private void method_5(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B38 RID: 2872 RVA: 0x0001942C File Offset: 0x0001762C
	[Token(Token = "0x6000B38")]
	[Address(RVA = "0x221E018", Offset = "0x221E018", VA = "0x221E018")]
	private IEnumerator method_6(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000B39 RID: 2873 RVA: 0x00019454 File Offset: 0x00017654
	[Token(Token = "0x6000B39")]
	[Address(RVA = "0x221E090", Offset = "0x221E090", VA = "0x221E090")]
	public void method_7(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "Player";
			return;
		}
	}

	// Token: 0x06000B3A RID: 2874 RVA: 0x00019478 File Offset: 0x00017678
	[Token(Token = "0x6000B3A")]
	[Address(RVA = "0x221E77C", Offset = "0x221E77C", VA = "0x221E77C")]
	public void method_8(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B3B RID: 2875 RVA: 0x00019494 File Offset: 0x00017694
	[Address(RVA = "0x221EC50", Offset = "0x221EC50", VA = "0x221EC50")]
	[Token(Token = "0x6000B3B")]
	private void method_9()
	{
		new GetUserInventoryRequest();
		Action<PlayFabError> <>9__28_ = DynamicCosmetics.<>c.<>9__28_1;
		if (<>9__28_ == null)
		{
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000B3C RID: 2876 RVA: 0x000194C4 File Offset: 0x000176C4
	[Token(Token = "0x6000B3C")]
	[Address(RVA = "0x221EE28", Offset = "0x221EE28", VA = "0x221EE28")]
	private void method_10()
	{
		new DynamicCosmetics.<>c();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
	}

	// Token: 0x06000B3D RID: 2877 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x221EFFC", Offset = "0x221EFFC", VA = "0x221EFFC")]
	[Token(Token = "0x6000B3D")]
	private void method_11()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B3E RID: 2878 RVA: 0x000194E4 File Offset: 0x000176E4
	[Address(RVA = "0x221F8FC", Offset = "0x221F8FC", VA = "0x221F8FC")]
	[Token(Token = "0x6000B3E")]
	public void method_12(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "BN";
			long num = 7L;
			this.int_3 = (int)num;
			return;
		}
	}

	// Token: 0x06000B3F RID: 2879 RVA: 0x00019514 File Offset: 0x00017714
	[Address(RVA = "0x221FFD8", Offset = "0x221FFD8", VA = "0x221FFD8")]
	[Token(Token = "0x6000B3F")]
	public void method_13(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "NormalWeather";
			long num = 1L;
			this.genum4_0 = (DynamicCosmetics.GEnum4)num;
			this.bool_0 = (num != 0L);
			return;
		}
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
	}

	// Token: 0x06000B40 RID: 2880 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x22206EC", Offset = "0x22206EC", VA = "0x22206EC")]
	[Token(Token = "0x6000B40")]
	private void method_14(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B41 RID: 2881 RVA: 0x00019554 File Offset: 0x00017754
	[Address(RVA = "0x22207CC", Offset = "0x22207CC", VA = "0x22207CC")]
	[Token(Token = "0x6000B41")]
	public void method_15(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B42 RID: 2882 RVA: 0x00019570 File Offset: 0x00017770
	[Token(Token = "0x6000B42")]
	[Address(RVA = "0x2220C74", Offset = "0x2220C74", VA = "0x2220C74")]
	public void method_16(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B43 RID: 2883 RVA: 0x0001958C File Offset: 0x0001778C
	[Token(Token = "0x6000B43")]
	[Address(RVA = "0x2221124", Offset = "0x2221124", VA = "0x2221124")]
	private void method_17()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000B44 RID: 2884 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x22212FC", Offset = "0x22212FC", VA = "0x22212FC")]
	[Token(Token = "0x6000B44")]
	public void method_18()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B45 RID: 2885 RVA: 0x000195B8 File Offset: 0x000177B8
	[Token(Token = "0x6000B45")]
	[Address(RVA = "0x222178C", Offset = "0x222178C", VA = "0x222178C")]
	public void method_19(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B46 RID: 2886 RVA: 0x000195D4 File Offset: 0x000177D4
	[Token(Token = "0x6000B46")]
	[Address(RVA = "0x2221C34", Offset = "0x2221C34", VA = "0x2221C34")]
	public void method_20(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_132();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.";
		purchaseItemRequest.CatalogVersion = "StartSong";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B47 RID: 2887 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x2222190", Offset = "0x2222190", VA = "0x2222190")]
	[Token(Token = "0x6000B47")]
	private void method_21(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B48 RID: 2888 RVA: 0x00019630 File Offset: 0x00017830
	[Token(Token = "0x6000B48")]
	[Address(RVA = "0x2222270", Offset = "0x2222270", VA = "0x2222270")]
	public void method_22(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "Update User Inventory";
			long num = 1L;
			long num2 = 3L;
			this.genum4_0 = (DynamicCosmetics.GEnum4)num;
			this.int_3 = (int)num2;
			return;
		}
	}

	// Token: 0x06000B49 RID: 2889 RVA: 0x00019668 File Offset: 0x00017868
	[Token(Token = "0x6000B49")]
	[Address(RVA = "0x2222948", Offset = "0x2222948", VA = "0x2222948")]
	public void method_23(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_44();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "Hats";
		purchaseItemRequest.CatalogVersion = "amongus";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B4A RID: 2890 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x2222EA8", Offset = "0x2222EA8", VA = "0x2222EA8")]
	[Token(Token = "0x6000B4A")]
	private void method_24(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B4B RID: 2891 RVA: 0x000196C4 File Offset: 0x000178C4
	[Address(RVA = "0x2222F88", Offset = "0x2222F88", VA = "0x2222F88")]
	[Token(Token = "0x6000B4B")]
	private void method_25()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
	}

	// Token: 0x06000B4C RID: 2892 RVA: 0x0001958C File Offset: 0x0001778C
	[Token(Token = "0x6000B4C")]
	[Address(RVA = "0x222315C", Offset = "0x222315C", VA = "0x222315C")]
	private void method_26()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000B4D RID: 2893 RVA: 0x0001942C File Offset: 0x0001762C
	[Token(Token = "0x6000B4D")]
	[Address(RVA = "0x2223334", Offset = "0x2223334", VA = "0x2223334")]
	private IEnumerator method_27(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000B4E RID: 2894 RVA: 0x000196C4 File Offset: 0x000178C4
	[Address(RVA = "0x22233AC", Offset = "0x22233AC", VA = "0x22233AC")]
	[Token(Token = "0x6000B4E")]
	private void method_28()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
	}

	// Token: 0x06000B4F RID: 2895 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000B4F")]
	[Address(RVA = "0x2223580", Offset = "0x2223580", VA = "0x2223580")]
	public void method_29()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B50 RID: 2896 RVA: 0x000196E4 File Offset: 0x000178E4
	[Token(Token = "0x6000B50")]
	[Address(RVA = "0x2223A24", Offset = "0x2223A24", VA = "0x2223A24")]
	private void Awake()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
		long num = 2L;
		this.int_3 = (int)num;
	}

	// Token: 0x06000B51 RID: 2897 RVA: 0x000193F4 File Offset: 0x000175F4
	[Token(Token = "0x6000B51")]
	[Address(RVA = "0x2223A90", Offset = "0x2223A90", VA = "0x2223A90")]
	private void method_30(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B52 RID: 2898 RVA: 0x00019700 File Offset: 0x00017900
	[Token(Token = "0x6000B52")]
	[Address(RVA = "0x2223B70", Offset = "0x2223B70", VA = "0x2223B70")]
	private void method_31()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
		long num = 4L;
		this.int_3 = (int)num;
	}

	// Token: 0x06000B53 RID: 2899 RVA: 0x0001942C File Offset: 0x0001762C
	[Address(RVA = "0x2222E30", Offset = "0x2222E30", VA = "0x2222E30")]
	[Token(Token = "0x6000B53")]
	private IEnumerator method_32(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000B54 RID: 2900 RVA: 0x00019700 File Offset: 0x00017900
	[Address(RVA = "0x2223BD4", Offset = "0x2223BD4", VA = "0x2223BD4")]
	[Token(Token = "0x6000B54")]
	private void method_33()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
		long num = 4L;
		this.int_3 = (int)num;
	}

	// Token: 0x06000B55 RID: 2901 RVA: 0x0001971C File Offset: 0x0001791C
	[Token(Token = "0x6000B55")]
	[Address(RVA = "0x2223C3C", Offset = "0x2223C3C", VA = "0x2223C3C")]
	public void method_34(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_25();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "Adding ";
		purchaseItemRequest.CatalogVersion = "lock unlocked!";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B56 RID: 2902 RVA: 0x0001942C File Offset: 0x0001762C
	[Token(Token = "0x6000B56")]
	[Address(RVA = "0x2223FC4", Offset = "0x2223FC4", VA = "0x2223FC4")]
	private IEnumerator method_35(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000B57 RID: 2903 RVA: 0x000193F4 File Offset: 0x000175F4
	[CompilerGenerated]
	[Address(RVA = "0x222403C", Offset = "0x222403C", VA = "0x222403C")]
	[Token(Token = "0x6000B57")]
	private void method_36(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B58 RID: 2904 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2224110", Offset = "0x2224110", VA = "0x2224110")]
	[Token(Token = "0x6000B58")]
	public void method_37()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B59 RID: 2905 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2224494", Offset = "0x2224494", VA = "0x2224494")]
	[Token(Token = "0x6000B59")]
	private void method_38()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B5A RID: 2906 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000B5A")]
	[Address(RVA = "0x2224EB0", Offset = "0x2224EB0", VA = "0x2224EB0")]
	public void method_39()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B5B RID: 2907 RVA: 0x00019778 File Offset: 0x00017978
	[Token(Token = "0x6000B5B")]
	[Address(RVA = "0x2225238", Offset = "0x2225238", VA = "0x2225238")]
	public void method_40(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class12 @class = new DynamicCosmetics.Class12();
		@class.button = purchaseCosmeticButton_0;
		@class.<>4__this = this;
		this.method_10();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "_Color";
		purchaseItemRequest.CatalogVersion = "EnableCosmetic";
		if (@class == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B5C RID: 2908 RVA: 0x000197D0 File Offset: 0x000179D0
	[Token(Token = "0x6000B5C")]
	[Address(RVA = "0x2225548", Offset = "0x2225548", VA = "0x2225548")]
	public void method_41(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "_Tint";
			long num = 1L;
			long num2 = 7L;
			this.bool_0 = (num != 0L);
			this.int_3 = (int)num2;
			return;
		}
		long num3 = 1L;
		this.bool_0 = (num3 != 0L);
	}

	// Token: 0x06000B5D RID: 2909 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000B5D")]
	[Address(RVA = "0x222576C", Offset = "0x222576C", VA = "0x222576C")]
	private void method_42()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B5E RID: 2910 RVA: 0x00019814 File Offset: 0x00017A14
	[Address(RVA = "0x2226280", Offset = "0x2226280", VA = "0x2226280")]
	[Token(Token = "0x6000B5E")]
	public void method_43(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "Damaged Arm";
			long num = 1L;
			this.genum4_0 = (DynamicCosmetics.GEnum4)num;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000B5F RID: 2911 RVA: 0x00019848 File Offset: 0x00017A48
	[Token(Token = "0x6000B5F")]
	[Address(RVA = "0x2222C58", Offset = "0x2222C58", VA = "0x2222C58")]
	private void method_44()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			DynamicCosmetics.<>c.<>9__28_1 = DynamicCosmetics.<>c.<>9;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000B60 RID: 2912 RVA: 0x00019878 File Offset: 0x00017A78
	[Address(RVA = "0x2226974", Offset = "0x2226974", VA = "0x2226974")]
	[Token(Token = "0x6000B60")]
	private IEnumerator method_45(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		new DynamicCosmetics.Class13((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x06000B61 RID: 2913 RVA: 0x000193F4 File Offset: 0x000175F4
	[Token(Token = "0x6000B61")]
	[Address(RVA = "0x22269EC", Offset = "0x22269EC", VA = "0x22269EC")]
	private void method_46(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B62 RID: 2914 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2226ACC", Offset = "0x2226ACC", VA = "0x2226ACC")]
	[Token(Token = "0x6000B62")]
	private void method_47()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B63 RID: 2915 RVA: 0x0001989C File Offset: 0x00017A9C
	[Address(RVA = "0x22274E4", Offset = "0x22274E4", VA = "0x22274E4")]
	[Token(Token = "0x6000B63")]
	public void method_48(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_26();
		long num = 0L;
		this.list_2 = num;
		this.int_0 = "Player";
		this.pvCache = "Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B64 RID: 2916 RVA: 0x0001942C File Offset: 0x0001762C
	[Address(RVA = "0x22277F4", Offset = "0x22277F4", VA = "0x22277F4")]
	[Token(Token = "0x6000B64")]
	private IEnumerator method_49(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000B65 RID: 2917 RVA: 0x000198F0 File Offset: 0x00017AF0
	[Token(Token = "0x6000B65")]
	[Address(RVA = "0x222786C", Offset = "0x222786C", VA = "0x222786C")]
	public void method_50(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_9();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "TurnAmount";
		purchaseItemRequest.CatalogVersion = "betaAgree";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B66 RID: 2918 RVA: 0x0001994C File Offset: 0x00017B4C
	[Token(Token = "0x6000B66")]
	[Address(RVA = "0x2227B7C", Offset = "0x2227B7C", VA = "0x2227B7C")]
	public void method_51(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B67 RID: 2919 RVA: 0x00019968 File Offset: 0x00017B68
	[Token(Token = "0x6000B67")]
	[Address(RVA = "0x2228044", Offset = "0x2228044", VA = "0x2228044")]
	public void method_52(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_10();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.";
		purchaseItemRequest.CatalogVersion = "Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B68 RID: 2920 RVA: 0x00019410 File Offset: 0x00017610
	[Address(RVA = "0x22283CC", Offset = "0x22283CC", VA = "0x22283CC")]
	[Token(Token = "0x6000B68")]
	public void method_53(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B69 RID: 2921 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x22288A4", Offset = "0x22288A4", VA = "0x22288A4")]
	[Token(Token = "0x6000B69")]
	private void method_54(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B6A RID: 2922 RVA: 0x000199C4 File Offset: 0x00017BC4
	[Address(RVA = "0x2228984", Offset = "0x2228984", VA = "0x2228984")]
	[Token(Token = "0x6000B6A")]
	public void method_55(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_68();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "BN";
		purchaseItemRequest.CatalogVersion = "CapuchinStore";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B6B RID: 2923 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2228EE4", Offset = "0x2228EE4", VA = "0x2228EE4")]
	[Token(Token = "0x6000B6B")]
	public void method_56()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B6C RID: 2924 RVA: 0x00019A20 File Offset: 0x00017C20
	[Address(RVA = "0x2229390", Offset = "0x2229390", VA = "0x2229390")]
	[Token(Token = "0x6000B6C")]
	public void method_57(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "This is the 2500 Bananas button, and it was just clicked";
			long num = 8L;
			this.int_3 = (int)num;
			return;
		}
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
	}

	// Token: 0x06000B6D RID: 2925 RVA: 0x00019A58 File Offset: 0x00017C58
	[Address(RVA = "0x22295BC", Offset = "0x22295BC", VA = "0x22295BC")]
	[Token(Token = "0x6000B6D")]
	public void method_58(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B6E RID: 2926 RVA: 0x00019A74 File Offset: 0x00017C74
	[Address(RVA = "0x2229A80", Offset = "0x2229A80", VA = "0x2229A80")]
	[Token(Token = "0x6000B6E")]
	public void method_59(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_60();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "Count of rooms ";
		purchaseItemRequest.CatalogVersion = "Purchased: ";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B6F RID: 2927 RVA: 0x0001958C File Offset: 0x0001778C
	[Address(RVA = "0x2229D90", Offset = "0x2229D90", VA = "0x2229D90")]
	[Token(Token = "0x6000B6F")]
	private void method_60()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000B70 RID: 2928 RVA: 0x00019AD0 File Offset: 0x00017CD0
	[Address(RVA = "0x221FB24", Offset = "0x221FB24", VA = "0x221FB24")]
	[Token(Token = "0x6000B70")]
	public void method_61(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		"ENABLE" == "ENABLE";
		if (string_0 == null)
		{
		}
	}

	// Token: 0x06000B71 RID: 2929 RVA: 0x000196E4 File Offset: 0x000178E4
	[Address(RVA = "0x2229F68", Offset = "0x2229F68", VA = "0x2229F68")]
	[Token(Token = "0x6000B71")]
	private void method_62()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
		long num = 2L;
		this.int_3 = (int)num;
	}

	// Token: 0x06000B72 RID: 2930 RVA: 0x0001942C File Offset: 0x0001762C
	[Address(RVA = "0x2229FD0", Offset = "0x2229FD0", VA = "0x2229FD0")]
	[Token(Token = "0x6000B72")]
	private IEnumerator method_63(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000B73 RID: 2931 RVA: 0x00019AF0 File Offset: 0x00017CF0
	[Address(RVA = "0x222A048", Offset = "0x222A048", VA = "0x222A048")]
	[Token(Token = "0x6000B73")]
	public void method_64(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "Cannot access index {0}. Buffer is empty";
			long num = 1L;
			this.genum4_0 = (DynamicCosmetics.GEnum4)num;
			this.bool_0 = (num != 0L);
			this.int_3 = (int)num;
			return;
		}
	}

	// Token: 0x06000B74 RID: 2932 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x222A278", Offset = "0x222A278", VA = "0x222A278")]
	[Token(Token = "0x6000B74")]
	public void method_65()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B75 RID: 2933 RVA: 0x00019B2C File Offset: 0x00017D2C
	[Address(RVA = "0x222A5C8", Offset = "0x222A5C8", VA = "0x222A5C8")]
	[Token(Token = "0x6000B75")]
	private void method_66()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
		long num = 6L;
		this.int_3 = (int)num;
	}

	// Token: 0x06000B76 RID: 2934 RVA: 0x00019B48 File Offset: 0x00017D48
	[Address(RVA = "0x222A634", Offset = "0x222A634", VA = "0x222A634")]
	[Token(Token = "0x6000B76")]
	public void method_67(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "TurnAmount";
			return;
		}
	}

	// Token: 0x06000B77 RID: 2935 RVA: 0x00019494 File Offset: 0x00017694
	[Address(RVA = "0x2228C94", Offset = "0x2228C94", VA = "0x2228C94")]
	[Token(Token = "0x6000B77")]
	private void method_68()
	{
		new GetUserInventoryRequest();
		Action<PlayFabError> <>9__28_ = DynamicCosmetics.<>c.<>9__28_1;
		if (<>9__28_ == null)
		{
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000B78 RID: 2936 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000B78")]
	[Address(RVA = "0x222A868", Offset = "0x222A868", VA = "0x222A868")]
	private void method_69()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B79 RID: 2937 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x222AF28", Offset = "0x222AF28", VA = "0x222AF28")]
	[Token(Token = "0x6000B79")]
	public void method_70()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B7A RID: 2938 RVA: 0x00019B6C File Offset: 0x00017D6C
	[Address(RVA = "0x222B2A4", Offset = "0x222B2A4", VA = "0x222B2A4")]
	[Token(Token = "0x6000B7A")]
	public void method_71(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_91();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "True";
		purchaseItemRequest.CatalogVersion = "M/d/yyyy";
		Action<PlayFabError> <>9__20_ = DynamicCosmetics.<>c.<>9__20_1;
		if (<>9__20_ == null)
		{
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B7B RID: 2939 RVA: 0x00019700 File Offset: 0x00017900
	[Address(RVA = "0x222B804", Offset = "0x222B804", VA = "0x222B804")]
	[Token(Token = "0x6000B7B")]
	private void method_72()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
		long num = 4L;
		this.int_3 = (int)num;
	}

	// Token: 0x06000B7C RID: 2940 RVA: 0x00019BCC File Offset: 0x00017DCC
	[Address(RVA = "0x222B868", Offset = "0x222B868", VA = "0x222B868")]
	[Token(Token = "0x6000B7C")]
	public void method_73(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "BN";
		purchaseItemRequest.CatalogVersion = "A Player has left the Room.";
		Action<PlayFabError> <>9__20_;
		DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
	}

	// Token: 0x06000B7D RID: 2941 RVA: 0x00019C1C File Offset: 0x00017E1C
	[Address(RVA = "0x222BBF0", Offset = "0x222BBF0", VA = "0x222BBF0")]
	[Token(Token = "0x6000B7D")]
	public void method_74(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_75();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "Cannot take elements from an empty buffer.";
		purchaseItemRequest.CatalogVersion = "forced knee retract";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B7E RID: 2942 RVA: 0x0001958C File Offset: 0x0001778C
	[Address(RVA = "0x222BF00", Offset = "0x222BF00", VA = "0x222BF00")]
	[Token(Token = "0x6000B7E")]
	private void method_75()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000B7F RID: 2943 RVA: 0x00019C78 File Offset: 0x00017E78
	[Address(RVA = "0x222C0D8", Offset = "0x222C0D8", VA = "0x222C0D8")]
	[Token(Token = "0x6000B7F")]
	public void method_76(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B80 RID: 2944 RVA: 0x00019C94 File Offset: 0x00017E94
	[Address(RVA = "0x222C59C", Offset = "0x222C59C", VA = "0x222C59C")]
	[Token(Token = "0x6000B80")]
	public void method_77(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "An error has occured while buying bananas, please restart your game and try again";
			long num = 2L;
			this.int_3 = (int)num;
			return;
		}
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
	}

	// Token: 0x06000B81 RID: 2945 RVA: 0x00019CCC File Offset: 0x00017ECC
	[Address(RVA = "0x222CC88", Offset = "0x222CC88", VA = "0x222CC88", Slot = "45")]
	[Token(Token = "0x6000B81")]
	public override void OnConnectedToMaster()
	{
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.method_68();
	}

	// Token: 0x06000B82 RID: 2946 RVA: 0x00019CE8 File Offset: 0x00017EE8
	[Address(RVA = "0x222CC94", Offset = "0x222CC94", VA = "0x222CC94")]
	[Token(Token = "0x6000B82")]
	public void method_78(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "Open";
			return;
		}
	}

	// Token: 0x06000B83 RID: 2947 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x222CEBC", Offset = "0x222CEBC", VA = "0x222CEBC")]
	[Token(Token = "0x6000B83")]
	private void method_79()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B84 RID: 2948 RVA: 0x00019D0C File Offset: 0x00017F0C
	[Address(RVA = "0x222D558", Offset = "0x222D558", VA = "0x222D558")]
	[Token(Token = "0x6000B84")]
	public void method_80(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "CapuchinStore";
			long num = 1L;
			long num2 = 8L;
			this.genum4_0 = (DynamicCosmetics.GEnum4)num;
			this.bool_0 = (num != 0L);
			this.int_3 = (int)num2;
			return;
		}
		long num3 = 1L;
		this.bool_0 = (num3 != 0L);
	}

	// Token: 0x06000B85 RID: 2949 RVA: 0x0001958C File Offset: 0x0001778C
	[Address(RVA = "0x222DC5C", Offset = "0x222DC5C", VA = "0x222DC5C")]
	[Token(Token = "0x6000B85")]
	private void method_81()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000B86 RID: 2950 RVA: 0x0000208D File Offset: 0x0000028D
	[Address(RVA = "0x222DE34", Offset = "0x222DE34", VA = "0x222DE34")]
	[Token(Token = "0x6000B86")]
	public DynamicCosmetics()
	{
	}

	// Token: 0x06000B87 RID: 2951 RVA: 0x000196C4 File Offset: 0x000178C4
	[Address(RVA = "0x222DE3C", Offset = "0x222DE3C", VA = "0x222DE3C")]
	[Token(Token = "0x6000B87")]
	private void method_82()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
	}

	// Token: 0x06000B88 RID: 2952 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x222E010", Offset = "0x222E010", VA = "0x222E010")]
	[Token(Token = "0x6000B88")]
	private void method_83()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B89 RID: 2953 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x222E6A0", Offset = "0x222E6A0", VA = "0x222E6A0")]
	[Token(Token = "0x6000B89")]
	private void method_84(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B8A RID: 2954 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x222E780", Offset = "0x222E780", VA = "0x222E780")]
	[Token(Token = "0x6000B8A")]
	private void method_85(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B8B RID: 2955 RVA: 0x00019D54 File Offset: 0x00017F54
	[Address(RVA = "0x222E860", Offset = "0x222E860", VA = "0x222E860")]
	[Token(Token = "0x6000B8B")]
	public void method_86(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_89();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "FLSPTLT";
		purchaseItemRequest.CatalogVersion = "Bare Torso";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B8C RID: 2956 RVA: 0x0001942C File Offset: 0x0001762C
	[Address(RVA = "0x222BB78", Offset = "0x222BB78", VA = "0x222BB78")]
	[Token(Token = "0x6000B8C")]
	private IEnumerator method_87(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000B8D RID: 2957 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x222ED44", Offset = "0x222ED44", VA = "0x222ED44")]
	[Token(Token = "0x6000B8D")]
	private void method_88(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000B8E RID: 2958 RVA: 0x000196C4 File Offset: 0x000178C4
	[Address(RVA = "0x222EB70", Offset = "0x222EB70", VA = "0x222EB70")]
	[Token(Token = "0x6000B8E")]
	private void method_89()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
	}

	// Token: 0x06000B8F RID: 2959 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x222EE24", Offset = "0x222EE24", VA = "0x222EE24")]
	[Token(Token = "0x6000B8F")]
	private void method_90()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B90 RID: 2960 RVA: 0x00019DB0 File Offset: 0x00017FB0
	[Address(RVA = "0x222B5B4", Offset = "0x222B5B4", VA = "0x222B5B4")]
	[Token(Token = "0x6000B90")]
	private void method_91()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 != null)
		{
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000B91 RID: 2961 RVA: 0x0001942C File Offset: 0x0001762C
	[Address(RVA = "0x2223F4C", Offset = "0x2223F4C", VA = "0x2223F4C")]
	[Token(Token = "0x6000B91")]
	private IEnumerator method_92(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000B92 RID: 2962 RVA: 0x00019DD4 File Offset: 0x00017FD4
	[Address(RVA = "0x222F4C0", Offset = "0x222F4C0", VA = "0x222F4C0")]
	[Token(Token = "0x6000B92")]
	public void method_93(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_82();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "Muted";
		purchaseItemRequest.CatalogVersion = "TurnAmount";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000B93 RID: 2963 RVA: 0x00019E30 File Offset: 0x00018030
	[Address(RVA = "0x222C7E0", Offset = "0x222C7E0", VA = "0x222C7E0")]
	[Token(Token = "0x6000B93")]
	public void method_94(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B94 RID: 2964 RVA: 0x00019E4C File Offset: 0x0001804C
	[Address(RVA = "0x222F7D0", Offset = "0x222F7D0", VA = "0x222F7D0")]
	[Token(Token = "0x6000B94")]
	public void method_95(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "TurnAmount";
			return;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000B95 RID: 2965 RVA: 0x00002337 File Offset: 0x00000537
	[Address(RVA = "0x222F9F4", Offset = "0x222F9F4", VA = "0x222F9F4")]
	[Token(Token = "0x6000B95")]
	private void method_96()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
	}

	// Token: 0x06000B96 RID: 2966 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x221F698", Offset = "0x221F698", VA = "0x221F698")]
	[Token(Token = "0x6000B96")]
	public void method_97()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B97 RID: 2967 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x222FA54", Offset = "0x222FA54", VA = "0x222FA54")]
	[Token(Token = "0x6000B97")]
	private void Update()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B98 RID: 2968 RVA: 0x00019E7C File Offset: 0x0001807C
	[Address(RVA = "0x223052C", Offset = "0x223052C", VA = "0x223052C")]
	[Token(Token = "0x6000B98")]
	private void method_98()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
		long num = 1L;
		this.int_3 = (int)num;
	}

	// Token: 0x06000B99 RID: 2969 RVA: 0x00019E98 File Offset: 0x00018098
	[Address(RVA = "0x2230590", Offset = "0x2230590", VA = "0x2230590")]
	[Token(Token = "0x6000B99")]
	public void method_99(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "Purchase For ";
			long num = 1L;
			this.genum4_0 = (DynamicCosmetics.GEnum4)num;
			this.bool_0 = (num != 0L);
			this.int_3 = (int)num;
			return;
		}
	}

	// Token: 0x06000B9A RID: 2970 RVA: 0x00019ED4 File Offset: 0x000180D4
	[Address(RVA = "0x22224A0", Offset = "0x22224A0", VA = "0x22224A0")]
	[Token(Token = "0x6000B9A")]
	public void method_100(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000B9B RID: 2971 RVA: 0x000196C4 File Offset: 0x000178C4
	[Address(RVA = "0x22307B4", Offset = "0x22307B4", VA = "0x22307B4")]
	[Token(Token = "0x6000B9B")]
	private void method_101()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
	}

	// Token: 0x06000B9C RID: 2972 RVA: 0x0001942C File Offset: 0x0001762C
	[Address(RVA = "0x222B78C", Offset = "0x222B78C", VA = "0x222B78C")]
	[Token(Token = "0x6000B9C")]
	private IEnumerator method_102(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000B9D RID: 2973 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2230988", Offset = "0x2230988", VA = "0x2230988")]
	[Token(Token = "0x6000B9D")]
	private void method_103()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B9E RID: 2974 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2231054", Offset = "0x2231054", VA = "0x2231054")]
	[Token(Token = "0x6000B9E")]
	private void method_104()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000B9F RID: 2975 RVA: 0x00019EF0 File Offset: 0x000180F0
	[Address(RVA = "0x222D79C", Offset = "0x222D79C", VA = "0x222D79C")]
	[Token(Token = "0x6000B9F")]
	public void method_105(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000BA0 RID: 2976 RVA: 0x0001942C File Offset: 0x0001762C
	[Address(RVA = "0x2228E6C", Offset = "0x2228E6C", VA = "0x2228E6C")]
	[Token(Token = "0x6000BA0")]
	private IEnumerator method_106(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000BA1 RID: 2977 RVA: 0x0001942C File Offset: 0x0001762C
	[Address(RVA = "0x22316EC", Offset = "0x22316EC", VA = "0x22316EC")]
	[Token(Token = "0x6000BA1")]
	private IEnumerator method_107(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000BA2 RID: 2978 RVA: 0x00019F0C File Offset: 0x0001810C
	[Address(RVA = "0x2231764", Offset = "0x2231764", VA = "0x2231764")]
	[Token(Token = "0x6000BA2")]
	public void method_108(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "Vector1_d371bd24217449349bd747533d51af6b";
			long num = 1L;
			this.genum4_0 = (DynamicCosmetics.GEnum4)num;
			return;
		}
	}

	// Token: 0x06000BA3 RID: 2979 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2230120", Offset = "0x2230120", VA = "0x2230120")]
	[Token(Token = "0x6000BA3")]
	public void method_109()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BA4 RID: 2980 RVA: 0x00019F3C File Offset: 0x0001813C
	[Address(RVA = "0x2231E5C", Offset = "0x2231E5C", VA = "0x2231E5C")]
	[Token(Token = "0x6000BA4")]
	public void method_110(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_28();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "Network Player";
		purchaseItemRequest.CatalogVersion = "Cannot take elements from an empty buffer.";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000BA5 RID: 2981 RVA: 0x0001942C File Offset: 0x0001762C
	[Address(RVA = "0x2228354", Offset = "0x2228354", VA = "0x2228354")]
	[Token(Token = "0x6000BA5")]
	private IEnumerator method_111(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000BA6 RID: 2982 RVA: 0x0001942C File Offset: 0x0001762C
	[Address(RVA = "0x2222118", Offset = "0x2222118", VA = "0x2222118")]
	[Token(Token = "0x6000BA6")]
	private IEnumerator method_112(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		DynamicCosmetics.Class13 @class = new DynamicCosmetics.Class13((int)0L);
		@class.button = purchaseCosmeticButton_0;
		throw new NullReferenceException();
	}

	// Token: 0x06000BA7 RID: 2983 RVA: 0x00019554 File Offset: 0x00017754
	[Address(RVA = "0x223216C", Offset = "0x223216C", VA = "0x223216C")]
	[Token(Token = "0x6000BA7")]
	public void method_113(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000BA8 RID: 2984 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x2232614", Offset = "0x2232614", VA = "0x2232614")]
	[Token(Token = "0x6000BA8")]
	private void method_114(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000BA9 RID: 2985 RVA: 0x00019F98 File Offset: 0x00018198
	[Address(RVA = "0x22326F4", Offset = "0x22326F4", VA = "0x22326F4")]
	[Token(Token = "0x6000BA9")]
	public void method_115(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_10();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "Creating and loadingtexture";
		purchaseItemRequest.CatalogVersion = "Start Gamemode";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000BAA RID: 2986 RVA: 0x00019FF4 File Offset: 0x000181F4
	[Address(RVA = "0x2232A04", Offset = "0x2232A04", VA = "0x2232A04")]
	[Token(Token = "0x6000BAA")]
	public void method_116(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "Player";
			long num = 1L;
			this.genum4_0 = (DynamicCosmetics.GEnum4)num;
			return;
		}
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
	}

	// Token: 0x06000BAB RID: 2987 RVA: 0x0001A02C File Offset: 0x0001822C
	[Address(RVA = "0x22264CC", Offset = "0x22264CC", VA = "0x22264CC")]
	[Token(Token = "0x6000BAB")]
	public void method_117(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000BAC RID: 2988 RVA: 0x0001A048 File Offset: 0x00018248
	[Address(RVA = "0x2232C1C", Offset = "0x2232C1C", VA = "0x2232C1C")]
	[Token(Token = "0x6000BAC")]
	public void method_118(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "closeToObject";
			string_ == "hh:mmtt";
			long num = 1L;
			this.genum4_0 = (DynamicCosmetics.GEnum4)num;
			this.bool_0 = (num != 0L);
		}
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
	}

	// Token: 0x06000BAD RID: 2989 RVA: 0x0001958C File Offset: 0x0001778C
	[Address(RVA = "0x2232E4C", Offset = "0x2232E4C", VA = "0x2232E4C")]
	[Token(Token = "0x6000BAD")]
	private void method_119()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000BAE RID: 2990 RVA: 0x0001A094 File Offset: 0x00018294
	[Address(RVA = "0x2233024", Offset = "0x2233024", VA = "0x2233024")]
	[Token(Token = "0x6000BAE")]
	public void method_120(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "Name Changing Error. Error: ";
			return;
		}
	}

	// Token: 0x06000BAF RID: 2991 RVA: 0x0001A0B8 File Offset: 0x000182B8
	[Address(RVA = "0x2233260", Offset = "0x2233260", VA = "0x2233260")]
	[Token(Token = "0x6000BAF")]
	public void method_121(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "Hats";
			return;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000BB0 RID: 2992 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2233484", Offset = "0x2233484", VA = "0x2233484")]
	[Token(Token = "0x6000BB0")]
	private void method_122()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BB1 RID: 2993 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2224B5C", Offset = "0x2224B5C", VA = "0x2224B5C")]
	[Token(Token = "0x6000BB1")]
	public void method_123()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BB2 RID: 2994 RVA: 0x0001A0E8 File Offset: 0x000182E8
	[Address(RVA = "0x2220224", Offset = "0x2220224", VA = "0x2220224")]
	[Token(Token = "0x6000BB2")]
	public void method_124(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000BB3 RID: 2995 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2233B24", Offset = "0x2233B24", VA = "0x2233B24")]
	[Token(Token = "0x6000BB3")]
	private void method_125()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BB4 RID: 2996 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x22341B4", Offset = "0x22341B4", VA = "0x22341B4")]
	[Token(Token = "0x6000BB4")]
	private void method_126()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BB5 RID: 2997 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2234858", Offset = "0x2234858", VA = "0x2234858")]
	[Token(Token = "0x6000BB5")]
	public void method_127()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BB6 RID: 2998 RVA: 0x00019410 File Offset: 0x00017610
	[Address(RVA = "0x2234BD0", Offset = "0x2234BD0", VA = "0x2234BD0")]
	[Token(Token = "0x6000BB6")]
	public void method_128(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000BB7 RID: 2999 RVA: 0x0001A104 File Offset: 0x00018304
	[Address(RVA = "0x22350A8", Offset = "0x22350A8", VA = "0x22350A8")]
	[Token(Token = "0x6000BB7")]
	public void method_129(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_75();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "A new Player joined a Room.";
		purchaseItemRequest.CatalogVersion = "Charged!";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000BB8 RID: 3000 RVA: 0x0001A160 File Offset: 0x00018360
	[Address(RVA = "0x22353B8", Offset = "0x22353B8", VA = "0x22353B8")]
	[Token(Token = "0x6000BB8")]
	public void method_130(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "A Player has left the Room.";
			return;
		}
	}

	// Token: 0x06000BB9 RID: 3001 RVA: 0x0001A184 File Offset: 0x00018384
	[Address(RVA = "0x22355F8", Offset = "0x22355F8", VA = "0x22355F8")]
	[Token(Token = "0x6000BB9")]
	public void method_131(PurchaseCosmeticButton purchaseCosmeticButton_0)
	{
		this.method_101();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		long itemId = 0L;
		purchaseItemRequest.ItemId = itemId;
		purchaseItemRequest.VirtualCurrency = "cosmos";
		purchaseItemRequest.CatalogVersion = "FingerTip";
		if (DynamicCosmetics.<>c.<>9__20_1 == null)
		{
			Action<PlayFabError> <>9__20_;
			DynamicCosmetics.<>c.<>9__20_1 = <>9__20_;
		}
	}

	// Token: 0x06000BBA RID: 3002 RVA: 0x0001A1E0 File Offset: 0x000183E0
	[Address(RVA = "0x2221F44", Offset = "0x2221F44", VA = "0x2221F44")]
	[Token(Token = "0x6000BBA")]
	private void method_132()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x06000BBB RID: 3003 RVA: 0x0001A1F4 File Offset: 0x000183F4
	[Address(RVA = "0x2235908", Offset = "0x2235908", VA = "0x2235908")]
	[Token(Token = "0x6000BBB")]
	public void method_133(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000BBC RID: 3004 RVA: 0x0001A210 File Offset: 0x00018410
	[Address(RVA = "0x2235DC8", Offset = "0x2235DC8", VA = "0x2235DC8")]
	[Token(Token = "0x6000BBC")]
	public void method_134(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "PRESS AGAIN TO CONFIRM";
			long num = 1L;
			this.int_3 = (int)num;
			return;
		}
	}

	// Token: 0x06000BBD RID: 3005 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2236004", Offset = "0x2236004", VA = "0x2236004")]
	[Token(Token = "0x6000BBD")]
	public void method_135()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BBE RID: 3006 RVA: 0x000196C4 File Offset: 0x000178C4
	[Token(Token = "0x6000BBE")]
	[Address(RVA = "0x2236378", Offset = "0x2236378", VA = "0x2236378")]
	private void method_136()
	{
		new GetUserInventoryRequest();
		if (DynamicCosmetics.<>c.<>9__28_1 == null)
		{
			Action<PlayFabError> <>9__28_;
			DynamicCosmetics.<>c.<>9__28_1 = <>9__28_;
		}
	}

	// Token: 0x06000BBF RID: 3007 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x223654C", Offset = "0x223654C", VA = "0x223654C")]
	[Token(Token = "0x6000BBF")]
	private void method_137(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000BC0 RID: 3008 RVA: 0x00019B2C File Offset: 0x00017D2C
	[Token(Token = "0x6000BC0")]
	[Address(RVA = "0x223662C", Offset = "0x223662C", VA = "0x223662C")]
	private void method_138()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
		long num = 6L;
		this.int_3 = (int)num;
	}

	// Token: 0x06000BC1 RID: 3009 RVA: 0x0000233F File Offset: 0x0000053F
	[Token(Token = "0x6000BC1")]
	[Address(RVA = "0x2236698", Offset = "0x2236698", VA = "0x2236698")]
	private void method_139()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
		this.int_3 = 5;
	}

	// Token: 0x06000BC2 RID: 3010 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x2236704", Offset = "0x2236704", VA = "0x2236704")]
	[Token(Token = "0x6000BC2")]
	private void method_140(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000BC3 RID: 3011 RVA: 0x0001A240 File Offset: 0x00018440
	[Token(Token = "0x6000BC3")]
	[Address(RVA = "0x22367E4", Offset = "0x22367E4", VA = "0x22367E4")]
	public void method_141(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000BC4 RID: 3012 RVA: 0x00019700 File Offset: 0x00017900
	[Address(RVA = "0x2236CAC", Offset = "0x2236CAC", VA = "0x2236CAC")]
	[Token(Token = "0x6000BC4")]
	private void method_142()
	{
		DynamicCosmetics.dynamicCosmetics_0 = this;
		long num = 4L;
		this.int_3 = (int)num;
	}

	// Token: 0x06000BC5 RID: 3013 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x2236D10", Offset = "0x2236D10", VA = "0x2236D10")]
	[Token(Token = "0x6000BC5")]
	private void method_143(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000BC6 RID: 3014 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000BC6")]
	[Address(RVA = "0x2236DF0", Offset = "0x2236DF0", VA = "0x2236DF0")]
	public void method_144()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BC7 RID: 3015 RVA: 0x0001A25C File Offset: 0x0001845C
	[Token(Token = "0x6000BC7")]
	[Address(RVA = "0x2231998", Offset = "0x2231998", VA = "0x2231998")]
	public void method_145(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000BC8 RID: 3016 RVA: 0x000193F4 File Offset: 0x000175F4
	[Address(RVA = "0x2237298", Offset = "0x2237298", VA = "0x2237298")]
	[Token(Token = "0x6000BC8")]
	private void method_146(GetUserInventoryResult getUserInventoryResult_0)
	{
		Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
		this.int_0 = virtualCurrency;
	}

	// Token: 0x06000BC9 RID: 3017 RVA: 0x0001A240 File Offset: 0x00018440
	[Address(RVA = "0x221E2B8", Offset = "0x221E2B8", VA = "0x221E2B8")]
	[Token(Token = "0x6000BC9")]
	public void method_147(string string_0, DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		if (string_0 != null && string_0 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06000BCA RID: 3018 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000BCA")]
	[Address(RVA = "0x222715C", Offset = "0x222715C", VA = "0x222715C")]
	public void method_148()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000BCB RID: 3019 RVA: 0x0001A278 File Offset: 0x00018478
	[Address(RVA = "0x2225E2C", Offset = "0x2225E2C", VA = "0x2225E2C")]
	[Token(Token = "0x6000BCB")]
	public void method_149()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num == 0L)
		{
			ThrowHelper.ThrowArgumentOutOfRangeException();
			ThrowHelper.ThrowArgumentOutOfRangeException();
			return;
		}
	}

	// Token: 0x06000BCC RID: 3020 RVA: 0x0001A298 File Offset: 0x00018498
	[Address(RVA = "0x2237378", Offset = "0x2237378", VA = "0x2237378")]
	[Token(Token = "0x6000BCC")]
	public void method_150(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "'s Grabber is not assigned.";
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000BCD RID: 3021 RVA: 0x0001A2C8 File Offset: 0x000184C8
	[Token(Token = "0x6000BCD")]
	[Address(RVA = "0x22375C0", Offset = "0x22375C0", VA = "0x22375C0")]
	public void method_151(DynamicCosmeticsButton dynamicCosmeticsButton_0)
	{
		string string_ = dynamicCosmeticsButton_0.string_0;
		if (string_ != null)
		{
			string_ == "";
			long num = 1L;
			long num2 = 4L;
			this.bool_0 = (num != 0L);
			this.int_3 = (int)num2;
			return;
		}
	}

	// Token: 0x0400019E RID: 414
	[Token(Token = "0x400019E")]
	public static DynamicCosmetics dynamicCosmetics_0;

	// Token: 0x0400019F RID: 415
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400019F")]
	public List<DynamicCosmetics.CosmeticItem> list_0;

	// Token: 0x040001A0 RID: 416
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001A0")]
	[Space]
	public List<DynamicCosmetics.CosmeticItem> list_1;

	// Token: 0x040001A1 RID: 417
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40001A1")]
	public List<DynamicCosmetics.CosmeticItem> list_2;

	// Token: 0x040001A2 RID: 418
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40001A2")]
	public List<DynamicCosmetics.CosmeticItem> list_3;

	// Token: 0x040001A3 RID: 419
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40001A3")]
	public List<DynamicCosmetics.CosmeticItem> list_4;

	// Token: 0x040001A4 RID: 420
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40001A4")]
	public int int_0;

	// Token: 0x040001A5 RID: 421
	[Token(Token = "0x40001A5")]
	[FieldOffset(Offset = "0x50")]
	public TMP_Text tmp_Text_0;

	// Token: 0x040001A6 RID: 422
	[Space]
	[Token(Token = "0x40001A6")]
	[FieldOffset(Offset = "0x58")]
	public DynamicParent[] dynamicParent_0;

	// Token: 0x040001A7 RID: 423
	[FieldOffset(Offset = "0x60")]
	[Space]
	[Token(Token = "0x40001A7")]
	public DynamicCosmetics.GEnum4 genum4_0;

	// Token: 0x040001A8 RID: 424
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x40001A8")]
	public NetworkPlayerSpawner networkPlayerSpawner_0;

	// Token: 0x040001A9 RID: 425
	[Token(Token = "0x40001A9")]
	[FieldOffset(Offset = "0x70")]
	private PhotonView photonView_0;

	// Token: 0x040001AA RID: 426
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x40001AA")]
	public DynamicCosmetics[] dynamicCosmetics_1;

	// Token: 0x040001AB RID: 427
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x40001AB")]
	public List<DynamicCosmetics.CosmeticItem> list_5;

	// Token: 0x040001AC RID: 428
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x40001AC")]
	public int int_1;

	// Token: 0x040001AD RID: 429
	[FieldOffset(Offset = "0x8C")]
	[Token(Token = "0x40001AD")]
	public int int_2;

	// Token: 0x040001AE RID: 430
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x40001AE")]
	public int int_3;

	// Token: 0x040001AF RID: 431
	[FieldOffset(Offset = "0x94")]
	[Token(Token = "0x40001AF")]
	[HideInInspector]
	public bool bool_0;

	// Token: 0x02000052 RID: 82
	[Token(Token = "0x2000052")]
	[Serializable]
	public struct CosmeticItem
	{
		// Token: 0x040001B0 RID: 432
		[Token(Token = "0x40001B0")]
		[FieldOffset(Offset = "0x0")]
		public string itemName;

		// Token: 0x040001B1 RID: 433
		[Space]
		[Token(Token = "0x40001B1")]
		[FieldOffset(Offset = "0x8")]
		public DynamicCosmetics.GEnum4 itemCategory;

		// Token: 0x040001B2 RID: 434
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40001B2")]
		[Space]
		public string displayName;
	}

	// Token: 0x02000053 RID: 83
	[Token(Token = "0x2000053")]
	public enum GEnum4
	{
		// Token: 0x040001B4 RID: 436
		[Token(Token = "0x40001B4")]
		const_0,
		// Token: 0x040001B5 RID: 437
		[Token(Token = "0x40001B5")]
		const_1,
		// Token: 0x040001B6 RID: 438
		[Token(Token = "0x40001B6")]
		const_2
	}

	// Token: 0x02000054 RID: 84
	[CompilerGenerated]
	[Token(Token = "0x2000054")]
	private sealed class Class12
	{
		// Token: 0x06000BCE RID: 3022 RVA: 0x000020B4 File Offset: 0x000002B4
		[Token(Token = "0x6000BCE")]
		[Address(RVA = "0x1070BE4", Offset = "0x1070BE4", VA = "0x1070BE4")]
		public Class12()
		{
		}

		// Token: 0x06000BCF RID: 3023 RVA: 0x0001A300 File Offset: 0x00018500
		[Token(Token = "0x6000BCF")]
		[Address(RVA = "0x1070BEC", Offset = "0x1070BEC", VA = "0x1070BEC")]
		internal void method_0(PurchaseItemResult result)
		{
			DynamicCosmetics dynamicCosmetics = this.<>4__this;
			long bool_ = 1L;
			dynamicCosmetics.bool_0 = (bool_ != 0L);
			this.<>4__this.method_68();
		}

		// Token: 0x040001B7 RID: 439
		[Token(Token = "0x40001B7")]
		[FieldOffset(Offset = "0x10")]
		public PurchaseCosmeticButton button;

		// Token: 0x040001B8 RID: 440
		[Token(Token = "0x40001B8")]
		[FieldOffset(Offset = "0x18")]
		public DynamicCosmetics <>4__this;
	}
}
