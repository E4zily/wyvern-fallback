﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000044 RID: 68
[Token(Token = "0x2000044")]
public class SwimmyV2 : MonoBehaviour
{
	// Token: 0x060008BE RID: 2238 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008BE")]
	[Address(RVA = "0x3085A10", Offset = "0x3085A10", VA = "0x3085A10")]
	public void method_0(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008BF RID: 2239 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3085D7C", Offset = "0x3085D7C", VA = "0x3085D7C")]
	[Token(Token = "0x60008BF")]
	public void method_1(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008C0 RID: 2240 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008C0")]
	[Address(RVA = "0x30860EC", Offset = "0x30860EC", VA = "0x30860EC")]
	public void method_2(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008C1 RID: 2241 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008C1")]
	[Address(RVA = "0x3086408", Offset = "0x3086408", VA = "0x3086408")]
	public void method_3(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008C2 RID: 2242 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008C2")]
	[Address(RVA = "0x3086728", Offset = "0x3086728", VA = "0x3086728")]
	public void method_4(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008C3 RID: 2243 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008C3")]
	[Address(RVA = "0x3086A9C", Offset = "0x3086A9C", VA = "0x3086A9C")]
	public void method_5(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008C4 RID: 2244 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3086DC0", Offset = "0x3086DC0", VA = "0x3086DC0")]
	[Token(Token = "0x60008C4")]
	public void method_6(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008C5 RID: 2245 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x30870E0", Offset = "0x30870E0", VA = "0x30870E0")]
	[Token(Token = "0x60008C5")]
	public void method_7(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008C6 RID: 2246 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x30873FC", Offset = "0x30873FC", VA = "0x30873FC")]
	[Token(Token = "0x60008C6")]
	public SwimmyV2()
	{
	}

	// Token: 0x060008C7 RID: 2247 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008C7")]
	[Address(RVA = "0x3087404", Offset = "0x3087404", VA = "0x3087404")]
	public void method_8(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008C8 RID: 2248 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008C8")]
	[Address(RVA = "0x3087774", Offset = "0x3087774", VA = "0x3087774")]
	public void method_9(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008C9 RID: 2249 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008C9")]
	[Address(RVA = "0x3087AE0", Offset = "0x3087AE0", VA = "0x3087AE0")]
	public void OnTriggerExit(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008CA RID: 2250 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008CA")]
	[Address(RVA = "0x3087DE8", Offset = "0x3087DE8", VA = "0x3087DE8")]
	public void OnTriggerEnter(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008CB RID: 2251 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x308813C", Offset = "0x308813C", VA = "0x308813C")]
	[Token(Token = "0x60008CB")]
	public void method_10(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0400014A RID: 330
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400014A")]
	public Rigidbody rigidbody_0;

	// Token: 0x0400014B RID: 331
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400014B")]
	public Transform transform_0;

	// Token: 0x0400014C RID: 332
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400014C")]
	public Rigidbody rigidbody_1;

	// Token: 0x0400014D RID: 333
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400014D")]
	public Rigidbody rigidbody_2;

	// Token: 0x0400014E RID: 334
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400014E")]
	public AudioLowPassFilter audioLowPassFilter_0;

	// Token: 0x0400014F RID: 335
	[Token(Token = "0x400014F")]
	[FieldOffset(Offset = "0x40")]
	public bool bool_0;

	// Token: 0x04000150 RID: 336
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000150")]
	public Transform transform_1;

	// Token: 0x04000151 RID: 337
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000151")]
	public Swimmy swimmy_0;

	// Token: 0x04000152 RID: 338
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000152")]
	public GameObject gameObject_0;

	// Token: 0x04000153 RID: 339
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000153")]
	public GameObject gameObject_1;

	// Token: 0x04000154 RID: 340
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000154")]
	public GameObject gameObject_2;

	// Token: 0x04000155 RID: 341
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000155")]
	public bool bool_1;

	// Token: 0x04000156 RID: 342
	[Token(Token = "0x4000156")]
	[FieldOffset(Offset = "0x71")]
	public bool bool_2;

	// Token: 0x04000157 RID: 343
	[Token(Token = "0x4000157")]
	[FieldOffset(Offset = "0x72")]
	public bool bool_3;

	// Token: 0x04000158 RID: 344
	[Token(Token = "0x4000158")]
	[FieldOffset(Offset = "0x78")]
	public GameObject gameObject_3;
}
