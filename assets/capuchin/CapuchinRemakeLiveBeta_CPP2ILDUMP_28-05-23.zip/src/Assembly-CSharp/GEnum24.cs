﻿using System;
using Cpp2IlInjected;

// Token: 0x0200016D RID: 365
[Token(Token = "0x200016D")]
public enum GEnum24
{
	// Token: 0x040009CE RID: 2510
	[Token(Token = "0x40009CE")]
	const_0,
	// Token: 0x040009CF RID: 2511
	[Token(Token = "0x40009CF")]
	const_1,
	// Token: 0x040009D0 RID: 2512
	[Token(Token = "0x40009D0")]
	const_2,
	// Token: 0x040009D1 RID: 2513
	[Token(Token = "0x40009D1")]
	const_3,
	// Token: 0x040009D2 RID: 2514
	[Token(Token = "0x40009D2")]
	const_4,
	// Token: 0x040009D3 RID: 2515
	[Token(Token = "0x40009D3")]
	const_5,
	// Token: 0x040009D4 RID: 2516
	[Token(Token = "0x40009D4")]
	const_6,
	// Token: 0x040009D5 RID: 2517
	[Token(Token = "0x40009D5")]
	const_7,
	// Token: 0x040009D6 RID: 2518
	[Token(Token = "0x40009D6")]
	const_8,
	// Token: 0x040009D7 RID: 2519
	[Token(Token = "0x40009D7")]
	const_9,
	// Token: 0x040009D8 RID: 2520
	[Token(Token = "0x40009D8")]
	const_10,
	// Token: 0x040009D9 RID: 2521
	[Token(Token = "0x40009D9")]
	const_11,
	// Token: 0x040009DA RID: 2522
	[Token(Token = "0x40009DA")]
	const_12,
	// Token: 0x040009DB RID: 2523
	[Token(Token = "0x40009DB")]
	const_13,
	// Token: 0x040009DC RID: 2524
	[Token(Token = "0x40009DC")]
	const_14,
	// Token: 0x040009DD RID: 2525
	[Token(Token = "0x40009DD")]
	const_15,
	// Token: 0x040009DE RID: 2526
	[Token(Token = "0x40009DE")]
	const_16,
	// Token: 0x040009DF RID: 2527
	[Token(Token = "0x40009DF")]
	const_17,
	// Token: 0x040009E0 RID: 2528
	[Token(Token = "0x40009E0")]
	const_18,
	// Token: 0x040009E1 RID: 2529
	[Token(Token = "0x40009E1")]
	const_19,
	// Token: 0x040009E2 RID: 2530
	[Token(Token = "0x40009E2")]
	const_20,
	// Token: 0x040009E3 RID: 2531
	[Token(Token = "0x40009E3")]
	const_21
}
