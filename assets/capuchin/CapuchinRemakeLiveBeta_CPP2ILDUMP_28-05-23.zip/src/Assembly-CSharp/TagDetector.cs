﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200000F RID: 15
[Token(Token = "0x200000F")]
public class TagDetector : MonoBehaviourPunCallbacks
{
	// Token: 0x060001B5 RID: 437 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001B5")]
	[Address(RVA = "0x2D1CC5C", Offset = "0x2D1CC5C", VA = "0x2D1CC5C")]
	private void method_0(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001B6 RID: 438 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D1D25C", Offset = "0x2D1D25C", VA = "0x2D1D25C")]
	[Token(Token = "0x60001B6")]
	private void method_1(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001B7 RID: 439 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D1D850", Offset = "0x2D1D850", VA = "0x2D1D850")]
	[Token(Token = "0x60001B7")]
	private void method_2(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001B8 RID: 440 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D1DE48", Offset = "0x2D1DE48", VA = "0x2D1DE48")]
	[Token(Token = "0x60001B8")]
	private void method_3(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001B9 RID: 441 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D1E444", Offset = "0x2D1E444", VA = "0x2D1E444")]
	[Token(Token = "0x60001B9")]
	private void method_4(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001BA RID: 442 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D1EA44", Offset = "0x2D1EA44", VA = "0x2D1EA44")]
	[Token(Token = "0x60001BA")]
	private void method_5(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001BB RID: 443 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D1F03C", Offset = "0x2D1F03C", VA = "0x2D1F03C")]
	[Token(Token = "0x60001BB")]
	private void method_6(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001BC RID: 444 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001BC")]
	[Address(RVA = "0x2D1F63C", Offset = "0x2D1F63C", VA = "0x2D1F63C")]
	private void method_7(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001BD RID: 445 RVA: 0x0000208D File Offset: 0x0000028D
	[Token(Token = "0x60001BD")]
	[Address(RVA = "0x2D1FC38", Offset = "0x2D1FC38", VA = "0x2D1FC38")]
	public TagDetector()
	{
	}

	// Token: 0x060001BE RID: 446 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D1FC40", Offset = "0x2D1FC40", VA = "0x2D1FC40")]
	[Token(Token = "0x60001BE")]
	private void method_8(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001BF RID: 447 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D2023C", Offset = "0x2D2023C", VA = "0x2D2023C")]
	[Token(Token = "0x60001BF")]
	private void method_9(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001C0 RID: 448 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D2083C", Offset = "0x2D2083C", VA = "0x2D2083C")]
	[Token(Token = "0x60001C0")]
	private void method_10(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001C1 RID: 449 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001C1")]
	[Address(RVA = "0x2D20E38", Offset = "0x2D20E38", VA = "0x2D20E38")]
	private void method_11(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001C2")]
	[Address(RVA = "0x2D21434", Offset = "0x2D21434", VA = "0x2D21434")]
	private void OnTriggerEnter(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001C3 RID: 451 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D21A24", Offset = "0x2D21A24", VA = "0x2D21A24")]
	[Token(Token = "0x60001C3")]
	private void method_12(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001C4 RID: 452 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001C4")]
	[Address(RVA = "0x2D22024", Offset = "0x2D22024", VA = "0x2D22024")]
	private void method_13(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001C5 RID: 453 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001C5")]
	[Address(RVA = "0x2D22624", Offset = "0x2D22624", VA = "0x2D22624")]
	private void method_14(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001C6 RID: 454 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001C6")]
	[Address(RVA = "0x2D22B4C", Offset = "0x2D22B4C", VA = "0x2D22B4C")]
	private void method_15(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001C7 RID: 455 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D23144", Offset = "0x2D23144", VA = "0x2D23144")]
	[Token(Token = "0x60001C7")]
	private void method_16(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001C8 RID: 456 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D23740", Offset = "0x2D23740", VA = "0x2D23740")]
	[Token(Token = "0x60001C8")]
	private void method_17(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001C9 RID: 457 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001C9")]
	[Address(RVA = "0x2D23D40", Offset = "0x2D23D40", VA = "0x2D23D40")]
	private void method_18(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001CA RID: 458 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D2433C", Offset = "0x2D2433C", VA = "0x2D2433C")]
	[Token(Token = "0x60001CA")]
	private void method_19(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001CB RID: 459 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001CB")]
	[Address(RVA = "0x2D24934", Offset = "0x2D24934", VA = "0x2D24934")]
	private void method_20(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001CC RID: 460 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001CC")]
	[Address(RVA = "0x2D24F2C", Offset = "0x2D24F2C", VA = "0x2D24F2C")]
	private void method_21(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001CD RID: 461 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001CD")]
	[Address(RVA = "0x2D25440", Offset = "0x2D25440", VA = "0x2D25440")]
	private void method_22(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001CE RID: 462 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001CE")]
	[Address(RVA = "0x2D2595C", Offset = "0x2D2595C", VA = "0x2D2595C")]
	private void method_23(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001CF RID: 463 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001CF")]
	[Address(RVA = "0x2D25E80", Offset = "0x2D25E80", VA = "0x2D25E80")]
	private void method_24(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001D0 RID: 464 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001D0")]
	[Address(RVA = "0x2D26478", Offset = "0x2D26478", VA = "0x2D26478")]
	private void method_25(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001D1 RID: 465 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001D1")]
	[Address(RVA = "0x2D26A70", Offset = "0x2D26A70", VA = "0x2D26A70")]
	private void method_26(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001D2 RID: 466 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D26F90", Offset = "0x2D26F90", VA = "0x2D26F90")]
	[Token(Token = "0x60001D2")]
	private void method_27(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001D3 RID: 467 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001D3")]
	[Address(RVA = "0x2D27590", Offset = "0x2D27590", VA = "0x2D27590")]
	private void method_28(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001D4 RID: 468 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001D4")]
	[Address(RVA = "0x2D27AB0", Offset = "0x2D27AB0", VA = "0x2D27AB0")]
	private void method_29(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001D5 RID: 469 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001D5")]
	[Address(RVA = "0x2D27FD0", Offset = "0x2D27FD0", VA = "0x2D27FD0")]
	private void method_30(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001D6 RID: 470 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D285CC", Offset = "0x2D285CC", VA = "0x2D285CC")]
	[Token(Token = "0x60001D6")]
	private void method_31(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001D7 RID: 471 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001D7")]
	[Address(RVA = "0x2D28BB0", Offset = "0x2D28BB0", VA = "0x2D28BB0")]
	private void method_32(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001D8 RID: 472 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001D8")]
	[Address(RVA = "0x2D291AC", Offset = "0x2D291AC", VA = "0x2D291AC")]
	private void method_33(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001D9 RID: 473 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001D9")]
	[Address(RVA = "0x2D297A8", Offset = "0x2D297A8", VA = "0x2D297A8")]
	private void method_34(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001DA RID: 474 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D29CD0", Offset = "0x2D29CD0", VA = "0x2D29CD0")]
	[Token(Token = "0x60001DA")]
	private void method_35(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001DB RID: 475 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D2A1F4", Offset = "0x2D2A1F4", VA = "0x2D2A1F4")]
	[Token(Token = "0x60001DB")]
	private void method_36(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001DC RID: 476 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001DC")]
	[Address(RVA = "0x2D2A7F0", Offset = "0x2D2A7F0", VA = "0x2D2A7F0")]
	private void method_37(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001DD RID: 477 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001DD")]
	[Address(RVA = "0x2D2ADD8", Offset = "0x2D2ADD8", VA = "0x2D2ADD8")]
	private void method_38(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001DE RID: 478 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001DE")]
	[Address(RVA = "0x2D2B3D0", Offset = "0x2D2B3D0", VA = "0x2D2B3D0")]
	private void method_39(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060001DF RID: 479 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60001DF")]
	[Address(RVA = "0x2D2B8F0", Offset = "0x2D2B8F0", VA = "0x2D2B8F0")]
	private void method_40(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0400003E RID: 62
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400003E")]
	public PhotonView photonView_0;

	// Token: 0x0400003F RID: 63
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400003F")]
	public PhotonView photonView_1;

	// Token: 0x04000040 RID: 64
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000040")]
	public TagManager tagManager_0;
}
