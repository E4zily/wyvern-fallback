﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000029 RID: 41
[Token(Token = "0x2000029")]
public class DoorLerp : MonoBehaviour
{
	// Token: 0x060004F6 RID: 1270 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60004F6")]
	[Address(RVA = "0x2EA844C", Offset = "0x2EA844C", VA = "0x2EA844C")]
	public void method_0(bool bool_2)
	{
	}

	// Token: 0x060004F7 RID: 1271 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA8458", Offset = "0x2EA8458", VA = "0x2EA8458")]
	[Token(Token = "0x60004F7")]
	public void method_1(bool bool_2)
	{
	}

	// Token: 0x060004F8 RID: 1272 RVA: 0x0000E0DC File Offset: 0x0000C2DC
	[Address(RVA = "0x2EA8464", Offset = "0x2EA8464", VA = "0x2EA8464")]
	[Token(Token = "0x60004F8")]
	private void method_2()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 1L;
			audioSource.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		AudioSource audioSource2 = this.audioSource_0;
		long enabled2 = 1L;
		long num = 1L;
		audioSource2.enabled = (enabled2 != 0L);
		this.bool_1 = (num != 0L);
	}

	// Token: 0x060004F9 RID: 1273 RVA: 0x0000E1A4 File Offset: 0x0000C3A4
	[Token(Token = "0x60004F9")]
	[Address(RVA = "0x2EA8748", Offset = "0x2EA8748", VA = "0x2EA8748")]
	private void method_3()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 0L;
			audioSource.enabled = (enabled != 0L);
			if (!this.bool_1)
			{
				this.audioSource_1.Play();
				long num = 1L;
				this.bool_1 = (num != 0L);
				return;
			}
		}
		else
		{
			Vector3 position5 = this.transform_1.position;
			Transform transform3 = this.transform_0;
			Vector3 position6 = transform3.position;
			Vector3 position7 = this.transform_1.position;
			float deltaTime2 = Time.deltaTime;
			Mathf.Clamp01(deltaTime2);
			AudioSource audioSource2 = this.audioSource_0;
			long enabled2 = 1L;
			long num2 = 1L;
			audioSource2.enabled = (enabled2 != 0L);
			this.bool_1 = (num2 != 0L);
		}
	}

	// Token: 0x060004FA RID: 1274 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA89FC", Offset = "0x2EA89FC", VA = "0x2EA89FC")]
	[Token(Token = "0x60004FA")]
	public void method_4(bool bool_2)
	{
	}

	// Token: 0x060004FB RID: 1275 RVA: 0x0000E28C File Offset: 0x0000C48C
	[Address(RVA = "0x2EA8A08", Offset = "0x2EA8A08", VA = "0x2EA8A08")]
	[Token(Token = "0x60004FB")]
	private void method_5()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 0L;
			audioSource.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		AudioSource audioSource2 = this.audioSource_0;
		long enabled2 = 0L;
		audioSource2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060004FC RID: 1276 RVA: 0x0000E348 File Offset: 0x0000C548
	[Address(RVA = "0x2EA8D10", Offset = "0x2EA8D10", VA = "0x2EA8D10")]
	[Token(Token = "0x60004FC")]
	private void method_6()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 1L;
			long num = 1L;
			audioSource.enabled = (enabled != 0L);
			this.bool_1 = (num != 0L);
			return;
		}
		Vector3 position5 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		AudioSource audioSource2 = this.audioSource_0;
		long enabled2 = 0L;
		audioSource2.enabled = (enabled2 != 0L);
	}

	// Token: 0x060004FD RID: 1277 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA901C", Offset = "0x2EA901C", VA = "0x2EA901C")]
	[Token(Token = "0x60004FD")]
	public void method_7(bool bool_2)
	{
	}

	// Token: 0x060004FE RID: 1278 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA9028", Offset = "0x2EA9028", VA = "0x2EA9028")]
	[Token(Token = "0x60004FE")]
	public void method_8(bool bool_2)
	{
	}

	// Token: 0x060004FF RID: 1279 RVA: 0x0000E410 File Offset: 0x0000C610
	[Address(RVA = "0x2EA9034", Offset = "0x2EA9034", VA = "0x2EA9034")]
	[Token(Token = "0x60004FF")]
	private void method_9()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 0L;
			audioSource.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		AudioSource audioSource2 = this.audioSource_0;
		long enabled2 = 0L;
		audioSource2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000500 RID: 1280 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA9318", Offset = "0x2EA9318", VA = "0x2EA9318")]
	[Token(Token = "0x6000500")]
	public void method_10(bool bool_2)
	{
	}

	// Token: 0x06000501 RID: 1281 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000501")]
	[Address(RVA = "0x2EA9324", Offset = "0x2EA9324", VA = "0x2EA9324")]
	public DoorLerp()
	{
	}

	// Token: 0x06000502 RID: 1282 RVA: 0x0000E4CC File Offset: 0x0000C6CC
	[Token(Token = "0x6000502")]
	[Address(RVA = "0x2EA932C", Offset = "0x2EA932C", VA = "0x2EA932C")]
	private void method_11()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 1L;
			long num = 1L;
			audioSource.enabled = (enabled != 0L);
			this.bool_1 = (num != 0L);
			return;
		}
		Vector3 position4 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		AudioSource audioSource2 = this.audioSource_0;
		long enabled2 = 0L;
		audioSource2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x0000E588 File Offset: 0x0000C788
	[Address(RVA = "0x2EA9638", Offset = "0x2EA9638", VA = "0x2EA9638")]
	[Token(Token = "0x6000503")]
	private void method_12()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 0L;
			audioSource.enabled = (enabled != 0L);
			long num = 1L;
			this.bool_1 = (num != 0L);
			return;
		}
		Vector3 position5 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		long enabled2 = 0L;
		AudioSource audioSource2 = this.audioSource_0;
		long num2 = 1L;
		audioSource2.enabled = (enabled2 != 0L);
		this.bool_1 = (num2 != 0L);
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x0000E65C File Offset: 0x0000C85C
	[Address(RVA = "0x2EA9924", Offset = "0x2EA9924", VA = "0x2EA9924")]
	[Token(Token = "0x6000504")]
	private void method_13()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 1L;
			audioSource.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.transform_1.position;
		Vector3 position6 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		AudioSource audioSource2 = this.audioSource_0;
		long enabled2 = 1L;
		long num = 1L;
		audioSource2.enabled = (enabled2 != 0L);
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x0000E714 File Offset: 0x0000C914
	[Address(RVA = "0x2EA9C34", Offset = "0x2EA9C34", VA = "0x2EA9C34")]
	[Token(Token = "0x6000505")]
	private void method_14()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 1L;
			long num = 1L;
			audioSource.enabled = (enabled != 0L);
			this.bool_1 = (num != 0L);
			return;
		}
		Vector3 position5 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		AudioSource audioSource2 = this.audioSource_0;
		long enabled2 = 0L;
		audioSource2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000506 RID: 1286 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000506")]
	[Address(RVA = "0x2EA9ED0", Offset = "0x2EA9ED0", VA = "0x2EA9ED0")]
	public void method_15(bool bool_2)
	{
	}

	// Token: 0x06000507 RID: 1287 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA9EDC", Offset = "0x2EA9EDC", VA = "0x2EA9EDC")]
	[Token(Token = "0x6000507")]
	public void method_16(bool bool_2)
	{
	}

	// Token: 0x06000508 RID: 1288 RVA: 0x0000E7DC File Offset: 0x0000C9DC
	[Address(RVA = "0x2EA9EE8", Offset = "0x2EA9EE8", VA = "0x2EA9EE8")]
	[Token(Token = "0x6000508")]
	private void method_17()
	{
		do
		{
			Transform transform = this.transform_0;
			bool flag = this.bool_0;
			Vector3 position = transform.position;
			if (!flag)
			{
				goto IL_3D;
			}
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
		}
		while (this.transform_2 != null);
		return;
		IL_3D:
		Vector3 position4 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float deltaTime = Time.deltaTime;
		Mathf.Clamp01(deltaTime);
		AudioSource audioSource = this.audioSource_0;
		long enabled = 0L;
		audioSource.enabled = (enabled != 0L);
	}

	// Token: 0x06000509 RID: 1289 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EAA0F8", Offset = "0x2EAA0F8", VA = "0x2EAA0F8")]
	[Token(Token = "0x6000509")]
	public void method_18(bool bool_2)
	{
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EAA104", Offset = "0x2EAA104", VA = "0x2EAA104")]
	[Token(Token = "0x600050A")]
	public void method_19(bool bool_2)
	{
	}

	// Token: 0x0600050B RID: 1291 RVA: 0x0000E874 File Offset: 0x0000CA74
	[Address(RVA = "0x2EAA110", Offset = "0x2EAA110", VA = "0x2EAA110")]
	[Token(Token = "0x600050B")]
	private void method_20()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 1L;
			audioSource.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		AudioSource audioSource2 = this.audioSource_0;
		long enabled2 = 1L;
		audioSource2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EAA3F4", Offset = "0x2EAA3F4", VA = "0x2EAA3F4")]
	[Token(Token = "0x600050C")]
	public void method_21(bool bool_2)
	{
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EAA400", Offset = "0x2EAA400", VA = "0x2EAA400")]
	[Token(Token = "0x600050D")]
	public void method_22(bool bool_2)
	{
	}

	// Token: 0x0600050E RID: 1294 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600050E")]
	[Address(RVA = "0x2EAA40C", Offset = "0x2EAA40C", VA = "0x2EAA40C")]
	public void method_23(bool bool_2)
	{
	}

	// Token: 0x0600050F RID: 1295 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600050F")]
	[Address(RVA = "0x2EAA418", Offset = "0x2EAA418", VA = "0x2EAA418")]
	public void method_24(bool bool_2)
	{
	}

	// Token: 0x06000510 RID: 1296 RVA: 0x0000E930 File Offset: 0x0000CB30
	[Token(Token = "0x6000510")]
	[Address(RVA = "0x2EAA424", Offset = "0x2EAA424", VA = "0x2EAA424")]
	private void method_25()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 0L;
			audioSource.enabled = (enabled != 0L);
			if (!this.bool_1)
			{
				this.audioSource_1.Play();
				return;
			}
		}
		else
		{
			Vector3 position5 = this.transform_1.position;
			Transform transform3 = this.transform_0;
			Vector3 position6 = transform3.position;
			Vector3 position7 = this.transform_1.position;
			float deltaTime2 = Time.deltaTime;
			Mathf.Clamp01(deltaTime2);
			AudioSource audioSource2 = this.audioSource_0;
			long enabled2 = 0L;
			audioSource2.enabled = (enabled2 != 0L);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x06000511 RID: 1297 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EAA6D0", Offset = "0x2EAA6D0", VA = "0x2EAA6D0")]
	[Token(Token = "0x6000511")]
	public void method_26(bool bool_2)
	{
	}

	// Token: 0x06000512 RID: 1298 RVA: 0x0000EA0C File Offset: 0x0000CC0C
	[Address(RVA = "0x2EAA6DC", Offset = "0x2EAA6DC", VA = "0x2EAA6DC")]
	[Token(Token = "0x6000512")]
	private void method_27()
	{
		Transform transform = this.transform_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_2.position;
		float deltaTime = Time.deltaTime;
		Mathf.Clamp01(deltaTime);
	}

	// Token: 0x06000513 RID: 1299 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EAA9D8", Offset = "0x2EAA9D8", VA = "0x2EAA9D8")]
	[Token(Token = "0x6000513")]
	public void method_28(bool bool_2)
	{
	}

	// Token: 0x06000514 RID: 1300 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000514")]
	[Address(RVA = "0x2EAA9E4", Offset = "0x2EAA9E4", VA = "0x2EAA9E4")]
	public void method_29(bool bool_2)
	{
	}

	// Token: 0x06000515 RID: 1301 RVA: 0x0000EA60 File Offset: 0x0000CC60
	[Address(RVA = "0x2EAA9F0", Offset = "0x2EAA9F0", VA = "0x2EAA9F0")]
	[Token(Token = "0x6000515")]
	private void method_30()
	{
		do
		{
			Transform transform = this.transform_0;
			bool flag = this.bool_0;
			Vector3 position = transform.position;
			if (!flag)
			{
				goto IL_3D;
			}
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
		}
		while (this.transform_2 != null);
		return;
		IL_3D:
		Vector3 position4 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float deltaTime = Time.deltaTime;
		Mathf.Clamp01(deltaTime);
		AudioSource audioSource = this.audioSource_0;
		long enabled = 0L;
		audioSource.enabled = (enabled != 0L);
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000516 RID: 1302 RVA: 0x0000EB00 File Offset: 0x0000CD00
	[Token(Token = "0x6000516")]
	[Address(RVA = "0x2EAAC00", Offset = "0x2EAAC00", VA = "0x2EAAC00")]
	private void Update()
	{
		do
		{
			Transform transform = this.transform_0;
			bool flag = this.bool_0;
			Vector3 position = transform.position;
			if (!flag)
			{
				goto IL_3D;
			}
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
		}
		while (this.transform_2 != null);
		return;
		IL_3D:
		Vector3 position4 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float deltaTime = Time.deltaTime;
		Mathf.Clamp01(deltaTime);
		AudioSource audioSource = this.audioSource_0;
		long enabled = 1L;
		audioSource.enabled = (enabled != 0L);
	}

	// Token: 0x06000517 RID: 1303 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000517")]
	[Address(RVA = "0x2EAAE10", Offset = "0x2EAAE10", VA = "0x2EAAE10")]
	public void method_31(bool bool_2)
	{
	}

	// Token: 0x06000518 RID: 1304 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000518")]
	[Address(RVA = "0x2EAAE1C", Offset = "0x2EAAE1C", VA = "0x2EAAE1C")]
	public void method_32(bool bool_2)
	{
	}

	// Token: 0x06000519 RID: 1305 RVA: 0x0000EB98 File Offset: 0x0000CD98
	[Address(RVA = "0x2EAAE28", Offset = "0x2EAAE28", VA = "0x2EAAE28")]
	[Token(Token = "0x6000519")]
	private void method_33()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			AudioSource audioSource = this.audioSource_0;
			long enabled = 0L;
			audioSource.enabled = (enabled != 0L);
			return;
		}
		Vector3 position5 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		AudioSource audioSource2 = this.audioSource_0;
		long enabled2 = 1L;
		audioSource2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600051A RID: 1306 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600051A")]
	[Address(RVA = "0x2EAB0BC", Offset = "0x2EAB0BC", VA = "0x2EAB0BC")]
	public void method_34(bool bool_2)
	{
	}

	// Token: 0x0600051B RID: 1307 RVA: 0x0000EC54 File Offset: 0x0000CE54
	[Address(RVA = "0x2EAB0C8", Offset = "0x2EAB0C8", VA = "0x2EAB0C8")]
	[Token(Token = "0x600051B")]
	private void method_35()
	{
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 position = transform.position;
		if (flag)
		{
			Vector3 position2 = this.transform_2.position;
			Transform transform2 = this.transform_0;
			Vector3 position3 = transform2.position;
			Vector3 position4 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
			return;
		}
		Vector3 position5 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		float deltaTime2 = Time.deltaTime;
		Mathf.Clamp01(deltaTime2);
		AudioSource audioSource = this.audioSource_0;
		long enabled = 0L;
		audioSource.enabled = (enabled != 0L);
	}

	// Token: 0x040000BE RID: 190
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000BE")]
	public Transform transform_0;

	// Token: 0x040000BF RID: 191
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000BF")]
	public bool bool_0;

	// Token: 0x040000C0 RID: 192
	[Token(Token = "0x40000C0")]
	[FieldOffset(Offset = "0x28")]
	public Transform transform_1;

	// Token: 0x040000C1 RID: 193
	[Token(Token = "0x40000C1")]
	[FieldOffset(Offset = "0x30")]
	public Transform transform_2;

	// Token: 0x040000C2 RID: 194
	[Token(Token = "0x40000C2")]
	[FieldOffset(Offset = "0x38")]
	public float float_0;

	// Token: 0x040000C3 RID: 195
	[Token(Token = "0x40000C3")]
	[FieldOffset(Offset = "0x3C")]
	public float float_1;

	// Token: 0x040000C4 RID: 196
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40000C4")]
	public float float_2;

	// Token: 0x040000C5 RID: 197
	[Token(Token = "0x40000C5")]
	[FieldOffset(Offset = "0x48")]
	public AudioSource audioSource_0;

	// Token: 0x040000C6 RID: 198
	[Token(Token = "0x40000C6")]
	[FieldOffset(Offset = "0x50")]
	public AudioSource audioSource_1;

	// Token: 0x040000C7 RID: 199
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40000C7")]
	private bool bool_1;
}
