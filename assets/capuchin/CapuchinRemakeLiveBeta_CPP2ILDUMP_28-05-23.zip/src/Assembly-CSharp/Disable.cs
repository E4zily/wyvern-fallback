﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000BA RID: 186
[Token(Token = "0x20000BA")]
public class Disable : MonoBehaviour
{
	// Token: 0x06001A91 RID: 6801 RVA: 0x00034848 File Offset: 0x00032A48
	[Address(RVA = "0x2EA56BC", Offset = "0x2EA56BC", VA = "0x2EA56BC")]
	[Token(Token = "0x6001A91")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("closeToObject");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A92 RID: 6802 RVA: 0x00034878 File Offset: 0x00032A78
	[Address(RVA = "0x2EA5754", Offset = "0x2EA5754", VA = "0x2EA5754")]
	[Token(Token = "0x6001A92")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A93 RID: 6803 RVA: 0x000348A8 File Offset: 0x00032AA8
	[Address(RVA = "0x2EA57EC", Offset = "0x2EA57EC", VA = "0x2EA57EC")]
	[Token(Token = "0x6001A93")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A94 RID: 6804 RVA: 0x000348D8 File Offset: 0x00032AD8
	[Address(RVA = "0x2EA5884", Offset = "0x2EA5884", VA = "0x2EA5884")]
	[Token(Token = "0x6001A94")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("false");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A95 RID: 6805 RVA: 0x00034908 File Offset: 0x00032B08
	[Address(RVA = "0x2EA591C", Offset = "0x2EA591C", VA = "0x2EA591C")]
	[Token(Token = "0x6001A95")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("NetworkPlayer");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A96 RID: 6806 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2EA59B4", Offset = "0x2EA59B4", VA = "0x2EA59B4")]
	[Token(Token = "0x6001A96")]
	public Disable()
	{
	}

	// Token: 0x06001A97 RID: 6807 RVA: 0x00034938 File Offset: 0x00032B38
	[Address(RVA = "0x2EA59BC", Offset = "0x2EA59BC", VA = "0x2EA59BC")]
	[Token(Token = "0x6001A97")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FLSPTLT");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A98 RID: 6808 RVA: 0x00034968 File Offset: 0x00032B68
	[Address(RVA = "0x2EA5A54", Offset = "0x2EA5A54", VA = "0x2EA5A54")]
	[Token(Token = "0x6001A98")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Charging...");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A99 RID: 6809 RVA: 0x00034998 File Offset: 0x00032B98
	[Address(RVA = "0x2EA5AEC", Offset = "0x2EA5AEC", VA = "0x2EA5AEC")]
	[Token(Token = "0x6001A99")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A9A RID: 6810 RVA: 0x000349C8 File Offset: 0x00032BC8
	[Address(RVA = "0x2EA5B84", Offset = "0x2EA5B84", VA = "0x2EA5B84")]
	[Token(Token = "0x6001A9A")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Game Started");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A9B RID: 6811 RVA: 0x000349F8 File Offset: 0x00032BF8
	[Address(RVA = "0x2EA5C1C", Offset = "0x2EA5C1C", VA = "0x2EA5C1C")]
	[Token(Token = "0x6001A9B")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ENABLE");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A9C RID: 6812 RVA: 0x00034A28 File Offset: 0x00032C28
	[Address(RVA = "0x2EA5CB4", Offset = "0x2EA5CB4", VA = "0x2EA5CB4")]
	[Token(Token = "0x6001A9C")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001A9D RID: 6813 RVA: 0x00034A58 File Offset: 0x00032C58
	[Address(RVA = "0x2EA5D4C", Offset = "0x2EA5D4C", VA = "0x2EA5D4C")]
	[Token(Token = "0x6001A9D")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Adding ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0400036F RID: 879
	[Token(Token = "0x400036F")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;
}
