﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000F9 RID: 249
[Token(Token = "0x20000F9")]
public class TVController : MonoBehaviour
{
	// Token: 0x06002589 RID: 9609 RVA: 0x00045E30 File Offset: 0x00044030
	[Address(RVA = "0x308CBA0", Offset = "0x308CBA0", VA = "0x308CBA0")]
	[Token(Token = "0x6002589")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("Collided");
		}
		if (this.bool_1)
		{
			return;
		}
	}

	// Token: 0x0600258A RID: 9610 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x308CCBC", Offset = "0x308CCBC", VA = "0x308CCBC")]
	[Token(Token = "0x600258A")]
	public TVController()
	{
	}

	// Token: 0x0600258B RID: 9611 RVA: 0x00045E70 File Offset: 0x00044070
	[Address(RVA = "0x308CCC4", Offset = "0x308CCC4", VA = "0x308CCC4")]
	[Token(Token = "0x600258B")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("ӵٟٜࢣ");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x0600258C RID: 9612 RVA: 0x00045EC8 File Offset: 0x000440C8
	[Address(RVA = "0x308CDE0", Offset = "0x308CDE0", VA = "0x308CDE0")]
	[Token(Token = "0x600258C")]
	public void method_2(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("true");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x0600258D RID: 9613 RVA: 0x00045F1C File Offset: 0x0004411C
	[Address(RVA = "0x308CEFC", Offset = "0x308CEFC", VA = "0x308CEFC")]
	[Token(Token = "0x600258D")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("typesOfTalk");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x0600258E RID: 9614 RVA: 0x00045F74 File Offset: 0x00044174
	[Address(RVA = "0x308D01C", Offset = "0x308D01C", VA = "0x308D01C")]
	[Token(Token = "0x600258E")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("cosmos");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x0600258F RID: 9615 RVA: 0x00045FCC File Offset: 0x000441CC
	[Address(RVA = "0x308D13C", Offset = "0x308D13C", VA = "0x308D13C")]
	[Token(Token = "0x600258F")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("Removing ");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x06002590 RID: 9616 RVA: 0x00046024 File Offset: 0x00044224
	[Address(RVA = "0x308D25C", Offset = "0x308D25C", VA = "0x308D25C")]
	[Token(Token = "0x6002590")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (!this.bool_0)
		{
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x06002591 RID: 9617 RVA: 0x0004606C File Offset: 0x0004426C
	[Address(RVA = "0x308D378", Offset = "0x308D378", VA = "0x308D378")]
	[Token(Token = "0x6002591")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x06002592 RID: 9618 RVA: 0x00046024 File Offset: 0x00044224
	[Address(RVA = "0x308D498", Offset = "0x308D498", VA = "0x308D498")]
	[Token(Token = "0x6002592")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (!this.bool_0)
		{
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x06002593 RID: 9619 RVA: 0x000460C4 File Offset: 0x000442C4
	[Address(RVA = "0x308D5B8", Offset = "0x308D5B8", VA = "0x308D5B8")]
	[Token(Token = "0x6002593")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("BN");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x06002594 RID: 9620 RVA: 0x0004611C File Offset: 0x0004431C
	[Address(RVA = "0x308D6D4", Offset = "0x308D6D4", VA = "0x308D6D4")]
	[Token(Token = "0x6002594")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06002595 RID: 9621 RVA: 0x0004613C File Offset: 0x0004433C
	[Address(RVA = "0x308D7F4", Offset = "0x308D7F4", VA = "0x308D7F4")]
	[Token(Token = "0x6002595")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (!this.bool_0)
		{
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x06002596 RID: 9622 RVA: 0x00046184 File Offset: 0x00044384
	[Address(RVA = "0x308D914", Offset = "0x308D914", VA = "0x308D914")]
	[Token(Token = "0x6002596")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("HandR");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x06002597 RID: 9623 RVA: 0x000461DC File Offset: 0x000443DC
	[Address(RVA = "0x308DA34", Offset = "0x308DA34", VA = "0x308DA34")]
	[Token(Token = "0x6002597")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("Display Name Changed!");
		}
		AudioSource audioSource = this.audioSource_0;
		long mute = 0L;
		bool mute2 = audioSource.mute;
		audioSource.mute = (mute != 0L);
	}

	// Token: 0x06002598 RID: 9624 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x308DB54", Offset = "0x308DB54", VA = "0x308DB54")]
	[Token(Token = "0x6002598")]
	public void OnTriggerEnter(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002599 RID: 9625 RVA: 0x0004622C File Offset: 0x0004442C
	[Address(RVA = "0x308DC74", Offset = "0x308DC74", VA = "0x308DC74")]
	[Token(Token = "0x6002599")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (!this.bool_0)
		{
		}
		if (this.bool_1)
		{
			return;
		}
	}

	// Token: 0x0600259A RID: 9626 RVA: 0x0004625C File Offset: 0x0004445C
	[Address(RVA = "0x308DD90", Offset = "0x308DD90", VA = "0x308DD90")]
	[Token(Token = "0x600259A")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("SaveHeight");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x0600259B RID: 9627 RVA: 0x000462B4 File Offset: 0x000444B4
	[Address(RVA = "0x308DEB0", Offset = "0x308DEB0", VA = "0x308DEB0")]
	[Token(Token = "0x600259B")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("Player");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x0600259C RID: 9628 RVA: 0x0004630C File Offset: 0x0004450C
	[Address(RVA = "0x308DFD0", Offset = "0x308DFD0", VA = "0x308DFD0")]
	[Token(Token = "0x600259C")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("Tagged");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x0600259D RID: 9629 RVA: 0x00046364 File Offset: 0x00044564
	[Address(RVA = "0x308E0F0", Offset = "0x308E0F0", VA = "0x308E0F0")]
	[Token(Token = "0x600259D")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("Squeeze");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x0600259E RID: 9630 RVA: 0x000463BC File Offset: 0x000445BC
	[Token(Token = "0x600259E")]
	[Address(RVA = "0x308E210", Offset = "0x308E210", VA = "0x308E210")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("Left a room");
		}
		if (this.bool_1)
		{
			return;
		}
	}

	// Token: 0x0600259F RID: 9631 RVA: 0x000463FC File Offset: 0x000445FC
	[Token(Token = "0x600259F")]
	[Address(RVA = "0x308E32C", Offset = "0x308E32C", VA = "0x308E32C")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("RainAndThunderWeather");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060025A0 RID: 9632 RVA: 0x00045F1C File Offset: 0x0004411C
	[Token(Token = "0x60025A0")]
	[Address(RVA = "0x308E448", Offset = "0x308E448", VA = "0x308E448")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("typesOfTalk");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060025A1 RID: 9633 RVA: 0x00046454 File Offset: 0x00044654
	[Token(Token = "0x60025A1")]
	[Address(RVA = "0x308E564", Offset = "0x308E564", VA = "0x308E564")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("[InputHelpers.IsPressed] The value of <button> is out or the supported range.");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060025A2 RID: 9634 RVA: 0x000462B4 File Offset: 0x000444B4
	[Token(Token = "0x60025A2")]
	[Address(RVA = "0x308E684", Offset = "0x308E684", VA = "0x308E684")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("Player");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060025A3 RID: 9635 RVA: 0x00045EC8 File Offset: 0x000440C8
	[Address(RVA = "0x308E7A4", Offset = "0x308E7A4", VA = "0x308E7A4")]
	[Token(Token = "0x60025A3")]
	public void method_24(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("true");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060025A4 RID: 9636 RVA: 0x000464AC File Offset: 0x000446AC
	[Address(RVA = "0x308E8C4", Offset = "0x308E8C4", VA = "0x308E8C4")]
	[Token(Token = "0x60025A4")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.tvmanager_0.StartCoroutine("username");
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x060025A5 RID: 9637 RVA: 0x00046024 File Offset: 0x00044224
	[Address(RVA = "0x308E9E0", Offset = "0x308E9E0", VA = "0x308E9E0")]
	[Token(Token = "0x60025A5")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (!this.bool_0)
		{
		}
		if (this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			long mute = 0L;
			bool mute2 = audioSource.mute;
			audioSource.mute = (mute != 0L);
			return;
		}
	}

	// Token: 0x040004D5 RID: 1237
	[Token(Token = "0x40004D5")]
	[FieldOffset(Offset = "0x18")]
	public bool bool_0;

	// Token: 0x040004D6 RID: 1238
	[Token(Token = "0x40004D6")]
	[FieldOffset(Offset = "0x19")]
	public bool bool_1;

	// Token: 0x040004D7 RID: 1239
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004D7")]
	public AudioSource audioSource_0;

	// Token: 0x040004D8 RID: 1240
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40004D8")]
	public TVManager tvmanager_0;
}
