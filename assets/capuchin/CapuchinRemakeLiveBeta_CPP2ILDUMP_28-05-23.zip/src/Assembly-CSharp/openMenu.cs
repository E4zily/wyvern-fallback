﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200010C RID: 268
[Token(Token = "0x200010C")]
public class openMenu : MonoBehaviour
{
	// Token: 0x06002851 RID: 10321 RVA: 0x000585F4 File Offset: 0x000567F4
	[Token(Token = "0x6002851")]
	[Address(RVA = "0x353889C", Offset = "0x353889C", VA = "0x353889C")]
	private void method_0()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002852 RID: 10322 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002852")]
	[Address(RVA = "0x3538950", Offset = "0x3538950", VA = "0x3538950")]
	public void method_1()
	{
	}

	// Token: 0x06002853 RID: 10323 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002853")]
	[Address(RVA = "0x3538958", Offset = "0x3538958", VA = "0x3538958")]
	public void method_2()
	{
	}

	// Token: 0x06002854 RID: 10324 RVA: 0x00058624 File Offset: 0x00056824
	[Token(Token = "0x6002854")]
	[Address(RVA = "0x3538960", Offset = "0x3538960", VA = "0x3538960")]
	public void method_3()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("Unpause");
	}

	// Token: 0x06002855 RID: 10325 RVA: 0x0005865C File Offset: 0x0005685C
	[Address(RVA = "0x3538A08", Offset = "0x3538A08", VA = "0x3538A08")]
	[Token(Token = "0x6002855")]
	public void method_4()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		long num = 1L;
		gameObject2.SetActive(active2 != 0L);
		this.bool_0 = (num != 0L);
		Debug.Log("Player");
	}

	// Token: 0x06002856 RID: 10326 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002856")]
	[Address(RVA = "0x3538AB4", Offset = "0x3538AB4", VA = "0x3538AB4")]
	public void method_5()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002857 RID: 10327 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002857")]
	[Address(RVA = "0x3538B68", Offset = "0x3538B68", VA = "0x3538B68")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002858 RID: 10328 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3538C1C", Offset = "0x3538C1C", VA = "0x3538C1C")]
	[Token(Token = "0x6002858")]
	public void method_6()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002859 RID: 10329 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002859")]
	[Address(RVA = "0x3538CD0", Offset = "0x3538CD0", VA = "0x3538CD0")]
	public void method_7()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600285A RID: 10330 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600285A")]
	[Address(RVA = "0x3538D84", Offset = "0x3538D84", VA = "0x3538D84")]
	public void method_8()
	{
	}

	// Token: 0x0600285B RID: 10331 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600285B")]
	[Address(RVA = "0x3538D8C", Offset = "0x3538D8C", VA = "0x3538D8C")]
	public void method_9()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600285C RID: 10332 RVA: 0x000586A0 File Offset: 0x000568A0
	[Address(RVA = "0x3538E40", Offset = "0x3538E40", VA = "0x3538E40")]
	[Token(Token = "0x600285C")]
	public void method_10()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("You Look Like Butt");
	}

	// Token: 0x0600285D RID: 10333 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3538EE8", Offset = "0x3538EE8", VA = "0x3538EE8")]
	[Token(Token = "0x600285D")]
	public void method_11()
	{
	}

	// Token: 0x0600285E RID: 10334 RVA: 0x000586D8 File Offset: 0x000568D8
	[Token(Token = "0x600285E")]
	[Address(RVA = "0x3538EF0", Offset = "0x3538EF0", VA = "0x3538EF0")]
	public void method_12()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		long num = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		this.bool_0 = (num != 0L);
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
	}

	// Token: 0x0600285F RID: 10335 RVA: 0x0005871C File Offset: 0x0005691C
	[Address(RVA = "0x3538F9C", Offset = "0x3538F9C", VA = "0x3538F9C")]
	[Token(Token = "0x600285F")]
	private void Update()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002860 RID: 10336 RVA: 0x0005873C File Offset: 0x0005693C
	[Address(RVA = "0x353907C", Offset = "0x353907C", VA = "0x353907C")]
	[Token(Token = "0x6002860")]
	private void method_13()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002861 RID: 10337 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002861")]
	[Address(RVA = "0x3539130", Offset = "0x3539130", VA = "0x3539130")]
	public void method_14()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002862 RID: 10338 RVA: 0x0005876C File Offset: 0x0005696C
	[Token(Token = "0x6002862")]
	[Address(RVA = "0x35391E4", Offset = "0x35391E4", VA = "0x35391E4")]
	public void method_15()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log(".Please press the button if you would like to play alone");
	}

	// Token: 0x06002863 RID: 10339 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x353928C", Offset = "0x353928C", VA = "0x353928C")]
	[Token(Token = "0x6002863")]
	public void method_16()
	{
	}

	// Token: 0x06002864 RID: 10340 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002864")]
	[Address(RVA = "0x3539294", Offset = "0x3539294", VA = "0x3539294")]
	public void method_17()
	{
	}

	// Token: 0x06002865 RID: 10341 RVA: 0x000587A4 File Offset: 0x000569A4
	[Token(Token = "0x6002865")]
	[Address(RVA = "0x353929C", Offset = "0x353929C", VA = "0x353929C")]
	private void method_18()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002866 RID: 10342 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3539350", Offset = "0x3539350", VA = "0x3539350")]
	[Token(Token = "0x6002866")]
	public void method_19()
	{
	}

	// Token: 0x06002867 RID: 10343 RVA: 0x000587D4 File Offset: 0x000569D4
	[Address(RVA = "0x3539358", Offset = "0x3539358", VA = "0x3539358")]
	[Token(Token = "0x6002867")]
	public void method_20()
	{
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002868 RID: 10344 RVA: 0x000587EC File Offset: 0x000569EC
	[Token(Token = "0x6002868")]
	[Address(RVA = "0x3539364", Offset = "0x3539364", VA = "0x3539364")]
	public void method_21()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("_Tint");
	}

	// Token: 0x06002869 RID: 10345 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x353940C", Offset = "0x353940C", VA = "0x353940C")]
	[Token(Token = "0x6002869")]
	public void method_22()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600286A RID: 10346 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x35394C0", Offset = "0x35394C0", VA = "0x35394C0")]
	[Token(Token = "0x600286A")]
	public void method_23()
	{
	}

	// Token: 0x0600286B RID: 10347 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600286B")]
	[Address(RVA = "0x35394C8", Offset = "0x35394C8", VA = "0x35394C8")]
	public void method_24()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600286C RID: 10348 RVA: 0x00058824 File Offset: 0x00056A24
	[Token(Token = "0x600286C")]
	[Address(RVA = "0x353957C", Offset = "0x353957C", VA = "0x353957C")]
	public void method_25()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		long num = 1L;
		gameObject2.SetActive(active2 != 0L);
		this.bool_0 = (num != 0L);
		Debug.Log("PlayerHead");
	}

	// Token: 0x0600286D RID: 10349 RVA: 0x00058868 File Offset: 0x00056A68
	[Token(Token = "0x600286D")]
	[Address(RVA = "0x3539628", Offset = "0x3539628", VA = "0x3539628")]
	public void method_26()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		long num = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		this.bool_0 = (num != 0L);
		Debug.Log("username");
	}

	// Token: 0x0600286E RID: 10350 RVA: 0x0005873C File Offset: 0x0005693C
	[Address(RVA = "0x35396D4", Offset = "0x35396D4", VA = "0x35396D4")]
	[Token(Token = "0x600286E")]
	private void method_27()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600286F RID: 10351 RVA: 0x000588AC File Offset: 0x00056AAC
	[Address(RVA = "0x3539788", Offset = "0x3539788", VA = "0x3539788")]
	[Token(Token = "0x600286F")]
	private void method_28()
	{
	}

	// Token: 0x06002870 RID: 10352 RVA: 0x000588BC File Offset: 0x00056ABC
	[Address(RVA = "0x3539854", Offset = "0x3539854", VA = "0x3539854")]
	[Token(Token = "0x6002870")]
	public void method_29()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("typesOfTalk");
	}

	// Token: 0x06002871 RID: 10353 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002871")]
	[Address(RVA = "0x35398FC", Offset = "0x35398FC", VA = "0x35398FC")]
	public void method_30()
	{
	}

	// Token: 0x06002872 RID: 10354 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002872")]
	[Address(RVA = "0x3539904", Offset = "0x3539904", VA = "0x3539904")]
	public void method_31()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002873 RID: 10355 RVA: 0x000588F4 File Offset: 0x00056AF4
	[Token(Token = "0x6002873")]
	[Address(RVA = "0x35399B8", Offset = "0x35399B8", VA = "0x35399B8")]
	private void method_32()
	{
	}

	// Token: 0x06002874 RID: 10356 RVA: 0x00058904 File Offset: 0x00056B04
	[Token(Token = "0x6002874")]
	[Address(RVA = "0x3539A88", Offset = "0x3539A88", VA = "0x3539A88")]
	public void method_33()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		long num = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		this.bool_0 = (num != 0L);
		Debug.Log("PlayWave");
	}

	// Token: 0x06002875 RID: 10357 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002875")]
	[Address(RVA = "0x3539B34", Offset = "0x3539B34", VA = "0x3539B34")]
	public void method_34()
	{
	}

	// Token: 0x06002876 RID: 10358 RVA: 0x00058948 File Offset: 0x00056B48
	[Address(RVA = "0x3539B3C", Offset = "0x3539B3C", VA = "0x3539B3C")]
	[Token(Token = "0x6002876")]
	private void method_35()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002877 RID: 10359 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6002877")]
	[Address(RVA = "0x3539BF0", Offset = "0x3539BF0", VA = "0x3539BF0")]
	public openMenu()
	{
	}

	// Token: 0x06002878 RID: 10360 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002878")]
	[Address(RVA = "0x3539BF8", Offset = "0x3539BF8", VA = "0x3539BF8")]
	public void method_36()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x04000546 RID: 1350
	[Token(Token = "0x4000546")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;

	// Token: 0x04000547 RID: 1351
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000547")]
	public GameObject gameObject_1;

	// Token: 0x04000548 RID: 1352
	[Token(Token = "0x4000548")]
	[FieldOffset(Offset = "0x28")]
	private InputDevice inputDevice_0;

	// Token: 0x04000549 RID: 1353
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000549")]
	public bool bool_0;
}
