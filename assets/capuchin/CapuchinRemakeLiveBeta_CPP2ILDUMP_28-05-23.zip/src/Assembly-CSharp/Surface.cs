﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000024 RID: 36
[Token(Token = "0x2000024")]
public class Surface : MonoBehaviour
{
	// Token: 0x060004AA RID: 1194 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60004AA")]
	[Address(RVA = "0x3084AC8", Offset = "0x3084AC8", VA = "0x3084AC8")]
	public Surface()
	{
	}

	// Token: 0x040000AB RID: 171
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000AB")]
	public GEnum1 genum1_0;

	// Token: 0x040000AC RID: 172
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x40000AC")]
	public bool bool_0;
}
