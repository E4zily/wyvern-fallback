﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace SizeChanging
{
	// Token: 0x02000110 RID: 272
	[Token(Token = "0x2000110")]
	public class sizeChanger : MonoBehaviour
	{
		// Token: 0x060028F2 RID: 10482 RVA: 0x000590C4 File Offset: 0x000572C4
		[Address(RVA = "0x3541A30", Offset = "0x3541A30", VA = "0x3541A30")]
		[Token(Token = "0x60028F2")]
		private void method_0()
		{
			float deltaTime = Time.deltaTime;
			GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
			this.gameObject_1 = gameObject;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x060028F3 RID: 10483 RVA: 0x000590F4 File Offset: 0x000572F4
		[Token(Token = "0x60028F3")]
		[Address(RVA = "0x3541AE0", Offset = "0x3541AE0", VA = "0x3541AE0")]
		private void method_1(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Added Winner Money");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x060028F4 RID: 10484 RVA: 0x0005915C File Offset: 0x0005735C
		[Token(Token = "0x60028F4")]
		[Address(RVA = "0x3541CF0", Offset = "0x3541CF0", VA = "0x3541CF0")]
		private void method_2(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("containsStaff");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x060028F5 RID: 10485 RVA: 0x000591C4 File Offset: 0x000573C4
		[Address(RVA = "0x3541F00", Offset = "0x3541F00", VA = "0x3541F00")]
		[Token(Token = "0x60028F5")]
		private void method_3(Collider collider_0)
		{
			GameObject gameObject;
			gameObject.CompareTag("liftoff failed!");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x060028F6 RID: 10486 RVA: 0x00059228 File Offset: 0x00057428
		[Token(Token = "0x60028F6")]
		[Address(RVA = "0x3542110", Offset = "0x3542110", VA = "0x3542110")]
		private void method_4(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("sound play stopped");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x060028F7 RID: 10487 RVA: 0x00059290 File Offset: 0x00057490
		[Address(RVA = "0x3542320", Offset = "0x3542320", VA = "0x3542320")]
		[Token(Token = "0x60028F7")]
		private void OnTriggerEnter(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Player");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x060028F8 RID: 10488 RVA: 0x000592F8 File Offset: 0x000574F8
		[Address(RVA = "0x3542530", Offset = "0x3542530", VA = "0x3542530")]
		[Token(Token = "0x60028F8")]
		private void method_5(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Name Changing Error. Error: ");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x060028F9 RID: 10489 RVA: 0x00059360 File Offset: 0x00057560
		[Address(RVA = "0x3542740", Offset = "0x3542740", VA = "0x3542740")]
		[Token(Token = "0x60028F9")]
		private void method_6(Collider collider_0)
		{
			GameObject gameObject;
			gameObject.CompareTag("Player");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x060028FA RID: 10490 RVA: 0x00059384 File Offset: 0x00057584
		[Address(RVA = "0x3542928", Offset = "0x3542928", VA = "0x3542928")]
		[Token(Token = "0x60028FA")]
		private void method_7(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("NGNNoSound");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x060028FB RID: 10491 RVA: 0x000593EC File Offset: 0x000575EC
		[Address(RVA = "0x3542B38", Offset = "0x3542B38", VA = "0x3542B38")]
		[Token(Token = "0x60028FB")]
		private void method_8(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("typesOfTalk");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x060028FC RID: 10492 RVA: 0x00059454 File Offset: 0x00057654
		[Token(Token = "0x60028FC")]
		[Address(RVA = "0x3542D48", Offset = "0x3542D48", VA = "0x3542D48")]
		private void method_9(Collider collider_0)
		{
			GameObject gameObject;
			gameObject.CompareTag("FingerTip");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x060028FD RID: 10493 RVA: 0x00059478 File Offset: 0x00057678
		[Token(Token = "0x60028FD")]
		[Address(RVA = "0x3542F30", Offset = "0x3542F30", VA = "0x3542F30")]
		private void method_10(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("TurnAmount");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x060028FE RID: 10494 RVA: 0x000594E0 File Offset: 0x000576E0
		[Token(Token = "0x60028FE")]
		[Address(RVA = "0x3543140", Offset = "0x3543140", VA = "0x3543140")]
		private void method_11(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("EnableCosmetic");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x060028FF RID: 10495 RVA: 0x00059508 File Offset: 0x00057708
		[Token(Token = "0x60028FF")]
		[Address(RVA = "0x3543328", Offset = "0x3543328", VA = "0x3543328")]
		private void method_12(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("A Player has left the Room.");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x06002900 RID: 10496 RVA: 0x000590C4 File Offset: 0x000572C4
		[Address(RVA = "0x3543510", Offset = "0x3543510", VA = "0x3543510")]
		[Token(Token = "0x6002900")]
		private void method_13()
		{
			float deltaTime = Time.deltaTime;
			GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
			this.gameObject_1 = gameObject;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002901 RID: 10497 RVA: 0x000590C4 File Offset: 0x000572C4
		[Address(RVA = "0x35435C0", Offset = "0x35435C0", VA = "0x35435C0")]
		[Token(Token = "0x6002901")]
		private void method_14()
		{
			float deltaTime = Time.deltaTime;
			GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
			this.gameObject_1 = gameObject;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002902 RID: 10498 RVA: 0x00059530 File Offset: 0x00057730
		[Token(Token = "0x6002902")]
		[Address(RVA = "0x3543670", Offset = "0x3543670", VA = "0x3543670")]
		private void method_15()
		{
			float deltaTime = Time.deltaTime;
			GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
			this.gameObject_1 = gameObject;
			Transform transform;
			Physics.gravity = transform.localScale;
		}

		// Token: 0x06002903 RID: 10499 RVA: 0x00059564 File Offset: 0x00057764
		[Token(Token = "0x6002903")]
		[Address(RVA = "0x3543720", Offset = "0x3543720", VA = "0x3543720")]
		private void method_16(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("username");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x06002904 RID: 10500 RVA: 0x00059290 File Offset: 0x00057490
		[Address(RVA = "0x3543930", Offset = "0x3543930", VA = "0x3543930")]
		[Token(Token = "0x6002904")]
		private void OnTriggerExit(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Player");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x06002905 RID: 10501 RVA: 0x000595CC File Offset: 0x000577CC
		[Address(RVA = "0x3543B40", Offset = "0x3543B40", VA = "0x3543B40")]
		[Token(Token = "0x6002905")]
		private void method_17(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Name Changing Error. Error: ");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x06002906 RID: 10502 RVA: 0x000595F4 File Offset: 0x000577F4
		[Token(Token = "0x6002906")]
		[Address(RVA = "0x3543D28", Offset = "0x3543D28", VA = "0x3543D28")]
		private void method_18(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("closeToObject");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x06002907 RID: 10503 RVA: 0x0005961C File Offset: 0x0005781C
		[Token(Token = "0x6002907")]
		[Address(RVA = "0x3543F10", Offset = "0x3543F10", VA = "0x3543F10")]
		private void method_19(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("SaveHeight");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x06002908 RID: 10504 RVA: 0x00059684 File Offset: 0x00057884
		[Token(Token = "0x6002908")]
		[Address(RVA = "0x3544120", Offset = "0x3544120", VA = "0x3544120")]
		private void method_20()
		{
			float deltaTime = Time.deltaTime;
			Vector3 localScale = 0.transform.localScale;
		}

		// Token: 0x06002909 RID: 10505 RVA: 0x000596A4 File Offset: 0x000578A4
		[Token(Token = "0x6002909")]
		[Address(RVA = "0x35441D0", Offset = "0x35441D0", VA = "0x35441D0")]
		private void method_21(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x0600290A RID: 10506 RVA: 0x000596CC File Offset: 0x000578CC
		[Address(RVA = "0x35443B8", Offset = "0x35443B8", VA = "0x35443B8")]
		[Token(Token = "0x600290A")]
		private void method_22(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Tagging");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x0600290B RID: 10507 RVA: 0x00059734 File Offset: 0x00057934
		[Token(Token = "0x600290B")]
		[Address(RVA = "0x35445C8", Offset = "0x35445C8", VA = "0x35445C8")]
		private void method_23(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("FLSPTLT");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x0600290C RID: 10508 RVA: 0x0005975C File Offset: 0x0005795C
		[Token(Token = "0x600290C")]
		[Address(RVA = "0x35447B0", Offset = "0x35447B0", VA = "0x35447B0")]
		private void method_24(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Joined Public Room Successfully");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x0600290D RID: 10509 RVA: 0x00059784 File Offset: 0x00057984
		[Address(RVA = "0x3544998", Offset = "0x3544998", VA = "0x3544998")]
		[Token(Token = "0x600290D")]
		private void method_25(Collider collider_0)
		{
			GameObject gameObject = collider_0.gameObject;
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x0600290E RID: 10510 RVA: 0x000597E0 File Offset: 0x000579E0
		[Address(RVA = "0x3544BA8", Offset = "0x3544BA8", VA = "0x3544BA8")]
		[Token(Token = "0x600290E")]
		private void method_26(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Thumb");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x0600290F RID: 10511 RVA: 0x00059808 File Offset: 0x00057A08
		[Token(Token = "0x600290F")]
		[Address(RVA = "0x3544D90", Offset = "0x3544D90", VA = "0x3544D90")]
		private void method_27(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("ChangeToTagged");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x06002910 RID: 10512 RVA: 0x00059870 File Offset: 0x00057A70
		[Token(Token = "0x6002910")]
		[Address(RVA = "0x3544FA0", Offset = "0x3544FA0", VA = "0x3544FA0")]
		private void method_28(Collider collider_0)
		{
			GameObject gameObject = collider_0.gameObject;
			throw new MissingMethodException();
		}

		// Token: 0x06002911 RID: 10513 RVA: 0x00059564 File Offset: 0x00057764
		[Token(Token = "0x6002911")]
		[Address(RVA = "0x3545188", Offset = "0x3545188", VA = "0x3545188")]
		private void method_29(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("username");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x06002912 RID: 10514 RVA: 0x0005988C File Offset: 0x00057A8C
		[Token(Token = "0x6002912")]
		[Address(RVA = "0x3545398", Offset = "0x3545398", VA = "0x3545398")]
		private void method_30(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Error");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x06002913 RID: 10515 RVA: 0x000590C4 File Offset: 0x000572C4
		[Token(Token = "0x6002913")]
		[Address(RVA = "0x3545580", Offset = "0x3545580", VA = "0x3545580")]
		private void Update()
		{
			float deltaTime = Time.deltaTime;
			GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
			this.gameObject_1 = gameObject;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002914 RID: 10516 RVA: 0x000598B4 File Offset: 0x00057AB4
		[Address(RVA = "0x3545628", Offset = "0x3545628", VA = "0x3545628")]
		[Token(Token = "0x6002914")]
		private void method_31(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Room1");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x06002915 RID: 10517 RVA: 0x000590C4 File Offset: 0x000572C4
		[Address(RVA = "0x3545838", Offset = "0x3545838", VA = "0x3545838")]
		[Token(Token = "0x6002915")]
		private void method_32()
		{
			float deltaTime = Time.deltaTime;
			GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
			this.gameObject_1 = gameObject;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002916 RID: 10518 RVA: 0x0005991C File Offset: 0x00057B1C
		[Address(RVA = "0x35458E8", Offset = "0x35458E8", VA = "0x35458E8")]
		[Token(Token = "0x6002916")]
		private void method_33(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("liftoff failed!");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x06002917 RID: 10519 RVA: 0x000590C4 File Offset: 0x000572C4
		[Address(RVA = "0x3545AD0", Offset = "0x3545AD0", VA = "0x3545AD0")]
		[Token(Token = "0x6002917")]
		private void method_34()
		{
			float deltaTime = Time.deltaTime;
			GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
			this.gameObject_1 = gameObject;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x06002918 RID: 10520 RVA: 0x00059944 File Offset: 0x00057B44
		[Address(RVA = "0x3545B80", Offset = "0x3545B80", VA = "0x3545B80")]
		[Token(Token = "0x6002918")]
		private void method_35(Collider collider_0)
		{
			GameObject gameObject;
			gameObject.CompareTag("hh:mmtt");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x06002919 RID: 10521 RVA: 0x000590C4 File Offset: 0x000572C4
		[Token(Token = "0x6002919")]
		[Address(RVA = "0x3545D90", Offset = "0x3545D90", VA = "0x3545D90")]
		private void method_36()
		{
			float deltaTime = Time.deltaTime;
			GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
			this.gameObject_1 = gameObject;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x0600291A RID: 10522 RVA: 0x000599A8 File Offset: 0x00057BA8
		[Address(RVA = "0x3545E40", Offset = "0x3545E40", VA = "0x3545E40")]
		[Token(Token = "0x600291A")]
		private void method_37(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("/");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x0600291B RID: 10523 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x600291B")]
		[Address(RVA = "0x3546028", Offset = "0x3546028", VA = "0x3546028")]
		public sizeChanger()
		{
		}

		// Token: 0x0600291C RID: 10524 RVA: 0x000599D0 File Offset: 0x00057BD0
		[Address(RVA = "0x354603C", Offset = "0x354603C", VA = "0x354603C")]
		[Token(Token = "0x600291C")]
		private void method_38()
		{
			float deltaTime = Time.deltaTime;
			GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
			this.gameObject_1 = gameObject;
			Transform transform;
			Vector3 localScale = transform.localScale;
		}

		// Token: 0x0600291D RID: 10525 RVA: 0x00059A00 File Offset: 0x00057C00
		[Address(RVA = "0x35460EC", Offset = "0x35460EC", VA = "0x35460EC")]
		[Token(Token = "0x600291D")]
		private void method_39(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("liftoff failed!");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x0600291E RID: 10526 RVA: 0x00059A68 File Offset: 0x00057C68
		[Address(RVA = "0x35462FC", Offset = "0x35462FC", VA = "0x35462FC")]
		[Token(Token = "0x600291E")]
		private void method_40(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Tagged");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x0600291F RID: 10527 RVA: 0x00059A90 File Offset: 0x00057C90
		[Address(RVA = "0x35464E4", Offset = "0x35464E4", VA = "0x35464E4")]
		[Token(Token = "0x600291F")]
		private void method_41(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Cannot take elements from an empty buffer.");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x06002920 RID: 10528 RVA: 0x0005961C File Offset: 0x0005781C
		[Token(Token = "0x6002920")]
		[Address(RVA = "0x35466CC", Offset = "0x35466CC", VA = "0x35466CC")]
		private void method_42(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("SaveHeight");
			Vector3 one = Vector3.one;
			Vector3 one2 = Vector3.one;
			float value;
			float time = Mathf.Clamp01(value);
			Transform transform = this.gameObject_1.transform;
			Vector3 one3 = Vector3.one;
			Vector3 one4 = Vector3.one;
			AnimationCurve animationCurve = this.animationCurve_0;
			float value2 = animationCurve.Evaluate(time);
			Mathf.Clamp01(value2);
		}

		// Token: 0x06002921 RID: 10529 RVA: 0x00059AB8 File Offset: 0x00057CB8
		[Address(RVA = "0x35468DC", Offset = "0x35468DC", VA = "0x35468DC")]
		[Token(Token = "0x6002921")]
		private void method_43(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("Room1");
			if (this.gameObject_0 == null)
			{
				return;
			}
		}

		// Token: 0x06002922 RID: 10530 RVA: 0x00059AE0 File Offset: 0x00057CE0
		[Address(RVA = "0x3546AC4", Offset = "0x3546AC4", VA = "0x3546AC4")]
		[Token(Token = "0x6002922")]
		private void method_44(Collider collider_0)
		{
			collider_0.gameObject.CompareTag("n0");
		}

		// Token: 0x0400055B RID: 1371
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400055B")]
		public GameObject[] gameObject_0;

		// Token: 0x0400055C RID: 1372
		[Token(Token = "0x400055C")]
		[FieldOffset(Offset = "0x20")]
		public float float_0;

		// Token: 0x0400055D RID: 1373
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x400055D")]
		private float float_1;

		// Token: 0x0400055E RID: 1374
		[SerializeField]
		[Header("How fast shall it change?")]
		[Token(Token = "0x400055E")]
		[FieldOffset(Offset = "0x28")]
		private float speedChanging;

		// Token: 0x0400055F RID: 1375
		[Token(Token = "0x400055F")]
		[FieldOffset(Offset = "0x30")]
		public AnimationCurve animationCurve_0;

		// Token: 0x04000560 RID: 1376
		[Token(Token = "0x4000560")]
		[FieldOffset(Offset = "0x38")]
		public NetworkPlayerSpawner networkPlayerSpawner_0;

		// Token: 0x04000561 RID: 1377
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000561")]
		public GameObject gameObject_1;

		// Token: 0x04000562 RID: 1378
		[FieldOffset(Offset = "0x48")]
		[HideInInspector]
		[Token(Token = "0x4000562")]
		private float float_2;

		// Token: 0x04000563 RID: 1379
		[Token(Token = "0x4000563")]
		[FieldOffset(Offset = "0x4C")]
		[HideInInspector]
		private float float_3;
	}
}
