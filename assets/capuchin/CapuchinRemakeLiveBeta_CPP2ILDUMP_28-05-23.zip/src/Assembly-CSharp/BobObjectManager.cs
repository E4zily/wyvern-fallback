﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200000B RID: 11
[Token(Token = "0x200000B")]
public class BobObjectManager : MonoBehaviour
{
	// Token: 0x06000132 RID: 306 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000132")]
	[Address(RVA = "0x25A7708", Offset = "0x25A7708", VA = "0x25A7708")]
	public void method_0(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000133 RID: 307 RVA: 0x00007740 File Offset: 0x00005940
	[Address(RVA = "0x25A77D0", Offset = "0x25A77D0", VA = "0x25A77D0")]
	[Token(Token = "0x6000133")]
	public void method_1(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000134 RID: 308 RVA: 0x0000775C File Offset: 0x0000595C
	[Address(RVA = "0x25A7898", Offset = "0x25A7898", VA = "0x25A7898")]
	[Token(Token = "0x6000134")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000135 RID: 309 RVA: 0x0000775C File Offset: 0x0000595C
	[Token(Token = "0x6000135")]
	[Address(RVA = "0x25A7960", Offset = "0x25A7960", VA = "0x25A7960")]
	public void method_2(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000136 RID: 310 RVA: 0x0000775C File Offset: 0x0000595C
	[Token(Token = "0x6000136")]
	[Address(RVA = "0x25A7A28", Offset = "0x25A7A28", VA = "0x25A7A28")]
	public void method_3(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000137 RID: 311 RVA: 0x00007788 File Offset: 0x00005988
	[Address(RVA = "0x25A7AF0", Offset = "0x25A7AF0", VA = "0x25A7AF0")]
	[Token(Token = "0x6000137")]
	public void method_4(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		collider_0;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000138 RID: 312 RVA: 0x000077B4 File Offset: 0x000059B4
	[Token(Token = "0x6000138")]
	[Address(RVA = "0x25A7BB8", Offset = "0x25A7BB8", VA = "0x25A7BB8")]
	public void method_5(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000139 RID: 313 RVA: 0x0000775C File Offset: 0x0000595C
	[Address(RVA = "0x25A7C80", Offset = "0x25A7C80", VA = "0x25A7C80")]
	[Token(Token = "0x6000139")]
	public void method_6(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600013A RID: 314 RVA: 0x0000775C File Offset: 0x0000595C
	[Address(RVA = "0x25A7D48", Offset = "0x25A7D48", VA = "0x25A7D48")]
	[Token(Token = "0x600013A")]
	public void method_7(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600013B RID: 315 RVA: 0x000077B4 File Offset: 0x000059B4
	[Token(Token = "0x600013B")]
	[Address(RVA = "0x25A7E10", Offset = "0x25A7E10", VA = "0x25A7E10")]
	public void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600013C RID: 316 RVA: 0x0000775C File Offset: 0x0000595C
	[Token(Token = "0x600013C")]
	[Address(RVA = "0x25A7ED8", Offset = "0x25A7ED8", VA = "0x25A7ED8")]
	public void method_9(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600013D RID: 317 RVA: 0x000077E0 File Offset: 0x000059E0
	[Token(Token = "0x600013D")]
	[Address(RVA = "0x25A7FA0", Offset = "0x25A7FA0", VA = "0x25A7FA0")]
	public void method_10(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x0600013E RID: 318 RVA: 0x0000775C File Offset: 0x0000595C
	[Address(RVA = "0x25A8068", Offset = "0x25A8068", VA = "0x25A8068")]
	[Token(Token = "0x600013E")]
	public void method_11(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600013F RID: 319 RVA: 0x0000775C File Offset: 0x0000595C
	[Token(Token = "0x600013F")]
	[Address(RVA = "0x25A8130", Offset = "0x25A8130", VA = "0x25A8130")]
	public void method_12(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000140 RID: 320 RVA: 0x000077B4 File Offset: 0x000059B4
	[Address(RVA = "0x25A81F8", Offset = "0x25A81F8", VA = "0x25A81F8")]
	[Token(Token = "0x6000140")]
	public void method_13(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000141 RID: 321 RVA: 0x000077F4 File Offset: 0x000059F4
	[Token(Token = "0x6000141")]
	[Address(RVA = "0x25A82C0", Offset = "0x25A82C0", VA = "0x25A82C0")]
	public void method_14(Collider collider_0)
	{
		HandColliders component = collider_0.GetComponent<HandColliders>();
		long active = 0L;
		component;
		this.gameObject_0.SetActive(active != 0L);
	}

	// Token: 0x06000142 RID: 322 RVA: 0x000077B4 File Offset: 0x000059B4
	[Address(RVA = "0x25A8388", Offset = "0x25A8388", VA = "0x25A8388")]
	[Token(Token = "0x6000142")]
	public void method_15(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000143 RID: 323 RVA: 0x0000775C File Offset: 0x0000595C
	[Token(Token = "0x6000143")]
	[Address(RVA = "0x25A8450", Offset = "0x25A8450", VA = "0x25A8450")]
	public void method_16(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000144 RID: 324 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000144")]
	[Address(RVA = "0x25A8518", Offset = "0x25A8518", VA = "0x25A8518")]
	public void method_17(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000145 RID: 325 RVA: 0x0000775C File Offset: 0x0000595C
	[Address(RVA = "0x25A85E0", Offset = "0x25A85E0", VA = "0x25A85E0")]
	[Token(Token = "0x6000145")]
	public void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000146 RID: 326 RVA: 0x00007820 File Offset: 0x00005A20
	[Token(Token = "0x6000146")]
	[Address(RVA = "0x25A86A8", Offset = "0x25A86A8", VA = "0x25A86A8")]
	public void method_19(Collider collider_0)
	{
		HandColliders exists;
		exists;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000147 RID: 327 RVA: 0x000077B4 File Offset: 0x000059B4
	[Token(Token = "0x6000147")]
	[Address(RVA = "0x25A8770", Offset = "0x25A8770", VA = "0x25A8770")]
	public void method_20(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000148 RID: 328 RVA: 0x000077B4 File Offset: 0x000059B4
	[Address(RVA = "0x25A8838", Offset = "0x25A8838", VA = "0x25A8838")]
	[Token(Token = "0x6000148")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000149 RID: 329 RVA: 0x0000775C File Offset: 0x0000595C
	[Token(Token = "0x6000149")]
	[Address(RVA = "0x25A8900", Offset = "0x25A8900", VA = "0x25A8900")]
	public void method_21(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600014A RID: 330 RVA: 0x0000775C File Offset: 0x0000595C
	[Address(RVA = "0x25A89C8", Offset = "0x25A89C8", VA = "0x25A89C8")]
	[Token(Token = "0x600014A")]
	public void method_22(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600014B RID: 331 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x600014B")]
	[Address(RVA = "0x25A8A90", Offset = "0x25A8A90", VA = "0x25A8A90")]
	public BobObjectManager()
	{
	}

	// Token: 0x0600014C RID: 332 RVA: 0x000077B4 File Offset: 0x000059B4
	[Token(Token = "0x600014C")]
	[Address(RVA = "0x25A8A98", Offset = "0x25A8A98", VA = "0x25A8A98")]
	public void method_23(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600014D RID: 333 RVA: 0x000077B4 File Offset: 0x000059B4
	[Token(Token = "0x600014D")]
	[Address(RVA = "0x25A8B60", Offset = "0x25A8B60", VA = "0x25A8B60")]
	public void method_24(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600014E RID: 334 RVA: 0x0000775C File Offset: 0x0000595C
	[Token(Token = "0x600014E")]
	[Address(RVA = "0x25A8C28", Offset = "0x25A8C28", VA = "0x25A8C28")]
	public void method_25(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600014F RID: 335 RVA: 0x000077B4 File Offset: 0x000059B4
	[Token(Token = "0x600014F")]
	[Address(RVA = "0x25A8CF0", Offset = "0x25A8CF0", VA = "0x25A8CF0")]
	public void method_26(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000150 RID: 336 RVA: 0x00007820 File Offset: 0x00005A20
	[Address(RVA = "0x25A8DB8", Offset = "0x25A8DB8", VA = "0x25A8DB8")]
	[Token(Token = "0x6000150")]
	public void method_27(Collider collider_0)
	{
		HandColliders exists;
		exists;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000151 RID: 337 RVA: 0x00007740 File Offset: 0x00005940
	[Token(Token = "0x6000151")]
	[Address(RVA = "0x25A8E80", Offset = "0x25A8E80", VA = "0x25A8E80")]
	public void method_28(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x0400002E RID: 46
	[Token(Token = "0x400002E")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;
}
