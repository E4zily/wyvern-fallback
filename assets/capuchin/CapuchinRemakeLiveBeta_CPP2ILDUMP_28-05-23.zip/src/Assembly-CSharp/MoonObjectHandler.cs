﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000091 RID: 145
[Token(Token = "0x2000091")]
public class MoonObjectHandler : MonoBehaviour
{
	// Token: 0x060014B9 RID: 5305 RVA: 0x00029350 File Offset: 0x00027550
	[Token(Token = "0x60014B9")]
	[Address(RVA = "0x2E68D34", Offset = "0x2E68D34", VA = "0x2E68D34")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
	}

	// Token: 0x060014BA RID: 5306 RVA: 0x00029370 File Offset: 0x00027570
	[Address(RVA = "0x2E68E00", Offset = "0x2E68E00", VA = "0x2E68E00")]
	[Token(Token = "0x60014BA")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014BB RID: 5307 RVA: 0x00029398 File Offset: 0x00027598
	[Token(Token = "0x60014BB")]
	[Address(RVA = "0x2E68EA4", Offset = "0x2E68EA4", VA = "0x2E68EA4")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("HDRP/Lit");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014BC RID: 5308 RVA: 0x000293C0 File Offset: 0x000275C0
	[Address(RVA = "0x2E68F48", Offset = "0x2E68F48", VA = "0x2E68F48")]
	[Token(Token = "0x60014BC")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("You struck apon an error. ");
	}

	// Token: 0x060014BD RID: 5309 RVA: 0x000293E0 File Offset: 0x000275E0
	[Token(Token = "0x60014BD")]
	[Address(RVA = "0x2E69014", Offset = "0x2E69014", VA = "0x2E69014")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("cosmos");
	}

	// Token: 0x060014BE RID: 5310 RVA: 0x00029400 File Offset: 0x00027600
	[Token(Token = "0x60014BE")]
	[Address(RVA = "0x2E690E0", Offset = "0x2E690E0", VA = "0x2E690E0")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Purchase For ");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014BF RID: 5311 RVA: 0x00029428 File Offset: 0x00027628
	[Token(Token = "0x60014BF")]
	[Address(RVA = "0x2E69184", Offset = "0x2E69184", VA = "0x2E69184")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Photon token acquired!");
	}

	// Token: 0x060014C0 RID: 5312 RVA: 0x00029448 File Offset: 0x00027648
	[Address(RVA = "0x2E69250", Offset = "0x2E69250", VA = "0x2E69250")]
	[Token(Token = "0x60014C0")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_Tint");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014C1 RID: 5313 RVA: 0x00029470 File Offset: 0x00027670
	[Token(Token = "0x60014C1")]
	[Address(RVA = "0x2E692F4", Offset = "0x2E692F4", VA = "0x2E692F4")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
	}

	// Token: 0x060014C2 RID: 5314 RVA: 0x00029470 File Offset: 0x00027670
	[Address(RVA = "0x2E693C0", Offset = "0x2E693C0", VA = "0x2E693C0")]
	[Token(Token = "0x60014C2")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
	}

	// Token: 0x060014C3 RID: 5315 RVA: 0x00029370 File Offset: 0x00027570
	[Address(RVA = "0x2E6948C", Offset = "0x2E6948C", VA = "0x2E6948C")]
	[Token(Token = "0x60014C3")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014C4 RID: 5316 RVA: 0x00029490 File Offset: 0x00027690
	[Token(Token = "0x60014C4")]
	[Address(RVA = "0x2E69530", Offset = "0x2E69530", VA = "0x2E69530")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("gamemode");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014C5 RID: 5317 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60014C5")]
	[Address(RVA = "0x2E695D4", Offset = "0x2E695D4", VA = "0x2E695D4")]
	public MoonObjectHandler()
	{
	}

	// Token: 0x060014C6 RID: 5318 RVA: 0x000294B8 File Offset: 0x000276B8
	[Token(Token = "0x60014C6")]
	[Address(RVA = "0x2E695DC", Offset = "0x2E695DC", VA = "0x2E695DC")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("liftoff failed!");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014C7 RID: 5319 RVA: 0x000294E0 File Offset: 0x000276E0
	[Address(RVA = "0x2E69680", Offset = "0x2E69680", VA = "0x2E69680")]
	[Token(Token = "0x60014C7")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Hate Speech");
	}

	// Token: 0x060014C8 RID: 5320 RVA: 0x00029500 File Offset: 0x00027700
	[Token(Token = "0x60014C8")]
	[Address(RVA = "0x2E6974C", Offset = "0x2E6974C", VA = "0x2E6974C")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Did Hit");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014C9 RID: 5321 RVA: 0x00029528 File Offset: 0x00027728
	[Address(RVA = "0x2E697F0", Offset = "0x2E697F0", VA = "0x2E697F0")]
	[Token(Token = "0x60014C9")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ENABLE");
	}

	// Token: 0x060014CA RID: 5322 RVA: 0x00029548 File Offset: 0x00027748
	[Token(Token = "0x60014CA")]
	[Address(RVA = "0x2E698BC", Offset = "0x2E698BC", VA = "0x2E698BC")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FLSPTLT");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014CB RID: 5323 RVA: 0x00029570 File Offset: 0x00027770
	[Address(RVA = "0x2E69960", Offset = "0x2E69960", VA = "0x2E69960")]
	[Token(Token = "0x60014CB")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("HandL");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014CC RID: 5324 RVA: 0x00029470 File Offset: 0x00027670
	[Token(Token = "0x60014CC")]
	[Address(RVA = "0x2E69A04", Offset = "0x2E69A04", VA = "0x2E69A04")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
	}

	// Token: 0x060014CD RID: 5325 RVA: 0x00029598 File Offset: 0x00027798
	[Address(RVA = "0x2E69AD0", Offset = "0x2E69AD0", VA = "0x2E69AD0")]
	[Token(Token = "0x60014CD")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014CE RID: 5326 RVA: 0x000295C0 File Offset: 0x000277C0
	[Token(Token = "0x60014CE")]
	[Address(RVA = "0x2E69B74", Offset = "0x2E69B74", VA = "0x2E69B74")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("next");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x060014CF RID: 5327 RVA: 0x000295E8 File Offset: 0x000277E8
	[Token(Token = "0x60014CF")]
	[Address(RVA = "0x2E69C18", Offset = "0x2E69C18", VA = "0x2E69C18")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Applying to material");
	}

	// Token: 0x060014D0 RID: 5328 RVA: 0x00029608 File Offset: 0x00027808
	[Address(RVA = "0x2E69CE4", Offset = "0x2E69CE4", VA = "0x2E69CE4")]
	[Token(Token = "0x60014D0")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("username");
		if (this.gameObject_0 == null)
		{
			return;
		}
	}

	// Token: 0x040002C1 RID: 705
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002C1")]
	public GameObject[] gameObject_0;
}
