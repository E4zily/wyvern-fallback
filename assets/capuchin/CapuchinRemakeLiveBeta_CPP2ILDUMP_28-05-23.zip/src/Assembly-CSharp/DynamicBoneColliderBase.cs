﻿using System;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000C5 RID: 197
[Token(Token = "0x20000C5")]
public class DynamicBoneColliderBase : MonoBehaviour
{
	// Token: 0x06001BC6 RID: 7110 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221C8E8", Offset = "0x221C8E8", VA = "0x221C8E8")]
	[Token(Token = "0x6001BC6")]
	public void method_0(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001BC7 RID: 7111 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C8F0", Offset = "0x221C8F0", VA = "0x221C8F0", Slot = "4")]
	[Token(Token = "0x6001BC7")]
	public virtual void vmethod_0()
	{
	}

	// Token: 0x06001BC8 RID: 7112 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221C8F4", Offset = "0x221C8F4", VA = "0x221C8F4")]
	[Token(Token = "0x6001BC8")]
	public void method_1(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001BC9 RID: 7113 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C8FC", Offset = "0x221C8FC", VA = "0x221C8FC", Slot = "5")]
	[Token(Token = "0x6001BC9")]
	public virtual void vmethod_1()
	{
	}

	// Token: 0x06001BCA RID: 7114 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C900", Offset = "0x221C900", VA = "0x221C900", Slot = "6")]
	[Token(Token = "0x6001BCA")]
	public virtual void vmethod_2()
	{
	}

	// Token: 0x06001BCB RID: 7115 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C904", Offset = "0x221C904", VA = "0x221C904", Slot = "7")]
	[Token(Token = "0x6001BCB")]
	public virtual void vmethod_3()
	{
	}

	// Token: 0x06001BCC RID: 7116 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C908", Offset = "0x221C908", VA = "0x221C908", Slot = "8")]
	[Token(Token = "0x6001BCC")]
	public virtual void vmethod_4()
	{
	}

	// Token: 0x06001BCD RID: 7117 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221C90C", Offset = "0x221C90C", VA = "0x221C90C")]
	[Token(Token = "0x6001BCD")]
	public void method_2(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001BCE RID: 7118 RVA: 0x00035BD8 File Offset: 0x00033DD8
	[Address(RVA = "0x2218AC0", Offset = "0x2218AC0", VA = "0x2218AC0")]
	[Token(Token = "0x6001BCE")]
	public DynamicBoneColliderBase()
	{
		long num = 1L;
		this.genum10_0 = (DynamicBoneColliderBase.GEnum10)num;
		Vector3 zero = Vector3.zero;
		base..ctor();
	}

	// Token: 0x06001BCF RID: 7119 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221C914", Offset = "0x221C914", VA = "0x221C914", Slot = "9")]
	[Token(Token = "0x6001BCF")]
	public virtual bool vmethod_5(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BD0 RID: 7120 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221C91C", Offset = "0x221C91C", VA = "0x221C91C")]
	[Token(Token = "0x6001BD0")]
	public void method_3(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001BD1 RID: 7121 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221C924", Offset = "0x221C924", VA = "0x221C924")]
	[Token(Token = "0x6001BD1")]
	public int method_4()
	{
		return this.int_0;
	}

	// Token: 0x06001BD2 RID: 7122 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221C92C", Offset = "0x221C92C", VA = "0x221C92C", Slot = "10")]
	[Token(Token = "0x6001BD2")]
	public virtual bool vmethod_6(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BD3 RID: 7123 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C934", Offset = "0x221C934", VA = "0x221C934", Slot = "11")]
	[Token(Token = "0x6001BD3")]
	public virtual void vmethod_7()
	{
	}

	// Token: 0x06001BD4 RID: 7124 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221C938", Offset = "0x221C938", VA = "0x221C938")]
	[Token(Token = "0x6001BD4")]
	public int method_5()
	{
		return this.int_0;
	}

	// Token: 0x06001BD5 RID: 7125 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221C940", Offset = "0x221C940", VA = "0x221C940")]
	[Token(Token = "0x6001BD5")]
	public int method_6()
	{
		return this.int_0;
	}

	// Token: 0x06001BD6 RID: 7126 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C948", Offset = "0x221C948", VA = "0x221C948", Slot = "12")]
	[Token(Token = "0x6001BD6")]
	public virtual void vmethod_8()
	{
	}

	// Token: 0x06001BD7 RID: 7127 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221C94C", Offset = "0x221C94C", VA = "0x221C94C", Slot = "13")]
	[Token(Token = "0x6001BD7")]
	public virtual bool vmethod_9(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BD8 RID: 7128 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x221C954", Offset = "0x221C954", VA = "0x221C954")]
	[Token(Token = "0x6001BD8")]
	public int method_7()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BD9 RID: 7129 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C95C", Offset = "0x221C95C", VA = "0x221C95C", Slot = "14")]
	[Token(Token = "0x6001BD9")]
	public virtual void vmethod_10()
	{
	}

	// Token: 0x06001BDA RID: 7130 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221C960", Offset = "0x221C960", VA = "0x221C960")]
	[Token(Token = "0x6001BDA")]
	public void method_8(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001BDB RID: 7131 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221C968", Offset = "0x221C968", VA = "0x221C968")]
	[Token(Token = "0x6001BDB")]
	public int method_9()
	{
		return this.int_0;
	}

	// Token: 0x06001BDC RID: 7132 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221C970", Offset = "0x221C970", VA = "0x221C970", Slot = "15")]
	[Token(Token = "0x6001BDC")]
	public virtual bool vmethod_11(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BDD RID: 7133 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C978", Offset = "0x221C978", VA = "0x221C978", Slot = "16")]
	[Token(Token = "0x6001BDD")]
	public virtual void vmethod_12()
	{
	}

	// Token: 0x06001BDE RID: 7134 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221C97C", Offset = "0x221C97C", VA = "0x221C97C", Slot = "17")]
	[Token(Token = "0x6001BDE")]
	public virtual bool vmethod_13(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BDF RID: 7135 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221C984", Offset = "0x221C984", VA = "0x221C984")]
	[Token(Token = "0x6001BDF")]
	public int method_10()
	{
		return this.int_0;
	}

	// Token: 0x17000067 RID: 103
	// (get) Token: 0x06001BE0 RID: 7136 RVA: 0x000029EF File Offset: 0x00000BEF
	// (set) Token: 0x06001C49 RID: 7241 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Token(Token = "0x17000067")]
	public int Int32_0 { [Address(RVA = "0x221C98C", Offset = "0x221C98C", VA = "0x221C98C")] [Token(Token = "0x6001BE0")] get; [Address(RVA = "0x221CC04", Offset = "0x221CC04", VA = "0x221CC04")] [Token(Token = "0x6001C49")] set; }

	// Token: 0x06001BE1 RID: 7137 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221C994", Offset = "0x221C994", VA = "0x221C994", Slot = "18")]
	[Token(Token = "0x6001BE1")]
	public virtual bool vmethod_14(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BE2 RID: 7138 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C99C", Offset = "0x221C99C", VA = "0x221C99C", Slot = "19")]
	[Token(Token = "0x6001BE2")]
	public virtual void vmethod_15()
	{
	}

	// Token: 0x06001BE3 RID: 7139 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221C9A0", Offset = "0x221C9A0", VA = "0x221C9A0", Slot = "20")]
	[Token(Token = "0x6001BE3")]
	public virtual bool vmethod_16(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BE4 RID: 7140 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9A8", Offset = "0x221C9A8", VA = "0x221C9A8", Slot = "21")]
	[Token(Token = "0x6001BE4")]
	public virtual void vmethod_17()
	{
	}

	// Token: 0x06001BE5 RID: 7141 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9AC", Offset = "0x221C9AC", VA = "0x221C9AC", Slot = "22")]
	[Token(Token = "0x6001BE5")]
	public virtual void vmethod_18()
	{
	}

	// Token: 0x06001BE6 RID: 7142 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9B0", Offset = "0x221C9B0", VA = "0x221C9B0", Slot = "23")]
	[Token(Token = "0x6001BE6")]
	public virtual void vmethod_19()
	{
	}

	// Token: 0x06001BE7 RID: 7143 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221C9B4", Offset = "0x221C9B4", VA = "0x221C9B4")]
	[Token(Token = "0x6001BE7")]
	public int method_11()
	{
		return this.int_0;
	}

	// Token: 0x06001BE8 RID: 7144 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221C9BC", Offset = "0x221C9BC", VA = "0x221C9BC")]
	[Token(Token = "0x6001BE8")]
	public void method_12(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001BE9 RID: 7145 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221C9C4", Offset = "0x221C9C4", VA = "0x221C9C4", Slot = "24")]
	[Token(Token = "0x6001BE9")]
	public virtual bool vmethod_20(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BEA RID: 7146 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9CC", Offset = "0x221C9CC", VA = "0x221C9CC", Slot = "25")]
	[Token(Token = "0x6001BEA")]
	public virtual void vmethod_21()
	{
	}

	// Token: 0x06001BEB RID: 7147 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9D0", Offset = "0x221C9D0", VA = "0x221C9D0", Slot = "26")]
	[Token(Token = "0x6001BEB")]
	public virtual void vmethod_22()
	{
	}

	// Token: 0x06001BEC RID: 7148 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9D4", Offset = "0x221C9D4", VA = "0x221C9D4", Slot = "27")]
	[Token(Token = "0x6001BEC")]
	public virtual void vmethod_23()
	{
	}

	// Token: 0x06001BED RID: 7149 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9D8", Offset = "0x221C9D8", VA = "0x221C9D8", Slot = "28")]
	[Token(Token = "0x6001BED")]
	public virtual void vmethod_24()
	{
	}

	// Token: 0x06001BEE RID: 7150 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221C9DC", Offset = "0x221C9DC", VA = "0x221C9DC")]
	[Token(Token = "0x6001BEE")]
	public int method_13()
	{
		return this.int_0;
	}

	// Token: 0x06001BEF RID: 7151 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9E4", Offset = "0x221C9E4", VA = "0x221C9E4", Slot = "29")]
	[Token(Token = "0x6001BEF")]
	public virtual void vmethod_25()
	{
	}

	// Token: 0x06001BF0 RID: 7152 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221C9E8", Offset = "0x221C9E8", VA = "0x221C9E8", Slot = "30")]
	[Token(Token = "0x6001BF0")]
	public virtual bool vmethod_26(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BF1 RID: 7153 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9F0", Offset = "0x221C9F0", VA = "0x221C9F0", Slot = "31")]
	[Token(Token = "0x6001BF1")]
	public virtual void vmethod_27()
	{
	}

	// Token: 0x06001BF2 RID: 7154 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9F4", Offset = "0x221C9F4", VA = "0x221C9F4", Slot = "32")]
	[Token(Token = "0x6001BF2")]
	public virtual void vmethod_28()
	{
	}

	// Token: 0x06001BF3 RID: 7155 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221C9F8", Offset = "0x221C9F8", VA = "0x221C9F8", Slot = "33")]
	[Token(Token = "0x6001BF3")]
	public virtual void vmethod_29()
	{
	}

	// Token: 0x06001BF4 RID: 7156 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221C9FC", Offset = "0x221C9FC", VA = "0x221C9FC", Slot = "34")]
	[Token(Token = "0x6001BF4")]
	public virtual bool vmethod_30(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BF5 RID: 7157 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CA04", Offset = "0x221CA04", VA = "0x221CA04")]
	[Token(Token = "0x6001BF5")]
	public int method_14()
	{
		return this.int_0;
	}

	// Token: 0x06001BF6 RID: 7158 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CA0C", Offset = "0x221CA0C", VA = "0x221CA0C")]
	[Token(Token = "0x6001BF6")]
	public void method_15(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001BF7 RID: 7159 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CA14", Offset = "0x221CA14", VA = "0x221CA14")]
	[Token(Token = "0x6001BF7")]
	public int method_16()
	{
		return this.int_0;
	}

	// Token: 0x06001BF8 RID: 7160 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CA1C", Offset = "0x221CA1C", VA = "0x221CA1C", Slot = "35")]
	[Token(Token = "0x6001BF8")]
	public virtual void vmethod_31()
	{
	}

	// Token: 0x06001BF9 RID: 7161 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CA20", Offset = "0x221CA20", VA = "0x221CA20")]
	[Token(Token = "0x6001BF9")]
	public void method_17(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001BFA RID: 7162 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CA28", Offset = "0x221CA28", VA = "0x221CA28", Slot = "36")]
	[Token(Token = "0x6001BFA")]
	public virtual void vmethod_32()
	{
	}

	// Token: 0x06001BFB RID: 7163 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CA2C", Offset = "0x221CA2C", VA = "0x221CA2C", Slot = "37")]
	[Token(Token = "0x6001BFB")]
	public virtual void vmethod_33()
	{
	}

	// Token: 0x06001BFC RID: 7164 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CA30", Offset = "0x221CA30", VA = "0x221CA30", Slot = "38")]
	[Token(Token = "0x6001BFC")]
	public virtual bool vmethod_34(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001BFD RID: 7165 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CA38", Offset = "0x221CA38", VA = "0x221CA38", Slot = "39")]
	[Token(Token = "0x6001BFD")]
	public virtual void vmethod_35()
	{
	}

	// Token: 0x06001BFE RID: 7166 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CA3C", Offset = "0x221CA3C", VA = "0x221CA3C")]
	[Token(Token = "0x6001BFE")]
	public int method_18()
	{
		return this.int_0;
	}

	// Token: 0x06001BFF RID: 7167 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CA44", Offset = "0x221CA44", VA = "0x221CA44")]
	[Token(Token = "0x6001BFF")]
	public int method_19()
	{
		return this.int_0;
	}

	// Token: 0x06001C00 RID: 7168 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CA4C", Offset = "0x221CA4C", VA = "0x221CA4C", Slot = "40")]
	[Token(Token = "0x6001C00")]
	public virtual bool vmethod_36(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C01 RID: 7169 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CA54", Offset = "0x221CA54", VA = "0x221CA54", Slot = "41")]
	[Token(Token = "0x6001C01")]
	public virtual void vmethod_37()
	{
	}

	// Token: 0x06001C02 RID: 7170 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CA58", Offset = "0x221CA58", VA = "0x221CA58")]
	[Token(Token = "0x6001C02")]
	public void method_20(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C03 RID: 7171 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CA60", Offset = "0x221CA60", VA = "0x221CA60")]
	[Token(Token = "0x6001C03")]
	public void method_21(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C04 RID: 7172 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CA68", Offset = "0x221CA68", VA = "0x221CA68")]
	[Token(Token = "0x6001C04")]
	public void method_22(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C05 RID: 7173 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CA70", Offset = "0x221CA70", VA = "0x221CA70")]
	[Token(Token = "0x6001C05")]
	public void method_23(int int_1)
	{
	}

	// Token: 0x06001C06 RID: 7174 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CA78", Offset = "0x221CA78", VA = "0x221CA78", Slot = "42")]
	[Token(Token = "0x6001C06")]
	public virtual bool vmethod_38(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C07 RID: 7175 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CA80", Offset = "0x221CA80", VA = "0x221CA80", Slot = "43")]
	[Token(Token = "0x6001C07")]
	public virtual void vmethod_39()
	{
	}

	// Token: 0x06001C08 RID: 7176 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CA84", Offset = "0x221CA84", VA = "0x221CA84", Slot = "44")]
	[Token(Token = "0x6001C08")]
	public virtual void vmethod_40()
	{
	}

	// Token: 0x06001C09 RID: 7177 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CA88", Offset = "0x221CA88", VA = "0x221CA88", Slot = "45")]
	[Token(Token = "0x6001C09")]
	public virtual bool vmethod_41(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C0A RID: 7178 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CA90", Offset = "0x221CA90", VA = "0x221CA90", Slot = "46")]
	[Token(Token = "0x6001C0A")]
	public virtual void vmethod_42()
	{
	}

	// Token: 0x06001C0B RID: 7179 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CA94", Offset = "0x221CA94", VA = "0x221CA94")]
	[Token(Token = "0x6001C0B")]
	public void method_24(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C0C RID: 7180 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CA9C", Offset = "0x221CA9C", VA = "0x221CA9C", Slot = "47")]
	[Token(Token = "0x6001C0C")]
	public virtual void vmethod_43()
	{
	}

	// Token: 0x06001C0D RID: 7181 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CAA0", Offset = "0x221CAA0", VA = "0x221CAA0", Slot = "48")]
	[Token(Token = "0x6001C0D")]
	public virtual void vmethod_44()
	{
	}

	// Token: 0x06001C0E RID: 7182 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CAA4", Offset = "0x221CAA4", VA = "0x221CAA4", Slot = "49")]
	[Token(Token = "0x6001C0E")]
	public virtual bool vmethod_45(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C0F RID: 7183 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CAAC", Offset = "0x221CAAC", VA = "0x221CAAC", Slot = "50")]
	[Token(Token = "0x6001C0F")]
	public virtual void vmethod_46()
	{
	}

	// Token: 0x06001C10 RID: 7184 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CAB0", Offset = "0x221CAB0", VA = "0x221CAB0", Slot = "51")]
	[Token(Token = "0x6001C10")]
	public virtual void vmethod_47()
	{
	}

	// Token: 0x06001C11 RID: 7185 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CAB4", Offset = "0x221CAB4", VA = "0x221CAB4", Slot = "52")]
	[Token(Token = "0x6001C11")]
	public virtual void vmethod_48()
	{
	}

	// Token: 0x06001C12 RID: 7186 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CAB8", Offset = "0x221CAB8", VA = "0x221CAB8", Slot = "53")]
	[Token(Token = "0x6001C12")]
	public virtual bool vmethod_49(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C13 RID: 7187 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CAC0", Offset = "0x221CAC0", VA = "0x221CAC0", Slot = "54")]
	[Token(Token = "0x6001C13")]
	public virtual bool vmethod_50(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C14 RID: 7188 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CAC8", Offset = "0x221CAC8", VA = "0x221CAC8", Slot = "55")]
	[Token(Token = "0x6001C14")]
	public virtual void vmethod_51()
	{
	}

	// Token: 0x06001C15 RID: 7189 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CACC", Offset = "0x221CACC", VA = "0x221CACC")]
	[Token(Token = "0x6001C15")]
	public int method_25()
	{
		return this.int_0;
	}

	// Token: 0x06001C16 RID: 7190 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CAD4", Offset = "0x221CAD4", VA = "0x221CAD4")]
	[Token(Token = "0x6001C16")]
	public void method_26(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C17 RID: 7191 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CADC", Offset = "0x221CADC", VA = "0x221CADC", Slot = "56")]
	[Token(Token = "0x6001C17")]
	public virtual bool vmethod_52(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C18 RID: 7192 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CAE4", Offset = "0x221CAE4", VA = "0x221CAE4", Slot = "57")]
	[Token(Token = "0x6001C18")]
	public virtual void vmethod_53()
	{
	}

	// Token: 0x06001C19 RID: 7193 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CAE8", Offset = "0x221CAE8", VA = "0x221CAE8")]
	[Token(Token = "0x6001C19")]
	public int method_27()
	{
		return this.int_0;
	}

	// Token: 0x06001C1A RID: 7194 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CAF0", Offset = "0x221CAF0", VA = "0x221CAF0", Slot = "58")]
	[Token(Token = "0x6001C1A")]
	public virtual void vmethod_54()
	{
	}

	// Token: 0x06001C1B RID: 7195 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CAF4", Offset = "0x221CAF4", VA = "0x221CAF4")]
	[Token(Token = "0x6001C1B")]
	public void method_28(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C1C RID: 7196 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CAFC", Offset = "0x221CAFC", VA = "0x221CAFC", Slot = "59")]
	[Token(Token = "0x6001C1C")]
	public virtual void vmethod_55()
	{
	}

	// Token: 0x06001C1D RID: 7197 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB00", Offset = "0x221CB00", VA = "0x221CB00", Slot = "60")]
	[Token(Token = "0x6001C1D")]
	public virtual void vmethod_56()
	{
	}

	// Token: 0x06001C1E RID: 7198 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB04", Offset = "0x221CB04", VA = "0x221CB04", Slot = "61")]
	[Token(Token = "0x6001C1E")]
	public virtual void vmethod_57()
	{
	}

	// Token: 0x06001C1F RID: 7199 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB08", Offset = "0x221CB08", VA = "0x221CB08", Slot = "62")]
	[Token(Token = "0x6001C1F")]
	public virtual void vmethod_58()
	{
	}

	// Token: 0x06001C20 RID: 7200 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB0C", Offset = "0x221CB0C", VA = "0x221CB0C", Slot = "63")]
	[Token(Token = "0x6001C20")]
	public virtual void vmethod_59()
	{
	}

	// Token: 0x06001C21 RID: 7201 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB10", Offset = "0x221CB10", VA = "0x221CB10", Slot = "64")]
	[Token(Token = "0x6001C21")]
	public virtual void vmethod_60()
	{
	}

	// Token: 0x06001C22 RID: 7202 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CB14", Offset = "0x221CB14", VA = "0x221CB14", Slot = "65")]
	[Token(Token = "0x6001C22")]
	public virtual bool vmethod_61(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C23 RID: 7203 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB1C", Offset = "0x221CB1C", VA = "0x221CB1C", Slot = "66")]
	[Token(Token = "0x6001C23")]
	public virtual void Start()
	{
	}

	// Token: 0x06001C24 RID: 7204 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CB20", Offset = "0x221CB20", VA = "0x221CB20")]
	[Token(Token = "0x6001C24")]
	public int method_29()
	{
		return this.int_0;
	}

	// Token: 0x06001C25 RID: 7205 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB28", Offset = "0x221CB28", VA = "0x221CB28", Slot = "67")]
	[Token(Token = "0x6001C25")]
	public virtual void vmethod_62()
	{
	}

	// Token: 0x06001C26 RID: 7206 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB2C", Offset = "0x221CB2C", VA = "0x221CB2C", Slot = "68")]
	[Token(Token = "0x6001C26")]
	public virtual void vmethod_63()
	{
	}

	// Token: 0x06001C27 RID: 7207 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB30", Offset = "0x221CB30", VA = "0x221CB30", Slot = "69")]
	[Token(Token = "0x6001C27")]
	public virtual void vmethod_64()
	{
	}

	// Token: 0x06001C28 RID: 7208 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CB34", Offset = "0x221CB34", VA = "0x221CB34")]
	[Token(Token = "0x6001C28")]
	public void method_30(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C29 RID: 7209 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB3C", Offset = "0x221CB3C", VA = "0x221CB3C", Slot = "70")]
	[Token(Token = "0x6001C29")]
	public virtual void vmethod_65()
	{
	}

	// Token: 0x06001C2A RID: 7210 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB40", Offset = "0x221CB40", VA = "0x221CB40", Slot = "71")]
	[Token(Token = "0x6001C2A")]
	public virtual void vmethod_66()
	{
	}

	// Token: 0x06001C2B RID: 7211 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CB44", Offset = "0x221CB44", VA = "0x221CB44")]
	[Token(Token = "0x6001C2B")]
	public void method_31(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C2C RID: 7212 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB4C", Offset = "0x221CB4C", VA = "0x221CB4C", Slot = "72")]
	[Token(Token = "0x6001C2C")]
	public virtual void vmethod_67()
	{
	}

	// Token: 0x06001C2D RID: 7213 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CB50", Offset = "0x221CB50", VA = "0x221CB50", Slot = "73")]
	[Token(Token = "0x6001C2D")]
	public virtual bool vmethod_68(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C2E RID: 7214 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CB58", Offset = "0x221CB58", VA = "0x221CB58", Slot = "74")]
	[Token(Token = "0x6001C2E")]
	public virtual bool vmethod_69(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C2F RID: 7215 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB60", Offset = "0x221CB60", VA = "0x221CB60", Slot = "75")]
	[Token(Token = "0x6001C2F")]
	public virtual void vmethod_70()
	{
	}

	// Token: 0x06001C30 RID: 7216 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB64", Offset = "0x221CB64", VA = "0x221CB64", Slot = "76")]
	[Token(Token = "0x6001C30")]
	public virtual void vmethod_71()
	{
	}

	// Token: 0x06001C31 RID: 7217 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB68", Offset = "0x221CB68", VA = "0x221CB68", Slot = "77")]
	[Token(Token = "0x6001C31")]
	public virtual void vmethod_72()
	{
	}

	// Token: 0x06001C32 RID: 7218 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CB6C", Offset = "0x221CB6C", VA = "0x221CB6C", Slot = "78")]
	[Token(Token = "0x6001C32")]
	public virtual bool vmethod_73(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C33 RID: 7219 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CB74", Offset = "0x221CB74", VA = "0x221CB74", Slot = "79")]
	[Token(Token = "0x6001C33")]
	public virtual bool vmethod_74(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C34 RID: 7220 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CB7C", Offset = "0x221CB7C", VA = "0x221CB7C")]
	[Token(Token = "0x6001C34")]
	public void method_32(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C35 RID: 7221 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x221CB84", Offset = "0x221CB84", VA = "0x221CB84")]
	[Token(Token = "0x6001C35")]
	public int method_33()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C36 RID: 7222 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CB8C", Offset = "0x221CB8C", VA = "0x221CB8C", Slot = "80")]
	[Token(Token = "0x6001C36")]
	public virtual bool vmethod_75(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C37 RID: 7223 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB94", Offset = "0x221CB94", VA = "0x221CB94", Slot = "81")]
	[Token(Token = "0x6001C37")]
	public virtual void vmethod_76()
	{
	}

	// Token: 0x06001C38 RID: 7224 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CB98", Offset = "0x221CB98", VA = "0x221CB98", Slot = "82")]
	[Token(Token = "0x6001C38")]
	public virtual void vmethod_77()
	{
	}

	// Token: 0x06001C39 RID: 7225 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CB9C", Offset = "0x221CB9C", VA = "0x221CB9C")]
	[Token(Token = "0x6001C39")]
	public int method_34()
	{
		return this.int_0;
	}

	// Token: 0x06001C3A RID: 7226 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CBA4", Offset = "0x221CBA4", VA = "0x221CBA4", Slot = "83")]
	[Token(Token = "0x6001C3A")]
	public virtual void vmethod_78()
	{
	}

	// Token: 0x06001C3B RID: 7227 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CBA8", Offset = "0x221CBA8", VA = "0x221CBA8", Slot = "84")]
	[Token(Token = "0x6001C3B")]
	public virtual void vmethod_79()
	{
	}

	// Token: 0x06001C3C RID: 7228 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CBAC", Offset = "0x221CBAC", VA = "0x221CBAC")]
	[Token(Token = "0x6001C3C")]
	public int method_35()
	{
		return this.int_0;
	}

	// Token: 0x06001C3D RID: 7229 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CBB4", Offset = "0x221CBB4", VA = "0x221CBB4")]
	[Token(Token = "0x6001C3D")]
	public int method_36()
	{
		return this.int_0;
	}

	// Token: 0x06001C3E RID: 7230 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CBBC", Offset = "0x221CBBC", VA = "0x221CBBC")]
	[Token(Token = "0x6001C3E")]
	public void method_37(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C3F RID: 7231 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x221CBC4", Offset = "0x221CBC4", VA = "0x221CBC4", Slot = "85")]
	[Token(Token = "0x6001C3F")]
	public virtual bool vmethod_80(ref Vector3 vector3_1, float float_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001C40 RID: 7232 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CBCC", Offset = "0x221CBCC", VA = "0x221CBCC", Slot = "86")]
	[Token(Token = "0x6001C40")]
	public virtual void vmethod_81()
	{
	}

	// Token: 0x06001C41 RID: 7233 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CBD0", Offset = "0x221CBD0", VA = "0x221CBD0", Slot = "87")]
	[Token(Token = "0x6001C41")]
	public virtual void vmethod_82()
	{
	}

	// Token: 0x06001C42 RID: 7234 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CBD4", Offset = "0x221CBD4", VA = "0x221CBD4", Slot = "88")]
	[Token(Token = "0x6001C42")]
	public virtual void vmethod_83()
	{
	}

	// Token: 0x06001C43 RID: 7235 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CBD8", Offset = "0x221CBD8", VA = "0x221CBD8")]
	[Token(Token = "0x6001C43")]
	public void method_38(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C44 RID: 7236 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CBE0", Offset = "0x221CBE0", VA = "0x221CBE0")]
	[Token(Token = "0x6001C44")]
	public int method_39()
	{
		return this.int_0;
	}

	// Token: 0x06001C45 RID: 7237 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CBE8", Offset = "0x221CBE8", VA = "0x221CBE8", Slot = "89")]
	[Token(Token = "0x6001C45")]
	public virtual void vmethod_84()
	{
	}

	// Token: 0x06001C46 RID: 7238 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CBEC", Offset = "0x221CBEC", VA = "0x221CBEC")]
	[Token(Token = "0x6001C46")]
	public void method_40(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C47 RID: 7239 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CBF4", Offset = "0x221CBF4", VA = "0x221CBF4", Slot = "90")]
	[Token(Token = "0x6001C47")]
	public virtual bool vmethod_85(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C48 RID: 7240 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CBFC", Offset = "0x221CBFC", VA = "0x221CBFC")]
	[Token(Token = "0x6001C48")]
	public int method_41()
	{
		return this.int_0;
	}

	// Token: 0x06001C4A RID: 7242 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CC0C", Offset = "0x221CC0C", VA = "0x221CC0C", Slot = "91")]
	[Token(Token = "0x6001C4A")]
	public virtual bool vmethod_86(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C4B RID: 7243 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CC14", Offset = "0x221CC14", VA = "0x221CC14", Slot = "92")]
	[Token(Token = "0x6001C4B")]
	public virtual bool vmethod_87(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C4C RID: 7244 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CC1C", Offset = "0x221CC1C", VA = "0x221CC1C")]
	[Token(Token = "0x6001C4C")]
	public void method_42(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C4D RID: 7245 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CC24", Offset = "0x221CC24", VA = "0x221CC24", Slot = "93")]
	[Token(Token = "0x6001C4D")]
	public virtual void vmethod_88()
	{
	}

	// Token: 0x06001C4E RID: 7246 RVA: 0x000029E6 File Offset: 0x00000BE6
	[Address(RVA = "0x221CC28", Offset = "0x221CC28", VA = "0x221CC28")]
	[Token(Token = "0x6001C4E")]
	public void method_43(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06001C4F RID: 7247 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CC30", Offset = "0x221CC30", VA = "0x221CC30", Slot = "94")]
	[Token(Token = "0x6001C4F")]
	public virtual bool vmethod_89(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C50 RID: 7248 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CC38", Offset = "0x221CC38", VA = "0x221CC38", Slot = "95")]
	[Token(Token = "0x6001C50")]
	public virtual void vmethod_90()
	{
	}

	// Token: 0x06001C51 RID: 7249 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CC3C", Offset = "0x221CC3C", VA = "0x221CC3C", Slot = "96")]
	[Token(Token = "0x6001C51")]
	public virtual void vmethod_91()
	{
	}

	// Token: 0x06001C52 RID: 7250 RVA: 0x000029EF File Offset: 0x00000BEF
	[Address(RVA = "0x221CC40", Offset = "0x221CC40", VA = "0x221CC40")]
	[Token(Token = "0x6001C52")]
	public int method_44()
	{
		return this.int_0;
	}

	// Token: 0x06001C53 RID: 7251 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CC48", Offset = "0x221CC48", VA = "0x221CC48", Slot = "97")]
	[Token(Token = "0x6001C53")]
	public virtual void vmethod_92()
	{
	}

	// Token: 0x06001C54 RID: 7252 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CC4C", Offset = "0x221CC4C", VA = "0x221CC4C", Slot = "98")]
	[Token(Token = "0x6001C54")]
	public virtual bool vmethod_93(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C55 RID: 7253 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CC54", Offset = "0x221CC54", VA = "0x221CC54", Slot = "99")]
	[Token(Token = "0x6001C55")]
	public virtual void vmethod_94()
	{
	}

	// Token: 0x06001C56 RID: 7254 RVA: 0x00035BFC File Offset: 0x00033DFC
	[Address(RVA = "0x221CC58", Offset = "0x221CC58", VA = "0x221CC58", Slot = "100")]
	[Token(Token = "0x6001C56")]
	public virtual bool vmethod_95(ref Vector3 vector3_1, float float_0)
	{
	}

	// Token: 0x06001C57 RID: 7255 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CC60", Offset = "0x221CC60", VA = "0x221CC60", Slot = "101")]
	[Token(Token = "0x6001C57")]
	public virtual void vmethod_96()
	{
	}

	// Token: 0x06001C58 RID: 7256 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x221CC64", Offset = "0x221CC64", VA = "0x221CC64", Slot = "102")]
	[Token(Token = "0x6001C58")]
	public virtual void vmethod_97()
	{
	}

	// Token: 0x040003D1 RID: 977
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003D1")]
	public DynamicBoneColliderBase.GEnum10 genum10_0;

	// Token: 0x040003D2 RID: 978
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40003D2")]
	public Vector3 vector3_0;

	// Token: 0x040003D3 RID: 979
	[Token(Token = "0x40003D3")]
	[FieldOffset(Offset = "0x28")]
	public DynamicBoneColliderBase.GEnum11 genum11_0;

	// Token: 0x040003D4 RID: 980
	[CompilerGenerated]
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x40003D4")]
	private int int_0;

	// Token: 0x020000C6 RID: 198
	[Token(Token = "0x20000C6")]
	public enum GEnum10
	{
		// Token: 0x040003D6 RID: 982
		[Token(Token = "0x40003D6")]
		const_0,
		// Token: 0x040003D7 RID: 983
		[Token(Token = "0x40003D7")]
		const_1,
		// Token: 0x040003D8 RID: 984
		[Token(Token = "0x40003D8")]
		const_2
	}

	// Token: 0x020000C7 RID: 199
	[Token(Token = "0x20000C7")]
	public enum GEnum11
	{
		// Token: 0x040003DA RID: 986
		[Token(Token = "0x40003DA")]
		const_0,
		// Token: 0x040003DB RID: 987
		[Token(Token = "0x40003DB")]
		const_1
	}
}
