﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using CapuchinPlayFab;
using Cpp2IlInjected;
using PlayFab;
using PlayFab.ClientModels;
using UnityEngine;

// Token: 0x020000E4 RID: 228
[Token(Token = "0x20000E4")]
public class PlayFabAccountItemChecker : MonoBehaviour
{
	// Token: 0x0600220B RID: 8715 RVA: 0x0003F16C File Offset: 0x0003D36C
	[Address(RVA = "0x305BCFC", Offset = "0x305BCFC", VA = "0x305BCFC")]
	[Token(Token = "0x600220B")]
	public void method_0()
	{
		IEnumerator routine = this.method_35();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600220C RID: 8716 RVA: 0x0003F188 File Offset: 0x0003D388
	[Address(RVA = "0x305BDA0", Offset = "0x305BDA0", VA = "0x305BDA0")]
	[Token(Token = "0x600220C")]
	public void method_1()
	{
		IEnumerator routine = this.method_53();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600220D RID: 8717 RVA: 0x0003F1A4 File Offset: 0x0003D3A4
	[Address(RVA = "0x305BE44", Offset = "0x305BE44", VA = "0x305BE44")]
	[Token(Token = "0x600220D")]
	public void method_2()
	{
		IEnumerator routine = this.method_48();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600220E RID: 8718 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305BEE8", Offset = "0x305BEE8", VA = "0x305BEE8")]
	[Token(Token = "0x600220E")]
	private IEnumerator method_3()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600220F RID: 8719 RVA: 0x0003F1E8 File Offset: 0x0003D3E8
	[Address(RVA = "0x305BF60", Offset = "0x305BF60", VA = "0x305BF60")]
	[Token(Token = "0x600220F")]
	private void method_4(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002210 RID: 8720 RVA: 0x0003F21C File Offset: 0x0003D41C
	[Address(RVA = "0x305C0CC", Offset = "0x305C0CC", VA = "0x305C0CC")]
	[Token(Token = "0x6002210")]
	private void method_5(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x06002211 RID: 8721 RVA: 0x0003F23C File Offset: 0x0003D43C
	[Address(RVA = "0x305C16C", Offset = "0x305C16C", VA = "0x305C16C")]
	[Token(Token = "0x6002211")]
	public void method_6()
	{
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002212 RID: 8722 RVA: 0x0003F258 File Offset: 0x0003D458
	[Address(RVA = "0x305C210", Offset = "0x305C210", VA = "0x305C210")]
	[Token(Token = "0x6002212")]
	public void method_7()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x06002213 RID: 8723 RVA: 0x0003F26C File Offset: 0x0003D46C
	[Address(RVA = "0x305C364", Offset = "0x305C364", VA = "0x305C364")]
	[Token(Token = "0x6002213")]
	public void method_8()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x06002214 RID: 8724 RVA: 0x0003F1E8 File Offset: 0x0003D3E8
	[Address(RVA = "0x305C4B8", Offset = "0x305C4B8", VA = "0x305C4B8")]
	[Token(Token = "0x6002214")]
	private void method_9(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002215 RID: 8725 RVA: 0x0003F280 File Offset: 0x0003D480
	[Address(RVA = "0x305C624", Offset = "0x305C624", VA = "0x305C624")]
	[Token(Token = "0x6002215")]
	private void method_10(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002216 RID: 8726 RVA: 0x0003F280 File Offset: 0x0003D480
	[Address(RVA = "0x305C790", Offset = "0x305C790", VA = "0x305C790")]
	[Token(Token = "0x6002216")]
	private void method_11(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002217 RID: 8727 RVA: 0x0003F258 File Offset: 0x0003D458
	[Address(RVA = "0x305C8FC", Offset = "0x305C8FC", VA = "0x305C8FC")]
	[Token(Token = "0x6002217")]
	public void method_12()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x06002218 RID: 8728 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305CA50", Offset = "0x305CA50", VA = "0x305CA50")]
	[Token(Token = "0x6002218")]
	private IEnumerator method_13()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002219 RID: 8729 RVA: 0x0003F2B4 File Offset: 0x0003D4B4
	[Address(RVA = "0x305CAC8", Offset = "0x305CAC8", VA = "0x305CAC8")]
	[Token(Token = "0x6002219")]
	private void method_14(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x0600221A RID: 8730 RVA: 0x0003F23C File Offset: 0x0003D43C
	[Address(RVA = "0x305CB68", Offset = "0x305CB68", VA = "0x305CB68")]
	[Token(Token = "0x600221A")]
	public void method_15()
	{
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600221B RID: 8731 RVA: 0x0003F23C File Offset: 0x0003D43C
	[Address(RVA = "0x305CB94", Offset = "0x305CB94", VA = "0x305CB94")]
	[Token(Token = "0x600221B")]
	public void method_16()
	{
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600221C RID: 8732 RVA: 0x0003F1E8 File Offset: 0x0003D3E8
	[Address(RVA = "0x305CBC0", Offset = "0x305CBC0", VA = "0x305CBC0")]
	[Token(Token = "0x600221C")]
	private void method_17(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600221D RID: 8733 RVA: 0x0003F258 File Offset: 0x0003D458
	[Address(RVA = "0x305CD2C", Offset = "0x305CD2C", VA = "0x305CD2C")]
	[Token(Token = "0x600221D")]
	public void method_18()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x0600221E RID: 8734 RVA: 0x0003F23C File Offset: 0x0003D43C
	[Address(RVA = "0x305CE80", Offset = "0x305CE80", VA = "0x305CE80")]
	[Token(Token = "0x600221E")]
	public void method_19()
	{
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600221F RID: 8735 RVA: 0x0003F1E8 File Offset: 0x0003D3E8
	[Address(RVA = "0x305CEAC", Offset = "0x305CEAC", VA = "0x305CEAC")]
	[Token(Token = "0x600221F")]
	private void method_20(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002220 RID: 8736 RVA: 0x0003F21C File Offset: 0x0003D41C
	[Address(RVA = "0x305D018", Offset = "0x305D018", VA = "0x305D018")]
	[Token(Token = "0x6002220")]
	private void method_21(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x06002221 RID: 8737 RVA: 0x0003F2D4 File Offset: 0x0003D4D4
	[Address(RVA = "0x305D0B8", Offset = "0x305D0B8", VA = "0x305D0B8")]
	[Token(Token = "0x6002221")]
	public void method_22()
	{
		IEnumerator routine = this.method_26();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002222 RID: 8738 RVA: 0x0003F2F0 File Offset: 0x0003D4F0
	[Address(RVA = "0x305D15C", Offset = "0x305D15C", VA = "0x305D15C")]
	[Token(Token = "0x6002222")]
	public void method_23()
	{
		IEnumerator routine = this.method_3();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002223 RID: 8739 RVA: 0x0003F30C File Offset: 0x0003D50C
	[Address(RVA = "0x305D188", Offset = "0x305D188", VA = "0x305D188")]
	[Token(Token = "0x6002223")]
	public void Awake()
	{
		IEnumerator routine = this.method_25();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002224 RID: 8740 RVA: 0x0003F1E8 File Offset: 0x0003D3E8
	[Address(RVA = "0x305D22C", Offset = "0x305D22C", VA = "0x305D22C")]
	[Token(Token = "0x6002224")]
	private void method_24(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002225 RID: 8741 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305D1B4", Offset = "0x305D1B4", VA = "0x305D1B4")]
	[Token(Token = "0x6002225")]
	private IEnumerator method_25()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002226 RID: 8742 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305D0E4", Offset = "0x305D0E4", VA = "0x305D0E4")]
	[Token(Token = "0x6002226")]
	private IEnumerator method_26()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002227 RID: 8743 RVA: 0x0003F280 File Offset: 0x0003D480
	[Address(RVA = "0x305D398", Offset = "0x305D398", VA = "0x305D398")]
	[Token(Token = "0x6002227")]
	private void method_27(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002228 RID: 8744 RVA: 0x0003F258 File Offset: 0x0003D458
	[Address(RVA = "0x305D504", Offset = "0x305D504", VA = "0x305D504")]
	[Token(Token = "0x6002228")]
	public void method_28()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x06002229 RID: 8745 RVA: 0x0003F328 File Offset: 0x0003D528
	[Address(RVA = "0x305D658", Offset = "0x305D658", VA = "0x305D658")]
	[Token(Token = "0x6002229")]
	public void method_29()
	{
		IEnumerator routine = this.method_67();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600222A RID: 8746 RVA: 0x0003F280 File Offset: 0x0003D480
	[CompilerGenerated]
	[Address(RVA = "0x305D6FC", Offset = "0x305D6FC", VA = "0x305D6FC")]
	[Token(Token = "0x600222A")]
	private void method_30(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600222B RID: 8747 RVA: 0x0003F258 File Offset: 0x0003D458
	[Address(RVA = "0x305D868", Offset = "0x305D868", VA = "0x305D868")]
	[Token(Token = "0x600222B")]
	public void method_31()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x0600222C RID: 8748 RVA: 0x0003F23C File Offset: 0x0003D43C
	[Address(RVA = "0x305D9BC", Offset = "0x305D9BC", VA = "0x305D9BC")]
	[Token(Token = "0x600222C")]
	public void method_32()
	{
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600222D RID: 8749 RVA: 0x0003F344 File Offset: 0x0003D544
	[Address(RVA = "0x305D9E8", Offset = "0x305D9E8", VA = "0x305D9E8")]
	[Token(Token = "0x600222D")]
	public void method_33()
	{
		IEnumerator routine = this.method_51();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600222E RID: 8750 RVA: 0x0003F21C File Offset: 0x0003D41C
	[CompilerGenerated]
	[Address(RVA = "0x305DA8C", Offset = "0x305DA8C", VA = "0x305DA8C")]
	[Token(Token = "0x600222E")]
	private void method_34(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x0600222F RID: 8751 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305BD28", Offset = "0x305BD28", VA = "0x305BD28")]
	[Token(Token = "0x600222F")]
	private IEnumerator method_35()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002230 RID: 8752 RVA: 0x0003F21C File Offset: 0x0003D41C
	[Address(RVA = "0x305DB2C", Offset = "0x305DB2C", VA = "0x305DB2C")]
	[Token(Token = "0x6002230")]
	private void method_36(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x06002231 RID: 8753 RVA: 0x0003F21C File Offset: 0x0003D41C
	[Address(RVA = "0x305DBCC", Offset = "0x305DBCC", VA = "0x305DBCC")]
	[Token(Token = "0x6002231")]
	private void method_37(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x06002232 RID: 8754 RVA: 0x0003F360 File Offset: 0x0003D560
	[Address(RVA = "0x305DC6C", Offset = "0x305DC6C", VA = "0x305DC6C")]
	[Token(Token = "0x6002232")]
	public void method_38()
	{
		IEnumerator routine = this.method_50();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002233 RID: 8755 RVA: 0x0003F37C File Offset: 0x0003D57C
	[Address(RVA = "0x305DD10", Offset = "0x305DD10", VA = "0x305DD10")]
	[Token(Token = "0x6002233")]
	public void method_39()
	{
		IEnumerator routine = this.method_68();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002234 RID: 8756 RVA: 0x0003F1E8 File Offset: 0x0003D3E8
	[Address(RVA = "0x305DDB4", Offset = "0x305DDB4", VA = "0x305DDB4")]
	[Token(Token = "0x6002234")]
	private void method_40(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002235 RID: 8757 RVA: 0x0003F26C File Offset: 0x0003D46C
	[Address(RVA = "0x305DF20", Offset = "0x305DF20", VA = "0x305DF20")]
	[Token(Token = "0x6002235")]
	public void method_41()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x06002236 RID: 8758 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x305E074", Offset = "0x305E074", VA = "0x305E074")]
	[Token(Token = "0x6002236")]
	public PlayFabAccountItemChecker()
	{
	}

	// Token: 0x06002237 RID: 8759 RVA: 0x0003F21C File Offset: 0x0003D41C
	[Address(RVA = "0x305E07C", Offset = "0x305E07C", VA = "0x305E07C")]
	[Token(Token = "0x6002237")]
	private void method_42(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x06002238 RID: 8760 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305C198", Offset = "0x305C198", VA = "0x305C198")]
	[Token(Token = "0x6002238")]
	private IEnumerator method_43()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002239 RID: 8761 RVA: 0x0003F258 File Offset: 0x0003D458
	[Address(RVA = "0x305E11C", Offset = "0x305E11C", VA = "0x305E11C")]
	[Token(Token = "0x6002239")]
	public void method_44()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x0600223A RID: 8762 RVA: 0x0003F30C File Offset: 0x0003D50C
	[Address(RVA = "0x305E270", Offset = "0x305E270", VA = "0x305E270")]
	[Token(Token = "0x600223A")]
	public void method_45()
	{
		IEnumerator routine = this.method_25();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600223B RID: 8763 RVA: 0x0003F280 File Offset: 0x0003D480
	[Address(RVA = "0x305E29C", Offset = "0x305E29C", VA = "0x305E29C")]
	[Token(Token = "0x600223B")]
	private void method_46(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600223C RID: 8764 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305E408", Offset = "0x305E408", VA = "0x305E408")]
	[Token(Token = "0x600223C")]
	private IEnumerator method_47()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600223D RID: 8765 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305BE70", Offset = "0x305BE70", VA = "0x305BE70")]
	[Token(Token = "0x600223D")]
	private IEnumerator method_48()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600223E RID: 8766 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305E480", Offset = "0x305E480", VA = "0x305E480")]
	[Token(Token = "0x600223E")]
	private IEnumerator method_49()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600223F RID: 8767 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305DC98", Offset = "0x305DC98", VA = "0x305DC98")]
	[Token(Token = "0x600223F")]
	private IEnumerator method_50()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002240 RID: 8768 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305DA14", Offset = "0x305DA14", VA = "0x305DA14")]
	[Token(Token = "0x6002240")]
	private IEnumerator method_51()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002241 RID: 8769 RVA: 0x0003F1E8 File Offset: 0x0003D3E8
	[Address(RVA = "0x305E4F8", Offset = "0x305E4F8", VA = "0x305E4F8")]
	[Token(Token = "0x6002241")]
	private void method_52(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002242 RID: 8770 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305BDCC", Offset = "0x305BDCC", VA = "0x305BDCC")]
	[Token(Token = "0x6002242")]
	private IEnumerator method_53()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002243 RID: 8771 RVA: 0x0003F21C File Offset: 0x0003D41C
	[Address(RVA = "0x305E664", Offset = "0x305E664", VA = "0x305E664")]
	[Token(Token = "0x6002243")]
	private void method_54(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x06002244 RID: 8772 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305E704", Offset = "0x305E704", VA = "0x305E704")]
	[Token(Token = "0x6002244")]
	private IEnumerator method_55()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002245 RID: 8773 RVA: 0x0003F344 File Offset: 0x0003D544
	[Address(RVA = "0x305E77C", Offset = "0x305E77C", VA = "0x305E77C")]
	[Token(Token = "0x6002245")]
	public void method_56()
	{
		IEnumerator routine = this.method_51();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002246 RID: 8774 RVA: 0x0003F398 File Offset: 0x0003D598
	[Address(RVA = "0x305E7A8", Offset = "0x305E7A8", VA = "0x305E7A8")]
	[Token(Token = "0x6002246")]
	public void method_57()
	{
		IEnumerator routine = this.method_65();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002247 RID: 8775 RVA: 0x0003F2D4 File Offset: 0x0003D4D4
	[Address(RVA = "0x305E84C", Offset = "0x305E84C", VA = "0x305E84C")]
	[Token(Token = "0x6002247")]
	public void method_58()
	{
		IEnumerator routine = this.method_26();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002248 RID: 8776 RVA: 0x0003F16C File Offset: 0x0003D36C
	[Address(RVA = "0x305E878", Offset = "0x305E878", VA = "0x305E878")]
	[Token(Token = "0x6002248")]
	public void method_59()
	{
		IEnumerator routine = this.method_35();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002249 RID: 8777 RVA: 0x0003F188 File Offset: 0x0003D388
	[Address(RVA = "0x305E8A4", Offset = "0x305E8A4", VA = "0x305E8A4")]
	[Token(Token = "0x6002249")]
	public void method_60()
	{
		IEnumerator routine = this.method_53();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600224A RID: 8778 RVA: 0x0003F3B4 File Offset: 0x0003D5B4
	[Address(RVA = "0x305E8D0", Offset = "0x305E8D0", VA = "0x305E8D0")]
	[Token(Token = "0x600224A")]
	public void method_61()
	{
		IEnumerator routine = this.method_47();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600224B RID: 8779 RVA: 0x0003F21C File Offset: 0x0003D41C
	[Address(RVA = "0x305E8FC", Offset = "0x305E8FC", VA = "0x305E8FC")]
	[Token(Token = "0x600224B")]
	private void method_62(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x0600224C RID: 8780 RVA: 0x0003F21C File Offset: 0x0003D41C
	[Address(RVA = "0x305E99C", Offset = "0x305E99C", VA = "0x305E99C")]
	[Token(Token = "0x600224C")]
	private void method_63(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x0600224D RID: 8781 RVA: 0x0003F3D0 File Offset: 0x0003D5D0
	[Address(RVA = "0x305EA3C", Offset = "0x305EA3C", VA = "0x305EA3C")]
	[Token(Token = "0x600224D")]
	private void method_64(PlayFabError playFabError_0)
	{
		long num = 1L;
		GameObject obj = this.gameObject_0;
		if (num != 0L)
		{
		}
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x0600224E RID: 8782 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305E7D4", Offset = "0x305E7D4", VA = "0x305E7D4")]
	[Token(Token = "0x600224E")]
	private IEnumerator method_65()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600224F RID: 8783 RVA: 0x0003F258 File Offset: 0x0003D458
	[Address(RVA = "0x305EADC", Offset = "0x305EADC", VA = "0x305EADC")]
	[Token(Token = "0x600224F")]
	public void method_66()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x06002250 RID: 8784 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305D684", Offset = "0x305D684", VA = "0x305D684")]
	[Token(Token = "0x6002250")]
	private IEnumerator method_67()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002251 RID: 8785 RVA: 0x0003F1C0 File Offset: 0x0003D3C0
	[Address(RVA = "0x305DD3C", Offset = "0x305DD3C", VA = "0x305DD3C")]
	[Token(Token = "0x6002251")]
	private IEnumerator method_68()
	{
		PlayFabAccountItemChecker.Class33 @class = new PlayFabAccountItemChecker.Class33((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002252 RID: 8786 RVA: 0x0003F258 File Offset: 0x0003D458
	[Address(RVA = "0x305EC30", Offset = "0x305EC30", VA = "0x305EC30")]
	[Token(Token = "0x6002252")]
	public void method_69()
	{
		new GetUserInventoryRequest();
	}

	// Token: 0x06002253 RID: 8787 RVA: 0x0003F1E8 File Offset: 0x0003D3E8
	[Address(RVA = "0x305ED84", Offset = "0x305ED84", VA = "0x305ED84")]
	[Token(Token = "0x6002253")]
	private void method_70(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002254 RID: 8788 RVA: 0x0003F21C File Offset: 0x0003D41C
	[Address(RVA = "0x305EEF0", Offset = "0x305EEF0", VA = "0x305EEF0")]
	[Token(Token = "0x6002254")]
	private void method_71(PlayFabError playFabError_0)
	{
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		Application.Quit();
	}

	// Token: 0x06002255 RID: 8789 RVA: 0x0003F16C File Offset: 0x0003D36C
	[Address(RVA = "0x305EF90", Offset = "0x305EF90", VA = "0x305EF90")]
	[Token(Token = "0x6002255")]
	public void method_72()
	{
		IEnumerator routine = this.method_35();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002256 RID: 8790 RVA: 0x0003F3F4 File Offset: 0x0003D5F4
	[Address(RVA = "0x305EFBC", Offset = "0x305EFBC", VA = "0x305EFBC")]
	[Token(Token = "0x6002256")]
	private IEnumerator method_73()
	{
		PlayFabAccountItemChecker.Class33 @class;
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06002257 RID: 8791 RVA: 0x0003F1A4 File Offset: 0x0003D3A4
	[Address(RVA = "0x305F034", Offset = "0x305F034", VA = "0x305F034")]
	[Token(Token = "0x6002257")]
	public void method_74()
	{
		IEnumerator routine = this.method_48();
		base.StartCoroutine(routine);
	}

	// Token: 0x04000476 RID: 1142
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000476")]
	public LoginManager loginManager_0;

	// Token: 0x04000477 RID: 1143
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000477")]
	public string string_0;

	// Token: 0x04000478 RID: 1144
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000478")]
	public string string_1;

	// Token: 0x04000479 RID: 1145
	[Token(Token = "0x4000479")]
	[FieldOffset(Offset = "0x30")]
	public GameObject gameObject_0;
}
