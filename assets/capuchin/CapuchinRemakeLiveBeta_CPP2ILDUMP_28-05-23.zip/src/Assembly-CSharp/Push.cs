﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200003D RID: 61
[Token(Token = "0x200003D")]
public class Push : MonoBehaviour
{
	// Token: 0x060007CF RID: 1999 RVA: 0x00012030 File Offset: 0x00010230
	[Token(Token = "0x60007CF")]
	[Address(RVA = "0x2A8684C", Offset = "0x2A8684C", VA = "0x2A8684C")]
	public void method_0()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007D0 RID: 2000 RVA: 0x00012068 File Offset: 0x00010268
	[Token(Token = "0x60007D0")]
	[Address(RVA = "0x2A868E0", Offset = "0x2A868E0", VA = "0x2A868E0")]
	public void method_1(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "ChangePlayerSize";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007D1 RID: 2001 RVA: 0x0001209C File Offset: 0x0001029C
	[Token(Token = "0x60007D1")]
	[Address(RVA = "0x2A869D8", Offset = "0x2A869D8", VA = "0x2A869D8")]
	public void method_2()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007D2 RID: 2002 RVA: 0x00012030 File Offset: 0x00010230
	[Address(RVA = "0x2A86A6C", Offset = "0x2A86A6C", VA = "0x2A86A6C")]
	[Token(Token = "0x60007D2")]
	public void method_3()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007D3 RID: 2003 RVA: 0x000120D4 File Offset: 0x000102D4
	[Token(Token = "0x60007D3")]
	[Address(RVA = "0x2A86B00", Offset = "0x2A86B00", VA = "0x2A86B00")]
	public void method_4()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 0L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007D4 RID: 2004 RVA: 0x00012030 File Offset: 0x00010230
	[Token(Token = "0x60007D4")]
	[Address(RVA = "0x2A86B98", Offset = "0x2A86B98", VA = "0x2A86B98")]
	public void method_5()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007D5 RID: 2005 RVA: 0x0001210C File Offset: 0x0001030C
	[Address(RVA = "0x2A86C30", Offset = "0x2A86C30", VA = "0x2A86C30")]
	[Token(Token = "0x60007D5")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "Add/Remove Hat";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007D6 RID: 2006 RVA: 0x00012144 File Offset: 0x00010344
	[Token(Token = "0x60007D6")]
	[Address(RVA = "0x2A86D28", Offset = "0x2A86D28", VA = "0x2A86D28")]
	public void Update()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
		}
	}

	// Token: 0x060007D7 RID: 2007 RVA: 0x00012144 File Offset: 0x00010344
	[Token(Token = "0x60007D7")]
	[Address(RVA = "0x2A86DB8", Offset = "0x2A86DB8", VA = "0x2A86DB8")]
	public void method_7()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
		}
	}

	// Token: 0x060007D8 RID: 2008 RVA: 0x00012144 File Offset: 0x00010344
	[Address(RVA = "0x2A86E48", Offset = "0x2A86E48", VA = "0x2A86E48")]
	[Token(Token = "0x60007D8")]
	public void method_8()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
		}
	}

	// Token: 0x060007D9 RID: 2009 RVA: 0x00012170 File Offset: 0x00010370
	[Address(RVA = "0x2A86ED8", Offset = "0x2A86ED8", VA = "0x2A86ED8")]
	[Token(Token = "0x60007D9")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.tag == "liftoff failed!";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007DA RID: 2010 RVA: 0x000121A8 File Offset: 0x000103A8
	[Address(RVA = "0x2A86FD0", Offset = "0x2A86FD0", VA = "0x2A86FD0")]
	[Token(Token = "0x60007DA")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "/";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007DB RID: 2011 RVA: 0x000121E0 File Offset: 0x000103E0
	[Token(Token = "0x60007DB")]
	[Address(RVA = "0x2A870C8", Offset = "0x2A870C8", VA = "0x2A870C8")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007DC RID: 2012 RVA: 0x00012218 File Offset: 0x00010418
	[Address(RVA = "0x2A871C0", Offset = "0x2A871C0", VA = "0x2A871C0")]
	[Token(Token = "0x60007DC")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007DD RID: 2013 RVA: 0x00012250 File Offset: 0x00010450
	[Address(RVA = "0x2A872B8", Offset = "0x2A872B8", VA = "0x2A872B8")]
	[Token(Token = "0x60007DD")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayWave";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007DE RID: 2014 RVA: 0x00012288 File Offset: 0x00010488
	[Address(RVA = "0x2A873B0", Offset = "0x2A873B0", VA = "0x2A873B0")]
	[Token(Token = "0x60007DE")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.tag == "Room Name: ";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007DF RID: 2015 RVA: 0x00012030 File Offset: 0x00010230
	[Address(RVA = "0x2A874A8", Offset = "0x2A874A8", VA = "0x2A874A8")]
	[Token(Token = "0x60007DF")]
	public void method_15()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007E0 RID: 2016 RVA: 0x00012030 File Offset: 0x00010230
	[Address(RVA = "0x2A87540", Offset = "0x2A87540", VA = "0x2A87540")]
	[Token(Token = "0x60007E0")]
	public void method_16()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007E1 RID: 2017 RVA: 0x00012030 File Offset: 0x00010230
	[Token(Token = "0x60007E1")]
	[Address(RVA = "0x2A875D8", Offset = "0x2A875D8", VA = "0x2A875D8")]
	public void method_17()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007E2 RID: 2018 RVA: 0x000120D4 File Offset: 0x000102D4
	[Address(RVA = "0x2A87670", Offset = "0x2A87670", VA = "0x2A87670")]
	[Token(Token = "0x60007E2")]
	public void method_18()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 0L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007E3 RID: 2019 RVA: 0x000122C0 File Offset: 0x000104C0
	[Address(RVA = "0x2A87710", Offset = "0x2A87710", VA = "0x2A87710")]
	[Token(Token = "0x60007E3")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007E4 RID: 2020 RVA: 0x000121E0 File Offset: 0x000103E0
	[Address(RVA = "0x2A87808", Offset = "0x2A87808", VA = "0x2A87808")]
	[Token(Token = "0x60007E4")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007E5 RID: 2021 RVA: 0x000122F8 File Offset: 0x000104F8
	[Address(RVA = "0x2A87900", Offset = "0x2A87900", VA = "0x2A87900")]
	[Token(Token = "0x60007E5")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.tag == "A Player has left the Room.";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007E6 RID: 2022 RVA: 0x00012030 File Offset: 0x00010230
	[Address(RVA = "0x2A879F8", Offset = "0x2A879F8", VA = "0x2A879F8")]
	[Token(Token = "0x60007E6")]
	public void method_21()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007E7 RID: 2023 RVA: 0x00012330 File Offset: 0x00010530
	[Address(RVA = "0x2A87A90", Offset = "0x2A87A90", VA = "0x2A87A90")]
	[Token(Token = "0x60007E7")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "button";
	}

	// Token: 0x060007E8 RID: 2024 RVA: 0x00012030 File Offset: 0x00010230
	[Address(RVA = "0x2A87B88", Offset = "0x2A87B88", VA = "0x2A87B88")]
	[Token(Token = "0x60007E8")]
	public void method_23()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007E9 RID: 2025 RVA: 0x00012354 File Offset: 0x00010554
	[Token(Token = "0x60007E9")]
	[Address(RVA = "0x2A87C1C", Offset = "0x2A87C1C", VA = "0x2A87C1C")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "FLSPTLT";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007EA RID: 2026 RVA: 0x00012030 File Offset: 0x00010230
	[Token(Token = "0x60007EA")]
	[Address(RVA = "0x2A87D14", Offset = "0x2A87D14", VA = "0x2A87D14")]
	public void method_25()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007EB RID: 2027 RVA: 0x00012030 File Offset: 0x00010230
	[Address(RVA = "0x2A87DA8", Offset = "0x2A87DA8", VA = "0x2A87DA8")]
	[Token(Token = "0x60007EB")]
	public void method_26()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007EC RID: 2028 RVA: 0x00012030 File Offset: 0x00010230
	[Address(RVA = "0x2A87E40", Offset = "0x2A87E40", VA = "0x2A87E40")]
	[Token(Token = "0x60007EC")]
	public void method_27()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007ED RID: 2029 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A87ED4", Offset = "0x2A87ED4", VA = "0x2A87ED4")]
	[Token(Token = "0x60007ED")]
	public Push()
	{
	}

	// Token: 0x060007EE RID: 2030 RVA: 0x0001238C File Offset: 0x0001058C
	[Address(RVA = "0x2A87EDC", Offset = "0x2A87EDC", VA = "0x2A87EDC")]
	[Token(Token = "0x60007EE")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.tag == "\tExpires: ";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007EF RID: 2031 RVA: 0x00012144 File Offset: 0x00010344
	[Token(Token = "0x60007EF")]
	[Address(RVA = "0x2A87FD4", Offset = "0x2A87FD4", VA = "0x2A87FD4")]
	public void method_29()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
		}
	}

	// Token: 0x060007F0 RID: 2032 RVA: 0x000123C4 File Offset: 0x000105C4
	[Address(RVA = "0x2A88064", Offset = "0x2A88064", VA = "0x2A88064")]
	[Token(Token = "0x60007F0")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.tag == "PLAYER IS BANNED";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007F1 RID: 2033 RVA: 0x00012030 File Offset: 0x00010230
	[Address(RVA = "0x2A8815C", Offset = "0x2A8815C", VA = "0x2A8815C")]
	[Token(Token = "0x60007F1")]
	public void method_31()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007F2 RID: 2034 RVA: 0x00012030 File Offset: 0x00010230
	[Address(RVA = "0x2A881F4", Offset = "0x2A881F4", VA = "0x2A881F4")]
	[Token(Token = "0x60007F2")]
	public void method_32()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007F3 RID: 2035 RVA: 0x000123FC File Offset: 0x000105FC
	[Token(Token = "0x60007F3")]
	[Address(RVA = "0x2A88288", Offset = "0x2A88288", VA = "0x2A88288")]
	public void method_33(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007F4 RID: 2036 RVA: 0x0001242C File Offset: 0x0001062C
	[Address(RVA = "0x2A88380", Offset = "0x2A88380", VA = "0x2A88380")]
	[Token(Token = "0x60007F4")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "Camera movement detected, calibrating height.";
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007F5 RID: 2037 RVA: 0x00012464 File Offset: 0x00010664
	[Address(RVA = "0x2A88478", Offset = "0x2A88478", VA = "0x2A88478")]
	[Token(Token = "0x60007F5")]
	public void method_35(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		if (this.bool_0)
		{
			return;
		}
		Vector3 up = base.transform.up;
	}

	// Token: 0x060007F6 RID: 2038 RVA: 0x00012030 File Offset: 0x00010230
	[Token(Token = "0x60007F6")]
	[Address(RVA = "0x2A88570", Offset = "0x2A88570", VA = "0x2A88570")]
	public void method_36()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007F7 RID: 2039 RVA: 0x00012494 File Offset: 0x00010694
	[Address(RVA = "0x2A88604", Offset = "0x2A88604", VA = "0x2A88604")]
	[Token(Token = "0x60007F7")]
	public void method_37()
	{
		bool flag;
		if (flag = this.bool_1)
		{
			if (flag)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060007F8 RID: 2040 RVA: 0x000120D4 File Offset: 0x000102D4
	[Token(Token = "0x60007F8")]
	[Address(RVA = "0x2A88698", Offset = "0x2A88698", VA = "0x2A88698")]
	public void method_38()
	{
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 up = base.transform.up;
			long num = 0L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x04000111 RID: 273
	[Token(Token = "0x4000111")]
	[FieldOffset(Offset = "0x18")]
	public Rigidbody rigidbody_0;

	// Token: 0x04000112 RID: 274
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000112")]
	public Vector3 vector3_0;

	// Token: 0x04000113 RID: 275
	[Token(Token = "0x4000113")]
	[FieldOffset(Offset = "0x2C")]
	public bool bool_0;

	// Token: 0x04000114 RID: 276
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000114")]
	public float float_0;

	// Token: 0x04000115 RID: 277
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x4000115")]
	public bool bool_1;
}
