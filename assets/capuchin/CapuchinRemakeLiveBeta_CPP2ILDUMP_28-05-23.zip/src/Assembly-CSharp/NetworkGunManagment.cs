﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000DD RID: 221
[Token(Token = "0x20000DD")]
public class NetworkGunManagment : MonoBehaviour
{
	// Token: 0x060020F8 RID: 8440 RVA: 0x0003D8AC File Offset: 0x0003BAAC
	[Address(RVA = "0x3686610", Offset = "0x3686610", VA = "0x3686610")]
	[Token(Token = "0x60020F8")]
	private void method_0()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x060020F9 RID: 8441 RVA: 0x0003D8AC File Offset: 0x0003BAAC
	[Address(RVA = "0x36866E4", Offset = "0x36866E4", VA = "0x36866E4")]
	[Token(Token = "0x60020F9")]
	private void method_1()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x060020FA RID: 8442 RVA: 0x0003D91C File Offset: 0x0003BB1C
	[Address(RVA = "0x36867B8", Offset = "0x36867B8", VA = "0x36867B8")]
	[Token(Token = "0x60020FA")]
	private void method_2()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 0L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x060020FB RID: 8443 RVA: 0x0003D9A0 File Offset: 0x0003BBA0
	[Address(RVA = "0x368687C", Offset = "0x368687C", VA = "0x368687C")]
	[Token(Token = "0x60020FB")]
	private void method_3()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		ClientGunManager clientGunManager = this.clientGunManager_0;
		long enabled = 0L;
		clientGunManager.enabled = (enabled != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		ClientGunManager clientGunManager2 = this.clientGunManager_0;
		long enabled2 = 0L;
		clientGunManager2.enabled = (enabled2 != 0L);
		bool activeSelf3 = this.gameObject_0.activeSelf;
		bool activeSelf4 = this.gameObject_1.activeSelf;
	}

	// Token: 0x060020FC RID: 8444 RVA: 0x0003DA04 File Offset: 0x0003BC04
	[Address(RVA = "0x3686940", Offset = "0x3686940", VA = "0x3686940")]
	[Token(Token = "0x60020FC")]
	private void method_4()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf2 = this.gameObject_0.activeSelf;
			bool activeSelf3 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x060020FD RID: 8445 RVA: 0x0003DA68 File Offset: 0x0003BC68
	[Address(RVA = "0x3686A14", Offset = "0x3686A14", VA = "0x3686A14")]
	[Token(Token = "0x60020FD")]
	private void method_5()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x060020FE RID: 8446 RVA: 0x0003DAEC File Offset: 0x0003BCEC
	[Address(RVA = "0x3686AD8", Offset = "0x3686AD8", VA = "0x3686AD8")]
	[Token(Token = "0x60020FE")]
	private void method_6()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x060020FF RID: 8447 RVA: 0x0003DB5C File Offset: 0x0003BD5C
	[Address(RVA = "0x3686BAC", Offset = "0x3686BAC", VA = "0x3686BAC")]
	[Token(Token = "0x60020FF")]
	private void method_7()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002100 RID: 8448 RVA: 0x0003DBE0 File Offset: 0x0003BDE0
	[Address(RVA = "0x3686C70", Offset = "0x3686C70", VA = "0x3686C70")]
	[Token(Token = "0x6002100")]
	private void method_8()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x06002101 RID: 8449 RVA: 0x0003DBE0 File Offset: 0x0003BDE0
	[Address(RVA = "0x3686D44", Offset = "0x3686D44", VA = "0x3686D44")]
	[Token(Token = "0x6002101")]
	private void method_9()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x06002102 RID: 8450 RVA: 0x0003D8AC File Offset: 0x0003BAAC
	[Address(RVA = "0x3686E18", Offset = "0x3686E18", VA = "0x3686E18")]
	[Token(Token = "0x6002102")]
	private void method_10()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x06002103 RID: 8451 RVA: 0x0003DAEC File Offset: 0x0003BCEC
	[Address(RVA = "0x3686EEC", Offset = "0x3686EEC", VA = "0x3686EEC")]
	[Token(Token = "0x6002103")]
	private void method_11()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x06002104 RID: 8452 RVA: 0x0003DC50 File Offset: 0x0003BE50
	[Address(RVA = "0x3686FC0", Offset = "0x3686FC0", VA = "0x3686FC0")]
	[Token(Token = "0x6002104")]
	private void method_12()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002105 RID: 8453 RVA: 0x0003DCD4 File Offset: 0x0003BED4
	[Address(RVA = "0x3687084", Offset = "0x3687084", VA = "0x3687084")]
	[Token(Token = "0x6002105")]
	private void method_13()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x06002106 RID: 8454 RVA: 0x0003DC50 File Offset: 0x0003BE50
	[Address(RVA = "0x3687158", Offset = "0x3687158", VA = "0x3687158")]
	[Token(Token = "0x6002106")]
	private void method_14()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002107 RID: 8455 RVA: 0x0003DD30 File Offset: 0x0003BF30
	[Address(RVA = "0x368721C", Offset = "0x368721C", VA = "0x368721C")]
	[Token(Token = "0x6002107")]
	private void method_15()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002108 RID: 8456 RVA: 0x0003DDB4 File Offset: 0x0003BFB4
	[Address(RVA = "0x36872E0", Offset = "0x36872E0", VA = "0x36872E0")]
	[Token(Token = "0x6002108")]
	private void method_16()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002109 RID: 8457 RVA: 0x0003DDD0 File Offset: 0x0003BFD0
	[Address(RVA = "0x36873A4", Offset = "0x36873A4", VA = "0x36873A4")]
	[Token(Token = "0x6002109")]
	private void Update()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 0L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x0600210A RID: 8458 RVA: 0x0003D91C File Offset: 0x0003BB1C
	[Address(RVA = "0x3687468", Offset = "0x3687468", VA = "0x3687468")]
	[Token(Token = "0x600210A")]
	private void method_17()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 0L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x0600210B RID: 8459 RVA: 0x0003DAEC File Offset: 0x0003BCEC
	[Address(RVA = "0x368752C", Offset = "0x368752C", VA = "0x368752C")]
	[Token(Token = "0x600210B")]
	private void method_18()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x0600210C RID: 8460 RVA: 0x0003DC50 File Offset: 0x0003BE50
	[Address(RVA = "0x3687600", Offset = "0x3687600", VA = "0x3687600")]
	[Token(Token = "0x600210C")]
	private void method_19()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x0600210D RID: 8461 RVA: 0x0003D8AC File Offset: 0x0003BAAC
	[Address(RVA = "0x36876C4", Offset = "0x36876C4", VA = "0x36876C4")]
	[Token(Token = "0x600210D")]
	private void method_20()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x0600210E RID: 8462 RVA: 0x0003DE54 File Offset: 0x0003C054
	[Address(RVA = "0x3687798", Offset = "0x3687798", VA = "0x3687798")]
	[Token(Token = "0x600210E")]
	private void method_21()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 0L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x0600210F RID: 8463 RVA: 0x0003DB5C File Offset: 0x0003BD5C
	[Address(RVA = "0x368785C", Offset = "0x368785C", VA = "0x368785C")]
	[Token(Token = "0x600210F")]
	private void method_22()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002110 RID: 8464 RVA: 0x0003DED8 File Offset: 0x0003C0D8
	[Address(RVA = "0x3687920", Offset = "0x3687920", VA = "0x3687920")]
	[Token(Token = "0x6002110")]
	private void method_23()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager2 = this.clientGunManager_0;
		long enabled2 = 1L;
		clientGunManager2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06002111 RID: 8465 RVA: 0x0003DC50 File Offset: 0x0003BE50
	[Address(RVA = "0x36879E4", Offset = "0x36879E4", VA = "0x36879E4")]
	[Token(Token = "0x6002111")]
	private void method_24()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002112 RID: 8466 RVA: 0x0003DF4C File Offset: 0x0003C14C
	[Address(RVA = "0x3687AA8", Offset = "0x3687AA8", VA = "0x3687AA8")]
	[Token(Token = "0x6002112")]
	private void method_25()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x06002113 RID: 8467 RVA: 0x0003DC50 File Offset: 0x0003BE50
	[Address(RVA = "0x3687B7C", Offset = "0x3687B7C", VA = "0x3687B7C")]
	[Token(Token = "0x6002113")]
	private void method_26()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002114 RID: 8468 RVA: 0x0003DF4C File Offset: 0x0003C14C
	[Address(RVA = "0x3687C40", Offset = "0x3687C40", VA = "0x3687C40")]
	[Token(Token = "0x6002114")]
	private void method_27()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x06002115 RID: 8469 RVA: 0x0003DDD0 File Offset: 0x0003BFD0
	[Address(RVA = "0x3687D14", Offset = "0x3687D14", VA = "0x3687D14")]
	[Token(Token = "0x6002115")]
	private void method_28()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 0L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002116 RID: 8470 RVA: 0x0003DDB4 File Offset: 0x0003BFB4
	[Address(RVA = "0x3687DD8", Offset = "0x3687DD8", VA = "0x3687DD8")]
	[Token(Token = "0x6002116")]
	private void method_29()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002117 RID: 8471 RVA: 0x0003DF4C File Offset: 0x0003C14C
	[Address(RVA = "0x3687EAC", Offset = "0x3687EAC", VA = "0x3687EAC")]
	[Token(Token = "0x6002117")]
	private void method_30()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x06002118 RID: 8472 RVA: 0x0003DF4C File Offset: 0x0003C14C
	[Address(RVA = "0x3687F80", Offset = "0x3687F80", VA = "0x3687F80")]
	[Token(Token = "0x6002118")]
	private void method_31()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x06002119 RID: 8473 RVA: 0x0003DFBC File Offset: 0x0003C1BC
	[Address(RVA = "0x3688054", Offset = "0x3688054", VA = "0x3688054")]
	[Token(Token = "0x6002119")]
	private void method_32()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			GameObject gameObject = this.gameObject_1;
			long enabled2 = 0L;
			bool activeSelf2 = gameObject.activeSelf;
			this.clientGunManager_0.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x0600211A RID: 8474 RVA: 0x0003DDB4 File Offset: 0x0003BFB4
	[Address(RVA = "0x3688128", Offset = "0x3688128", VA = "0x3688128")]
	[Token(Token = "0x600211A")]
	private void method_33()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600211B RID: 8475 RVA: 0x0003E02C File Offset: 0x0003C22C
	[Address(RVA = "0x36881EC", Offset = "0x36881EC", VA = "0x36881EC")]
	[Token(Token = "0x600211B")]
	private void method_34()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 0L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x0600211C RID: 8476 RVA: 0x0003DF4C File Offset: 0x0003C14C
	[Address(RVA = "0x36882B0", Offset = "0x36882B0", VA = "0x36882B0")]
	[Token(Token = "0x600211C")]
	private void method_35()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x0600211D RID: 8477 RVA: 0x0003DBE0 File Offset: 0x0003BDE0
	[Address(RVA = "0x3688384", Offset = "0x3688384", VA = "0x3688384")]
	[Token(Token = "0x600211D")]
	private void method_36()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x0600211E RID: 8478 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3688458", Offset = "0x3688458", VA = "0x3688458")]
	[Token(Token = "0x600211E")]
	public NetworkGunManagment()
	{
	}

	// Token: 0x0600211F RID: 8479 RVA: 0x0003DA68 File Offset: 0x0003BC68
	[Address(RVA = "0x3688460", Offset = "0x3688460", VA = "0x3688460")]
	[Token(Token = "0x600211F")]
	private void method_37()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002120 RID: 8480 RVA: 0x0003DAEC File Offset: 0x0003BCEC
	[Address(RVA = "0x3688524", Offset = "0x3688524", VA = "0x3688524")]
	[Token(Token = "0x6002120")]
	private void method_38()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
	}

	// Token: 0x06002121 RID: 8481 RVA: 0x0003DA68 File Offset: 0x0003BC68
	[Address(RVA = "0x36885F8", Offset = "0x36885F8", VA = "0x36885F8")]
	[Token(Token = "0x6002121")]
	private void method_39()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002122 RID: 8482 RVA: 0x0003DD30 File Offset: 0x0003BF30
	[Address(RVA = "0x36886BC", Offset = "0x36886BC", VA = "0x36886BC")]
	[Token(Token = "0x6002122")]
	private void method_40()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 0L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002123 RID: 8483 RVA: 0x0003DDD0 File Offset: 0x0003BFD0
	[Address(RVA = "0x3688780", Offset = "0x3688780", VA = "0x3688780")]
	[Token(Token = "0x6002123")]
	private void method_41()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 1L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 0L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x06002124 RID: 8484 RVA: 0x0003DB5C File Offset: 0x0003BD5C
	[Address(RVA = "0x3688844", Offset = "0x3688844", VA = "0x3688844")]
	[Token(Token = "0x6002124")]
	private void method_42()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			bool activeSelf = this.gameObject_0.activeSelf;
			ClientGunManager clientGunManager = this.clientGunManager_0;
			long enabled = 1L;
			clientGunManager.enabled = (enabled != 0L);
			bool activeSelf2 = this.gameObject_1.activeSelf;
			ClientGunManager clientGunManager2 = this.clientGunManager_0;
			long enabled2 = 0L;
			clientGunManager2.enabled = (enabled2 != 0L);
			bool activeSelf3 = this.gameObject_0.activeSelf;
			bool activeSelf4 = this.gameObject_1.activeSelf;
			return;
		}
		ClientGunManager clientGunManager3 = this.clientGunManager_0;
		long enabled3 = 1L;
		clientGunManager3.enabled = (enabled3 != 0L);
	}

	// Token: 0x0400045E RID: 1118
	[Token(Token = "0x400045E")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;

	// Token: 0x0400045F RID: 1119
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400045F")]
	public GameObject gameObject_1;

	// Token: 0x04000460 RID: 1120
	[Token(Token = "0x4000460")]
	[FieldOffset(Offset = "0x28")]
	public PhotonView photonView_0;

	// Token: 0x04000461 RID: 1121
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000461")]
	public ClientGunManager clientGunManager_0;
}
