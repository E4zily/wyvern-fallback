﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200010D RID: 269
[Token(Token = "0x200010D")]
[Serializable]
public class AxleInfo
{
	// Token: 0x06002879 RID: 10361 RVA: 0x000020B4 File Offset: 0x000002B4
	[Address(RVA = "0x2BFB998", Offset = "0x2BFB998", VA = "0x2BFB998")]
	[Token(Token = "0x6002879")]
	public AxleInfo()
	{
	}

	// Token: 0x0400054A RID: 1354
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400054A")]
	public WheelCollider leftWheel;

	// Token: 0x0400054B RID: 1355
	[Token(Token = "0x400054B")]
	[FieldOffset(Offset = "0x18")]
	public WheelCollider rightWheel;

	// Token: 0x0400054C RID: 1356
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400054C")]
	public bool motor;

	// Token: 0x0400054D RID: 1357
	[FieldOffset(Offset = "0x21")]
	[Token(Token = "0x400054D")]
	public bool steering;
}
