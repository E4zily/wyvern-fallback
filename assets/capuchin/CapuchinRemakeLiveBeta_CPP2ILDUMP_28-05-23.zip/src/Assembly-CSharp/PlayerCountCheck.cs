﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200009A RID: 154
[Token(Token = "0x200009A")]
public class PlayerCountCheck : MonoBehaviour
{
	// Token: 0x060016E0 RID: 5856 RVA: 0x0002C648 File Offset: 0x0002A848
	[Address(RVA = "0x2A76F40", Offset = "0x2A76F40", VA = "0x2A76F40")]
	[Token(Token = "0x60016E0")]
	private void method_0()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x060016E1 RID: 5857 RVA: 0x0002C670 File Offset: 0x0002A870
	[Address(RVA = "0x2A77004", Offset = "0x2A77004", VA = "0x2A77004")]
	[Token(Token = "0x60016E1")]
	private void method_1()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016E2 RID: 5858 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A770B4", Offset = "0x2A770B4", VA = "0x2A770B4")]
	[Token(Token = "0x60016E2")]
	public PlayerCountCheck()
	{
	}

	// Token: 0x060016E3 RID: 5859 RVA: 0x0002C6AC File Offset: 0x0002A8AC
	[Token(Token = "0x60016E3")]
	[Address(RVA = "0x2A770BC", Offset = "0x2A770BC", VA = "0x2A770BC")]
	private void method_2()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016E4 RID: 5860 RVA: 0x0002C6E8 File Offset: 0x0002A8E8
	[Token(Token = "0x60016E4")]
	[Address(RVA = "0x2A7716C", Offset = "0x2A7716C", VA = "0x2A7716C")]
	private void method_3()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016E5 RID: 5861 RVA: 0x0002C6E8 File Offset: 0x0002A8E8
	[Address(RVA = "0x2A7722C", Offset = "0x2A7722C", VA = "0x2A7722C")]
	[Token(Token = "0x60016E5")]
	private void method_4()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016E6 RID: 5862 RVA: 0x0002C648 File Offset: 0x0002A848
	[Token(Token = "0x60016E6")]
	[Address(RVA = "0x2A772EC", Offset = "0x2A772EC", VA = "0x2A772EC")]
	private void method_5()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x060016E7 RID: 5863 RVA: 0x0002C648 File Offset: 0x0002A848
	[Token(Token = "0x60016E7")]
	[Address(RVA = "0x2A773B0", Offset = "0x2A773B0", VA = "0x2A773B0")]
	private void method_6()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x060016E8 RID: 5864 RVA: 0x0002C648 File Offset: 0x0002A848
	[Address(RVA = "0x2A77474", Offset = "0x2A77474", VA = "0x2A77474")]
	[Token(Token = "0x60016E8")]
	private void Update()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x060016E9 RID: 5865 RVA: 0x0002C648 File Offset: 0x0002A848
	[Address(RVA = "0x2A77538", Offset = "0x2A77538", VA = "0x2A77538")]
	[Token(Token = "0x60016E9")]
	private void method_7()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x060016EA RID: 5866 RVA: 0x0002C670 File Offset: 0x0002A870
	[Token(Token = "0x60016EA")]
	[Address(RVA = "0x2A775FC", Offset = "0x2A775FC", VA = "0x2A775FC")]
	private void method_8()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016EB RID: 5867 RVA: 0x0002C648 File Offset: 0x0002A848
	[Token(Token = "0x60016EB")]
	[Address(RVA = "0x2A776AC", Offset = "0x2A776AC", VA = "0x2A776AC")]
	private void method_9()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x060016EC RID: 5868 RVA: 0x0002C670 File Offset: 0x0002A870
	[Address(RVA = "0x2A77770", Offset = "0x2A77770", VA = "0x2A77770")]
	[Token(Token = "0x60016EC")]
	private void method_10()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016ED RID: 5869 RVA: 0x0002C724 File Offset: 0x0002A924
	[Address(RVA = "0x2A77820", Offset = "0x2A77820", VA = "0x2A77820")]
	[Token(Token = "0x60016ED")]
	private void method_11()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016EE RID: 5870 RVA: 0x0002C670 File Offset: 0x0002A870
	[Address(RVA = "0x2A778E0", Offset = "0x2A778E0", VA = "0x2A778E0")]
	[Token(Token = "0x60016EE")]
	private void method_12()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016EF RID: 5871 RVA: 0x0002C670 File Offset: 0x0002A870
	[Address(RVA = "0x2A77990", Offset = "0x2A77990", VA = "0x2A77990")]
	[Token(Token = "0x60016EF")]
	private void method_13()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016F0 RID: 5872 RVA: 0x0002C648 File Offset: 0x0002A848
	[Token(Token = "0x60016F0")]
	[Address(RVA = "0x2A77A38", Offset = "0x2A77A38", VA = "0x2A77A38")]
	private void method_14()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x060016F1 RID: 5873 RVA: 0x0002C6AC File Offset: 0x0002A8AC
	[Token(Token = "0x60016F1")]
	[Address(RVA = "0x2A77AFC", Offset = "0x2A77AFC", VA = "0x2A77AFC")]
	private void method_15()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016F2 RID: 5874 RVA: 0x0002C670 File Offset: 0x0002A870
	[Token(Token = "0x60016F2")]
	[Address(RVA = "0x2A77BAC", Offset = "0x2A77BAC", VA = "0x2A77BAC")]
	private void method_16()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016F3 RID: 5875 RVA: 0x0002C648 File Offset: 0x0002A848
	[Token(Token = "0x60016F3")]
	[Address(RVA = "0x2A77C5C", Offset = "0x2A77C5C", VA = "0x2A77C5C")]
	private void method_17()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x060016F4 RID: 5876 RVA: 0x0002C6AC File Offset: 0x0002A8AC
	[Address(RVA = "0x2A77D20", Offset = "0x2A77D20", VA = "0x2A77D20")]
	[Token(Token = "0x60016F4")]
	private void method_18()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016F5 RID: 5877 RVA: 0x0002C648 File Offset: 0x0002A848
	[Address(RVA = "0x2A77DD0", Offset = "0x2A77DD0", VA = "0x2A77DD0")]
	[Token(Token = "0x60016F5")]
	private void method_19()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x060016F6 RID: 5878 RVA: 0x0002C670 File Offset: 0x0002A870
	[Token(Token = "0x60016F6")]
	[Address(RVA = "0x2A77E94", Offset = "0x2A77E94", VA = "0x2A77E94")]
	private void method_20()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016F7 RID: 5879 RVA: 0x0002C648 File Offset: 0x0002A848
	[Token(Token = "0x60016F7")]
	[Address(RVA = "0x2A77F44", Offset = "0x2A77F44", VA = "0x2A77F44")]
	private void method_21()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x060016F8 RID: 5880 RVA: 0x0002C670 File Offset: 0x0002A870
	[Address(RVA = "0x2A78008", Offset = "0x2A78008", VA = "0x2A78008")]
	[Token(Token = "0x60016F8")]
	private void method_22()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060016F9 RID: 5881 RVA: 0x0002C648 File Offset: 0x0002A848
	[Address(RVA = "0x2A780B8", Offset = "0x2A780B8", VA = "0x2A780B8")]
	[Token(Token = "0x60016F9")]
	private void method_23()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
	}

	// Token: 0x040002F5 RID: 757
	[Token(Token = "0x40002F5")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;
}
