﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using CapuchinPlayFab;
using Cpp2IlInjected;
using PlayFab;
using PlayFab.ClientModels;
using TMPro;
using UnityEngine;

// Token: 0x02000014 RID: 20
[Token(Token = "0x2000014")]
public class BuyCosmetic : MonoBehaviour
{
	// Token: 0x06000252 RID: 594 RVA: 0x00009150 File Offset: 0x00007350
	[Address(RVA = "0x25AA590", Offset = "0x25AA590", VA = "0x25AA590")]
	[Token(Token = "0x6000252")]
	public BuyCosmetic()
	{
		long num = 1073741824L;
		this.float_0 = (float)num;
		base..ctor();
	}

	// Token: 0x06000253 RID: 595 RVA: 0x00009170 File Offset: 0x00007370
	[Token(Token = "0x6000253")]
	[Address(RVA = "0x25AA5A0", Offset = "0x25AA5A0", VA = "0x25AA5A0")]
	public void method_0()
	{
		LoginManager.loginManager_0.method_43();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		int price = this.int_0;
		purchaseItemRequest.Price = price;
		base.StartCoroutine("ӵٟٜࢣ");
	}

	// Token: 0x06000254 RID: 596 RVA: 0x000091A8 File Offset: 0x000073A8
	[Address(RVA = "0x25AA850", Offset = "0x25AA850", VA = "0x25AA850")]
	[Token(Token = "0x6000254")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.tag == "BN";
		this.method_51();
	}

	// Token: 0x06000255 RID: 597 RVA: 0x000091D4 File Offset: 0x000073D4
	[Token(Token = "0x6000255")]
	[Address(RVA = "0x25AA9D4", Offset = "0x25AA9D4", VA = "0x25AA9D4")]
	private IEnumerator method_2()
	{
		new BuyCosmetic.Class2((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x06000256 RID: 598 RVA: 0x000091F8 File Offset: 0x000073F8
	[Token(Token = "0x6000256")]
	[Address(RVA = "0x25AAA4C", Offset = "0x25AAA4C", VA = "0x25AAA4C")]
	public void Awake()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_0 = component;
		PlayFabClientAPI.IsClientLoggedIn();
		LoginManager.loginManager_0.method_43();
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000257 RID: 599 RVA: 0x0000923C File Offset: 0x0000743C
	[Token(Token = "0x6000257")]
	[Address(RVA = "0x25AAB4C", Offset = "0x25AAB4C", VA = "0x25AAB4C")]
	public void Update()
	{
		float deltaTime = Time.deltaTime;
		if (!this.bool_1)
		{
		}
		this.float_0 = (float)7238;
	}

	// Token: 0x06000258 RID: 600 RVA: 0x00009264 File Offset: 0x00007464
	[Address(RVA = "0x25AAC40", Offset = "0x25AAC40", VA = "0x25AAC40")]
	[Token(Token = "0x6000258")]
	private void method_3()
	{
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		purchaseItemRequest.CatalogVersion = "closeToObject";
		string catalogVersion = this.string_0;
		purchaseItemRequest.CatalogVersion = catalogVersion;
		purchaseItemRequest.ItemId = "EnableCosmetic";
		int characterId = this.int_0;
		purchaseItemRequest.CharacterId = characterId;
	}

	// Token: 0x06000259 RID: 601 RVA: 0x000092AC File Offset: 0x000074AC
	[Token(Token = "0x6000259")]
	[Address(RVA = "0x25AAE00", Offset = "0x25AAE00", VA = "0x25AAE00")]
	private void method_4()
	{
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		purchaseItemRequest.CatalogVersion = "/";
		string catalogVersion = this.string_0;
		purchaseItemRequest.CatalogVersion = catalogVersion;
		purchaseItemRequest.ItemId = "retract broken";
		int characterId = this.int_0;
		purchaseItemRequest.CharacterId = characterId;
	}

	// Token: 0x0600025A RID: 602 RVA: 0x000092F4 File Offset: 0x000074F4
	[Address(RVA = "0x25AAFC0", Offset = "0x25AAFC0", VA = "0x25AAFC0")]
	[Token(Token = "0x600025A")]
	[CompilerGenerated]
	private void method_5(GetUserInventoryResult getUserInventoryResult_0)
	{
		List<ItemInstance>.Enumerator enumerator = getUserInventoryResult_0.Inventory.GetEnumerator();
		long num = 1L;
		enumerator.MoveNext();
		this.string_0 == "CapuchinStore";
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		this.bool_1 = (num != 0L);
	}

	// Token: 0x0600025B RID: 603 RVA: 0x00009344 File Offset: 0x00007544
	[Address(RVA = "0x25AB238", Offset = "0x25AB238", VA = "0x25AB238")]
	[Token(Token = "0x600025B")]
	private void method_6(PurchaseItemResult purchaseItemResult_0)
	{
		string str = this.string_0;
		string str2;
		string message = "PRESS AGAIN TO CONFIRM" + str + "ScoreCounter" + str2;
		Debug.Log(message);
		this.method_14();
	}

	// Token: 0x0600025C RID: 604 RVA: 0x00009378 File Offset: 0x00007578
	[Address(RVA = "0x25AB4CC", Offset = "0x25AB4CC", VA = "0x25AB4CC")]
	[Token(Token = "0x600025C")]
	public void method_7()
	{
		new GetUserInventoryRequest();
		if (BuyCosmetic.<>c.<>9__12_1 == null)
		{
			Action<PlayFabError> <>9__12_;
			BuyCosmetic.<>c.<>9__12_1 = <>9__12_;
		}
	}

	// Token: 0x0600025D RID: 605 RVA: 0x00009398 File Offset: 0x00007598
	[Token(Token = "0x600025D")]
	[Address(RVA = "0x25AB698", Offset = "0x25AB698", VA = "0x25AB698")]
	private IEnumerator method_8()
	{
		BuyCosmetic.Class2 @class = new BuyCosmetic.Class2((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600025E RID: 606 RVA: 0x000093C0 File Offset: 0x000075C0
	[Token(Token = "0x600025E")]
	[Address(RVA = "0x25AB710", Offset = "0x25AB710", VA = "0x25AB710")]
	private void method_9(PurchaseItemResult purchaseItemResult_0)
	{
		string str = this.string_0;
		string str2;
		string message = "procedural animation script required on " + str + "True" + str2;
		Debug.Log(message);
		this.method_14();
	}

	// Token: 0x0600025F RID: 607 RVA: 0x000093F4 File Offset: 0x000075F4
	[Token(Token = "0x600025F")]
	[Address(RVA = "0x25AB7D8", Offset = "0x25AB7D8", VA = "0x25AB7D8")]
	public void method_10()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_0 = component;
		PlayFabClientAPI.IsClientLoggedIn();
	}

	// Token: 0x06000260 RID: 608 RVA: 0x00009424 File Offset: 0x00007624
	[Address(RVA = "0x25AB8D4", Offset = "0x25AB8D4", VA = "0x25AB8D4")]
	[Token(Token = "0x6000260")]
	public void method_11()
	{
		LoginManager.loginManager_0.method_62();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		int price = this.int_0;
		purchaseItemRequest.Price = price;
		base.StartCoroutine("HandL");
	}

	// Token: 0x06000261 RID: 609 RVA: 0x0000945C File Offset: 0x0000765C
	[Address(RVA = "0x25ABB84", Offset = "0x25ABB84", VA = "0x25ABB84")]
	[Token(Token = "0x6000261")]
	public void method_12()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_0 = component;
		PlayFabClientAPI.IsClientLoggedIn();
		LoginManager.loginManager_0.method_49();
	}

	// Token: 0x06000262 RID: 610 RVA: 0x00009498 File Offset: 0x00007698
	[Address(RVA = "0x25ABC80", Offset = "0x25ABC80", VA = "0x25ABC80")]
	[Token(Token = "0x6000262")]
	private void method_13()
	{
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		purchaseItemRequest.CatalogVersion = "hand 2";
		string catalogVersion = this.string_0;
		purchaseItemRequest.CatalogVersion = catalogVersion;
		purchaseItemRequest.ItemId = "PlayWave";
		int characterId = this.int_0;
		purchaseItemRequest.CharacterId = characterId;
	}

	// Token: 0x06000263 RID: 611 RVA: 0x000094E0 File Offset: 0x000076E0
	[Token(Token = "0x6000263")]
	[Address(RVA = "0x25AB300", Offset = "0x25AB300", VA = "0x25AB300")]
	public void method_14()
	{
		new GetUserInventoryRequest();
		if (BuyCosmetic.<>c.<>9__12_1 == null)
		{
			BuyCosmetic.<>c <>9__12_;
			BuyCosmetic.<>c.<>9__12_1 = <>9__12_;
		}
	}

	// Token: 0x06000264 RID: 612 RVA: 0x00009500 File Offset: 0x00007700
	[Address(RVA = "0x25ABE40", Offset = "0x25ABE40", VA = "0x25ABE40")]
	[Token(Token = "0x6000264")]
	private IEnumerator method_15()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06000265 RID: 613 RVA: 0x00009514 File Offset: 0x00007714
	[Token(Token = "0x6000265")]
	[Address(RVA = "0x25ABEB8", Offset = "0x25ABEB8", VA = "0x25ABEB8")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.tag == "CapuchinStore";
	}

	// Token: 0x06000266 RID: 614 RVA: 0x00009398 File Offset: 0x00007598
	[Address(RVA = "0x25ABF4C", Offset = "0x25ABF4C", VA = "0x25ABF4C")]
	[Token(Token = "0x6000266")]
	private IEnumerator method_17()
	{
		BuyCosmetic.Class2 @class = new BuyCosmetic.Class2((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000267 RID: 615 RVA: 0x00009538 File Offset: 0x00007738
	[Address(RVA = "0x25ABFC4", Offset = "0x25ABFC4", VA = "0x25ABFC4")]
	[Token(Token = "0x6000267")]
	public void method_18()
	{
		LoginManager.loginManager_0.method_62();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		int price = this.int_0;
		purchaseItemRequest.Price = price;
		base.StartCoroutine("ࡉٝܭ۲");
	}

	// Token: 0x06000268 RID: 616 RVA: 0x00009570 File Offset: 0x00007770
	[Address(RVA = "0x25AC0B4", Offset = "0x25AC0B4", VA = "0x25AC0B4")]
	[Token(Token = "0x6000268")]
	public void method_19()
	{
		float deltaTime = Time.deltaTime;
		string str;
		", " + str;
		if (this.bool_1)
		{
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		this.float_0 = (float)49152;
	}

	// Token: 0x06000269 RID: 617 RVA: 0x00009378 File Offset: 0x00007578
	[Address(RVA = "0x25AC1B4", Offset = "0x25AC1B4", VA = "0x25AC1B4")]
	[Token(Token = "0x6000269")]
	public void method_20()
	{
		new GetUserInventoryRequest();
		if (BuyCosmetic.<>c.<>9__12_1 == null)
		{
			Action<PlayFabError> <>9__12_;
			BuyCosmetic.<>c.<>9__12_1 = <>9__12_;
		}
	}

	// Token: 0x0600026A RID: 618 RVA: 0x000095B0 File Offset: 0x000077B0
	[Token(Token = "0x600026A")]
	[Address(RVA = "0x25AC380", Offset = "0x25AC380", VA = "0x25AC380")]
	public void method_21()
	{
		if (BuyCosmetic.<>c.<>9__12_1 == null)
		{
			Action<PlayFabError> <>9__12_;
			BuyCosmetic.<>c.<>9__12_1 = <>9__12_;
		}
	}

	// Token: 0x0600026B RID: 619 RVA: 0x000095CC File Offset: 0x000077CC
	[Address(RVA = "0x25AC54C", Offset = "0x25AC54C", VA = "0x25AC54C")]
	[Token(Token = "0x600026B")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "MetaAuth";
		this.method_51();
	}

	// Token: 0x0600026C RID: 620 RVA: 0x000095F8 File Offset: 0x000077F8
	[Token(Token = "0x600026C")]
	[Address(RVA = "0x25AC5E0", Offset = "0x25AC5E0", VA = "0x25AC5E0")]
	public void method_23()
	{
		Debug.Log("gamemode");
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x0600026D RID: 621 RVA: 0x00009620 File Offset: 0x00007820
	[Token(Token = "0x600026D")]
	[Address(RVA = "0x25AC6A0", Offset = "0x25AC6A0", VA = "0x25AC6A0")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "1BN";
		this.method_51();
	}

	// Token: 0x0600026E RID: 622 RVA: 0x000091F8 File Offset: 0x000073F8
	[Address(RVA = "0x25AC734", Offset = "0x25AC734", VA = "0x25AC734")]
	[Token(Token = "0x600026E")]
	public void method_25()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_0 = component;
		PlayFabClientAPI.IsClientLoggedIn();
		LoginManager.loginManager_0.method_43();
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600026F RID: 623 RVA: 0x0000964C File Offset: 0x0000784C
	[Address(RVA = "0x25AC834", Offset = "0x25AC834", VA = "0x25AC834")]
	[Token(Token = "0x600026F")]
	private void method_26(PurchaseItemResult purchaseItemResult_0)
	{
		string str = this.string_0;
		string str2;
		string message = "Purchased: " + str + " and for the price of " + str2;
		Debug.Log(message);
		this.method_21();
	}

	// Token: 0x06000270 RID: 624 RVA: 0x00009680 File Offset: 0x00007880
	[Address(RVA = "0x25AC8FC", Offset = "0x25AC8FC", VA = "0x25AC8FC")]
	[Token(Token = "0x6000270")]
	private void method_27(PurchaseItemResult purchaseItemResult_0)
	{
		string str = this.string_0;
		string str2;
		string message = "" + str + "htc" + str2;
		Debug.Log(message);
		this.method_32();
	}

	// Token: 0x06000271 RID: 625 RVA: 0x000096B4 File Offset: 0x000078B4
	[Token(Token = "0x6000271")]
	[Address(RVA = "0x25ACB90", Offset = "0x25ACB90", VA = "0x25ACB90")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		this.method_0();
	}

	// Token: 0x06000272 RID: 626 RVA: 0x0000945C File Offset: 0x0000765C
	[Token(Token = "0x6000272")]
	[Address(RVA = "0x25ACC24", Offset = "0x25ACC24", VA = "0x25ACC24")]
	public void method_28()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_0 = component;
		PlayFabClientAPI.IsClientLoggedIn();
		LoginManager.loginManager_0.method_49();
	}

	// Token: 0x06000273 RID: 627 RVA: 0x000096E0 File Offset: 0x000078E0
	[Address(RVA = "0x25ACD20", Offset = "0x25ACD20", VA = "0x25ACD20")]
	[Token(Token = "0x6000273")]
	public void method_29()
	{
		Debug.Log("Display Name Changed!");
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06000274 RID: 628 RVA: 0x00009398 File Offset: 0x00007598
	[Address(RVA = "0x25ACDE0", Offset = "0x25ACDE0", VA = "0x25ACDE0")]
	[Token(Token = "0x6000274")]
	private IEnumerator method_30()
	{
		BuyCosmetic.Class2 @class = new BuyCosmetic.Class2((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000275 RID: 629 RVA: 0x00009708 File Offset: 0x00007908
	[Token(Token = "0x6000275")]
	[Address(RVA = "0x25ACE58", Offset = "0x25ACE58", VA = "0x25ACE58")]
	public void method_31()
	{
		float deltaTime = Time.deltaTime;
		string str;
		"Agreed" + str;
		if (this.bool_1)
		{
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		this.float_0 = (float)40960;
	}

	// Token: 0x06000276 RID: 630 RVA: 0x00009378 File Offset: 0x00007578
	[Token(Token = "0x6000276")]
	[Address(RVA = "0x25AC9C4", Offset = "0x25AC9C4", VA = "0x25AC9C4")]
	public void method_32()
	{
		new GetUserInventoryRequest();
		if (BuyCosmetic.<>c.<>9__12_1 == null)
		{
			Action<PlayFabError> <>9__12_;
			BuyCosmetic.<>c.<>9__12_1 = <>9__12_;
		}
	}

	// Token: 0x06000277 RID: 631 RVA: 0x00009748 File Offset: 0x00007948
	[Address(RVA = "0x25ACF58", Offset = "0x25ACF58", VA = "0x25ACF58")]
	[Token(Token = "0x6000277")]
	private void method_33(GetUserInventoryResult getUserInventoryResult_0)
	{
		List<ItemInstance>.Enumerator enumerator = getUserInventoryResult_0.Inventory.GetEnumerator();
		long num = 1L;
		enumerator.MoveNext();
		this.string_0 == "TurnAmount";
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		this.bool_1 = (num != 0L);
		DynamicCosmetics.dynamicCosmetics_0.method_70();
		LoginManager.loginManager_0.method_56();
		LoginManager.loginManager_0.method_62();
	}

	// Token: 0x06000278 RID: 632 RVA: 0x000097B4 File Offset: 0x000079B4
	[Address(RVA = "0x25AD1D0", Offset = "0x25AD1D0", VA = "0x25AD1D0")]
	[Token(Token = "0x6000278")]
	public void method_34()
	{
		Debug.Log("{0}/{1:f0}");
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06000279 RID: 633 RVA: 0x00009398 File Offset: 0x00007598
	[Address(RVA = "0x25AD290", Offset = "0x25AD290", VA = "0x25AD290")]
	[Token(Token = "0x6000279")]
	private IEnumerator method_35()
	{
		BuyCosmetic.Class2 @class = new BuyCosmetic.Class2((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600027A RID: 634 RVA: 0x000097DC File Offset: 0x000079DC
	[Address(RVA = "0x25AD308", Offset = "0x25AD308", VA = "0x25AD308")]
	[Token(Token = "0x600027A")]
	public void method_36()
	{
		float deltaTime = Time.deltaTime;
		string str;
		"typesOfTalk" + str;
		if (this.bool_1)
		{
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		this.float_0 = (float)17266;
	}

	// Token: 0x0600027B RID: 635 RVA: 0x000091D4 File Offset: 0x000073D4
	[Token(Token = "0x600027B")]
	[Address(RVA = "0x25AD404", Offset = "0x25AD404", VA = "0x25AD404")]
	private IEnumerator method_37()
	{
		new BuyCosmetic.Class2((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x0600027C RID: 636 RVA: 0x00009378 File Offset: 0x00007578
	[Address(RVA = "0x25AD47C", Offset = "0x25AD47C", VA = "0x25AD47C")]
	[Token(Token = "0x600027C")]
	public void method_38()
	{
		new GetUserInventoryRequest();
		if (BuyCosmetic.<>c.<>9__12_1 == null)
		{
			Action<PlayFabError> <>9__12_;
			BuyCosmetic.<>c.<>9__12_1 = <>9__12_;
		}
	}

	// Token: 0x0600027D RID: 637 RVA: 0x0000981C File Offset: 0x00007A1C
	[Address(RVA = "0x25AD648", Offset = "0x25AD648", VA = "0x25AD648")]
	[Token(Token = "0x600027D")]
	private void method_39(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.LogWarning(message);
	}

	// Token: 0x0600027E RID: 638 RVA: 0x00009398 File Offset: 0x00007598
	[Address(RVA = "0x25AD720", Offset = "0x25AD720", VA = "0x25AD720")]
	[Token(Token = "0x600027E")]
	private IEnumerator method_40()
	{
		BuyCosmetic.Class2 @class = new BuyCosmetic.Class2((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600027F RID: 639 RVA: 0x00009834 File Offset: 0x00007A34
	[Address(RVA = "0x25AD798", Offset = "0x25AD798", VA = "0x25AD798")]
	[Token(Token = "0x600027F")]
	private void method_41(GetUserInventoryResult getUserInventoryResult_0)
	{
		List<ItemInstance>.Enumerator enumerator = getUserInventoryResult_0.Inventory.GetEnumerator();
		long num = 1L;
		enumerator.MoveNext();
		this.string_0 == "windowsmr";
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		this.bool_1 = (num != 0L);
		DynamicCosmetics.dynamicCosmetics_0.method_29();
		LoginManager.loginManager_0.method_56();
		LoginManager.loginManager_0.method_49();
	}

	// Token: 0x06000280 RID: 640 RVA: 0x00009398 File Offset: 0x00007598
	[Token(Token = "0x6000280")]
	[Address(RVA = "0x25ADA10", Offset = "0x25ADA10", VA = "0x25ADA10")]
	private IEnumerator method_42()
	{
		BuyCosmetic.Class2 @class = new BuyCosmetic.Class2((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000281 RID: 641 RVA: 0x00009398 File Offset: 0x00007598
	[Token(Token = "0x6000281")]
	[Address(RVA = "0x25ADA88", Offset = "0x25ADA88", VA = "0x25ADA88")]
	private IEnumerator method_43()
	{
		BuyCosmetic.Class2 @class = new BuyCosmetic.Class2((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000282 RID: 642 RVA: 0x000098A0 File Offset: 0x00007AA0
	[Token(Token = "0x6000282")]
	[Address(RVA = "0x25ADB00", Offset = "0x25ADB00", VA = "0x25ADB00")]
	private void method_44(PurchaseItemResult purchaseItemResult_0)
	{
		string str = this.string_0;
		string str2;
		string message = "On" + str + "Not connected to room" + str2;
		Debug.Log(message);
		this.method_21();
	}

	// Token: 0x06000283 RID: 643 RVA: 0x000098D4 File Offset: 0x00007AD4
	[Address(RVA = "0x25ADBC8", Offset = "0x25ADBC8", VA = "0x25ADBC8")]
	[Token(Token = "0x6000283")]
	public void method_45()
	{
		LoginManager.loginManager_0.method_43();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		int price = this.int_0;
		purchaseItemRequest.Price = price;
		base.StartCoroutine("Tagged");
	}

	// Token: 0x06000284 RID: 644 RVA: 0x00009398 File Offset: 0x00007598
	[Token(Token = "0x6000284")]
	[Address(RVA = "0x25ADCB8", Offset = "0x25ADCB8", VA = "0x25ADCB8")]
	private IEnumerator method_46()
	{
		BuyCosmetic.Class2 @class = new BuyCosmetic.Class2((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000285 RID: 645 RVA: 0x0000990C File Offset: 0x00007B0C
	[Token(Token = "0x6000285")]
	[Address(RVA = "0x25ADD30", Offset = "0x25ADD30", VA = "0x25ADD30")]
	private void method_47(PurchaseItemResult purchaseItemResult_0)
	{
		string str = this.string_0;
		string str2;
		string message = "SaveHeight" + str + " hours. You were banned because of " + str2;
		Debug.Log(message);
		this.method_21();
	}

	// Token: 0x06000286 RID: 646 RVA: 0x00009940 File Offset: 0x00007B40
	[Token(Token = "0x6000286")]
	[Address(RVA = "0x25ADDF8", Offset = "0x25ADDF8", VA = "0x25ADDF8")]
	private void method_48(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.LogWarning(message);
		Application.Quit();
	}

	// Token: 0x06000287 RID: 647 RVA: 0x0000995C File Offset: 0x00007B5C
	[Address(RVA = "0x25AA690", Offset = "0x25AA690", VA = "0x25AA690")]
	[Token(Token = "0x6000287")]
	private void method_49()
	{
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		purchaseItemRequest.CatalogVersion = "CapuchinStore";
		string catalogVersion = this.string_0;
		purchaseItemRequest.CatalogVersion = catalogVersion;
		purchaseItemRequest.ItemId = "BN";
		int characterId = this.int_0;
		purchaseItemRequest.CharacterId = characterId;
	}

	// Token: 0x06000288 RID: 648 RVA: 0x00009940 File Offset: 0x00007B40
	[Address(RVA = "0x25ADED0", Offset = "0x25ADED0", VA = "0x25ADED0")]
	[Token(Token = "0x6000288")]
	private void method_50(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.LogWarning(message);
		Application.Quit();
	}

	// Token: 0x06000289 RID: 649 RVA: 0x000099A4 File Offset: 0x00007BA4
	[Token(Token = "0x6000289")]
	[Address(RVA = "0x25AA8E4", Offset = "0x25AA8E4", VA = "0x25AA8E4")]
	public void method_51()
	{
		LoginManager.loginManager_0.method_62();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		int price = this.int_0;
		purchaseItemRequest.Price = price;
		base.StartCoroutine("_BumpMap");
	}

	// Token: 0x0600028A RID: 650 RVA: 0x00009398 File Offset: 0x00007598
	[Token(Token = "0x600028A")]
	[Address(RVA = "0x25ADFA8", Offset = "0x25ADFA8", VA = "0x25ADFA8")]
	private IEnumerator method_52()
	{
		BuyCosmetic.Class2 @class = new BuyCosmetic.Class2((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600028B RID: 651 RVA: 0x000099DC File Offset: 0x00007BDC
	[Token(Token = "0x600028B")]
	[Address(RVA = "0x25AE020", Offset = "0x25AE020", VA = "0x25AE020")]
	private void method_53(GetUserInventoryResult getUserInventoryResult_0)
	{
		getUserInventoryResult_0.Inventory.GetEnumerator().MoveNext();
		this.string_0 == "Player";
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		DynamicCosmetics.dynamicCosmetics_0.method_18();
		LoginManager.loginManager_0.method_20();
		LoginManager.loginManager_0.method_49();
	}

	// Token: 0x0600028C RID: 652 RVA: 0x00009A40 File Offset: 0x00007C40
	[Token(Token = "0x600028C")]
	[Address(RVA = "0x25AE294", Offset = "0x25AE294", VA = "0x25AE294")]
	public void method_54()
	{
		float deltaTime = Time.deltaTime;
		string text;
		text + text;
		if (!this.bool_1)
		{
		}
		this.float_0 = (float)17177;
	}

	// Token: 0x0600028D RID: 653 RVA: 0x00009398 File Offset: 0x00007598
	[Address(RVA = "0x25AE38C", Offset = "0x25AE38C", VA = "0x25AE38C")]
	[Token(Token = "0x600028D")]
	private IEnumerator method_55()
	{
		BuyCosmetic.Class2 @class = new BuyCosmetic.Class2((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600028E RID: 654 RVA: 0x00009A70 File Offset: 0x00007C70
	[Address(RVA = "0x25AB9C4", Offset = "0x25AB9C4", VA = "0x25AB9C4")]
	[Token(Token = "0x600028E")]
	private void method_56()
	{
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		purchaseItemRequest.CatalogVersion = "FingerTip";
		string catalogVersion = this.string_0;
		purchaseItemRequest.CatalogVersion = catalogVersion;
		purchaseItemRequest.ItemId = "Hate Speech";
		int characterId = this.int_0;
		purchaseItemRequest.CharacterId = characterId;
	}

	// Token: 0x0600028F RID: 655 RVA: 0x00009AB8 File Offset: 0x00007CB8
	[Token(Token = "0x600028F")]
	[Address(RVA = "0x25AE404", Offset = "0x25AE404", VA = "0x25AE404")]
	private void method_57()
	{
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		purchaseItemRequest.CatalogVersion = "You Already Own This Item";
		string catalogVersion = this.string_0;
		purchaseItemRequest.CatalogVersion = catalogVersion;
		purchaseItemRequest.ItemId = "CapuchinStore";
		int characterId = this.int_0;
		purchaseItemRequest.CharacterId = characterId;
	}

	// Token: 0x06000290 RID: 656 RVA: 0x00009B00 File Offset: 0x00007D00
	[Token(Token = "0x6000290")]
	[Address(RVA = "0x25AE5C4", Offset = "0x25AE5C4", VA = "0x25AE5C4")]
	public void method_58()
	{
		LoginManager.loginManager_0.method_43();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		int price = this.int_0;
		purchaseItemRequest.Price = price;
		base.StartCoroutine("You struck apon an error. ");
	}

	// Token: 0x06000291 RID: 657 RVA: 0x00009B38 File Offset: 0x00007D38
	[Address(RVA = "0x25AE6B4", Offset = "0x25AE6B4", VA = "0x25AE6B4")]
	[Token(Token = "0x6000291")]
	public void method_59()
	{
		Debug.Log("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06000292 RID: 658 RVA: 0x00009B60 File Offset: 0x00007D60
	[Token(Token = "0x6000292")]
	[Address(RVA = "0x25AE774", Offset = "0x25AE774", VA = "0x25AE774")]
	public void method_60()
	{
		LoginManager.loginManager_0.method_43();
		PurchaseItemRequest purchaseItemRequest = new PurchaseItemRequest();
		int price = this.int_0;
		purchaseItemRequest.Price = price;
		base.StartCoroutine("You Already Own This Item");
	}

	// Token: 0x06000293 RID: 659 RVA: 0x00009B98 File Offset: 0x00007D98
	[Address(RVA = "0x25AE864", Offset = "0x25AE864", VA = "0x25AE864")]
	[Token(Token = "0x6000293")]
	public void method_61()
	{
		Debug.Log("_Tint");
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06000294 RID: 660 RVA: 0x00009378 File Offset: 0x00007578
	[Address(RVA = "0x25AE924", Offset = "0x25AE924", VA = "0x25AE924")]
	[Token(Token = "0x6000294")]
	public void method_62()
	{
		new GetUserInventoryRequest();
		if (BuyCosmetic.<>c.<>9__12_1 == null)
		{
			Action<PlayFabError> <>9__12_;
			BuyCosmetic.<>c.<>9__12_1 = <>9__12_;
		}
	}

	// Token: 0x06000295 RID: 661 RVA: 0x00009BC0 File Offset: 0x00007DC0
	[Address(RVA = "0x25AEAF0", Offset = "0x25AEAF0", VA = "0x25AEAF0")]
	[Token(Token = "0x6000295")]
	public void method_63()
	{
		float deltaTime = Time.deltaTime;
		string str;
		"true" + str;
		if (this.bool_1)
		{
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		this.float_0 = (float)40960;
	}

	// Token: 0x06000296 RID: 662 RVA: 0x00009C00 File Offset: 0x00007E00
	[Address(RVA = "0x25AEBF0", Offset = "0x25AEBF0", VA = "0x25AEBF0")]
	[Token(Token = "0x6000296")]
	public void method_64()
	{
		new GetUserInventoryRequest();
		if (BuyCosmetic.<>c.<>9__12_1 == null)
		{
			Action<PlayFabError> <>9__12_;
			BuyCosmetic.<>c.<>9__12_1 = <>9__12_;
		}
	}

	// Token: 0x06000297 RID: 663 RVA: 0x00009C20 File Offset: 0x00007E20
	[Address(RVA = "0x25AEDBC", Offset = "0x25AEDBC", VA = "0x25AEDBC")]
	[Token(Token = "0x6000297")]
	private void method_65(PurchaseItemResult purchaseItemResult_0)
	{
		string str = this.string_0;
		string str2;
		string message = "username" + str + "Player" + str2;
		Debug.Log(message);
		this.method_7();
	}

	// Token: 0x04000051 RID: 81
	[Token(Token = "0x4000051")]
	[FieldOffset(Offset = "0x18")]
	private float float_0;

	// Token: 0x04000052 RID: 82
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4000052")]
	private bool bool_0;

	// Token: 0x04000053 RID: 83
	[Token(Token = "0x4000053")]
	[FieldOffset(Offset = "0x20")]
	public string string_0;

	// Token: 0x04000054 RID: 84
	[Token(Token = "0x4000054")]
	[FieldOffset(Offset = "0x28")]
	public int int_0;

	// Token: 0x04000055 RID: 85
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000055")]
	private BoxCollider boxCollider_0;

	// Token: 0x04000056 RID: 86
	[Token(Token = "0x4000056")]
	[FieldOffset(Offset = "0x38")]
	private TextMeshPro textMeshPro_0;

	// Token: 0x04000057 RID: 87
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000057")]
	private bool bool_1;
}
