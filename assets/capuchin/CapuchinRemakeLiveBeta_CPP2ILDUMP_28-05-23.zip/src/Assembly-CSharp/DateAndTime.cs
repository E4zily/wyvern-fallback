﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x02000027 RID: 39
[Token(Token = "0x2000027")]
public class DateAndTime : MonoBehaviour
{
	// Token: 0x060004BC RID: 1212 RVA: 0x0000D128 File Offset: 0x0000B328
	[Address(RVA = "0x2A70B54", Offset = "0x2A70B54", VA = "0x2A70B54")]
	[Token(Token = "0x60004BC")]
	private void method_0()
	{
		bool flag;
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("True");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("liftoff failed!");
			"NetworkGunShoot" + str2 + "Open" + str;
			if (!(flag = this.bool_0))
			{
				return;
			}
		}
		if (flag)
		{
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("\n");
		"RainAndThunderWeather" + str4 + "username" + str3;
	}

	// Token: 0x060004BD RID: 1213 RVA: 0x0000D1C8 File Offset: 0x0000B3C8
	[Token(Token = "0x60004BD")]
	[Address(RVA = "0x2A70DC0", Offset = "0x2A70DC0", VA = "0x2A70DC0")]
	private void method_1()
	{
		if (!this.bool_0)
		{
			DateTime.UtcNow.ToLocalTime();
			string str = DateTime.UtcNow.ToLocalTime().ToString("HandR");
			string str2;
			"PRESS AGAIN TO CONFIRM" + str + "manual footTimings length should be equal to the leg count" + str2;
			if (!this.bool_0)
			{
				return;
			}
		}
		DateTime.UtcNow.ToLocalTime();
		string text = DateTime.UtcNow.ToLocalTime().ToString("tp 2");
		string str3;
		text + text + "PURCHASED!" + str3;
	}

	// Token: 0x060004BE RID: 1214 RVA: 0x0000D24C File Offset: 0x0000B44C
	[Token(Token = "0x60004BE")]
	[Address(RVA = "0x2A7102C", Offset = "0x2A7102C", VA = "0x2A7102C")]
	private void method_2()
	{
		if (!this.bool_0)
		{
			DateTime.UtcNow.ToLocalTime().ToString("_Color");
			DateTime.UtcNow.ToLocalTime().ToString("hh:mm:sstt");
			if (!this.bool_0)
			{
				return;
			}
		}
		DateTime.UtcNow.ToLocalTime().ToString("Player");
		DateTime.UtcNow.ToLocalTime().ToString("BN");
	}

	// Token: 0x060004BF RID: 1215 RVA: 0x0000D2C0 File Offset: 0x0000B4C0
	[Address(RVA = "0x2A71298", Offset = "0x2A71298", VA = "0x2A71298")]
	[Token(Token = "0x60004BF")]
	private void method_3()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.");
			"username" + str2 + "_BumpScale" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("_BumpScale");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("Player");
		"liftoff failed!" + str4 + "isLava" + str3;
	}

	// Token: 0x060004C0 RID: 1216 RVA: 0x0000D35C File Offset: 0x0000B55C
	[Address(RVA = "0x2A714EC", Offset = "0x2A714EC", VA = "0x2A714EC")]
	[Token(Token = "0x60004C0")]
	private void method_4()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("PlayWave");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString(", ");
			"QuickStatic" + str2 + "BloodKill" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("hh:mmtt");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("_Tint");
		"Trying Getting Entilement..." + str4 + "Version" + str3;
	}

	// Token: 0x060004C1 RID: 1217 RVA: 0x0000D3F8 File Offset: 0x0000B5F8
	[Token(Token = "0x60004C1")]
	[Address(RVA = "0x2A71758", Offset = "0x2A71758", VA = "0x2A71758")]
	private void method_5()
	{
		if (!this.bool_0)
		{
			DateTime.UtcNow.ToLocalTime().ToString("openvr");
			DateTime.UtcNow.ToLocalTime().ToString("liftoff failed!");
			if (!this.bool_0)
			{
				return;
			}
		}
		string str = DateTime.UtcNow.ToLocalTime().ToString("Vector1_d371bd24217449349bd747533d51af6b");
		string str2 = DateTime.UtcNow.ToLocalTime().ToString("ChangeToTagged");
		"lava" + str2 + "Connected to Server." + str;
	}

	// Token: 0x060004C2 RID: 1218 RVA: 0x0000D480 File Offset: 0x0000B680
	[Address(RVA = "0x2A719B8", Offset = "0x2A719B8", VA = "0x2A719B8")]
	[Token(Token = "0x60004C2")]
	private void method_6()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("gravThing");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("hh:mmtt");
			"Agreed" + str2 + "_Tint" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("liftoff failed!");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("Game Started");
		"Players Online: " + str4 + "Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}" + str3;
	}

	// Token: 0x060004C3 RID: 1219 RVA: 0x0000D51C File Offset: 0x0000B71C
	[Token(Token = "0x60004C3")]
	[Address(RVA = "0x2A71C24", Offset = "0x2A71C24", VA = "0x2A71C24")]
	private void Update()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("hh:mmtt");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("M/d/yyyy");
			"Date: " + str2 + "\n Time: " + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		DateTime.UtcNow.ToLocalTime().ToString("hh:mm:sstt");
		DateTime.UtcNow.ToLocalTime();
	}

	// Token: 0x060004C4 RID: 1220 RVA: 0x0000D598 File Offset: 0x0000B798
	[Address(RVA = "0x2A71E6C", Offset = "0x2A71E6C", VA = "0x2A71E6C")]
	[Token(Token = "0x60004C4")]
	private void method_7()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("HeadAttachPoint");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Pause");
			"You are on an outdated version of Capuchin. Your version is " + str2 + "PlayWave" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("1BN");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("Unpause");
		"Muted" + str4 + "Agreed" + str3;
	}

	// Token: 0x060004C5 RID: 1221 RVA: 0x0000D634 File Offset: 0x0000B834
	[Token(Token = "0x60004C5")]
	[Address(RVA = "0x2A720D8", Offset = "0x2A720D8", VA = "0x2A720D8")]
	private void method_8()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("BN");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Not connected to room");
			"Failed to get catalog, cosmetic name, and price. Exact error details is: " + str2 + "PRESS AGAIN TO CONFIRM" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("Player");
		"_Tint" + str4 + "XR Usage" + str3;
	}

	// Token: 0x060004C6 RID: 1222 RVA: 0x0000D6D0 File Offset: 0x0000B8D0
	[Token(Token = "0x60004C6")]
	[Address(RVA = "0x2A72344", Offset = "0x2A72344", VA = "0x2A72344")]
	private void method_9()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("Photon token acquired!");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("back");
			"ErrorScreen" + str2 + "Round end" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("'s Grabber is not assigned.");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n");
		"username" + str4 + "Round end" + str3;
	}

	// Token: 0x060004C7 RID: 1223 RVA: 0x0000D76C File Offset: 0x0000B96C
	[Address(RVA = "0x2A725B0", Offset = "0x2A725B0", VA = "0x2A725B0")]
	[Token(Token = "0x60004C7")]
	private void method_10()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("Regular");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("PushToTalk");
			"PLAYER IS BANNED" + str2 + "BN" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString(" ");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("{0} ({1})");
		"Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe." + str4 + "amongus" + str3;
	}

	// Token: 0x060004C8 RID: 1224 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60004C8")]
	[Address(RVA = "0x2A7281C", Offset = "0x2A7281C", VA = "0x2A7281C")]
	public DateAndTime()
	{
	}

	// Token: 0x060004C9 RID: 1225 RVA: 0x0000D808 File Offset: 0x0000BA08
	[Address(RVA = "0x2A72824", Offset = "0x2A72824", VA = "0x2A72824")]
	[Token(Token = "0x60004C9")]
	private void method_11()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("manual footTimings length should be equal to the leg count");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("ChangePlayerSize");
			"Player" + str2 + "Purchase For " + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("isLava");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("RainAndThunderWeather");
		"ORGPORT" + str4 + "_Tint" + str3;
	}

	// Token: 0x060004CA RID: 1226 RVA: 0x0000D8A4 File Offset: 0x0000BAA4
	[Address(RVA = "0x2A72A90", Offset = "0x2A72A90", VA = "0x2A72A90")]
	[Token(Token = "0x60004CA")]
	private void method_12()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("Horizontal");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Reason: ");
			"Target" + str2 + "gameMode" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("CapuchinStore");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("HeadAttachPoint");
		"RightHandAttachPoint" + str4 + "Cannot access an empty buffer." + str3;
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x0000D940 File Offset: 0x0000BB40
	[Address(RVA = "0x2A72CFC", Offset = "0x2A72CFC", VA = "0x2A72CFC")]
	[Token(Token = "0x60004CB")]
	private void method_13()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("Combine textures & build combined mesh using coroutine");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("Camera movement detected, calibrating height.");
			"spooky guy true" + str2 + "Name Changing Error. Error: " + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("PlayNoise");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString(", ");
		"[InputHelpers.IsPressed] The value of <button> is out or the supported range." + str4 + " and the correct version is " + str3;
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x0000D9DC File Offset: 0x0000BBDC
	[Address(RVA = "0x2A72F68", Offset = "0x2A72F68", VA = "0x2A72F68")]
	[Token(Token = "0x60004CC")]
	private void method_14()
	{
		if (!this.bool_0)
		{
			return;
		}
		string str = DateTime.UtcNow.ToLocalTime().ToString("FingerTip");
		string str2 = DateTime.UtcNow.ToLocalTime().ToString("Purchase For ");
		"True" + str2 + "Skelechin" + str;
	}

	// Token: 0x060004CD RID: 1229 RVA: 0x0000DA34 File Offset: 0x0000BC34
	[Address(RVA = "0x2A731C8", Offset = "0x2A731C8", VA = "0x2A731C8")]
	[Token(Token = "0x60004CD")]
	private void method_15()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("A new Player joined a Room.");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("CapuchinStore");
			"_BumpScale" + str2 + "typesOfTalk" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("You have been banned for ");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("SaveHeight");
		"PURCHASE" + str4 + "_WobbleZ" + str3;
	}

	// Token: 0x060004CE RID: 1230 RVA: 0x0000DAD0 File Offset: 0x0000BCD0
	[Address(RVA = "0x2A73434", Offset = "0x2A73434", VA = "0x2A73434")]
	[Token(Token = "0x60004CE")]
	private void method_16()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("poweredup!");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("StartGamemode");
			"Joined Public Room Successfully" + str2 + "CapuchinStore" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("_Tint");
		"You are not the master of the server, you cannot start the game." + str4 + "Connected to Server." + str3;
	}

	// Token: 0x060004CF RID: 1231 RVA: 0x0000DB6C File Offset: 0x0000BD6C
	[Token(Token = "0x60004CF")]
	[Address(RVA = "0x2A736A0", Offset = "0x2A736A0", VA = "0x2A736A0")]
	private void method_17()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("Update User Inventory");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("GET");
			"PlayerHead" + str2 + "Not connected to room" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("PURCHASE");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("Target");
		"PlayerHead" + str4 + "Cannot access index {0}. Buffer size is {1}" + str3;
	}

	// Token: 0x060004D0 RID: 1232 RVA: 0x0000DC08 File Offset: 0x0000BE08
	[Address(RVA = "0x2A73900", Offset = "0x2A73900", VA = "0x2A73900")]
	[Token(Token = "0x60004D0")]
	private void method_18()
	{
		if (!this.bool_0)
		{
			DateTime.UtcNow.ToLocalTime().ToString("Trigger");
			DateTime.UtcNow.ToLocalTime().ToString("Player");
			if (!this.bool_0)
			{
				return;
			}
		}
		string str = DateTime.UtcNow.ToLocalTime().ToString("liftoff failed!");
		string str2 = DateTime.UtcNow.ToLocalTime().ToString("Player");
		"1BN" + str2 + "Player" + str;
	}

	// Token: 0x060004D1 RID: 1233 RVA: 0x0000DC90 File Offset: 0x0000BE90
	[Token(Token = "0x60004D1")]
	[Address(RVA = "0x2A73B4C", Offset = "0x2A73B4C", VA = "0x2A73B4C")]
	private void method_19()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("StartSong");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("ChangeToTagged");
			"FingerTip" + str2 + "BLUPORT" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("Faild To Add Winner Money: ");
		"We don't need this electrical box" + str4 + "PlayerHead" + str3;
	}

	// Token: 0x060004D2 RID: 1234 RVA: 0x0000DD2C File Offset: 0x0000BF2C
	[Address(RVA = "0x2A73DB8", Offset = "0x2A73DB8", VA = "0x2A73DB8")]
	[Token(Token = "0x60004D2")]
	private void method_20()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("FingerTip");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("ORGPORT");
			"TurnAmount" + str2 + "Joined Public Room Successfully" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("DisableCosmetic");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("Vector1_d371bd24217449349bd747533d51af6b");
		"containsStaff" + str4 + "_Tint" + str3;
	}

	// Token: 0x060004D3 RID: 1235 RVA: 0x0000DDC8 File Offset: 0x0000BFC8
	[Token(Token = "0x60004D3")]
	[Address(RVA = "0x2A74024", Offset = "0x2A74024", VA = "0x2A74024")]
	private void method_21()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("Name Changing Error. Error: ");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("PlayerHead");
			"Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh." + str2 + "Key" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("Update User Inventory");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("Player was caught cheating");
		"hh:mmtt" + str4 + "FingerTip" + str3;
	}

	// Token: 0x060004D4 RID: 1236 RVA: 0x0000DE64 File Offset: 0x0000C064
	[Token(Token = "0x60004D4")]
	[Address(RVA = "0x2A74290", Offset = "0x2A74290", VA = "0x2A74290")]
	private void method_22()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("Bruh i cannot go here you stupid L bozo");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("username");
			"_Tint" + str2 + "Hate Speech" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		DateTime.UtcNow.ToLocalTime().ToString("retract broken");
		DateTime.UtcNow.ToLocalTime().ToString("MetaAuth");
	}

	// Token: 0x060004D5 RID: 1237 RVA: 0x0000DEE8 File Offset: 0x0000C0E8
	[Address(RVA = "0x2A744FC", Offset = "0x2A744FC", VA = "0x2A744FC")]
	[Token(Token = "0x60004D5")]
	private void method_23()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("On");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("FingerTip");
			"Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:" + str2 + "Squeeze" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString(".Please press the button if you would like to play alone");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("Vector1_d371bd24217449349bd747533d51af6b");
		"PRESS AGAIN TO CONFIRM" + str4 + "hh:mmtt" + str3;
	}

	// Token: 0x060004D6 RID: 1238 RVA: 0x0000DF84 File Offset: 0x0000C184
	[Token(Token = "0x60004D6")]
	[Address(RVA = "0x2A74768", Offset = "0x2A74768", VA = "0x2A74768")]
	private void method_24()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("true");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("/");
			"casual" + str2 + "PRESS AGAIN TO CONFIRM" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("deathScream");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("You Look Like Butt");
		"Connected to Server." + str4 + "\tExpires: " + str3;
	}

	// Token: 0x060004D7 RID: 1239 RVA: 0x0000E020 File Offset: 0x0000C220
	[Address(RVA = "0x2A749D4", Offset = "0x2A749D4", VA = "0x2A749D4")]
	[Token(Token = "0x60004D7")]
	private void method_25()
	{
		if (!this.bool_0)
		{
			string str = DateTime.UtcNow.ToLocalTime().ToString("/");
			string str2 = DateTime.UtcNow.ToLocalTime().ToString("BN");
			"Trying Getting Entilement..." + str2 + "retract broken" + str;
			if (!this.bool_0)
			{
				return;
			}
		}
		string str3 = DateTime.UtcNow.ToLocalTime().ToString("closeToObject");
		string str4 = DateTime.UtcNow.ToLocalTime().ToString("A Player has left the Room.");
		"casual" + str4 + "Adding " + str3;
	}

	// Token: 0x040000BA RID: 186
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000BA")]
	public TextMeshPro textMeshPro_0;

	// Token: 0x040000BB RID: 187
	[Token(Token = "0x40000BB")]
	[FieldOffset(Offset = "0x20")]
	public bool bool_0;
}
