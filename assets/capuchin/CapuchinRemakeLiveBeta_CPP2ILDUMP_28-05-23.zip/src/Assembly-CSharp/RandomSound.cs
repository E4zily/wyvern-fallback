﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200003E RID: 62
[Token(Token = "0x200003E")]
public class RandomSound : MonoBehaviour
{
	// Token: 0x060007F9 RID: 2041 RVA: 0x000124C8 File Offset: 0x000106C8
	[Address(RVA = "0x3480398", Offset = "0x3480398", VA = "0x3480398")]
	[Token(Token = "0x60007F9")]
	public IEnumerator method_0()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060007FA RID: 2042 RVA: 0x000124F0 File Offset: 0x000106F0
	[Address(RVA = "0x3480410", Offset = "0x3480410", VA = "0x3480410")]
	[Token(Token = "0x60007FA")]
	private void method_1()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_0();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x060007FB RID: 2043 RVA: 0x000124C8 File Offset: 0x000106C8
	[Address(RVA = "0x34804B4", Offset = "0x34804B4", VA = "0x34804B4")]
	[Token(Token = "0x60007FB")]
	public IEnumerator method_2()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060007FC RID: 2044 RVA: 0x00012518 File Offset: 0x00010718
	[Address(RVA = "0x348052C", Offset = "0x348052C", VA = "0x348052C")]
	[Token(Token = "0x60007FC")]
	private void method_3()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x060007FD RID: 2045 RVA: 0x000124C8 File Offset: 0x000106C8
	[Address(RVA = "0x3480648", Offset = "0x3480648", VA = "0x3480648")]
	[Token(Token = "0x60007FD")]
	public IEnumerator method_4()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060007FE RID: 2046 RVA: 0x00012540 File Offset: 0x00010740
	[Address(RVA = "0x34806C0", Offset = "0x34806C0", VA = "0x34806C0")]
	[Token(Token = "0x60007FE")]
	private void method_5()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_34();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x060007FF RID: 2047 RVA: 0x00012568 File Offset: 0x00010768
	[Token(Token = "0x60007FF")]
	[Address(RVA = "0x34807D8", Offset = "0x34807D8", VA = "0x34807D8")]
	private void method_6()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_38();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000800 RID: 2048 RVA: 0x00012590 File Offset: 0x00010790
	[Address(RVA = "0x34808F0", Offset = "0x34808F0", VA = "0x34808F0")]
	[Token(Token = "0x6000800")]
	private void method_7()
	{
		IEnumerator routine = this.method_34();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000801 RID: 2049 RVA: 0x000124C8 File Offset: 0x000106C8
	[Address(RVA = "0x3480990", Offset = "0x3480990", VA = "0x3480990")]
	[Token(Token = "0x6000801")]
	public IEnumerator method_8()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000802 RID: 2050 RVA: 0x000124C8 File Offset: 0x000106C8
	[Address(RVA = "0x3480A08", Offset = "0x3480A08", VA = "0x3480A08")]
	[Token(Token = "0x6000802")]
	public IEnumerator method_9()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000803 RID: 2051 RVA: 0x000125B0 File Offset: 0x000107B0
	[Address(RVA = "0x3480A80", Offset = "0x3480A80", VA = "0x3480A80")]
	[Token(Token = "0x6000803")]
	private void method_10()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_15();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000804 RID: 2052 RVA: 0x000125D8 File Offset: 0x000107D8
	[Token(Token = "0x6000804")]
	[Address(RVA = "0x3480B9C", Offset = "0x3480B9C", VA = "0x3480B9C")]
	private void method_11()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_13();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000805 RID: 2053 RVA: 0x00012600 File Offset: 0x00010800
	[Token(Token = "0x6000805")]
	[Address(RVA = "0x3480CB4", Offset = "0x3480CB4", VA = "0x3480CB4")]
	private void method_12()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_40();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000806 RID: 2054 RVA: 0x000124C8 File Offset: 0x000106C8
	[Token(Token = "0x6000806")]
	[Address(RVA = "0x3480C3C", Offset = "0x3480C3C", VA = "0x3480C3C")]
	public IEnumerator method_13()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000807 RID: 2055 RVA: 0x000124C8 File Offset: 0x000106C8
	[Token(Token = "0x6000807")]
	[Address(RVA = "0x34805D0", Offset = "0x34805D0", VA = "0x34805D0")]
	public IEnumerator method_14()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000808 RID: 2056 RVA: 0x000124C8 File Offset: 0x000106C8
	[Address(RVA = "0x3480B24", Offset = "0x3480B24", VA = "0x3480B24")]
	[Token(Token = "0x6000808")]
	public IEnumerator method_15()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000809 RID: 2057 RVA: 0x000124C8 File Offset: 0x000106C8
	[Token(Token = "0x6000809")]
	[Address(RVA = "0x3480DD0", Offset = "0x3480DD0", VA = "0x3480DD0")]
	public IEnumerator method_16()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600080A RID: 2058 RVA: 0x00012628 File Offset: 0x00010828
	[Address(RVA = "0x3480E48", Offset = "0x3480E48", VA = "0x3480E48")]
	[Token(Token = "0x600080A")]
	private void method_17()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_16();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x0600080B RID: 2059 RVA: 0x00012650 File Offset: 0x00010850
	[Token(Token = "0x600080B")]
	[Address(RVA = "0x3480EEC", Offset = "0x3480EEC", VA = "0x3480EEC")]
	private void method_18()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_25();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x0600080C RID: 2060 RVA: 0x000124C8 File Offset: 0x000106C8
	[Token(Token = "0x600080C")]
	[Address(RVA = "0x3481008", Offset = "0x3481008", VA = "0x3481008")]
	public IEnumerator method_19()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600080D RID: 2061 RVA: 0x00012678 File Offset: 0x00010878
	[Token(Token = "0x600080D")]
	[Address(RVA = "0x3481080", Offset = "0x3481080", VA = "0x3481080")]
	private void method_20()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_30();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x0600080E RID: 2062 RVA: 0x000126A0 File Offset: 0x000108A0
	[Token(Token = "0x600080E")]
	[Address(RVA = "0x348119C", Offset = "0x348119C", VA = "0x348119C")]
	public IEnumerator method_21()
	{
		RandomSound.Class10 @class;
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600080F RID: 2063 RVA: 0x000126BC File Offset: 0x000108BC
	[Address(RVA = "0x3481214", Offset = "0x3481214", VA = "0x3481214")]
	[Token(Token = "0x600080F")]
	private void method_22()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_19();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000810 RID: 2064 RVA: 0x000126E4 File Offset: 0x000108E4
	[Token(Token = "0x6000810")]
	[Address(RVA = "0x34812B8", Offset = "0x34812B8", VA = "0x34812B8")]
	private void Start()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_32();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000811 RID: 2065 RVA: 0x0001270C File Offset: 0x0001090C
	[Token(Token = "0x6000811")]
	[Address(RVA = "0x34813D4", Offset = "0x34813D4", VA = "0x34813D4")]
	private void method_23()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_32();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000812 RID: 2066 RVA: 0x00012600 File Offset: 0x00010800
	[Address(RVA = "0x3481474", Offset = "0x3481474", VA = "0x3481474")]
	[Token(Token = "0x6000812")]
	private void method_24()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_40();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000813 RID: 2067 RVA: 0x000124C8 File Offset: 0x000106C8
	[Token(Token = "0x6000813")]
	[Address(RVA = "0x3480F90", Offset = "0x3480F90", VA = "0x3480F90")]
	public IEnumerator method_25()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000814 RID: 2068 RVA: 0x00012734 File Offset: 0x00010934
	[Address(RVA = "0x3481518", Offset = "0x3481518", VA = "0x3481518")]
	[Token(Token = "0x6000814")]
	private void method_26()
	{
		if (this.bool_0)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000815 RID: 2069 RVA: 0x000124C8 File Offset: 0x000106C8
	[Token(Token = "0x6000815")]
	[Address(RVA = "0x34815BC", Offset = "0x34815BC", VA = "0x34815BC")]
	public IEnumerator method_27()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000816 RID: 2070 RVA: 0x00012754 File Offset: 0x00010954
	[Token(Token = "0x6000816")]
	[Address(RVA = "0x3481634", Offset = "0x3481634", VA = "0x3481634")]
	private void method_28()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_31();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000817 RID: 2071 RVA: 0x00012518 File Offset: 0x00010718
	[Token(Token = "0x6000817")]
	[Address(RVA = "0x348174C", Offset = "0x348174C", VA = "0x348174C")]
	private void method_29()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000818 RID: 2072 RVA: 0x0001277C File Offset: 0x0001097C
	[Token(Token = "0x6000818")]
	[Address(RVA = "0x3481124", Offset = "0x3481124", VA = "0x3481124")]
	public IEnumerator method_30()
	{
		new RandomSound.Class10((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x06000819 RID: 2073 RVA: 0x000124C8 File Offset: 0x000106C8
	[Address(RVA = "0x34816D4", Offset = "0x34816D4", VA = "0x34816D4")]
	[Token(Token = "0x6000819")]
	public IEnumerator method_31()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600081A RID: 2074 RVA: 0x000124C8 File Offset: 0x000106C8
	[Address(RVA = "0x348135C", Offset = "0x348135C", VA = "0x348135C")]
	[Token(Token = "0x600081A")]
	public IEnumerator method_32()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600081B RID: 2075 RVA: 0x000127A0 File Offset: 0x000109A0
	[Address(RVA = "0x34817F0", Offset = "0x34817F0", VA = "0x34817F0")]
	[Token(Token = "0x600081B")]
	private void method_33()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_27();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x0600081C RID: 2076 RVA: 0x000124C8 File Offset: 0x000106C8
	[Token(Token = "0x600081C")]
	[Address(RVA = "0x3480760", Offset = "0x3480760", VA = "0x3480760")]
	public IEnumerator method_34()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600081D RID: 2077 RVA: 0x00012678 File Offset: 0x00010878
	[Token(Token = "0x600081D")]
	[Address(RVA = "0x3481890", Offset = "0x3481890", VA = "0x3481890")]
	private void method_35()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_30();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x0600081E RID: 2078 RVA: 0x00012600 File Offset: 0x00010800
	[Address(RVA = "0x3481934", Offset = "0x3481934", VA = "0x3481934")]
	[Token(Token = "0x600081E")]
	private void method_36()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_40();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x0600081F RID: 2079 RVA: 0x000127C8 File Offset: 0x000109C8
	[Token(Token = "0x600081F")]
	[Address(RVA = "0x34819D8", Offset = "0x34819D8", VA = "0x34819D8")]
	private void method_37()
	{
		if (this.bool_0)
		{
			IEnumerator routine = this.method_9();
			base.StartCoroutine(routine);
			return;
		}
	}

	// Token: 0x06000820 RID: 2080 RVA: 0x000124C8 File Offset: 0x000106C8
	[Address(RVA = "0x3480878", Offset = "0x3480878", VA = "0x3480878")]
	[Token(Token = "0x6000820")]
	public IEnumerator method_38()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000821 RID: 2081 RVA: 0x000124C8 File Offset: 0x000106C8
	[Token(Token = "0x6000821")]
	[Address(RVA = "0x3481A7C", Offset = "0x3481A7C", VA = "0x3481A7C")]
	public IEnumerator method_39()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000822 RID: 2082 RVA: 0x000124C8 File Offset: 0x000106C8
	[Address(RVA = "0x3480D58", Offset = "0x3480D58", VA = "0x3480D58")]
	[Token(Token = "0x6000822")]
	public IEnumerator method_40()
	{
		RandomSound.Class10 @class = new RandomSound.Class10((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000823 RID: 2083 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000823")]
	[Address(RVA = "0x3481AF4", Offset = "0x3481AF4", VA = "0x3481AF4")]
	public RandomSound()
	{
	}

	// Token: 0x04000116 RID: 278
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000116")]
	public bool bool_0;

	// Token: 0x04000117 RID: 279
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x4000117")]
	public bool bool_1;

	// Token: 0x04000118 RID: 280
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000118")]
	public AudioSource audioSource_0;

	// Token: 0x04000119 RID: 281
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000119")]
	public AudioClip[] audioClip_0;
}
