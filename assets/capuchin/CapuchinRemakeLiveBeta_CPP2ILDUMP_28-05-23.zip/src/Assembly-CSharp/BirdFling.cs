﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200000A RID: 10
[Token(Token = "0x200000A")]
public class BirdFling : MonoBehaviour
{
	// Token: 0x0600011B RID: 283 RVA: 0x00007120 File Offset: 0x00005320
	[Address(RVA = "0x25A32CC", Offset = "0x25A32CC", VA = "0x25A32CC")]
	[Token(Token = "0x600011B")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("\n Time: ");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("typesOfTalk");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x0600011C RID: 284 RVA: 0x00007168 File Offset: 0x00005368
	[Token(Token = "0x600011C")]
	[Address(RVA = "0x25A3488", Offset = "0x25A3488", VA = "0x25A3488")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_Tint");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("down unstuck");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x0600011D RID: 285 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x600011D")]
	[Address(RVA = "0x25A3644", Offset = "0x25A3644", VA = "0x25A3644")]
	public BirdFling()
	{
	}

	// Token: 0x0600011E RID: 286 RVA: 0x000071B0 File Offset: 0x000053B0
	[Token(Token = "0x600011E")]
	[Address(RVA = "0x25A364C", Offset = "0x25A364C", VA = "0x25A364C")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("FingerTip");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x0600011F RID: 287 RVA: 0x000071F8 File Offset: 0x000053F8
	[Address(RVA = "0x25A3808", Offset = "0x25A3808", VA = "0x25A3808")]
	[Token(Token = "0x600011F")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("5BN");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("spooky guy true");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x06000120 RID: 288 RVA: 0x00007240 File Offset: 0x00005440
	[Address(RVA = "0x25A39C4", Offset = "0x25A39C4", VA = "0x25A39C4")]
	[Token(Token = "0x6000120")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("HandR");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("DISABLE");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x06000121 RID: 289 RVA: 0x00007288 File Offset: 0x00005488
	[Address(RVA = "0x25A3B80", Offset = "0x25A3B80", VA = "0x25A3B80")]
	[Token(Token = "0x6000121")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("EnableCosmetic");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("_Color");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x06000122 RID: 290 RVA: 0x000072D0 File Offset: 0x000054D0
	[Token(Token = "0x6000122")]
	[Address(RVA = "0x25A3D3C", Offset = "0x25A3D3C", VA = "0x25A3D3C")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Done");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("Skelechin");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x06000123 RID: 291 RVA: 0x00007318 File Offset: 0x00005518
	[Token(Token = "0x6000123")]
	[Address(RVA = "0x25A3EF8", Offset = "0x25A3EF8", VA = "0x25A3EF8")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PRESS AGAIN TO CONFIRM");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("5BN");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x06000124 RID: 292 RVA: 0x00007360 File Offset: 0x00005560
	[Token(Token = "0x6000124")]
	[Address(RVA = "0x25A40B4", Offset = "0x25A40B4", VA = "0x25A40B4")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("containsStaff");
		Vector3 up2 = base.transform.up;
		long maxExclusive = 0L;
		UnityEngine.Random.Range(1, (int)maxExclusive);
	}

	// Token: 0x06000125 RID: 293 RVA: 0x000073B4 File Offset: 0x000055B4
	[Token(Token = "0x6000125")]
	[Address(RVA = "0x25A4270", Offset = "0x25A4270", VA = "0x25A4270")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("We don't need this electrical box");
		Transform transform;
		Vector3 up = transform.up;
		long maxExclusive = 0L;
		UnityEngine.Random.Range(1, (int)maxExclusive);
		collider_0.gameObject.CompareTag("5BN");
		Transform transform2;
		Vector3 up2 = transform2.up;
		long maxExclusive2 = 0L;
		UnityEngine.Random.Range(0, (int)maxExclusive2);
	}

	// Token: 0x06000126 RID: 294 RVA: 0x00007408 File Offset: 0x00005608
	[Token(Token = "0x6000126")]
	[Address(RVA = "0x25A442C", Offset = "0x25A442C", VA = "0x25A442C")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Added Winner Money");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("Player");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x06000127 RID: 295 RVA: 0x00007450 File Offset: 0x00005650
	[Address(RVA = "0x25A45E8", Offset = "0x25A45E8", VA = "0x25A45E8")]
	[Token(Token = "0x6000127")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Tagging");
		Transform transform;
		Vector3 up = transform.up;
		collider_0.gameObject.CompareTag("Player");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x06000128 RID: 296 RVA: 0x00007494 File Offset: 0x00005694
	[Address(RVA = "0x25A47A4", Offset = "0x25A47A4", VA = "0x25A47A4")]
	[Token(Token = "0x6000128")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("A Player has left the Room.");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("typesOfTalk");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x06000129 RID: 297 RVA: 0x000074DC File Offset: 0x000056DC
	[Address(RVA = "0x25A4960", Offset = "0x25A4960", VA = "0x25A4960")]
	[Token(Token = "0x6000129")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("cheese");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("HandL");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x0600012A RID: 298 RVA: 0x00007524 File Offset: 0x00005724
	[Address(RVA = "0x25A4B1C", Offset = "0x25A4B1C", VA = "0x25A4B1C")]
	[Token(Token = "0x600012A")]
	public void method_13(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
		Vector3 up = base.transform.up;
		GameObject gameObject2 = collider_0.gameObject;
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x0600012B RID: 299 RVA: 0x00007558 File Offset: 0x00005758
	[Address(RVA = "0x25A4CD8", Offset = "0x25A4CD8", VA = "0x25A4CD8")]
	[Token(Token = "0x600012B")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("TurnAmount");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x0600012C RID: 300 RVA: 0x000075A0 File Offset: 0x000057A0
	[Address(RVA = "0x25A4E94", Offset = "0x25A4E94", VA = "0x25A4E94")]
	[Token(Token = "0x600012C")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("TurnAmount");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x0600012D RID: 301 RVA: 0x000075E8 File Offset: 0x000057E8
	[Token(Token = "0x600012D")]
	[Address(RVA = "0x25A5050", Offset = "0x25A5050", VA = "0x25A5050")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("Toxicity");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x0600012E RID: 302 RVA: 0x00007630 File Offset: 0x00005830
	[Address(RVA = "0x25A520C", Offset = "0x25A520C", VA = "0x25A520C")]
	[Token(Token = "0x600012E")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("username");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("Did Hit");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x0600012F RID: 303 RVA: 0x00007678 File Offset: 0x00005878
	[Token(Token = "0x600012F")]
	[Address(RVA = "0x25A53C8", Offset = "0x25A53C8", VA = "0x25A53C8")]
	public void method_18(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
		Transform transform;
		Vector3 up = transform.up;
		collider_0.gameObject.CompareTag("_WobbleZ");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x06000130 RID: 304 RVA: 0x000076B0 File Offset: 0x000058B0
	[Address(RVA = "0x25A5584", Offset = "0x25A5584", VA = "0x25A5584")]
	[Token(Token = "0x6000130")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("A new Player joined a Room.");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("PlayerHead");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x06000131 RID: 305 RVA: 0x000076F8 File Offset: 0x000058F8
	[Address(RVA = "0x25A5740", Offset = "0x25A5740", VA = "0x25A5740")]
	[Token(Token = "0x6000131")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("TurnAmount");
		Vector3 up = base.transform.up;
		collider_0.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
		Vector3 up2 = base.transform.up;
	}

	// Token: 0x04000029 RID: 41
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000029")]
	public Rigidbody rigidbody_0;

	// Token: 0x0400002A RID: 42
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400002A")]
	public Transform transform_0;

	// Token: 0x0400002B RID: 43
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400002B")]
	public float float_0;

	// Token: 0x0400002C RID: 44
	[Token(Token = "0x400002C")]
	[FieldOffset(Offset = "0x30")]
	public AudioSource audioSource_0;

	// Token: 0x0400002D RID: 45
	[Token(Token = "0x400002D")]
	[FieldOffset(Offset = "0x38")]
	public AudioClip[] audioClip_0;
}
