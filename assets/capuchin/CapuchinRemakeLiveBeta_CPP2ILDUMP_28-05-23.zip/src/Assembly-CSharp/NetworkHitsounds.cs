﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000DE RID: 222
[Token(Token = "0x20000DE")]
public class NetworkHitsounds : MonoBehaviour
{
	// Token: 0x06002125 RID: 8485 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x3688908", Offset = "0x3688908", VA = "0x3688908")]
	[Token(Token = "0x6002125")]
	private void method_0(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002126 RID: 8486 RVA: 0x0003E0E4 File Offset: 0x0003C2E4
	[Address(RVA = "0x3688B5C", Offset = "0x3688B5C", VA = "0x3688B5C")]
	[Token(Token = "0x6002126")]
	private void method_1(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002127 RID: 8487 RVA: 0x0003E118 File Offset: 0x0003C318
	[Address(RVA = "0x3688DB0", Offset = "0x3688DB0", VA = "0x3688DB0")]
	[Token(Token = "0x6002127")]
	private void method_2(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002128 RID: 8488 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x3689004", Offset = "0x3689004", VA = "0x3689004")]
	[Token(Token = "0x6002128")]
	private void method_3(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002129 RID: 8489 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x3689258", Offset = "0x3689258", VA = "0x3689258")]
	[Token(Token = "0x6002129")]
	private void method_4(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600212A RID: 8490 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x36894AC", Offset = "0x36894AC", VA = "0x36894AC")]
	[Token(Token = "0x600212A")]
	private void method_5(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600212B RID: 8491 RVA: 0x0003E14C File Offset: 0x0003C34C
	[Address(RVA = "0x3689700", Offset = "0x3689700", VA = "0x3689700")]
	[Token(Token = "0x600212B")]
	public NetworkHitsounds()
	{
		long num = 1L;
		this.bool_0 = (num != 0L);
		base..ctor();
	}

	// Token: 0x0600212C RID: 8492 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x3689710", Offset = "0x3689710", VA = "0x3689710")]
	[Token(Token = "0x600212C")]
	private void method_6(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600212D RID: 8493 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x3689964", Offset = "0x3689964", VA = "0x3689964")]
	[Token(Token = "0x600212D")]
	private void method_7(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600212E RID: 8494 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x3689BB8", Offset = "0x3689BB8", VA = "0x3689BB8")]
	[Token(Token = "0x600212E")]
	private void method_8(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600212F RID: 8495 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x3689E0C", Offset = "0x3689E0C", VA = "0x3689E0C")]
	[Token(Token = "0x600212F")]
	private void method_9(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002130 RID: 8496 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368A060", Offset = "0x368A060", VA = "0x368A060")]
	[Token(Token = "0x6002130")]
	private void method_10(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002131 RID: 8497 RVA: 0x0003E168 File Offset: 0x0003C368
	[Address(RVA = "0x368A2B4", Offset = "0x368A2B4", VA = "0x368A2B4")]
	[Token(Token = "0x6002131")]
	private void method_11(Collider collider_0)
	{
		GameObject gameObject;
		Surface component = gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject2 = base.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002132 RID: 8498 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368A508", Offset = "0x368A508", VA = "0x368A508")]
	[Token(Token = "0x6002132")]
	private void method_12(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002133 RID: 8499 RVA: 0x0003E198 File Offset: 0x0003C398
	[Address(RVA = "0x368A75C", Offset = "0x368A75C", VA = "0x368A75C")]
	[Token(Token = "0x6002133")]
	private void method_13(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002134 RID: 8500 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368A9B0", Offset = "0x368A9B0", VA = "0x368A9B0")]
	[Token(Token = "0x6002134")]
	private void method_14(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002135 RID: 8501 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368AC04", Offset = "0x368AC04", VA = "0x368AC04")]
	[Token(Token = "0x6002135")]
	private void method_15(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002136 RID: 8502 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368AE58", Offset = "0x368AE58", VA = "0x368AE58")]
	[Token(Token = "0x6002136")]
	private void method_16(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002137 RID: 8503 RVA: 0x0003E1CC File Offset: 0x0003C3CC
	[Address(RVA = "0x368B0AC", Offset = "0x368B0AC", VA = "0x368B0AC")]
	[Token(Token = "0x6002137")]
	private void method_17(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002138 RID: 8504 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368B300", Offset = "0x368B300", VA = "0x368B300")]
	[Token(Token = "0x6002138")]
	private void method_18(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002139 RID: 8505 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368B554", Offset = "0x368B554", VA = "0x368B554")]
	[Token(Token = "0x6002139")]
	private void method_19(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600213A RID: 8506 RVA: 0x0003E0E4 File Offset: 0x0003C2E4
	[Address(RVA = "0x368B7A8", Offset = "0x368B7A8", VA = "0x368B7A8")]
	[Token(Token = "0x600213A")]
	private void method_20(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600213B RID: 8507 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x368B9FC", Offset = "0x368B9FC", VA = "0x368B9FC")]
	[Token(Token = "0x600213B")]
	private void method_21(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600213C RID: 8508 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368BC50", Offset = "0x368BC50", VA = "0x368BC50")]
	[Token(Token = "0x600213C")]
	private void method_22(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600213D RID: 8509 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368BEA4", Offset = "0x368BEA4", VA = "0x368BEA4")]
	[Token(Token = "0x600213D")]
	private void method_23(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600213E RID: 8510 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368C0F8", Offset = "0x368C0F8", VA = "0x368C0F8")]
	[Token(Token = "0x600213E")]
	private void method_24(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600213F RID: 8511 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368C34C", Offset = "0x368C34C", VA = "0x368C34C")]
	[Token(Token = "0x600213F")]
	private void method_25(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002140 RID: 8512 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368C5A0", Offset = "0x368C5A0", VA = "0x368C5A0")]
	[Token(Token = "0x6002140")]
	private void method_26(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002141 RID: 8513 RVA: 0x0003E200 File Offset: 0x0003C400
	[Address(RVA = "0x368C7F4", Offset = "0x368C7F4", VA = "0x368C7F4")]
	[Token(Token = "0x6002141")]
	private void method_27(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Surface>();
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002142 RID: 8514 RVA: 0x0003E22C File Offset: 0x0003C42C
	[Address(RVA = "0x368CA48", Offset = "0x368CA48", VA = "0x368CA48")]
	[Token(Token = "0x6002142")]
	private void OnTriggerEnter(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002143 RID: 8515 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368CC90", Offset = "0x368CC90", VA = "0x368CC90")]
	[Token(Token = "0x6002143")]
	private void method_28(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002144 RID: 8516 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368CEE4", Offset = "0x368CEE4", VA = "0x368CEE4")]
	[Token(Token = "0x6002144")]
	private void method_29(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002145 RID: 8517 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368D138", Offset = "0x368D138", VA = "0x368D138")]
	[Token(Token = "0x6002145")]
	private void method_30(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002146 RID: 8518 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368D38C", Offset = "0x368D38C", VA = "0x368D38C")]
	[Token(Token = "0x6002146")]
	private void method_31(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002147 RID: 8519 RVA: 0x0003E260 File Offset: 0x0003C460
	[Address(RVA = "0x368D5E0", Offset = "0x368D5E0", VA = "0x368D5E0")]
	[Token(Token = "0x6002147")]
	private void method_32(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06002148 RID: 8520 RVA: 0x0003E294 File Offset: 0x0003C494
	[Address(RVA = "0x368D834", Offset = "0x368D834", VA = "0x368D834")]
	[Token(Token = "0x6002148")]
	private void method_33(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = base.gameObject;
		AudioSource audioSource = this.audioSource_0;
		audioSource.Play();
	}

	// Token: 0x06002149 RID: 8521 RVA: 0x0003E118 File Offset: 0x0003C318
	[Address(RVA = "0x368DA88", Offset = "0x368DA88", VA = "0x368DA88")]
	[Token(Token = "0x6002149")]
	private void method_34(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600214A RID: 8522 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368DCDC", Offset = "0x368DCDC", VA = "0x368DCDC")]
	[Token(Token = "0x600214A")]
	private void method_35(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600214B RID: 8523 RVA: 0x0003E0B0 File Offset: 0x0003C2B0
	[Address(RVA = "0x368DF30", Offset = "0x368DF30", VA = "0x368DF30")]
	[Token(Token = "0x600214B")]
	private void method_36(Collider collider_0)
	{
		Surface component = collider_0.gameObject.GetComponent<Surface>();
		this.surface_0 = component;
		GameObject gameObject = collider_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x04000462 RID: 1122
	[Token(Token = "0x4000462")]
	[FieldOffset(Offset = "0x18")]
	public AudioClip[] audioClip_0;

	// Token: 0x04000463 RID: 1123
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000463")]
	public AudioClip[] audioClip_1;

	// Token: 0x04000464 RID: 1124
	[Token(Token = "0x4000464")]
	[FieldOffset(Offset = "0x28")]
	public AudioClip[] audioClip_2;

	// Token: 0x04000465 RID: 1125
	[Token(Token = "0x4000465")]
	[FieldOffset(Offset = "0x30")]
	public AudioClip[] audioClip_3;

	// Token: 0x04000466 RID: 1126
	[Token(Token = "0x4000466")]
	[FieldOffset(Offset = "0x38")]
	public AudioSource audioSource_0;

	// Token: 0x04000467 RID: 1127
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000467")]
	public AudioClip[] audioClip_4;

	// Token: 0x04000468 RID: 1128
	[Token(Token = "0x4000468")]
	[FieldOffset(Offset = "0x48")]
	public AudioClip[] audioClip_5;

	// Token: 0x04000469 RID: 1129
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000469")]
	public AudioClip[] audioClip_6;

	// Token: 0x0400046A RID: 1130
	[Token(Token = "0x400046A")]
	[FieldOffset(Offset = "0x58")]
	public AudioClip[] audioClip_7;

	// Token: 0x0400046B RID: 1131
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400046B")]
	public AudioClip[] audioClip_8;

	// Token: 0x0400046C RID: 1132
	[Token(Token = "0x400046C")]
	[FieldOffset(Offset = "0x68")]
	public AudioClip[] audioClip_9;

	// Token: 0x0400046D RID: 1133
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x400046D")]
	private bool bool_0;

	// Token: 0x0400046E RID: 1134
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x400046E")]
	private Surface surface_0;
}
