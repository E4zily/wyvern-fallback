﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000037 RID: 55
[Token(Token = "0x2000037")]
public class NetworkPlayerColor : MonoBehaviour
{
	// Token: 0x060006C8 RID: 1736 RVA: 0x00011354 File Offset: 0x0000F554
	[Token(Token = "0x60006C8")]
	[Address(RVA = "0x2D4DA1C", Offset = "0x2D4DA1C", VA = "0x2D4DA1C")]
	private void method_0()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("goUpRPC", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture("lock unlocked!", value2);
			material.name = "Applying to material";
			return;
		}
	}

	// Token: 0x060006C9 RID: 1737 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Token(Token = "0x60006C9")]
	[Address(RVA = "0x2D4DBC8", Offset = "0x2D4DBC8", VA = "0x2D4DBC8")]
	public void method_1(Vector3 vector3_1)
	{
	}

	// Token: 0x060006CA RID: 1738 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Address(RVA = "0x2D4DCD8", Offset = "0x2D4DCD8", VA = "0x2D4DCD8")]
	[Token(Token = "0x60006CA")]
	public void method_2(Vector3 vector3_1)
	{
	}

	// Token: 0x060006CB RID: 1739 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Token(Token = "0x60006CB")]
	[Address(RVA = "0x2D4DDE8", Offset = "0x2D4DDE8", VA = "0x2D4DDE8")]
	public void method_3(Vector3 vector3_1)
	{
	}

	// Token: 0x060006CC RID: 1740 RVA: 0x000113CC File Offset: 0x0000F5CC
	[Address(RVA = "0x2D4DF1C", Offset = "0x2D4DF1C", VA = "0x2D4DF1C")]
	[Token(Token = "0x60006CC")]
	public void method_4(Vector3 vector3_1)
	{
		PhotonView photonView = this.photonView_0;
		object[] parameters = new object[0];
		photonView.RPC("\tExpires: ", RpcTarget.AllViaServer, parameters);
	}

	// Token: 0x060006CD RID: 1741 RVA: 0x000113F4 File Offset: 0x0000F5F4
	[Address(RVA = "0x2D4E04C", Offset = "0x2D4E04C", VA = "0x2D4E04C")]
	[Token(Token = "0x60006CD")]
	public void method_5(Vector3 vector3_1)
	{
		PhotonView photonView = this.photonView_0;
		object[] parameters = new object[0];
		photonView.RPC("BN", RpcTarget.AllViaServer, parameters);
	}

	// Token: 0x060006CE RID: 1742 RVA: 0x0001141C File Offset: 0x0000F61C
	[Token(Token = "0x60006CE")]
	[Address(RVA = "0x2D4E17C", Offset = "0x2D4E17C", VA = "0x2D4E17C")]
	private void method_6()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.shader_0);
		Texture2D value = this.texture2D_0;
		material.SetTexture("Failed to login, please restart", value);
		Texture2D value2 = this.texture2D_1;
		material.SetTexture("Vector1_d371bd24217449349bd747533d51af6b", value2);
		if (this.skinnedMeshRenderer_0 == null)
		{
			return;
		}
		material.name = "Date: ";
	}

	// Token: 0x060006CF RID: 1743 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Token(Token = "0x60006CF")]
	[Address(RVA = "0x2D4E2FC", Offset = "0x2D4E2FC", VA = "0x2D4E2FC")]
	public void method_7(Vector3 vector3_1)
	{
	}

	// Token: 0x060006D0 RID: 1744 RVA: 0x00011480 File Offset: 0x0000F680
	[Address(RVA = "0x2D4E40C", Offset = "0x2D4E40C", VA = "0x2D4E40C")]
	[Token(Token = "0x60006D0")]
	private void method_8()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("Did Hit", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture("Player", value2);
			material.name = "closeToObject";
			return;
		}
	}

	// Token: 0x060006D1 RID: 1745 RVA: 0x000114D8 File Offset: 0x0000F6D8
	[Token(Token = "0x60006D1")]
	[Address(RVA = "0x2D4E5B8", Offset = "0x2D4E5B8", VA = "0x2D4E5B8")]
	private void method_9()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.shader_0);
		Texture2D value = this.texture2D_0;
		material.SetTexture("Start Gamemode", value);
		Texture2D value2 = this.texture2D_1;
		material.SetTexture("MetaId", value2);
		if (this.skinnedMeshRenderer_0 == null)
		{
			return;
		}
		material.name = "character limit reached";
	}

	// Token: 0x060006D2 RID: 1746 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Token(Token = "0x60006D2")]
	[Address(RVA = "0x2D4E73C", Offset = "0x2D4E73C", VA = "0x2D4E73C")]
	public void method_10(Vector3 vector3_1)
	{
	}

	// Token: 0x060006D3 RID: 1747 RVA: 0x0001153C File Offset: 0x0000F73C
	[Token(Token = "0x60006D3")]
	[Address(RVA = "0x2D4E84C", Offset = "0x2D4E84C", VA = "0x2D4E84C")]
	public void method_11(Vector3 vector3_1)
	{
	}

	// Token: 0x060006D4 RID: 1748 RVA: 0x0001153C File Offset: 0x0000F73C
	[Address(RVA = "0x2D4E980", Offset = "0x2D4E980", VA = "0x2D4E980")]
	[Token(Token = "0x60006D4")]
	public void method_12(Vector3 vector3_1)
	{
	}

	// Token: 0x060006D5 RID: 1749 RVA: 0x0001153C File Offset: 0x0000F73C
	[Token(Token = "0x60006D5")]
	[Address(RVA = "0x2D4EAB0", Offset = "0x2D4EAB0", VA = "0x2D4EAB0")]
	public void method_13(Vector3 vector3_1)
	{
	}

	// Token: 0x060006D6 RID: 1750 RVA: 0x0001154C File Offset: 0x0000F74C
	[Token(Token = "0x60006D6")]
	[Address(RVA = "0x2D4EBE4", Offset = "0x2D4EBE4", VA = "0x2D4EBE4")]
	private void method_14()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.shader_0);
		Texture2D value = this.texture2D_0;
		material.SetTexture("Bare Torso", value);
		Texture2D value2 = this.texture2D_1;
		material.SetTexture("CASUAL", value2);
		if (this.skinnedMeshRenderer_0 == null)
		{
			return;
		}
		material.name = "CapuchinStore";
	}

	// Token: 0x060006D7 RID: 1751 RVA: 0x0001153C File Offset: 0x0000F73C
	[Token(Token = "0x60006D7")]
	[Address(RVA = "0x2D4ED68", Offset = "0x2D4ED68", VA = "0x2D4ED68")]
	public void method_15(Vector3 vector3_1)
	{
	}

	// Token: 0x060006D8 RID: 1752 RVA: 0x0001153C File Offset: 0x0000F73C
	[Token(Token = "0x60006D8")]
	[Address(RVA = "0x2D4EE9C", Offset = "0x2D4EE9C", VA = "0x2D4EE9C")]
	public void method_16(Vector3 vector3_1)
	{
	}

	// Token: 0x060006D9 RID: 1753 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Address(RVA = "0x2D4EFCC", Offset = "0x2D4EFCC", VA = "0x2D4EFCC")]
	[Token(Token = "0x60006D9")]
	public void method_17(Vector3 vector3_1)
	{
	}

	// Token: 0x060006DA RID: 1754 RVA: 0x0001153C File Offset: 0x0000F73C
	[Token(Token = "0x60006DA")]
	[Address(RVA = "0x2D4F0DC", Offset = "0x2D4F0DC", VA = "0x2D4F0DC")]
	public void method_18(Vector3 vector3_1)
	{
	}

	// Token: 0x060006DB RID: 1755 RVA: 0x000115B0 File Offset: 0x0000F7B0
	[Token(Token = "0x60006DB")]
	[Address(RVA = "0x2D4F20C", Offset = "0x2D4F20C", VA = "0x2D4F20C")]
	private void method_19()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("Calling success callback. baking meshes", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture("Player", value2);
			material.name = "CapuchinRemade";
			return;
		}
	}

	// Token: 0x060006DC RID: 1756 RVA: 0x00011608 File Offset: 0x0000F808
	[Token(Token = "0x60006DC")]
	[Address(RVA = "0x2D4F3B8", Offset = "0x2D4F3B8", VA = "0x2D4F3B8")]
	private void method_20()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("button", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture("True", value2);
			material.name = "KeyPos";
			return;
		}
	}

	// Token: 0x060006DD RID: 1757 RVA: 0x0001153C File Offset: 0x0000F73C
	[Address(RVA = "0x2D4F564", Offset = "0x2D4F564", VA = "0x2D4F564")]
	[Token(Token = "0x60006DD")]
	public void method_21(Vector3 vector3_1)
	{
	}

	// Token: 0x060006DE RID: 1758 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Address(RVA = "0x2D4F694", Offset = "0x2D4F694", VA = "0x2D4F694")]
	[Token(Token = "0x60006DE")]
	public void method_22(Vector3 vector3_1)
	{
	}

	// Token: 0x060006DF RID: 1759 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Address(RVA = "0x2D4F7C8", Offset = "0x2D4F7C8", VA = "0x2D4F7C8")]
	[Token(Token = "0x60006DF")]
	public void method_23(Vector3 vector3_1)
	{
	}

	// Token: 0x060006E0 RID: 1760 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Address(RVA = "0x2D4F8D8", Offset = "0x2D4F8D8", VA = "0x2D4F8D8")]
	[Token(Token = "0x60006E0")]
	public void method_24(Vector3 vector3_1)
	{
	}

	// Token: 0x060006E1 RID: 1761 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Address(RVA = "0x2D4FA0C", Offset = "0x2D4FA0C", VA = "0x2D4FA0C")]
	[Token(Token = "0x60006E1")]
	public void method_25(Vector3 vector3_1)
	{
	}

	// Token: 0x060006E2 RID: 1762 RVA: 0x00011660 File Offset: 0x0000F860
	[Token(Token = "0x60006E2")]
	[Address(RVA = "0x2D4FB1C", Offset = "0x2D4FB1C", VA = "0x2D4FB1C")]
	public void method_26(Vector3 vector3_1)
	{
	}

	// Token: 0x060006E3 RID: 1763 RVA: 0x000113AC File Offset: 0x0000F5AC
	[PunRPC]
	[Token(Token = "0x60006E3")]
	[Address(RVA = "0x2D4FC04", Offset = "0x2D4FC04", VA = "0x2D4FC04")]
	public void SetColor(Vector3 vector3_1)
	{
	}

	// Token: 0x060006E4 RID: 1764 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Token(Token = "0x60006E4")]
	[Address(RVA = "0x2D4FD14", Offset = "0x2D4FD14", VA = "0x2D4FD14")]
	public void method_27(Vector3 vector3_1)
	{
	}

	// Token: 0x060006E5 RID: 1765 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Token(Token = "0x60006E5")]
	[Address(RVA = "0x2D4FE44", Offset = "0x2D4FE44", VA = "0x2D4FE44")]
	public void method_28(Vector3 vector3_1)
	{
	}

	// Token: 0x060006E6 RID: 1766 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Token(Token = "0x60006E6")]
	[Address(RVA = "0x2D4FF78", Offset = "0x2D4FF78", VA = "0x2D4FF78")]
	public void method_29(Vector3 vector3_1)
	{
	}

	// Token: 0x060006E7 RID: 1767 RVA: 0x00011660 File Offset: 0x0000F860
	[Address(RVA = "0x2D50088", Offset = "0x2D50088", VA = "0x2D50088")]
	[Token(Token = "0x60006E7")]
	public void method_30(Vector3 vector3_1)
	{
	}

	// Token: 0x060006E8 RID: 1768 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Token(Token = "0x60006E8")]
	[Address(RVA = "0x2D50170", Offset = "0x2D50170", VA = "0x2D50170")]
	public void method_31(Vector3 vector3_1)
	{
	}

	// Token: 0x060006E9 RID: 1769 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Token(Token = "0x60006E9")]
	[Address(RVA = "0x2D50280", Offset = "0x2D50280", VA = "0x2D50280")]
	public void method_32(Vector3 vector3_1)
	{
	}

	// Token: 0x060006EA RID: 1770 RVA: 0x00011660 File Offset: 0x0000F860
	[Address(RVA = "0x2D50390", Offset = "0x2D50390", VA = "0x2D50390")]
	[Token(Token = "0x60006EA")]
	public void method_33(Vector3 vector3_1)
	{
	}

	// Token: 0x060006EB RID: 1771 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Address(RVA = "0x2D50478", Offset = "0x2D50478", VA = "0x2D50478")]
	[Token(Token = "0x60006EB")]
	public void method_34(Vector3 vector3_1)
	{
	}

	// Token: 0x060006EC RID: 1772 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Token(Token = "0x60006EC")]
	[Address(RVA = "0x2D50588", Offset = "0x2D50588", VA = "0x2D50588")]
	public void method_35(Vector3 vector3_1)
	{
	}

	// Token: 0x060006ED RID: 1773 RVA: 0x0001153C File Offset: 0x0000F73C
	[Address(RVA = "0x2D506B8", Offset = "0x2D506B8", VA = "0x2D506B8")]
	[Token(Token = "0x60006ED")]
	public void method_36(Vector3 vector3_1)
	{
	}

	// Token: 0x060006EE RID: 1774 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Token(Token = "0x60006EE")]
	[Address(RVA = "0x2D507E8", Offset = "0x2D507E8", VA = "0x2D507E8")]
	public void method_37(Vector3 vector3_1)
	{
	}

	// Token: 0x060006EF RID: 1775 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Address(RVA = "0x2D5091C", Offset = "0x2D5091C", VA = "0x2D5091C")]
	[Token(Token = "0x60006EF")]
	public void method_38(Vector3 vector3_1)
	{
	}

	// Token: 0x060006F0 RID: 1776 RVA: 0x00011670 File Offset: 0x0000F870
	[Address(RVA = "0x2D50A4C", Offset = "0x2D50A4C", VA = "0x2D50A4C")]
	[Token(Token = "0x60006F0")]
	private void method_39()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		if (this.skinnedMeshRenderer_0 == null)
		{
			return;
		}
	}

	// Token: 0x060006F1 RID: 1777 RVA: 0x00011660 File Offset: 0x0000F860
	[Token(Token = "0x60006F1")]
	[Address(RVA = "0x2D50BD0", Offset = "0x2D50BD0", VA = "0x2D50BD0")]
	public void method_40(Vector3 vector3_1)
	{
	}

	// Token: 0x060006F2 RID: 1778 RVA: 0x00011694 File Offset: 0x0000F894
	[Address(RVA = "0x2D50CB8", Offset = "0x2D50CB8", VA = "0x2D50CB8")]
	[Token(Token = "0x60006F2")]
	public void method_41(Vector3 vector3_1)
	{
	}

	// Token: 0x060006F3 RID: 1779 RVA: 0x0001153C File Offset: 0x0000F73C
	[Address(RVA = "0x2D50DEC", Offset = "0x2D50DEC", VA = "0x2D50DEC")]
	[Token(Token = "0x60006F3")]
	public void method_42(Vector3 vector3_1)
	{
	}

	// Token: 0x060006F4 RID: 1780 RVA: 0x00011660 File Offset: 0x0000F860
	[Token(Token = "0x60006F4")]
	[Address(RVA = "0x2D50F20", Offset = "0x2D50F20", VA = "0x2D50F20")]
	public void method_43(Vector3 vector3_1)
	{
	}

	// Token: 0x060006F5 RID: 1781 RVA: 0x000116A4 File Offset: 0x0000F8A4
	[Token(Token = "0x60006F5")]
	[Address(RVA = "0x2D51008", Offset = "0x2D51008", VA = "0x2D51008")]
	private void method_44()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("PURCHASED!", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture("Updating Material to: ", value2);
			material.name = "cosmos";
			return;
		}
	}

	// Token: 0x060006F6 RID: 1782 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Token(Token = "0x60006F6")]
	[Address(RVA = "0x2D511B4", Offset = "0x2D511B4", VA = "0x2D511B4")]
	public void method_45(Vector3 vector3_1)
	{
	}

	// Token: 0x060006F7 RID: 1783 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Token(Token = "0x60006F7")]
	[Address(RVA = "0x2D512E8", Offset = "0x2D512E8", VA = "0x2D512E8")]
	public void method_46(Vector3 vector3_1)
	{
	}

	// Token: 0x060006F8 RID: 1784 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60006F8")]
	[Address(RVA = "0x2D51418", Offset = "0x2D51418", VA = "0x2D51418")]
	public NetworkPlayerColor()
	{
	}

	// Token: 0x060006F9 RID: 1785 RVA: 0x00011660 File Offset: 0x0000F860
	[Address(RVA = "0x2D51420", Offset = "0x2D51420", VA = "0x2D51420")]
	[Token(Token = "0x60006F9")]
	public void method_47(Vector3 vector3_1)
	{
	}

	// Token: 0x060006FA RID: 1786 RVA: 0x00011660 File Offset: 0x0000F860
	[Address(RVA = "0x2D51508", Offset = "0x2D51508", VA = "0x2D51508")]
	[Token(Token = "0x60006FA")]
	public void method_48(Vector3 vector3_1)
	{
	}

	// Token: 0x060006FB RID: 1787 RVA: 0x00011694 File Offset: 0x0000F894
	[Address(RVA = "0x2D515F0", Offset = "0x2D515F0", VA = "0x2D515F0")]
	[Token(Token = "0x60006FB")]
	public void method_49(Vector3 vector3_1)
	{
	}

	// Token: 0x060006FC RID: 1788 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Token(Token = "0x60006FC")]
	[Address(RVA = "0x2D51724", Offset = "0x2D51724", VA = "0x2D51724")]
	public void method_50(Vector3 vector3_1)
	{
	}

	// Token: 0x060006FD RID: 1789 RVA: 0x0001153C File Offset: 0x0000F73C
	[Token(Token = "0x60006FD")]
	[Address(RVA = "0x2D51834", Offset = "0x2D51834", VA = "0x2D51834")]
	public void method_51(Vector3 vector3_1)
	{
	}

	// Token: 0x060006FE RID: 1790 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Token(Token = "0x60006FE")]
	[Address(RVA = "0x2D51964", Offset = "0x2D51964", VA = "0x2D51964")]
	public void method_52(Vector3 vector3_1)
	{
	}

	// Token: 0x060006FF RID: 1791 RVA: 0x000116FC File Offset: 0x0000F8FC
	[Token(Token = "0x60006FF")]
	[Address(RVA = "0x2D51A74", Offset = "0x2D51A74", VA = "0x2D51A74")]
	private void method_53()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("Players: ", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture("Tagged", value2);
			material.name = "A Player has left the Room.";
			return;
		}
	}

	// Token: 0x06000700 RID: 1792 RVA: 0x00011754 File Offset: 0x0000F954
	[Address(RVA = "0x2D51C0C", Offset = "0x2D51C0C", VA = "0x2D51C0C")]
	[Token(Token = "0x6000700")]
	private void method_54()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("User has been reported for: ", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture("username", value2);
			material.name = "Agreed";
			return;
		}
	}

	// Token: 0x06000701 RID: 1793 RVA: 0x00011660 File Offset: 0x0000F860
	[Address(RVA = "0x2D51DB8", Offset = "0x2D51DB8", VA = "0x2D51DB8")]
	[Token(Token = "0x6000701")]
	public void method_55(Vector3 vector3_1)
	{
	}

	// Token: 0x06000702 RID: 1794 RVA: 0x000117AC File Offset: 0x0000F9AC
	[Address(RVA = "0x2D51EA0", Offset = "0x2D51EA0", VA = "0x2D51EA0")]
	[Token(Token = "0x6000702")]
	private void method_56()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("Player", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture("TurnAmount", value2);
			return;
		}
	}

	// Token: 0x06000703 RID: 1795 RVA: 0x000117FC File Offset: 0x0000F9FC
	[Address(RVA = "0x2D5204C", Offset = "0x2D5204C", VA = "0x2D5204C")]
	[Token(Token = "0x6000703")]
	private void method_57()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.shader_0);
		Texture2D value = this.texture2D_0;
		material.SetTexture("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.", value);
		Texture2D value2 = this.texture2D_1;
		material.SetTexture("MetaAuth", value2);
		if (this.skinnedMeshRenderer_0 == null)
		{
			return;
		}
		material.name = "Failed To Join Public Room Successfully. The error is: ";
	}

	// Token: 0x06000704 RID: 1796 RVA: 0x00011660 File Offset: 0x0000F860
	[Address(RVA = "0x2D521D0", Offset = "0x2D521D0", VA = "0x2D521D0")]
	[Token(Token = "0x6000704")]
	public void method_58(Vector3 vector3_1)
	{
	}

	// Token: 0x06000705 RID: 1797 RVA: 0x00011860 File Offset: 0x0000FA60
	[Token(Token = "0x6000705")]
	[Address(RVA = "0x2D522B8", Offset = "0x2D522B8", VA = "0x2D522B8")]
	public void method_59(Vector3 vector3_1)
	{
	}

	// Token: 0x06000706 RID: 1798 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Token(Token = "0x6000706")]
	[Address(RVA = "0x2D523EC", Offset = "0x2D523EC", VA = "0x2D523EC")]
	public void method_60(Vector3 vector3_1)
	{
	}

	// Token: 0x06000707 RID: 1799 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Token(Token = "0x6000707")]
	[Address(RVA = "0x2D524FC", Offset = "0x2D524FC", VA = "0x2D524FC")]
	public void method_61(Vector3 vector3_1)
	{
	}

	// Token: 0x06000708 RID: 1800 RVA: 0x00011870 File Offset: 0x0000FA70
	[Address(RVA = "0x2D5262C", Offset = "0x2D5262C", VA = "0x2D5262C")]
	[Token(Token = "0x6000708")]
	private void method_62()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.shader_0);
		Texture2D value = this.texture2D_0;
		material.SetTexture("Left a room", value);
		Texture2D value2 = this.texture2D_1;
		material.SetTexture("HDRP/Lit", value2);
		if (this.skinnedMeshRenderer_0 == null)
		{
			return;
		}
		material.name = "true";
	}

	// Token: 0x06000709 RID: 1801 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Token(Token = "0x6000709")]
	[Address(RVA = "0x2D527B0", Offset = "0x2D527B0", VA = "0x2D527B0")]
	public void method_63(Vector3 vector3_1)
	{
	}

	// Token: 0x0600070A RID: 1802 RVA: 0x000118D4 File Offset: 0x0000FAD4
	[Token(Token = "0x600070A")]
	[Address(RVA = "0x2D528E4", Offset = "0x2D528E4", VA = "0x2D528E4")]
	private void method_64()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("FingerTip", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture("isLava", value2);
			material.name = "liftoff failed!";
			return;
		}
	}

	// Token: 0x0600070B RID: 1803 RVA: 0x0001192C File Offset: 0x0000FB2C
	[Token(Token = "0x600070B")]
	[Address(RVA = "0x2D52A90", Offset = "0x2D52A90", VA = "0x2D52A90")]
	private void method_65()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("Display Name Changed!", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture(" and the correct version is ", value2);
			material.name = "ChangePlayerSize";
			return;
		}
	}

	// Token: 0x0600070C RID: 1804 RVA: 0x00011984 File Offset: 0x0000FB84
	[Token(Token = "0x600070C")]
	[Address(RVA = "0x2D52C3C", Offset = "0x2D52C3C", VA = "0x2D52C3C")]
	private void method_66()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Material material = new Material(this.shader_0);
		Texture2D value = this.texture2D_0;
		material.SetTexture("RightHandAttachPoint", value);
		Texture2D value2 = this.texture2D_1;
		material.SetTexture("HorrorAgreement", value2);
		if (this.skinnedMeshRenderer_0 == null)
		{
			return;
		}
		material.name = "Try Connect To Server...";
	}

	// Token: 0x0600070D RID: 1805 RVA: 0x000119E8 File Offset: 0x0000FBE8
	[Token(Token = "0x600070D")]
	[Address(RVA = "0x2D52DC0", Offset = "0x2D52DC0", VA = "0x2D52DC0")]
	private void Start()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Material material = new Material(this.shader_0);
			Texture2D value = this.texture2D_0;
			material.SetTexture("_BaseMap", value);
			Texture2D value2 = this.texture2D_1;
			material.SetTexture("_BumpMap", value2);
			material.name = "trol";
			return;
		}
	}

	// Token: 0x0600070E RID: 1806 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Address(RVA = "0x2D52F68", Offset = "0x2D52F68", VA = "0x2D52F68")]
	[Token(Token = "0x600070E")]
	public void method_67(Vector3 vector3_1)
	{
	}

	// Token: 0x0600070F RID: 1807 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Token(Token = "0x600070F")]
	[Address(RVA = "0x2D53078", Offset = "0x2D53078", VA = "0x2D53078")]
	public void method_68(Vector3 vector3_1)
	{
	}

	// Token: 0x06000710 RID: 1808 RVA: 0x0001153C File Offset: 0x0000F73C
	[Token(Token = "0x6000710")]
	[Address(RVA = "0x2D531AC", Offset = "0x2D531AC", VA = "0x2D531AC")]
	public void method_69(Vector3 vector3_1)
	{
	}

	// Token: 0x06000711 RID: 1809 RVA: 0x00011660 File Offset: 0x0000F860
	[Address(RVA = "0x2D532E0", Offset = "0x2D532E0", VA = "0x2D532E0")]
	[Token(Token = "0x6000711")]
	public void method_70(Vector3 vector3_1)
	{
	}

	// Token: 0x06000712 RID: 1810 RVA: 0x0001153C File Offset: 0x0000F73C
	[Token(Token = "0x6000712")]
	[Address(RVA = "0x2D533C8", Offset = "0x2D533C8", VA = "0x2D533C8")]
	public void method_71(Vector3 vector3_1)
	{
	}

	// Token: 0x06000713 RID: 1811 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Address(RVA = "0x2D534F8", Offset = "0x2D534F8", VA = "0x2D534F8")]
	[Token(Token = "0x6000713")]
	public void method_72(Vector3 vector3_1)
	{
	}

	// Token: 0x06000714 RID: 1812 RVA: 0x00011660 File Offset: 0x0000F860
	[Token(Token = "0x6000714")]
	[Address(RVA = "0x2D53628", Offset = "0x2D53628", VA = "0x2D53628")]
	public void method_73(Vector3 vector3_1)
	{
	}

	// Token: 0x06000715 RID: 1813 RVA: 0x00011660 File Offset: 0x0000F860
	[Token(Token = "0x6000715")]
	[Address(RVA = "0x2D53710", Offset = "0x2D53710", VA = "0x2D53710")]
	public void method_74(Vector3 vector3_1)
	{
	}

	// Token: 0x06000716 RID: 1814 RVA: 0x000113BC File Offset: 0x0000F5BC
	[Address(RVA = "0x2D537F8", Offset = "0x2D537F8", VA = "0x2D537F8")]
	[Token(Token = "0x6000716")]
	public void method_75(Vector3 vector3_1)
	{
	}

	// Token: 0x06000717 RID: 1815 RVA: 0x000113AC File Offset: 0x0000F5AC
	[Address(RVA = "0x2D53928", Offset = "0x2D53928", VA = "0x2D53928")]
	[Token(Token = "0x6000717")]
	public void method_76(Vector3 vector3_1)
	{
	}

	// Token: 0x040000F8 RID: 248
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000F8")]
	public Texture2D texture2D_0;

	// Token: 0x040000F9 RID: 249
	[Token(Token = "0x40000F9")]
	[FieldOffset(Offset = "0x20")]
	public Texture2D texture2D_1;

	// Token: 0x040000FA RID: 250
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40000FA")]
	public Shader shader_0;

	// Token: 0x040000FB RID: 251
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40000FB")]
	public SkinnedMeshRenderer[] skinnedMeshRenderer_0;

	// Token: 0x040000FC RID: 252
	[Token(Token = "0x40000FC")]
	[FieldOffset(Offset = "0x38")]
	public PhotonView photonView_0;

	// Token: 0x040000FD RID: 253
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40000FD")]
	public Vector3 vector3_0;
}
