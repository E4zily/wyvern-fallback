﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Photon.Rooms
{
	// Token: 0x02000186 RID: 390
	[Token(Token = "0x2000186")]
	public class RoomListingMenu : MonoBehaviourPunCallbacks
	{
		// Token: 0x06003C45 RID: 15429 RVA: 0x00075D60 File Offset: 0x00073F60
		[Token(Token = "0x6003C45")]
		[Address(RVA = "0x2E12D04", Offset = "0x2E12D04", VA = "0x2E12D04")]
		private void Start()
		{
			RoomListingMenu.Instance = this;
		}

		// Token: 0x06003C46 RID: 15430 RVA: 0x00075D74 File Offset: 0x00073F74
		[Token(Token = "0x6003C46")]
		[Address(RVA = "0x2E12DCC", Offset = "0x2E12DCC", VA = "0x2E12DCC")]
		private void FixedUpdate()
		{
			long num = 1L;
			if (num != 0L)
			{
			}
			bool isConnected = PhotonNetwork.IsConnected;
			if (num != 0L)
			{
			}
			bool inLobby = PhotonNetwork.InLobby;
			long num2;
			if (!this.l)
			{
				GClass1.smethod_3("Joining Lobby.");
				PhotonNetwork.JoinLobby();
				GClass1.smethod_3("Joined Lobby.");
				num2 = 1L;
				this.l = (num2 != 0L);
			}
			if (num2 != 0L)
			{
			}
			bool inLobby2 = PhotonNetwork.InLobby;
			int pos = this.posCount;
			this.UpdateMenu(pos);
			TouchScreenKeyboard touchScreenKeyboard = this.overlayKeyboard;
			if (touchScreenKeyboard != null)
			{
				bool active = touchScreenKeyboard.active;
				string text = this.overlayKeyboard.text;
				this.inputText = text;
				Transform transform = base.transform;
				long index = 0L;
				transform.GetChild((int)index).gameObject.GetComponent<TMP_Text>();
				return;
			}
		}

		// Token: 0x06003C47 RID: 15431 RVA: 0x00075E28 File Offset: 0x00074028
		[Token(Token = "0x6003C47")]
		[Address(RVA = "0x2E13B38", Offset = "0x2E13B38", VA = "0x2E13B38", Slot = "40")]
		public override void OnRoomListUpdate(List<RoomInfo> roomList)
		{
			string str;
			Debug.Log("amount of rooms found: " + str);
			string str2;
			GClass1.smethod_3("Amount Of Rooms Found: " + str2);
			List.Enumerator enumerator;
			enumerator.MoveNext();
			Debug.Log("This Room No Longer Exists, Removing It...");
		}

		// Token: 0x06003C48 RID: 15432 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2E12F9C", Offset = "0x2E12F9C", VA = "0x2E12F9C")]
		[Token(Token = "0x6003C48")]
		private void UpdateMenu(int pos)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003C49 RID: 15433 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6003C49")]
		[Address(RVA = "0x2E13FF4", Offset = "0x2E13FF4", VA = "0x2E13FF4")]
		public void ButtonPress(RoomsListingButton button)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003C4A RID: 15434 RVA: 0x000037EB File Offset: 0x000019EB
		[Token(Token = "0x6003C4A")]
		[Address(RVA = "0x2E1447C", Offset = "0x2E1447C", VA = "0x2E1447C")]
		public RoomListingMenu()
		{
		}

		// Token: 0x04000A9D RID: 2717
		[Token(Token = "0x4000A9D")]
		public static RoomListingMenu Instance;

		// Token: 0x04000A9E RID: 2718
		[Token(Token = "0x4000A9E")]
		[FieldOffset(Offset = "0x20")]
		public List<RoomListingMenu.Room> rooms;

		// Token: 0x04000A9F RID: 2719
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000A9F")]
		public TMP_Text infoText1;

		// Token: 0x04000AA0 RID: 2720
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000AA0")]
		public TMP_Text infoText2;

		// Token: 0x04000AA1 RID: 2721
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000AA1")]
		public TMP_Text infoText3;

		// Token: 0x04000AA2 RID: 2722
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000AA2")]
		public Image modicon1;

		// Token: 0x04000AA3 RID: 2723
		[Token(Token = "0x4000AA3")]
		[FieldOffset(Offset = "0x48")]
		public Image modicon2;

		// Token: 0x04000AA4 RID: 2724
		[Token(Token = "0x4000AA4")]
		[FieldOffset(Offset = "0x50")]
		public Image modicon3;

		// Token: 0x04000AA5 RID: 2725
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000AA5")]
		public Image backing1;

		// Token: 0x04000AA6 RID: 2726
		[Token(Token = "0x4000AA6")]
		[FieldOffset(Offset = "0x60")]
		public Image backing2;

		// Token: 0x04000AA7 RID: 2727
		[Token(Token = "0x4000AA7")]
		[FieldOffset(Offset = "0x68")]
		public Image backing3;

		// Token: 0x04000AA8 RID: 2728
		[Token(Token = "0x4000AA8")]
		[FieldOffset(Offset = "0x70")]
		public Sprite lava;

		// Token: 0x04000AA9 RID: 2729
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x4000AA9")]
		public Sprite cheese;

		// Token: 0x04000AAA RID: 2730
		[Token(Token = "0x4000AAA")]
		[FieldOffset(Offset = "0x80")]
		public Sprite norm;

		// Token: 0x04000AAB RID: 2731
		[FieldOffset(Offset = "0x88")]
		[Token(Token = "0x4000AAB")]
		public GameObject[] scriptApplys;

		// Token: 0x04000AAC RID: 2732
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000AAC")]
		private int posCount;

		// Token: 0x04000AAD RID: 2733
		[FieldOffset(Offset = "0x94")]
		[Token(Token = "0x4000AAD")]
		private bool l;

		// Token: 0x04000AAE RID: 2734
		[Token(Token = "0x4000AAE")]
		[FieldOffset(Offset = "0x98")]
		private TouchScreenKeyboard overlayKeyboard;

		// Token: 0x04000AAF RID: 2735
		[Token(Token = "0x4000AAF")]
		[FieldOffset(Offset = "0xA0")]
		private string inputText = "";

		// Token: 0x04000AB0 RID: 2736
		[Token(Token = "0x4000AB0")]
		[FieldOffset(Offset = "0xA8")]
		private RoomsListingButton tempButton;

		// Token: 0x02000187 RID: 391
		[Token(Token = "0x2000187")]
		[Serializable]
		public struct Room
		{
			// Token: 0x04000AB1 RID: 2737
			[Token(Token = "0x4000AB1")]
			[FieldOffset(Offset = "0x0")]
			public string RoomName;

			// Token: 0x04000AB2 RID: 2738
			[Token(Token = "0x4000AB2")]
			[FieldOffset(Offset = "0x8")]
			public int playerCount;

			// Token: 0x04000AB3 RID: 2739
			[Token(Token = "0x4000AB3")]
			[FieldOffset(Offset = "0xC")]
			public bool inLava;

			// Token: 0x04000AB4 RID: 2740
			[FieldOffset(Offset = "0xD")]
			[Token(Token = "0x4000AB4")]
			public bool isJoinable;

			// Token: 0x04000AB5 RID: 2741
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000AB5")]
			public int maxPlayers;

			// Token: 0x04000AB6 RID: 2742
			[FieldOffset(Offset = "0x14")]
			[Token(Token = "0x4000AB6")]
			public bool hasStaff;

			// Token: 0x04000AB7 RID: 2743
			[Token(Token = "0x4000AB7")]
			[FieldOffset(Offset = "0x18")]
			public string currentQueue;
		}
	}
}
