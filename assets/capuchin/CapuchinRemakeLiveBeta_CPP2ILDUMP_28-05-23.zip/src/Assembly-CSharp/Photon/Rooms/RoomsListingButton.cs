﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Photon.Rooms
{
	// Token: 0x02000188 RID: 392
	[Token(Token = "0x2000188")]
	public class RoomsListingButton : MonoBehaviour
	{
		// Token: 0x06003C4B RID: 15435 RVA: 0x00075E68 File Offset: 0x00074068
		[Token(Token = "0x6003C4B")]
		[Address(RVA = "0x2E144D8", Offset = "0x2E144D8", VA = "0x2E144D8")]
		private void Start()
		{
			string name = base.gameObject.name;
			this.function = name;
		}

		// Token: 0x06003C4C RID: 15436 RVA: 0x000037FE File Offset: 0x000019FE
		[Token(Token = "0x6003C4C")]
		[Address(RVA = "0x2E14518", Offset = "0x2E14518", VA = "0x2E14518")]
		private void Update()
		{
			if (this.press)
			{
				RoomListingMenu.Instance.ButtonPress(this);
				return;
			}
		}

		// Token: 0x06003C4D RID: 15437 RVA: 0x00075E88 File Offset: 0x00074088
		[Address(RVA = "0x2E1458C", Offset = "0x2E1458C", VA = "0x2E1458C")]
		[Token(Token = "0x6003C4D")]
		private void OnTriggerEnter(Collider other)
		{
			other.GetComponent<HandColliders>();
			RoomListingMenu.Instance.ButtonPress(this);
		}

		// Token: 0x06003C4E RID: 15438 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x2E1466C", Offset = "0x2E1466C", VA = "0x2E1466C")]
		[Token(Token = "0x6003C4E")]
		public RoomsListingButton()
		{
		}

		// Token: 0x04000AB8 RID: 2744
		[Token(Token = "0x4000AB8")]
		[FieldOffset(Offset = "0x18")]
		public string function;

		// Token: 0x04000AB9 RID: 2745
		[Token(Token = "0x4000AB9")]
		[FieldOffset(Offset = "0x20")]
		public bool press;
	}
}
