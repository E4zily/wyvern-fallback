﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E1 RID: 225
[Token(Token = "0x20000E1")]
public class OneGunCheck : MonoBehaviour
{
	// Token: 0x0600216F RID: 8559 RVA: 0x0003E2EC File Offset: 0x0003C4EC
	[Address(RVA = "0x3457A5C", Offset = "0x3457A5C", VA = "0x3457A5C")]
	[Token(Token = "0x600216F")]
	public void method_0()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002170 RID: 8560 RVA: 0x0003E338 File Offset: 0x0003C538
	[Address(RVA = "0x3457AD4", Offset = "0x3457AD4", VA = "0x3457AD4")]
	[Token(Token = "0x6002170")]
	public void method_1()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002171 RID: 8561 RVA: 0x0003E384 File Offset: 0x0003C584
	[Address(RVA = "0x3457B4C", Offset = "0x3457B4C", VA = "0x3457B4C")]
	[Token(Token = "0x6002171")]
	public void method_2()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = gameObject.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002172 RID: 8562 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x3457BC4", Offset = "0x3457BC4", VA = "0x3457BC4")]
	[Token(Token = "0x6002172")]
	public void method_3()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002173 RID: 8563 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3457C3C", Offset = "0x3457C3C", VA = "0x3457C3C")]
	[Token(Token = "0x6002173")]
	public OneGunCheck()
	{
	}

	// Token: 0x06002174 RID: 8564 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x3457C44", Offset = "0x3457C44", VA = "0x3457C44")]
	[Token(Token = "0x6002174")]
	public void method_4()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002175 RID: 8565 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x3457CBC", Offset = "0x3457CBC", VA = "0x3457CBC")]
	[Token(Token = "0x6002175")]
	public void method_5()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002176 RID: 8566 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x3457D34", Offset = "0x3457D34", VA = "0x3457D34")]
	[Token(Token = "0x6002176")]
	public void method_6()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002177 RID: 8567 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x3457DAC", Offset = "0x3457DAC", VA = "0x3457DAC")]
	[Token(Token = "0x6002177")]
	public void method_7()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002178 RID: 8568 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x3457E24", Offset = "0x3457E24", VA = "0x3457E24")]
	[Token(Token = "0x6002178")]
	public void method_8()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002179 RID: 8569 RVA: 0x0003E2EC File Offset: 0x0003C4EC
	[Address(RVA = "0x3457E9C", Offset = "0x3457E9C", VA = "0x3457E9C")]
	[Token(Token = "0x6002179")]
	public void method_9()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600217A RID: 8570 RVA: 0x0003E338 File Offset: 0x0003C538
	[Address(RVA = "0x3457F14", Offset = "0x3457F14", VA = "0x3457F14")]
	[Token(Token = "0x600217A")]
	public void method_10()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600217B RID: 8571 RVA: 0x0003E338 File Offset: 0x0003C538
	[Address(RVA = "0x3457F8C", Offset = "0x3457F8C", VA = "0x3457F8C")]
	[Token(Token = "0x600217B")]
	public void method_11()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600217C RID: 8572 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x3458004", Offset = "0x3458004", VA = "0x3458004")]
	[Token(Token = "0x600217C")]
	public void method_12()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600217D RID: 8573 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x345807C", Offset = "0x345807C", VA = "0x345807C")]
	[Token(Token = "0x600217D")]
	public void method_13()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600217E RID: 8574 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x34580F4", Offset = "0x34580F4", VA = "0x34580F4")]
	[Token(Token = "0x600217E")]
	public void method_14()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600217F RID: 8575 RVA: 0x0003E2EC File Offset: 0x0003C4EC
	[Address(RVA = "0x345816C", Offset = "0x345816C", VA = "0x345816C")]
	[Token(Token = "0x600217F")]
	public void method_15()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002180 RID: 8576 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x34581E4", Offset = "0x34581E4", VA = "0x34581E4")]
	[Token(Token = "0x6002180")]
	public void method_16()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002181 RID: 8577 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x345825C", Offset = "0x345825C", VA = "0x345825C")]
	[Token(Token = "0x6002181")]
	public void method_17()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002182 RID: 8578 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x34582D4", Offset = "0x34582D4", VA = "0x34582D4")]
	[Token(Token = "0x6002182")]
	public void method_18()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002183 RID: 8579 RVA: 0x0003E2EC File Offset: 0x0003C4EC
	[Address(RVA = "0x345834C", Offset = "0x345834C", VA = "0x345834C")]
	[Token(Token = "0x6002183")]
	public void method_19()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002184 RID: 8580 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x34583C4", Offset = "0x34583C4", VA = "0x34583C4")]
	[Token(Token = "0x6002184")]
	public void method_20()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002185 RID: 8581 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x345843C", Offset = "0x345843C", VA = "0x345843C")]
	[Token(Token = "0x6002185")]
	public void method_21()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002186 RID: 8582 RVA: 0x0003E338 File Offset: 0x0003C538
	[Address(RVA = "0x34584B4", Offset = "0x34584B4", VA = "0x34584B4")]
	[Token(Token = "0x6002186")]
	public void method_22()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002187 RID: 8583 RVA: 0x0003E2EC File Offset: 0x0003C4EC
	[Address(RVA = "0x345852C", Offset = "0x345852C", VA = "0x345852C")]
	[Token(Token = "0x6002187")]
	public void method_23()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002188 RID: 8584 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x34585A4", Offset = "0x34585A4", VA = "0x34585A4")]
	[Token(Token = "0x6002188")]
	public void method_24()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002189 RID: 8585 RVA: 0x0003E2EC File Offset: 0x0003C4EC
	[Address(RVA = "0x345861C", Offset = "0x345861C", VA = "0x345861C")]
	[Token(Token = "0x6002189")]
	public void method_25()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600218A RID: 8586 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x3458694", Offset = "0x3458694", VA = "0x3458694")]
	[Token(Token = "0x600218A")]
	public void method_26()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600218B RID: 8587 RVA: 0x0003E2EC File Offset: 0x0003C4EC
	[Address(RVA = "0x345870C", Offset = "0x345870C", VA = "0x345870C")]
	[Token(Token = "0x600218B")]
	public void method_27()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600218C RID: 8588 RVA: 0x0003E338 File Offset: 0x0003C538
	[Address(RVA = "0x3458784", Offset = "0x3458784", VA = "0x3458784")]
	[Token(Token = "0x600218C")]
	public void method_28()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600218D RID: 8589 RVA: 0x0003E460 File Offset: 0x0003C660
	[Address(RVA = "0x34587FC", Offset = "0x34587FC", VA = "0x34587FC")]
	[Token(Token = "0x600218D")]
	public void method_29()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600218E RID: 8590 RVA: 0x0003E2EC File Offset: 0x0003C4EC
	[Address(RVA = "0x3458874", Offset = "0x3458874", VA = "0x3458874")]
	[Token(Token = "0x600218E")]
	public void FixedUpdate()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600218F RID: 8591 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x34588EC", Offset = "0x34588EC", VA = "0x34588EC")]
	[Token(Token = "0x600218F")]
	public void method_30()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002190 RID: 8592 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x3458964", Offset = "0x3458964", VA = "0x3458964")]
	[Token(Token = "0x6002190")]
	public void method_31()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002191 RID: 8593 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x34589DC", Offset = "0x34589DC", VA = "0x34589DC")]
	[Token(Token = "0x6002191")]
	public void method_32()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002192 RID: 8594 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x3458A54", Offset = "0x3458A54", VA = "0x3458A54")]
	[Token(Token = "0x6002192")]
	public void method_33()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002193 RID: 8595 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x3458ACC", Offset = "0x3458ACC", VA = "0x3458ACC")]
	[Token(Token = "0x6002193")]
	public void method_34()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002194 RID: 8596 RVA: 0x0003E4A0 File Offset: 0x0003C6A0
	[Address(RVA = "0x3458B44", Offset = "0x3458B44", VA = "0x3458B44")]
	[Token(Token = "0x6002194")]
	public void method_35()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		bool activeSelf2 = gameObject2.activeSelf;
		this.gameObject_0.SetActive(active2 != 0L);
	}

	// Token: 0x06002195 RID: 8597 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x3458BBC", Offset = "0x3458BBC", VA = "0x3458BBC")]
	[Token(Token = "0x6002195")]
	public void method_36()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002196 RID: 8598 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x3458C34", Offset = "0x3458C34", VA = "0x3458C34")]
	[Token(Token = "0x6002196")]
	public void method_37()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002197 RID: 8599 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x3458CAC", Offset = "0x3458CAC", VA = "0x3458CAC")]
	[Token(Token = "0x6002197")]
	public void method_38()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002198 RID: 8600 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x3458D24", Offset = "0x3458D24", VA = "0x3458D24")]
	[Token(Token = "0x6002198")]
	public void method_39()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002199 RID: 8601 RVA: 0x0003E414 File Offset: 0x0003C614
	[Address(RVA = "0x3458D9C", Offset = "0x3458D9C", VA = "0x3458D9C")]
	[Token(Token = "0x6002199")]
	public void method_40()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600219A RID: 8602 RVA: 0x0003E3C8 File Offset: 0x0003C5C8
	[Address(RVA = "0x3458E14", Offset = "0x3458E14", VA = "0x3458E14")]
	[Token(Token = "0x600219A")]
	public void method_41()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600219B RID: 8603 RVA: 0x0003E338 File Offset: 0x0003C538
	[Address(RVA = "0x3458E8C", Offset = "0x3458E8C", VA = "0x3458E8C")]
	[Token(Token = "0x600219B")]
	public void method_42()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600219C RID: 8604 RVA: 0x0003E2EC File Offset: 0x0003C4EC
	[Address(RVA = "0x3458F04", Offset = "0x3458F04", VA = "0x3458F04")]
	[Token(Token = "0x600219C")]
	public void method_43()
	{
		bool activeSelf = this.gameObject_0.activeSelf;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf2 = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600219D RID: 8605 RVA: 0x0003E4E8 File Offset: 0x0003C6E8
	[Address(RVA = "0x3458F7C", Offset = "0x3458F7C", VA = "0x3458F7C")]
	[Token(Token = "0x600219D")]
	public void method_44()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		bool activeSelf = this.gameObject_1.activeSelf;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x04000470 RID: 1136
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000470")]
	public GameObject gameObject_0;

	// Token: 0x04000471 RID: 1137
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000471")]
	public GameObject gameObject_1;
}
