﻿using System;
using Cpp2IlInjected;
using HexabodyVR.PlayerController;
using UnityEngine;

// Token: 0x020000A0 RID: 160
[Token(Token = "0x20000A0")]
public class HexaResetZone : MonoBehaviour
{
	// Token: 0x06001793 RID: 6035 RVA: 0x000301F4 File Offset: 0x0002E3F4
	[Address(RVA = "0x337E624", Offset = "0x337E624", VA = "0x337E624")]
	[Token(Token = "0x6001793")]
	public void method_0()
	{
		if (this.bool_0)
		{
			HexaBodyPlayer4 exists = this.hexaBodyPlayer4_0;
			exists;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001794 RID: 6036 RVA: 0x000301F4 File Offset: 0x0002E3F4
	[Address(RVA = "0x337E6CC", Offset = "0x337E6CC", VA = "0x337E6CC")]
	[Token(Token = "0x6001794")]
	public void method_1()
	{
		if (this.bool_0)
		{
			HexaBodyPlayer4 exists = this.hexaBodyPlayer4_0;
			exists;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001795 RID: 6037 RVA: 0x00030230 File Offset: 0x0002E430
	[Address(RVA = "0x337E774", Offset = "0x337E774", VA = "0x337E774")]
	[Token(Token = "0x6001795")]
	public void FixedUpdate()
	{
		if (this.bool_0)
		{
			HexaBodyPlayer4 exists = this.hexaBodyPlayer4_0;
			exists;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
		}
	}

	// Token: 0x06001796 RID: 6038 RVA: 0x00030264 File Offset: 0x0002E464
	[Address(RVA = "0x337E818", Offset = "0x337E818", VA = "0x337E818")]
	[Token(Token = "0x6001796")]
	private void method_2(Collider collider_0)
	{
		if (!this.bool_0)
		{
			collider_0.gameObject.GetComponentInParent<HexaBodyPlayer4>();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001797 RID: 6039 RVA: 0x00030290 File Offset: 0x0002E490
	[Token(Token = "0x6001797")]
	[Address(RVA = "0x337E8EC", Offset = "0x337E8EC", VA = "0x337E8EC")]
	private void OnTriggerEnter(Collider collider_0)
	{
		if (!this.bool_0)
		{
			HexaBodyPlayer4 componentInParent = collider_0.gameObject.GetComponentInParent<HexaBodyPlayer4>();
			this.hexaBodyPlayer4_0 = componentInParent;
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001798 RID: 6040 RVA: 0x00030230 File Offset: 0x0002E430
	[Address(RVA = "0x337E9C0", Offset = "0x337E9C0", VA = "0x337E9C0")]
	[Token(Token = "0x6001798")]
	public void method_3()
	{
		if (this.bool_0)
		{
			HexaBodyPlayer4 exists = this.hexaBodyPlayer4_0;
			exists;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
		}
	}

	// Token: 0x06001799 RID: 6041 RVA: 0x000302C4 File Offset: 0x0002E4C4
	[Address(RVA = "0x337EA64", Offset = "0x337EA64", VA = "0x337EA64")]
	[Token(Token = "0x6001799")]
	private void method_4(Collider collider_0)
	{
		if (!this.bool_0)
		{
			HexaBodyPlayer4 componentInParent = collider_0.gameObject.GetComponentInParent<HexaBodyPlayer4>();
			this.hexaBodyPlayer4_0 = componentInParent;
		}
	}

	// Token: 0x0600179A RID: 6042 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x600179A")]
	[Address(RVA = "0x337EB34", Offset = "0x337EB34", VA = "0x337EB34")]
	public HexaResetZone()
	{
	}

	// Token: 0x0600179B RID: 6043 RVA: 0x000302EC File Offset: 0x0002E4EC
	[Address(RVA = "0x337EB3C", Offset = "0x337EB3C", VA = "0x337EB3C")]
	[Token(Token = "0x600179B")]
	public void method_5()
	{
		if (this.bool_0)
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
		}
	}

	// Token: 0x0600179C RID: 6044 RVA: 0x00030290 File Offset: 0x0002E490
	[Token(Token = "0x600179C")]
	[Address(RVA = "0x337EBE0", Offset = "0x337EBE0", VA = "0x337EBE0")]
	private void method_6(Collider collider_0)
	{
		if (!this.bool_0)
		{
			HexaBodyPlayer4 componentInParent = collider_0.gameObject.GetComponentInParent<HexaBodyPlayer4>();
			this.hexaBodyPlayer4_0 = componentInParent;
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x0600179D RID: 6045 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600179D")]
	[Address(RVA = "0x337ECB4", Offset = "0x337ECB4", VA = "0x337ECB4")]
	private void method_7(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600179E RID: 6046 RVA: 0x000301F4 File Offset: 0x0002E3F4
	[Token(Token = "0x600179E")]
	[Address(RVA = "0x337ED88", Offset = "0x337ED88", VA = "0x337ED88")]
	public void method_8()
	{
		if (this.bool_0)
		{
			HexaBodyPlayer4 exists = this.hexaBodyPlayer4_0;
			exists;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x0600179F RID: 6047 RVA: 0x00030310 File Offset: 0x0002E510
	[Token(Token = "0x600179F")]
	[Address(RVA = "0x337EE30", Offset = "0x337EE30", VA = "0x337EE30")]
	public void method_9()
	{
		if (this.bool_0)
		{
			HexaBodyPlayer4 exists = this.hexaBodyPlayer4_0;
			exists;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			this.bool_0 = (typeof(UnityEngine.Object).TypeHandle != null);
		}
	}

	// Token: 0x04000309 RID: 777
	[Token(Token = "0x4000309")]
	[FieldOffset(Offset = "0x18")]
	public Transform transform_0;

	// Token: 0x0400030A RID: 778
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400030A")]
	public bool bool_0;

	// Token: 0x0400030B RID: 779
	[Token(Token = "0x400030B")]
	[FieldOffset(Offset = "0x28")]
	public HexaBodyPlayer4 hexaBodyPlayer4_0;
}
