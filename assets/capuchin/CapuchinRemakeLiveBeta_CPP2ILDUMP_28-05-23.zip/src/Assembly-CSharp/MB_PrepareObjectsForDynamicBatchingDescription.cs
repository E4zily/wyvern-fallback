﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000081 RID: 129
[Token(Token = "0x2000081")]
public class MB_PrepareObjectsForDynamicBatchingDescription : MonoBehaviour
{
	// Token: 0x0600126C RID: 4716 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600126C")]
	[Address(RVA = "0x2EF9540", Offset = "0x2EF9540", VA = "0x2EF9540")]
	private void method_0()
	{
	}

	// Token: 0x0600126D RID: 4717 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF9620", Offset = "0x2EF9620", VA = "0x2EF9620")]
	[Token(Token = "0x600126D")]
	private void method_1()
	{
	}

	// Token: 0x0600126E RID: 4718 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600126E")]
	[Address(RVA = "0x2EF9700", Offset = "0x2EF9700", VA = "0x2EF9700")]
	private void method_2()
	{
	}

	// Token: 0x0600126F RID: 4719 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF97E0", Offset = "0x2EF97E0", VA = "0x2EF97E0")]
	[Token(Token = "0x600126F")]
	private void method_3()
	{
	}

	// Token: 0x06001270 RID: 4720 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001270")]
	[Address(RVA = "0x2EF98C0", Offset = "0x2EF98C0", VA = "0x2EF98C0")]
	private void method_4()
	{
	}

	// Token: 0x06001271 RID: 4721 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF99A0", Offset = "0x2EF99A0", VA = "0x2EF99A0")]
	[Token(Token = "0x6001271")]
	private void method_5()
	{
	}

	// Token: 0x06001272 RID: 4722 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001272")]
	[Address(RVA = "0x2EF9A80", Offset = "0x2EF9A80", VA = "0x2EF9A80")]
	private void method_6()
	{
	}

	// Token: 0x06001273 RID: 4723 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001273")]
	[Address(RVA = "0x2EF9B60", Offset = "0x2EF9B60", VA = "0x2EF9B60")]
	private void method_7()
	{
	}

	// Token: 0x06001274 RID: 4724 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001274")]
	[Address(RVA = "0x2EF9C40", Offset = "0x2EF9C40", VA = "0x2EF9C40")]
	private void method_8()
	{
	}

	// Token: 0x06001275 RID: 4725 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF9D20", Offset = "0x2EF9D20", VA = "0x2EF9D20")]
	[Token(Token = "0x6001275")]
	private void method_9()
	{
	}

	// Token: 0x06001276 RID: 4726 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF9E00", Offset = "0x2EF9E00", VA = "0x2EF9E00")]
	[Token(Token = "0x6001276")]
	private void method_10()
	{
	}

	// Token: 0x06001277 RID: 4727 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001277")]
	[Address(RVA = "0x2EF9EE0", Offset = "0x2EF9EE0", VA = "0x2EF9EE0")]
	private void method_11()
	{
	}

	// Token: 0x06001278 RID: 4728 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF9FC0", Offset = "0x2EF9FC0", VA = "0x2EF9FC0")]
	[Token(Token = "0x6001278")]
	private void method_12()
	{
	}

	// Token: 0x06001279 RID: 4729 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001279")]
	[Address(RVA = "0x2EFA0A0", Offset = "0x2EFA0A0", VA = "0x2EFA0A0")]
	private void method_13()
	{
	}

	// Token: 0x0600127A RID: 4730 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600127A")]
	[Address(RVA = "0x2EFA180", Offset = "0x2EFA180", VA = "0x2EFA180")]
	private void method_14()
	{
	}

	// Token: 0x0600127B RID: 4731 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600127B")]
	[Address(RVA = "0x2EFA260", Offset = "0x2EFA260", VA = "0x2EFA260")]
	private void method_15()
	{
	}

	// Token: 0x0600127C RID: 4732 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EFA340", Offset = "0x2EFA340", VA = "0x2EFA340")]
	[Token(Token = "0x600127C")]
	private void OnGUI()
	{
	}

	// Token: 0x0600127D RID: 4733 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2EFA420", Offset = "0x2EFA420", VA = "0x2EFA420")]
	[Token(Token = "0x600127D")]
	public MB_PrepareObjectsForDynamicBatchingDescription()
	{
	}

	// Token: 0x0600127E RID: 4734 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600127E")]
	[Address(RVA = "0x2EFA428", Offset = "0x2EFA428", VA = "0x2EFA428")]
	private void method_16()
	{
	}

	// Token: 0x0600127F RID: 4735 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EFA508", Offset = "0x2EFA508", VA = "0x2EFA508")]
	[Token(Token = "0x600127F")]
	private void method_17()
	{
	}

	// Token: 0x06001280 RID: 4736 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001280")]
	[Address(RVA = "0x2EFA5E8", Offset = "0x2EFA5E8", VA = "0x2EFA5E8")]
	private void method_18()
	{
	}

	// Token: 0x06001281 RID: 4737 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001281")]
	[Address(RVA = "0x2EFA6C8", Offset = "0x2EFA6C8", VA = "0x2EFA6C8")]
	private void method_19()
	{
	}

	// Token: 0x06001282 RID: 4738 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EFA7A8", Offset = "0x2EFA7A8", VA = "0x2EFA7A8")]
	[Token(Token = "0x6001282")]
	private void method_20()
	{
	}
}
