﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x020000B8 RID: 184
[Token(Token = "0x20000B8")]
public class ComputerTextField : MonoBehaviour
{
	// Token: 0x06001A44 RID: 6724 RVA: 0x000340DC File Offset: 0x000322DC
	[Address(RVA = "0x2A668A0", Offset = "0x2A668A0", VA = "0x2A668A0")]
	[Token(Token = "0x6001A44")]
	private void method_0()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("NetworkPlayer");
			return;
		}
	}

	// Token: 0x06001A45 RID: 6725 RVA: 0x00034104 File Offset: 0x00032304
	[Address(RVA = "0x2A66948", Offset = "0x2A66948", VA = "0x2A66948")]
	[Token(Token = "0x6001A45")]
	private void method_1()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("closeToObject");
			return;
		}
	}

	// Token: 0x06001A46 RID: 6726 RVA: 0x0003412C File Offset: 0x0003232C
	[Address(RVA = "0x2A669F0", Offset = "0x2A669F0", VA = "0x2A669F0")]
	[Token(Token = "0x6001A46")]
	private void method_2()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("FingerTip");
			return;
		}
	}

	// Token: 0x06001A47 RID: 6727 RVA: 0x00034154 File Offset: 0x00032354
	[Address(RVA = "0x2A66A98", Offset = "0x2A66A98", VA = "0x2A66A98")]
	[Token(Token = "0x6001A47")]
	private void method_3()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("ChangeToTagged");
			return;
		}
	}

	// Token: 0x06001A48 RID: 6728 RVA: 0x0003417C File Offset: 0x0003237C
	[Address(RVA = "0x2A66B40", Offset = "0x2A66B40", VA = "0x2A66B40")]
	[Token(Token = "0x6001A48")]
	private void method_4()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("down unstuck");
			return;
		}
	}

	// Token: 0x06001A49 RID: 6729 RVA: 0x000341A4 File Offset: 0x000323A4
	[Address(RVA = "0x2A66BE8", Offset = "0x2A66BE8", VA = "0x2A66BE8")]
	[Token(Token = "0x6001A49")]
	private void method_5()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("isLava");
			return;
		}
	}

	// Token: 0x06001A4A RID: 6730 RVA: 0x000341CC File Offset: 0x000323CC
	[Address(RVA = "0x2A66C90", Offset = "0x2A66C90", VA = "0x2A66C90")]
	[Token(Token = "0x6001A4A")]
	private void method_6()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("Player");
			return;
		}
	}

	// Token: 0x06001A4B RID: 6731 RVA: 0x000341F4 File Offset: 0x000323F4
	[Address(RVA = "0x2A66D38", Offset = "0x2A66D38", VA = "0x2A66D38")]
	[Token(Token = "0x6001A4B")]
	private void method_7()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			return;
		}
	}

	// Token: 0x06001A4C RID: 6732 RVA: 0x00034214 File Offset: 0x00032414
	[Address(RVA = "0x2A66DE0", Offset = "0x2A66DE0", VA = "0x2A66DE0")]
	[Token(Token = "0x6001A4C")]
	private void method_8()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("cheese");
			return;
		}
	}

	// Token: 0x06001A4D RID: 6733 RVA: 0x0003423C File Offset: 0x0003243C
	[Address(RVA = "0x2A66E88", Offset = "0x2A66E88", VA = "0x2A66E88")]
	[Token(Token = "0x6001A4D")]
	private void method_9()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("goDownRPC");
			return;
		}
	}

	// Token: 0x06001A4E RID: 6734 RVA: 0x000341CC File Offset: 0x000323CC
	[Address(RVA = "0x2A66F30", Offset = "0x2A66F30", VA = "0x2A66F30")]
	[Token(Token = "0x6001A4E")]
	private void method_10()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("Player");
			return;
		}
	}

	// Token: 0x06001A4F RID: 6735 RVA: 0x00034264 File Offset: 0x00032464
	[Address(RVA = "0x2A66FD8", Offset = "0x2A66FD8", VA = "0x2A66FD8")]
	[Token(Token = "0x6001A4F")]
	private void method_11()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("ErrorScreen");
			return;
		}
	}

	// Token: 0x06001A50 RID: 6736 RVA: 0x0003412C File Offset: 0x0003232C
	[Address(RVA = "0x2A67080", Offset = "0x2A67080", VA = "0x2A67080")]
	[Token(Token = "0x6001A50")]
	private void method_12()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("FingerTip");
			return;
		}
	}

	// Token: 0x06001A51 RID: 6737 RVA: 0x0003428C File Offset: 0x0003248C
	[Address(RVA = "0x2A67128", Offset = "0x2A67128", VA = "0x2A67128")]
	[Token(Token = "0x6001A51")]
	private void method_13()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("character limit reached");
			return;
		}
	}

	// Token: 0x06001A52 RID: 6738 RVA: 0x000342B4 File Offset: 0x000324B4
	[Address(RVA = "0x2A671D0", Offset = "0x2A671D0", VA = "0x2A671D0")]
	[Token(Token = "0x6001A52")]
	private void method_14()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("On");
			return;
		}
	}

	// Token: 0x06001A53 RID: 6739 RVA: 0x000342DC File Offset: 0x000324DC
	[Address(RVA = "0x2A67278", Offset = "0x2A67278", VA = "0x2A67278")]
	[Token(Token = "0x6001A53")]
	private void method_15()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("Bruh i cannot go here you stupid L bozo");
			return;
		}
	}

	// Token: 0x06001A54 RID: 6740 RVA: 0x00034304 File Offset: 0x00032504
	[Address(RVA = "0x2A67320", Offset = "0x2A67320", VA = "0x2A67320")]
	[Token(Token = "0x6001A54")]
	private void method_16()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("MetaAuth");
			return;
		}
	}

	// Token: 0x06001A55 RID: 6741 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A673C8", Offset = "0x2A673C8", VA = "0x2A673C8")]
	[Token(Token = "0x6001A55")]
	public ComputerTextField()
	{
	}

	// Token: 0x06001A56 RID: 6742 RVA: 0x0003432C File Offset: 0x0003252C
	[Address(RVA = "0x2A673D0", Offset = "0x2A673D0", VA = "0x2A673D0")]
	[Token(Token = "0x6001A56")]
	private void method_17()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("You Look Like Butt");
			return;
		}
	}

	// Token: 0x06001A57 RID: 6743 RVA: 0x00034354 File Offset: 0x00032554
	[Address(RVA = "0x2A67478", Offset = "0x2A67478", VA = "0x2A67478")]
	[Token(Token = "0x6001A57")]
	private void method_18()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("A Player has left the Room.");
			return;
		}
	}

	// Token: 0x06001A58 RID: 6744 RVA: 0x0003437C File Offset: 0x0003257C
	[Address(RVA = "0x2A67520", Offset = "0x2A67520", VA = "0x2A67520")]
	[Token(Token = "0x6001A58")]
	private void method_19()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("isLava");
		}
	}

	// Token: 0x06001A59 RID: 6745 RVA: 0x000343A4 File Offset: 0x000325A4
	[Address(RVA = "0x2A675C8", Offset = "0x2A675C8", VA = "0x2A675C8")]
	[Token(Token = "0x6001A59")]
	private void method_20()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("Reason: ");
			return;
		}
	}

	// Token: 0x06001A5A RID: 6746 RVA: 0x000343CC File Offset: 0x000325CC
	[Address(RVA = "0x2A67670", Offset = "0x2A67670", VA = "0x2A67670")]
	[Token(Token = "0x6001A5A")]
	private void method_21()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("TurnAmount");
			return;
		}
	}

	// Token: 0x06001A5B RID: 6747 RVA: 0x000343F4 File Offset: 0x000325F4
	[Address(RVA = "0x2A67718", Offset = "0x2A67718", VA = "0x2A67718")]
	[Token(Token = "0x6001A5B")]
	private void method_22()
	{
		base.GetComponent<TextMeshPro>();
		PlayerPrefs.GetString("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
	}

	// Token: 0x06001A5C RID: 6748 RVA: 0x00034414 File Offset: 0x00032614
	[Address(RVA = "0x2A677C0", Offset = "0x2A677C0", VA = "0x2A677C0")]
	[Token(Token = "0x6001A5C")]
	private void method_23()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("liftoff failed!");
			return;
		}
	}

	// Token: 0x06001A5D RID: 6749 RVA: 0x000343A4 File Offset: 0x000325A4
	[Address(RVA = "0x2A67868", Offset = "0x2A67868", VA = "0x2A67868")]
	[Token(Token = "0x6001A5D")]
	private void method_24()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("Reason: ");
			return;
		}
	}

	// Token: 0x06001A5E RID: 6750 RVA: 0x000343CC File Offset: 0x000325CC
	[Address(RVA = "0x2A67910", Offset = "0x2A67910", VA = "0x2A67910")]
	[Token(Token = "0x6001A5E")]
	private void method_25()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("TurnAmount");
			return;
		}
	}

	// Token: 0x06001A5F RID: 6751 RVA: 0x0003443C File Offset: 0x0003263C
	[Address(RVA = "0x2A679B8", Offset = "0x2A679B8", VA = "0x2A679B8")]
	[Token(Token = "0x6001A5F")]
	private void method_26()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("\tExpires: ");
			return;
		}
	}

	// Token: 0x06001A60 RID: 6752 RVA: 0x00034304 File Offset: 0x00032504
	[Address(RVA = "0x2A67A60", Offset = "0x2A67A60", VA = "0x2A67A60")]
	[Token(Token = "0x6001A60")]
	private void method_27()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("MetaAuth");
			return;
		}
	}

	// Token: 0x06001A61 RID: 6753 RVA: 0x00034464 File Offset: 0x00032664
	[Address(RVA = "0x2A67B08", Offset = "0x2A67B08", VA = "0x2A67B08")]
	[Token(Token = "0x6001A61")]
	private void method_28()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("CapuchinStore");
			return;
		}
	}

	// Token: 0x06001A62 RID: 6754 RVA: 0x0003448C File Offset: 0x0003268C
	[Address(RVA = "0x2A67BB0", Offset = "0x2A67BB0", VA = "0x2A67BB0")]
	[Token(Token = "0x6001A62")]
	private void method_29()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("deathScream");
			return;
		}
	}

	// Token: 0x06001A63 RID: 6755 RVA: 0x000344B4 File Offset: 0x000326B4
	[Address(RVA = "0x2A67C58", Offset = "0x2A67C58", VA = "0x2A67C58")]
	[Token(Token = "0x6001A63")]
	private void method_30()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("Open");
			return;
		}
	}

	// Token: 0x06001A64 RID: 6756 RVA: 0x000344DC File Offset: 0x000326DC
	[Address(RVA = "0x2A67D00", Offset = "0x2A67D00", VA = "0x2A67D00")]
	[Token(Token = "0x6001A64")]
	private void Start()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("username");
			return;
		}
	}

	// Token: 0x06001A65 RID: 6757 RVA: 0x00034504 File Offset: 0x00032704
	[Address(RVA = "0x2A67DA8", Offset = "0x2A67DA8", VA = "0x2A67DA8")]
	[Token(Token = "0x6001A65")]
	private void method_31()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("You have been banned for ");
			return;
		}
	}

	// Token: 0x06001A66 RID: 6758 RVA: 0x000341CC File Offset: 0x000323CC
	[Address(RVA = "0x2A67E50", Offset = "0x2A67E50", VA = "0x2A67E50")]
	[Token(Token = "0x6001A66")]
	private void method_32()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("Player");
			return;
		}
	}

	// Token: 0x06001A67 RID: 6759 RVA: 0x0003452C File Offset: 0x0003272C
	[Address(RVA = "0x2A67EF8", Offset = "0x2A67EF8", VA = "0x2A67EF8")]
	[Token(Token = "0x6001A67")]
	private void method_33()
	{
		if (this.bool_0)
		{
			base.GetComponent<TextMeshPro>();
			PlayerPrefs.GetString("EnableCosmetic");
			return;
		}
	}

	// Token: 0x0400036C RID: 876
	[Token(Token = "0x400036C")]
	[FieldOffset(Offset = "0x18")]
	public bool bool_0;
}
