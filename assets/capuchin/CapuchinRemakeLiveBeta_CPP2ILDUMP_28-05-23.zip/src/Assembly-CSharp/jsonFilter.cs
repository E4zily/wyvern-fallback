﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;

// Token: 0x020000F4 RID: 244
[Token(Token = "0x20000F4")]
[Serializable]
public class jsonFilter
{
	// Token: 0x060024E4 RID: 9444 RVA: 0x000020B4 File Offset: 0x000002B4
	[Address(RVA = "0x34BBD14", Offset = "0x34BBD14", VA = "0x34BBD14")]
	[Token(Token = "0x60024E4")]
	public jsonFilter()
	{
	}

	// Token: 0x040004D0 RID: 1232
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40004D0")]
	public List<filteredNamels> filteredNames;
}
