﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x02000079 RID: 121
[Token(Token = "0x2000079")]
public class KeyboardPopUp : MonoBehaviour
{
	// Token: 0x0600110A RID: 4362 RVA: 0x000239CC File Offset: 0x00021BCC
	[Address(RVA = "0x3133180", Offset = "0x3133180", VA = "0x3133180")]
	[Token(Token = "0x600110A")]
	public void method_0(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600110B RID: 4363 RVA: 0x00023A20 File Offset: 0x00021C20
	[Token(Token = "0x600110B")]
	[Address(RVA = "0x313327C", Offset = "0x313327C", VA = "0x313327C")]
	public void method_1(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600110C RID: 4364 RVA: 0x00023A68 File Offset: 0x00021C68
	[Token(Token = "0x600110C")]
	[Address(RVA = "0x3133374", Offset = "0x3133374", VA = "0x3133374")]
	public void method_2()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("friend", value);
	}

	// Token: 0x0600110D RID: 4365 RVA: 0x00023A20 File Offset: 0x00021C20
	[Token(Token = "0x600110D")]
	[Address(RVA = "0x31333D0", Offset = "0x31333D0", VA = "0x31333D0")]
	public void method_3(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600110E RID: 4366 RVA: 0x000239CC File Offset: 0x00021BCC
	[Address(RVA = "0x31334C8", Offset = "0x31334C8", VA = "0x31334C8")]
	[Token(Token = "0x600110E")]
	public void method_4(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600110F RID: 4367 RVA: 0x00023A90 File Offset: 0x00021C90
	[Token(Token = "0x600110F")]
	[Address(RVA = "0x31335C4", Offset = "0x31335C4", VA = "0x31335C4")]
	public void method_5()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("username", value);
	}

	// Token: 0x06001110 RID: 4368 RVA: 0x00023AB8 File Offset: 0x00021CB8
	[Token(Token = "0x6001110")]
	[Address(RVA = "0x3133620", Offset = "0x3133620", VA = "0x3133620")]
	public void method_6()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("PlayerHead", value);
	}

	// Token: 0x06001111 RID: 4369 RVA: 0x00023AE0 File Offset: 0x00021CE0
	[Token(Token = "0x6001111")]
	[Address(RVA = "0x313367C", Offset = "0x313367C", VA = "0x313367C")]
	public void method_7()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("A new Player joined a Room.", value);
	}

	// Token: 0x06001112 RID: 4370 RVA: 0x00023B08 File Offset: 0x00021D08
	[Token(Token = "0x6001112")]
	[Address(RVA = "0x31336D8", Offset = "0x31336D8", VA = "0x31336D8")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001113 RID: 4371 RVA: 0x00023B5C File Offset: 0x00021D5C
	[Token(Token = "0x6001113")]
	[Address(RVA = "0x31337D4", Offset = "0x31337D4", VA = "0x31337D4")]
	public void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001114 RID: 4372 RVA: 0x00023BB0 File Offset: 0x00021DB0
	[Address(RVA = "0x31338D0", Offset = "0x31338D0", VA = "0x31338D0")]
	[Token(Token = "0x6001114")]
	public void method_9()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("Right Hand", value);
	}

	// Token: 0x06001115 RID: 4373 RVA: 0x00023BD8 File Offset: 0x00021DD8
	[Token(Token = "0x6001115")]
	[Address(RVA = "0x313392C", Offset = "0x313392C", VA = "0x313392C")]
	public void method_10(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001116 RID: 4374 RVA: 0x00023C20 File Offset: 0x00021E20
	[Address(RVA = "0x3133A24", Offset = "0x3133A24", VA = "0x3133A24")]
	[Token(Token = "0x6001116")]
	public void Update()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("Open", value);
	}

	// Token: 0x06001117 RID: 4375 RVA: 0x00023B08 File Offset: 0x00021D08
	[Token(Token = "0x6001117")]
	[Address(RVA = "0x3133A80", Offset = "0x3133A80", VA = "0x3133A80")]
	public void method_11(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001118 RID: 4376 RVA: 0x00023C48 File Offset: 0x00021E48
	[Token(Token = "0x6001118")]
	[Address(RVA = "0x3133B7C", Offset = "0x3133B7C", VA = "0x3133B7C")]
	public void method_12()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("HandL", value);
	}

	// Token: 0x06001119 RID: 4377 RVA: 0x00023B5C File Offset: 0x00021D5C
	[Token(Token = "0x6001119")]
	[Address(RVA = "0x3133BD8", Offset = "0x3133BD8", VA = "0x3133BD8")]
	public void method_13(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600111A RID: 4378 RVA: 0x00023BD8 File Offset: 0x00021DD8
	[Token(Token = "0x600111A")]
	[Address(RVA = "0x3133CD4", Offset = "0x3133CD4", VA = "0x3133CD4")]
	public void method_14(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600111B RID: 4379 RVA: 0x00023C70 File Offset: 0x00021E70
	[Address(RVA = "0x3133DCC", Offset = "0x3133DCC", VA = "0x3133DCC")]
	[Token(Token = "0x600111B")]
	public void method_15()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("run", value);
	}

	// Token: 0x0600111C RID: 4380 RVA: 0x00023A68 File Offset: 0x00021C68
	[Token(Token = "0x600111C")]
	[Address(RVA = "0x3133E28", Offset = "0x3133E28", VA = "0x3133E28")]
	public void method_16()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("friend", value);
	}

	// Token: 0x0600111D RID: 4381 RVA: 0x00023C98 File Offset: 0x00021E98
	[Address(RVA = "0x3133E84", Offset = "0x3133E84", VA = "0x3133E84")]
	[Token(Token = "0x600111D")]
	public void method_17()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("User is on an outdated version of Capuchin. Your version is ", value);
	}

	// Token: 0x0600111E RID: 4382 RVA: 0x000239CC File Offset: 0x00021BCC
	[Token(Token = "0x600111E")]
	[Address(RVA = "0x3133EE0", Offset = "0x3133EE0", VA = "0x3133EE0")]
	public void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600111F RID: 4383 RVA: 0x00023B5C File Offset: 0x00021D5C
	[Token(Token = "0x600111F")]
	[Address(RVA = "0x3133FDC", Offset = "0x3133FDC", VA = "0x3133FDC")]
	public void method_19(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001120 RID: 4384 RVA: 0x00023CC0 File Offset: 0x00021EC0
	[Token(Token = "0x6001120")]
	[Address(RVA = "0x31340D8", Offset = "0x31340D8", VA = "0x31340D8")]
	public void method_20()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("Failed to get catalog, cosmetic name, and price. Exact error details is: ", value);
	}

	// Token: 0x06001121 RID: 4385 RVA: 0x00023CE8 File Offset: 0x00021EE8
	[Token(Token = "0x6001121")]
	[Address(RVA = "0x3134134", Offset = "0x3134134", VA = "0x3134134")]
	public void method_21(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001122 RID: 4386 RVA: 0x00023BD8 File Offset: 0x00021DD8
	[Address(RVA = "0x3134230", Offset = "0x3134230", VA = "0x3134230")]
	[Token(Token = "0x6001122")]
	public void method_22(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001123 RID: 4387 RVA: 0x00023BD8 File Offset: 0x00021DD8
	[Token(Token = "0x6001123")]
	[Address(RVA = "0x3134328", Offset = "0x3134328", VA = "0x3134328")]
	public void method_23(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001124 RID: 4388 RVA: 0x00023AE0 File Offset: 0x00021CE0
	[Address(RVA = "0x3134420", Offset = "0x3134420", VA = "0x3134420")]
	[Token(Token = "0x6001124")]
	public void method_24()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("A new Player joined a Room.", value);
	}

	// Token: 0x06001125 RID: 4389 RVA: 0x00023D3C File Offset: 0x00021F3C
	[Token(Token = "0x6001125")]
	[Address(RVA = "0x313447C", Offset = "0x313447C", VA = "0x313447C")]
	public void method_25()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("BN", value);
	}

	// Token: 0x06001126 RID: 4390 RVA: 0x00023D64 File Offset: 0x00021F64
	[Address(RVA = "0x31344D8", Offset = "0x31344D8", VA = "0x31344D8")]
	[Token(Token = "0x6001126")]
	public void method_26()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("Adding ", value);
	}

	// Token: 0x06001127 RID: 4391 RVA: 0x00023A20 File Offset: 0x00021C20
	[Token(Token = "0x6001127")]
	[Address(RVA = "0x3134534", Offset = "0x3134534", VA = "0x3134534")]
	public void method_27(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001128 RID: 4392 RVA: 0x00023D8C File Offset: 0x00021F8C
	[Token(Token = "0x6001128")]
	[Address(RVA = "0x313462C", Offset = "0x313462C", VA = "0x313462C")]
	public void method_28(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001129 RID: 4393 RVA: 0x00023D8C File Offset: 0x00021F8C
	[Token(Token = "0x6001129")]
	[Address(RVA = "0x3134724", Offset = "0x3134724", VA = "0x3134724")]
	public void method_29(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600112A RID: 4394 RVA: 0x00023DD4 File Offset: 0x00021FD4
	[Address(RVA = "0x313481C", Offset = "0x313481C", VA = "0x313481C")]
	[Token(Token = "0x600112A")]
	public void method_30()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("FingerTip", value);
	}

	// Token: 0x0600112B RID: 4395 RVA: 0x00023CE8 File Offset: 0x00021EE8
	[Address(RVA = "0x3134878", Offset = "0x3134878", VA = "0x3134878")]
	[Token(Token = "0x600112B")]
	public void method_31(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600112C RID: 4396 RVA: 0x00023DFC File Offset: 0x00021FFC
	[Token(Token = "0x600112C")]
	[Address(RVA = "0x3134974", Offset = "0x3134974", VA = "0x3134974")]
	public void method_32()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("monkeScream", value);
	}

	// Token: 0x0600112D RID: 4397 RVA: 0x00023BD8 File Offset: 0x00021DD8
	[Token(Token = "0x600112D")]
	[Address(RVA = "0x31349D0", Offset = "0x31349D0", VA = "0x31349D0")]
	public void method_33(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600112E RID: 4398 RVA: 0x00023E24 File Offset: 0x00022024
	[Token(Token = "0x600112E")]
	[Address(RVA = "0x3134AC8", Offset = "0x3134AC8", VA = "0x3134AC8")]
	public void method_34()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("META", value);
	}

	// Token: 0x0600112F RID: 4399 RVA: 0x00023A90 File Offset: 0x00021C90
	[Token(Token = "0x600112F")]
	[Address(RVA = "0x3134B24", Offset = "0x3134B24", VA = "0x3134B24")]
	public void method_35()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("username", value);
	}

	// Token: 0x06001130 RID: 4400 RVA: 0x00023E4C File Offset: 0x0002204C
	[Address(RVA = "0x3134B80", Offset = "0x3134B80", VA = "0x3134B80")]
	[Token(Token = "0x6001130")]
	public void method_36()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("TurnAmount", value);
	}

	// Token: 0x06001131 RID: 4401 RVA: 0x00023E74 File Offset: 0x00022074
	[Token(Token = "0x6001131")]
	[Address(RVA = "0x3134BDC", Offset = "0x3134BDC", VA = "0x3134BDC")]
	public void method_37()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("/", value);
	}

	// Token: 0x06001132 RID: 4402 RVA: 0x00023A20 File Offset: 0x00021C20
	[Address(RVA = "0x3134C38", Offset = "0x3134C38", VA = "0x3134C38")]
	[Token(Token = "0x6001132")]
	public void method_38(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001133 RID: 4403 RVA: 0x00023D3C File Offset: 0x00021F3C
	[Token(Token = "0x6001133")]
	[Address(RVA = "0x3134D30", Offset = "0x3134D30", VA = "0x3134D30")]
	public void method_39()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("BN", value);
	}

	// Token: 0x06001134 RID: 4404 RVA: 0x00023B5C File Offset: 0x00021D5C
	[Address(RVA = "0x3134D8C", Offset = "0x3134D8C", VA = "0x3134D8C")]
	[Token(Token = "0x6001134")]
	public void method_40(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001135 RID: 4405 RVA: 0x00023A20 File Offset: 0x00021C20
	[Token(Token = "0x6001135")]
	[Address(RVA = "0x3134E88", Offset = "0x3134E88", VA = "0x3134E88")]
	public void method_41(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001136 RID: 4406 RVA: 0x00023E9C File Offset: 0x0002209C
	[Token(Token = "0x6001136")]
	[Address(RVA = "0x3134F80", Offset = "0x3134F80", VA = "0x3134F80")]
	public void method_42()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("BLUPORT", value);
	}

	// Token: 0x06001137 RID: 4407 RVA: 0x000239CC File Offset: 0x00021BCC
	[Token(Token = "0x6001137")]
	[Address(RVA = "0x3134FDC", Offset = "0x3134FDC", VA = "0x3134FDC")]
	public void method_43(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001138 RID: 4408 RVA: 0x00023D8C File Offset: 0x00021F8C
	[Address(RVA = "0x31350D8", Offset = "0x31350D8", VA = "0x31350D8")]
	[Token(Token = "0x6001138")]
	public void method_44(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001139 RID: 4409 RVA: 0x00023EC4 File Offset: 0x000220C4
	[Address(RVA = "0x31351D0", Offset = "0x31351D0", VA = "0x31351D0")]
	[Token(Token = "0x6001139")]
	public void method_45()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("Player", value);
	}

	// Token: 0x0600113A RID: 4410 RVA: 0x00023A20 File Offset: 0x00021C20
	[Token(Token = "0x600113A")]
	[Address(RVA = "0x313522C", Offset = "0x313522C", VA = "0x313522C")]
	public void method_46(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600113B RID: 4411 RVA: 0x000239CC File Offset: 0x00021BCC
	[Address(RVA = "0x3135324", Offset = "0x3135324", VA = "0x3135324")]
	[Token(Token = "0x600113B")]
	public void method_47(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600113C RID: 4412 RVA: 0x00023B5C File Offset: 0x00021D5C
	[Token(Token = "0x600113C")]
	[Address(RVA = "0x3135420", Offset = "0x3135420", VA = "0x3135420")]
	public void method_48(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		TextMeshPro textMeshPro = this.textMeshPro_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		GameObject gameObject = textMeshPro.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600113D RID: 4413 RVA: 0x00023EEC File Offset: 0x000220EC
	[Token(Token = "0x600113D")]
	[Address(RVA = "0x313551C", Offset = "0x313551C", VA = "0x313551C")]
	public void method_49()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("HandR", value);
	}

	// Token: 0x0600113E RID: 4414 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x600113E")]
	[Address(RVA = "0x3135578", Offset = "0x3135578", VA = "0x3135578")]
	public KeyboardPopUp()
	{
	}

	// Token: 0x0600113F RID: 4415 RVA: 0x00023F14 File Offset: 0x00022114
	[Address(RVA = "0x3135580", Offset = "0x3135580", VA = "0x3135580")]
	[Token(Token = "0x600113F")]
	public void method_50()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("StartSong", value);
	}

	// Token: 0x06001140 RID: 4416 RVA: 0x00023F3C File Offset: 0x0002213C
	[Address(RVA = "0x31355DC", Offset = "0x31355DC", VA = "0x31355DC")]
	[Token(Token = "0x6001140")]
	public void method_51()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("Tagged", value);
	}

	// Token: 0x06001141 RID: 4417 RVA: 0x00023F64 File Offset: 0x00022164
	[Token(Token = "0x6001141")]
	[Address(RVA = "0x3135638", Offset = "0x3135638", VA = "0x3135638")]
	public void method_52(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001142 RID: 4418 RVA: 0x00023FAC File Offset: 0x000221AC
	[Address(RVA = "0x3135730", Offset = "0x3135730", VA = "0x3135730")]
	[Token(Token = "0x6001142")]
	public void method_53()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool(" hours. You were banned because of ", value);
	}

	// Token: 0x06001143 RID: 4419 RVA: 0x00023DD4 File Offset: 0x00021FD4
	[Token(Token = "0x6001143")]
	[Address(RVA = "0x313578C", Offset = "0x313578C", VA = "0x313578C")]
	public void method_54()
	{
		Animator animator = this.animator_0;
		bool value = this.bool_0;
		animator.SetBool("FingerTip", value);
	}

	// Token: 0x06001144 RID: 4420 RVA: 0x00023D8C File Offset: 0x00021F8C
	[Token(Token = "0x6001144")]
	[Address(RVA = "0x31357E8", Offset = "0x31357E8", VA = "0x31357E8")]
	public void method_55(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.textMeshPro_0.gameObject;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.textMeshPro_1.gameObject;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x04000276 RID: 630
	[Token(Token = "0x4000276")]
	[FieldOffset(Offset = "0x18")]
	public Animator animator_0;

	// Token: 0x04000277 RID: 631
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000277")]
	public bool bool_0;

	// Token: 0x04000278 RID: 632
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000278")]
	public TextMeshPro textMeshPro_0;

	// Token: 0x04000279 RID: 633
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000279")]
	public TextMeshPro textMeshPro_1;
}
