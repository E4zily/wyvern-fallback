﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000087 RID: 135
[ExecuteInEditMode]
[Token(Token = "0x2000087")]
public class MB_MigrateMaterialsToDifferentPipeline : MonoBehaviour
{
	// Token: 0x0600139D RID: 5021 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2EF9538", Offset = "0x2EF9538", VA = "0x2EF9538")]
	[Token(Token = "0x600139D")]
	public MB_MigrateMaterialsToDifferentPipeline()
	{
	}
}
