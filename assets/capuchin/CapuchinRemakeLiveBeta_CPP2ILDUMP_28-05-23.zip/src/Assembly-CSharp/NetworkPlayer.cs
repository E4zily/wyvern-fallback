﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000DF RID: 223
[Token(Token = "0x20000DF")]
public class NetworkPlayer : MonoBehaviour
{
	// Token: 0x0600214C RID: 8524 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4CDB4", Offset = "0x2D4CDB4", VA = "0x2D4CDB4")]
	[Token(Token = "0x600214C")]
	private void method_0(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600214D RID: 8525 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4CE14", Offset = "0x2D4CE14", VA = "0x2D4CE14")]
	[Token(Token = "0x600214D")]
	private void method_1(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600214E RID: 8526 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[PunRPC]
	[Address(RVA = "0x2D4CE74", Offset = "0x2D4CE74", VA = "0x2D4CE74")]
	[Token(Token = "0x600214E")]
	private void ChangePlayerSize(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600214F RID: 8527 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4CED4", Offset = "0x2D4CED4", VA = "0x2D4CED4")]
	[Token(Token = "0x600214F")]
	private void method_2(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002150 RID: 8528 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4CF34", Offset = "0x2D4CF34", VA = "0x2D4CF34")]
	[Token(Token = "0x6002150")]
	private void method_3(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002151 RID: 8529 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4CF94", Offset = "0x2D4CF94", VA = "0x2D4CF94")]
	[Token(Token = "0x6002151")]
	private void method_4(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002152 RID: 8530 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4CFF4", Offset = "0x2D4CFF4", VA = "0x2D4CFF4")]
	[Token(Token = "0x6002152")]
	private void method_5(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002153 RID: 8531 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D054", Offset = "0x2D4D054", VA = "0x2D4D054")]
	[Token(Token = "0x6002153")]
	private void method_6(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002154 RID: 8532 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D0B4", Offset = "0x2D4D0B4", VA = "0x2D4D0B4")]
	[Token(Token = "0x6002154")]
	private void method_7(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002155 RID: 8533 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D114", Offset = "0x2D4D114", VA = "0x2D4D114")]
	[Token(Token = "0x6002155")]
	private void method_8(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002156 RID: 8534 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D174", Offset = "0x2D4D174", VA = "0x2D4D174")]
	[Token(Token = "0x6002156")]
	private void method_9(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002157 RID: 8535 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D1D4", Offset = "0x2D4D1D4", VA = "0x2D4D1D4")]
	[Token(Token = "0x6002157")]
	private void method_10(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002158 RID: 8536 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D234", Offset = "0x2D4D234", VA = "0x2D4D234")]
	[Token(Token = "0x6002158")]
	private void method_11(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002159 RID: 8537 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D294", Offset = "0x2D4D294", VA = "0x2D4D294")]
	[Token(Token = "0x6002159")]
	private void method_12(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600215A RID: 8538 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D2F4", Offset = "0x2D4D2F4", VA = "0x2D4D2F4")]
	[Token(Token = "0x600215A")]
	private void method_13(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600215B RID: 8539 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D354", Offset = "0x2D4D354", VA = "0x2D4D354")]
	[Token(Token = "0x600215B")]
	private void method_14(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600215C RID: 8540 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D3B4", Offset = "0x2D4D3B4", VA = "0x2D4D3B4")]
	[Token(Token = "0x600215C")]
	private void method_15(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600215D RID: 8541 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D414", Offset = "0x2D4D414", VA = "0x2D4D414")]
	[Token(Token = "0x600215D")]
	private void method_16(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600215E RID: 8542 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D474", Offset = "0x2D4D474", VA = "0x2D4D474")]
	[Token(Token = "0x600215E")]
	private void method_17(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600215F RID: 8543 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D4D4", Offset = "0x2D4D4D4", VA = "0x2D4D4D4")]
	[Token(Token = "0x600215F")]
	private void method_18(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002160 RID: 8544 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D534", Offset = "0x2D4D534", VA = "0x2D4D534")]
	[Token(Token = "0x6002160")]
	private void method_19(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002161 RID: 8545 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D594", Offset = "0x2D4D594", VA = "0x2D4D594")]
	[Token(Token = "0x6002161")]
	private void method_20(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002162 RID: 8546 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D5F4", Offset = "0x2D4D5F4", VA = "0x2D4D5F4")]
	[Token(Token = "0x6002162")]
	private void method_21(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002163 RID: 8547 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D654", Offset = "0x2D4D654", VA = "0x2D4D654")]
	[Token(Token = "0x6002163")]
	private void method_22(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002164 RID: 8548 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D6B4", Offset = "0x2D4D6B4", VA = "0x2D4D6B4")]
	[Token(Token = "0x6002164")]
	private void method_23(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002165 RID: 8549 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D714", Offset = "0x2D4D714", VA = "0x2D4D714")]
	[Token(Token = "0x6002165")]
	private void method_24(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002166 RID: 8550 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D774", Offset = "0x2D4D774", VA = "0x2D4D774")]
	[Token(Token = "0x6002166")]
	private void method_25(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002167 RID: 8551 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2D4D7D4", Offset = "0x2D4D7D4", VA = "0x2D4D7D4")]
	[Token(Token = "0x6002167")]
	public NetworkPlayer()
	{
	}

	// Token: 0x06002168 RID: 8552 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D7DC", Offset = "0x2D4D7DC", VA = "0x2D4D7DC")]
	[Token(Token = "0x6002168")]
	private void method_26(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002169 RID: 8553 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D83C", Offset = "0x2D4D83C", VA = "0x2D4D83C")]
	[Token(Token = "0x6002169")]
	private void method_27(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600216A RID: 8554 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D89C", Offset = "0x2D4D89C", VA = "0x2D4D89C")]
	[Token(Token = "0x600216A")]
	private void method_28(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600216B RID: 8555 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D8FC", Offset = "0x2D4D8FC", VA = "0x2D4D8FC")]
	[Token(Token = "0x600216B")]
	private void method_29(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600216C RID: 8556 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D95C", Offset = "0x2D4D95C", VA = "0x2D4D95C")]
	[Token(Token = "0x600216C")]
	private void method_30(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600216D RID: 8557 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2D4D9BC", Offset = "0x2D4D9BC", VA = "0x2D4D9BC")]
	[Token(Token = "0x600216D")]
	private void method_31(float float_0)
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}
}
