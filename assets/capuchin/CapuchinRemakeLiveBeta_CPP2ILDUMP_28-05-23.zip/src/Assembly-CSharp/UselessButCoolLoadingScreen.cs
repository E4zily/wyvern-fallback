﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000F2 RID: 242
[Token(Token = "0x20000F2")]
public class UselessButCoolLoadingScreen : MonoBehaviour
{
	// Token: 0x06002466 RID: 9318 RVA: 0x00043700 File Offset: 0x00041900
	[Address(RVA = "0x20F475C", Offset = "0x20F475C", VA = "0x20F475C")]
	[Token(Token = "0x6002466")]
	public void method_0()
	{
		float num = this.float_0;
		float deltaTime = Time.deltaTime;
		this.float_0 = num;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)17438;
	}

	// Token: 0x06002467 RID: 9319 RVA: 0x0004373C File Offset: 0x0004193C
	[Address(RVA = "0x20F47E0", Offset = "0x20F47E0", VA = "0x20F47E0")]
	[Token(Token = "0x6002467")]
	public void Update()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)16544;
	}

	// Token: 0x06002468 RID: 9320 RVA: 0x00043784 File Offset: 0x00041984
	[Address(RVA = "0x20F485C", Offset = "0x20F485C", VA = "0x20F485C")]
	[Token(Token = "0x6002468")]
	public void method_1()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)17394;
	}

	// Token: 0x06002469 RID: 9321 RVA: 0x000437CC File Offset: 0x000419CC
	[Address(RVA = "0x20F48E0", Offset = "0x20F48E0", VA = "0x20F48E0")]
	[Token(Token = "0x6002469")]
	public void method_2()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)49152;
	}

	// Token: 0x0600246A RID: 9322 RVA: 0x00043814 File Offset: 0x00041A14
	[Address(RVA = "0x20F4968", Offset = "0x20F4968", VA = "0x20F4968")]
	[Token(Token = "0x600246A")]
	public void method_3()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)16384;
	}

	// Token: 0x0600246B RID: 9323 RVA: 0x00043868 File Offset: 0x00041A68
	[Address(RVA = "0x20F49F4", Offset = "0x20F49F4", VA = "0x20F49F4")]
	[Token(Token = "0x600246B")]
	public void method_4()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)32768;
	}

	// Token: 0x0600246C RID: 9324 RVA: 0x000438B0 File Offset: 0x00041AB0
	[Address(RVA = "0x20F4A7C", Offset = "0x20F4A7C", VA = "0x20F4A7C")]
	[Token(Token = "0x600246C")]
	public void method_5()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)8192;
	}

	// Token: 0x0600246D RID: 9325 RVA: 0x00043904 File Offset: 0x00041B04
	[Address(RVA = "0x20F4B08", Offset = "0x20F4B08", VA = "0x20F4B08")]
	[Token(Token = "0x600246D")]
	public void method_6()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)49152;
	}

	// Token: 0x0600246E RID: 9326 RVA: 0x00043958 File Offset: 0x00041B58
	[Address(RVA = "0x20F4B94", Offset = "0x20F4B94", VA = "0x20F4B94")]
	[Token(Token = "0x600246E")]
	public void method_7()
	{
		if (this.bool_0)
		{
			float deltaTime = Time.deltaTime;
		}
	}

	// Token: 0x0600246F RID: 9327 RVA: 0x00043974 File Offset: 0x00041B74
	[Address(RVA = "0x20F4C20", Offset = "0x20F4C20", VA = "0x20F4C20")]
	[Token(Token = "0x600246F")]
	public void method_8()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)17175;
	}

	// Token: 0x06002470 RID: 9328 RVA: 0x000439BC File Offset: 0x00041BBC
	[Address(RVA = "0x20F4CA4", Offset = "0x20F4CA4", VA = "0x20F4CA4")]
	[Token(Token = "0x6002470")]
	public void method_9()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)17648;
	}

	// Token: 0x06002471 RID: 9329 RVA: 0x00043904 File Offset: 0x00041B04
	[Address(RVA = "0x20F4D2C", Offset = "0x20F4D2C", VA = "0x20F4D2C")]
	[Token(Token = "0x6002471")]
	public void method_10()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)49152;
	}

	// Token: 0x06002472 RID: 9330 RVA: 0x00043904 File Offset: 0x00041B04
	[Address(RVA = "0x20F4DB8", Offset = "0x20F4DB8", VA = "0x20F4DB8")]
	[Token(Token = "0x6002472")]
	public void method_11()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)49152;
	}

	// Token: 0x06002473 RID: 9331 RVA: 0x00043A10 File Offset: 0x00041C10
	[Address(RVA = "0x20F4E44", Offset = "0x20F4E44", VA = "0x20F4E44")]
	[Token(Token = "0x6002473")]
	public void method_12()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)57344;
	}

	// Token: 0x06002474 RID: 9332 RVA: 0x00043A58 File Offset: 0x00041C58
	[Address(RVA = "0x20F4ECC", Offset = "0x20F4ECC", VA = "0x20F4ECC")]
	[Token(Token = "0x6002474")]
	public void method_13()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)40960;
	}

	// Token: 0x06002475 RID: 9333 RVA: 0x00043AAC File Offset: 0x00041CAC
	[Address(RVA = "0x20F4F58", Offset = "0x20F4F58", VA = "0x20F4F58")]
	[Token(Token = "0x6002475")]
	public void method_14()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)16384;
	}

	// Token: 0x06002476 RID: 9334 RVA: 0x00043AF4 File Offset: 0x00041CF4
	[Address(RVA = "0x20F4FE0", Offset = "0x20F4FE0", VA = "0x20F4FE0")]
	[Token(Token = "0x6002476")]
	public void method_15()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)32768;
	}

	// Token: 0x06002477 RID: 9335 RVA: 0x00043B48 File Offset: 0x00041D48
	[Address(RVA = "0x20F506C", Offset = "0x20F506C", VA = "0x20F506C")]
	[Token(Token = "0x6002477")]
	public void method_16()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)17435;
	}

	// Token: 0x06002478 RID: 9336 RVA: 0x00043B90 File Offset: 0x00041D90
	[Address(RVA = "0x20F50F0", Offset = "0x20F50F0", VA = "0x20F50F0")]
	[Token(Token = "0x6002478")]
	public void method_17()
	{
		if (this.bool_0)
		{
			float deltaTime = Time.deltaTime;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)40960;
	}

	// Token: 0x06002479 RID: 9337 RVA: 0x00043BC4 File Offset: 0x00041DC4
	[Address(RVA = "0x20F5178", Offset = "0x20F5178", VA = "0x20F5178")]
	[Token(Token = "0x6002479")]
	public void method_18()
	{
		if (this.bool_0)
		{
			float deltaTime = Time.deltaTime;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)32768;
	}

	// Token: 0x0600247A RID: 9338 RVA: 0x00043AAC File Offset: 0x00041CAC
	[Address(RVA = "0x20F5200", Offset = "0x20F5200", VA = "0x20F5200")]
	[Token(Token = "0x600247A")]
	public void method_19()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)16384;
	}

	// Token: 0x0600247B RID: 9339 RVA: 0x00043868 File Offset: 0x00041A68
	[Address(RVA = "0x20F5288", Offset = "0x20F5288", VA = "0x20F5288")]
	[Token(Token = "0x600247B")]
	public void method_20()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)32768;
	}

	// Token: 0x0600247C RID: 9340 RVA: 0x00043BF8 File Offset: 0x00041DF8
	[Address(RVA = "0x20F5310", Offset = "0x20F5310", VA = "0x20F5310")]
	[Token(Token = "0x600247C")]
	public void method_21()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)24576;
	}

	// Token: 0x0600247D RID: 9341 RVA: 0x00043958 File Offset: 0x00041B58
	[Address(RVA = "0x20F539C", Offset = "0x20F539C", VA = "0x20F539C")]
	[Token(Token = "0x600247D")]
	public void method_22()
	{
		if (this.bool_0)
		{
			float deltaTime = Time.deltaTime;
		}
	}

	// Token: 0x0600247E RID: 9342 RVA: 0x00043C4C File Offset: 0x00041E4C
	[Address(RVA = "0x20F5424", Offset = "0x20F5424", VA = "0x20F5424")]
	[Token(Token = "0x600247E")]
	public void method_23()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)17385;
	}

	// Token: 0x0600247F RID: 9343 RVA: 0x00043904 File Offset: 0x00041B04
	[Address(RVA = "0x20F54A8", Offset = "0x20F54A8", VA = "0x20F54A8")]
	[Token(Token = "0x600247F")]
	public void method_24()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)49152;
	}

	// Token: 0x06002480 RID: 9344 RVA: 0x00043C94 File Offset: 0x00041E94
	[Address(RVA = "0x20F5534", Offset = "0x20F5534", VA = "0x20F5534")]
	[Token(Token = "0x6002480")]
	public void method_25()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)17473;
	}

	// Token: 0x06002481 RID: 9345 RVA: 0x00043CD8 File Offset: 0x00041ED8
	[Address(RVA = "0x20F55B8", Offset = "0x20F55B8", VA = "0x20F55B8")]
	[Token(Token = "0x6002481")]
	public void method_26()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)8192;
	}

	// Token: 0x06002482 RID: 9346 RVA: 0x00043904 File Offset: 0x00041B04
	[Address(RVA = "0x20F5640", Offset = "0x20F5640", VA = "0x20F5640")]
	[Token(Token = "0x6002482")]
	public void method_27()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)49152;
	}

	// Token: 0x06002483 RID: 9347 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x20F56CC", Offset = "0x20F56CC", VA = "0x20F56CC")]
	[Token(Token = "0x6002483")]
	public UselessButCoolLoadingScreen()
	{
	}

	// Token: 0x06002484 RID: 9348 RVA: 0x00043D20 File Offset: 0x00041F20
	[Address(RVA = "0x20F56D4", Offset = "0x20F56D4", VA = "0x20F56D4")]
	[Token(Token = "0x6002484")]
	public void method_28()
	{
		if (this.bool_0)
		{
			float deltaTime = Time.deltaTime;
		}
		Transform transform = this.transform_1;
		long num = 1L;
		this.bool_0 = (num != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)17236;
	}

	// Token: 0x06002485 RID: 9349 RVA: 0x00043AF4 File Offset: 0x00041CF4
	[Address(RVA = "0x20F575C", Offset = "0x20F575C", VA = "0x20F575C")]
	[Token(Token = "0x6002485")]
	public void method_29()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)32768;
	}

	// Token: 0x06002486 RID: 9350 RVA: 0x00043D60 File Offset: 0x00041F60
	[Address(RVA = "0x20F57E8", Offset = "0x20F57E8", VA = "0x20F57E8")]
	[Token(Token = "0x6002486")]
	public void method_30()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)16384;
	}

	// Token: 0x06002487 RID: 9351 RVA: 0x00043868 File Offset: 0x00041A68
	[Address(RVA = "0x20F5874", Offset = "0x20F5874", VA = "0x20F5874")]
	[Token(Token = "0x6002487")]
	public void method_31()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)32768;
	}

	// Token: 0x06002488 RID: 9352 RVA: 0x00043DB4 File Offset: 0x00041FB4
	[Address(RVA = "0x20F58FC", Offset = "0x20F58FC", VA = "0x20F58FC")]
	[Token(Token = "0x6002488")]
	public void method_32()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)17603;
	}

	// Token: 0x06002489 RID: 9353 RVA: 0x00043904 File Offset: 0x00041B04
	[Address(RVA = "0x20F5980", Offset = "0x20F5980", VA = "0x20F5980")]
	[Token(Token = "0x6002489")]
	public void method_33()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)49152;
	}

	// Token: 0x0600248A RID: 9354 RVA: 0x00043958 File Offset: 0x00041B58
	[Address(RVA = "0x20F5A0C", Offset = "0x20F5A0C", VA = "0x20F5A0C")]
	[Token(Token = "0x600248A")]
	public void method_34()
	{
		if (this.bool_0)
		{
			float deltaTime = Time.deltaTime;
		}
	}

	// Token: 0x0600248B RID: 9355 RVA: 0x00043814 File Offset: 0x00041A14
	[Address(RVA = "0x20F5A94", Offset = "0x20F5A94", VA = "0x20F5A94")]
	[Token(Token = "0x600248B")]
	public void method_35()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)16384;
	}

	// Token: 0x0600248C RID: 9356 RVA: 0x00043958 File Offset: 0x00041B58
	[Address(RVA = "0x20F5B20", Offset = "0x20F5B20", VA = "0x20F5B20")]
	[Token(Token = "0x600248C")]
	public void method_36()
	{
		if (this.bool_0)
		{
			float deltaTime = Time.deltaTime;
		}
	}

	// Token: 0x0600248D RID: 9357 RVA: 0x00043868 File Offset: 0x00041A68
	[Address(RVA = "0x20F5BA8", Offset = "0x20F5BA8", VA = "0x20F5BA8")]
	[Token(Token = "0x600248D")]
	public void method_37()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)32768;
	}

	// Token: 0x0600248E RID: 9358 RVA: 0x00043DFC File Offset: 0x00041FFC
	[Address(RVA = "0x20F5C30", Offset = "0x20F5C30", VA = "0x20F5C30")]
	[Token(Token = "0x600248E")]
	public void method_38()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)17472;
	}

	// Token: 0x0600248F RID: 9359 RVA: 0x00043814 File Offset: 0x00041A14
	[Address(RVA = "0x20F5CB8", Offset = "0x20F5CB8", VA = "0x20F5CB8")]
	[Token(Token = "0x600248F")]
	public void method_39()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		Vector3 position = transform.position;
		this.float_0 = (float)16384;
	}

	// Token: 0x06002490 RID: 9360 RVA: 0x00043E50 File Offset: 0x00042050
	[Address(RVA = "0x20F5D44", Offset = "0x20F5D44", VA = "0x20F5D44")]
	[Token(Token = "0x6002490")]
	public void method_40()
	{
		bool flag = this.bool_0;
		float num = this.float_0;
		if (flag)
		{
			float deltaTime = Time.deltaTime;
			this.float_0 = num;
		}
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		this.float_0 = (float)17292;
	}

	// Token: 0x040004C8 RID: 1224
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004C8")]
	public Transform transform_0;

	// Token: 0x040004C9 RID: 1225
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004C9")]
	public Transform transform_1;

	// Token: 0x040004CA RID: 1226
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40004CA")]
	public float float_0;

	// Token: 0x040004CB RID: 1227
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x40004CB")]
	public bool bool_0;
}
