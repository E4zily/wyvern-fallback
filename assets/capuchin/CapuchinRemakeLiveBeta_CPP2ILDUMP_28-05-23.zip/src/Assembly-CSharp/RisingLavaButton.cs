﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

// Token: 0x020000EA RID: 234
[Token(Token = "0x20000EA")]
public class RisingLavaButton : MonoBehaviour
{
	// Token: 0x060022E6 RID: 8934 RVA: 0x000411D0 File Offset: 0x0003F3D0
	[Address(RVA = "0x2E06258", Offset = "0x2E06258", VA = "0x2E06258")]
	[Token(Token = "0x60022E6")]
	public void method_0()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x060022E7 RID: 8935 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E065C8", Offset = "0x2E065C8", VA = "0x2E065C8")]
	[Token(Token = "0x60022E7")]
	public void method_1()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060022E8 RID: 8936 RVA: 0x00041210 File Offset: 0x0003F410
	[Address(RVA = "0x2E06914", Offset = "0x2E06914", VA = "0x2E06914")]
	[Token(Token = "0x60022E8")]
	public void method_2(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "ChangeToTagged";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060022E9 RID: 8937 RVA: 0x0004126C File Offset: 0x0003F46C
	[Address(RVA = "0x2E06ACC", Offset = "0x2E06ACC", VA = "0x2E06ACC")]
	[Token(Token = "0x60022E9")]
	public void method_3()
	{
		TextMeshPro textMeshPro;
		this.textMeshPro_0 = textMeshPro;
	}

	// Token: 0x060022EA RID: 8938 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E06B28", Offset = "0x2E06B28", VA = "0x2E06B28")]
	[Token(Token = "0x60022EA")]
	public void method_4()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x060022EB RID: 8939 RVA: 0x0004129C File Offset: 0x0003F49C
	[Address(RVA = "0x2E06B84", Offset = "0x2E06B84", VA = "0x2E06B84")]
	[Token(Token = "0x60022EB")]
	public void method_5()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 0L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 0L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 1L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 0L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 0L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled7 = 0L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x060022EC RID: 8940 RVA: 0x00041388 File Offset: 0x0003F588
	[Address(RVA = "0x2E06C90", Offset = "0x2E06C90", VA = "0x2E06C90")]
	[Token(Token = "0x60022EC")]
	public void method_6()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 0L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 1L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		long enabled4 = 1L;
		capsuleCollider.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_1;
		long enabled5 = 0L;
		sphereCollider3.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 0L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		long num = 1L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		this.bool_0 = (num != 0L);
		long enabled7 = 0L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
	}

	// Token: 0x060022ED RID: 8941 RVA: 0x00041464 File Offset: 0x0003F664
	[Address(RVA = "0x2E06DA0", Offset = "0x2E06DA0", VA = "0x2E06DA0")]
	[Token(Token = "0x60022ED")]
	public void method_7(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "Removing ";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060022EE RID: 8942 RVA: 0x000414C0 File Offset: 0x0003F6C0
	[Address(RVA = "0x2E06F58", Offset = "0x2E06F58", VA = "0x2E06F58")]
	[Token(Token = "0x60022EE")]
	public void method_8()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x060022EF RID: 8943 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E072C8", Offset = "0x2E072C8", VA = "0x2E072C8")]
	[Token(Token = "0x60022EF")]
	public void method_9()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x060022F0 RID: 8944 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E07324", Offset = "0x2E07324", VA = "0x2E07324")]
	[Token(Token = "0x60022F0")]
	public void method_10()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x060022F1 RID: 8945 RVA: 0x000414F8 File Offset: 0x0003F6F8
	[PunRPC]
	[Address(RVA = "0x2E07380", Offset = "0x2E07380", VA = "0x2E07380")]
	[Token(Token = "0x60022F1")]
	public void StartGamemode()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 0L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 0L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 1L;
		sphereCollider3.enabled = (enabled4 != 0L);
		long enabled5 = 1L;
		sphereCollider3.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 0L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		long num = 1L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		this.bool_0 = (num != 0L);
		long enabled7 = 0L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x060022F2 RID: 8946 RVA: 0x000415E8 File Offset: 0x0003F7E8
	[Address(RVA = "0x2E07490", Offset = "0x2E07490", VA = "0x2E07490")]
	[Token(Token = "0x60022F2")]
	public void method_11(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "Platform failed to initialize due to exception.";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060022F3 RID: 8947 RVA: 0x00041644 File Offset: 0x0003F844
	[Address(RVA = "0x2E07648", Offset = "0x2E07648", VA = "0x2E07648")]
	[Token(Token = "0x60022F3")]
	public void method_12()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x060022F4 RID: 8948 RVA: 0x00041684 File Offset: 0x0003F884
	[Address(RVA = "0x2E079B4", Offset = "0x2E079B4", VA = "0x2E079B4")]
	[Token(Token = "0x60022F4")]
	public void method_13()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x060022F5 RID: 8949 RVA: 0x00041644 File Offset: 0x0003F844
	[Address(RVA = "0x2E07D3C", Offset = "0x2E07D3C", VA = "0x2E07D3C")]
	[Token(Token = "0x60022F5")]
	public void method_14()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x060022F6 RID: 8950 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E080AC", Offset = "0x2E080AC", VA = "0x2E080AC")]
	[Token(Token = "0x60022F6")]
	public void method_15()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x060022F7 RID: 8951 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E08108", Offset = "0x2E08108", VA = "0x2E08108")]
	[Token(Token = "0x60022F7")]
	public void method_16()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x060022F8 RID: 8952 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E08164", Offset = "0x2E08164", VA = "0x2E08164")]
	[Token(Token = "0x60022F8")]
	public void method_17()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x060022F9 RID: 8953 RVA: 0x000416C4 File Offset: 0x0003F8C4
	[Address(RVA = "0x2E081C0", Offset = "0x2E081C0", VA = "0x2E081C0")]
	[Token(Token = "0x60022F9")]
	public void method_18(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "username";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060022FA RID: 8954 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E08378", Offset = "0x2E08378", VA = "0x2E08378")]
	[Token(Token = "0x60022FA")]
	public void method_19()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x060022FB RID: 8955 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E083D4", Offset = "0x2E083D4", VA = "0x2E083D4")]
	[Token(Token = "0x60022FB")]
	public void method_20()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x060022FC RID: 8956 RVA: 0x00041720 File Offset: 0x0003F920
	[Address(RVA = "0x2E08430", Offset = "0x2E08430", VA = "0x2E08430")]
	[Token(Token = "0x60022FC")]
	public void method_21()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 1L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 0L;
		sphereCollider2.enabled = (enabled2 != 0L);
		long enabled3 = 0L;
		sphereCollider2.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 1L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 1L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled6 = 1L;
		capsuleCollider.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 1L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled7 = 1L;
		boxCollider.enabled = (enabled7 != 0L);
		AudioSource audioSource = this.audioSource_1;
		long active2 = 0L;
		audioSource.Play();
		this.gameObject_1.SetActive(active2 != 0L);
	}

	// Token: 0x060022FD RID: 8957 RVA: 0x00041804 File Offset: 0x0003FA04
	[Address(RVA = "0x2E0853C", Offset = "0x2E0853C", VA = "0x2E0853C")]
	[Token(Token = "0x60022FD")]
	public void method_22()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 0L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 0L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 0L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 1L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 1L;
		long num = 1L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		this.bool_0 = (num != 0L);
		long enabled7 = 0L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060022FE RID: 8958 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0864C", Offset = "0x2E0864C", VA = "0x2E0864C")]
	[Token(Token = "0x60022FE")]
	public void method_23()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x060022FF RID: 8959 RVA: 0x000418E8 File Offset: 0x0003FAE8
	[Address(RVA = "0x2E086A8", Offset = "0x2E086A8", VA = "0x2E086A8")]
	[Token(Token = "0x60022FF")]
	public void method_24()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 1L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 1L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 1L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 0L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		long enabled7 = 0L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002300 RID: 8960 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E087B8", Offset = "0x2E087B8", VA = "0x2E087B8")]
	[Token(Token = "0x6002300")]
	public void method_25()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002301 RID: 8961 RVA: 0x000419CC File Offset: 0x0003FBCC
	[Address(RVA = "0x2E08814", Offset = "0x2E08814", VA = "0x2E08814")]
	[Token(Token = "0x6002301")]
	public void method_26()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		long isKinematic2 = 0L;
		rigidbody.isKinematic = (isKinematic2 != 0L);
	}

	// Token: 0x06002302 RID: 8962 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E08920", Offset = "0x2E08920", VA = "0x2E08920")]
	[Token(Token = "0x6002302")]
	public void method_27()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002303 RID: 8963 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0897C", Offset = "0x2E0897C", VA = "0x2E0897C")]
	[Token(Token = "0x6002303")]
	public void method_28()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002304 RID: 8964 RVA: 0x000419F4 File Offset: 0x0003FBF4
	[Address(RVA = "0x2E089D8", Offset = "0x2E089D8", VA = "0x2E089D8")]
	[Token(Token = "0x6002304")]
	public void method_29()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x06002305 RID: 8965 RVA: 0x00041A34 File Offset: 0x0003FC34
	[Address(RVA = "0x2E08D44", Offset = "0x2E08D44", VA = "0x2E08D44")]
	[Token(Token = "0x6002305")]
	public void method_30(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "QuickStatic";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002306 RID: 8966 RVA: 0x00041A90 File Offset: 0x0003FC90
	[Address(RVA = "0x2E08EFC", Offset = "0x2E08EFC", VA = "0x2E08EFC")]
	[Token(Token = "0x6002306")]
	public void Update()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x06002307 RID: 8967 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E09264", Offset = "0x2E09264", VA = "0x2E09264")]
	[Token(Token = "0x6002307")]
	public void method_31()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002308 RID: 8968 RVA: 0x00041210 File Offset: 0x0003F410
	[Address(RVA = "0x2E092C0", Offset = "0x2E092C0", VA = "0x2E092C0")]
	[Token(Token = "0x6002308")]
	public void method_32(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "ChangeToTagged";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002309 RID: 8969 RVA: 0x00041AD0 File Offset: 0x0003FCD0
	[Address(RVA = "0x2E09478", Offset = "0x2E09478", VA = "0x2E09478")]
	[Token(Token = "0x6002309")]
	public void method_33()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 0L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 0L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 0L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 0L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 1L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled7 = 1L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600230A RID: 8970 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E09584", Offset = "0x2E09584", VA = "0x2E09584")]
	[Token(Token = "0x600230A")]
	public void method_34()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x0600230B RID: 8971 RVA: 0x00041BBC File Offset: 0x0003FDBC
	[Address(RVA = "0x2E095E0", Offset = "0x2E095E0", VA = "0x2E095E0")]
	[Token(Token = "0x600230B")]
	public void method_35()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x0600230C RID: 8972 RVA: 0x00041BFC File Offset: 0x0003FDFC
	[Address(RVA = "0x2E0994C", Offset = "0x2E0994C", VA = "0x2E0994C")]
	[Token(Token = "0x600230C")]
	public void method_36(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == " ";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600230D RID: 8973 RVA: 0x00041C58 File Offset: 0x0003FE58
	[Address(RVA = "0x2E09B04", Offset = "0x2E09B04", VA = "0x2E09B04")]
	[Token(Token = "0x600230D")]
	public void method_37()
	{
		bool inRoom = PhotonNetwork.InRoom;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x0600230E RID: 8974 RVA: 0x00041C88 File Offset: 0x0003FE88
	[Address(RVA = "0x2E09E50", Offset = "0x2E09E50", VA = "0x2E09E50")]
	[Token(Token = "0x600230E")]
	public void method_38(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "EnableCosmetic";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600230F RID: 8975 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0A008", Offset = "0x2E0A008", VA = "0x2E0A008")]
	[Token(Token = "0x600230F")]
	public void method_39()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002310 RID: 8976 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0A064", Offset = "0x2E0A064", VA = "0x2E0A064")]
	[Token(Token = "0x6002310")]
	public void method_40()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002311 RID: 8977 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0A0C0", Offset = "0x2E0A0C0", VA = "0x2E0A0C0")]
	[Token(Token = "0x6002311")]
	public void method_41()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002312 RID: 8978 RVA: 0x000411D0 File Offset: 0x0003F3D0
	[Address(RVA = "0x2E0A11C", Offset = "0x2E0A11C", VA = "0x2E0A11C")]
	[Token(Token = "0x6002312")]
	public void method_42()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x06002313 RID: 8979 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0A48C", Offset = "0x2E0A48C", VA = "0x2E0A48C")]
	[Token(Token = "0x6002313")]
	public void method_43()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002314 RID: 8980 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0A4E8", Offset = "0x2E0A4E8", VA = "0x2E0A4E8")]
	[Token(Token = "0x6002314")]
	public void method_44()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002315 RID: 8981 RVA: 0x00041CE4 File Offset: 0x0003FEE4
	[Address(RVA = "0x2E0A544", Offset = "0x2E0A544", VA = "0x2E0A544")]
	[Token(Token = "0x6002315")]
	public void method_45(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "ENABLE";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002316 RID: 8982 RVA: 0x00041D40 File Offset: 0x0003FF40
	[Address(RVA = "0x2E0A6FC", Offset = "0x2E0A6FC", VA = "0x2E0A6FC")]
	[Token(Token = "0x6002316")]
	public void method_46()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 1L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 1L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 1L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 1L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 1L;
		long num = 1L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		this.bool_0 = (num != 0L);
		long enabled7 = 0L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002317 RID: 8983 RVA: 0x00041E38 File Offset: 0x00040038
	[Address(RVA = "0x2E0A80C", Offset = "0x2E0A80C", VA = "0x2E0A80C")]
	[Token(Token = "0x6002317")]
	public void method_47(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002318 RID: 8984 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0A9C4", Offset = "0x2E0A9C4", VA = "0x2E0A9C4")]
	[Token(Token = "0x6002318")]
	public void method_48()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002319 RID: 8985 RVA: 0x00041E94 File Offset: 0x00040094
	[Address(RVA = "0x2E0AA20", Offset = "0x2E0AA20", VA = "0x2E0AA20")]
	[Token(Token = "0x6002319")]
	public void method_49()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x0600231A RID: 8986 RVA: 0x00041ED4 File Offset: 0x000400D4
	[Address(RVA = "0x2E0AD84", Offset = "0x2E0AD84", VA = "0x2E0AD84")]
	[Token(Token = "0x600231A")]
	public void method_50()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 0L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 0L;
		sphereCollider2.enabled = (enabled2 != 0L);
		long enabled3 = 0L;
		sphereCollider2.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 0L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 0L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled6 = 1L;
		capsuleCollider.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 1L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled7 = 1L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600231B RID: 8987 RVA: 0x00041FB8 File Offset: 0x000401B8
	[Address(RVA = "0x2E0AE90", Offset = "0x2E0AE90", VA = "0x2E0AE90")]
	[Token(Token = "0x600231B")]
	public void method_51()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 0L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 0L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 1L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 1L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 0L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		long enabled7 = 0L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600231C RID: 8988 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0AFA0", Offset = "0x2E0AFA0", VA = "0x2E0AFA0")]
	[Token(Token = "0x600231C")]
	public void method_52()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x0600231D RID: 8989 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0AFFC", Offset = "0x2E0AFFC", VA = "0x2E0AFFC")]
	[Token(Token = "0x600231D")]
	public void method_53()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x0600231E RID: 8990 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0B058", Offset = "0x2E0B058", VA = "0x2E0B058")]
	[Token(Token = "0x600231E")]
	public void method_54()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x0600231F RID: 8991 RVA: 0x000411D0 File Offset: 0x0003F3D0
	[Address(RVA = "0x2E0B0B4", Offset = "0x2E0B0B4", VA = "0x2E0B0B4")]
	[Token(Token = "0x600231F")]
	public void method_55()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x06002320 RID: 8992 RVA: 0x000420B0 File Offset: 0x000402B0
	[Address(RVA = "0x2E0B420", Offset = "0x2E0B420", VA = "0x2E0B420")]
	[Token(Token = "0x6002320")]
	public void method_56()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x06002321 RID: 8993 RVA: 0x000420F0 File Offset: 0x000402F0
	[Address(RVA = "0x2E0B788", Offset = "0x2E0B788", VA = "0x2E0B788")]
	[Token(Token = "0x6002321")]
	public void method_57()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 1L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 0L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 0L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 0L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 1L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled7 = 1L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002322 RID: 8994 RVA: 0x000421DC File Offset: 0x000403DC
	[Address(RVA = "0x2E0B894", Offset = "0x2E0B894", VA = "0x2E0B894")]
	[Token(Token = "0x6002322")]
	public void method_58(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		GameObject gameObject;
		gameObject.tag == "DisableCosmetic";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		audioSource.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002323 RID: 8995 RVA: 0x00042230 File Offset: 0x00040430
	[Address(RVA = "0x2E0BA4C", Offset = "0x2E0BA4C", VA = "0x2E0BA4C")]
	[Token(Token = "0x6002323")]
	public void method_59(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002324 RID: 8996 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0BC04", Offset = "0x2E0BC04", VA = "0x2E0BC04")]
	[Token(Token = "0x6002324")]
	public void method_60()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002325 RID: 8997 RVA: 0x0004228C File Offset: 0x0004048C
	[Address(RVA = "0x2E0BC60", Offset = "0x2E0BC60", VA = "0x2E0BC60")]
	[Token(Token = "0x6002325")]
	public void method_61()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long num = 1L;
		rigidbody.isKinematic = (num != 0L);
		this.sphereCollider_0.enabled = (num != 0L);
		SphereCollider sphereCollider = this.sphereCollider_1;
		long enabled = 1L;
		sphereCollider.enabled = (enabled != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled2 = 1L;
		capsuleCollider.enabled = (enabled2 != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_0;
		long enabled3 = 1L;
		sphereCollider2.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_1;
		long enabled4 = 1L;
		sphereCollider3.enabled = (enabled4 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled5 = 0L;
		capsuleCollider2.enabled = (enabled5 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic = 1L;
		long num2 = 1L;
		rigidbody2.isKinematic = (isKinematic != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		this.bool_0 = (num2 != 0L);
		long enabled6 = 0L;
		boxCollider.enabled = (enabled6 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06002326 RID: 8998 RVA: 0x0004237C File Offset: 0x0004057C
	[Address(RVA = "0x2E0BD70", Offset = "0x2E0BD70", VA = "0x2E0BD70")]
	[Token(Token = "0x6002326")]
	public void method_62(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "HandL";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002327 RID: 8999 RVA: 0x000423D8 File Offset: 0x000405D8
	[Address(RVA = "0x2E0BF28", Offset = "0x2E0BF28", VA = "0x2E0BF28")]
	[Token(Token = "0x6002327")]
	public void method_63()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			throw new MissingMethodException();
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x06002328 RID: 9000 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0C2B4", Offset = "0x2E0C2B4", VA = "0x2E0C2B4")]
	[Token(Token = "0x6002328")]
	public void Start()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002329 RID: 9001 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0C310", Offset = "0x2E0C310", VA = "0x2E0C310")]
	[Token(Token = "0x6002329")]
	public void method_64()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x0600232A RID: 9002 RVA: 0x0004241C File Offset: 0x0004061C
	[Address(RVA = "0x2E0C36C", Offset = "0x2E0C36C", VA = "0x2E0C36C")]
	[Token(Token = "0x600232A")]
	public void method_65(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "DISABLE";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600232B RID: 9003 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0C524", Offset = "0x2E0C524", VA = "0x2E0C524")]
	[Token(Token = "0x600232B")]
	public void method_66()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x0600232C RID: 9004 RVA: 0x00041A90 File Offset: 0x0003FC90
	[Address(RVA = "0x2E0C580", Offset = "0x2E0C580", VA = "0x2E0C580")]
	[Token(Token = "0x600232C")]
	public void method_67()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x0600232D RID: 9005 RVA: 0x00042478 File Offset: 0x00040678
	[Address(RVA = "0x2E0C90C", Offset = "0x2E0C90C", VA = "0x2E0C90C")]
	[Token(Token = "0x600232D")]
	public void method_68()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x0600232E RID: 9006 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0CC5C", Offset = "0x2E0CC5C", VA = "0x2E0CC5C")]
	[Token(Token = "0x600232E")]
	public void method_69()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x0600232F RID: 9007 RVA: 0x000424B8 File Offset: 0x000406B8
	[Address(RVA = "0x2E0CCB8", Offset = "0x2E0CCB8", VA = "0x2E0CCB8")]
	[Token(Token = "0x600232F")]
	public void method_70(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "User has been reported for: ";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.sphereCollider_0 != null)
		{
			return;
		}
	}

	// Token: 0x06002330 RID: 9008 RVA: 0x00002D51 File Offset: 0x00000F51
	[Address(RVA = "0x2E0CE70", Offset = "0x2E0CE70", VA = "0x2E0CE70")]
	[Token(Token = "0x6002330")]
	public RisingLavaButton()
	{
	}

	// Token: 0x06002331 RID: 9009 RVA: 0x00041280 File Offset: 0x0003F480
	[Address(RVA = "0x2E0CE80", Offset = "0x2E0CE80", VA = "0x2E0CE80")]
	[Token(Token = "0x6002331")]
	public void method_71()
	{
		TextMeshPro componentInChildren = base.GetComponentInChildren<TextMeshPro>();
		this.textMeshPro_0 = componentInChildren;
	}

	// Token: 0x06002332 RID: 9010 RVA: 0x0004250C File Offset: 0x0004070C
	[Address(RVA = "0x2E0CEDC", Offset = "0x2E0CEDC", VA = "0x2E0CEDC")]
	[Token(Token = "0x6002332")]
	public void OnTriggerEnter(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		GameObject gameObject;
		gameObject.tag == "FingerTip";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002333 RID: 9011 RVA: 0x00042564 File Offset: 0x00040764
	[Address(RVA = "0x2E0D094", Offset = "0x2E0D094", VA = "0x2E0D094")]
	[Token(Token = "0x6002333")]
	public void method_72(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002334 RID: 9012 RVA: 0x000425C0 File Offset: 0x000407C0
	[Address(RVA = "0x2E0D24C", Offset = "0x2E0D24C", VA = "0x2E0D24C")]
	[Token(Token = "0x6002334")]
	public void method_73(Collider collider_0)
	{
		bool isMasterClient = PhotonNetwork.IsMasterClient;
		collider_0.gameObject.tag == "Failed to login, please restart";
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_1;
		audioSource.clip = clip;
		this.audioSource_0.Play();
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002335 RID: 9013 RVA: 0x0004261C File Offset: 0x0004081C
	[Address(RVA = "0x2E0D404", Offset = "0x2E0D404", VA = "0x2E0D404")]
	[Token(Token = "0x6002335")]
	public void method_74()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x06002336 RID: 9014 RVA: 0x000419F4 File Offset: 0x0003FBF4
	[Address(RVA = "0x2E0D770", Offset = "0x2E0D770", VA = "0x2E0D770")]
	[Token(Token = "0x6002336")]
	public void method_75()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x06002337 RID: 9015 RVA: 0x0004265C File Offset: 0x0004085C
	[Address(RVA = "0x2E0DAD8", Offset = "0x2E0DAD8", VA = "0x2E0DAD8")]
	[Token(Token = "0x6002337")]
	public void method_76()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 1L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 1L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 0L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 1L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 1L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 0L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 0L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled7 = 1L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
	}

	// Token: 0x06002338 RID: 9016 RVA: 0x00042734 File Offset: 0x00040934
	[Address(RVA = "0x2E0DBE4", Offset = "0x2E0DBE4", VA = "0x2E0DBE4")]
	[Token(Token = "0x6002338")]
	public void method_77()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x06002339 RID: 9017 RVA: 0x00042774 File Offset: 0x00040974
	[Address(RVA = "0x2E0DF54", Offset = "0x2E0DF54", VA = "0x2E0DF54")]
	[Token(Token = "0x6002339")]
	public void method_78()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		SphereCollider sphereCollider = this.sphereCollider_0;
		long enabled = 0L;
		sphereCollider.enabled = (enabled != 0L);
		SphereCollider sphereCollider2 = this.sphereCollider_1;
		long enabled2 = 1L;
		sphereCollider2.enabled = (enabled2 != 0L);
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		long enabled3 = 1L;
		capsuleCollider.enabled = (enabled3 != 0L);
		SphereCollider sphereCollider3 = this.sphereCollider_0;
		long enabled4 = 0L;
		sphereCollider3.enabled = (enabled4 != 0L);
		SphereCollider sphereCollider4 = this.sphereCollider_1;
		long enabled5 = 1L;
		sphereCollider4.enabled = (enabled5 != 0L);
		CapsuleCollider capsuleCollider2 = this.capsuleCollider_0;
		long enabled6 = 1L;
		capsuleCollider2.enabled = (enabled6 != 0L);
		Rigidbody rigidbody2 = this.rigidbody_0;
		long isKinematic2 = 0L;
		rigidbody2.isKinematic = (isKinematic2 != 0L);
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		BoxCollider boxCollider = this.boxCollider_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		long enabled7 = 0L;
		boxCollider.enabled = (enabled7 != 0L);
		this.audioSource_1.Play();
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600233A RID: 9018 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E0E064", Offset = "0x2E0E064", VA = "0x2E0E064")]
	[Token(Token = "0x600233A")]
	public void method_79()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600233B RID: 9019 RVA: 0x000411D0 File Offset: 0x0003F3D0
	[Address(RVA = "0x2E0E3F0", Offset = "0x2E0E3F0", VA = "0x2E0E3F0")]
	[Token(Token = "0x600233B")]
	public void method_80()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		bool isMasterClient = PhotonNetwork.IsMasterClient;
	}

	// Token: 0x04000493 RID: 1171
	[Token(Token = "0x4000493")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;

	// Token: 0x04000494 RID: 1172
	[Token(Token = "0x4000494")]
	[FieldOffset(Offset = "0x20")]
	public float float_0 = (float)17174;

	// Token: 0x04000495 RID: 1173
	[Token(Token = "0x4000495")]
	[FieldOffset(Offset = "0x28")]
	public Transform transform_0;

	// Token: 0x04000496 RID: 1174
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000496")]
	public Transform transform_1;

	// Token: 0x04000497 RID: 1175
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000497")]
	public bool bool_0;

	// Token: 0x04000498 RID: 1176
	[Token(Token = "0x4000498")]
	[FieldOffset(Offset = "0x40")]
	public TextMeshPro textMeshPro_0;

	// Token: 0x04000499 RID: 1177
	[Token(Token = "0x4000499")]
	[FieldOffset(Offset = "0x48")]
	public BoxCollider boxCollider_0;

	// Token: 0x0400049A RID: 1178
	[Token(Token = "0x400049A")]
	[FieldOffset(Offset = "0x50")]
	public Rigidbody rigidbody_0;

	// Token: 0x0400049B RID: 1179
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400049B")]
	public CapsuleCollider capsuleCollider_0;

	// Token: 0x0400049C RID: 1180
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400049C")]
	public SphereCollider sphereCollider_0;

	// Token: 0x0400049D RID: 1181
	[Token(Token = "0x400049D")]
	[FieldOffset(Offset = "0x68")]
	public SphereCollider sphereCollider_1;

	// Token: 0x0400049E RID: 1182
	[Token(Token = "0x400049E")]
	[FieldOffset(Offset = "0x70")]
	public GameObject gameObject_1;

	// Token: 0x0400049F RID: 1183
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x400049F")]
	public AudioSource audioSource_0;

	// Token: 0x040004A0 RID: 1184
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x40004A0")]
	public AudioClip audioClip_0;

	// Token: 0x040004A1 RID: 1185
	[Token(Token = "0x40004A1")]
	[FieldOffset(Offset = "0x88")]
	public AudioClip audioClip_1;

	// Token: 0x040004A2 RID: 1186
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x40004A2")]
	public AudioSource audioSource_1;

	// Token: 0x040004A3 RID: 1187
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x40004A3")]
	public NetworkPlayerSpawner networkPlayerSpawner_0;

	// Token: 0x040004A4 RID: 1188
	[Token(Token = "0x40004A4")]
	[FieldOffset(Offset = "0xA0")]
	public PhotonView photonView_0;

	// Token: 0x040004A5 RID: 1189
	[Token(Token = "0x40004A5")]
	[FieldOffset(Offset = "0xA8")]
	private PhotonView photonView_1;

	// Token: 0x040004A6 RID: 1190
	[Header("Lerp")]
	[Token(Token = "0x40004A6")]
	[FieldOffset(Offset = "0xB0")]
	[SerializeField]
	private float lerpSpeed;
}
