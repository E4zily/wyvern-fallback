﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x020001AA RID: 426
	internal class AttributeAttribute : Attribute
	{
		// Token: 0x04000B6D RID: 2925
		public string Name;

		// Token: 0x04000B6E RID: 2926
		public string RVA;

		// Token: 0x04000B6F RID: 2927
		public string Offset;
	}
}
