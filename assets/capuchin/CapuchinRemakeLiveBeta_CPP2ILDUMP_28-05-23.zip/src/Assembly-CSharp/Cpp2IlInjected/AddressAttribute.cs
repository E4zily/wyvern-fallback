﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x020001A8 RID: 424
	internal class AddressAttribute : Attribute
	{
		// Token: 0x04000B68 RID: 2920
		public string RVA;

		// Token: 0x04000B69 RID: 2921
		public string Offset;

		// Token: 0x04000B6A RID: 2922
		public string VA;

		// Token: 0x04000B6B RID: 2923
		public string Slot;
	}
}
