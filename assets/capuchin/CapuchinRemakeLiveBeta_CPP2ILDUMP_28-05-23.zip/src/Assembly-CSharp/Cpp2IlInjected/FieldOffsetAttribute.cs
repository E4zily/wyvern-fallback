﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x020001A9 RID: 425
	internal class FieldOffsetAttribute : Attribute
	{
		// Token: 0x04000B6C RID: 2924
		public string Offset;
	}
}
