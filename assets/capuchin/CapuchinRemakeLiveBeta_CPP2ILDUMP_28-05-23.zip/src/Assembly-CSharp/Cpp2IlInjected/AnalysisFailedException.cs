﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x020001AD RID: 429
	internal class AnalysisFailedException : Exception
	{
		// Token: 0x06003D24 RID: 15652 RVA: 0x0000391B File Offset: 0x00001B1B
		public AnalysisFailedException(string message) : base(message)
		{
		}
	}
}
