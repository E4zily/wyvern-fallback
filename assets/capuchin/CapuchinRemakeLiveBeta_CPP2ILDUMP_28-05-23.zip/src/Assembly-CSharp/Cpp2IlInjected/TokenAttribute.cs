﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x020001AC RID: 428
	internal class TokenAttribute : Attribute
	{
		// Token: 0x04000B71 RID: 2929
		public string Token;
	}
}
