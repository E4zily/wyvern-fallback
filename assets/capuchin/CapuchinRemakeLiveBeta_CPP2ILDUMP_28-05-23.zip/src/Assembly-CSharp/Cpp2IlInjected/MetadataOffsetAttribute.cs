﻿using System;

namespace Cpp2IlInjected
{
	// Token: 0x020001AB RID: 427
	internal class MetadataOffsetAttribute : Attribute
	{
		// Token: 0x04000B70 RID: 2928
		public string Offset;
	}
}
