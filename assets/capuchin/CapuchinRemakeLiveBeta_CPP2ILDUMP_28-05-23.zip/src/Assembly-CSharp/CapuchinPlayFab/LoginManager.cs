﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using Oculus.Platform;
using Oculus.Platform.Models;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using PlayFab.ClientModels;
using TMPro;
using UnityEngine;

namespace CapuchinPlayFab
{
	// Token: 0x02000189 RID: 393
	[Token(Token = "0x2000189")]
	public class LoginManager : MonoBehaviourPunCallbacks
	{
		// Token: 0x06003C4F RID: 15439 RVA: 0x00075EAC File Offset: 0x000740AC
		[Address(RVA = "0x241D6B4", Offset = "0x241D6B4", VA = "0x241D6B4")]
		[Token(Token = "0x6003C4F")]
		private void method_0(GetPhotonAuthenticationTokenResult getPhotonAuthenticationTokenResult_0)
		{
			Debug.Log("Photon token acquired!");
			AuthenticationValues authValues = new AuthenticationValues();
			PhotonNetwork.AuthValues = authValues;
			new GetTitleNewsRequest();
			TextureSwap textureSwap = this.textureSwap_0;
			long enabled = 0L;
			textureSwap.enabled = (enabled != 0L);
			GameObject gameObject = this.gameObject_8;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_7;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			long displayName = 0L;
			PlayerPrefs.GetString("username");
			updateUserTitleDisplayNameRequest.DisplayName = displayName;
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
		}

		// Token: 0x06003C50 RID: 15440 RVA: 0x00075F5C File Offset: 0x0007415C
		[Address(RVA = "0x241DE4C", Offset = "0x241DE4C", VA = "0x241DE4C")]
		[Token(Token = "0x6003C50")]
		public void method_1()
		{
			PhotonNetwork.Disconnect();
		}

		// Token: 0x06003C51 RID: 15441 RVA: 0x00075F70 File Offset: 0x00074170
		[Address(RVA = "0x241DEA4", Offset = "0x241DEA4", VA = "0x241DEA4")]
		[Token(Token = "0x6003C51")]
		private void method_2(Message message_0)
		{
			bool isError = message_0.IsError;
			if (message_0 != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06003C52 RID: 15442 RVA: 0x00075F90 File Offset: 0x00074190
		[Address(RVA = "0x241E020", Offset = "0x241E020", VA = "0x241E020", Slot = "41")]
		[Token(Token = "0x6003C52")]
		public override void OnJoinedRoom()
		{
			Debug.Log("Joined a Room.");
			base.OnJoinedRoom();
			Photon.Realtime.Room currentRoom = PhotonNetwork.CurrentRoom;
			if (this.bool_3)
			{
				Photon.Realtime.Room currentRoom2 = PhotonNetwork.CurrentRoom;
			}
			RendererDisable rendererDisable = this.rendererDisable_0;
			long num = 1L;
			rendererDisable.bool_0 = (num != 0L);
			GameObject gameObject = this.gameObject_4;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			gameObject.SetActive(active2 != 0L);
		}

		// Token: 0x06003C53 RID: 15443 RVA: 0x00075FF8 File Offset: 0x000741F8
		[Token(Token = "0x6003C53")]
		[Address(RVA = "0x241E20C", Offset = "0x241E20C", VA = "0x241E20C")]
		public void Update()
		{
			bool flag;
			if (flag = this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				this.double_0 = (double)deltaTime;
			}
			if (flag)
			{
			}
			bool inRoom = PhotonNetwork.InRoom;
			NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
			if (networkPlayerSpawner.bool_0)
			{
				RendererDisable component = networkPlayerSpawner.gameObject_0.GetComponent<RendererDisable>();
				this.rendererDisable_0 = component;
				float deltaTime2 = Time.deltaTime;
			}
		}

		// Token: 0x06003C54 RID: 15444 RVA: 0x00076054 File Offset: 0x00074254
		[Token(Token = "0x6003C54")]
		[Address(RVA = "0x241E2F8", Offset = "0x241E2F8", VA = "0x241E2F8")]
		private void method_3(GetTitleDataResult getTitleDataResult_0)
		{
			Dictionary<string, string> data = getTitleDataResult_0.Data;
			this.string_4 = data;
			string version = UnityEngine.Application.version;
			string b = this.string_4;
			version != b;
			GameObject gameObject = this.gameObject_9;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003C55 RID: 15445 RVA: 0x00076098 File Offset: 0x00074298
		[Address(RVA = "0x241E77C", Offset = "0x241E77C", VA = "0x241E77C")]
		[CompilerGenerated]
		[Token(Token = "0x6003C55")]
		private void method_4(GetUserInventoryResult getUserInventoryResult_0)
		{
			List<ItemInstance> inventory = getUserInventoryResult_0.Inventory;
			this.list_0 = inventory;
			DynamicCosmetics.dynamicCosmetics_0.method_109();
		}

		// Token: 0x06003C56 RID: 15446 RVA: 0x000760C0 File Offset: 0x000742C0
		[Address(RVA = "0x241E7F8", Offset = "0x241E7F8", VA = "0x241E7F8")]
		[Token(Token = "0x6003C56")]
		private void method_5(GetUserInventoryResult getUserInventoryResult_0)
		{
			List<ItemInstance> inventory = getUserInventoryResult_0.Inventory;
			this.list_0 = inventory;
			DynamicCosmetics.dynamicCosmetics_0.method_18();
		}

		// Token: 0x06003C57 RID: 15447 RVA: 0x00075F70 File Offset: 0x00074170
		[Token(Token = "0x6003C57")]
		[Address(RVA = "0x241E874", Offset = "0x241E874", VA = "0x241E874")]
		private void method_6(Message message_0)
		{
			bool isError = message_0.IsError;
			if (message_0 != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06003C58 RID: 15448 RVA: 0x000760E8 File Offset: 0x000742E8
		[Address(RVA = "0x241E9F0", Offset = "0x241E9F0", VA = "0x241E9F0")]
		[Token(Token = "0x6003C58")]
		private void method_7(GetTitleDataResult getTitleDataResult_0)
		{
			Dictionary<string, string> data = getTitleDataResult_0.Data;
			this.string_4 = data;
			string version = UnityEngine.Application.version;
			string b = this.string_4;
			version != b;
			GameObject gameObject = this.gameObject_9;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003C59 RID: 15449 RVA: 0x0007612C File Offset: 0x0007432C
		[Token(Token = "0x6003C59")]
		[Address(RVA = "0x241EE68", Offset = "0x241EE68", VA = "0x241EE68")]
		public void method_8()
		{
			PhotonNetwork.Disconnect();
			this.method_12();
		}

		// Token: 0x06003C5A RID: 15450 RVA: 0x00003814 File Offset: 0x00001A14
		[Token(Token = "0x6003C5A")]
		[Address(RVA = "0x241EF28", Offset = "0x241EF28", VA = "0x241EF28")]
		private void method_9(PlayFabError playFabError_0)
		{
			Debug.LogError(playFabError_0.GenerateErrorReport());
		}

		// Token: 0x06003C5B RID: 15451 RVA: 0x00075F70 File Offset: 0x00074170
		[Address(RVA = "0x241EFA8", Offset = "0x241EFA8", VA = "0x241EFA8")]
		[Token(Token = "0x6003C5B")]
		private void method_10(Message message_0)
		{
			bool isError = message_0.IsError;
			if (message_0 != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06003C5C RID: 15452 RVA: 0x00076144 File Offset: 0x00074344
		[Token(Token = "0x6003C5C")]
		[Address(RVA = "0x241F124", Offset = "0x241F124", VA = "0x241F124")]
		private void method_11(LoginResult loginResult_0)
		{
			string playFabId = loginResult_0.PlayFabId;
			this.string_7 = playFabId;
			string appIdRealtime = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime;
		}

		// Token: 0x06003C5D RID: 15453 RVA: 0x00075F5C File Offset: 0x0007415C
		[Address(RVA = "0x241EED0", Offset = "0x241EED0", VA = "0x241EED0")]
		[Token(Token = "0x6003C5D")]
		public void method_12()
		{
			PhotonNetwork.Disconnect();
		}

		// Token: 0x06003C5E RID: 15454 RVA: 0x00076170 File Offset: 0x00074370
		[Address(RVA = "0x241F2E8", Offset = "0x241F2E8", VA = "0x241F2E8")]
		[Token(Token = "0x6003C5E")]
		private void method_13(GetUserInventoryResult getUserInventoryResult_0)
		{
			Debug.Log("Round end");
			Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
			this.Bananas = virtualCurrency;
		}

		// Token: 0x06003C5F RID: 15455 RVA: 0x00076198 File Offset: 0x00074398
		[Address(RVA = "0x241DDD4", Offset = "0x241DDD4", VA = "0x241DDD4")]
		[Token(Token = "0x6003C5F")]
		public IEnumerator method_14()
		{
			LoginManager.Class65 @class = new LoginManager.Class65((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003C60 RID: 15456 RVA: 0x000761C0 File Offset: 0x000743C0
		[Address(RVA = "0x241F69C", Offset = "0x241F69C", VA = "0x241F69C")]
		[Token(Token = "0x6003C60")]
		private void method_15(GetTitleNewsResult getTitleNewsResult_0)
		{
			getTitleNewsResult_0.News.GetEnumerator().MoveNext();
		}

		// Token: 0x06003C61 RID: 15457 RVA: 0x000761E0 File Offset: 0x000743E0
		[Address(RVA = "0x241F7FC", Offset = "0x241F7FC", VA = "0x241F7FC")]
		[Token(Token = "0x6003C61")]
		private void method_16(PlayFabError playFabError_0)
		{
			Debug.Log(playFabError_0);
			Debug.Log("PLAYER IS BANNED");
			Debug.Log(playFabError_0.GenerateErrorReport());
			ThrowHelper.ThrowArgumentOutOfRangeException();
			DateTime d;
			double totalHours = (DateTime.Now - d).TotalHours;
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_1 = (num != 0L);
			this.double_0 = totalHours;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003C62 RID: 15458 RVA: 0x00076248 File Offset: 0x00074448
		[Address(RVA = "0x2420188", Offset = "0x2420188", VA = "0x2420188")]
		[Token(Token = "0x6003C62")]
		private void method_17(Message<User> message_0)
		{
			Request<OrgScopedID> request;
			Message<OrgScopedID>.Callback callback;
			request.OnComplete(callback);
		}

		// Token: 0x06003C63 RID: 15459 RVA: 0x00076274 File Offset: 0x00074474
		[Address(RVA = "0x2420318", Offset = "0x2420318", VA = "0x2420318")]
		[Token(Token = "0x6003C63")]
		private void method_18(LoginResult loginResult_0)
		{
			string playFabId = loginResult_0.PlayFabId;
			this.string_7 = playFabId;
			GetPhotonAuthenticationTokenRequest getPhotonAuthenticationTokenRequest = new GetPhotonAuthenticationTokenRequest();
			string appIdRealtime = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime;
			getPhotonAuthenticationTokenRequest.PhotonApplicationId = appIdRealtime;
		}

		// Token: 0x06003C64 RID: 15460 RVA: 0x000762AC File Offset: 0x000744AC
		[Address(RVA = "0x24204DC", Offset = "0x24204DC", VA = "0x24204DC")]
		[Token(Token = "0x6003C64")]
		private void method_19(GetUserInventoryResult getUserInventoryResult_0)
		{
			Debug.Log("Update User Inventory");
			Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
			this.Bananas = virtualCurrency;
		}

		// Token: 0x06003C65 RID: 15461 RVA: 0x000762D4 File Offset: 0x000744D4
		[Address(RVA = "0x241DB60", Offset = "0x241DB60", VA = "0x241DB60")]
		[Token(Token = "0x6003C65")]
		public void method_20()
		{
			new GetUserInventoryRequest();
			if (LoginManager.<>c.<>9__59_1 == null)
			{
				Action<PlayFabError> <>9__59_;
				LoginManager.<>c.<>9__59_1 = <>9__59_;
			}
		}

		// Token: 0x06003C66 RID: 15462 RVA: 0x000762F4 File Offset: 0x000744F4
		[Address(RVA = "0x24208A8", Offset = "0x24208A8", VA = "0x24208A8")]
		[Token(Token = "0x6003C66")]
		private void method_21(PlayFabError playFabError_0)
		{
			playFabError_0.GenerateErrorReport();
			Debug.LogError(playFabError_0);
		}

		// Token: 0x06003C67 RID: 15463 RVA: 0x00076310 File Offset: 0x00074510
		[Token(Token = "0x6003C67")]
		[Address(RVA = "0x2420928", Offset = "0x2420928", VA = "0x2420928")]
		[CompilerGenerated]
		private void method_22(GetTitleDataResult getTitleDataResult_0)
		{
			Dictionary<string, string> data = getTitleDataResult_0.Data;
			this.string_4 = data;
			string version = UnityEngine.Application.version;
			string b = this.string_4;
			version != b;
			GameObject gameObject = this.gameObject_9;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003C68 RID: 15464 RVA: 0x000761C0 File Offset: 0x000743C0
		[Address(RVA = "0x2420D80", Offset = "0x2420D80", VA = "0x2420D80")]
		[Token(Token = "0x6003C68")]
		private void method_23(GetTitleNewsResult getTitleNewsResult_0)
		{
			getTitleNewsResult_0.News.GetEnumerator().MoveNext();
		}

		// Token: 0x06003C69 RID: 15465 RVA: 0x00076354 File Offset: 0x00074554
		[Token(Token = "0x6003C69")]
		[Address(RVA = "0x2420EE0", Offset = "0x2420EE0", VA = "0x2420EE0")]
		private void method_24(ulong ulong_2, ulong ulong_3, string string_8)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string str;
			string customId = "CapuchinStore" + str;
			loginWithCustomIDRequest.CustomId = customId;
			Dictionary<string, string> customTags;
			loginWithCustomIDRequest.CustomTags = customTags;
			BuyCosmetic[] array = UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
			this.buyCosmetic_0 = array;
		}

		// Token: 0x06003C6A RID: 15466 RVA: 0x00076394 File Offset: 0x00074594
		[Token(Token = "0x6003C6A")]
		[Address(RVA = "0x24211DC", Offset = "0x24211DC", VA = "0x24211DC")]
		public void method_25()
		{
			GetTitleDataRequest getTitleDataRequest = new GetTitleDataRequest();
			List<string> keys = new List();
			getTitleDataRequest.Keys = keys;
			if (LoginManager.<>c.<>9__56_1 == null)
			{
				Action<PlayFabError> <>9__56_;
				LoginManager.<>c.<>9__56_1 = <>9__56_;
			}
		}

		// Token: 0x06003C6B RID: 15467 RVA: 0x000763C4 File Offset: 0x000745C4
		[Address(RVA = "0x2421438", Offset = "0x2421438", VA = "0x2421438", Slot = "45")]
		[Token(Token = "0x6003C6B")]
		public override void OnConnectedToMaster()
		{
			Debug.Log("Connected to Server.");
			PhotonNetwork.JoinLobby();
		}

		// Token: 0x06003C6C RID: 15468 RVA: 0x000763E4 File Offset: 0x000745E4
		[Address(RVA = "0x24214E0", Offset = "0x24214E0", VA = "0x24214E0")]
		[Token(Token = "0x6003C6C")]
		public void method_26()
		{
			PhotonNetwork.ConnectUsingSettings();
			Debug.Log(". Please update you game to the latest version");
		}

		// Token: 0x06003C6D RID: 15469 RVA: 0x00075F70 File Offset: 0x00074170
		[Token(Token = "0x6003C6D")]
		[Address(RVA = "0x2421588", Offset = "0x2421588", VA = "0x2421588")]
		private void method_27(Message message_0)
		{
			bool isError = message_0.IsError;
			if (message_0 != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06003C6E RID: 15470 RVA: 0x00076248 File Offset: 0x00074448
		[Token(Token = "0x6003C6E")]
		[Address(RVA = "0x2421704", Offset = "0x2421704", VA = "0x2421704")]
		private void method_28(Message<User> message_0)
		{
			Request<OrgScopedID> request;
			Message<OrgScopedID>.Callback callback;
			request.OnComplete(callback);
		}

		// Token: 0x06003C6F RID: 15471 RVA: 0x00076404 File Offset: 0x00074604
		[Token(Token = "0x6003C6F")]
		[Address(RVA = "0x2421894", Offset = "0x2421894", VA = "0x2421894")]
		private void method_29(ulong ulong_2, ulong ulong_3, string string_8)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string text;
			"Grip" + text;
			loginWithCustomIDRequest.CustomId = text;
			Dictionary<string, string> customTags;
			loginWithCustomIDRequest.CustomTags = customTags;
			BuyCosmetic[] array = UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
			this.buyCosmetic_0 = array;
		}

		// Token: 0x06003C70 RID: 15472 RVA: 0x00076440 File Offset: 0x00074640
		[Token(Token = "0x6003C70")]
		[Address(RVA = "0x2421B90", Offset = "0x2421B90", VA = "0x2421B90")]
		public void method_30()
		{
			PhotonNetwork.ConnectUsingSettings();
			Debug.Log("\n Time: ");
		}

		// Token: 0x06003C71 RID: 15473 RVA: 0x00076460 File Offset: 0x00074660
		[Token(Token = "0x6003C71")]
		[Address(RVA = "0x2421C38", Offset = "0x2421C38", VA = "0x2421C38")]
		private void method_31(GetPhotonAuthenticationTokenResult getPhotonAuthenticationTokenResult_0)
		{
			Debug.Log("You Already Own This Item");
			AuthenticationValues authValues = new AuthenticationValues();
			PhotonNetwork.AuthValues = authValues;
			new GetTitleNewsRequest();
			TextureSwap textureSwap = this.textureSwap_0;
			long enabled = 0L;
			textureSwap.enabled = (enabled != 0L);
			GameObject gameObject = this.gameObject_8;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_7;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			this.method_20();
			this.method_30();
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				return;
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_;
				LoginManager.<>c.<>9__49_1 = <>9__49_;
			}
		}

		// Token: 0x06003C72 RID: 15474 RVA: 0x00076518 File Offset: 0x00074718
		[Token(Token = "0x6003C72")]
		[Address(RVA = "0x24220F8", Offset = "0x24220F8", VA = "0x24220F8")]
		private void method_32(GetTitleDataResult getTitleDataResult_0)
		{
			Dictionary<string, string> data = getTitleDataResult_0.Data;
			this.string_4 = data;
			string version = UnityEngine.Application.version;
			string b = this.string_4;
			version != b;
			GameObject gameObject = this.gameObject_9;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003C73 RID: 15475 RVA: 0x0007655C File Offset: 0x0007475C
		[Token(Token = "0x6003C73")]
		[Address(RVA = "0x24225E0", Offset = "0x24225E0", VA = "0x24225E0", Slot = "31")]
		public override void OnLeftRoom()
		{
			base.OnLeftRoom();
			GameObject gameObject = this.gameObject_4;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_5;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			if (this.rendererDisable_0 != null)
			{
			}
			Photon.Realtime.Room currentRoom = PhotonNetwork.CurrentRoom;
			if (currentRoom != null)
			{
			}
			Debug.Log("Left a room");
			if (this.bool_3)
			{
				Photon.Realtime.Room currentRoom2 = PhotonNetwork.CurrentRoom;
			}
		}

		// Token: 0x06003C74 RID: 15476 RVA: 0x000765BC File Offset: 0x000747BC
		[Token(Token = "0x6003C74")]
		[Address(RVA = "0x24227B4", Offset = "0x24227B4", VA = "0x24227B4")]
		private void method_33(GetTitleDataResult getTitleDataResult_0)
		{
			Dictionary<string, string> data = getTitleDataResult_0.Data;
			this.string_4 = data;
			string version = UnityEngine.Application.version;
			string b = this.string_4;
			version != b;
			GameObject gameObject = this.gameObject_9;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003C75 RID: 15477 RVA: 0x00003821 File Offset: 0x00001A21
		[Address(RVA = "0x2422C40", Offset = "0x2422C40", VA = "0x2422C40")]
		[Token(Token = "0x6003C75")]
		public void method_34()
		{
			LoginManager.loginManager_0 = this;
			this.method_57();
		}

		// Token: 0x06003C76 RID: 15478 RVA: 0x00076600 File Offset: 0x00074800
		[Token(Token = "0x6003C76")]
		[Address(RVA = "0x2422EAC", Offset = "0x2422EAC", VA = "0x2422EAC")]
		private void method_35(Message message_0)
		{
			bool isError = message_0.IsError;
			if (message_0 != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06003C77 RID: 15479 RVA: 0x00076620 File Offset: 0x00074820
		[Token(Token = "0x6003C77")]
		[Address(RVA = "0x2423028", Offset = "0x2423028", VA = "0x2423028")]
		public LoginManager()
		{
			long num = 1L;
			this.bool_2 = (num != 0L);
			base..ctor();
		}

		// Token: 0x06003C78 RID: 15480 RVA: 0x00076394 File Offset: 0x00074594
		[Token(Token = "0x6003C78")]
		[Address(RVA = "0x2423038", Offset = "0x2423038", VA = "0x2423038")]
		public void method_36()
		{
			GetTitleDataRequest getTitleDataRequest = new GetTitleDataRequest();
			List<string> keys = new List();
			getTitleDataRequest.Keys = keys;
			if (LoginManager.<>c.<>9__56_1 == null)
			{
				Action<PlayFabError> <>9__56_;
				LoginManager.<>c.<>9__56_1 = <>9__56_;
			}
		}

		// Token: 0x06003C79 RID: 15481 RVA: 0x0007663C File Offset: 0x0007483C
		[Token(Token = "0x6003C79")]
		[Address(RVA = "0x2423294", Offset = "0x2423294", VA = "0x2423294")]
		private void method_37(PlayFabError playFabError_0)
		{
			Debug.Log(playFabError_0);
			if (this.buyCosmetic_0 == null)
			{
				return;
			}
			Debug.Log("Network Player");
			Debug.Log(playFabError_0.GenerateErrorReport());
			ThrowHelper.ThrowArgumentOutOfRangeException();
			DateTime d = DateTime.Parse("XRI.SelectExit");
			double totalHours = (DateTime.Now - d).TotalHours;
			GameObject gameObject = this.gameObject_0;
			this.double_0 = totalHours;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003C7A RID: 15482 RVA: 0x000766B0 File Offset: 0x000748B0
		[Address(RVA = "0x2423C54", Offset = "0x2423C54", VA = "0x2423C54")]
		[Token(Token = "0x6003C7A")]
		private void method_38(GetPhotonAuthenticationTokenResult getPhotonAuthenticationTokenResult_0)
		{
			Debug.Log("gravThing");
			AuthenticationValues authValues = new AuthenticationValues();
			PhotonNetwork.AuthValues = authValues;
			new GetTitleNewsRequest();
			TextureSwap textureSwap = this.textureSwap_0;
			long enabled = 1L;
			textureSwap.enabled = (enabled != 0L);
			GameObject gameObject = this.gameObject_8;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_7;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			this.method_20();
			this.method_63();
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("deathScream");
			this.textMeshPro_0 = @string;
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			Action<PlayFabError> <>9__49_2;
			LoginManager.<>c.<>9__49_1 = <>9__49_2;
		}

		// Token: 0x06003C7B RID: 15483 RVA: 0x00076764 File Offset: 0x00074964
		[Address(RVA = "0x2424114", Offset = "0x2424114", VA = "0x2424114")]
		[Token(Token = "0x6003C7B")]
		private void method_39(GetPhotonAuthenticationTokenResult getPhotonAuthenticationTokenResult_0)
		{
			Debug.Log(" and the correct version is ");
			AuthenticationValues authValues = new AuthenticationValues();
			PhotonNetwork.AuthValues = authValues;
			new GetTitleNewsRequest();
			TextureSwap textureSwap = this.textureSwap_0;
			long enabled = 1L;
			textureSwap.enabled = (enabled != 0L);
			GameObject gameObject = this.gameObject_8;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_7;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			this.method_20();
			this.method_30();
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			string displayName;
			new UpdateUserTitleDisplayNameRequest().DisplayName = displayName;
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
		}

		// Token: 0x06003C7C RID: 15484 RVA: 0x00076810 File Offset: 0x00074A10
		[Address(RVA = "0x24245D4", Offset = "0x24245D4", VA = "0x24245D4")]
		[Token(Token = "0x6003C7C")]
		public void method_40()
		{
			new List();
			if (LoginManager.<>c.<>9__56_1 == null)
			{
				Action<PlayFabError> <>9__56_;
				LoginManager.<>c.<>9__56_1 = <>9__56_;
			}
		}

		// Token: 0x06003C7D RID: 15485 RVA: 0x00002207 File Offset: 0x00000407
		[Token(Token = "0x6003C7D")]
		[Address(RVA = "0x2424830", Offset = "0x2424830", VA = "0x2424830", Slot = "43")]
		public override void OnPlayerLeftRoom(Player otherPlayer)
		{
			Debug.Log("A Player has left the Room.");
			base.OnPlayerLeftRoom(otherPlayer);
		}

		// Token: 0x06003C7E RID: 15486 RVA: 0x00076274 File Offset: 0x00074474
		[Token(Token = "0x6003C7E")]
		[Address(RVA = "0x24248C4", Offset = "0x24248C4", VA = "0x24248C4")]
		private void method_41(LoginResult loginResult_0)
		{
			string playFabId = loginResult_0.PlayFabId;
			this.string_7 = playFabId;
			GetPhotonAuthenticationTokenRequest getPhotonAuthenticationTokenRequest = new GetPhotonAuthenticationTokenRequest();
			string appIdRealtime = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime;
			getPhotonAuthenticationTokenRequest.PhotonApplicationId = appIdRealtime;
		}

		// Token: 0x06003C7F RID: 15487 RVA: 0x00076830 File Offset: 0x00074A30
		[Token(Token = "0x6003C7F")]
		[Address(RVA = "0x2424A88", Offset = "0x2424A88", VA = "0x2424A88")]
		public void method_42()
		{
			new LoginManager.<>c();
			if (LoginManager.<>c.<>9__59_1 == null)
			{
				Action<PlayFabError> <>9__59_;
				LoginManager.<>c.<>9__59_1 = <>9__59_;
			}
		}

		// Token: 0x06003C80 RID: 15488 RVA: 0x0003F26C File Offset: 0x0003D46C
		[Token(Token = "0x6003C80")]
		[Address(RVA = "0x2424C54", Offset = "0x2424C54", VA = "0x2424C54")]
		public void method_43()
		{
			new GetUserInventoryRequest();
		}

		// Token: 0x06003C81 RID: 15489 RVA: 0x00076248 File Offset: 0x00074448
		[Address(RVA = "0x2424DA8", Offset = "0x2424DA8", VA = "0x2424DA8")]
		[Token(Token = "0x6003C81")]
		private void method_44(Message<User> message_0)
		{
			Request<OrgScopedID> request;
			Message<OrgScopedID>.Callback callback;
			request.OnComplete(callback);
		}

		// Token: 0x06003C82 RID: 15490 RVA: 0x000021F4 File Offset: 0x000003F4
		[Token(Token = "0x6003C82")]
		[Address(RVA = "0x2424F38", Offset = "0x2424F38", VA = "0x2424F38", Slot = "42")]
		public override void OnPlayerEnteredRoom(Player newPlayer)
		{
			Debug.Log("A new Player joined a Room.");
			base.OnPlayerEnteredRoom(newPlayer);
		}

		// Token: 0x06003C83 RID: 15491 RVA: 0x00076850 File Offset: 0x00074A50
		[Address(RVA = "0x2424FCC", Offset = "0x2424FCC", VA = "0x2424FCC")]
		[Token(Token = "0x6003C83")]
		private void method_45(ulong ulong_2, ulong ulong_3, string string_8)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string str;
			string customId = "META" + str;
			loginWithCustomIDRequest.CustomId = customId;
			Dictionary<string, string> customTags;
			loginWithCustomIDRequest.CustomTags = customTags;
			UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
		}

		// Token: 0x06003C84 RID: 15492 RVA: 0x00076888 File Offset: 0x00074A88
		[Address(RVA = "0x24252C8", Offset = "0x24252C8", VA = "0x24252C8")]
		[Token(Token = "0x6003C84")]
		public void method_46()
		{
			if (this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				this.double_0 = (double)deltaTime;
			}
			bool inRoom = PhotonNetwork.InRoom;
			NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
			if (networkPlayerSpawner.bool_0)
			{
				RendererDisable component = networkPlayerSpawner.gameObject_0.GetComponent<RendererDisable>();
				this.rendererDisable_0 = component;
				float deltaTime2 = Time.deltaTime;
			}
		}

		// Token: 0x06003C85 RID: 15493 RVA: 0x000768E0 File Offset: 0x00074AE0
		[Address(RVA = "0x24253B4", Offset = "0x24253B4", VA = "0x24253B4")]
		[Token(Token = "0x6003C85")]
		private void method_47(GetPhotonAuthenticationTokenResult getPhotonAuthenticationTokenResult_0)
		{
			Debug.Log("CapuchinRemade");
			AuthenticationValues authValues = new AuthenticationValues();
			PhotonNetwork.AuthValues = authValues;
			new GetTitleNewsRequest();
			TextureSwap textureSwap = this.textureSwap_0;
			long enabled = 0L;
			textureSwap.enabled = (enabled != 0L);
			GameObject gameObject = this.gameObject_8;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_7;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			this.method_42();
			this.method_26();
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("PRESS AGAIN TO CONFIRM");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
		}

		// Token: 0x06003C86 RID: 15494 RVA: 0x000761C0 File Offset: 0x000743C0
		[Address(RVA = "0x2425874", Offset = "0x2425874", VA = "0x2425874")]
		[Token(Token = "0x6003C86")]
		private void method_48(GetTitleNewsResult getTitleNewsResult_0)
		{
			getTitleNewsResult_0.News.GetEnumerator().MoveNext();
		}

		// Token: 0x06003C87 RID: 15495 RVA: 0x0000382F File Offset: 0x00001A2F
		[Token(Token = "0x6003C87")]
		[Address(RVA = "0x24259D4", Offset = "0x24259D4", VA = "0x24259D4")]
		public void Awake()
		{
			this.method_57();
		}

		// Token: 0x06003C88 RID: 15496 RVA: 0x0003F258 File Offset: 0x0003D458
		[Address(RVA = "0x2425A30", Offset = "0x2425A30", VA = "0x2425A30")]
		[Token(Token = "0x6003C88")]
		public void method_49()
		{
			new GetUserInventoryRequest();
		}

		// Token: 0x06003C89 RID: 15497 RVA: 0x00075F70 File Offset: 0x00074170
		[Token(Token = "0x6003C89")]
		[Address(RVA = "0x2425B84", Offset = "0x2425B84", VA = "0x2425B84")]
		private void method_50(Message message_0)
		{
			bool isError = message_0.IsError;
			if (message_0 != null)
			{
				return;
			}
			string message;
			Debug.LogError(message);
		}

		// Token: 0x06003C8A RID: 15498 RVA: 0x00076248 File Offset: 0x00074448
		[CompilerGenerated]
		[Address(RVA = "0x2425D00", Offset = "0x2425D00", VA = "0x2425D00")]
		[Token(Token = "0x6003C8A")]
		private void method_51(Message<User> message_0)
		{
			Request<OrgScopedID> request;
			Message<OrgScopedID>.Callback callback;
			request.OnComplete(callback);
		}

		// Token: 0x06003C8B RID: 15499 RVA: 0x0007699C File Offset: 0x00074B9C
		[Token(Token = "0x6003C8B")]
		[Address(RVA = "0x2425E98", Offset = "0x2425E98", VA = "0x2425E98")]
		private void method_52(GetUserInventoryResult getUserInventoryResult_0)
		{
			List<ItemInstance> inventory = getUserInventoryResult_0.Inventory;
			this.list_0 = inventory;
			DynamicCosmetics.dynamicCosmetics_0.method_149();
		}

		// Token: 0x06003C8C RID: 15500 RVA: 0x00003814 File Offset: 0x00001A14
		[Address(RVA = "0x2425F14", Offset = "0x2425F14", VA = "0x2425F14")]
		[Token(Token = "0x6003C8C")]
		private void method_53(PlayFabError playFabError_0)
		{
			Debug.LogError(playFabError_0.GenerateErrorReport());
		}

		// Token: 0x06003C8D RID: 15501 RVA: 0x000769C4 File Offset: 0x00074BC4
		[Token(Token = "0x6003C8D")]
		[Address(RVA = "0x2425F94", Offset = "0x2425F94", VA = "0x2425F94")]
		private void method_54(GetUserInventoryResult getUserInventoryResult_0)
		{
			Debug.Log("Failed to login, please restart");
			Dictionary<string, int> virtualCurrency = getUserInventoryResult_0.VirtualCurrency;
			this.Bananas = virtualCurrency;
		}

		// Token: 0x06003C8E RID: 15502 RVA: 0x000769EC File Offset: 0x00074BEC
		[Address(RVA = "0x2426364", Offset = "0x2426364", VA = "0x2426364")]
		[Token(Token = "0x6003C8E")]
		private void method_55(GetPhotonAuthenticationTokenResult getPhotonAuthenticationTokenResult_0)
		{
			Debug.Log("lava");
			AuthenticationValues authenticationValues = new AuthenticationValues();
			long authType = 1L;
			authenticationValues.authType = (CustomAuthenticationType)authType;
			PhotonNetwork.AuthValues = authenticationValues;
			new GetTitleNewsRequest();
			TextureSwap textureSwap = this.textureSwap_0;
			long enabled = 1L;
			textureSwap.enabled = (enabled != 0L);
			GameObject gameObject = this.gameObject_8;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_7;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			this.method_56();
			this.method_63();
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("Vector1_d371bd24217449349bd747533d51af6b");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
		}

		// Token: 0x06003C8F RID: 15503 RVA: 0x000762D4 File Offset: 0x000744D4
		[Token(Token = "0x6003C8F")]
		[Address(RVA = "0x2426828", Offset = "0x2426828", VA = "0x2426828")]
		public void method_56()
		{
			new GetUserInventoryRequest();
			if (LoginManager.<>c.<>9__59_1 == null)
			{
				Action<PlayFabError> <>9__59_;
				LoginManager.<>c.<>9__59_1 = <>9__59_;
			}
		}

		// Token: 0x06003C90 RID: 15504 RVA: 0x00076AB0 File Offset: 0x00074CB0
		[Token(Token = "0x6003C90")]
		[Address(RVA = "0x2422C9C", Offset = "0x2422C9C", VA = "0x2422C9C")]
		public void method_57()
		{
			Debug.Log("Trying Getting Entilement...");
			Message.Callback callback;
			Entitlements.IsUserEntitledToApplication().OnComplete(callback);
		}

		// Token: 0x06003C91 RID: 15505 RVA: 0x00076AD4 File Offset: 0x00074CD4
		[Token(Token = "0x6003C91")]
		[Address(RVA = "0x24269F4", Offset = "0x24269F4", VA = "0x24269F4")]
		private void method_58(GetPhotonAuthenticationTokenResult getPhotonAuthenticationTokenResult_0)
		{
			Debug.Log("PRESS AGAIN TO CONFIRM");
			AuthenticationValues authValues = new AuthenticationValues();
			PhotonNetwork.AuthValues = authValues;
			new GetTitleNewsRequest();
			TextureSwap textureSwap = this.textureSwap_0;
			long num = 0L;
			textureSwap.enabled = (num != 0L);
			this.gameObject_8.SetActive(num != 0L);
			GameObject gameObject = this.gameObject_7;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			this.method_42();
			this.method_30();
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("Grip");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
		}

		// Token: 0x06003C92 RID: 15506 RVA: 0x00075F5C File Offset: 0x0007415C
		[Token(Token = "0x6003C92")]
		[Address(RVA = "0x2422588", Offset = "0x2422588", VA = "0x2422588")]
		public void method_59()
		{
			PhotonNetwork.Disconnect();
		}

		// Token: 0x06003C93 RID: 15507 RVA: 0x000761C0 File Offset: 0x000743C0
		[Address(RVA = "0x2426EB4", Offset = "0x2426EB4", VA = "0x2426EB4")]
		[Token(Token = "0x6003C93")]
		private void method_60(GetTitleNewsResult getTitleNewsResult_0)
		{
			getTitleNewsResult_0.News.GetEnumerator().MoveNext();
		}

		// Token: 0x06003C94 RID: 15508 RVA: 0x00076B88 File Offset: 0x00074D88
		[Address(RVA = "0x2427014", Offset = "0x2427014", VA = "0x2427014")]
		[Token(Token = "0x6003C94")]
		private void method_61(GetPhotonAuthenticationTokenResult getPhotonAuthenticationTokenResult_0)
		{
			Debug.Log("Player");
			AuthenticationValues authValues = new AuthenticationValues();
			PhotonNetwork.AuthValues = authValues;
			new GetTitleNewsRequest();
			TextureSwap textureSwap = this.textureSwap_0;
			long enabled = 1L;
			textureSwap.enabled = (enabled != 0L);
			GameObject gameObject = this.gameObject_8;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_7;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			this.method_56();
			this.method_26();
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("HorrorAgreement");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if (LoginManager.<>c.<>9__49_0 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__49_;
				LoginManager.<>c.<>9__49_0 = <>9__49_;
			}
			if (LoginManager.<>c.<>9__49_1 == null)
			{
				Action<PlayFabError> <>9__49_2;
				LoginManager.<>c.<>9__49_1 = <>9__49_2;
			}
		}

		// Token: 0x06003C95 RID: 15509 RVA: 0x00076C44 File Offset: 0x00074E44
		[Token(Token = "0x6003C95")]
		[Address(RVA = "0x24274D4", Offset = "0x24274D4", VA = "0x24274D4")]
		public void method_62()
		{
		}

		// Token: 0x06003C96 RID: 15510 RVA: 0x00011AA0 File Offset: 0x0000FCA0
		[Token(Token = "0x6003C96")]
		[Address(RVA = "0x241DD2C", Offset = "0x241DD2C", VA = "0x241DD2C")]
		public void method_63()
		{
			PhotonNetwork.ConnectUsingSettings();
			Debug.Log("Try Connect To Server...");
		}

		// Token: 0x06003C97 RID: 15511 RVA: 0x00076C54 File Offset: 0x00074E54
		[Address(RVA = "0x2427628", Offset = "0x2427628", VA = "0x2427628")]
		[Token(Token = "0x6003C97")]
		private void method_64(ulong ulong_2, ulong ulong_3, string string_8)
		{
			LoginWithCustomIDRequest loginWithCustomIDRequest = new LoginWithCustomIDRequest();
			string str;
			string customId = "jump char false" + str;
			loginWithCustomIDRequest.CustomId = customId;
			BuyCosmetic[] array = UnityEngine.Object.FindObjectsOfType<BuyCosmetic>();
			this.buyCosmetic_0 = array;
		}

		// Token: 0x04000ABA RID: 2746
		[Token(Token = "0x4000ABA")]
		public static LoginManager loginManager_0;

		// Token: 0x04000ABB RID: 2747
		[Token(Token = "0x4000ABB")]
		[FieldOffset(Offset = "0x20")]
		public TextMeshPro textMeshPro_0;

		// Token: 0x04000ABC RID: 2748
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000ABC")]
		public string string_0;

		// Token: 0x04000ABD RID: 2749
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000ABD")]
		public bool bool_0;

		// Token: 0x04000ABE RID: 2750
		[Token(Token = "0x4000ABE")]
		[FieldOffset(Offset = "0x38")]
		private string string_1;

		// Token: 0x04000ABF RID: 2751
		[Token(Token = "0x4000ABF")]
		[FieldOffset(Offset = "0x40")]
		public Transform transform_0;

		// Token: 0x04000AC0 RID: 2752
		[Token(Token = "0x4000AC0")]
		[FieldOffset(Offset = "0x48")]
		public Transform transform_1;

		// Token: 0x04000AC1 RID: 2753
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000AC1")]
		public TextMeshPro textMeshPro_1;

		// Token: 0x04000AC2 RID: 2754
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000AC2")]
		public GameObject gameObject_0;

		// Token: 0x04000AC3 RID: 2755
		[Token(Token = "0x4000AC3")]
		[FieldOffset(Offset = "0x60")]
		public GameObject gameObject_1;

		// Token: 0x04000AC4 RID: 2756
		[Token(Token = "0x4000AC4")]
		[FieldOffset(Offset = "0x68")]
		public GameObject gameObject_2;

		// Token: 0x04000AC5 RID: 2757
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x4000AC5")]
		public GameObject gameObject_3;

		// Token: 0x04000AC6 RID: 2758
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x4000AC6")]
		private bool bool_1;

		// Token: 0x04000AC7 RID: 2759
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x4000AC7")]
		private double double_0;

		// Token: 0x04000AC8 RID: 2760
		[FieldOffset(Offset = "0x88")]
		[Token(Token = "0x4000AC8")]
		public TextMeshPro textMeshPro_2;

		// Token: 0x04000AC9 RID: 2761
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000AC9")]
		public TextMeshPro textMeshPro_3;

		// Token: 0x04000ACA RID: 2762
		[SerializeField]
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x4000ACA")]
		public int Bananas;

		// Token: 0x04000ACB RID: 2763
		[FieldOffset(Offset = "0x9C")]
		[Token(Token = "0x4000ACB")]
		[SerializeField]
		public int Pebbles;

		// Token: 0x04000ACC RID: 2764
		[Token(Token = "0x4000ACC")]
		[FieldOffset(Offset = "0xA0")]
		private BuyCosmetic[] buyCosmetic_0;

		// Token: 0x04000ACD RID: 2765
		[FieldOffset(Offset = "0xA8")]
		[Token(Token = "0x4000ACD")]
		private bool bool_2;

		// Token: 0x04000ACE RID: 2766
		[Token(Token = "0x4000ACE")]
		[FieldOffset(Offset = "0xB0")]
		public string string_2;

		// Token: 0x04000ACF RID: 2767
		[FieldOffset(Offset = "0xB8")]
		[Token(Token = "0x4000ACF")]
		public string string_3;

		// Token: 0x04000AD0 RID: 2768
		[Token(Token = "0x4000AD0")]
		[FieldOffset(Offset = "0xC0")]
		public GameObject gameObject_4;

		// Token: 0x04000AD1 RID: 2769
		[FieldOffset(Offset = "0xC8")]
		[Token(Token = "0x4000AD1")]
		public GameObject gameObject_5;

		// Token: 0x04000AD2 RID: 2770
		[FieldOffset(Offset = "0xD0")]
		[Token(Token = "0x4000AD2")]
		public RendererDisable rendererDisable_0;

		// Token: 0x04000AD3 RID: 2771
		[Token(Token = "0x4000AD3")]
		[FieldOffset(Offset = "0xD8")]
		public NetworkPlayerSpawner networkPlayerSpawner_0;

		// Token: 0x04000AD4 RID: 2772
		[FieldOffset(Offset = "0xE0")]
		[Token(Token = "0x4000AD4")]
		private float float_0;

		// Token: 0x04000AD5 RID: 2773
		[Token(Token = "0x4000AD5")]
		[FieldOffset(Offset = "0xE8")]
		public GameObject gameObject_6;

		// Token: 0x04000AD6 RID: 2774
		[Token(Token = "0x4000AD6")]
		[FieldOffset(Offset = "0xF0")]
		public Material material_0;

		// Token: 0x04000AD7 RID: 2775
		[Token(Token = "0x4000AD7")]
		[FieldOffset(Offset = "0xF8")]
		public Texture2D texture2D_0;

		// Token: 0x04000AD8 RID: 2776
		[Token(Token = "0x4000AD8")]
		[FieldOffset(Offset = "0x100")]
		public GameObject gameObject_7;

		// Token: 0x04000AD9 RID: 2777
		[FieldOffset(Offset = "0x108")]
		[Token(Token = "0x4000AD9")]
		public GameObject gameObject_8;

		// Token: 0x04000ADA RID: 2778
		[FieldOffset(Offset = "0x110")]
		[Token(Token = "0x4000ADA")]
		public TextureSwap textureSwap_0;

		// Token: 0x04000ADB RID: 2779
		[FieldOffset(Offset = "0x118")]
		[Token(Token = "0x4000ADB")]
		public ulong ulong_0;

		// Token: 0x04000ADC RID: 2780
		[FieldOffset(Offset = "0x120")]
		[Token(Token = "0x4000ADC")]
		public ulong ulong_1;

		// Token: 0x04000ADD RID: 2781
		[Token(Token = "0x4000ADD")]
		[FieldOffset(Offset = "0x128")]
		public string string_4;

		// Token: 0x04000ADE RID: 2782
		[Token(Token = "0x4000ADE")]
		[FieldOffset(Offset = "0x130")]
		public GameObject gameObject_9;

		// Token: 0x04000ADF RID: 2783
		[FieldOffset(Offset = "0x138")]
		[Token(Token = "0x4000ADF")]
		public TextMeshPro textMeshPro_4;

		// Token: 0x04000AE0 RID: 2784
		[FieldOffset(Offset = "0x140")]
		[Token(Token = "0x4000AE0")]
		public string string_5;

		// Token: 0x04000AE1 RID: 2785
		[FieldOffset(Offset = "0x148")]
		[Token(Token = "0x4000AE1")]
		public string string_6;

		// Token: 0x04000AE2 RID: 2786
		[Token(Token = "0x4000AE2")]
		[FieldOffset(Offset = "0x150")]
		public openMenu openMenu_0;

		// Token: 0x04000AE3 RID: 2787
		[FieldOffset(Offset = "0x158")]
		[Token(Token = "0x4000AE3")]
		public bool bool_3;

		// Token: 0x04000AE4 RID: 2788
		[Token(Token = "0x4000AE4")]
		[FieldOffset(Offset = "0x160")]
		private string string_7;

		// Token: 0x04000AE5 RID: 2789
		[Token(Token = "0x4000AE5")]
		[FieldOffset(Offset = "0x168")]
		public List<ItemInstance> list_0;

		// Token: 0x0200018A RID: 394
		[Token(Token = "0x200018A")]
		[CompilerGenerated]
		private sealed class Class63
		{
			// Token: 0x06003C98 RID: 15512 RVA: 0x000020B4 File Offset: 0x000002B4
			[Token(Token = "0x6003C98")]
			[Address(RVA = "0x10748D8", Offset = "0x10748D8", VA = "0x10748D8")]
			public Class63()
			{
			}

			// Token: 0x06003C99 RID: 15513 RVA: 0x00076C8C File Offset: 0x00074E8C
			[Address(RVA = "0x10748E0", Offset = "0x10748E0", VA = "0x10748E0")]
			[Token(Token = "0x6003C99")]
			internal void method_0(Message<OrgScopedID> result)
			{
				LoginManager.Class64 @class = new LoginManager.Class64();
				@class.CS$<>8__locals1 = this;
				@class.result = result;
				Message<UserProof>.Callback callback;
				Users.GetUserProof().OnComplete(callback);
			}

			// Token: 0x04000AE6 RID: 2790
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000AE6")]
			public Message<User> m;

			// Token: 0x04000AE7 RID: 2791
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x4000AE7")]
			public LoginManager <>4__this;
		}

		// Token: 0x0200018B RID: 395
		[Token(Token = "0x200018B")]
		[CompilerGenerated]
		private sealed class Class64
		{
			// Token: 0x06003C9A RID: 15514 RVA: 0x000020B4 File Offset: 0x000002B4
			[Token(Token = "0x6003C9A")]
			[Address(RVA = "0x1074AC4", Offset = "0x1074AC4", VA = "0x1074AC4")]
			public Class64()
			{
			}

			// Token: 0x06003C9B RID: 15515 RVA: 0x00002068 File Offset: 0x00000268
			[Address(RVA = "0x1074C0C", Offset = "0x1074C0C", VA = "0x1074C0C")]
			[Token(Token = "0x6003C9B")]
			internal void method_0(Message<UserProof> r)
			{
				throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
			}

			// Token: 0x04000AE8 RID: 2792
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000AE8")]
			public Message<OrgScopedID> result;

			// Token: 0x04000AE9 RID: 2793
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x4000AE9")]
			public LoginManager.Class63 CS$<>8__locals1;
		}
	}
}
