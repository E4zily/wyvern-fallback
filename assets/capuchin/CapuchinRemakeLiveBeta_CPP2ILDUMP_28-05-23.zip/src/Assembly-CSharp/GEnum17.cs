﻿using System;
using Cpp2IlInjected;

// Token: 0x02000160 RID: 352
[Token(Token = "0x2000160")]
public enum GEnum17
{
	// Token: 0x0400094E RID: 2382
	[Token(Token = "0x400094E")]
	const_0,
	// Token: 0x0400094F RID: 2383
	[Token(Token = "0x400094F")]
	const_1,
	// Token: 0x04000950 RID: 2384
	[Token(Token = "0x4000950")]
	const_2,
	// Token: 0x04000951 RID: 2385
	[Token(Token = "0x4000951")]
	const_3
}
