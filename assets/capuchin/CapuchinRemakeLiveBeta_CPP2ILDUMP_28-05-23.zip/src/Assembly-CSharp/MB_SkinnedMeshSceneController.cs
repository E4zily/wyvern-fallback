﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000088 RID: 136
[Token(Token = "0x2000088")]
public class MB_SkinnedMeshSceneController : MonoBehaviour
{
	// Token: 0x0600139E RID: 5022 RVA: 0x0002771C File Offset: 0x0002591C
	[Address(RVA = "0x2EFA888", Offset = "0x2EFA888", VA = "0x2EFA888")]
	[Token(Token = "0x600139E")]
	public Transform method_0(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		Transform child = transform_0.GetChild((int)index);
		this.method_44(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x0600139F RID: 5023 RVA: 0x00027758 File Offset: 0x00025958
	[Address(RVA = "0x2EFAA88", Offset = "0x2EFAA88", VA = "0x2EFAA88")]
	[Token(Token = "0x600139F")]
	public Transform method_1(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		Transform child = transform_0.GetChild((int)index);
		this.method_31(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x060013A0 RID: 5024 RVA: 0x00027794 File Offset: 0x00025994
	[Address(RVA = "0x2EFACA4", Offset = "0x2EFACA4", VA = "0x2EFACA4")]
	[Token(Token = "0x60013A0")]
	public Transform method_2(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_31(child, string_0);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013A1 RID: 5025 RVA: 0x000277D4 File Offset: 0x000259D4
	[Address(RVA = "0x2EFADC0", Offset = "0x2EFADC0", VA = "0x2EFADC0")]
	[Token(Token = "0x60013A1")]
	public Transform method_3(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		Transform child = transform_0.GetChild((int)index);
		this.method_10(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x060013A2 RID: 5026 RVA: 0x00027810 File Offset: 0x00025A10
	[Address(RVA = "0x2EFAFC0", Offset = "0x2EFAFC0", VA = "0x2EFAFC0")]
	[Token(Token = "0x60013A2")]
	private void method_4()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("FingerTip");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013A3 RID: 5027 RVA: 0x00027850 File Offset: 0x00025A50
	[Address(RVA = "0x2EFB1C4", Offset = "0x2EFB1C4", VA = "0x2EFB1C4")]
	[Token(Token = "0x60013A3")]
	private void method_5()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013A4 RID: 5028 RVA: 0x00027890 File Offset: 0x00025A90
	[Address(RVA = "0x2EFB3CC", Offset = "0x2EFB3CC", VA = "0x2EFB3CC")]
	[Token(Token = "0x60013A4")]
	private void method_6()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num != 0L)
		{
		}
		Transform transform = this.gameObject_4.transform;
		Transform parent = this.method_41(transform, "/");
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013A5 RID: 5029 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EFC39C", Offset = "0x2EFC39C", VA = "0x2EFC39C")]
	[Token(Token = "0x60013A5")]
	private void method_7()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013A6 RID: 5030 RVA: 0x000278F4 File Offset: 0x00025AF4
	[Address(RVA = "0x2EFC5A4", Offset = "0x2EFC5A4", VA = "0x2EFC5A4")]
	[Token(Token = "0x60013A6")]
	private void method_8()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013A7 RID: 5031 RVA: 0x00027934 File Offset: 0x00025B34
	[Address(RVA = "0x2EFC7A8", Offset = "0x2EFC7A8", VA = "0x2EFC7A8")]
	[Token(Token = "0x60013A7")]
	public Transform method_9(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		transform_0.GetChild((int)index);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013A8 RID: 5032 RVA: 0x0002796C File Offset: 0x00025B6C
	[Address(RVA = "0x2EFAEC0", Offset = "0x2EFAEC0", VA = "0x2EFAEC0")]
	[Token(Token = "0x60013A8")]
	public Transform method_10(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		Transform child = transform_0.GetChild((int)index);
		this.method_20(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x060013A9 RID: 5033 RVA: 0x000279A8 File Offset: 0x00025BA8
	[Address(RVA = "0x2EFC9DC", Offset = "0x2EFC9DC", VA = "0x2EFC9DC")]
	[Token(Token = "0x60013A9")]
	public Transform method_11(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		Transform child = transform_0.GetChild((int)index);
		this.method_19(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x060013AA RID: 5034 RVA: 0x000279E4 File Offset: 0x00025BE4
	[Address(RVA = "0x2EFCADC", Offset = "0x2EFCADC", VA = "0x2EFCADC")]
	[Token(Token = "0x60013AA")]
	public Transform method_12(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		Transform child = transform_0.GetChild((int)index);
		this.method_29(child, string_0);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013AB RID: 5035 RVA: 0x00027A24 File Offset: 0x00025C24
	[Address(RVA = "0x2EFCD10", Offset = "0x2EFCD10", VA = "0x2EFCD10")]
	[Token(Token = "0x60013AB")]
	public Transform method_13(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		Transform child = transform_0.GetChild((int)index);
		this.method_32(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x060013AC RID: 5036 RVA: 0x00027A60 File Offset: 0x00025C60
	[Address(RVA = "0x2EFCF2C", Offset = "0x2EFCF2C", VA = "0x2EFCF2C")]
	[Token(Token = "0x60013AC")]
	private void method_14()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("hh:mmtt");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013AD RID: 5037 RVA: 0x00027AA0 File Offset: 0x00025CA0
	[Address(RVA = "0x2EFD130", Offset = "0x2EFD130", VA = "0x2EFD130")]
	[Token(Token = "0x60013AD")]
	public Transform method_15(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_19(child, string_0);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013AE RID: 5038 RVA: 0x00027AE0 File Offset: 0x00025CE0
	[Address(RVA = "0x2EFD24C", Offset = "0x2EFD24C", VA = "0x2EFD24C")]
	[Token(Token = "0x60013AE")]
	public Transform method_16(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		Transform child = transform_0.GetChild((int)index);
		this.method_21(child, string_0);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013AF RID: 5039 RVA: 0x00027B20 File Offset: 0x00025D20
	[Address(RVA = "0x2EFD464", Offset = "0x2EFD464", VA = "0x2EFD464")]
	[Token(Token = "0x60013AF")]
	private void method_17()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num != 0L)
		{
		}
		Transform transform = this.gameObject_4.transform;
		Transform parent = this.method_13(transform, "Adding ");
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013B0 RID: 5040 RVA: 0x00027B84 File Offset: 0x00025D84
	[Address(RVA = "0x2EFE1FC", Offset = "0x2EFE1FC", VA = "0x2EFE1FC")]
	[Token(Token = "0x60013B0")]
	private void method_18()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("next");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013B1 RID: 5041 RVA: 0x00027BC4 File Offset: 0x00025DC4
	[Address(RVA = "0x2EFC280", Offset = "0x2EFC280", VA = "0x2EFC280")]
	[Token(Token = "0x60013B1")]
	public Transform method_19(Transform transform_0, string string_0)
	{
		string text;
		text.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_41(child, string_0);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013B2 RID: 5042 RVA: 0x00027C04 File Offset: 0x00025E04
	[Address(RVA = "0x2EFC8C0", Offset = "0x2EFC8C0", VA = "0x2EFC8C0")]
	[Token(Token = "0x60013B2")]
	public Transform method_20(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_21(child, string_0) != child;
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013B3 RID: 5043 RVA: 0x00027C4C File Offset: 0x00025E4C
	[Address(RVA = "0x2EFE404", Offset = "0x2EFE404", VA = "0x2EFE404")]
	[Token(Token = "0x60013B3")]
	private void OnGUI()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num != 0L)
		{
		}
		Transform transform = this.gameObject_4.transform;
		Transform parent = this.method_9(transform, "RightHandAttachPoint");
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013B4 RID: 5044 RVA: 0x00027CB0 File Offset: 0x00025EB0
	[Address(RVA = "0x2EFD364", Offset = "0x2EFD364", VA = "0x2EFD364")]
	[Token(Token = "0x60013B4")]
	public Transform method_21(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_3(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x060013B5 RID: 5045 RVA: 0x00027CEC File Offset: 0x00025EEC
	[Address(RVA = "0x2EFF090", Offset = "0x2EFF090", VA = "0x2EFF090")]
	[Token(Token = "0x60013B5")]
	private void method_22()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("All audio clips have been played.");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013B6 RID: 5046 RVA: 0x00027D2C File Offset: 0x00025F2C
	[Address(RVA = "0x2EFF298", Offset = "0x2EFF298", VA = "0x2EFF298")]
	[Token(Token = "0x60013B6")]
	private void method_23()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("Cheating");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013B7 RID: 5047 RVA: 0x00027D6C File Offset: 0x00025F6C
	[Address(RVA = "0x2EFF4A0", Offset = "0x2EFF4A0", VA = "0x2EFF4A0")]
	[Token(Token = "0x60013B7")]
	private void method_24()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num != 0L)
		{
		}
		Transform transform = this.gameObject_4.transform;
		Transform parent = this.method_21(transform, "FingerTip");
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013B8 RID: 5048 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2F00138", Offset = "0x2F00138", VA = "0x2F00138")]
	[Token(Token = "0x60013B8")]
	private void method_25()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013B9 RID: 5049 RVA: 0x00027DD0 File Offset: 0x00025FD0
	[Address(RVA = "0x2F00DD0", Offset = "0x2F00DD0", VA = "0x2F00DD0")]
	[Token(Token = "0x60013B9")]
	public Transform method_26(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_21(child, string_0);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013BA RID: 5050 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2F00EEC", Offset = "0x2F00EEC", VA = "0x2F00EEC")]
	[Token(Token = "0x60013BA")]
	private void method_27()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013BB RID: 5051 RVA: 0x00027E10 File Offset: 0x00026010
	[Address(RVA = "0x2EFE0FC", Offset = "0x2EFE0FC", VA = "0x2EFE0FC")]
	[Token(Token = "0x60013BB")]
	public Transform method_28(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		Transform child = transform_0.GetChild((int)index);
		this.method_16(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x060013BC RID: 5052 RVA: 0x00027E4C File Offset: 0x0002604C
	[Token(Token = "0x60013BC")]
	[Address(RVA = "0x2EFCBF4", Offset = "0x2EFCBF4", VA = "0x2EFCBF4")]
	public Transform method_29(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		Transform result = this.method_1(child, string_0);
		int childCount2 = transform_0.childCount;
		return result;
	}

	// Token: 0x060013BD RID: 5053 RVA: 0x00027E8C File Offset: 0x0002608C
	[Token(Token = "0x60013BD")]
	[Address(RVA = "0x2F01B80", Offset = "0x2F01B80", VA = "0x2F01B80")]
	private void method_30()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("BN");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013BE RID: 5054 RVA: 0x00027ECC File Offset: 0x000260CC
	[Token(Token = "0x60013BE")]
	[Address(RVA = "0x2EFAB88", Offset = "0x2EFAB88", VA = "0x2EFAB88")]
	public Transform method_31(Transform transform_0, string string_0)
	{
		string name = transform_0.name;
		int childCount = transform_0.childCount;
		long index = 1L;
		transform_0.GetChild((int)index);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013BF RID: 5055 RVA: 0x00027F00 File Offset: 0x00026100
	[Address(RVA = "0x2EFCE10", Offset = "0x2EFCE10", VA = "0x2EFCE10")]
	[Token(Token = "0x60013BF")]
	public Transform method_32(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_20(child, string_0);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013C0 RID: 5056 RVA: 0x00027F40 File Offset: 0x00026140
	[Address(RVA = "0x2F01D84", Offset = "0x2F01D84", VA = "0x2F01D84")]
	[Token(Token = "0x60013C0")]
	private void method_33()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("tutorialCheck");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013C1 RID: 5057 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2F01F88", Offset = "0x2F01F88", VA = "0x2F01F88")]
	[Token(Token = "0x60013C1")]
	private void method_34()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013C2 RID: 5058 RVA: 0x00027F80 File Offset: 0x00026180
	[Address(RVA = "0x2F02C20", Offset = "0x2F02C20", VA = "0x2F02C20")]
	[Token(Token = "0x60013C2")]
	private void method_35()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num != 0L)
		{
		}
		Transform transform = this.gameObject_4.transform;
		Transform transform2;
		Transform parent;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013C3 RID: 5059 RVA: 0x00027FD4 File Offset: 0x000261D4
	[Address(RVA = "0x2F038B8", Offset = "0x2F038B8", VA = "0x2F038B8")]
	[Token(Token = "0x60013C3")]
	public Transform method_36(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_44(child, string_0);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013C4 RID: 5060 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2F039D4", Offset = "0x2F039D4", VA = "0x2F039D4")]
	[Token(Token = "0x60013C4")]
	private void method_37()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060013C5 RID: 5061 RVA: 0x00028014 File Offset: 0x00026214
	[Address(RVA = "0x2F04668", Offset = "0x2F04668", VA = "0x2F04668")]
	[Token(Token = "0x60013C5")]
	private void method_38()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("\tExpires: ");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013C6 RID: 5062 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2F0486C", Offset = "0x2F0486C", VA = "0x2F0486C")]
	[Token(Token = "0x60013C6")]
	public MB_SkinnedMeshSceneController()
	{
	}

	// Token: 0x060013C7 RID: 5063 RVA: 0x00028054 File Offset: 0x00026254
	[Token(Token = "0x60013C7")]
	[Address(RVA = "0x2F04874", Offset = "0x2F04874", VA = "0x2F04874")]
	private void method_39()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num != 0L)
		{
		}
		Transform transform = this.gameObject_4.transform;
		Transform parent = this.method_1(transform, "{0}/{1:f0}");
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013C8 RID: 5064 RVA: 0x000280B8 File Offset: 0x000262B8
	[Address(RVA = "0x2F05504", Offset = "0x2F05504", VA = "0x2F05504")]
	[Token(Token = "0x60013C8")]
	public Transform method_40(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 0L;
		Transform child = transform_0.GetChild((int)index);
		this.method_15(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x060013C9 RID: 5065 RVA: 0x000280F4 File Offset: 0x000262F4
	[Address(RVA = "0x2EFC064", Offset = "0x2EFC064", VA = "0x2EFC064")]
	[Token(Token = "0x60013C9")]
	public Transform method_41(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_26(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x060013CA RID: 5066 RVA: 0x00028130 File Offset: 0x00026330
	[Address(RVA = "0x2EFC164", Offset = "0x2EFC164", VA = "0x2EFC164")]
	[Token(Token = "0x60013CA")]
	public Transform method_42(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_9(child, string_0);
		int childCount2 = transform_0.childCount;
		throw new NullReferenceException();
	}

	// Token: 0x060013CB RID: 5067 RVA: 0x00028170 File Offset: 0x00026370
	[Address(RVA = "0x2F05604", Offset = "0x2F05604", VA = "0x2F05604")]
	[Token(Token = "0x60013CB")]
	private void method_43()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num != 0L)
		{
		}
		Transform transform = this.gameObject_4.transform;
		Transform parent = this.method_13(transform, " hour. You were banned because of ");
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013CC RID: 5068 RVA: 0x000280F4 File Offset: 0x000262F4
	[Address(RVA = "0x2EFA988", Offset = "0x2EFA988", VA = "0x2EFA988")]
	[Token(Token = "0x60013CC")]
	public Transform method_44(Transform transform_0, string string_0)
	{
		transform_0.name.Equals(string_0);
		int childCount = transform_0.childCount;
		long index = 1L;
		Transform child = transform_0.GetChild((int)index);
		this.method_26(child, string_0);
		throw new NullReferenceException();
	}

	// Token: 0x060013CD RID: 5069 RVA: 0x000281D4 File Offset: 0x000263D4
	[Address(RVA = "0x2F062A0", Offset = "0x2F062A0", VA = "0x2F062A0")]
	[Token(Token = "0x60013CD")]
	private void method_45()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num != 0L)
		{
		}
		Transform transform = this.gameObject_4.transform;
		Transform parent = this.method_31(transform, "Name Changing Error. Error: ");
		Transform transform2;
		transform2.parent = parent;
		Vector3 zero = Vector3.zero;
		Quaternion identity = Quaternion.identity;
		Vector3 one = Vector3.one;
		MeshRenderer meshRenderer;
		GameObject gameObject = meshRenderer.gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013CE RID: 5070 RVA: 0x00028238 File Offset: 0x00026438
	[Address(RVA = "0x2F06F30", Offset = "0x2F06F30", VA = "0x2F06F30")]
	[Token(Token = "0x60013CE")]
	private void Start()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>().Play("run");
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060013CF RID: 5071 RVA: 0x00028278 File Offset: 0x00026478
	[Address(RVA = "0x2F07130", Offset = "0x2F07130", VA = "0x2F07130")]
	[Token(Token = "0x60013CF")]
	private void method_46()
	{
		GameObject gameObject;
		Transform transform = gameObject.transform;
		gameObject.GetComponent<Animation>();
		GameObject gameObject2 = gameObject.GetComponentInChildren<SkinnedMeshRenderer>().gameObject;
		if (gameObject2 != null && gameObject2 == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x04000299 RID: 665
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000299")]
	public GameObject gameObject_0;

	// Token: 0x0400029A RID: 666
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400029A")]
	public GameObject gameObject_1;

	// Token: 0x0400029B RID: 667
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400029B")]
	public GameObject gameObject_2;

	// Token: 0x0400029C RID: 668
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400029C")]
	public GameObject gameObject_3;

	// Token: 0x0400029D RID: 669
	[Token(Token = "0x400029D")]
	[FieldOffset(Offset = "0x38")]
	public GameObject gameObject_4;

	// Token: 0x0400029E RID: 670
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400029E")]
	public MB3_MeshBaker mb3_MeshBaker_0;

	// Token: 0x0400029F RID: 671
	[Token(Token = "0x400029F")]
	[FieldOffset(Offset = "0x48")]
	private GameObject gameObject_5;

	// Token: 0x040002A0 RID: 672
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40002A0")]
	private GameObject gameObject_6;

	// Token: 0x040002A1 RID: 673
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40002A1")]
	private GameObject gameObject_7;
}
