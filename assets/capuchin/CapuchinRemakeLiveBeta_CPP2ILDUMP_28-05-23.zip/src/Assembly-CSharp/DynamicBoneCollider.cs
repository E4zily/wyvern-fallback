﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200000D RID: 13
[AddComponentMenu("Dynamic Bone/Dynamic Bone Collider")]
[Token(Token = "0x200000D")]
public class DynamicBoneCollider : DynamicBoneColliderBase
{
	// Token: 0x06000184 RID: 388 RVA: 0x000085BC File Offset: 0x000067BC
	[Address(RVA = "0x2218A7C", Offset = "0x2218A7C", VA = "0x2218A7C")]
	[Token(Token = "0x6000184")]
	public DynamicBoneCollider()
	{
		long num = 1056964608L;
		long genum10_ = 1L;
		this.float_0 = (float)num;
		this.genum10_0 = (DynamicBoneColliderBase.GEnum10)genum10_;
		Vector3 zero = Vector3.zero;
		base..ctor();
	}

	// Token: 0x06000185 RID: 389 RVA: 0x000085EC File Offset: 0x000067EC
	[Token(Token = "0x6000185")]
	[Address(RVA = "0x2218AFC", Offset = "0x2218AFC", VA = "0x2218AFC")]
	private void OnDrawGizmosSelected()
	{
		bool enabled = base.enabled;
		if (this.genum11_0 != DynamicBoneColliderBase.GEnum11.const_0)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
	}

	// Token: 0x06000186 RID: 390 RVA: 0x00008618 File Offset: 0x00006818
	[Address(RVA = "0x2218C54", Offset = "0x2218C54", VA = "0x2218C54")]
	[Token(Token = "0x6000186")]
	private static bool smethod_0(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8, float float_9)
	{
		/*
An exception occurred when decompiling this method (06000186)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::smethod_0(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(float_9), ldloc:float32(float_8)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000187 RID: 391 RVA: 0x00008630 File Offset: 0x00006830
	[Address(RVA = "0x2218EB8", Offset = "0x2218EB8", VA = "0x2218EB8")]
	[Token(Token = "0x6000187")]
	private static bool smethod_1(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8, float float_9)
	{
		/*
An exception occurred when decompiling this method (06000187)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::smethod_1(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(float_9), ldloc:float32(float_8)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000188 RID: 392 RVA: 0x00008648 File Offset: 0x00006848
	[Address(RVA = "0x2219120", Offset = "0x2219120", VA = "0x2219120")]
	[Token(Token = "0x6000188")]
	private static bool smethod_2(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8, float float_9)
	{
		/*
An exception occurred when decompiling this method (06000188)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::smethod_2(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(float_9), ldloc:float32(float_8)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000189 RID: 393 RVA: 0x00008660 File Offset: 0x00006860
	[Address(RVA = "0x2219384", Offset = "0x2219384", VA = "0x2219384")]
	[Token(Token = "0x6000189")]
	private static bool smethod_3(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8)
	{
	}

	// Token: 0x0600018A RID: 394 RVA: 0x00008670 File Offset: 0x00006870
	[Address(RVA = "0x2219584", Offset = "0x2219584", VA = "0x2219584")]
	[Token(Token = "0x600018A")]
	private static bool smethod_4(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8)
	{
	}

	// Token: 0x0600018B RID: 395 RVA: 0x00008680 File Offset: 0x00006880
	[Token(Token = "0x600018B")]
	[Address(RVA = "0x22197AC", Offset = "0x22197AC", VA = "0x22197AC", Slot = "13")]
	public override bool vmethod_9(ref Vector3 vector3_3, float float_6)
	{
		return false;
	}

	// Token: 0x0600018C RID: 396 RVA: 0x00008660 File Offset: 0x00006860
	[Token(Token = "0x600018C")]
	[Address(RVA = "0x221A2FC", Offset = "0x221A2FC", VA = "0x221A2FC")]
	private static bool smethod_5(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8)
	{
	}

	// Token: 0x0600018D RID: 397 RVA: 0x00008690 File Offset: 0x00006890
	[Address(RVA = "0x221A4FC", Offset = "0x221A4FC", VA = "0x221A4FC")]
	[Token(Token = "0x600018D")]
	private static void smethod_6(Vector3 vector3_3, Vector3 vector3_4, float float_6, float float_7)
	{
	}

	// Token: 0x0600018E RID: 398 RVA: 0x000086A0 File Offset: 0x000068A0
	[Address(RVA = "0x221A580", Offset = "0x221A580", VA = "0x221A580")]
	[Token(Token = "0x600018E")]
	private static bool smethod_7(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x0600018F RID: 399 RVA: 0x000086B0 File Offset: 0x000068B0
	[Token(Token = "0x600018F")]
	[Address(RVA = "0x221A634", Offset = "0x221A634", VA = "0x221A634")]
	private static bool smethod_8(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x06000190 RID: 400 RVA: 0x000085EC File Offset: 0x000067EC
	[Token(Token = "0x6000190")]
	[Address(RVA = "0x221A6F0", Offset = "0x221A6F0", VA = "0x221A6F0")]
	private void method_45()
	{
		bool enabled = base.enabled;
		if (this.genum11_0 != DynamicBoneColliderBase.GEnum11.const_0)
		{
			Color magenta = Color.magenta;
			return;
		}
		Color yellow = Color.yellow;
	}

	// Token: 0x06000191 RID: 401 RVA: 0x00008630 File Offset: 0x00006830
	[Token(Token = "0x6000191")]
	[Address(RVA = "0x221A7CC", Offset = "0x221A7CC", VA = "0x221A7CC")]
	private static bool smethod_9(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8, float float_9)
	{
		/*
An exception occurred when decompiling this method (06000191)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::smethod_9(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(float_9), ldloc:float32(float_8)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06000192 RID: 402 RVA: 0x00008690 File Offset: 0x00006890
	[Token(Token = "0x6000192")]
	[Address(RVA = "0x2218BD0", Offset = "0x2218BD0", VA = "0x2218BD0")]
	private static void smethod_10(Vector3 vector3_3, Vector3 vector3_4, float float_6, float float_7)
	{
	}

	// Token: 0x06000193 RID: 403 RVA: 0x000086C0 File Offset: 0x000068C0
	[Token(Token = "0x6000193")]
	[Address(RVA = "0x221AA34", Offset = "0x221AA34", VA = "0x221AA34")]
	private void method_46()
	{
		float num = this.float_0;
		this.float_0 = num;
		this.float_1 = num;
		this.float_2 = num;
	}

	// Token: 0x06000194 RID: 404 RVA: 0x000086A0 File Offset: 0x000068A0
	[Address(RVA = "0x221AAA0", Offset = "0x221AAA0", VA = "0x221AAA0")]
	[Token(Token = "0x6000194")]
	private static bool smethod_11(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x06000195 RID: 405 RVA: 0x000086EC File Offset: 0x000068EC
	[Token(Token = "0x6000195")]
	[Address(RVA = "0x2219C40", Offset = "0x2219C40", VA = "0x2219C40")]
	private static bool smethod_12(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8)
	{
	}

	// Token: 0x06000196 RID: 406 RVA: 0x000086C0 File Offset: 0x000068C0
	[Address(RVA = "0x221AB54", Offset = "0x221AB54", VA = "0x221AB54")]
	[Token(Token = "0x6000196")]
	private void OnValidate()
	{
		float num = this.float_0;
		this.float_0 = num;
		this.float_1 = num;
		this.float_2 = num;
	}

	// Token: 0x06000197 RID: 407 RVA: 0x000086A0 File Offset: 0x000068A0
	[Address(RVA = "0x221ABB4", Offset = "0x221ABB4", VA = "0x221ABB4")]
	[Token(Token = "0x6000197")]
	private static bool smethod_13(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x06000198 RID: 408 RVA: 0x000086A0 File Offset: 0x000068A0
	[Token(Token = "0x6000198")]
	[Address(RVA = "0x221AC68", Offset = "0x221AC68", VA = "0x221AC68")]
	private static bool smethod_14(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x06000199 RID: 409 RVA: 0x000086B0 File Offset: 0x000068B0
	[Address(RVA = "0x221AD34", Offset = "0x221AD34", VA = "0x221AD34")]
	[Token(Token = "0x6000199")]
	private static bool smethod_15(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x0600019A RID: 410 RVA: 0x000086EC File Offset: 0x000068EC
	[Token(Token = "0x600019A")]
	[Address(RVA = "0x221ADF0", Offset = "0x221ADF0", VA = "0x221ADF0")]
	private static bool smethod_16(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8)
	{
	}

	// Token: 0x0600019B RID: 411 RVA: 0x000086FC File Offset: 0x000068FC
	[Token(Token = "0x600019B")]
	[Address(RVA = "0x221AFEC", Offset = "0x221AFEC", VA = "0x221AFEC")]
	private static bool smethod_17(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8, float float_9)
	{
		/*
An exception occurred when decompiling this method (0600019B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::smethod_17(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(float_9), ldloc:float32(float_8)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600019C RID: 412 RVA: 0x000086FC File Offset: 0x000068FC
	[Token(Token = "0x600019C")]
	[Address(RVA = "0x2219E30", Offset = "0x2219E30", VA = "0x2219E30")]
	private static bool smethod_18(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8, float float_9)
	{
		/*
An exception occurred when decompiling this method (0600019C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::smethod_18(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(float_9), ldloc:float32(float_8)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x0600019D RID: 413 RVA: 0x000086C0 File Offset: 0x000068C0
	[Token(Token = "0x600019D")]
	[Address(RVA = "0x221B290", Offset = "0x221B290", VA = "0x221B290")]
	private void method_47()
	{
		float num = this.float_0;
		this.float_0 = num;
		this.float_1 = num;
		this.float_2 = num;
	}

	// Token: 0x0600019E RID: 414 RVA: 0x000086A0 File Offset: 0x000068A0
	[Token(Token = "0x600019E")]
	[Address(RVA = "0x221B2FC", Offset = "0x221B2FC", VA = "0x221B2FC")]
	private static bool smethod_19(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x0600019F RID: 415 RVA: 0x00008714 File Offset: 0x00006914
	[Token(Token = "0x600019F")]
	[Address(RVA = "0x221B3B0", Offset = "0x221B3B0", VA = "0x221B3B0")]
	private static bool smethod_20(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8)
	{
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x00008724 File Offset: 0x00006924
	[Token(Token = "0x60001A0")]
	[Address(RVA = "0x221B5B0", Offset = "0x221B5B0", VA = "0x221B5B0")]
	private static bool smethod_21(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8, float float_9)
	{
		/*
An exception occurred when decompiling this method (060001A0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::smethod_21(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(float_9), ldloc:float32(float_8)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x000086C0 File Offset: 0x000068C0
	[Address(RVA = "0x221B808", Offset = "0x221B808", VA = "0x221B808")]
	[Token(Token = "0x60001A1")]
	private void method_48()
	{
		float num = this.float_0;
		this.float_0 = num;
		this.float_1 = num;
		this.float_2 = num;
	}

	// Token: 0x060001A2 RID: 418 RVA: 0x0000873C File Offset: 0x0000693C
	[Address(RVA = "0x221B874", Offset = "0x221B874", VA = "0x221B874", Slot = "25")]
	[Token(Token = "0x60001A2")]
	public override void vmethod_21()
	{
		Vector3 lossyScale = base.transform.lossyScale;
		float num = this.float_2;
		this.float_3 = num;
		if (this.genum10_0 == DynamicBoneColliderBase.GEnum10.const_0)
		{
			return;
		}
		Transform transform = base.transform;
		float x;
		this.vector3_1.x = x;
		float y;
		this.vector3_1.y = y;
		float z;
		this.vector3_1.z = z;
		Transform transform2 = base.transform;
		this.vector3_2.x = x;
		this.vector3_2.y = y;
		this.vector3_2.z = z;
		Vector3 vector;
		float magnitude = vector.magnitude;
		this.float_5 = x;
	}

	// Token: 0x060001A3 RID: 419 RVA: 0x00008724 File Offset: 0x00006924
	[Token(Token = "0x60001A3")]
	[Address(RVA = "0x221BB8C", Offset = "0x221BB8C", VA = "0x221BB8C")]
	private static bool smethod_22(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8, float float_9)
	{
		/*
An exception occurred when decompiling this method (060001A3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::smethod_22(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(float_9), ldloc:float32(float_8)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001A4 RID: 420 RVA: 0x000086C0 File Offset: 0x000068C0
	[Address(RVA = "0x221BDE4", Offset = "0x221BDE4", VA = "0x221BDE4")]
	[Token(Token = "0x60001A4")]
	private void method_49()
	{
		float num = this.float_0;
		this.float_0 = num;
		this.float_1 = num;
		this.float_2 = num;
	}

	// Token: 0x060001A5 RID: 421 RVA: 0x000086B0 File Offset: 0x000068B0
	[Token(Token = "0x60001A5")]
	[Address(RVA = "0x221BE50", Offset = "0x221BE50", VA = "0x221BE50")]
	private static bool smethod_23(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x060001A6 RID: 422 RVA: 0x000086A0 File Offset: 0x000068A0
	[Token(Token = "0x60001A6")]
	[Address(RVA = "0x2219984", Offset = "0x2219984", VA = "0x2219984")]
	private static bool smethod_24(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x060001A7 RID: 423 RVA: 0x000087DC File Offset: 0x000069DC
	[Address(RVA = "0x221BF0C", Offset = "0x221BF0C", VA = "0x221BF0C")]
	[Token(Token = "0x60001A7")]
	private void method_50()
	{
		bool enabled = base.enabled;
		Color magenta = Color.magenta;
	}

	// Token: 0x060001A8 RID: 424 RVA: 0x000086A0 File Offset: 0x000068A0
	[Address(RVA = "0x221BFE8", Offset = "0x221BFE8", VA = "0x221BFE8")]
	[Token(Token = "0x60001A8")]
	private static bool smethod_25(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x060001A9 RID: 425 RVA: 0x00008690 File Offset: 0x00006890
	[Token(Token = "0x60001A9")]
	[Address(RVA = "0x221C09C", Offset = "0x221C09C", VA = "0x221C09C")]
	private static void smethod_26(Vector3 vector3_3, Vector3 vector3_4, float float_6, float float_7)
	{
	}

	// Token: 0x060001AA RID: 426 RVA: 0x000086A0 File Offset: 0x000068A0
	[Address(RVA = "0x22198BC", Offset = "0x22198BC", VA = "0x22198BC")]
	[Token(Token = "0x60001AA")]
	private static bool smethod_27(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x060001AB RID: 427 RVA: 0x000087F8 File Offset: 0x000069F8
	[Address(RVA = "0x221C120", Offset = "0x221C120", VA = "0x221C120")]
	[Token(Token = "0x60001AB")]
	private void method_51()
	{
		float num = this.float_0;
		this.float_0 = num;
		this.float_1 = num;
		this.float_2 = num;
	}

	// Token: 0x060001AC RID: 428 RVA: 0x00008690 File Offset: 0x00006890
	[Address(RVA = "0x221C18C", Offset = "0x221C18C", VA = "0x221C18C")]
	[Token(Token = "0x60001AC")]
	private static void smethod_28(Vector3 vector3_3, Vector3 vector3_4, float float_6, float float_7)
	{
	}

	// Token: 0x060001AD RID: 429 RVA: 0x000086A0 File Offset: 0x000068A0
	[Token(Token = "0x60001AD")]
	[Address(RVA = "0x221C210", Offset = "0x221C210", VA = "0x221C210")]
	private static bool smethod_29(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x060001AE RID: 430 RVA: 0x00008824 File Offset: 0x00006A24
	[Address(RVA = "0x221C2DC", Offset = "0x221C2DC", VA = "0x221C2DC")]
	[Token(Token = "0x60001AE")]
	private static bool smethod_30(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8)
	{
	}

	// Token: 0x060001AF RID: 431 RVA: 0x000086A0 File Offset: 0x000068A0
	[Address(RVA = "0x221C4E0", Offset = "0x221C4E0", VA = "0x221C4E0")]
	[Token(Token = "0x60001AF")]
	private static bool smethod_31(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x060001B0 RID: 432 RVA: 0x00008618 File Offset: 0x00006818
	[Address(RVA = "0x221C5AC", Offset = "0x221C5AC", VA = "0x221C5AC")]
	[Token(Token = "0x60001B0")]
	private static bool smethod_32(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8, float float_9)
	{
		/*
An exception occurred when decompiling this method (060001B0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::smethod_32(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(float_9), ldloc:float32(float_8)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060001B1 RID: 433 RVA: 0x00008670 File Offset: 0x00006870
	[Address(RVA = "0x2219A40", Offset = "0x2219A40", VA = "0x2219A40")]
	[Token(Token = "0x60001B1")]
	private static bool smethod_33(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8)
	{
	}

	// Token: 0x060001B2 RID: 434 RVA: 0x000086A0 File Offset: 0x000068A0
	[Address(RVA = "0x221C818", Offset = "0x221C818", VA = "0x221C818")]
	[Token(Token = "0x60001B2")]
	private static bool smethod_34(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, float float_7)
	{
	}

	// Token: 0x060001B3 RID: 435 RVA: 0x00008834 File Offset: 0x00006A34
	[Address(RVA = "0x221A0A4", Offset = "0x221A0A4", VA = "0x221A0A4")]
	[Token(Token = "0x60001B3")]
	private static bool smethod_35(ref Vector3 vector3_3, float float_6, Vector3 vector3_4, Vector3 vector3_5, float float_7, float float_8, float float_9)
	{
		/*
An exception occurred when decompiling this method (060001B3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBoneCollider::smethod_35(UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:float32(Mathf::Lerp, ldloc:float32(var_0), ldloc:float32(float_9), ldloc:float32(float_8)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x04000033 RID: 51
	[Token(Token = "0x4000033")]
	[FieldOffset(Offset = "0x30")]
	public float float_0;

	// Token: 0x04000034 RID: 52
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x4000034")]
	public float float_1;

	// Token: 0x04000035 RID: 53
	[Token(Token = "0x4000035")]
	[FieldOffset(Offset = "0x38")]
	public float float_2;

	// Token: 0x04000036 RID: 54
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x4000036")]
	private float float_3;

	// Token: 0x04000037 RID: 55
	[Token(Token = "0x4000037")]
	[FieldOffset(Offset = "0x40")]
	private float float_4;

	// Token: 0x04000038 RID: 56
	[Token(Token = "0x4000038")]
	[FieldOffset(Offset = "0x44")]
	private Vector3 vector3_1;

	// Token: 0x04000039 RID: 57
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000039")]
	private Vector3 vector3_2;

	// Token: 0x0400003A RID: 58
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x400003A")]
	private float float_5;

	// Token: 0x0400003B RID: 59
	[Token(Token = "0x400003B")]
	[FieldOffset(Offset = "0x60")]
	private int int_1;
}
