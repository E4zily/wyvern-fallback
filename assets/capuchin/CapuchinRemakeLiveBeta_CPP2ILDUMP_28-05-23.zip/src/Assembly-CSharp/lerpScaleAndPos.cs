﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000109 RID: 265
[Token(Token = "0x2000109")]
public class lerpScaleAndPos : MonoBehaviour
{
	// Token: 0x060027E6 RID: 10214 RVA: 0x00054FEC File Offset: 0x000531EC
	[Address(RVA = "0x34BBD1C", Offset = "0x34BBD1C", VA = "0x34BBD1C")]
	[Token(Token = "0x60027E6")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("duration done");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x060027E7 RID: 10215 RVA: 0x00055014 File Offset: 0x00053214
	[Address(RVA = "0x34BBD9C", Offset = "0x34BBD9C", VA = "0x34BBD9C")]
	[Token(Token = "0x60027E7")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Grip");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x060027E8 RID: 10216 RVA: 0x0005503C File Offset: 0x0005323C
	[Address(RVA = "0x34BBE1C", Offset = "0x34BBE1C", VA = "0x34BBE1C")]
	[Token(Token = "0x60027E8")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ENABLE");
	}

	// Token: 0x060027E9 RID: 10217 RVA: 0x0005505C File Offset: 0x0005325C
	[Address(RVA = "0x34BBE98", Offset = "0x34BBE98", VA = "0x34BBE98")]
	[Token(Token = "0x60027E9")]
	public void method_3()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("ScoreCounter");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("{0}/{1:f0}").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x060027EA RID: 10218 RVA: 0x00055168 File Offset: 0x00053368
	[Address(RVA = "0x34BC2CC", Offset = "0x34BC2CC", VA = "0x34BC2CC")]
	[Token(Token = "0x60027EA")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("character limit reached");
	}

	// Token: 0x060027EB RID: 10219 RVA: 0x00055188 File Offset: 0x00053388
	[Address(RVA = "0x34BC348", Offset = "0x34BC348", VA = "0x34BC348")]
	[Token(Token = "0x60027EB")]
	public void method_5()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("TurnAmount");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("This is the 2500 Bananas button, and it was just clicked").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		float value3;
		if (this.bool_0)
		{
			Transform transform = this.transform_0;
			Vector3 localScale2 = transform.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform3 = this.gameObject_0.transform;
			Vector3 localScale4 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform4 = this.transform_0;
		Vector3 localScale5 = transform4.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform6 = this.gameObject_0.transform;
		Vector3 localScale7 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x060027EC RID: 10220 RVA: 0x00055280 File Offset: 0x00053480
	[Address(RVA = "0x34BC77C", Offset = "0x34BC77C", VA = "0x34BC77C")]
	[Token(Token = "0x60027EC")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("manual footTimings length should be equal to the leg count");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x060027ED RID: 10221 RVA: 0x000552A8 File Offset: 0x000534A8
	[Address(RVA = "0x34BC7FC", Offset = "0x34BC7FC", VA = "0x34BC7FC")]
	[Token(Token = "0x60027ED")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x060027EE RID: 10222 RVA: 0x000552D0 File Offset: 0x000534D0
	[Address(RVA = "0x34BC87C", Offset = "0x34BC87C", VA = "0x34BC87C")]
	[Token(Token = "0x60027EE")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("RainAndThunderWeather");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x060027EF RID: 10223 RVA: 0x000552F8 File Offset: 0x000534F8
	[Address(RVA = "0x34BC8FC", Offset = "0x34BC8FC", VA = "0x34BC8FC")]
	[Token(Token = "0x60027EF")]
	public void method_9()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Name Changing Error. Error: ");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("Player").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x060027F0 RID: 10224 RVA: 0x00055404 File Offset: 0x00053604
	[Token(Token = "0x60027F0")]
	[Address(RVA = "0x34BCD30", Offset = "0x34BCD30", VA = "0x34BCD30")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("gameMode");
	}

	// Token: 0x060027F1 RID: 10225 RVA: 0x00055424 File Offset: 0x00053624
	[Address(RVA = "0x34BCDAC", Offset = "0x34BCDAC", VA = "0x34BCDAC")]
	[Token(Token = "0x60027F1")]
	public void method_11()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag(" hours. You were banned because of ");
		this.gameObject_0 = gameObject;
		GameObject.FindGameObjectWithTag("false").GetComponent<PhotonView>();
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x060027F2 RID: 10226 RVA: 0x00055528 File Offset: 0x00053728
	[Address(RVA = "0x34BD1E0", Offset = "0x34BD1E0", VA = "0x34BD1E0")]
	[Token(Token = "0x60027F2")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Wear Hoodie");
	}

	// Token: 0x060027F3 RID: 10227 RVA: 0x00055548 File Offset: 0x00053748
	[Address(RVA = "0x34BD25C", Offset = "0x34BD25C", VA = "0x34BD25C")]
	[Token(Token = "0x60027F3")]
	public void method_13()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("goUpRPC");
		this.gameObject_0 = gameObject;
		GameObject.FindGameObjectWithTag("HOLY MOLY THE STICK IS ON FIRE!!!!!!").GetComponent<PhotonView>();
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x060027F4 RID: 10228 RVA: 0x0005564C File Offset: 0x0005384C
	[Address(RVA = "0x34BD690", Offset = "0x34BD690", VA = "0x34BD690")]
	[Token(Token = "0x60027F4")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("True");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x060027F5 RID: 10229 RVA: 0x00055674 File Offset: 0x00053874
	[Token(Token = "0x60027F5")]
	[Address(RVA = "0x34BD710", Offset = "0x34BD710", VA = "0x34BD710")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Tagged");
	}

	// Token: 0x060027F6 RID: 10230 RVA: 0x00055694 File Offset: 0x00053894
	[Address(RVA = "0x34BD78C", Offset = "0x34BD78C", VA = "0x34BD78C")]
	[Token(Token = "0x60027F6")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("CapuchinRemade");
	}

	// Token: 0x060027F7 RID: 10231 RVA: 0x000556B4 File Offset: 0x000538B4
	[Address(RVA = "0x34BD808", Offset = "0x34BD808", VA = "0x34BD808")]
	[Token(Token = "0x60027F7")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("\tExpires: ");
	}

	// Token: 0x060027F8 RID: 10232 RVA: 0x000556D4 File Offset: 0x000538D4
	[Address(RVA = "0x34BD884", Offset = "0x34BD884", VA = "0x34BD884")]
	[Token(Token = "0x60027F8")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}");
	}

	// Token: 0x060027F9 RID: 10233 RVA: 0x000556F4 File Offset: 0x000538F4
	[Address(RVA = "0x34BD900", Offset = "0x34BD900", VA = "0x34BD900")]
	[Token(Token = "0x60027F9")]
	public void method_19()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("TurnAmount");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("friend").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x060027FA RID: 10234 RVA: 0x00055800 File Offset: 0x00053A00
	[Token(Token = "0x60027FA")]
	[Address(RVA = "0x34BDD34", Offset = "0x34BDD34", VA = "0x34BDD34")]
	public void method_20()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Agreed");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag(".Please press the button if you would like to play alone").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x060027FB RID: 10235 RVA: 0x0005590C File Offset: 0x00053B0C
	[Address(RVA = "0x34BE168", Offset = "0x34BE168", VA = "0x34BE168")]
	[Token(Token = "0x60027FB")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Trying Getting Entilement...");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x060027FC RID: 10236 RVA: 0x00055934 File Offset: 0x00053B34
	[Address(RVA = "0x34BE1E8", Offset = "0x34BE1E8", VA = "0x34BE1E8")]
	[Token(Token = "0x60027FC")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Skelechin");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x060027FD RID: 10237 RVA: 0x0005595C File Offset: 0x00053B5C
	[Address(RVA = "0x34BE268", Offset = "0x34BE268", VA = "0x34BE268")]
	[Token(Token = "0x60027FD")]
	public void method_23()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Fire Stick Is Lighting...");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("TurnAmount").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x060027FE RID: 10238 RVA: 0x00055A68 File Offset: 0x00053C68
	[Address(RVA = "0x34BE69C", Offset = "0x34BE69C", VA = "0x34BE69C")]
	[Token(Token = "0x60027FE")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FLSPTLT");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x060027FF RID: 10239 RVA: 0x00055A90 File Offset: 0x00053C90
	[Address(RVA = "0x34BE71C", Offset = "0x34BE71C", VA = "0x34BE71C")]
	[Token(Token = "0x60027FF")]
	public void method_25()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("SaveHeight");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("ENABLE").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002800 RID: 10240 RVA: 0x00055B9C File Offset: 0x00053D9C
	[Address(RVA = "0x34BEB50", Offset = "0x34BEB50", VA = "0x34BEB50")]
	[Token(Token = "0x6002800")]
	public void method_26()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("_BaseColor").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002801 RID: 10241 RVA: 0x00037F30 File Offset: 0x00036130
	[Token(Token = "0x6002801")]
	[Address(RVA = "0x34BEF84", Offset = "0x34BEF84", VA = "0x34BEF84")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PlayerHead");
	}

	// Token: 0x06002802 RID: 10242 RVA: 0x00055CA8 File Offset: 0x00053EA8
	[Token(Token = "0x6002802")]
	[Address(RVA = "0x34BF000", Offset = "0x34BF000", VA = "0x34BF000")]
	public void method_28()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("username");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("Name Changing Error. Error: ").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002803 RID: 10243 RVA: 0x00055DA8 File Offset: 0x00053FA8
	[Token(Token = "0x6002803")]
	[Address(RVA = "0x34BF434", Offset = "0x34BF434", VA = "0x34BF434")]
	public void method_29()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Purchase For ");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("BN").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002804 RID: 10244 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6002804")]
	[Address(RVA = "0x34BF868", Offset = "0x34BF868", VA = "0x34BF868")]
	public lerpScaleAndPos()
	{
	}

	// Token: 0x06002805 RID: 10245 RVA: 0x00055EB4 File Offset: 0x000540B4
	[Address(RVA = "0x34BF870", Offset = "0x34BF870", VA = "0x34BF870")]
	[Token(Token = "0x6002805")]
	public void method_30()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("goDownRPC").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002806 RID: 10246 RVA: 0x00055FC0 File Offset: 0x000541C0
	[Token(Token = "0x6002806")]
	[Address(RVA = "0x34BFCA4", Offset = "0x34BFCA4", VA = "0x34BFCA4")]
	public void method_31()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("This is the 2500 Bananas button, and it was just clicked");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("_Tint").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002807 RID: 10247 RVA: 0x000560CC File Offset: 0x000542CC
	[Address(RVA = "0x34C00D8", Offset = "0x34C00D8", VA = "0x34C00D8")]
	[Token(Token = "0x6002807")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.CompareTag(".Please press the button if you would like to play alone");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002808 RID: 10248 RVA: 0x000560F4 File Offset: 0x000542F4
	[Token(Token = "0x6002808")]
	[Address(RVA = "0x34C0158", Offset = "0x34C0158", VA = "0x34C0158")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("false");
	}

	// Token: 0x06002809 RID: 10249 RVA: 0x00056114 File Offset: 0x00054314
	[Address(RVA = "0x34C01D4", Offset = "0x34C01D4", VA = "0x34C01D4")]
	[Token(Token = "0x6002809")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_WobbleX");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600280A RID: 10250 RVA: 0x0005613C File Offset: 0x0005433C
	[Token(Token = "0x600280A")]
	[Address(RVA = "0x34C0254", Offset = "0x34C0254", VA = "0x34C0254")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("GET");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600280B RID: 10251 RVA: 0x00056164 File Offset: 0x00054364
	[Address(RVA = "0x34C02D4", Offset = "0x34C02D4", VA = "0x34C02D4")]
	[Token(Token = "0x600280B")]
	public void method_36()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("_Tint");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("SetColor").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600280C RID: 10252 RVA: 0x00056270 File Offset: 0x00054470
	[Token(Token = "0x600280C")]
	[Address(RVA = "0x34C0708", Offset = "0x34C0708", VA = "0x34C0708")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600280D RID: 10253 RVA: 0x0003E7D8 File Offset: 0x0003C9D8
	[Address(RVA = "0x34C0788", Offset = "0x34C0788", VA = "0x34C0788")]
	[Token(Token = "0x600280D")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Bruh i cannot go here you stupid L bozo");
	}

	// Token: 0x0600280E RID: 10254 RVA: 0x00056298 File Offset: 0x00054498
	[Address(RVA = "0x34C0804", Offset = "0x34C0804", VA = "0x34C0804")]
	[Token(Token = "0x600280E")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PlayWave");
	}

	// Token: 0x0600280F RID: 10255 RVA: 0x000562B8 File Offset: 0x000544B8
	[Address(RVA = "0x34C0880", Offset = "0x34C0880", VA = "0x34C0880")]
	[Token(Token = "0x600280F")]
	public void method_40()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Queue");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("forced knee retract").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002810 RID: 10256 RVA: 0x000563C4 File Offset: 0x000545C4
	[Address(RVA = "0x34C0CB4", Offset = "0x34C0CB4", VA = "0x34C0CB4")]
	[Token(Token = "0x6002810")]
	public void method_41()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("Charging...").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002811 RID: 10257 RVA: 0x000564D0 File Offset: 0x000546D0
	[Address(RVA = "0x34C10E8", Offset = "0x34C10E8", VA = "0x34C10E8")]
	[Token(Token = "0x6002811")]
	public void method_42()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("DisableCosmetic");
		this.gameObject_0 = gameObject;
		GameObject.FindGameObjectWithTag("CASUAL").GetComponent<PhotonView>();
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002812 RID: 10258 RVA: 0x000565D4 File Offset: 0x000547D4
	[Address(RVA = "0x34C151C", Offset = "0x34C151C", VA = "0x34C151C")]
	[Token(Token = "0x6002812")]
	public void method_43(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Grip");
	}

	// Token: 0x06002813 RID: 10259 RVA: 0x000565F4 File Offset: 0x000547F4
	[Address(RVA = "0x34C1598", Offset = "0x34C1598", VA = "0x34C1598")]
	[Token(Token = "0x6002813")]
	public void method_44()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("NormalWeather");
		this.gameObject_0 = gameObject;
		GameObject gameObject2;
		PhotonView component = gameObject2.GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		float value3;
		if (this.bool_0)
		{
			Transform transform = this.transform_0;
			Vector3 localScale2 = transform.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			value3 = Mathf.Clamp01(value);
			Vector3 localScale4 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform3 = this.transform_0;
		Vector3 localScale5 = transform3.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform4 = this.transform_0;
		Vector3 localScale6 = transform4.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform5 = this.gameObject_0.transform;
		Vector3 localScale7 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002814 RID: 10260 RVA: 0x00037FE8 File Offset: 0x000361E8
	[Address(RVA = "0x34C19CC", Offset = "0x34C19CC", VA = "0x34C19CC")]
	[Token(Token = "0x6002814")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
	}

	// Token: 0x06002815 RID: 10261 RVA: 0x000566D8 File Offset: 0x000548D8
	[Address(RVA = "0x34C1A48", Offset = "0x34C1A48", VA = "0x34C1A48")]
	[Token(Token = "0x6002815")]
	public void method_46()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Try Connect To Server...");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("spooky guy true").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform4 = this.transform_0;
		Vector3 localScale6 = transform4.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform5 = this.transform_0;
		Vector3 localScale7 = transform5.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform6 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002816 RID: 10262 RVA: 0x000556B4 File Offset: 0x000538B4
	[Address(RVA = "0x34C1E7C", Offset = "0x34C1E7C", VA = "0x34C1E7C")]
	[Token(Token = "0x6002816")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("\tExpires: ");
	}

	// Token: 0x06002817 RID: 10263 RVA: 0x000567D8 File Offset: 0x000549D8
	[Address(RVA = "0x34C1EF8", Offset = "0x34C1EF8", VA = "0x34C1EF8")]
	[Token(Token = "0x6002817")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
	}

	// Token: 0x06002818 RID: 10264 RVA: 0x000567F8 File Offset: 0x000549F8
	[Token(Token = "0x6002818")]
	[Address(RVA = "0x34C1F74", Offset = "0x34C1F74", VA = "0x34C1F74")]
	public void method_48()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("/");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("liftoff failed!").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002819 RID: 10265 RVA: 0x00056904 File Offset: 0x00054B04
	[Address(RVA = "0x34C23A8", Offset = "0x34C23A8", VA = "0x34C23A8")]
	[Token(Token = "0x6002819")]
	public void method_49(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("trol");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600281A RID: 10266 RVA: 0x0005692C File Offset: 0x00054B2C
	[Address(RVA = "0x34C2428", Offset = "0x34C2428", VA = "0x34C2428")]
	[Token(Token = "0x600281A")]
	public void method_50()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("PushToTalk");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("CASUAL").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600281B RID: 10267 RVA: 0x00037F30 File Offset: 0x00036130
	[Address(RVA = "0x34C285C", Offset = "0x34C285C", VA = "0x34C285C")]
	[Token(Token = "0x600281B")]
	public void method_51(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PlayerHead");
	}

	// Token: 0x0600281C RID: 10268 RVA: 0x00056A38 File Offset: 0x00054C38
	[Address(RVA = "0x34C28D8", Offset = "0x34C28D8", VA = "0x34C28D8")]
	[Token(Token = "0x600281C")]
	public void method_52(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Version");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600281D RID: 10269 RVA: 0x00056A60 File Offset: 0x00054C60
	[Address(RVA = "0x34C2958", Offset = "0x34C2958", VA = "0x34C2958")]
	[Token(Token = "0x600281D")]
	public void method_53(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("CapuchinStore");
	}

	// Token: 0x0600281E RID: 10270 RVA: 0x00056A80 File Offset: 0x00054C80
	[Address(RVA = "0x34C29D4", Offset = "0x34C29D4", VA = "0x34C29D4")]
	[Token(Token = "0x600281E")]
	public void method_54()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("BLUTARG");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("ChangeToTagged").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600281F RID: 10271 RVA: 0x000552A8 File Offset: 0x000534A8
	[Address(RVA = "0x34C2E08", Offset = "0x34C2E08", VA = "0x34C2E08")]
	[Token(Token = "0x600281F")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002820 RID: 10272 RVA: 0x00056B8C File Offset: 0x00054D8C
	[Address(RVA = "0x34C2E88", Offset = "0x34C2E88", VA = "0x34C2E88")]
	[Token(Token = "0x6002820")]
	public void method_55(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ChangeToRegular");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002821 RID: 10273 RVA: 0x00056BB4 File Offset: 0x00054DB4
	[Token(Token = "0x6002821")]
	[Address(RVA = "0x34C2F08", Offset = "0x34C2F08", VA = "0x34C2F08")]
	public void method_56()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Charging...");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("\n Time: ").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002822 RID: 10274 RVA: 0x00056CC0 File Offset: 0x00054EC0
	[Address(RVA = "0x34C333C", Offset = "0x34C333C", VA = "0x34C333C")]
	[Token(Token = "0x6002822")]
	public void method_57()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("SaveHeight");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("FingerTip").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002823 RID: 10275 RVA: 0x00056DCC File Offset: 0x00054FCC
	[Token(Token = "0x6002823")]
	[Address(RVA = "0x34C3770", Offset = "0x34C3770", VA = "0x34C3770")]
	public void method_58(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PLAYER IS BANNED");
	}

	// Token: 0x06002824 RID: 10276 RVA: 0x00056DEC File Offset: 0x00054FEC
	[Address(RVA = "0x34C37EC", Offset = "0x34C37EC", VA = "0x34C37EC")]
	[Token(Token = "0x6002824")]
	public void method_59(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("username");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002825 RID: 10277 RVA: 0x00056E14 File Offset: 0x00055014
	[Address(RVA = "0x34C386C", Offset = "0x34C386C", VA = "0x34C386C")]
	[Token(Token = "0x6002825")]
	public void method_60()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("EnableCosmetic");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("Player").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002826 RID: 10278 RVA: 0x00056F20 File Offset: 0x00055120
	[Address(RVA = "0x34C3CA0", Offset = "0x34C3CA0", VA = "0x34C3CA0")]
	[Token(Token = "0x6002826")]
	public void Update()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("NetworkPlayer");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("NetworkPlayer").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002827 RID: 10279 RVA: 0x0005702C File Offset: 0x0005522C
	[Address(RVA = "0x34C40B8", Offset = "0x34C40B8", VA = "0x34C40B8")]
	[Token(Token = "0x6002827")]
	public void method_61()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("BN");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("This is the 1000 Bananas button, and it was just clicked").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002828 RID: 10280 RVA: 0x00057138 File Offset: 0x00055338
	[Address(RVA = "0x34C44EC", Offset = "0x34C44EC", VA = "0x34C44EC")]
	[Token(Token = "0x6002828")]
	public void method_62(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Joined a Room.");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002829 RID: 10281 RVA: 0x00057160 File Offset: 0x00055360
	[Address(RVA = "0x34C456C", Offset = "0x34C456C", VA = "0x34C456C")]
	[Token(Token = "0x6002829")]
	public void method_63()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("HorrorAgreement");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("Completed baking textures on frame ").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600282A RID: 10282 RVA: 0x000567D8 File Offset: 0x000549D8
	[Address(RVA = "0x34C49A0", Offset = "0x34C49A0", VA = "0x34C49A0")]
	[Token(Token = "0x600282A")]
	public void method_64(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
	}

	// Token: 0x0600282B RID: 10283 RVA: 0x000379E0 File Offset: 0x00035BE0
	[Address(RVA = "0x34C4A1C", Offset = "0x34C4A1C", VA = "0x34C4A1C")]
	[Token(Token = "0x600282B")]
	public void method_65(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
	}

	// Token: 0x0600282C RID: 10284 RVA: 0x0005726C File Offset: 0x0005546C
	[Address(RVA = "0x34C4A98", Offset = "0x34C4A98", VA = "0x34C4A98")]
	[Token(Token = "0x600282C")]
	public void method_66(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ORGPORT");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600282D RID: 10285 RVA: 0x00057294 File Offset: 0x00055494
	[Address(RVA = "0x34C4B18", Offset = "0x34C4B18", VA = "0x34C4B18")]
	[Token(Token = "0x600282D")]
	public void method_67(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Updating Material to: ");
	}

	// Token: 0x0600282E RID: 10286 RVA: 0x000572B4 File Offset: 0x000554B4
	[Address(RVA = "0x34C4B94", Offset = "0x34C4B94", VA = "0x34C4B94")]
	[Token(Token = "0x600282E")]
	public void method_68()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("Agreed").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600282F RID: 10287 RVA: 0x00037FE8 File Offset: 0x000361E8
	[Address(RVA = "0x34C4FC8", Offset = "0x34C4FC8", VA = "0x34C4FC8")]
	[Token(Token = "0x600282F")]
	public void method_69(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
	}

	// Token: 0x06002830 RID: 10288 RVA: 0x000573C0 File Offset: 0x000555C0
	[Address(RVA = "0x34C5044", Offset = "0x34C5044", VA = "0x34C5044")]
	[Token(Token = "0x6002830")]
	public void method_70()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("openvr");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("\tExpires: ").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002831 RID: 10289 RVA: 0x000574CC File Offset: 0x000556CC
	[Token(Token = "0x6002831")]
	[Address(RVA = "0x34C5478", Offset = "0x34C5478", VA = "0x34C5478")]
	public void method_71(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PRESS AGAIN TO CONFIRM");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002832 RID: 10290 RVA: 0x000574F4 File Offset: 0x000556F4
	[Address(RVA = "0x34C54F8", Offset = "0x34C54F8", VA = "0x34C54F8")]
	[Token(Token = "0x6002832")]
	public void method_72(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("'s Grabber is not assigned.");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002833 RID: 10291 RVA: 0x0005751C File Offset: 0x0005571C
	[Token(Token = "0x6002833")]
	[Address(RVA = "0x34C5578", Offset = "0x34C5578", VA = "0x34C5578")]
	public void method_73()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("SaveHeight");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("GET").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002834 RID: 10292 RVA: 0x00057628 File Offset: 0x00055828
	[Address(RVA = "0x34C59AC", Offset = "0x34C59AC", VA = "0x34C59AC")]
	[Token(Token = "0x6002834")]
	public void method_74()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("username");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("oculus").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002835 RID: 10293 RVA: 0x00057734 File Offset: 0x00055934
	[Token(Token = "0x6002835")]
	[Address(RVA = "0x34C5DE0", Offset = "0x34C5DE0", VA = "0x34C5DE0")]
	public void method_75(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("hh:mmtt");
	}

	// Token: 0x06002836 RID: 10294 RVA: 0x00057754 File Offset: 0x00055954
	[Address(RVA = "0x34C5E5C", Offset = "0x34C5E5C", VA = "0x34C5E5C")]
	[Token(Token = "0x6002836")]
	public void method_76()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Add/Remove Sword");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("Player").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002837 RID: 10295 RVA: 0x00057860 File Offset: 0x00055A60
	[Token(Token = "0x6002837")]
	[Address(RVA = "0x34C6290", Offset = "0x34C6290", VA = "0x34C6290")]
	public void method_77(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.CompareTag("duration done");
	}

	// Token: 0x06002838 RID: 10296 RVA: 0x0005787C File Offset: 0x00055A7C
	[Address(RVA = "0x34C630C", Offset = "0x34C630C", VA = "0x34C630C")]
	[Token(Token = "0x6002838")]
	public void method_78()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Left a room");
		this.gameObject_0 = gameObject;
		GameObject gameObject2;
		PhotonView component = gameObject2.GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002839 RID: 10297 RVA: 0x00057980 File Offset: 0x00055B80
	[Token(Token = "0x6002839")]
	[Address(RVA = "0x34C673C", Offset = "0x34C673C", VA = "0x34C673C")]
	public void method_79()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("\tExpires: ");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("closeToObject").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600283A RID: 10298 RVA: 0x00057A8C File Offset: 0x00055C8C
	[Address(RVA = "0x34C6B70", Offset = "0x34C6B70", VA = "0x34C6B70")]
	[Token(Token = "0x600283A")]
	public void method_80(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Done");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600283B RID: 10299 RVA: 0x00057AB4 File Offset: 0x00055CB4
	[Token(Token = "0x600283B")]
	[Address(RVA = "0x34C6BF0", Offset = "0x34C6BF0", VA = "0x34C6BF0")]
	public void method_81(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600283C RID: 10300 RVA: 0x00057AD4 File Offset: 0x00055CD4
	[Token(Token = "0x600283C")]
	[Address(RVA = "0x34C6C70", Offset = "0x34C6C70", VA = "0x34C6C70")]
	public void method_82(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("NormalWeather");
	}

	// Token: 0x0600283D RID: 10301 RVA: 0x00057AB4 File Offset: 0x00055CB4
	[Address(RVA = "0x34C6CEC", Offset = "0x34C6CEC", VA = "0x34C6CEC")]
	[Token(Token = "0x600283D")]
	public void method_83(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600283E RID: 10302 RVA: 0x00057AF4 File Offset: 0x00055CF4
	[Token(Token = "0x600283E")]
	[Address(RVA = "0x34C6D6C", Offset = "0x34C6D6C", VA = "0x34C6D6C")]
	public void method_84()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Name Changing Error. Error: ");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("ChangeMaterialToNormal").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Vector3 localScale3 = transform.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform2 = this.transform_0;
			Vector3 localScale4 = transform2.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform3 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform4 = this.transform_0;
		Vector3 localScale6 = transform4.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform5 = this.transform_0;
		Vector3 localScale7 = transform5.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform6 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600283F RID: 10303 RVA: 0x00057BF8 File Offset: 0x00055DF8
	[Address(RVA = "0x34C71A0", Offset = "0x34C71A0", VA = "0x34C71A0")]
	[Token(Token = "0x600283F")]
	public void method_85()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Failed To Join Public Room Successfully. The error is: ");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("You are not the master of the server, you cannot start the game.").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002840 RID: 10304 RVA: 0x00037BF8 File Offset: 0x00035DF8
	[Token(Token = "0x6002840")]
	[Address(RVA = "0x34C75D4", Offset = "0x34C75D4", VA = "0x34C75D4")]
	public void method_86(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("TurnAmount");
	}

	// Token: 0x06002841 RID: 10305 RVA: 0x00057D04 File Offset: 0x00055F04
	[Address(RVA = "0x34C7650", Offset = "0x34C7650", VA = "0x34C7650")]
	[Token(Token = "0x6002841")]
	public void method_87()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("goDownRPC");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("Not connected to room").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Vector3 localScale3 = this.transform_0.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform2 = this.transform_0;
			Vector3 localScale4 = transform2.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform3 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform4 = this.transform_0;
		Vector3 localScale6 = transform4.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform5 = this.transform_0;
		Vector3 localScale7 = transform5.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform6 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002842 RID: 10306 RVA: 0x000552A8 File Offset: 0x000534A8
	[Address(RVA = "0x34C7A84", Offset = "0x34C7A84", VA = "0x34C7A84")]
	[Token(Token = "0x6002842")]
	public void method_88(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002843 RID: 10307 RVA: 0x00057E0C File Offset: 0x0005600C
	[Token(Token = "0x6002843")]
	[Address(RVA = "0x34C7B04", Offset = "0x34C7B04", VA = "0x34C7B04")]
	public void method_89(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("CASUAL");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002844 RID: 10308 RVA: 0x00037FE8 File Offset: 0x000361E8
	[Token(Token = "0x6002844")]
	[Address(RVA = "0x34C7B84", Offset = "0x34C7B84", VA = "0x34C7B84")]
	public void method_90(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
	}

	// Token: 0x06002845 RID: 10309 RVA: 0x00057E34 File Offset: 0x00056034
	[Token(Token = "0x6002845")]
	[Address(RVA = "0x34C7C00", Offset = "0x34C7C00", VA = "0x34C7C00")]
	public void method_91()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("FingerTip");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("got funky mone").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x06002846 RID: 10310 RVA: 0x00057F40 File Offset: 0x00056140
	[Address(RVA = "0x34C8034", Offset = "0x34C8034", VA = "0x34C8034")]
	[Token(Token = "0x6002846")]
	public void method_92(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("BLUTARG");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002847 RID: 10311 RVA: 0x00057F68 File Offset: 0x00056168
	[Token(Token = "0x6002847")]
	[Address(RVA = "0x34C80B4", Offset = "0x34C80B4", VA = "0x34C80B4")]
	public void method_93(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Agreed");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002848 RID: 10312 RVA: 0x000552A8 File Offset: 0x000534A8
	[Token(Token = "0x6002848")]
	[Address(RVA = "0x34C8134", Offset = "0x34C8134", VA = "0x34C8134")]
	public void method_94(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002849 RID: 10313 RVA: 0x00057F90 File Offset: 0x00056190
	[Address(RVA = "0x34C81B4", Offset = "0x34C81B4", VA = "0x34C81B4")]
	[Token(Token = "0x6002849")]
	public void method_95(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Camera movement detected, calibrating height.");
	}

	// Token: 0x0600284A RID: 10314 RVA: 0x00057FB0 File Offset: 0x000561B0
	[Token(Token = "0x600284A")]
	[Address(RVA = "0x34C8230", Offset = "0x34C8230", VA = "0x34C8230")]
	public void method_96()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("TurnAmount");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("StartGamemode").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600284B RID: 10315 RVA: 0x000580BC File Offset: 0x000562BC
	[Address(RVA = "0x34C8664", Offset = "0x34C8664", VA = "0x34C8664")]
	[Token(Token = "0x600284B")]
	public void method_97()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("got funky mone").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600284C RID: 10316 RVA: 0x000581C8 File Offset: 0x000563C8
	[Token(Token = "0x600284C")]
	[Address(RVA = "0x34C8A98", Offset = "0x34C8A98", VA = "0x34C8A98")]
	public void method_98()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("BN");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("ErrorScreen").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = transform7.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600284D RID: 10317 RVA: 0x000582D0 File Offset: 0x000564D0
	[Token(Token = "0x600284D")]
	[Address(RVA = "0x34C8ECC", Offset = "0x34C8ECC", VA = "0x34C8ECC")]
	public void method_99()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("Target");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("DisableCosmetic").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600284E RID: 10318 RVA: 0x000583DC File Offset: 0x000565DC
	[Address(RVA = "0x34C9300", Offset = "0x34C9300", VA = "0x34C9300")]
	[Token(Token = "0x600284E")]
	public void method_100()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("goUpRPC");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("User has been reported for: ").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0600284F RID: 10319 RVA: 0x000552A8 File Offset: 0x000534A8
	[Address(RVA = "0x34C9734", Offset = "0x34C9734", VA = "0x34C9734")]
	[Token(Token = "0x600284F")]
	public void method_101(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06002850 RID: 10320 RVA: 0x000584E8 File Offset: 0x000566E8
	[Address(RVA = "0x34C97B4", Offset = "0x34C97B4", VA = "0x34C97B4")]
	[Token(Token = "0x6002850")]
	public void method_102()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = GameObject.FindGameObjectWithTag("friend");
		this.gameObject_0 = gameObject;
		PhotonView component = GameObject.FindGameObjectWithTag("XR Usage").GetComponent<PhotonView>();
		this.photonView_0 = component;
		Vector3 localScale = this.transform_0.localScale;
		Transform transform = this.transform_0;
		bool flag = this.bool_0;
		Vector3 localScale2 = transform.localScale;
		float value3;
		if (flag)
		{
			Transform transform2 = this.transform_0;
			Vector3 localScale3 = transform2.localScale;
			float value2;
			float value = Mathf.Clamp01(value2);
			Transform transform3 = this.transform_0;
			Vector3 localScale4 = transform3.localScale;
			value3 = Mathf.Clamp01(value);
			Transform transform4 = this.gameObject_0.transform;
			Vector3 localScale5 = this.transform_0.localScale;
			return;
		}
		float value4 = Mathf.Clamp01(value3);
		Transform transform5 = this.transform_0;
		Vector3 localScale6 = transform5.localScale;
		float value5 = Mathf.Clamp01(value4);
		Transform transform6 = this.transform_0;
		Vector3 localScale7 = transform6.localScale;
		float value6 = Mathf.Clamp01(value5);
		Transform transform7 = this.gameObject_0.transform;
		Vector3 localScale8 = this.transform_0.localScale;
		Mathf.Clamp01(value6);
	}

	// Token: 0x0400053A RID: 1338
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400053A")]
	public Transform transform_0;

	// Token: 0x0400053B RID: 1339
	[Token(Token = "0x400053B")]
	[FieldOffset(Offset = "0x20")]
	public Transform transform_1;

	// Token: 0x0400053C RID: 1340
	[Token(Token = "0x400053C")]
	[FieldOffset(Offset = "0x28")]
	public Transform transform_2;

	// Token: 0x0400053D RID: 1341
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400053D")]
	public GameObject gameObject_0;

	// Token: 0x0400053E RID: 1342
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400053E")]
	public PhotonView photonView_0;

	// Token: 0x0400053F RID: 1343
	[Token(Token = "0x400053F")]
	[FieldOffset(Offset = "0x40")]
	public bool bool_0;

	// Token: 0x04000540 RID: 1344
	[FieldOffset(Offset = "0x41")]
	[Token(Token = "0x4000540")]
	public bool bool_1;

	// Token: 0x04000541 RID: 1345
	[Token(Token = "0x4000541")]
	[FieldOffset(Offset = "0x44")]
	public lerpScaleAndPos.Lerp lerp_0;

	// Token: 0x0200010A RID: 266
	[Token(Token = "0x200010A")]
	[Serializable]
	public struct Lerp
	{
		// Token: 0x04000542 RID: 1346
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000542")]
		public float lerpSpeed;

		// Token: 0x04000543 RID: 1347
		[FieldOffset(Offset = "0x4")]
		[Token(Token = "0x4000543")]
		public lerpScaleAndPos.Lerp.Scale ScaleData;

		// Token: 0x0200010B RID: 267
		[Token(Token = "0x200010B")]
		[Serializable]
		public struct Scale
		{
			// Token: 0x04000544 RID: 1348
			[Token(Token = "0x4000544")]
			[FieldOffset(Offset = "0x0")]
			public Vector3 standardSize;

			// Token: 0x04000545 RID: 1349
			[Token(Token = "0x4000545")]
			[FieldOffset(Offset = "0xC")]
			public Vector3 smallSize;
		}
	}
}
