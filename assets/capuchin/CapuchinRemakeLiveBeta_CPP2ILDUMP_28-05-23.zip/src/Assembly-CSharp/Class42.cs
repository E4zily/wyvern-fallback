﻿using System;
using System.Collections;
using System.Collections.Generic;
using Cpp2IlInjected;

// Token: 0x0200013E RID: 318
[Token(Token = "0x200013E")]
internal class Class42<T> : IEnumerable<T>, IEnumerable
{
	// Token: 0x06003330 RID: 13104 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E9706C", Offset = "0x2E9706C", VA = "0x2E9706C")]
	[Token(Token = "0x6003330")]
	public int method_0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003331 RID: 13105 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E97088", Offset = "0x2E97088", VA = "0x2E97088", Slot = "6")]
	[Token(Token = "0x6003331")]
	private IEnumerator vmethod_0()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003332 RID: 13106 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E970AC", Offset = "0x2E970AC", VA = "0x2E970AC")]
	[Token(Token = "0x6003332")]
	public bool method_1()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003333 RID: 13107 RVA: 0x00065DE4 File Offset: 0x00063FE4
	[Address(RVA = "0x2E9710C", Offset = "0x2E9710C", VA = "0x2E9710C")]
	[Token(Token = "0x6003333")]
	public void method_2(T gparam_1)
	{
		this.int_2 = gparam_1;
		int num = this.int_1;
		this.int_0 = num;
	}

	// Token: 0x06003334 RID: 13108 RVA: 0x0000317E File Offset: 0x0000137E
	[Address(RVA = "0x2E971D0", Offset = "0x2E971D0", VA = "0x2E971D0")]
	[Token(Token = "0x6003334")]
	private void method_3(ref int int_3)
	{
		int_3.m_value = this;
		int_3.m_value = this;
	}

	// Token: 0x06003335 RID: 13109 RVA: 0x0000317E File Offset: 0x0000137E
	[Address(RVA = "0x2E97220", Offset = "0x2E97220", VA = "0x2E97220")]
	[Token(Token = "0x6003335")]
	private void method_4(ref int int_3)
	{
		int_3.m_value = this;
		int_3.m_value = this;
	}

	// Token: 0x06003336 RID: 13110 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E97270", Offset = "0x2E97270", VA = "0x2E97270")]
	[Token(Token = "0x6003336")]
	private void method_5(ref int int_3)
	{
	}

	// Token: 0x06003337 RID: 13111 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E972B8", Offset = "0x2E972B8", VA = "0x2E972B8")]
	[Token(Token = "0x6003337")]
	private void method_6(ref int int_3)
	{
	}

	// Token: 0x06003338 RID: 13112 RVA: 0x0000317E File Offset: 0x0000137E
	[Address(RVA = "0x2E97308", Offset = "0x2E97308", VA = "0x2E97308")]
	[Token(Token = "0x6003338")]
	private void method_7(ref int int_3)
	{
		int_3.m_value = this;
		int_3.m_value = this;
	}

	// Token: 0x06003339 RID: 13113 RVA: 0x00065E08 File Offset: 0x00064008
	[Address(RVA = "0x2E97358", Offset = "0x2E97358", VA = "0x2E97358")]
	[Token(Token = "0x6003339")]
	private void method_8(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x0600333A RID: 13114 RVA: 0x0000318E File Offset: 0x0000138E
	[Address(RVA = "0x2E973CC", Offset = "0x2E973CC", VA = "0x2E973CC")]
	[Token(Token = "0x600333A")]
	private void method_9(ref int int_3)
	{
		int_3.m_value = this;
	}

	// Token: 0x1700008E RID: 142
	[Token(Token = "0x1700008E")]
	public T this[int int_3]
	{
		[Address(RVA = "0x2E97410", Offset = "0x2E97410", VA = "0x2E97410")]
		[Token(Token = "0x600333B")]
		get
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}
		[Address(RVA = "0x2E9974C", Offset = "0x2E9974C", VA = "0x2E9974C")]
		[Token(Token = "0x6003389")]
		set
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}
	}

	// Token: 0x0600333C RID: 13116 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E97580", Offset = "0x2E97580", VA = "0x2E97580")]
	[Token(Token = "0x600333C")]
	public T method_10()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600333D RID: 13117 RVA: 0x0000317E File Offset: 0x0000137E
	[Address(RVA = "0x2E97620", Offset = "0x2E97620", VA = "0x2E97620")]
	[Token(Token = "0x600333D")]
	private void method_11(ref int int_3)
	{
		int_3.m_value = this;
		int_3.m_value = this;
	}

	// Token: 0x0600333E RID: 13118 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E97670", Offset = "0x2E97670", VA = "0x2E97670")]
	[Token(Token = "0x600333E")]
	public void method_12()
	{
	}

	// Token: 0x0600333F RID: 13119 RVA: 0x00003197 File Offset: 0x00001397
	[Address(RVA = "0x2E97734", Offset = "0x2E97734", VA = "0x2E97734")]
	[Token(Token = "0x600333F")]
	public int method_13()
	{
		return this.int_2;
	}

	// Token: 0x06003340 RID: 13120 RVA: 0x0000317E File Offset: 0x0000137E
	[Address(RVA = "0x2E9773C", Offset = "0x2E9773C", VA = "0x2E9773C")]
	[Token(Token = "0x6003340")]
	private void method_14(ref int int_3)
	{
		int_3.m_value = this;
		int_3.m_value = this;
	}

	// Token: 0x06003341 RID: 13121 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E9778C", Offset = "0x2E9778C", VA = "0x2E9778C", Slot = "7")]
	[Token(Token = "0x6003341")]
	private IEnumerator vmethod_1()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003342 RID: 13122 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E977B0", Offset = "0x2E977B0", VA = "0x2E977B0")]
	[Token(Token = "0x6003342")]
	public bool method_15()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003343 RID: 13123 RVA: 0x00065E08 File Offset: 0x00064008
	[Address(RVA = "0x2E977E4", Offset = "0x2E977E4", VA = "0x2E977E4")]
	[Token(Token = "0x6003343")]
	private void method_16(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x06003344 RID: 13124 RVA: 0x00065E18 File Offset: 0x00064018
	[Address(RVA = "0x2E97858", Offset = "0x2E97858", VA = "0x2E97858")]
	[Token(Token = "0x6003344")]
	private int method_17(int int_3)
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003345 RID: 13125 RVA: 0x00065E08 File Offset: 0x00064008
	[Address(RVA = "0x2E978D4", Offset = "0x2E978D4", VA = "0x2E978D4")]
	[Token(Token = "0x6003345")]
	private void method_18(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x06003346 RID: 13126 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E97948", Offset = "0x2E97948", VA = "0x2E97948")]
	[Token(Token = "0x6003346")]
	public bool method_19()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003347 RID: 13127 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E979A8", Offset = "0x2E979A8", VA = "0x2E979A8")]
	[Token(Token = "0x6003347")]
	public bool method_20()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003348 RID: 13128 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E979DC", Offset = "0x2E979DC", VA = "0x2E979DC")]
	[Token(Token = "0x6003348")]
	public bool method_21()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003349 RID: 13129 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E97A10", Offset = "0x2E97A10", VA = "0x2E97A10", Slot = "8")]
	[Token(Token = "0x6003349")]
	private IEnumerator vmethod_2()
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600334A RID: 13130 RVA: 0x00003197 File Offset: 0x00001397
	[Address(RVA = "0x2E97A34", Offset = "0x2E97A34", VA = "0x2E97A34")]
	[Token(Token = "0x600334A")]
	public int method_22()
	{
		return this.int_2;
	}

	// Token: 0x0600334B RID: 13131 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E97A3C", Offset = "0x2E97A3C", VA = "0x2E97A3C", Slot = "5")]
	[Token(Token = "0x600334B")]
	IEnumerator IEnumerable.GetEnumerator()
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600334C RID: 13132 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E97A60", Offset = "0x2E97A60", VA = "0x2E97A60")]
	[Token(Token = "0x600334C")]
	private void method_23(ref int int_3)
	{
	}

	// Token: 0x0600334D RID: 13133 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E97AA8", Offset = "0x2E97AA8", VA = "0x2E97AA8")]
	[Token(Token = "0x600334D")]
	public void method_24()
	{
	}

	// Token: 0x0600334E RID: 13134 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E97B6C", Offset = "0x2E97B6C", VA = "0x2E97B6C")]
	[Token(Token = "0x600334E")]
	public void method_25(T gparam_1)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600334F RID: 13135 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E97C50", Offset = "0x2E97C50", VA = "0x2E97C50")]
	[Token(Token = "0x600334F")]
	public void method_26()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003350 RID: 13136 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E97D10", Offset = "0x2E97D10", VA = "0x2E97D10")]
	[Token(Token = "0x6003350")]
	public void method_27()
	{
	}

	// Token: 0x06003351 RID: 13137 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E97DD4", Offset = "0x2E97DD4", VA = "0x2E97DD4")]
	[Token(Token = "0x6003351")]
	private ArraySegment<T> method_28()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003352 RID: 13138 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E97EAC", Offset = "0x2E97EAC", VA = "0x2E97EAC")]
	[Token(Token = "0x6003352")]
	public void method_29()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003353 RID: 13139 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E97F7C", Offset = "0x2E97F7C", VA = "0x2E97F7C")]
	[Token(Token = "0x6003353")]
	public Class42(int int_3)
	{
	}

	// Token: 0x06003354 RID: 13140 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E97FF4", Offset = "0x2E97FF4", VA = "0x2E97FF4")]
	[Token(Token = "0x6003354")]
	public int method_30()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003355 RID: 13141 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E98010", Offset = "0x2E98010", VA = "0x2E98010")]
	[Token(Token = "0x6003355")]
	public void method_31()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003356 RID: 13142 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E980D0", Offset = "0x2E980D0", VA = "0x2E980D0")]
	[Token(Token = "0x6003356")]
	public bool method_32()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003357 RID: 13143 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E98104", Offset = "0x2E98104", VA = "0x2E98104")]
	[Token(Token = "0x6003357")]
	public bool method_33()
	{
		throw new NullReferenceException();
	}

	// Token: 0x1700008D RID: 141
	// (get) Token: 0x06003358 RID: 13144 RVA: 0x00003197 File Offset: 0x00001397
	[Token(Token = "0x1700008D")]
	public int Int32_1
	{
		[Address(RVA = "0x2E98138", Offset = "0x2E98138", VA = "0x2E98138")]
		[Token(Token = "0x6003358")]
		get
		{
			return this.int_2;
		}
	}

	// Token: 0x06003359 RID: 13145 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E98140", Offset = "0x2E98140", VA = "0x2E98140")]
	[Token(Token = "0x6003359")]
	public void method_34()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x1700008C RID: 140
	// (get) Token: 0x0600335A RID: 13146 RVA: 0x0000258C File Offset: 0x0000078C
	[Token(Token = "0x1700008C")]
	public bool Boolean_1
	{
		[Address(RVA = "0x2E98200", Offset = "0x2E98200", VA = "0x2E98200")]
		[Token(Token = "0x600335A")]
		get
		{
			throw new NullReferenceException();
		}
	}

	// Token: 0x0600335B RID: 13147 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E98234", Offset = "0x2E98234", VA = "0x2E98234")]
	[Token(Token = "0x600335B")]
	public void method_35()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600335C RID: 13148 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E982F4", Offset = "0x2E982F4", VA = "0x2E982F4")]
	[Token(Token = "0x600335C")]
	public void method_36()
	{
	}

	// Token: 0x0600335D RID: 13149 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E983B8", Offset = "0x2E983B8", VA = "0x2E983B8")]
	[Token(Token = "0x600335D")]
	public void method_37()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600335E RID: 13150 RVA: 0x00065E2C File Offset: 0x0006402C
	[Address(RVA = "0x2E98488", Offset = "0x2E98488", VA = "0x2E98488")]
	[Token(Token = "0x600335E")]
	private void method_38(ref int int_3)
	{
		long value = 1L;
		int_3.m_value = (int)value;
	}

	// Token: 0x0600335F RID: 13151 RVA: 0x00065E18 File Offset: 0x00064018
	[Address(RVA = "0x2E984D4", Offset = "0x2E984D4", VA = "0x2E984D4")]
	[Token(Token = "0x600335F")]
	private int method_39(int int_3)
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003360 RID: 13152 RVA: 0x00065E08 File Offset: 0x00064008
	[Address(RVA = "0x2E98550", Offset = "0x2E98550", VA = "0x2E98550")]
	[Token(Token = "0x6003360")]
	private void method_40(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x06003361 RID: 13153 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E985C4", Offset = "0x2E985C4", VA = "0x2E985C4")]
	[Token(Token = "0x6003361")]
	public bool method_41()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003362 RID: 13154 RVA: 0x00065E18 File Offset: 0x00064018
	[Address(RVA = "0x2E98624", Offset = "0x2E98624", VA = "0x2E98624")]
	[Token(Token = "0x6003362")]
	private int method_42(int int_3)
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003363 RID: 13155 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E986A0", Offset = "0x2E986A0", VA = "0x2E986A0")]
	[Token(Token = "0x6003363")]
	public int method_43()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003364 RID: 13156 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E986BC", Offset = "0x2E986BC", VA = "0x2E986BC")]
	[Token(Token = "0x6003364")]
	public bool method_44()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003365 RID: 13157 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E986F0", Offset = "0x2E986F0", VA = "0x2E986F0", Slot = "9")]
	[Token(Token = "0x6003365")]
	private IEnumerator vmethod_3()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003366 RID: 13158 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E98714", Offset = "0x2E98714", VA = "0x2E98714")]
	[Token(Token = "0x6003366")]
	public void method_45()
	{
	}

	// Token: 0x06003367 RID: 13159 RVA: 0x00003197 File Offset: 0x00001397
	[Address(RVA = "0x2E987D8", Offset = "0x2E987D8", VA = "0x2E987D8")]
	[Token(Token = "0x6003367")]
	public int method_46()
	{
		return this.int_2;
	}

	// Token: 0x06003368 RID: 13160 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E987E0", Offset = "0x2E987E0", VA = "0x2E987E0")]
	[Token(Token = "0x6003368")]
	public bool method_47()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003369 RID: 13161 RVA: 0x00065E44 File Offset: 0x00064044
	[Address(RVA = "0x2E98814", Offset = "0x2E98814", VA = "0x2E98814")]
	[Token(Token = "0x6003369")]
	public void method_48()
	{
		int num = this.int_2;
		this.int_2 = num;
	}

	// Token: 0x0600336A RID: 13162 RVA: 0x00065E18 File Offset: 0x00064018
	[Address(RVA = "0x2E988E8", Offset = "0x2E988E8", VA = "0x2E988E8")]
	[Token(Token = "0x600336A")]
	private int method_49(int int_3)
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600336B RID: 13163 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E98964", Offset = "0x2E98964", VA = "0x2E98964")]
	[Token(Token = "0x600336B")]
	public T method_50()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600336C RID: 13164 RVA: 0x00003197 File Offset: 0x00001397
	[Address(RVA = "0x2E98A24", Offset = "0x2E98A24", VA = "0x2E98A24")]
	[Token(Token = "0x600336C")]
	public int method_51()
	{
		return this.int_2;
	}

	// Token: 0x0600336D RID: 13165 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E98A2C", Offset = "0x2E98A2C", VA = "0x2E98A2C")]
	[Token(Token = "0x600336D")]
	public bool method_52()
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600336E RID: 13166 RVA: 0x00065E18 File Offset: 0x00064018
	[Address(RVA = "0x2E98A60", Offset = "0x2E98A60", VA = "0x2E98A60")]
	[Token(Token = "0x600336E")]
	private int method_53(int int_3)
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600336F RID: 13167 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E98ADC", Offset = "0x2E98ADC", VA = "0x2E98ADC")]
	[Token(Token = "0x600336F")]
	public bool method_54()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003370 RID: 13168 RVA: 0x0000317E File Offset: 0x0000137E
	[Address(RVA = "0x2E98B3C", Offset = "0x2E98B3C", VA = "0x2E98B3C")]
	[Token(Token = "0x6003370")]
	private void method_55(ref int int_3)
	{
		int_3.m_value = this;
		int_3.m_value = this;
	}

	// Token: 0x06003371 RID: 13169 RVA: 0x00065E18 File Offset: 0x00064018
	[Address(RVA = "0x2E98B8C", Offset = "0x2E98B8C", VA = "0x2E98B8C")]
	[Token(Token = "0x6003371")]
	private int method_56(int int_3)
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003372 RID: 13170 RVA: 0x00065E18 File Offset: 0x00064018
	[Address(RVA = "0x2E98C08", Offset = "0x2E98C08", VA = "0x2E98C08")]
	[Token(Token = "0x6003372")]
	private int method_57(int int_3)
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003373 RID: 13171 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E98C84", Offset = "0x2E98C84", VA = "0x2E98C84")]
	[Token(Token = "0x6003373")]
	public void method_58()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003374 RID: 13172 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E98D44", Offset = "0x2E98D44", VA = "0x2E98D44")]
	[Token(Token = "0x6003374")]
	private ArraySegment<T> method_59()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003375 RID: 13173 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E98E1C", Offset = "0x2E98E1C", VA = "0x2E98E1C")]
	[Token(Token = "0x6003375")]
	public int method_60()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003376 RID: 13174 RVA: 0x0000317E File Offset: 0x0000137E
	[Address(RVA = "0x2E98E38", Offset = "0x2E98E38", VA = "0x2E98E38")]
	[Token(Token = "0x6003376")]
	private void method_61(ref int int_3)
	{
		int_3.m_value = this;
		int_3.m_value = this;
	}

	// Token: 0x06003377 RID: 13175 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E98E88", Offset = "0x2E98E88", VA = "0x2E98E88")]
	[Token(Token = "0x6003377")]
	public int method_62()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003378 RID: 13176 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E98EA4", Offset = "0x2E98EA4", VA = "0x2E98EA4")]
	[Token(Token = "0x6003378")]
	public void method_63()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x1700008B RID: 139
	// (get) Token: 0x06003379 RID: 13177 RVA: 0x0000258C File Offset: 0x0000078C
	[Token(Token = "0x1700008B")]
	public bool Boolean_0
	{
		[Address(RVA = "0x2E98F64", Offset = "0x2E98F64", VA = "0x2E98F64")]
		[Token(Token = "0x6003379")]
		get
		{
			throw new NullReferenceException();
		}
	}

	// Token: 0x0600337A RID: 13178 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E98FC4", Offset = "0x2E98FC4", VA = "0x2E98FC4")]
	[Token(Token = "0x600337A")]
	private void method_64(ref int int_3)
	{
	}

	// Token: 0x0600337B RID: 13179 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E99014", Offset = "0x2E99014", VA = "0x2E99014")]
	[Token(Token = "0x600337B")]
	private void method_65(ref int int_3)
	{
	}

	// Token: 0x0600337C RID: 13180 RVA: 0x00065E60 File Offset: 0x00064060
	[Address(RVA = "0x2E99064", Offset = "0x2E99064", VA = "0x2E99064")]
	[Token(Token = "0x600337C")]
	public T[] method_66()
	{
		if (this.int_0 != 0)
		{
			this.int_2 = this;
		}
		throw new IndexOutOfRangeException();
	}

	// Token: 0x0600337D RID: 13181 RVA: 0x0000317E File Offset: 0x0000137E
	[Address(RVA = "0x2E991E8", Offset = "0x2E991E8", VA = "0x2E991E8")]
	[Token(Token = "0x600337D")]
	private void method_67(ref int int_3)
	{
		int_3.m_value = this;
		int_3.m_value = this;
	}

	// Token: 0x0600337E RID: 13182 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E99238", Offset = "0x2E99238", VA = "0x2E99238")]
	[Token(Token = "0x600337E")]
	private void method_68(ref int int_3)
	{
	}

	// Token: 0x0600337F RID: 13183 RVA: 0x00065E08 File Offset: 0x00064008
	[Address(RVA = "0x2E99288", Offset = "0x2E99288", VA = "0x2E99288")]
	[Token(Token = "0x600337F")]
	private void method_69(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x06003380 RID: 13184 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E992FC", Offset = "0x2E992FC", VA = "0x2E992FC")]
	[Token(Token = "0x6003380")]
	public void method_70()
	{
	}

	// Token: 0x06003381 RID: 13185 RVA: 0x00065E2C File Offset: 0x0006402C
	[Address(RVA = "0x2E993C0", Offset = "0x2E993C0", VA = "0x2E993C0")]
	[Token(Token = "0x6003381")]
	private void method_71(ref int int_3)
	{
		long value = 1L;
		int_3.m_value = (int)value;
	}

	// Token: 0x06003382 RID: 13186 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E9940C", Offset = "0x2E9940C", VA = "0x2E9940C")]
	[Token(Token = "0x6003382")]
	private void method_72(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x06003383 RID: 13187 RVA: 0x00065E44 File Offset: 0x00064044
	[Address(RVA = "0x2E99480", Offset = "0x2E99480", VA = "0x2E99480")]
	[Token(Token = "0x6003383")]
	public void method_73()
	{
		int num = this.int_2;
		this.int_2 = num;
	}

	// Token: 0x06003384 RID: 13188 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E99554", Offset = "0x2E99554", VA = "0x2E99554", Slot = "10")]
	[Token(Token = "0x6003384")]
	private IEnumerator vmethod_4()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003385 RID: 13189 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E99578", Offset = "0x2E99578", VA = "0x2E99578")]
	[Token(Token = "0x6003385")]
	private void method_74(ref int int_3)
	{
	}

	// Token: 0x06003386 RID: 13190 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E995C8", Offset = "0x2E995C8", VA = "0x2E995C8")]
	[Token(Token = "0x6003386")]
	public bool method_75()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003387 RID: 13191 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E99628", Offset = "0x2E99628", VA = "0x2E99628")]
	[Token(Token = "0x6003387")]
	public void method_76()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003388 RID: 13192 RVA: 0x00065E2C File Offset: 0x0006402C
	[Address(RVA = "0x2E996F8", Offset = "0x2E996F8", VA = "0x2E996F8")]
	[Token(Token = "0x6003388")]
	private void method_77(ref int int_3)
	{
		long value = 1L;
		int_3.m_value = (int)value;
	}

	// Token: 0x0600338A RID: 13194 RVA: 0x00065E44 File Offset: 0x00064044
	[Address(RVA = "0x2E998C4", Offset = "0x2E998C4", VA = "0x2E998C4")]
	[Token(Token = "0x600338A")]
	public void method_78()
	{
		int num = this.int_2;
		this.int_2 = num;
	}

	// Token: 0x0600338B RID: 13195 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E99998", Offset = "0x2E99998", VA = "0x2E99998")]
	[Token(Token = "0x600338B")]
	public bool method_79()
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600338C RID: 13196 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E999CC", Offset = "0x2E999CC", VA = "0x2E999CC")]
	[Token(Token = "0x600338C")]
	private void method_80(ref int int_3)
	{
	}

	// Token: 0x0600338D RID: 13197 RVA: 0x00065E08 File Offset: 0x00064008
	[Address(RVA = "0x2E99A14", Offset = "0x2E99A14", VA = "0x2E99A14")]
	[Token(Token = "0x600338D")]
	private void method_81(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x0600338E RID: 13198 RVA: 0x00003197 File Offset: 0x00001397
	[Address(RVA = "0x2E99A88", Offset = "0x2E99A88", VA = "0x2E99A88")]
	[Token(Token = "0x600338E")]
	public int method_82()
	{
		return this.int_2;
	}

	// Token: 0x0600338F RID: 13199 RVA: 0x00003197 File Offset: 0x00001397
	[Address(RVA = "0x2E99A90", Offset = "0x2E99A90", VA = "0x2E99A90")]
	[Token(Token = "0x600338F")]
	public int method_83()
	{
		return this.int_2;
	}

	// Token: 0x06003390 RID: 13200 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E99A98", Offset = "0x2E99A98", VA = "0x2E99A98")]
	[Token(Token = "0x6003390")]
	public bool method_84()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003391 RID: 13201 RVA: 0x00065E08 File Offset: 0x00064008
	[Address(RVA = "0x2E99ACC", Offset = "0x2E99ACC", VA = "0x2E99ACC")]
	[Token(Token = "0x6003391")]
	private void method_85(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x06003392 RID: 13202 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E99B40", Offset = "0x2E99B40", VA = "0x2E99B40")]
	[Token(Token = "0x6003392")]
	public int method_86()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06003393 RID: 13203 RVA: 0x00003197 File Offset: 0x00001397
	[Address(RVA = "0x2E99B5C", Offset = "0x2E99B5C", VA = "0x2E99B5C")]
	[Token(Token = "0x6003393")]
	public int method_87()
	{
		return this.int_2;
	}

	// Token: 0x06003394 RID: 13204 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E99B64", Offset = "0x2E99B64", VA = "0x2E99B64")]
	[Token(Token = "0x6003394")]
	public bool method_88()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003395 RID: 13205 RVA: 0x00065E08 File Offset: 0x00064008
	[Address(RVA = "0x2E99BC4", Offset = "0x2E99BC4", VA = "0x2E99BC4")]
	[Token(Token = "0x6003395")]
	private void method_89(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x06003396 RID: 13206 RVA: 0x00065E08 File Offset: 0x00064008
	[Address(RVA = "0x2E99C38", Offset = "0x2E99C38", VA = "0x2E99C38")]
	[Token(Token = "0x6003396")]
	private void method_90(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x06003397 RID: 13207 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E99CAC", Offset = "0x2E99CAC", VA = "0x2E99CAC")]
	[Token(Token = "0x6003397")]
	public bool method_91()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003398 RID: 13208 RVA: 0x00065E18 File Offset: 0x00064018
	[Address(RVA = "0x2E99D0C", Offset = "0x2E99D0C", VA = "0x2E99D0C")]
	[Token(Token = "0x6003398")]
	private int method_92(int int_3)
	{
		throw new NullReferenceException();
	}

	// Token: 0x06003399 RID: 13209 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E99D88", Offset = "0x2E99D88", VA = "0x2E99D88")]
	[Token(Token = "0x6003399")]
	public int method_93()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600339A RID: 13210 RVA: 0x0000317E File Offset: 0x0000137E
	[Address(RVA = "0x2E99DA4", Offset = "0x2E99DA4", VA = "0x2E99DA4")]
	[Token(Token = "0x600339A")]
	private void method_94(ref int int_3)
	{
		int_3.m_value = this;
		int_3.m_value = this;
	}

	// Token: 0x0600339B RID: 13211 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E99DF4", Offset = "0x2E99DF4", VA = "0x2E99DF4")]
	[Token(Token = "0x600339B")]
	private void method_95(ref int int_3)
	{
	}

	// Token: 0x0600339C RID: 13212 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E99E3C", Offset = "0x2E99E3C", VA = "0x2E99E3C")]
	[Token(Token = "0x600339C")]
	private void method_96(ref int int_3)
	{
	}

	// Token: 0x0600339D RID: 13213 RVA: 0x00065E18 File Offset: 0x00064018
	[Address(RVA = "0x2E99E8C", Offset = "0x2E99E8C", VA = "0x2E99E8C")]
	[Token(Token = "0x600339D")]
	private int method_97(int int_3)
	{
		throw new NullReferenceException();
	}

	// Token: 0x0600339E RID: 13214 RVA: 0x00065E44 File Offset: 0x00064044
	[Address(RVA = "0x2E99F08", Offset = "0x2E99F08", VA = "0x2E99F08")]
	[Token(Token = "0x600339E")]
	public void method_98()
	{
		int num = this.int_2;
		this.int_2 = num;
	}

	// Token: 0x0600339F RID: 13215 RVA: 0x00065E2C File Offset: 0x0006402C
	[Address(RVA = "0x2E99FDC", Offset = "0x2E99FDC", VA = "0x2E99FDC")]
	[Token(Token = "0x600339F")]
	private void method_99(ref int int_3)
	{
		long value = 1L;
		int_3.m_value = (int)value;
	}

	// Token: 0x060033A0 RID: 13216 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E9A030", Offset = "0x2E9A030", VA = "0x2E9A030", Slot = "11")]
	[Token(Token = "0x60033A0")]
	private IEnumerator vmethod_5()
	{
		throw new NullReferenceException();
	}

	// Token: 0x060033A1 RID: 13217 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E9A054", Offset = "0x2E9A054", VA = "0x2E9A054")]
	[Token(Token = "0x60033A1")]
	public bool method_100()
	{
		throw new NullReferenceException();
	}

	// Token: 0x060033A2 RID: 13218 RVA: 0x00065E84 File Offset: 0x00064084
	[Address(RVA = "0x2E9A088", Offset = "0x2E9A088", VA = "0x2E9A088")]
	[Token(Token = "0x60033A2")]
	public Class42(int int_3, T[] gparam_1)
	{
		if (gparam_1 != null)
		{
			this.gparam_0 = this;
			return;
		}
		new ArgumentNullException("items");
	}

	// Token: 0x060033A3 RID: 13219 RVA: 0x0000317E File Offset: 0x0000137E
	[Address(RVA = "0x2E9A200", Offset = "0x2E9A200", VA = "0x2E9A200")]
	[Token(Token = "0x60033A3")]
	private void method_101(ref int int_3)
	{
		int_3.m_value = this;
		int_3.m_value = this;
	}

	// Token: 0x060033A4 RID: 13220 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E9A250", Offset = "0x2E9A250", VA = "0x2E9A250")]
	[Token(Token = "0x60033A4")]
	public void method_102()
	{
	}

	// Token: 0x060033A5 RID: 13221 RVA: 0x0000258C File Offset: 0x0000078C
	[Address(RVA = "0x2E9A314", Offset = "0x2E9A314", VA = "0x2E9A314")]
	[Token(Token = "0x60033A5")]
	public bool method_103()
	{
		throw new NullReferenceException();
	}

	// Token: 0x060033A6 RID: 13222 RVA: 0x00065E2C File Offset: 0x0006402C
	[Address(RVA = "0x2E9A348", Offset = "0x2E9A348", VA = "0x2E9A348")]
	[Token(Token = "0x60033A6")]
	private void method_104(ref int int_3)
	{
		long value = 1L;
		int_3.m_value = (int)value;
	}

	// Token: 0x060033A7 RID: 13223 RVA: 0x0000318E File Offset: 0x0000138E
	[Address(RVA = "0x2E9A394", Offset = "0x2E9A394", VA = "0x2E9A394")]
	[Token(Token = "0x60033A7")]
	private void method_105(ref int int_3)
	{
		int_3.m_value = this;
	}

	// Token: 0x060033A8 RID: 13224 RVA: 0x00065E08 File Offset: 0x00064008
	[Address(RVA = "0x2E9A3D8", Offset = "0x2E9A3D8", VA = "0x2E9A3D8")]
	[Token(Token = "0x60033A8")]
	private void method_106(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x1700008A RID: 138
	// (get) Token: 0x060033A9 RID: 13225 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x1700008A")]
	public int Int32_0
	{
		[Address(RVA = "0x2E9A44C", Offset = "0x2E9A44C", VA = "0x2E9A44C")]
		[Token(Token = "0x60033A9")]
		get
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}
	}

	// Token: 0x060033AA RID: 13226 RVA: 0x00065E44 File Offset: 0x00064044
	[Address(RVA = "0x2E9A468", Offset = "0x2E9A468", VA = "0x2E9A468")]
	[Token(Token = "0x60033AA")]
	public void method_107()
	{
		int num = this.int_2;
		this.int_2 = num;
	}

	// Token: 0x060033AB RID: 13227 RVA: 0x0000319F File Offset: 0x0000139F
	[Address(RVA = "0x2E9A53C", Offset = "0x2E9A53C", VA = "0x2E9A53C", Slot = "4")]
	[Token(Token = "0x60033AB")]
	public IEnumerator<T> GetEnumerator()
	{
		this.int_2 = this;
		throw new NullReferenceException();
	}

	// Token: 0x060033AC RID: 13228 RVA: 0x00065E08 File Offset: 0x00064008
	[Token(Token = "0x60033AC")]
	[Address(RVA = "0x2E9A5C0", Offset = "0x2E9A5C0", VA = "0x2E9A5C0")]
	private void method_108(string string_0 = "Cannot access an empty buffer.")
	{
	}

	// Token: 0x060033AD RID: 13229 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60033AD")]
	[Address(RVA = "0x2E9A634", Offset = "0x2E9A634", VA = "0x2E9A634")]
	public void method_109()
	{
	}

	// Token: 0x060033AE RID: 13230 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2E9A6F8", Offset = "0x2E9A6F8", VA = "0x2E9A6F8")]
	[Token(Token = "0x60033AE")]
	public void method_110()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0400065B RID: 1627
	[Token(Token = "0x400065B")]
	[FieldOffset(Offset = "0x0")]
	private readonly T[] gparam_0;

	// Token: 0x0400065C RID: 1628
	[Token(Token = "0x400065C")]
	[FieldOffset(Offset = "0x0")]
	private int int_0;

	// Token: 0x0400065D RID: 1629
	[Token(Token = "0x400065D")]
	[FieldOffset(Offset = "0x0")]
	private int int_1;

	// Token: 0x0400065E RID: 1630
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400065E")]
	private int int_2;
}
