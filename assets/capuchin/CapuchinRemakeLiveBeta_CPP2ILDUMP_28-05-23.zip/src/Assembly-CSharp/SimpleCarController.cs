﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200010E RID: 270
[Token(Token = "0x200010E")]
public class SimpleCarController : MonoBehaviour
{
	// Token: 0x0600287A RID: 10362 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600287A")]
	[Address(RVA = "0x2B8BCF4", Offset = "0x2B8BCF4", VA = "0x2B8BCF4")]
	public void method_0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600287B RID: 10363 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x600287B")]
	[Address(RVA = "0x2B8BDF0", Offset = "0x2B8BDF0", VA = "0x2B8BDF0")]
	private void method_1()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x0600287C RID: 10364 RVA: 0x0005897C File Offset: 0x00056B7C
	[Token(Token = "0x600287C")]
	[Address(RVA = "0x2B8BE54", Offset = "0x2B8BE54", VA = "0x2B8BE54")]
	public void method_2()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x0600287D RID: 10365 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Address(RVA = "0x2B8C318", Offset = "0x2B8C318", VA = "0x2B8C318")]
	[Token(Token = "0x600287D")]
	public void method_3(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x0600287E RID: 10366 RVA: 0x0005897C File Offset: 0x00056B7C
	[Token(Token = "0x600287E")]
	[Address(RVA = "0x2B8C3E4", Offset = "0x2B8C3E4", VA = "0x2B8C3E4")]
	public void FixedUpdate()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x0600287F RID: 10367 RVA: 0x00058A04 File Offset: 0x00056C04
	[Token(Token = "0x600287F")]
	[Address(RVA = "0x2B8C7CC", Offset = "0x2B8C7CC", VA = "0x2B8C7CC")]
	public void method_4(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002880 RID: 10368 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002880")]
	[Address(RVA = "0x2B8C898", Offset = "0x2B8C898", VA = "0x2B8C898")]
	public void method_5()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002881 RID: 10369 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002881")]
	[Address(RVA = "0x2B8C9A0", Offset = "0x2B8C9A0", VA = "0x2B8C9A0")]
	public void method_6()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002882 RID: 10370 RVA: 0x0005897C File Offset: 0x00056B7C
	[Address(RVA = "0x2B8CAB4", Offset = "0x2B8CAB4", VA = "0x2B8CAB4")]
	[Token(Token = "0x6002882")]
	public void method_7()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x06002883 RID: 10371 RVA: 0x0005897C File Offset: 0x00056B7C
	[Token(Token = "0x6002883")]
	[Address(RVA = "0x2B8CEAC", Offset = "0x2B8CEAC", VA = "0x2B8CEAC")]
	public void method_8()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x06002884 RID: 10372 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002884")]
	[Address(RVA = "0x2B8D2A0", Offset = "0x2B8D2A0", VA = "0x2B8D2A0")]
	public void method_9()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002885 RID: 10373 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x6002885")]
	[Address(RVA = "0x2B8D3A8", Offset = "0x2B8D3A8", VA = "0x2B8D3A8")]
	private void method_10()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x06002886 RID: 10374 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Address(RVA = "0x2B8D40C", Offset = "0x2B8D40C", VA = "0x2B8D40C")]
	[Token(Token = "0x6002886")]
	public void method_11(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002887 RID: 10375 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x6002887")]
	[Address(RVA = "0x2B8D4D8", Offset = "0x2B8D4D8", VA = "0x2B8D4D8")]
	private void method_12()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x06002888 RID: 10376 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Token(Token = "0x6002888")]
	[Address(RVA = "0x2B8D1D4", Offset = "0x2B8D1D4", VA = "0x2B8D1D4")]
	public void method_13(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002889 RID: 10377 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x6002889")]
	[Address(RVA = "0x2B8D53C", Offset = "0x2B8D53C", VA = "0x2B8D53C")]
	private void method_14()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x0600288A RID: 10378 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600288A")]
	[Address(RVA = "0x2B8D5A0", Offset = "0x2B8D5A0", VA = "0x2B8D5A0")]
	public void method_15()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600288B RID: 10379 RVA: 0x00058A04 File Offset: 0x00056C04
	[Token(Token = "0x600288B")]
	[Address(RVA = "0x2B8D6A8", Offset = "0x2B8D6A8", VA = "0x2B8D6A8")]
	public void method_16(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x0600288C RID: 10380 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B8D774", Offset = "0x2B8D774", VA = "0x2B8D774")]
	[Token(Token = "0x600288C")]
	public void method_17()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600288D RID: 10381 RVA: 0x00058A40 File Offset: 0x00056C40
	[Address(RVA = "0x2B8D87C", Offset = "0x2B8D87C", VA = "0x2B8D87C")]
	[Token(Token = "0x600288D")]
	public void method_18()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x0600288E RID: 10382 RVA: 0x00058968 File Offset: 0x00056B68
	[Address(RVA = "0x2B8DC74", Offset = "0x2B8DC74", VA = "0x2B8DC74")]
	[Token(Token = "0x600288E")]
	private void method_19()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x0600288F RID: 10383 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Address(RVA = "0x2B8DCD8", Offset = "0x2B8DCD8", VA = "0x2B8DCD8")]
	[Token(Token = "0x600288F")]
	public void method_20(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002890 RID: 10384 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x6002890")]
	[Address(RVA = "0x2B8DDA4", Offset = "0x2B8DDA4", VA = "0x2B8DDA4")]
	private void method_21()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x06002891 RID: 10385 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Token(Token = "0x6002891")]
	[Address(RVA = "0x2B8DE08", Offset = "0x2B8DE08", VA = "0x2B8DE08")]
	public void method_22(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002892 RID: 10386 RVA: 0x0005897C File Offset: 0x00056B7C
	[Token(Token = "0x6002892")]
	[Address(RVA = "0x2B8DED4", Offset = "0x2B8DED4", VA = "0x2B8DED4")]
	public void method_23()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x06002893 RID: 10387 RVA: 0x00058968 File Offset: 0x00056B68
	[Address(RVA = "0x2B8E398", Offset = "0x2B8E398", VA = "0x2B8E398")]
	[Token(Token = "0x6002893")]
	private void method_24()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x06002894 RID: 10388 RVA: 0x0005897C File Offset: 0x00056B7C
	[Address(RVA = "0x2B8E3FC", Offset = "0x2B8E3FC", VA = "0x2B8E3FC")]
	[Token(Token = "0x6002894")]
	public void method_25()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x06002895 RID: 10389 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x6002895")]
	[Address(RVA = "0x2B8E728", Offset = "0x2B8E728", VA = "0x2B8E728")]
	private void method_26()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x06002896 RID: 10390 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x6002896")]
	[Address(RVA = "0x2B8E78C", Offset = "0x2B8E78C", VA = "0x2B8E78C")]
	private void method_27()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x06002897 RID: 10391 RVA: 0x00058A04 File Offset: 0x00056C04
	[Token(Token = "0x6002897")]
	[Address(RVA = "0x2B8C180", Offset = "0x2B8C180", VA = "0x2B8C180")]
	public void method_28(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x06002898 RID: 10392 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B8E7F0", Offset = "0x2B8E7F0", VA = "0x2B8E7F0")]
	[Token(Token = "0x6002898")]
	public void method_29()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002899 RID: 10393 RVA: 0x00058A04 File Offset: 0x00056C04
	[Token(Token = "0x6002899")]
	[Address(RVA = "0x2B8E8EC", Offset = "0x2B8E8EC", VA = "0x2B8E8EC")]
	public void method_30(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x0600289A RID: 10394 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Token(Token = "0x600289A")]
	[Address(RVA = "0x2B8E9B8", Offset = "0x2B8E9B8", VA = "0x2B8E9B8")]
	public void method_31(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x0600289B RID: 10395 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x600289B")]
	[Address(RVA = "0x2B8EA84", Offset = "0x2B8EA84", VA = "0x2B8EA84")]
	private void method_32()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x0600289C RID: 10396 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600289C")]
	[Address(RVA = "0x2B8EAE8", Offset = "0x2B8EAE8", VA = "0x2B8EAE8")]
	public void method_33()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600289D RID: 10397 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B8EBE4", Offset = "0x2B8EBE4", VA = "0x2B8EBE4")]
	[Token(Token = "0x600289D")]
	public void method_34()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600289E RID: 10398 RVA: 0x0005897C File Offset: 0x00056B7C
	[Address(RVA = "0x2B8ECE0", Offset = "0x2B8ECE0", VA = "0x2B8ECE0")]
	[Token(Token = "0x600289E")]
	public void method_35()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x0600289F RID: 10399 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B8F008", Offset = "0x2B8F008", VA = "0x2B8F008")]
	[Token(Token = "0x600289F")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028A0 RID: 10400 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60028A0")]
	[Address(RVA = "0x2B8F104", Offset = "0x2B8F104", VA = "0x2B8F104")]
	public void method_36()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028A1 RID: 10401 RVA: 0x0005897C File Offset: 0x00056B7C
	[Address(RVA = "0x2B8F200", Offset = "0x2B8F200", VA = "0x2B8F200")]
	[Token(Token = "0x60028A1")]
	public void method_37()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x060028A2 RID: 10402 RVA: 0x00058968 File Offset: 0x00056B68
	[Address(RVA = "0x2B8F52C", Offset = "0x2B8F52C", VA = "0x2B8F52C")]
	[Token(Token = "0x60028A2")]
	private void method_38()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028A3 RID: 10403 RVA: 0x00058968 File Offset: 0x00056B68
	[Address(RVA = "0x2B8F590", Offset = "0x2B8F590", VA = "0x2B8F590")]
	[Token(Token = "0x60028A3")]
	private void Start()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028A4 RID: 10404 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Address(RVA = "0x2B8E2CC", Offset = "0x2B8E2CC", VA = "0x2B8E2CC")]
	[Token(Token = "0x60028A4")]
	public void method_39(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028A5 RID: 10405 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x60028A5")]
	[Address(RVA = "0x2B8F5F4", Offset = "0x2B8F5F4", VA = "0x2B8F5F4")]
	private void method_40()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028A6 RID: 10406 RVA: 0x00058968 File Offset: 0x00056B68
	[Address(RVA = "0x2B8F658", Offset = "0x2B8F658", VA = "0x2B8F658")]
	[Token(Token = "0x60028A6")]
	private void method_41()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028A7 RID: 10407 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60028A7")]
	[Address(RVA = "0x2B8F6BC", Offset = "0x2B8F6BC", VA = "0x2B8F6BC")]
	public void method_42()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028A8 RID: 10408 RVA: 0x00058A04 File Offset: 0x00056C04
	[Address(RVA = "0x2B8F7B8", Offset = "0x2B8F7B8", VA = "0x2B8F7B8")]
	[Token(Token = "0x60028A8")]
	public void method_43(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028A9 RID: 10409 RVA: 0x00058A8C File Offset: 0x00056C8C
	[Token(Token = "0x60028A9")]
	[Address(RVA = "0x2B8F884", Offset = "0x2B8F884", VA = "0x2B8F884")]
	public void method_44(WheelCollider wheelCollider_0)
	{
		if (base.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028AA RID: 10410 RVA: 0x00058A04 File Offset: 0x00056C04
	[Address(RVA = "0x2B8C24C", Offset = "0x2B8C24C", VA = "0x2B8C24C")]
	[Token(Token = "0x60028AA")]
	public void method_45(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028AB RID: 10411 RVA: 0x00058AC8 File Offset: 0x00056CC8
	[Address(RVA = "0x2B8C700", Offset = "0x2B8C700", VA = "0x2B8C700")]
	[Token(Token = "0x60028AB")]
	public void method_46(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = wheelCollider_0.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028AC RID: 10412 RVA: 0x0005897C File Offset: 0x00056B7C
	[Address(RVA = "0x2B8F950", Offset = "0x2B8F950", VA = "0x2B8F950")]
	[Token(Token = "0x60028AC")]
	public void method_47()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x060028AD RID: 10413 RVA: 0x0005897C File Offset: 0x00056B7C
	[Address(RVA = "0x2B8FC7C", Offset = "0x2B8FC7C", VA = "0x2B8FC7C")]
	[Token(Token = "0x60028AD")]
	public void method_48()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x060028AE RID: 10414 RVA: 0x00058B04 File Offset: 0x00056D04
	[Address(RVA = "0x2B8FFA8", Offset = "0x2B8FFA8", VA = "0x2B8FFA8")]
	[Token(Token = "0x60028AE")]
	private void method_49()
	{
	}

	// Token: 0x060028AF RID: 10415 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B9000C", Offset = "0x2B9000C", VA = "0x2B9000C")]
	[Token(Token = "0x60028AF")]
	public void method_50()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028B0 RID: 10416 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Token(Token = "0x60028B0")]
	[Address(RVA = "0x2B8DBA8", Offset = "0x2B8DBA8", VA = "0x2B8DBA8")]
	public void method_51(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028B1 RID: 10417 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x60028B1")]
	[Address(RVA = "0x2B90114", Offset = "0x2B90114", VA = "0x2B90114")]
	private void method_52()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028B2 RID: 10418 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B90178", Offset = "0x2B90178", VA = "0x2B90178")]
	[Token(Token = "0x60028B2")]
	public void method_53()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028B3 RID: 10419 RVA: 0x0005897C File Offset: 0x00056B7C
	[Token(Token = "0x60028B3")]
	[Address(RVA = "0x2B90280", Offset = "0x2B90280", VA = "0x2B90280")]
	public void method_54()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x060028B4 RID: 10420 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B905AC", Offset = "0x2B905AC", VA = "0x2B905AC")]
	[Token(Token = "0x60028B4")]
	public void method_55()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028B5 RID: 10421 RVA: 0x00058A04 File Offset: 0x00056C04
	[Address(RVA = "0x2B8CDE0", Offset = "0x2B8CDE0", VA = "0x2B8CDE0")]
	[Token(Token = "0x60028B5")]
	public void method_56(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028B6 RID: 10422 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60028B6")]
	[Address(RVA = "0x2B906A8", Offset = "0x2B906A8", VA = "0x2B906A8")]
	private void method_57()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028B7 RID: 10423 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B9070C", Offset = "0x2B9070C", VA = "0x2B9070C")]
	[Token(Token = "0x60028B7")]
	public void method_58()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028B8 RID: 10424 RVA: 0x00058B14 File Offset: 0x00056D14
	[Token(Token = "0x60028B8")]
	[Address(RVA = "0x2B90814", Offset = "0x2B90814", VA = "0x2B90814")]
	public void method_59()
	{
		ThrowHelper.ThrowArgumentOutOfRangeException();
	}

	// Token: 0x060028B9 RID: 10425 RVA: 0x00058B28 File Offset: 0x00056D28
	[Token(Token = "0x60028B9")]
	[Address(RVA = "0x2B9091C", Offset = "0x2B9091C", VA = "0x2B9091C")]
	private void method_60()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028BA RID: 10426 RVA: 0x00058968 File Offset: 0x00056B68
	[Address(RVA = "0x2B90980", Offset = "0x2B90980", VA = "0x2B90980")]
	[Token(Token = "0x60028BA")]
	private void method_61()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028BB RID: 10427 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60028BB")]
	[Address(RVA = "0x2B909E4", Offset = "0x2B909E4", VA = "0x2B909E4")]
	public void method_62()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028BC RID: 10428 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x60028BC")]
	[Address(RVA = "0x2B90AEC", Offset = "0x2B90AEC", VA = "0x2B90AEC")]
	private void method_63()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028BD RID: 10429 RVA: 0x0005897C File Offset: 0x00056B7C
	[Address(RVA = "0x2B90B50", Offset = "0x2B90B50", VA = "0x2B90B50")]
	[Token(Token = "0x60028BD")]
	public void method_64()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x060028BE RID: 10430 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B91014", Offset = "0x2B91014", VA = "0x2B91014")]
	[Token(Token = "0x60028BE")]
	public void method_65()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028BF RID: 10431 RVA: 0x00058B3C File Offset: 0x00056D3C
	[Token(Token = "0x60028BF")]
	[Address(RVA = "0x2B91110", Offset = "0x2B91110", VA = "0x2B91110")]
	private void method_66()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028C0 RID: 10432 RVA: 0x0005897C File Offset: 0x00056B7C
	[Address(RVA = "0x2B91174", Offset = "0x2B91174", VA = "0x2B91174")]
	[Token(Token = "0x60028C0")]
	public void method_67()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x060028C1 RID: 10433 RVA: 0x00058B50 File Offset: 0x00056D50
	[Address(RVA = "0x2B9156C", Offset = "0x2B9156C", VA = "0x2B9156C")]
	[Token(Token = "0x60028C1")]
	public void method_68()
	{
		if (this.bool_0)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		List.Enumerator enumerator;
		enumerator.MoveNext();
		if (!this.bool_1)
		{
			throw new MissingMethodException();
		}
	}

	// Token: 0x060028C2 RID: 10434 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B91964", Offset = "0x2B91964", VA = "0x2B91964")]
	[Token(Token = "0x60028C2")]
	public void method_69()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028C3 RID: 10435 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x60028C3")]
	[Address(RVA = "0x2B91A78", Offset = "0x2B91A78", VA = "0x2B91A78")]
	private void method_70()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028C4 RID: 10436 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B91ADC", Offset = "0x2B91ADC", VA = "0x2B91ADC")]
	[Token(Token = "0x60028C4")]
	public void method_71()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028C5 RID: 10437 RVA: 0x00058B8C File Offset: 0x00056D8C
	[Token(Token = "0x60028C5")]
	[Address(RVA = "0x2B91BE4", Offset = "0x2B91BE4", VA = "0x2B91BE4")]
	public void method_72()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		List.Enumerator enumerator;
		enumerator.MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x060028C6 RID: 10438 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x60028C6")]
	[Address(RVA = "0x2B91FDC", Offset = "0x2B91FDC", VA = "0x2B91FDC")]
	private void method_73()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028C7 RID: 10439 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B92040", Offset = "0x2B92040", VA = "0x2B92040")]
	[Token(Token = "0x60028C7")]
	public void method_74()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028C8 RID: 10440 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60028C8")]
	[Address(RVA = "0x2B9213C", Offset = "0x2B9213C", VA = "0x2B9213C")]
	public void method_75()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028C9 RID: 10441 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Address(RVA = "0x2B92238", Offset = "0x2B92238", VA = "0x2B92238")]
	[Token(Token = "0x60028C9")]
	public void method_76(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028CA RID: 10442 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60028CA")]
	[Address(RVA = "0x2B92304", Offset = "0x2B92304", VA = "0x2B92304")]
	public void method_77()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028CB RID: 10443 RVA: 0x00058A04 File Offset: 0x00056C04
	[Token(Token = "0x60028CB")]
	[Address(RVA = "0x2B90E7C", Offset = "0x2B90E7C", VA = "0x2B90E7C")]
	public void method_78(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028CC RID: 10444 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Token(Token = "0x60028CC")]
	[Address(RVA = "0x2B914A0", Offset = "0x2B914A0", VA = "0x2B914A0")]
	public void method_79(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028CD RID: 10445 RVA: 0x00058B3C File Offset: 0x00056D3C
	[Address(RVA = "0x2B92400", Offset = "0x2B92400", VA = "0x2B92400")]
	[Token(Token = "0x60028CD")]
	private void method_80()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028CE RID: 10446 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Address(RVA = "0x2B8E200", Offset = "0x2B8E200", VA = "0x2B8E200")]
	[Token(Token = "0x60028CE")]
	public void method_81(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028CF RID: 10447 RVA: 0x0005897C File Offset: 0x00056B7C
	[Address(RVA = "0x2B92464", Offset = "0x2B92464", VA = "0x2B92464")]
	[Token(Token = "0x60028CF")]
	public void method_82()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x060028D0 RID: 10448 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Address(RVA = "0x2B91898", Offset = "0x2B91898", VA = "0x2B91898")]
	[Token(Token = "0x60028D0")]
	public void method_83(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028D1 RID: 10449 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x60028D1")]
	[Address(RVA = "0x2B92790", Offset = "0x2B92790", VA = "0x2B92790")]
	private void method_84()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028D2 RID: 10450 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B927F4", Offset = "0x2B927F4", VA = "0x2B927F4")]
	[Token(Token = "0x60028D2")]
	public void method_85()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028D3 RID: 10451 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Address(RVA = "0x2B91F10", Offset = "0x2B91F10", VA = "0x2B91F10")]
	[Token(Token = "0x60028D3")]
	public void method_86(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028D4 RID: 10452 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60028D4")]
	[Address(RVA = "0x2B928FC", Offset = "0x2B928FC", VA = "0x2B928FC")]
	public SimpleCarController()
	{
	}

	// Token: 0x060028D5 RID: 10453 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60028D5")]
	[Address(RVA = "0x2B92904", Offset = "0x2B92904", VA = "0x2B92904")]
	public void method_87()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060028D6 RID: 10454 RVA: 0x00058A04 File Offset: 0x00056C04
	[Address(RVA = "0x2B90F48", Offset = "0x2B90F48", VA = "0x2B90F48")]
	[Token(Token = "0x60028D6")]
	public void method_88(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 1L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028D7 RID: 10455 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Token(Token = "0x60028D7")]
	[Address(RVA = "0x2B92A00", Offset = "0x2B92A00", VA = "0x2B92A00")]
	public void method_89(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028D8 RID: 10456 RVA: 0x00058968 File Offset: 0x00056B68
	[Token(Token = "0x60028D8")]
	[Address(RVA = "0x2B92ACC", Offset = "0x2B92ACC", VA = "0x2B92ACC")]
	private void method_90()
	{
		base.GetComponent<Rigidbody>();
	}

	// Token: 0x060028D9 RID: 10457 RVA: 0x000589C8 File Offset: 0x00056BC8
	[Token(Token = "0x60028D9")]
	[Address(RVA = "0x2B92B30", Offset = "0x2B92B30", VA = "0x2B92B30")]
	public void method_91(WheelCollider wheelCollider_0)
	{
		if (wheelCollider_0.transform.childCount != 0)
		{
			Transform transform = wheelCollider_0.transform;
			long index = 0L;
			Transform child = transform.GetChild((int)index);
			Transform transform2 = child.transform;
			Transform transform3 = child.transform;
		}
	}

	// Token: 0x060028DA RID: 10458 RVA: 0x0005897C File Offset: 0x00056B7C
	[Token(Token = "0x60028DA")]
	[Address(RVA = "0x2B92BFC", Offset = "0x2B92BFC", VA = "0x2B92BFC")]
	public void method_92()
	{
		bool flag;
		if (!(flag = this.bool_0))
		{
			return;
		}
		if (flag)
		{
		}
		Transform transform = this.transform_0;
		Quaternion localRotation = transform.localRotation;
		this.list_0.GetEnumerator().MoveNext();
		if (this.bool_1)
		{
			return;
		}
		throw new MissingMethodException();
	}

	// Token: 0x060028DB RID: 10459 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2B92F28", Offset = "0x2B92F28", VA = "0x2B92F28")]
	[Token(Token = "0x60028DB")]
	private void method_93()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0400054E RID: 1358
	[Token(Token = "0x400054E")]
	[FieldOffset(Offset = "0x18")]
	public List<AxleInfo> list_0;

	// Token: 0x0400054F RID: 1359
	[Token(Token = "0x400054F")]
	[FieldOffset(Offset = "0x20")]
	public float float_0;

	// Token: 0x04000550 RID: 1360
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x4000550")]
	public float float_1;

	// Token: 0x04000551 RID: 1361
	[Token(Token = "0x4000551")]
	[FieldOffset(Offset = "0x28")]
	private InputDevice inputDevice_0;

	// Token: 0x04000552 RID: 1362
	[Token(Token = "0x4000552")]
	[FieldOffset(Offset = "0x38")]
	private InputDevice inputDevice_1;

	// Token: 0x04000553 RID: 1363
	[Token(Token = "0x4000553")]
	[FieldOffset(Offset = "0x48")]
	public float float_2;

	// Token: 0x04000554 RID: 1364
	[Token(Token = "0x4000554")]
	[FieldOffset(Offset = "0x50")]
	public Transform transform_0;

	// Token: 0x04000555 RID: 1365
	[Token(Token = "0x4000555")]
	[FieldOffset(Offset = "0x58")]
	public Vector3 vector3_0;

	// Token: 0x04000556 RID: 1366
	[Token(Token = "0x4000556")]
	[FieldOffset(Offset = "0x64")]
	public bool bool_0;

	// Token: 0x04000557 RID: 1367
	[FieldOffset(Offset = "0x65")]
	[Token(Token = "0x4000557")]
	private bool bool_1;
}
