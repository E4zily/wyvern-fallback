﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000032 RID: 50
[Token(Token = "0x2000032")]
public class CannonYipee : MonoBehaviour
{
	// Token: 0x06000617 RID: 1559 RVA: 0x0000F9F4 File Offset: 0x0000DBF4
	[Address(RVA = "0x25B946C", Offset = "0x25B946C", VA = "0x25B946C")]
	[Token(Token = "0x6000617")]
	private void method_0()
	{
		bool flag;
		if (flag = this.bool_0)
		{
			if (!flag)
			{
				float deltaTime = Time.deltaTime;
				Mathf.Clamp01(deltaTime);
			}
			return;
		}
		float deltaTime2 = Time.deltaTime;
	}

	// Token: 0x06000618 RID: 1560 RVA: 0x0000FA24 File Offset: 0x0000DC24
	[Token(Token = "0x6000618")]
	[Address(RVA = "0x25B9888", Offset = "0x25B9888", VA = "0x25B9888")]
	private void method_1()
	{
		if (this.bool_0)
		{
			Rigidbody rigidbody = this.rigidbody_0;
			long num = 1L;
			this.bool_2 = (num != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.bool_1)
			{
				Vector3 position = this.transform_0.position;
				Vector3 position2 = this.transform_2.position;
				float deltaTime = Time.deltaTime;
				Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.transform_0.position;
			Vector3 position4 = this.transform_2.position;
			return;
		}
		if (this.bool_2)
		{
			Quaternion rotation = this.transform_0.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x06000619 RID: 1561 RVA: 0x0000FAB8 File Offset: 0x0000DCB8
	[Token(Token = "0x6000619")]
	[Address(RVA = "0x25B9C90", Offset = "0x25B9C90", VA = "0x25B9C90")]
	private void method_2(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.name == "Completed baking textures on frame ";
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600061A RID: 1562 RVA: 0x0000FAE0 File Offset: 0x0000DCE0
	[Address(RVA = "0x25B9D18", Offset = "0x25B9D18", VA = "0x25B9D18")]
	[Token(Token = "0x600061A")]
	private void method_3()
	{
		Rigidbody rigidbody = this.rigidbody_0;
		long num = 1L;
		this.bool_2 = (num != 0L);
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		if (!this.bool_1)
		{
			Vector3 position = this.transform_0.position;
			Vector3 position2 = this.transform_2.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
		}
		Vector3 position3 = this.transform_0.position;
		Vector3 position4 = this.transform_2.position;
	}

	// Token: 0x0600061B RID: 1563 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x600061B")]
	[Address(RVA = "0x25BA110", Offset = "0x25BA110", VA = "0x25BA110")]
	public CannonYipee()
	{
	}

	// Token: 0x0600061C RID: 1564 RVA: 0x0000FB50 File Offset: 0x0000DD50
	[Address(RVA = "0x25BA118", Offset = "0x25BA118", VA = "0x25BA118")]
	[Token(Token = "0x600061C")]
	private void method_4(Collider collider_0)
	{
		collider_0.gameObject.name == "This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n";
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600061D RID: 1565 RVA: 0x0000FB7C File Offset: 0x0000DD7C
	[Address(RVA = "0x25BA1A0", Offset = "0x25BA1A0", VA = "0x25BA1A0")]
	[Token(Token = "0x600061D")]
	private void method_5(Collider collider_0)
	{
		collider_0.gameObject.name == "gravThing";
	}

	// Token: 0x0600061E RID: 1566 RVA: 0x0000FBA0 File Offset: 0x0000DDA0
	[Address(RVA = "0x25BA224", Offset = "0x25BA224", VA = "0x25BA224")]
	[Token(Token = "0x600061E")]
	public IEnumerator method_6()
	{
		CannonYipee.Class9 @class = new CannonYipee.Class9((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x0000FBC8 File Offset: 0x0000DDC8
	[Token(Token = "0x600061F")]
	[Address(RVA = "0x25B9C18", Offset = "0x25B9C18", VA = "0x25B9C18")]
	public IEnumerator method_7()
	{
		new CannonYipee.Class9((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x06000620 RID: 1568 RVA: 0x0000FBEC File Offset: 0x0000DDEC
	[Token(Token = "0x6000620")]
	[Address(RVA = "0x25BA29C", Offset = "0x25BA29C", VA = "0x25BA29C")]
	private void method_8(Collider collider_0)
	{
		collider_0.gameObject.name == "Error";
	}

	// Token: 0x06000621 RID: 1569 RVA: 0x0000FBA0 File Offset: 0x0000DDA0
	[Address(RVA = "0x25BA320", Offset = "0x25BA320", VA = "0x25BA320")]
	[Token(Token = "0x6000621")]
	public IEnumerator method_9()
	{
		CannonYipee.Class9 @class = new CannonYipee.Class9((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000622 RID: 1570 RVA: 0x0000FC10 File Offset: 0x0000DE10
	[Token(Token = "0x6000622")]
	[Address(RVA = "0x25BA398", Offset = "0x25BA398", VA = "0x25BA398")]
	private void method_10()
	{
		if (this.bool_0)
		{
			Rigidbody rigidbody = this.rigidbody_0;
			long num = 1L;
			this.bool_2 = (num != 0L);
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.bool_1)
			{
				Vector3 position = this.transform_0.position;
				Vector3 position2 = this.transform_2.position;
				float deltaTime = Time.deltaTime;
				Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.transform_0.position;
			Vector3 position4 = this.transform_2.position;
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
			return;
		}
		if (this.bool_2)
		{
			Quaternion rotation = this.transform_0.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x06000623 RID: 1571 RVA: 0x0000FCAC File Offset: 0x0000DEAC
	[Token(Token = "0x6000623")]
	[Address(RVA = "0x25BA78C", Offset = "0x25BA78C", VA = "0x25BA78C")]
	private void method_11(Collider collider_0)
	{
		collider_0.gameObject.name == "next";
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000624 RID: 1572 RVA: 0x0000FBA0 File Offset: 0x0000DDA0
	[Address(RVA = "0x25BA814", Offset = "0x25BA814", VA = "0x25BA814")]
	[Token(Token = "0x6000624")]
	public IEnumerator method_12()
	{
		CannonYipee.Class9 @class = new CannonYipee.Class9((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000625 RID: 1573 RVA: 0x0000FBA0 File Offset: 0x0000DDA0
	[Token(Token = "0x6000625")]
	[Address(RVA = "0x25B9810", Offset = "0x25B9810", VA = "0x25B9810")]
	public IEnumerator method_13()
	{
		CannonYipee.Class9 @class = new CannonYipee.Class9((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000626 RID: 1574 RVA: 0x0000FBA0 File Offset: 0x0000DDA0
	[Address(RVA = "0x25BA098", Offset = "0x25BA098", VA = "0x25BA098")]
	[Token(Token = "0x6000626")]
	public IEnumerator method_14()
	{
		CannonYipee.Class9 @class = new CannonYipee.Class9((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000627 RID: 1575 RVA: 0x0000FCD8 File Offset: 0x0000DED8
	[Address(RVA = "0x25BA88C", Offset = "0x25BA88C", VA = "0x25BA88C")]
	[Token(Token = "0x6000627")]
	private void method_15(Collider collider_0)
	{
		collider_0.gameObject.name == "FingerTip";
	}

	// Token: 0x06000628 RID: 1576 RVA: 0x0000FCFC File Offset: 0x0000DEFC
	[Address(RVA = "0x25BA910", Offset = "0x25BA910", VA = "0x25BA910")]
	[Token(Token = "0x6000628")]
	private void method_16(Collider collider_0)
	{
		collider_0.gameObject.name == "_BumpMap";
	}

	// Token: 0x06000629 RID: 1577 RVA: 0x0000FBA0 File Offset: 0x0000DDA0
	[Token(Token = "0x6000629")]
	[Address(RVA = "0x25BA714", Offset = "0x25BA714", VA = "0x25BA714")]
	public IEnumerator method_17()
	{
		CannonYipee.Class9 @class = new CannonYipee.Class9((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600062A RID: 1578 RVA: 0x0000FBA0 File Offset: 0x0000DDA0
	[Address(RVA = "0x25BA994", Offset = "0x25BA994", VA = "0x25BA994")]
	[Token(Token = "0x600062A")]
	public IEnumerator method_18()
	{
		CannonYipee.Class9 @class = new CannonYipee.Class9((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600062B RID: 1579 RVA: 0x0000FD20 File Offset: 0x0000DF20
	[Token(Token = "0x600062B")]
	[Address(RVA = "0x25BAA0C", Offset = "0x25BAA0C", VA = "0x25BAA0C")]
	private void Update()
	{
		if (this.bool_0)
		{
			Rigidbody rigidbody = this.rigidbody_0;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.bool_1)
			{
				Vector3 position = this.transform_0.position;
				Vector3 position2 = this.transform_2.position;
				float deltaTime = Time.deltaTime;
				Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.transform_0.position;
			Vector3 position4 = this.transform_2.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
			return;
		}
		if (this.bool_2)
		{
			Quaternion rotation = this.transform_0.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x0600062C RID: 1580 RVA: 0x0000FDB4 File Offset: 0x0000DFB4
	[Token(Token = "0x600062C")]
	[Address(RVA = "0x25BAD94", Offset = "0x25BAD94", VA = "0x25BAD94")]
	private void method_19()
	{
		if (this.bool_0)
		{
			Rigidbody rigidbody = this.rigidbody_0;
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.bool_1)
			{
				Vector3 position = this.transform_0.position;
				Vector3 position2 = this.transform_2.position;
				float deltaTime = Time.deltaTime;
				Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.transform_0.position;
			Vector3 position4 = this.transform_2.position;
			return;
		}
		if (this.bool_2)
		{
			Quaternion rotation = this.transform_0.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x0600062D RID: 1581 RVA: 0x0000FE3C File Offset: 0x0000E03C
	[Token(Token = "0x600062D")]
	[Address(RVA = "0x25BB110", Offset = "0x25BB110", VA = "0x25BB110")]
	private void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.name == "PlayerHead";
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x0000FE68 File Offset: 0x0000E068
	[Token(Token = "0x600062E")]
	[Address(RVA = "0x25BB198", Offset = "0x25BB198", VA = "0x25BB198")]
	private void method_20()
	{
		if (this.bool_0)
		{
			Rigidbody rigidbody = this.rigidbody_0;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			if (!this.bool_1)
			{
				Vector3 position = this.transform_0.position;
				Vector3 position2 = this.transform_2.position;
				float deltaTime = Time.deltaTime;
				Mathf.Clamp01(deltaTime);
			}
			Vector3 position3 = this.transform_0.position;
			Vector3 position4 = this.transform_2.position;
			return;
		}
		if (this.bool_2)
		{
			Quaternion rotation = this.transform_0.rotation;
			float deltaTime2 = Time.deltaTime;
			return;
		}
	}

	// Token: 0x0600062F RID: 1583 RVA: 0x0000FEF0 File Offset: 0x0000E0F0
	[Token(Token = "0x600062F")]
	[Address(RVA = "0x25BB520", Offset = "0x25BB520", VA = "0x25BB520")]
	private void method_21(Collider collider_0)
	{
		collider_0.gameObject.name == "Player";
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x040000E2 RID: 226
	[Token(Token = "0x40000E2")]
	[FieldOffset(Offset = "0x18")]
	public Transform transform_0;

	// Token: 0x040000E3 RID: 227
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000E3")]
	public Rigidbody rigidbody_0;

	// Token: 0x040000E4 RID: 228
	[Token(Token = "0x40000E4")]
	[FieldOffset(Offset = "0x28")]
	public Transform transform_1;

	// Token: 0x040000E5 RID: 229
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40000E5")]
	public GravityBody gravityBody_0;

	// Token: 0x040000E6 RID: 230
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40000E6")]
	public float float_0;

	// Token: 0x040000E7 RID: 231
	[Token(Token = "0x40000E7")]
	[FieldOffset(Offset = "0x3C")]
	public float float_1;

	// Token: 0x040000E8 RID: 232
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40000E8")]
	public Transform transform_2;

	// Token: 0x040000E9 RID: 233
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40000E9")]
	public bool bool_0;

	// Token: 0x040000EA RID: 234
	[Token(Token = "0x40000EA")]
	[FieldOffset(Offset = "0x49")]
	private bool bool_1;

	// Token: 0x040000EB RID: 235
	[Token(Token = "0x40000EB")]
	[FieldOffset(Offset = "0x4A")]
	private bool bool_2;

	// Token: 0x040000EC RID: 236
	[Token(Token = "0x40000EC")]
	[FieldOffset(Offset = "0x4B")]
	public bool bool_3;
}
