﻿using System;
using Cpp2IlInjected;

// Token: 0x02000134 RID: 308
[Flags]
[Token(Token = "0x2000134")]
public enum GEnum14
{
	// Token: 0x040005FA RID: 1530
	[Token(Token = "0x40005FA")]
	flag_0 = 0,
	// Token: 0x040005FB RID: 1531
	[Token(Token = "0x40005FB")]
	flag_1 = 1,
	// Token: 0x040005FC RID: 1532
	[Token(Token = "0x40005FC")]
	flag_2 = 2,
	// Token: 0x040005FD RID: 1533
	[Token(Token = "0x40005FD")]
	flag_3 = 4,
	// Token: 0x040005FE RID: 1534
	[Token(Token = "0x40005FE")]
	flag_4 = 8,
	// Token: 0x040005FF RID: 1535
	[Token(Token = "0x40005FF")]
	flag_5 = 16,
	// Token: 0x04000600 RID: 1536
	[Token(Token = "0x4000600")]
	flag_6 = 32,
	// Token: 0x04000601 RID: 1537
	[Token(Token = "0x4000601")]
	flag_7 = 64,
	// Token: 0x04000602 RID: 1538
	[Token(Token = "0x4000602")]
	flag_8 = 128,
	// Token: 0x04000603 RID: 1539
	[Token(Token = "0x4000603")]
	flag_9 = 256,
	// Token: 0x04000604 RID: 1540
	[Token(Token = "0x4000604")]
	flag_10 = 512,
	// Token: 0x04000605 RID: 1541
	[Token(Token = "0x4000605")]
	flag_11 = 1024,
	// Token: 0x04000606 RID: 1542
	[Token(Token = "0x4000606")]
	flag_12 = -1
}
