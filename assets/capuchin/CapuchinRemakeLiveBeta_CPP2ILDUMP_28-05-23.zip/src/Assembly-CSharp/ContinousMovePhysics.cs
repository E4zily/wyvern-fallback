﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000097 RID: 151
[Token(Token = "0x2000097")]
public class ContinousMovePhysics : MonoBehaviour
{
	// Token: 0x060015E7 RID: 5607 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A67FA0", Offset = "0x2A67FA0", VA = "0x2A67FA0")]
	[Token(Token = "0x60015E7")]
	private void method_0()
	{
	}

	// Token: 0x060015E8 RID: 5608 RVA: 0x0002A8D0 File Offset: 0x00028AD0
	[Token(Token = "0x60015E8")]
	[Address(RVA = "0x2A67FA4", Offset = "0x2A67FA4", VA = "0x2A67FA4")]
	private void method_1()
	{
		long num = 1L;
		this.method_24();
		if (num != 0L)
		{
		}
		Vector3 eulerAngles = this.transform_0.eulerAngles;
		Vector3 position = this.rigidbody_0.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
	}

	// Token: 0x060015E9 RID: 5609 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60015E9")]
	[Address(RVA = "0x2A6823C", Offset = "0x2A6823C", VA = "0x2A6823C")]
	private void method_2()
	{
	}

	// Token: 0x060015EA RID: 5610 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60015EA")]
	[Address(RVA = "0x2A68240", Offset = "0x2A68240", VA = "0x2A68240")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060015EB RID: 5611 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A6833C", Offset = "0x2A6833C", VA = "0x2A6833C")]
	[Token(Token = "0x60015EB")]
	private void method_3()
	{
	}

	// Token: 0x060015EC RID: 5612 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60015EC")]
	[Address(RVA = "0x2A68340", Offset = "0x2A68340", VA = "0x2A68340")]
	private void method_4()
	{
	}

	// Token: 0x060015ED RID: 5613 RVA: 0x0002A908 File Offset: 0x00028B08
	[Token(Token = "0x60015ED")]
	[Address(RVA = "0x2A68344", Offset = "0x2A68344", VA = "0x2A68344")]
	private void FixedUpdate()
	{
		long num = 1L;
		this.method_8();
		if (num != 0L)
		{
		}
		Vector3 eulerAngles = this.transform_0.eulerAngles;
		Vector3 position = this.rigidbody_0.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
	}

	// Token: 0x060015EE RID: 5614 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60015EE")]
	[Address(RVA = "0x2A685CC", Offset = "0x2A685CC", VA = "0x2A685CC")]
	private void method_5()
	{
	}

	// Token: 0x060015EF RID: 5615 RVA: 0x0002A940 File Offset: 0x00028B40
	[Address(RVA = "0x2A685D0", Offset = "0x2A685D0", VA = "0x2A685D0")]
	[Token(Token = "0x60015EF")]
	public bool method_6()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x060015F0 RID: 5616 RVA: 0x0002A99C File Offset: 0x00028B9C
	[Address(RVA = "0x2A68714", Offset = "0x2A68714", VA = "0x2A68714")]
	[Token(Token = "0x60015F0")]
	private void method_7()
	{
		long num = 1L;
		this.method_15();
		if (num != 0L)
		{
		}
		Vector3 eulerAngles = this.transform_0.eulerAngles;
		float fixedDeltaTime = Time.fixedDeltaTime;
	}

	// Token: 0x060015F1 RID: 5617 RVA: 0x0002A940 File Offset: 0x00028B40
	[Token(Token = "0x60015F1")]
	[Address(RVA = "0x2A6848C", Offset = "0x2A6848C", VA = "0x2A6848C")]
	public bool method_8()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x060015F2 RID: 5618 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60015F2")]
	[Address(RVA = "0x2A689AC", Offset = "0x2A689AC", VA = "0x2A689AC")]
	private void method_9()
	{
	}

	// Token: 0x060015F3 RID: 5619 RVA: 0x0002A9C8 File Offset: 0x00028BC8
	[Address(RVA = "0x2A689B0", Offset = "0x2A689B0", VA = "0x2A689B0")]
	[Token(Token = "0x60015F3")]
	private void method_10()
	{
		long num = 1L;
		this.method_11();
		if (num != 0L)
		{
		}
		Vector3 eulerAngles = this.transform_0.eulerAngles;
		Vector3 position = this.rigidbody_0.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
	}

	// Token: 0x060015F4 RID: 5620 RVA: 0x0002A940 File Offset: 0x00028B40
	[Address(RVA = "0x2A68B04", Offset = "0x2A68B04", VA = "0x2A68B04")]
	[Token(Token = "0x60015F4")]
	public bool method_11()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x060015F5 RID: 5621 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A68C48", Offset = "0x2A68C48", VA = "0x2A68C48")]
	[Token(Token = "0x60015F5")]
	private void method_12()
	{
	}

	// Token: 0x060015F6 RID: 5622 RVA: 0x0002A940 File Offset: 0x00028B40
	[Token(Token = "0x60015F6")]
	[Address(RVA = "0x2A68C4C", Offset = "0x2A68C4C", VA = "0x2A68C4C")]
	public bool method_13()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x060015F7 RID: 5623 RVA: 0x0002AA00 File Offset: 0x00028C00
	[Address(RVA = "0x2A68D90", Offset = "0x2A68D90", VA = "0x2A68D90")]
	[Token(Token = "0x60015F7")]
	private void method_14()
	{
		long num = 1L;
		this.method_21();
		if (num != 0L)
		{
		}
		Vector3 eulerAngles = this.transform_0.eulerAngles;
		Vector3 position = this.rigidbody_0.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
	}

	// Token: 0x060015F8 RID: 5624 RVA: 0x0002A940 File Offset: 0x00028B40
	[Address(RVA = "0x2A68868", Offset = "0x2A68868", VA = "0x2A68868")]
	[Token(Token = "0x60015F8")]
	public bool method_15()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x060015F9 RID: 5625 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A69028", Offset = "0x2A69028", VA = "0x2A69028")]
	[Token(Token = "0x60015F9")]
	private void Start()
	{
	}

	// Token: 0x060015FA RID: 5626 RVA: 0x0002AA38 File Offset: 0x00028C38
	[Token(Token = "0x60015FA")]
	[Address(RVA = "0x2A6902C", Offset = "0x2A6902C", VA = "0x2A6902C")]
	private void method_16()
	{
		long num = 1L;
		this.method_6();
		if (num != 0L)
		{
		}
		Vector3 eulerAngles = this.transform_0.eulerAngles;
		Vector3 position = this.rigidbody_0.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
	}

	// Token: 0x060015FB RID: 5627 RVA: 0x0002A940 File Offset: 0x00028B40
	[Token(Token = "0x60015FB")]
	[Address(RVA = "0x2A69180", Offset = "0x2A69180", VA = "0x2A69180")]
	public bool method_17()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x060015FC RID: 5628 RVA: 0x0002A940 File Offset: 0x00028B40
	[Token(Token = "0x60015FC")]
	[Address(RVA = "0x2A692C4", Offset = "0x2A692C4", VA = "0x2A692C4")]
	public bool method_18()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x060015FD RID: 5629 RVA: 0x0002AA70 File Offset: 0x00028C70
	[Address(RVA = "0x2A69408", Offset = "0x2A69408", VA = "0x2A69408")]
	[Token(Token = "0x60015FD")]
	private void method_19()
	{
		long num = 1L;
		this.method_33();
		if (num != 0L)
		{
		}
		Vector3 eulerAngles = this.transform_0.eulerAngles;
		Vector3 position = this.rigidbody_0.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
	}

	// Token: 0x060015FE RID: 5630 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60015FE")]
	[Address(RVA = "0x2A696A0", Offset = "0x2A696A0", VA = "0x2A696A0")]
	private void method_20()
	{
	}

	// Token: 0x060015FF RID: 5631 RVA: 0x0002A940 File Offset: 0x00028B40
	[Address(RVA = "0x2A68EE4", Offset = "0x2A68EE4", VA = "0x2A68EE4")]
	[Token(Token = "0x60015FF")]
	public bool method_21()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x06001600 RID: 5632 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A696A4", Offset = "0x2A696A4", VA = "0x2A696A4")]
	[Token(Token = "0x6001600")]
	private void method_22()
	{
	}

	// Token: 0x06001601 RID: 5633 RVA: 0x0002AAA8 File Offset: 0x00028CA8
	[Address(RVA = "0x2A696A8", Offset = "0x2A696A8", VA = "0x2A696A8")]
	[Token(Token = "0x6001601")]
	public ContinousMovePhysics()
	{
		long num = 1065353216L;
		this.float_0 = (float)num;
		base..ctor();
	}

	// Token: 0x06001602 RID: 5634 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A696B8", Offset = "0x2A696B8", VA = "0x2A696B8")]
	[Token(Token = "0x6001602")]
	private void method_23()
	{
	}

	// Token: 0x06001603 RID: 5635 RVA: 0x0002A940 File Offset: 0x00028B40
	[Address(RVA = "0x2A680F8", Offset = "0x2A680F8", VA = "0x2A680F8")]
	[Token(Token = "0x6001603")]
	public bool method_24()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x06001604 RID: 5636 RVA: 0x0002A940 File Offset: 0x00028B40
	[Address(RVA = "0x2A696BC", Offset = "0x2A696BC", VA = "0x2A696BC")]
	[Token(Token = "0x6001604")]
	public bool method_25()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x06001605 RID: 5637 RVA: 0x0002A940 File Offset: 0x00028B40
	[Address(RVA = "0x2A69800", Offset = "0x2A69800", VA = "0x2A69800")]
	[Token(Token = "0x6001605")]
	public bool method_26()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x06001606 RID: 5638 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A69940", Offset = "0x2A69940", VA = "0x2A69940")]
	[Token(Token = "0x6001606")]
	public void method_27()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001607 RID: 5639 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A69A3C", Offset = "0x2A69A3C", VA = "0x2A69A3C")]
	[Token(Token = "0x6001607")]
	private void Update()
	{
	}

	// Token: 0x06001608 RID: 5640 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001608")]
	[Address(RVA = "0x2A69A40", Offset = "0x2A69A40", VA = "0x2A69A40")]
	public void method_28()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001609 RID: 5641 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A69B48", Offset = "0x2A69B48", VA = "0x2A69B48")]
	[Token(Token = "0x6001609")]
	private void method_29()
	{
	}

	// Token: 0x0600160A RID: 5642 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A69B4C", Offset = "0x2A69B4C", VA = "0x2A69B4C")]
	[Token(Token = "0x600160A")]
	private void method_30()
	{
	}

	// Token: 0x0600160B RID: 5643 RVA: 0x0002A908 File Offset: 0x00028B08
	[Address(RVA = "0x2A69B50", Offset = "0x2A69B50", VA = "0x2A69B50")]
	[Token(Token = "0x600160B")]
	private void method_31()
	{
		long num = 1L;
		this.method_8();
		if (num != 0L)
		{
		}
		Vector3 eulerAngles = this.transform_0.eulerAngles;
		Vector3 position = this.rigidbody_0.position;
		float fixedDeltaTime = Time.fixedDeltaTime;
	}

	// Token: 0x0600160C RID: 5644 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A69CA4", Offset = "0x2A69CA4", VA = "0x2A69CA4")]
	[Token(Token = "0x600160C")]
	public void method_32()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600160D RID: 5645 RVA: 0x0002A940 File Offset: 0x00028B40
	[Address(RVA = "0x2A6955C", Offset = "0x2A6955C", VA = "0x2A6955C")]
	[Token(Token = "0x600160D")]
	public bool method_33()
	{
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 center = this.capsuleCollider_0.center;
		float height = this.capsuleCollider_0.height;
		float radius = this.capsuleCollider_0.radius;
		float radius2 = this.capsuleCollider_0.radius;
		Vector3 down = Vector3.down;
		this.layerMask_0;
		return false;
	}

	// Token: 0x0600160E RID: 5646 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A69DAC", Offset = "0x2A69DAC", VA = "0x2A69DAC")]
	[Token(Token = "0x600160E")]
	public void method_34()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600160F RID: 5647 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A69EB4", Offset = "0x2A69EB4", VA = "0x2A69EB4")]
	[Token(Token = "0x600160F")]
	private void method_35()
	{
	}

	// Token: 0x06001610 RID: 5648 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2A69EB8", Offset = "0x2A69EB8", VA = "0x2A69EB8")]
	[Token(Token = "0x6001610")]
	private void method_36()
	{
	}

	// Token: 0x040002D7 RID: 727
	[Token(Token = "0x40002D7")]
	[FieldOffset(Offset = "0x18")]
	public float float_0;

	// Token: 0x040002D8 RID: 728
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002D8")]
	public Rigidbody rigidbody_0;

	// Token: 0x040002D9 RID: 729
	[Token(Token = "0x40002D9")]
	[FieldOffset(Offset = "0x28")]
	private InputDevice inputDevice_0;

	// Token: 0x040002DA RID: 730
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40002DA")]
	private InputDevice inputDevice_1;

	// Token: 0x040002DB RID: 731
	[Token(Token = "0x40002DB")]
	[FieldOffset(Offset = "0x48")]
	public Transform transform_0;

	// Token: 0x040002DC RID: 732
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40002DC")]
	public CapsuleCollider capsuleCollider_0;

	// Token: 0x040002DD RID: 733
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40002DD")]
	public LayerMask layerMask_0;

	// Token: 0x040002DE RID: 734
	[Token(Token = "0x40002DE")]
	[FieldOffset(Offset = "0x5C")]
	private Vector2 vector2_0;
}
