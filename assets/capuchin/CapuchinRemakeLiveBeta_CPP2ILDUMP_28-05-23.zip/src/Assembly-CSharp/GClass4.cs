﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using Cpp2IlInjected;

// Token: 0x020001A6 RID: 422
[Token(Token = "0x20001A6")]
[StructLayout(3, CharSet = CharSet.Auto)]
public class GClass4
{
	// Token: 0x06003D02 RID: 15618 RVA: 0x00077784 File Offset: 0x00075984
	[Token(Token = "0x6003D02")]
	[Address(RVA = "0x217A22C", Offset = "0x217A22C", VA = "0x217A22C")]
	public static string smethod_0(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D03 RID: 15619 RVA: 0x0007779C File Offset: 0x0007599C
	[Address(RVA = "0x217A334", Offset = "0x217A334", VA = "0x217A334")]
	[Token(Token = "0x6003D03")]
	public static string smethod_1(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D04 RID: 15620 RVA: 0x00077784 File Offset: 0x00075984
	[Token(Token = "0x6003D04")]
	[Address(RVA = "0x217A3D8", Offset = "0x217A3D8", VA = "0x217A3D8")]
	public static string smethod_2(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D05 RID: 15621 RVA: 0x000777B4 File Offset: 0x000759B4
	[Token(Token = "0x6003D05")]
	[Address(RVA = "0x217A4A4", Offset = "0x217A4A4", VA = "0x217A4A4")]
	public static string smethod_3(byte[] byte_0, byte[] byte_1)
	{
		1.m_value = byte_0;
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D06 RID: 15622 RVA: 0x0007779C File Offset: 0x0007599C
	[Token(Token = "0x6003D06")]
	[Address(RVA = "0x217A5C4", Offset = "0x217A5C4", VA = "0x217A5C4")]
	public static string smethod_4(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D07 RID: 15623 RVA: 0x00077784 File Offset: 0x00075984
	[Address(RVA = "0x217A66C", Offset = "0x217A66C", VA = "0x217A66C")]
	[Token(Token = "0x6003D07")]
	public static string smethod_5(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D08 RID: 15624 RVA: 0x00077784 File Offset: 0x00075984
	[Token(Token = "0x6003D08")]
	[Address(RVA = "0x217A78C", Offset = "0x217A78C", VA = "0x217A78C")]
	public static string smethod_6(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D09 RID: 15625 RVA: 0x00077784 File Offset: 0x00075984
	[Token(Token = "0x6003D09")]
	[Address(RVA = "0x217A88C", Offset = "0x217A88C", VA = "0x217A88C")]
	public static string smethod_7(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D0A RID: 15626 RVA: 0x00077784 File Offset: 0x00075984
	[Token(Token = "0x6003D0A")]
	[Address(RVA = "0x217A994", Offset = "0x217A994", VA = "0x217A994")]
	public static string smethod_8(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D0B RID: 15627 RVA: 0x0007779C File Offset: 0x0007599C
	[Address(RVA = "0x217AA94", Offset = "0x217AA94", VA = "0x217AA94")]
	[Token(Token = "0x6003D0B")]
	public static string smethod_9(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D0C RID: 15628 RVA: 0x00077784 File Offset: 0x00075984
	[Token(Token = "0x6003D0C")]
	[Address(RVA = "0x217AB3C", Offset = "0x217AB3C", VA = "0x217AB3C")]
	public static string smethod_10(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D0D RID: 15629 RVA: 0x0007779C File Offset: 0x0007599C
	[Address(RVA = "0x217AC5C", Offset = "0x217AC5C", VA = "0x217AC5C")]
	[Token(Token = "0x6003D0D")]
	public static string smethod_11(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D0E RID: 15630 RVA: 0x00077784 File Offset: 0x00075984
	[Token(Token = "0x6003D0E")]
	[Address(RVA = "0x217AD04", Offset = "0x217AD04", VA = "0x217AD04")]
	public static string smethod_12(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D0F RID: 15631 RVA: 0x0007779C File Offset: 0x0007599C
	[Address(RVA = "0x217AE18", Offset = "0x217AE18", VA = "0x217AE18")]
	[Token(Token = "0x6003D0F")]
	public static string smethod_13(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D10 RID: 15632 RVA: 0x000777B4 File Offset: 0x000759B4
	[Token(Token = "0x6003D10")]
	[Address(RVA = "0x217AEBC", Offset = "0x217AEBC", VA = "0x217AEBC")]
	public static string smethod_14(byte[] byte_0, byte[] byte_1)
	{
		1.m_value = byte_0;
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D11 RID: 15633 RVA: 0x00077784 File Offset: 0x00075984
	[Address(RVA = "0x217AFE8", Offset = "0x217AFE8", VA = "0x217AFE8")]
	[Token(Token = "0x6003D11")]
	public static string smethod_15(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D12 RID: 15634 RVA: 0x00077784 File Offset: 0x00075984
	[Token(Token = "0x6003D12")]
	[Address(RVA = "0x217B10C", Offset = "0x217B10C", VA = "0x217B10C")]
	public static string smethod_16(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D13 RID: 15635 RVA: 0x0007779C File Offset: 0x0007599C
	[Token(Token = "0x6003D13")]
	[Address(RVA = "0x217B218", Offset = "0x217B218", VA = "0x217B218")]
	public static string smethod_17(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D14 RID: 15636 RVA: 0x0007779C File Offset: 0x0007599C
	[Token(Token = "0x6003D14")]
	[Address(RVA = "0x217B2BC", Offset = "0x217B2BC", VA = "0x217B2BC")]
	public static string smethod_18(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D15 RID: 15637 RVA: 0x0007779C File Offset: 0x0007599C
	[Address(RVA = "0x217B364", Offset = "0x217B364", VA = "0x217B364")]
	[Token(Token = "0x6003D15")]
	public static string smethod_19(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D16 RID: 15638 RVA: 0x00077784 File Offset: 0x00075984
	[Token(Token = "0x6003D16")]
	[Address(RVA = "0x217B408", Offset = "0x217B408", VA = "0x217B408")]
	public static string smethod_20(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D17 RID: 15639 RVA: 0x0007779C File Offset: 0x0007599C
	[Address(RVA = "0x217B514", Offset = "0x217B514", VA = "0x217B514")]
	[Token(Token = "0x6003D17")]
	public static string smethod_21(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D18 RID: 15640 RVA: 0x0007779C File Offset: 0x0007599C
	[Address(RVA = "0x217B5BC", Offset = "0x217B5BC", VA = "0x217B5BC")]
	[Token(Token = "0x6003D18")]
	public static string smethod_22(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D19 RID: 15641 RVA: 0x000020B4 File Offset: 0x000002B4
	[Token(Token = "0x6003D19")]
	[Address(RVA = "0x217B664", Offset = "0x217B664", VA = "0x217B664")]
	public GClass4()
	{
	}

	// Token: 0x06003D1A RID: 15642 RVA: 0x00077784 File Offset: 0x00075984
	[Address(RVA = "0x217B66C", Offset = "0x217B66C", VA = "0x217B66C")]
	[Token(Token = "0x6003D1A")]
	public static string smethod_23(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D1B RID: 15643 RVA: 0x00077784 File Offset: 0x00075984
	[Token(Token = "0x6003D1B")]
	[Address(RVA = "0x217B738", Offset = "0x217B738", VA = "0x217B738")]
	public static string smethod_24(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D1C RID: 15644 RVA: 0x000777B4 File Offset: 0x000759B4
	[Address(RVA = "0x217B84C", Offset = "0x217B84C", VA = "0x217B84C")]
	[Token(Token = "0x6003D1C")]
	public static string smethod_25(byte[] byte_0, byte[] byte_1)
	{
		1.m_value = byte_0;
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D1D RID: 15645 RVA: 0x0007779C File Offset: 0x0007599C
	[Token(Token = "0x6003D1D")]
	[Address(RVA = "0x217B978", Offset = "0x217B978", VA = "0x217B978")]
	public static string smethod_26(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}

	// Token: 0x06003D1E RID: 15646 RVA: 0x0007779C File Offset: 0x0007599C
	[Token(Token = "0x6003D1E")]
	[Address(RVA = "0x217BA1C", Offset = "0x217BA1C", VA = "0x217BA1C")]
	public static string smethod_27(byte[] byte_0, byte[] byte_1)
	{
		Encoding utf = Encoding.UTF8;
		string result;
		return result;
	}
}
