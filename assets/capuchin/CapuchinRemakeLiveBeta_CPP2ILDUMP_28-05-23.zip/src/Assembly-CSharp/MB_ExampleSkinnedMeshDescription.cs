﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000086 RID: 134
[Token(Token = "0x2000086")]
public class MB_ExampleSkinnedMeshDescription : MonoBehaviour
{
	// Token: 0x0600138E RID: 5006 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF88F0", Offset = "0x2EF88F0", VA = "0x2EF88F0")]
	[Token(Token = "0x600138E")]
	private void method_0()
	{
	}

	// Token: 0x0600138F RID: 5007 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF89D0", Offset = "0x2EF89D0", VA = "0x2EF89D0")]
	[Token(Token = "0x600138F")]
	private void method_1()
	{
	}

	// Token: 0x06001390 RID: 5008 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF8AB0", Offset = "0x2EF8AB0", VA = "0x2EF8AB0")]
	[Token(Token = "0x6001390")]
	private void method_2()
	{
	}

	// Token: 0x06001391 RID: 5009 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF8B90", Offset = "0x2EF8B90", VA = "0x2EF8B90")]
	[Token(Token = "0x6001391")]
	private void method_3()
	{
	}

	// Token: 0x06001392 RID: 5010 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF8C70", Offset = "0x2EF8C70", VA = "0x2EF8C70")]
	[Token(Token = "0x6001392")]
	private void method_4()
	{
	}

	// Token: 0x06001393 RID: 5011 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF8D50", Offset = "0x2EF8D50", VA = "0x2EF8D50")]
	[Token(Token = "0x6001393")]
	private void method_5()
	{
	}

	// Token: 0x06001394 RID: 5012 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF8E30", Offset = "0x2EF8E30", VA = "0x2EF8E30")]
	[Token(Token = "0x6001394")]
	private void method_6()
	{
	}

	// Token: 0x06001395 RID: 5013 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF8F10", Offset = "0x2EF8F10", VA = "0x2EF8F10")]
	[Token(Token = "0x6001395")]
	private void method_7()
	{
	}

	// Token: 0x06001396 RID: 5014 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF8FF0", Offset = "0x2EF8FF0", VA = "0x2EF8FF0")]
	[Token(Token = "0x6001396")]
	private void method_8()
	{
	}

	// Token: 0x06001397 RID: 5015 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF90D0", Offset = "0x2EF90D0", VA = "0x2EF90D0")]
	[Token(Token = "0x6001397")]
	private void OnGUI()
	{
	}

	// Token: 0x06001398 RID: 5016 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF91B0", Offset = "0x2EF91B0", VA = "0x2EF91B0")]
	[Token(Token = "0x6001398")]
	private void method_9()
	{
	}

	// Token: 0x06001399 RID: 5017 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF9290", Offset = "0x2EF9290", VA = "0x2EF9290")]
	[Token(Token = "0x6001399")]
	private void method_10()
	{
	}

	// Token: 0x0600139A RID: 5018 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF9370", Offset = "0x2EF9370", VA = "0x2EF9370")]
	[Token(Token = "0x600139A")]
	private void method_11()
	{
	}

	// Token: 0x0600139B RID: 5019 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EF9450", Offset = "0x2EF9450", VA = "0x2EF9450")]
	[Token(Token = "0x600139B")]
	private void method_12()
	{
	}

	// Token: 0x0600139C RID: 5020 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2EF9530", Offset = "0x2EF9530", VA = "0x2EF9530")]
	[Token(Token = "0x600139C")]
	public MB_ExampleSkinnedMeshDescription()
	{
	}
}
