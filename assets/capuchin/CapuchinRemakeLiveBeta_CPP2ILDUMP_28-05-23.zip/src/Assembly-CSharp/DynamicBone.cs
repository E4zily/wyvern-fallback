﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000BF RID: 191
[Token(Token = "0x20000BF")]
[AddComponentMenu("Dynamic Bone/Dynamic Bone")]
public class DynamicBone : MonoBehaviour
{
	// Token: 0x06001B56 RID: 6998 RVA: 0x00002998 File Offset: 0x00000B98
	[Address(RVA = "0x2EAC62C", Offset = "0x2EAC62C", VA = "0x2EAC62C")]
	[Token(Token = "0x6001B56")]
	private void OnEnable()
	{
		this.method_28();
	}

	// Token: 0x06001B57 RID: 6999 RVA: 0x000029A0 File Offset: 0x00000BA0
	[Address(RVA = "0x2EAC6EC", Offset = "0x2EAC6EC", VA = "0x2EAC6EC")]
	[Token(Token = "0x6001B57")]
	private void method_0()
	{
		this.method_25();
	}

	// Token: 0x06001B58 RID: 7000 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAC79C", Offset = "0x2EAC79C", VA = "0x2EAC79C")]
	[Token(Token = "0x6001B58")]
	private void method_1(DynamicBone.Class28 class28_0, float float_14, int int_5)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B59 RID: 7001 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAC9BC", Offset = "0x2EAC9BC", VA = "0x2EAC9BC")]
	[Token(Token = "0x6001B59")]
	private void method_2()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B5A RID: 7002 RVA: 0x000029A8 File Offset: 0x00000BA8
	[Address(RVA = "0x2EACC48", Offset = "0x2EACC48", VA = "0x2EACC48")]
	[Token(Token = "0x6001B5A")]
	private void method_3()
	{
		this.method_19();
	}

	// Token: 0x06001B5C RID: 7004 RVA: 0x00035370 File Offset: 0x00033570
	[Address(RVA = "0x2EACD78", Offset = "0x2EACD78", VA = "0x2EACD78")]
	[Token(Token = "0x6001B5C")]
	private void method_4(Transform transform_2)
	{
		new DynamicBone.Class28().transform_0 = transform_2;
		Matrix4x4 worldToLocalMatrix = transform_2.worldToLocalMatrix;
	}

	// Token: 0x06001B5D RID: 7005 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x2EACEA0", Offset = "0x2EACEA0", VA = "0x2EACEA0")]
	[Token(Token = "0x6001B5D")]
	private void method_5(float float_14)
	{
	}

	// Token: 0x06001B5E RID: 7006 RVA: 0x00035390 File Offset: 0x00033590
	[Address(RVA = "0x2EAD420", Offset = "0x2EAD420", VA = "0x2EAD420")]
	[Token(Token = "0x6001B5E")]
	private void method_6()
	{
		this.method_8();
		if (this.bool_1)
		{
			DynamicBone.smethod_9(this);
		}
		DynamicBone.int_3 = DynamicBone.int_3;
	}

	// Token: 0x06001B5F RID: 7007 RVA: 0x000353BC File Offset: 0x000335BC
	[Address(RVA = "0x2EAD5BC", Offset = "0x2EAD5BC", VA = "0x2EAD5BC")]
	[Token(Token = "0x6001B5F")]
	private void FixedUpdate()
	{
		this.method_8();
	}

	// Token: 0x06001B60 RID: 7008 RVA: 0x000353D0 File Offset: 0x000335D0
	[Address(RVA = "0x2EAD5D0", Offset = "0x2EAD5D0", VA = "0x2EAD5D0")]
	[Token(Token = "0x6001B60")]
	private void method_7()
	{
		if (this.bool_0 && this.bool_2)
		{
			return;
		}
		this.method_64();
	}

	// Token: 0x06001B61 RID: 7009 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAD6C4", Offset = "0x2EAD6C4", VA = "0x2EAD6C4")]
	[Token(Token = "0x6001B61")]
	private static void smethod_0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B62 RID: 7010 RVA: 0x000353F4 File Offset: 0x000335F4
	[Address(RVA = "0x2EAD4E4", Offset = "0x2EAD4E4", VA = "0x2EAD4E4")]
	[Token(Token = "0x6001B62")]
	private void method_8()
	{
		if (!this.bool_0 || !this.bool_2)
		{
			this.method_43();
		}
		int num = this.int_0;
		this.int_0 = num;
	}

	// Token: 0x06001B63 RID: 7011 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAE428", Offset = "0x2EAE428", VA = "0x2EAE428")]
	[Token(Token = "0x6001B63")]
	private void method_9(DynamicBone.Class28 class28_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B64 RID: 7012 RVA: 0x00035428 File Offset: 0x00033628
	[Address(RVA = "0x2EAE798", Offset = "0x2EAE798", VA = "0x2EAE798")]
	[Token(Token = "0x6001B64")]
	private void method_10()
	{
		float num = this.float_0;
		this.float_0 = num;
		float value2;
		float value = Mathf.Clamp01(value2);
		this.float_1 = num;
		float value3 = Mathf.Clamp01(value);
		this.float_2 = num;
		float value4 = Mathf.Clamp01(value3);
		this.float_3 = num;
		float value5 = Mathf.Clamp01(value4);
		this.float_4 = num;
		Mathf.Clamp01(value5);
		this.float_5 = num;
		this.float_6 = num;
		bool isEditor = Application.isEditor;
		bool isPlaying = Application.isPlaying;
		this.method_29();
		this.method_39();
		this.method_68();
	}

	// Token: 0x06001B65 RID: 7013 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAEFE4", Offset = "0x2EAEFE4", VA = "0x2EAEFE4")]
	[Token(Token = "0x6001B65")]
	private void method_11()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B66 RID: 7014 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAF0AC", Offset = "0x2EAF0AC", VA = "0x2EAF0AC")]
	[Token(Token = "0x6001B66")]
	private void method_12(DynamicBone.Class28 class28_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B67 RID: 7015 RVA: 0x000354B8 File Offset: 0x000336B8
	[Address(RVA = "0x2EAF180", Offset = "0x2EAF180", VA = "0x2EAF180")]
	[Token(Token = "0x6001B67")]
	private void method_13()
	{
		int num = this.int_0;
		if (num != 0)
		{
			if (num != 0)
			{
			}
			if (DynamicBone.int_3 != 0)
			{
			}
			DynamicBone.list_5 = 1;
			if (this.bool_3)
			{
				DynamicBone.smethod_15();
				return;
			}
			this.method_63();
			if (this.bool_0 && !this.bool_2)
			{
				this.method_49();
				this.method_34();
				this.method_33();
			}
			long num2 = 1L;
			this.int_0 = (int)num2;
		}
	}

	// Token: 0x06001B68 RID: 7016 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAFE9C", Offset = "0x2EAFE9C", VA = "0x2EAFE9C")]
	[Token(Token = "0x6001B68")]
	private bool method_14()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B69 RID: 7017 RVA: 0x00035520 File Offset: 0x00033720
	[Address(RVA = "0x2EB01B8", Offset = "0x2EB01B8", VA = "0x2EB01B8")]
	[Token(Token = "0x6001B69")]
	private void method_15()
	{
		this.method_79();
	}

	// Token: 0x06001B6A RID: 7018 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB0220", Offset = "0x2EB0220", VA = "0x2EB0220")]
	[Token(Token = "0x6001B6A")]
	private bool method_16()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B6B RID: 7019 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB0564", Offset = "0x2EB0564", VA = "0x2EB0564")]
	[Token(Token = "0x6001B6B")]
	private void method_17(DynamicBone.Class28 class28_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B6C RID: 7020 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB067C", Offset = "0x2EB067C", VA = "0x2EB067C")]
	[Token(Token = "0x6001B6C")]
	private void method_18(DynamicBone.Class28 class28_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B6D RID: 7021 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x2EACC4C", Offset = "0x2EACC4C", VA = "0x2EACC4C")]
	[Token(Token = "0x6001B6D")]
	private void method_19()
	{
	}

	// Token: 0x06001B6E RID: 7022 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB0794", Offset = "0x2EB0794", VA = "0x2EB0794")]
	[Token(Token = "0x6001B6E")]
	private void method_20()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B6F RID: 7023 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB0B90", Offset = "0x2EB0B90", VA = "0x2EB0B90")]
	[Token(Token = "0x6001B6F")]
	private static DynamicBone smethod_1()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B70 RID: 7024 RVA: 0x00035534 File Offset: 0x00033734
	[Address(RVA = "0x2EB0C40", Offset = "0x2EB0C40", VA = "0x2EB0C40")]
	[Token(Token = "0x6001B70")]
	private static void smethod_2()
	{
	}

	// Token: 0x06001B71 RID: 7025 RVA: 0x00035544 File Offset: 0x00033744
	[Address(RVA = "0x2EB0E24", Offset = "0x2EB0E24", VA = "0x2EB0E24")]
	[Token(Token = "0x6001B71")]
	private void method_21()
	{
		if (!this.bool_0 || !this.bool_2)
		{
			this.method_64();
		}
	}

	// Token: 0x06001B72 RID: 7026 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB0E70", Offset = "0x2EB0E70", VA = "0x2EB0E70")]
	[Token(Token = "0x6001B72")]
	private void method_22()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B73 RID: 7027 RVA: 0x00002998 File Offset: 0x00000B98
	[Address(RVA = "0x2EB0F6C", Offset = "0x2EB0F6C", VA = "0x2EB0F6C")]
	[Token(Token = "0x6001B73")]
	private void method_23()
	{
		this.method_28();
	}

	// Token: 0x06001B74 RID: 7028 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB0F70", Offset = "0x2EB0F70", VA = "0x2EB0F70")]
	[Token(Token = "0x6001B74")]
	private void method_24(DynamicBone.Class28 class28_0, float float_14)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B75 RID: 7029 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAC6F0", Offset = "0x2EAC6F0", VA = "0x2EAC6F0")]
	[Token(Token = "0x6001B75")]
	public void method_25()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B76 RID: 7030 RVA: 0x000029C6 File Offset: 0x00000BC6
	[Address(RVA = "0x2EB179C", Offset = "0x2EB179C", VA = "0x2EB179C")]
	[Token(Token = "0x6001B76")]
	private void method_26()
	{
		this.method_81();
	}

	// Token: 0x06001B77 RID: 7031 RVA: 0x00035568 File Offset: 0x00033768
	[Address(RVA = "0x2EB0D08", Offset = "0x2EB0D08", VA = "0x2EB0D08")]
	[Token(Token = "0x6001B77")]
	private void method_27()
	{
	}

	// Token: 0x06001B78 RID: 7032 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAC630", Offset = "0x2EAC630", VA = "0x2EAC630")]
	[Token(Token = "0x6001B78")]
	private void method_28()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B79 RID: 7033 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAE898", Offset = "0x2EAE898", VA = "0x2EAE898")]
	[Token(Token = "0x6001B79")]
	private bool method_29()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B7A RID: 7034 RVA: 0x00035578 File Offset: 0x00033778
	[Address(RVA = "0x2EB1C90", Offset = "0x2EB1C90", VA = "0x2EB1C90")]
	[Token(Token = "0x6001B7A")]
	private void method_30()
	{
	}

	// Token: 0x06001B7B RID: 7035 RVA: 0x00035588 File Offset: 0x00033788
	[Address(RVA = "0x2EB1D20", Offset = "0x2EB1D20", VA = "0x2EB1D20")]
	[Token(Token = "0x6001B7B")]
	private static void smethod_3(DynamicBone dynamicBone_0)
	{
		DynamicBone.semaphore_0.Release();
	}

	// Token: 0x06001B7C RID: 7036 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB1D90", Offset = "0x2EB1D90", VA = "0x2EB1D90")]
	[Token(Token = "0x6001B7C")]
	public void method_31()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B7D RID: 7037 RVA: 0x000355A0 File Offset: 0x000337A0
	[Address(RVA = "0x2EB25F4", Offset = "0x2EB25F4", VA = "0x2EB25F4")]
	[Token(Token = "0x6001B7D")]
	private void method_32()
	{
		int num = this.int_0;
		if (num != 0)
		{
			if (num != 0)
			{
			}
			if (DynamicBone.int_3 != 0)
			{
			}
			if (this.bool_3)
			{
				long num2 = 1L;
				this.bool_3 = (num2 != 0L);
				if (num2 != 0L)
				{
				}
				DynamicBone.smethod_0();
				return;
			}
			this.method_53();
			if (!this.bool_0 || !this.bool_2)
			{
				this.method_37();
				this.method_27();
				this.method_2();
			}
		}
	}

	// Token: 0x06001B7E RID: 7038 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAFDD4", Offset = "0x2EAFDD4", VA = "0x2EAFDD4")]
	[Token(Token = "0x6001B7E")]
	private void method_33()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B7F RID: 7039 RVA: 0x00035604 File Offset: 0x00033804
	[Address(RVA = "0x2EAFD20", Offset = "0x2EAFD20", VA = "0x2EAFD20")]
	[Token(Token = "0x6001B7F")]
	private void method_34()
	{
		if (this.genum8_0 != DynamicBone.GEnum8.const_0)
		{
			float num = this.float_0;
			this.float_11 = num;
			this.float_11 = num;
		}
		this.method_66();
	}

	// Token: 0x06001B80 RID: 7040 RVA: 0x00035634 File Offset: 0x00033834
	[Address(RVA = "0x2EAD5F4", Offset = "0x2EAD5F4", VA = "0x2EAD5F4")]
	[Token(Token = "0x6001B80")]
	private bool method_35()
	{
		if (!this.bool_0)
		{
			return;
		}
	}

	// Token: 0x06001B81 RID: 7041 RVA: 0x000029CE File Offset: 0x00000BCE
	[Address(RVA = "0x2EB2B2C", Offset = "0x2EB2B2C", VA = "0x2EB2B2C")]
	[Token(Token = "0x6001B81")]
	private void method_36()
	{
		this.method_71();
	}

	// Token: 0x06001B82 RID: 7042 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB270C", Offset = "0x2EB270C", VA = "0x2EB270C")]
	[Token(Token = "0x6001B82")]
	private void method_37()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B83 RID: 7043 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAE2C4", Offset = "0x2EAE2C4", VA = "0x2EAE2C4")]
	[Token(Token = "0x6001B83")]
	private void method_38()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B84 RID: 7044 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x2EAEBE0", Offset = "0x2EAEBE0", VA = "0x2EAEBE0")]
	[Token(Token = "0x6001B84")]
	private void method_39()
	{
	}

	// Token: 0x06001B85 RID: 7045 RVA: 0x000285D8 File Offset: 0x000267D8
	[Address(RVA = "0x2EB2BE4", Offset = "0x2EB2BE4", VA = "0x2EB2BE4")]
	[Token(Token = "0x6001B85")]
	private static Vector3 smethod_4(Vector3 vector3_5, Vector3 vector3_6)
	{
		Vector3 result;
		return result;
	}

	// Token: 0x06001B86 RID: 7046 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB1A88", Offset = "0x2EB1A88", VA = "0x2EB1A88")]
	[Token(Token = "0x6001B86")]
	private void method_40(float float_14, int int_5)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B87 RID: 7047 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EACF24", Offset = "0x2EACF24", VA = "0x2EACF24")]
	[Token(Token = "0x6001B87")]
	private void method_41(DynamicBone.Class28 class28_0, float float_14)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B88 RID: 7048 RVA: 0x00035534 File Offset: 0x00033734
	[Address(RVA = "0x2EB2C18", Offset = "0x2EB2C18", VA = "0x2EB2C18")]
	[Token(Token = "0x6001B88")]
	private static void smethod_5()
	{
	}

	// Token: 0x06001B89 RID: 7049 RVA: 0x00035534 File Offset: 0x00033734
	[Address(RVA = "0x2EB2D90", Offset = "0x2EB2D90", VA = "0x2EB2D90")]
	[Token(Token = "0x6001B89")]
	private static void smethod_6()
	{
	}

	// Token: 0x06001B8A RID: 7050 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB2E58", Offset = "0x2EB2E58", VA = "0x2EB2E58")]
	[Token(Token = "0x6001B8A")]
	public void method_42()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B8B RID: 7051 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAE38C", Offset = "0x2EAE38C", VA = "0x2EAE38C")]
	[Token(Token = "0x6001B8B")]
	private void method_43()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B8C RID: 7052 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB3268", Offset = "0x2EB3268", VA = "0x2EB3268")]
	[Token(Token = "0x6001B8C")]
	private void method_44(DynamicBone.Class28 class28_0, Transform transform_2, int int_5, float float_14)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B8D RID: 7053 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EADE74", Offset = "0x2EADE74", VA = "0x2EADE74")]
	[Token(Token = "0x6001B8D")]
	private void method_45()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B8E RID: 7054 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB3804", Offset = "0x2EB3804", VA = "0x2EB3804")]
	[Token(Token = "0x6001B8E")]
	private void method_46()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B8F RID: 7055 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x2EB3C20", Offset = "0x2EB3C20", VA = "0x2EB3C20")]
	[Token(Token = "0x6001B8F")]
	private void method_47(float float_14)
	{
	}

	// Token: 0x06001B90 RID: 7056 RVA: 0x0003564C File Offset: 0x0003384C
	[Address(RVA = "0x2EB3CA4", Offset = "0x2EB3CA4", VA = "0x2EB3CA4")]
	[Token(Token = "0x6001B90")]
	public DynamicBone()
	{
		long num = 17008L;
		this.float_0 = (float)num;
		this.float_1 = (float)52429;
		this.float_2 = (float)52429;
		this.float_3 = (float)52429;
		Vector3 zero = Vector3.zero;
		Vector3 zero2 = Vector3.zero;
		Vector3 zero3 = Vector3.zero;
		long num2 = 1065353216L;
		long num3 = 1L;
		this.float_8 = (float)num2;
		this.float_9 = (float)16800;
		this.bool_1 = (num3 != 0L);
		this.float_12 = (float)num2;
		List<DynamicBone.Class28> list = new List();
		this.list_3 = list;
		base..ctor();
	}

	// Token: 0x06001B91 RID: 7057 RVA: 0x000356DC File Offset: 0x000338DC
	[Address(RVA = "0x2EB2B30", Offset = "0x2EB2B30", VA = "0x2EB2B30")]
	[Token(Token = "0x6001B91")]
	private void method_48(DynamicBone.Class28 class28_0)
	{
		if (class28_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001B92 RID: 7058 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAF8E4", Offset = "0x2EAF8E4", VA = "0x2EAF8E4")]
	[Token(Token = "0x6001B92")]
	private void method_49()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B93 RID: 7059 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB1B40", Offset = "0x2EB1B40", VA = "0x2EB1B40")]
	[Token(Token = "0x6001B93")]
	private void method_50(float float_14)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B94 RID: 7060 RVA: 0x000356F0 File Offset: 0x000338F0
	[Address(RVA = "0x2EAF2BC", Offset = "0x2EAF2BC", VA = "0x2EAF2BC")]
	[Token(Token = "0x6001B94")]
	public void method_51(float float_14)
	{
		this.method_43();
	}

	// Token: 0x06001B95 RID: 7061 RVA: 0x000029D6 File Offset: 0x00000BD6
	[Address(RVA = "0x2EB3D94", Offset = "0x2EB3D94", VA = "0x2EB3D94")]
	[Token(Token = "0x6001B95")]
	private void OnDisable()
	{
		this.method_43();
	}

	// Token: 0x06001B96 RID: 7062 RVA: 0x00035370 File Offset: 0x00033570
	[Address(RVA = "0x2EB3140", Offset = "0x2EB3140", VA = "0x2EB3140")]
	[Token(Token = "0x6001B96")]
	private void method_52(Transform transform_2)
	{
		new DynamicBone.Class28().transform_0 = transform_2;
		Matrix4x4 worldToLocalMatrix = transform_2.worldToLocalMatrix;
	}

	// Token: 0x06001B97 RID: 7063 RVA: 0x00035704 File Offset: 0x00033904
	[Address(RVA = "0x2EADACC", Offset = "0x2EADACC", VA = "0x2EADACC")]
	[Token(Token = "0x6001B97")]
	private void method_53()
	{
		bool flag;
		if (flag = this.bool_0)
		{
			if (flag)
			{
			}
			Camera main = Camera.main;
			Transform transform = Camera.main.transform;
			Vector3 position = transform.position;
			float sqrMagnitude = base.transform.position.sqrMagnitude;
			bool flag2 = this.bool_2;
			this.method_30();
			this.bool_2 = flag2;
		}
	}

	// Token: 0x06001B98 RID: 7064 RVA: 0x000029A0 File Offset: 0x00000BA0
	[Address(RVA = "0x2EB3D98", Offset = "0x2EB3D98", VA = "0x2EB3D98")]
	[Token(Token = "0x6001B98")]
	private void method_54()
	{
		this.method_25();
	}

	// Token: 0x06001B99 RID: 7065 RVA: 0x00035760 File Offset: 0x00033960
	[Address(RVA = "0x2EB3D9C", Offset = "0x2EB3D9C", VA = "0x2EB3D9C")]
	[Token(Token = "0x6001B99")]
	private void method_55()
	{
		float num = this.float_0;
		this.float_0 = num;
		float value2;
		float value = Mathf.Clamp01(value2);
		this.float_1 = num;
		float value3 = Mathf.Clamp01(value);
		this.float_2 = num;
		float value4 = Mathf.Clamp01(value3);
		this.float_3 = num;
		float value5 = Mathf.Clamp01(value4);
		this.float_4 = num;
		Mathf.Clamp01(value5);
		this.float_5 = num;
		this.float_6 = num;
		bool isEditor = Application.isEditor;
		bool isPlaying = Application.isPlaying;
		this.method_16();
		this.method_43();
		this.method_68();
	}

	// Token: 0x06001B9A RID: 7066 RVA: 0x000357F0 File Offset: 0x000339F0
	[Address(RVA = "0x2EB3E98", Offset = "0x2EB3E98", VA = "0x2EB3E98")]
	[Token(Token = "0x6001B9A")]
	private void LateUpdate()
	{
		int num = this.int_0;
		if (num != 0)
		{
			if (num != 0)
			{
			}
			if (DynamicBone.int_3 != 0)
			{
			}
			bool flag;
			if (flag = this.bool_3)
			{
				if (flag)
				{
				}
				DynamicBone.smethod_7();
				return;
			}
			this.method_63();
			if (!this.bool_0 || !this.bool_2)
			{
				this.method_49();
				this.method_27();
				this.method_2();
			}
		}
	}

	// Token: 0x06001B9B RID: 7067 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB1460", Offset = "0x2EB1460", VA = "0x2EB1460")]
	[Token(Token = "0x6001B9B")]
	private void method_56(DynamicBone.Class28 class28_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B9C RID: 7068 RVA: 0x0003584C File Offset: 0x00033A4C
	[Address(RVA = "0x2EB43B0", Offset = "0x2EB43B0", VA = "0x2EB43B0")]
	[Token(Token = "0x6001B9C")]
	public float method_57()
	{
	}

	// Token: 0x06001B9D RID: 7069 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB3FC0", Offset = "0x2EB3FC0", VA = "0x2EB3FC0")]
	[Token(Token = "0x6001B9D")]
	private static void smethod_7()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001B9E RID: 7070 RVA: 0x00035370 File Offset: 0x00033570
	[Address(RVA = "0x2EB43B8", Offset = "0x2EB43B8", VA = "0x2EB43B8")]
	[Token(Token = "0x6001B9E")]
	private void method_58(Transform transform_2)
	{
		new DynamicBone.Class28().transform_0 = transform_2;
		Matrix4x4 worldToLocalMatrix = transform_2.worldToLocalMatrix;
	}

	// Token: 0x06001B9F RID: 7071 RVA: 0x0003585C File Offset: 0x00033A5C
	[Address(RVA = "0x2EB44E0", Offset = "0x2EB44E0", VA = "0x2EB44E0")]
	[Token(Token = "0x6001B9F")]
	private void OnValidate()
	{
		float num = this.float_0;
		this.float_0 = num;
		float value2;
		float value = Mathf.Clamp01(value2);
		this.float_1 = num;
		float value3 = Mathf.Clamp01(value);
		this.float_2 = num;
		float value4 = Mathf.Clamp01(value3);
		this.float_3 = num;
		float value5 = Mathf.Clamp01(value4);
		this.float_4 = num;
		Mathf.Clamp01(value5);
		this.float_5 = num;
		this.float_6 = num;
		bool isEditor = Application.isEditor;
		bool isPlaying = Application.isPlaying;
		this.method_16();
		this.method_43();
		this.method_31();
	}

	// Token: 0x06001BA0 RID: 7072 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB45D8", Offset = "0x2EB45D8", VA = "0x2EB45D8")]
	[Token(Token = "0x6001BA0")]
	private void method_59(DynamicBone.Class28 class28_0, float float_14, int int_5)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BA1 RID: 7073 RVA: 0x0003584C File Offset: 0x00033A4C
	[Address(RVA = "0x2EB47F0", Offset = "0x2EB47F0", VA = "0x2EB47F0")]
	[Token(Token = "0x6001BA1")]
	public float method_60()
	{
	}

	// Token: 0x06001BA2 RID: 7074 RVA: 0x000358EC File Offset: 0x00033AEC
	[Address(RVA = "0x2EB47F8", Offset = "0x2EB47F8", VA = "0x2EB47F8")]
	[Token(Token = "0x6001BA2")]
	private void Update()
	{
		this.method_8();
		long num;
		if (this.bool_1)
		{
			DynamicBone.smethod_13(this);
			num = 1L;
			this.bool_3 = (num != 0L);
		}
		if (num != 0L)
		{
		}
		DynamicBone.int_3 = DynamicBone.int_3;
	}

	// Token: 0x06001BA3 RID: 7075 RVA: 0x00035924 File Offset: 0x00033B24
	[Address(RVA = "0x2EADCC8", Offset = "0x2EADCC8", VA = "0x2EADCC8")]
	[Token(Token = "0x6001BA3")]
	private static void smethod_8()
	{
		AutoResetEvent autoResetEvent = new AutoResetEvent(0L != 0L);
		DynamicBone.autoResetEvent_0 = autoResetEvent;
		Semaphore semaphore = new Semaphore((int)0L, (int)0L);
		DynamicBone.semaphore_0 = semaphore;
		int processorCount = Environment.ProcessorCount;
		ThreadStart start;
		Thread thread = new Thread(start);
		long isBackground = 1L;
		thread.IsBackground = (isBackground != 0L);
		thread.Start();
	}

	// Token: 0x06001BA4 RID: 7076 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB494C", Offset = "0x2EB494C", VA = "0x2EB494C")]
	[Token(Token = "0x6001BA4")]
	private void OnDrawGizmosSelected()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BA5 RID: 7077 RVA: 0x00035988 File Offset: 0x00033B88
	[Address(RVA = "0x2EB4A48", Offset = "0x2EB4A48", VA = "0x2EB4A48")]
	[Token(Token = "0x6001BA5")]
	private void method_61()
	{
		bool flag;
		if (flag = this.bool_0)
		{
			if (flag)
			{
			}
			Camera main = Camera.main;
			Transform transform = Camera.main.transform;
			Vector3 position = transform.position;
			Transform transform2;
			float sqrMagnitude = transform2.position.sqrMagnitude;
			bool flag2 = this.bool_2;
			this.method_30();
			this.bool_2 = flag2;
		}
	}

	// Token: 0x06001BA6 RID: 7078 RVA: 0x000359E0 File Offset: 0x00033BE0
	[Address(RVA = "0x2EB4C08", Offset = "0x2EB4C08", VA = "0x2EB4C08")]
	[Token(Token = "0x6001BA6")]
	private void method_62()
	{
		int num = this.int_0;
		if (num != 0)
		{
			if (num != 0)
			{
			}
			if (DynamicBone.int_3 != 0)
			{
			}
			DynamicBone.list_5 = 1;
			bool flag;
			if (flag = this.bool_3)
			{
				if (flag)
				{
				}
				DynamicBone.smethod_7();
				return;
			}
			this.method_53();
			if (this.bool_0 && !this.bool_2)
			{
				this.method_77();
				this.method_27();
				this.method_11();
			}
			long num2 = 1L;
			this.int_0 = (int)num2;
		}
	}

	// Token: 0x06001BA7 RID: 7079 RVA: 0x00035A50 File Offset: 0x00033C50
	[Address(RVA = "0x2EAF724", Offset = "0x2EAF724", VA = "0x2EAF724")]
	[Token(Token = "0x6001BA7")]
	private void method_63()
	{
		bool flag;
		if (flag = this.bool_0)
		{
			if (flag)
			{
			}
			Camera main = Camera.main;
			Transform transform = Camera.main.transform;
			Vector3 position = transform.position;
			float sqrMagnitude = base.transform.position.sqrMagnitude;
			bool flag2 = this.bool_2;
			this.method_28();
			this.bool_2 = flag2;
		}
	}

	// Token: 0x06001BA8 RID: 7080 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAD628", Offset = "0x2EAD628", VA = "0x2EAD628")]
	[Token(Token = "0x6001BA8")]
	private void method_64()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BA9 RID: 7081 RVA: 0x00035AAC File Offset: 0x00033CAC
	[Address(RVA = "0x2EADC8C", Offset = "0x2EADC8C", VA = "0x2EADC8C")]
	[Token(Token = "0x6001BA9")]
	private bool method_65()
	{
		/*
An exception occurred when decompiling this method (06001BA9)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DynamicBone::method_65()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	IL_00:; 	brtrue(IL_00, logicnot:bool(ldfld:bool(DynamicBone::bool_0, ldloc:DynamicBone(this)))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1815
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1815
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1783
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06001BAA RID: 7082 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB1BF0", Offset = "0x2EB1BF0", VA = "0x2EB1BF0")]
	[Token(Token = "0x6001BAA")]
	private void method_66()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BAB RID: 7083 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB520C", Offset = "0x2EB520C", VA = "0x2EB520C")]
	[Token(Token = "0x6001BAB")]
	private void method_67(DynamicBone.Class28 class28_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BAC RID: 7084 RVA: 0x00035AC4 File Offset: 0x00033CC4
	[Address(RVA = "0x2EAD530", Offset = "0x2EAD530", VA = "0x2EAD530")]
	[Token(Token = "0x6001BAC")]
	private static void smethod_9(DynamicBone dynamicBone_0)
	{
	}

	// Token: 0x06001BAD RID: 7085 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAEC50", Offset = "0x2EAEC50", VA = "0x2EAEC50")]
	[Token(Token = "0x6001BAD")]
	public void method_68()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BAE RID: 7086 RVA: 0x0003584C File Offset: 0x00033A4C
	[Address(RVA = "0x2EB5558", Offset = "0x2EB5558", VA = "0x2EB5558")]
	[Token(Token = "0x6001BAE")]
	public float method_69()
	{
	}

	// Token: 0x06001BAF RID: 7087 RVA: 0x00035588 File Offset: 0x00033788
	[Address(RVA = "0x2EAE254", Offset = "0x2EAE254", VA = "0x2EAE254")]
	[Token(Token = "0x6001BAF")]
	private static void smethod_10(DynamicBone dynamicBone_0)
	{
		DynamicBone.semaphore_0.Release();
	}

	// Token: 0x06001BB0 RID: 7088 RVA: 0x0003584C File Offset: 0x00033A4C
	[Address(RVA = "0x2EB5560", Offset = "0x2EB5560", VA = "0x2EB5560")]
	[Token(Token = "0x6001BB0")]
	public float method_70()
	{
	}

	// Token: 0x06001BB1 RID: 7089 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAEF38", Offset = "0x2EAEF38", VA = "0x2EAEF38")]
	[Token(Token = "0x6001BB1")]
	public void method_71()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BB2 RID: 7090 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB5898", Offset = "0x2EB5898", VA = "0x2EB5898")]
	[Token(Token = "0x6001BB2")]
	private static Vector3 smethod_11(Vector3 vector3_5, Vector3 vector3_6)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BB3 RID: 7091 RVA: 0x00035AD4 File Offset: 0x00033CD4
	[Address(RVA = "0x2EB58D4", Offset = "0x2EB58D4", VA = "0x2EB58D4")]
	[Token(Token = "0x6001BB3")]
	private void method_72()
	{
		int num = this.int_0;
		if (num != 0)
		{
			if (num != 0)
			{
			}
			if (DynamicBone.int_3 != 0)
			{
			}
			DynamicBone.list_5 = 1;
			if (this.bool_3)
			{
				DynamicBone.smethod_15();
				return;
			}
			this.method_53();
			if (!this.bool_0 || !this.bool_2)
			{
				this.method_37();
				this.method_27();
				this.method_2();
			}
		}
	}

	// Token: 0x06001BB4 RID: 7092 RVA: 0x00035B34 File Offset: 0x00033D34
	[Address(RVA = "0x2EB5A00", Offset = "0x2EB5A00", VA = "0x2EB5A00")]
	[Token(Token = "0x6001BB4")]
	private void method_73(DynamicBone.Class28 class28_0)
	{
		if (class28_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001BB5 RID: 7093 RVA: 0x000029A8 File Offset: 0x00000BA8
	[Address(RVA = "0x2EB5AEC", Offset = "0x2EB5AEC", VA = "0x2EB5AEC")]
	[Token(Token = "0x6001BB5")]
	private void method_74()
	{
		this.method_19();
	}

	// Token: 0x06001BB6 RID: 7094 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EACA84", Offset = "0x2EACA84", VA = "0x2EACA84")]
	[Token(Token = "0x6001BB6")]
	private void method_75(DynamicBone.Class28 class28_0, Vector3 vector3_5, Vector3 vector3_6, Vector3 vector3_7, bool bool_4, bool bool_5, bool bool_6)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BB7 RID: 7095 RVA: 0x00035B48 File Offset: 0x00033D48
	[Address(RVA = "0x2EB2CE0", Offset = "0x2EB2CE0", VA = "0x2EB2CE0")]
	[Token(Token = "0x6001BB7")]
	private static DynamicBone smethod_12()
	{
		ThrowHelper.ThrowArgumentOutOfRangeException();
		throw new NullReferenceException();
	}

	// Token: 0x06001BB8 RID: 7096 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB2084", Offset = "0x2EB2084", VA = "0x2EB2084")]
	[Token(Token = "0x6001BB8")]
	private void method_76(DynamicBone.Class28 class28_0, Transform transform_2, int int_5, float float_14)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BB9 RID: 7097 RVA: 0x00035AC4 File Offset: 0x00033CC4
	[Address(RVA = "0x2EB48C0", Offset = "0x2EB48C0", VA = "0x2EB48C0")]
	[Token(Token = "0x6001BB9")]
	private static void smethod_13(DynamicBone dynamicBone_0)
	{
	}

	// Token: 0x06001BBA RID: 7098 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB4D40", Offset = "0x2EB4D40", VA = "0x2EB4D40")]
	[Token(Token = "0x6001BBA")]
	private void method_77()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BBB RID: 7099 RVA: 0x000029DE File Offset: 0x00000BDE
	[Address(RVA = "0x2EB5AF0", Offset = "0x2EB5AF0", VA = "0x2EB5AF0")]
	[Token(Token = "0x6001BBB")]
	private void Start()
	{
		this.method_31();
	}

	// Token: 0x06001BBC RID: 7100 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB5568", Offset = "0x2EB5568", VA = "0x2EB5568")]
	[Token(Token = "0x6001BBC")]
	private void method_78(DynamicBone.Class28 class28_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BBD RID: 7101 RVA: 0x00035B60 File Offset: 0x00033D60
	[Address(RVA = "0x2EB01CC", Offset = "0x2EB01CC", VA = "0x2EB01CC")]
	[Token(Token = "0x6001BBD")]
	private void method_79()
	{
		if (this.bool_0 && !this.bool_2)
		{
			this.method_39();
		}
		int num = this.int_0;
		this.int_0 = num;
	}

	// Token: 0x06001BBE RID: 7102 RVA: 0x00035534 File Offset: 0x00033734
	[Address(RVA = "0x2EB5AF4", Offset = "0x2EB5AF4", VA = "0x2EB5AF4")]
	[Token(Token = "0x6001BBE")]
	private static void smethod_14()
	{
	}

	// Token: 0x06001BBF RID: 7103 RVA: 0x000356DC File Offset: 0x000338DC
	[Token(Token = "0x6001BBF")]
	[Address(RVA = "0x2EB5158", Offset = "0x2EB5158", VA = "0x2EB5158")]
	private void method_80(DynamicBone.Class28 class28_0)
	{
		if (class28_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001BC0 RID: 7104 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EB17A0", Offset = "0x2EB17A0", VA = "0x2EB17A0")]
	[Token(Token = "0x6001BC0")]
	public void method_81()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001BC1 RID: 7105 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2EAF31C", Offset = "0x2EAF31C", VA = "0x2EAF31C")]
	[Token(Token = "0x6001BC1")]
	private static void smethod_15()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0400037D RID: 893
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400037D")]
	public Transform transform_0;

	// Token: 0x0400037E RID: 894
	[Token(Token = "0x400037E")]
	[FieldOffset(Offset = "0x20")]
	public List<Transform> list_0;

	// Token: 0x0400037F RID: 895
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400037F")]
	public float float_0;

	// Token: 0x04000380 RID: 896
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x4000380")]
	public DynamicBone.GEnum8 genum8_0;

	// Token: 0x04000381 RID: 897
	[Token(Token = "0x4000381")]
	[FieldOffset(Offset = "0x30")]
	public float float_1;

	// Token: 0x04000382 RID: 898
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000382")]
	public AnimationCurve animationCurve_0;

	// Token: 0x04000383 RID: 899
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000383")]
	public float float_2;

	// Token: 0x04000384 RID: 900
	[Token(Token = "0x4000384")]
	[FieldOffset(Offset = "0x48")]
	public AnimationCurve animationCurve_1;

	// Token: 0x04000385 RID: 901
	[Token(Token = "0x4000385")]
	[FieldOffset(Offset = "0x50")]
	public float float_3;

	// Token: 0x04000386 RID: 902
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000386")]
	public AnimationCurve animationCurve_2;

	// Token: 0x04000387 RID: 903
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000387")]
	public float float_4;

	// Token: 0x04000388 RID: 904
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000388")]
	public AnimationCurve animationCurve_3;

	// Token: 0x04000389 RID: 905
	[Token(Token = "0x4000389")]
	[FieldOffset(Offset = "0x70")]
	public float float_5;

	// Token: 0x0400038A RID: 906
	[Token(Token = "0x400038A")]
	[FieldOffset(Offset = "0x78")]
	public AnimationCurve animationCurve_4;

	// Token: 0x0400038B RID: 907
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x400038B")]
	public float float_6;

	// Token: 0x0400038C RID: 908
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x400038C")]
	public AnimationCurve animationCurve_5;

	// Token: 0x0400038D RID: 909
	[Token(Token = "0x400038D")]
	[FieldOffset(Offset = "0x90")]
	public float float_7;

	// Token: 0x0400038E RID: 910
	[FieldOffset(Offset = "0x94")]
	[Token(Token = "0x400038E")]
	public Vector3 vector3_0;

	// Token: 0x0400038F RID: 911
	[Token(Token = "0x400038F")]
	[FieldOffset(Offset = "0xA0")]
	public Vector3 vector3_1;

	// Token: 0x04000390 RID: 912
	[FieldOffset(Offset = "0xAC")]
	[Token(Token = "0x4000390")]
	public Vector3 vector3_2;

	// Token: 0x04000391 RID: 913
	[Token(Token = "0x4000391")]
	[FieldOffset(Offset = "0xB8")]
	public float float_8;

	// Token: 0x04000392 RID: 914
	[Token(Token = "0x4000392")]
	[FieldOffset(Offset = "0xC0")]
	public List<DynamicBoneColliderBase> list_1;

	// Token: 0x04000393 RID: 915
	[Token(Token = "0x4000393")]
	[FieldOffset(Offset = "0xC8")]
	public List<Transform> list_2;

	// Token: 0x04000394 RID: 916
	[FieldOffset(Offset = "0xD0")]
	[Token(Token = "0x4000394")]
	public DynamicBone.GEnum9 genum9_0;

	// Token: 0x04000395 RID: 917
	[Token(Token = "0x4000395")]
	[FieldOffset(Offset = "0xD4")]
	public bool bool_0;

	// Token: 0x04000396 RID: 918
	[FieldOffset(Offset = "0xD8")]
	[Token(Token = "0x4000396")]
	public Transform transform_1;

	// Token: 0x04000397 RID: 919
	[Token(Token = "0x4000397")]
	[FieldOffset(Offset = "0xE0")]
	public float float_9;

	// Token: 0x04000398 RID: 920
	[HideInInspector]
	[Token(Token = "0x4000398")]
	[FieldOffset(Offset = "0xE4")]
	public bool bool_1;

	// Token: 0x04000399 RID: 921
	[FieldOffset(Offset = "0xE8")]
	[Token(Token = "0x4000399")]
	private Vector3 vector3_3;

	// Token: 0x0400039A RID: 922
	[Token(Token = "0x400039A")]
	[FieldOffset(Offset = "0xF4")]
	private Vector3 vector3_4;

	// Token: 0x0400039B RID: 923
	[FieldOffset(Offset = "0x100")]
	[Token(Token = "0x400039B")]
	private float float_10;

	// Token: 0x0400039C RID: 924
	[FieldOffset(Offset = "0x104")]
	[Token(Token = "0x400039C")]
	private float float_11;

	// Token: 0x0400039D RID: 925
	[Token(Token = "0x400039D")]
	[FieldOffset(Offset = "0x108")]
	private float float_12;

	// Token: 0x0400039E RID: 926
	[FieldOffset(Offset = "0x10C")]
	[Token(Token = "0x400039E")]
	private bool bool_2;

	// Token: 0x0400039F RID: 927
	[FieldOffset(Offset = "0x110")]
	[Token(Token = "0x400039F")]
	private int int_0;

	// Token: 0x040003A0 RID: 928
	[Token(Token = "0x40003A0")]
	[FieldOffset(Offset = "0x118")]
	private List<DynamicBone.Class28> list_3;

	// Token: 0x040003A1 RID: 929
	[Token(Token = "0x40003A1")]
	[FieldOffset(Offset = "0x120")]
	private float float_13;

	// Token: 0x040003A2 RID: 930
	[FieldOffset(Offset = "0x128")]
	[Token(Token = "0x40003A2")]
	private List<DynamicBoneColliderBase> list_4;

	// Token: 0x040003A3 RID: 931
	[Token(Token = "0x40003A3")]
	[FieldOffset(Offset = "0x130")]
	private bool bool_3;

	// Token: 0x040003A4 RID: 932
	[Token(Token = "0x40003A4")]
	private static List<DynamicBone> list_5 = new List();

	// Token: 0x040003A5 RID: 933
	[Token(Token = "0x40003A5")]
	private static List<DynamicBone> list_6 = new List();

	// Token: 0x040003A6 RID: 934
	[Token(Token = "0x40003A6")]
	private static AutoResetEvent autoResetEvent_0;

	// Token: 0x040003A7 RID: 935
	[Token(Token = "0x40003A7")]
	private static int int_1;

	// Token: 0x040003A8 RID: 936
	[Token(Token = "0x40003A8")]
	private static Semaphore semaphore_0;

	// Token: 0x040003A9 RID: 937
	[Token(Token = "0x40003A9")]
	private static int int_2;

	// Token: 0x040003AA RID: 938
	[Token(Token = "0x40003AA")]
	private static int int_3;

	// Token: 0x040003AB RID: 939
	[Token(Token = "0x40003AB")]
	private static int int_4;

	// Token: 0x020000C0 RID: 192
	[Token(Token = "0x20000C0")]
	public enum GEnum8
	{
		// Token: 0x040003AD RID: 941
		[Token(Token = "0x40003AD")]
		const_0,
		// Token: 0x040003AE RID: 942
		[Token(Token = "0x40003AE")]
		const_1,
		// Token: 0x040003AF RID: 943
		[Token(Token = "0x40003AF")]
		const_2,
		// Token: 0x040003B0 RID: 944
		[Token(Token = "0x40003B0")]
		const_3
	}

	// Token: 0x020000C1 RID: 193
	[Token(Token = "0x20000C1")]
	public enum GEnum9
	{
		// Token: 0x040003B2 RID: 946
		[Token(Token = "0x40003B2")]
		const_0,
		// Token: 0x040003B3 RID: 947
		[Token(Token = "0x40003B3")]
		const_1,
		// Token: 0x040003B4 RID: 948
		[Token(Token = "0x40003B4")]
		const_2,
		// Token: 0x040003B5 RID: 949
		[Token(Token = "0x40003B5")]
		const_3
	}

	// Token: 0x020000C2 RID: 194
	[Token(Token = "0x20000C2")]
	private class Class27
	{
		// Token: 0x06001BC2 RID: 7106 RVA: 0x000020B4 File Offset: 0x000002B4
		[Address(RVA = "0x1070AE4", Offset = "0x1070AE4", VA = "0x1070AE4")]
		[Token(Token = "0x6001BC2")]
		public Class27()
		{
		}

		// Token: 0x040003B6 RID: 950
		[Token(Token = "0x40003B6")]
		[FieldOffset(Offset = "0x10")]
		public Transform transform_0;

		// Token: 0x040003B7 RID: 951
		[Token(Token = "0x40003B7")]
		[FieldOffset(Offset = "0x18")]
		public int int_0;

		// Token: 0x040003B8 RID: 952
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x40003B8")]
		public int int_1;

		// Token: 0x040003B9 RID: 953
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40003B9")]
		public float float_0;

		// Token: 0x040003BA RID: 954
		[Token(Token = "0x40003BA")]
		[FieldOffset(Offset = "0x24")]
		public float float_1;

		// Token: 0x040003BB RID: 955
		[Token(Token = "0x40003BB")]
		[FieldOffset(Offset = "0x28")]
		public float float_2;

		// Token: 0x040003BC RID: 956
		[Token(Token = "0x40003BC")]
		[FieldOffset(Offset = "0x2C")]
		public float float_3;

		// Token: 0x040003BD RID: 957
		[Token(Token = "0x40003BD")]
		[FieldOffset(Offset = "0x30")]
		public float float_4;

		// Token: 0x040003BE RID: 958
		[FieldOffset(Offset = "0x34")]
		[Token(Token = "0x40003BE")]
		public float float_5;

		// Token: 0x040003BF RID: 959
		[Token(Token = "0x40003BF")]
		[FieldOffset(Offset = "0x38")]
		public float float_6;

		// Token: 0x040003C0 RID: 960
		[FieldOffset(Offset = "0x3C")]
		[Token(Token = "0x40003C0")]
		public bool bool_0;

		// Token: 0x040003C1 RID: 961
		[FieldOffset(Offset = "0x3D")]
		[Token(Token = "0x40003C1")]
		public bool bool_1;

		// Token: 0x040003C2 RID: 962
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40003C2")]
		public Vector3 vector3_0;

		// Token: 0x040003C3 RID: 963
		[FieldOffset(Offset = "0x4C")]
		[Token(Token = "0x40003C3")]
		public Vector3 vector3_1;

		// Token: 0x040003C4 RID: 964
		[Token(Token = "0x40003C4")]
		[FieldOffset(Offset = "0x58")]
		public Vector3 vector3_2;

		// Token: 0x040003C5 RID: 965
		[FieldOffset(Offset = "0x64")]
		[Token(Token = "0x40003C5")]
		public Vector3 vector3_3;

		// Token: 0x040003C6 RID: 966
		[Token(Token = "0x40003C6")]
		[FieldOffset(Offset = "0x70")]
		public Quaternion quaternion_0;

		// Token: 0x040003C7 RID: 967
		[Token(Token = "0x40003C7")]
		[FieldOffset(Offset = "0x80")]
		public Vector3 vector3_4;

		// Token: 0x040003C8 RID: 968
		[FieldOffset(Offset = "0x8C")]
		[Token(Token = "0x40003C8")]
		public Vector3 vector3_5;

		// Token: 0x040003C9 RID: 969
		[Token(Token = "0x40003C9")]
		[FieldOffset(Offset = "0x98")]
		public Matrix4x4 matrix4x4_0;
	}

	// Token: 0x020000C3 RID: 195
	[Token(Token = "0x20000C3")]
	private class Class28
	{
		// Token: 0x06001BC3 RID: 7107 RVA: 0x00035B94 File Offset: 0x00033D94
		[Address(RVA = "0x1070AEC", Offset = "0x1070AEC", VA = "0x1070AEC")]
		[Token(Token = "0x6001BC3")]
		public Class28()
		{
			List<DynamicBone.Class27> list = new List();
			this.list_0 = list;
			base..ctor();
		}

		// Token: 0x040003CA RID: 970
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40003CA")]
		public Transform transform_0;

		// Token: 0x040003CB RID: 971
		[Token(Token = "0x40003CB")]
		[FieldOffset(Offset = "0x18")]
		public Vector3 vector3_0;

		// Token: 0x040003CC RID: 972
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x40003CC")]
		public Matrix4x4 matrix4x4_0;

		// Token: 0x040003CD RID: 973
		[Token(Token = "0x40003CD")]
		[FieldOffset(Offset = "0x64")]
		public float float_0;

		// Token: 0x040003CE RID: 974
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x40003CE")]
		public List<DynamicBone.Class27> list_0;

		// Token: 0x040003CF RID: 975
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x40003CF")]
		public Vector3 vector3_1;
	}

	// Token: 0x020000C4 RID: 196
	[CompilerGenerated]
	[Token(Token = "0x20000C4")]
	private sealed class Class29
	{
		// Token: 0x06001BC4 RID: 7108 RVA: 0x000020B4 File Offset: 0x000002B4
		[Address(RVA = "0x1070A58", Offset = "0x1070A58", VA = "0x1070A58")]
		[Token(Token = "0x6001BC4")]
		public Class29()
		{
		}

		// Token: 0x06001BC5 RID: 7109 RVA: 0x00035BB4 File Offset: 0x00033DB4
		[Address(RVA = "0x1070A60", Offset = "0x1070A60", VA = "0x1070A60")]
		[Token(Token = "0x6001BC5")]
		internal bool method_0(DynamicBone.Class28 x)
		{
			Transform transform_ = x.transform_0;
			Transform y = this.root;
			return transform_ == y;
		}

		// Token: 0x040003D0 RID: 976
		[Token(Token = "0x40003D0")]
		[FieldOffset(Offset = "0x10")]
		public Transform root;
	}
}
