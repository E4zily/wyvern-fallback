﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200007B RID: 123
[Token(Token = "0x200007B")]
public class Level1MapSystem : MonoBehaviour
{
	// Token: 0x06001161 RID: 4449 RVA: 0x00024A24 File Offset: 0x00022C24
	[Token(Token = "0x6001161")]
	[Address(RVA = "0x2D8F01C", Offset = "0x2D8F01C", VA = "0x2D8F01C")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001162 RID: 4450 RVA: 0x00024A54 File Offset: 0x00022C54
	[Token(Token = "0x6001162")]
	[Address(RVA = "0x2D8F0B4", Offset = "0x2D8F0B4", VA = "0x2D8F0B4")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("EnableCosmetic");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001163 RID: 4451 RVA: 0x00024A84 File Offset: 0x00022C84
	[Token(Token = "0x6001163")]
	[Address(RVA = "0x2D8F14C", Offset = "0x2D8F14C", VA = "0x2D8F14C")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("n0");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001164 RID: 4452 RVA: 0x00024AB4 File Offset: 0x00022CB4
	[Address(RVA = "0x2D8F1E4", Offset = "0x2D8F1E4", VA = "0x2D8F1E4")]
	[Token(Token = "0x6001164")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.CompareTag(".Please press the button if you would like to play alone");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001165 RID: 4453 RVA: 0x00024AE4 File Offset: 0x00022CE4
	[Address(RVA = "0x2D8F27C", Offset = "0x2D8F27C", VA = "0x2D8F27C")]
	[Token(Token = "0x6001165")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("CapuchinRemade");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001166 RID: 4454 RVA: 0x00024A24 File Offset: 0x00022C24
	[Token(Token = "0x6001166")]
	[Address(RVA = "0x2D8F314", Offset = "0x2D8F314", VA = "0x2D8F314")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001167 RID: 4455 RVA: 0x00024B14 File Offset: 0x00022D14
	[Token(Token = "0x6001167")]
	[Address(RVA = "0x2D8F3AC", Offset = "0x2D8F3AC", VA = "0x2D8F3AC")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001168 RID: 4456 RVA: 0x00024B44 File Offset: 0x00022D44
	[Address(RVA = "0x2D8F444", Offset = "0x2D8F444", VA = "0x2D8F444")]
	[Token(Token = "0x6001168")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("monke is not my monke");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001169 RID: 4457 RVA: 0x00024B74 File Offset: 0x00022D74
	[Token(Token = "0x6001169")]
	[Address(RVA = "0x2D8F4DC", Offset = "0x2D8F4DC", VA = "0x2D8F4DC")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600116A RID: 4458 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x600116A")]
	[Address(RVA = "0x2D8F574", Offset = "0x2D8F574", VA = "0x2D8F574")]
	public Level1MapSystem()
	{
	}

	// Token: 0x0600116B RID: 4459 RVA: 0x00024BA4 File Offset: 0x00022DA4
	[Token(Token = "0x600116B")]
	[Address(RVA = "0x2D8F57C", Offset = "0x2D8F57C", VA = "0x2D8F57C")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Players: ");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600116C RID: 4460 RVA: 0x00024BD4 File Offset: 0x00022DD4
	[Token(Token = "0x600116C")]
	[Address(RVA = "0x2D8F614", Offset = "0x2D8F614", VA = "0x2D8F614")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("BN");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600116D RID: 4461 RVA: 0x00024C04 File Offset: 0x00022E04
	[Address(RVA = "0x2D8F6AC", Offset = "0x2D8F6AC", VA = "0x2D8F6AC")]
	[Token(Token = "0x600116D")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("User has been reported for: ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600116E RID: 4462 RVA: 0x00024C34 File Offset: 0x00022E34
	[Token(Token = "0x600116E")]
	[Address(RVA = "0x2D8F744", Offset = "0x2D8F744", VA = "0x2D8F744")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Cannot access index {0}. Buffer is empty");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0400027D RID: 637
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400027D")]
	public GameObject gameObject_0;
}
