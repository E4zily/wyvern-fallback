﻿using System;
using System.Runtime.InteropServices;
using Cpp2IlInjected;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;

// Token: 0x02000040 RID: 64
[Token(Token = "0x2000040")]
public class CreateRoom : MonoBehaviourPunCallbacks
{
	// Token: 0x0600082A RID: 2090 RVA: 0x00002261 File Offset: 0x00000461
	[Token(Token = "0x600082A")]
	[Address(RVA = "0x2A6D4AC", Offset = "0x2A6D4AC", VA = "0x2A6D4AC")]
	public void Start()
	{
		CreateRoom.Instance = this;
		this.CheckPlayerPrefs();
	}

	// Token: 0x0600082B RID: 2091 RVA: 0x00012858 File Offset: 0x00010A58
	[Token(Token = "0x600082B")]
	[Address(RVA = "0x2A6D974", Offset = "0x2A6D974", VA = "0x2A6D974")]
	public void CreateRoomLol()
	{
		bool isConnected = PhotonNetwork.IsConnected;
		if (this.roomName.m_CachedPtr != 0)
		{
		}
		bool isConnected2 = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600082C RID: 2092 RVA: 0x00012880 File Offset: 0x00010A80
	[Token(Token = "0x600082C")]
	[Address(RVA = "0x2A6DE84", Offset = "0x2A6DE84", VA = "0x2A6DE84")]
	public void LeaveRoomLol()
	{
		PhotonNetwork.LeaveRoom(true);
	}

	// Token: 0x0600082D RID: 2093 RVA: 0x00012894 File Offset: 0x00010A94
	[Token(Token = "0x600082D")]
	[Address(RVA = "0x2A6DB08", Offset = "0x2A6DB08", VA = "0x2A6DB08")]
	public void CreateSillyRoom(string roomName, [Optional] string queue1)
	{
		RoomOptions roomOptions = new RoomOptions();
		byte b = this.maxPlayers;
		long <PublishUserId>k__BackingField = 1L;
		roomOptions.isVisible = (257 != 0);
		roomOptions.<PublishUserId>k__BackingField = (<PublishUserId>k__BackingField != 0L);
		roomOptions.MaxPlayers = b;
		Hashtable customRoomProperties = new Hashtable();
		new Hashtable();
		new Hashtable();
		if (queue1 != null)
		{
			return;
		}
		roomOptions.CustomRoomProperties = customRoomProperties;
	}

	// Token: 0x0600082E RID: 2094 RVA: 0x000128E8 File Offset: 0x00010AE8
	[Address(RVA = "0x2A6D508", Offset = "0x2A6D508", VA = "0x2A6D508")]
	[Token(Token = "0x600082E")]
	public void CheckPlayerPrefs()
	{
		PlayerPrefs.GetString("Queue") == "";
		PlayerPrefs.SetString("Queue", "casual");
		Color red = Color.red;
		Color white = Color.white;
		Color white2 = Color.white;
		PlayerPrefs.GetString("Queue") == "casual";
		this.queue = "casual";
		Color red2 = Color.red;
		Color white3 = Color.white;
		Color white4 = Color.white;
		PlayerPrefs.GetString("Queue") == "lava";
		Color red3 = Color.red;
		Color white5 = Color.white;
		Color white6 = Color.white;
		PlayerPrefs.GetString("Queue") == "cheese";
		this.queue = "cheese";
		Color red4 = Color.red;
		Color white7 = Color.white;
		Color white8 = Color.white;
	}

	// Token: 0x0600082F RID: 2095 RVA: 0x000129B8 File Offset: 0x00010BB8
	[Address(RVA = "0x2A6DEE4", Offset = "0x2A6DEE4", VA = "0x2A6DEE4", Slot = "35")]
	[Token(Token = "0x600082F")]
	public override void OnCreatedRoom()
	{
		string message;
		Debug.Log(message);
	}

	// Token: 0x06000830 RID: 2096 RVA: 0x000129CC File Offset: 0x00010BCC
	[Address(RVA = "0x2A6DFAC", Offset = "0x2A6DFAC", VA = "0x2A6DFAC", Slot = "33")]
	[Token(Token = "0x6000830")]
	public override void OnCreateRoomFailed(short returnCode, string message)
	{
		Debug.Log("Room Creation Failed: " + message);
	}

	// Token: 0x06000831 RID: 2097 RVA: 0x0000208D File Offset: 0x0000028D
	[Token(Token = "0x6000831")]
	[Address(RVA = "0x2A6E0DC", Offset = "0x2A6E0DC", VA = "0x2A6E0DC")]
	public CreateRoom()
	{
	}

	// Token: 0x0400011D RID: 285
	[Token(Token = "0x400011D")]
	public static CreateRoom Instance;

	// Token: 0x0400011E RID: 286
	[Cpp2IlInjected.FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400011E")]
	[SerializeField]
	public TextMeshPro roomName;

	// Token: 0x0400011F RID: 287
	[Token(Token = "0x400011F")]
	[Cpp2IlInjected.FieldOffset(Offset = "0x28")]
	public byte maxPlayers;

	// Token: 0x04000120 RID: 288
	[Cpp2IlInjected.FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000120")]
	public LobbyStats LobbyStats;

	// Token: 0x04000121 RID: 289
	[Cpp2IlInjected.FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000121")]
	[Header("QUEUE STRINGS NEED TO BE 'casual', 'lava', or 'cheese'")]
	public string queue;

	// Token: 0x04000122 RID: 290
	[Token(Token = "0x4000122")]
	[Cpp2IlInjected.FieldOffset(Offset = "0x40")]
	public MeshRenderer[] queueSelects;
}
