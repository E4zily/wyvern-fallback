﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000022 RID: 34
[Token(Token = "0x2000022")]
public class PhysicsHand : MonoBehaviour
{
	// Token: 0x06000475 RID: 1141 RVA: 0x0000C8FC File Offset: 0x0000AAFC
	[Token(Token = "0x6000475")]
	[Address(RVA = "0x3054568", Offset = "0x3054568", VA = "0x3054568")]
	public IEnumerator method_0()
	{
		PhysicsHand.Class8 @class = new PhysicsHand.Class8((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000476 RID: 1142 RVA: 0x0000C924 File Offset: 0x0000AB24
	[Token(Token = "0x6000476")]
	[Address(RVA = "0x30545E0", Offset = "0x30545E0", VA = "0x30545E0")]
	private void method_1()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.target.position;
		this.method_38();
		if (this.bool_1)
		{
			Vector3 velocity = this.playerRigidbody.velocity;
			return;
		}
	}

	// Token: 0x06000477 RID: 1143 RVA: 0x0000C968 File Offset: 0x0000AB68
	[Address(RVA = "0x30547E8", Offset = "0x30547E8", VA = "0x30547E8")]
	[Token(Token = "0x6000477")]
	private void method_2()
	{
		if (!this.bool_1)
		{
			Transform transform = this.rigidbody_0.transform;
			Vector3 position = this.target.position;
			return;
		}
		this.method_23();
		this.method_21();
		if (this.bool_2)
		{
			this.method_39();
			return;
		}
	}

	// Token: 0x06000478 RID: 1144 RVA: 0x0000C9B4 File Offset: 0x0000ABB4
	[Token(Token = "0x6000478")]
	[Address(RVA = "0x3054D48", Offset = "0x3054D48", VA = "0x3054D48")]
	private void OnCollisionEnter(Collision collision_0)
	{
		GameObject gameObject = collision_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06000479 RID: 1145 RVA: 0x0000C9D4 File Offset: 0x0000ABD4
	[Address(RVA = "0x3055118", Offset = "0x3055118", VA = "0x3055118")]
	[Token(Token = "0x6000479")]
	private void method_3()
	{
		if (!this.bool_1)
		{
			Transform transform = this.rigidbody_0.transform;
			Vector3 position = this.target.position;
			return;
		}
		this.method_36();
		this.method_21();
		if (this.bool_2)
		{
			this.method_1();
			return;
		}
	}

	// Token: 0x0600047A RID: 1146 RVA: 0x0000C8FC File Offset: 0x0000AAFC
	[Address(RVA = "0x3055368", Offset = "0x3055368", VA = "0x3055368")]
	[Token(Token = "0x600047A")]
	public IEnumerator method_4()
	{
		PhysicsHand.Class8 @class = new PhysicsHand.Class8((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600047B RID: 1147 RVA: 0x0000CA20 File Offset: 0x0000AC20
	[Token(Token = "0x600047B")]
	[Address(RVA = "0x30553E0", Offset = "0x30553E0", VA = "0x30553E0")]
	private void method_5()
	{
		if (!this.bool_1)
		{
			Transform transform = this.rigidbody_0.transform;
			Vector3 position = this.target.position;
			return;
		}
		this.method_6();
		this.method_21();
		if (this.bool_2)
		{
			this.method_1();
			return;
		}
	}

	// Token: 0x0600047C RID: 1148 RVA: 0x0000CA6C File Offset: 0x0000AC6C
	[Token(Token = "0x600047C")]
	[Address(RVA = "0x3055470", Offset = "0x3055470", VA = "0x3055470")]
	private void method_6()
	{
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Vector3 position = this.target.position;
		Vector3 position2 = base.transform.position;
		Vector3 velocity = this.playerRigidbody.velocity;
		Vector3 velocity2 = this.rigidbody_0.velocity;
	}

	// Token: 0x0600047D RID: 1149 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3054F58", Offset = "0x3054F58", VA = "0x3054F58")]
	[Token(Token = "0x600047D")]
	private void method_7()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600047E RID: 1150 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600047E")]
	[Address(RVA = "0x3055630", Offset = "0x3055630", VA = "0x3055630")]
	private void method_8(Collision collision_0)
	{
	}

	// Token: 0x0600047F RID: 1151 RVA: 0x0000CAC4 File Offset: 0x0000ACC4
	[Address(RVA = "0x3055638", Offset = "0x3055638", VA = "0x3055638")]
	[Token(Token = "0x600047F")]
	private float method_9()
	{
		Vector3 localPosition = this.target.localPosition;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x06000480 RID: 1152 RVA: 0x0000CAC4 File Offset: 0x0000ACC4
	[Address(RVA = "0x3055724", Offset = "0x3055724", VA = "0x3055724")]
	[Token(Token = "0x6000480")]
	private float method_10()
	{
		Vector3 localPosition = this.target.localPosition;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x06000481 RID: 1153 RVA: 0x0000CAF4 File Offset: 0x0000ACF4
	[Token(Token = "0x6000481")]
	[Address(RVA = "0x3055814", Offset = "0x3055814", VA = "0x3055814")]
	public IEnumerator method_11()
	{
		new PhysicsHand.Class8((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x06000482 RID: 1154 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x305588C", Offset = "0x305588C", VA = "0x305588C")]
	[Token(Token = "0x6000482")]
	private void method_12()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000483 RID: 1155 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3055A54", Offset = "0x3055A54", VA = "0x3055A54")]
	[Token(Token = "0x6000483")]
	private void method_13()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000484 RID: 1156 RVA: 0x0000CB18 File Offset: 0x0000AD18
	[Address(RVA = "0x3055C1C", Offset = "0x3055C1C", VA = "0x3055C1C")]
	[Token(Token = "0x6000484")]
	private void method_14(Collision collision_0)
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x06000485 RID: 1157 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000485")]
	[Address(RVA = "0x3055C28", Offset = "0x3055C28", VA = "0x3055C28")]
	private void method_15()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000486 RID: 1158 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3055DF0", Offset = "0x3055DF0", VA = "0x3055DF0")]
	[Token(Token = "0x6000486")]
	private void method_16()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000487 RID: 1159 RVA: 0x0000CAC4 File Offset: 0x0000ACC4
	[Token(Token = "0x6000487")]
	[Address(RVA = "0x3055FB8", Offset = "0x3055FB8", VA = "0x3055FB8")]
	private float method_17()
	{
		Vector3 localPosition = this.target.localPosition;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x06000488 RID: 1160 RVA: 0x0000CB30 File Offset: 0x0000AD30
	[Token(Token = "0x6000488")]
	[Address(RVA = "0x30560A8", Offset = "0x30560A8", VA = "0x30560A8")]
	private void FixedUpdate()
	{
		if (!this.bool_1)
		{
			Transform transform = this.rigidbody_0.transform;
			Vector3 position = this.target.position;
			return;
		}
		this.method_23();
		this.method_21();
		if (this.bool_2)
		{
			this.method_19();
			return;
		}
	}

	// Token: 0x06000489 RID: 1161 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000489")]
	[Address(RVA = "0x3056250", Offset = "0x3056250", VA = "0x3056250")]
	private void OnCollisionExit(Collision collision_0)
	{
	}

	// Token: 0x0600048A RID: 1162 RVA: 0x00002134 File Offset: 0x00000334
	[Address(RVA = "0x3056258", Offset = "0x3056258", VA = "0x3056258")]
	[Token(Token = "0x600048A")]
	public PhysicsHand()
	{
	}

	// Token: 0x0600048B RID: 1163 RVA: 0x0000CAC4 File Offset: 0x0000ACC4
	[Address(RVA = "0x3056280", Offset = "0x3056280", VA = "0x3056280")]
	[Token(Token = "0x600048B")]
	private float method_18()
	{
		Vector3 localPosition = this.target.localPosition;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x0600048C RID: 1164 RVA: 0x0000CB7C File Offset: 0x0000AD7C
	[Address(RVA = "0x3056138", Offset = "0x3056138", VA = "0x3056138")]
	[Token(Token = "0x600048C")]
	private void method_19()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.target.position;
		this.method_20();
		if (this.bool_1)
		{
			Vector3 velocity = this.playerRigidbody.velocity;
			return;
		}
	}

	// Token: 0x0600048D RID: 1165 RVA: 0x0000CAC4 File Offset: 0x0000ACC4
	[Address(RVA = "0x3056370", Offset = "0x3056370", VA = "0x3056370")]
	[Token(Token = "0x600048D")]
	private float method_20()
	{
		Vector3 localPosition = this.target.localPosition;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x0600048E RID: 1166 RVA: 0x0000CBC0 File Offset: 0x0000ADC0
	[Token(Token = "0x600048E")]
	[Address(RVA = "0x3054A14", Offset = "0x3054A14", VA = "0x3054A14")]
	private void method_21()
	{
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Quaternion rotation = this.target.rotation;
		Quaternion rotation2 = base.transform.rotation;
		Vector3 angularVelocity = this.rigidbody_0.angularVelocity;
	}

	// Token: 0x0600048F RID: 1167 RVA: 0x0000CC0C File Offset: 0x0000AE0C
	[Token(Token = "0x600048F")]
	[Address(RVA = "0x3056440", Offset = "0x3056440", VA = "0x3056440")]
	private void method_22(Collision collision_0)
	{
		GameObject gameObject = collision_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x06000490 RID: 1168 RVA: 0x0000CA6C File Offset: 0x0000AC6C
	[Token(Token = "0x6000490")]
	[Address(RVA = "0x3054878", Offset = "0x3054878", VA = "0x3054878")]
	private void method_23()
	{
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Vector3 position = this.target.position;
		Vector3 position2 = base.transform.position;
		Vector3 velocity = this.playerRigidbody.velocity;
		Vector3 velocity2 = this.rigidbody_0.velocity;
	}

	// Token: 0x06000491 RID: 1169 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000491")]
	[Address(RVA = "0x305665C", Offset = "0x305665C", VA = "0x305665C")]
	private void method_24()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000492 RID: 1170 RVA: 0x0000CC2C File Offset: 0x0000AE2C
	[Address(RVA = "0x3056824", Offset = "0x3056824", VA = "0x3056824")]
	[Token(Token = "0x6000492")]
	private void Start()
	{
		Transform transform = base.transform;
		Vector3 position = this.target.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.target.rotation;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 position2 = base.transform.position;
	}

	// Token: 0x06000493 RID: 1171 RVA: 0x0000CC7C File Offset: 0x0000AE7C
	[Token(Token = "0x6000493")]
	[Address(RVA = "0x3056928", Offset = "0x3056928", VA = "0x3056928")]
	private void method_25()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.target.position;
		this.method_9();
		if (this.bool_1)
		{
			Vector3 velocity = this.playerRigidbody.velocity;
			return;
		}
	}

	// Token: 0x06000494 RID: 1172 RVA: 0x0000CAC4 File Offset: 0x0000ACC4
	[Address(RVA = "0x3056A40", Offset = "0x3056A40", VA = "0x3056A40")]
	[Token(Token = "0x6000494")]
	private float method_26()
	{
		Vector3 localPosition = this.target.localPosition;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x06000495 RID: 1173 RVA: 0x0000CC2C File Offset: 0x0000AE2C
	[Token(Token = "0x6000495")]
	[Address(RVA = "0x3056B30", Offset = "0x3056B30", VA = "0x3056B30")]
	private void method_27()
	{
		Transform transform = base.transform;
		Vector3 position = this.target.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.target.rotation;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 position2 = base.transform.position;
	}

	// Token: 0x06000496 RID: 1174 RVA: 0x0000CB18 File Offset: 0x0000AD18
	[Token(Token = "0x6000496")]
	[Address(RVA = "0x3056C34", Offset = "0x3056C34", VA = "0x3056C34")]
	private void method_28(Collision collision_0)
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x06000497 RID: 1175 RVA: 0x0000C8FC File Offset: 0x0000AAFC
	[Token(Token = "0x6000497")]
	[Address(RVA = "0x3056C40", Offset = "0x3056C40", VA = "0x3056C40")]
	public IEnumerator method_29()
	{
		PhysicsHand.Class8 @class = new PhysicsHand.Class8((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000498 RID: 1176 RVA: 0x0000C924 File Offset: 0x0000AB24
	[Address(RVA = "0x3056CB8", Offset = "0x3056CB8", VA = "0x3056CB8")]
	[Token(Token = "0x6000498")]
	private void method_30()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.target.position;
		this.method_38();
		if (this.bool_1)
		{
			Vector3 velocity = this.playerRigidbody.velocity;
			return;
		}
	}

	// Token: 0x06000499 RID: 1177 RVA: 0x0000CA6C File Offset: 0x0000AC6C
	[Token(Token = "0x6000499")]
	[Address(RVA = "0x3056DD0", Offset = "0x3056DD0", VA = "0x3056DD0")]
	private void method_31()
	{
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Vector3 position = this.target.position;
		Vector3 position2 = base.transform.position;
		Vector3 velocity = this.playerRigidbody.velocity;
		Vector3 velocity2 = this.rigidbody_0.velocity;
	}

	// Token: 0x0600049A RID: 1178 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3056F90", Offset = "0x3056F90", VA = "0x3056F90")]
	[Token(Token = "0x600049A")]
	private void method_32()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600049B RID: 1179 RVA: 0x0000CC0C File Offset: 0x0000AE0C
	[Address(RVA = "0x3057158", Offset = "0x3057158", VA = "0x3057158")]
	[Token(Token = "0x600049B")]
	private void method_33(Collision collision_0)
	{
		GameObject gameObject = collision_0.gameObject;
		this.audioSource_0.Play();
	}

	// Token: 0x0600049C RID: 1180 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600049C")]
	[Address(RVA = "0x3057374", Offset = "0x3057374", VA = "0x3057374")]
	private void method_34(Collision collision_0)
	{
	}

	// Token: 0x0600049D RID: 1181 RVA: 0x0000C8FC File Offset: 0x0000AAFC
	[Address(RVA = "0x305737C", Offset = "0x305737C", VA = "0x305737C")]
	[Token(Token = "0x600049D")]
	public IEnumerator method_35()
	{
		PhysicsHand.Class8 @class = new PhysicsHand.Class8((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600049E RID: 1182 RVA: 0x0000CCC0 File Offset: 0x0000AEC0
	[Token(Token = "0x600049E")]
	[Address(RVA = "0x30551A8", Offset = "0x30551A8", VA = "0x30551A8")]
	private void method_36()
	{
		float fixedDeltaTime = Time.fixedDeltaTime;
		float fixedDeltaTime2 = Time.fixedDeltaTime;
		float fixedDeltaTime3 = Time.fixedDeltaTime;
		float fixedDeltaTime4 = Time.fixedDeltaTime;
		Vector3 position = this.target.position;
		Transform transform;
		Vector3 position2 = transform.position;
		Vector3 velocity = this.playerRigidbody.velocity;
		Vector3 velocity2 = this.rigidbody_0.velocity;
	}

	// Token: 0x0600049F RID: 1183 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x30573F4", Offset = "0x30573F4", VA = "0x30573F4")]
	[Token(Token = "0x600049F")]
	private void method_37()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060004A0 RID: 1184 RVA: 0x0000CAC4 File Offset: 0x0000ACC4
	[Token(Token = "0x60004A0")]
	[Address(RVA = "0x30546F8", Offset = "0x30546F8", VA = "0x30546F8")]
	private float method_38()
	{
		Vector3 localPosition = this.target.localPosition;
		float fixedDeltaTime = Time.fixedDeltaTime;
		Vector3 position = base.transform.position;
		throw new NullReferenceException();
	}

	// Token: 0x060004A1 RID: 1185 RVA: 0x0000C924 File Offset: 0x0000AB24
	[Token(Token = "0x60004A1")]
	[Address(RVA = "0x3054C30", Offset = "0x3054C30", VA = "0x3054C30")]
	private void method_39()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.target.position;
		this.method_38();
		if (this.bool_1)
		{
			Vector3 velocity = this.playerRigidbody.velocity;
			return;
		}
	}

	// Token: 0x060004A2 RID: 1186 RVA: 0x0000C8FC File Offset: 0x0000AAFC
	[Address(RVA = "0x30575BC", Offset = "0x30575BC", VA = "0x30575BC")]
	[Token(Token = "0x60004A2")]
	public IEnumerator method_40()
	{
		PhysicsHand.Class8 @class = new PhysicsHand.Class8((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060004A3 RID: 1187 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3057634", Offset = "0x3057634", VA = "0x3057634")]
	[Token(Token = "0x60004A3")]
	private void method_41()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0400008D RID: 141
	[SerializeField]
	[Header("PID")]
	[Token(Token = "0x400008D")]
	[FieldOffset(Offset = "0x18")]
	private float frequency;

	// Token: 0x0400008E RID: 142
	[Token(Token = "0x400008E")]
	[FieldOffset(Offset = "0x1C")]
	[SerializeField]
	private float damping;

	// Token: 0x0400008F RID: 143
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400008F")]
	[SerializeField]
	private float rotfrequency;

	// Token: 0x04000090 RID: 144
	[SerializeField]
	[Token(Token = "0x4000090")]
	[FieldOffset(Offset = "0x24")]
	private float rotDamping;

	// Token: 0x04000091 RID: 145
	[Token(Token = "0x4000091")]
	[FieldOffset(Offset = "0x28")]
	[SerializeField]
	private Rigidbody playerRigidbody;

	// Token: 0x04000092 RID: 146
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000092")]
	[SerializeField]
	private Transform target;

	// Token: 0x04000093 RID: 147
	[SerializeField]
	[Token(Token = "0x4000093")]
	[FieldOffset(Offset = "0x38")]
	private Rigidbody Hand;

	// Token: 0x04000094 RID: 148
	[SerializeField]
	[Token(Token = "0x4000094")]
	[FieldOffset(Offset = "0x40")]
	private float hitAmount;

	// Token: 0x04000095 RID: 149
	[SerializeField]
	[Header("Springs")]
	[Space]
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000095")]
	private float climbForce;

	// Token: 0x04000096 RID: 150
	[Token(Token = "0x4000096")]
	[SerializeField]
	[FieldOffset(Offset = "0x48")]
	private float climbDrag;

	// Token: 0x04000097 RID: 151
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000097")]
	public AudioClip[] audioClip_0;

	// Token: 0x04000098 RID: 152
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000098")]
	public AudioClip[] audioClip_1;

	// Token: 0x04000099 RID: 153
	[Token(Token = "0x4000099")]
	[FieldOffset(Offset = "0x60")]
	public AudioClip[] audioClip_2;

	// Token: 0x0400009A RID: 154
	[Token(Token = "0x400009A")]
	[FieldOffset(Offset = "0x68")]
	public AudioClip[] audioClip_3;

	// Token: 0x0400009B RID: 155
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x400009B")]
	public AudioSource audioSource_0;

	// Token: 0x0400009C RID: 156
	[Token(Token = "0x400009C")]
	[FieldOffset(Offset = "0x78")]
	public AudioClip[] audioClip_4;

	// Token: 0x0400009D RID: 157
	[Token(Token = "0x400009D")]
	[FieldOffset(Offset = "0x80")]
	public AudioClip[] audioClip_5;

	// Token: 0x0400009E RID: 158
	[Token(Token = "0x400009E")]
	[FieldOffset(Offset = "0x88")]
	public AudioClip[] audioClip_6;

	// Token: 0x0400009F RID: 159
	[Token(Token = "0x400009F")]
	[FieldOffset(Offset = "0x90")]
	public AudioClip[] audioClip_7;

	// Token: 0x040000A0 RID: 160
	[Token(Token = "0x40000A0")]
	[FieldOffset(Offset = "0x98")]
	public AudioClip[] audioClip_8;

	// Token: 0x040000A1 RID: 161
	[FieldOffset(Offset = "0xA0")]
	[Token(Token = "0x40000A1")]
	public AudioClip[] audioClip_9;

	// Token: 0x040000A2 RID: 162
	[Token(Token = "0x40000A2")]
	[FieldOffset(Offset = "0xA8")]
	private bool bool_0 = 257 != 0;

	// Token: 0x040000A3 RID: 163
	[FieldOffset(Offset = "0xA9")]
	[Token(Token = "0x40000A3")]
	private bool bool_1;

	// Token: 0x040000A4 RID: 164
	[Token(Token = "0x40000A4")]
	[FieldOffset(Offset = "0xAC")]
	private Vector3 vector3_0;

	// Token: 0x040000A5 RID: 165
	[Token(Token = "0x40000A5")]
	[FieldOffset(Offset = "0xB8")]
	private Rigidbody rigidbody_0;

	// Token: 0x040000A6 RID: 166
	[FieldOffset(Offset = "0xC0")]
	[Token(Token = "0x40000A6")]
	private bool bool_2;

	// Token: 0x040000A7 RID: 167
	[Token(Token = "0x40000A7")]
	[FieldOffset(Offset = "0xC1")]
	public bool bool_3;
}
