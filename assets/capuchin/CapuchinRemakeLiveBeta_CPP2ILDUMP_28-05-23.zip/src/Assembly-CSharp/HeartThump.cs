﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000CE RID: 206
[Token(Token = "0x20000CE")]
public class HeartThump : MonoBehaviour
{
	// Token: 0x06001D80 RID: 7552 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3638FB4", Offset = "0x3638FB4", VA = "0x3638FB4")]
	[Token(Token = "0x6001D80")]
	public IEnumerator method_0()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D81 RID: 7553 RVA: 0x00038218 File Offset: 0x00036418
	[Address(RVA = "0x363902C", Offset = "0x363902C", VA = "0x363902C")]
	[Token(Token = "0x6001D81")]
	public IEnumerator method_1()
	{
		new HeartThump.Class30((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x06001D82 RID: 7554 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x36390A4", Offset = "0x36390A4", VA = "0x36390A4")]
	[Token(Token = "0x6001D82")]
	public void method_2()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001D83 RID: 7555 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3639130", Offset = "0x3639130", VA = "0x3639130")]
	[Token(Token = "0x6001D83")]
	public IEnumerator method_3()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D84 RID: 7556 RVA: 0x00038264 File Offset: 0x00036464
	[Address(RVA = "0x36391A8", Offset = "0x36391A8", VA = "0x36391A8")]
	[Token(Token = "0x6001D84")]
	public void method_4()
	{
		base.StartCoroutine("BLUTARG");
	}

	// Token: 0x06001D85 RID: 7557 RVA: 0x00038280 File Offset: 0x00036480
	[Address(RVA = "0x36391F8", Offset = "0x36391F8", VA = "0x36391F8")]
	[Token(Token = "0x6001D85")]
	public void method_5()
	{
		base.StartCoroutine("Horizontal");
	}

	// Token: 0x06001D86 RID: 7558 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x3639248", Offset = "0x3639248", VA = "0x3639248")]
	[Token(Token = "0x6001D86")]
	public void method_6()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001D87 RID: 7559 RVA: 0x0003829C File Offset: 0x0003649C
	[Address(RVA = "0x36392D4", Offset = "0x36392D4", VA = "0x36392D4")]
	[Token(Token = "0x6001D87")]
	public void method_7()
	{
		base.StartCoroutine("Count of rooms ");
	}

	// Token: 0x06001D88 RID: 7560 RVA: 0x00009500 File Offset: 0x00007700
	[Address(RVA = "0x3639324", Offset = "0x3639324", VA = "0x3639324")]
	[Token(Token = "0x6001D88")]
	public IEnumerator method_8()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06001D89 RID: 7561 RVA: 0x000382B8 File Offset: 0x000364B8
	[Address(RVA = "0x363939C", Offset = "0x363939C", VA = "0x363939C")]
	[Token(Token = "0x6001D89")]
	public void method_9()
	{
		base.StartCoroutine("username");
	}

	// Token: 0x06001D8A RID: 7562 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x36393EC", Offset = "0x36393EC", VA = "0x36393EC")]
	[Token(Token = "0x6001D8A")]
	public IEnumerator method_10()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D8B RID: 7563 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3639464", Offset = "0x3639464", VA = "0x3639464")]
	[Token(Token = "0x6001D8B")]
	public IEnumerator method_11()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D8C RID: 7564 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x36394DC", Offset = "0x36394DC", VA = "0x36394DC")]
	[Token(Token = "0x6001D8C")]
	public void method_12()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001D8D RID: 7565 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x3639568", Offset = "0x3639568", VA = "0x3639568")]
	[Token(Token = "0x6001D8D")]
	public void method_13()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001D8E RID: 7566 RVA: 0x000382D4 File Offset: 0x000364D4
	[Address(RVA = "0x36395F4", Offset = "0x36395F4", VA = "0x36395F4")]
	[Token(Token = "0x6001D8E")]
	public void method_14()
	{
		base.StartCoroutine("cosmos");
	}

	// Token: 0x06001D8F RID: 7567 RVA: 0x000382F0 File Offset: 0x000364F0
	[Address(RVA = "0x3639644", Offset = "0x3639644", VA = "0x3639644")]
	[Token(Token = "0x6001D8F")]
	public void method_15()
	{
		base.StartCoroutine("vive");
	}

	// Token: 0x06001D90 RID: 7568 RVA: 0x0003830C File Offset: 0x0003650C
	[Address(RVA = "0x3639694", Offset = "0x3639694", VA = "0x3639694")]
	[Token(Token = "0x6001D90")]
	public void method_16()
	{
		base.StartCoroutine("M/d/yyyy");
	}

	// Token: 0x06001D91 RID: 7569 RVA: 0x00038328 File Offset: 0x00036528
	[Address(RVA = "0x36396E4", Offset = "0x36396E4", VA = "0x36396E4")]
	[Token(Token = "0x6001D91")]
	public void method_17()
	{
		base.StartCoroutine("Starting to bake textures on frame ");
	}

	// Token: 0x06001D92 RID: 7570 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x3639734", Offset = "0x3639734", VA = "0x3639734")]
	[Token(Token = "0x6001D92")]
	public void method_18()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001D93 RID: 7571 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x36397C0", Offset = "0x36397C0", VA = "0x36397C0")]
	[Token(Token = "0x6001D93")]
	public void method_19()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001D94 RID: 7572 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363984C", Offset = "0x363984C", VA = "0x363984C")]
	[Token(Token = "0x6001D94")]
	public void method_20()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001D95 RID: 7573 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x36398D8", Offset = "0x36398D8", VA = "0x36398D8")]
	[Token(Token = "0x6001D95")]
	public void method_21()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001D96 RID: 7574 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3639964", Offset = "0x3639964", VA = "0x3639964")]
	[Token(Token = "0x6001D96")]
	public IEnumerator method_22()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D97 RID: 7575 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x36399DC", Offset = "0x36399DC", VA = "0x36399DC")]
	[Token(Token = "0x6001D97")]
	public IEnumerator method_23()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D98 RID: 7576 RVA: 0x00038344 File Offset: 0x00036544
	[Address(RVA = "0x3639A54", Offset = "0x3639A54", VA = "0x3639A54")]
	[Token(Token = "0x6001D98")]
	public void method_24()
	{
		base.StartCoroutine("DISABLE");
	}

	// Token: 0x06001D99 RID: 7577 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x3639AA4", Offset = "0x3639AA4", VA = "0x3639AA4")]
	[Token(Token = "0x6001D99")]
	public void method_25()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001D9A RID: 7578 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3639B30", Offset = "0x3639B30", VA = "0x3639B30")]
	[Token(Token = "0x6001D9A")]
	public IEnumerator method_26()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D9B RID: 7579 RVA: 0x00038360 File Offset: 0x00036560
	[Address(RVA = "0x3639BA8", Offset = "0x3639BA8", VA = "0x3639BA8")]
	[Token(Token = "0x6001D9B")]
	public void method_27()
	{
		base.StartCoroutine("Added Winner Money");
	}

	// Token: 0x06001D9C RID: 7580 RVA: 0x0003837C File Offset: 0x0003657C
	[Address(RVA = "0x3639BF8", Offset = "0x3639BF8", VA = "0x3639BF8")]
	[Token(Token = "0x6001D9C")]
	public void method_28()
	{
		base.StartCoroutine("Vertical");
	}

	// Token: 0x06001D9D RID: 7581 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3639C48", Offset = "0x3639C48", VA = "0x3639C48")]
	[Token(Token = "0x6001D9D")]
	public IEnumerator method_29()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D9E RID: 7582 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3639CC0", Offset = "0x3639CC0", VA = "0x3639CC0")]
	[Token(Token = "0x6001D9E")]
	public IEnumerator method_30()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001D9F RID: 7583 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3639D38", Offset = "0x3639D38", VA = "0x3639D38")]
	[Token(Token = "0x6001D9F")]
	public IEnumerator method_31()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DA0 RID: 7584 RVA: 0x00009500 File Offset: 0x00007700
	[Address(RVA = "0x3639DB0", Offset = "0x3639DB0", VA = "0x3639DB0")]
	[Token(Token = "0x6001DA0")]
	public IEnumerator method_32()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06001DA1 RID: 7585 RVA: 0x00038398 File Offset: 0x00036598
	[Address(RVA = "0x3639E28", Offset = "0x3639E28", VA = "0x3639E28")]
	[Token(Token = "0x6001DA1")]
	public void method_33()
	{
		base.StartCoroutine("DisableCosmetic");
	}

	// Token: 0x06001DA2 RID: 7586 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3639E78", Offset = "0x3639E78", VA = "0x3639E78")]
	[Token(Token = "0x6001DA2")]
	public IEnumerator method_34()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DA3 RID: 7587 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3639EF0", Offset = "0x3639EF0", VA = "0x3639EF0")]
	[Token(Token = "0x6001DA3")]
	public IEnumerator method_35()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DA4 RID: 7588 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x3639F68", Offset = "0x3639F68", VA = "0x3639F68")]
	[Token(Token = "0x6001DA4")]
	public IEnumerator method_36()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DA5 RID: 7589 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x3639FE0", Offset = "0x3639FE0", VA = "0x3639FE0")]
	[Token(Token = "0x6001DA5")]
	public void method_37()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DA6 RID: 7590 RVA: 0x000383B4 File Offset: 0x000365B4
	[Address(RVA = "0x363A06C", Offset = "0x363A06C", VA = "0x363A06C")]
	[Token(Token = "0x6001DA6")]
	public void method_38()
	{
		base.StartCoroutine("FingerTip");
	}

	// Token: 0x06001DA7 RID: 7591 RVA: 0x00038344 File Offset: 0x00036544
	[Address(RVA = "0x363A0BC", Offset = "0x363A0BC", VA = "0x363A0BC")]
	[Token(Token = "0x6001DA7")]
	public void method_39()
	{
		base.StartCoroutine("DISABLE");
	}

	// Token: 0x06001DA8 RID: 7592 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363A10C", Offset = "0x363A10C", VA = "0x363A10C")]
	[Token(Token = "0x6001DA8")]
	public void method_40()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DA9 RID: 7593 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363A198", Offset = "0x363A198", VA = "0x363A198")]
	[Token(Token = "0x6001DA9")]
	public IEnumerator method_41()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DAA RID: 7594 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363A210", Offset = "0x363A210", VA = "0x363A210")]
	[Token(Token = "0x6001DAA")]
	public void method_42()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DAB RID: 7595 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363A29C", Offset = "0x363A29C", VA = "0x363A29C")]
	[Token(Token = "0x6001DAB")]
	public IEnumerator method_43()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DAC RID: 7596 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363A314", Offset = "0x363A314", VA = "0x363A314")]
	[Token(Token = "0x6001DAC")]
	public IEnumerator method_44()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DAD RID: 7597 RVA: 0x000383D0 File Offset: 0x000365D0
	[Address(RVA = "0x363A38C", Offset = "0x363A38C", VA = "0x363A38C")]
	[Token(Token = "0x6001DAD")]
	public void method_45()
	{
		base.StartCoroutine("_Tint");
	}

	// Token: 0x06001DAE RID: 7598 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363A3DC", Offset = "0x363A3DC", VA = "0x363A3DC")]
	[Token(Token = "0x6001DAE")]
	public void method_46()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DAF RID: 7599 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363A468", Offset = "0x363A468", VA = "0x363A468")]
	[Token(Token = "0x6001DAF")]
	public void method_47()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DB0 RID: 7600 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363A4F4", Offset = "0x363A4F4", VA = "0x363A4F4")]
	[Token(Token = "0x6001DB0")]
	public void method_48()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DB1 RID: 7601 RVA: 0x000383EC File Offset: 0x000365EC
	[Address(RVA = "0x363A580", Offset = "0x363A580", VA = "0x363A580")]
	[Token(Token = "0x6001DB1")]
	public void method_49()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DB2 RID: 7602 RVA: 0x00038414 File Offset: 0x00036614
	[Address(RVA = "0x363A60C", Offset = "0x363A60C", VA = "0x363A60C")]
	[Token(Token = "0x6001DB2")]
	public void method_50()
	{
		base.StartCoroutine("Player");
	}

	// Token: 0x06001DB3 RID: 7603 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363A65C", Offset = "0x363A65C", VA = "0x363A65C")]
	[Token(Token = "0x6001DB3")]
	public void method_51()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DB4 RID: 7604 RVA: 0x00038430 File Offset: 0x00036630
	[Address(RVA = "0x363A6E8", Offset = "0x363A6E8", VA = "0x363A6E8")]
	[Token(Token = "0x6001DB4")]
	public void method_52()
	{
		base.StartCoroutine(".Please press the button if you would like to play alone");
	}

	// Token: 0x06001DB5 RID: 7605 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363A738", Offset = "0x363A738", VA = "0x363A738")]
	[Token(Token = "0x6001DB5")]
	public void method_53()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DB6 RID: 7606 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363A7C4", Offset = "0x363A7C4", VA = "0x363A7C4")]
	[Token(Token = "0x6001DB6")]
	public void method_54()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DB7 RID: 7607 RVA: 0x000383EC File Offset: 0x000365EC
	[Address(RVA = "0x363A850", Offset = "0x363A850", VA = "0x363A850")]
	[Token(Token = "0x6001DB7")]
	public void method_55()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DB8 RID: 7608 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363A8DC", Offset = "0x363A8DC", VA = "0x363A8DC")]
	[Token(Token = "0x6001DB8")]
	public IEnumerator method_56()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DB9 RID: 7609 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363A954", Offset = "0x363A954", VA = "0x363A954")]
	[Token(Token = "0x6001DB9")]
	public IEnumerator method_57()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DBA RID: 7610 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363A9CC", Offset = "0x363A9CC", VA = "0x363A9CC")]
	[Token(Token = "0x6001DBA")]
	public IEnumerator method_58()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DBB RID: 7611 RVA: 0x0003844C File Offset: 0x0003664C
	[Address(RVA = "0x363AA44", Offset = "0x363AA44", VA = "0x363AA44")]
	[Token(Token = "0x6001DBB")]
	public void method_59()
	{
		base.StartCoroutine("{0}/{1:f0}");
	}

	// Token: 0x06001DBC RID: 7612 RVA: 0x00038468 File Offset: 0x00036668
	[Address(RVA = "0x363AA94", Offset = "0x363AA94", VA = "0x363AA94")]
	[Token(Token = "0x6001DBC")]
	public void method_60()
	{
		base.StartCoroutine("/");
	}

	// Token: 0x06001DBD RID: 7613 RVA: 0x00038484 File Offset: 0x00036684
	[Address(RVA = "0x363AAE4", Offset = "0x363AAE4", VA = "0x363AAE4")]
	[Token(Token = "0x6001DBD")]
	public void method_61()
	{
		base.StartCoroutine("You struck apon an error. ");
	}

	// Token: 0x06001DBE RID: 7614 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363AB34", Offset = "0x363AB34", VA = "0x363AB34")]
	[Token(Token = "0x6001DBE")]
	public void method_62()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DBF RID: 7615 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363ABC0", Offset = "0x363ABC0", VA = "0x363ABC0")]
	[Token(Token = "0x6001DBF")]
	public IEnumerator method_63()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DC0 RID: 7616 RVA: 0x00009500 File Offset: 0x00007700
	[Address(RVA = "0x363AC38", Offset = "0x363AC38", VA = "0x363AC38")]
	[Token(Token = "0x6001DC0")]
	public IEnumerator method_64()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06001DC1 RID: 7617 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363ACB0", Offset = "0x363ACB0", VA = "0x363ACB0")]
	[Token(Token = "0x6001DC1")]
	public IEnumerator method_65()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DC2 RID: 7618 RVA: 0x000384A0 File Offset: 0x000366A0
	[Address(RVA = "0x363AD28", Offset = "0x363AD28", VA = "0x363AD28")]
	[Token(Token = "0x6001DC2")]
	public void method_66()
	{
		base.StartCoroutine("EnableCosmetic");
	}

	// Token: 0x06001DC3 RID: 7619 RVA: 0x00038218 File Offset: 0x00036418
	[Address(RVA = "0x363AD78", Offset = "0x363AD78", VA = "0x363AD78")]
	[Token(Token = "0x6001DC3")]
	public IEnumerator method_67()
	{
		new HeartThump.Class30((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x06001DC4 RID: 7620 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363ADF0", Offset = "0x363ADF0", VA = "0x363ADF0")]
	[Token(Token = "0x6001DC4")]
	public IEnumerator method_68()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DC5 RID: 7621 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363AE68", Offset = "0x363AE68", VA = "0x363AE68")]
	[Token(Token = "0x6001DC5")]
	public IEnumerator method_69()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DC6 RID: 7622 RVA: 0x000384BC File Offset: 0x000366BC
	[Address(RVA = "0x363AEE0", Offset = "0x363AEE0", VA = "0x363AEE0")]
	[Token(Token = "0x6001DC6")]
	public void method_70()
	{
		base.StartCoroutine("A new Player joined a Room.");
	}

	// Token: 0x06001DC7 RID: 7623 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363AF30", Offset = "0x363AF30", VA = "0x363AF30")]
	[Token(Token = "0x6001DC7")]
	public IEnumerator method_71()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DC8 RID: 7624 RVA: 0x00038414 File Offset: 0x00036614
	[Address(RVA = "0x363AFA8", Offset = "0x363AFA8", VA = "0x363AFA8")]
	[Token(Token = "0x6001DC8")]
	public void method_72()
	{
		base.StartCoroutine("Player");
	}

	// Token: 0x06001DC9 RID: 7625 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363AFF8", Offset = "0x363AFF8", VA = "0x363AFF8")]
	[Token(Token = "0x6001DC9")]
	public void Update()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DCA RID: 7626 RVA: 0x000383EC File Offset: 0x000365EC
	[Address(RVA = "0x363B084", Offset = "0x363B084", VA = "0x363B084")]
	[Token(Token = "0x6001DCA")]
	public void method_73()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DCB RID: 7627 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363B110", Offset = "0x363B110", VA = "0x363B110")]
	[Token(Token = "0x6001DCB")]
	public void method_74()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DCC RID: 7628 RVA: 0x000383D0 File Offset: 0x000365D0
	[Address(RVA = "0x363B19C", Offset = "0x363B19C", VA = "0x363B19C")]
	[Token(Token = "0x6001DCC")]
	public void method_75()
	{
		base.StartCoroutine("_Tint");
	}

	// Token: 0x06001DCD RID: 7629 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363B1EC", Offset = "0x363B1EC", VA = "0x363B1EC")]
	[Token(Token = "0x6001DCD")]
	public IEnumerator method_76()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DCE RID: 7630 RVA: 0x000384D8 File Offset: 0x000366D8
	[Address(RVA = "0x363B264", Offset = "0x363B264", VA = "0x363B264")]
	[Token(Token = "0x6001DCE")]
	public void method_77()
	{
		base.StartCoroutine("This is the 2500 Bananas button, and it was just clicked");
	}

	// Token: 0x06001DCF RID: 7631 RVA: 0x000384F4 File Offset: 0x000366F4
	[Address(RVA = "0x363B2B4", Offset = "0x363B2B4", VA = "0x363B2B4")]
	[Token(Token = "0x6001DCF")]
	public void method_78()
	{
		base.StartCoroutine("NetworkPlayer");
	}

	// Token: 0x06001DD0 RID: 7632 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363B304", Offset = "0x363B304", VA = "0x363B304")]
	[Token(Token = "0x6001DD0")]
	public IEnumerator method_79()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DD1 RID: 7633 RVA: 0x00038510 File Offset: 0x00036710
	[Address(RVA = "0x363B37C", Offset = "0x363B37C", VA = "0x363B37C")]
	[Token(Token = "0x6001DD1")]
	public void method_80()
	{
		base.StartCoroutine("PlayerHead");
	}

	// Token: 0x06001DD2 RID: 7634 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363B3CC", Offset = "0x363B3CC", VA = "0x363B3CC")]
	[Token(Token = "0x6001DD2")]
	public void method_81()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DD3 RID: 7635 RVA: 0x000383D0 File Offset: 0x000365D0
	[Address(RVA = "0x363B458", Offset = "0x363B458", VA = "0x363B458")]
	[Token(Token = "0x6001DD3")]
	public void method_82()
	{
		base.StartCoroutine("_Tint");
	}

	// Token: 0x06001DD4 RID: 7636 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363B4A8", Offset = "0x363B4A8", VA = "0x363B4A8")]
	[Token(Token = "0x6001DD4")]
	public void method_83()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DD5 RID: 7637 RVA: 0x0003852C File Offset: 0x0003672C
	[Address(RVA = "0x363B534", Offset = "0x363B534", VA = "0x363B534")]
	[Token(Token = "0x6001DD5")]
	public void method_84()
	{
		base.StartCoroutine("oculus");
	}

	// Token: 0x06001DD6 RID: 7638 RVA: 0x00038548 File Offset: 0x00036748
	[Address(RVA = "0x363B584", Offset = "0x363B584", VA = "0x363B584")]
	[Token(Token = "0x6001DD6")]
	public void method_85()
	{
	}

	// Token: 0x06001DD7 RID: 7639 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363B5D4", Offset = "0x363B5D4", VA = "0x363B5D4")]
	[Token(Token = "0x6001DD7")]
	public IEnumerator method_86()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DD8 RID: 7640 RVA: 0x00038558 File Offset: 0x00036758
	[Address(RVA = "0x363B64C", Offset = "0x363B64C", VA = "0x363B64C")]
	[Token(Token = "0x6001DD8")]
	public void method_87()
	{
		base.StartCoroutine("TurnAmount");
	}

	// Token: 0x06001DD9 RID: 7641 RVA: 0x00038574 File Offset: 0x00036774
	[Address(RVA = "0x363B69C", Offset = "0x363B69C", VA = "0x363B69C")]
	[Token(Token = "0x6001DD9")]
	public void method_88()
	{
		base.StartCoroutine("PlayWave");
	}

	// Token: 0x06001DDA RID: 7642 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363B6EC", Offset = "0x363B6EC", VA = "0x363B6EC")]
	[Token(Token = "0x6001DDA")]
	public IEnumerator method_89()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DDB RID: 7643 RVA: 0x00038590 File Offset: 0x00036790
	[Address(RVA = "0x363B764", Offset = "0x363B764", VA = "0x363B764")]
	[Token(Token = "0x6001DDB")]
	public void method_90()
	{
		base.StartCoroutine("friend");
	}

	// Token: 0x06001DDC RID: 7644 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363B7B4", Offset = "0x363B7B4", VA = "0x363B7B4")]
	[Token(Token = "0x6001DDC")]
	public void method_91()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DDD RID: 7645 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363B840", Offset = "0x363B840", VA = "0x363B840")]
	[Token(Token = "0x6001DDD")]
	public IEnumerator method_92()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DDE RID: 7646 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363B8B8", Offset = "0x363B8B8", VA = "0x363B8B8")]
	[Token(Token = "0x6001DDE")]
	public IEnumerator method_93()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DDF RID: 7647 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363B930", Offset = "0x363B930", VA = "0x363B930")]
	[Token(Token = "0x6001DDF")]
	public IEnumerator method_94()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DE0 RID: 7648 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363B9A8", Offset = "0x363B9A8", VA = "0x363B9A8")]
	[Token(Token = "0x6001DE0")]
	public void method_95()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DE1 RID: 7649 RVA: 0x000385AC File Offset: 0x000367AC
	[Address(RVA = "0x363BA34", Offset = "0x363BA34", VA = "0x363BA34")]
	[Token(Token = "0x6001DE1")]
	public void method_96()
	{
		base.StartCoroutine("ӊԎߵڱ");
	}

	// Token: 0x06001DE2 RID: 7650 RVA: 0x000385AC File Offset: 0x000367AC
	[Address(RVA = "0x363BA84", Offset = "0x363BA84", VA = "0x363BA84")]
	[Token(Token = "0x6001DE2")]
	public void Awake()
	{
		base.StartCoroutine("ӊԎߵڱ");
	}

	// Token: 0x06001DE3 RID: 7651 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363BAD4", Offset = "0x363BAD4", VA = "0x363BAD4")]
	[Token(Token = "0x6001DE3")]
	public void method_97()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DE4 RID: 7652 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363BB60", Offset = "0x363BB60", VA = "0x363BB60")]
	[Token(Token = "0x6001DE4")]
	public void method_98()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DE5 RID: 7653 RVA: 0x000385C8 File Offset: 0x000367C8
	[Address(RVA = "0x363BBEC", Offset = "0x363BBEC", VA = "0x363BBEC")]
	[Token(Token = "0x6001DE5")]
	public IEnumerator method_99()
	{
		HeartThump.Class30 @class;
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DE6 RID: 7654 RVA: 0x000385E4 File Offset: 0x000367E4
	[Address(RVA = "0x363BC64", Offset = "0x363BC64", VA = "0x363BC64")]
	[Token(Token = "0x6001DE6")]
	public void method_100()
	{
		base.StartCoroutine("HDRP/Lit");
	}

	// Token: 0x06001DE7 RID: 7655 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363BCB4", Offset = "0x363BCB4", VA = "0x363BCB4")]
	[Token(Token = "0x6001DE7")]
	public void method_101()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DE8 RID: 7656 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363BD40", Offset = "0x363BD40", VA = "0x363BD40")]
	[Token(Token = "0x6001DE8")]
	public IEnumerator method_102()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DE9 RID: 7657 RVA: 0x00038600 File Offset: 0x00036800
	[Address(RVA = "0x363BDB8", Offset = "0x363BDB8", VA = "0x363BDB8")]
	[Token(Token = "0x6001DE9")]
	public void method_103()
	{
		base.StartCoroutine("{0} ({1})");
	}

	// Token: 0x06001DEA RID: 7658 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363BE08", Offset = "0x363BE08", VA = "0x363BE08")]
	[Token(Token = "0x6001DEA")]
	public void method_104()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DEB RID: 7659 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x363BE94", Offset = "0x363BE94", VA = "0x363BE94")]
	[Token(Token = "0x6001DEB")]
	public HeartThump()
	{
	}

	// Token: 0x06001DEC RID: 7660 RVA: 0x0003861C File Offset: 0x0003681C
	[Address(RVA = "0x363BE9C", Offset = "0x363BE9C", VA = "0x363BE9C")]
	[Token(Token = "0x6001DEC")]
	public void method_105()
	{
		base.StartCoroutine("User has been reported for: ");
	}

	// Token: 0x06001DED RID: 7661 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363BEEC", Offset = "0x363BEEC", VA = "0x363BEEC")]
	[Token(Token = "0x6001DED")]
	public void method_106()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DEE RID: 7662 RVA: 0x00038574 File Offset: 0x00036774
	[Address(RVA = "0x363BF78", Offset = "0x363BF78", VA = "0x363BF78")]
	[Token(Token = "0x6001DEE")]
	public void method_107()
	{
		base.StartCoroutine("PlayWave");
	}

	// Token: 0x06001DEF RID: 7663 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363BFC8", Offset = "0x363BFC8", VA = "0x363BFC8")]
	[Token(Token = "0x6001DEF")]
	public void method_108()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DF0 RID: 7664 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363C054", Offset = "0x363C054", VA = "0x363C054")]
	[Token(Token = "0x6001DF0")]
	public void method_109()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DF1 RID: 7665 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363C0E0", Offset = "0x363C0E0", VA = "0x363C0E0")]
	[Token(Token = "0x6001DF1")]
	public IEnumerator method_110()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DF2 RID: 7666 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363C158", Offset = "0x363C158", VA = "0x363C158")]
	[Token(Token = "0x6001DF2")]
	public IEnumerator method_111()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DF3 RID: 7667 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363C1D0", Offset = "0x363C1D0", VA = "0x363C1D0")]
	[Token(Token = "0x6001DF3")]
	public void method_112()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DF4 RID: 7668 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363C25C", Offset = "0x363C25C", VA = "0x363C25C")]
	[Token(Token = "0x6001DF4")]
	public void method_113()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DF5 RID: 7669 RVA: 0x00038548 File Offset: 0x00036748
	[Address(RVA = "0x363C2E8", Offset = "0x363C2E8", VA = "0x363C2E8")]
	[Token(Token = "0x6001DF5")]
	public void method_114()
	{
	}

	// Token: 0x06001DF6 RID: 7670 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363C338", Offset = "0x363C338", VA = "0x363C338")]
	[Token(Token = "0x6001DF6")]
	public void method_115()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DF7 RID: 7671 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363C3C4", Offset = "0x363C3C4", VA = "0x363C3C4")]
	[Token(Token = "0x6001DF7")]
	public void method_116()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DF8 RID: 7672 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363C450", Offset = "0x363C450", VA = "0x363C450")]
	[Token(Token = "0x6001DF8")]
	public IEnumerator method_117()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001DF9 RID: 7673 RVA: 0x00038638 File Offset: 0x00036838
	[Address(RVA = "0x363C4C8", Offset = "0x363C4C8", VA = "0x363C4C8")]
	[Token(Token = "0x6001DF9")]
	public void method_118()
	{
		base.StartCoroutine("Not connected to room");
	}

	// Token: 0x06001DFA RID: 7674 RVA: 0x0003823C File Offset: 0x0003643C
	[Address(RVA = "0x363C518", Offset = "0x363C518", VA = "0x363C518")]
	[Token(Token = "0x6001DFA")]
	public void method_119()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
	}

	// Token: 0x06001DFB RID: 7675 RVA: 0x00038654 File Offset: 0x00036854
	[Address(RVA = "0x363C5A4", Offset = "0x363C5A4", VA = "0x363C5A4")]
	[Token(Token = "0x6001DFB")]
	public void method_120()
	{
		base.StartCoroutine("A Player has left the Room.");
	}

	// Token: 0x06001DFC RID: 7676 RVA: 0x000381F0 File Offset: 0x000363F0
	[Address(RVA = "0x363C5F4", Offset = "0x363C5F4", VA = "0x363C5F4")]
	[Token(Token = "0x6001DFC")]
	public IEnumerator method_121()
	{
		HeartThump.Class30 @class = new HeartThump.Class30((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x040003F5 RID: 1013
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003F5")]
	public float float_0;

	// Token: 0x040003F6 RID: 1014
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003F6")]
	public Transform transform_0;

	// Token: 0x040003F7 RID: 1015
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003F7")]
	public AudioSource audioSource_0;

	// Token: 0x040003F8 RID: 1016
	[Token(Token = "0x40003F8")]
	[FieldOffset(Offset = "0x30")]
	public AudioClip audioClip_0;

	// Token: 0x040003F9 RID: 1017
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40003F9")]
	public float float_1;
}
