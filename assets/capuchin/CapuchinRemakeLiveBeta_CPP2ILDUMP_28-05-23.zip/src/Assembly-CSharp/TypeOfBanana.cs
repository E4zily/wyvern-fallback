﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000F1 RID: 241
[Token(Token = "0x20000F1")]
public class TypeOfBanana : MonoBehaviour
{
	// Token: 0x06002465 RID: 9317 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x20F4754", Offset = "0x20F4754", VA = "0x20F4754")]
	[Token(Token = "0x6002465")]
	public TypeOfBanana()
	{
	}

	// Token: 0x040004C5 RID: 1221
	[Token(Token = "0x40004C5")]
	[FieldOffset(Offset = "0x18")]
	public bool bool_0;

	// Token: 0x040004C6 RID: 1222
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x40004C6")]
	public bool bool_1;

	// Token: 0x040004C7 RID: 1223
	[Token(Token = "0x40004C7")]
	[FieldOffset(Offset = "0x1A")]
	public bool bool_2;
}
