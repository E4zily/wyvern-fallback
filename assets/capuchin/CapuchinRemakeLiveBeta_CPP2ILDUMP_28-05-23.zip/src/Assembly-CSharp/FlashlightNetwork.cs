﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000CA RID: 202
[Token(Token = "0x20000CA")]
public class FlashlightNetwork : MonoBehaviour
{
	// Token: 0x06001CDD RID: 7389 RVA: 0x00036FAC File Offset: 0x000351AC
	[Address(RVA = "0x34F74AC", Offset = "0x34F74AC", VA = "0x34F74AC")]
	[Token(Token = "0x6001CDD")]
	private void method_0(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("Player");
		if (this == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CDE RID: 7390 RVA: 0x00036FDC File Offset: 0x000351DC
	[Address(RVA = "0x34F7614", Offset = "0x34F7614", VA = "0x34F7614")]
	[Token(Token = "0x6001CDE")]
	private void method_1(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("Left a room");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CDF RID: 7391 RVA: 0x00037018 File Offset: 0x00035218
	[Address(RVA = "0x34F7778", Offset = "0x34F7778", VA = "0x34F7778")]
	[Token(Token = "0x6001CDF")]
	private void method_2(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("Player");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CE0 RID: 7392 RVA: 0x00037054 File Offset: 0x00035254
	[Address(RVA = "0x34F78DC", Offset = "0x34F78DC", VA = "0x34F78DC")]
	[Token(Token = "0x6001CE0")]
	private void method_3(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("FingerTip");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CE1 RID: 7393 RVA: 0x00037090 File Offset: 0x00035290
	[Address(RVA = "0x34F7A44", Offset = "0x34F7A44", VA = "0x34F7A44")]
	[Token(Token = "0x6001CE1")]
	private void method_4(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CE2 RID: 7394 RVA: 0x000370CC File Offset: 0x000352CC
	[Address(RVA = "0x34F7BAC", Offset = "0x34F7BAC", VA = "0x34F7BAC")]
	[Token(Token = "0x6001CE2")]
	private void method_5(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("windowsmr");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CE3 RID: 7395 RVA: 0x00037108 File Offset: 0x00035308
	[Address(RVA = "0x34F7D10", Offset = "0x34F7D10", VA = "0x34F7D10")]
	[Token(Token = "0x6001CE3")]
	private void method_6(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("A Player has left the Room.");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CE4 RID: 7396 RVA: 0x00037144 File Offset: 0x00035344
	[Address(RVA = "0x34F7E74", Offset = "0x34F7E74", VA = "0x34F7E74")]
	[Token(Token = "0x6001CE4")]
	private void method_7(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("_Tint");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CE5 RID: 7397 RVA: 0x00037180 File Offset: 0x00035380
	[Address(RVA = "0x34F7FD8", Offset = "0x34F7FD8", VA = "0x34F7FD8")]
	[Token(Token = "0x6001CE5")]
	private void OnTriggerExit(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("Player");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CE6 RID: 7398 RVA: 0x000371BC File Offset: 0x000353BC
	[Address(RVA = "0x34F813C", Offset = "0x34F813C", VA = "0x34F813C")]
	[Token(Token = "0x6001CE6")]
	private void method_8(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("Player");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CE7 RID: 7399 RVA: 0x000371BC File Offset: 0x000353BC
	[Address(RVA = "0x34F82A4", Offset = "0x34F82A4", VA = "0x34F82A4")]
	[Token(Token = "0x6001CE7")]
	private void OnTriggerEnter(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("Player");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CE8 RID: 7400 RVA: 0x000371F8 File Offset: 0x000353F8
	[Address(RVA = "0x34F8408", Offset = "0x34F8408", VA = "0x34F8408")]
	[Token(Token = "0x6001CE8")]
	private void method_9(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("HandR");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CE9 RID: 7401 RVA: 0x00037234 File Offset: 0x00035434
	[Address(RVA = "0x34F8570", Offset = "0x34F8570", VA = "0x34F8570")]
	[Token(Token = "0x6001CE9")]
	private void method_10()
	{
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		if (networkPlayerSpawner.bool_0)
		{
			PhotonView component = networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
			this.photonView_0 = component;
			return;
		}
	}

	// Token: 0x06001CEA RID: 7402 RVA: 0x0003726C File Offset: 0x0003546C
	[Address(RVA = "0x34F8628", Offset = "0x34F8628", VA = "0x34F8628")]
	[Token(Token = "0x6001CEA")]
	private void method_11(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("You struck apon an error. ");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CEB RID: 7403 RVA: 0x00037234 File Offset: 0x00035434
	[Address(RVA = "0x34F878C", Offset = "0x34F878C", VA = "0x34F878C")]
	[Token(Token = "0x6001CEB")]
	private void Update()
	{
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		if (networkPlayerSpawner.bool_0)
		{
			PhotonView component = networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
			this.photonView_0 = component;
			return;
		}
	}

	// Token: 0x06001CEC RID: 7404 RVA: 0x000372A8 File Offset: 0x000354A8
	[Address(RVA = "0x34F8844", Offset = "0x34F8844", VA = "0x34F8844")]
	[Token(Token = "0x6001CEC")]
	private void method_12(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("BN");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CED RID: 7405 RVA: 0x000372E4 File Offset: 0x000354E4
	[Address(RVA = "0x34F89A8", Offset = "0x34F89A8", VA = "0x34F89A8")]
	[Token(Token = "0x6001CED")]
	private void method_13(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("Name Changing Error. Error: ");
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x06001CEE RID: 7406 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x34F8B0C", Offset = "0x34F8B0C", VA = "0x34F8B0C")]
	[Token(Token = "0x6001CEE")]
	public FlashlightNetwork()
	{
	}

	// Token: 0x06001CEF RID: 7407 RVA: 0x00037320 File Offset: 0x00035520
	[Address(RVA = "0x34F8B14", Offset = "0x34F8B14", VA = "0x34F8B14")]
	[Token(Token = "0x6001CEF")]
	private void method_14(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.CompareTag("n0");
		if (new object[1] == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x040003E5 RID: 997
	[Token(Token = "0x40003E5")]
	[FieldOffset(Offset = "0x18")]
	public string string_0;

	// Token: 0x040003E6 RID: 998
	[Token(Token = "0x40003E6")]
	[FieldOffset(Offset = "0x20")]
	public NetworkPlayerSpawner networkPlayerSpawner_0;

	// Token: 0x040003E7 RID: 999
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003E7")]
	private PhotonView photonView_0;
}
