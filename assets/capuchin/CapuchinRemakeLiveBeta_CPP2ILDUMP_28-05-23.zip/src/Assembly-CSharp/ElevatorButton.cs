﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200005E RID: 94
[Token(Token = "0x200005E")]
public class ElevatorButton : MonoBehaviour
{
	// Token: 0x06000D4D RID: 3405 RVA: 0x0001C788 File Offset: 0x0001A988
	[Address(RVA = "0x10D1350", Offset = "0x10D1350", VA = "0x10D1350")]
	[Token(Token = "0x6000D4D")]
	public void method_0(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_11();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_13();
			return;
		}
	}

	// Token: 0x06000D4E RID: 3406 RVA: 0x0001C7C8 File Offset: 0x0001A9C8
	[Token(Token = "0x6000D4E")]
	[Address(RVA = "0x10D162C", Offset = "0x10D162C", VA = "0x10D162C")]
	public void method_1(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_25();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_14();
			return;
		}
	}

	// Token: 0x06000D4F RID: 3407 RVA: 0x0001C808 File Offset: 0x0001AA08
	[Address(RVA = "0x10D1908", Offset = "0x10D1908", VA = "0x10D1908")]
	[Token(Token = "0x6000D4F")]
	public void method_2(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_19();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_7();
			return;
		}
	}

	// Token: 0x06000D50 RID: 3408 RVA: 0x0001C848 File Offset: 0x0001AA48
	[Address(RVA = "0x10D1BE4", Offset = "0x10D1BE4", VA = "0x10D1BE4")]
	[Token(Token = "0x6000D50")]
	public void method_3(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_18();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_36();
			return;
		}
	}

	// Token: 0x06000D51 RID: 3409 RVA: 0x0001C888 File Offset: 0x0001AA88
	[Token(Token = "0x6000D51")]
	[Address(RVA = "0x10D1EC0", Offset = "0x10D1EC0", VA = "0x10D1EC0")]
	public void method_4(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_30();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_5();
			return;
		}
	}

	// Token: 0x06000D52 RID: 3410 RVA: 0x0001C8C8 File Offset: 0x0001AAC8
	[Token(Token = "0x6000D52")]
	[Address(RVA = "0x10D219C", Offset = "0x10D219C", VA = "0x10D219C")]
	public void method_5(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_26();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_8();
			return;
		}
	}

	// Token: 0x06000D53 RID: 3411 RVA: 0x0001C908 File Offset: 0x0001AB08
	[Token(Token = "0x6000D53")]
	[Address(RVA = "0x10D2478", Offset = "0x10D2478", VA = "0x10D2478")]
	public void method_6(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_21();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_5();
			return;
		}
	}

	// Token: 0x06000D54 RID: 3412 RVA: 0x0001C948 File Offset: 0x0001AB48
	[Token(Token = "0x6000D54")]
	[Address(RVA = "0x10D2654", Offset = "0x10D2654", VA = "0x10D2654")]
	public void method_7(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_25();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_10();
			return;
		}
	}

	// Token: 0x06000D55 RID: 3413 RVA: 0x0001C988 File Offset: 0x0001AB88
	[Address(RVA = "0x10D2830", Offset = "0x10D2830", VA = "0x10D2830")]
	[Token(Token = "0x6000D55")]
	public void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_18();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_16();
			return;
		}
	}

	// Token: 0x06000D56 RID: 3414 RVA: 0x0001C9C8 File Offset: 0x0001ABC8
	[Token(Token = "0x6000D56")]
	[Address(RVA = "0x10D2A0C", Offset = "0x10D2A0C", VA = "0x10D2A0C")]
	public void method_9(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_25();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_37();
			return;
		}
	}

	// Token: 0x06000D57 RID: 3415 RVA: 0x0001CA08 File Offset: 0x0001AC08
	[Token(Token = "0x6000D57")]
	[Address(RVA = "0x10D2BE8", Offset = "0x10D2BE8", VA = "0x10D2BE8")]
	public void method_10(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_26();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_7();
			return;
		}
	}

	// Token: 0x06000D58 RID: 3416 RVA: 0x0001CA48 File Offset: 0x0001AC48
	[Address(RVA = "0x10D2CC4", Offset = "0x10D2CC4", VA = "0x10D2CC4")]
	[Token(Token = "0x6000D58")]
	public void method_11(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_30();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_14();
			return;
		}
	}

	// Token: 0x06000D59 RID: 3417 RVA: 0x0001CA88 File Offset: 0x0001AC88
	[Token(Token = "0x6000D59")]
	[Address(RVA = "0x10D2DA0", Offset = "0x10D2DA0", VA = "0x10D2DA0")]
	public void method_12(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_30();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_10();
			return;
		}
	}

	// Token: 0x06000D5A RID: 3418 RVA: 0x0001CAC8 File Offset: 0x0001ACC8
	[Token(Token = "0x6000D5A")]
	[Address(RVA = "0x10D2E7C", Offset = "0x10D2E7C", VA = "0x10D2E7C")]
	public void method_13(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.elevatorManager_0.method_11();
		if (this.bool_1)
		{
			this.elevatorManager_0.method_17();
			return;
		}
	}

	// Token: 0x06000D5B RID: 3419 RVA: 0x0001CB00 File Offset: 0x0001AD00
	[Address(RVA = "0x10D3058", Offset = "0x10D3058", VA = "0x10D3058")]
	[Token(Token = "0x6000D5B")]
	public void method_14(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_30();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_16();
			return;
		}
	}

	// Token: 0x06000D5C RID: 3420 RVA: 0x0001CB40 File Offset: 0x0001AD40
	[Token(Token = "0x6000D5C")]
	[Address(RVA = "0x10D3134", Offset = "0x10D3134", VA = "0x10D3134")]
	public void method_15(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_11();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_36();
			return;
		}
	}

	// Token: 0x06000D5D RID: 3421 RVA: 0x0001CB80 File Offset: 0x0001AD80
	[Token(Token = "0x6000D5D")]
	[Address(RVA = "0x10D3210", Offset = "0x10D3210", VA = "0x10D3210")]
	public void method_16(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_25();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_17();
			return;
		}
	}

	// Token: 0x06000D5E RID: 3422 RVA: 0x0001CBC0 File Offset: 0x0001ADC0
	[Token(Token = "0x6000D5E")]
	[Address(RVA = "0x10D32EC", Offset = "0x10D32EC", VA = "0x10D32EC")]
	public void method_17(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_19();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_40();
			return;
		}
	}

	// Token: 0x06000D5F RID: 3423 RVA: 0x0001CC00 File Offset: 0x0001AE00
	[Address(RVA = "0x10D34C8", Offset = "0x10D34C8", VA = "0x10D34C8")]
	[Token(Token = "0x6000D5F")]
	public void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_18();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_14();
			return;
		}
	}

	// Token: 0x06000D60 RID: 3424 RVA: 0x0001CC40 File Offset: 0x0001AE40
	[Token(Token = "0x6000D60")]
	[Address(RVA = "0x10D35A4", Offset = "0x10D35A4", VA = "0x10D35A4")]
	public void method_19(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_31();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_13();
			return;
		}
	}

	// Token: 0x06000D61 RID: 3425 RVA: 0x0001CC80 File Offset: 0x0001AE80
	[Token(Token = "0x6000D61")]
	[Address(RVA = "0x10D3780", Offset = "0x10D3780", VA = "0x10D3780")]
	public void method_20(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_19();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_13();
			return;
		}
	}

	// Token: 0x06000D62 RID: 3426 RVA: 0x0001CCC0 File Offset: 0x0001AEC0
	[Address(RVA = "0x10D385C", Offset = "0x10D385C", VA = "0x10D385C")]
	[Token(Token = "0x6000D62")]
	public void method_21(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_11();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_14();
			return;
		}
	}

	// Token: 0x06000D63 RID: 3427 RVA: 0x0001CD00 File Offset: 0x0001AF00
	[Token(Token = "0x6000D63")]
	[Address(RVA = "0x10D3938", Offset = "0x10D3938", VA = "0x10D3938")]
	public void method_22(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_11();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_40();
			return;
		}
	}

	// Token: 0x06000D64 RID: 3428 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000D64")]
	[Address(RVA = "0x10D3A14", Offset = "0x10D3A14", VA = "0x10D3A14")]
	public ElevatorButton()
	{
	}

	// Token: 0x06000D65 RID: 3429 RVA: 0x0001C848 File Offset: 0x0001AA48
	[Token(Token = "0x6000D65")]
	[Address(RVA = "0x10D3A1C", Offset = "0x10D3A1C", VA = "0x10D3A1C")]
	public void method_23(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_18();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_36();
			return;
		}
	}

	// Token: 0x06000D66 RID: 3430 RVA: 0x0001CD40 File Offset: 0x0001AF40
	[Address(RVA = "0x10D3AF8", Offset = "0x10D3AF8", VA = "0x10D3AF8")]
	[Token(Token = "0x6000D66")]
	public void method_24(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_26();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_5();
			return;
		}
	}

	// Token: 0x06000D67 RID: 3431 RVA: 0x0001CD80 File Offset: 0x0001AF80
	[Token(Token = "0x6000D67")]
	[Address(RVA = "0x10D3BD4", Offset = "0x10D3BD4", VA = "0x10D3BD4")]
	public void method_25(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_18();
		}
		this.elevatorManager_0.method_8();
	}

	// Token: 0x06000D68 RID: 3432 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000D68")]
	[Address(RVA = "0x10D3CB0", Offset = "0x10D3CB0", VA = "0x10D3CB0")]
	public void method_26(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000D69 RID: 3433 RVA: 0x0001C888 File Offset: 0x0001AA88
	[Address(RVA = "0x10D3E8C", Offset = "0x10D3E8C", VA = "0x10D3E8C")]
	[Token(Token = "0x6000D69")]
	public void method_27(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_30();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_5();
			return;
		}
	}

	// Token: 0x06000D6A RID: 3434 RVA: 0x0001CC80 File Offset: 0x0001AE80
	[Token(Token = "0x6000D6A")]
	[Address(RVA = "0x10D3F68", Offset = "0x10D3F68", VA = "0x10D3F68")]
	public void method_28(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_19();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_13();
			return;
		}
	}

	// Token: 0x06000D6B RID: 3435 RVA: 0x0001CDB8 File Offset: 0x0001AFB8
	[Token(Token = "0x6000D6B")]
	[Address(RVA = "0x10D4044", Offset = "0x10D4044", VA = "0x10D4044")]
	public void method_29(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_30();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_37();
			return;
		}
	}

	// Token: 0x06000D6C RID: 3436 RVA: 0x0001CDF8 File Offset: 0x0001AFF8
	[Address(RVA = "0x10D4120", Offset = "0x10D4120", VA = "0x10D4120")]
	[Token(Token = "0x6000D6C")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_21();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_10();
			return;
		}
	}

	// Token: 0x06000D6D RID: 3437 RVA: 0x0001CC80 File Offset: 0x0001AE80
	[Address(RVA = "0x10D41FC", Offset = "0x10D41FC", VA = "0x10D41FC")]
	[Token(Token = "0x6000D6D")]
	public void method_30(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_19();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_13();
			return;
		}
	}

	// Token: 0x06000D6E RID: 3438 RVA: 0x0001CE38 File Offset: 0x0001B038
	[Address(RVA = "0x10D42D8", Offset = "0x10D42D8", VA = "0x10D42D8")]
	[Token(Token = "0x6000D6E")]
	public void method_31(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_18();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_7();
			return;
		}
	}

	// Token: 0x06000D6F RID: 3439 RVA: 0x0001CE78 File Offset: 0x0001B078
	[Address(RVA = "0x10D43B4", Offset = "0x10D43B4", VA = "0x10D43B4")]
	[Token(Token = "0x6000D6F")]
	public void method_32(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_31();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_34();
			return;
		}
	}

	// Token: 0x06000D70 RID: 3440 RVA: 0x0001CEB8 File Offset: 0x0001B0B8
	[Address(RVA = "0x10D4490", Offset = "0x10D4490", VA = "0x10D4490")]
	[Token(Token = "0x6000D70")]
	public void method_33(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_18();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_34();
			return;
		}
	}

	// Token: 0x06000D71 RID: 3441 RVA: 0x0001CEF8 File Offset: 0x0001B0F8
	[Token(Token = "0x6000D71")]
	[Address(RVA = "0x10D456C", Offset = "0x10D456C", VA = "0x10D456C")]
	public void method_34(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ElevatorManager elevatorManager;
		if (this.bool_0)
		{
			elevatorManager = this.elevatorManager_0;
			elevatorManager.method_21();
		}
		if (this.bool_1)
		{
			elevatorManager.method_40();
			return;
		}
	}

	// Token: 0x06000D72 RID: 3442 RVA: 0x0001CF38 File Offset: 0x0001B138
	[Address(RVA = "0x10D4648", Offset = "0x10D4648", VA = "0x10D4648")]
	[Token(Token = "0x6000D72")]
	public void method_35(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_11();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_17();
			return;
		}
	}

	// Token: 0x06000D73 RID: 3443 RVA: 0x0001CF78 File Offset: 0x0001B178
	[Address(RVA = "0x10D4724", Offset = "0x10D4724", VA = "0x10D4724")]
	[Token(Token = "0x6000D73")]
	public void method_36(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_18();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_17();
			return;
		}
	}

	// Token: 0x06000D74 RID: 3444 RVA: 0x0001CFB8 File Offset: 0x0001B1B8
	[Address(RVA = "0x10D4800", Offset = "0x10D4800", VA = "0x10D4800")]
	[Token(Token = "0x6000D74")]
	public void method_37(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_19();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_10();
			return;
		}
	}

	// Token: 0x06000D75 RID: 3445 RVA: 0x0001CFF8 File Offset: 0x0001B1F8
	[Address(RVA = "0x10D48DC", Offset = "0x10D48DC", VA = "0x10D48DC")]
	[Token(Token = "0x6000D75")]
	public void method_38(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ElevatorManager elevatorManager;
		if (this.bool_0)
		{
			elevatorManager = this.elevatorManager_0;
			elevatorManager.method_26();
		}
		if (this.bool_1)
		{
			elevatorManager.method_40();
			return;
		}
	}

	// Token: 0x06000D76 RID: 3446 RVA: 0x0001D038 File Offset: 0x0001B238
	[Address(RVA = "0x10D49B8", Offset = "0x10D49B8", VA = "0x10D49B8")]
	[Token(Token = "0x6000D76")]
	public void method_39(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_31();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_16();
			return;
		}
	}

	// Token: 0x06000D77 RID: 3447 RVA: 0x0001D078 File Offset: 0x0001B278
	[Address(RVA = "0x10D4A94", Offset = "0x10D4A94", VA = "0x10D4A94")]
	[Token(Token = "0x6000D77")]
	public void method_40(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_26();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_10();
			return;
		}
	}

	// Token: 0x06000D78 RID: 3448 RVA: 0x0001D0B8 File Offset: 0x0001B2B8
	[Address(RVA = "0x10D4B70", Offset = "0x10D4B70", VA = "0x10D4B70")]
	[Token(Token = "0x6000D78")]
	public void method_41(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_21();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_17();
			return;
		}
	}

	// Token: 0x06000D79 RID: 3449 RVA: 0x0001D0F8 File Offset: 0x0001B2F8
	[Token(Token = "0x6000D79")]
	[Address(RVA = "0x10D4C4C", Offset = "0x10D4C4C", VA = "0x10D4C4C")]
	public void method_42(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_21();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_7();
			return;
		}
	}

	// Token: 0x06000D7A RID: 3450 RVA: 0x0001D138 File Offset: 0x0001B338
	[Address(RVA = "0x10D4D28", Offset = "0x10D4D28", VA = "0x10D4D28")]
	[Token(Token = "0x6000D7A")]
	public void method_43(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_26();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_37();
			return;
		}
	}

	// Token: 0x06000D7B RID: 3451 RVA: 0x0001CD40 File Offset: 0x0001AF40
	[Address(RVA = "0x10D4E04", Offset = "0x10D4E04", VA = "0x10D4E04")]
	[Token(Token = "0x6000D7B")]
	public void method_44(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_26();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_5();
			return;
		}
	}

	// Token: 0x06000D7C RID: 3452 RVA: 0x0001D178 File Offset: 0x0001B378
	[Token(Token = "0x6000D7C")]
	[Address(RVA = "0x10D4EE0", Offset = "0x10D4EE0", VA = "0x10D4EE0")]
	public void method_45(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_19();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_36();
			return;
		}
	}

	// Token: 0x06000D7D RID: 3453 RVA: 0x0001CC00 File Offset: 0x0001AE00
	[Address(RVA = "0x10D4FBC", Offset = "0x10D4FBC", VA = "0x10D4FBC")]
	[Token(Token = "0x6000D7D")]
	public void method_46(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_18();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_14();
			return;
		}
	}

	// Token: 0x06000D7E RID: 3454 RVA: 0x0001D1B8 File Offset: 0x0001B3B8
	[Address(RVA = "0x10D5098", Offset = "0x10D5098", VA = "0x10D5098")]
	[Token(Token = "0x6000D7E")]
	public void method_47(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_19();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_14();
			return;
		}
	}

	// Token: 0x06000D7F RID: 3455 RVA: 0x0001D1F8 File Offset: 0x0001B3F8
	[Token(Token = "0x6000D7F")]
	[Address(RVA = "0x10D5174", Offset = "0x10D5174", VA = "0x10D5174")]
	public void method_48(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.elevatorManager_0.method_25();
		}
		if (this.bool_1)
		{
			this.elevatorManager_0.method_17();
			return;
		}
	}

	// Token: 0x040001EE RID: 494
	[Token(Token = "0x40001EE")]
	[FieldOffset(Offset = "0x18")]
	public ElevatorManager elevatorManager_0;

	// Token: 0x040001EF RID: 495
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001EF")]
	public bool bool_0;

	// Token: 0x040001F0 RID: 496
	[FieldOffset(Offset = "0x21")]
	[Token(Token = "0x40001F0")]
	public bool bool_1;
}
