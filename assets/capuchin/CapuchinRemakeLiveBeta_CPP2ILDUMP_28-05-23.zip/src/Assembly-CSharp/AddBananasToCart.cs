﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x020000A3 RID: 163
[Token(Token = "0x20000A3")]
public class AddBananasToCart : MonoBehaviour
{
	// Token: 0x060017BF RID: 6079 RVA: 0x0003034C File Offset: 0x0002E54C
	[Token(Token = "0x60017BF")]
	[Address(RVA = "0x2BF0488", Offset = "0x2BF0488", VA = "0x2BF0488")]
	public void method_0(Collider collider_0)
	{
		if (collider_0 == null)
		{
			throw new NullReferenceException();
		}
		collider_0.gameObject.CompareTag("FingerTip");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("poweredup!");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "/";
			this.buyScript_0.int_0 = 65;
			return;
		}
	}

	// Token: 0x060017C0 RID: 6080 RVA: 0x000303B0 File Offset: 0x0002E5B0
	[Token(Token = "0x60017C0")]
	[Address(RVA = "0x2BF076C", Offset = "0x2BF076C", VA = "0x2BF076C")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("On");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "You are not the master of the server, you cannot start the game.";
			return;
		}
	}

	// Token: 0x060017C1 RID: 6081 RVA: 0x000303FC File Offset: 0x0002E5FC
	[Address(RVA = "0x2BF0A44", Offset = "0x2BF0A44", VA = "0x2BF0A44")]
	[Token(Token = "0x60017C1")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("This is the 2500 Bananas button, and it was just clicked");
		AddBananasToCart.GEnum7 genum = this.genum7_0;
		if (genum == AddBananasToCart.GEnum7.const_0)
		{
			if (genum != AddBananasToCart.GEnum7.const_0)
			{
			}
			Debug.Log("Add/Remove Sword");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Calling success callback. baking meshes";
			return;
		}
	}

	// Token: 0x060017C2 RID: 6082 RVA: 0x00030450 File Offset: 0x0002E650
	[Token(Token = "0x60017C2")]
	[Address(RVA = "0x2BF0D14", Offset = "0x2BF0D14", VA = "0x2BF0D14")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("HeadAttachPoint");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("containsStaff");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "jump char false";
			return;
		}
	}

	// Token: 0x060017C3 RID: 6083 RVA: 0x0003049C File Offset: 0x0002E69C
	[Address(RVA = "0x2BF0FE8", Offset = "0x2BF0FE8", VA = "0x2BF0FE8")]
	[Token(Token = "0x60017C3")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PLAYER IS BANNED");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "SaveHeight";
			return;
		}
	}

	// Token: 0x060017C4 RID: 6084 RVA: 0x000304E0 File Offset: 0x0002E6E0
	[Token(Token = "0x60017C4")]
	[Address(RVA = "0x2BF12CC", Offset = "0x2BF12CC", VA = "0x2BF12CC")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Cheating");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("Try Connect To Server...");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "typesOfTalk";
			return;
		}
	}

	// Token: 0x060017C5 RID: 6085 RVA: 0x0003052C File Offset: 0x0002E72C
	[Token(Token = "0x60017C5")]
	[Address(RVA = "0x2BF15A0", Offset = "0x2BF15A0", VA = "0x2BF15A0")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Queue");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("Head");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Cannot access index {0}. Buffer is empty";
			return;
		}
	}

	// Token: 0x060017C6 RID: 6086 RVA: 0x00030578 File Offset: 0x0002E778
	[Token(Token = "0x60017C6")]
	[Address(RVA = "0x2BF1884", Offset = "0x2BF1884", VA = "0x2BF1884")]
	public void method_7(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("PRESS AGAIN TO CONFIRM");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "You struck apon an error. ";
			return;
		}
	}

	// Token: 0x060017C7 RID: 6087 RVA: 0x000305BC File Offset: 0x0002E7BC
	[Address(RVA = "0x2BF1B68", Offset = "0x2BF1B68", VA = "0x2BF1B68")]
	[Token(Token = "0x60017C7")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Push To Talk");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("[InputHelpers.IsPressed] The value of <button> is out or the supported range.");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Player";
			BuyScript buyScript = this.buyScript_0;
			long int_ = 16L;
			buyScript.int_0 = (int)int_;
			return;
		}
	}

	// Token: 0x060017C8 RID: 6088 RVA: 0x0003061C File Offset: 0x0002E81C
	[Address(RVA = "0x2BF1E4C", Offset = "0x2BF1E4C", VA = "0x2BF1E4C")]
	[Token(Token = "0x60017C8")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("monke screamed");
		Debug.Log("TurnAmount");
		this.particleSystem_0.Play();
		this.buyScript_0.string_0 = "On";
	}

	// Token: 0x060017C9 RID: 6089 RVA: 0x00030660 File Offset: 0x0002E860
	[Address(RVA = "0x2BF2120", Offset = "0x2BF2120", VA = "0x2BF2120")]
	[Token(Token = "0x60017C9")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Cannot access index {0}. Buffer is empty");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "lava";
			return;
		}
	}

	// Token: 0x060017CA RID: 6090 RVA: 0x000306A4 File Offset: 0x0002E8A4
	[Address(RVA = "0x2BF2404", Offset = "0x2BF2404", VA = "0x2BF2404")]
	[Token(Token = "0x60017CA")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Trying Getting Entilement...");
	}

	// Token: 0x060017CB RID: 6091 RVA: 0x000306C4 File Offset: 0x0002E8C4
	[Address(RVA = "0x2BF26E8", Offset = "0x2BF26E8", VA = "0x2BF26E8")]
	[Token(Token = "0x60017CB")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ENABLE");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("FingerTip");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Cannot access index {0}. Buffer size is {1}";
			return;
		}
	}

	// Token: 0x060017CC RID: 6092 RVA: 0x00030710 File Offset: 0x0002E910
	[Address(RVA = "0x2BF29CC", Offset = "0x2BF29CC", VA = "0x2BF29CC")]
	[Token(Token = "0x60017CC")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("We don't need this electrical box");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "/";
			return;
		}
	}

	// Token: 0x060017CD RID: 6093 RVA: 0x0003075C File Offset: 0x0002E95C
	[Address(RVA = "0x2BF2CA0", Offset = "0x2BF2CA0", VA = "0x2BF2CA0")]
	[Token(Token = "0x60017CD")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("This is the 1000 Bananas button, and it was just clicked");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "1BN";
			return;
		}
	}

	// Token: 0x060017CE RID: 6094 RVA: 0x000307A8 File Offset: 0x0002E9A8
	[Address(RVA = "0x2BF2F70", Offset = "0x2BF2F70", VA = "0x2BF2F70")]
	[Token(Token = "0x60017CE")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("containsStaff");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("Collided");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Added Winner Money";
			return;
		}
	}

	// Token: 0x060017CF RID: 6095 RVA: 0x000307F4 File Offset: 0x0002E9F4
	[Address(RVA = "0x2BF3248", Offset = "0x2BF3248", VA = "0x2BF3248")]
	[Token(Token = "0x60017CF")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("poweredup!");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("PlayerHead");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Meta Platform entitlement error: ";
			return;
		}
	}

	// Token: 0x060017D0 RID: 6096 RVA: 0x00030840 File Offset: 0x0002EA40
	[Token(Token = "0x60017D0")]
	[Address(RVA = "0x2BF3520", Offset = "0x2BF3520", VA = "0x2BF3520")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Tagging");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("Key");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Camera movement detected, calibrating height.";
			this.buyScript_0.int_0 = "Agreed";
			return;
		}
	}

	// Token: 0x060017D1 RID: 6097 RVA: 0x0003089C File Offset: 0x0002EA9C
	[Address(RVA = "0x2BF3804", Offset = "0x2BF3804", VA = "0x2BF3804")]
	[Token(Token = "0x60017D1")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("TurnAmount");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("TurnAmount");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "openvr";
			return;
		}
	}

	// Token: 0x060017D2 RID: 6098 RVA: 0x000308E8 File Offset: 0x0002EAE8
	[Token(Token = "0x60017D2")]
	[Address(RVA = "0x2BF3AD4", Offset = "0x2BF3AD4", VA = "0x2BF3AD4")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("/");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("INSIGNIFICANT CURRENCY");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "_Color";
			return;
		}
	}

	// Token: 0x060017D3 RID: 6099 RVA: 0x00030934 File Offset: 0x0002EB34
	[Address(RVA = "0x2BF3DB8", Offset = "0x2BF3DB8", VA = "0x2BF3DB8")]
	[Token(Token = "0x60017D3")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("https://raw.githubusercontent.com/");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("spatial");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Thumb";
			return;
		}
	}

	// Token: 0x060017D4 RID: 6100 RVA: 0x00030980 File Offset: 0x0002EB80
	[Address(RVA = "0x2BF409C", Offset = "0x2BF409C", VA = "0x2BF409C")]
	[Token(Token = "0x60017D4")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("waited for your bullshit unity grrr");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("On");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "cheese";
			return;
		}
	}

	// Token: 0x060017D5 RID: 6101 RVA: 0x000309CC File Offset: 0x0002EBCC
	[Token(Token = "0x60017D5")]
	[Address(RVA = "0x2BF4380", Offset = "0x2BF4380", VA = "0x2BF4380")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Version");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("You are on an outdated version of Capuchin. Your version is ");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Tagged";
			return;
		}
	}

	// Token: 0x060017D6 RID: 6102 RVA: 0x00030A18 File Offset: 0x0002EC18
	[Address(RVA = "0x2BF4654", Offset = "0x2BF4654", VA = "0x2BF4654")]
	[Token(Token = "0x60017D6")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Universal Render Pipeline/Lit");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("PlayerDeath");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "PlayWave";
			this.buyScript_0.int_0 = "gamemode";
			return;
		}
	}

	// Token: 0x060017D7 RID: 6103 RVA: 0x00030A74 File Offset: 0x0002EC74
	[Token(Token = "0x60017D7")]
	[Address(RVA = "0x2BF4938", Offset = "0x2BF4938", VA = "0x2BF4938")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Charged!");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("True");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "true";
			return;
		}
	}

	// Token: 0x060017D8 RID: 6104 RVA: 0x00030AC0 File Offset: 0x0002ECC0
	[Address(RVA = "0x2BF4C0C", Offset = "0x2BF4C0C", VA = "0x2BF4C0C")]
	[Token(Token = "0x60017D8")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Right Hand");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("_Tint");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Player";
			return;
		}
	}

	// Token: 0x060017D9 RID: 6105 RVA: 0x00030B0C File Offset: 0x0002ED0C
	[Address(RVA = "0x2BF4EF0", Offset = "0x2BF4EF0", VA = "0x2BF4EF0")]
	[Token(Token = "0x60017D9")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("/");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("FingerTip");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "GET";
			return;
		}
	}

	// Token: 0x060017DA RID: 6106 RVA: 0x00030B58 File Offset: 0x0002ED58
	[Token(Token = "0x60017DA")]
	[Address(RVA = "0x2BF51D4", Offset = "0x2BF51D4", VA = "0x2BF51D4")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ORGTARG");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("Failed To Join Public Room Successfully. The error is: ");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "_WobbleX";
			return;
		}
	}

	// Token: 0x060017DB RID: 6107 RVA: 0x00030BA4 File Offset: 0x0002EDA4
	[Token(Token = "0x60017DB")]
	[Address(RVA = "0x2BF54A8", Offset = "0x2BF54A8", VA = "0x2BF54A8")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("poweredup!");
			this.particleSystem_0.Play();
			this.buyScript_0.string_0 = "Display Name Changed!";
			return;
		}
	}

	// Token: 0x060017DC RID: 6108 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60017DC")]
	[Address(RVA = "0x2BF5780", Offset = "0x2BF5780", VA = "0x2BF5780")]
	public AddBananasToCart()
	{
	}

	// Token: 0x060017DD RID: 6109 RVA: 0x00030BF0 File Offset: 0x0002EDF0
	[Token(Token = "0x60017DD")]
	[Address(RVA = "0x2BF5788", Offset = "0x2BF5788", VA = "0x2BF5788")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("RainAndThunderWeather");
		if (this.genum7_0 == AddBananasToCart.GEnum7.const_0)
		{
			Debug.Log("Applying to material");
			this.particleSystem_0.Play();
			this.textMeshPro_0.m_Material = "liftoff failed!";
			return;
		}
	}

	// Token: 0x04000310 RID: 784
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000310")]
	public AddBananasToCart.GEnum7 genum7_0;

	// Token: 0x04000311 RID: 785
	[Token(Token = "0x4000311")]
	[FieldOffset(Offset = "0x20")]
	public DoorLerp doorLerp_0;

	// Token: 0x04000312 RID: 786
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000312")]
	public ParticleSystem particleSystem_0;

	// Token: 0x04000313 RID: 787
	[Token(Token = "0x4000313")]
	[FieldOffset(Offset = "0x30")]
	public TextMeshPro textMeshPro_0;

	// Token: 0x04000314 RID: 788
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000314")]
	public BuyScript buyScript_0;

	// Token: 0x020000A4 RID: 164
	[Token(Token = "0x20000A4")]
	public enum GEnum7
	{
		// Token: 0x04000316 RID: 790
		[Token(Token = "0x4000316")]
		const_0,
		// Token: 0x04000317 RID: 791
		[Token(Token = "0x4000317")]
		const_1,
		// Token: 0x04000318 RID: 792
		[Token(Token = "0x4000318")]
		const_2
	}
}
