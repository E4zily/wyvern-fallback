﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000058 RID: 88
[Token(Token = "0x2000058")]
public class DynamicParent : MonoBehaviour
{
	// Token: 0x06000C24 RID: 3108 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10C9348", Offset = "0x10C9348", VA = "0x10C9348")]
	[Token(Token = "0x6000C24")]
	private void method_0(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C25 RID: 3109 RVA: 0x0001A848 File Offset: 0x00018A48
	[Token(Token = "0x6000C25")]
	[Address(RVA = "0x10C9368", Offset = "0x10C9368", VA = "0x10C9368")]
	public void method_1()
	{
	}

	// Token: 0x06000C26 RID: 3110 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10C9508", Offset = "0x10C9508", VA = "0x10C9508")]
	[Token(Token = "0x6000C26")]
	private void method_2(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C27 RID: 3111 RVA: 0x0001A858 File Offset: 0x00018A58
	[Token(Token = "0x6000C27")]
	[Address(RVA = "0x10C9670", Offset = "0x10C9670", VA = "0x10C9670")]
	private void method_3(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C28 RID: 3112 RVA: 0x0001A870 File Offset: 0x00018A70
	[Token(Token = "0x6000C28")]
	[Address(RVA = "0x10C9798", Offset = "0x10C9798", VA = "0x10C9798")]
	public void method_4(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C29 RID: 3113 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10C9AD0", Offset = "0x10C9AD0", VA = "0x10C9AD0")]
	[Token(Token = "0x6000C29")]
	private void method_5(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C2A RID: 3114 RVA: 0x0001A890 File Offset: 0x00018A90
	[Token(Token = "0x6000C2A")]
	[Address(RVA = "0x10C9BD8", Offset = "0x10C9BD8", VA = "0x10C9BD8")]
	private void method_6(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C2B RID: 3115 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10C9940", Offset = "0x10C9940", VA = "0x10C9940")]
	[Token(Token = "0x6000C2B")]
	private void method_7(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C2C RID: 3116 RVA: 0x0001A858 File Offset: 0x00018A58
	[Token(Token = "0x6000C2C")]
	[Address(RVA = "0x10C9D00", Offset = "0x10C9D00", VA = "0x10C9D00")]
	private void method_8(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C2D RID: 3117 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000C2D")]
	[Address(RVA = "0x10C9CA0", Offset = "0x10C9CA0", VA = "0x10C9CA0")]
	private void method_9(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C2E RID: 3118 RVA: 0x0001A870 File Offset: 0x00018A70
	[Address(RVA = "0x10C9DC8", Offset = "0x10C9DC8", VA = "0x10C9DC8")]
	[Token(Token = "0x6000C2E")]
	public void method_10(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C2F RID: 3119 RVA: 0x0001A848 File Offset: 0x00018A48
	[Token(Token = "0x6000C2F")]
	[Address(RVA = "0x10C9F6C", Offset = "0x10C9F6C", VA = "0x10C9F6C")]
	public void method_11()
	{
	}

	// Token: 0x06000C30 RID: 3120 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Token(Token = "0x6000C30")]
	[Address(RVA = "0x10CA10C", Offset = "0x10CA10C", VA = "0x10CA10C")]
	public void method_12(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C31 RID: 3121 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CA37C", Offset = "0x10CA37C", VA = "0x10CA37C")]
	[Token(Token = "0x6000C31")]
	private void method_13(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C32 RID: 3122 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Token(Token = "0x6000C32")]
	[Address(RVA = "0x10CA444", Offset = "0x10CA444", VA = "0x10CA444")]
	public void method_14(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C33 RID: 3123 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000C33")]
	[Address(RVA = "0x10C95F0", Offset = "0x10C95F0", VA = "0x10C95F0")]
	private void method_15(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C34 RID: 3124 RVA: 0x0001A8C0 File Offset: 0x00018AC0
	[Address(RVA = "0x10C9440", Offset = "0x10C9440", VA = "0x10C9440")]
	[Token(Token = "0x6000C34")]
	private void method_16(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C35 RID: 3125 RVA: 0x0001A870 File Offset: 0x00018A70
	[Address(RVA = "0x10CA77C", Offset = "0x10CA77C", VA = "0x10CA77C")]
	[Token(Token = "0x6000C35")]
	public void method_17(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C36 RID: 3126 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000C36")]
	[Address(RVA = "0x10C9630", Offset = "0x10C9630", VA = "0x10C9630")]
	private void method_18(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C37 RID: 3127 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000C37")]
	[Address(RVA = "0x10C9610", Offset = "0x10C9610", VA = "0x10C9610")]
	private void method_19(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C38 RID: 3128 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Address(RVA = "0x10CA9E8", Offset = "0x10CA9E8", VA = "0x10CA9E8")]
	[Token(Token = "0x6000C38")]
	public void method_20(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C39 RID: 3129 RVA: 0x0001A870 File Offset: 0x00018A70
	[Token(Token = "0x6000C39")]
	[Address(RVA = "0x10CAB8C", Offset = "0x10CAB8C", VA = "0x10CAB8C")]
	public void method_21(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C3A RID: 3130 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000C3A")]
	[Address(RVA = "0x10C9778", Offset = "0x10C9778", VA = "0x10C9778")]
	private void method_22(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C3B RID: 3131 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CA920", Offset = "0x10CA920", VA = "0x10CA920")]
	[Token(Token = "0x6000C3B")]
	private void method_23(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C3C RID: 3132 RVA: 0x0001A8D8 File Offset: 0x00018AD8
	[Address(RVA = "0x10CADFC", Offset = "0x10CADFC", VA = "0x10CADFC")]
	[Token(Token = "0x6000C3C")]
	public void method_24()
	{
	}

	// Token: 0x06000C3D RID: 3133 RVA: 0x0001A858 File Offset: 0x00018A58
	[Token(Token = "0x6000C3D")]
	[Address(RVA = "0x10CAEB0", Offset = "0x10CAEB0", VA = "0x10CAEB0")]
	private void method_25(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C3E RID: 3134 RVA: 0x0001A8D8 File Offset: 0x00018AD8
	[Token(Token = "0x6000C3E")]
	[Address(RVA = "0x10CAF78", Offset = "0x10CAF78", VA = "0x10CAF78")]
	public void method_26()
	{
	}

	// Token: 0x06000C3F RID: 3135 RVA: 0x0001A858 File Offset: 0x00018A58
	[Token(Token = "0x6000C3F")]
	[Address(RVA = "0x10CA5EC", Offset = "0x10CA5EC", VA = "0x10CA5EC")]
	private void method_27(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C40 RID: 3136 RVA: 0x0001A870 File Offset: 0x00018A70
	[Address(RVA = "0x10CB114", Offset = "0x10CB114", VA = "0x10CB114")]
	[Token(Token = "0x6000C40")]
	public void method_28(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C41 RID: 3137 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10CB0F4", Offset = "0x10CB0F4", VA = "0x10CB0F4")]
	[Token(Token = "0x6000C41")]
	private void method_29(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C42 RID: 3138 RVA: 0x0001A8D8 File Offset: 0x00018AD8
	[Token(Token = "0x6000C42")]
	[Address(RVA = "0x10CB380", Offset = "0x10CB380", VA = "0x10CB380")]
	public void method_30()
	{
	}

	// Token: 0x06000C43 RID: 3139 RVA: 0x0001A8E8 File Offset: 0x00018AE8
	[Token(Token = "0x6000C43")]
	[Address(RVA = "0x10CB438", Offset = "0x10CB438", VA = "0x10CB438")]
	public void method_31(string string_0)
	{
		List.Enumerator enumerator;
		enumerator.MoveNext();
	}

	// Token: 0x06000C44 RID: 3140 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Token(Token = "0x6000C44")]
	[Address(RVA = "0x10CB6A8", Offset = "0x10CB6A8", VA = "0x10CB6A8")]
	public void method_32(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C45 RID: 3141 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Address(RVA = "0x10CB918", Offset = "0x10CB918", VA = "0x10CB918")]
	[Token(Token = "0x6000C45")]
	public void method_33(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C46 RID: 3142 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000C46")]
	[Address(RVA = "0x10C9738", Offset = "0x10C9738", VA = "0x10C9738")]
	private void method_34(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C47 RID: 3143 RVA: 0x0001A8FC File Offset: 0x00018AFC
	[Token(Token = "0x6000C47")]
	[Address(RVA = "0x10CBB84", Offset = "0x10CBB84", VA = "0x10CBB84")]
	public void method_35()
	{
	}

	// Token: 0x06000C48 RID: 3144 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Token(Token = "0x6000C48")]
	[Address(RVA = "0x10CBC38", Offset = "0x10CBC38", VA = "0x10CBC38")]
	public void method_36(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C49 RID: 3145 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Token(Token = "0x6000C49")]
	[Address(RVA = "0x10CBDE0", Offset = "0x10CBDE0", VA = "0x10CBDE0")]
	public void method_37(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C4A RID: 3146 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CB5E0", Offset = "0x10CB5E0", VA = "0x10CB5E0")]
	[Token(Token = "0x6000C4A")]
	private void method_38(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C4B RID: 3147 RVA: 0x0001A848 File Offset: 0x00018A48
	[Address(RVA = "0x10CC114", Offset = "0x10CC114", VA = "0x10CC114")]
	[Token(Token = "0x6000C4B")]
	public void Awake()
	{
	}

	// Token: 0x06000C4C RID: 3148 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CC1E8", Offset = "0x10CC1E8", VA = "0x10CC1E8")]
	[Token(Token = "0x6000C4C")]
	private void method_39(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C4D RID: 3149 RVA: 0x0001A90C File Offset: 0x00018B0C
	[Token(Token = "0x6000C4D")]
	[Address(RVA = "0x10CC2B0", Offset = "0x10CC2B0", VA = "0x10CC2B0")]
	public DynamicParent()
	{
		List<GameObject> list = new List();
		this.list_0 = list;
		Dictionary<string, GameObject> dictionary;
		this.dictionary_0 = dictionary;
		base..ctor();
	}

	// Token: 0x06000C4E RID: 3150 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CC04C", Offset = "0x10CC04C", VA = "0x10CC04C")]
	[Token(Token = "0x6000C4E")]
	private void method_40(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C4F RID: 3151 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Token(Token = "0x6000C4F")]
	[Address(RVA = "0x10CC380", Offset = "0x10CC380", VA = "0x10CC380")]
	public void method_41(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C50 RID: 3152 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000C50")]
	[Address(RVA = "0x10C9650", Offset = "0x10C9650", VA = "0x10C9650")]
	private void method_42(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C51 RID: 3153 RVA: 0x0001A8D8 File Offset: 0x00018AD8
	[Token(Token = "0x6000C51")]
	[Address(RVA = "0x10CC524", Offset = "0x10CC524", VA = "0x10CC524")]
	public void method_43()
	{
	}

	// Token: 0x06000C52 RID: 3154 RVA: 0x0001A8D8 File Offset: 0x00018AD8
	[Token(Token = "0x6000C52")]
	[Address(RVA = "0x10CC5D8", Offset = "0x10CC5D8", VA = "0x10CC5D8")]
	public void method_44()
	{
	}

	// Token: 0x06000C53 RID: 3155 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Address(RVA = "0x10CC690", Offset = "0x10CC690", VA = "0x10CC690")]
	[Token(Token = "0x6000C53")]
	public void method_45(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C54 RID: 3156 RVA: 0x0001A848 File Offset: 0x00018A48
	[Token(Token = "0x6000C54")]
	[Address(RVA = "0x10CC834", Offset = "0x10CC834", VA = "0x10CC834")]
	public void method_46()
	{
	}

	// Token: 0x06000C55 RID: 3157 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Token(Token = "0x6000C55")]
	[Address(RVA = "0x10CC908", Offset = "0x10CC908", VA = "0x10CC908")]
	public void method_47(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C56 RID: 3158 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10C95D0", Offset = "0x10C95D0", VA = "0x10C95D0")]
	[Token(Token = "0x6000C56")]
	private void method_48(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C57 RID: 3159 RVA: 0x0001A848 File Offset: 0x00018A48
	[Token(Token = "0x6000C57")]
	[Address(RVA = "0x10CCAAC", Offset = "0x10CCAAC", VA = "0x10CCAAC")]
	public void method_49()
	{
	}

	// Token: 0x06000C58 RID: 3160 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000C58")]
	[Address(RVA = "0x10C9BB8", Offset = "0x10C9BB8", VA = "0x10C9BB8")]
	private void method_50(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C59 RID: 3161 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10C9B98", Offset = "0x10C9B98", VA = "0x10C9B98")]
	[Token(Token = "0x6000C59")]
	private void method_51(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C5A RID: 3162 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Token(Token = "0x6000C5A")]
	[Address(RVA = "0x10CCB80", Offset = "0x10CCB80", VA = "0x10CCB80")]
	public void method_52(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C5B RID: 3163 RVA: 0x0001A848 File Offset: 0x00018A48
	[Token(Token = "0x6000C5B")]
	[Address(RVA = "0x10CCD24", Offset = "0x10CCD24", VA = "0x10CCD24")]
	public void method_53()
	{
	}

	// Token: 0x06000C5C RID: 3164 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Address(RVA = "0x10CCEC0", Offset = "0x10CCEC0", VA = "0x10CCEC0")]
	[Token(Token = "0x6000C5C")]
	public void method_54(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C5D RID: 3165 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Token(Token = "0x6000C5D")]
	[Address(RVA = "0x10CD068", Offset = "0x10CD068", VA = "0x10CD068")]
	public void method_55(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C5E RID: 3166 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CCDF8", Offset = "0x10CCDF8", VA = "0x10CCDF8")]
	[Token(Token = "0x6000C5E")]
	private void method_56(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C5F RID: 3167 RVA: 0x0001A858 File Offset: 0x00018A58
	[Token(Token = "0x6000C5F")]
	[Address(RVA = "0x10CA044", Offset = "0x10CA044", VA = "0x10CA044")]
	private void method_57(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C60 RID: 3168 RVA: 0x0001A870 File Offset: 0x00018A70
	[Token(Token = "0x6000C60")]
	[Address(RVA = "0x10CD20C", Offset = "0x10CD20C", VA = "0x10CD20C")]
	public void method_58(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C61 RID: 3169 RVA: 0x0001A848 File Offset: 0x00018A48
	[Address(RVA = "0x10CD3B4", Offset = "0x10CD3B4", VA = "0x10CD3B4")]
	[Token(Token = "0x6000C61")]
	public void method_59()
	{
	}

	// Token: 0x06000C62 RID: 3170 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Token(Token = "0x6000C62")]
	[Address(RVA = "0x10CD48C", Offset = "0x10CD48C", VA = "0x10CD48C")]
	public void method_60(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C63 RID: 3171 RVA: 0x0001A8D8 File Offset: 0x00018AD8
	[Token(Token = "0x6000C63")]
	[Address(RVA = "0x10CD630", Offset = "0x10CD630", VA = "0x10CD630")]
	public void method_61()
	{
	}

	// Token: 0x06000C64 RID: 3172 RVA: 0x0001A8A0 File Offset: 0x00018AA0
	[Address(RVA = "0x10CD6E8", Offset = "0x10CD6E8", VA = "0x10CD6E8")]
	[Token(Token = "0x6000C64")]
	public void method_62(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C65 RID: 3173 RVA: 0x0001A8D8 File Offset: 0x00018AD8
	[Address(RVA = "0x10CD890", Offset = "0x10CD890", VA = "0x10CD890")]
	[Token(Token = "0x6000C65")]
	public void method_63()
	{
	}

	// Token: 0x06000C66 RID: 3174 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CB850", Offset = "0x10CB850", VA = "0x10CB850")]
	[Token(Token = "0x6000C66")]
	private void method_64(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C67 RID: 3175 RVA: 0x0001A858 File Offset: 0x00018A58
	[Token(Token = "0x6000C67")]
	[Address(RVA = "0x10CAD34", Offset = "0x10CAD34", VA = "0x10CAD34")]
	private void method_65(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C68 RID: 3176 RVA: 0x0001A870 File Offset: 0x00018A70
	[Token(Token = "0x6000C68")]
	[Address(RVA = "0x10CD944", Offset = "0x10CD944", VA = "0x10CD944")]
	public void method_66(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C69 RID: 3177 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000C69")]
	[Address(RVA = "0x10C9CE0", Offset = "0x10C9CE0", VA = "0x10C9CE0")]
	private void method_67(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C6A RID: 3178 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CA2B4", Offset = "0x10CA2B4", VA = "0x10CA2B4")]
	[Token(Token = "0x6000C6A")]
	private void method_68(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C6B RID: 3179 RVA: 0x0001A934 File Offset: 0x00018B34
	[Token(Token = "0x6000C6B")]
	[Address(RVA = "0x10CDAE8", Offset = "0x10CDAE8", VA = "0x10CDAE8")]
	public void method_69(string string_0)
	{
		this.list_0.GetEnumerator().MoveNext();
	}

	// Token: 0x06000C6C RID: 3180 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CBABC", Offset = "0x10CBABC", VA = "0x10CBABC")]
	[Token(Token = "0x6000C6C")]
	private void method_70(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C6D RID: 3181 RVA: 0x0001A858 File Offset: 0x00018A58
	[Token(Token = "0x6000C6D")]
	[Address(RVA = "0x10CB2B8", Offset = "0x10CB2B8", VA = "0x10CB2B8")]
	private void method_71(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C6E RID: 3182 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CA6B4", Offset = "0x10CA6B4", VA = "0x10CA6B4")]
	[Token(Token = "0x6000C6E")]
	private void method_72(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C6F RID: 3183 RVA: 0x0001A848 File Offset: 0x00018A48
	[Token(Token = "0x6000C6F")]
	[Address(RVA = "0x10CDC8C", Offset = "0x10CDC8C", VA = "0x10CDC8C")]
	public void method_73()
	{
	}

	// Token: 0x06000C70 RID: 3184 RVA: 0x0001A848 File Offset: 0x00018A48
	[Token(Token = "0x6000C70")]
	[Address(RVA = "0x10CDD60", Offset = "0x10CDD60", VA = "0x10CDD60")]
	public void method_74()
	{
	}

	// Token: 0x06000C71 RID: 3185 RVA: 0x0001A848 File Offset: 0x00018A48
	[Address(RVA = "0x10CDE38", Offset = "0x10CDE38", VA = "0x10CDE38")]
	[Token(Token = "0x6000C71")]
	public void method_75()
	{
	}

	// Token: 0x06000C72 RID: 3186 RVA: 0x0001A954 File Offset: 0x00018B54
	[Token(Token = "0x6000C72")]
	[Address(RVA = "0x10CB02C", Offset = "0x10CB02C", VA = "0x10CB02C")]
	private void method_76(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C73 RID: 3187 RVA: 0x0001A848 File Offset: 0x00018A48
	[Token(Token = "0x6000C73")]
	[Address(RVA = "0x10CDF0C", Offset = "0x10CDF0C", VA = "0x10CDF0C")]
	public void method_77()
	{
	}

	// Token: 0x06000C74 RID: 3188 RVA: 0x0001A858 File Offset: 0x00018A58
	[Token(Token = "0x6000C74")]
	[Address(RVA = "0x10C9A08", Offset = "0x10C9A08", VA = "0x10C9A08")]
	private void method_78(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C75 RID: 3189 RVA: 0x0001A858 File Offset: 0x00018A58
	[Address(RVA = "0x10CBF84", Offset = "0x10CBF84", VA = "0x10CBF84")]
	[Token(Token = "0x6000C75")]
	private void method_79(GameObject gameObject_2, bool bool_0)
	{
		long active = 0L;
		gameObject_2.SetActive(active != 0L);
	}

	// Token: 0x06000C76 RID: 3190 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10C9CC0", Offset = "0x10C9CC0", VA = "0x10C9CC0")]
	[Token(Token = "0x6000C76")]
	private void method_80(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C77 RID: 3191 RVA: 0x0001A954 File Offset: 0x00018B54
	[Token(Token = "0x6000C77")]
	[Address(RVA = "0x10CDFE0", Offset = "0x10CDFE0", VA = "0x10CDFE0")]
	private void method_81(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x06000C78 RID: 3192 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000C78")]
	[Address(RVA = "0x10C9758", Offset = "0x10C9758", VA = "0x10C9758")]
	private void method_82(GameObject gameObject_2, bool bool_0)
	{
	}

	// Token: 0x040001C4 RID: 452
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001C4")]
	public GameObject[] gameObject_0;

	// Token: 0x040001C5 RID: 453
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001C5")]
	public GameObject gameObject_1;

	// Token: 0x040001C6 RID: 454
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001C6")]
	public List<GameObject> list_0;

	// Token: 0x040001C7 RID: 455
	[Token(Token = "0x40001C7")]
	[FieldOffset(Offset = "0x30")]
	public Dictionary<string, GameObject> dictionary_0;
}
