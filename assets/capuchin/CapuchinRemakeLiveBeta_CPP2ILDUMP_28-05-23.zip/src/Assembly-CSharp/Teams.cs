﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x02000012 RID: 18
[Token(Token = "0x2000012")]
public class Teams : MonoBehaviourPunCallbacks
{
	// Token: 0x060001FE RID: 510 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D30A84", Offset = "0x2D30A84", VA = "0x2D30A84")]
	[Token(Token = "0x60001FE")]
	public IEnumerator method_0()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060001FF RID: 511 RVA: 0x00008E1C File Offset: 0x0000701C
	[Address(RVA = "0x2D30AFC", Offset = "0x2D30AFC", VA = "0x2D30AFC")]
	[Token(Token = "0x60001FF")]
	public IEnumerator method_1()
	{
		new Teams.Class1((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x06000200 RID: 512 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D30B74", Offset = "0x2D30B74", VA = "0x2D30B74")]
	[Token(Token = "0x6000200")]
	public IEnumerator method_2()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000201 RID: 513 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D30BEC", Offset = "0x2D30BEC", VA = "0x2D30BEC")]
	[Token(Token = "0x6000201")]
	public IEnumerator method_3()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000202 RID: 514 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D30C64", Offset = "0x2D30C64", VA = "0x2D30C64")]
	[Token(Token = "0x6000202")]
	public IEnumerator method_4()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000203 RID: 515 RVA: 0x00008E40 File Offset: 0x00007040
	[Address(RVA = "0x2D30CDC", Offset = "0x2D30CDC", VA = "0x2D30CDC")]
	[Token(Token = "0x6000203")]
	public void method_5()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000204 RID: 516 RVA: 0x00008E80 File Offset: 0x00007080
	[Address(RVA = "0x2D30DF0", Offset = "0x2D30DF0", VA = "0x2D30DF0")]
	[Token(Token = "0x6000204")]
	public void method_6()
	{
		for (;;)
		{
			TagManager tagManager;
			if (!tagManager.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000205 RID: 517 RVA: 0x00008EB0 File Offset: 0x000070B0
	[Address(RVA = "0x2D30F18", Offset = "0x2D30F18", VA = "0x2D30F18")]
	[Token(Token = "0x6000205")]
	public void method_7()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000206 RID: 518 RVA: 0x00008EF0 File Offset: 0x000070F0
	[Address(RVA = "0x2D3102C", Offset = "0x2D3102C", VA = "0x2D3102C", Slot = "43")]
	[Token(Token = "0x6000206")]
	public override void OnPlayerLeftRoom(Player otherPlayer)
	{
		IEnumerator routine = this.method_28();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000207 RID: 519 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x6000207")]
	[Address(RVA = "0x2D310D0", Offset = "0x2D310D0", VA = "0x2D310D0")]
	public IEnumerator method_8()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000208 RID: 520 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D31148", Offset = "0x2D31148", VA = "0x2D31148")]
	[Token(Token = "0x6000208")]
	public IEnumerator method_9()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000209 RID: 521 RVA: 0x00008E1C File Offset: 0x0000701C
	[Token(Token = "0x6000209")]
	[Address(RVA = "0x2D311C0", Offset = "0x2D311C0", VA = "0x2D311C0")]
	public IEnumerator method_10()
	{
		new Teams.Class1((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x0600020A RID: 522 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D31238", Offset = "0x2D31238", VA = "0x2D31238")]
	[Token(Token = "0x600020A")]
	public IEnumerator method_11()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600020B RID: 523 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D312B0", Offset = "0x2D312B0", VA = "0x2D312B0")]
	[Token(Token = "0x600020B")]
	public IEnumerator method_12()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600020C RID: 524 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x600020C")]
	[Address(RVA = "0x2D31328", Offset = "0x2D31328", VA = "0x2D31328")]
	public IEnumerator method_13()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600020D RID: 525 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D313A0", Offset = "0x2D313A0", VA = "0x2D313A0")]
	[Token(Token = "0x600020D")]
	public IEnumerator method_14()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600020E RID: 526 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x600020E")]
	[Address(RVA = "0x2D31418", Offset = "0x2D31418", VA = "0x2D31418")]
	public IEnumerator method_15()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600020F RID: 527 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x600020F")]
	[Address(RVA = "0x2D31490", Offset = "0x2D31490", VA = "0x2D31490")]
	public IEnumerator method_16()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000210 RID: 528 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D31508", Offset = "0x2D31508", VA = "0x2D31508")]
	[Token(Token = "0x6000210")]
	public IEnumerator method_17()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000211 RID: 529 RVA: 0x00008E40 File Offset: 0x00007040
	[Address(RVA = "0x2D31580", Offset = "0x2D31580", VA = "0x2D31580")]
	[Token(Token = "0x6000211")]
	public void method_18()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000212 RID: 530 RVA: 0x00008E40 File Offset: 0x00007040
	[Address(RVA = "0x2D316A8", Offset = "0x2D316A8", VA = "0x2D316A8")]
	[Token(Token = "0x6000212")]
	public void method_19()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000213 RID: 531 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x6000213")]
	[Address(RVA = "0x2D317D0", Offset = "0x2D317D0", VA = "0x2D317D0")]
	public IEnumerator method_20()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000214 RID: 532 RVA: 0x00008EB0 File Offset: 0x000070B0
	[Address(RVA = "0x2D31848", Offset = "0x2D31848", VA = "0x2D31848")]
	[Token(Token = "0x6000214")]
	public void method_21()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000215 RID: 533 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x6000215")]
	[Address(RVA = "0x2D31970", Offset = "0x2D31970", VA = "0x2D31970")]
	public IEnumerator method_22()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000216 RID: 534 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x6000216")]
	[Address(RVA = "0x2D319E8", Offset = "0x2D319E8", VA = "0x2D319E8")]
	public IEnumerator method_23()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000217 RID: 535 RVA: 0x00008F0C File Offset: 0x0000710C
	[Address(RVA = "0x2D31A60", Offset = "0x2D31A60", VA = "0x2D31A60")]
	[Token(Token = "0x6000217")]
	public void method_24()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				return;
			}
		}
		while (this.renderer_0 != null);
	}

	// Token: 0x06000218 RID: 536 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x6000218")]
	[Address(RVA = "0x2D31B48", Offset = "0x2D31B48", VA = "0x2D31B48")]
	public IEnumerator method_25()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000219 RID: 537 RVA: 0x00008F3C File Offset: 0x0000713C
	[Address(RVA = "0x2D31BC0", Offset = "0x2D31BC0", VA = "0x2D31BC0")]
	[Token(Token = "0x6000219")]
	public void method_26()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x0600021A RID: 538 RVA: 0x00008F3C File Offset: 0x0000713C
	[Address(RVA = "0x2D31CE8", Offset = "0x2D31CE8", VA = "0x2D31CE8")]
	[Token(Token = "0x600021A")]
	public void method_27()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x0600021B RID: 539 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x600021B")]
	[Address(RVA = "0x2D31058", Offset = "0x2D31058", VA = "0x2D31058")]
	public IEnumerator method_28()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600021C RID: 540 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x600021C")]
	[Address(RVA = "0x2D31DFC", Offset = "0x2D31DFC", VA = "0x2D31DFC")]
	public IEnumerator method_29()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600021D RID: 541 RVA: 0x00008F0C File Offset: 0x0000710C
	[Token(Token = "0x600021D")]
	[Address(RVA = "0x2D31E74", Offset = "0x2D31E74", VA = "0x2D31E74")]
	public void method_30()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				return;
			}
		}
		while (this.renderer_0 != null);
	}

	// Token: 0x0600021E RID: 542 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D31F5C", Offset = "0x2D31F5C", VA = "0x2D31F5C")]
	[Token(Token = "0x600021E")]
	public IEnumerator method_31()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600021F RID: 543 RVA: 0x00008F0C File Offset: 0x0000710C
	[Address(RVA = "0x2D31FD4", Offset = "0x2D31FD4", VA = "0x2D31FD4")]
	[Token(Token = "0x600021F")]
	public void method_32()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				return;
			}
		}
		while (this.renderer_0 != null);
	}

	// Token: 0x06000220 RID: 544 RVA: 0x00008F0C File Offset: 0x0000710C
	[Address(RVA = "0x2D320BC", Offset = "0x2D320BC", VA = "0x2D320BC")]
	[Token(Token = "0x6000220")]
	public void method_33()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				return;
			}
		}
		while (this.renderer_0 != null);
	}

	// Token: 0x06000221 RID: 545 RVA: 0x00008EB0 File Offset: 0x000070B0
	[Address(RVA = "0x2D321A4", Offset = "0x2D321A4", VA = "0x2D321A4")]
	[Token(Token = "0x6000221")]
	public void method_34()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000222 RID: 546 RVA: 0x00008F7C File Offset: 0x0000717C
	[Address(RVA = "0x2D322B8", Offset = "0x2D322B8", VA = "0x2D322B8")]
	[Token(Token = "0x6000222")]
	public void method_35()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000223 RID: 547 RVA: 0x00008EB0 File Offset: 0x000070B0
	[Address(RVA = "0x2D323E0", Offset = "0x2D323E0", VA = "0x2D323E0")]
	[Token(Token = "0x6000223")]
	public void method_36()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000224 RID: 548 RVA: 0x00008EF0 File Offset: 0x000070F0
	[Token(Token = "0x6000224")]
	[Address(RVA = "0x2D324F4", Offset = "0x2D324F4", VA = "0x2D324F4", Slot = "42")]
	public override void OnPlayerEnteredRoom(Player newPlayer)
	{
		IEnumerator routine = this.method_28();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000225 RID: 549 RVA: 0x00008FBC File Offset: 0x000071BC
	[Address(RVA = "0x2D32520", Offset = "0x2D32520", VA = "0x2D32520", Slot = "41")]
	[Token(Token = "0x6000225")]
	public override void OnJoinedRoom()
	{
		this.method_28();
	}

	// Token: 0x06000226 RID: 550 RVA: 0x00008FD0 File Offset: 0x000071D0
	[Token(Token = "0x6000226")]
	[Address(RVA = "0x2D3254C", Offset = "0x2D3254C", VA = "0x2D3254C")]
	public void method_37()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000227 RID: 551 RVA: 0x00008E40 File Offset: 0x00007040
	[Address(RVA = "0x2D32660", Offset = "0x2D32660", VA = "0x2D32660")]
	[Token(Token = "0x6000227")]
	public void method_38()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000228 RID: 552 RVA: 0x00009010 File Offset: 0x00007210
	[Token(Token = "0x6000228")]
	[Address(RVA = "0x2D32788", Offset = "0x2D32788", VA = "0x2D32788")]
	public IEnumerator method_39()
	{
		Teams.Class1 @class;
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000229 RID: 553 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D32800", Offset = "0x2D32800", VA = "0x2D32800")]
	[Token(Token = "0x6000229")]
	public IEnumerator method_40()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600022A RID: 554 RVA: 0x0000902C File Offset: 0x0000722C
	[Token(Token = "0x600022A")]
	[Address(RVA = "0x2D32878", Offset = "0x2D32878", VA = "0x2D32878")]
	public void method_41()
	{
		TagManager tagManager;
		if (tagManager.bool_0)
		{
			return;
		}
	}

	// Token: 0x0600022B RID: 555 RVA: 0x00008EF0 File Offset: 0x000070F0
	[Address(RVA = "0x2D32960", Offset = "0x2D32960", VA = "0x2D32960", Slot = "32")]
	[Token(Token = "0x600022B")]
	public override void OnMasterClientSwitched(Player newMasterClient)
	{
		IEnumerator routine = this.method_28();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600022C RID: 556 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D3298C", Offset = "0x2D3298C", VA = "0x2D3298C")]
	[Token(Token = "0x600022C")]
	public IEnumerator method_42()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600022D RID: 557 RVA: 0x00008F0C File Offset: 0x0000710C
	[Address(RVA = "0x2D32A04", Offset = "0x2D32A04", VA = "0x2D32A04")]
	[Token(Token = "0x600022D")]
	public void method_43()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				return;
			}
		}
		while (this.renderer_0 != null);
	}

	// Token: 0x0600022E RID: 558 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D32AEC", Offset = "0x2D32AEC", VA = "0x2D32AEC")]
	[Token(Token = "0x600022E")]
	public IEnumerator method_44()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600022F RID: 559 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D32B64", Offset = "0x2D32B64", VA = "0x2D32B64")]
	[Token(Token = "0x600022F")]
	public IEnumerator method_45()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000230 RID: 560 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x6000230")]
	[Address(RVA = "0x2D32BDC", Offset = "0x2D32BDC", VA = "0x2D32BDC")]
	public IEnumerator method_46()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000231 RID: 561 RVA: 0x00008E40 File Offset: 0x00007040
	[Address(RVA = "0x2D32C54", Offset = "0x2D32C54", VA = "0x2D32C54")]
	[Token(Token = "0x6000231")]
	public void method_47()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000232 RID: 562 RVA: 0x00008E40 File Offset: 0x00007040
	[Address(RVA = "0x2D32D7C", Offset = "0x2D32D7C", VA = "0x2D32D7C")]
	[Token(Token = "0x6000232")]
	public void method_48()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000233 RID: 563 RVA: 0x00008EB0 File Offset: 0x000070B0
	[Token(Token = "0x6000233")]
	[Address(RVA = "0x2D32E90", Offset = "0x2D32E90", VA = "0x2D32E90")]
	public void method_49()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000234 RID: 564 RVA: 0x00008E40 File Offset: 0x00007040
	[Address(RVA = "0x2D32FA4", Offset = "0x2D32FA4", VA = "0x2D32FA4")]
	[Token(Token = "0x6000234")]
	public void method_50()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000235 RID: 565 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D330B8", Offset = "0x2D330B8", VA = "0x2D330B8")]
	[Token(Token = "0x6000235")]
	public IEnumerator method_51()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000236 RID: 566 RVA: 0x00009044 File Offset: 0x00007244
	[Address(RVA = "0x2D33130", Offset = "0x2D33130", VA = "0x2D33130")]
	[Token(Token = "0x6000236")]
	public void method_52()
	{
		TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
		if (component.bool_0)
		{
			return;
		}
	}

	// Token: 0x06000237 RID: 567 RVA: 0x00008EB0 File Offset: 0x000070B0
	[Token(Token = "0x6000237")]
	[Address(RVA = "0x2D33218", Offset = "0x2D33218", VA = "0x2D33218")]
	public void method_53()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000238 RID: 568 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x6000238")]
	[Address(RVA = "0x2D3332C", Offset = "0x2D3332C", VA = "0x2D3332C")]
	public IEnumerator method_54()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000239 RID: 569 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D333A4", Offset = "0x2D333A4", VA = "0x2D333A4")]
	[Token(Token = "0x6000239")]
	public IEnumerator method_55()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600023A RID: 570 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D3341C", Offset = "0x2D3341C", VA = "0x2D3341C")]
	[Token(Token = "0x600023A")]
	public IEnumerator method_56()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600023B RID: 571 RVA: 0x00008F3C File Offset: 0x0000713C
	[Token(Token = "0x600023B")]
	[Address(RVA = "0x2D33494", Offset = "0x2D33494", VA = "0x2D33494")]
	public void method_57()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x0600023C RID: 572 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D335A8", Offset = "0x2D335A8", VA = "0x2D335A8")]
	[Token(Token = "0x600023C")]
	public IEnumerator method_58()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600023D RID: 573 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D33620", Offset = "0x2D33620", VA = "0x2D33620")]
	[Token(Token = "0x600023D")]
	public void method_59()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600023E RID: 574 RVA: 0x00008F0C File Offset: 0x0000710C
	[Token(Token = "0x600023E")]
	[Address(RVA = "0x2D33748", Offset = "0x2D33748", VA = "0x2D33748")]
	public void method_60()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				return;
			}
		}
		while (this.renderer_0 != null);
	}

	// Token: 0x0600023F RID: 575 RVA: 0x00008F3C File Offset: 0x0000713C
	[Token(Token = "0x600023F")]
	[Address(RVA = "0x2D33830", Offset = "0x2D33830", VA = "0x2D33830")]
	public void method_61()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000240 RID: 576 RVA: 0x0000906C File Offset: 0x0000726C
	[Token(Token = "0x6000240")]
	[Address(RVA = "0x2D33944", Offset = "0x2D33944", VA = "0x2D33944")]
	public void method_62()
	{
		TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
		Renderer[] array;
		if (component.bool_0)
		{
			array = this.renderer_0;
			while (array != null)
			{
			}
			return;
		}
		while (array != null)
		{
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000241 RID: 577 RVA: 0x00008E40 File Offset: 0x00007040
	[Address(RVA = "0x2D33A6C", Offset = "0x2D33A6C", VA = "0x2D33A6C")]
	[Token(Token = "0x6000241")]
	public void method_63()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000242 RID: 578 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Token(Token = "0x6000242")]
	[Address(RVA = "0x2D33B80", Offset = "0x2D33B80", VA = "0x2D33B80")]
	public IEnumerator method_64()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000243 RID: 579 RVA: 0x0000208D File Offset: 0x0000028D
	[Token(Token = "0x6000243")]
	[Address(RVA = "0x2D33BF8", Offset = "0x2D33BF8", VA = "0x2D33BF8")]
	public Teams()
	{
	}

	// Token: 0x06000244 RID: 580 RVA: 0x00008F0C File Offset: 0x0000710C
	[Address(RVA = "0x2D33C00", Offset = "0x2D33C00", VA = "0x2D33C00")]
	[Token(Token = "0x6000244")]
	public void method_65()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				return;
			}
		}
		while (this.renderer_0 != null);
	}

	// Token: 0x06000245 RID: 581 RVA: 0x00008F7C File Offset: 0x0000717C
	[Address(RVA = "0x2D33CE8", Offset = "0x2D33CE8", VA = "0x2D33CE8")]
	[Token(Token = "0x6000245")]
	public void method_66()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000246 RID: 582 RVA: 0x00008F0C File Offset: 0x0000710C
	[Token(Token = "0x6000246")]
	[Address(RVA = "0x2D33E10", Offset = "0x2D33E10", VA = "0x2D33E10")]
	public void method_67()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				return;
			}
		}
		while (this.renderer_0 != null);
	}

	// Token: 0x06000247 RID: 583 RVA: 0x00008F3C File Offset: 0x0000713C
	[Address(RVA = "0x2D33EF8", Offset = "0x2D33EF8", VA = "0x2D33EF8")]
	[Token(Token = "0x6000247")]
	public void method_68()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000248 RID: 584 RVA: 0x00008F0C File Offset: 0x0000710C
	[Address(RVA = "0x2D3400C", Offset = "0x2D3400C", VA = "0x2D3400C")]
	[Token(Token = "0x6000248")]
	public void method_69()
	{
		do
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				return;
			}
		}
		while (this.renderer_0 != null);
	}

	// Token: 0x06000249 RID: 585 RVA: 0x00008E40 File Offset: 0x00007040
	[Address(RVA = "0x2D340F4", Offset = "0x2D340F4", VA = "0x2D340F4")]
	[Token(Token = "0x6000249")]
	public void method_70()
	{
		for (;;)
		{
			TagManager component = NetworkPlayerSpawner.networkPlayerSpawner_0.gameObject_0.GetComponent<TagManager>();
			if (!component.bool_0)
			{
				if (this.renderer_0 == null)
				{
					break;
				}
			}
			else if (this.renderer_0 == null)
			{
				return;
			}
		}
		throw new NullReferenceException();
	}

	// Token: 0x0600024A RID: 586 RVA: 0x00009010 File Offset: 0x00007210
	[Token(Token = "0x600024A")]
	[Address(RVA = "0x2D34208", Offset = "0x2D34208", VA = "0x2D34208")]
	public IEnumerator method_71()
	{
		Teams.Class1 @class;
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600024B RID: 587 RVA: 0x00008DF4 File Offset: 0x00006FF4
	[Address(RVA = "0x2D34280", Offset = "0x2D34280", VA = "0x2D34280")]
	[Token(Token = "0x600024B")]
	public IEnumerator method_72()
	{
		Teams.Class1 @class = new Teams.Class1((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0400004A RID: 74
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400004A")]
	public GameObject[] gameObject_0;

	// Token: 0x0400004B RID: 75
	[Token(Token = "0x400004B")]
	[FieldOffset(Offset = "0x28")]
	public GameObject[] gameObject_1;

	// Token: 0x0400004C RID: 76
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400004C")]
	public Renderer[] renderer_0;

	// Token: 0x0400004D RID: 77
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400004D")]
	public AudioSource audioSource_0;
}
