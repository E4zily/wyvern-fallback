﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200004E RID: 78
[Token(Token = "0x200004E")]
public class ColorButton : MonoBehaviour
{
	// Token: 0x06000AC4 RID: 2756 RVA: 0x00018764 File Offset: 0x00016964
	[Token(Token = "0x6000AC4")]
	[Address(RVA = "0x2A5C5D0", Offset = "0x2A5C5D0", VA = "0x2A5C5D0")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "cheese";
		ColorManager.colorManager_0.method_5();
	}

	// Token: 0x06000AC5 RID: 2757 RVA: 0x00018794 File Offset: 0x00016994
	[Token(Token = "0x6000AC5")]
	[Address(RVA = "0x2A5C7E4", Offset = "0x2A5C7E4", VA = "0x2A5C7E4")]
	private void method_1()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_6();
		}
	}

	// Token: 0x06000AC6 RID: 2758 RVA: 0x000187B4 File Offset: 0x000169B4
	[Address(RVA = "0x2A5C9B0", Offset = "0x2A5C9B0", VA = "0x2A5C9B0")]
	[Token(Token = "0x6000AC6")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.tag == "DISABLE";
		ColorManager.colorManager_0.method_17();
	}

	// Token: 0x06000AC7 RID: 2759 RVA: 0x000187E4 File Offset: 0x000169E4
	[Address(RVA = "0x2A5CBC0", Offset = "0x2A5CBC0", VA = "0x2A5CBC0")]
	[Token(Token = "0x6000AC7")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.tag == "A Player has left the Room.";
		ColorManager.colorManager_0.method_5();
	}

	// Token: 0x06000AC8 RID: 2760 RVA: 0x00018814 File Offset: 0x00016A14
	[Token(Token = "0x6000AC8")]
	[Address(RVA = "0x2A5CCB4", Offset = "0x2A5CCB4", VA = "0x2A5CCB4")]
	private void method_4()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_23();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000AC9 RID: 2761 RVA: 0x0001883C File Offset: 0x00016A3C
	[Address(RVA = "0x2A5CE90", Offset = "0x2A5CE90", VA = "0x2A5CE90")]
	[Token(Token = "0x6000AC9")]
	public void method_5(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		ColorManager.colorManager_0.method_5();
	}

	// Token: 0x06000ACA RID: 2762 RVA: 0x00018860 File Offset: 0x00016A60
	[Token(Token = "0x6000ACA")]
	[Address(RVA = "0x2A5CF84", Offset = "0x2A5CF84", VA = "0x2A5CF84")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "hand 1";
	}

	// Token: 0x06000ACB RID: 2763 RVA: 0x00018884 File Offset: 0x00016A84
	[Token(Token = "0x6000ACB")]
	[Address(RVA = "0x2A5D078", Offset = "0x2A5D078", VA = "0x2A5D078")]
	private void method_7()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_14();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000ACC RID: 2764 RVA: 0x000188AC File Offset: 0x00016AAC
	[Address(RVA = "0x2A5D244", Offset = "0x2A5D244", VA = "0x2A5D244")]
	[Token(Token = "0x6000ACC")]
	private void method_8()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000ACD RID: 2765 RVA: 0x000188CC File Offset: 0x00016ACC
	[Address(RVA = "0x2A5D404", Offset = "0x2A5D404", VA = "0x2A5D404")]
	[Token(Token = "0x6000ACD")]
	private void method_9()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_9();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000ACE RID: 2766 RVA: 0x000188F4 File Offset: 0x00016AF4
	[Address(RVA = "0x2A5D5F8", Offset = "0x2A5D5F8", VA = "0x2A5D5F8")]
	[Token(Token = "0x6000ACE")]
	private void method_10()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_23();
		}
	}

	// Token: 0x06000ACF RID: 2767 RVA: 0x000188AC File Offset: 0x00016AAC
	[Token(Token = "0x6000ACF")]
	[Address(RVA = "0x2A5D6A0", Offset = "0x2A5D6A0", VA = "0x2A5D6A0")]
	private void method_11()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000AD0 RID: 2768 RVA: 0x00018914 File Offset: 0x00016B14
	[Token(Token = "0x6000AD0")]
	[Address(RVA = "0x2A5D74C", Offset = "0x2A5D74C", VA = "0x2A5D74C")]
	private void method_12()
	{
		ColorManager.colorManager_0.method_9();
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000AD1 RID: 2769 RVA: 0x00018934 File Offset: 0x00016B34
	[Token(Token = "0x6000AD1")]
	[Address(RVA = "0x2A5D7F8", Offset = "0x2A5D7F8", VA = "0x2A5D7F8")]
	private void method_13()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_20();
		}
	}

	// Token: 0x06000AD2 RID: 2770 RVA: 0x00018954 File Offset: 0x00016B54
	[Address(RVA = "0x2A5D9AC", Offset = "0x2A5D9AC", VA = "0x2A5D9AC")]
	[Token(Token = "0x6000AD2")]
	private void method_14()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_24();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000AD3 RID: 2771 RVA: 0x0001897C File Offset: 0x00016B7C
	[Address(RVA = "0x2A5DB6C", Offset = "0x2A5DB6C", VA = "0x2A5DB6C")]
	[Token(Token = "0x6000AD3")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.tag == "BN";
	}

	// Token: 0x06000AD4 RID: 2772 RVA: 0x000189A0 File Offset: 0x00016BA0
	[Address(RVA = "0x2A5DC60", Offset = "0x2A5DC60", VA = "0x2A5DC60")]
	[Token(Token = "0x6000AD4")]
	private void method_16()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_5();
		}
	}

	// Token: 0x06000AD5 RID: 2773 RVA: 0x000189C0 File Offset: 0x00016BC0
	[Token(Token = "0x6000AD5")]
	[Address(RVA = "0x2A5DD08", Offset = "0x2A5DD08", VA = "0x2A5DD08")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.tag == "gamemode";
		ColorManager.colorManager_0.method_6();
	}

	// Token: 0x06000AD6 RID: 2774 RVA: 0x000189F0 File Offset: 0x00016BF0
	[Address(RVA = "0x2A5DDFC", Offset = "0x2A5DDFC", VA = "0x2A5DDFC")]
	[Token(Token = "0x6000AD6")]
	public void method_18(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == " hours. You were banned because of ";
		ColorManager.colorManager_0.method_9();
	}

	// Token: 0x06000AD7 RID: 2775 RVA: 0x00018A18 File Offset: 0x00016C18
	[Token(Token = "0x6000AD7")]
	[Address(RVA = "0x2A5DEF0", Offset = "0x2A5DEF0", VA = "0x2A5DEF0")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.tag == "On";
		ColorManager.colorManager_0.method_11();
	}

	// Token: 0x06000AD8 RID: 2776 RVA: 0x00018A48 File Offset: 0x00016C48
	[Address(RVA = "0x2A5E128", Offset = "0x2A5E128", VA = "0x2A5E128")]
	[Token(Token = "0x6000AD8")]
	private void method_20()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_5();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000AD9 RID: 2777 RVA: 0x00018A70 File Offset: 0x00016C70
	[Token(Token = "0x6000AD9")]
	[Address(RVA = "0x2A5E1D4", Offset = "0x2A5E1D4", VA = "0x2A5E1D4")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.tag == "SaveHeight";
		ColorManager.colorManager_0.method_22();
	}

	// Token: 0x06000ADA RID: 2778 RVA: 0x00018AA0 File Offset: 0x00016CA0
	[Address(RVA = "0x2A5E3DC", Offset = "0x2A5E3DC", VA = "0x2A5E3DC")]
	[Token(Token = "0x6000ADA")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		ColorManager.colorManager_0.SetColor();
	}

	// Token: 0x06000ADB RID: 2779 RVA: 0x00018AD0 File Offset: 0x00016CD0
	[Token(Token = "0x6000ADB")]
	[Address(RVA = "0x2A5E618", Offset = "0x2A5E618", VA = "0x2A5E618")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.tag == "DISABLE";
		ColorManager.colorManager_0.method_22();
	}

	// Token: 0x06000ADC RID: 2780 RVA: 0x00018B00 File Offset: 0x00016D00
	[Address(RVA = "0x2A5E70C", Offset = "0x2A5E70C", VA = "0x2A5E70C")]
	[Token(Token = "0x6000ADC")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayerHead";
		ColorManager.colorManager_0.method_6();
	}

	// Token: 0x06000ADD RID: 2781 RVA: 0x00018B30 File Offset: 0x00016D30
	[Address(RVA = "0x2A5E800", Offset = "0x2A5E800", VA = "0x2A5E800")]
	[Token(Token = "0x6000ADD")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.tag == "Update User Inventory";
	}

	// Token: 0x06000ADE RID: 2782 RVA: 0x00018B54 File Offset: 0x00016D54
	[Token(Token = "0x6000ADE")]
	[Address(RVA = "0x2A5EA18", Offset = "0x2A5EA18", VA = "0x2A5EA18")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
	}

	// Token: 0x06000ADF RID: 2783 RVA: 0x00018B78 File Offset: 0x00016D78
	[Address(RVA = "0x2A5EB0C", Offset = "0x2A5EB0C", VA = "0x2A5EB0C")]
	[Token(Token = "0x6000ADF")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.tag == "knuckles";
		ColorManager.colorManager_0.SetColor();
	}

	// Token: 0x06000AE0 RID: 2784 RVA: 0x00018A48 File Offset: 0x00016C48
	[Token(Token = "0x6000AE0")]
	[Address(RVA = "0x2A5EC00", Offset = "0x2A5EC00", VA = "0x2A5EC00")]
	private void method_28()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_5();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000AE1 RID: 2785 RVA: 0x00018BA8 File Offset: 0x00016DA8
	[Address(RVA = "0x2A5ECAC", Offset = "0x2A5ECAC", VA = "0x2A5ECAC")]
	[Token(Token = "0x6000AE1")]
	private void method_29()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_25();
		}
	}

	// Token: 0x06000AE2 RID: 2786 RVA: 0x00018BC8 File Offset: 0x00016DC8
	[Address(RVA = "0x2A5ED54", Offset = "0x2A5ED54", VA = "0x2A5ED54")]
	[Token(Token = "0x6000AE2")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.tag == "You Already Own This Item";
		ColorManager.colorManager_0.method_9();
	}

	// Token: 0x06000AE3 RID: 2787 RVA: 0x00018BF8 File Offset: 0x00016DF8
	[Token(Token = "0x6000AE3")]
	[Address(RVA = "0x2A5EE48", Offset = "0x2A5EE48", VA = "0x2A5EE48")]
	private void method_31()
	{
		ColorManager.colorManager_0.method_22();
	}

	// Token: 0x06000AE4 RID: 2788 RVA: 0x00018C10 File Offset: 0x00016E10
	[Address(RVA = "0x2A5EEF0", Offset = "0x2A5EEF0", VA = "0x2A5EEF0")]
	[Token(Token = "0x6000AE4")]
	private void method_32()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_25();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000AE5 RID: 2789 RVA: 0x00018C38 File Offset: 0x00016E38
	[Address(RVA = "0x2A5EF9C", Offset = "0x2A5EF9C", VA = "0x2A5EF9C")]
	[Token(Token = "0x6000AE5")]
	public void method_33(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
	}

	// Token: 0x06000AE6 RID: 2790 RVA: 0x00018C54 File Offset: 0x00016E54
	[Token(Token = "0x6000AE6")]
	[Address(RVA = "0x2A5F090", Offset = "0x2A5F090", VA = "0x2A5F090")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "gravThing";
		ColorManager.colorManager_0.method_25();
	}

	// Token: 0x06000AE7 RID: 2791 RVA: 0x00018C84 File Offset: 0x00016E84
	[Token(Token = "0x6000AE7")]
	[Address(RVA = "0x2A5F184", Offset = "0x2A5F184", VA = "0x2A5F184")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.tag == "{0} ({1})";
		ColorManager.colorManager_0.method_20();
	}

	// Token: 0x06000AE8 RID: 2792 RVA: 0x00018CB4 File Offset: 0x00016EB4
	[Token(Token = "0x6000AE8")]
	[Address(RVA = "0x2A5F278", Offset = "0x2A5F278", VA = "0x2A5F278")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.tag == "Regular";
	}

	// Token: 0x06000AE9 RID: 2793 RVA: 0x00018CD8 File Offset: 0x00016ED8
	[Address(RVA = "0x2A5F36C", Offset = "0x2A5F36C", VA = "0x2A5F36C")]
	[Token(Token = "0x6000AE9")]
	private void method_37()
	{
		ColorManager.colorManager_0.method_23();
	}

	// Token: 0x06000AEA RID: 2794 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A5F418", Offset = "0x2A5F418", VA = "0x2A5F418")]
	[Token(Token = "0x6000AEA")]
	public ColorButton()
	{
	}

	// Token: 0x06000AEB RID: 2795 RVA: 0x00018CF0 File Offset: 0x00016EF0
	[Token(Token = "0x6000AEB")]
	[Address(RVA = "0x2A5F420", Offset = "0x2A5F420", VA = "0x2A5F420")]
	private void method_38()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_22();
		}
	}

	// Token: 0x06000AEC RID: 2796 RVA: 0x00018D10 File Offset: 0x00016F10
	[Token(Token = "0x6000AEC")]
	[Address(RVA = "0x2A5F4C8", Offset = "0x2A5F4C8", VA = "0x2A5F4C8")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.tag == "Name Changing Error. Error: ";
		ColorManager.colorManager_0.method_17();
	}

	// Token: 0x06000AED RID: 2797 RVA: 0x00018D40 File Offset: 0x00016F40
	[Token(Token = "0x6000AED")]
	[Address(RVA = "0x2A5F5BC", Offset = "0x2A5F5BC", VA = "0x2A5F5BC")]
	public void method_40(Collider collider_0)
	{
		collider_0.gameObject.tag == "monke is not my monke";
		ColorManager.colorManager_0.method_25();
	}

	// Token: 0x06000AEE RID: 2798 RVA: 0x000188F4 File Offset: 0x00016AF4
	[Token(Token = "0x6000AEE")]
	[Address(RVA = "0x2A5F6B0", Offset = "0x2A5F6B0", VA = "0x2A5F6B0")]
	private void method_41()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_23();
		}
	}

	// Token: 0x06000AEF RID: 2799 RVA: 0x00018D70 File Offset: 0x00016F70
	[Token(Token = "0x6000AEF")]
	[Address(RVA = "0x2A5F758", Offset = "0x2A5F758", VA = "0x2A5F758")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.tag == "User has been reported for: ";
		ColorManager.colorManager_0.method_6();
	}

	// Token: 0x06000AF0 RID: 2800 RVA: 0x00018DA0 File Offset: 0x00016FA0
	[Token(Token = "0x6000AF0")]
	[Address(RVA = "0x2A5F84C", Offset = "0x2A5F84C", VA = "0x2A5F84C")]
	private void method_43()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_22();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000AF1 RID: 2801 RVA: 0x00018DC8 File Offset: 0x00016FC8
	[Token(Token = "0x6000AF1")]
	[Address(RVA = "0x2A5F8F8", Offset = "0x2A5F8F8", VA = "0x2A5F8F8")]
	private void method_44()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_11();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000AF2 RID: 2802 RVA: 0x00018DF0 File Offset: 0x00016FF0
	[Address(RVA = "0x2A5F9A4", Offset = "0x2A5F9A4", VA = "0x2A5F9A4")]
	[Token(Token = "0x6000AF2")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.tag == "Version";
		ColorManager.colorManager_0.SetColor();
	}

	// Token: 0x06000AF3 RID: 2803 RVA: 0x00018E20 File Offset: 0x00017020
	[Address(RVA = "0x2A5FA98", Offset = "0x2A5FA98", VA = "0x2A5FA98")]
	[Token(Token = "0x6000AF3")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cannot access an empty buffer.";
		ColorManager.colorManager_0.method_23();
	}

	// Token: 0x06000AF4 RID: 2804 RVA: 0x00018E50 File Offset: 0x00017050
	[Token(Token = "0x6000AF4")]
	[Address(RVA = "0x2A5FB8C", Offset = "0x2A5FB8C", VA = "0x2A5FB8C")]
	private void method_47()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_20();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000AF5 RID: 2805 RVA: 0x000188F4 File Offset: 0x00016AF4
	[Address(RVA = "0x2A5FC38", Offset = "0x2A5FC38", VA = "0x2A5FC38")]
	[Token(Token = "0x6000AF5")]
	private void method_48()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_23();
		}
	}

	// Token: 0x06000AF6 RID: 2806 RVA: 0x00018BA8 File Offset: 0x00016DA8
	[Address(RVA = "0x2A5FCE0", Offset = "0x2A5FCE0", VA = "0x2A5FCE0")]
	[Token(Token = "0x6000AF6")]
	private void method_49()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_25();
		}
	}

	// Token: 0x06000AF7 RID: 2807 RVA: 0x00018E78 File Offset: 0x00017078
	[Address(RVA = "0x2A5FD88", Offset = "0x2A5FD88", VA = "0x2A5FD88")]
	[Token(Token = "0x6000AF7")]
	public void method_50(Collider collider_0)
	{
		collider_0.gameObject.tag == "\n";
		ColorManager.colorManager_0.method_22();
	}

	// Token: 0x06000AF8 RID: 2808 RVA: 0x00018EA8 File Offset: 0x000170A8
	[Address(RVA = "0x2A5FE7C", Offset = "0x2A5FE7C", VA = "0x2A5FE7C")]
	[Token(Token = "0x6000AF8")]
	private void method_51()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_19();
		}
	}

	// Token: 0x06000AF9 RID: 2809 RVA: 0x00018EC8 File Offset: 0x000170C8
	[Token(Token = "0x6000AF9")]
	[Address(RVA = "0x2A5FF24", Offset = "0x2A5FF24", VA = "0x2A5FF24")]
	public void method_52(Collider collider_0)
	{
		collider_0.gameObject.tag == "QuickStatic";
		ColorManager.colorManager_0.method_19();
	}

	// Token: 0x06000AFA RID: 2810 RVA: 0x00018EF8 File Offset: 0x000170F8
	[Token(Token = "0x6000AFA")]
	[Address(RVA = "0x2A60018", Offset = "0x2A60018", VA = "0x2A60018")]
	public void method_53(Collider collider_0)
	{
		collider_0.gameObject.tag == "got funky mone";
		ColorManager.colorManager_0.method_17();
	}

	// Token: 0x06000AFB RID: 2811 RVA: 0x00018CF0 File Offset: 0x00016EF0
	[Token(Token = "0x6000AFB")]
	[Address(RVA = "0x2A6010C", Offset = "0x2A6010C", VA = "0x2A6010C")]
	private void method_54()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_22();
		}
	}

	// Token: 0x06000AFC RID: 2812 RVA: 0x00018F28 File Offset: 0x00017128
	[Address(RVA = "0x2A601B4", Offset = "0x2A601B4", VA = "0x2A601B4")]
	[Token(Token = "0x6000AFC")]
	public void method_55(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		ColorManager.colorManager_0.SetColor();
	}

	// Token: 0x06000AFD RID: 2813 RVA: 0x00018F58 File Offset: 0x00017158
	[Token(Token = "0x6000AFD")]
	[Address(RVA = "0x2A602A8", Offset = "0x2A602A8", VA = "0x2A602A8")]
	private void method_56()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_17();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000AFE RID: 2814 RVA: 0x00018F80 File Offset: 0x00017180
	[Address(RVA = "0x2A60354", Offset = "0x2A60354", VA = "0x2A60354")]
	[Token(Token = "0x6000AFE")]
	private void Update()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.SetColor();
		}
	}

	// Token: 0x06000AFF RID: 2815 RVA: 0x00018FA0 File Offset: 0x000171A0
	[Address(RVA = "0x2A603FC", Offset = "0x2A603FC", VA = "0x2A603FC")]
	[Token(Token = "0x6000AFF")]
	private void method_57()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_9();
		}
	}

	// Token: 0x06000B00 RID: 2816 RVA: 0x00018FC0 File Offset: 0x000171C0
	[Address(RVA = "0x2A604A4", Offset = "0x2A604A4", VA = "0x2A604A4")]
	[Token(Token = "0x6000B00")]
	public void method_58(Collider collider_0)
	{
		collider_0.gameObject.tag == "Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.";
		ColorManager.colorManager_0.SetColor();
	}

	// Token: 0x06000B01 RID: 2817 RVA: 0x00018FF0 File Offset: 0x000171F0
	[Address(RVA = "0x2A60598", Offset = "0x2A60598", VA = "0x2A60598")]
	[Token(Token = "0x6000B01")]
	public void method_59(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		ColorManager.colorManager_0.method_24();
	}

	// Token: 0x06000B02 RID: 2818 RVA: 0x00019020 File Offset: 0x00017220
	[Token(Token = "0x6000B02")]
	[Address(RVA = "0x2A6068C", Offset = "0x2A6068C", VA = "0x2A6068C")]
	public void method_60(Collider collider_0)
	{
		collider_0.gameObject.tag == "procedural animation script required on ";
		ColorManager.colorManager_0.method_5();
	}

	// Token: 0x06000B03 RID: 2819 RVA: 0x00019050 File Offset: 0x00017250
	[Token(Token = "0x6000B03")]
	[Address(RVA = "0x2A60780", Offset = "0x2A60780", VA = "0x2A60780")]
	public void method_61(Collider collider_0)
	{
		collider_0.gameObject.tag == "NetworkPlayer";
		ColorManager.colorManager_0.method_17();
	}

	// Token: 0x06000B04 RID: 2820 RVA: 0x00018FA0 File Offset: 0x000171A0
	[Token(Token = "0x6000B04")]
	[Address(RVA = "0x2A60874", Offset = "0x2A60874", VA = "0x2A60874")]
	private void method_62()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_9();
		}
	}

	// Token: 0x06000B05 RID: 2821 RVA: 0x00019080 File Offset: 0x00017280
	[Token(Token = "0x6000B05")]
	[Address(RVA = "0x2A6091C", Offset = "0x2A6091C", VA = "0x2A6091C")]
	public void method_63(Collider collider_0)
	{
		collider_0.gameObject.tag == "This is the 2500 Bananas button, and it was just clicked";
		ColorManager.colorManager_0.method_6();
	}

	// Token: 0x06000B06 RID: 2822 RVA: 0x00018794 File Offset: 0x00016994
	[Token(Token = "0x6000B06")]
	[Address(RVA = "0x2A60A10", Offset = "0x2A60A10", VA = "0x2A60A10")]
	private void method_64()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_6();
		}
	}

	// Token: 0x06000B07 RID: 2823 RVA: 0x00018BA8 File Offset: 0x00016DA8
	[Token(Token = "0x6000B07")]
	[Address(RVA = "0x2A60AB8", Offset = "0x2A60AB8", VA = "0x2A60AB8")]
	private void method_65()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_25();
		}
	}

	// Token: 0x06000B08 RID: 2824 RVA: 0x000188CC File Offset: 0x00016ACC
	[Address(RVA = "0x2A60B60", Offset = "0x2A60B60", VA = "0x2A60B60")]
	[Token(Token = "0x6000B08")]
	private void method_66()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_9();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000B09 RID: 2825 RVA: 0x000190B0 File Offset: 0x000172B0
	[Token(Token = "0x6000B09")]
	[Address(RVA = "0x2A60C0C", Offset = "0x2A60C0C", VA = "0x2A60C0C")]
	public void method_67(Collider collider_0)
	{
		collider_0.gameObject.tag == "Body";
		ColorManager.colorManager_0.method_23();
	}

	// Token: 0x06000B0A RID: 2826 RVA: 0x000190E0 File Offset: 0x000172E0
	[Address(RVA = "0x2A60D00", Offset = "0x2A60D00", VA = "0x2A60D00")]
	[Token(Token = "0x6000B0A")]
	public void method_68(Collider collider_0)
	{
		collider_0.gameObject.tag == "ChangeToRegular";
		ColorManager.colorManager_0.method_6();
	}

	// Token: 0x06000B0B RID: 2827 RVA: 0x00019110 File Offset: 0x00017310
	[Address(RVA = "0x2A60DF4", Offset = "0x2A60DF4", VA = "0x2A60DF4")]
	[Token(Token = "0x6000B0B")]
	private void method_69()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_17();
		}
	}

	// Token: 0x06000B0C RID: 2828 RVA: 0x00019130 File Offset: 0x00017330
	[Address(RVA = "0x2A60E9C", Offset = "0x2A60E9C", VA = "0x2A60E9C")]
	[Token(Token = "0x6000B0C")]
	public void method_70(Collider collider_0)
	{
		collider_0.gameObject.tag == "ORGTARG";
		ColorManager.colorManager_0.method_24();
	}

	// Token: 0x06000B0D RID: 2829 RVA: 0x00018A48 File Offset: 0x00016C48
	[Address(RVA = "0x2A60F90", Offset = "0x2A60F90", VA = "0x2A60F90")]
	[Token(Token = "0x6000B0D")]
	private void method_71()
	{
		if (this.bool_0)
		{
			ColorManager.colorManager_0.method_5();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000B0E RID: 2830 RVA: 0x00019160 File Offset: 0x00017360
	[Address(RVA = "0x2A6103C", Offset = "0x2A6103C", VA = "0x2A6103C")]
	[Token(Token = "0x6000B0E")]
	public void method_72(Collider collider_0)
	{
		collider_0.gameObject.tag == "Failed to get catalog, cosmetic name, and price. Exact error details is: ";
		ColorManager.colorManager_0.method_11();
	}

	// Token: 0x06000B0F RID: 2831 RVA: 0x00018AA0 File Offset: 0x00016CA0
	[Address(RVA = "0x2A61130", Offset = "0x2A61130", VA = "0x2A61130")]
	[Token(Token = "0x6000B0F")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		ColorManager.colorManager_0.SetColor();
	}

	// Token: 0x06000B10 RID: 2832 RVA: 0x00019190 File Offset: 0x00017390
	[Address(RVA = "0x2A61224", Offset = "0x2A61224", VA = "0x2A61224")]
	[Token(Token = "0x6000B10")]
	public void method_73(Collider collider_0)
	{
		collider_0.gameObject.tag == "EnableCosmetic";
	}

	// Token: 0x0400018B RID: 395
	[Token(Token = "0x400018B")]
	[FieldOffset(Offset = "0x18")]
	public float float_0;

	// Token: 0x0400018C RID: 396
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x400018C")]
	public ColorButton.GEnum3 genum3_0;

	// Token: 0x0400018D RID: 397
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400018D")]
	public bool bool_0;

	// Token: 0x0200004F RID: 79
	[Token(Token = "0x200004F")]
	public enum GEnum3
	{
		// Token: 0x0400018F RID: 399
		[Token(Token = "0x400018F")]
		const_0,
		// Token: 0x04000190 RID: 400
		[Token(Token = "0x4000190")]
		const_1,
		// Token: 0x04000191 RID: 401
		[Token(Token = "0x4000191")]
		const_2
	}
}
