﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000080 RID: 128
[Token(Token = "0x2000080")]
public class MB_SwapShirts : MonoBehaviour
{
	// Token: 0x06001219 RID: 4633 RVA: 0x00026854 File Offset: 0x00024A54
	[Address(RVA = "0x2F07330", Offset = "0x2F07330", VA = "0x2F07330")]
	[Token(Token = "0x6001219")]
	private void method_0(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x0600121A RID: 4634 RVA: 0x00026888 File Offset: 0x00024A88
	[Token(Token = "0x600121A")]
	[Address(RVA = "0x2F0787C", Offset = "0x2F0787C", VA = "0x2F0787C")]
	private void method_1(Renderer[] renderer_3)
	{
		List<GameObject>.Enumerator enumerator = new List().GetEnumerator();
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x0600121B RID: 4635 RVA: 0x000268C0 File Offset: 0x00024AC0
	[Address(RVA = "0x2F07DD0", Offset = "0x2F07DD0", VA = "0x2F07DD0")]
	[Token(Token = "0x600121B")]
	private void method_2()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_49(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_69(renderer_2);
		if (num != 0L)
		{
		}
	}

	// Token: 0x0600121C RID: 4636 RVA: 0x000268F8 File Offset: 0x00024AF8
	[Token(Token = "0x600121C")]
	[Address(RVA = "0x2F08FE8", Offset = "0x2F08FE8", VA = "0x2F08FE8")]
	private void Start()
	{
		GameObject gameObject;
		while (gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600121D RID: 4637 RVA: 0x0002691C File Offset: 0x00024B1C
	[Token(Token = "0x600121D")]
	[Address(RVA = "0x2F09148", Offset = "0x2F09148", VA = "0x2F09148")]
	private void method_3(Renderer[] renderer_3)
	{
		new List();
	}

	// Token: 0x0600121E RID: 4638 RVA: 0x00026930 File Offset: 0x00024B30
	[Token(Token = "0x600121E")]
	[Address(RVA = "0x2F09594", Offset = "0x2F09594", VA = "0x2F09594")]
	private void method_4(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
	}

	// Token: 0x0600121F RID: 4639 RVA: 0x0002694C File Offset: 0x00024B4C
	[Token(Token = "0x600121F")]
	[Address(RVA = "0x2F09AE4", Offset = "0x2F09AE4", VA = "0x2F09AE4")]
	private void method_5()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001220 RID: 4640 RVA: 0x00026974 File Offset: 0x00024B74
	[Address(RVA = "0x2F09C44", Offset = "0x2F09C44", VA = "0x2F09C44")]
	[Token(Token = "0x6001220")]
	private void method_6(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001221 RID: 4641 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Token(Token = "0x6001221")]
	[Address(RVA = "0x2F0A1B8", Offset = "0x2F0A1B8", VA = "0x2F0A1B8")]
	private void method_7()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001222 RID: 4642 RVA: 0x000269D0 File Offset: 0x00024BD0
	[Address(RVA = "0x2F0A318", Offset = "0x2F0A318", VA = "0x2F0A318")]
	[Token(Token = "0x6001222")]
	private void method_8(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
	}

	// Token: 0x06001223 RID: 4643 RVA: 0x000269EC File Offset: 0x00024BEC
	[Token(Token = "0x6001223")]
	[Address(RVA = "0x2F0A85C", Offset = "0x2F0A85C", VA = "0x2F0A85C")]
	private void OnGUI()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_30(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_30(renderer_2);
		Renderer[] renderer_3 = this.renderer_1;
		this.method_30(renderer_3);
	}

	// Token: 0x06001224 RID: 4644 RVA: 0x0002694C File Offset: 0x00024B4C
	[Address(RVA = "0x2F0B05C", Offset = "0x2F0B05C", VA = "0x2F0B05C")]
	[Token(Token = "0x6001224")]
	private void method_9()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001225 RID: 4645 RVA: 0x0002694C File Offset: 0x00024B4C
	[Token(Token = "0x6001225")]
	[Address(RVA = "0x2F0B1BC", Offset = "0x2F0B1BC", VA = "0x2F0B1BC")]
	private void method_10()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001226 RID: 4646 RVA: 0x00026A30 File Offset: 0x00024C30
	[Token(Token = "0x6001226")]
	[Address(RVA = "0x2F0B31C", Offset = "0x2F0B31C", VA = "0x2F0B31C")]
	private void method_11()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_27(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_64(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_62(renderer_3);
	}

	// Token: 0x06001227 RID: 4647 RVA: 0x00026A78 File Offset: 0x00024C78
	[Token(Token = "0x6001227")]
	[Address(RVA = "0x2F0C540", Offset = "0x2F0C540", VA = "0x2F0C540")]
	private void method_12(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
	}

	// Token: 0x06001228 RID: 4648 RVA: 0x00026AA4 File Offset: 0x00024CA4
	[Address(RVA = "0x2F0CAC0", Offset = "0x2F0CAC0", VA = "0x2F0CAC0")]
	[Token(Token = "0x6001228")]
	private void method_13()
	{
		GameObject gameObject;
		if (gameObject != null && gameObject == null)
		{
			throw new ArrayTypeMismatchException();
		}
		goto IL_0C;
		for (;;)
		{
			IL_0C:
			goto IL_0C;
		}
	}

	// Token: 0x06001229 RID: 4649 RVA: 0x00026888 File Offset: 0x00024A88
	[Address(RVA = "0x2F0CC20", Offset = "0x2F0CC20", VA = "0x2F0CC20")]
	[Token(Token = "0x6001229")]
	private void method_14(Renderer[] renderer_3)
	{
		List<GameObject>.Enumerator enumerator = new List().GetEnumerator();
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x0600122A RID: 4650 RVA: 0x0002691C File Offset: 0x00024B1C
	[Token(Token = "0x600122A")]
	[Address(RVA = "0x2F0D1B4", Offset = "0x2F0D1B4", VA = "0x2F0D1B4")]
	private void method_15(Renderer[] renderer_3)
	{
		new List();
	}

	// Token: 0x0600122B RID: 4651 RVA: 0x00026AC0 File Offset: 0x00024CC0
	[Token(Token = "0x600122B")]
	[Address(RVA = "0x2F0D64C", Offset = "0x2F0D64C", VA = "0x2F0D64C")]
	private void method_16()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_26(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_58(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_42(renderer_3);
	}

	// Token: 0x0600122C RID: 4652 RVA: 0x00026888 File Offset: 0x00024A88
	[Token(Token = "0x600122C")]
	[Address(RVA = "0x2F0E838", Offset = "0x2F0E838", VA = "0x2F0E838")]
	private void method_17(Renderer[] renderer_3)
	{
		List<GameObject>.Enumerator enumerator = new List().GetEnumerator();
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x0600122D RID: 4653 RVA: 0x00026974 File Offset: 0x00024B74
	[Token(Token = "0x600122D")]
	[Address(RVA = "0x2F0EDCC", Offset = "0x2F0EDCC", VA = "0x2F0EDCC")]
	private void method_18(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x0600122E RID: 4654 RVA: 0x00026B08 File Offset: 0x00024D08
	[Address(RVA = "0x2F0F340", Offset = "0x2F0F340", VA = "0x2F0F340")]
	[Token(Token = "0x600122E")]
	private void method_19()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_18(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_4(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_17(renderer_3);
	}

	// Token: 0x0600122F RID: 4655 RVA: 0x00026B50 File Offset: 0x00024D50
	[Token(Token = "0x600122F")]
	[Address(RVA = "0x2F0F5B4", Offset = "0x2F0F5B4", VA = "0x2F0F5B4")]
	private void method_20()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_0;
		this.method_65(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_1;
		this.method_8(renderer_2);
	}

	// Token: 0x06001230 RID: 4656 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Address(RVA = "0x2F1012C", Offset = "0x2F1012C", VA = "0x2F1012C")]
	[Token(Token = "0x6001230")]
	private void method_21()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001231 RID: 4657 RVA: 0x00026B88 File Offset: 0x00024D88
	[Token(Token = "0x6001231")]
	[Address(RVA = "0x2F10268", Offset = "0x2F10268", VA = "0x2F10268")]
	private void method_22()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_52(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_70(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_63(renderer_3);
	}

	// Token: 0x06001232 RID: 4658 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Address(RVA = "0x2F11538", Offset = "0x2F11538", VA = "0x2F11538")]
	[Token(Token = "0x6001232")]
	private void method_23()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001233 RID: 4659 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Token(Token = "0x6001233")]
	[Address(RVA = "0x2F11698", Offset = "0x2F11698", VA = "0x2F11698")]
	private void method_24()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001234 RID: 4660 RVA: 0x00026BD0 File Offset: 0x00024DD0
	[Token(Token = "0x6001234")]
	[Address(RVA = "0x2F117D0", Offset = "0x2F117D0", VA = "0x2F117D0")]
	private void method_25(Renderer[] renderer_3)
	{
		List<GameObject>.Enumerator enumerator = new List().GetEnumerator();
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001235 RID: 4661 RVA: 0x00026C08 File Offset: 0x00024E08
	[Token(Token = "0x6001235")]
	[Address(RVA = "0x2F0D8C0", Offset = "0x2F0D8C0", VA = "0x2F0D8C0")]
	private void method_26(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		GameObject gameObject2;
		if (gameObject2 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001236 RID: 4662 RVA: 0x00026C38 File Offset: 0x00024E38
	[Address(RVA = "0x2F0B590", Offset = "0x2F0B590", VA = "0x2F0B590")]
	[Token(Token = "0x6001236")]
	private void method_27(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001237 RID: 4663 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Address(RVA = "0x2F11D08", Offset = "0x2F11D08", VA = "0x2F11D08")]
	[Token(Token = "0x6001237")]
	private void method_28()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001238 RID: 4664 RVA: 0x00026C6C File Offset: 0x00024E6C
	[Token(Token = "0x6001238")]
	[Address(RVA = "0x2F11E68", Offset = "0x2F11E68", VA = "0x2F11E68")]
	private void method_29()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_49(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_54(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_48(renderer_3);
	}

	// Token: 0x06001239 RID: 4665 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2F12BBC", Offset = "0x2F12BBC", VA = "0x2F12BBC")]
	[Token(Token = "0x6001239")]
	public MB_SwapShirts()
	{
	}

	// Token: 0x0600123A RID: 4666 RVA: 0x00026CB4 File Offset: 0x00024EB4
	[Token(Token = "0x600123A")]
	[Address(RVA = "0x2F0AAD0", Offset = "0x2F0AAD0", VA = "0x2F0AAD0")]
	private void method_30(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		GameObject gameObject;
		if (gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x0600123B RID: 4667 RVA: 0x00026CDC File Offset: 0x00024EDC
	[Token(Token = "0x600123B")]
	[Address(RVA = "0x2F12BC4", Offset = "0x2F12BC4", VA = "0x2F12BC4")]
	private void method_31(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x0600123C RID: 4668 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Token(Token = "0x600123C")]
	[Address(RVA = "0x2F13150", Offset = "0x2F13150", VA = "0x2F13150")]
	private void method_32()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600123D RID: 4669 RVA: 0x000269D0 File Offset: 0x00024BD0
	[Address(RVA = "0x2F1328C", Offset = "0x2F1328C", VA = "0x2F1328C")]
	[Token(Token = "0x600123D")]
	private void method_33(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
	}

	// Token: 0x0600123E RID: 4670 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Address(RVA = "0x2F137C4", Offset = "0x2F137C4", VA = "0x2F137C4")]
	[Token(Token = "0x600123E")]
	private void method_34()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600123F RID: 4671 RVA: 0x00026D10 File Offset: 0x00024F10
	[Token(Token = "0x600123F")]
	[Address(RVA = "0x2F08B44", Offset = "0x2F08B44", VA = "0x2F08B44")]
	private void method_35(Renderer[] renderer_3)
	{
		new List();
	}

	// Token: 0x06001240 RID: 4672 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Address(RVA = "0x2F13900", Offset = "0x2F13900", VA = "0x2F13900")]
	[Token(Token = "0x6001240")]
	private void method_36()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001241 RID: 4673 RVA: 0x00026D24 File Offset: 0x00024F24
	[Token(Token = "0x6001241")]
	[Address(RVA = "0x2F13A38", Offset = "0x2F13A38", VA = "0x2F13A38")]
	private void method_37(Renderer[] renderer_3)
	{
		new List();
	}

	// Token: 0x06001242 RID: 4674 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Token(Token = "0x6001242")]
	[Address(RVA = "0x2F13ED4", Offset = "0x2F13ED4", VA = "0x2F13ED4")]
	private void method_38()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001243 RID: 4675 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Address(RVA = "0x2F14034", Offset = "0x2F14034", VA = "0x2F14034")]
	[Token(Token = "0x6001243")]
	private void method_39()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001244 RID: 4676 RVA: 0x00026D38 File Offset: 0x00024F38
	[Address(RVA = "0x2F14170", Offset = "0x2F14170", VA = "0x2F14170")]
	[Token(Token = "0x6001244")]
	private void method_40(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
	}

	// Token: 0x06001245 RID: 4677 RVA: 0x00026D54 File Offset: 0x00024F54
	[Token(Token = "0x6001245")]
	[Address(RVA = "0x2F146EC", Offset = "0x2F146EC", VA = "0x2F146EC")]
	private void method_41()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_62(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_76(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_69(renderer_3);
	}

	// Token: 0x06001246 RID: 4678 RVA: 0x00026888 File Offset: 0x00024A88
	[Token(Token = "0x6001246")]
	[Address(RVA = "0x2F0E2A4", Offset = "0x2F0E2A4", VA = "0x2F0E2A4")]
	private void method_42(Renderer[] renderer_3)
	{
		List<GameObject>.Enumerator enumerator = new List().GetEnumerator();
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001247 RID: 4679 RVA: 0x00026D9C File Offset: 0x00024F9C
	[Token(Token = "0x6001247")]
	[Address(RVA = "0x2F14E98", Offset = "0x2F14E98", VA = "0x2F14E98")]
	private void method_43()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_45(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_64(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_27(renderer_3);
	}

	// Token: 0x06001248 RID: 4680 RVA: 0x00026DE4 File Offset: 0x00024FE4
	[Address(RVA = "0x2F15574", Offset = "0x2F15574", VA = "0x2F15574")]
	[Token(Token = "0x6001248")]
	private void method_44(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001249 RID: 4681 RVA: 0x00026E18 File Offset: 0x00025018
	[Address(RVA = "0x2F1510C", Offset = "0x2F1510C", VA = "0x2F1510C")]
	[Token(Token = "0x6001249")]
	private void method_45(Renderer[] renderer_3)
	{
		new List();
	}

	// Token: 0x0600124A RID: 4682 RVA: 0x00026E2C File Offset: 0x0002502C
	[Token(Token = "0x600124A")]
	[Address(RVA = "0x2F15AA8", Offset = "0x2F15AA8", VA = "0x2F15AA8")]
	private void method_46()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_1(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_35(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_3(renderer_3);
	}

	// Token: 0x0600124B RID: 4683 RVA: 0x00026E74 File Offset: 0x00025074
	[Token(Token = "0x600124B")]
	[Address(RVA = "0x2F15D1C", Offset = "0x2F15D1C", VA = "0x2F15D1C")]
	private void method_47()
	{
		Renderer[] renderer_ = this.renderer_2;
		this.method_30(renderer_);
		Renderer[] renderer_2 = this.renderer_0;
		this.method_70(renderer_2);
		Renderer[] renderer_3 = this.renderer_1;
		this.method_56(renderer_3);
	}

	// Token: 0x0600124C RID: 4684 RVA: 0x00026C38 File Offset: 0x00024E38
	[Address(RVA = "0x2F12630", Offset = "0x2F12630", VA = "0x2F12630")]
	[Token(Token = "0x600124C")]
	private void method_48(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x0600124D RID: 4685 RVA: 0x00026EB0 File Offset: 0x000250B0
	[Address(RVA = "0x2F08044", Offset = "0x2F08044", VA = "0x2F08044")]
	[Token(Token = "0x600124D")]
	private void method_49(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		Debug.Log("Player");
	}

	// Token: 0x0600124E RID: 4686 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Token(Token = "0x600124E")]
	[Address(RVA = "0x2F164E4", Offset = "0x2F164E4", VA = "0x2F164E4")]
	private void method_50()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600124F RID: 4687 RVA: 0x00026EE8 File Offset: 0x000250E8
	[Token(Token = "0x600124F")]
	[Address(RVA = "0x2F16620", Offset = "0x2F16620", VA = "0x2F16620")]
	private void method_51()
	{
		do
		{
			GameObject gameObject;
			if (gameObject == null)
			{
			}
		}
		while (this.renderer_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001250 RID: 4688 RVA: 0x00026854 File Offset: 0x00024A54
	[Address(RVA = "0x2F104DC", Offset = "0x2F104DC", VA = "0x2F104DC")]
	[Token(Token = "0x6001250")]
	private void method_52(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001251 RID: 4689 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Token(Token = "0x6001251")]
	[Address(RVA = "0x2F16780", Offset = "0x2F16780", VA = "0x2F16780")]
	private void method_53()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001252 RID: 4690 RVA: 0x00026F08 File Offset: 0x00025108
	[Token(Token = "0x6001252")]
	[Address(RVA = "0x2F120DC", Offset = "0x2F120DC", VA = "0x2F120DC")]
	private void method_54(Renderer[] renderer_3)
	{
		List<GameObject>.Enumerator enumerator = new List().GetEnumerator();
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001253 RID: 4691 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Address(RVA = "0x2F168E0", Offset = "0x2F168E0", VA = "0x2F168E0")]
	[Token(Token = "0x6001253")]
	private void method_55()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001254 RID: 4692 RVA: 0x00026F40 File Offset: 0x00025140
	[Address(RVA = "0x2F15F90", Offset = "0x2F15F90", VA = "0x2F15F90")]
	[Token(Token = "0x6001254")]
	private void method_56(Renderer[] renderer_3)
	{
		new List().GetEnumerator().MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001255 RID: 4693 RVA: 0x00026F74 File Offset: 0x00025174
	[Token(Token = "0x6001255")]
	[Address(RVA = "0x2F16A1C", Offset = "0x2F16A1C", VA = "0x2F16A1C")]
	private void method_57()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_56(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_42(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_35(renderer_3);
	}

	// Token: 0x06001256 RID: 4694 RVA: 0x00026FBC File Offset: 0x000251BC
	[Token(Token = "0x6001256")]
	[Address(RVA = "0x2F0DE4C", Offset = "0x2F0DE4C", VA = "0x2F0DE4C")]
	private void method_58(Renderer[] renderer_3)
	{
	}

	// Token: 0x06001257 RID: 4695 RVA: 0x00026FCC File Offset: 0x000251CC
	[Address(RVA = "0x2F16C90", Offset = "0x2F16C90", VA = "0x2F16C90")]
	[Token(Token = "0x6001257")]
	private void method_59()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001258 RID: 4696 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Address(RVA = "0x2F16DF0", Offset = "0x2F16DF0", VA = "0x2F16DF0")]
	[Token(Token = "0x6001258")]
	private void method_60()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001259 RID: 4697 RVA: 0x00026FF4 File Offset: 0x000251F4
	[Address(RVA = "0x2F16F28", Offset = "0x2F16F28", VA = "0x2F16F28")]
	[Token(Token = "0x6001259")]
	private void method_61()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_68(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_63(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_40(renderer_3);
	}

	// Token: 0x0600125A RID: 4698 RVA: 0x0002703C File Offset: 0x0002523C
	[Token(Token = "0x600125A")]
	[Address(RVA = "0x2F0BFAC", Offset = "0x2F0BFAC", VA = "0x2F0BFAC")]
	private void method_62(Renderer[] renderer_3)
	{
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x0600125B RID: 4699 RVA: 0x00026930 File Offset: 0x00024B30
	[Token(Token = "0x600125B")]
	[Address(RVA = "0x2F10FB0", Offset = "0x2F10FB0", VA = "0x2F10FB0")]
	private void method_63(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
	}

	// Token: 0x0600125C RID: 4700 RVA: 0x00027068 File Offset: 0x00025268
	[Address(RVA = "0x2F0BB1C", Offset = "0x2F0BB1C", VA = "0x2F0BB1C")]
	[Token(Token = "0x600125C")]
	private void method_64(Renderer[] renderer_3)
	{
	}

	// Token: 0x0600125D RID: 4701 RVA: 0x00026D24 File Offset: 0x00024F24
	[Address(RVA = "0x2F0FC90", Offset = "0x2F0FC90", VA = "0x2F0FC90")]
	[Token(Token = "0x600125D")]
	private void method_65(Renderer[] renderer_3)
	{
		new List();
	}

	// Token: 0x0600125E RID: 4702 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Token(Token = "0x600125E")]
	[Address(RVA = "0x2F1719C", Offset = "0x2F1719C", VA = "0x2F1719C")]
	private void method_66()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600125F RID: 4703 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Address(RVA = "0x2F172FC", Offset = "0x2F172FC", VA = "0x2F172FC")]
	[Token(Token = "0x600125F")]
	private void method_67()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001260 RID: 4704 RVA: 0x00026E18 File Offset: 0x00025018
	[Token(Token = "0x6001260")]
	[Address(RVA = "0x2F0F828", Offset = "0x2F0F828", VA = "0x2F0F828")]
	private void method_68(Renderer[] renderer_3)
	{
		new List();
	}

	// Token: 0x06001261 RID: 4705 RVA: 0x00026974 File Offset: 0x00024B74
	[Token(Token = "0x6001261")]
	[Address(RVA = "0x2F085D0", Offset = "0x2F085D0", VA = "0x2F085D0")]
	private void method_69(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001262 RID: 4706 RVA: 0x00026930 File Offset: 0x00024B30
	[Address(RVA = "0x2F10A28", Offset = "0x2F10A28", VA = "0x2F10A28")]
	[Token(Token = "0x6001262")]
	private void method_70(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
	}

	// Token: 0x06001263 RID: 4707 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Address(RVA = "0x2F17438", Offset = "0x2F17438", VA = "0x2F17438")]
	[Token(Token = "0x6001263")]
	private void method_71()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001264 RID: 4708 RVA: 0x00027078 File Offset: 0x00025278
	[Token(Token = "0x6001264")]
	[Address(RVA = "0x2F17570", Offset = "0x2F17570", VA = "0x2F17570")]
	private void method_72()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_26(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_35(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_1(renderer_3);
	}

	// Token: 0x06001265 RID: 4709 RVA: 0x0002694C File Offset: 0x00024B4C
	[Token(Token = "0x6001265")]
	[Address(RVA = "0x2F177DC", Offset = "0x2F177DC", VA = "0x2F177DC")]
	private void method_73()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001266 RID: 4710 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Token(Token = "0x6001266")]
	[Address(RVA = "0x2F1793C", Offset = "0x2F1793C", VA = "0x2F1793C")]
	private void method_74()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001267 RID: 4711 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Token(Token = "0x6001267")]
	[Address(RVA = "0x2F17A9C", Offset = "0x2F17A9C", VA = "0x2F17A9C")]
	private void method_75()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x06001268 RID: 4712 RVA: 0x000270C0 File Offset: 0x000252C0
	[Address(RVA = "0x2F14960", Offset = "0x2F14960", VA = "0x2F14960")]
	[Token(Token = "0x6001268")]
	private void method_76(Renderer[] renderer_3)
	{
		new List();
		List.Enumerator enumerator;
		enumerator.MoveNext();
		Renderer renderer;
		GameObject gameObject = renderer.gameObject;
		if (renderer.gameObject != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001269 RID: 4713 RVA: 0x000269A8 File Offset: 0x00024BA8
	[Token(Token = "0x6001269")]
	[Address(RVA = "0x2F17BFC", Offset = "0x2F17BFC", VA = "0x2F17BFC")]
	private void method_77()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600126A RID: 4714 RVA: 0x0002694C File Offset: 0x00024B4C
	[Token(Token = "0x600126A")]
	[Address(RVA = "0x2F17D34", Offset = "0x2F17D34", VA = "0x2F17D34")]
	private void method_78()
	{
		GameObject gameObject;
		while (gameObject == null || gameObject != null)
		{
			if (this.renderer_0 == null)
			{
				throw new NullReferenceException();
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x0600126B RID: 4715 RVA: 0x000270F4 File Offset: 0x000252F4
	[Token(Token = "0x600126B")]
	[Address(RVA = "0x2F17E94", Offset = "0x2F17E94", VA = "0x2F17E94")]
	private void method_79()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		Renderer[] renderer_ = this.renderer_2;
		this.method_30(renderer_);
		if (num != 0L)
		{
		}
		Renderer[] renderer_2 = this.renderer_0;
		this.method_45(renderer_2);
		if (num != 0L)
		{
		}
		Renderer[] renderer_3 = this.renderer_1;
		this.method_62(renderer_3);
	}

	// Token: 0x0400028B RID: 651
	[Token(Token = "0x400028B")]
	[FieldOffset(Offset = "0x18")]
	public MB3_MeshBaker mb3_MeshBaker_0;

	// Token: 0x0400028C RID: 652
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400028C")]
	public Renderer[] renderer_0;

	// Token: 0x0400028D RID: 653
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400028D")]
	public Renderer[] renderer_1;

	// Token: 0x0400028E RID: 654
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400028E")]
	public Renderer[] renderer_2;
}
