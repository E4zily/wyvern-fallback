﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;

// Token: 0x0200007D RID: 125
[Token(Token = "0x200007D")]
public class LobbyStats : MonoBehaviourPunCallbacks
{
	// Token: 0x0600119B RID: 4507 RVA: 0x00024CC4 File Offset: 0x00022EC4
	[Address(RVA = "0x2D93AC0", Offset = "0x2D93AC0", VA = "0x2D93AC0")]
	[Token(Token = "0x600119B")]
	public void method_0()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Tagging" + str;
		string name = PhotonNetwork.CurrentRoom.name;
		"FingerTip" + name;
	}

	// Token: 0x0600119C RID: 4508 RVA: 0x00024D1C File Offset: 0x00022F1C
	[Address(RVA = "0x2D93CEC", Offset = "0x2D93CEC", VA = "0x2D93CEC")]
	[Token(Token = "0x600119C")]
	public void method_1()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"BloodKill" + str;
		string str2;
		"\n" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"poweredup!" + name;
	}

	// Token: 0x0600119D RID: 4509 RVA: 0x00024D80 File Offset: 0x00022F80
	[Token(Token = "0x600119D")]
	[Address(RVA = "0x2D93F18", Offset = "0x2D93F18", VA = "0x2D93F18")]
	public void method_2()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"unstuck" + str;
	}

	// Token: 0x0600119E RID: 4510 RVA: 0x00024DC4 File Offset: 0x00022FC4
	[Token(Token = "0x600119E")]
	[Address(RVA = "0x2D93FB0", Offset = "0x2D93FB0", VA = "0x2D93FB0")]
	public void method_3()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"username" + str;
	}

	// Token: 0x0600119F RID: 4511 RVA: 0x0000208D File Offset: 0x0000028D
	[Address(RVA = "0x2D94048", Offset = "0x2D94048", VA = "0x2D94048")]
	[Token(Token = "0x600119F")]
	public LobbyStats()
	{
	}

	// Token: 0x060011A0 RID: 4512 RVA: 0x00024E08 File Offset: 0x00023008
	[Token(Token = "0x60011A0")]
	[Address(RVA = "0x2D94050", Offset = "0x2D94050", VA = "0x2D94050")]
	public void method_4()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Cannot access index {0}. Buffer is empty" + str;
	}

	// Token: 0x060011A1 RID: 4513 RVA: 0x00024E4C File Offset: 0x0002304C
	[Token(Token = "0x60011A1")]
	[Address(RVA = "0x2D940E8", Offset = "0x2D940E8", VA = "0x2D940E8")]
	public void method_5()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"You struck apon an error. " + str;
	}

	// Token: 0x060011A2 RID: 4514 RVA: 0x00024E90 File Offset: 0x00023090
	[Token(Token = "0x60011A2")]
	[Address(RVA = "0x2D94180", Offset = "0x2D94180", VA = "0x2D94180")]
	public void method_6()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Cannot take elements from an empty buffer." + str;
	}

	// Token: 0x060011A3 RID: 4515 RVA: 0x00024ED4 File Offset: 0x000230D4
	[Token(Token = "0x60011A3")]
	[Address(RVA = "0x2D94218", Offset = "0x2D94218", VA = "0x2D94218")]
	public void method_7()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Players Online: " + str;
		string str2;
		"Faild To Add Winner Money: " + str2;
		string name = PhotonNetwork.CurrentRoom.name;
	}

	// Token: 0x060011A4 RID: 4516 RVA: 0x00024F2C File Offset: 0x0002312C
	[Address(RVA = "0x2D94430", Offset = "0x2D94430", VA = "0x2D94430")]
	[Token(Token = "0x60011A4")]
	public void method_8()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Player" + str;
		string str2;
		"Bruh i cannot go here you stupid L bozo" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"true" + name;
	}

	// Token: 0x060011A5 RID: 4517 RVA: 0x00024F90 File Offset: 0x00023190
	[Address(RVA = "0x2D9465C", Offset = "0x2D9465C", VA = "0x2D9465C")]
	[Token(Token = "0x60011A5")]
	public void method_9()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"HOLY MOLY THE STICK IS ON FIRE!!!!!!" + str;
	}

	// Token: 0x060011A6 RID: 4518 RVA: 0x00024FD4 File Offset: 0x000231D4
	[Token(Token = "0x60011A6")]
	[Address(RVA = "0x2D946F4", Offset = "0x2D946F4", VA = "0x2D946F4")]
	public void method_10()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n" + str;
	}

	// Token: 0x060011A7 RID: 4519 RVA: 0x00025018 File Offset: 0x00023218
	[Token(Token = "0x60011A7")]
	[Address(RVA = "0x2D9478C", Offset = "0x2D9478C", VA = "0x2D9478C")]
	public void method_11()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"FingerTip" + str;
	}

	// Token: 0x060011A8 RID: 4520 RVA: 0x0002505C File Offset: 0x0002325C
	[Address(RVA = "0x2D94824", Offset = "0x2D94824", VA = "0x2D94824")]
	[Token(Token = "0x60011A8")]
	public void method_12()
	{
		long num = 1L;
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"typesOfTalk" + str;
		string str2;
		"PURCHASE" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"5BN" + name;
	}

	// Token: 0x060011A9 RID: 4521 RVA: 0x000250BC File Offset: 0x000232BC
	[Token(Token = "0x60011A9")]
	[Address(RVA = "0x2D94A50", Offset = "0x2D94A50", VA = "0x2D94A50")]
	public void method_13()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Connected to Server." + str;
	}

	// Token: 0x060011AA RID: 4522 RVA: 0x00025100 File Offset: 0x00023300
	[Token(Token = "0x60011AA")]
	[Address(RVA = "0x2D94AE8", Offset = "0x2D94AE8", VA = "0x2D94AE8")]
	public void method_14()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Universal Render Pipeline/Lit" + str;
		string str2;
		"Name Changing Error. Error: " + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"Update User Inventory" + name;
	}

	// Token: 0x060011AB RID: 4523 RVA: 0x00025164 File Offset: 0x00023364
	[Token(Token = "0x60011AB")]
	[Address(RVA = "0x2D94D00", Offset = "0x2D94D00", VA = "0x2D94D00")]
	public void method_15()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"SetColor" + str;
		string str2;
		"Joined Public Room Successfully" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"_BaseColor" + name;
	}

	// Token: 0x060011AC RID: 4524 RVA: 0x000251C8 File Offset: 0x000233C8
	[Address(RVA = "0x2D94F2C", Offset = "0x2D94F2C", VA = "0x2D94F2C")]
	[Token(Token = "0x60011AC")]
	public void method_16()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Stopped Colliding" + str;
	}

	// Token: 0x060011AD RID: 4525 RVA: 0x0002520C File Offset: 0x0002340C
	[Address(RVA = "0x2D94FC4", Offset = "0x2D94FC4", VA = "0x2D94FC4")]
	[Token(Token = "0x60011AD")]
	public void method_17()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Player" + str;
	}

	// Token: 0x060011AE RID: 4526 RVA: 0x00025250 File Offset: 0x00023450
	[Token(Token = "0x60011AE")]
	[Address(RVA = "0x2D9505C", Offset = "0x2D9505C", VA = "0x2D9505C")]
	public void method_18()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		string str = this.string_0;
		"M/d/yyyy" + str;
	}

	// Token: 0x060011AF RID: 4527 RVA: 0x00025284 File Offset: 0x00023484
	[Token(Token = "0x60011AF")]
	[Address(RVA = "0x2D950F4", Offset = "0x2D950F4", VA = "0x2D950F4")]
	public void method_19()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Bare Torso" + str;
		string str2;
		"Player" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"A new Player joined a Room." + name;
	}

	// Token: 0x060011B0 RID: 4528 RVA: 0x000252E8 File Offset: 0x000234E8
	[Address(RVA = "0x2D95320", Offset = "0x2D95320", VA = "0x2D95320")]
	[Token(Token = "0x60011B0")]
	public void method_20()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Bruh i cannot go here you stupid L bozo" + str;
	}

	// Token: 0x060011B1 RID: 4529 RVA: 0x0002532C File Offset: 0x0002352C
	[Token(Token = "0x60011B1")]
	[Address(RVA = "0x2D953B8", Offset = "0x2D953B8", VA = "0x2D953B8")]
	public void method_21()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"On" + str;
		string str2;
		"Left Hand" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"Are you sure you would like to buy 1000 Bananas for $1.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe." + name;
	}

	// Token: 0x060011B2 RID: 4530 RVA: 0x00025390 File Offset: 0x00023590
	[Token(Token = "0x60011B2")]
	[Address(RVA = "0x2D955E4", Offset = "0x2D955E4", VA = "0x2D955E4")]
	public void method_22()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"{0}/{1:f0}" + str;
		string str2;
		"Tagged" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"A Player has left the Room." + name;
	}

	// Token: 0x060011B3 RID: 4531 RVA: 0x000253EC File Offset: 0x000235EC
	[Token(Token = "0x60011B3")]
	[Address(RVA = "0x2D95810", Offset = "0x2D95810", VA = "0x2D95810")]
	public void method_23()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"PURCHASED" + str;
		string name = PhotonNetwork.CurrentRoom.name;
		"PushToTalk" + name;
	}

	// Token: 0x060011B4 RID: 4532 RVA: 0x00025444 File Offset: 0x00023644
	[Token(Token = "0x60011B4")]
	[Address(RVA = "0x2D95A3C", Offset = "0x2D95A3C", VA = "0x2D95A3C")]
	public void method_24()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Player" + str;
		string str2;
		"_WobbleZ" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"_BaseColor" + name;
	}

	// Token: 0x060011B5 RID: 4533 RVA: 0x000254A8 File Offset: 0x000236A8
	[Token(Token = "0x60011B5")]
	[Address(RVA = "0x2D95C68", Offset = "0x2D95C68", VA = "0x2D95C68")]
	public void method_25()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Joined a Room." + str;
	}

	// Token: 0x060011B6 RID: 4534 RVA: 0x000254EC File Offset: 0x000236EC
	[Token(Token = "0x60011B6")]
	[Address(RVA = "0x2D95D00", Offset = "0x2D95D00", VA = "0x2D95D00")]
	public void method_26()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Collided" + str;
	}

	// Token: 0x060011B7 RID: 4535 RVA: 0x00025530 File Offset: 0x00023730
	[Address(RVA = "0x2D95D98", Offset = "0x2D95D98", VA = "0x2D95D98")]
	[Token(Token = "0x60011B7")]
	public void method_27()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"{0}/{1:f0}" + str;
		string str2;
		"Key" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"EnableCosmetic" + name;
	}

	// Token: 0x060011B8 RID: 4536 RVA: 0x00025594 File Offset: 0x00023794
	[Address(RVA = "0x2D95FC4", Offset = "0x2D95FC4", VA = "0x2D95FC4")]
	[Token(Token = "0x60011B8")]
	public void method_28()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"unlocked!" + str;
	}

	// Token: 0x060011B9 RID: 4537 RVA: 0x000255D8 File Offset: 0x000237D8
	[Address(RVA = "0x2D9605C", Offset = "0x2D9605C", VA = "0x2D9605C")]
	[Token(Token = "0x60011B9")]
	public void method_29()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"htc" + str;
	}

	// Token: 0x060011BA RID: 4538 RVA: 0x0002561C File Offset: 0x0002381C
	[Address(RVA = "0x2D960F4", Offset = "0x2D960F4", VA = "0x2D960F4")]
	[Token(Token = "0x60011BA")]
	public void method_30()
	{
	}

	// Token: 0x060011BB RID: 4539 RVA: 0x0002561C File Offset: 0x0002381C
	[Token(Token = "0x60011BB")]
	[Address(RVA = "0x2D9618C", Offset = "0x2D9618C", VA = "0x2D9618C")]
	public void method_31()
	{
	}

	// Token: 0x060011BC RID: 4540 RVA: 0x0002562C File Offset: 0x0002382C
	[Token(Token = "0x60011BC")]
	[Address(RVA = "0x2D96224", Offset = "0x2D96224", VA = "0x2D96224")]
	public void method_32()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Not enough amount of currency" + str;
	}

	// Token: 0x060011BD RID: 4541 RVA: 0x00025670 File Offset: 0x00023870
	[Token(Token = "0x60011BD")]
	[Address(RVA = "0x2D962BC", Offset = "0x2D962BC", VA = "0x2D962BC")]
	public void method_33()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x060011BE RID: 4542 RVA: 0x000256A0 File Offset: 0x000238A0
	[Address(RVA = "0x2D96354", Offset = "0x2D96354", VA = "0x2D96354")]
	[Token(Token = "0x60011BE")]
	public void method_34()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"5BN" + str;
		string str2;
		"button" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"Add/Remove Glasses" + name;
	}

	// Token: 0x060011BF RID: 4543 RVA: 0x00025704 File Offset: 0x00023904
	[Token(Token = "0x60011BF")]
	[Address(RVA = "0x2D96580", Offset = "0x2D96580", VA = "0x2D96580")]
	public void method_35()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Faild To Add Winner Money: " + str;
		string str2;
		"_BumpScale" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"RainAndThunderWeather" + name;
	}

	// Token: 0x060011C0 RID: 4544 RVA: 0x00025768 File Offset: 0x00023968
	[Address(RVA = "0x2D967AC", Offset = "0x2D967AC", VA = "0x2D967AC")]
	[Token(Token = "0x60011C0")]
	public void method_36()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"typesOfTalk" + str;
	}

	// Token: 0x060011C1 RID: 4545 RVA: 0x000257AC File Offset: 0x000239AC
	[Token(Token = "0x60011C1")]
	[Address(RVA = "0x2D96844", Offset = "0x2D96844", VA = "0x2D96844")]
	public void method_37()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		".Please press the button if you would like to play alone" + str;
		string str2;
		"make more points bobo" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"/" + name;
	}

	// Token: 0x060011C2 RID: 4546 RVA: 0x00025810 File Offset: 0x00023A10
	[Token(Token = "0x60011C2")]
	[Address(RVA = "0x2D96A70", Offset = "0x2D96A70", VA = "0x2D96A70")]
	public void method_38()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x060011C3 RID: 4547 RVA: 0x00025840 File Offset: 0x00023A40
	[Address(RVA = "0x2D96B08", Offset = "0x2D96B08", VA = "0x2D96B08")]
	[Token(Token = "0x60011C3")]
	public void method_39()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Trying Getting Entilement..." + str;
	}

	// Token: 0x060011C4 RID: 4548 RVA: 0x00025884 File Offset: 0x00023A84
	[Token(Token = "0x60011C4")]
	[Address(RVA = "0x2D96BA0", Offset = "0x2D96BA0", VA = "0x2D96BA0")]
	public void method_40()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"forced knee" + str;
		string name = PhotonNetwork.CurrentRoom.name;
		"" + name;
	}

	// Token: 0x060011C5 RID: 4549 RVA: 0x000258DC File Offset: 0x00023ADC
	[Token(Token = "0x60011C5")]
	[Address(RVA = "0x2D96DCC", Offset = "0x2D96DCC", VA = "0x2D96DCC")]
	public void method_41()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Calling success callback. baking meshes" + str;
		string str2;
		"META" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"HandL" + name;
	}

	// Token: 0x060011C6 RID: 4550 RVA: 0x00025940 File Offset: 0x00023B40
	[Token(Token = "0x60011C6")]
	[Address(RVA = "0x2D96FF8", Offset = "0x2D96FF8", VA = "0x2D96FF8")]
	public void method_42()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"typesOfTalk" + str;
	}

	// Token: 0x060011C7 RID: 4551 RVA: 0x00025984 File Offset: 0x00023B84
	[Address(RVA = "0x2D97090", Offset = "0x2D97090", VA = "0x2D97090")]
	[Token(Token = "0x60011C7")]
	public void method_43()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		string str = PhotonNetwork.CountOfRooms.ToString();
		"Vector1_d371bd24217449349bd747533d51af6b" + str;
		string str2;
		"Failed to get catalog, cosmetic name, and price. Exact error details is: " + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"BLUTARG" + name;
	}

	// Token: 0x060011C8 RID: 4552 RVA: 0x000259E4 File Offset: 0x00023BE4
	[Token(Token = "0x60011C8")]
	[Address(RVA = "0x2D972BC", Offset = "0x2D972BC", VA = "0x2D972BC")]
	public void method_44()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Unpause" + str;
	}

	// Token: 0x060011C9 RID: 4553 RVA: 0x00025A28 File Offset: 0x00023C28
	[Address(RVA = "0x2D97354", Offset = "0x2D97354", VA = "0x2D97354")]
	[Token(Token = "0x60011C9")]
	public void method_45()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		" and the correct version is " + str;
	}

	// Token: 0x060011CA RID: 4554 RVA: 0x00025A6C File Offset: 0x00023C6C
	[Token(Token = "0x60011CA")]
	[Address(RVA = "0x2D973EC", Offset = "0x2D973EC", VA = "0x2D973EC")]
	public void method_46()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"sound play stopped" + str;
		string str2;
		"MetaAuth" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"BN" + name;
	}

	// Token: 0x060011CB RID: 4555 RVA: 0x00025AD0 File Offset: 0x00023CD0
	[Token(Token = "0x60011CB")]
	[Address(RVA = "0x2D97618", Offset = "0x2D97618", VA = "0x2D97618")]
	public void method_47()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"" + str;
	}

	// Token: 0x060011CC RID: 4556 RVA: 0x00025B14 File Offset: 0x00023D14
	[Address(RVA = "0x2D976B0", Offset = "0x2D976B0", VA = "0x2D976B0")]
	[Token(Token = "0x60011CC")]
	public void method_48()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"trol" + str;
		string str2;
		"Name Changing Error. Error: " + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"PURCHASED!" + name;
	}

	// Token: 0x060011CD RID: 4557 RVA: 0x00025B78 File Offset: 0x00023D78
	[Token(Token = "0x60011CD")]
	[Address(RVA = "0x2D978DC", Offset = "0x2D978DC", VA = "0x2D978DC")]
	public void method_49()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Vector1_d371bd24217449349bd747533d51af6b" + str;
	}

	// Token: 0x060011CE RID: 4558 RVA: 0x00025BBC File Offset: 0x00023DBC
	[Token(Token = "0x60011CE")]
	[Address(RVA = "0x2D97974", Offset = "0x2D97974", VA = "0x2D97974")]
	public void method_50()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"_Tint" + str;
		string str3;
		string str2 = "_Tint" + str3;
		Room currentRoom = PhotonNetwork.CurrentRoom;
		"Update User Inventory" + str2;
	}

	// Token: 0x060011CF RID: 4559 RVA: 0x00025C1C File Offset: 0x00023E1C
	[Token(Token = "0x60011CF")]
	[Address(RVA = "0x2D97B94", Offset = "0x2D97B94", VA = "0x2D97B94")]
	public void method_51()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Photon token acquired!" + str;
		string str2;
		"PlayerHead" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"You Already Own This Item" + name;
	}

	// Token: 0x060011D0 RID: 4560 RVA: 0x00025C80 File Offset: 0x00023E80
	[Token(Token = "0x60011D0")]
	[Address(RVA = "0x2D97DC0", Offset = "0x2D97DC0", VA = "0x2D97DC0")]
	public void method_52()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"EnableCosmetic" + str;
	}

	// Token: 0x060011D1 RID: 4561 RVA: 0x00025CC4 File Offset: 0x00023EC4
	[Address(RVA = "0x2D97E58", Offset = "0x2D97E58", VA = "0x2D97E58")]
	[Token(Token = "0x60011D1")]
	public void method_53()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string text;
		text + text;
		string str;
		"ENABLE" + str;
		string name = PhotonNetwork.CurrentRoom.name;
		"trol" + name;
	}

	// Token: 0x060011D2 RID: 4562 RVA: 0x00025D24 File Offset: 0x00023F24
	[Token(Token = "0x60011D2")]
	[Address(RVA = "0x2D98084", Offset = "0x2D98084", VA = "0x2D98084")]
	public void method_54()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"retract broken" + str;
		string str2;
		"true" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"PURCHASE" + name;
	}

	// Token: 0x060011D3 RID: 4563 RVA: 0x00025D88 File Offset: 0x00023F88
	[Token(Token = "0x60011D3")]
	[Address(RVA = "0x2D982B0", Offset = "0x2D982B0", VA = "0x2D982B0")]
	public void method_55()
	{
		bool inRoom = PhotonNetwork.InRoom;
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"FingerTip" + str;
		string str2;
		"False" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"EnableCosmetic" + name;
	}

	// Token: 0x060011D4 RID: 4564 RVA: 0x00025DE4 File Offset: 0x00023FE4
	[Address(RVA = "0x2D984DC", Offset = "0x2D984DC", VA = "0x2D984DC")]
	[Token(Token = "0x60011D4")]
	public void method_56()
	{
		bool inRoom = PhotonNetwork.InRoom;
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"sound play play" + str;
		string str2;
		"Vector1_d371bd24217449349bd747533d51af6b" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"DisableCosmetic" + name;
	}

	// Token: 0x060011D5 RID: 4565 RVA: 0x00025E40 File Offset: 0x00024040
	[Address(RVA = "0x2D98708", Offset = "0x2D98708", VA = "0x2D98708")]
	[Token(Token = "0x60011D5")]
	public void method_57()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x060011D6 RID: 4566 RVA: 0x000251C8 File Offset: 0x000233C8
	[Token(Token = "0x60011D6")]
	[Address(RVA = "0x2D987A0", Offset = "0x2D987A0", VA = "0x2D987A0")]
	public void method_58()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Stopped Colliding" + str;
	}

	// Token: 0x060011D7 RID: 4567 RVA: 0x00025E70 File Offset: 0x00024070
	[Token(Token = "0x60011D7")]
	[Address(RVA = "0x2D98838", Offset = "0x2D98838", VA = "0x2D98838")]
	public void method_59()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"amongus" + str;
		string str2;
		"cheese" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"Failed to get catalog, cosmetic name, and price. Exact error details is: " + name;
	}

	// Token: 0x060011D8 RID: 4568 RVA: 0x00025ED4 File Offset: 0x000240D4
	[Token(Token = "0x60011D8")]
	[Address(RVA = "0x2D98A64", Offset = "0x2D98A64", VA = "0x2D98A64")]
	public void method_60()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"PURCHASED!" + str;
		string str2;
		"TurnAmount" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"sound play play" + name;
	}

	// Token: 0x060011D9 RID: 4569 RVA: 0x00025F38 File Offset: 0x00024138
	[Token(Token = "0x60011D9")]
	[Address(RVA = "0x2D98C90", Offset = "0x2D98C90", VA = "0x2D98C90")]
	public void Update()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Players Online: " + str;
		string str2;
		"Count of rooms " + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"Room Name: " + name;
	}

	// Token: 0x060011DA RID: 4570 RVA: 0x00025F9C File Offset: 0x0002419C
	[Token(Token = "0x60011DA")]
	[Address(RVA = "0x2D98E90", Offset = "0x2D98E90", VA = "0x2D98E90")]
	public void method_61()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"We don't need this electrical box" + str;
	}

	// Token: 0x060011DB RID: 4571 RVA: 0x00025FE0 File Offset: 0x000241E0
	[Token(Token = "0x60011DB")]
	[Address(RVA = "0x2D98F28", Offset = "0x2D98F28", VA = "0x2D98F28")]
	public void method_62()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"You are not the master of the server, you cannot start the game." + str;
		string str2;
		"We don't need this electrical box" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"Date: " + name;
	}

	// Token: 0x060011DC RID: 4572 RVA: 0x00026044 File Offset: 0x00024244
	[Token(Token = "0x60011DC")]
	[Address(RVA = "0x2D99154", Offset = "0x2D99154", VA = "0x2D99154")]
	public void method_63()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"User has been reported for: " + str;
	}

	// Token: 0x060011DD RID: 4573 RVA: 0x00026088 File Offset: 0x00024288
	[Address(RVA = "0x2D991EC", Offset = "0x2D991EC", VA = "0x2D991EC")]
	[Token(Token = "0x60011DD")]
	public void method_64()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Creating and loadingtexture" + str;
		string str2;
		"retract broken" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"betaAgree" + name;
	}

	// Token: 0x060011DE RID: 4574 RVA: 0x000260EC File Offset: 0x000242EC
	[Token(Token = "0x60011DE")]
	[Address(RVA = "0x2D99418", Offset = "0x2D99418", VA = "0x2D99418")]
	public void method_65()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Add/Remove Sword" + str;
	}

	// Token: 0x060011DF RID: 4575 RVA: 0x0002562C File Offset: 0x0002382C
	[Token(Token = "0x60011DF")]
	[Address(RVA = "0x2D994B0", Offset = "0x2D994B0", VA = "0x2D994B0")]
	public void method_66()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"Not enough amount of currency" + str;
	}

	// Token: 0x060011E0 RID: 4576 RVA: 0x00026130 File Offset: 0x00024330
	[Address(RVA = "0x2D99548", Offset = "0x2D99548", VA = "0x2D99548")]
	[Token(Token = "0x60011E0")]
	public void method_67()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"retract broken" + str;
	}

	// Token: 0x060011E1 RID: 4577 RVA: 0x00026174 File Offset: 0x00024374
	[Token(Token = "0x60011E1")]
	[Address(RVA = "0x2D995E0", Offset = "0x2D995E0", VA = "0x2D995E0")]
	public void method_68()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		string str = this.string_0;
		"ORGPORT" + str;
	}

	// Token: 0x060011E2 RID: 4578 RVA: 0x000261A8 File Offset: 0x000243A8
	[Token(Token = "0x60011E2")]
	[Address(RVA = "0x2D99678", Offset = "0x2D99678", VA = "0x2D99678")]
	public void method_69()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"_Tint" + str;
	}

	// Token: 0x060011E3 RID: 4579 RVA: 0x000261EC File Offset: 0x000243EC
	[Token(Token = "0x60011E3")]
	[Address(RVA = "0x2D99710", Offset = "0x2D99710", VA = "0x2D99710")]
	public void method_70()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"True" + str;
	}

	// Token: 0x060011E4 RID: 4580 RVA: 0x00026230 File Offset: 0x00024430
	[Address(RVA = "0x2D997A8", Offset = "0x2D997A8", VA = "0x2D997A8")]
	[Token(Token = "0x60011E4")]
	public void method_71()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string str;
		"Display Name Changed!" + str;
		string str2;
		"Update User Inventory" + str2;
		string name = PhotonNetwork.CurrentRoom.name;
		"NetworkPlayer" + name;
	}

	// Token: 0x060011E5 RID: 4581 RVA: 0x00026294 File Offset: 0x00024494
	[Address(RVA = "0x2D999C8", Offset = "0x2D999C8", VA = "0x2D999C8")]
	[Token(Token = "0x60011E5")]
	public void method_72()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		bool inRoom = PhotonNetwork.InRoom;
		if (num != 0L)
		{
		}
		int countOfPlayersOnMaster = PhotonNetwork.CountOfPlayersOnMaster;
		this.int_0 = countOfPlayersOnMaster;
		int countOfRooms = PhotonNetwork.CountOfRooms;
		string name = PhotonNetwork.CurrentRoom.name;
		"Player" + name;
	}

	// Token: 0x060011E6 RID: 4582 RVA: 0x000262E0 File Offset: 0x000244E0
	[Token(Token = "0x60011E6")]
	[Address(RVA = "0x2D99BE8", Offset = "0x2D99BE8", VA = "0x2D99BE8")]
	public void method_73()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		string str = this.string_0;
		"PRESS AGAIN TO CONFIRM" + str;
	}

	// Token: 0x0400027F RID: 639
	[Token(Token = "0x400027F")]
	[FieldOffset(Offset = "0x20")]
	public TextMeshPro textMeshPro_0;

	// Token: 0x04000280 RID: 640
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000280")]
	public TextMeshPro textMeshPro_1;

	// Token: 0x04000281 RID: 641
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000281")]
	public TextMeshPro textMeshPro_2;

	// Token: 0x04000282 RID: 642
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000282")]
	public int int_0;

	// Token: 0x04000283 RID: 643
	[Token(Token = "0x4000283")]
	[FieldOffset(Offset = "0x3C")]
	public int int_1;

	// Token: 0x04000284 RID: 644
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000284")]
	public TextMeshPro textMeshPro_3;

	// Token: 0x04000285 RID: 645
	[Token(Token = "0x4000285")]
	[FieldOffset(Offset = "0x48")]
	public string string_0;

	// Token: 0x04000286 RID: 646
	[Token(Token = "0x4000286")]
	[FieldOffset(Offset = "0x50")]
	public GameObject gameObject_0;

	// Token: 0x04000287 RID: 647
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000287")]
	public GameObject gameObject_1;
}
