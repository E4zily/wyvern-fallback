﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000034 RID: 52
[Token(Token = "0x2000034")]
public class EnableMoonGrav : MonoBehaviour
{
	// Token: 0x06000636 RID: 1590 RVA: 0x0000FF50 File Offset: 0x0000E150
	[Address(RVA = "0x10D65FC", Offset = "0x10D65FC", VA = "0x10D65FC")]
	[Token(Token = "0x6000636")]
	public void method_0(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 1L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000637 RID: 1591 RVA: 0x0000FFB0 File Offset: 0x0000E1B0
	[Token(Token = "0x6000637")]
	[Address(RVA = "0x10D6688", Offset = "0x10D6688", VA = "0x10D6688")]
	public void method_1(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 0L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 1L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000638 RID: 1592 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x10D6714", Offset = "0x10D6714", VA = "0x10D6714")]
	[Token(Token = "0x6000638")]
	public EnableMoonGrav()
	{
	}

	// Token: 0x06000639 RID: 1593 RVA: 0x00010010 File Offset: 0x0000E210
	[Address(RVA = "0x10D671C", Offset = "0x10D671C", VA = "0x10D671C")]
	[Token(Token = "0x6000639")]
	public void method_2(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 0L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 0L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600063A RID: 1594 RVA: 0x0000FFB0 File Offset: 0x0000E1B0
	[Address(RVA = "0x10D67A8", Offset = "0x10D67A8", VA = "0x10D67A8")]
	[Token(Token = "0x600063A")]
	public void OnTriggerEnter(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 0L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 1L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600063B RID: 1595 RVA: 0x00010070 File Offset: 0x0000E270
	[Token(Token = "0x600063B")]
	[Address(RVA = "0x10D6834", Offset = "0x10D6834", VA = "0x10D6834")]
	public void method_3(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 0L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600063C RID: 1596 RVA: 0x000100D0 File Offset: 0x0000E2D0
	[Address(RVA = "0x10D68C0", Offset = "0x10D68C0", VA = "0x10D68C0")]
	[Token(Token = "0x600063C")]
	public void method_4(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			return;
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 0L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600063D RID: 1597 RVA: 0x0000FFB0 File Offset: 0x0000E1B0
	[Address(RVA = "0x10D694C", Offset = "0x10D694C", VA = "0x10D694C")]
	[Token(Token = "0x600063D")]
	public void method_5(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 0L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 1L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600063E RID: 1598 RVA: 0x0000FFB0 File Offset: 0x0000E1B0
	[Address(RVA = "0x10D69D8", Offset = "0x10D69D8", VA = "0x10D69D8")]
	[Token(Token = "0x600063E")]
	public void method_6(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 0L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 1L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600063F RID: 1599 RVA: 0x00010070 File Offset: 0x0000E270
	[Token(Token = "0x600063F")]
	[Address(RVA = "0x10D6A64", Offset = "0x10D6A64", VA = "0x10D6A64")]
	public void method_7(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 0L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000640 RID: 1600 RVA: 0x00010128 File Offset: 0x0000E328
	[Address(RVA = "0x10D6AF0", Offset = "0x10D6AF0", VA = "0x10D6AF0")]
	[Token(Token = "0x6000640")]
	public void method_8(Collider collider_0)
	{
		string tag = base.gameObject.tag;
		string b = this.string_0;
		tag == b;
		GravityBody gravityBody;
		if (this.bool_0)
		{
			gravityBody = this.gravityBody_0;
			long enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		long enabled2 = 0L;
		gravityBody.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000641 RID: 1601 RVA: 0x0000FF50 File Offset: 0x0000E150
	[Address(RVA = "0x10D6B7C", Offset = "0x10D6B7C", VA = "0x10D6B7C")]
	[Token(Token = "0x6000641")]
	public void method_9(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 1L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000642 RID: 1602 RVA: 0x00010070 File Offset: 0x0000E270
	[Token(Token = "0x6000642")]
	[Address(RVA = "0x10D6C08", Offset = "0x10D6C08", VA = "0x10D6C08")]
	public void method_10(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 0L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000643 RID: 1603 RVA: 0x0000FFB0 File Offset: 0x0000E1B0
	[Token(Token = "0x6000643")]
	[Address(RVA = "0x10D6C94", Offset = "0x10D6C94", VA = "0x10D6C94")]
	public void method_11(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 0L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 1L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000644 RID: 1604 RVA: 0x00010070 File Offset: 0x0000E270
	[Token(Token = "0x6000644")]
	[Address(RVA = "0x10D6D20", Offset = "0x10D6D20", VA = "0x10D6D20")]
	public void method_12(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 0L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000645 RID: 1605 RVA: 0x0000FFB0 File Offset: 0x0000E1B0
	[Token(Token = "0x6000645")]
	[Address(RVA = "0x10D6DAC", Offset = "0x10D6DAC", VA = "0x10D6DAC")]
	public void method_13(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 0L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 1L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000646 RID: 1606 RVA: 0x00010070 File Offset: 0x0000E270
	[Token(Token = "0x6000646")]
	[Address(RVA = "0x10D6E38", Offset = "0x10D6E38", VA = "0x10D6E38")]
	public void method_14(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 0L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000647 RID: 1607 RVA: 0x00010180 File Offset: 0x0000E380
	[Address(RVA = "0x10D6EC4", Offset = "0x10D6EC4", VA = "0x10D6EC4")]
	[Token(Token = "0x6000647")]
	public void method_15(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		long enabled;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		this.gravityBody_0.enabled = (enabled != 0L);
	}

	// Token: 0x06000648 RID: 1608 RVA: 0x0000FF50 File Offset: 0x0000E150
	[Address(RVA = "0x10D6F50", Offset = "0x10D6F50", VA = "0x10D6F50")]
	[Token(Token = "0x6000648")]
	public void method_16(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 1L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 1L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000649 RID: 1609 RVA: 0x0000FFB0 File Offset: 0x0000E1B0
	[Address(RVA = "0x10D6FDC", Offset = "0x10D6FDC", VA = "0x10D6FDC")]
	[Token(Token = "0x6000649")]
	public void method_17(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GravityBody gravityBody = this.gravityBody_0;
			long enabled = 0L;
			gravityBody.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GravityBody gravityBody2 = this.gravityBody_0;
		long enabled2 = 1L;
		gravityBody2.enabled = (enabled2 != 0L);
	}

	// Token: 0x0600064A RID: 1610 RVA: 0x0000ABE0 File Offset: 0x00008DE0
	[Token(Token = "0x600064A")]
	[Address(RVA = "0x10D7068", Offset = "0x10D7068", VA = "0x10D7068")]
	public void method_18(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
	}

	// Token: 0x040000F0 RID: 240
	[Token(Token = "0x40000F0")]
	[FieldOffset(Offset = "0x18")]
	public bool bool_0;

	// Token: 0x040000F1 RID: 241
	[Token(Token = "0x40000F1")]
	[FieldOffset(Offset = "0x20")]
	public GravityBody gravityBody_0;

	// Token: 0x040000F2 RID: 242
	[Token(Token = "0x40000F2")]
	[FieldOffset(Offset = "0x28")]
	public string string_0;
}
