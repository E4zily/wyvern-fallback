﻿using System;
using System.Collections;
using Cpp2IlInjected;
using DigitalOpus.MB.Core;
using UnityEngine;

// Token: 0x0200007E RID: 126
[Token(Token = "0x200007E")]
public class BakeTexturesAtRuntime : MonoBehaviour
{
	// Token: 0x060011E7 RID: 4583 RVA: 0x00026324 File Offset: 0x00024524
	[Address(RVA = "0x2BFB9A0", Offset = "0x2BFB9A0", VA = "0x2BFB9A0")]
	[Token(Token = "0x60011E7")]
	private void method_0()
	{
		Debug.Log("Cheating");
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		this.gameObject_0.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.ԥک\u0830\u0618 ԥک_u0830_u0618_ = this.ԥک\u0830\u0618_0;
		bool u0604ӏӺ_u06D;
		if (!(u0604ӏӺ_u06D = ԥک_u0830_u0618_.\u0604ӏӺ\u06D9) || !ԥک_u0830_u0618_.Ӭ\u0558շ\u07BF)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Wear Hoodie" + str;
		if (u0604ӏӺ_u06D)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x060011E8 RID: 4584 RVA: 0x00026390 File Offset: 0x00024590
	[Token(Token = "0x60011E8")]
	[Address(RVA = "0x2BFBBA8", Offset = "0x2BFBBA8", VA = "0x2BFBBA8")]
	private void method_1()
	{
		Debug.Log("Calling success callback. baking meshes");
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		this.gameObject_0.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.ԥک\u0830\u0618 ԥک_u0830_u0618_ = this.ԥک\u0830\u0618_0;
		bool u0604ӏӺ_u06D;
		if (!(u0604ӏӺ_u06D = ԥک_u0830_u0618_.\u0604ӏӺ\u06D9) || !ԥک_u0830_u0618_.Ӭ\u0558շ\u07BF)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Completed baking textures on frame " + str;
		if (u0604ӏӺ_u06D)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x060011E9 RID: 4585 RVA: 0x000263FC File Offset: 0x000245FC
	[Token(Token = "0x60011E9")]
	[Address(RVA = "0x2BFBDB0", Offset = "0x2BFBDB0", VA = "0x2BFBDB0")]
	public string method_2()
	{
		ض\u05BAࢴ\u0893.٩گՅࢶ();
		ض\u05BAࢴ\u0893.٩گՅࢶ();
		return "FingerTip";
	}

	// Token: 0x060011EA RID: 4586 RVA: 0x0002641C File Offset: 0x0002461C
	[Token(Token = "0x60011EA")]
	[Address(RVA = "0x2BFBE40", Offset = "0x2BFBE40", VA = "0x2BFBE40")]
	private void method_3()
	{
		Debug.Log("Players Online: ");
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		this.gameObject_0.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.ԥک\u0830\u0618 ԥک_u0830_u0618_ = this.ԥک\u0830\u0618_0;
		bool u0604ӏӺ_u06D = ԥک_u0830_u0618_.\u0604ӏӺ\u06D9;
		if (!ԥک_u0830_u0618_.Ӭ\u0558շ\u07BF)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "{0}/{1:f0}" + str;
		if (u0604ӏӺ_u06D)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x060011EB RID: 4587 RVA: 0x00026488 File Offset: 0x00024688
	[Address(RVA = "0x2BFC048", Offset = "0x2BFC048", VA = "0x2BFC048")]
	[Token(Token = "0x60011EB")]
	private void method_4()
	{
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		this.gameObject_0.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.ԥک\u0830\u0618 ԥک_u0830_u0618_ = this.ԥک\u0830\u0618_0;
		bool u0604ӏӺ_u06D;
		if (!(u0604ӏӺ_u06D = ԥک_u0830_u0618_.\u0604ӏӺ\u06D9) || !ԥک_u0830_u0618_.Ӭ\u0558շ\u07BF)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Name Changing Error. Error: " + str;
		if (u0604ӏӺ_u06D)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x060011EC RID: 4588 RVA: 0x000264EC File Offset: 0x000246EC
	[Address(RVA = "0x2BFC250", Offset = "0x2BFC250", VA = "0x2BFC250")]
	[Token(Token = "0x60011EC")]
	public string method_5()
	{
		ض\u05BAࢴ\u0893.٩گՅࢶ();
		ض\u05BAࢴ\u0893.٩گՅࢶ();
		return "/";
	}

	// Token: 0x060011ED RID: 4589 RVA: 0x0002650C File Offset: 0x0002470C
	[Token(Token = "0x60011ED")]
	[Address(RVA = "0x2BFC2E0", Offset = "0x2BFC2E0", VA = "0x2BFC2E0")]
	public BakeTexturesAtRuntime()
	{
		MB3_TextureCombiner.ԥک\u0830\u0618 ԥک_u0830_u0618_ = new MB3_TextureCombiner.ԥک\u0830\u0618();
		this.ԥک\u0830\u0618_0 = ԥک_u0830_u0618_;
		base..ctor();
	}

	// Token: 0x060011EE RID: 4590 RVA: 0x0002652C File Offset: 0x0002472C
	[Address(RVA = "0x2BFC350", Offset = "0x2BFC350", VA = "0x2BFC350")]
	[Token(Token = "0x60011EE")]
	private void method_6()
	{
		Debug.Log("trol");
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		this.gameObject_0.GetComponent<MB3_TextureBaker>();
		MB3_TextureCombiner.ԥک\u0830\u0618 ԥک_u0830_u0618_ = this.ԥک\u0830\u0618_0;
		bool u0604ӏӺ_u06D;
		if (!(u0604ӏӺ_u06D = ԥک_u0830_u0618_.\u0604ӏӺ\u06D9) || !ԥک_u0830_u0618_.Ӭ\u0558շ\u07BF)
		{
		}
		string str = Time.frameCount.ToString();
		string message = "Left Hand" + str;
		if (u0604ӏӺ_u06D)
		{
		}
		Debug.Log(message);
	}

	// Token: 0x060011EF RID: 4591 RVA: 0x00026598 File Offset: 0x00024798
	[Token(Token = "0x60011EF")]
	[Address(RVA = "0x2BFC558", Offset = "0x2BFC558", VA = "0x2BFC558")]
	public string method_7()
	{
		ض\u05BAࢴ\u0893.٩گՅࢶ();
		ض\u05BAࢴ\u0893.٩گՅࢶ();
		return "Name Changing Error. Error: ";
	}

	// Token: 0x060011F0 RID: 4592 RVA: 0x000265B8 File Offset: 0x000247B8
	[Token(Token = "0x60011F0")]
	[Address(RVA = "0x2BFC5E8", Offset = "0x2BFC5E8", VA = "0x2BFC5E8")]
	private void method_8()
	{
		Debug.Log("You struck apon an error. ");
		MB3_MeshBaker componentInChildren = this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		GameObject gameObject = this.gameObject_0;
		gameObject.GetComponent<MB3_TextureBaker>();
		if (gameObject.m_CachedPtr == 0)
		{
		}
		string str = Time.frameCount.ToString();
		"containsStaff" + str;
		Debug.Log(componentInChildren);
	}

	// Token: 0x060011F1 RID: 4593 RVA: 0x00026610 File Offset: 0x00024810
	[Address(RVA = "0x2BFC7F0", Offset = "0x2BFC7F0", VA = "0x2BFC7F0")]
	[Token(Token = "0x60011F1")]
	private void method_9()
	{
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.gameObject_0.GetComponent<MB3_TextureBaker>();
		ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		component.\u05AE\u059B\u05FC\u0705();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str = Time.frameCount.ToString();
		string message = "sound play stopped" + str;
		Debug.Log(message);
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		this.gameObject_0.GetComponent<MB3_TextureBaker>();
		ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		new Material(Shader.Find(name2));
		IEnumerator routine;
		base.StartCoroutine(routine);
	}

	// Token: 0x060011F2 RID: 4594 RVA: 0x000266B4 File Offset: 0x000248B4
	[Address(RVA = "0x2BFCEA0", Offset = "0x2BFCEA0", VA = "0x2BFCEA0")]
	[Token(Token = "0x60011F2")]
	public string method_10()
	{
		ض\u05BAࢴ\u0893.٩گՅࢶ();
		ض\u05BAࢴ\u0893.٩گՅࢶ();
		return "Diffuse";
	}

	// Token: 0x060011F3 RID: 4595 RVA: 0x000266D4 File Offset: 0x000248D4
	[Token(Token = "0x60011F3")]
	[Address(RVA = "0x2BFCF30", Offset = "0x2BFCF30", VA = "0x2BFCF30")]
	private void OnGUI()
	{
		string str;
		"Time to bake textures: " + str;
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.gameObject_0.GetComponent<MB3_TextureBaker>();
		ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		component.\u05AE\u059B\u05FC\u0705();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "Starting to bake textures on frame " + str2;
		Debug.Log(message);
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		this.gameObject_0.GetComponent<MB3_TextureBaker>();
		ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		new Material(Shader.Find(name2));
		IEnumerator routine;
		base.StartCoroutine(routine);
	}

	// Token: 0x060011F4 RID: 4596 RVA: 0x00026784 File Offset: 0x00024984
	[Token(Token = "0x60011F4")]
	[Address(RVA = "0x2BFD5E0", Offset = "0x2BFD5E0", VA = "0x2BFD5E0")]
	private void method_11()
	{
		string str;
		"You have been banned for " + str;
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		MB3_TextureBaker component = this.gameObject_0.GetComponent<MB3_TextureBaker>();
		ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name;
		new Material(Shader.Find(name));
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		component.\u05AE\u059B\u05FC\u0705();
		float realtimeSinceStartup2 = Time.realtimeSinceStartup;
		string str2 = Time.frameCount.ToString();
		string message = "DISABLE" + str2;
		Debug.Log(message);
		this.gameObject_0.GetComponentInChildren<MB3_MeshBaker>();
		this.gameObject_0.GetComponent<MB3_TextureBaker>();
		ScriptableObject.CreateInstance<MB2_TextureBakeResults>();
		string name2;
		new Material(Shader.Find(name2));
		IEnumerator routine;
		base.StartCoroutine(routine);
	}

	// Token: 0x060011F5 RID: 4597 RVA: 0x00026834 File Offset: 0x00024A34
	[Address(RVA = "0x2BFDC74", Offset = "0x2BFDC74", VA = "0x2BFDC74")]
	[Token(Token = "0x60011F5")]
	public string method_12()
	{
		ض\u05BAࢴ\u0893.٩گՅࢶ();
		ض\u05BAࢴ\u0893.٩گՅࢶ();
		return "BLUPORT";
	}

	// Token: 0x04000288 RID: 648
	[Token(Token = "0x4000288")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;

	// Token: 0x04000289 RID: 649
	[Token(Token = "0x4000289")]
	[FieldOffset(Offset = "0x20")]
	private float float_0;

	// Token: 0x0400028A RID: 650
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400028A")]
	private MB3_TextureCombiner.ԥک\u0830\u0618 ԥک\u0830\u0618_0;
}
