﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000065 RID: 101
[Token(Token = "0x2000065")]
public class AiTarget : MonoBehaviour
{
	// Token: 0x06000DCA RID: 3530 RVA: 0x0001DCB8 File Offset: 0x0001BEB8
	[Token(Token = "0x6000DCA")]
	[Address(RVA = "0x2BF5A6C", Offset = "0x2BF5A6C", VA = "0x2BF5A6C")]
	private void method_0()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_27();
	}

	// Token: 0x06000DCB RID: 3531 RVA: 0x0001DCFC File Offset: 0x0001BEFC
	[Address(RVA = "0x2BF5BA4", Offset = "0x2BF5BA4", VA = "0x2BF5BA4")]
	[Token(Token = "0x6000DCB")]
	private void method_1()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_9();
	}

	// Token: 0x06000DCC RID: 3532 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Token(Token = "0x6000DCC")]
	[Address(RVA = "0x2BF5CDC", Offset = "0x2BF5CDC", VA = "0x2BF5CDC")]
	public void method_2()
	{
	}

	// Token: 0x06000DCD RID: 3533 RVA: 0x0001DD50 File Offset: 0x0001BF50
	[Token(Token = "0x6000DCD")]
	[Address(RVA = "0x2BF5D58", Offset = "0x2BF5D58", VA = "0x2BF5D58")]
	private void method_3()
	{
		int maxExclusive = this.int_0;
		UnityEngine.Random.Range(1, maxExclusive);
	}

	// Token: 0x06000DCE RID: 3534 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF5E90", Offset = "0x2BF5E90", VA = "0x2BF5E90")]
	[Token(Token = "0x6000DCE")]
	public void method_4()
	{
	}

	// Token: 0x06000DCF RID: 3535 RVA: 0x0001DD6C File Offset: 0x0001BF6C
	[Address(RVA = "0x2BF5F0C", Offset = "0x2BF5F0C", VA = "0x2BF5F0C")]
	[Token(Token = "0x6000DCF")]
	private void method_5()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_2();
	}

	// Token: 0x06000DD0 RID: 3536 RVA: 0x0001DDB0 File Offset: 0x0001BFB0
	[Token(Token = "0x6000DD0")]
	[Address(RVA = "0x2BF5FC8", Offset = "0x2BF5FC8", VA = "0x2BF5FC8")]
	private void method_6()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_18();
	}

	// Token: 0x06000DD1 RID: 3537 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF6100", Offset = "0x2BF6100", VA = "0x2BF6100")]
	[Token(Token = "0x6000DD1")]
	public void method_7()
	{
	}

	// Token: 0x06000DD2 RID: 3538 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Token(Token = "0x6000DD2")]
	[Address(RVA = "0x2BF617C", Offset = "0x2BF617C", VA = "0x2BF617C")]
	public void method_8()
	{
	}

	// Token: 0x06000DD3 RID: 3539 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Token(Token = "0x6000DD3")]
	[Address(RVA = "0x2BF5C60", Offset = "0x2BF5C60", VA = "0x2BF5C60")]
	public void method_9()
	{
	}

	// Token: 0x06000DD4 RID: 3540 RVA: 0x0001DDF4 File Offset: 0x0001BFF4
	[Token(Token = "0x6000DD4")]
	[Address(RVA = "0x2BF61F8", Offset = "0x2BF61F8", VA = "0x2BF61F8")]
	private void method_10()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_16();
	}

	// Token: 0x06000DD5 RID: 3541 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF6330", Offset = "0x2BF6330", VA = "0x2BF6330")]
	[Token(Token = "0x6000DD5")]
	public void method_11()
	{
	}

	// Token: 0x06000DD6 RID: 3542 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF63AC", Offset = "0x2BF63AC", VA = "0x2BF63AC")]
	[Token(Token = "0x6000DD6")]
	public void method_12()
	{
	}

	// Token: 0x06000DD7 RID: 3543 RVA: 0x0001DE38 File Offset: 0x0001C038
	[Address(RVA = "0x2BF6428", Offset = "0x2BF6428", VA = "0x2BF6428")]
	[Token(Token = "0x6000DD7")]
	private void Update()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_15();
	}

	// Token: 0x06000DD8 RID: 3544 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2BF655C", Offset = "0x2BF655C", VA = "0x2BF655C")]
	[Token(Token = "0x6000DD8")]
	public AiTarget()
	{
	}

	// Token: 0x06000DD9 RID: 3545 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF6564", Offset = "0x2BF6564", VA = "0x2BF6564")]
	[Token(Token = "0x6000DD9")]
	public void method_13()
	{
	}

	// Token: 0x06000DDA RID: 3546 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF65E0", Offset = "0x2BF65E0", VA = "0x2BF65E0")]
	[Token(Token = "0x6000DDA")]
	public void method_14()
	{
	}

	// Token: 0x06000DDB RID: 3547 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF64E0", Offset = "0x2BF64E0", VA = "0x2BF64E0")]
	[Token(Token = "0x6000DDB")]
	public void method_15()
	{
	}

	// Token: 0x06000DDC RID: 3548 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF62B4", Offset = "0x2BF62B4", VA = "0x2BF62B4")]
	[Token(Token = "0x6000DDC")]
	public void method_16()
	{
	}

	// Token: 0x06000DDD RID: 3549 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF5E14", Offset = "0x2BF5E14", VA = "0x2BF5E14")]
	[Token(Token = "0x6000DDD")]
	public void method_17()
	{
	}

	// Token: 0x06000DDE RID: 3550 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF6084", Offset = "0x2BF6084", VA = "0x2BF6084")]
	[Token(Token = "0x6000DDE")]
	public void method_18()
	{
	}

	// Token: 0x06000DDF RID: 3551 RVA: 0x0001DE7C File Offset: 0x0001C07C
	[Address(RVA = "0x2BF665C", Offset = "0x2BF665C", VA = "0x2BF665C")]
	[Token(Token = "0x6000DDF")]
	private void method_19()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_4();
	}

	// Token: 0x06000DE0 RID: 3552 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF6718", Offset = "0x2BF6718", VA = "0x2BF6718")]
	[Token(Token = "0x6000DE0")]
	public void method_20()
	{
	}

	// Token: 0x06000DE1 RID: 3553 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF6794", Offset = "0x2BF6794", VA = "0x2BF6794")]
	[Token(Token = "0x6000DE1")]
	public void method_21()
	{
	}

	// Token: 0x06000DE2 RID: 3554 RVA: 0x0001DEC0 File Offset: 0x0001C0C0
	[Address(RVA = "0x2BF6810", Offset = "0x2BF6810", VA = "0x2BF6810")]
	[Token(Token = "0x6000DE2")]
	private void method_22()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_11();
	}

	// Token: 0x06000DE3 RID: 3555 RVA: 0x0001DF04 File Offset: 0x0001C104
	[Address(RVA = "0x2BF68CC", Offset = "0x2BF68CC", VA = "0x2BF68CC")]
	[Token(Token = "0x6000DE3")]
	private void method_23()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_25();
	}

	// Token: 0x06000DE4 RID: 3556 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Token(Token = "0x6000DE4")]
	[Address(RVA = "0x2BF6A04", Offset = "0x2BF6A04", VA = "0x2BF6A04")]
	public void method_24()
	{
	}

	// Token: 0x06000DE5 RID: 3557 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Token(Token = "0x6000DE5")]
	[Address(RVA = "0x2BF6988", Offset = "0x2BF6988", VA = "0x2BF6988")]
	public void method_25()
	{
	}

	// Token: 0x06000DE6 RID: 3558 RVA: 0x0001DF48 File Offset: 0x0001C148
	[Address(RVA = "0x2BF6A80", Offset = "0x2BF6A80", VA = "0x2BF6A80")]
	[Token(Token = "0x6000DE6")]
	private void method_26()
	{
		Transform transform = this.transform_1;
		this.int_1 = 0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_16();
	}

	// Token: 0x06000DE7 RID: 3559 RVA: 0x0001DD40 File Offset: 0x0001BF40
	[Address(RVA = "0x2BF5B28", Offset = "0x2BF5B28", VA = "0x2BF5B28")]
	[Token(Token = "0x6000DE7")]
	public void method_27()
	{
	}

	// Token: 0x06000DE8 RID: 3560 RVA: 0x0001DF7C File Offset: 0x0001C17C
	[Token(Token = "0x6000DE8")]
	[Address(RVA = "0x2BF6B3C", Offset = "0x2BF6B3C", VA = "0x2BF6B3C")]
	private void method_28()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(0, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_17();
	}

	// Token: 0x06000DE9 RID: 3561 RVA: 0x0001DFC0 File Offset: 0x0001C1C0
	[Token(Token = "0x6000DE9")]
	[Address(RVA = "0x2BF6BF8", Offset = "0x2BF6BF8", VA = "0x2BF6BF8")]
	private void method_29()
	{
		int maxExclusive = this.int_0;
		int num = UnityEngine.Random.Range(1, maxExclusive);
		Transform transform = this.transform_1;
		this.int_1 = num;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.method_11();
	}

	// Token: 0x04000208 RID: 520
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000208")]
	public Transform[] transform_0;

	// Token: 0x04000209 RID: 521
	[Token(Token = "0x4000209")]
	[FieldOffset(Offset = "0x20")]
	public Transform transform_1;

	// Token: 0x0400020A RID: 522
	[Token(Token = "0x400020A")]
	[FieldOffset(Offset = "0x28")]
	public Transform transform_2;

	// Token: 0x0400020B RID: 523
	[Token(Token = "0x400020B")]
	[FieldOffset(Offset = "0x30")]
	public Transform transform_3;

	// Token: 0x0400020C RID: 524
	[Token(Token = "0x400020C")]
	[FieldOffset(Offset = "0x38")]
	public int int_0;

	// Token: 0x0400020D RID: 525
	[Token(Token = "0x400020D")]
	[FieldOffset(Offset = "0x3C")]
	private int int_1;

	// Token: 0x0400020E RID: 526
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400020E")]
	public float float_0;
}
