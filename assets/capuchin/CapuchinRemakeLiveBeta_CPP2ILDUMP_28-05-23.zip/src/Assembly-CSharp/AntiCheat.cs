﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000002 RID: 2
[Token(Token = "0x2000002")]
public class AntiCheat : MonoBehaviour
{
	// Token: 0x06000001 RID: 1 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF6CB4", Offset = "0x2BF6CB4", VA = "0x2BF6CB4")]
	[Token(Token = "0x6000001")]
	private void method_0()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000002 RID: 2 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF6E38", Offset = "0x2BF6E38", VA = "0x2BF6E38")]
	[Token(Token = "0x6000002")]
	private void method_1()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000003")]
	[Address(RVA = "0x2BF6FBC", Offset = "0x2BF6FBC", VA = "0x2BF6FBC")]
	private void method_2()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000004 RID: 4 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000004")]
	[Address(RVA = "0x2BF7140", Offset = "0x2BF7140", VA = "0x2BF7140")]
	private void method_3()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000005 RID: 5 RVA: 0x0000394C File Offset: 0x00001B4C
	[Address(RVA = "0x2BF72C4", Offset = "0x2BF72C4", VA = "0x2BF72C4")]
	[Token(Token = "0x6000005")]
	private void method_4()
	{
		this.gameObject_0.GetComponent<Rigidbody>();
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000006 RID: 6 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000006")]
	[Address(RVA = "0x2BF7448", Offset = "0x2BF7448", VA = "0x2BF7448")]
	private void method_5()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000007 RID: 7 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000007")]
	[Address(RVA = "0x2BF6DC0", Offset = "0x2BF6DC0", VA = "0x2BF6DC0")]
	private IEnumerator method_6()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000008 RID: 8 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000008")]
	[Address(RVA = "0x2BF75CC", Offset = "0x2BF75CC", VA = "0x2BF75CC")]
	private IEnumerator method_7()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000009 RID: 9 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF7644", Offset = "0x2BF7644", VA = "0x2BF7644")]
	[Token(Token = "0x6000009")]
	private void method_8()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000A RID: 10 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF77C8", Offset = "0x2BF77C8", VA = "0x2BF77C8")]
	[Token(Token = "0x600000A")]
	private void method_9()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000B RID: 11 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF794C", Offset = "0x2BF794C", VA = "0x2BF794C")]
	[Token(Token = "0x600000B")]
	private void method_10()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF7AD0", Offset = "0x2BF7AD0", VA = "0x2BF7AD0")]
	[Token(Token = "0x600000C")]
	private void method_11()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000D RID: 13 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600000D")]
	[Address(RVA = "0x2BF7C54", Offset = "0x2BF7C54", VA = "0x2BF7C54")]
	private void method_12()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000E RID: 14 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF7D60", Offset = "0x2BF7D60", VA = "0x2BF7D60")]
	[Token(Token = "0x600000E")]
	private void method_13()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600000F RID: 15 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600000F")]
	[Address(RVA = "0x2BF7E6C", Offset = "0x2BF7E6C", VA = "0x2BF7E6C")]
	private void method_14()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000010 RID: 16 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000010")]
	[Address(RVA = "0x2BF7F78", Offset = "0x2BF7F78", VA = "0x2BF7F78")]
	private IEnumerator method_15()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000011 RID: 17 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000011")]
	[Address(RVA = "0x2BF7FF0", Offset = "0x2BF7FF0", VA = "0x2BF7FF0")]
	private IEnumerator method_16()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000012 RID: 18 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000012")]
	[Address(RVA = "0x2BF70C8", Offset = "0x2BF70C8", VA = "0x2BF70C8")]
	private IEnumerator method_17()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000013 RID: 19 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000013")]
	[Address(RVA = "0x2BF8068", Offset = "0x2BF8068", VA = "0x2BF8068")]
	private IEnumerator method_18()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000014 RID: 20 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BF80E0", Offset = "0x2BF80E0", VA = "0x2BF80E0")]
	[Token(Token = "0x6000014")]
	private IEnumerator method_19()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000015 RID: 21 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000015")]
	[Address(RVA = "0x2BF8158", Offset = "0x2BF8158", VA = "0x2BF8158")]
	private void method_20()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000016 RID: 22 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF8264", Offset = "0x2BF8264", VA = "0x2BF8264")]
	[Token(Token = "0x6000016")]
	private void method_21()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000017 RID: 23 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BF83E4", Offset = "0x2BF83E4", VA = "0x2BF83E4")]
	[Token(Token = "0x6000017")]
	private IEnumerator method_22()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000018 RID: 24 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000018")]
	[Address(RVA = "0x2BF845C", Offset = "0x2BF845C", VA = "0x2BF845C")]
	public AntiCheat()
	{
	}

	// Token: 0x06000019 RID: 25 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BF8464", Offset = "0x2BF8464", VA = "0x2BF8464")]
	[Token(Token = "0x6000019")]
	private IEnumerator method_23()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600001A RID: 26 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600001A")]
	[Address(RVA = "0x2BF84DC", Offset = "0x2BF84DC", VA = "0x2BF84DC")]
	private void method_24()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600001B RID: 27 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF85E8", Offset = "0x2BF85E8", VA = "0x2BF85E8")]
	[Token(Token = "0x600001B")]
	private void method_25()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600001C")]
	[Address(RVA = "0x2BF876C", Offset = "0x2BF876C", VA = "0x2BF876C")]
	private void method_26()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600001D RID: 29 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600001D")]
	[Address(RVA = "0x2BF88F0", Offset = "0x2BF88F0", VA = "0x2BF88F0")]
	private void method_27()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600001E RID: 30 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF89FC", Offset = "0x2BF89FC", VA = "0x2BF89FC")]
	[Token(Token = "0x600001E")]
	private void method_28()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600001F RID: 31 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600001F")]
	[Address(RVA = "0x2BF8B80", Offset = "0x2BF8B80", VA = "0x2BF8B80")]
	private void method_29()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000020 RID: 32 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BF8D04", Offset = "0x2BF8D04", VA = "0x2BF8D04")]
	[Token(Token = "0x6000020")]
	private IEnumerator method_30()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000021 RID: 33 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF8D7C", Offset = "0x2BF8D7C", VA = "0x2BF8D7C")]
	[Token(Token = "0x6000021")]
	private void method_31()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000022 RID: 34 RVA: 0x00003994 File Offset: 0x00001B94
	[Address(RVA = "0x2BF8E88", Offset = "0x2BF8E88", VA = "0x2BF8E88")]
	[Token(Token = "0x6000022")]
	private void Update()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
		Vector3 vector2;
		float magnitude2 = vector2.magnitude;
		IEnumerator routine = this.method_22();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000023 RID: 35 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000023")]
	[Address(RVA = "0x2BF8F8C", Offset = "0x2BF8F8C", VA = "0x2BF8F8C")]
	private void method_32()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000024 RID: 36 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000024")]
	[Address(RVA = "0x2BF9098", Offset = "0x2BF9098", VA = "0x2BF9098")]
	private IEnumerator method_33()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000025 RID: 37 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000025")]
	[Address(RVA = "0x2BF9110", Offset = "0x2BF9110", VA = "0x2BF9110")]
	private IEnumerator method_34()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000026 RID: 38 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF9188", Offset = "0x2BF9188", VA = "0x2BF9188")]
	[Token(Token = "0x6000026")]
	private void method_35()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000027 RID: 39 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF9294", Offset = "0x2BF9294", VA = "0x2BF9294")]
	[Token(Token = "0x6000027")]
	private void method_36()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000028 RID: 40 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF93A0", Offset = "0x2BF93A0", VA = "0x2BF93A0")]
	[Token(Token = "0x6000028")]
	private void method_37()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000029 RID: 41 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000029")]
	[Address(RVA = "0x2BF9524", Offset = "0x2BF9524", VA = "0x2BF9524")]
	private IEnumerator method_38()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600002A RID: 42 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BF959C", Offset = "0x2BF959C", VA = "0x2BF959C")]
	[Token(Token = "0x600002A")]
	private IEnumerator method_39()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600002B RID: 43 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF9614", Offset = "0x2BF9614", VA = "0x2BF9614")]
	[Token(Token = "0x600002B")]
	private void method_40()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600002C RID: 44 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600002C")]
	[Address(RVA = "0x2BF9720", Offset = "0x2BF9720", VA = "0x2BF9720")]
	private void method_41()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600002D RID: 45 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600002D")]
	[Address(RVA = "0x2BF982C", Offset = "0x2BF982C", VA = "0x2BF982C")]
	private void method_42()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600002E RID: 46 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BF7554", Offset = "0x2BF7554", VA = "0x2BF7554")]
	[Token(Token = "0x600002E")]
	private IEnumerator method_43()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600002F RID: 47 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x600002F")]
	[Address(RVA = "0x2BF6F44", Offset = "0x2BF6F44", VA = "0x2BF6F44")]
	private IEnumerator method_44()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000030 RID: 48 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000030")]
	[Address(RVA = "0x2BF9938", Offset = "0x2BF9938", VA = "0x2BF9938")]
	private void method_45()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000031 RID: 49 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BF9A44", Offset = "0x2BF9A44", VA = "0x2BF9A44")]
	[Token(Token = "0x6000031")]
	private IEnumerator method_46()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000032 RID: 50 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000032")]
	[Address(RVA = "0x2BF7A58", Offset = "0x2BF7A58", VA = "0x2BF7A58")]
	private IEnumerator method_47()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000033 RID: 51 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000033")]
	[Address(RVA = "0x2BF8878", Offset = "0x2BF8878", VA = "0x2BF8878")]
	private IEnumerator method_48()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000034 RID: 52 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000034")]
	[Address(RVA = "0x2BF9ABC", Offset = "0x2BF9ABC", VA = "0x2BF9ABC")]
	private void method_49()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000035 RID: 53 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000035")]
	[Address(RVA = "0x2BF9BC8", Offset = "0x2BF9BC8", VA = "0x2BF9BC8")]
	private IEnumerator method_50()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000036 RID: 54 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000036")]
	[Address(RVA = "0x2BF9C40", Offset = "0x2BF9C40", VA = "0x2BF9C40")]
	private void method_51()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000037 RID: 55 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000037")]
	[Address(RVA = "0x2BF9D4C", Offset = "0x2BF9D4C", VA = "0x2BF9D4C")]
	private void method_52()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000038 RID: 56 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000038")]
	[Address(RVA = "0x2BF724C", Offset = "0x2BF724C", VA = "0x2BF724C")]
	private IEnumerator method_53()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000039 RID: 57 RVA: 0x000039D4 File Offset: 0x00001BD4
	[Address(RVA = "0x2BF8C8C", Offset = "0x2BF8C8C", VA = "0x2BF8C8C")]
	[Token(Token = "0x6000039")]
	private IEnumerator method_54()
	{
		new AntiCheat.Class0((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x0600003A RID: 58 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600003A")]
	[Address(RVA = "0x2BF9E58", Offset = "0x2BF9E58", VA = "0x2BF9E58")]
	private void method_55()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600003B RID: 59 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BF9F64", Offset = "0x2BF9F64", VA = "0x2BF9F64")]
	[Token(Token = "0x600003B")]
	private void method_56()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600003C RID: 60 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BFA070", Offset = "0x2BFA070", VA = "0x2BFA070")]
	[Token(Token = "0x600003C")]
	private IEnumerator method_57()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600003D RID: 61 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2BFA0E8", Offset = "0x2BFA0E8", VA = "0x2BFA0E8")]
	[Token(Token = "0x600003D")]
	private void method_58()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600003E RID: 62 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600003E")]
	[Address(RVA = "0x2BFA26C", Offset = "0x2BFA26C", VA = "0x2BFA26C")]
	private void method_59()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600003F RID: 63 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BFA378", Offset = "0x2BFA378", VA = "0x2BFA378")]
	[Token(Token = "0x600003F")]
	private void method_60()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000040 RID: 64 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000040")]
	[Address(RVA = "0x2BFA484", Offset = "0x2BFA484", VA = "0x2BFA484")]
	private IEnumerator method_61()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000041 RID: 65 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000041")]
	[Address(RVA = "0x2BFA4FC", Offset = "0x2BFA4FC", VA = "0x2BFA4FC")]
	private void method_62()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000042 RID: 66 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BFA608", Offset = "0x2BFA608", VA = "0x2BFA608")]
	[Token(Token = "0x6000042")]
	private void method_63()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000043 RID: 67 RVA: 0x000039F8 File Offset: 0x00001BF8
	[Address(RVA = "0x2BFA714", Offset = "0x2BFA714", VA = "0x2BFA714")]
	[Token(Token = "0x6000043")]
	private void method_64()
	{
		Rigidbody rigidbody;
		this.rigidbody_0 = rigidbody;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000044 RID: 68 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000044")]
	[Address(RVA = "0x2BFA820", Offset = "0x2BFA820", VA = "0x2BFA820")]
	private void method_65()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000045 RID: 69 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BFA9A4", Offset = "0x2BFA9A4", VA = "0x2BFA9A4")]
	[Token(Token = "0x6000045")]
	private void method_66()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000046 RID: 70 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BFAAB0", Offset = "0x2BFAAB0", VA = "0x2BFAAB0")]
	[Token(Token = "0x6000046")]
	private void method_67()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000047 RID: 71 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000047")]
	[Address(RVA = "0x2BF7BDC", Offset = "0x2BF7BDC", VA = "0x2BF7BDC")]
	private IEnumerator method_68()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000048 RID: 72 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BFABBC", Offset = "0x2BFABBC", VA = "0x2BFABBC")]
	[Token(Token = "0x6000048")]
	private void method_69()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000049 RID: 73 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000049")]
	[Address(RVA = "0x2BF73D0", Offset = "0x2BF73D0", VA = "0x2BF73D0")]
	private IEnumerator method_70()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600004A RID: 74 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BF94AC", Offset = "0x2BF94AC", VA = "0x2BF94AC")]
	[Token(Token = "0x600004A")]
	private IEnumerator method_71()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600004B RID: 75 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BF78D4", Offset = "0x2BF78D4", VA = "0x2BF78D4")]
	[Token(Token = "0x600004B")]
	private IEnumerator method_72()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600004C RID: 76 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BFA1F4", Offset = "0x2BFA1F4", VA = "0x2BFA1F4")]
	[Token(Token = "0x600004C")]
	private IEnumerator method_73()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600004D RID: 77 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600004D")]
	[Address(RVA = "0x2BFACC8", Offset = "0x2BFACC8", VA = "0x2BFACC8")]
	private void method_74()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600004E RID: 78 RVA: 0x000039D4 File Offset: 0x00001BD4
	[Address(RVA = "0x2BF8B08", Offset = "0x2BF8B08", VA = "0x2BF8B08")]
	[Token(Token = "0x600004E")]
	private IEnumerator method_75()
	{
		new AntiCheat.Class0((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x0600004F RID: 79 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BFADD4", Offset = "0x2BFADD4", VA = "0x2BFADD4")]
	[Token(Token = "0x600004F")]
	private void method_76()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000050 RID: 80 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000050")]
	[Address(RVA = "0x2BFAEE0", Offset = "0x2BFAEE0", VA = "0x2BFAEE0")]
	private void method_77()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000051 RID: 81 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000051")]
	[Address(RVA = "0x2BFA92C", Offset = "0x2BFA92C", VA = "0x2BFA92C")]
	private IEnumerator method_78()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000052 RID: 82 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000052")]
	[Address(RVA = "0x2BFAFEC", Offset = "0x2BFAFEC", VA = "0x2BFAFEC")]
	private IEnumerator method_79()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000053 RID: 83 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000053")]
	[Address(RVA = "0x2BF86F4", Offset = "0x2BF86F4", VA = "0x2BF86F4")]
	private IEnumerator method_80()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000054 RID: 84 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000054")]
	[Address(RVA = "0x2BFB064", Offset = "0x2BFB064", VA = "0x2BFB064")]
	private void method_81()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000055 RID: 85 RVA: 0x0000394C File Offset: 0x00001B4C
	[Address(RVA = "0x2BFB170", Offset = "0x2BFB170", VA = "0x2BFB170")]
	[Token(Token = "0x6000055")]
	private void method_82()
	{
		this.gameObject_0.GetComponent<Rigidbody>();
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000056 RID: 86 RVA: 0x00003924 File Offset: 0x00001B24
	[Address(RVA = "0x2BFB2F4", Offset = "0x2BFB2F4", VA = "0x2BFB2F4")]
	[Token(Token = "0x6000056")]
	private void method_83()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000057 RID: 87 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x6000057")]
	[Address(RVA = "0x2BFB400", Offset = "0x2BFB400", VA = "0x2BFB400")]
	private void method_84()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x06000058 RID: 88 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BFB50C", Offset = "0x2BFB50C", VA = "0x2BFB50C")]
	[Token(Token = "0x6000058")]
	private IEnumerator method_85()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000059 RID: 89 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x6000059")]
	[Address(RVA = "0x2BF836C", Offset = "0x2BF836C", VA = "0x2BF836C")]
	private IEnumerator method_86()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600005A RID: 90 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600005A")]
	[Address(RVA = "0x2BFB584", Offset = "0x2BFB584", VA = "0x2BFB584")]
	private void method_87()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600005B RID: 91 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x600005B")]
	[Address(RVA = "0x2BFB690", Offset = "0x2BFB690", VA = "0x2BFB690")]
	private IEnumerator method_88()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600005C RID: 92 RVA: 0x0000396C File Offset: 0x00001B6C
	[Token(Token = "0x600005C")]
	[Address(RVA = "0x2BFB27C", Offset = "0x2BFB27C", VA = "0x2BFB27C")]
	private IEnumerator method_89()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600005D RID: 93 RVA: 0x00003A14 File Offset: 0x00001C14
	[Address(RVA = "0x2BFB708", Offset = "0x2BFB708", VA = "0x2BFB708")]
	[Token(Token = "0x600005D")]
	private void method_90()
	{
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600005E RID: 94 RVA: 0x00003924 File Offset: 0x00001B24
	[Token(Token = "0x600005E")]
	[Address(RVA = "0x2BFB814", Offset = "0x2BFB814", VA = "0x2BFB814")]
	private void method_91()
	{
		Rigidbody component = this.gameObject_0.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Vector3 vector;
		float magnitude = vector.magnitude;
	}

	// Token: 0x0600005F RID: 95 RVA: 0x0000396C File Offset: 0x00001B6C
	[Address(RVA = "0x2BF7750", Offset = "0x2BF7750", VA = "0x2BF7750")]
	[Token(Token = "0x600005F")]
	private IEnumerator method_92()
	{
		AntiCheat.Class0 @class = new AntiCheat.Class0((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000060 RID: 96 RVA: 0x000039D4 File Offset: 0x00001BD4
	[Address(RVA = "0x2BFB920", Offset = "0x2BFB920", VA = "0x2BFB920")]
	[Token(Token = "0x6000060")]
	private IEnumerator method_93()
	{
		new AntiCheat.Class0((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x04000001 RID: 1
	[Token(Token = "0x4000001")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;

	// Token: 0x04000002 RID: 2
	[Token(Token = "0x4000002")]
	[FieldOffset(Offset = "0x20")]
	private Rigidbody rigidbody_0;

	// Token: 0x04000003 RID: 3
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000003")]
	public float float_0;

	// Token: 0x04000004 RID: 4
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x4000004")]
	public float float_1;

	// Token: 0x04000005 RID: 5
	[Token(Token = "0x4000005")]
	[FieldOffset(Offset = "0x30")]
	public GameObject gameObject_1;
}
