﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E9 RID: 233
[Token(Token = "0x20000E9")]
public class Report : MonoBehaviour
{
	// Token: 0x060022BE RID: 8894 RVA: 0x0003F4DC File Offset: 0x0003D6DC
	[Address(RVA = "0x2E013EC", Offset = "0x2E013EC", VA = "0x2E013EC")]
	[Token(Token = "0x60022BE")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "procedural animation script required on ";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_E5;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "Removing ";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "typesOfTalk";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "Vector1_d371bd24217449349bd747533d51af6b";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022BF RID: 8895 RVA: 0x0003F5EC File Offset: 0x0003D7EC
	[Address(RVA = "0x2E016BC", Offset = "0x2E016BC", VA = "0x2E016BC")]
	[Token(Token = "0x60022BF")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.tag == "Updating Material to: ";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_E5;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "TurnAmount";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "CapuchinRemade";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "ENABLE";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022C0 RID: 8896 RVA: 0x0003F6FC File Offset: 0x0003D8FC
	[Address(RVA = "0x2E0198C", Offset = "0x2E0198C", VA = "0x2E0198C")]
	[Token(Token = "0x60022C0")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.tag == "HorrorAgreement";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_E5;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "PlayWave";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "_Tint";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "_WobbleZ";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022C1 RID: 8897 RVA: 0x0003F80C File Offset: 0x0003DA0C
	[Address(RVA = "0x2E01C5C", Offset = "0x2E01C5C", VA = "0x2E01C5C")]
	[Token(Token = "0x60022C1")]
	private void method_3()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022C2 RID: 8898 RVA: 0x0003F85C File Offset: 0x0003DA5C
	[Address(RVA = "0x2E01CC8", Offset = "0x2E01CC8", VA = "0x2E01CC8")]
	[Token(Token = "0x60022C2")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.tag == "Display Name Changed!";
	}

	// Token: 0x060022C3 RID: 8899 RVA: 0x0003F880 File Offset: 0x0003DA80
	[Address(RVA = "0x2E01F98", Offset = "0x2E01F98", VA = "0x2E01F98")]
	[Token(Token = "0x60022C3")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_F0;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "FingerTip";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "{0}/{1:f0}";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "Fire Stick Is Lighting...";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022C4 RID: 8900 RVA: 0x0003F99C File Offset: 0x0003DB9C
	[Address(RVA = "0x2E02258", Offset = "0x2E02258", VA = "0x2E02258")]
	[Token(Token = "0x60022C4")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_FB;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "waited for your bullshit unity grrr";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "_Tint";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "{0}/{1:f0}";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long num3 = 1L;
			this.bool_0 = (num3 != 0L);
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_FB:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022C5 RID: 8901 RVA: 0x0003FAC4 File Offset: 0x0003DCC4
	[Address(RVA = "0x2E02530", Offset = "0x2E02530", VA = "0x2E02530")]
	[Token(Token = "0x60022C5")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_F4;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "Unpause";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "typesOfTalk";
			GameObject gameObject2 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		GameObject gameObject3;
		if (this.bool_4)
		{
			this.string_0 = "containsStaff";
			string message2;
			Debug.Log(message2);
			gameObject3 = this.gameObject_0;
			long num3 = 1L;
			this.bool_0 = (num3 != 0L);
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_F4:
		if (this.bool_1)
		{
			long active4 = 0L;
			gameObject3.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022C6 RID: 8902 RVA: 0x0003FBDC File Offset: 0x0003DDDC
	[Address(RVA = "0x2E027F4", Offset = "0x2E027F4", VA = "0x2E027F4")]
	[Token(Token = "0x60022C6")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.tag == "Joined a Room.";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_F0;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "TurnAmount";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "PLAYER IS BANNED";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "\n Time: ";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022C7 RID: 8903 RVA: 0x0003FCF8 File Offset: 0x0003DEF8
	[Address(RVA = "0x2E02AC8", Offset = "0x2E02AC8", VA = "0x2E02AC8")]
	[Token(Token = "0x60022C7")]
	private void method_9()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022C8 RID: 8904 RVA: 0x0003FD30 File Offset: 0x0003DF30
	[Address(RVA = "0x2E02B34", Offset = "0x2E02B34", VA = "0x2E02B34")]
	[Token(Token = "0x60022C8")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "HandL";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_E5;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "HandR";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "FingerTip";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "gamemode";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022C9 RID: 8905 RVA: 0x0003FE40 File Offset: 0x0003E040
	[Address(RVA = "0x2E02E04", Offset = "0x2E02E04", VA = "0x2E02E04")]
	[Token(Token = "0x60022C9")]
	private void method_11()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022CA RID: 8906 RVA: 0x0003FE90 File Offset: 0x0003E090
	[Address(RVA = "0x2E02E70", Offset = "0x2E02E70", VA = "0x2E02E70")]
	[Token(Token = "0x60022CA")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "MetaId";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_B2;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "Player";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			return;
		}
		if (this.bool_4)
		{
			this.string_0 = "You are on an outdated version of Capuchin. Your version is ";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		IL_B2:
		if (this.bool_1)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
			return;
		}
	}

	// Token: 0x060022CB RID: 8907 RVA: 0x0003FF6C File Offset: 0x0003E16C
	[Address(RVA = "0x2E03140", Offset = "0x2E03140", VA = "0x2E03140")]
	[Token(Token = "0x60022CB")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.tag == "CapuchinRemade";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_DC;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "On";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "INSIGNIFICANT CURRENCY";
			string message2;
			Debug.Log(message2);
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "FLSPTLT";
			string message3;
			Debug.Log(message3);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		IL_DC:
		if (this.bool_1)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
			return;
		}
	}

	// Token: 0x060022CC RID: 8908 RVA: 0x00040074 File Offset: 0x0003E274
	[Address(RVA = "0x2E03414", Offset = "0x2E03414", VA = "0x2E03414")]
	[Token(Token = "0x60022CC")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.tag == "SetColor";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_F0;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "Completed baking textures on frame ";
			long active = 0L;
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "FingerTip";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long num3 = 1L;
			this.bool_0 = (num3 != 0L);
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022CD RID: 8909 RVA: 0x00040190 File Offset: 0x0003E390
	[Address(RVA = "0x2E036D4", Offset = "0x2E036D4", VA = "0x2E036D4")]
	[Token(Token = "0x60022CD")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.tag == "XR Usage";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_E5;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "Cannot access index {0}. Buffer is empty";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "Player";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "ENABLE";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022CE RID: 8910 RVA: 0x000402A0 File Offset: 0x0003E4A0
	[Address(RVA = "0x2E039A4", Offset = "0x2E039A4", VA = "0x2E039A4")]
	[Token(Token = "0x60022CE")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_E5;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "Error";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "Key";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "Starting to bake textures on frame ";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022CF RID: 8911 RVA: 0x0003FE40 File Offset: 0x0003E040
	[Address(RVA = "0x2E03C74", Offset = "0x2E03C74", VA = "0x2E03C74")]
	[Token(Token = "0x60022CF")]
	private void method_17()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022D0 RID: 8912 RVA: 0x0003F80C File Offset: 0x0003DA0C
	[Address(RVA = "0x2E03CE0", Offset = "0x2E03CE0", VA = "0x2E03CE0")]
	[Token(Token = "0x60022D0")]
	private void method_18()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022D1 RID: 8913 RVA: 0x0003FE40 File Offset: 0x0003E040
	[Address(RVA = "0x2E03D4C", Offset = "0x2E03D4C", VA = "0x2E03D4C")]
	[Token(Token = "0x60022D1")]
	private void method_19()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022D2 RID: 8914 RVA: 0x000403B0 File Offset: 0x0003E5B0
	[Address(RVA = "0x2E03DB8", Offset = "0x2E03DB8", VA = "0x2E03DB8")]
	[Token(Token = "0x60022D2")]
	private void method_20()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022D3 RID: 8915 RVA: 0x00040400 File Offset: 0x0003E600
	[Address(RVA = "0x2E03E24", Offset = "0x2E03E24", VA = "0x2E03E24")]
	[Token(Token = "0x60022D3")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.tag == "";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_EC;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "Thumb";
			long active = 0L;
			string message;
			Debug.Log(message);
			this.gameObject_0.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "Count of rooms ";
			string message2;
			Debug.Log(message2);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active2 = 0L;
			gameObject.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "liftoff failed!";
			string message3;
			Debug.Log(message3);
			GameObject gameObject2 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active3 = 0L;
			gameObject2.SetActive(active3 != 0L);
		}
		IL_EC:
		if (this.bool_1)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active4 = 0L;
			gameObject3.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022D4 RID: 8916 RVA: 0x0003FE40 File Offset: 0x0003E040
	[Address(RVA = "0x2E040E4", Offset = "0x2E040E4", VA = "0x2E040E4")]
	[Token(Token = "0x60022D4")]
	private void method_22()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022D5 RID: 8917 RVA: 0x00040518 File Offset: 0x0003E718
	[Address(RVA = "0x2E04150", Offset = "0x2E04150", VA = "0x2E04150")]
	[Token(Token = "0x60022D5")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.tag == "Queue";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_F0;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "BN";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "Player";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = " and for the price of ";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022D6 RID: 8918 RVA: 0x00040634 File Offset: 0x0003E834
	[Address(RVA = "0x2E04424", Offset = "0x2E04424", VA = "0x2E04424")]
	[Token(Token = "0x60022D6")]
	private void method_24()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022D7 RID: 8919 RVA: 0x00040684 File Offset: 0x0003E884
	[Address(RVA = "0x2E04490", Offset = "0x2E04490", VA = "0x2E04490")]
	[Token(Token = "0x60022D7")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.tag == ". Please update you game to the latest version";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_FB;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "MetaId";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "Purchased: ";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "Player";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long num3 = 1L;
			this.bool_0 = (num3 != 0L);
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_FB:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022D8 RID: 8920 RVA: 0x000407AC File Offset: 0x0003E9AC
	[Address(RVA = "0x2E0475C", Offset = "0x2E0475C", VA = "0x2E0475C")]
	[Token(Token = "0x60022D8")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "hh:mmtt";
		bool flag;
		if (flag = this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (flag)
			{
				goto IL_F2;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "run";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		this.string_0 = "Player";
		string message2;
		Debug.Log(message2);
		GameObject gameObject2 = this.gameObject_0;
		long num2 = 1L;
		this.bool_0 = (num2 != 0L);
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		if (this.bool_4)
		{
			this.string_0 = "Horizontal";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long num3 = 1L;
			this.bool_0 = (num3 != 0L);
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_F2:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022D9 RID: 8921 RVA: 0x000408C8 File Offset: 0x0003EAC8
	[Address(RVA = "0x2E04A20", Offset = "0x2E04A20", VA = "0x2E04A20")]
	[Token(Token = "0x60022D9")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.tag == "Trigger";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_F0;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "SaveHeight";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "You are not the master of the server, you cannot start the game.";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "Cannot access an empty buffer.";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_F0:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022DA RID: 8922 RVA: 0x000409E4 File Offset: 0x0003EBE4
	[Address(RVA = "0x2E04CF4", Offset = "0x2E04CF4", VA = "0x2E04CF4")]
	[Token(Token = "0x60022DA")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.tag == "Holdable";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_E5;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "hand 2";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "got funky mone";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "username";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022DB RID: 8923 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2E04FC4", Offset = "0x2E04FC4", VA = "0x2E04FC4")]
	[Token(Token = "0x60022DB")]
	public Report()
	{
	}

	// Token: 0x060022DC RID: 8924 RVA: 0x000403B0 File Offset: 0x0003E5B0
	[Address(RVA = "0x2E04FCC", Offset = "0x2E04FCC", VA = "0x2E04FCC")]
	[Token(Token = "0x60022DC")]
	private void method_29()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022DD RID: 8925 RVA: 0x00040AF4 File Offset: 0x0003ECF4
	[Address(RVA = "0x2E05038", Offset = "0x2E05038", VA = "0x2E05038")]
	[Token(Token = "0x60022DD")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_CC;
			}
		}
		if (this.bool_2)
		{
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "Player";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "_Tint";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_CC:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022DE RID: 8926 RVA: 0x00040BEC File Offset: 0x0003EDEC
	[Address(RVA = "0x2E05304", Offset = "0x2E05304", VA = "0x2E05304")]
	[Token(Token = "0x60022DE")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.tag == ", ";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_F4;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "typesOfTalk";
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "EnableCosmetic";
			string message;
			Debug.Log(message);
			GameObject gameObject2 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "Player";
			string message2;
			Debug.Log(message2);
			GameObject gameObject3 = this.gameObject_0;
			long num3 = 1L;
			this.bool_0 = (num3 != 0L);
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_F4:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022DF RID: 8927 RVA: 0x00040D0C File Offset: 0x0003EF0C
	[Address(RVA = "0x2E055DC", Offset = "0x2E055DC", VA = "0x2E055DC")]
	[Token(Token = "0x60022DF")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.tag == "ENABLE";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_E5;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "tutorialCheck";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "hh:mmtt";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "{0}/{1:f0}";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_E5:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022E0 RID: 8928 RVA: 0x00040E1C File Offset: 0x0003F01C
	[Token(Token = "0x60022E0")]
	[Address(RVA = "0x2E058AC", Offset = "0x2E058AC", VA = "0x2E058AC")]
	private void Update()
	{
		if (this.bool_0)
		{
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022E1 RID: 8929 RVA: 0x00040634 File Offset: 0x0003E834
	[Address(RVA = "0x2E05918", Offset = "0x2E05918", VA = "0x2E05918")]
	[Token(Token = "0x60022E1")]
	private void method_33()
	{
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x060022E2 RID: 8930 RVA: 0x00040E5C File Offset: 0x0003F05C
	[Address(RVA = "0x2E05984", Offset = "0x2E05984", VA = "0x2E05984")]
	[Token(Token = "0x60022E2")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "DisableCosmetic";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			if (this.bool_0)
			{
				goto IL_E4;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "True";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "Muted";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "Add/Remove Glasses";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long num3 = 1L;
			this.bool_0 = (num3 != 0L);
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_E4:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022E3 RID: 8931 RVA: 0x00040F6C File Offset: 0x0003F16C
	[Address(RVA = "0x2E05C5C", Offset = "0x2E05C5C", VA = "0x2E05C5C")]
	[Token(Token = "0x60022E3")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cannot access index {0}. Buffer is empty";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_DA;
			}
		}
		if (this.bool_2)
		{
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "Joined a Room.";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			this.bool_0 = (typeof(Debug).TypeHandle != null);
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_4)
		{
			this.string_0 = "hh:mmtt";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_DA:
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			return;
		}
	}

	// Token: 0x060022E4 RID: 8932 RVA: 0x00041070 File Offset: 0x0003F270
	[Address(RVA = "0x2E05F2C", Offset = "0x2E05F2C", VA = "0x2E05F2C")]
	[Token(Token = "0x60022E4")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		if (this.bool_0)
		{
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			if (this.bool_0)
			{
				goto IL_FB;
			}
		}
		if (this.bool_2)
		{
			this.string_0 = "Cheating";
			string message;
			Debug.Log(message);
			GameObject gameObject = this.gameObject_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}
		if (this.bool_3)
		{
			this.string_0 = "Hate Speech";
			string message2;
			Debug.Log(message2);
			GameObject gameObject2 = this.gameObject_0;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		long active3;
		if (this.bool_4)
		{
			this.string_0 = "Toxicity";
			string message3;
			Debug.Log(message3);
			GameObject gameObject3 = this.gameObject_0;
			long num3 = 1L;
			this.bool_0 = (num3 != 0L);
			active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		IL_FB:
		if (this.bool_1)
		{
			this.gameObject_0.SetActive(active3 != 0L);
			return;
		}
	}

	// Token: 0x060022E5 RID: 8933 RVA: 0x00041190 File Offset: 0x0003F390
	[Address(RVA = "0x2E061EC", Offset = "0x2E061EC", VA = "0x2E061EC")]
	[Token(Token = "0x60022E5")]
	private void method_36()
	{
		if (this.bool_0)
		{
			MeshRenderer meshRenderer = this.meshRenderer_0;
			Material material = this.material_0;
			meshRenderer.material = material;
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
	}

	// Token: 0x04000482 RID: 1154
	[Token(Token = "0x4000482")]
	[FieldOffset(Offset = "0x18")]
	public bool bool_0;

	// Token: 0x04000483 RID: 1155
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x4000483")]
	public bool bool_1;

	// Token: 0x04000484 RID: 1156
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000484")]
	public BoxCollider boxCollider_0;

	// Token: 0x04000485 RID: 1157
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000485")]
	public MeshRenderer meshRenderer_0;

	// Token: 0x04000486 RID: 1158
	[Token(Token = "0x4000486")]
	[FieldOffset(Offset = "0x30")]
	public Material material_0;

	// Token: 0x04000487 RID: 1159
	[Token(Token = "0x4000487")]
	[FieldOffset(Offset = "0x38")]
	public Material material_1;

	// Token: 0x04000488 RID: 1160
	[Token(Token = "0x4000488")]
	[FieldOffset(Offset = "0x40")]
	public bool bool_2;

	// Token: 0x04000489 RID: 1161
	[Token(Token = "0x4000489")]
	[FieldOffset(Offset = "0x41")]
	public bool bool_3;

	// Token: 0x0400048A RID: 1162
	[FieldOffset(Offset = "0x42")]
	[Token(Token = "0x400048A")]
	public bool bool_4;

	// Token: 0x0400048B RID: 1163
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400048B")]
	public BoxCollider boxCollider_1;

	// Token: 0x0400048C RID: 1164
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400048C")]
	public BoxCollider boxCollider_2;

	// Token: 0x0400048D RID: 1165
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400048D")]
	public BoxCollider boxCollider_3;

	// Token: 0x0400048E RID: 1166
	[Token(Token = "0x400048E")]
	[FieldOffset(Offset = "0x60")]
	public MeshRenderer meshRenderer_1;

	// Token: 0x0400048F RID: 1167
	[Token(Token = "0x400048F")]
	[FieldOffset(Offset = "0x68")]
	public MeshRenderer meshRenderer_2;

	// Token: 0x04000490 RID: 1168
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000490")]
	public MeshRenderer meshRenderer_3;

	// Token: 0x04000491 RID: 1169
	[Token(Token = "0x4000491")]
	[FieldOffset(Offset = "0x78")]
	private string string_0;

	// Token: 0x04000492 RID: 1170
	[Token(Token = "0x4000492")]
	[FieldOffset(Offset = "0x80")]
	public GameObject gameObject_0;
}
