﻿using System;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000041 RID: 65
[Token(Token = "0x2000041")]
public class RoomListing : MonoBehaviourPunCallbacks
{
	// Token: 0x06000832 RID: 2098 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E0E758", Offset = "0x2E0E758", VA = "0x2E0E758")]
	[Token(Token = "0x6000832")]
	public RoomInfo method_0()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000833 RID: 2099 RVA: 0x000129EC File Offset: 0x00010BEC
	[Address(RVA = "0x2E0E760", Offset = "0x2E0E760", VA = "0x2E0E760")]
	[Token(Token = "0x6000833")]
	public void method_1(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_18();
	}

	// Token: 0x06000834 RID: 2100 RVA: 0x00012A14 File Offset: 0x00010C14
	[Address(RVA = "0x2E0E8CC", Offset = "0x2E0E8CC", VA = "0x2E0E8CC")]
	[Token(Token = "0x6000834")]
	public void method_2()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000835 RID: 2101 RVA: 0x00012A2C File Offset: 0x00010C2C
	[Token(Token = "0x6000835")]
	[Address(RVA = "0x2E0E944", Offset = "0x2E0E944", VA = "0x2E0E944")]
	public void method_3(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000836 RID: 2102 RVA: 0x00012A40 File Offset: 0x00010C40
	[Address(RVA = "0x2E0EBD8", Offset = "0x2E0EBD8", VA = "0x2E0EBD8")]
	[Token(Token = "0x6000836")]
	public void method_4(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000837 RID: 2103 RVA: 0x00002277 File Offset: 0x00000477
	[Address(RVA = "0x2E0EE68", Offset = "0x2E0EE68", VA = "0x2E0EE68")]
	[Token(Token = "0x6000837")]
	private void method_5(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000838 RID: 2104 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E0EE70", Offset = "0x2E0EE70", VA = "0x2E0EE70")]
	[Token(Token = "0x6000838")]
	public RoomInfo method_6()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000839 RID: 2105 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E0EE78", Offset = "0x2E0EE78", VA = "0x2E0EE78")]
	[Token(Token = "0x6000839")]
	public RoomInfo method_7()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600083A RID: 2106 RVA: 0x00012A54 File Offset: 0x00010C54
	[Address(RVA = "0x2E0EE80", Offset = "0x2E0EE80", VA = "0x2E0EE80")]
	[Token(Token = "0x600083A")]
	public void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_53();
	}

	// Token: 0x0600083B RID: 2107 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E0EFEC", Offset = "0x2E0EFEC", VA = "0x2E0EFEC")]
	[Token(Token = "0x600083B")]
	public RoomInfo method_9()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600083C RID: 2108 RVA: 0x00012A7C File Offset: 0x00010C7C
	[Token(Token = "0x600083C")]
	[Address(RVA = "0x2E0EFF4", Offset = "0x2E0EFF4", VA = "0x2E0EFF4")]
	public void method_10(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x0600083D RID: 2109 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E0F280", Offset = "0x2E0F280", VA = "0x2E0F280")]
	[Token(Token = "0x600083D")]
	public RoomInfo method_11()
	{
		return this.roomInfo_0;
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000866 RID: 2150 RVA: 0x0000226F File Offset: 0x0000046F
	// (set) Token: 0x0600083E RID: 2110 RVA: 0x00002277 File Offset: 0x00000477
	[Token(Token = "0x17000017")]
	public RoomInfo RoomInfo_0 { [Address(RVA = "0x2E111D4", Offset = "0x2E111D4", VA = "0x2E111D4")] [Token(Token = "0x6000866")] get; [Token(Token = "0x600083E")] [Address(RVA = "0x2E0F288", Offset = "0x2E0F288", VA = "0x2E0F288")] private set; }

	// Token: 0x0600083F RID: 2111 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E0F290", Offset = "0x2E0F290", VA = "0x2E0F290")]
	[Token(Token = "0x600083F")]
	public RoomInfo method_12()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000840 RID: 2112 RVA: 0x00012A90 File Offset: 0x00010C90
	[Token(Token = "0x6000840")]
	[Address(RVA = "0x2E0F298", Offset = "0x2E0F298", VA = "0x2E0F298")]
	public void method_13(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_89();
	}

	// Token: 0x06000841 RID: 2113 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E0F404", Offset = "0x2E0F404", VA = "0x2E0F404")]
	[Token(Token = "0x6000841")]
	public RoomInfo method_14()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000842 RID: 2114 RVA: 0x00002277 File Offset: 0x00000477
	[Token(Token = "0x6000842")]
	[Address(RVA = "0x2E0F40C", Offset = "0x2E0F40C", VA = "0x2E0F40C")]
	private void method_15(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000843 RID: 2115 RVA: 0x00012AB8 File Offset: 0x00010CB8
	[Token(Token = "0x6000843")]
	[Address(RVA = "0x2E0F414", Offset = "0x2E0F414", VA = "0x2E0F414")]
	public void method_16(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_23();
	}

	// Token: 0x06000844 RID: 2116 RVA: 0x00012AE0 File Offset: 0x00010CE0
	[Address(RVA = "0x2E0F580", Offset = "0x2E0F580", VA = "0x2E0F580")]
	[Token(Token = "0x6000844")]
	public void method_17(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_74();
	}

	// Token: 0x06000845 RID: 2117 RVA: 0x00012A14 File Offset: 0x00010C14
	[Address(RVA = "0x2E0E854", Offset = "0x2E0E854", VA = "0x2E0E854")]
	[Token(Token = "0x6000845")]
	public void method_18()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000846 RID: 2118 RVA: 0x00012B08 File Offset: 0x00010D08
	[Address(RVA = "0x2E0F6EC", Offset = "0x2E0F6EC", VA = "0x2E0F6EC")]
	[Token(Token = "0x6000846")]
	public void method_19(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000847 RID: 2119 RVA: 0x00012B1C File Offset: 0x00010D1C
	[Address(RVA = "0x2E0F978", Offset = "0x2E0F978", VA = "0x2E0F978")]
	[Token(Token = "0x6000847")]
	public void method_20(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_32();
	}

	// Token: 0x06000848 RID: 2120 RVA: 0x00012A14 File Offset: 0x00010C14
	[Address(RVA = "0x2E0FAE4", Offset = "0x2E0FAE4", VA = "0x2E0FAE4")]
	[Token(Token = "0x6000848")]
	public void method_21()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000849 RID: 2121 RVA: 0x00012A7C File Offset: 0x00010C7C
	[Token(Token = "0x6000849")]
	[Address(RVA = "0x2E0FB5C", Offset = "0x2E0FB5C", VA = "0x2E0FB5C")]
	public void method_22(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x0600084A RID: 2122 RVA: 0x00012A14 File Offset: 0x00010C14
	[Address(RVA = "0x2E0F508", Offset = "0x2E0F508", VA = "0x2E0F508")]
	[Token(Token = "0x600084A")]
	public void method_23()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x0600084B RID: 2123 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E0FDF0", Offset = "0x2E0FDF0", VA = "0x2E0FDF0")]
	[Token(Token = "0x600084B")]
	public RoomInfo method_24()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600084C RID: 2124 RVA: 0x00012B44 File Offset: 0x00010D44
	[Token(Token = "0x600084C")]
	[Address(RVA = "0x2E0FDF8", Offset = "0x2E0FDF8", VA = "0x2E0FDF8")]
	public void method_25(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_61();
	}

	// Token: 0x0600084D RID: 2125 RVA: 0x0000226F File Offset: 0x0000046F
	[Token(Token = "0x600084D")]
	[Address(RVA = "0x2E0FF64", Offset = "0x2E0FF64", VA = "0x2E0FF64")]
	public RoomInfo method_26()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600084E RID: 2126 RVA: 0x00012A7C File Offset: 0x00010C7C
	[Address(RVA = "0x2E0FF6C", Offset = "0x2E0FF6C", VA = "0x2E0FF6C")]
	[Token(Token = "0x600084E")]
	public void method_27(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x0600084F RID: 2127 RVA: 0x00002277 File Offset: 0x00000477
	[Token(Token = "0x600084F")]
	[Address(RVA = "0x2E101F4", Offset = "0x2E101F4", VA = "0x2E101F4")]
	private void method_28(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000850 RID: 2128 RVA: 0x00012B6C File Offset: 0x00010D6C
	[Address(RVA = "0x2E101FC", Offset = "0x2E101FC", VA = "0x2E101FC")]
	[Token(Token = "0x6000850")]
	public void method_29(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_89();
	}

	// Token: 0x06000851 RID: 2129 RVA: 0x00002280 File Offset: 0x00000480
	[Address(RVA = "0x2E102F0", Offset = "0x2E102F0", VA = "0x2E102F0", Slot = "41")]
	[Token(Token = "0x6000851")]
	public override void OnJoinedRoom()
	{
		base.OnJoinedRoom();
		Debug.Log("Joined Public Room Successfully");
	}

	// Token: 0x06000852 RID: 2130 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E10374", Offset = "0x2E10374", VA = "0x2E10374")]
	[Token(Token = "0x6000852")]
	public RoomInfo method_30()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000853 RID: 2131 RVA: 0x000129EC File Offset: 0x00010BEC
	[Address(RVA = "0x2E1037C", Offset = "0x2E1037C", VA = "0x2E1037C")]
	[Token(Token = "0x6000853")]
	public void method_31(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_18();
	}

	// Token: 0x06000854 RID: 2132 RVA: 0x00012A14 File Offset: 0x00010C14
	[Token(Token = "0x6000854")]
	[Address(RVA = "0x2E0FA6C", Offset = "0x2E0FA6C", VA = "0x2E0FA6C")]
	public void method_32()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000855 RID: 2133 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E10470", Offset = "0x2E10470", VA = "0x2E10470")]
	[Token(Token = "0x6000855")]
	public RoomInfo method_33()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000856 RID: 2134 RVA: 0x00012AE0 File Offset: 0x00010CE0
	[Token(Token = "0x6000856")]
	[Address(RVA = "0x2E10478", Offset = "0x2E10478", VA = "0x2E10478")]
	public void method_34(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_74();
	}

	// Token: 0x06000857 RID: 2135 RVA: 0x00012A7C File Offset: 0x00010C7C
	[Token(Token = "0x6000857")]
	[Address(RVA = "0x2E1056C", Offset = "0x2E1056C", VA = "0x2E1056C")]
	public void method_35(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000858 RID: 2136 RVA: 0x00002277 File Offset: 0x00000477
	[Address(RVA = "0x2E107FC", Offset = "0x2E107FC", VA = "0x2E107FC")]
	[Token(Token = "0x6000858")]
	private void method_36(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000859 RID: 2137 RVA: 0x00012B8C File Offset: 0x00010D8C
	[Token(Token = "0x6000859")]
	[Address(RVA = "0x2E10804", Offset = "0x2E10804", VA = "0x2E10804")]
	public void method_37(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_77();
	}

	// Token: 0x0600085A RID: 2138 RVA: 0x0000226F File Offset: 0x0000046F
	[Token(Token = "0x600085A")]
	[Address(RVA = "0x2E10970", Offset = "0x2E10970", VA = "0x2E10970")]
	public RoomInfo method_38()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600085B RID: 2139 RVA: 0x00002292 File Offset: 0x00000492
	[Address(RVA = "0x2E10978", Offset = "0x2E10978", VA = "0x2E10978", Slot = "34")]
	[Token(Token = "0x600085B")]
	public override void OnJoinRoomFailed(short returnCode, string message)
	{
		base.OnJoinRoomFailed(returnCode, message);
		Debug.Log("Failed To Join Public Room Successfully. The error is: " + message);
	}

	// Token: 0x0600085C RID: 2140 RVA: 0x00012A14 File Offset: 0x00010C14
	[Token(Token = "0x600085C")]
	[Address(RVA = "0x2E10A2C", Offset = "0x2E10A2C", VA = "0x2E10A2C")]
	public void method_39()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x0600085D RID: 2141 RVA: 0x0000226F File Offset: 0x0000046F
	[Token(Token = "0x600085D")]
	[Address(RVA = "0x2E10AA4", Offset = "0x2E10AA4", VA = "0x2E10AA4")]
	public RoomInfo method_40()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600085E RID: 2142 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E10AAC", Offset = "0x2E10AAC", VA = "0x2E10AAC")]
	[Token(Token = "0x600085E")]
	private void method_41(RoomInfo roomInfo_1)
	{
	}

	// Token: 0x0600085F RID: 2143 RVA: 0x00012A14 File Offset: 0x00010C14
	[Token(Token = "0x600085F")]
	[Address(RVA = "0x2E10AB4", Offset = "0x2E10AB4", VA = "0x2E10AB4")]
	public void method_42()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000860 RID: 2144 RVA: 0x00012A7C File Offset: 0x00010C7C
	[Address(RVA = "0x2E10B2C", Offset = "0x2E10B2C", VA = "0x2E10B2C")]
	[Token(Token = "0x6000860")]
	public void method_43(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000861 RID: 2145 RVA: 0x00002277 File Offset: 0x00000477
	[Address(RVA = "0x2E10DC4", Offset = "0x2E10DC4", VA = "0x2E10DC4")]
	[Token(Token = "0x6000861")]
	private void method_44(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000862 RID: 2146 RVA: 0x00012B8C File Offset: 0x00010D8C
	[Address(RVA = "0x2E10DCC", Offset = "0x2E10DCC", VA = "0x2E10DCC")]
	[Token(Token = "0x6000862")]
	public void method_45(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_77();
	}

	// Token: 0x06000863 RID: 2147 RVA: 0x00002277 File Offset: 0x00000477
	[Token(Token = "0x6000863")]
	[Address(RVA = "0x2E10EC0", Offset = "0x2E10EC0", VA = "0x2E10EC0")]
	private void method_46(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000864 RID: 2148 RVA: 0x00012A14 File Offset: 0x00010C14
	[Address(RVA = "0x2E10EC8", Offset = "0x2E10EC8", VA = "0x2E10EC8")]
	[Token(Token = "0x6000864")]
	public void method_47()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000865 RID: 2149 RVA: 0x00012BB4 File Offset: 0x00010DB4
	[Token(Token = "0x6000865")]
	[Address(RVA = "0x2E10F40", Offset = "0x2E10F40", VA = "0x2E10F40")]
	public void method_48(RoomInfo roomInfo_1)
	{
	}

	// Token: 0x06000867 RID: 2151 RVA: 0x00012A40 File Offset: 0x00010C40
	[Token(Token = "0x6000867")]
	[Address(RVA = "0x2E111DC", Offset = "0x2E111DC", VA = "0x2E111DC")]
	public void method_49(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000868 RID: 2152 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E1146C", Offset = "0x2E1146C", VA = "0x2E1146C")]
	[Token(Token = "0x6000868")]
	public RoomInfo method_50()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000869 RID: 2153 RVA: 0x00002277 File Offset: 0x00000477
	[Token(Token = "0x6000869")]
	[Address(RVA = "0x2E11474", Offset = "0x2E11474", VA = "0x2E11474")]
	private void method_51(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x0600086A RID: 2154 RVA: 0x00012A90 File Offset: 0x00010C90
	[Address(RVA = "0x2E1147C", Offset = "0x2E1147C", VA = "0x2E1147C")]
	[Token(Token = "0x600086A")]
	public void method_52(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_89();
	}

	// Token: 0x0600086B RID: 2155 RVA: 0x00012A14 File Offset: 0x00010C14
	[Address(RVA = "0x2E0EF74", Offset = "0x2E0EF74", VA = "0x2E0EF74")]
	[Token(Token = "0x600086B")]
	public void method_53()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x0600086C RID: 2156 RVA: 0x00012A7C File Offset: 0x00010C7C
	[Address(RVA = "0x2E11570", Offset = "0x2E11570", VA = "0x2E11570")]
	[Token(Token = "0x600086C")]
	public void method_54(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x0600086D RID: 2157 RVA: 0x00012BC4 File Offset: 0x00010DC4
	[Address(RVA = "0x2E11808", Offset = "0x2E11808", VA = "0x2E11808")]
	[Token(Token = "0x600086D")]
	public void method_55(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x0600086E RID: 2158 RVA: 0x0000226F File Offset: 0x0000046F
	[Token(Token = "0x600086E")]
	[Address(RVA = "0x2E11974", Offset = "0x2E11974", VA = "0x2E11974")]
	public RoomInfo method_56()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600086F RID: 2159 RVA: 0x00002277 File Offset: 0x00000477
	[Address(RVA = "0x2E1197C", Offset = "0x2E1197C", VA = "0x2E1197C")]
	[Token(Token = "0x600086F")]
	private void method_57(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000870 RID: 2160 RVA: 0x00012BE4 File Offset: 0x00010DE4
	[Token(Token = "0x6000870")]
	[Address(RVA = "0x2E11984", Offset = "0x2E11984", VA = "0x2E11984")]
	public void method_58(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_71();
	}

	// Token: 0x06000871 RID: 2161 RVA: 0x00012A14 File Offset: 0x00010C14
	[Address(RVA = "0x2E11A78", Offset = "0x2E11A78", VA = "0x2E11A78")]
	[Token(Token = "0x6000871")]
	public void method_59()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000872 RID: 2162 RVA: 0x00002277 File Offset: 0x00000477
	[Address(RVA = "0x2E11AF0", Offset = "0x2E11AF0", VA = "0x2E11AF0")]
	[Token(Token = "0x6000872")]
	private void method_60(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000873 RID: 2163 RVA: 0x00012A14 File Offset: 0x00010C14
	[Token(Token = "0x6000873")]
	[Address(RVA = "0x2E0FEEC", Offset = "0x2E0FEEC", VA = "0x2E0FEEC")]
	public void method_61()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000874 RID: 2164 RVA: 0x00012A54 File Offset: 0x00010C54
	[Address(RVA = "0x2E11AF8", Offset = "0x2E11AF8", VA = "0x2E11AF8")]
	[Token(Token = "0x6000874")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_53();
	}

	// Token: 0x06000875 RID: 2165 RVA: 0x00012A7C File Offset: 0x00010C7C
	[Address(RVA = "0x2E11BEC", Offset = "0x2E11BEC", VA = "0x2E11BEC")]
	[Token(Token = "0x6000875")]
	public void method_62(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000876 RID: 2166 RVA: 0x0000226F File Offset: 0x0000046F
	[Token(Token = "0x6000876")]
	[Address(RVA = "0x2E11E7C", Offset = "0x2E11E7C", VA = "0x2E11E7C")]
	public RoomInfo method_63()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000877 RID: 2167 RVA: 0x00012A7C File Offset: 0x00010C7C
	[Address(RVA = "0x2E11E84", Offset = "0x2E11E84", VA = "0x2E11E84")]
	[Token(Token = "0x6000877")]
	public void method_64(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000878 RID: 2168 RVA: 0x00002277 File Offset: 0x00000477
	[Address(RVA = "0x2E12114", Offset = "0x2E12114", VA = "0x2E12114")]
	[Token(Token = "0x6000878")]
	private void method_65(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000879 RID: 2169 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E1211C", Offset = "0x2E1211C", VA = "0x2E1211C")]
	[Token(Token = "0x6000879")]
	public RoomInfo method_66()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600087A RID: 2170 RVA: 0x00012A7C File Offset: 0x00010C7C
	[Token(Token = "0x600087A")]
	[Address(RVA = "0x2E12124", Offset = "0x2E12124", VA = "0x2E12124")]
	public void method_67(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x0600087B RID: 2171 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2E123B0", Offset = "0x2E123B0", VA = "0x2E123B0")]
	[Token(Token = "0x600087B")]
	private void method_68(RoomInfo roomInfo_1)
	{
	}

	// Token: 0x0600087C RID: 2172 RVA: 0x00012C0C File Offset: 0x00010E0C
	[Token(Token = "0x600087C")]
	[Address(RVA = "0x2E123B8", Offset = "0x2E123B8", VA = "0x2E123B8")]
	public void method_69(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_59();
	}

	// Token: 0x0600087D RID: 2173 RVA: 0x0000226F File Offset: 0x0000046F
	[Token(Token = "0x600087D")]
	[Address(RVA = "0x2E124AC", Offset = "0x2E124AC", VA = "0x2E124AC")]
	public RoomInfo method_70()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600087E RID: 2174 RVA: 0x00012A14 File Offset: 0x00010C14
	[Address(RVA = "0x2E118FC", Offset = "0x2E118FC", VA = "0x2E118FC")]
	[Token(Token = "0x600087E")]
	public void method_71()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x0600087F RID: 2175 RVA: 0x0000208D File Offset: 0x0000028D
	[Address(RVA = "0x2E124B4", Offset = "0x2E124B4", VA = "0x2E124B4")]
	[Token(Token = "0x600087F")]
	public RoomListing()
	{
	}

	// Token: 0x06000880 RID: 2176 RVA: 0x00012C34 File Offset: 0x00010E34
	[Token(Token = "0x6000880")]
	[Address(RVA = "0x2E124BC", Offset = "0x2E124BC", VA = "0x2E124BC")]
	public void method_72(Collider collider_0)
	{
		HandColliders exists;
		exists;
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000881 RID: 2177 RVA: 0x00002277 File Offset: 0x00000477
	[Address(RVA = "0x2E125B0", Offset = "0x2E125B0", VA = "0x2E125B0")]
	[Token(Token = "0x6000881")]
	private void method_73(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000882 RID: 2178 RVA: 0x00012A14 File Offset: 0x00010C14
	[Token(Token = "0x6000882")]
	[Address(RVA = "0x2E0F674", Offset = "0x2E0F674", VA = "0x2E0F674")]
	public void method_74()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000883 RID: 2179 RVA: 0x00012C50 File Offset: 0x00010E50
	[Token(Token = "0x6000883")]
	[Address(RVA = "0x2E125B8", Offset = "0x2E125B8", VA = "0x2E125B8")]
	public void method_75(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool isConnected = PhotonNetwork.IsConnected;
		this.method_39();
	}

	// Token: 0x06000884 RID: 2180 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E126AC", Offset = "0x2E126AC", VA = "0x2E126AC")]
	[Token(Token = "0x6000884")]
	public RoomInfo method_76()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000885 RID: 2181 RVA: 0x00012A14 File Offset: 0x00010C14
	[Address(RVA = "0x2E108F8", Offset = "0x2E108F8", VA = "0x2E108F8")]
	[Token(Token = "0x6000885")]
	public void method_77()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000886 RID: 2182 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E126B4", Offset = "0x2E126B4", VA = "0x2E126B4")]
	[Token(Token = "0x6000886")]
	public RoomInfo method_78()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000887 RID: 2183 RVA: 0x00012A14 File Offset: 0x00010C14
	[Token(Token = "0x6000887")]
	[Address(RVA = "0x2E126BC", Offset = "0x2E126BC", VA = "0x2E126BC")]
	public void method_79()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x06000888 RID: 2184 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E12734", Offset = "0x2E12734", VA = "0x2E12734")]
	[Token(Token = "0x6000888")]
	public RoomInfo method_80()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000889 RID: 2185 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E1273C", Offset = "0x2E1273C", VA = "0x2E1273C")]
	[Token(Token = "0x6000889")]
	public RoomInfo method_81()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600088A RID: 2186 RVA: 0x00012C78 File Offset: 0x00010E78
	[Token(Token = "0x600088A")]
	[Address(RVA = "0x2E12744", Offset = "0x2E12744", VA = "0x2E12744")]
	public void method_82(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x0600088B RID: 2187 RVA: 0x0000226F File Offset: 0x0000046F
	[Token(Token = "0x600088B")]
	[Address(RVA = "0x2E129D8", Offset = "0x2E129D8", VA = "0x2E129D8")]
	public RoomInfo method_83()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600088C RID: 2188 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E129E0", Offset = "0x2E129E0", VA = "0x2E129E0")]
	[Token(Token = "0x600088C")]
	public RoomInfo method_84()
	{
		return this.roomInfo_0;
	}

	// Token: 0x0600088D RID: 2189 RVA: 0x00002277 File Offset: 0x00000477
	[Token(Token = "0x600088D")]
	[Address(RVA = "0x2E129E8", Offset = "0x2E129E8", VA = "0x2E129E8")]
	private void method_85(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x0600088E RID: 2190 RVA: 0x00012A14 File Offset: 0x00010C14
	[Address(RVA = "0x2E129F0", Offset = "0x2E129F0", VA = "0x2E129F0")]
	[Token(Token = "0x600088E")]
	public void method_86()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x0600088F RID: 2191 RVA: 0x0000226F File Offset: 0x0000046F
	[Address(RVA = "0x2E12A68", Offset = "0x2E12A68", VA = "0x2E12A68")]
	[Token(Token = "0x600088F")]
	public RoomInfo method_87()
	{
		return this.roomInfo_0;
	}

	// Token: 0x06000890 RID: 2192 RVA: 0x00012A7C File Offset: 0x00010C7C
	[Address(RVA = "0x2E12A70", Offset = "0x2E12A70", VA = "0x2E12A70")]
	[Token(Token = "0x6000890")]
	public void method_88(RoomInfo roomInfo_1)
	{
		this.roomInfo_0 = roomInfo_1;
	}

	// Token: 0x06000891 RID: 2193 RVA: 0x00012A14 File Offset: 0x00010C14
	[Token(Token = "0x6000891")]
	[Address(RVA = "0x2E0F38C", Offset = "0x2E0F38C", VA = "0x2E0F38C")]
	public void method_89()
	{
		RoomInfo roomInfo = this.roomInfo_0;
		if (roomInfo != null)
		{
		}
	}

	// Token: 0x04000123 RID: 291
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000123")]
	public Text text_0;

	// Token: 0x04000124 RID: 292
	[Token(Token = "0x4000124")]
	[FieldOffset(Offset = "0x28")]
	[CompilerGenerated]
	private RoomInfo roomInfo_0;
}
