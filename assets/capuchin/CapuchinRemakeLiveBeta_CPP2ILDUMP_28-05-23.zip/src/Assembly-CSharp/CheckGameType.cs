﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200004D RID: 77
[Token(Token = "0x200004D")]
public class CheckGameType : MonoBehaviour
{
	// Token: 0x06000A92 RID: 2706 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0324", Offset = "0x2AF0324", VA = "0x2AF0324")]
	[Token(Token = "0x6000A92")]
	private void method_0()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000A93 RID: 2707 RVA: 0x00018708 File Offset: 0x00016908
	[Address(RVA = "0x2AF0370", Offset = "0x2AF0370", VA = "0x2AF0370")]
	[Token(Token = "0x6000A93")]
	private void method_1()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000A94 RID: 2708 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF03BC", Offset = "0x2AF03BC", VA = "0x2AF03BC")]
	[Token(Token = "0x6000A94")]
	private void method_2()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000A95 RID: 2709 RVA: 0x000186F4 File Offset: 0x000168F4
	[Token(Token = "0x6000A95")]
	[Address(RVA = "0x2AF0408", Offset = "0x2AF0408", VA = "0x2AF0408")]
	private void method_3()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000A96 RID: 2710 RVA: 0x000186F4 File Offset: 0x000168F4
	[Token(Token = "0x6000A96")]
	[Address(RVA = "0x2AF0454", Offset = "0x2AF0454", VA = "0x2AF0454")]
	private void method_4()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000A97 RID: 2711 RVA: 0x0001871C File Offset: 0x0001691C
	[Token(Token = "0x6000A97")]
	[Address(RVA = "0x2AF04A0", Offset = "0x2AF04A0", VA = "0x2AF04A0")]
	private void method_5()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000A98 RID: 2712 RVA: 0x00018740 File Offset: 0x00016940
	[Address(RVA = "0x2AF04D8", Offset = "0x2AF04D8", VA = "0x2AF04D8")]
	[Token(Token = "0x6000A98")]
	private void method_6()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000A99 RID: 2713 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0510", Offset = "0x2AF0510", VA = "0x2AF0510")]
	[Token(Token = "0x6000A99")]
	private void method_7()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000A9A RID: 2714 RVA: 0x000186F4 File Offset: 0x000168F4
	[Token(Token = "0x6000A9A")]
	[Address(RVA = "0x2AF055C", Offset = "0x2AF055C", VA = "0x2AF055C")]
	private void method_8()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000A9B RID: 2715 RVA: 0x0001871C File Offset: 0x0001691C
	[Token(Token = "0x6000A9B")]
	[Address(RVA = "0x2AF05A8", Offset = "0x2AF05A8", VA = "0x2AF05A8")]
	private void method_9()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000A9C RID: 2716 RVA: 0x0001871C File Offset: 0x0001691C
	[Address(RVA = "0x2AF05E0", Offset = "0x2AF05E0", VA = "0x2AF05E0")]
	[Token(Token = "0x6000A9C")]
	private void method_10()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000A9D RID: 2717 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0618", Offset = "0x2AF0618", VA = "0x2AF0618")]
	[Token(Token = "0x6000A9D")]
	private void method_11()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000A9E RID: 2718 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0664", Offset = "0x2AF0664", VA = "0x2AF0664")]
	[Token(Token = "0x6000A9E")]
	private void method_12()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000A9F RID: 2719 RVA: 0x000186F4 File Offset: 0x000168F4
	[Token(Token = "0x6000A9F")]
	[Address(RVA = "0x2AF06B0", Offset = "0x2AF06B0", VA = "0x2AF06B0")]
	private void method_13()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AA0 RID: 2720 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF06FC", Offset = "0x2AF06FC", VA = "0x2AF06FC")]
	[Token(Token = "0x6000AA0")]
	private void method_14()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AA1 RID: 2721 RVA: 0x00018740 File Offset: 0x00016940
	[Token(Token = "0x6000AA1")]
	[Address(RVA = "0x2AF0748", Offset = "0x2AF0748", VA = "0x2AF0748")]
	private void method_15()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AA2 RID: 2722 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0780", Offset = "0x2AF0780", VA = "0x2AF0780")]
	[Token(Token = "0x6000AA2")]
	private void method_16()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AA3 RID: 2723 RVA: 0x00018740 File Offset: 0x00016940
	[Token(Token = "0x6000AA3")]
	[Address(RVA = "0x2AF07CC", Offset = "0x2AF07CC", VA = "0x2AF07CC")]
	private void method_17()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AA4 RID: 2724 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2AF0804", Offset = "0x2AF0804", VA = "0x2AF0804")]
	[Token(Token = "0x6000AA4")]
	public CheckGameType()
	{
	}

	// Token: 0x06000AA5 RID: 2725 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF080C", Offset = "0x2AF080C", VA = "0x2AF080C")]
	[Token(Token = "0x6000AA5")]
	private void method_18()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AA6 RID: 2726 RVA: 0x00018708 File Offset: 0x00016908
	[Address(RVA = "0x2AF0858", Offset = "0x2AF0858", VA = "0x2AF0858")]
	[Token(Token = "0x6000AA6")]
	private void method_19()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AA7 RID: 2727 RVA: 0x00018740 File Offset: 0x00016940
	[Address(RVA = "0x2AF08A4", Offset = "0x2AF08A4", VA = "0x2AF08A4")]
	[Token(Token = "0x6000AA7")]
	private void method_20()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AA8 RID: 2728 RVA: 0x00018740 File Offset: 0x00016940
	[Address(RVA = "0x2AF08DC", Offset = "0x2AF08DC", VA = "0x2AF08DC")]
	[Token(Token = "0x6000AA8")]
	private void method_21()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AA9 RID: 2729 RVA: 0x0001871C File Offset: 0x0001691C
	[Address(RVA = "0x2AF0914", Offset = "0x2AF0914", VA = "0x2AF0914")]
	[Token(Token = "0x6000AA9")]
	private void method_22()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AAA RID: 2730 RVA: 0x00018740 File Offset: 0x00016940
	[Token(Token = "0x6000AAA")]
	[Address(RVA = "0x2AF094C", Offset = "0x2AF094C", VA = "0x2AF094C")]
	private void method_23()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AAB RID: 2731 RVA: 0x000186F4 File Offset: 0x000168F4
	[Token(Token = "0x6000AAB")]
	[Address(RVA = "0x2AF0984", Offset = "0x2AF0984", VA = "0x2AF0984")]
	private void method_24()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AAC RID: 2732 RVA: 0x00018740 File Offset: 0x00016940
	[Address(RVA = "0x2AF09D0", Offset = "0x2AF09D0", VA = "0x2AF09D0")]
	[Token(Token = "0x6000AAC")]
	private void method_25()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AAD RID: 2733 RVA: 0x000186F4 File Offset: 0x000168F4
	[Token(Token = "0x6000AAD")]
	[Address(RVA = "0x2AF0A08", Offset = "0x2AF0A08", VA = "0x2AF0A08")]
	private void method_26()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AAE RID: 2734 RVA: 0x000186F4 File Offset: 0x000168F4
	[Token(Token = "0x6000AAE")]
	[Address(RVA = "0x2AF0A54", Offset = "0x2AF0A54", VA = "0x2AF0A54")]
	private void method_27()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AAF RID: 2735 RVA: 0x0001871C File Offset: 0x0001691C
	[Address(RVA = "0x2AF0AA0", Offset = "0x2AF0AA0", VA = "0x2AF0AA0")]
	[Token(Token = "0x6000AAF")]
	private void method_28()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AB0 RID: 2736 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0AD8", Offset = "0x2AF0AD8", VA = "0x2AF0AD8")]
	[Token(Token = "0x6000AB0")]
	private void method_29()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AB1 RID: 2737 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0B24", Offset = "0x2AF0B24", VA = "0x2AF0B24")]
	[Token(Token = "0x6000AB1")]
	private void method_30()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AB2 RID: 2738 RVA: 0x0001871C File Offset: 0x0001691C
	[Token(Token = "0x6000AB2")]
	[Address(RVA = "0x2AF0B70", Offset = "0x2AF0B70", VA = "0x2AF0B70")]
	private void method_31()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AB3 RID: 2739 RVA: 0x0001871C File Offset: 0x0001691C
	[Address(RVA = "0x2AF0BA8", Offset = "0x2AF0BA8", VA = "0x2AF0BA8")]
	[Token(Token = "0x6000AB3")]
	private void method_32()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AB4 RID: 2740 RVA: 0x000186F4 File Offset: 0x000168F4
	[Token(Token = "0x6000AB4")]
	[Address(RVA = "0x2AF0BE0", Offset = "0x2AF0BE0", VA = "0x2AF0BE0")]
	private void method_33()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AB5 RID: 2741 RVA: 0x0001871C File Offset: 0x0001691C
	[Address(RVA = "0x2AF0C2C", Offset = "0x2AF0C2C", VA = "0x2AF0C2C")]
	[Token(Token = "0x6000AB5")]
	private void method_34()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AB6 RID: 2742 RVA: 0x000186F4 File Offset: 0x000168F4
	[Token(Token = "0x6000AB6")]
	[Address(RVA = "0x2AF0C64", Offset = "0x2AF0C64", VA = "0x2AF0C64")]
	private void method_35()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AB7 RID: 2743 RVA: 0x00018740 File Offset: 0x00016940
	[Token(Token = "0x6000AB7")]
	[Address(RVA = "0x2AF0CB0", Offset = "0x2AF0CB0", VA = "0x2AF0CB0")]
	private void method_36()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AB8 RID: 2744 RVA: 0x00018740 File Offset: 0x00016940
	[Address(RVA = "0x2AF0CE8", Offset = "0x2AF0CE8", VA = "0x2AF0CE8")]
	[Token(Token = "0x6000AB8")]
	private void method_37()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AB9 RID: 2745 RVA: 0x0001871C File Offset: 0x0001691C
	[Address(RVA = "0x2AF0D20", Offset = "0x2AF0D20", VA = "0x2AF0D20")]
	[Token(Token = "0x6000AB9")]
	private void method_38()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000ABA RID: 2746 RVA: 0x00018740 File Offset: 0x00016940
	[Token(Token = "0x6000ABA")]
	[Address(RVA = "0x2AF0D58", Offset = "0x2AF0D58", VA = "0x2AF0D58")]
	private void method_39()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000ABB RID: 2747 RVA: 0x00018740 File Offset: 0x00016940
	[Token(Token = "0x6000ABB")]
	[Address(RVA = "0x2AF0D90", Offset = "0x2AF0D90", VA = "0x2AF0D90")]
	private void method_40()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000ABC RID: 2748 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0DC8", Offset = "0x2AF0DC8", VA = "0x2AF0DC8")]
	[Token(Token = "0x6000ABC")]
	private void method_41()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000ABD RID: 2749 RVA: 0x00018708 File Offset: 0x00016908
	[Address(RVA = "0x2AF0E14", Offset = "0x2AF0E14", VA = "0x2AF0E14")]
	[Token(Token = "0x6000ABD")]
	private void Start()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000ABE RID: 2750 RVA: 0x0001871C File Offset: 0x0001691C
	[Token(Token = "0x6000ABE")]
	[Address(RVA = "0x2AF0E60", Offset = "0x2AF0E60", VA = "0x2AF0E60")]
	private void method_42()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000ABF RID: 2751 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0E98", Offset = "0x2AF0E98", VA = "0x2AF0E98")]
	[Token(Token = "0x6000ABF")]
	private void method_43()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AC0 RID: 2752 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0EE4", Offset = "0x2AF0EE4", VA = "0x2AF0EE4")]
	[Token(Token = "0x6000AC0")]
	private void method_44()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x06000AC1 RID: 2753 RVA: 0x00018740 File Offset: 0x00016940
	[Address(RVA = "0x2AF0F30", Offset = "0x2AF0F30", VA = "0x2AF0F30")]
	[Token(Token = "0x6000AC1")]
	private void method_45()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AC2 RID: 2754 RVA: 0x0001871C File Offset: 0x0001691C
	[Token(Token = "0x6000AC2")]
	[Address(RVA = "0x2AF0F68", Offset = "0x2AF0F68", VA = "0x2AF0F68")]
	private void method_46()
	{
		bool isEditor = Application.isEditor;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06000AC3 RID: 2755 RVA: 0x000186F4 File Offset: 0x000168F4
	[Address(RVA = "0x2AF0FA0", Offset = "0x2AF0FA0", VA = "0x2AF0FA0")]
	[Token(Token = "0x6000AC3")]
	private void method_47()
	{
		bool isEditor = Application.isEditor;
	}

	// Token: 0x0400018A RID: 394
	[Token(Token = "0x400018A")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;
}
