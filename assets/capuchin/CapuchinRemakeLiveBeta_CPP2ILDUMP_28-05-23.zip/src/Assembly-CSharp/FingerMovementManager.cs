﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200005F RID: 95
[Token(Token = "0x200005F")]
[ExecuteAlways]
public class FingerMovementManager : MonoBehaviourPun
{
	// Token: 0x06000D80 RID: 3456 RVA: 0x0001D234 File Offset: 0x0001B434
	[Address(RVA = "0x10DB05C", Offset = "0x10DB05C", VA = "0x10DB05C")]
	[Token(Token = "0x6000D80")]
	private void method_0()
	{
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000D81 RID: 3457 RVA: 0x0001D24C File Offset: 0x0001B44C
	[Token(Token = "0x6000D81")]
	[Address(RVA = "0x10DB068", Offset = "0x10DB068", VA = "0x10DB068")]
	private void method_1()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D82 RID: 3458 RVA: 0x0001D268 File Offset: 0x0001B468
	[Address(RVA = "0x10DB3CC", Offset = "0x10DB3CC", VA = "0x10DB3CC")]
	[Token(Token = "0x6000D82")]
	private void method_2()
	{
		if (!this.bool_0)
		{
			this.method_4();
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.method_21();
			return;
		}
	}

	// Token: 0x06000D83 RID: 3459 RVA: 0x0001D298 File Offset: 0x0001B498
	[Address(RVA = "0x10DC9A8", Offset = "0x10DC9A8", VA = "0x10DC9A8")]
	[Token(Token = "0x6000D83")]
	private void method_3()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D84 RID: 3460 RVA: 0x0001D2B4 File Offset: 0x0001B4B4
	[Address(RVA = "0x10DC38C", Offset = "0x10DC38C", VA = "0x10DC38C")]
	[Token(Token = "0x6000D84")]
	private void method_4()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D85 RID: 3461 RVA: 0x0001D2D0 File Offset: 0x0001B4D0
	[Address(RVA = "0x10DCCE0", Offset = "0x10DCCE0", VA = "0x10DCCE0")]
	[Token(Token = "0x6000D85")]
	private void method_5()
	{
		for (;;)
		{
			if (!this.bool_0)
			{
				this.method_38();
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				Vector3 zero3 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					break;
				}
			}
			else
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.method_59();
				Vector3 zero4 = Vector3.zero;
				Vector3 zero5 = Vector3.zero;
				Vector3 zero6 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000D86 RID: 3462 RVA: 0x0001D338 File Offset: 0x0001B538
	[Address(RVA = "0x10DE2D8", Offset = "0x10DE2D8", VA = "0x10DE2D8")]
	[Token(Token = "0x6000D86")]
	private void method_6()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D87 RID: 3463 RVA: 0x0001D354 File Offset: 0x0001B554
	[Address(RVA = "0x10DE60C", Offset = "0x10DE60C", VA = "0x10DE60C")]
	[Token(Token = "0x6000D87")]
	private void method_7()
	{
		while (this.bool_0)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.method_62();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		this.method_46();
	}

	// Token: 0x06000D88 RID: 3464 RVA: 0x0001D3A0 File Offset: 0x0001B5A0
	[Address(RVA = "0x10DFC48", Offset = "0x10DFC48", VA = "0x10DFC48")]
	[Token(Token = "0x6000D88")]
	private void method_8()
	{
		while (!this.bool_0)
		{
			this.method_23();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.method_14();
			return;
		}
	}

	// Token: 0x06000D89 RID: 3465 RVA: 0x0001D234 File Offset: 0x0001B434
	[Address(RVA = "0x10E121C", Offset = "0x10E121C", VA = "0x10E121C")]
	[Token(Token = "0x6000D89")]
	private void method_9()
	{
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000D8A RID: 3466 RVA: 0x0001D3EC File Offset: 0x0001B5EC
	[Address(RVA = "0x10E1228", Offset = "0x10E1228", VA = "0x10E1228")]
	[Token(Token = "0x6000D8A")]
	private void method_10()
	{
		bool <IsMine>k__BackingField;
		if (!this.bool_0)
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			while (<IsMine>k__BackingField)
			{
			}
			return;
		}
		if (<IsMine>k__BackingField = base.photonView.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06000D8B RID: 3467 RVA: 0x0001D428 File Offset: 0x0001B628
	[Address(RVA = "0x10E2560", Offset = "0x10E2560", VA = "0x10E2560")]
	[Token(Token = "0x6000D8B")]
	private void method_11()
	{
		for (;;)
		{
			if (!this.bool_0)
			{
				this.method_20();
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				Vector3 zero3 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					break;
				}
			}
			else
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.method_21();
				Vector3 zero4 = Vector3.zero;
				Vector3 zero5 = Vector3.zero;
				Vector3 zero6 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000D8C RID: 3468 RVA: 0x0001D490 File Offset: 0x0001B690
	[Address(RVA = "0x10E3540", Offset = "0x10E3540", VA = "0x10E3540")]
	[Token(Token = "0x6000D8C")]
	private void method_12()
	{
		while (base.photonView.<IsMine>k__BackingField)
		{
			this.method_42();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
	}

	// Token: 0x06000D8D RID: 3469 RVA: 0x0001D234 File Offset: 0x0001B434
	[Token(Token = "0x6000D8D")]
	[Address(RVA = "0x10E491C", Offset = "0x10E491C", VA = "0x10E491C")]
	private void method_13()
	{
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000D8E RID: 3470 RVA: 0x0001D4CC File Offset: 0x0001B6CC
	[Token(Token = "0x6000D8E")]
	[Address(RVA = "0x10E0EE4", Offset = "0x10E0EE4", VA = "0x10E0EE4")]
	private void method_14()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D8F RID: 3471 RVA: 0x0001D2B4 File Offset: 0x0001B4B4
	[Address(RVA = "0x10E4928", Offset = "0x10E4928", VA = "0x10E4928")]
	[Token(Token = "0x6000D8F")]
	private void method_15()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D90 RID: 3472 RVA: 0x0001D24C File Offset: 0x0001B44C
	[Address(RVA = "0x10E4C14", Offset = "0x10E4C14", VA = "0x10E4C14")]
	[Token(Token = "0x6000D90")]
	private void method_16()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D91 RID: 3473 RVA: 0x0001D4E8 File Offset: 0x0001B6E8
	[Address(RVA = "0x10E4F68", Offset = "0x10E4F68", VA = "0x10E4F68")]
	[Token(Token = "0x6000D91")]
	private void method_17()
	{
		while (this.bool_0)
		{
			bool <IsMine>k__BackingField = base.photonView.<IsMine>k__BackingField;
			this.method_14();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		this.method_15();
	}

	// Token: 0x06000D92 RID: 3474 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000D92")]
	[Address(RVA = "0x10E5F80", Offset = "0x10E5F80", VA = "0x10E5F80")]
	private void method_18()
	{
	}

	// Token: 0x06000D93 RID: 3475 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10E5F88", Offset = "0x10E5F88", VA = "0x10E5F88")]
	[Token(Token = "0x6000D93")]
	private void method_19()
	{
	}

	// Token: 0x06000D94 RID: 3476 RVA: 0x0001D530 File Offset: 0x0001B730
	[Address(RVA = "0x10E2230", Offset = "0x10E2230", VA = "0x10E2230")]
	[Token(Token = "0x6000D94")]
	private void method_20()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D95 RID: 3477 RVA: 0x0001D4CC File Offset: 0x0001B6CC
	[Token(Token = "0x6000D95")]
	[Address(RVA = "0x10DC688", Offset = "0x10DC688", VA = "0x10DC688")]
	private void method_21()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D96 RID: 3478 RVA: 0x0001D54C File Offset: 0x0001B74C
	[Address(RVA = "0x10E5F90", Offset = "0x10E5F90", VA = "0x10E5F90")]
	[Token(Token = "0x6000D96")]
	private void method_22()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D97 RID: 3479 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10E62D0", Offset = "0x10E62D0", VA = "0x10E62D0")]
	[Token(Token = "0x6000D97")]
	private void Start()
	{
	}

	// Token: 0x06000D98 RID: 3480 RVA: 0x0001D2B4 File Offset: 0x0001B4B4
	[Token(Token = "0x6000D98")]
	[Address(RVA = "0x10E0BF8", Offset = "0x10E0BF8", VA = "0x10E0BF8")]
	private void method_23()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D99 RID: 3481 RVA: 0x0001D568 File Offset: 0x0001B768
	[Token(Token = "0x6000D99")]
	[Address(RVA = "0x10E62D8", Offset = "0x10E62D8", VA = "0x10E62D8")]
	private void method_24()
	{
		if (!this.bool_0)
		{
			this.method_15();
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.method_48();
			return;
		}
	}

	// Token: 0x06000D9A RID: 3482 RVA: 0x0001D598 File Offset: 0x0001B798
	[Token(Token = "0x6000D9A")]
	[Address(RVA = "0x10E75F4", Offset = "0x10E75F4", VA = "0x10E75F4")]
	private void method_25()
	{
		while (this.bool_0)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.method_22();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		this.method_4();
	}

	// Token: 0x06000D9B RID: 3483 RVA: 0x0001D5E4 File Offset: 0x0001B7E4
	[Address(RVA = "0x10E8514", Offset = "0x10E8514", VA = "0x10E8514")]
	[Token(Token = "0x6000D9B")]
	private void method_26()
	{
		if (!this.bool_0)
		{
			this.method_50();
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.method_22();
			return;
		}
	}

	// Token: 0x06000D9C RID: 3484 RVA: 0x0001D614 File Offset: 0x0001B814
	[Address(RVA = "0x10E97B8", Offset = "0x10E97B8", VA = "0x10E97B8")]
	[Token(Token = "0x6000D9C")]
	private void method_27()
	{
		while (this.bool_0)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.method_29();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		this.method_62();
	}

	// Token: 0x06000D9D RID: 3485 RVA: 0x0001D660 File Offset: 0x0001B860
	[Token(Token = "0x6000D9D")]
	[Address(RVA = "0x10EAA80", Offset = "0x10EAA80", VA = "0x10EAA80")]
	private void method_28()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D9E RID: 3486 RVA: 0x0001D67C File Offset: 0x0001B87C
	[Address(RVA = "0x10EA720", Offset = "0x10EA720", VA = "0x10EA720")]
	[Token(Token = "0x6000D9E")]
	private void method_29()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000D9F RID: 3487 RVA: 0x0001D234 File Offset: 0x0001B434
	[Token(Token = "0x6000D9F")]
	[Address(RVA = "0x10EADA0", Offset = "0x10EADA0", VA = "0x10EADA0")]
	private void method_30()
	{
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000DA0 RID: 3488 RVA: 0x0001D698 File Offset: 0x0001B898
	[Token(Token = "0x6000DA0")]
	[Address(RVA = "0x10EADAC", Offset = "0x10EADAC", VA = "0x10EADAC")]
	private void method_31()
	{
		while (!this.bool_0)
		{
			this.method_23();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.method_38();
			return;
		}
	}

	// Token: 0x06000DA1 RID: 3489 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10EBCFC", Offset = "0x10EBCFC", VA = "0x10EBCFC")]
	[Token(Token = "0x6000DA1")]
	private void method_32()
	{
	}

	// Token: 0x06000DA2 RID: 3490 RVA: 0x0001D6E4 File Offset: 0x0001B8E4
	[Address(RVA = "0x10EBD04", Offset = "0x10EBD04", VA = "0x10EBD04")]
	[Token(Token = "0x6000DA2")]
	private void method_33()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DA3 RID: 3491 RVA: 0x0001D700 File Offset: 0x0001B900
	[Address(RVA = "0x10EC03C", Offset = "0x10EC03C", VA = "0x10EC03C")]
	[Token(Token = "0x6000DA3")]
	private void LateUpdate()
	{
		for (;;)
		{
			if (!this.bool_0)
			{
				this.method_59();
				Quaternion.Euler(Vector3.zero);
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					break;
				}
			}
			else
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.method_59();
				Vector3 zero3 = Vector3.zero;
				Vector3 zero4 = Vector3.zero;
				Vector3 zero5 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000DA4 RID: 3492 RVA: 0x0001D76C File Offset: 0x0001B96C
	[Address(RVA = "0x10ED0D4", Offset = "0x10ED0D4", VA = "0x10ED0D4")]
	[Token(Token = "0x6000DA4")]
	private void method_34()
	{
		for (;;)
		{
			if (!this.bool_0)
			{
				this.method_69();
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				Vector3 zero3 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					break;
				}
			}
			else
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.method_3();
				Vector3 zero4 = Vector3.zero;
				Vector3 zero5 = Vector3.zero;
				Vector3 zero6 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000DA5 RID: 3493 RVA: 0x0001D660 File Offset: 0x0001B860
	[Token(Token = "0x6000DA5")]
	[Address(RVA = "0x10EE3D8", Offset = "0x10EE3D8", VA = "0x10EE3D8")]
	private void method_35()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DA6 RID: 3494 RVA: 0x000024C9 File Offset: 0x000006C9
	[Address(RVA = "0x10EE6FC", Offset = "0x10EE6FC", VA = "0x10EE6FC")]
	[Token(Token = "0x6000DA6")]
	public FingerMovementManager()
	{
	}

	// Token: 0x06000DA7 RID: 3495 RVA: 0x0001D7D4 File Offset: 0x0001B9D4
	[Token(Token = "0x6000DA7")]
	[Address(RVA = "0x10EE710", Offset = "0x10EE710", VA = "0x10EE710")]
	private void method_36()
	{
		for (;;)
		{
			if (!this.bool_0)
			{
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				Vector3 zero3 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					break;
				}
			}
			else
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.method_35();
				Vector3 zero4 = Vector3.zero;
				Vector3 zero5 = Vector3.zero;
				Vector3 zero6 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000DA8 RID: 3496 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10EF734", Offset = "0x10EF734", VA = "0x10EF734")]
	[Token(Token = "0x6000DA8")]
	private void method_37()
	{
	}

	// Token: 0x06000DA9 RID: 3497 RVA: 0x0001D2B4 File Offset: 0x0001B4B4
	[Token(Token = "0x6000DA9")]
	[Address(RVA = "0x10DDC9C", Offset = "0x10DDC9C", VA = "0x10DDC9C")]
	private void method_38()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DAA RID: 3498 RVA: 0x0001D234 File Offset: 0x0001B434
	[Address(RVA = "0x10EF73C", Offset = "0x10EF73C", VA = "0x10EF73C")]
	[Token(Token = "0x6000DAA")]
	private void method_39()
	{
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000DAB RID: 3499 RVA: 0x0001D834 File Offset: 0x0001BA34
	[Address(RVA = "0x10EF748", Offset = "0x10EF748", VA = "0x10EF748")]
	[Token(Token = "0x6000DAB")]
	private void method_40()
	{
		while (this.bool_0)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.method_15();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		this.method_35();
	}

	// Token: 0x06000DAC RID: 3500 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000DAC")]
	[Address(RVA = "0x10F0778", Offset = "0x10F0778", VA = "0x10F0778")]
	private void method_41()
	{
	}

	// Token: 0x06000DAD RID: 3501 RVA: 0x0001D880 File Offset: 0x0001BA80
	[Token(Token = "0x6000DAD")]
	[Address(RVA = "0x10E45AC", Offset = "0x10E45AC", VA = "0x10E45AC")]
	private void method_42()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DAE RID: 3502 RVA: 0x0001D89C File Offset: 0x0001BA9C
	[Address(RVA = "0x10F0780", Offset = "0x10F0780", VA = "0x10F0780")]
	[Token(Token = "0x6000DAE")]
	private void method_43()
	{
		for (;;)
		{
			if (!this.bool_0)
			{
				this.method_38();
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				Vector3 zero3 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					break;
				}
			}
			else
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.method_61();
				Vector3 zero4 = Vector3.zero;
				Vector3 zero5 = Vector3.zero;
				Vector3 zero6 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000DAF RID: 3503 RVA: 0x0001D234 File Offset: 0x0001B434
	[Token(Token = "0x6000DAF")]
	[Address(RVA = "0x10F1AD8", Offset = "0x10F1AD8", VA = "0x10F1AD8")]
	private void method_44()
	{
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000DB0 RID: 3504 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10F1AE4", Offset = "0x10F1AE4", VA = "0x10F1AE4")]
	[Token(Token = "0x6000DB0")]
	private void method_45()
	{
	}

	// Token: 0x06000DB1 RID: 3505 RVA: 0x0001D660 File Offset: 0x0001B860
	[Token(Token = "0x6000DB1")]
	[Address(RVA = "0x10DF5D8", Offset = "0x10DF5D8", VA = "0x10DF5D8")]
	private void method_46()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DB2 RID: 3506 RVA: 0x0001D904 File Offset: 0x0001BB04
	[Address(RVA = "0x10F1AEC", Offset = "0x10F1AEC", VA = "0x10F1AEC")]
	[Token(Token = "0x6000DB2")]
	private void method_47()
	{
		while (this.bool_0)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.method_3();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		this.method_4();
	}

	// Token: 0x06000DB3 RID: 3507 RVA: 0x0001D660 File Offset: 0x0001B860
	[Address(RVA = "0x10E72C4", Offset = "0x10E72C4", VA = "0x10E72C4")]
	[Token(Token = "0x6000DB3")]
	private void method_48()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DB4 RID: 3508 RVA: 0x0001D4CC File Offset: 0x0001B6CC
	[Address(RVA = "0x10F29E4", Offset = "0x10F29E4", VA = "0x10F29E4")]
	[Token(Token = "0x6000DB4")]
	private void method_49()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DB5 RID: 3509 RVA: 0x0001D4CC File Offset: 0x0001B6CC
	[Address(RVA = "0x10E9498", Offset = "0x10E9498", VA = "0x10E9498")]
	[Token(Token = "0x6000DB5")]
	private void method_50()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DB6 RID: 3510 RVA: 0x0001D950 File Offset: 0x0001BB50
	[Address(RVA = "0x10F2D14", Offset = "0x10F2D14", VA = "0x10F2D14")]
	[Token(Token = "0x6000DB6")]
	private void method_51()
	{
		while (!this.bool_0)
		{
			this.method_42();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.method_29();
			return;
		}
	}

	// Token: 0x06000DB7 RID: 3511 RVA: 0x0001D99C File Offset: 0x0001BB9C
	[Address(RVA = "0x10F3D60", Offset = "0x10F3D60", VA = "0x10F3D60")]
	[Token(Token = "0x6000DB7")]
	private void method_52()
	{
		for (;;)
		{
			if (!this.bool_0)
			{
				this.method_14();
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				Vector3 zero3 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					break;
				}
			}
			else
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.method_23();
				Vector3 zero4 = Vector3.zero;
				Vector3 zero5 = Vector3.zero;
				Vector3 zero6 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000DB8 RID: 3512 RVA: 0x0001D234 File Offset: 0x0001B434
	[Address(RVA = "0x10F4D58", Offset = "0x10F4D58", VA = "0x10F4D58")]
	[Token(Token = "0x6000DB8")]
	private void method_53()
	{
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000DB9 RID: 3513 RVA: 0x0001D234 File Offset: 0x0001B434
	[Address(RVA = "0x10F4D64", Offset = "0x10F4D64", VA = "0x10F4D64")]
	[Token(Token = "0x6000DB9")]
	private void method_54()
	{
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000DBA RID: 3514 RVA: 0x0001DA04 File Offset: 0x0001BC04
	[Address(RVA = "0x10F4D70", Offset = "0x10F4D70", VA = "0x10F4D70")]
	[Token(Token = "0x6000DBA")]
	private void method_55()
	{
		for (;;)
		{
			if (!this.bool_0)
			{
				this.method_29();
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				Vector3 zero3 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					break;
				}
			}
			else
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.method_14();
				Vector3 zero4 = Vector3.zero;
				Vector3 zero5 = Vector3.zero;
				Vector3 zero6 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000DBB RID: 3515 RVA: 0x0001DA6C File Offset: 0x0001BC6C
	[Address(RVA = "0x10F5D34", Offset = "0x10F5D34", VA = "0x10F5D34")]
	[Token(Token = "0x6000DBB")]
	private void method_56()
	{
		for (;;)
		{
			if (!this.bool_0)
			{
				this.method_35();
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				Vector3 zero3 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					break;
				}
			}
			else
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.method_38();
				Vector3 zero4 = Vector3.zero;
				Vector3 zero5 = Vector3.zero;
				Vector3 zero6 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000DBC RID: 3516 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10F6D74", Offset = "0x10F6D74", VA = "0x10F6D74")]
	[Token(Token = "0x6000DBC")]
	private void method_57()
	{
	}

	// Token: 0x06000DBD RID: 3517 RVA: 0x0001D234 File Offset: 0x0001B434
	[Address(RVA = "0x10F6D7C", Offset = "0x10F6D7C", VA = "0x10F6D7C")]
	[Token(Token = "0x6000DBD")]
	private void method_58()
	{
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000DBE RID: 3518 RVA: 0x0001DAD4 File Offset: 0x0001BCD4
	[Address(RVA = "0x10DDF88", Offset = "0x10DDF88", VA = "0x10DDF88")]
	[Token(Token = "0x6000DBE")]
	private void method_59()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DBF RID: 3519 RVA: 0x0001DAF0 File Offset: 0x0001BCF0
	[Address(RVA = "0x10F6D88", Offset = "0x10F6D88", VA = "0x10F6D88")]
	[Token(Token = "0x6000DBF")]
	private void method_60()
	{
		for (;;)
		{
			if (!this.bool_0)
			{
				this.method_29();
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				Vector3 zero3 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					break;
				}
			}
			else
			{
				if (!base.photonView.<IsMine>k__BackingField)
				{
					return;
				}
				this.method_1();
				Vector3 zero4 = Vector3.zero;
				Vector3 zero5 = Vector3.zero;
				Vector3 zero6 = Vector3.zero;
				if (this.rightHand_0 == null)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000DC0 RID: 3520 RVA: 0x0001DB58 File Offset: 0x0001BD58
	[Address(RVA = "0x10F1780", Offset = "0x10F1780", VA = "0x10F1780")]
	[Token(Token = "0x6000DC0")]
	private void method_61()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DC1 RID: 3521 RVA: 0x0001D4CC File Offset: 0x0001B6CC
	[Token(Token = "0x6000DC1")]
	[Address(RVA = "0x10DF90C", Offset = "0x10DF90C", VA = "0x10DF90C")]
	private void method_62()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DC2 RID: 3522 RVA: 0x0001D4CC File Offset: 0x0001B6CC
	[Address(RVA = "0x10F7C9C", Offset = "0x10F7C9C", VA = "0x10F7C9C")]
	[Token(Token = "0x6000DC2")]
	private void method_63()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DC3 RID: 3523 RVA: 0x0001D234 File Offset: 0x0001B434
	[Address(RVA = "0x10F7FBC", Offset = "0x10F7FBC", VA = "0x10F7FBC")]
	[Token(Token = "0x6000DC3")]
	private void method_64()
	{
		long num = 1L;
		this.bool_1 = (num != 0L);
	}

	// Token: 0x06000DC4 RID: 3524 RVA: 0x0001DB74 File Offset: 0x0001BD74
	[Address(RVA = "0x10F7FC8", Offset = "0x10F7FC8", VA = "0x10F7FC8")]
	[Token(Token = "0x6000DC4")]
	private void method_65()
	{
		while (this.bool_0)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				return;
			}
			this.method_33();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		this.method_6();
	}

	// Token: 0x06000DC5 RID: 3525 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x10F8FCC", Offset = "0x10F8FCC", VA = "0x10F8FCC")]
	[Token(Token = "0x6000DC5")]
	private void method_66()
	{
	}

	// Token: 0x06000DC6 RID: 3526 RVA: 0x0001DBC0 File Offset: 0x0001BDC0
	[Address(RVA = "0x10F8FD4", Offset = "0x10F8FD4", VA = "0x10F8FD4")]
	[Token(Token = "0x6000DC6")]
	private void method_67()
	{
		while (!this.bool_0)
		{
			this.method_35();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.method_21();
			return;
		}
	}

	// Token: 0x06000DC7 RID: 3527 RVA: 0x0001DC0C File Offset: 0x0001BE0C
	[Token(Token = "0x6000DC7")]
	[Address(RVA = "0x10FA02C", Offset = "0x10FA02C", VA = "0x10FA02C")]
	private void method_68()
	{
		if (!this.bool_0)
		{
			this.method_38();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			return;
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.method_4();
			return;
		}
	}

	// Token: 0x06000DC8 RID: 3528 RVA: 0x0001DC50 File Offset: 0x0001BE50
	[Token(Token = "0x6000DC8")]
	[Address(RVA = "0x10EE0A0", Offset = "0x10EE0A0", VA = "0x10EE0A0")]
	private void method_69()
	{
		if (!this.bool_1)
		{
			InputDevice inputDevice;
			if (inputDevice != null)
			{
			}
			return;
		}
	}

	// Token: 0x06000DC9 RID: 3529 RVA: 0x0001DC6C File Offset: 0x0001BE6C
	[Token(Token = "0x6000DC9")]
	[Address(RVA = "0x10FAFA4", Offset = "0x10FAFA4", VA = "0x10FAFA4")]
	private void method_70()
	{
		while (!this.bool_0)
		{
			this.method_49();
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			if (this.rightHand_0 == null)
			{
				return;
			}
		}
		if (base.photonView.<IsMine>k__BackingField)
		{
			this.method_48();
			return;
		}
	}

	// Token: 0x040001F1 RID: 497
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001F1")]
	public bool bool_0;

	// Token: 0x040001F2 RID: 498
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x40001F2")]
	public float float_0 = (float)5243;

	// Token: 0x040001F3 RID: 499
	[Token(Token = "0x40001F3")]
	[FieldOffset(Offset = "0x28")]
	public FingerMovementManager.RightHand rightHand_0;

	// Token: 0x040001F4 RID: 500
	[Space]
	[Token(Token = "0x40001F4")]
	[FieldOffset(Offset = "0x30")]
	public FingerMovementManager.LeftHand leftHand_0;

	// Token: 0x040001F5 RID: 501
	[Token(Token = "0x40001F5")]
	[FieldOffset(Offset = "0x38")]
	public bool bool_1;

	// Token: 0x02000060 RID: 96
	[Token(Token = "0x2000060")]
	public enum GEnum5
	{
		// Token: 0x040001F7 RID: 503
		[Token(Token = "0x40001F7")]
		const_0,
		// Token: 0x040001F8 RID: 504
		[Token(Token = "0x40001F8")]
		const_1,
		// Token: 0x040001F9 RID: 505
		[Token(Token = "0x40001F9")]
		const_2,
		// Token: 0x040001FA RID: 506
		[Token(Token = "0x40001FA")]
		const_3,
		// Token: 0x040001FB RID: 507
		[Token(Token = "0x40001FB")]
		[InspectorName("Primary & Secondary")]
		const_4
	}

	// Token: 0x02000061 RID: 97
	[Token(Token = "0x2000061")]
	[Serializable]
	public struct RightHand
	{
		// Token: 0x040001FC RID: 508
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40001FC")]
		public FingerMovementManager.RightHand.Finger[] fingers;

		// Token: 0x02000062 RID: 98
		[Token(Token = "0x2000062")]
		[Serializable]
		public struct Finger
		{
			// Token: 0x040001FD RID: 509
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x40001FD")]
			public Transform[] bones;

			// Token: 0x040001FE RID: 510
			[FieldOffset(Offset = "0x8")]
			[Token(Token = "0x40001FE")]
			public Vector3 rotation;

			// Token: 0x040001FF RID: 511
			[FieldOffset(Offset = "0x14")]
			[Token(Token = "0x40001FF")]
			public Quaternion FirstBoneoffset;

			// Token: 0x04000200 RID: 512
			[Token(Token = "0x4000200")]
			[HideInInspector]
			[FieldOffset(Offset = "0x24")]
			public float var;

			// Token: 0x04000201 RID: 513
			[FieldOffset(Offset = "0x28")]
			[Token(Token = "0x4000201")]
			public FingerMovementManager.GEnum5 button;
		}
	}

	// Token: 0x02000063 RID: 99
	[Token(Token = "0x2000063")]
	[Serializable]
	public struct LeftHand
	{
		// Token: 0x04000202 RID: 514
		[Token(Token = "0x4000202")]
		[FieldOffset(Offset = "0x0")]
		public FingerMovementManager.LeftHand.Finger[] fingers;

		// Token: 0x02000064 RID: 100
		[Token(Token = "0x2000064")]
		[Serializable]
		public struct Finger
		{
			// Token: 0x04000203 RID: 515
			[Token(Token = "0x4000203")]
			[FieldOffset(Offset = "0x0")]
			public Transform[] bones;

			// Token: 0x04000204 RID: 516
			[FieldOffset(Offset = "0x8")]
			[Token(Token = "0x4000204")]
			public Vector3 rotation;

			// Token: 0x04000205 RID: 517
			[Token(Token = "0x4000205")]
			[FieldOffset(Offset = "0x14")]
			public Quaternion FirstBoneoffset;

			// Token: 0x04000206 RID: 518
			[FieldOffset(Offset = "0x24")]
			[Token(Token = "0x4000206")]
			[HideInInspector]
			public float var;

			// Token: 0x04000207 RID: 519
			[FieldOffset(Offset = "0x28")]
			[Token(Token = "0x4000207")]
			public FingerMovementManager.GEnum5 button;
		}
	}
}
