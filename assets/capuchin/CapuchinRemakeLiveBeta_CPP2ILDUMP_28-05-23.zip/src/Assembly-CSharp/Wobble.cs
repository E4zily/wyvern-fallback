﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000049 RID: 73
[Token(Token = "0x2000049")]
public class Wobble : MonoBehaviour
{
	// Token: 0x060009E5 RID: 2533 RVA: 0x00016B20 File Offset: 0x00014D20
	[Token(Token = "0x60009E5")]
	[Address(RVA = "0x354BC60", Offset = "0x354BC60", VA = "0x354BC60")]
	private void method_0()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009E6 RID: 2534 RVA: 0x00016B20 File Offset: 0x00014D20
	[Address(RVA = "0x354BCBC", Offset = "0x354BCBC", VA = "0x354BCBC")]
	[Token(Token = "0x60009E6")]
	private void method_1()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009E7 RID: 2535 RVA: 0x00016B20 File Offset: 0x00014D20
	[Token(Token = "0x60009E7")]
	[Address(RVA = "0x354BD18", Offset = "0x354BD18", VA = "0x354BD18")]
	private void method_2()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009E8 RID: 2536 RVA: 0x00016B20 File Offset: 0x00014D20
	[Token(Token = "0x60009E8")]
	[Address(RVA = "0x354BD74", Offset = "0x354BD74", VA = "0x354BD74")]
	private void method_3()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009E9 RID: 2537 RVA: 0x00016B20 File Offset: 0x00014D20
	[Token(Token = "0x60009E9")]
	[Address(RVA = "0x354BDD0", Offset = "0x354BDD0", VA = "0x354BDD0")]
	private void method_4()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009EA RID: 2538 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x354BE2C", Offset = "0x354BE2C", VA = "0x354BE2C")]
	[Token(Token = "0x60009EA")]
	private void method_5()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060009EB RID: 2539 RVA: 0x00016B20 File Offset: 0x00014D20
	[Address(RVA = "0x354BE88", Offset = "0x354BE88", VA = "0x354BE88")]
	[Token(Token = "0x60009EB")]
	private void method_6()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009EC RID: 2540 RVA: 0x00016B20 File Offset: 0x00014D20
	[Address(RVA = "0x354BEE4", Offset = "0x354BEE4", VA = "0x354BEE4")]
	[Token(Token = "0x60009EC")]
	private void method_7()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009ED RID: 2541 RVA: 0x00016B20 File Offset: 0x00014D20
	[Token(Token = "0x60009ED")]
	[Address(RVA = "0x354BF40", Offset = "0x354BF40", VA = "0x354BF40")]
	private void method_8()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009EE RID: 2542 RVA: 0x00016B20 File Offset: 0x00014D20
	[Token(Token = "0x60009EE")]
	[Address(RVA = "0x354BF9C", Offset = "0x354BF9C", VA = "0x354BF9C")]
	private void method_9()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009EF RID: 2543 RVA: 0x00016B3C File Offset: 0x00014D3C
	[Token(Token = "0x60009EF")]
	[Address(RVA = "0x354BFF8", Offset = "0x354BFF8", VA = "0x354BFF8")]
	private void method_10()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float num = this.float_1;
		float z = this.float_8;
		this.float_7 = num;
		Material material = this.renderer_0.material;
		float value;
		material.SetFloat("Player", value);
		Material material2 = this.renderer_0.material;
		float num2 = this.float_4;
		material2.SetFloat("Purchase For ", value);
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.vector3_1.z = num2;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		this.vector3_3.z = z;
		float x = this.vector3_3.x;
		float z2 = this.float_0;
		this.float_5 = num2;
		this.float_6 = num2;
		Vector3 position2 = base.transform.position;
		this.vector3_0.x = num2;
		this.vector3_0.y = x;
		this.vector3_0.z = z2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.vector3_2.x = num2;
		this.vector3_2.y = x;
		this.vector3_2.z = z2;
	}

	// Token: 0x060009F0 RID: 2544 RVA: 0x00016C80 File Offset: 0x00014E80
	[Address(RVA = "0x354C2AC", Offset = "0x354C2AC", VA = "0x354C2AC")]
	[Token(Token = "0x60009F0")]
	private void method_11()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float num = this.float_1;
		float z = this.float_8;
		this.float_7 = num;
		Material material = this.renderer_0.material;
		float value;
		material.SetFloat("tutorialCheck", value);
		Material material2 = this.renderer_0.material;
		float num2 = this.float_4;
		material2.SetFloat(" needs Pelvis transform assigned.", value);
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.vector3_1.z = num2;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		this.vector3_3.z = z;
		float x = this.vector3_3.x;
		float z2 = this.float_0;
		this.float_5 = num2;
		this.float_6 = num2;
		Vector3 position2 = base.transform.position;
		this.vector3_0.x = num2;
		this.vector3_0.y = x;
		this.vector3_0.z = z2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.vector3_2.x = num2;
		this.vector3_2.y = x;
		this.vector3_2.z = z2;
	}

	// Token: 0x060009F1 RID: 2545 RVA: 0x00016B20 File Offset: 0x00014D20
	[Address(RVA = "0x354C560", Offset = "0x354C560", VA = "0x354C560")]
	[Token(Token = "0x60009F1")]
	private void Start()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009F2 RID: 2546 RVA: 0x00016DC4 File Offset: 0x00014FC4
	[Address(RVA = "0x354C5BC", Offset = "0x354C5BC", VA = "0x354C5BC")]
	[Token(Token = "0x60009F2")]
	private void method_12()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float num = this.float_1;
		float z = this.float_8;
		this.float_7 = num;
		Material material = this.renderer_0.material;
		float value;
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		Material material2 = this.renderer_0.material;
		float num2 = this.float_4;
		material2.SetFloat("You Look Like Butt", value);
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.vector3_1.z = num2;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		this.vector3_3.z = z;
		float x = this.vector3_3.x;
		float z2 = this.float_0;
		this.float_5 = num2;
		this.float_6 = num2;
		Vector3 position2 = base.transform.position;
		this.vector3_0.x = num2;
		this.vector3_0.y = x;
		this.vector3_0.z = z2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.vector3_2.x = num2;
		this.vector3_2.y = x;
		this.vector3_2.z = z2;
	}

	// Token: 0x060009F3 RID: 2547 RVA: 0x00016B20 File Offset: 0x00014D20
	[Token(Token = "0x60009F3")]
	[Address(RVA = "0x354C870", Offset = "0x354C870", VA = "0x354C870")]
	private void method_13()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009F4 RID: 2548 RVA: 0x00016F08 File Offset: 0x00015108
	[Address(RVA = "0x354C8CC", Offset = "0x354C8CC", VA = "0x354C8CC")]
	[Token(Token = "0x60009F4")]
	private void method_14()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float num = this.float_1;
		float z = this.float_8;
		this.float_7 = num;
		Material material = this.renderer_0.material;
		float value;
		material.SetFloat("BN", value);
		Material material2 = this.renderer_0.material;
		float num2 = this.float_4;
		material2.SetFloat("Skelechin", value);
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.vector3_1.z = num2;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		this.vector3_3.z = z;
		float x = this.vector3_3.x;
		float z2 = this.float_0;
		this.float_5 = num2;
		this.float_6 = num2;
		Vector3 position2 = base.transform.position;
		this.vector3_0.x = num2;
		this.vector3_0.y = x;
		this.vector3_0.z = z2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.vector3_2.x = num2;
		this.vector3_2.y = x;
		this.vector3_2.z = z2;
	}

	// Token: 0x060009F5 RID: 2549 RVA: 0x0001704C File Offset: 0x0001524C
	[Token(Token = "0x60009F5")]
	[Address(RVA = "0x354CB80", Offset = "0x354CB80", VA = "0x354CB80")]
	private void method_15()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float num = this.float_1;
		float z = this.float_8;
		this.float_7 = num;
		Material material = this.renderer_0.material;
		float value;
		material.SetFloat("containsStaff", value);
		float num2 = this.float_4;
		Material material2;
		material2.SetFloat("forced knee retract", value);
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.vector3_1.z = num2;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		this.vector3_3.z = z;
		float x = this.vector3_3.x;
		float z2 = this.float_0;
		this.float_5 = num2;
		this.float_6 = num2;
		Vector3 position2 = base.transform.position;
		this.vector3_0.x = num2;
		this.vector3_0.y = x;
		this.vector3_0.z = z2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.vector3_2.x = num2;
		this.vector3_2.y = x;
		this.vector3_2.z = z2;
	}

	// Token: 0x060009F6 RID: 2550 RVA: 0x00017184 File Offset: 0x00015384
	[Address(RVA = "0x354CE34", Offset = "0x354CE34", VA = "0x354CE34")]
	[Token(Token = "0x60009F6")]
	private void method_16()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float num = this.float_1;
		float z = this.float_8;
		this.float_7 = num;
		Material material = this.renderer_0.material;
		float value;
		material.SetFloat("{0} ({1})", value);
		Material material2 = this.renderer_0.material;
		float num2 = this.float_4;
		material2.SetFloat("PRESS AGAIN TO CONFIRM", value);
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.vector3_1.z = num2;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		this.vector3_3.z = z;
		float x = this.vector3_3.x;
		float z2 = this.float_0;
		this.float_5 = num2;
		this.float_6 = num2;
		Vector3 position2 = base.transform.position;
		this.vector3_0.x = num2;
		this.vector3_0.y = x;
		this.vector3_0.z = z2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.vector3_2.x = num2;
		this.vector3_2.y = x;
		this.vector3_2.z = z2;
	}

	// Token: 0x060009F7 RID: 2551 RVA: 0x000172C8 File Offset: 0x000154C8
	[Token(Token = "0x60009F7")]
	[Address(RVA = "0x354D0E8", Offset = "0x354D0E8", VA = "0x354D0E8")]
	private void method_17()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float num = this.float_1;
		float z = this.float_8;
		this.float_7 = num;
		Material material = this.renderer_0.material;
		float value;
		material.SetFloat("BN", value);
		Material material2 = this.renderer_0.material;
		float num2 = this.float_4;
		material2.SetFloat("Did Hit", value);
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.vector3_1.z = num2;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		this.vector3_3.z = z;
		float x = this.vector3_3.x;
		float z2 = this.float_0;
		this.float_5 = num2;
		this.float_6 = num2;
		Vector3 position2 = base.transform.position;
		this.vector3_0.x = num2;
		this.vector3_0.y = x;
		this.vector3_0.z = z2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.vector3_2.x = num2;
		this.vector3_2.y = x;
		this.vector3_2.z = z2;
	}

	// Token: 0x060009F8 RID: 2552 RVA: 0x0001740C File Offset: 0x0001560C
	[Address(RVA = "0x354D39C", Offset = "0x354D39C", VA = "0x354D39C")]
	[Token(Token = "0x60009F8")]
	private void Update()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float num = this.float_1;
		float z = this.float_8;
		this.float_7 = num;
		Material material = this.renderer_0.material;
		float value;
		material.SetFloat("_WobbleX", value);
		Material material2 = this.renderer_0.material;
		float num2 = this.float_4;
		material2.SetFloat("_WobbleZ", value);
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.vector3_1.z = num2;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		this.vector3_3.z = z;
		float x = this.vector3_3.x;
		float z2 = this.float_0;
		this.float_5 = num2;
		this.float_6 = num2;
		Vector3 position2 = base.transform.position;
		this.vector3_0.x = num2;
		this.vector3_0.y = x;
		this.vector3_0.z = z2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.vector3_2.x = num2;
		this.vector3_2.y = x;
		this.vector3_2.z = z2;
	}

	// Token: 0x060009F9 RID: 2553 RVA: 0x00016B20 File Offset: 0x00014D20
	[Token(Token = "0x60009F9")]
	[Address(RVA = "0x354D640", Offset = "0x354D640", VA = "0x354D640")]
	private void method_18()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009FA RID: 2554 RVA: 0x00016B20 File Offset: 0x00014D20
	[Address(RVA = "0x354D69C", Offset = "0x354D69C", VA = "0x354D69C")]
	[Token(Token = "0x60009FA")]
	private void method_19()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009FB RID: 2555 RVA: 0x00016B20 File Offset: 0x00014D20
	[Address(RVA = "0x354D6F8", Offset = "0x354D6F8", VA = "0x354D6F8")]
	[Token(Token = "0x60009FB")]
	private void method_20()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009FC RID: 2556 RVA: 0x00017550 File Offset: 0x00015750
	[Address(RVA = "0x354D754", Offset = "0x354D754", VA = "0x354D754")]
	[Token(Token = "0x60009FC")]
	public Wobble()
	{
		long num = 1065353216L;
		long num2 = 1056964608L;
		this.float_2 = (float)num;
		this.float_8 = (float)num2;
		base..ctor();
	}

	// Token: 0x060009FD RID: 2557 RVA: 0x00017580 File Offset: 0x00015780
	[Address(RVA = "0x354D778", Offset = "0x354D778", VA = "0x354D778")]
	[Token(Token = "0x60009FD")]
	private void method_21()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float num = this.float_1;
		float z = this.float_8;
		this.float_7 = num;
		Material material = this.renderer_0.material;
		float value;
		material.SetFloat("Left a room", value);
		Material material2 = this.renderer_0.material;
		float num2 = this.float_4;
		material2.SetFloat("ChangeToTagged", value);
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.vector3_1.z = num2;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		this.vector3_3.z = z;
		float x = this.vector3_3.x;
		float z2 = this.float_0;
		this.float_5 = num2;
		this.float_6 = num2;
		Vector3 position2 = base.transform.position;
		this.vector3_0.x = num2;
		this.vector3_0.y = x;
		this.vector3_0.z = z2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.vector3_2.x = num2;
		this.vector3_2.y = x;
		this.vector3_2.z = z2;
	}

	// Token: 0x060009FE RID: 2558 RVA: 0x00016B20 File Offset: 0x00014D20
	[Address(RVA = "0x354DA2C", Offset = "0x354DA2C", VA = "0x354DA2C")]
	[Token(Token = "0x60009FE")]
	private void method_22()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x060009FF RID: 2559 RVA: 0x00016B20 File Offset: 0x00014D20
	[Address(RVA = "0x354DA88", Offset = "0x354DA88", VA = "0x354DA88")]
	[Token(Token = "0x60009FF")]
	private void method_23()
	{
		Renderer component = base.GetComponent<Renderer>();
		this.renderer_0 = component;
	}

	// Token: 0x06000A00 RID: 2560 RVA: 0x000176C4 File Offset: 0x000158C4
	[Token(Token = "0x6000A00")]
	[Address(RVA = "0x354DAE4", Offset = "0x354DAE4", VA = "0x354DAE4")]
	private void method_24()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		float num = this.float_1;
		float z = this.float_8;
		this.float_7 = num;
		Material material = this.renderer_0.material;
		float value;
		material.SetFloat("TurnAmount", value);
		Material material2 = this.renderer_0.material;
		float num2 = this.float_4;
		material2.SetFloat("Round end", value);
		Vector3 position = base.transform.position;
		float deltaTime4 = Time.deltaTime;
		this.vector3_1.z = num2;
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		this.vector3_3.z = z;
		float x = this.vector3_3.x;
		float z2 = this.float_0;
		this.float_5 = num2;
		this.float_6 = num2;
		Vector3 position2 = base.transform.position;
		this.vector3_0.x = num2;
		this.vector3_0.y = x;
		this.vector3_0.z = z2;
		Vector3 eulerAngles2 = base.transform.rotation.eulerAngles;
		this.vector3_2.x = num2;
		this.vector3_2.y = x;
		this.vector3_2.z = z2;
	}

	// Token: 0x04000174 RID: 372
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000174")]
	private Renderer renderer_0;

	// Token: 0x04000175 RID: 373
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000175")]
	private Vector3 vector3_0;

	// Token: 0x04000176 RID: 374
	[Token(Token = "0x4000176")]
	[FieldOffset(Offset = "0x2C")]
	private Vector3 vector3_1;

	// Token: 0x04000177 RID: 375
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000177")]
	private Vector3 vector3_2;

	// Token: 0x04000178 RID: 376
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000178")]
	private Vector3 vector3_3;

	// Token: 0x04000179 RID: 377
	[Token(Token = "0x4000179")]
	[FieldOffset(Offset = "0x50")]
	public float float_0;

	// Token: 0x0400017A RID: 378
	[Token(Token = "0x400017A")]
	[FieldOffset(Offset = "0x54")]
	public float float_1;

	// Token: 0x0400017B RID: 379
	[Token(Token = "0x400017B")]
	[FieldOffset(Offset = "0x58")]
	public float float_2;

	// Token: 0x0400017C RID: 380
	[Token(Token = "0x400017C")]
	[FieldOffset(Offset = "0x5C")]
	private float float_3;

	// Token: 0x0400017D RID: 381
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400017D")]
	private float float_4;

	// Token: 0x0400017E RID: 382
	[Token(Token = "0x400017E")]
	[FieldOffset(Offset = "0x64")]
	private float float_5;

	// Token: 0x0400017F RID: 383
	[Token(Token = "0x400017F")]
	[FieldOffset(Offset = "0x68")]
	private float float_6;

	// Token: 0x04000180 RID: 384
	[FieldOffset(Offset = "0x6C")]
	[Token(Token = "0x4000180")]
	private float float_7;

	// Token: 0x04000181 RID: 385
	[Token(Token = "0x4000181")]
	[FieldOffset(Offset = "0x70")]
	private float float_8;
}
