﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Locomotion;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000011 RID: 17
[Token(Token = "0x2000011")]
public class TagManager : MonoBehaviourPun
{
	// Token: 0x060001E0 RID: 480 RVA: 0x0000884C File Offset: 0x00006A4C
	[Address(RVA = "0x2D2BEEC", Offset = "0x2D2BEEC", VA = "0x2D2BEEC")]
	[Token(Token = "0x60001E0")]
	private void method_0()
	{
		if (this.bool_0)
		{
			if (!this.bool_1)
			{
				AudioSource audioSource = this.audioSource_0;
				AudioClip clip = this.audioClip_0;
				audioSource.PlayOneShot(clip);
				IEnumerator routine = Player.player_0.method_10();
				base.StartCoroutine(routine);
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
			return;
		}
		if (!this.bool_1)
		{
		}
	}

	// Token: 0x060001E1 RID: 481 RVA: 0x000088A8 File Offset: 0x00006AA8
	[Address(RVA = "0x2D2BFEC", Offset = "0x2D2BFEC", VA = "0x2D2BFEC")]
	[PunRPC]
	[Token(Token = "0x60001E1")]
	public void ChangeToRegular()
	{
		do
		{
			base.gameObject.tag = "Regular";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001E2 RID: 482 RVA: 0x000088D4 File Offset: 0x00006AD4
	[Address(RVA = "0x2D2C0FC", Offset = "0x2D2C0FC", VA = "0x2D2C0FC")]
	[Token(Token = "0x60001E2")]
	public void method_1()
	{
		base.gameObject.tag = "NGNNoSound";
	}

	// Token: 0x060001E3 RID: 483 RVA: 0x00002095 File Offset: 0x00000295
	[Token(Token = "0x60001E3")]
	[Address(RVA = "0x2D2C1EC", Offset = "0x2D2C1EC", VA = "0x2D2C1EC")]
	public TagManager()
	{
	}

	// Token: 0x060001E4 RID: 484 RVA: 0x000088F4 File Offset: 0x00006AF4
	[Token(Token = "0x60001E4")]
	[Address(RVA = "0x2D2C1F4", Offset = "0x2D2C1F4", VA = "0x2D2C1F4")]
	public void method_2()
	{
		do
		{
			base.gameObject.tag = "lava";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001E5 RID: 485 RVA: 0x00008920 File Offset: 0x00006B20
	[Address(RVA = "0x2D2C304", Offset = "0x2D2C304", VA = "0x2D2C304")]
	[Token(Token = "0x60001E5")]
	private void method_3()
	{
		if (this.bool_0)
		{
			if (!this.bool_1)
			{
				AudioSource audioSource = this.audioSource_0;
				AudioClip clip = this.audioClip_0;
				audioSource.PlayOneShot(clip);
				IEnumerator routine = Player.player_0.method_10();
				base.StartCoroutine(routine);
			}
			return;
		}
		if (!this.bool_1)
		{
		}
	}

	// Token: 0x060001E6 RID: 486 RVA: 0x00008970 File Offset: 0x00006B70
	[Token(Token = "0x60001E6")]
	[Address(RVA = "0x2D2C3FC", Offset = "0x2D2C3FC", VA = "0x2D2C3FC")]
	private void Update()
	{
		if (this.bool_0)
		{
			if (!this.bool_1)
			{
				AudioSource audioSource = this.audioSource_0;
				AudioClip clip = this.audioClip_0;
				audioSource.PlayOneShot(clip);
				IEnumerator routine = Player.player_0.method_35();
				base.StartCoroutine(routine);
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
			return;
		}
		if (!this.bool_1)
		{
		}
	}

	// Token: 0x060001E7 RID: 487 RVA: 0x000089CC File Offset: 0x00006BCC
	[Token(Token = "0x60001E7")]
	[Address(RVA = "0x2D2C4F8", Offset = "0x2D2C4F8", VA = "0x2D2C4F8")]
	public void method_4()
	{
		do
		{
			base.gameObject.tag = "liftoff failed!";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001E8 RID: 488 RVA: 0x000089F8 File Offset: 0x00006BF8
	[Token(Token = "0x60001E8")]
	[Address(RVA = "0x2D2C60C", Offset = "0x2D2C60C", VA = "0x2D2C60C")]
	public void method_5()
	{
		do
		{
			base.gameObject.tag = "Player";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001E9 RID: 489 RVA: 0x00008A24 File Offset: 0x00006C24
	[Address(RVA = "0x2D2C720", Offset = "0x2D2C720", VA = "0x2D2C720")]
	[Token(Token = "0x60001E9")]
	private void method_6()
	{
		if (!this.bool_1)
		{
			AudioSource audioSource = this.audioSource_0;
			AudioClip clip = this.audioClip_0;
			audioSource.PlayOneShot(clip);
			IEnumerator routine = Player.player_0.method_35();
			base.StartCoroutine(routine);
		}
	}

	// Token: 0x060001EA RID: 490 RVA: 0x00008A64 File Offset: 0x00006C64
	[Token(Token = "0x60001EA")]
	[Address(RVA = "0x2D2C820", Offset = "0x2D2C820", VA = "0x2D2C820")]
	public void method_7()
	{
		do
		{
			base.gameObject.tag = "You are not the master of the server, you cannot start the game.";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001EB RID: 491 RVA: 0x00008A90 File Offset: 0x00006C90
	[Address(RVA = "0x2D2C934", Offset = "0x2D2C934", VA = "0x2D2C934")]
	[Token(Token = "0x60001EB")]
	public void method_8(bool bool_2)
	{
		do
		{
			base.gameObject.tag = "You have been banned for ";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001EC RID: 492 RVA: 0x00008ABC File Offset: 0x00006CBC
	[Address(RVA = "0x2D2CA48", Offset = "0x2D2CA48", VA = "0x2D2CA48")]
	[Token(Token = "0x60001EC")]
	public void method_9(bool bool_2)
	{
		base.gameObject.tag = "got funky mone";
	}

	// Token: 0x060001ED RID: 493 RVA: 0x00008ADC File Offset: 0x00006CDC
	[Token(Token = "0x60001ED")]
	[Address(RVA = "0x2D2CB34", Offset = "0x2D2CB34", VA = "0x2D2CB34")]
	public void method_10()
	{
		do
		{
			base.gameObject.tag = "Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001EE RID: 494 RVA: 0x00008B08 File Offset: 0x00006D08
	[Address(RVA = "0x2D2CC44", Offset = "0x2D2CC44", VA = "0x2D2CC44")]
	[Token(Token = "0x60001EE")]
	public void method_11()
	{
		base.gameObject.tag = "typesOfTalk";
	}

	// Token: 0x060001EF RID: 495 RVA: 0x00008B28 File Offset: 0x00006D28
	[Address(RVA = "0x2D2CD34", Offset = "0x2D2CD34", VA = "0x2D2CD34")]
	[Token(Token = "0x60001EF")]
	private void method_12()
	{
		if (this.bool_0)
		{
			if (!this.bool_1)
			{
				AudioSource audioSource = this.audioSource_0;
				AudioClip clip = this.audioClip_0;
				audioSource.PlayOneShot(clip);
				IEnumerator routine = Player.player_0.method_8();
				base.StartCoroutine(routine);
			}
			return;
		}
		if (!this.bool_1)
		{
		}
	}

	// Token: 0x060001F0 RID: 496 RVA: 0x00008B78 File Offset: 0x00006D78
	[Address(RVA = "0x2D2CE34", Offset = "0x2D2CE34", VA = "0x2D2CE34")]
	[Token(Token = "0x60001F0")]
	public void method_13()
	{
		do
		{
			base.gameObject.tag = "Start Gamemode";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001F1 RID: 497 RVA: 0x00008BA4 File Offset: 0x00006DA4
	[Address(RVA = "0x2D2CF44", Offset = "0x2D2CF44", VA = "0x2D2CF44")]
	[Token(Token = "0x60001F1")]
	public void method_14()
	{
		base.gameObject.tag = "Pause";
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x00008BC4 File Offset: 0x00006DC4
	[Token(Token = "0x60001F2")]
	[Address(RVA = "0x2D2D030", Offset = "0x2D2D030", VA = "0x2D2D030")]
	public void method_15()
	{
		do
		{
			base.gameObject.tag = "PRESS AGAIN TO CONFIRM";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001F3 RID: 499 RVA: 0x00008BF0 File Offset: 0x00006DF0
	[Address(RVA = "0x2D2D140", Offset = "0x2D2D140", VA = "0x2D2D140")]
	[Token(Token = "0x60001F3")]
	public void method_16()
	{
		base.gameObject.tag = "_Color";
		Renderer[] bodyParts = this.BodyParts;
		while (bodyParts != null)
		{
		}
		throw new NullReferenceException();
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x00008C1C File Offset: 0x00006E1C
	[Token(Token = "0x60001F4")]
	[Address(RVA = "0x2D2D250", Offset = "0x2D2D250", VA = "0x2D2D250")]
	public void method_17()
	{
		base.gameObject.tag = "Player";
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x00008C3C File Offset: 0x00006E3C
	[Token(Token = "0x60001F5")]
	[Address(RVA = "0x2D2D340", Offset = "0x2D2D340", VA = "0x2D2D340")]
	private void method_18()
	{
		if (this.bool_0)
		{
			if (!this.bool_1)
			{
				IEnumerator routine = Player.player_0.method_8();
				base.StartCoroutine(routine);
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
			return;
		}
		if (!this.bool_1)
		{
		}
	}

	// Token: 0x060001F6 RID: 502 RVA: 0x00008C80 File Offset: 0x00006E80
	[Address(RVA = "0x2D2D444", Offset = "0x2D2D444", VA = "0x2D2D444")]
	[PunRPC]
	[Token(Token = "0x60001F6")]
	public void ChangeToTagged(bool bool_2)
	{
		do
		{
			base.gameObject.tag = "Tagged";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001F7 RID: 503 RVA: 0x00008CAC File Offset: 0x00006EAC
	[Address(RVA = "0x2D2D558", Offset = "0x2D2D558", VA = "0x2D2D558")]
	[Token(Token = "0x60001F7")]
	public void method_19(bool bool_2)
	{
		do
		{
			base.gameObject.tag = "_Tint";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001F8 RID: 504 RVA: 0x00008CD8 File Offset: 0x00006ED8
	[Address(RVA = "0x2D2D66C", Offset = "0x2D2D66C", VA = "0x2D2D66C")]
	[Token(Token = "0x60001F8")]
	public void method_20()
	{
		base.gameObject.tag = "Player";
	}

	// Token: 0x060001F9 RID: 505 RVA: 0x00008CF8 File Offset: 0x00006EF8
	[Token(Token = "0x60001F9")]
	[Address(RVA = "0x2D2D75C", Offset = "0x2D2D75C", VA = "0x2D2D75C")]
	private void method_21()
	{
		if (this.bool_0)
		{
			if (!this.bool_1)
			{
				AudioSource audioSource = this.audioSource_0;
				AudioClip clip = this.audioClip_0;
				audioSource.PlayOneShot(clip);
				IEnumerator routine = Player.player_0.method_35();
				base.StartCoroutine(routine);
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
			return;
		}
		if (this.bool_1)
		{
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
	}

	// Token: 0x060001FA RID: 506 RVA: 0x00008D5C File Offset: 0x00006F5C
	[Address(RVA = "0x2D2D860", Offset = "0x2D2D860", VA = "0x2D2D860")]
	[Token(Token = "0x60001FA")]
	public void method_22()
	{
		do
		{
			base.gameObject.tag = "/";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x060001FB RID: 507 RVA: 0x00008D88 File Offset: 0x00006F88
	[Address(RVA = "0x2D2D970", Offset = "0x2D2D970", VA = "0x2D2D970")]
	[Token(Token = "0x60001FB")]
	public void method_23()
	{
		base.gameObject.tag = "You are not the master of the server, you cannot start the game.";
	}

	// Token: 0x060001FC RID: 508 RVA: 0x00008DA8 File Offset: 0x00006FA8
	[Token(Token = "0x60001FC")]
	[Address(RVA = "0x2D2DA60", Offset = "0x2D2DA60", VA = "0x2D2DA60")]
	public void method_24(bool bool_2)
	{
		base.gameObject.tag = "PRESS AGAIN TO CONFIRM";
	}

	// Token: 0x060001FD RID: 509 RVA: 0x00008DC8 File Offset: 0x00006FC8
	[Address(RVA = "0x2D2DB4C", Offset = "0x2D2DB4C", VA = "0x2D2DB4C")]
	[Token(Token = "0x60001FD")]
	public void method_25(bool bool_2)
	{
		do
		{
			base.gameObject.tag = "hh:mmtt";
		}
		while (this.BodyParts != null);
		throw new NullReferenceException();
	}

	// Token: 0x04000043 RID: 67
	[SerializeField]
	[Header("Player Info")]
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000043")]
	private Renderer[] BodyParts;

	// Token: 0x04000044 RID: 68
	[Token(Token = "0x4000044")]
	[FieldOffset(Offset = "0x28")]
	public bool bool_0;

	// Token: 0x04000045 RID: 69
	[Token(Token = "0x4000045")]
	[FieldOffset(Offset = "0x30")]
	public TeamSettings teamSettings_0;

	// Token: 0x04000046 RID: 70
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000046")]
	public AudioSource audioSource_0;

	// Token: 0x04000047 RID: 71
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000047")]
	public AudioClip audioClip_0;

	// Token: 0x04000048 RID: 72
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000048")]
	public ParticleSystem[] particleSystem_0;

	// Token: 0x04000049 RID: 73
	[Token(Token = "0x4000049")]
	[FieldOffset(Offset = "0x58")]
	private bool bool_1;
}
