﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

// Token: 0x02000100 RID: 256
[Token(Token = "0x2000100")]
public class TurnSpeedChanger : MonoBehaviour
{
	// Token: 0x06002706 RID: 9990 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x25D5638", Offset = "0x25D5638", VA = "0x25D5638")]
	[Token(Token = "0x6002706")]
	public TurnSpeedChanger()
	{
	}

	// Token: 0x06002707 RID: 9991 RVA: 0x00048740 File Offset: 0x00046940
	[Token(Token = "0x6002707")]
	[Address(RVA = "0x25D5640", Offset = "0x25D5640", VA = "0x25D5640")]
	public void method_0(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("SaveHeight", value);
		}
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("PRESS AGAIN TO CONFIRM", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("monkeScream", value3);
		if (this.int_0 == 0)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			int value4 = this.int_1;
			PlayerPrefs.SetInt("Vector1_d371bd24217449349bd747533d51af6b", value4);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("{0}/{1:f0}", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("clickLol", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("NetworkPlayer", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49676;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("PLAYER IS BANNED", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16384;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 0L;
		gameObject20.SetActive(active20 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Squeeze", value9);
	}

	// Token: 0x06002708 RID: 9992 RVA: 0x00048A2C File Offset: 0x00046C2C
	[Address(RVA = "0x25D5AF4", Offset = "0x25D5AF4", VA = "0x25D5AF4")]
	[Token(Token = "0x6002708")]
	public void method_1(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("_WobbleX", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("_Color", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Player", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("forced knee retract", value4);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("\tExpires: ", value5);
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("You have been banned for ", value6);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1073741824L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("username", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("A new Player joined a Room.", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17052;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Added Winner Money", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)32768;
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_0;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("An error has occured while buying bananas, please restart your game and try again", value10);
	}

	// Token: 0x06002709 RID: 9993 RVA: 0x00048D14 File Offset: 0x00046F14
	[Address(RVA = "0x25D5FB0", Offset = "0x25D5FB0", VA = "0x25D5FB0")]
	[Token(Token = "0x6002709")]
	public void method_2(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("EnableCosmetic", value);
			if (this.int_0 == 0)
			{
				GameObject gameObject3 = this.gameObject_0;
				long active3 = 0L;
				gameObject3.SetActive(active3 != 0L);
				this.gameObject_1.SetActive(active3 != 0L);
				int value2 = this.int_1;
				PlayerPrefs.SetInt("username", value2);
			}
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject4 = this.gameObject_0;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		GameObject gameObject5 = this.gameObject_1;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Cannot access index {0}. Buffer size is {1}", value3);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject6 = this.gameObject_0;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		GameObject gameObject7 = this.gameObject_1;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("Update User Inventory", value4);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject8 = this.gameObject_0;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		GameObject gameObject9 = this.gameObject_1;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("Player", value5);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1073741824L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		GameObject gameObject10 = this.gameObject_0;
		long active10 = 0L;
		gameObject10.SetActive(active10 != 0L);
		GameObject gameObject11 = this.gameObject_1;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("KeyPos", value6);
		ContinuousTurnProviderBase continuousTurnProviderBase4 = this.continuousTurnProviderBase_0;
		long turnSpeed4 = 1073741824L;
		continuousTurnProviderBase4.m_TurnSpeed = (float)turnSpeed4;
		GameObject gameObject12 = this.gameObject_0;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		GameObject gameObject13 = this.gameObject_1;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("_BaseColor", value7);
		ContinuousTurnProviderBase continuousTurnProviderBase5 = this.continuousTurnProviderBase_0;
		long turnSpeed5 = 1065353216L;
		continuousTurnProviderBase5.m_TurnSpeed = (float)turnSpeed5;
		GameObject gameObject14 = this.gameObject_0;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("Queue", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49716;
		GameObject gameObject16 = this.gameObject_0;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("_BumpMap", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)40960;
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		GameObject gameObject19 = this.gameObject_0;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("Vector1_d371bd24217449349bd747533d51af6b", value10);
	}

	// Token: 0x0600270A RID: 9994 RVA: 0x0004903C File Offset: 0x0004723C
	[Token(Token = "0x600270A")]
	[Address(RVA = "0x25D6464", Offset = "0x25D6464", VA = "0x25D6464")]
	public void method_3(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("poweredup!", value);
		}
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("Add/Remove Hat", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Start Gamemode", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("Muted", value4);
		if (this.int_0 == 0)
		{
			GameObject gameObject9 = this.gameObject_0;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			GameObject gameObject10 = this.gameObject_1;
			long active10 = 0L;
			gameObject10.SetActive(active10 != 0L);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("You are not the master of the server, you cannot start the game.", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("PlayWave", value6);
		if (this.int_0 == 0)
		{
			GameObject gameObject15 = this.gameObject_0;
			long active15 = 0L;
			gameObject15.SetActive(active15 != 0L);
			GameObject gameObject16 = this.gameObject_1;
			long active16 = 0L;
			gameObject16.SetActive(active16 != 0L);
			int value7 = this.int_1;
			PlayerPrefs.SetInt("liftoff failed!", value7);
			if (this.int_0 == 0)
			{
				GameObject gameObject17 = this.gameObject_0;
				long active17 = 1L;
				gameObject17.SetActive(active17 != 0L);
				GameObject gameObject18 = this.gameObject_1;
				long active18 = 0L;
				gameObject18.SetActive(active18 != 0L);
				int value8 = this.int_1;
				PlayerPrefs.SetInt(" ", value8);
				if (this.int_0 == 0)
				{
					this.continuousTurnProviderBase_0.m_TurnSpeed = (float)24576;
					GameObject gameObject19 = this.gameObject_1;
					long active19 = 0L;
					gameObject19.SetActive(active19 != 0L);
					GameObject gameObject20 = this.gameObject_0;
					long active20 = 1L;
					gameObject20.SetActive(active20 != 0L);
					int value9 = this.int_1;
					PlayerPrefs.SetInt("RightHandAttachPoint", value9);
					return;
				}
			}
		}
	}

	// Token: 0x0600270B RID: 9995 RVA: 0x0004932C File Offset: 0x0004752C
	[Address(RVA = "0x25D6908", Offset = "0x25D6908", VA = "0x25D6908")]
	[Token(Token = "0x600270B")]
	public void method_4(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("Faild To Add Winner Money: ", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("StartSong", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Horizontal", value3);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.", value4);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1073741824L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 0L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("\tExpires: ", value5);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1065353216L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Skelechin", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("character limit reached", value7);
		ContinuousTurnProviderBase continuousTurnProviderBase4 = this.continuousTurnProviderBase_0;
		long turnSpeed4 = 1065353216L;
		continuousTurnProviderBase4.m_TurnSpeed = (float)turnSpeed4;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("false", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49914;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Squeeze", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)40960;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 1L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("back", value10);
	}

	// Token: 0x0600270C RID: 9996 RVA: 0x0004965C File Offset: 0x0004785C
	[Token(Token = "0x600270C")]
	[Address(RVA = "0x25D6DC4", Offset = "0x25D6DC4", VA = "0x25D6DC4")]
	public void method_5(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("Body", value);
			if (this.int_0 == 0)
			{
				GameObject gameObject3 = this.gameObject_0;
				long active3 = 0L;
				gameObject3.SetActive(active3 != 0L);
				GameObject gameObject4 = this.gameObject_1;
				long active4 = 1L;
				gameObject4.SetActive(active4 != 0L);
				int value2 = this.int_1;
				PlayerPrefs.SetInt("True", value2);
			}
		}
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Open", value3);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1073741824L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("betaAgree", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("PRESS AGAIN TO CONFIRM", value5);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1065353216L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		long active12 = 1L;
		gameObject11.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("CapuchinRemade", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject12 = this.gameObject_0;
		long active13 = 1L;
		gameObject12.SetActive(active13 != 0L);
		GameObject gameObject13 = this.gameObject_1;
		long active14 = 1L;
		gameObject13.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("false", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject14 = this.gameObject_0;
		long active15 = 1L;
		gameObject14.SetActive(active15 != 0L);
		GameObject gameObject15 = this.gameObject_1;
		long active16 = 0L;
		gameObject15.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("windowsmr", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16904;
		GameObject gameObject16 = this.gameObject_0;
		long active17 = 1L;
		gameObject16.SetActive(active17 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active18 = 1L;
		gameObject17.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Stopped Colliding", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)32768;
		GameObject gameObject18 = this.gameObject_1;
		long active19 = 0L;
		gameObject18.SetActive(active19 != 0L);
		GameObject gameObject19 = this.gameObject_0;
		long active20 = 0L;
		gameObject19.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt(", ", value10);
	}

	// Token: 0x0600270D RID: 9997 RVA: 0x00049970 File Offset: 0x00047B70
	[Address(RVA = "0x25D7278", Offset = "0x25D7278", VA = "0x25D7278")]
	[Token(Token = "0x600270D")]
	public void method_6(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("FingerTip", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("HeadAttachPoint", value2);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt(".Please press the button if you would like to play alone", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("Head", value4);
		if (this.int_0 == 0)
		{
			GameObject gameObject9 = this.gameObject_0;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			GameObject gameObject10 = this.gameObject_1;
			long active10 = 1L;
			gameObject10.SetActive(active10 != 0L);
			int value5 = this.int_1;
			PlayerPrefs.SetInt("Date: ", value5);
		}
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("HandL", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int active15 = this.int_1;
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		this.gameObject_0.SetActive(active15 != 0);
		GameObject gameObject15 = this.gameObject_1;
		long active16 = 1L;
		gameObject15.SetActive(active16 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("Skelechin", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49920;
		GameObject gameObject16 = this.gameObject_0;
		long active17 = 0L;
		gameObject16.SetActive(active17 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active18 = 1L;
		gameObject17.SetActive(active18 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("isLava", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)32768;
		GameObject gameObject18 = this.gameObject_1;
		long active19 = 0L;
		gameObject18.SetActive(active19 != 0L);
		GameObject gameObject19 = this.gameObject_0;
		long active20 = 1L;
		gameObject19.SetActive(active20 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Players Online: ", value9);
	}

	// Token: 0x0600270E RID: 9998 RVA: 0x00049C74 File Offset: 0x00047E74
	[Address(RVA = "0x25D772C", Offset = "0x25D772C", VA = "0x25D772C")]
	[Token(Token = "0x600270E")]
	public void method_7(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("PlayerHead", value);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Player", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("FingerTip", value4);
		if (this.int_0 == 0)
		{
			GameObject gameObject9 = this.gameObject_0;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			GameObject gameObject10 = this.gameObject_1;
			long active10 = 1L;
			gameObject10.SetActive(active10 != 0L);
			int value5 = this.int_1;
			PlayerPrefs.SetInt("TurnAmount", value5);
		}
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Game Started", value6);
		if (this.int_0 == 0)
		{
			GameObject gameObject13 = this.gameObject_0;
			long active13 = 0L;
			gameObject13.SetActive(active13 != 0L);
			GameObject gameObject14 = this.gameObject_1;
			long active14 = 0L;
			gameObject14.SetActive(active14 != 0L);
			int value7 = this.int_1;
			PlayerPrefs.SetInt("Did Hit", value7);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("1BN", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49820;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("ChangePlayerSize", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17060;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 1L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("MetaAuth", value10);
	}

	// Token: 0x0600270F RID: 9999 RVA: 0x00049F8C File Offset: 0x0004818C
	[Address(RVA = "0x25D7BDC", Offset = "0x25D7BDC", VA = "0x25D7BDC")]
	[Token(Token = "0x600270F")]
	public void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("/", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("HandR", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("FLSPTLT", value3);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("You struck apon an error. ", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("ErrorScreen", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Head", value6);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1073741824L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt(".Please press the button if you would like to play alone", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("retract broken", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49862;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("This is the 2500 Bananas button, and it was just clicked", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)57344;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 1L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("ENABLE", value10);
	}

	// Token: 0x06002710 RID: 10000 RVA: 0x0004A2AC File Offset: 0x000484AC
	[Token(Token = "0x6002710")]
	[Address(RVA = "0x25D8098", Offset = "0x25D8098", VA = "0x25D8098")]
	public void method_9(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("FLSPTLT", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("Player", value2);
		if (this.int_0 == 0)
		{
			GameObject gameObject5 = this.gameObject_0;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_1;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
			int value3 = this.int_1;
			PlayerPrefs.SetInt("PURCHASED", value3);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("username", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 0L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("containsStaff", value5);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("_Tint", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49858;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("tp 2", value7);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49152;
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_0;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("You are not the master of the server, you cannot start the game.", value8);
	}

	// Token: 0x06002711 RID: 10001 RVA: 0x0004A524 File Offset: 0x00048724
	[Token(Token = "0x6002711")]
	[Address(RVA = "0x25D853C", Offset = "0x25D853C", VA = "0x25D853C")]
	public void method_10(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("retract broken", value);
			if (this.int_0 == 0)
			{
				GameObject gameObject3 = this.gameObject_0;
				long active3 = 0L;
				gameObject3.SetActive(active3 != 0L);
				GameObject gameObject4 = this.gameObject_1;
				long active4 = 1L;
				gameObject4.SetActive(active4 != 0L);
				int value2 = this.int_1;
				PlayerPrefs.SetInt("Name Changing Error. Error: ", value2);
			}
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Cheating", value3);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("sound play play", value4);
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("Muted", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int num = this.int_1;
		PlayerPrefs.SetInt("PURCHASED", num);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		this.gameObject_0.SetActive(num != 0);
		GameObject gameObject13 = this.gameObject_1;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject14 = this.gameObject_0;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("META", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16800;
		GameObject gameObject16 = this.gameObject_0;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("Name Changing Error. Error: ", value7);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49152;
		GameObject gameObject18 = this.gameObject_0;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("liftoff failed!", value8);
	}

	// Token: 0x06002712 RID: 10002 RVA: 0x0004A7F4 File Offset: 0x000489F4
	[Address(RVA = "0x25D89DC", Offset = "0x25D89DC", VA = "0x25D89DC")]
	[Token(Token = "0x6002712")]
	public void method_11(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			gameObject.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("Reason: ", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject2 = this.gameObject_0;
		long active3 = 1L;
		gameObject2.SetActive(active3 != 0L);
		long active4 = 0L;
		gameObject2.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("betaAgree", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject3 = this.gameObject_0;
		long active5 = 0L;
		gameObject3.SetActive(active5 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long num = 0L;
		gameObject4.SetActive(num != 0L);
		PlayerPrefs.SetInt("ChangeToRegular", (int)num);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject5 = this.gameObject_0;
		long active6 = 0L;
		gameObject5.SetActive(active6 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active7 = 1L;
		gameObject6.SetActive(active7 != 0L);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject7 = this.gameObject_0;
		long active8 = 1L;
		gameObject7.SetActive(active8 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active9 = 0L;
		gameObject8.SetActive(active9 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("\n", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject9 = this.gameObject_0;
		long active10 = 1L;
		gameObject9.SetActive(active10 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active11 = 0L;
		gameObject10.SetActive(active11 != 0L);
		int num2 = this.int_1;
		PlayerPrefs.SetInt("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.", num2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		this.gameObject_0.SetActive(num2 != 0);
		GameObject gameObject11 = this.gameObject_1;
		long active12 = 1L;
		gameObject11.SetActive(active12 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("EnableCosmetic", value4);
		if (this.int_0 == 0)
		{
			GameObject gameObject12 = this.gameObject_0;
			long active13 = 1L;
			gameObject12.SetActive(active13 != 0L);
			GameObject gameObject13 = this.gameObject_1;
			long active14 = 1L;
			gameObject13.SetActive(active14 != 0L);
			int value5 = this.int_1;
			PlayerPrefs.SetInt("Date: ", value5);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49680;
		GameObject gameObject14 = this.gameObject_0;
		long active15 = 0L;
		gameObject14.SetActive(active15 != 0L);
		GameObject gameObject15 = this.gameObject_1;
		long active16 = 0L;
		gameObject15.SetActive(active16 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("QuickStatic", value6);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17321;
		GameObject gameObject16 = this.gameObject_1;
		long active17 = 1L;
		gameObject16.SetActive(active17 != 0L);
		GameObject gameObject17 = this.gameObject_0;
		long active18 = 1L;
		gameObject17.SetActive(active18 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("Tagged", value7);
	}

	// Token: 0x06002713 RID: 10003 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002713")]
	[Address(RVA = "0x25D8E8C", Offset = "0x25D8E8C", VA = "0x25D8E8C")]
	public void method_12(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002714 RID: 10004 RVA: 0x0004AAD0 File Offset: 0x00048CD0
	[Token(Token = "0x6002714")]
	[Address(RVA = "0x25D9350", Offset = "0x25D9350", VA = "0x25D9350")]
	public void method_13(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("DISABLE", value);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("isLava", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Meta Platform entitlement error: ", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("spooky guy true", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 0L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("Agreed", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("closeToObject", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("PlayWave", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49640;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("TurnAmount", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49152;
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_0;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("NetworkPlayer", value9);
	}

	// Token: 0x06002715 RID: 10005 RVA: 0x0004ADA4 File Offset: 0x00048FA4
	[Token(Token = "0x6002715")]
	[Address(RVA = "0x25D980C", Offset = "0x25D980C", VA = "0x25D980C")]
	public void method_14(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("TurnAmount", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("Body", value2);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("TurnAmount", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 0L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("Key", value5);
		if (this.int_0 == 0)
		{
			GameObject gameObject11 = this.gameObject_0;
			long active11 = 0L;
			gameObject11.SetActive(active11 != 0L);
			GameObject gameObject12 = this.gameObject_1;
			long active12 = 0L;
			gameObject12.SetActive(active12 != 0L);
			int value6 = this.int_1;
			PlayerPrefs.SetInt("username", value6);
		}
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("oculus", value7);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1065353216L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("TurnAmount", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49842;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("duration done", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17004;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 0L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("Player", value10);
	}

	// Token: 0x06002716 RID: 10006 RVA: 0x0004B0C4 File Offset: 0x000492C4
	[Token(Token = "0x6002716")]
	[Address(RVA = "0x25D9CA4", Offset = "0x25D9CA4", VA = "0x25D9CA4")]
	public void method_15(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("Time to bake textures: ", value);
		}
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("SetColor", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Failed to get catalog, cosmetic name, and price. Exact error details is: ", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("MetaAuth", value4);
		if (this.int_0 == 0)
		{
			GameObject gameObject9 = this.gameObject_0;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			GameObject gameObject10 = this.gameObject_1;
			long active10 = 0L;
			gameObject10.SetActive(active10 != 0L);
			int value5 = this.int_1;
			PlayerPrefs.SetInt("waited for your bullshit unity grrr", value5);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("M/d/yyyy", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("goUpRPC", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("Player", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49736;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)8192;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 1L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("retract broken", value10);
	}

	// Token: 0x06002717 RID: 10007 RVA: 0x0004B3D4 File Offset: 0x000495D4
	[Token(Token = "0x6002717")]
	[Address(RVA = "0x25DA158", Offset = "0x25DA158", VA = "0x25DA158")]
	public void method_16(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("CapuchinRemade", value);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("true", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("openvr", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int num = this.int_1;
		PlayerPrefs.SetInt("EnableCosmetic", num);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		this.gameObject_0.SetActive(num != 0);
		GameObject gameObject9 = this.gameObject_1;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("ChangePlayerSize", value4);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject10 = this.gameObject_0;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		GameObject gameObject11 = this.gameObject_1;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("Player", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject12 = this.gameObject_0;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		GameObject gameObject13 = this.gameObject_1;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		int num2 = this.int_1;
		PlayerPrefs.SetInt("make more points bobo", num2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		this.gameObject_0.SetActive(num2 != 0);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Hate Speech", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17074;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("casual", value7);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17626;
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_0;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("username", value8);
	}

	// Token: 0x06002718 RID: 10008 RVA: 0x0004B6EC File Offset: 0x000498EC
	[Address(RVA = "0x25DA618", Offset = "0x25DA618", VA = "0x25DA618")]
	[Token(Token = "0x6002718")]
	public void method_17(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("containsStaff", value);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("typesOfTalk", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject5 = this.gameObject_1;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("NetworkPlayer", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject6 = this.gameObject_0;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		GameObject gameObject7 = this.gameObject_1;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("You are not the master of the server, you cannot start the game.", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject8 = this.gameObject_0;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		GameObject gameObject9 = this.gameObject_1;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("EnableCosmetic", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject10 = this.gameObject_0;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		GameObject gameObject11 = this.gameObject_1;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Error", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject12 = this.gameObject_0;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		GameObject gameObject13 = this.gameObject_1;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("HDRP/Lit", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject14 = this.gameObject_0;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("Time to bake textures: ", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49832;
		GameObject gameObject16 = this.gameObject_0;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Camera movement detected, calibrating height.", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17501;
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		GameObject gameObject19 = this.gameObject_0;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("Queue", value10);
	}

	// Token: 0x06002719 RID: 10009 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x25DAAD8", Offset = "0x25DAAD8", VA = "0x25DAAD8")]
	[Token(Token = "0x6002719")]
	public void method_18(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600271A RID: 10010 RVA: 0x0004B9F8 File Offset: 0x00049BF8
	[Address(RVA = "0x25DAF80", Offset = "0x25DAF80", VA = "0x25DAF80")]
	[Token(Token = "0x600271A")]
	public void method_19(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("A Player has left the Room.", value);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("User has been reported for: ", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("username", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("_Tint", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("ChangeToTagged", value5);
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long num = 1L;
		gameObject12.SetActive(num != 0L);
		PlayerPrefs.SetInt("procedural animation script required on ", (int)num);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1073741824L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		GameObject gameObject13 = this.gameObject_0;
		long active12 = 1L;
		gameObject13.SetActive(active12 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active13 = 0L;
		gameObject14.SetActive(active13 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("\n Time: ", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject15 = this.gameObject_0;
		long active14 = 0L;
		gameObject15.SetActive(active14 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active15 = 0L;
		gameObject16.SetActive(active15 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("hh:mmtt", value7);
		GameObject gameObject17 = this.gameObject_0;
		long active16 = 0L;
		gameObject17.SetActive(active16 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active17 = 0L;
		gameObject18.SetActive(active17 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("Cheating", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)32768;
		GameObject gameObject19 = this.gameObject_1;
		long active18 = 1L;
		gameObject19.SetActive(active18 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active19 = 1L;
		gameObject20.SetActive(active19 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Purchase For ", value9);
	}

	// Token: 0x0600271B RID: 10011 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x25DB444", Offset = "0x25DB444", VA = "0x25DB444")]
	[Token(Token = "0x600271B")]
	public void method_20(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600271C RID: 10012 RVA: 0x0004BD00 File Offset: 0x00049F00
	[Address(RVA = "0x25DB8F4", Offset = "0x25DB8F4", VA = "0x25DB8F4")]
	[Token(Token = "0x600271C")]
	public void method_21(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("spatial", value);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("Version", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("/", value3);
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("M/d/yyyy", value4);
		if (this.int_0 == 0)
		{
			GameObject gameObject11 = this.gameObject_0;
			long active11 = 1L;
			gameObject11.SetActive(active11 != 0L);
			GameObject gameObject12 = this.gameObject_1;
			long active12 = 0L;
			gameObject12.SetActive(active12 != 0L);
			int value5 = this.int_1;
			PlayerPrefs.SetInt("Player", value5);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("/", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("FingerTip", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49916;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("ScoreCounter", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)57344;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 0L;
		gameObject20.SetActive(active20 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("spatial", value9);
	}

	// Token: 0x0600271D RID: 10013 RVA: 0x0004BFE4 File Offset: 0x0004A1E4
	[Address(RVA = "0x25DBD84", Offset = "0x25DBD84", VA = "0x25DBD84")]
	[Token(Token = "0x600271D")]
	public void method_22(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("retract broken", value);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("HandR", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("DisableCosmetic", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		this.gameObject_1.SetActive(active9 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("PRESS AGAIN TO CONFIRM", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject10 = this.gameObject_0;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		GameObject gameObject11 = this.gameObject_1;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt(" and the correct version is ", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject12 = this.gameObject_0;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		GameObject gameObject13 = this.gameObject_1;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Regular", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("Horizontal", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49870;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("Player", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)40960;
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_0;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Hats", value9);
	}

	// Token: 0x0600271E RID: 10014 RVA: 0x0004C2DC File Offset: 0x0004A4DC
	[Address(RVA = "0x25DC248", Offset = "0x25DC248", VA = "0x25DC248")]
	[Token(Token = "0x600271E")]
	public void method_23(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("FingerTip", value);
		}
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("FingerTip", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("ErrorScreen", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("Tagged", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 0L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("true", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("Camera movement detected, calibrating height.", value7);
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("Vector1_d371bd24217449349bd747533d51af6b", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16880;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Cannot access index {0}. Buffer is empty", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17197;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 0L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("make more points bobo", value10);
	}

	// Token: 0x0600271F RID: 10015 RVA: 0x0004C5E0 File Offset: 0x0004A7E0
	[Address(RVA = "0x25DC6F4", Offset = "0x25DC6F4", VA = "0x25DC6F4")]
	[Token(Token = "0x600271F")]
	public void method_24(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("Meta Platform entitlement error: ", value);
		if (this.int_0 == 0)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
			GameObject gameObject4 = this.gameObject_1;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
		}
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("Combine textures & build combined mesh all at once", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("NetworkPlayer", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 0L;
		gameObject10.SetActive(active10 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("closeToObject", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("PURCHASED", value5);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int num = this.int_1;
		PlayerPrefs.SetInt("lava", num);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1065353216L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		this.gameObject_0.SetActive(num != 0);
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("/", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49912;
		GameObject gameObject16 = this.gameObject_0;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("NetworkPlayer", value7);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)57344;
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		this.gameObject_0.SetActive(active18 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("Open", value8);
	}

	// Token: 0x06002720 RID: 10016 RVA: 0x0004C8D4 File Offset: 0x0004AAD4
	[Token(Token = "0x6002720")]
	[Address(RVA = "0x25DCBA4", Offset = "0x25DCBA4", VA = "0x25DCBA4")]
	public void method_25(Collider collider_0)
	{
		HandColliders exists;
		exists;
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("PRESS AGAIN TO CONFIRM", value);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1073741824L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("Player", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Target", value3);
		if (this.int_0 == 0)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			int value4 = this.int_1;
			PlayerPrefs.SetInt("Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}", value4);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("True", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("EnableCosmetic", value6);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1065353216L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int num = this.int_1;
		PlayerPrefs.SetInt("Cannot access index {0}. Buffer is empty", num);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		this.gameObject_0.SetActive(num != 0);
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("Not connected to room", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17034;
		GameObject gameObject16 = this.gameObject_0;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("User has been reported for: ", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17578;
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		GameObject gameObject19 = this.gameObject_0;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Add/Remove Hat", value9);
	}

	// Token: 0x06002721 RID: 10017 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x25DD05C", Offset = "0x25DD05C", VA = "0x25DD05C")]
	[Token(Token = "0x6002721")]
	public void OnTriggerEnter(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002722 RID: 10018 RVA: 0x0004CBF0 File Offset: 0x0004ADF0
	[Token(Token = "0x6002722")]
	[Address(RVA = "0x25DD4AC", Offset = "0x25DD4AC", VA = "0x25DD4AC")]
	public void method_26(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("true", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("Tagged", value2);
		if (this.int_0 == 0)
		{
			GameObject gameObject5 = this.gameObject_0;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_1;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			int value3 = this.int_1;
			PlayerPrefs.SetInt("Player", value3);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("typesOfTalk", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("FingerTip", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Version", value6);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("PlayerHead", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("ChangeToTagged", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Thumb", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49152;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long num = 1L;
		gameObject20.SetActive(num != 0L);
		PlayerPrefs.SetInt("User has been reported for: ", (int)num);
	}

	// Token: 0x06002723 RID: 10019 RVA: 0x0004CEF8 File Offset: 0x0004B0F8
	[Token(Token = "0x6002723")]
	[Address(RVA = "0x25DD960", Offset = "0x25DD960", VA = "0x25DD960")]
	public void method_27(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n", value);
			if (this.int_0 == 0)
			{
				GameObject gameObject3 = this.gameObject_0;
				long active3 = 0L;
				gameObject3.SetActive(active3 != 0L);
				GameObject gameObject4 = this.gameObject_1;
				long active4 = 1L;
				gameObject4.SetActive(active4 != 0L);
				int value2 = this.int_1;
				PlayerPrefs.SetInt("Cannot access index {0}. Buffer is empty", value2);
			}
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("HandR", value3);
		if (this.int_0 == 0)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			int value4 = this.int_1;
			PlayerPrefs.SetInt("TurnAmount", value4);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 0L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("Vector1_d371bd24217449349bd747533d51af6b", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("SetColor", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("\n", value7);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		long active16 = 1L;
		gameObject15.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("/", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16848;
		GameObject gameObject16 = this.gameObject_0;
		long active17 = 1L;
		gameObject16.SetActive(active17 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active18 = 0L;
		gameObject17.SetActive(active18 != 0L);
		int num = this.int_1;
		PlayerPrefs.SetInt("Reason: ", num);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17393;
		this.gameObject_1.SetActive(num != 0);
		GameObject gameObject18 = this.gameObject_0;
		long active19 = 1L;
		gameObject18.SetActive(active19 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Add/Remove Sword", value9);
	}

	// Token: 0x06002724 RID: 10020 RVA: 0x0004D1F0 File Offset: 0x0004B3F0
	[Token(Token = "0x6002724")]
	[Address(RVA = "0x25DDE08", Offset = "0x25DDE08", VA = "0x25DDE08")]
	public void method_28(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("_WobbleZ", value);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("Universal Render Pipeline/Lit", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Not connected to room", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("username", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("PlayWave", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Player", value6);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1065353216L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("You are on an outdated version of Capuchin. Your version is ", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("PLAYER IS BANNED", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49700;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("PURCHASE", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16384;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 0L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("TurnAmount", value10);
	}

	// Token: 0x06002725 RID: 10021 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x25DE2CC", Offset = "0x25DE2CC", VA = "0x25DE2CC")]
	[Token(Token = "0x6002725")]
	public void method_29(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002726 RID: 10022 RVA: 0x0004D520 File Offset: 0x0004B720
	[Token(Token = "0x6002726")]
	[Address(RVA = "0x25DE774", Offset = "0x25DE774", VA = "0x25DE774")]
	public void method_30(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("Creating and loadingtexture", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("True", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long num = 1L;
		gameObject6.SetActive(num != 0L);
		PlayerPrefs.SetInt("FingerTip", (int)num);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject7 = this.gameObject_0;
		long active6 = 0L;
		gameObject7.SetActive(active6 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active7 = 0L;
		gameObject8.SetActive(active7 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Try Connect To Server...", value3);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject9 = this.gameObject_0;
		long active8 = 1L;
		gameObject9.SetActive(active8 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active9 = 0L;
		gameObject10.SetActive(active9 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("Version", value4);
		if (this.int_0 == 0)
		{
			GameObject gameObject11 = this.gameObject_0;
			long active10 = 1L;
			gameObject11.SetActive(active10 != 0L);
			GameObject gameObject12 = this.gameObject_1;
			long active11 = 0L;
			gameObject12.SetActive(active11 != 0L);
			int value5 = this.int_1;
			PlayerPrefs.SetInt("StartGamemode", value5);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject13 = this.gameObject_0;
		long active12 = 0L;
		gameObject13.SetActive(active12 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active13 = 1L;
		gameObject14.SetActive(active13 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Charged!", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject15 = this.gameObject_0;
		long active14 = 1L;
		gameObject15.SetActive(active14 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active15 = 1L;
		gameObject16.SetActive(active15 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("Tagged", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16984;
		GameObject gameObject17 = this.gameObject_0;
		long active16 = 1L;
		gameObject17.SetActive(active16 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active17 = 1L;
		gameObject18.SetActive(active17 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("Found Gameobject: ", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)57344;
		GameObject gameObject19 = this.gameObject_1;
		long active18 = 1L;
		gameObject19.SetActive(active18 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active19 = 1L;
		gameObject20.SetActive(active19 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("HDRP/Lit", value9);
	}

	// Token: 0x06002727 RID: 10023 RVA: 0x0004D828 File Offset: 0x0004BA28
	[Address(RVA = "0x25DEC28", Offset = "0x25DEC28", VA = "0x25DEC28")]
	[Token(Token = "0x6002727")]
	public void method_31(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("Regular", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("false", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("DisableCosmetic", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("typesOfTalk", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("Failed To Join Public Room Successfully. The error is: ", value5);
		if (this.int_0 == 0)
		{
			GameObject gameObject11 = this.gameObject_0;
			long active11 = 0L;
			gameObject11.SetActive(active11 != 0L);
			GameObject gameObject12 = this.gameObject_1;
			long active12 = 0L;
			gameObject12.SetActive(active12 != 0L);
			int value6 = this.int_1;
			PlayerPrefs.SetInt("You are on an outdated version of Capuchin. Your version is ", value6);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("Cheating", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("We don't need this electrical box", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17064;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Player", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17219;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 0L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("Queue", value10);
	}

	// Token: 0x06002728 RID: 10024 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6002728")]
	[Address(RVA = "0x25DF0D8", Offset = "0x25DF0D8", VA = "0x25DF0D8")]
	public void method_32(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002729 RID: 10025 RVA: 0x0004DB30 File Offset: 0x0004BD30
	[Token(Token = "0x6002729")]
	[Address(RVA = "0x25DF594", Offset = "0x25DF594", VA = "0x25DF594")]
	public void method_33(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("retract broken", value);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("/", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("forced knee", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject7 = this.gameObject_1;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("SaveHeight", value4);
		if (this.int_0 == 0)
		{
			GameObject gameObject8 = this.gameObject_0;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_1;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			int value5 = this.int_1;
			PlayerPrefs.SetInt("TurnAmount", value5);
		}
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1073741824L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject10 = this.gameObject_0;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		GameObject gameObject11 = this.gameObject_1;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("FingerTip", value6);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1065353216L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		GameObject gameObject12 = this.gameObject_0;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		GameObject gameObject13 = this.gameObject_1;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("hand 1", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject14 = this.gameObject_0;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("Body", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17122;
		GameObject gameObject16 = this.gameObject_0;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Failed to login, please restart", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16384;
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		GameObject gameObject19 = this.gameObject_0;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("Thumb", value10);
	}

	// Token: 0x0600272A RID: 10026 RVA: 0x0004DE34 File Offset: 0x0004C034
	[Token(Token = "0x600272A")]
	[Address(RVA = "0x25DFA50", Offset = "0x25DFA50", VA = "0x25DFA50")]
	public void method_34(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("ChangeToTagged", value);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("You have been banned for ", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("PURCHASE", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("Player", value4);
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("Player", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("typesOfTalk", value6);
		if (this.int_0 == 0)
		{
			GameObject gameObject13 = this.gameObject_0;
			long active13 = 1L;
			gameObject13.SetActive(active13 != 0L);
			GameObject gameObject14 = this.gameObject_1;
			long active14 = 1L;
			gameObject14.SetActive(active14 != 0L);
			int value7 = this.int_1;
			PlayerPrefs.SetInt("User is on an outdated version of Capuchin. Your version is ", value7);
			if (this.int_0 == 0)
			{
				GameObject gameObject15 = this.gameObject_1;
				long active15 = 0L;
				gameObject15.SetActive(active15 != 0L);
				int value8 = this.int_1;
				PlayerPrefs.SetInt("Player", value8);
			}
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49868;
		GameObject gameObject16 = this.gameObject_0;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("liftoff failed!", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16384;
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		GameObject gameObject19 = this.gameObject_0;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
	}

	// Token: 0x0600272B RID: 10027 RVA: 0x0004E10C File Offset: 0x0004C30C
	[Address(RVA = "0x25DFEEC", Offset = "0x25DFEEC", VA = "0x25DFEEC")]
	[Token(Token = "0x600272B")]
	public void method_35(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("ENABLE", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("QuickStatic", value2);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("hand 2", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("Room Name: ", value4);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("Cannot access index {0}. Buffer is empty", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("lava", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("PlayWave", value7);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1065353216L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("closeToObject", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17068;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Regular", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17122;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 0L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("Stopped Colliding", value10);
	}

	// Token: 0x0600272C RID: 10028 RVA: 0x0004E434 File Offset: 0x0004C634
	[Address(RVA = "0x25E03A4", Offset = "0x25E03A4", VA = "0x25E03A4")]
	[Token(Token = "0x600272C")]
	public void method_36(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("SaveHeight", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("true", value3);
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("FingerTip", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("_Tint", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("liftoff failed!", value6);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("ENABLE", value7);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("CapuchinStore", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17028;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("SaveHeight", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)8192;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 1L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("Head", value10);
	}

	// Token: 0x0600272D RID: 10029 RVA: 0x0004E744 File Offset: 0x0004C944
	[Address(RVA = "0x25E0854", Offset = "0x25E0854", VA = "0x25E0854")]
	[Token(Token = "0x600272D")]
	public void method_37(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("FLSPTLT", value);
			if (this.int_0 == 0)
			{
				GameObject gameObject3 = this.gameObject_0;
				long active3 = 1L;
				gameObject3.SetActive(active3 != 0L);
				GameObject gameObject4 = this.gameObject_1;
				long active4 = 0L;
				gameObject4.SetActive(active4 != 0L);
				int value2 = this.int_1;
				PlayerPrefs.SetInt("FingerTip", value2);
			}
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		long active6 = 1L;
		gameObject5.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("_BaseMap", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject6 = this.gameObject_0;
		long active7 = 1L;
		gameObject6.SetActive(active7 != 0L);
		GameObject gameObject7 = this.gameObject_1;
		long active8 = 0L;
		gameObject7.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("hh:mmtt", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16576;
		GameObject gameObject8 = this.gameObject_0;
		long active9 = 1L;
		gameObject8.SetActive(active9 != 0L);
		GameObject gameObject9 = this.gameObject_1;
		long active10 = 0L;
		gameObject9.SetActive(active10 != 0L);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject10 = this.gameObject_0;
		long active11 = 1L;
		gameObject10.SetActive(active11 != 0L);
		long active12 = 1L;
		gameObject10.SetActive(active12 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("FingerTip", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject11 = this.gameObject_0;
		long active13 = 0L;
		gameObject11.SetActive(active13 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active14 = 1L;
		gameObject12.SetActive(active14 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("TurnAmount", value6);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject13 = this.gameObject_0;
		long active15 = 0L;
		gameObject13.SetActive(active15 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active16 = 0L;
		gameObject14.SetActive(active16 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("PRESS AGAIN TO CONFIRM", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17098;
		GameObject gameObject15 = this.gameObject_0;
		long active17 = 0L;
		gameObject15.SetActive(active17 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active18 = 0L;
		gameObject16.SetActive(active18 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt(" ", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)32768;
		GameObject gameObject17 = this.gameObject_1;
		long active19 = 1L;
		gameObject17.SetActive(active19 != 0L);
		GameObject gameObject18 = this.gameObject_0;
		long active20 = 0L;
		gameObject18.SetActive(active20 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("button", value9);
	}

	// Token: 0x0600272E RID: 10030 RVA: 0x0004EA30 File Offset: 0x0004CC30
	[Address(RVA = "0x25E0CFC", Offset = "0x25E0CFC", VA = "0x25E0CFC")]
	[Token(Token = "0x600272E")]
	public void method_38(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt(" ", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("Horizontal", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("liftoff failed!", value3);
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("lava", value4);
		int num;
		if (this.int_0 == 0)
		{
			GameObject gameObject9 = this.gameObject_0;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			GameObject gameObject10 = this.gameObject_1;
			long active10 = 0L;
			gameObject10.SetActive(active10 != 0L);
			int value5 = this.int_1;
			PlayerPrefs.SetInt("CASUAL", value5);
			if (this.int_0 == 0)
			{
				GameObject gameObject11 = this.gameObject_0;
				long active11 = 0L;
				gameObject11.SetActive(active11 != 0L);
				GameObject gameObject12 = this.gameObject_1;
				long active12 = 0L;
				gameObject12.SetActive(active12 != 0L);
				num = this.int_1;
				PlayerPrefs.SetInt("DISABLE", num);
			}
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		this.gameObject_0.SetActive(num != 0);
		GameObject gameObject13 = this.gameObject_1;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("QuickStatic", value6);
		if (this.int_0 == 0)
		{
			GameObject gameObject14 = this.gameObject_0;
			long active14 = 0L;
			gameObject14.SetActive(active14 != 0L);
			GameObject gameObject15 = this.gameObject_1;
			long active15 = 0L;
			gameObject15.SetActive(active15 != 0L);
			int value7 = this.int_1;
			PlayerPrefs.SetInt("Not connected to room", value7);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17040;
		GameObject gameObject16 = this.gameObject_0;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("isLava", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)8192;
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		this.gameObject_0.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Charging...", value9);
	}

	// Token: 0x0600272F RID: 10031 RVA: 0x0004ED0C File Offset: 0x0004CF0C
	[Address(RVA = "0x25E11A0", Offset = "0x25E11A0", VA = "0x25E11A0")]
	[Token(Token = "0x600272F")]
	public void method_39(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("Bruh i cannot go here you stupid L bozo", value);
		}
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("sound play play", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Player", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		this.gameObject_1.SetActive(active7 != 0L);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject8 = this.gameObject_0;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		GameObject gameObject9 = this.gameObject_1;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("run", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject10 = this.gameObject_0;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		GameObject gameObject11 = this.gameObject_1;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("BloodKill", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject12 = this.gameObject_0;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		GameObject gameObject13 = this.gameObject_1;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("On", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject14 = this.gameObject_0;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("ORGTARG", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16880;
		GameObject gameObject16 = this.gameObject_0;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("n0", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17534;
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		GameObject gameObject19 = this.gameObject_0;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Connected to Server.", value9);
	}

	// Token: 0x06002730 RID: 10032 RVA: 0x0004F008 File Offset: 0x0004D208
	[Address(RVA = "0x25E1658", Offset = "0x25E1658", VA = "0x25E1658")]
	[Token(Token = "0x6002730")]
	public void method_40(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("EnableCosmetic", value);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("Charging...", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("XR Usage", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("Damaged Arm", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("monkeScream", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("ORGTARG", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("Reason: ", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17016;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 0L;
		gameObject18.SetActive(active18 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("HeadAttachPoint", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17455;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 0L;
		gameObject20.SetActive(active20 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("forced knee retract", value9);
	}

	// Token: 0x06002731 RID: 10033 RVA: 0x0004F314 File Offset: 0x0004D514
	[Address(RVA = "0x25E1B18", Offset = "0x25E1B18", VA = "0x25E1B18")]
	[Token(Token = "0x6002731")]
	public void method_41(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("Player", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("SaveHeight", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("TurnAmount", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("TurnAmount", value4);
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("CASUAL", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Charged!", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("PURCHASED", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("typesOfTalk", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)32768;
		GameObject gameObject17 = this.gameObject_1;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_0;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Game Started", value9);
	}

	// Token: 0x06002732 RID: 10034 RVA: 0x0004F5E0 File Offset: 0x0004D7E0
	[Address(RVA = "0x25E1FCC", Offset = "0x25E1FCC", VA = "0x25E1FCC")]
	[Token(Token = "0x6002732")]
	public void method_42(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		long value = 1L;
		PlayerPrefs.SetInt("Pause", (int)value);
		long value2 = 0L;
		PlayerPrefs.SetInt("Failed to login, please restart", (int)value2);
		long value3 = 0L;
		PlayerPrefs.SetInt("FingerTip", (int)value3);
		long value4 = 1L;
		PlayerPrefs.SetInt("\n Time: ", (int)value4);
		long value5 = 0L;
		PlayerPrefs.SetInt("Connected to Server.", (int)value5);
		long value6 = 1L;
		PlayerPrefs.SetInt("Cannot access index {0}. Buffer is empty", (int)value6);
		long value7 = 0L;
		PlayerPrefs.SetInt("NetworkPlayer", (int)value7);
	}

	// Token: 0x06002733 RID: 10035 RVA: 0x0004F660 File Offset: 0x0004D860
	[Address(RVA = "0x25E2480", Offset = "0x25E2480", VA = "0x25E2480")]
	[Token(Token = "0x6002733")]
	public void method_43(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("Joined Public Room Successfully", value);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("M/d/yyyy", value2);
		if (this.int_0 == 0)
		{
			GameObject gameObject5 = this.gameObject_0;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_1;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			int value3 = this.int_1;
			PlayerPrefs.SetInt("back", value3);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("containsStaff", value4);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("hand 1", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("KeyPos", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("retract broken", value7);
		ContinuousTurnProviderBase continuousTurnProviderBase3 = this.continuousTurnProviderBase_0;
		long turnSpeed3 = 1073741824L;
		continuousTurnProviderBase3.m_TurnSpeed = (float)turnSpeed3;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt(" ", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49776;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("This is the 1000 Bananas button, and it was just clicked", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)8192;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 0L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("StartSong", value10);
	}

	// Token: 0x06002734 RID: 10036 RVA: 0x0004F978 File Offset: 0x0004DB78
	[Address(RVA = "0x25E293C", Offset = "0x25E293C", VA = "0x25E293C")]
	[Token(Token = "0x6002734")]
	public void method_44(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("username", value);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("PlayWave", value2);
		if (this.int_0 == 0)
		{
			GameObject gameObject5 = this.gameObject_0;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_1;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
			int value3 = this.int_1;
			PlayerPrefs.SetInt("containsStaff", value3);
		}
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1073741824L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("_WobbleZ", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 0L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("DisableCosmetic", value5);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 0L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("sound play play", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 0L;
		gameObject16.SetActive(active16 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("betaAgree", value7);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49908;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		long active18 = 1L;
		gameObject17.SetActive(active18 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("XR Usage", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)40960;
		GameObject gameObject18 = this.gameObject_1;
		long active19 = 0L;
		gameObject18.SetActive(active19 != 0L);
		GameObject gameObject19 = this.gameObject_0;
		long active20 = 0L;
		gameObject19.SetActive(active20 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("TurnAmount", value9);
	}

	// Token: 0x06002735 RID: 10037 RVA: 0x0004FC74 File Offset: 0x0004DE74
	[Address(RVA = "0x25E2DF0", Offset = "0x25E2DF0", VA = "0x25E2DF0")]
	[Token(Token = "0x6002735")]
	public void method_45(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("false", value);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("BLUPORT", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject4 = this.gameObject_0;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		GameObject gameObject5 = this.gameObject_1;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("sound play stopped", value3);
		GameObject gameObject6 = this.gameObject_0;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		GameObject gameObject7 = this.gameObject_1;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		int num = this.int_1;
		PlayerPrefs.SetInt("Joined a Room.", num);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		this.gameObject_0.SetActive(num != 0);
		GameObject gameObject8 = this.gameObject_1;
		long num2 = 0L;
		gameObject8.SetActive(num2 != 0L);
		PlayerPrefs.SetInt("FingerTip", (int)num2);
		if (this.int_0 == 0)
		{
			GameObject gameObject9 = this.gameObject_0;
			long active8 = 1L;
			gameObject9.SetActive(active8 != 0L);
			GameObject gameObject10 = this.gameObject_1;
			long active9 = 0L;
			gameObject10.SetActive(active9 != 0L);
			int value4 = this.int_1;
			PlayerPrefs.SetInt("RainAndThunderWeather", value4);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject11 = this.gameObject_0;
		long active10 = 0L;
		gameObject11.SetActive(active10 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active11 = 0L;
		gameObject12.SetActive(active11 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("PlayerHead", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17036;
		GameObject gameObject13 = this.gameObject_0;
		long active12 = 0L;
		gameObject13.SetActive(active12 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active13 = 1L;
		gameObject14.SetActive(active13 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("Creating and loadingtexture", value6);
	}

	// Token: 0x06002736 RID: 10038 RVA: 0x0004FEB4 File Offset: 0x0004E0B4
	[Address(RVA = "0x25E32A0", Offset = "0x25E32A0", VA = "0x25E32A0")]
	[Token(Token = "0x6002736")]
	public void method_46(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.int_0 == 0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			this.gameObject_1.SetActive(active != 0L);
			int value = this.int_1;
			PlayerPrefs.SetInt("FingerTip", value);
		}
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		int value2 = this.int_1;
		PlayerPrefs.SetInt("FingerTip", value2);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16544;
		GameObject gameObject4 = this.gameObject_0;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		GameObject gameObject5 = this.gameObject_1;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("Not enough amount of currency", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject6 = this.gameObject_0;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		GameObject gameObject7 = this.gameObject_1;
		long active7 = 0L;
		gameObject7.SetActive(active7 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("_WobbleZ", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16640;
		GameObject gameObject8 = this.gameObject_0;
		long active8 = 1L;
		gameObject8.SetActive(active8 != 0L);
		GameObject gameObject9 = this.gameObject_1;
		long active9 = 0L;
		gameObject9.SetActive(active9 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("You have been banned for ", value5);
		if (this.int_0 == 0)
		{
			GameObject gameObject10 = this.gameObject_0;
			long active10 = 0L;
			gameObject10.SetActive(active10 != 0L);
			GameObject gameObject11 = this.gameObject_1;
			long active11 = 1L;
			gameObject11.SetActive(active11 != 0L);
			int value6 = this.int_1;
			PlayerPrefs.SetInt("Added Winner Money", value6);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject12 = this.gameObject_0;
		long active12 = 1L;
		gameObject12.SetActive(active12 != 0L);
		GameObject gameObject13 = this.gameObject_1;
		long num = 1L;
		gameObject13.SetActive(num != 0L);
		PlayerPrefs.SetInt("back", (int)num);
		if (this.int_0 == 0)
		{
			GameObject gameObject14 = this.gameObject_0;
			long active13 = 0L;
			gameObject14.SetActive(active13 != 0L);
			GameObject gameObject15 = this.gameObject_1;
			long active14 = 0L;
			gameObject15.SetActive(active14 != 0L);
			int value7 = this.int_1;
			PlayerPrefs.SetInt("[InputHelpers.IsPressed] The value of <button> is out or the supported range.", value7);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)49830;
		GameObject gameObject16 = this.gameObject_0;
		long active15 = 1L;
		gameObject16.SetActive(active15 != 0L);
		GameObject gameObject17 = this.gameObject_1;
		long active16 = 0L;
		gameObject17.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("TurnAmount", value8);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17408;
		GameObject gameObject18 = this.gameObject_1;
		long active17 = 1L;
		gameObject18.SetActive(active17 != 0L);
		GameObject gameObject19 = this.gameObject_0;
		long active18 = 1L;
		gameObject19.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("gamemode", value9);
	}

	// Token: 0x06002737 RID: 10039 RVA: 0x000501AC File Offset: 0x0004E3AC
	[Address(RVA = "0x25E373C", Offset = "0x25E373C", VA = "0x25E373C")]
	[Token(Token = "0x6002737")]
	public void method_47(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		ContinuousTurnProviderBase continuousTurnProviderBase = this.continuousTurnProviderBase_0;
		long turnSpeed = 1065353216L;
		continuousTurnProviderBase.m_TurnSpeed = (float)turnSpeed;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		int value = this.int_1;
		PlayerPrefs.SetInt("PRESS AGAIN TO CONFIRM", value);
		if (this.int_0 == 0)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
			GameObject gameObject4 = this.gameObject_1;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			int value2 = this.int_1;
			PlayerPrefs.SetInt("Player", value2);
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
		int value3 = this.int_1;
		PlayerPrefs.SetInt("An error has occured while buying bananas, please restart your game and try again", value3);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject7 = this.gameObject_0;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_1;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		int value4 = this.int_1;
		PlayerPrefs.SetInt("_Tint", value4);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16512;
		GameObject gameObject9 = this.gameObject_0;
		long active9 = 1L;
		gameObject9.SetActive(active9 != 0L);
		GameObject gameObject10 = this.gameObject_1;
		long active10 = 0L;
		gameObject10.SetActive(active10 != 0L);
		int value5 = this.int_1;
		PlayerPrefs.SetInt("ChangeToTagged", value5);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16448;
		GameObject gameObject11 = this.gameObject_0;
		long active11 = 1L;
		gameObject11.SetActive(active11 != 0L);
		GameObject gameObject12 = this.gameObject_1;
		long active12 = 0L;
		gameObject12.SetActive(active12 != 0L);
		int value6 = this.int_1;
		PlayerPrefs.SetInt("{0}/{1:f0}", value6);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)16608;
		GameObject gameObject13 = this.gameObject_0;
		long active13 = 1L;
		gameObject13.SetActive(active13 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		int value7 = this.int_1;
		PlayerPrefs.SetInt("true", value7);
		ContinuousTurnProviderBase continuousTurnProviderBase2 = this.continuousTurnProviderBase_0;
		long turnSpeed2 = 1065353216L;
		continuousTurnProviderBase2.m_TurnSpeed = (float)turnSpeed2;
		GameObject gameObject15 = this.gameObject_0;
		long active15 = 1L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.gameObject_1;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		int value8 = this.int_1;
		PlayerPrefs.SetInt("_BaseColor", value8);
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)17094;
		GameObject gameObject17 = this.gameObject_0;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_1;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		int value9 = this.int_1;
		PlayerPrefs.SetInt("Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.", value9);
		if (this.int_0 != 0)
		{
			return;
		}
		this.continuousTurnProviderBase_0.m_TurnSpeed = (float)57344;
		GameObject gameObject19 = this.gameObject_1;
		long active19 = 0L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_0;
		long active20 = 1L;
		gameObject20.SetActive(active20 != 0L);
		int value10 = this.int_1;
		PlayerPrefs.SetInt("Muted", value10);
	}

	// Token: 0x040004F1 RID: 1265
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004F1")]
	public int int_0;

	// Token: 0x040004F2 RID: 1266
	[Token(Token = "0x40004F2")]
	[FieldOffset(Offset = "0x1C")]
	public int int_1;

	// Token: 0x040004F3 RID: 1267
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004F3")]
	public GameObject gameObject_0;

	// Token: 0x040004F4 RID: 1268
	[Token(Token = "0x40004F4")]
	[FieldOffset(Offset = "0x28")]
	public GameObject gameObject_1;

	// Token: 0x040004F5 RID: 1269
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40004F5")]
	public ContinuousTurnProviderBase continuousTurnProviderBase_0;
}
