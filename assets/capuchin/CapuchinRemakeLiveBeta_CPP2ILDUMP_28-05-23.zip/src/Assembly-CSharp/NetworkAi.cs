﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.AI;

// Token: 0x02000066 RID: 102
[Token(Token = "0x2000066")]
public class NetworkAi : MonoBehaviour
{
	// Token: 0x06000DEA RID: 3562 RVA: 0x0001E004 File Offset: 0x0001C204
	[Address(RVA = "0x2E78B88", Offset = "0x2E78B88", VA = "0x2E78B88")]
	[Token(Token = "0x6000DEA")]
	private void method_0()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DEB RID: 3563 RVA: 0x0001E044 File Offset: 0x0001C244
	[Token(Token = "0x6000DEB")]
	[Address(RVA = "0x2E78BE4", Offset = "0x2E78BE4", VA = "0x2E78BE4")]
	private void Update()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		NavMeshAgent navMeshAgent;
		if (photonView.<IsMine>k__BackingField)
		{
			long enabled = 1L;
			patrolAI.enabled = (enabled != 0L);
			navMeshAgent = this.navMeshAgent_0;
			return;
		}
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
		NavMeshAgent navMeshAgent2 = this.navMeshAgent_0;
		long enabled3 = 0L;
		navMeshAgent2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000DEC RID: 3564 RVA: 0x0001E098 File Offset: 0x0001C298
	[Token(Token = "0x6000DEC")]
	[Address(RVA = "0x2E78C54", Offset = "0x2E78C54", VA = "0x2E78C54")]
	private void method_1()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 1L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DED RID: 3565 RVA: 0x0001E0C8 File Offset: 0x0001C2C8
	[Token(Token = "0x6000DED")]
	[Address(RVA = "0x2E78CA0", Offset = "0x2E78CA0", VA = "0x2E78CA0")]
	private void method_2()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DEE RID: 3566 RVA: 0x0001E0F8 File Offset: 0x0001C2F8
	[Address(RVA = "0x2E78CEC", Offset = "0x2E78CEC", VA = "0x2E78CEC")]
	[Token(Token = "0x6000DEE")]
	private void method_3()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		long enabled = 1L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DEF RID: 3567 RVA: 0x0001E098 File Offset: 0x0001C298
	[Address(RVA = "0x2E78D48", Offset = "0x2E78D48", VA = "0x2E78D48")]
	[Token(Token = "0x6000DEF")]
	private void method_4()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 1L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DF0 RID: 3568 RVA: 0x0001E044 File Offset: 0x0001C244
	[Address(RVA = "0x2E78D94", Offset = "0x2E78D94", VA = "0x2E78D94")]
	[Token(Token = "0x6000DF0")]
	private void method_5()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		NavMeshAgent navMeshAgent;
		if (photonView.<IsMine>k__BackingField)
		{
			long enabled = 1L;
			patrolAI.enabled = (enabled != 0L);
			navMeshAgent = this.navMeshAgent_0;
			return;
		}
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
		NavMeshAgent navMeshAgent2 = this.navMeshAgent_0;
		long enabled3 = 0L;
		navMeshAgent2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000DF1 RID: 3569 RVA: 0x0001E13C File Offset: 0x0001C33C
	[Address(RVA = "0x2E78E04", Offset = "0x2E78E04", VA = "0x2E78E04")]
	[Token(Token = "0x6000DF1")]
	private void method_6()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		long enabled2 = 1L;
		patrolAI.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DF2 RID: 3570 RVA: 0x0001E164 File Offset: 0x0001C364
	[Address(RVA = "0x2E78E50", Offset = "0x2E78E50", VA = "0x2E78E50")]
	[Token(Token = "0x6000DF2")]
	private void method_7()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		NavMeshAgent navMeshAgent;
		if (photonView.<IsMine>k__BackingField)
		{
			long enabled = 1L;
			patrolAI.enabled = (enabled != 0L);
			navMeshAgent = this.navMeshAgent_0;
			return;
		}
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
		NavMeshAgent navMeshAgent2 = this.navMeshAgent_0;
		long enabled3 = 1L;
		navMeshAgent2.enabled = (enabled3 != 0L);
	}

	// Token: 0x06000DF3 RID: 3571 RVA: 0x0001E098 File Offset: 0x0001C298
	[Address(RVA = "0x2E78EC0", Offset = "0x2E78EC0", VA = "0x2E78EC0")]
	[Token(Token = "0x6000DF3")]
	private void method_8()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 1L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DF4 RID: 3572 RVA: 0x0001E1B8 File Offset: 0x0001C3B8
	[Address(RVA = "0x2E78F0C", Offset = "0x2E78F0C", VA = "0x2E78F0C")]
	[Token(Token = "0x6000DF4")]
	private void method_9()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 1L;
		patrolAI.enabled = (enabled != 0L);
	}

	// Token: 0x06000DF5 RID: 3573 RVA: 0x0001E004 File Offset: 0x0001C204
	[Token(Token = "0x6000DF5")]
	[Address(RVA = "0x2E78F68", Offset = "0x2E78F68", VA = "0x2E78F68")]
	private void method_10()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DF6 RID: 3574 RVA: 0x0001E1D8 File Offset: 0x0001C3D8
	[Address(RVA = "0x2E78FC4", Offset = "0x2E78FC4", VA = "0x2E78FC4")]
	[Token(Token = "0x6000DF6")]
	private void method_11()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 1L;
		patrolAI.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DF7 RID: 3575 RVA: 0x0001E214 File Offset: 0x0001C414
	[Address(RVA = "0x2E79020", Offset = "0x2E79020", VA = "0x2E79020")]
	[Token(Token = "0x6000DF7")]
	private void method_12()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 1L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 1L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DF8 RID: 3576 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2E7907C", Offset = "0x2E7907C", VA = "0x2E7907C")]
	[Token(Token = "0x6000DF8")]
	public NetworkAi()
	{
	}

	// Token: 0x06000DF9 RID: 3577 RVA: 0x0001E0C8 File Offset: 0x0001C2C8
	[Address(RVA = "0x2E79084", Offset = "0x2E79084", VA = "0x2E79084")]
	[Token(Token = "0x6000DF9")]
	private void method_13()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DFA RID: 3578 RVA: 0x0001E254 File Offset: 0x0001C454
	[Token(Token = "0x6000DFA")]
	[Address(RVA = "0x2E790D0", Offset = "0x2E790D0", VA = "0x2E790D0")]
	private void method_14()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 1L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 1L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DFB RID: 3579 RVA: 0x0001E284 File Offset: 0x0001C484
	[Address(RVA = "0x2E7911C", Offset = "0x2E7911C", VA = "0x2E7911C")]
	[Token(Token = "0x6000DFB")]
	private void method_15()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		this.navMeshAgent_0.enabled = (enabled != 0L);
	}

	// Token: 0x06000DFC RID: 3580 RVA: 0x0001E2C0 File Offset: 0x0001C4C0
	[Token(Token = "0x6000DFC")]
	[Address(RVA = "0x2E79178", Offset = "0x2E79178", VA = "0x2E79178")]
	private void method_16()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DFD RID: 3581 RVA: 0x0001E304 File Offset: 0x0001C504
	[Address(RVA = "0x2E791D4", Offset = "0x2E791D4", VA = "0x2E791D4")]
	[Token(Token = "0x6000DFD")]
	private void method_17()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		long enabled2 = 1L;
		patrolAI.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DFE RID: 3582 RVA: 0x0001E254 File Offset: 0x0001C454
	[Token(Token = "0x6000DFE")]
	[Address(RVA = "0x2E79230", Offset = "0x2E79230", VA = "0x2E79230")]
	private void method_18()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 1L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 1L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000DFF RID: 3583 RVA: 0x0001E33C File Offset: 0x0001C53C
	[Token(Token = "0x6000DFF")]
	[Address(RVA = "0x2E7927C", Offset = "0x2E7927C", VA = "0x2E7927C")]
	private void method_19()
	{
		PhotonView photonView = this.photonView_0;
		PatrolAI patrolAI = this.patrolAI_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 1L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E00 RID: 3584 RVA: 0x0001E098 File Offset: 0x0001C298
	[Address(RVA = "0x2E792D8", Offset = "0x2E792D8", VA = "0x2E792D8")]
	[Token(Token = "0x6000E00")]
	private void method_20()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 1L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x06000E01 RID: 3585 RVA: 0x0001E0C8 File Offset: 0x0001C2C8
	[Address(RVA = "0x2E79324", Offset = "0x2E79324", VA = "0x2E79324")]
	[Token(Token = "0x6000E01")]
	private void method_21()
	{
		PatrolAI patrolAI = this.patrolAI_0;
		long enabled = 0L;
		patrolAI.enabled = (enabled != 0L);
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		long enabled2 = 0L;
		navMeshAgent.enabled = (enabled2 != 0L);
	}

	// Token: 0x0400020F RID: 527
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400020F")]
	public PhotonView photonView_0;

	// Token: 0x04000210 RID: 528
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000210")]
	public NavMeshAgent navMeshAgent_0;

	// Token: 0x04000211 RID: 529
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000211")]
	public PatrolAI patrolAI_0;
}
