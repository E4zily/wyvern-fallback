﻿using System;
using Cpp2IlInjected;

// Token: 0x02000163 RID: 355
[Token(Token = "0x2000163")]
public enum GEnum20
{
	// Token: 0x04000959 RID: 2393
	[Token(Token = "0x4000959")]
	const_0,
	// Token: 0x0400095A RID: 2394
	[Token(Token = "0x400095A")]
	const_1,
	// Token: 0x0400095B RID: 2395
	[Token(Token = "0x400095B")]
	const_2,
	// Token: 0x0400095C RID: 2396
	[Token(Token = "0x400095C")]
	const_3,
	// Token: 0x0400095D RID: 2397
	[Token(Token = "0x400095D")]
	const_4
}
