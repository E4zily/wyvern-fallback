﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020000B3 RID: 179
[Token(Token = "0x20000B3")]
public class ClientGunManager : MonoBehaviour
{
	// Token: 0x060019C3 RID: 6595 RVA: 0x00002775 File Offset: 0x00000975
	[Address(RVA = "0x2AF0FEC", Offset = "0x2AF0FEC", VA = "0x2AF0FEC")]
	[Token(Token = "0x60019C3")]
	public void method_0()
	{
		this.method_19();
		this.method_2();
	}

	// Token: 0x060019C4 RID: 6596 RVA: 0x000333C0 File Offset: 0x000315C0
	[Address(RVA = "0x2AF12E8", Offset = "0x2AF12E8", VA = "0x2AF12E8")]
	[Token(Token = "0x60019C4")]
	public void method_1()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Collider collider;
		collider.CompareTag("forced knee retract");
	}

	// Token: 0x060019C5 RID: 6597 RVA: 0x00033404 File Offset: 0x00031604
	[Address(RVA = "0x2AF1074", Offset = "0x2AF1074", VA = "0x2AF1074")]
	[Token(Token = "0x60019C5")]
	public void method_2()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060019C6 RID: 6598 RVA: 0x0003343C File Offset: 0x0003163C
	[Address(RVA = "0x2AF1584", Offset = "0x2AF1584", VA = "0x2AF1584")]
	[Token(Token = "0x60019C6")]
	private void method_3()
	{
		TextMeshPro component = GameObject.Find("username").GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_1)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
			this.method_22();
		}
		if (this.bool_0 && this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060019C7 RID: 6599 RVA: 0x0003349C File Offset: 0x0003169C
	[Address(RVA = "0x2AF1978", Offset = "0x2AF1978", VA = "0x2AF1978")]
	[Token(Token = "0x60019C7")]
	public void method_4()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Collider collider;
		collider.CompareTag("Target");
		int num = this.int_0;
		this.int_0 = num;
	}

	// Token: 0x060019C8 RID: 6600 RVA: 0x000334F0 File Offset: 0x000316F0
	[Address(RVA = "0x2AF1C24", Offset = "0x2AF1C24", VA = "0x2AF1C24")]
	[Token(Token = "0x60019C8")]
	public void method_5()
	{
		Vector3 forward = Vector3.forward;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Collider collider;
		collider.CompareTag("CapuchinStore");
	}

	// Token: 0x060019C9 RID: 6601 RVA: 0x00002783 File Offset: 0x00000983
	[PunRPC]
	[Address(RVA = "0x2AF1EC0", Offset = "0x2AF1EC0", VA = "0x2AF1EC0")]
	[Token(Token = "0x60019C9")]
	public void NGNNoSound()
	{
		this.method_4();
	}

	// Token: 0x060019CA RID: 6602 RVA: 0x0003351C File Offset: 0x0003171C
	[Address(RVA = "0x2AF1EC4", Offset = "0x2AF1EC4", VA = "0x2AF1EC4")]
	[Token(Token = "0x60019CA")]
	private void method_6()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("Purchase For ").GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (!this.bool_1)
		{
			this.method_22();
		}
		if (this.bool_0 && this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060019CB RID: 6603 RVA: 0x00033580 File Offset: 0x00031780
	[Address(RVA = "0x2AF2134", Offset = "0x2AF2134", VA = "0x2AF2134")]
	[Token(Token = "0x60019CB")]
	private void Update()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject.Find("ScoreCounter").GetComponent<TextMeshPro>();
		}
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_1)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
			this.method_22();
			this.bool_1 = (num != 0L);
		}
		if (this.bool_0 && this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060019CC RID: 6604 RVA: 0x0000278B File Offset: 0x0000098B
	[Address(RVA = "0x2AF23A4", Offset = "0x2AF23A4", VA = "0x2AF23A4")]
	[Token(Token = "0x60019CC")]
	public void method_7()
	{
		this.method_24();
	}

	// Token: 0x060019CD RID: 6605 RVA: 0x000335EC File Offset: 0x000317EC
	[Address(RVA = "0x2AF2658", Offset = "0x2AF2658", VA = "0x2AF2658")]
	[Token(Token = "0x60019CD")]
	public void method_8()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Collider collider;
		collider.CompareTag("FingerTip");
	}

	// Token: 0x060019CE RID: 6606 RVA: 0x00033630 File Offset: 0x00031830
	[Address(RVA = "0x2AF28F4", Offset = "0x2AF28F4", VA = "0x2AF28F4")]
	[Token(Token = "0x60019CE")]
	private void method_9()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("HandL").GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_1)
		{
			this.method_32();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		long num2 = 1L;
		this.bool_1 = (num2 != 0L);
		if (this.bool_0 && this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060019CF RID: 6607 RVA: 0x00002793 File Offset: 0x00000993
	[Address(RVA = "0x2AF2CE4", Offset = "0x2AF2CE4", VA = "0x2AF2CE4")]
	[Token(Token = "0x60019CF")]
	public void method_10()
	{
		this.method_12();
		this.method_8();
	}

	// Token: 0x060019D0 RID: 6608 RVA: 0x000336A8 File Offset: 0x000318A8
	[Address(RVA = "0x2AF2D6C", Offset = "0x2AF2D6C", VA = "0x2AF2D6C")]
	[Token(Token = "0x60019D0")]
	private void method_11()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("monkeScream").GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_1)
		{
			this.method_25();
		}
		long num = 1L;
		this.bool_1 = (num != 0L);
		if (this.bool_0 && this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060019D1 RID: 6609 RVA: 0x00033714 File Offset: 0x00031914
	[Address(RVA = "0x2AF2D08", Offset = "0x2AF2D08", VA = "0x2AF2D08")]
	[Token(Token = "0x60019D1")]
	public void method_12()
	{
	}

	// Token: 0x060019D2 RID: 6610 RVA: 0x000027A1 File Offset: 0x000009A1
	[Address(RVA = "0x2AF3158", Offset = "0x2AF3158", VA = "0x2AF3158")]
	[Token(Token = "0x60019D2")]
	public void method_13()
	{
		this.method_27();
		this.method_8();
	}

	// Token: 0x060019D3 RID: 6611 RVA: 0x00033724 File Offset: 0x00031924
	[Address(RVA = "0x2AF31E0", Offset = "0x2AF31E0", VA = "0x2AF31E0")]
	[Token(Token = "0x60019D3")]
	private void method_14()
	{
		GameObject.Find("retract broken").GetComponent<TextMeshPro>();
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_1)
		{
			this.method_25();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		if (this.bool_0 && this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060019D4 RID: 6612 RVA: 0x00002793 File Offset: 0x00000993
	[Address(RVA = "0x2AF345C", Offset = "0x2AF345C", VA = "0x2AF345C")]
	[Token(Token = "0x60019D4")]
	public void method_15()
	{
		this.method_12();
		this.method_8();
	}

	// Token: 0x060019D5 RID: 6613 RVA: 0x000027AF File Offset: 0x000009AF
	[Address(RVA = "0x2AF3480", Offset = "0x2AF3480", VA = "0x2AF3480")]
	[Token(Token = "0x60019D5")]
	public void method_16()
	{
		this.method_12();
		this.method_4();
	}

	// Token: 0x060019D6 RID: 6614 RVA: 0x000027BD File Offset: 0x000009BD
	[Address(RVA = "0x2AF34A4", Offset = "0x2AF34A4", VA = "0x2AF34A4")]
	[Token(Token = "0x60019D6")]
	public void method_17()
	{
		this.method_8();
	}

	// Token: 0x060019D7 RID: 6615 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2AF34A8", Offset = "0x2AF34A8", VA = "0x2AF34A8")]
	[Token(Token = "0x60019D7")]
	public ClientGunManager()
	{
	}

	// Token: 0x060019D8 RID: 6616 RVA: 0x0003377C File Offset: 0x0003197C
	[Address(RVA = "0x2AF34B0", Offset = "0x2AF34B0", VA = "0x2AF34B0")]
	[Token(Token = "0x60019D8")]
	private void method_18()
	{
		TextMeshPro component = GameObject.Find("Left Hand").GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_1)
		{
			this.method_22();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		long num2 = 1L;
		this.bool_1 = (num2 != 0L);
		if (this.bool_0 && this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060019D9 RID: 6617 RVA: 0x000337E8 File Offset: 0x000319E8
	[Address(RVA = "0x2AF1010", Offset = "0x2AF1010", VA = "0x2AF1010")]
	[Token(Token = "0x60019D9")]
	public void method_19()
	{
	}

	// Token: 0x060019DA RID: 6618 RVA: 0x000027C5 File Offset: 0x000009C5
	[Address(RVA = "0x2AF3728", Offset = "0x2AF3728", VA = "0x2AF3728")]
	[Token(Token = "0x60019DA")]
	public void method_20()
	{
		this.method_27();
		this.method_1();
	}

	// Token: 0x060019DB RID: 6619 RVA: 0x000337F8 File Offset: 0x000319F8
	[Address(RVA = "0x2AF374C", Offset = "0x2AF374C", VA = "0x2AF374C")]
	[Token(Token = "0x60019DB")]
	private void method_21()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("Fire Stick Is Lighting...").GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_1)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
			this.method_22();
			this.bool_1 = (num != 0L);
		}
		long num2 = 1L;
		this.bool_1 = (num2 != 0L);
		if (this.bool_0 && this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060019DC RID: 6620 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2AF1800", Offset = "0x2AF1800", VA = "0x2AF1800")]
	[Token(Token = "0x60019DC")]
	private void method_22()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019DD RID: 6621 RVA: 0x00033878 File Offset: 0x00031A78
	[Address(RVA = "0x2AF39C4", Offset = "0x2AF39C4", VA = "0x2AF39C4")]
	[Token(Token = "0x60019DD")]
	private void method_23()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			TextMeshPro component = GameObject.Find("TurnAmount").GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_1)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
			this.method_32();
			this.bool_1 = (num != 0L);
		}
		long num2 = 1L;
		this.bool_1 = (num2 != 0L);
		if (this.bool_0 && this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x060019DE RID: 6622 RVA: 0x000338F8 File Offset: 0x00031AF8
	[Address(RVA = "0x2AF23A8", Offset = "0x2AF23A8", VA = "0x2AF23A8")]
	[Token(Token = "0x60019DE")]
	public void method_24()
	{
		Vector3 forward = Vector3.forward;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060019DF RID: 6623 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2AF2FE0", Offset = "0x2AF2FE0", VA = "0x2AF2FE0")]
	[Token(Token = "0x60019DF")]
	private void method_25()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019E0 RID: 6624 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2AF3C34", Offset = "0x2AF3C34", VA = "0x2AF3C34")]
	[Token(Token = "0x60019E0")]
	private void method_26()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060019E1 RID: 6625 RVA: 0x00033918 File Offset: 0x00031B18
	[Address(RVA = "0x2AF317C", Offset = "0x2AF317C", VA = "0x2AF317C")]
	[Token(Token = "0x60019E1")]
	public void method_27()
	{
	}

	// Token: 0x060019E2 RID: 6626 RVA: 0x000027BD File Offset: 0x000009BD
	[Address(RVA = "0x2AF3DAC", Offset = "0x2AF3DAC", VA = "0x2AF3DAC")]
	[Token(Token = "0x60019E2")]
	public void method_28()
	{
		this.method_8();
	}

	// Token: 0x060019E3 RID: 6627 RVA: 0x000027D3 File Offset: 0x000009D3
	[Address(RVA = "0x2AF3DB0", Offset = "0x2AF3DB0", VA = "0x2AF3DB0")]
	[Token(Token = "0x60019E3")]
	public void method_29()
	{
		this.method_12();
		this.method_5();
	}

	// Token: 0x060019E4 RID: 6628 RVA: 0x00033928 File Offset: 0x00031B28
	[Address(RVA = "0x2AF3DD4", Offset = "0x2AF3DD4", VA = "0x2AF3DD4")]
	[Token(Token = "0x60019E4")]
	public void method_30()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Collider collider;
		collider.CompareTag("Player");
	}

	// Token: 0x060019E5 RID: 6629 RVA: 0x000027E1 File Offset: 0x000009E1
	[Address(RVA = "0x2AF404C", Offset = "0x2AF404C", VA = "0x2AF404C")]
	[Token(Token = "0x60019E5")]
	public void method_31()
	{
		this.method_19();
		this.method_30();
	}

	// Token: 0x060019E6 RID: 6630 RVA: 0x000027AF File Offset: 0x000009AF
	[PunRPC]
	[Address(RVA = "0x2AF4070", Offset = "0x2AF4070", VA = "0x2AF4070")]
	[Token(Token = "0x60019E6")]
	public void NetworkGunShoot()
	{
		this.method_12();
		this.method_4();
	}

	// Token: 0x060019E7 RID: 6631 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2AF2B6C", Offset = "0x2AF2B6C", VA = "0x2AF2B6C")]
	[Token(Token = "0x60019E7")]
	private void method_32()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0400034C RID: 844
	[Token(Token = "0x400034C")]
	[FieldOffset(Offset = "0x18")]
	public Transform transform_0;

	// Token: 0x0400034D RID: 845
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400034D")]
	public float float_0;

	// Token: 0x0400034E RID: 846
	[Token(Token = "0x400034E")]
	[FieldOffset(Offset = "0x24")]
	public bool bool_0;

	// Token: 0x0400034F RID: 847
	[Token(Token = "0x400034F")]
	[FieldOffset(Offset = "0x28")]
	public ParticleSystem[] particleSystem_0;

	// Token: 0x04000350 RID: 848
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000350")]
	public XRNode xrnode_0;

	// Token: 0x04000351 RID: 849
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x4000351")]
	public bool bool_1;

	// Token: 0x04000352 RID: 850
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000352")]
	public AudioSource audioSource_0;

	// Token: 0x04000353 RID: 851
	[Token(Token = "0x4000353")]
	[FieldOffset(Offset = "0x40")]
	public AudioClip[] audioClip_0;

	// Token: 0x04000354 RID: 852
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000354")]
	private bool bool_2;

	// Token: 0x04000355 RID: 853
	[Token(Token = "0x4000355")]
	[FieldOffset(Offset = "0x4C")]
	public int int_0;

	// Token: 0x04000356 RID: 854
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000356")]
	public TextMeshPro textMeshPro_0;

	// Token: 0x04000357 RID: 855
	[Token(Token = "0x4000357")]
	[FieldOffset(Offset = "0x58")]
	public PhotonView photonView_0;
}
