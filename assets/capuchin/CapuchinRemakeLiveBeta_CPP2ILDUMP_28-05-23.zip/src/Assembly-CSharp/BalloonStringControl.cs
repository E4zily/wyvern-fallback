﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000A5 RID: 165
[Token(Token = "0x20000A5")]
public class BalloonStringControl : MonoBehaviour
{
	// Token: 0x060017DE RID: 6110 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Token(Token = "0x60017DE")]
	[Address(RVA = "0x2BFDD04", Offset = "0x2BFDD04", VA = "0x2BFDD04")]
	private void method_0()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017DF RID: 6111 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60017DF")]
	[Address(RVA = "0x2BFDD80", Offset = "0x2BFDD80", VA = "0x2BFDD80")]
	public BalloonStringControl()
	{
	}

	// Token: 0x060017E0 RID: 6112 RVA: 0x00030C58 File Offset: 0x0002EE58
	[Token(Token = "0x60017E0")]
	[Address(RVA = "0x2BFDD88", Offset = "0x2BFDD88", VA = "0x2BFDD88")]
	private void method_1()
	{
		while (this.points != null)
		{
		}
		throw new NullReferenceException();
	}

	// Token: 0x060017E1 RID: 6113 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Token(Token = "0x60017E1")]
	[Address(RVA = "0x2BFDDEC", Offset = "0x2BFDDEC", VA = "0x2BFDDEC")]
	private void Start()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017E2 RID: 6114 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Token(Token = "0x60017E2")]
	[Address(RVA = "0x2BFDE68", Offset = "0x2BFDE68", VA = "0x2BFDE68")]
	private void method_2()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017E3 RID: 6115 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Address(RVA = "0x2BFDEE4", Offset = "0x2BFDEE4", VA = "0x2BFDEE4")]
	[Token(Token = "0x60017E3")]
	private void method_3()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017E4 RID: 6116 RVA: 0x00030C74 File Offset: 0x0002EE74
	[Address(RVA = "0x2BFDF60", Offset = "0x2BFDF60", VA = "0x2BFDF60")]
	[Token(Token = "0x60017E4")]
	private void Update()
	{
		while (this.points != null)
		{
		}
		throw new NullReferenceException();
	}

	// Token: 0x060017E5 RID: 6117 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Token(Token = "0x60017E5")]
	[Address(RVA = "0x2BFDFEC", Offset = "0x2BFDFEC", VA = "0x2BFDFEC")]
	private void method_4()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017E6 RID: 6118 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Address(RVA = "0x2BFE068", Offset = "0x2BFE068", VA = "0x2BFE068")]
	[Token(Token = "0x60017E6")]
	private void method_5()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017E7 RID: 6119 RVA: 0x00030C58 File Offset: 0x0002EE58
	[Token(Token = "0x60017E7")]
	[Address(RVA = "0x2BFE0E4", Offset = "0x2BFE0E4", VA = "0x2BFE0E4")]
	private void method_6()
	{
		while (this.points != null)
		{
		}
		throw new NullReferenceException();
	}

	// Token: 0x060017E8 RID: 6120 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Token(Token = "0x60017E8")]
	[Address(RVA = "0x2BFE170", Offset = "0x2BFE170", VA = "0x2BFE170")]
	private void method_7()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017E9 RID: 6121 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60017E9")]
	[Address(RVA = "0x2BFE1EC", Offset = "0x2BFE1EC", VA = "0x2BFE1EC")]
	private void method_8()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060017EA RID: 6122 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Address(RVA = "0x2BFE268", Offset = "0x2BFE268", VA = "0x2BFE268")]
	[Token(Token = "0x60017EA")]
	private void method_9()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017EB RID: 6123 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Address(RVA = "0x2BFE2E4", Offset = "0x2BFE2E4", VA = "0x2BFE2E4")]
	[Token(Token = "0x60017EB")]
	private void method_10()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017EC RID: 6124 RVA: 0x00030C58 File Offset: 0x0002EE58
	[Token(Token = "0x60017EC")]
	[Address(RVA = "0x2BFE360", Offset = "0x2BFE360", VA = "0x2BFE360")]
	private void method_11()
	{
		while (this.points != null)
		{
		}
		throw new NullReferenceException();
	}

	// Token: 0x060017ED RID: 6125 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Address(RVA = "0x2BFE3EC", Offset = "0x2BFE3EC", VA = "0x2BFE3EC")]
	[Token(Token = "0x60017ED")]
	private void method_12()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017EE RID: 6126 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Token(Token = "0x60017EE")]
	[Address(RVA = "0x2BFE468", Offset = "0x2BFE468", VA = "0x2BFE468")]
	private void method_13()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017EF RID: 6127 RVA: 0x00030C90 File Offset: 0x0002EE90
	[Address(RVA = "0x2BFE4E4", Offset = "0x2BFE4E4", VA = "0x2BFE4E4")]
	[Token(Token = "0x60017EF")]
	private void method_14()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017F0 RID: 6128 RVA: 0x00030C58 File Offset: 0x0002EE58
	[Token(Token = "0x60017F0")]
	[Address(RVA = "0x2BFE560", Offset = "0x2BFE560", VA = "0x2BFE560")]
	private void method_15()
	{
		while (this.points != null)
		{
		}
		throw new NullReferenceException();
	}

	// Token: 0x060017F1 RID: 6129 RVA: 0x00030C3C File Offset: 0x0002EE3C
	[Address(RVA = "0x2BFE5EC", Offset = "0x2BFE5EC", VA = "0x2BFE5EC")]
	[Token(Token = "0x60017F1")]
	private void method_16()
	{
		LineRenderer component = base.GetComponent<LineRenderer>();
		this.lineRenderer_0 = component;
	}

	// Token: 0x060017F2 RID: 6130 RVA: 0x00030C58 File Offset: 0x0002EE58
	[Address(RVA = "0x2BFE668", Offset = "0x2BFE668", VA = "0x2BFE668")]
	[Token(Token = "0x60017F2")]
	private void method_17()
	{
		while (this.points != null)
		{
		}
		throw new NullReferenceException();
	}

	// Token: 0x04000319 RID: 793
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000319")]
	private LineRenderer lineRenderer_0;

	// Token: 0x0400031A RID: 794
	[Token(Token = "0x400031A")]
	[SerializeField]
	[FieldOffset(Offset = "0x20")]
	private Transform[] points;
}
