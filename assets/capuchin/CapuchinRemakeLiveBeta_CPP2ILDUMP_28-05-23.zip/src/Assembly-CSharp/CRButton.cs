﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200000C RID: 12
[Token(Token = "0x200000C")]
public class CRButton : MonoBehaviour
{
	// Token: 0x06000152 RID: 338 RVA: 0x00007844 File Offset: 0x00005A44
	[Address(RVA = "0x25B6054", Offset = "0x25B6054", VA = "0x25B6054")]
	[Token(Token = "0x6000152")]
	public void method_0(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("\n Time: ", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000153 RID: 339 RVA: 0x0000789C File Offset: 0x00005A9C
	[Address(RVA = "0x25B6164", Offset = "0x25B6164", VA = "0x25B6164")]
	[Token(Token = "0x6000153")]
	public void method_1(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		collider_0;
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("Name Changing Error. Error: ", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000154 RID: 340 RVA: 0x000078F4 File Offset: 0x00005AF4
	[Token(Token = "0x6000154")]
	[Address(RVA = "0x25B6274", Offset = "0x25B6274", VA = "0x25B6274")]
	public void method_2(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000155 RID: 341 RVA: 0x00007934 File Offset: 0x00005B34
	[Address(RVA = "0x25B6384", Offset = "0x25B6384", VA = "0x25B6384")]
	[Token(Token = "0x6000155")]
	public void method_3(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("Not enough amount of currency", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000156 RID: 342 RVA: 0x0000798C File Offset: 0x00005B8C
	[Address(RVA = "0x25B6494", Offset = "0x25B6494", VA = "0x25B6494")]
	[Token(Token = "0x6000156")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("Open", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000157 RID: 343 RVA: 0x000079E4 File Offset: 0x00005BE4
	[Address(RVA = "0x25B65A4", Offset = "0x25B65A4", VA = "0x25B65A4")]
	[Token(Token = "0x6000157")]
	public void method_4(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("Player", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000158 RID: 344 RVA: 0x00007A3C File Offset: 0x00005C3C
	[Address(RVA = "0x25B66B4", Offset = "0x25B66B4", VA = "0x25B66B4")]
	[Token(Token = "0x6000158")]
	public void method_5(Collider collider_0)
	{
		HandColliders exists;
		exists;
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool(".Please press the button if you would like to play alone", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000159 RID: 345 RVA: 0x00007A8C File Offset: 0x00005C8C
	[Address(RVA = "0x25B67C4", Offset = "0x25B67C4", VA = "0x25B67C4")]
	[Token(Token = "0x6000159")]
	public void method_6(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("hh:mmtt", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015A RID: 346 RVA: 0x00007AE4 File Offset: 0x00005CE4
	[Token(Token = "0x600015A")]
	[Address(RVA = "0x25B68D4", Offset = "0x25B68D4", VA = "0x25B68D4")]
	public void method_7(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("tutorialCheck", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015B RID: 347 RVA: 0x00007934 File Offset: 0x00005B34
	[Token(Token = "0x600015B")]
	[Address(RVA = "0x25B69E4", Offset = "0x25B69E4", VA = "0x25B69E4")]
	public void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("Not enough amount of currency", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015C RID: 348 RVA: 0x000078F4 File Offset: 0x00005AF4
	[Token(Token = "0x600015C")]
	[Address(RVA = "0x25B6AF4", Offset = "0x25B6AF4", VA = "0x25B6AF4")]
	public void method_9(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015D RID: 349 RVA: 0x000079E4 File Offset: 0x00005BE4
	[Token(Token = "0x600015D")]
	[Address(RVA = "0x25B6C04", Offset = "0x25B6C04", VA = "0x25B6C04")]
	public void method_10(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("Player", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015E RID: 350 RVA: 0x00007B3C File Offset: 0x00005D3C
	[Token(Token = "0x600015E")]
	[Address(RVA = "0x25B6D14", Offset = "0x25B6D14", VA = "0x25B6D14")]
	public void method_11(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("Count of rooms ", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600015F RID: 351 RVA: 0x00007B8C File Offset: 0x00005D8C
	[Address(RVA = "0x25B6E24", Offset = "0x25B6E24", VA = "0x25B6E24")]
	[Token(Token = "0x600015F")]
	public void method_12(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("Removing ", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000160 RID: 352 RVA: 0x00007BE4 File Offset: 0x00005DE4
	[Token(Token = "0x6000160")]
	[Address(RVA = "0x25B6F34", Offset = "0x25B6F34", VA = "0x25B6F34")]
	public void method_13(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("Squeeze", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000161 RID: 353 RVA: 0x00007C34 File Offset: 0x00005E34
	[Address(RVA = "0x25B7044", Offset = "0x25B7044", VA = "0x25B7044")]
	[Token(Token = "0x6000161")]
	public void method_14(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool(" and the correct version is ", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000162 RID: 354 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x25B7154", Offset = "0x25B7154", VA = "0x25B7154")]
	[Token(Token = "0x6000162")]
	public void method_15(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000163 RID: 355 RVA: 0x00007C8C File Offset: 0x00005E8C
	[Address(RVA = "0x25B7264", Offset = "0x25B7264", VA = "0x25B7264")]
	[Token(Token = "0x6000163")]
	public void method_16(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("make more points bobo", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000164 RID: 356 RVA: 0x00007CE4 File Offset: 0x00005EE4
	[Address(RVA = "0x25B7374", Offset = "0x25B7374", VA = "0x25B7374")]
	[Token(Token = "0x6000164")]
	public void method_17(Collider collider_0)
	{
		HandColliders exists;
		exists;
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("true", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000165 RID: 357 RVA: 0x00007D34 File Offset: 0x00005F34
	[Token(Token = "0x6000165")]
	[Address(RVA = "0x25B7484", Offset = "0x25B7484", VA = "0x25B7484")]
	public void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("Queue", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000166 RID: 358 RVA: 0x00007D8C File Offset: 0x00005F8C
	[Token(Token = "0x6000166")]
	[Address(RVA = "0x25B7594", Offset = "0x25B7594", VA = "0x25B7594")]
	public void method_19(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("Player", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000167 RID: 359 RVA: 0x00007DE4 File Offset: 0x00005FE4
	[Address(RVA = "0x25B76A4", Offset = "0x25B76A4", VA = "0x25B76A4")]
	[Token(Token = "0x6000167")]
	public void method_20(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		collider_0;
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("button", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000168 RID: 360 RVA: 0x00007E3C File Offset: 0x0000603C
	[Address(RVA = "0x25B77B4", Offset = "0x25B77B4", VA = "0x25B77B4")]
	[Token(Token = "0x6000168")]
	public void method_21(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("Round end", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000169 RID: 361 RVA: 0x00007E94 File Offset: 0x00006094
	[Token(Token = "0x6000169")]
	[Address(RVA = "0x25B78C4", Offset = "0x25B78C4", VA = "0x25B78C4")]
	public void method_22(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("FingerTip", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600016A RID: 362 RVA: 0x00007EEC File Offset: 0x000060EC
	[Token(Token = "0x600016A")]
	[Address(RVA = "0x25B79D4", Offset = "0x25B79D4", VA = "0x25B79D4")]
	public void method_23(Collider collider_0)
	{
		collider_0;
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("StartSong", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600016B RID: 363 RVA: 0x00007F3C File Offset: 0x0000613C
	[Address(RVA = "0x25B7AE4", Offset = "0x25B7AE4", VA = "0x25B7AE4")]
	[Token(Token = "0x600016B")]
	public void method_24(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("username", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600016C RID: 364 RVA: 0x000078F4 File Offset: 0x00005AF4
	[Address(RVA = "0x25B7BF4", Offset = "0x25B7BF4", VA = "0x25B7BF4")]
	[Token(Token = "0x600016C")]
	public void method_25(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600016D RID: 365 RVA: 0x00007F94 File Offset: 0x00006194
	[Address(RVA = "0x25B7D04", Offset = "0x25B7D04", VA = "0x25B7D04")]
	[Token(Token = "0x600016D")]
	public void method_26(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("true", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600016E RID: 366 RVA: 0x00007FEC File Offset: 0x000061EC
	[Address(RVA = "0x25B7E14", Offset = "0x25B7E14", VA = "0x25B7E14")]
	[Token(Token = "0x600016E")]
	public void method_27(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("amongus", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600016F RID: 367 RVA: 0x00008044 File Offset: 0x00006244
	[Token(Token = "0x600016F")]
	[Address(RVA = "0x25B7F24", Offset = "0x25B7F24", VA = "0x25B7F24")]
	public void method_28(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("Version", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000170 RID: 368 RVA: 0x0000809C File Offset: 0x0000629C
	[Address(RVA = "0x25B8034", Offset = "0x25B8034", VA = "0x25B8034")]
	[Token(Token = "0x6000170")]
	public void method_29(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("HandL", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000171 RID: 369 RVA: 0x000080F4 File Offset: 0x000062F4
	[Address(RVA = "0x25B8144", Offset = "0x25B8144", VA = "0x25B8144")]
	[Token(Token = "0x6000171")]
	public void method_30(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("monkeScream", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000172 RID: 370 RVA: 0x0000814C File Offset: 0x0000634C
	[Address(RVA = "0x25B8254", Offset = "0x25B8254", VA = "0x25B8254")]
	[Token(Token = "0x6000172")]
	public void method_31(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("{0}/{1:f0}", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000173 RID: 371 RVA: 0x000081A4 File Offset: 0x000063A4
	[Address(RVA = "0x25B8364", Offset = "0x25B8364", VA = "0x25B8364")]
	[Token(Token = "0x6000173")]
	public void method_32(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000174 RID: 372 RVA: 0x000081FC File Offset: 0x000063FC
	[Token(Token = "0x6000174")]
	[Address(RVA = "0x25B8474", Offset = "0x25B8474", VA = "0x25B8474")]
	public void method_33(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("betaAgree", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000175 RID: 373 RVA: 0x00008254 File Offset: 0x00006454
	[Address(RVA = "0x25B8584", Offset = "0x25B8584", VA = "0x25B8584")]
	[Token(Token = "0x6000175")]
	public void method_34(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("trol", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000176 RID: 374 RVA: 0x000082AC File Offset: 0x000064AC
	[Token(Token = "0x6000176")]
	[Address(RVA = "0x25B8694", Offset = "0x25B8694", VA = "0x25B8694")]
	public void method_35(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("Is Colliding", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000177 RID: 375 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x25B87A4", Offset = "0x25B87A4", VA = "0x25B87A4")]
	[Token(Token = "0x6000177")]
	public void method_36(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000178 RID: 376 RVA: 0x00008304 File Offset: 0x00006504
	[Token(Token = "0x6000178")]
	[Address(RVA = "0x25B88B4", Offset = "0x25B88B4", VA = "0x25B88B4")]
	public void method_37(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("Joined a Room.", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000179 RID: 377 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000179")]
	[Address(RVA = "0x25B89C4", Offset = "0x25B89C4", VA = "0x25B89C4")]
	public void method_38(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600017A RID: 378 RVA: 0x0000835C File Offset: 0x0000655C
	[Address(RVA = "0x25B8AD4", Offset = "0x25B8AD4", VA = "0x25B8AD4")]
	[Token(Token = "0x600017A")]
	public void method_39(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("monke is not my monke", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600017B RID: 379 RVA: 0x00007F3C File Offset: 0x0000613C
	[Token(Token = "0x600017B")]
	[Address(RVA = "0x25B8BE4", Offset = "0x25B8BE4", VA = "0x25B8BE4")]
	public void method_40(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("username", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600017C RID: 380 RVA: 0x00007740 File Offset: 0x00005940
	[Token(Token = "0x600017C")]
	[Address(RVA = "0x25B8CF4", Offset = "0x25B8CF4", VA = "0x25B8CF4")]
	public void method_41(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x0600017D RID: 381 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x600017D")]
	[Address(RVA = "0x25B8E04", Offset = "0x25B8E04", VA = "0x25B8E04")]
	public CRButton()
	{
	}

	// Token: 0x0600017E RID: 382 RVA: 0x000083B4 File Offset: 0x000065B4
	[Token(Token = "0x600017E")]
	[Address(RVA = "0x25B8E0C", Offset = "0x25B8E0C", VA = "0x25B8E0C")]
	public void method_42(Collider collider_0)
	{
		HandColliders exists;
		exists;
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("Cannot access index {0}. Buffer size is {1}", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0600017F RID: 383 RVA: 0x00008404 File Offset: 0x00006604
	[Token(Token = "0x600017F")]
	[Address(RVA = "0x25B8F1C", Offset = "0x25B8F1C", VA = "0x25B8F1C")]
	public void method_43(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("BN", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000180 RID: 384 RVA: 0x0000845C File Offset: 0x0000665C
	[Address(RVA = "0x25B902C", Offset = "0x25B902C", VA = "0x25B902C")]
	[Token(Token = "0x6000180")]
	public void method_44(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("Update User Inventory", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000181 RID: 385 RVA: 0x000084B4 File Offset: 0x000066B4
	[Token(Token = "0x6000181")]
	[Address(RVA = "0x25B913C", Offset = "0x25B913C", VA = "0x25B913C")]
	public void method_45(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 1L;
			animator.SetBool("Platform failed to initialize due to exception.", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000182 RID: 386 RVA: 0x0000850C File Offset: 0x0000670C
	[Token(Token = "0x6000182")]
	[Address(RVA = "0x25B924C", Offset = "0x25B924C", VA = "0x25B924C")]
	public void method_46(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("TurnAmount", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x06000183 RID: 387 RVA: 0x00008564 File Offset: 0x00006764
	[Token(Token = "0x6000183")]
	[Address(RVA = "0x25B935C", Offset = "0x25B935C", VA = "0x25B935C")]
	public void method_47(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			this.createRoom_0.CreateRoomLol();
			Animator animator = this.animator_0;
			long value = 0L;
			animator.SetBool("Hats", value != 0L);
		}
		if (this.bool_1)
		{
			this.createRoom_0.LeaveRoomLol();
			return;
		}
	}

	// Token: 0x0400002F RID: 47
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400002F")]
	public CreateRoom createRoom_0;

	// Token: 0x04000030 RID: 48
	[Token(Token = "0x4000030")]
	[FieldOffset(Offset = "0x20")]
	public bool bool_0;

	// Token: 0x04000031 RID: 49
	[Token(Token = "0x4000031")]
	[FieldOffset(Offset = "0x21")]
	public bool bool_1;

	// Token: 0x04000032 RID: 50
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000032")]
	public Animator animator_0;
}
