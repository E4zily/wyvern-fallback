﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200005B RID: 91
[Token(Token = "0x200005B")]
public class DeleteAndroidDebugger : MonoBehaviour
{
	// Token: 0x06000CB3 RID: 3251 RVA: 0x0001AFF8 File Offset: 0x000191F8
	[Address(RVA = "0x2A08D18", Offset = "0x2A08D18", VA = "0x2A08D18")]
	[Token(Token = "0x6000CB3")]
	private void method_0()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("XR Usage");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CB4 RID: 3252 RVA: 0x0001B074 File Offset: 0x00019274
	[Address(RVA = "0x2A09020", Offset = "0x2A09020", VA = "0x2A09020")]
	[Token(Token = "0x6000CB4")]
	private void method_1()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Transform transform3;
		Vector3 position3 = transform3.position;
		Debug.Log("This is the 1000 Bananas button, and it was just clicked");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform4;
			UnityEngine.Object.Destroy(transform4.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000CB5 RID: 3253 RVA: 0x0001B0F8 File Offset: 0x000192F8
	[Address(RVA = "0x2A0932C", Offset = "0x2A0932C", VA = "0x2A0932C")]
	[Token(Token = "0x6000CB5")]
	private void method_2()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("PlayerHead");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000CB6 RID: 3254 RVA: 0x0001B180 File Offset: 0x00019380
	[Address(RVA = "0x2A09640", Offset = "0x2A09640", VA = "0x2A09640")]
	[Token(Token = "0x6000CB6")]
	private void method_3()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("Player");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CB7 RID: 3255 RVA: 0x0001B1FC File Offset: 0x000193FC
	[Address(RVA = "0x2A09948", Offset = "0x2A09948", VA = "0x2A09948")]
	[Token(Token = "0x6000CB7")]
	private void method_4()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("tutorialCheck");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			return;
		}
	}

	// Token: 0x06000CB8 RID: 3256 RVA: 0x0001B27C File Offset: 0x0001947C
	[Address(RVA = "0x2A09C5C", Offset = "0x2A09C5C", VA = "0x2A09C5C")]
	[Token(Token = "0x6000CB8")]
	private void method_5()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("HeadAttachPoint");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000CB9 RID: 3257 RVA: 0x0001B304 File Offset: 0x00019504
	[Address(RVA = "0x2A09F68", Offset = "0x2A09F68", VA = "0x2A09F68")]
	[Token(Token = "0x6000CB9")]
	private void FixedUpdate()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("Did Hit");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000CBA RID: 3258 RVA: 0x0001B38C File Offset: 0x0001958C
	[Token(Token = "0x6000CBA")]
	[Address(RVA = "0x2A0A278", Offset = "0x2A0A278", VA = "0x2A0A278")]
	private void method_6()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("Hats");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CBB RID: 3259 RVA: 0x0001B408 File Offset: 0x00019608
	[Token(Token = "0x6000CBB")]
	[Address(RVA = "0x2A0A580", Offset = "0x2A0A580", VA = "0x2A0A580")]
	private void method_7()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("An error has occured while buying bananas, please restart your game and try again");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000CBC RID: 3260 RVA: 0x0001B490 File Offset: 0x00019690
	[Token(Token = "0x6000CBC")]
	[Address(RVA = "0x2A0A894", Offset = "0x2A0A894", VA = "0x2A0A894")]
	private void method_8()
	{
		Transform transform;
		Vector3 position = transform.position;
		Vector3 forward = Vector3.forward;
		Transform transform2;
		Vector3 position2 = transform2.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Transform transform3;
		Vector3 position3 = transform3.position;
		Debug.Log("Player");
		InputDevice inputDevice;
		if (inputDevice != null)
		{
		}
		Transform transform4;
		UnityEngine.Object.Destroy(transform4.gameObject);
	}

	// Token: 0x06000CBD RID: 3261 RVA: 0x0001B4E0 File Offset: 0x000196E0
	[Token(Token = "0x6000CBD")]
	[Address(RVA = "0x2A0ABA8", Offset = "0x2A0ABA8", VA = "0x2A0ABA8")]
	private void method_9()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("Connected to Server.");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		Transform transform3;
		UnityEngine.Object.Destroy(transform3.gameObject);
	}

	// Token: 0x06000CBE RID: 3262 RVA: 0x0001B554 File Offset: 0x00019754
	[Token(Token = "0x6000CBE")]
	[Address(RVA = "0x2A0AEB0", Offset = "0x2A0AEB0", VA = "0x2A0AEB0")]
	private void method_10()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("Not connected to room");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform2;
			UnityEngine.Object.Destroy(transform2.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000CBF RID: 3263 RVA: 0x0001B5D8 File Offset: 0x000197D8
	[Address(RVA = "0x2A0B1C4", Offset = "0x2A0B1C4", VA = "0x2A0B1C4")]
	[Token(Token = "0x6000CBF")]
	private void method_11()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("true");
		InputDevice inputDevice;
		if (inputDevice != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CC0 RID: 3264 RVA: 0x0001B64C File Offset: 0x0001984C
	[Address(RVA = "0x2A0B4C8", Offset = "0x2A0B4C8", VA = "0x2A0B4C8")]
	[Token(Token = "0x6000CC0")]
	private void method_12()
	{
		Vector3 position = base.transform.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("Player");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform2;
			UnityEngine.Object.Destroy(transform2.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000CC1 RID: 3265 RVA: 0x0001B6D0 File Offset: 0x000198D0
	[Token(Token = "0x6000CC1")]
	[Address(RVA = "0x2A0B7DC", Offset = "0x2A0B7DC", VA = "0x2A0B7DC")]
	private void method_13()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("FingerTip");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000CC2 RID: 3266 RVA: 0x0001B758 File Offset: 0x00019958
	[Token(Token = "0x6000CC2")]
	[Address(RVA = "0x2A0BAF0", Offset = "0x2A0BAF0", VA = "0x2A0BAF0")]
	private void method_14()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("This is the 2500 Bananas button, and it was just clicked");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000CC3 RID: 3267 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A0BE04", Offset = "0x2A0BE04", VA = "0x2A0BE04")]
	[Token(Token = "0x6000CC3")]
	public DeleteAndroidDebugger()
	{
	}

	// Token: 0x06000CC4 RID: 3268 RVA: 0x0001B7E0 File Offset: 0x000199E0
	[Token(Token = "0x6000CC4")]
	[Address(RVA = "0x2A0BE0C", Offset = "0x2A0BE0C", VA = "0x2A0BE0C")]
	private void method_15()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("A new Player joined a Room.");
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			return;
		}
	}

	// Token: 0x06000CC5 RID: 3269 RVA: 0x0001B85C File Offset: 0x00019A5C
	[Address(RVA = "0x2A0C120", Offset = "0x2A0C120", VA = "0x2A0C120")]
	[Token(Token = "0x6000CC5")]
	private void method_16()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("tutorialCheck");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CC6 RID: 3270 RVA: 0x0001B8D8 File Offset: 0x00019AD8
	[Token(Token = "0x6000CC6")]
	[Address(RVA = "0x2A0C428", Offset = "0x2A0C428", VA = "0x2A0C428")]
	private void method_17()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("_BaseColor");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000CC7 RID: 3271 RVA: 0x0001B960 File Offset: 0x00019B60
	[Address(RVA = "0x2A0C73C", Offset = "0x2A0C73C", VA = "0x2A0C73C")]
	[Token(Token = "0x6000CC7")]
	private void method_18()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("2BN");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000CC8 RID: 3272 RVA: 0x0001B9E8 File Offset: 0x00019BE8
	[Token(Token = "0x6000CC8")]
	[Address(RVA = "0x2A0CA50", Offset = "0x2A0CA50", VA = "0x2A0CA50")]
	private void method_19()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("You Already Own This Item");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000CC9 RID: 3273 RVA: 0x0001BA70 File Offset: 0x00019C70
	[Token(Token = "0x6000CC9")]
	[Address(RVA = "0x2A0CD5C", Offset = "0x2A0CD5C", VA = "0x2A0CD5C")]
	private void method_20()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log(", ");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000CCA RID: 3274 RVA: 0x0001B180 File Offset: 0x00019380
	[Address(RVA = "0x2A0D064", Offset = "0x2A0D064", VA = "0x2A0D064")]
	[Token(Token = "0x6000CCA")]
	private void method_21()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("Player");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CCB RID: 3275 RVA: 0x0001BAF8 File Offset: 0x00019CF8
	[Token(Token = "0x6000CCB")]
	[Address(RVA = "0x2A0D36C", Offset = "0x2A0D36C", VA = "0x2A0D36C")]
	private void method_22()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			return;
		}
	}

	// Token: 0x06000CCC RID: 3276 RVA: 0x0001BB78 File Offset: 0x00019D78
	[Address(RVA = "0x2A0D680", Offset = "0x2A0D680", VA = "0x2A0D680")]
	[Token(Token = "0x6000CCC")]
	private void method_23()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("Connected to Server.");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000CCD RID: 3277 RVA: 0x0001BC00 File Offset: 0x00019E00
	[Address(RVA = "0x2A0D994", Offset = "0x2A0D994", VA = "0x2A0D994")]
	[Token(Token = "0x6000CCD")]
	private void method_24()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("/");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			return;
		}
	}

	// Token: 0x06000CCE RID: 3278 RVA: 0x0001BC80 File Offset: 0x00019E80
	[Token(Token = "0x6000CCE")]
	[Address(RVA = "0x2A0DCA8", Offset = "0x2A0DCA8", VA = "0x2A0DCA8")]
	private void method_25()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("Player");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		Transform transform3;
		UnityEngine.Object.Destroy(transform3.gameObject);
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000CCF RID: 3279 RVA: 0x0001BD00 File Offset: 0x00019F00
	[Token(Token = "0x6000CCF")]
	[Address(RVA = "0x2A0DFBC", Offset = "0x2A0DFBC", VA = "0x2A0DFBC")]
	private void method_26()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("User is on an outdated version of Capuchin. Your version is ");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
		}
	}

	// Token: 0x06000CD0 RID: 3280 RVA: 0x0001BD7C File Offset: 0x00019F7C
	[Token(Token = "0x6000CD0")]
	[Address(RVA = "0x2A0E2C4", Offset = "0x2A0E2C4", VA = "0x2A0E2C4")]
	private void method_27()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = base.transform.position;
		Transform transform2 = base.transform;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
		Vector3 position3 = base.transform.position;
		Debug.Log("DisableCosmetic");
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		if (!this.bool_0)
		{
			Transform transform3;
			UnityEngine.Object.Destroy(transform3.gameObject);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x040001D6 RID: 470
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001D6")]
	public XRNode xrnode_0;

	// Token: 0x040001D7 RID: 471
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40001D7")]
	private bool bool_0;
}
