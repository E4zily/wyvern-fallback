﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;

// Token: 0x020000BC RID: 188
[Token(Token = "0x20000BC")]
public class GClass1
{
	// Token: 0x06001ABF RID: 6847 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2182B04", Offset = "0x2182B04", VA = "0x2182B04")]
	[Token(Token = "0x6001ABF")]
	public static void smethod_0(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AC0 RID: 6848 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2182FB0", Offset = "0x2182FB0", VA = "0x2182FB0")]
	[Token(Token = "0x6001AC0")]
	public static void smethod_1(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AC1 RID: 6849 RVA: 0x000020B4 File Offset: 0x000002B4
	[Address(RVA = "0x218345C", Offset = "0x218345C", VA = "0x218345C")]
	[Token(Token = "0x6001AC1")]
	public GClass1()
	{
	}

	// Token: 0x06001AC2 RID: 6850 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2183464", Offset = "0x2183464", VA = "0x2183464")]
	[Token(Token = "0x6001AC2")]
	public static void smethod_2(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AC3 RID: 6851 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2183914", Offset = "0x2183914", VA = "0x2183914")]
	[Token(Token = "0x6001AC3")]
	public static void smethod_3(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AC4 RID: 6852 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2183DC0", Offset = "0x2183DC0", VA = "0x2183DC0")]
	[Token(Token = "0x6001AC4")]
	public static void smethod_4(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AC5 RID: 6853 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218426C", Offset = "0x218426C", VA = "0x218426C")]
	[Token(Token = "0x6001AC5")]
	public static void smethod_5(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AC6 RID: 6854 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218471C", Offset = "0x218471C", VA = "0x218471C")]
	[Token(Token = "0x6001AC6")]
	public static void smethod_6(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AC7 RID: 6855 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x2184BC8", Offset = "0x2184BC8", VA = "0x2184BC8")]
	[Token(Token = "0x6001AC7")]
	public static void smethod_7()
	{
	}

	// Token: 0x06001AC8 RID: 6856 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x2184CB0", Offset = "0x2184CB0", VA = "0x2184CB0")]
	[Token(Token = "0x6001AC8")]
	public static void smethod_8()
	{
	}

	// Token: 0x06001AC9 RID: 6857 RVA: 0x00034FBC File Offset: 0x000331BC
	[Address(RVA = "0x2184D98", Offset = "0x2184D98", VA = "0x2184D98")]
	[Token(Token = "0x6001AC9")]
	public static void smethod_9()
	{
	}

	// Token: 0x06001ACA RID: 6858 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2184E80", Offset = "0x2184E80", VA = "0x2184E80")]
	[Token(Token = "0x6001ACA")]
	public static void smethod_10(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001ACB RID: 6859 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218532C", Offset = "0x218532C", VA = "0x218532C")]
	[Token(Token = "0x6001ACB")]
	public static void smethod_11()
	{
	}

	// Token: 0x06001ACC RID: 6860 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2185414", Offset = "0x2185414", VA = "0x2185414")]
	[Token(Token = "0x6001ACC")]
	public static void smethod_12(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001ACD RID: 6861 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x21858C0", Offset = "0x21858C0", VA = "0x21858C0")]
	[Token(Token = "0x6001ACD")]
	public static void smethod_13()
	{
	}

	// Token: 0x06001ACE RID: 6862 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x21859A8", Offset = "0x21859A8", VA = "0x21859A8")]
	[Token(Token = "0x6001ACE")]
	public static void smethod_14()
	{
	}

	// Token: 0x06001ACF RID: 6863 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x2185A90", Offset = "0x2185A90", VA = "0x2185A90")]
	[Token(Token = "0x6001ACF")]
	public static void smethod_15()
	{
	}

	// Token: 0x06001AD0 RID: 6864 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x2185B78", Offset = "0x2185B78", VA = "0x2185B78")]
	[Token(Token = "0x6001AD0")]
	public static void smethod_16()
	{
	}

	// Token: 0x06001AD1 RID: 6865 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2185C60", Offset = "0x2185C60", VA = "0x2185C60")]
	[Token(Token = "0x6001AD1")]
	public static void smethod_17(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AD2 RID: 6866 RVA: 0x00034FCC File Offset: 0x000331CC
	[Address(RVA = "0x2186110", Offset = "0x2186110", VA = "0x2186110")]
	[Token(Token = "0x6001AD2")]
	public static void smethod_18()
	{
	}

	// Token: 0x06001AD3 RID: 6867 RVA: 0x00034FDC File Offset: 0x000331DC
	[Address(RVA = "0x21861F8", Offset = "0x21861F8", VA = "0x21861F8")]
	[Token(Token = "0x6001AD3")]
	public static void smethod_19()
	{
	}

	// Token: 0x06001AD4 RID: 6868 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x21862E0", Offset = "0x21862E0", VA = "0x21862E0")]
	[Token(Token = "0x6001AD4")]
	public static void smethod_20(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AD5 RID: 6869 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218678C", Offset = "0x218678C", VA = "0x218678C")]
	[Token(Token = "0x6001AD5")]
	public static void smethod_21(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AD6 RID: 6870 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x2186C3C", Offset = "0x2186C3C", VA = "0x2186C3C")]
	[Token(Token = "0x6001AD6")]
	public static void smethod_22()
	{
	}

	// Token: 0x06001AD7 RID: 6871 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2186D24", Offset = "0x2186D24", VA = "0x2186D24")]
	[Token(Token = "0x6001AD7")]
	public static void smethod_23(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AD8 RID: 6872 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x21871D0", Offset = "0x21871D0", VA = "0x21871D0")]
	[Token(Token = "0x6001AD8")]
	public static void smethod_24(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AD9 RID: 6873 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2187680", Offset = "0x2187680", VA = "0x2187680")]
	[Token(Token = "0x6001AD9")]
	public static void smethod_25(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001ADA RID: 6874 RVA: 0x00034FBC File Offset: 0x000331BC
	[Address(RVA = "0x2187B30", Offset = "0x2187B30", VA = "0x2187B30")]
	[Token(Token = "0x6001ADA")]
	public static void smethod_26()
	{
	}

	// Token: 0x06001ADB RID: 6875 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x2187C18", Offset = "0x2187C18", VA = "0x2187C18")]
	[Token(Token = "0x6001ADB")]
	public static void smethod_27()
	{
	}

	// Token: 0x06001ADC RID: 6876 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2187D00", Offset = "0x2187D00", VA = "0x2187D00")]
	[Token(Token = "0x6001ADC")]
	public static void smethod_28(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001ADD RID: 6877 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x21881AC", Offset = "0x21881AC", VA = "0x21881AC")]
	[Token(Token = "0x6001ADD")]
	public static void smethod_29(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001ADE RID: 6878 RVA: 0x00034FEC File Offset: 0x000331EC
	[Address(RVA = "0x218865C", Offset = "0x218865C", VA = "0x218865C")]
	[Token(Token = "0x6001ADE")]
	public static void smethod_30(string string_0)
	{
		string text;
		if (text != null)
		{
			return;
		}
		long messageIndex2 = 0L;
		ThrowHelper.ThrowArgumentOutOfRangeException();
		if (text != null)
		{
		}
		int messageIndex = (int)messageIndex2;
		if (text != null)
		{
		}
		if (text != null)
		{
		}
	}

	// Token: 0x06001ADF RID: 6879 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2188B0C", Offset = "0x2188B0C", VA = "0x2188B0C")]
	[Token(Token = "0x6001ADF")]
	public static void smethod_31(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AE0 RID: 6880 RVA: 0x00035024 File Offset: 0x00033224
	[Address(RVA = "0x2188FB8", Offset = "0x2188FB8", VA = "0x2188FB8")]
	[Token(Token = "0x6001AE0")]
	public static void smethod_32(string string_0)
	{
		Func<string, bool> func;
		string text = Enumerable.FirstOrDefault<string>(DisplayLogsToText.displayLogsToText_0.dictionary_0, func);
		if (text != null)
		{
			return;
		}
		ThrowHelper.ThrowArgumentOutOfRangeException();
		List<string> list_ = DisplayLogsToText.displayLogsToText_0.list_0;
		if (text != null)
		{
		}
		int messageIndex = list_;
		if (text != null)
		{
		}
		if (text != null)
		{
		}
	}

	// Token: 0x06001AE1 RID: 6881 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2189468", Offset = "0x2189468", VA = "0x2189468")]
	[Token(Token = "0x6001AE1")]
	public static void smethod_33(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AE2 RID: 6882 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2189914", Offset = "0x2189914", VA = "0x2189914")]
	[Token(Token = "0x6001AE2")]
	public static void smethod_34(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AE3 RID: 6883 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x2189DC4", Offset = "0x2189DC4", VA = "0x2189DC4")]
	[Token(Token = "0x6001AE3")]
	public static void smethod_35()
	{
	}

	// Token: 0x06001AE4 RID: 6884 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2189EAC", Offset = "0x2189EAC", VA = "0x2189EAC")]
	[Token(Token = "0x6001AE4")]
	public static void smethod_36(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AE5 RID: 6885 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218A35C", Offset = "0x218A35C", VA = "0x218A35C")]
	[Token(Token = "0x6001AE5")]
	public static void smethod_37()
	{
	}

	// Token: 0x06001AE6 RID: 6886 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218A444", Offset = "0x218A444", VA = "0x218A444")]
	[Token(Token = "0x6001AE6")]
	public static void smethod_38()
	{
	}

	// Token: 0x06001AE7 RID: 6887 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218A52C", Offset = "0x218A52C", VA = "0x218A52C")]
	[Token(Token = "0x6001AE7")]
	public static void smethod_39()
	{
	}

	// Token: 0x06001AE8 RID: 6888 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218A614", Offset = "0x218A614", VA = "0x218A614")]
	[Token(Token = "0x6001AE8")]
	public static void smethod_40(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AE9 RID: 6889 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218AAC0", Offset = "0x218AAC0", VA = "0x218AAC0")]
	[Token(Token = "0x6001AE9")]
	public static void smethod_41()
	{
	}

	// Token: 0x06001AEA RID: 6890 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218ABA8", Offset = "0x218ABA8", VA = "0x218ABA8")]
	[Token(Token = "0x6001AEA")]
	public static void smethod_42()
	{
	}

	// Token: 0x06001AEB RID: 6891 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218AC90", Offset = "0x218AC90", VA = "0x218AC90")]
	[Token(Token = "0x6001AEB")]
	public static void smethod_43(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AEC RID: 6892 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218B140", Offset = "0x218B140", VA = "0x218B140")]
	[Token(Token = "0x6001AEC")]
	public static void smethod_44()
	{
	}

	// Token: 0x06001AED RID: 6893 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218B228", Offset = "0x218B228", VA = "0x218B228")]
	[Token(Token = "0x6001AED")]
	public static void smethod_45()
	{
	}

	// Token: 0x06001AEE RID: 6894 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218B310", Offset = "0x218B310", VA = "0x218B310")]
	[Token(Token = "0x6001AEE")]
	public static void smethod_46()
	{
	}

	// Token: 0x06001AEF RID: 6895 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218B3F8", Offset = "0x218B3F8", VA = "0x218B3F8")]
	[Token(Token = "0x6001AEF")]
	public static void smethod_47()
	{
	}

	// Token: 0x06001AF0 RID: 6896 RVA: 0x00034FBC File Offset: 0x000331BC
	[Address(RVA = "0x218B4E0", Offset = "0x218B4E0", VA = "0x218B4E0")]
	[Token(Token = "0x6001AF0")]
	public static void smethod_48()
	{
	}

	// Token: 0x06001AF1 RID: 6897 RVA: 0x00034FAC File Offset: 0x000331AC
	[Address(RVA = "0x218B5C8", Offset = "0x218B5C8", VA = "0x218B5C8")]
	[Token(Token = "0x6001AF1")]
	public static void smethod_49()
	{
	}

	// Token: 0x06001AF2 RID: 6898 RVA: 0x00035078 File Offset: 0x00033278
	[Address(RVA = "0x218B6B0", Offset = "0x218B6B0", VA = "0x218B6B0")]
	[Token(Token = "0x6001AF2")]
	public static void smethod_50(string string_0)
	{
		string text;
		if (text != null)
		{
			return;
		}
		long messageIndex2 = 0L;
		ThrowHelper.ThrowArgumentOutOfRangeException();
		if (text != null)
		{
		}
		int messageIndex = (int)messageIndex2;
		if (text != null)
		{
		}
		if (text != null)
		{
		}
	}

	// Token: 0x06001AF3 RID: 6899 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218BB5C", Offset = "0x218BB5C", VA = "0x218BB5C")]
	[Token(Token = "0x6001AF3")]
	public static void smethod_51(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001AF4 RID: 6900 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218C008", Offset = "0x218C008", VA = "0x218C008")]
	[Token(Token = "0x6001AF4")]
	public static void smethod_52(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x020000BD RID: 189
	[Token(Token = "0x20000BD")]
	[CompilerGenerated]
	private sealed class Class26
	{
		// Token: 0x06001AF5 RID: 6901 RVA: 0x000020B4 File Offset: 0x000002B4
		[Address(RVA = "0x107771C", Offset = "0x107771C", VA = "0x107771C")]
		[Token(Token = "0x6001AF5")]
		public Class26()
		{
		}

		// Token: 0x06001AF6 RID: 6902 RVA: 0x000350B0 File Offset: 0x000332B0
		[Address(RVA = "0x1077724", Offset = "0x1077724", VA = "0x1077724")]
		[Token(Token = "0x6001AF6")]
		internal bool method_0(string m)
		{
			string value = this.message;
			return m.Equals(value);
		}

		// Token: 0x06001AF7 RID: 6903 RVA: 0x000350CC File Offset: 0x000332CC
		[Address(RVA = "0x1077748", Offset = "0x1077748", VA = "0x1077748")]
		[Token(Token = "0x6001AF7")]
		internal string method_1(string m, int i)
		{
			return this.messageWithCount;
		}

		// Token: 0x04000373 RID: 883
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000373")]
		public string message;

		// Token: 0x04000374 RID: 884
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000374")]
		public int messageIndex;

		// Token: 0x04000375 RID: 885
		[Token(Token = "0x4000375")]
		[FieldOffset(Offset = "0x20")]
		public string messageWithCount;
	}
}
