﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000B4 RID: 180
[Token(Token = "0x20000B4")]
public class Clothing : MonoBehaviour
{
	// Token: 0x060019E8 RID: 6632 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2AF4094", Offset = "0x2AF4094", VA = "0x2AF4094")]
	[Token(Token = "0x60019E8")]
	public Clothing()
	{
	}

	// Token: 0x060019E9 RID: 6633 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF409C", Offset = "0x2AF409C", VA = "0x2AF409C")]
	[Token(Token = "0x60019E9")]
	private void method_0()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019EA RID: 6634 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF411C", Offset = "0x2AF411C", VA = "0x2AF411C")]
	[Token(Token = "0x60019EA")]
	private void method_1()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019EB RID: 6635 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF419C", Offset = "0x2AF419C", VA = "0x2AF419C")]
	[Token(Token = "0x60019EB")]
	private void method_2()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019EC RID: 6636 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF421C", Offset = "0x2AF421C", VA = "0x2AF421C")]
	[Token(Token = "0x60019EC")]
	private void method_3()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019ED RID: 6637 RVA: 0x000339A0 File Offset: 0x00031BA0
	[Address(RVA = "0x2AF429C", Offset = "0x2AF429C", VA = "0x2AF429C")]
	[Token(Token = "0x60019ED")]
	private void method_4()
	{
		Transform transform = base.transform;
		Vector3 position = transform.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019EE RID: 6638 RVA: 0x000339D0 File Offset: 0x00031BD0
	[Address(RVA = "0x2AF431C", Offset = "0x2AF431C", VA = "0x2AF431C")]
	[Token(Token = "0x60019EE")]
	private void method_5()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019EF RID: 6639 RVA: 0x000339A0 File Offset: 0x00031BA0
	[Token(Token = "0x60019EF")]
	[Address(RVA = "0x2AF439C", Offset = "0x2AF439C", VA = "0x2AF439C")]
	private void method_6()
	{
		Transform transform = base.transform;
		Vector3 position = transform.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019F0 RID: 6640 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF441C", Offset = "0x2AF441C", VA = "0x2AF441C")]
	[Token(Token = "0x60019F0")]
	private void method_7()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019F1 RID: 6641 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF449C", Offset = "0x2AF449C", VA = "0x2AF449C")]
	[Token(Token = "0x60019F1")]
	private void method_8()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019F2 RID: 6642 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF451C", Offset = "0x2AF451C", VA = "0x2AF451C")]
	[Token(Token = "0x60019F2")]
	private void method_9()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019F3 RID: 6643 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF459C", Offset = "0x2AF459C", VA = "0x2AF459C")]
	[Token(Token = "0x60019F3")]
	private void method_10()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019F4 RID: 6644 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF461C", Offset = "0x2AF461C", VA = "0x2AF461C")]
	[Token(Token = "0x60019F4")]
	private void Update()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019F5 RID: 6645 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF469C", Offset = "0x2AF469C", VA = "0x2AF469C")]
	[Token(Token = "0x60019F5")]
	private void method_11()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019F6 RID: 6646 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF471C", Offset = "0x2AF471C", VA = "0x2AF471C")]
	[Token(Token = "0x60019F6")]
	private void method_12()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019F7 RID: 6647 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF479C", Offset = "0x2AF479C", VA = "0x2AF479C")]
	[Token(Token = "0x60019F7")]
	private void method_13()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019F8 RID: 6648 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF481C", Offset = "0x2AF481C", VA = "0x2AF481C")]
	[Token(Token = "0x60019F8")]
	private void method_14()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019F9 RID: 6649 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF489C", Offset = "0x2AF489C", VA = "0x2AF489C")]
	[Token(Token = "0x60019F9")]
	private void method_15()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019FA RID: 6650 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF491C", Offset = "0x2AF491C", VA = "0x2AF491C")]
	[Token(Token = "0x60019FA")]
	private void method_16()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019FB RID: 6651 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF499C", Offset = "0x2AF499C", VA = "0x2AF499C")]
	[Token(Token = "0x60019FB")]
	private void method_17()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019FC RID: 6652 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4A1C", Offset = "0x2AF4A1C", VA = "0x2AF4A1C")]
	[Token(Token = "0x60019FC")]
	private void method_18()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019FD RID: 6653 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4A9C", Offset = "0x2AF4A9C", VA = "0x2AF4A9C")]
	[Token(Token = "0x60019FD")]
	private void method_19()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019FE RID: 6654 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4B1C", Offset = "0x2AF4B1C", VA = "0x2AF4B1C")]
	[Token(Token = "0x60019FE")]
	private void method_20()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x060019FF RID: 6655 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4B9C", Offset = "0x2AF4B9C", VA = "0x2AF4B9C")]
	[Token(Token = "0x60019FF")]
	private void method_21()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A00 RID: 6656 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4C1C", Offset = "0x2AF4C1C", VA = "0x2AF4C1C")]
	[Token(Token = "0x6001A00")]
	private void method_22()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A01 RID: 6657 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4C9C", Offset = "0x2AF4C9C", VA = "0x2AF4C9C")]
	[Token(Token = "0x6001A01")]
	private void method_23()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A02 RID: 6658 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4D1C", Offset = "0x2AF4D1C", VA = "0x2AF4D1C")]
	[Token(Token = "0x6001A02")]
	private void method_24()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A03 RID: 6659 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4D9C", Offset = "0x2AF4D9C", VA = "0x2AF4D9C")]
	[Token(Token = "0x6001A03")]
	private void method_25()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A04 RID: 6660 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4E1C", Offset = "0x2AF4E1C", VA = "0x2AF4E1C")]
	[Token(Token = "0x6001A04")]
	private void method_26()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A05 RID: 6661 RVA: 0x000339D0 File Offset: 0x00031BD0
	[Address(RVA = "0x2AF4E9C", Offset = "0x2AF4E9C", VA = "0x2AF4E9C")]
	[Token(Token = "0x6001A05")]
	private void method_27()
	{
		Vector3 position = base.transform.position;
		Transform transform = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A06 RID: 6662 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4F1C", Offset = "0x2AF4F1C", VA = "0x2AF4F1C")]
	[Token(Token = "0x6001A06")]
	private void method_28()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A07 RID: 6663 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF4F9C", Offset = "0x2AF4F9C", VA = "0x2AF4F9C")]
	[Token(Token = "0x6001A07")]
	private void method_29()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A08 RID: 6664 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF501C", Offset = "0x2AF501C", VA = "0x2AF501C")]
	[Token(Token = "0x6001A08")]
	private void method_30()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A09 RID: 6665 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF509C", Offset = "0x2AF509C", VA = "0x2AF509C")]
	[Token(Token = "0x6001A09")]
	private void method_31()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A0A RID: 6666 RVA: 0x000339FC File Offset: 0x00031BFC
	[Address(RVA = "0x2AF511C", Offset = "0x2AF511C", VA = "0x2AF511C")]
	[Token(Token = "0x6001A0A")]
	private void method_32()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = transform2.rotation;
	}

	// Token: 0x06001A0B RID: 6667 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF519C", Offset = "0x2AF519C", VA = "0x2AF519C")]
	[Token(Token = "0x6001A0B")]
	private void method_33()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A0C RID: 6668 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF521C", Offset = "0x2AF521C", VA = "0x2AF521C")]
	[Token(Token = "0x6001A0C")]
	private void method_34()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A0D RID: 6669 RVA: 0x000339A0 File Offset: 0x00031BA0
	[Address(RVA = "0x2AF529C", Offset = "0x2AF529C", VA = "0x2AF529C")]
	[Token(Token = "0x6001A0D")]
	private void method_35()
	{
		Transform transform = base.transform;
		Vector3 position = transform.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A0E RID: 6670 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF531C", Offset = "0x2AF531C", VA = "0x2AF531C")]
	[Token(Token = "0x6001A0E")]
	private void method_36()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x06001A0F RID: 6671 RVA: 0x0003396C File Offset: 0x00031B6C
	[Address(RVA = "0x2AF539C", Offset = "0x2AF539C", VA = "0x2AF539C")]
	[Token(Token = "0x6001A0F")]
	private void method_37()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = base.transform;
		Quaternion rotation = this.transform_0.rotation;
	}

	// Token: 0x04000358 RID: 856
	[Token(Token = "0x4000358")]
	[FieldOffset(Offset = "0x18")]
	public Transform transform_0;
}
