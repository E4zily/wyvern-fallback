﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200002C RID: 44
[Token(Token = "0x200002C")]
public class HandScriptNetwork : MonoBehaviour
{
	// Token: 0x06000557 RID: 1367 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x6000557")]
	[Address(RVA = "0x3637508", Offset = "0x3637508", VA = "0x3637508")]
	public void method_0()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000558 RID: 1368 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x6000558")]
	[Address(RVA = "0x3637544", Offset = "0x3637544", VA = "0x3637544")]
	public void method_1()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000559 RID: 1369 RVA: 0x0000F398 File Offset: 0x0000D598
	[Token(Token = "0x6000559")]
	[Address(RVA = "0x3637580", Offset = "0x3637580", VA = "0x3637580")]
	public void method_2()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600055A RID: 1370 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x36375BC", Offset = "0x36375BC", VA = "0x36375BC")]
	[Token(Token = "0x600055A")]
	public void method_3()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600055B RID: 1371 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x36375F8", Offset = "0x36375F8", VA = "0x36375F8")]
	[Token(Token = "0x600055B")]
	public void method_4()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600055C RID: 1372 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Address(RVA = "0x3637634", Offset = "0x3637634", VA = "0x3637634")]
	[Token(Token = "0x600055C")]
	public void method_5()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600055D RID: 1373 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x3637670", Offset = "0x3637670", VA = "0x3637670")]
	[Token(Token = "0x600055D")]
	public void method_6()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600055E RID: 1374 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x36376AC", Offset = "0x36376AC", VA = "0x36376AC")]
	[Token(Token = "0x600055E")]
	public void method_7()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600055F RID: 1375 RVA: 0x0000F3E0 File Offset: 0x0000D5E0
	[Token(Token = "0x600055F")]
	[Address(RVA = "0x36376E8", Offset = "0x36376E8", VA = "0x36376E8")]
	public void method_8()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		long enabled = 1L;
		base.enabled = (enabled != 0L);
	}

	// Token: 0x06000560 RID: 1376 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x3637724", Offset = "0x3637724", VA = "0x3637724")]
	[Token(Token = "0x6000560")]
	public void method_9()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000561 RID: 1377 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x6000561")]
	[Address(RVA = "0x3637760", Offset = "0x3637760", VA = "0x3637760")]
	public void method_10()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000562 RID: 1378 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x363779C", Offset = "0x363779C", VA = "0x363779C")]
	[Token(Token = "0x6000562")]
	public void method_11()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000563 RID: 1379 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x36377D8", Offset = "0x36377D8", VA = "0x36377D8")]
	[Token(Token = "0x6000563")]
	public void method_12()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000564 RID: 1380 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x6000564")]
	[Address(RVA = "0x3637814", Offset = "0x3637814", VA = "0x3637814")]
	public void method_13()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000565 RID: 1381 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Address(RVA = "0x3637850", Offset = "0x3637850", VA = "0x3637850")]
	[Token(Token = "0x6000565")]
	public void method_14()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000566 RID: 1382 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Address(RVA = "0x363788C", Offset = "0x363788C", VA = "0x363788C")]
	[Token(Token = "0x6000566")]
	public void method_15()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000567 RID: 1383 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x6000567")]
	[Address(RVA = "0x36378C8", Offset = "0x36378C8", VA = "0x36378C8")]
	public void method_16()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000568 RID: 1384 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x3637904", Offset = "0x3637904", VA = "0x3637904")]
	[Token(Token = "0x6000568")]
	public void method_17()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000569 RID: 1385 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Address(RVA = "0x3637940", Offset = "0x3637940", VA = "0x3637940")]
	[Token(Token = "0x6000569")]
	public void method_18()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600056A RID: 1386 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Token(Token = "0x600056A")]
	[Address(RVA = "0x363797C", Offset = "0x363797C", VA = "0x363797C")]
	public void method_19()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600056B RID: 1387 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x36379B8", Offset = "0x36379B8", VA = "0x36379B8")]
	[Token(Token = "0x600056B")]
	public void method_20()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600056C RID: 1388 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Token(Token = "0x600056C")]
	[Address(RVA = "0x36379F4", Offset = "0x36379F4", VA = "0x36379F4")]
	public void method_21()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600056D RID: 1389 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Address(RVA = "0x3637A30", Offset = "0x3637A30", VA = "0x3637A30")]
	[Token(Token = "0x600056D")]
	public void method_22()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600056E RID: 1390 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x600056E")]
	[Address(RVA = "0x3637A6C", Offset = "0x3637A6C", VA = "0x3637A6C")]
	public void method_23()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600056F RID: 1391 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x3637AA8", Offset = "0x3637AA8", VA = "0x3637AA8")]
	[Token(Token = "0x600056F")]
	public void method_24()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000570 RID: 1392 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x3637AE4", Offset = "0x3637AE4", VA = "0x3637AE4")]
	[Token(Token = "0x6000570")]
	public void method_25()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000571 RID: 1393 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x3637B20", Offset = "0x3637B20", VA = "0x3637B20")]
	[Token(Token = "0x6000571")]
	public void Start()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000572 RID: 1394 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Address(RVA = "0x3637B5C", Offset = "0x3637B5C", VA = "0x3637B5C")]
	[Token(Token = "0x6000572")]
	public void method_26()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000573 RID: 1395 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x3637B98", Offset = "0x3637B98", VA = "0x3637B98")]
	[Token(Token = "0x6000573")]
	public void method_27()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000574 RID: 1396 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x6000574")]
	[Address(RVA = "0x3637BD4", Offset = "0x3637BD4", VA = "0x3637BD4")]
	public void method_28()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Address(RVA = "0x3637C10", Offset = "0x3637C10", VA = "0x3637C10")]
	[Token(Token = "0x6000575")]
	public void method_29()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Address(RVA = "0x3637C4C", Offset = "0x3637C4C", VA = "0x3637C4C")]
	[Token(Token = "0x6000576")]
	public void method_30()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000577 RID: 1399 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x6000577")]
	[Address(RVA = "0x3637C88", Offset = "0x3637C88", VA = "0x3637C88")]
	public void method_31()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x06000578 RID: 1400 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000578")]
	[Address(RVA = "0x3637CC4", Offset = "0x3637CC4", VA = "0x3637CC4")]
	public HandScriptNetwork()
	{
	}

	// Token: 0x06000579 RID: 1401 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Token(Token = "0x6000579")]
	[Address(RVA = "0x3637CCC", Offset = "0x3637CCC", VA = "0x3637CCC")]
	public void method_32()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600057A RID: 1402 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x600057A")]
	[Address(RVA = "0x3637D08", Offset = "0x3637D08", VA = "0x3637D08")]
	public void method_33()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600057B RID: 1403 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Token(Token = "0x600057B")]
	[Address(RVA = "0x3637D44", Offset = "0x3637D44", VA = "0x3637D44")]
	public void method_34()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600057C RID: 1404 RVA: 0x0000F36C File Offset: 0x0000D56C
	[Address(RVA = "0x3637D80", Offset = "0x3637D80", VA = "0x3637D80")]
	[Token(Token = "0x600057C")]
	public void method_35()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 1L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x0600057D RID: 1405 RVA: 0x0000F3B4 File Offset: 0x0000D5B4
	[Address(RVA = "0x3637DBC", Offset = "0x3637DBC", VA = "0x3637DBC")]
	[Token(Token = "0x600057D")]
	public void method_36()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		HandScript handScript = this.handScript_0;
		long enabled = 0L;
		handScript.enabled = (enabled != 0L);
	}

	// Token: 0x040000CB RID: 203
	[Token(Token = "0x40000CB")]
	[FieldOffset(Offset = "0x18")]
	public HandScript handScript_0;

	// Token: 0x040000CC RID: 204
	[Token(Token = "0x40000CC")]
	[FieldOffset(Offset = "0x20")]
	public PhotonView photonView_0;
}
