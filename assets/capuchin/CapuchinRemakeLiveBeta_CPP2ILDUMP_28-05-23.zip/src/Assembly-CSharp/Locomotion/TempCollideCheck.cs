﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Locomotion
{
	// Token: 0x02000184 RID: 388
	[Token(Token = "0x2000184")]
	public class TempCollideCheck : MonoBehaviour
	{
		// Token: 0x06003B62 RID: 15202 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BE760", Offset = "0x25BE760", VA = "0x25BE760")]
		[Token(Token = "0x6003B62")]
		private void method_0(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B63 RID: 15203 RVA: 0x00024CB4 File Offset: 0x00022EB4
		[Address(RVA = "0x25BE7D4", Offset = "0x25BE7D4", VA = "0x25BE7D4")]
		[Token(Token = "0x6003B63")]
		private void method_1(Collision collision_0)
		{
		}

		// Token: 0x06003B64 RID: 15204 RVA: 0x00074E9C File Offset: 0x0007309C
		[Address(RVA = "0x25BE848", Offset = "0x25BE848", VA = "0x25BE848")]
		[Token(Token = "0x6003B64")]
		private void method_2()
		{
			base.gameObject.name == "spatial";
			this.bool_0 = ("spatial" != null);
		}

		// Token: 0x06003B65 RID: 15205 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BE8BC", Offset = "0x25BE8BC", VA = "0x25BE8BC")]
		[Token(Token = "0x6003B65")]
		private void method_3(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B66 RID: 15206 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BE930", Offset = "0x25BE930", VA = "0x25BE930")]
		[Token(Token = "0x6003B66")]
		private void method_4(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B67 RID: 15207 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BE9A4", Offset = "0x25BE9A4", VA = "0x25BE9A4")]
		[Token(Token = "0x6003B67")]
		private void method_5(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B68 RID: 15208 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25BEA18", Offset = "0x25BEA18", VA = "0x25BEA18")]
		[Token(Token = "0x6003B68")]
		private void method_6(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B69 RID: 15209 RVA: 0x00074EEC File Offset: 0x000730EC
		[Address(RVA = "0x25BEA8C", Offset = "0x25BEA8C", VA = "0x25BEA8C")]
		[Token(Token = "0x6003B69")]
		private void method_7()
		{
			base.gameObject.name == "Tagging";
			this.bool_0 = ("Tagging" != null);
		}

		// Token: 0x06003B6A RID: 15210 RVA: 0x00074F1C File Offset: 0x0007311C
		[Address(RVA = "0x25BEB00", Offset = "0x25BEB00", VA = "0x25BEB00")]
		[Token(Token = "0x6003B6A")]
		private void method_8()
		{
			base.gameObject.name == "Player";
			this.bool_0 = ("Player" != null);
		}

		// Token: 0x06003B6B RID: 15211 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25BEB74", Offset = "0x25BEB74", VA = "0x25BEB74")]
		[Token(Token = "0x6003B6B")]
		private void method_9(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B6C RID: 15212 RVA: 0x00074F4C File Offset: 0x0007314C
		[Address(RVA = "0x25BEBE8", Offset = "0x25BEBE8", VA = "0x25BEBE8")]
		[Token(Token = "0x6003B6C")]
		private void method_10()
		{
			base.gameObject.name == "false";
			this.bool_0 = ("false" != null);
		}

		// Token: 0x06003B6D RID: 15213 RVA: 0x00074F7C File Offset: 0x0007317C
		[Address(RVA = "0x25BEC5C", Offset = "0x25BEC5C", VA = "0x25BEC5C")]
		[Token(Token = "0x6003B6D")]
		private void method_11(Collision collision_0)
		{
		}

		// Token: 0x06003B6E RID: 15214 RVA: 0x00074F7C File Offset: 0x0007317C
		[Address(RVA = "0x25BECD0", Offset = "0x25BECD0", VA = "0x25BECD0")]
		[Token(Token = "0x6003B6E")]
		private void method_12(Collision collision_0)
		{
		}

		// Token: 0x06003B6F RID: 15215 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25BED44", Offset = "0x25BED44", VA = "0x25BED44")]
		[Token(Token = "0x6003B6F")]
		private void OnCollisionEnter(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B70 RID: 15216 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BEDB8", Offset = "0x25BEDB8", VA = "0x25BEDB8")]
		[Token(Token = "0x6003B70")]
		private void method_13(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B71 RID: 15217 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x25BEE2C", Offset = "0x25BEE2C", VA = "0x25BEE2C")]
		[Token(Token = "0x6003B71")]
		private void method_14(Collision collision_0)
		{
		}

		// Token: 0x06003B72 RID: 15218 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BEEA0", Offset = "0x25BEEA0", VA = "0x25BEEA0")]
		[Token(Token = "0x6003B72")]
		private void method_15(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B73 RID: 15219 RVA: 0x00074F8C File Offset: 0x0007318C
		[Address(RVA = "0x25BEF14", Offset = "0x25BEF14", VA = "0x25BEF14")]
		[Token(Token = "0x6003B73")]
		private void method_16()
		{
			base.gameObject.name == "FingerTip";
			this.bool_0 = ("FingerTip" != null);
		}

		// Token: 0x06003B74 RID: 15220 RVA: 0x00074F7C File Offset: 0x0007317C
		[Address(RVA = "0x25BEF88", Offset = "0x25BEF88", VA = "0x25BEF88")]
		[Token(Token = "0x6003B74")]
		private void method_17(Collision collision_0)
		{
		}

		// Token: 0x06003B75 RID: 15221 RVA: 0x00074FBC File Offset: 0x000731BC
		[Token(Token = "0x6003B75")]
		[Address(RVA = "0x25BEFFC", Offset = "0x25BEFFC", VA = "0x25BEFFC")]
		private void method_18()
		{
			GameObject gameObject;
			gameObject.name == "waited for your bullshit unity grrr";
		}

		// Token: 0x06003B76 RID: 15222 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25BF070", Offset = "0x25BF070", VA = "0x25BF070")]
		[Token(Token = "0x6003B76")]
		private void method_19(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B77 RID: 15223 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25BF0E4", Offset = "0x25BF0E4", VA = "0x25BF0E4")]
		[Token(Token = "0x6003B77")]
		private void method_20(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B78 RID: 15224 RVA: 0x00074FDC File Offset: 0x000731DC
		[Address(RVA = "0x25BF158", Offset = "0x25BF158", VA = "0x25BF158")]
		[Token(Token = "0x6003B78")]
		private void method_21()
		{
			base.gameObject.name == "DisableCosmetic";
			this.bool_0 = ("DisableCosmetic" != null);
		}

		// Token: 0x06003B79 RID: 15225 RVA: 0x0007500C File Offset: 0x0007320C
		[Address(RVA = "0x25BF1CC", Offset = "0x25BF1CC", VA = "0x25BF1CC")]
		[Token(Token = "0x6003B79")]
		private void method_22()
		{
			base.gameObject.name == "Cannot access index {0}. Buffer size is {1}";
			this.bool_0 = ("Cannot access index {0}. Buffer size is {1}" != null);
		}

		// Token: 0x06003B7A RID: 15226 RVA: 0x00074ECC File Offset: 0x000730CC
		[Token(Token = "0x6003B7A")]
		[Address(RVA = "0x25BF240", Offset = "0x25BF240", VA = "0x25BF240")]
		private void method_23(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B7B RID: 15227 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BF2B4", Offset = "0x25BF2B4", VA = "0x25BF2B4")]
		[Token(Token = "0x6003B7B")]
		private void method_24(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B7C RID: 15228 RVA: 0x0007503C File Offset: 0x0007323C
		[Address(RVA = "0x25BF328", Offset = "0x25BF328", VA = "0x25BF328")]
		[Token(Token = "0x6003B7C")]
		private void method_25()
		{
			base.gameObject.name == ", ";
			this.bool_0 = (", " != null);
		}

		// Token: 0x06003B7D RID: 15229 RVA: 0x0007506C File Offset: 0x0007326C
		[Address(RVA = "0x25BF39C", Offset = "0x25BF39C", VA = "0x25BF39C")]
		[Token(Token = "0x6003B7D")]
		private void method_26()
		{
			base.gameObject.name == "CapuchinStore";
			this.bool_0 = ("CapuchinStore" != null);
		}

		// Token: 0x06003B7E RID: 15230 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BF410", Offset = "0x25BF410", VA = "0x25BF410")]
		[Token(Token = "0x6003B7E")]
		private void method_27(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B7F RID: 15231 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25BF484", Offset = "0x25BF484", VA = "0x25BF484")]
		[Token(Token = "0x6003B7F")]
		private void method_28(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B80 RID: 15232 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x25BF4F8", Offset = "0x25BF4F8", VA = "0x25BF4F8")]
		[Token(Token = "0x6003B80")]
		public TempCollideCheck()
		{
		}

		// Token: 0x06003B81 RID: 15233 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BF500", Offset = "0x25BF500", VA = "0x25BF500")]
		[Token(Token = "0x6003B81")]
		private void method_29(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B82 RID: 15234 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BF574", Offset = "0x25BF574", VA = "0x25BF574")]
		[Token(Token = "0x6003B82")]
		private void method_30(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B83 RID: 15235 RVA: 0x00074F7C File Offset: 0x0007317C
		[Address(RVA = "0x25BF5E8", Offset = "0x25BF5E8", VA = "0x25BF5E8")]
		[Token(Token = "0x6003B83")]
		private void method_31(Collision collision_0)
		{
		}

		// Token: 0x06003B84 RID: 15236 RVA: 0x00074F7C File Offset: 0x0007317C
		[Token(Token = "0x6003B84")]
		[Address(RVA = "0x25BF65C", Offset = "0x25BF65C", VA = "0x25BF65C")]
		private void method_32(Collision collision_0)
		{
		}

		// Token: 0x06003B85 RID: 15237 RVA: 0x0007509C File Offset: 0x0007329C
		[Address(RVA = "0x25BF6D0", Offset = "0x25BF6D0", VA = "0x25BF6D0")]
		[Token(Token = "0x6003B85")]
		private void method_33()
		{
			GameObject gameObject;
			gameObject.name == "Failed To Join Public Room Successfully. The error is: ";
		}

		// Token: 0x06003B86 RID: 15238 RVA: 0x000750BC File Offset: 0x000732BC
		[Address(RVA = "0x25BF744", Offset = "0x25BF744", VA = "0x25BF744")]
		[Token(Token = "0x6003B86")]
		private void method_34()
		{
			base.gameObject.name == "clickLol";
		}

		// Token: 0x06003B87 RID: 15239 RVA: 0x000750E0 File Offset: 0x000732E0
		[Token(Token = "0x6003B87")]
		[Address(RVA = "0x25BF7B8", Offset = "0x25BF7B8", VA = "0x25BF7B8")]
		private void method_35()
		{
			GameObject gameObject;
			gameObject.name == "Regular";
		}

		// Token: 0x06003B88 RID: 15240 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25BF82C", Offset = "0x25BF82C", VA = "0x25BF82C")]
		[Token(Token = "0x6003B88")]
		private void method_36(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B89 RID: 15241 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BF8A0", Offset = "0x25BF8A0", VA = "0x25BF8A0")]
		[Token(Token = "0x6003B89")]
		private void method_37(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B8A RID: 15242 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BF914", Offset = "0x25BF914", VA = "0x25BF914")]
		[Token(Token = "0x6003B8A")]
		private void method_38(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B8B RID: 15243 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BF988", Offset = "0x25BF988", VA = "0x25BF988")]
		[Token(Token = "0x6003B8B")]
		private void method_39(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B8C RID: 15244 RVA: 0x00075100 File Offset: 0x00073300
		[Address(RVA = "0x25BF9FC", Offset = "0x25BF9FC", VA = "0x25BF9FC")]
		[Token(Token = "0x6003B8C")]
		private void method_40()
		{
			base.gameObject.name == "Failed To Join Public Room Successfully. The error is: ";
			this.bool_0 = ("Failed To Join Public Room Successfully. The error is: " != null);
		}

		// Token: 0x06003B8D RID: 15245 RVA: 0x00075130 File Offset: 0x00073330
		[Address(RVA = "0x25BFA70", Offset = "0x25BFA70", VA = "0x25BFA70")]
		[Token(Token = "0x6003B8D")]
		private void method_41()
		{
			base.gameObject.name == "deathScream";
			this.bool_0 = ("deathScream" != null);
		}

		// Token: 0x06003B8E RID: 15246 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BFAE4", Offset = "0x25BFAE4", VA = "0x25BFAE4")]
		[Token(Token = "0x6003B8E")]
		private void method_42(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B8F RID: 15247 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BFB58", Offset = "0x25BFB58", VA = "0x25BFB58")]
		[Token(Token = "0x6003B8F")]
		private void method_43(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B90 RID: 15248 RVA: 0x00075160 File Offset: 0x00073360
		[Address(RVA = "0x25BFBCC", Offset = "0x25BFBCC", VA = "0x25BFBCC")]
		[Token(Token = "0x6003B90")]
		private void method_44()
		{
			base.gameObject.name == "https://raw.githubusercontent.com/";
			this.bool_0 = ("https://raw.githubusercontent.com/" != null);
		}

		// Token: 0x06003B91 RID: 15249 RVA: 0x00075190 File Offset: 0x00073390
		[Address(RVA = "0x25BFC40", Offset = "0x25BFC40", VA = "0x25BFC40")]
		[Token(Token = "0x6003B91")]
		private void method_45()
		{
			base.gameObject.name == "SetColor";
			this.bool_0 = ("SetColor" != null);
		}

		// Token: 0x06003B92 RID: 15250 RVA: 0x00074F4C File Offset: 0x0007314C
		[Token(Token = "0x6003B92")]
		[Address(RVA = "0x25BFCB4", Offset = "0x25BFCB4", VA = "0x25BFCB4")]
		private void method_46()
		{
			base.gameObject.name == "false";
			this.bool_0 = ("false" != null);
		}

		// Token: 0x06003B93 RID: 15251 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25BFD28", Offset = "0x25BFD28", VA = "0x25BFD28")]
		[Token(Token = "0x6003B93")]
		private void method_47(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B94 RID: 15252 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25BFD9C", Offset = "0x25BFD9C", VA = "0x25BFD9C")]
		[Token(Token = "0x6003B94")]
		private void method_48(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B95 RID: 15253 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BFE10", Offset = "0x25BFE10", VA = "0x25BFE10")]
		[Token(Token = "0x6003B95")]
		private void method_49(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B96 RID: 15254 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25BFE84", Offset = "0x25BFE84", VA = "0x25BFE84")]
		[Token(Token = "0x6003B96")]
		private void method_50(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B97 RID: 15255 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25BFEF8", Offset = "0x25BFEF8", VA = "0x25BFEF8")]
		[Token(Token = "0x6003B97")]
		private void method_51(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B98 RID: 15256 RVA: 0x000751C0 File Offset: 0x000733C0
		[Address(RVA = "0x25BFF6C", Offset = "0x25BFF6C", VA = "0x25BFF6C")]
		[Token(Token = "0x6003B98")]
		private void method_52()
		{
			base.gameObject.name == "Vector1_d371bd24217449349bd747533d51af6b";
			this.bool_0 = ("Vector1_d371bd24217449349bd747533d51af6b" != null);
		}

		// Token: 0x06003B99 RID: 15257 RVA: 0x00074E7C File Offset: 0x0007307C
		[Token(Token = "0x6003B99")]
		[Address(RVA = "0x25BFFE0", Offset = "0x25BFFE0", VA = "0x25BFFE0")]
		private void method_53(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B9A RID: 15258 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25C0054", Offset = "0x25C0054", VA = "0x25C0054")]
		[Token(Token = "0x6003B9A")]
		private void method_54(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B9B RID: 15259 RVA: 0x000751F0 File Offset: 0x000733F0
		[Token(Token = "0x6003B9B")]
		[Address(RVA = "0x25C00C8", Offset = "0x25C00C8", VA = "0x25C00C8")]
		private void method_55()
		{
			base.gameObject.name == "down unstuck";
			this.bool_0 = ("down unstuck" != null);
		}

		// Token: 0x06003B9C RID: 15260 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25C013C", Offset = "0x25C013C", VA = "0x25C013C")]
		[Token(Token = "0x6003B9C")]
		private void OnCollisionExit(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B9D RID: 15261 RVA: 0x00075220 File Offset: 0x00073420
		[Address(RVA = "0x25C01B0", Offset = "0x25C01B0", VA = "0x25C01B0")]
		[Token(Token = "0x6003B9D")]
		private void method_56()
		{
			base.gameObject.name == "gameMode";
			this.bool_0 = ("gameMode" != null);
		}

		// Token: 0x06003B9E RID: 15262 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25C0224", Offset = "0x25C0224", VA = "0x25C0224")]
		[Token(Token = "0x6003B9E")]
		private void method_57(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003B9F RID: 15263 RVA: 0x00074F7C File Offset: 0x0007317C
		[Token(Token = "0x6003B9F")]
		[Address(RVA = "0x25C0298", Offset = "0x25C0298", VA = "0x25C0298")]
		private void method_58(Collision collision_0)
		{
		}

		// Token: 0x06003BA0 RID: 15264 RVA: 0x00075250 File Offset: 0x00073450
		[Address(RVA = "0x25C030C", Offset = "0x25C030C", VA = "0x25C030C")]
		[Token(Token = "0x6003BA0")]
		private void Start()
		{
			base.gameObject.name == "HandL";
			this.bool_0 = ("HandL" != null);
		}

		// Token: 0x06003BA1 RID: 15265 RVA: 0x00074F7C File Offset: 0x0007317C
		[Token(Token = "0x6003BA1")]
		[Address(RVA = "0x25C0380", Offset = "0x25C0380", VA = "0x25C0380")]
		private void method_59(Collision collision_0)
		{
		}

		// Token: 0x06003BA2 RID: 15266 RVA: 0x00074E7C File Offset: 0x0007307C
		[Address(RVA = "0x25C03F4", Offset = "0x25C03F4", VA = "0x25C03F4")]
		[Token(Token = "0x6003BA2")]
		private void method_60(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003BA3 RID: 15267 RVA: 0x00074ECC File Offset: 0x000730CC
		[Token(Token = "0x6003BA3")]
		[Address(RVA = "0x25C0468", Offset = "0x25C0468", VA = "0x25C0468")]
		private void method_61(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003BA4 RID: 15268 RVA: 0x00074ECC File Offset: 0x000730CC
		[Token(Token = "0x6003BA4")]
		[Address(RVA = "0x25C04DC", Offset = "0x25C04DC", VA = "0x25C04DC")]
		private void method_62(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003BA5 RID: 15269 RVA: 0x00074F7C File Offset: 0x0007317C
		[Token(Token = "0x6003BA5")]
		[Address(RVA = "0x25C0550", Offset = "0x25C0550", VA = "0x25C0550")]
		private void method_63(Collision collision_0)
		{
		}

		// Token: 0x06003BA6 RID: 15270 RVA: 0x00074F7C File Offset: 0x0007317C
		[Address(RVA = "0x25C05C4", Offset = "0x25C05C4", VA = "0x25C05C4")]
		[Token(Token = "0x6003BA6")]
		private void method_64(Collision collision_0)
		{
		}

		// Token: 0x06003BA7 RID: 15271 RVA: 0x00074ECC File Offset: 0x000730CC
		[Address(RVA = "0x25C0638", Offset = "0x25C0638", VA = "0x25C0638")]
		[Token(Token = "0x6003BA7")]
		private void method_65(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003BA8 RID: 15272 RVA: 0x00074ECC File Offset: 0x000730CC
		[Token(Token = "0x6003BA8")]
		[Address(RVA = "0x25C06AC", Offset = "0x25C06AC", VA = "0x25C06AC")]
		private void method_66(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 0L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x06003BA9 RID: 15273 RVA: 0x00074E7C File Offset: 0x0007307C
		[Token(Token = "0x6003BA9")]
		[Address(RVA = "0x25C0720", Offset = "0x25C0720", VA = "0x25C0720")]
		private void method_67(Collision collision_0)
		{
			Player player_ = Player.player_0;
			long bool_ = 1L;
			player_.method_4(this, bool_ != 0L, collision_0);
		}

		// Token: 0x04000A99 RID: 2713
		[Token(Token = "0x4000A99")]
		[FieldOffset(Offset = "0x18")]
		public bool bool_0;
	}
}
