﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

namespace Locomotion
{
	// Token: 0x0200017F RID: 383
	[Token(Token = "0x200017F")]
	public class Player : MonoBehaviour
	{
		// Token: 0x06003B18 RID: 15128 RVA: 0x000742F8 File Offset: 0x000724F8
		[Token(Token = "0x6003B18")]
		[Address(RVA = "0x305F434", Offset = "0x305F434", VA = "0x305F434")]
		private void method_0()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.rigidbody_0.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Vector3 position3 = this.RightTarget.position;
			Vector3 position4 = this.RightHand.position;
			Vector3 velocity3 = this.rigidbody_0.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
		}

		// Token: 0x06003B19 RID: 15129 RVA: 0x00074380 File Offset: 0x00072580
		[Token(Token = "0x6003B19")]
		[Address(RVA = "0x305F6A4", Offset = "0x305F6A4", VA = "0x305F6A4")]
		private float method_1()
		{
			do
			{
				bool flag = this.bool_5;
				bool flag2 = this.bool_8;
				if (flag && !flag2)
				{
					Vector3 localPosition = this.LeftTarget.localPosition;
					float fixedDeltaTime = Time.fixedDeltaTime;
				}
				Vector3 localPosition2 = this.LeftTarget.localPosition;
				float fixedDeltaTime2 = Time.fixedDeltaTime;
				Vector3 position = this.LeftHand.position;
			}
			while (!this.bool_6 || this.bool_7);
			Vector3 localPosition3 = this.RightTarget.localPosition;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			Vector3 position2 = this.RightHand.position;
			throw new NullReferenceException();
		}

		// Token: 0x06003B1A RID: 15130 RVA: 0x00074408 File Offset: 0x00072608
		[Token(Token = "0x6003B1A")]
		[Address(RVA = "0x305F8B8", Offset = "0x305F8B8", VA = "0x305F8B8")]
		private void method_2()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Quaternion rotation = this.LeftTarget.rotation;
			Quaternion rotation2 = this.LeftHand.rotation;
			Vector3 angularVelocity = this.LeftHand.angularVelocity;
			float fixedDeltaTime5 = Time.fixedDeltaTime;
			float fixedDeltaTime6 = Time.fixedDeltaTime;
			float fixedDeltaTime7 = Time.fixedDeltaTime;
			float fixedDeltaTime8 = Time.fixedDeltaTime;
			Quaternion rotation3 = this.RightTarget.rotation;
			Quaternion rotation4 = this.RightHand.rotation;
			Vector3 angularVelocity2 = this.RightHand.angularVelocity;
		}

		// Token: 0x06003B1B RID: 15131 RVA: 0x00074490 File Offset: 0x00072690
		[Address(RVA = "0x305FCE0", Offset = "0x305FCE0", VA = "0x305FCE0")]
		[Token(Token = "0x6003B1B")]
		private void FixedUpdate()
		{
			if (!this.bool_4)
			{
				Transform transform = this.RightHand.transform;
				Vector3 position = this.RightTarget.position;
				Transform transform2 = this.LeftHand.transform;
				Vector3 position2 = this.LeftTarget.position;
				return;
			}
			this.method_36();
			this.method_44();
			this.method_42();
			if (this.disableMovement)
			{
				return;
			}
		}

		// Token: 0x06003B1C RID: 15132 RVA: 0x000744F4 File Offset: 0x000726F4
		[Address(RVA = "0x30605B4", Offset = "0x30605B4", VA = "0x30605B4")]
		[Token(Token = "0x6003B1C")]
		private void method_3()
		{
			if (!this.bool_4)
			{
				Transform transform = this.RightHand.transform;
				Vector3 position = this.RightTarget.position;
				Transform transform2 = this.LeftHand.transform;
				Vector3 position2 = this.LeftTarget.position;
				return;
			}
			this.method_30();
			this.method_2();
			this.method_48();
			if (this.disableMovement)
			{
				return;
			}
		}

		// Token: 0x06003B1D RID: 15133 RVA: 0x00074558 File Offset: 0x00072758
		[Address(RVA = "0x3060AD8", Offset = "0x3060AD8", VA = "0x3060AD8")]
		[Token(Token = "0x6003B1D")]
		public void method_4(TempCollideCheck tempCollideCheck_0, bool bool_9, Collision collision_0)
		{
			GameObject gameObject = collision_0.gameObject;
			if (!tempCollideCheck_0.bool_0)
			{
				return;
			}
			Debug.Log("Stopped Colliding");
		}

		// Token: 0x06003B1E RID: 15134 RVA: 0x00074580 File Offset: 0x00072780
		[Address(RVA = "0x3061180", Offset = "0x3061180", VA = "0x3061180")]
		[Token(Token = "0x6003B1E")]
		private void method_5()
		{
		}

		// Token: 0x06003B1F RID: 15135 RVA: 0x00074408 File Offset: 0x00072608
		[Address(RVA = "0x3061328", Offset = "0x3061328", VA = "0x3061328")]
		[Token(Token = "0x6003B1F")]
		private void method_6()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Quaternion rotation = this.LeftTarget.rotation;
			Quaternion rotation2 = this.LeftHand.rotation;
			Vector3 angularVelocity = this.LeftHand.angularVelocity;
			float fixedDeltaTime5 = Time.fixedDeltaTime;
			float fixedDeltaTime6 = Time.fixedDeltaTime;
			float fixedDeltaTime7 = Time.fixedDeltaTime;
			float fixedDeltaTime8 = Time.fixedDeltaTime;
			Quaternion rotation3 = this.RightTarget.rotation;
			Quaternion rotation4 = this.RightHand.rotation;
			Vector3 angularVelocity2 = this.RightHand.angularVelocity;
		}

		// Token: 0x06003B20 RID: 15136 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x3061750", Offset = "0x3061750", VA = "0x3061750")]
		[Token(Token = "0x6003B20")]
		private void method_7(bool bool_9)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003B21 RID: 15137 RVA: 0x00074590 File Offset: 0x00072790
		[Address(RVA = "0x3061990", Offset = "0x3061990", VA = "0x3061990")]
		[Token(Token = "0x6003B21")]
		public IEnumerator method_8()
		{
			Player.Class61 @class = new Player.Class61((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003B22 RID: 15138 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x3061A08", Offset = "0x3061A08", VA = "0x3061A08")]
		[Token(Token = "0x6003B22")]
		private void method_9(bool bool_9)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003B23 RID: 15139 RVA: 0x00074590 File Offset: 0x00072790
		[Address(RVA = "0x3061C48", Offset = "0x3061C48", VA = "0x3061C48")]
		[Token(Token = "0x6003B23")]
		public IEnumerator method_10()
		{
			Player.Class61 @class = new Player.Class61((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003B24 RID: 15140 RVA: 0x000745B8 File Offset: 0x000727B8
		[Address(RVA = "0x3061CC0", Offset = "0x3061CC0", VA = "0x3061CC0")]
		[Token(Token = "0x6003B24")]
		private void method_11()
		{
			if (!this.bool_0 && this.bool_1)
			{
				IEnumerator routine = this.method_37();
				base.StartCoroutine(routine);
			}
			if (this.bool_2 && this.bool_1)
			{
				IEnumerator routine2 = this.method_34();
				base.StartCoroutine(routine2);
				long num = 1L;
				this.bool_2 = (num != 0L);
			}
			OVRManager.ռ\u066Bހ\u073B;
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			this.transform_0.GetComponent<Camera>();
		}

		// Token: 0x06003B25 RID: 15141 RVA: 0x00074638 File Offset: 0x00072838
		[Address(RVA = "0x3061FE8", Offset = "0x3061FE8", VA = "0x3061FE8")]
		[Token(Token = "0x6003B25")]
		private void method_12()
		{
			Player.player_0 = this;
			Transform leftTarget = this.LeftTarget;
			Vector3 position = leftTarget.position;
			Quaternion rotation = this.LeftTarget.rotation;
			Transform rightTarget = this.RightTarget;
			Vector3 position2 = rightTarget.position;
			Transform rightTarget2 = this.RightTarget;
			Quaternion rotation2 = rightTarget2.rotation;
			Vector3 position3 = this.LeftHand.position;
			Vector3 position4 = this.LeftHand.position;
		}

		// Token: 0x06003B26 RID: 15142 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x3060F50", Offset = "0x3060F50", VA = "0x3060F50")]
		[Token(Token = "0x6003B26")]
		private void method_13(bool bool_9)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003B27 RID: 15143 RVA: 0x000746A0 File Offset: 0x000728A0
		[Address(RVA = "0x3062190", Offset = "0x3062190", VA = "0x3062190")]
		[Token(Token = "0x6003B27")]
		private void method_14()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.rigidbody_0.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Vector3 position3 = this.RightTarget.position;
			Vector3 position4 = this.RightHand.position;
			Vector3 velocity3 = this.rigidbody_0.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
		}

		// Token: 0x06003B28 RID: 15144 RVA: 0x00074728 File Offset: 0x00072928
		[Address(RVA = "0x3062400", Offset = "0x3062400", VA = "0x3062400")]
		[Token(Token = "0x6003B28")]
		public IEnumerator method_15()
		{
			Player.Class60 @class = new Player.Class60((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003B29 RID: 15145 RVA: 0x00074380 File Offset: 0x00072580
		[Address(RVA = "0x3062478", Offset = "0x3062478", VA = "0x3062478")]
		[Token(Token = "0x6003B29")]
		private float method_16()
		{
			do
			{
				bool flag = this.bool_5;
				bool flag2 = this.bool_8;
				if (flag && !flag2)
				{
					Vector3 localPosition = this.LeftTarget.localPosition;
					float fixedDeltaTime = Time.fixedDeltaTime;
				}
				Vector3 localPosition2 = this.LeftTarget.localPosition;
				float fixedDeltaTime2 = Time.fixedDeltaTime;
				Vector3 position = this.LeftHand.position;
			}
			while (!this.bool_6 || this.bool_7);
			Vector3 localPosition3 = this.RightTarget.localPosition;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			Vector3 position2 = this.RightHand.position;
			throw new NullReferenceException();
		}

		// Token: 0x06003B2A RID: 15146 RVA: 0x00074750 File Offset: 0x00072950
		[Address(RVA = "0x30626F4", Offset = "0x30626F4", VA = "0x30626F4")]
		[Token(Token = "0x6003B2A")]
		private void method_17()
		{
			this.LeftHand.gameObject.AddComponent<TempCollideCheck>();
			this.RightHand.gameObject.AddComponent<TempCollideCheck>();
		}

		// Token: 0x06003B2B RID: 15147 RVA: 0x00074780 File Offset: 0x00072980
		[Address(RVA = "0x3062770", Offset = "0x3062770", VA = "0x3062770")]
		[Token(Token = "0x6003B2B")]
		private void method_18()
		{
			if (!this.bool_0 && this.bool_1)
			{
				IEnumerator routine = this.method_34();
				base.StartCoroutine(routine);
			}
			long num;
			if (this.bool_2 && this.bool_1)
			{
				IEnumerator routine2 = this.method_24();
				base.StartCoroutine(routine2);
				num = 1L;
				this.bool_2 = (num != 0L);
			}
			if (num != 0L)
			{
			}
			OVRManager.ռ\u066Bހ\u073B;
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			this.transform_0.GetComponent<Camera>();
		}

		// Token: 0x06003B2C RID: 15148 RVA: 0x00074750 File Offset: 0x00072950
		[Address(RVA = "0x3062A20", Offset = "0x3062A20", VA = "0x3062A20")]
		[Token(Token = "0x6003B2C")]
		private void method_19()
		{
			this.LeftHand.gameObject.AddComponent<TempCollideCheck>();
			this.RightHand.gameObject.AddComponent<TempCollideCheck>();
		}

		// Token: 0x06003B2D RID: 15149 RVA: 0x00074728 File Offset: 0x00072928
		[Address(RVA = "0x3062A9C", Offset = "0x3062A9C", VA = "0x3062A9C")]
		[Token(Token = "0x6003B2D")]
		public IEnumerator method_20()
		{
			Player.Class60 @class = new Player.Class60((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003B2E RID: 15150 RVA: 0x00074750 File Offset: 0x00072950
		[Address(RVA = "0x3062B14", Offset = "0x3062B14", VA = "0x3062B14")]
		[Token(Token = "0x6003B2E")]
		private void method_21()
		{
			this.LeftHand.gameObject.AddComponent<TempCollideCheck>();
			this.RightHand.gameObject.AddComponent<TempCollideCheck>();
		}

		// Token: 0x06003B2F RID: 15151 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x3062B90", Offset = "0x3062B90", VA = "0x3062B90")]
		[Token(Token = "0x6003B2F")]
		private void method_22()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003B30 RID: 15152 RVA: 0x00074804 File Offset: 0x00072A04
		[Address(RVA = "0x3062C8C", Offset = "0x3062C8C", VA = "0x3062C8C")]
		[Token(Token = "0x6003B30")]
		private void method_23()
		{
			Player.player_0 = this;
			Transform leftTarget = this.LeftTarget;
			Vector3 position = leftTarget.position;
			Transform leftTarget2 = this.LeftTarget;
			Quaternion rotation = leftTarget2.rotation;
			Transform rightTarget = this.RightTarget;
			Vector3 position2 = rightTarget.position;
			Transform rightTarget2 = this.RightTarget;
			Quaternion rotation2 = rightTarget2.rotation;
			Vector3 position3 = this.LeftHand.position;
			Vector3 position4 = this.LeftHand.position;
		}

		// Token: 0x06003B31 RID: 15153 RVA: 0x00074870 File Offset: 0x00072A70
		[Address(RVA = "0x30629A8", Offset = "0x30629A8", VA = "0x30629A8")]
		[Token(Token = "0x6003B31")]
		public IEnumerator method_24()
		{
			Player.Class62 @class = new Player.Class62((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003B32 RID: 15154 RVA: 0x00074750 File Offset: 0x00072950
		[Address(RVA = "0x3062E34", Offset = "0x3062E34", VA = "0x3062E34")]
		[Token(Token = "0x6003B32")]
		private void method_25()
		{
			this.LeftHand.gameObject.AddComponent<TempCollideCheck>();
			this.RightHand.gameObject.AddComponent<TempCollideCheck>();
		}

		// Token: 0x06003B33 RID: 15155 RVA: 0x000746A0 File Offset: 0x000728A0
		[Address(RVA = "0x3062EB0", Offset = "0x3062EB0", VA = "0x3062EB0")]
		[Token(Token = "0x6003B33")]
		private void method_26()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.rigidbody_0.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Vector3 position3 = this.RightTarget.position;
			Vector3 position4 = this.RightHand.position;
			Vector3 velocity3 = this.rigidbody_0.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
		}

		// Token: 0x06003B34 RID: 15156 RVA: 0x00074408 File Offset: 0x00072608
		[Address(RVA = "0x3063120", Offset = "0x3063120", VA = "0x3063120")]
		[Token(Token = "0x6003B34")]
		private void method_27()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Quaternion rotation = this.LeftTarget.rotation;
			Quaternion rotation2 = this.LeftHand.rotation;
			Vector3 angularVelocity = this.LeftHand.angularVelocity;
			float fixedDeltaTime5 = Time.fixedDeltaTime;
			float fixedDeltaTime6 = Time.fixedDeltaTime;
			float fixedDeltaTime7 = Time.fixedDeltaTime;
			float fixedDeltaTime8 = Time.fixedDeltaTime;
			Quaternion rotation3 = this.RightTarget.rotation;
			Quaternion rotation4 = this.RightHand.rotation;
			Vector3 angularVelocity2 = this.RightHand.angularVelocity;
		}

		// Token: 0x06003B35 RID: 15157 RVA: 0x00074750 File Offset: 0x00072950
		[Address(RVA = "0x306353C", Offset = "0x306353C", VA = "0x306353C")]
		[Token(Token = "0x6003B35")]
		private void Awake()
		{
			this.LeftHand.gameObject.AddComponent<TempCollideCheck>();
			this.RightHand.gameObject.AddComponent<TempCollideCheck>();
		}

		// Token: 0x06003B36 RID: 15158 RVA: 0x00074380 File Offset: 0x00072580
		[Address(RVA = "0x30635B8", Offset = "0x30635B8", VA = "0x30635B8")]
		[Token(Token = "0x6003B36")]
		private float method_28()
		{
			do
			{
				bool flag = this.bool_5;
				bool flag2 = this.bool_8;
				if (flag && !flag2)
				{
					Vector3 localPosition = this.LeftTarget.localPosition;
					float fixedDeltaTime = Time.fixedDeltaTime;
				}
				Vector3 localPosition2 = this.LeftTarget.localPosition;
				float fixedDeltaTime2 = Time.fixedDeltaTime;
				Vector3 position = this.LeftHand.position;
			}
			while (!this.bool_6 || this.bool_7);
			Vector3 localPosition3 = this.RightTarget.localPosition;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			Vector3 position2 = this.RightHand.position;
			throw new NullReferenceException();
		}

		// Token: 0x06003B37 RID: 15159 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x3063830", Offset = "0x3063830", VA = "0x3063830")]
		[Token(Token = "0x6003B37")]
		private void method_29(bool bool_9)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003B38 RID: 15160 RVA: 0x000746A0 File Offset: 0x000728A0
		[Address(RVA = "0x3060688", Offset = "0x3060688", VA = "0x3060688")]
		[Token(Token = "0x6003B38")]
		private void method_30()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.rigidbody_0.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Vector3 position3 = this.RightTarget.position;
			Vector3 position4 = this.RightHand.position;
			Vector3 velocity3 = this.rigidbody_0.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
		}

		// Token: 0x06003B39 RID: 15161 RVA: 0x00074898 File Offset: 0x00072A98
		[Address(RVA = "0x3063A70", Offset = "0x3063A70", VA = "0x3063A70")]
		[Token(Token = "0x6003B39")]
		private void method_31()
		{
			if (!this.bool_0 && this.bool_1)
			{
				IEnumerator routine = this.method_34();
				base.StartCoroutine(routine);
			}
			if (this.bool_2 && this.bool_1)
			{
				IEnumerator routine2 = this.method_34();
				base.StartCoroutine(routine2);
				long num = 1L;
				this.bool_2 = (num != 0L);
			}
			OVRManager.ռ\u066Bހ\u073B;
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			this.transform_0.GetComponent<Camera>();
		}

		// Token: 0x06003B3A RID: 15162 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x3063CA4", Offset = "0x3063CA4", VA = "0x3063CA4")]
		[Token(Token = "0x6003B3A")]
		private void method_32(bool bool_9)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003B3B RID: 15163 RVA: 0x00074918 File Offset: 0x00072B18
		[Address(RVA = "0x3063EE4", Offset = "0x3063EE4", VA = "0x3063EE4")]
		[Token(Token = "0x6003B3B")]
		private void method_33()
		{
			bool flag;
			if (!(flag = this.bool_4))
			{
				Transform transform = base.transform.transform;
				return;
			}
			this.method_14();
			this.method_6();
			this.method_42();
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06003B3C RID: 15164 RVA: 0x00003782 File Offset: 0x00001982
		[Address(RVA = "0x3063FBC", Offset = "0x3063FBC", VA = "0x3063FBC")]
		[Token(Token = "0x6003B3C")]
		public Player()
		{
		}

		// Token: 0x06003B3D RID: 15165 RVA: 0x00074870 File Offset: 0x00072A70
		[Address(RVA = "0x3061F70", Offset = "0x3061F70", VA = "0x3061F70")]
		[Token(Token = "0x6003B3D")]
		public IEnumerator method_34()
		{
			Player.Class62 @class = new Player.Class62((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003B3E RID: 15166 RVA: 0x00074954 File Offset: 0x00072B54
		[Address(RVA = "0x3063FE4", Offset = "0x3063FE4", VA = "0x3063FE4")]
		[Token(Token = "0x6003B3E")]
		public IEnumerator method_35()
		{
			Player.Class61 @class;
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003B3F RID: 15167 RVA: 0x000746A0 File Offset: 0x000728A0
		[Address(RVA = "0x305FDB0", Offset = "0x305FDB0", VA = "0x305FDB0")]
		[Token(Token = "0x6003B3F")]
		private void method_36()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.rigidbody_0.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Vector3 position3 = this.RightTarget.position;
			Vector3 position4 = this.RightHand.position;
			Vector3 velocity3 = this.rigidbody_0.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
		}

		// Token: 0x06003B40 RID: 15168 RVA: 0x00074870 File Offset: 0x00072A70
		[Address(RVA = "0x3061EF8", Offset = "0x3061EF8", VA = "0x3061EF8")]
		[Token(Token = "0x6003B40")]
		public IEnumerator method_37()
		{
			Player.Class62 @class = new Player.Class62((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003B41 RID: 15169 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x306405C", Offset = "0x306405C", VA = "0x306405C")]
		[Token(Token = "0x6003B41")]
		private void method_38(bool bool_9)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003B42 RID: 15170 RVA: 0x00074970 File Offset: 0x00072B70
		[Address(RVA = "0x306429C", Offset = "0x306429C", VA = "0x306429C")]
		[Token(Token = "0x6003B42")]
		private void method_39()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Quaternion rotation = this.LeftHand.rotation;
			Vector3 angularVelocity = this.LeftHand.angularVelocity;
			float fixedDeltaTime5 = Time.fixedDeltaTime;
			float fixedDeltaTime6 = Time.fixedDeltaTime;
			float fixedDeltaTime7 = Time.fixedDeltaTime;
			float fixedDeltaTime8 = Time.fixedDeltaTime;
			Quaternion rotation2 = this.RightTarget.rotation;
			Quaternion rotation3 = this.RightHand.rotation;
			Vector3 angularVelocity2 = this.RightHand.angularVelocity;
		}

		// Token: 0x06003B43 RID: 15171 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x30646C8", Offset = "0x30646C8", VA = "0x30646C8")]
		[Token(Token = "0x6003B43")]
		private void LateUpdate()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003B44 RID: 15172 RVA: 0x000749EC File Offset: 0x00072BEC
		[Address(RVA = "0x30647C4", Offset = "0x30647C4", VA = "0x30647C4")]
		[Token(Token = "0x6003B44")]
		private void method_40()
		{
			if (!this.bool_4)
			{
				Transform transform = this.RightHand.transform;
				Vector3 position = this.RightTarget.position;
				Transform transform2 = this.LeftHand.transform;
				Vector3 position2 = this.LeftTarget.position;
				return;
			}
			this.method_49();
			this.method_44();
			this.method_42();
			if (this.disableMovement)
			{
				return;
			}
		}

		// Token: 0x06003B45 RID: 15173 RVA: 0x00074A50 File Offset: 0x00072C50
		[Address(RVA = "0x3064B0C", Offset = "0x3064B0C", VA = "0x3064B0C")]
		[Token(Token = "0x6003B45")]
		private void method_41()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.rigidbody_0.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Vector3 position3 = this.RightHand.position;
			Vector3 velocity3 = this.rigidbody_0.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
		}

		// Token: 0x06003B46 RID: 15174 RVA: 0x00074ACC File Offset: 0x00072CCC
		[Address(RVA = "0x30603D4", Offset = "0x30603D4", VA = "0x30603D4")]
		[Token(Token = "0x6003B46")]
		private void method_42()
		{
			if (this.bool_5)
			{
				Vector3 position = this.LeftHand.position;
				Vector3 position2 = this.LeftTarget.position;
				this.method_1();
				if (this.bool_4)
				{
					Vector3 velocity = this.rigidbody_0.velocity;
				}
			}
			if (this.bool_6)
			{
				Vector3 position3 = this.RightHand.position;
				Vector3 position4 = this.RightTarget.position;
				this.method_1();
				if (this.bool_4)
				{
					Vector3 velocity2 = this.rigidbody_0.velocity;
					return;
				}
			}
		}

		// Token: 0x06003B47 RID: 15175 RVA: 0x00074580 File Offset: 0x00072780
		[Address(RVA = "0x3064D78", Offset = "0x3064D78", VA = "0x3064D78")]
		[Token(Token = "0x6003B47")]
		private void method_43()
		{
		}

		// Token: 0x06003B48 RID: 15176 RVA: 0x00074B50 File Offset: 0x00072D50
		[Address(RVA = "0x3064F20", Offset = "0x3064F20", VA = "0x3064F20")]
		[Token(Token = "0x6003B48")]
		private void Update()
		{
			if (!this.bool_0)
			{
				this.method_37();
			}
			if (this.bool_2 && this.bool_1)
			{
				IEnumerator routine = this.method_37();
				base.StartCoroutine(routine);
			}
			OVRManager.ռ\u066Bހ\u073B;
			this.transform_0.GetComponent<Camera>();
		}

		// Token: 0x06003B49 RID: 15177 RVA: 0x00074408 File Offset: 0x00072608
		[Address(RVA = "0x3060000", Offset = "0x3060000", VA = "0x3060000")]
		[Token(Token = "0x6003B49")]
		private void method_44()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Quaternion rotation = this.LeftTarget.rotation;
			Quaternion rotation2 = this.LeftHand.rotation;
			Vector3 angularVelocity = this.LeftHand.angularVelocity;
			float fixedDeltaTime5 = Time.fixedDeltaTime;
			float fixedDeltaTime6 = Time.fixedDeltaTime;
			float fixedDeltaTime7 = Time.fixedDeltaTime;
			float fixedDeltaTime8 = Time.fixedDeltaTime;
			Quaternion rotation3 = this.RightTarget.rotation;
			Quaternion rotation4 = this.RightHand.rotation;
			Vector3 angularVelocity2 = this.RightHand.angularVelocity;
		}

		// Token: 0x06003B4A RID: 15178 RVA: 0x00074BA0 File Offset: 0x00072DA0
		[Address(RVA = "0x3065154", Offset = "0x3065154", VA = "0x3065154")]
		[Token(Token = "0x6003B4A")]
		private void method_45()
		{
			Player.player_0 = this;
			Transform leftTarget = this.LeftTarget;
			Vector3 position = leftTarget.position;
			Transform leftTarget2 = this.LeftTarget;
			Quaternion rotation = leftTarget2.rotation;
			Transform rightTarget = this.RightTarget;
			Vector3 position2 = rightTarget.position;
			Transform rightTarget2 = this.RightTarget;
			Quaternion rotation2 = rightTarget2.rotation;
			Vector3 position3 = this.LeftHand.position;
			Vector3 position4 = this.LeftHand.position;
		}

		// Token: 0x06003B4B RID: 15179 RVA: 0x00074C0C File Offset: 0x00072E0C
		[Token(Token = "0x6003B4B")]
		[Address(RVA = "0x30652FC", Offset = "0x30652FC", VA = "0x30652FC")]
		private void method_46()
		{
			if (!this.bool_4)
			{
				Transform transform = this.RightHand.transform;
				Transform transform2 = this.LeftHand.transform;
				Vector3 position = this.LeftTarget.position;
				return;
			}
			this.method_49();
			this.method_6();
			this.method_42();
			if (this.disableMovement)
			{
				return;
			}
		}

		// Token: 0x06003B4C RID: 15180 RVA: 0x00074408 File Offset: 0x00072608
		[Address(RVA = "0x30653D0", Offset = "0x30653D0", VA = "0x30653D0")]
		[Token(Token = "0x6003B4C")]
		private void method_47()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Quaternion rotation = this.LeftTarget.rotation;
			Quaternion rotation2 = this.LeftHand.rotation;
			Vector3 angularVelocity = this.LeftHand.angularVelocity;
			float fixedDeltaTime5 = Time.fixedDeltaTime;
			float fixedDeltaTime6 = Time.fixedDeltaTime;
			float fixedDeltaTime7 = Time.fixedDeltaTime;
			float fixedDeltaTime8 = Time.fixedDeltaTime;
			Quaternion rotation3 = this.RightTarget.rotation;
			Quaternion rotation4 = this.RightHand.rotation;
			Vector3 angularVelocity2 = this.RightHand.angularVelocity;
		}

		// Token: 0x06003B4D RID: 15181 RVA: 0x00074638 File Offset: 0x00072838
		[Token(Token = "0x6003B4D")]
		[Address(RVA = "0x30657FC", Offset = "0x30657FC", VA = "0x30657FC")]
		private void Start()
		{
			Player.player_0 = this;
			Transform leftTarget = this.LeftTarget;
			Vector3 position = leftTarget.position;
			Quaternion rotation = this.LeftTarget.rotation;
			Transform rightTarget = this.RightTarget;
			Vector3 position2 = rightTarget.position;
			Transform rightTarget2 = this.RightTarget;
			Quaternion rotation2 = rightTarget2.rotation;
			Vector3 position3 = this.LeftHand.position;
			Vector3 position4 = this.LeftHand.position;
		}

		// Token: 0x06003B4E RID: 15182 RVA: 0x00074C64 File Offset: 0x00072E64
		[Address(RVA = "0x30608F8", Offset = "0x30608F8", VA = "0x30608F8")]
		[Token(Token = "0x6003B4E")]
		private void method_48()
		{
			if (this.bool_5)
			{
				Vector3 position = this.LeftHand.position;
				Vector3 position2 = this.LeftTarget.position;
				this.method_28();
				if (this.bool_4)
				{
					Rigidbody rigidbody = this.rigidbody_0;
					Vector3 velocity = rigidbody.velocity;
				}
			}
			if (this.bool_6)
			{
				Vector3 position3 = this.RightHand.position;
				Vector3 position4 = this.RightTarget.position;
				this.method_28();
				if (this.bool_4)
				{
					Vector3 velocity2 = this.rigidbody_0.velocity;
					return;
				}
			}
		}

		// Token: 0x06003B4F RID: 15183 RVA: 0x00074A50 File Offset: 0x00072C50
		[Address(RVA = "0x306489C", Offset = "0x306489C", VA = "0x306489C")]
		[Token(Token = "0x6003B4F")]
		private void method_49()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			float fixedDeltaTime3 = Time.fixedDeltaTime;
			float fixedDeltaTime4 = Time.fixedDeltaTime;
			Vector3 position = this.LeftTarget.position;
			Vector3 position2 = this.LeftHand.position;
			Vector3 velocity = this.rigidbody_0.velocity;
			Vector3 velocity2 = this.LeftHand.velocity;
			Vector3 position3 = this.RightHand.position;
			Vector3 velocity3 = this.rigidbody_0.velocity;
			Vector3 velocity4 = this.RightHand.velocity;
		}

		// Token: 0x04000A5A RID: 2650
		[Token(Token = "0x4000A5A")]
		public static Player player_0;

		// Token: 0x04000A5B RID: 2651
		[Token(Token = "0x4000A5B")]
		[SerializeField]
		[FieldOffset(Offset = "0x18")]
		[Header("PID")]
		private float frequency;

		// Token: 0x04000A5C RID: 2652
		[FieldOffset(Offset = "0x1C")]
		[SerializeField]
		[Token(Token = "0x4000A5C")]
		private float damping;

		// Token: 0x04000A5D RID: 2653
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000A5D")]
		[SerializeField]
		private float rotfrequency;

		// Token: 0x04000A5E RID: 2654
		[FieldOffset(Offset = "0x24")]
		[SerializeField]
		[Token(Token = "0x4000A5E")]
		private float rotDamping;

		// Token: 0x04000A5F RID: 2655
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000A5F")]
		public Rigidbody rigidbody_0;

		// Token: 0x04000A60 RID: 2656
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000A60")]
		[SerializeField]
		private Transform LeftTarget;

		// Token: 0x04000A61 RID: 2657
		[FieldOffset(Offset = "0x38")]
		[SerializeField]
		[Token(Token = "0x4000A61")]
		private Rigidbody LeftHand;

		// Token: 0x04000A62 RID: 2658
		[Token(Token = "0x4000A62")]
		[SerializeField]
		[FieldOffset(Offset = "0x40")]
		private Transform RightTarget;

		// Token: 0x04000A63 RID: 2659
		[Token(Token = "0x4000A63")]
		[SerializeField]
		[FieldOffset(Offset = "0x48")]
		private Rigidbody RightHand;

		// Token: 0x04000A64 RID: 2660
		[SerializeField]
		[Token(Token = "0x4000A64")]
		[FieldOffset(Offset = "0x50")]
		private float hitAmountL;

		// Token: 0x04000A65 RID: 2661
		[Token(Token = "0x4000A65")]
		[FieldOffset(Offset = "0x54")]
		[SerializeField]
		private float hitAmountR;

		// Token: 0x04000A66 RID: 2662
		[Header("Springs (should be 400, 200, and false)")]
		[SerializeField]
		[Space]
		[Token(Token = "0x4000A66")]
		[FieldOffset(Offset = "0x58")]
		private float climbForce;

		// Token: 0x04000A67 RID: 2663
		[SerializeField]
		[Token(Token = "0x4000A67")]
		[FieldOffset(Offset = "0x5C")]
		private float climbDrag;

		// Token: 0x04000A68 RID: 2664
		[FieldOffset(Offset = "0x60")]
		[SerializeField]
		[Token(Token = "0x4000A68")]
		private bool disableMovement;

		// Token: 0x04000A69 RID: 2665
		[Token(Token = "0x4000A69")]
		[FieldOffset(Offset = "0x68")]
		public AudioSource audioSource_0;

		// Token: 0x04000A6A RID: 2666
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x4000A6A")]
		public AudioSource audioSource_1;

		// Token: 0x04000A6B RID: 2667
		[Token(Token = "0x4000A6B")]
		[FieldOffset(Offset = "0x78")]
		public AudioClip[] audioClip_0;

		// Token: 0x04000A6C RID: 2668
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x4000A6C")]
		public AudioClip[] audioClip_1;

		// Token: 0x04000A6D RID: 2669
		[FieldOffset(Offset = "0x88")]
		[Token(Token = "0x4000A6D")]
		public AudioClip[] audioClip_2;

		// Token: 0x04000A6E RID: 2670
		[Token(Token = "0x4000A6E")]
		[FieldOffset(Offset = "0x90")]
		public AudioClip[] audioClip_3;

		// Token: 0x04000A6F RID: 2671
		[Token(Token = "0x4000A6F")]
		[FieldOffset(Offset = "0x98")]
		public AudioClip[] audioClip_4;

		// Token: 0x04000A70 RID: 2672
		[Token(Token = "0x4000A70")]
		[FieldOffset(Offset = "0xA0")]
		public AudioClip[] audioClip_5;

		// Token: 0x04000A71 RID: 2673
		[Token(Token = "0x4000A71")]
		[FieldOffset(Offset = "0xA8")]
		public AudioClip[] audioClip_6;

		// Token: 0x04000A72 RID: 2674
		[Token(Token = "0x4000A72")]
		[FieldOffset(Offset = "0xB0")]
		public AudioClip[] audioClip_7;

		// Token: 0x04000A73 RID: 2675
		[Token(Token = "0x4000A73")]
		[FieldOffset(Offset = "0xB8")]
		public AudioClip[] audioClip_8;

		// Token: 0x04000A74 RID: 2676
		[Token(Token = "0x4000A74")]
		[FieldOffset(Offset = "0xC0")]
		public AudioClip[] audioClip_9;

		// Token: 0x04000A75 RID: 2677
		[Token(Token = "0x4000A75")]
		[FieldOffset(Offset = "0xC8")]
		public ParticleSystem particleSystem_0;

		// Token: 0x04000A76 RID: 2678
		[FieldOffset(Offset = "0xD0")]
		[Token(Token = "0x4000A76")]
		public bool bool_0;

		// Token: 0x04000A77 RID: 2679
		[FieldOffset(Offset = "0xD1")]
		[Token(Token = "0x4000A77")]
		public bool bool_1;

		// Token: 0x04000A78 RID: 2680
		[Token(Token = "0x4000A78")]
		[FieldOffset(Offset = "0xD2")]
		public bool bool_2;

		// Token: 0x04000A79 RID: 2681
		[Token(Token = "0x4000A79")]
		[FieldOffset(Offset = "0xD4")]
		public float float_0;

		// Token: 0x04000A7A RID: 2682
		[Token(Token = "0x4000A7A")]
		[FieldOffset(Offset = "0xD8")]
		public Transform transform_0;

		// Token: 0x04000A7B RID: 2683
		[FieldOffset(Offset = "0xE0")]
		[Token(Token = "0x4000A7B")]
		public AudioSource audioSource_2;

		// Token: 0x04000A7C RID: 2684
		[FieldOffset(Offset = "0xE8")]
		[Token(Token = "0x4000A7C")]
		private InputDevice inputDevice_0;

		// Token: 0x04000A7D RID: 2685
		[Token(Token = "0x4000A7D")]
		[FieldOffset(Offset = "0xF8")]
		private InputDevice inputDevice_1;

		// Token: 0x04000A7E RID: 2686
		[Token(Token = "0x4000A7E")]
		[FieldOffset(Offset = "0x108")]
		public OVRManager ovrmanager_0;

		// Token: 0x04000A7F RID: 2687
		[FieldOffset(Offset = "0x110")]
		[Token(Token = "0x4000A7F")]
		public Transform transform_1;

		// Token: 0x04000A80 RID: 2688
		[FieldOffset(Offset = "0x118")]
		[Token(Token = "0x4000A80")]
		public GameObject gameObject_0;

		// Token: 0x04000A81 RID: 2689
		[Token(Token = "0x4000A81")]
		[FieldOffset(Offset = "0x120")]
		private bool bool_3 = 257 != 0;

		// Token: 0x04000A82 RID: 2690
		[Token(Token = "0x4000A82")]
		[FieldOffset(Offset = "0x121")]
		private bool bool_4;

		// Token: 0x04000A83 RID: 2691
		[Token(Token = "0x4000A83")]
		[FieldOffset(Offset = "0x124")]
		private Vector3 vector3_0;

		// Token: 0x04000A84 RID: 2692
		[Token(Token = "0x4000A84")]
		[FieldOffset(Offset = "0x130")]
		private Vector3 vector3_1;

		// Token: 0x04000A85 RID: 2693
		[Token(Token = "0x4000A85")]
		[FieldOffset(Offset = "0x13C")]
		private bool bool_5;

		// Token: 0x04000A86 RID: 2694
		[Token(Token = "0x4000A86")]
		[FieldOffset(Offset = "0x13D")]
		private bool bool_6;

		// Token: 0x04000A87 RID: 2695
		[FieldOffset(Offset = "0x13E")]
		[Token(Token = "0x4000A87")]
		private bool bool_7;

		// Token: 0x04000A88 RID: 2696
		[Token(Token = "0x4000A88")]
		[FieldOffset(Offset = "0x13F")]
		private bool bool_8;

		// Token: 0x02000180 RID: 384
		[Token(Token = "0x2000180")]
		[Serializable]
		public struct MatHitData
		{
			// Token: 0x04000A89 RID: 2697
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4000A89")]
			public string materialName;

			// Token: 0x04000A8A RID: 2698
			[Token(Token = "0x4000A8A")]
			[FieldOffset(Offset = "0x8")]
			public bool OverrideSound;

			// Token: 0x04000A8B RID: 2699
			[Token(Token = "0x4000A8B")]
			[FieldOffset(Offset = "0xC")]
			public float SoundOverride;

			// Token: 0x04000A8C RID: 2700
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000A8C")]
			public AudioClip audio;

			// Token: 0x04000A8D RID: 2701
			[Token(Token = "0x4000A8D")]
			[FieldOffset(Offset = "0x18")]
			public Vector2 pitchAB;

			// Token: 0x04000A8E RID: 2702
			[FieldOffset(Offset = "0x20")]
			[Token(Token = "0x4000A8E")]
			public bool slip;
		}
	}
}
