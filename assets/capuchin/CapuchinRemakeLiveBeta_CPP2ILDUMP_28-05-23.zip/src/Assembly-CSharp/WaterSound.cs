﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000045 RID: 69
[Token(Token = "0x2000045")]
public class WaterSound : MonoBehaviour
{
	// Token: 0x060008CC RID: 2252 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x60008CC")]
	[Address(RVA = "0x20FAD28", Offset = "0x20FAD28", VA = "0x20FAD28")]
	private void method_0()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008CD RID: 2253 RVA: 0x0001342C File Offset: 0x0001162C
	[Token(Token = "0x60008CD")]
	[Address(RVA = "0x20FAF08", Offset = "0x20FAF08", VA = "0x20FAF08")]
	private void method_1()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		float volume2 = this.audioSource_1.volume;
		float deltaTime = Time.deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource2 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource2.volume;
		AudioSource audioSource3 = this.audioSource_0;
		float volume4 = audioSource3.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource3.volume = deltaTime2;
	}

	// Token: 0x060008CE RID: 2254 RVA: 0x000134B0 File Offset: 0x000116B0
	[Token(Token = "0x60008CE")]
	[Address(RVA = "0x20FB0E8", Offset = "0x20FB0E8", VA = "0x20FB0E8")]
	private void method_2()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008CF RID: 2255 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008CF")]
	[Address(RVA = "0x20FB124", Offset = "0x20FB124", VA = "0x20FB124")]
	public void method_3()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008D0 RID: 2256 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x60008D0")]
	[Address(RVA = "0x20FB220", Offset = "0x20FB220", VA = "0x20FB220")]
	private void method_4()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008D1 RID: 2257 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x60008D1")]
	[Address(RVA = "0x20FB400", Offset = "0x20FB400", VA = "0x20FB400")]
	private void method_5()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008D2 RID: 2258 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x20FB5E0", Offset = "0x20FB5E0", VA = "0x20FB5E0")]
	[Token(Token = "0x60008D2")]
	private void method_6()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008D3 RID: 2259 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008D3")]
	[Address(RVA = "0x20FB7C0", Offset = "0x20FB7C0", VA = "0x20FB7C0")]
	public void method_7()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008D4 RID: 2260 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008D4")]
	[Address(RVA = "0x20FB8BC", Offset = "0x20FB8BC", VA = "0x20FB8BC")]
	public void method_8()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008D5 RID: 2261 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x20FB9D0", Offset = "0x20FB9D0", VA = "0x20FB9D0")]
	[Token(Token = "0x60008D5")]
	private void method_9()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008D6 RID: 2262 RVA: 0x000134EC File Offset: 0x000116EC
	[Address(RVA = "0x20FBBB0", Offset = "0x20FBBB0", VA = "0x20FBBB0")]
	[Token(Token = "0x60008D6")]
	private void method_10()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
	}

	// Token: 0x060008D7 RID: 2263 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008D7")]
	[Address(RVA = "0x20FBD90", Offset = "0x20FBD90", VA = "0x20FBD90")]
	public void method_11()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008D8 RID: 2264 RVA: 0x0001353C File Offset: 0x0001173C
	[Address(RVA = "0x20FBE8C", Offset = "0x20FBE8C", VA = "0x20FBE8C")]
	[Token(Token = "0x60008D8")]
	private void method_12()
	{
		long initialized = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.inputDevice_0 = deviceAtXRNode;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice;
		this.inputDevice_1 = inputDevice;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008D9 RID: 2265 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x20FBEC8", Offset = "0x20FBEC8", VA = "0x20FBEC8")]
	[Token(Token = "0x60008D9")]
	private void method_13()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008DA RID: 2266 RVA: 0x000134B0 File Offset: 0x000116B0
	[Token(Token = "0x60008DA")]
	[Address(RVA = "0x20FBF04", Offset = "0x20FBF04", VA = "0x20FBF04")]
	private void method_14()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008DB RID: 2267 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008DB")]
	[Address(RVA = "0x20FBF40", Offset = "0x20FBF40", VA = "0x20FBF40")]
	public void method_15()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008DC RID: 2268 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008DC")]
	[Address(RVA = "0x20FC048", Offset = "0x20FC048", VA = "0x20FC048")]
	public void method_16()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008DD RID: 2269 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008DD")]
	[Address(RVA = "0x20FC15C", Offset = "0x20FC15C", VA = "0x20FC15C")]
	public void method_17()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008DE RID: 2270 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x20FC258", Offset = "0x20FC258", VA = "0x20FC258")]
	[Token(Token = "0x60008DE")]
	private void method_18()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008DF RID: 2271 RVA: 0x0001357C File Offset: 0x0001177C
	[Address(RVA = "0x20FC294", Offset = "0x20FC294", VA = "0x20FC294")]
	[Token(Token = "0x60008DF")]
	private void method_19()
	{
	}

	// Token: 0x060008E0 RID: 2272 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x20FC474", Offset = "0x20FC474", VA = "0x20FC474")]
	[Token(Token = "0x60008E0")]
	public void method_20()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008E1 RID: 2273 RVA: 0x0001358C File Offset: 0x0001178C
	[Address(RVA = "0x20FC570", Offset = "0x20FC570", VA = "0x20FC570")]
	[Token(Token = "0x60008E1")]
	private void method_21()
	{
	}

	// Token: 0x060008E2 RID: 2274 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x20FC750", Offset = "0x20FC750", VA = "0x20FC750")]
	[Token(Token = "0x60008E2")]
	private void method_22()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008E3 RID: 2275 RVA: 0x0001359C File Offset: 0x0001179C
	[Address(RVA = "0x20FC78C", Offset = "0x20FC78C", VA = "0x20FC78C")]
	[Token(Token = "0x60008E3")]
	private void method_23()
	{
		InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
	}

	// Token: 0x060008E4 RID: 2276 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x20FC7C8", Offset = "0x20FC7C8", VA = "0x20FC7C8")]
	[Token(Token = "0x60008E4")]
	public void method_24()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008E5 RID: 2277 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x20FC8D0", Offset = "0x20FC8D0", VA = "0x20FC8D0")]
	[Token(Token = "0x60008E5")]
	public void method_25()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008E6 RID: 2278 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x60008E6")]
	[Address(RVA = "0x20FC9D8", Offset = "0x20FC9D8", VA = "0x20FC9D8")]
	private void method_26()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008E7 RID: 2279 RVA: 0x000134B0 File Offset: 0x000116B0
	[Token(Token = "0x60008E7")]
	[Address(RVA = "0x20FCBB8", Offset = "0x20FCBB8", VA = "0x20FCBB8")]
	private void method_27()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008E8 RID: 2280 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008E8")]
	[Address(RVA = "0x20FCBF4", Offset = "0x20FCBF4", VA = "0x20FCBF4")]
	public void method_28()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008E9 RID: 2281 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x20FCCF0", Offset = "0x20FCCF0", VA = "0x20FCCF0")]
	[Token(Token = "0x60008E9")]
	private void method_29()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008EA RID: 2282 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008EA")]
	[Address(RVA = "0x20FCD2C", Offset = "0x20FCD2C", VA = "0x20FCD2C")]
	public void method_30()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008EB RID: 2283 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x20FCE34", Offset = "0x20FCE34", VA = "0x20FCE34")]
	[Token(Token = "0x60008EB")]
	public void method_31()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008EC RID: 2284 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x20FCF30", Offset = "0x20FCF30", VA = "0x20FCF30")]
	[Token(Token = "0x60008EC")]
	private void method_32()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008ED RID: 2285 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x20FCF6C", Offset = "0x20FCF6C", VA = "0x20FCF6C")]
	[Token(Token = "0x60008ED")]
	private void method_33()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008EE RID: 2286 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x20FD14C", Offset = "0x20FD14C", VA = "0x20FD14C")]
	[Token(Token = "0x60008EE")]
	public void method_34()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008EF RID: 2287 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x20FD248", Offset = "0x20FD248", VA = "0x20FD248")]
	[Token(Token = "0x60008EF")]
	private void method_35()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008F0 RID: 2288 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x20FD428", Offset = "0x20FD428", VA = "0x20FD428")]
	[Token(Token = "0x60008F0")]
	public void method_36()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008F1 RID: 2289 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008F1")]
	[Address(RVA = "0x20FD524", Offset = "0x20FD524", VA = "0x20FD524")]
	public void method_37()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008F2 RID: 2290 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x60008F2")]
	[Address(RVA = "0x20FD62C", Offset = "0x20FD62C", VA = "0x20FD62C")]
	private void method_38()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008F3 RID: 2291 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x20FD80C", Offset = "0x20FD80C", VA = "0x20FD80C")]
	[Token(Token = "0x60008F3")]
	private void method_39()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008F4 RID: 2292 RVA: 0x0001353C File Offset: 0x0001173C
	[Token(Token = "0x60008F4")]
	[Address(RVA = "0x20FD848", Offset = "0x20FD848", VA = "0x20FD848")]
	private void method_40()
	{
		long initialized = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.inputDevice_0 = deviceAtXRNode;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice;
		this.inputDevice_1 = inputDevice;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008F5 RID: 2293 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x20FD884", Offset = "0x20FD884", VA = "0x20FD884")]
	[Token(Token = "0x60008F5")]
	public WaterSound()
	{
	}

	// Token: 0x060008F6 RID: 2294 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008F6")]
	[Address(RVA = "0x20FD88C", Offset = "0x20FD88C", VA = "0x20FD88C")]
	public void method_41()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008F7 RID: 2295 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x60008F7")]
	[Address(RVA = "0x20FD988", Offset = "0x20FD988", VA = "0x20FD988")]
	private void method_42()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008F8 RID: 2296 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x20FDB68", Offset = "0x20FDB68", VA = "0x20FDB68")]
	[Token(Token = "0x60008F8")]
	public void method_43()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008F9 RID: 2297 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008F9")]
	[Address(RVA = "0x20FDC64", Offset = "0x20FDC64", VA = "0x20FDC64")]
	public void method_44()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008FA RID: 2298 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x60008FA")]
	[Address(RVA = "0x20FDD6C", Offset = "0x20FDD6C", VA = "0x20FDD6C")]
	private void method_45()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008FB RID: 2299 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008FB")]
	[Address(RVA = "0x20FDF4C", Offset = "0x20FDF4C", VA = "0x20FDF4C")]
	public void method_46()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008FC RID: 2300 RVA: 0x000135B0 File Offset: 0x000117B0
	[Token(Token = "0x60008FC")]
	[Address(RVA = "0x20FE048", Offset = "0x20FE048", VA = "0x20FE048")]
	private void method_47()
	{
		long initialized = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.inputDevice_0 = deviceAtXRNode;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice;
		this.inputDevice_1 = inputDevice;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x060008FD RID: 2301 RVA: 0x000135F0 File Offset: 0x000117F0
	[Address(RVA = "0x20FE084", Offset = "0x20FE084", VA = "0x20FE084")]
	[Token(Token = "0x60008FD")]
	private void method_48()
	{
		SwimmyV2 swimmyV = this.swimmyV2_0;
		AudioSource audioSource = this.audioSource_1;
		if (swimmyV != null)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_ = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008FE RID: 2302 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x20FE264", Offset = "0x20FE264", VA = "0x20FE264")]
	[Token(Token = "0x60008FE")]
	private void method_49()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x060008FF RID: 2303 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x20FE444", Offset = "0x20FE444", VA = "0x20FE444")]
	[Token(Token = "0x60008FF")]
	private void method_50()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000900 RID: 2304 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x20FE480", Offset = "0x20FE480", VA = "0x20FE480")]
	[Token(Token = "0x6000900")]
	public void method_51()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000901 RID: 2305 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x20FE57C", Offset = "0x20FE57C", VA = "0x20FE57C")]
	[Token(Token = "0x6000901")]
	private void method_52()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000902 RID: 2306 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000902")]
	[Address(RVA = "0x20FE5B8", Offset = "0x20FE5B8", VA = "0x20FE5B8")]
	public void method_53()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000903 RID: 2307 RVA: 0x0001367C File Offset: 0x0001187C
	[Address(RVA = "0x20FE6C0", Offset = "0x20FE6C0", VA = "0x20FE6C0")]
	[Token(Token = "0x6000903")]
	private void method_54()
	{
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
	}

	// Token: 0x06000904 RID: 2308 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000904")]
	[Address(RVA = "0x20FE6FC", Offset = "0x20FE6FC", VA = "0x20FE6FC")]
	public void method_55()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000905 RID: 2309 RVA: 0x00013690 File Offset: 0x00011890
	[Address(RVA = "0x20FE7F8", Offset = "0x20FE7F8", VA = "0x20FE7F8")]
	[Token(Token = "0x6000905")]
	private void method_56()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.inputDevice_1 = deviceAtXRNode;
		this.inputDevice_1.m_Initialized = (initialized != 0L);
	}

	// Token: 0x06000906 RID: 2310 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000906")]
	[Address(RVA = "0x20FE834", Offset = "0x20FE834", VA = "0x20FE834")]
	public void method_57()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000907 RID: 2311 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000907")]
	[Address(RVA = "0x20FE93C", Offset = "0x20FE93C", VA = "0x20FE93C")]
	public void method_58()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000908 RID: 2312 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000908")]
	[Address(RVA = "0x20FEA38", Offset = "0x20FEA38", VA = "0x20FEA38")]
	public void method_59()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000909 RID: 2313 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x6000909")]
	[Address(RVA = "0x20FEB40", Offset = "0x20FEB40", VA = "0x20FEB40")]
	private void method_60()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x0600090A RID: 2314 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x600090A")]
	[Address(RVA = "0x20FED20", Offset = "0x20FED20", VA = "0x20FED20")]
	private void method_61()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x0600090B RID: 2315 RVA: 0x000136CC File Offset: 0x000118CC
	[Token(Token = "0x600090B")]
	[Address(RVA = "0x20FEF00", Offset = "0x20FEF00", VA = "0x20FEF00")]
	private void Start()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.inputDevice_1 = deviceAtXRNode;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600090C RID: 2316 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x20FEF3C", Offset = "0x20FEF3C", VA = "0x20FEF3C")]
	[Token(Token = "0x600090C")]
	public void method_62()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600090D RID: 2317 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x20FF038", Offset = "0x20FF038", VA = "0x20FF038")]
	[Token(Token = "0x600090D")]
	public void method_63()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600090E RID: 2318 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x20FF134", Offset = "0x20FF134", VA = "0x20FF134")]
	[Token(Token = "0x600090E")]
	private void method_64()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x0600090F RID: 2319 RVA: 0x0001370C File Offset: 0x0001190C
	[Token(Token = "0x600090F")]
	[Address(RVA = "0x20FF314", Offset = "0x20FF314", VA = "0x20FF314")]
	private void method_65()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x06000910 RID: 2320 RVA: 0x000137A0 File Offset: 0x000119A0
	[Token(Token = "0x6000910")]
	[Address(RVA = "0x20FF4F4", Offset = "0x20FF4F4", VA = "0x20FF4F4")]
	private void method_66()
	{
		long initialized = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.inputDevice_0 = deviceAtXRNode;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice deviceAtXRNode2 = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.inputDevice_1 = deviceAtXRNode2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000911 RID: 2321 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x6000911")]
	[Address(RVA = "0x20FF530", Offset = "0x20FF530", VA = "0x20FF530")]
	private void method_67()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x06000912 RID: 2322 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x20FF710", Offset = "0x20FF710", VA = "0x20FF710")]
	[Token(Token = "0x6000912")]
	private void method_68()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000913 RID: 2323 RVA: 0x000137E8 File Offset: 0x000119E8
	[Token(Token = "0x6000913")]
	[Address(RVA = "0x20FF74C", Offset = "0x20FF74C", VA = "0x20FF74C")]
	private void method_69()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x06000914 RID: 2324 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x6000914")]
	[Address(RVA = "0x20FF92C", Offset = "0x20FF92C", VA = "0x20FF92C")]
	private void method_70()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x06000915 RID: 2325 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x20FFB0C", Offset = "0x20FFB0C", VA = "0x20FFB0C")]
	[Token(Token = "0x6000915")]
	private void method_71()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x06000916 RID: 2326 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x20FFCEC", Offset = "0x20FFCEC", VA = "0x20FFCEC")]
	[Token(Token = "0x6000916")]
	private void method_72()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x06000917 RID: 2327 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x20FFECC", Offset = "0x20FFECC", VA = "0x20FFECC")]
	[Token(Token = "0x6000917")]
	private void FixedUpdate()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x06000918 RID: 2328 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000918")]
	[Address(RVA = "0x210009C", Offset = "0x210009C", VA = "0x210009C")]
	public void method_73()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000919 RID: 2329 RVA: 0x0001353C File Offset: 0x0001173C
	[Token(Token = "0x6000919")]
	[Address(RVA = "0x21001A4", Offset = "0x21001A4", VA = "0x21001A4")]
	private void method_74()
	{
		long initialized = 0L;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		this.inputDevice_0 = deviceAtXRNode;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice;
		this.inputDevice_1 = inputDevice;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600091A RID: 2330 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600091A")]
	[Address(RVA = "0x21001E0", Offset = "0x21001E0", VA = "0x21001E0")]
	public void method_75()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600091B RID: 2331 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x21002F4", Offset = "0x21002F4", VA = "0x21002F4")]
	[Token(Token = "0x600091B")]
	private void method_76()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x0600091C RID: 2332 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x600091C")]
	[Address(RVA = "0x21004D4", Offset = "0x21004D4", VA = "0x21004D4")]
	private void method_77()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x0600091D RID: 2333 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x21006B4", Offset = "0x21006B4", VA = "0x21006B4")]
	[Token(Token = "0x600091D")]
	public void method_78()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600091E RID: 2334 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600091E")]
	[Address(RVA = "0x21007B0", Offset = "0x21007B0", VA = "0x21007B0")]
	public void method_79()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600091F RID: 2335 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600091F")]
	[Address(RVA = "0x21008AC", Offset = "0x21008AC", VA = "0x21008AC")]
	public void method_80()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000920 RID: 2336 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x21009B4", Offset = "0x21009B4", VA = "0x21009B4")]
	[Token(Token = "0x6000920")]
	private void method_81()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000921 RID: 2337 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x6000921")]
	[Address(RVA = "0x21009F0", Offset = "0x21009F0", VA = "0x21009F0")]
	private void method_82()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x06000922 RID: 2338 RVA: 0x00013398 File Offset: 0x00011598
	[Address(RVA = "0x2100BD0", Offset = "0x2100BD0", VA = "0x2100BD0")]
	[Token(Token = "0x6000922")]
	private void method_83()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x06000923 RID: 2339 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2100DB0", Offset = "0x2100DB0", VA = "0x2100DB0")]
	[Token(Token = "0x6000923")]
	public void method_84()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000924 RID: 2340 RVA: 0x00013398 File Offset: 0x00011598
	[Token(Token = "0x6000924")]
	[Address(RVA = "0x2100EC4", Offset = "0x2100EC4", VA = "0x2100EC4")]
	private void method_85()
	{
		bool bool_ = this.swimmyV2_0.bool_3;
		AudioSource audioSource = this.audioSource_1;
		if (bool_)
		{
			return;
		}
		float volume = audioSource.volume;
		AudioSource audioSource2 = this.audioSource_1;
		float volume2 = audioSource2.volume;
		float deltaTime = Time.deltaTime;
		audioSource2.volume = deltaTime;
		bool bool_2 = this.swimmyV2_0.bool_2;
		AudioSource audioSource3 = this.audioSource_0;
		if (bool_2)
		{
			return;
		}
		float volume3 = audioSource3.volume;
		AudioSource audioSource4 = this.audioSource_0;
		float volume4 = audioSource4.volume;
		float deltaTime2 = Time.deltaTime;
		audioSource4.volume = deltaTime2;
	}

	// Token: 0x06000925 RID: 2341 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x21010A4", Offset = "0x21010A4", VA = "0x21010A4")]
	[Token(Token = "0x6000925")]
	public void method_86()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000926 RID: 2342 RVA: 0x000134B0 File Offset: 0x000116B0
	[Token(Token = "0x6000926")]
	[Address(RVA = "0x21011AC", Offset = "0x21011AC", VA = "0x21011AC")]
	private void method_87()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000927 RID: 2343 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000927")]
	[Address(RVA = "0x21011E8", Offset = "0x21011E8", VA = "0x21011E8")]
	public void method_88()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000928 RID: 2344 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x21012E4", Offset = "0x21012E4", VA = "0x21012E4")]
	[Token(Token = "0x6000928")]
	private void method_89()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x06000929 RID: 2345 RVA: 0x0001387C File Offset: 0x00011A7C
	[Token(Token = "0x6000929")]
	[Address(RVA = "0x2101320", Offset = "0x2101320", VA = "0x2101320")]
	private void method_90()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized != 0L);
	}

	// Token: 0x0600092A RID: 2346 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x210135C", Offset = "0x210135C", VA = "0x210135C")]
	[Token(Token = "0x600092A")]
	public void method_91()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600092B RID: 2347 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600092B")]
	[Address(RVA = "0x2101458", Offset = "0x2101458", VA = "0x2101458")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600092C RID: 2348 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600092C")]
	[Address(RVA = "0x2101554", Offset = "0x2101554", VA = "0x2101554")]
	public void method_92()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600092D RID: 2349 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600092D")]
	[Address(RVA = "0x2101650", Offset = "0x2101650", VA = "0x2101650")]
	public void method_93()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600092E RID: 2350 RVA: 0x000134B0 File Offset: 0x000116B0
	[Token(Token = "0x600092E")]
	[Address(RVA = "0x210174C", Offset = "0x210174C", VA = "0x210174C")]
	private void method_94()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x0600092F RID: 2351 RVA: 0x000134B0 File Offset: 0x000116B0
	[Address(RVA = "0x2101788", Offset = "0x2101788", VA = "0x2101788")]
	[Token(Token = "0x600092F")]
	private void method_95()
	{
		long initialized = 0L;
		InputDevice inputDevice;
		this.inputDevice_0 = inputDevice;
		this.inputDevice_0.m_Initialized = (initialized != 0L);
		long initialized2 = 0L;
		InputDevice inputDevice2;
		this.inputDevice_1 = inputDevice2;
		this.inputDevice_1.m_Initialized = (initialized2 != 0L);
	}

	// Token: 0x04000159 RID: 345
	[Token(Token = "0x4000159")]
	[FieldOffset(Offset = "0x18")]
	private InputDevice inputDevice_0;

	// Token: 0x0400015A RID: 346
	[Token(Token = "0x400015A")]
	[FieldOffset(Offset = "0x28")]
	private InputDevice inputDevice_1;

	// Token: 0x0400015B RID: 347
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400015B")]
	public Vector3 vector3_0;

	// Token: 0x0400015C RID: 348
	[Token(Token = "0x400015C")]
	[FieldOffset(Offset = "0x44")]
	public Vector3 vector3_1;

	// Token: 0x0400015D RID: 349
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400015D")]
	private InputDevice inputDevice_2;

	// Token: 0x0400015E RID: 350
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400015E")]
	private InputDevice inputDevice_3;

	// Token: 0x0400015F RID: 351
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x400015F")]
	public Transform transform_0;

	// Token: 0x04000160 RID: 352
	[Token(Token = "0x4000160")]
	[FieldOffset(Offset = "0x78")]
	public Transform transform_1;

	// Token: 0x04000161 RID: 353
	[Token(Token = "0x4000161")]
	[FieldOffset(Offset = "0x80")]
	public float float_0;

	// Token: 0x04000162 RID: 354
	[Token(Token = "0x4000162")]
	[FieldOffset(Offset = "0x84")]
	public float float_1;

	// Token: 0x04000163 RID: 355
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x4000163")]
	public float float_2;

	// Token: 0x04000164 RID: 356
	[Token(Token = "0x4000164")]
	[FieldOffset(Offset = "0x90")]
	public AudioSource audioSource_0;

	// Token: 0x04000165 RID: 357
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x4000165")]
	public AudioSource audioSource_1;

	// Token: 0x04000166 RID: 358
	[FieldOffset(Offset = "0xA0")]
	[Token(Token = "0x4000166")]
	public SwimmyV2 swimmyV2_0;
}
