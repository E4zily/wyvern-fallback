﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000010 RID: 16
[Token(Token = "0x2000010")]
[Serializable]
public struct TeamSettings
{
	// Token: 0x04000041 RID: 65
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000041")]
	[Header("Materials")]
	public Material Tagged;

	// Token: 0x04000042 RID: 66
	[Token(Token = "0x4000042")]
	[FieldOffset(Offset = "0x8")]
	public Material Reg;
}
