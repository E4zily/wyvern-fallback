﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000F8 RID: 248
[Token(Token = "0x20000F8")]
public class StartButton : MonoBehaviour
{
	// Token: 0x0600254F RID: 9551 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F6C", Offset = "0x3082F6C", VA = "0x3082F6C")]
	[Token(Token = "0x600254F")]
	private void method_0()
	{
	}

	// Token: 0x06002550 RID: 9552 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F70", Offset = "0x3082F70", VA = "0x3082F70")]
	[Token(Token = "0x6002550")]
	private void method_1()
	{
	}

	// Token: 0x06002551 RID: 9553 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3082F74", Offset = "0x3082F74", VA = "0x3082F74")]
	[Token(Token = "0x6002551")]
	public StartButton()
	{
	}

	// Token: 0x06002552 RID: 9554 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F7C", Offset = "0x3082F7C", VA = "0x3082F7C")]
	[Token(Token = "0x6002552")]
	private void method_2()
	{
	}

	// Token: 0x06002553 RID: 9555 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F80", Offset = "0x3082F80", VA = "0x3082F80")]
	[Token(Token = "0x6002553")]
	private void method_3()
	{
	}

	// Token: 0x06002554 RID: 9556 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F84", Offset = "0x3082F84", VA = "0x3082F84")]
	[Token(Token = "0x6002554")]
	private void method_4()
	{
	}

	// Token: 0x06002555 RID: 9557 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F88", Offset = "0x3082F88", VA = "0x3082F88")]
	[Token(Token = "0x6002555")]
	private void method_5()
	{
	}

	// Token: 0x06002556 RID: 9558 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F8C", Offset = "0x3082F8C", VA = "0x3082F8C")]
	[Token(Token = "0x6002556")]
	private void method_6()
	{
	}

	// Token: 0x06002557 RID: 9559 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F90", Offset = "0x3082F90", VA = "0x3082F90")]
	[Token(Token = "0x6002557")]
	private void method_7()
	{
	}

	// Token: 0x06002558 RID: 9560 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F94", Offset = "0x3082F94", VA = "0x3082F94")]
	[Token(Token = "0x6002558")]
	private void Start()
	{
	}

	// Token: 0x06002559 RID: 9561 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F98", Offset = "0x3082F98", VA = "0x3082F98")]
	[Token(Token = "0x6002559")]
	private void method_8()
	{
	}

	// Token: 0x0600255A RID: 9562 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082F9C", Offset = "0x3082F9C", VA = "0x3082F9C")]
	[Token(Token = "0x600255A")]
	private void method_9()
	{
	}

	// Token: 0x0600255B RID: 9563 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FA0", Offset = "0x3082FA0", VA = "0x3082FA0")]
	[Token(Token = "0x600255B")]
	private void method_10()
	{
	}

	// Token: 0x0600255C RID: 9564 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FA4", Offset = "0x3082FA4", VA = "0x3082FA4")]
	[Token(Token = "0x600255C")]
	private void method_11()
	{
	}

	// Token: 0x0600255D RID: 9565 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FA8", Offset = "0x3082FA8", VA = "0x3082FA8")]
	[Token(Token = "0x600255D")]
	private void method_12()
	{
	}

	// Token: 0x0600255E RID: 9566 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FAC", Offset = "0x3082FAC", VA = "0x3082FAC")]
	[Token(Token = "0x600255E")]
	private void method_13()
	{
	}

	// Token: 0x0600255F RID: 9567 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FB0", Offset = "0x3082FB0", VA = "0x3082FB0")]
	[Token(Token = "0x600255F")]
	private void method_14()
	{
	}

	// Token: 0x06002560 RID: 9568 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FB4", Offset = "0x3082FB4", VA = "0x3082FB4")]
	[Token(Token = "0x6002560")]
	private void method_15()
	{
	}

	// Token: 0x06002561 RID: 9569 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FB8", Offset = "0x3082FB8", VA = "0x3082FB8")]
	[Token(Token = "0x6002561")]
	private void method_16()
	{
	}

	// Token: 0x06002562 RID: 9570 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FBC", Offset = "0x3082FBC", VA = "0x3082FBC")]
	[Token(Token = "0x6002562")]
	private void method_17()
	{
	}

	// Token: 0x06002563 RID: 9571 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FC0", Offset = "0x3082FC0", VA = "0x3082FC0")]
	[Token(Token = "0x6002563")]
	private void Update()
	{
	}

	// Token: 0x06002564 RID: 9572 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FC4", Offset = "0x3082FC4", VA = "0x3082FC4")]
	[Token(Token = "0x6002564")]
	private void method_18()
	{
	}

	// Token: 0x06002565 RID: 9573 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FC8", Offset = "0x3082FC8", VA = "0x3082FC8")]
	[Token(Token = "0x6002565")]
	private void method_19()
	{
	}

	// Token: 0x06002566 RID: 9574 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FCC", Offset = "0x3082FCC", VA = "0x3082FCC")]
	[Token(Token = "0x6002566")]
	private void method_20()
	{
	}

	// Token: 0x06002567 RID: 9575 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FD0", Offset = "0x3082FD0", VA = "0x3082FD0")]
	[Token(Token = "0x6002567")]
	private void method_21()
	{
	}

	// Token: 0x06002568 RID: 9576 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FD4", Offset = "0x3082FD4", VA = "0x3082FD4")]
	[Token(Token = "0x6002568")]
	private void method_22()
	{
	}

	// Token: 0x06002569 RID: 9577 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FD8", Offset = "0x3082FD8", VA = "0x3082FD8")]
	[Token(Token = "0x6002569")]
	private void method_23()
	{
	}

	// Token: 0x0600256A RID: 9578 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FDC", Offset = "0x3082FDC", VA = "0x3082FDC")]
	[Token(Token = "0x600256A")]
	private void method_24()
	{
	}

	// Token: 0x0600256B RID: 9579 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FE0", Offset = "0x3082FE0", VA = "0x3082FE0")]
	[Token(Token = "0x600256B")]
	private void method_25()
	{
	}

	// Token: 0x0600256C RID: 9580 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FE4", Offset = "0x3082FE4", VA = "0x3082FE4")]
	[Token(Token = "0x600256C")]
	private void method_26()
	{
	}

	// Token: 0x0600256D RID: 9581 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FE8", Offset = "0x3082FE8", VA = "0x3082FE8")]
	[Token(Token = "0x600256D")]
	private void method_27()
	{
	}

	// Token: 0x0600256E RID: 9582 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FEC", Offset = "0x3082FEC", VA = "0x3082FEC")]
	[Token(Token = "0x600256E")]
	private void method_28()
	{
	}

	// Token: 0x0600256F RID: 9583 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FF0", Offset = "0x3082FF0", VA = "0x3082FF0")]
	[Token(Token = "0x600256F")]
	private void method_29()
	{
	}

	// Token: 0x06002570 RID: 9584 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FF4", Offset = "0x3082FF4", VA = "0x3082FF4")]
	[Token(Token = "0x6002570")]
	private void method_30()
	{
	}

	// Token: 0x06002571 RID: 9585 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FF8", Offset = "0x3082FF8", VA = "0x3082FF8")]
	[Token(Token = "0x6002571")]
	private void method_31()
	{
	}

	// Token: 0x06002572 RID: 9586 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3082FFC", Offset = "0x3082FFC", VA = "0x3082FFC")]
	[Token(Token = "0x6002572")]
	private void method_32()
	{
	}

	// Token: 0x06002573 RID: 9587 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083000", Offset = "0x3083000", VA = "0x3083000")]
	[Token(Token = "0x6002573")]
	private void method_33()
	{
	}

	// Token: 0x06002574 RID: 9588 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083004", Offset = "0x3083004", VA = "0x3083004")]
	[Token(Token = "0x6002574")]
	private void method_34()
	{
	}

	// Token: 0x06002575 RID: 9589 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083008", Offset = "0x3083008", VA = "0x3083008")]
	[Token(Token = "0x6002575")]
	private void method_35()
	{
	}

	// Token: 0x06002576 RID: 9590 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x308300C", Offset = "0x308300C", VA = "0x308300C")]
	[Token(Token = "0x6002576")]
	private void method_36()
	{
	}

	// Token: 0x06002577 RID: 9591 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083010", Offset = "0x3083010", VA = "0x3083010")]
	[Token(Token = "0x6002577")]
	private void method_37()
	{
	}

	// Token: 0x06002578 RID: 9592 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083014", Offset = "0x3083014", VA = "0x3083014")]
	[Token(Token = "0x6002578")]
	private void method_38()
	{
	}

	// Token: 0x06002579 RID: 9593 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083018", Offset = "0x3083018", VA = "0x3083018")]
	[Token(Token = "0x6002579")]
	private void method_39()
	{
	}

	// Token: 0x0600257A RID: 9594 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x308301C", Offset = "0x308301C", VA = "0x308301C")]
	[Token(Token = "0x600257A")]
	private void method_40()
	{
	}

	// Token: 0x0600257B RID: 9595 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083020", Offset = "0x3083020", VA = "0x3083020")]
	[Token(Token = "0x600257B")]
	private void method_41()
	{
	}

	// Token: 0x0600257C RID: 9596 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083024", Offset = "0x3083024", VA = "0x3083024")]
	[Token(Token = "0x600257C")]
	private void method_42()
	{
	}

	// Token: 0x0600257D RID: 9597 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083028", Offset = "0x3083028", VA = "0x3083028")]
	[Token(Token = "0x600257D")]
	private void method_43()
	{
	}

	// Token: 0x0600257E RID: 9598 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x308302C", Offset = "0x308302C", VA = "0x308302C")]
	[Token(Token = "0x600257E")]
	private void method_44()
	{
	}

	// Token: 0x0600257F RID: 9599 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083030", Offset = "0x3083030", VA = "0x3083030")]
	[Token(Token = "0x600257F")]
	private void method_45()
	{
	}

	// Token: 0x06002580 RID: 9600 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083034", Offset = "0x3083034", VA = "0x3083034")]
	[Token(Token = "0x6002580")]
	private void method_46()
	{
	}

	// Token: 0x06002581 RID: 9601 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083038", Offset = "0x3083038", VA = "0x3083038")]
	[Token(Token = "0x6002581")]
	private void method_47()
	{
	}

	// Token: 0x06002582 RID: 9602 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x308303C", Offset = "0x308303C", VA = "0x308303C")]
	[Token(Token = "0x6002582")]
	private void method_48()
	{
	}

	// Token: 0x06002583 RID: 9603 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083040", Offset = "0x3083040", VA = "0x3083040")]
	[Token(Token = "0x6002583")]
	private void method_49()
	{
	}

	// Token: 0x06002584 RID: 9604 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083044", Offset = "0x3083044", VA = "0x3083044")]
	[Token(Token = "0x6002584")]
	private void method_50()
	{
	}

	// Token: 0x06002585 RID: 9605 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083048", Offset = "0x3083048", VA = "0x3083048")]
	[Token(Token = "0x6002585")]
	private void method_51()
	{
	}

	// Token: 0x06002586 RID: 9606 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x308304C", Offset = "0x308304C", VA = "0x308304C")]
	[Token(Token = "0x6002586")]
	private void method_52()
	{
	}

	// Token: 0x06002587 RID: 9607 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083050", Offset = "0x3083050", VA = "0x3083050")]
	[Token(Token = "0x6002587")]
	private void method_53()
	{
	}

	// Token: 0x06002588 RID: 9608 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3083054", Offset = "0x3083054", VA = "0x3083054")]
	[Token(Token = "0x6002588")]
	private void method_54()
	{
	}
}
