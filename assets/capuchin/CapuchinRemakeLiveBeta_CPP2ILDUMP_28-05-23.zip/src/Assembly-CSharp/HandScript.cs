﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200002B RID: 43
[Token(Token = "0x200002B")]
public class HandScript : MonoBehaviour
{
	// Token: 0x06000534 RID: 1332 RVA: 0x0000ED50 File Offset: 0x0000CF50
	[Address(RVA = "0x3508F48", Offset = "0x3508F48", VA = "0x3508F48")]
	[Token(Token = "0x6000534")]
	private void method_0()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("_BaseMap", value != 0L);
	}

	// Token: 0x06000535 RID: 1333 RVA: 0x0000ED80 File Offset: 0x0000CF80
	[Address(RVA = "0x35090E0", Offset = "0x35090E0", VA = "0x35090E0")]
	[Token(Token = "0x6000535")]
	private void method_1()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Name Changing Error. Error: ", value != 0L);
	}

	// Token: 0x06000536 RID: 1334 RVA: 0x0000EDB0 File Offset: 0x0000CFB0
	[Token(Token = "0x6000536")]
	[Address(RVA = "0x3509278", Offset = "0x3509278", VA = "0x3509278")]
	private void method_2()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("This is the 5000 Bananas button, and it was just clicked", value != 0L);
	}

	// Token: 0x06000537 RID: 1335 RVA: 0x0000EDE0 File Offset: 0x0000CFE0
	[Address(RVA = "0x3509410", Offset = "0x3509410", VA = "0x3509410")]
	[Token(Token = "0x6000537")]
	private void method_3()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("ChangeToTagged", value != 0L);
	}

	// Token: 0x06000538 RID: 1336 RVA: 0x0000EE10 File Offset: 0x0000D010
	[Token(Token = "0x6000538")]
	[Address(RVA = "0x35095A8", Offset = "0x35095A8", VA = "0x35095A8")]
	private void method_4()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.", value != 0L);
	}

	// Token: 0x06000539 RID: 1337 RVA: 0x0000EE40 File Offset: 0x0000D040
	[Address(RVA = "0x3509740", Offset = "0x3509740", VA = "0x3509740")]
	[Token(Token = "0x6000539")]
	private void method_5()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Player", value != 0L);
	}

	// Token: 0x0600053A RID: 1338 RVA: 0x0000EE70 File Offset: 0x0000D070
	[Token(Token = "0x600053A")]
	[Address(RVA = "0x35098D8", Offset = "0x35098D8", VA = "0x35098D8")]
	private void method_6()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("back", value != 0L);
	}

	// Token: 0x0600053B RID: 1339 RVA: 0x0000EEA0 File Offset: 0x0000D0A0
	[Address(RVA = "0x3509A70", Offset = "0x3509A70", VA = "0x3509A70")]
	[Token(Token = "0x600053B")]
	private void Update()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
	}

	// Token: 0x0600053C RID: 1340 RVA: 0x0000EEBC File Offset: 0x0000D0BC
	[Address(RVA = "0x3509C08", Offset = "0x3509C08", VA = "0x3509C08")]
	[Token(Token = "0x600053C")]
	private void method_7()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Agreed", value != 0L);
	}

	// Token: 0x0600053D RID: 1341 RVA: 0x0000EEEC File Offset: 0x0000D0EC
	[Address(RVA = "0x3509DA0", Offset = "0x3509DA0", VA = "0x3509DA0")]
	[Token(Token = "0x600053D")]
	private void method_8()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("typesOfTalk", value != 0L);
	}

	// Token: 0x0600053E RID: 1342 RVA: 0x0000EF1C File Offset: 0x0000D11C
	[Address(RVA = "0x3509F38", Offset = "0x3509F38", VA = "0x3509F38")]
	[Token(Token = "0x600053E")]
	private void method_9()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("All audio clips have been played.", value != 0L);
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x0000EF4C File Offset: 0x0000D14C
	[Address(RVA = "0x350A0D0", Offset = "0x350A0D0", VA = "0x350A0D0")]
	[Token(Token = "0x600053F")]
	private void method_10()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool(".Please press the button if you would like to play alone", value != 0L);
	}

	// Token: 0x06000540 RID: 1344 RVA: 0x0000EF7C File Offset: 0x0000D17C
	[Address(RVA = "0x350A268", Offset = "0x350A268", VA = "0x350A268")]
	[Token(Token = "0x6000540")]
	private void method_11()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Vector1_d371bd24217449349bd747533d51af6b", value != 0L);
	}

	// Token: 0x06000541 RID: 1345 RVA: 0x0000EFAC File Offset: 0x0000D1AC
	[Address(RVA = "0x350A400", Offset = "0x350A400", VA = "0x350A400")]
	[Token(Token = "0x6000541")]
	private void method_12()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Body", value != 0L);
	}

	// Token: 0x06000542 RID: 1346 RVA: 0x0000EFDC File Offset: 0x0000D1DC
	[Token(Token = "0x6000542")]
	[Address(RVA = "0x350A598", Offset = "0x350A598", VA = "0x350A598")]
	private void method_13()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("\tExpires: ", value != 0L);
	}

	// Token: 0x06000543 RID: 1347 RVA: 0x0000F00C File Offset: 0x0000D20C
	[Address(RVA = "0x350A730", Offset = "0x350A730", VA = "0x350A730")]
	[Token(Token = "0x6000543")]
	private void method_14()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("PURCHASED", value != 0L);
	}

	// Token: 0x06000544 RID: 1348 RVA: 0x0000F03C File Offset: 0x0000D23C
	[Token(Token = "0x6000544")]
	[Address(RVA = "0x350A8C8", Offset = "0x350A8C8", VA = "0x350A8C8")]
	private void method_15()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("You Already Own This Item", value != 0L);
	}

	// Token: 0x06000545 RID: 1349 RVA: 0x0000F06C File Offset: 0x0000D26C
	[Address(RVA = "0x350AA60", Offset = "0x350AA60", VA = "0x350AA60")]
	[Token(Token = "0x6000545")]
	private void method_16()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("BN", value != 0L);
	}

	// Token: 0x06000546 RID: 1350 RVA: 0x0000F09C File Offset: 0x0000D29C
	[Token(Token = "0x6000546")]
	[Address(RVA = "0x350ABF8", Offset = "0x350ABF8", VA = "0x350ABF8")]
	private void method_17()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("DisableCosmetic", value != 0L);
	}

	// Token: 0x06000547 RID: 1351 RVA: 0x0000F0CC File Offset: 0x0000D2CC
	[Address(RVA = "0x350AD90", Offset = "0x350AD90", VA = "0x350AD90")]
	[Token(Token = "0x6000547")]
	private void method_18()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("5BN", value != 0L);
	}

	// Token: 0x06000548 RID: 1352 RVA: 0x0000F0FC File Offset: 0x0000D2FC
	[Address(RVA = "0x350AF28", Offset = "0x350AF28", VA = "0x350AF28")]
	[Token(Token = "0x6000548")]
	private void method_19()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Network Player", value != 0L);
	}

	// Token: 0x06000549 RID: 1353 RVA: 0x0000F12C File Offset: 0x0000D32C
	[Token(Token = "0x6000549")]
	[Address(RVA = "0x350B0C0", Offset = "0x350B0C0", VA = "0x350B0C0")]
	private void method_20()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("True", value != 0L);
	}

	// Token: 0x0600054A RID: 1354 RVA: 0x0000F15C File Offset: 0x0000D35C
	[Address(RVA = "0x350B258", Offset = "0x350B258", VA = "0x350B258")]
	[Token(Token = "0x600054A")]
	private void method_21()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("PlayerDeath", value != 0L);
	}

	// Token: 0x0600054B RID: 1355 RVA: 0x0000F18C File Offset: 0x0000D38C
	[Token(Token = "0x600054B")]
	[Address(RVA = "0x350B3F0", Offset = "0x350B3F0", VA = "0x350B3F0")]
	private void method_22()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("EnableCosmetic", value != 0L);
	}

	// Token: 0x0600054C RID: 1356 RVA: 0x0000F09C File Offset: 0x0000D29C
	[Address(RVA = "0x350B588", Offset = "0x350B588", VA = "0x350B588")]
	[Token(Token = "0x600054C")]
	private void method_23()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("DisableCosmetic", value != 0L);
	}

	// Token: 0x0600054D RID: 1357 RVA: 0x0000F1BC File Offset: 0x0000D3BC
	[Token(Token = "0x600054D")]
	[Address(RVA = "0x350B720", Offset = "0x350B720", VA = "0x350B720")]
	private void method_24()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Cannot access index {0}. Buffer size is {1}", value != 0L);
	}

	// Token: 0x0600054E RID: 1358 RVA: 0x0000F1EC File Offset: 0x0000D3EC
	[Token(Token = "0x600054E")]
	[Address(RVA = "0x350B8B8", Offset = "0x350B8B8", VA = "0x350B8B8")]
	private void method_25()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("You are not the master of the server, you cannot start the game.", value != 0L);
	}

	// Token: 0x0600054F RID: 1359 RVA: 0x0000F21C File Offset: 0x0000D41C
	[Token(Token = "0x600054F")]
	[Address(RVA = "0x350BA50", Offset = "0x350BA50", VA = "0x350BA50")]
	private void method_26()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("got funky mone", value != 0L);
	}

	// Token: 0x06000550 RID: 1360 RVA: 0x0000F24C File Offset: 0x0000D44C
	[Token(Token = "0x6000550")]
	[Address(RVA = "0x350BBE8", Offset = "0x350BBE8", VA = "0x350BBE8")]
	private void method_27()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("{0} ({1})", value != 0L);
	}

	// Token: 0x06000551 RID: 1361 RVA: 0x0000F27C File Offset: 0x0000D47C
	[Token(Token = "0x6000551")]
	[Address(RVA = "0x350BD80", Offset = "0x350BD80", VA = "0x350BD80")]
	private void method_28()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Charged!", value != 0L);
	}

	// Token: 0x06000552 RID: 1362 RVA: 0x0000F2AC File Offset: 0x0000D4AC
	[Token(Token = "0x6000552")]
	[Address(RVA = "0x350BF18", Offset = "0x350BF18", VA = "0x350BF18")]
	private void method_29()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("TurnAmount", value != 0L);
	}

	// Token: 0x06000553 RID: 1363 RVA: 0x0000F2DC File Offset: 0x0000D4DC
	[Address(RVA = "0x350C0B0", Offset = "0x350C0B0", VA = "0x350C0B0")]
	[Token(Token = "0x6000553")]
	private void method_30()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Room Name: ", value != 0L);
	}

	// Token: 0x06000554 RID: 1364 RVA: 0x0000F30C File Offset: 0x0000D50C
	[Address(RVA = "0x350C248", Offset = "0x350C248", VA = "0x350C248")]
	[Token(Token = "0x6000554")]
	private void method_31()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n", value != 0L);
	}

	// Token: 0x06000555 RID: 1365 RVA: 0x0000F33C File Offset: 0x0000D53C
	[Token(Token = "0x6000555")]
	[Address(RVA = "0x350C3E0", Offset = "0x350C3E0", VA = "0x350C3E0")]
	private void method_32()
	{
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_0) != null)
		{
		}
		long value = 0L;
		this.animator_0.SetBool("Add/Remove Hat", value != 0L);
	}

	// Token: 0x06000556 RID: 1366 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000556")]
	[Address(RVA = "0x350C56C", Offset = "0x350C56C", VA = "0x350C56C")]
	public HandScript()
	{
	}

	// Token: 0x040000C9 RID: 201
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000C9")]
	public XRNode xrnode_0;

	// Token: 0x040000CA RID: 202
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000CA")]
	public Animator animator_0;
}
