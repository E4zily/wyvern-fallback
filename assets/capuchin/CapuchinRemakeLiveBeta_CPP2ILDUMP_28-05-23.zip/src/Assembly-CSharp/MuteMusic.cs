﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000094 RID: 148
[Token(Token = "0x2000094")]
public class MuteMusic : MonoBehaviour
{
	// Token: 0x0600153C RID: 5436 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Token(Token = "0x600153C")]
	[Address(RVA = "0x2E755FC", Offset = "0x2E755FC", VA = "0x2E755FC")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600153D RID: 5437 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Token(Token = "0x600153D")]
	[Address(RVA = "0x2E756F0", Offset = "0x2E756F0", VA = "0x2E756F0")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600153E RID: 5438 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Token(Token = "0x600153E")]
	[Address(RVA = "0x2E757E4", Offset = "0x2E757E4", VA = "0x2E757E4")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600153F RID: 5439 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Token(Token = "0x600153F")]
	[Address(RVA = "0x2E758FC", Offset = "0x2E758FC", VA = "0x2E758FC")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001540 RID: 5440 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E75A18", Offset = "0x2E75A18", VA = "0x2E75A18")]
	[Token(Token = "0x6001540")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001541 RID: 5441 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E75B34", Offset = "0x2E75B34", VA = "0x2E75B34")]
	[Token(Token = "0x6001541")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001542 RID: 5442 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E75C4C", Offset = "0x2E75C4C", VA = "0x2E75C4C")]
	[Token(Token = "0x6001542")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001543 RID: 5443 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E75D3C", Offset = "0x2E75D3C", VA = "0x2E75D3C")]
	[Token(Token = "0x6001543")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001544 RID: 5444 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E75E30", Offset = "0x2E75E30", VA = "0x2E75E30")]
	[Token(Token = "0x6001544")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001545 RID: 5445 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E75F48", Offset = "0x2E75F48", VA = "0x2E75F48")]
	[Token(Token = "0x6001545")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001546 RID: 5446 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E76064", Offset = "0x2E76064", VA = "0x2E76064")]
	[Token(Token = "0x6001546")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001547 RID: 5447 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E76180", Offset = "0x2E76180", VA = "0x2E76180")]
	[Token(Token = "0x6001547")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001548 RID: 5448 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E76270", Offset = "0x2E76270", VA = "0x2E76270")]
	[Token(Token = "0x6001548")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001549 RID: 5449 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E76360", Offset = "0x2E76360", VA = "0x2E76360")]
	[Token(Token = "0x6001549")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600154A RID: 5450 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E7647C", Offset = "0x2E7647C", VA = "0x2E7647C")]
	[Token(Token = "0x600154A")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600154B RID: 5451 RVA: 0x00029DE4 File Offset: 0x00027FE4
	[Address(RVA = "0x2E76594", Offset = "0x2E76594", VA = "0x2E76594")]
	[Token(Token = "0x600154B")]
	public void method_15(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600154C RID: 5452 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Token(Token = "0x600154C")]
	[Address(RVA = "0x2E76688", Offset = "0x2E76688", VA = "0x2E76688")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600154D RID: 5453 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E767A4", Offset = "0x2E767A4", VA = "0x2E767A4")]
	[Token(Token = "0x600154D")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600154E RID: 5454 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E768BC", Offset = "0x2E768BC", VA = "0x2E768BC")]
	[Token(Token = "0x600154E")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600154F RID: 5455 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E769AC", Offset = "0x2E769AC", VA = "0x2E769AC")]
	[Token(Token = "0x600154F")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001550 RID: 5456 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001550")]
	[Address(RVA = "0x2E76AC8", Offset = "0x2E76AC8", VA = "0x2E76AC8")]
	public void method_19(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001551 RID: 5457 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Token(Token = "0x6001551")]
	[Address(RVA = "0x2E76BE0", Offset = "0x2E76BE0", VA = "0x2E76BE0")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001552 RID: 5458 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Token(Token = "0x6001552")]
	[Address(RVA = "0x2E76CD4", Offset = "0x2E76CD4", VA = "0x2E76CD4")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001553 RID: 5459 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E76DC8", Offset = "0x2E76DC8", VA = "0x2E76DC8")]
	[Token(Token = "0x6001553")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001554 RID: 5460 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E76EE0", Offset = "0x2E76EE0", VA = "0x2E76EE0")]
	[Token(Token = "0x6001554")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001555 RID: 5461 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E76FD0", Offset = "0x2E76FD0", VA = "0x2E76FD0")]
	[Token(Token = "0x6001555")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001556 RID: 5462 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Token(Token = "0x6001556")]
	[Address(RVA = "0x2E770C0", Offset = "0x2E770C0", VA = "0x2E770C0")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001557 RID: 5463 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E771D8", Offset = "0x2E771D8", VA = "0x2E771D8")]
	[Token(Token = "0x6001557")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001558 RID: 5464 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E772CC", Offset = "0x2E772CC", VA = "0x2E772CC")]
	[Token(Token = "0x6001558")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001559 RID: 5465 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E773BC", Offset = "0x2E773BC", VA = "0x2E773BC")]
	[Token(Token = "0x6001559")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600155A RID: 5466 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E774D4", Offset = "0x2E774D4", VA = "0x2E774D4")]
	[Token(Token = "0x600155A")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600155B RID: 5467 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Token(Token = "0x600155B")]
	[Address(RVA = "0x2E775EC", Offset = "0x2E775EC", VA = "0x2E775EC")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600155C RID: 5468 RVA: 0x00029E08 File Offset: 0x00028008
	[Address(RVA = "0x2E776DC", Offset = "0x2E776DC", VA = "0x2E776DC")]
	[Token(Token = "0x600155C")]
	public void method_31(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600155D RID: 5469 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E777F8", Offset = "0x2E777F8", VA = "0x2E777F8")]
	[Token(Token = "0x600155D")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600155E RID: 5470 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E77914", Offset = "0x2E77914", VA = "0x2E77914")]
	[Token(Token = "0x600155E")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600155F RID: 5471 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E77A30", Offset = "0x2E77A30", VA = "0x2E77A30")]
	[Token(Token = "0x600155F")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001560 RID: 5472 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E77B20", Offset = "0x2E77B20", VA = "0x2E77B20")]
	[Token(Token = "0x6001560")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001561 RID: 5473 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Token(Token = "0x6001561")]
	[Address(RVA = "0x2E77C10", Offset = "0x2E77C10", VA = "0x2E77C10")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001562 RID: 5474 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6001562")]
	[Address(RVA = "0x2E77D00", Offset = "0x2E77D00", VA = "0x2E77D00")]
	public MuteMusic()
	{
	}

	// Token: 0x06001563 RID: 5475 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E77D08", Offset = "0x2E77D08", VA = "0x2E77D08")]
	[Token(Token = "0x6001563")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001564 RID: 5476 RVA: 0x00029E24 File Offset: 0x00028024
	[Address(RVA = "0x2E77E24", Offset = "0x2E77E24", VA = "0x2E77E24")]
	[Token(Token = "0x6001564")]
	public void method_38(Collider collider_0)
	{
		HandColliders component = collider_0.gameObject.GetComponent<HandColliders>();
		component;
	}

	// Token: 0x06001565 RID: 5477 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Token(Token = "0x6001565")]
	[Address(RVA = "0x2E77F18", Offset = "0x2E77F18", VA = "0x2E77F18")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001566 RID: 5478 RVA: 0x00029E08 File Offset: 0x00028008
	[Address(RVA = "0x2E78030", Offset = "0x2E78030", VA = "0x2E78030")]
	[Token(Token = "0x6001566")]
	public void method_40(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001567 RID: 5479 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E78148", Offset = "0x2E78148", VA = "0x2E78148")]
	[Token(Token = "0x6001567")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001568 RID: 5480 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001568")]
	[Address(RVA = "0x2E78238", Offset = "0x2E78238", VA = "0x2E78238")]
	public void method_42(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001569 RID: 5481 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Token(Token = "0x6001569")]
	[Address(RVA = "0x2E78350", Offset = "0x2E78350", VA = "0x2E78350")]
	public void method_43(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600156A RID: 5482 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Token(Token = "0x600156A")]
	[Address(RVA = "0x2E7846C", Offset = "0x2E7846C", VA = "0x2E7846C")]
	public void method_44(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600156B RID: 5483 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Token(Token = "0x600156B")]
	[Address(RVA = "0x2E78588", Offset = "0x2E78588", VA = "0x2E78588")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600156C RID: 5484 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E7867C", Offset = "0x2E7867C", VA = "0x2E7867C")]
	[Token(Token = "0x600156C")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600156D RID: 5485 RVA: 0x00029DC4 File Offset: 0x00027FC4
	[Address(RVA = "0x2E78798", Offset = "0x2E78798", VA = "0x2E78798")]
	[Token(Token = "0x600156D")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x0600156E RID: 5486 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E788B0", Offset = "0x2E788B0", VA = "0x2E788B0")]
	[Token(Token = "0x600156E")]
	public void method_48(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600156F RID: 5487 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Address(RVA = "0x2E789A4", Offset = "0x2E789A4", VA = "0x2E789A4")]
	[Token(Token = "0x600156F")]
	public void method_49(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x06001570 RID: 5488 RVA: 0x00029D9C File Offset: 0x00027F9C
	[Token(Token = "0x6001570")]
	[Address(RVA = "0x2E78A98", Offset = "0x2E78A98", VA = "0x2E78A98")]
	public void method_50(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		if (this.audioSource_0 == null)
		{
			return;
		}
	}

	// Token: 0x040002C7 RID: 711
	[Token(Token = "0x40002C7")]
	[FieldOffset(Offset = "0x18")]
	public AudioSource[] audioSource_0;
}
