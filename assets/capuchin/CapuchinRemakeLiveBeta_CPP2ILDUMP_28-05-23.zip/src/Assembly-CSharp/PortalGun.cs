﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200009B RID: 155
[Token(Token = "0x200009B")]
public class PortalGun : MonoBehaviour
{
	// Token: 0x060016FA RID: 5882 RVA: 0x0002C760 File Offset: 0x0002A960
	[Address(RVA = "0x2A79B68", Offset = "0x2A79B68", VA = "0x2A79B68")]
	[Token(Token = "0x60016FA")]
	public void method_0()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Version");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("token");
		GameObject.FindGameObjectWithTag("FLSPTLT");
	}

	// Token: 0x060016FB RID: 5883 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60016FB")]
	[Address(RVA = "0x2A79C54", Offset = "0x2A79C54", VA = "0x2A79C54")]
	public PortalGun()
	{
	}

	// Token: 0x060016FC RID: 5884 RVA: 0x0002C798 File Offset: 0x0002A998
	[Token(Token = "0x60016FC")]
	[Address(RVA = "0x2A79C5C", Offset = "0x2A79C5C", VA = "0x2A79C5C")]
	public void method_1()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("You are not the master of the server, you cannot start the game.");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n");
		GameObject.FindGameObjectWithTag("Regular");
		GameObject.FindGameObjectWithTag("'s Grabber is not assigned.");
	}

	// Token: 0x060016FD RID: 5885 RVA: 0x0002C7D8 File Offset: 0x0002A9D8
	[Token(Token = "0x60016FD")]
	[Address(RVA = "0x2A79D48", Offset = "0x2A79D48", VA = "0x2A79D48")]
	public void method_2()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Diffuse");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("TurnAmount");
		GameObject.FindGameObjectWithTag("\n");
		GameObject.FindGameObjectWithTag("StartGamemode");
	}

	// Token: 0x060016FE RID: 5886 RVA: 0x0002C818 File Offset: 0x0002AA18
	[Address(RVA = "0x2A79E34", Offset = "0x2A79E34", VA = "0x2A79E34")]
	[Token(Token = "0x60016FE")]
	public void method_3()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Faild To Add Winner Money: ");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("DISABLE");
		GameObject.FindGameObjectWithTag("Failed to login, please restart");
		GameObject.FindGameObjectWithTag("Queue");
	}

	// Token: 0x060016FF RID: 5887 RVA: 0x0002C858 File Offset: 0x0002AA58
	[Token(Token = "0x60016FF")]
	[Address(RVA = "0x2A79F20", Offset = "0x2A79F20", VA = "0x2A79F20")]
	public void method_4()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Updating Material to: ");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("INSIGNIFICANT CURRENCY");
		GameObject.FindGameObjectWithTag("Right Hand");
		GameObject.FindGameObjectWithTag("htc");
	}

	// Token: 0x06001700 RID: 5888 RVA: 0x0002C898 File Offset: 0x0002AA98
	[Token(Token = "0x6001700")]
	[Address(RVA = "0x2A7A00C", Offset = "0x2A7A00C", VA = "0x2A7A00C")]
	public void method_5()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("HandL");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("");
		GameObject.FindGameObjectWithTag("Hate Speech");
		GameObject.FindGameObjectWithTag("HDRP/Lit");
	}

	// Token: 0x06001701 RID: 5889 RVA: 0x0002C8D8 File Offset: 0x0002AAD8
	[Address(RVA = "0x2A7A0F8", Offset = "0x2A7A0F8", VA = "0x2A7A0F8")]
	[Token(Token = "0x6001701")]
	public void method_6()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Reason: ");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Calling success callback. baking meshes");
		GameObject.FindGameObjectWithTag("username");
		GameObject.FindGameObjectWithTag("_Color");
	}

	// Token: 0x06001702 RID: 5890 RVA: 0x0002C918 File Offset: 0x0002AB18
	[Address(RVA = "0x2A7A1E4", Offset = "0x2A7A1E4", VA = "0x2A7A1E4")]
	[Token(Token = "0x6001702")]
	public void method_7()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("DisableCosmetic");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Room Name: ");
		GameObject.FindGameObjectWithTag("waited for your bullshit unity grrr");
		GameObject.FindGameObjectWithTag("true");
	}

	// Token: 0x06001703 RID: 5891 RVA: 0x0002C958 File Offset: 0x0002AB58
	[Address(RVA = "0x2A7A2D0", Offset = "0x2A7A2D0", VA = "0x2A7A2D0")]
	[Token(Token = "0x6001703")]
	public void method_8()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("[InputHelpers.IsPressed] The value of <button> is out or the supported range.");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("");
		GameObject.FindGameObjectWithTag("Room1");
		GameObject.FindGameObjectWithTag("Wear Hoodie");
	}

	// Token: 0x06001704 RID: 5892 RVA: 0x0002C998 File Offset: 0x0002AB98
	[Token(Token = "0x6001704")]
	[Address(RVA = "0x2A7A3BC", Offset = "0x2A7A3BC", VA = "0x2A7A3BC")]
	public void method_9()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("_Smoothness");
		GameObject.FindGameObjectWithTag("gamemode");
		GameObject.FindGameObjectWithTag("username");
	}

	// Token: 0x06001705 RID: 5893 RVA: 0x0002C9D8 File Offset: 0x0002ABD8
	[Address(RVA = "0x2A7A4A8", Offset = "0x2A7A4A8", VA = "0x2A7A4A8")]
	[Token(Token = "0x6001705")]
	public void method_10()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("poweredup!");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Player");
		GameObject.FindGameObjectWithTag("friend");
		GameObject.FindGameObjectWithTag("username");
	}

	// Token: 0x06001706 RID: 5894 RVA: 0x0002CA18 File Offset: 0x0002AC18
	[Address(RVA = "0x2A7A594", Offset = "0x2A7A594", VA = "0x2A7A594")]
	[Token(Token = "0x6001706")]
	public void method_11()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("BN");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("FLSPTLT");
		GameObject.FindGameObjectWithTag("Skelechin");
		GameObject.FindGameObjectWithTag("\n");
	}

	// Token: 0x06001707 RID: 5895 RVA: 0x0002CA58 File Offset: 0x0002AC58
	[Address(RVA = "0x2A7A680", Offset = "0x2A7A680", VA = "0x2A7A680")]
	[Token(Token = "0x6001707")]
	public void method_12()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("unstuck");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("tutorialCheck");
		GameObject.FindGameObjectWithTag("forced knee");
		GameObject.FindGameObjectWithTag("1BN");
	}

	// Token: 0x06001708 RID: 5896 RVA: 0x0002CA98 File Offset: 0x0002AC98
	[Token(Token = "0x6001708")]
	[Address(RVA = "0x2A7A76C", Offset = "0x2A7A76C", VA = "0x2A7A76C")]
	public void method_13()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("User is on an outdated version of Capuchin. Your version is ");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag(" and for the price of ");
		GameObject.FindGameObjectWithTag("EnableCosmetic");
		GameObject.FindGameObjectWithTag("PRESS AGAIN TO CONFIRM");
	}

	// Token: 0x06001709 RID: 5897 RVA: 0x0002CAD8 File Offset: 0x0002ACD8
	[Address(RVA = "0x2A7A858", Offset = "0x2A7A858", VA = "0x2A7A858")]
	[Token(Token = "0x6001709")]
	public void method_14()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("\n");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.");
		GameObject.FindGameObjectWithTag("NetworkPlayer");
		GameObject.FindGameObjectWithTag("Squeeze");
	}

	// Token: 0x0600170A RID: 5898 RVA: 0x0002CB18 File Offset: 0x0002AD18
	[Address(RVA = "0x2A7A944", Offset = "0x2A7A944", VA = "0x2A7A944")]
	[Token(Token = "0x600170A")]
	public void method_15()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("CASUAL");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("HandL");
		GameObject.FindGameObjectWithTag("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject.FindGameObjectWithTag("NGNNoSound");
	}

	// Token: 0x0600170B RID: 5899 RVA: 0x0002CB58 File Offset: 0x0002AD58
	[Token(Token = "0x600170B")]
	[Address(RVA = "0x2A7AA30", Offset = "0x2A7AA30", VA = "0x2A7AA30")]
	public void method_16()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("spatial");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Time to bake textures: ");
		GameObject.FindGameObjectWithTag("FingerTip");
		GameObject.FindGameObjectWithTag("RightHandAttachPoint");
	}

	// Token: 0x0600170C RID: 5900 RVA: 0x0002CB98 File Offset: 0x0002AD98
	[Address(RVA = "0x2A7AB1C", Offset = "0x2A7AB1C", VA = "0x2A7AB1C")]
	[Token(Token = "0x600170C")]
	public void method_17()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("DISABLE");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("typesOfTalk");
		GameObject.FindGameObjectWithTag("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n");
		GameObject.FindGameObjectWithTag("Time to bake textures: ");
	}

	// Token: 0x0600170D RID: 5901 RVA: 0x0002CBD8 File Offset: 0x0002ADD8
	[Address(RVA = "0x2A7AC08", Offset = "0x2A7AC08", VA = "0x2A7AC08")]
	[Token(Token = "0x600170D")]
	public void method_18()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Tagged");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("FLSPTLT");
		GameObject.FindGameObjectWithTag("Purchased: ");
		GameObject.FindGameObjectWithTag("Tagging");
	}

	// Token: 0x0600170E RID: 5902 RVA: 0x0002CC18 File Offset: 0x0002AE18
	[Token(Token = "0x600170E")]
	[Address(RVA = "0x2A7ACF4", Offset = "0x2A7ACF4", VA = "0x2A7ACF4")]
	public void method_19()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("TurnAmount");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Try Connect To Server...");
		GameObject.FindGameObjectWithTag("username");
		GameObject.FindGameObjectWithTag("Update User Inventory");
	}

	// Token: 0x0600170F RID: 5903 RVA: 0x0002CC58 File Offset: 0x0002AE58
	[Token(Token = "0x600170F")]
	[Address(RVA = "0x2A7ADE0", Offset = "0x2A7ADE0", VA = "0x2A7ADE0")]
	public void method_20()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("{0}/{1:f0}");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Combine textures & build combined mesh all at once");
		GameObject.FindGameObjectWithTag("1BN");
		GameObject.FindGameObjectWithTag("TurnAmount");
	}

	// Token: 0x06001710 RID: 5904 RVA: 0x0002CC98 File Offset: 0x0002AE98
	[Token(Token = "0x6001710")]
	[Address(RVA = "0x2A7AECC", Offset = "0x2A7AECC", VA = "0x2A7AECC")]
	public void method_21()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("User has been reported for: ");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Key");
		GameObject.FindGameObjectWithTag("A Player has left the Room.");
		GameObject.FindGameObjectWithTag("");
	}

	// Token: 0x06001711 RID: 5905 RVA: 0x0002CCD8 File Offset: 0x0002AED8
	[Token(Token = "0x6001711")]
	[Address(RVA = "0x2A7AFB8", Offset = "0x2A7AFB8", VA = "0x2A7AFB8")]
	public void method_22()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Photon token acquired!");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("");
		GameObject.FindGameObjectWithTag("Wear Hoodie");
		GameObject.FindGameObjectWithTag("hh:mmtt");
	}

	// Token: 0x06001712 RID: 5906 RVA: 0x0002CD18 File Offset: 0x0002AF18
	[Address(RVA = "0x2A7B0A4", Offset = "0x2A7B0A4", VA = "0x2A7B0A4")]
	[Token(Token = "0x6001712")]
	public void method_23()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Squeeze");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("On");
		GameObject.FindGameObjectWithTag("Game Started");
		GameObject.FindGameObjectWithTag("Player");
	}

	// Token: 0x06001713 RID: 5907 RVA: 0x0002CD58 File Offset: 0x0002AF58
	[Token(Token = "0x6001713")]
	[Address(RVA = "0x2A7B190", Offset = "0x2A7B190", VA = "0x2A7B190")]
	public void FixedUpdate()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("ORGTARG");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("BLUTARG");
		GameObject.FindGameObjectWithTag("BLUPORT");
		GameObject.FindGameObjectWithTag("ORGPORT");
	}

	// Token: 0x06001714 RID: 5908 RVA: 0x0002CD98 File Offset: 0x0002AF98
	[Address(RVA = "0x2A7B27C", Offset = "0x2A7B27C", VA = "0x2A7B27C")]
	[Token(Token = "0x6001714")]
	public void method_24()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("cheeseTouch");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("True");
		GameObject.FindGameObjectWithTag("Open");
	}

	// Token: 0x06001715 RID: 5909 RVA: 0x0002CDD0 File Offset: 0x0002AFD0
	[Address(RVA = "0x2A7B368", Offset = "0x2A7B368", VA = "0x2A7B368")]
	[Token(Token = "0x6001715")]
	public void method_25()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("htc");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("procedural animation script required on ");
		GameObject.FindGameObjectWithTag("HeadAttachPoint");
		GameObject.FindGameObjectWithTag("Found Gameobject: ");
	}

	// Token: 0x06001716 RID: 5910 RVA: 0x0002CE10 File Offset: 0x0002B010
	[Address(RVA = "0x2A7B454", Offset = "0x2A7B454", VA = "0x2A7B454")]
	[Token(Token = "0x6001716")]
	public void method_26()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("On");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("liftoff failed!");
		GameObject.FindGameObjectWithTag("KeyPos");
		GameObject.FindGameObjectWithTag("/");
	}

	// Token: 0x06001717 RID: 5911 RVA: 0x0002CE50 File Offset: 0x0002B050
	[Token(Token = "0x6001717")]
	[Address(RVA = "0x2A7B540", Offset = "0x2A7B540", VA = "0x2A7B540")]
	public void method_27()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("BN");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Player");
		GameObject.FindGameObjectWithTag("MetaId");
		GameObject.FindGameObjectWithTag("retract broken");
	}

	// Token: 0x06001718 RID: 5912 RVA: 0x0002CE90 File Offset: 0x0002B090
	[Token(Token = "0x6001718")]
	[Address(RVA = "0x2A7B62C", Offset = "0x2A7B62C", VA = "0x2A7B62C")]
	public void method_28()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("TurnAmount");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("You Look Like Butt");
		GameObject.FindGameObjectWithTag("TurnAmount");
		GameObject.FindGameObjectWithTag("Queue");
	}

	// Token: 0x06001719 RID: 5913 RVA: 0x0002CED0 File Offset: 0x0002B0D0
	[Token(Token = "0x6001719")]
	[Address(RVA = "0x2A7B704", Offset = "0x2A7B704", VA = "0x2A7B704")]
	public void method_29()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("ChangeToTagged");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("goDownRPC");
		GameObject.FindGameObjectWithTag("Unpause");
		GameObject.FindGameObjectWithTag("Not connected to room");
	}

	// Token: 0x0600171A RID: 5914 RVA: 0x0002CF10 File Offset: 0x0002B110
	[Token(Token = "0x600171A")]
	[Address(RVA = "0x2A7B7F0", Offset = "0x2A7B7F0", VA = "0x2A7B7F0")]
	public void method_30()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("DISABLE");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("containsStaff");
		GameObject.FindGameObjectWithTag("Open");
		GameObject.FindGameObjectWithTag("_Tint");
	}

	// Token: 0x0600171B RID: 5915 RVA: 0x0002CF50 File Offset: 0x0002B150
	[Address(RVA = "0x2A7B8DC", Offset = "0x2A7B8DC", VA = "0x2A7B8DC")]
	[Token(Token = "0x600171B")]
	public void method_31()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Network Player");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("ChangePlayerSize");
		GameObject.FindGameObjectWithTag("username");
		GameObject.FindGameObjectWithTag("Cannot take elements from an empty buffer.");
	}

	// Token: 0x0600171C RID: 5916 RVA: 0x0002CF90 File Offset: 0x0002B190
	[Address(RVA = "0x2A7B9C8", Offset = "0x2A7B9C8", VA = "0x2A7B9C8")]
	[Token(Token = "0x600171C")]
	public void method_32()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("EnableCosmetic");
		GameObject.FindGameObjectWithTag("PushToTalk");
		GameObject.FindGameObjectWithTag("");
	}

	// Token: 0x0600171D RID: 5917 RVA: 0x0002CFD0 File Offset: 0x0002B1D0
	[Address(RVA = "0x2A7BAB4", Offset = "0x2A7BAB4", VA = "0x2A7BAB4")]
	[Token(Token = "0x600171D")]
	public void method_33()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Not connected to room");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("RainAndThunderWeather");
		GameObject.FindGameObjectWithTag("manual footTimings length should be equal to the leg count");
		GameObject.FindGameObjectWithTag("Player was caught cheating");
	}

	// Token: 0x0600171E RID: 5918 RVA: 0x0002D010 File Offset: 0x0002B210
	[Token(Token = "0x600171E")]
	[Address(RVA = "0x2A7BBA0", Offset = "0x2A7BBA0", VA = "0x2A7BBA0")]
	public void method_34()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("PRESS AGAIN TO CONFIRM");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Player");
		GameObject.FindGameObjectWithTag("Count of rooms ");
		GameObject.FindGameObjectWithTag("_Tint");
	}

	// Token: 0x0600171F RID: 5919 RVA: 0x0002D050 File Offset: 0x0002B250
	[Address(RVA = "0x2A7BC8C", Offset = "0x2A7BC8C", VA = "0x2A7BC8C")]
	[Token(Token = "0x600171F")]
	public void method_35()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("TurnAmount");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("cosmos");
		GameObject.FindGameObjectWithTag("A new Player joined a Room.");
		GameObject.FindGameObjectWithTag("StartGamemode");
	}

	// Token: 0x06001720 RID: 5920 RVA: 0x0002D090 File Offset: 0x0002B290
	[Address(RVA = "0x2A7BD78", Offset = "0x2A7BD78", VA = "0x2A7BD78")]
	[Token(Token = "0x6001720")]
	public void method_36()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("BloodKill");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject.FindGameObjectWithTag("Player");
		GameObject.FindGameObjectWithTag("Is Colliding");
	}

	// Token: 0x06001721 RID: 5921 RVA: 0x0002D0D0 File Offset: 0x0002B2D0
	[Token(Token = "0x6001721")]
	[Address(RVA = "0x2A7BE64", Offset = "0x2A7BE64", VA = "0x2A7BE64")]
	public void method_37()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag(" and for the price of ");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Cannot access index {0}. Buffer size is {1}");
		GameObject.FindGameObjectWithTag("/");
		GameObject.FindGameObjectWithTag("Player");
	}

	// Token: 0x06001722 RID: 5922 RVA: 0x0002D110 File Offset: 0x0002B310
	[Address(RVA = "0x2A7BF50", Offset = "0x2A7BF50", VA = "0x2A7BF50")]
	[Token(Token = "0x6001722")]
	public void method_38()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("username");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Player");
		GameObject.FindGameObjectWithTag(".Please press the button if you would like to play alone");
		GameObject.FindGameObjectWithTag("/");
	}

	// Token: 0x06001723 RID: 5923 RVA: 0x0002D150 File Offset: 0x0002B350
	[Address(RVA = "0x2A7C03C", Offset = "0x2A7C03C", VA = "0x2A7C03C")]
	[Token(Token = "0x6001723")]
	public void method_39()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Vertical");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("Name Changing Error. Error: ");
		GameObject.FindGameObjectWithTag("FingerTip");
		GameObject.FindGameObjectWithTag("Joined a Room.");
	}

	// Token: 0x06001724 RID: 5924 RVA: 0x0002D190 File Offset: 0x0002B390
	[Address(RVA = "0x2A7C128", Offset = "0x2A7C128", VA = "0x2A7C128")]
	[Token(Token = "0x6001724")]
	public void method_40()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Thumb");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("EnableCosmetic");
		GameObject.FindGameObjectWithTag("Name Changing Error. Error: ");
		GameObject.FindGameObjectWithTag("On");
	}

	// Token: 0x06001725 RID: 5925 RVA: 0x0002D1D0 File Offset: 0x0002B3D0
	[Address(RVA = "0x2A7C214", Offset = "0x2A7C214", VA = "0x2A7C214")]
	[Token(Token = "0x6001725")]
	public void method_41()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("Player was caught cheating");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("\n");
		GameObject.FindGameObjectWithTag("HandL");
		GameObject.FindGameObjectWithTag("TurnAmount");
	}

	// Token: 0x06001726 RID: 5926 RVA: 0x0002D210 File Offset: 0x0002B410
	[Address(RVA = "0x2A7C300", Offset = "0x2A7C300", VA = "0x2A7C300")]
	[Token(Token = "0x6001726")]
	public void method_42()
	{
		GameObject gameObject = GameObject.FindGameObjectWithTag("next");
		this.gameObject_5 = gameObject;
		GameObject.FindGameObjectWithTag("spatial");
		GameObject.FindGameObjectWithTag("Faild To Add Winner Money: ");
		GameObject.FindGameObjectWithTag("CASUAL");
	}

	// Token: 0x040002F6 RID: 758
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002F6")]
	public GameObject gameObject_0;

	// Token: 0x040002F7 RID: 759
	[Token(Token = "0x40002F7")]
	[FieldOffset(Offset = "0x20")]
	public GameObject gameObject_1;

	// Token: 0x040002F8 RID: 760
	[Token(Token = "0x40002F8")]
	[FieldOffset(Offset = "0x28")]
	public GameObject gameObject_2;

	// Token: 0x040002F9 RID: 761
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40002F9")]
	public GameObject gameObject_3;

	// Token: 0x040002FA RID: 762
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40002FA")]
	private GameObject gameObject_4;

	// Token: 0x040002FB RID: 763
	[Token(Token = "0x40002FB")]
	[FieldOffset(Offset = "0x40")]
	private GameObject gameObject_5;
}
