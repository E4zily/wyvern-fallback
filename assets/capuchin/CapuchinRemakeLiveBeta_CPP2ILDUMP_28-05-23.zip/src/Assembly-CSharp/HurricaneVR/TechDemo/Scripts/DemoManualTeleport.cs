﻿using System;
using System.Linq;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core.Player;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000129 RID: 297
	[Token(Token = "0x2000129")]
	public class DemoManualTeleport : MonoBehaviour
	{
		// Token: 0x06002ED1 RID: 11985 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002ED1")]
		[Address(RVA = "0x1B25724", Offset = "0x1B25724", VA = "0x1B25724")]
		public void method_0()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002ED2 RID: 11986 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002ED2")]
		[Address(RVA = "0x1B258B8", Offset = "0x1B258B8", VA = "0x1B258B8")]
		public void method_1()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002ED3 RID: 11987 RVA: 0x0005F240 File Offset: 0x0005D440
		[Address(RVA = "0x1B25A4C", Offset = "0x1B25A4C", VA = "0x1B25A4C")]
		[Token(Token = "0x6002ED3")]
		public void method_2()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Vector3 position = this.transform_1.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002ED4 RID: 11988 RVA: 0x0000306E File Offset: 0x0000126E
		[Token(Token = "0x6002ED4")]
		[Address(RVA = "0x1B25B78", Offset = "0x1B25B78", VA = "0x1B25B78")]
		public HVRTeleporter method_3()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002ED5 RID: 11989 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B25B80", Offset = "0x1B25B80", VA = "0x1B25B80")]
		[Token(Token = "0x6002ED5")]
		public void method_4()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002ED6 RID: 11990 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002ED6")]
		[Address(RVA = "0x1B25CAC", Offset = "0x1B25CAC", VA = "0x1B25CAC")]
		public void method_5()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002ED7 RID: 11991 RVA: 0x0005F2DC File Offset: 0x0005D4DC
		[Address(RVA = "0x1B25E40", Offset = "0x1B25E40", VA = "0x1B25E40")]
		[Token(Token = "0x6002ED7")]
		public void method_6()
		{
			UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c <>9__6_;
				DemoManualTeleport.<>c.<>9__6_0 = <>9__6_;
			}
			HVRTeleporter hvrteleporter;
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002ED8 RID: 11992 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Token(Token = "0x6002ED8")]
		[Address(RVA = "0x1B25FD4", Offset = "0x1B25FD4", VA = "0x1B25FD4")]
		public void method_7()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002ED9 RID: 11993 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B26100", Offset = "0x1B26100", VA = "0x1B26100")]
		[Token(Token = "0x6002ED9")]
		public void method_8()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002EDA RID: 11994 RVA: 0x0005F304 File Offset: 0x0005D504
		[Token(Token = "0x6002EDA")]
		[Address(RVA = "0x1B2622C", Offset = "0x1B2622C", VA = "0x1B2622C")]
		public void method_9()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002EDB RID: 11995 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B26358", Offset = "0x1B26358", VA = "0x1B26358")]
		[Token(Token = "0x6002EDB")]
		public void method_10()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002EDC RID: 11996 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002EDC")]
		[Address(RVA = "0x1B264EC", Offset = "0x1B264EC", VA = "0x1B264EC")]
		public HVRTeleporter method_11()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002EDD RID: 11997 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B264F4", Offset = "0x1B264F4", VA = "0x1B264F4")]
		[Token(Token = "0x6002EDD")]
		public void method_12()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002EDE RID: 11998 RVA: 0x0000306E File Offset: 0x0000126E
		[Token(Token = "0x6002EDE")]
		[Address(RVA = "0x1B26620", Offset = "0x1B26620", VA = "0x1B26620")]
		public HVRTeleporter method_13()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002EDF RID: 11999 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B26628", Offset = "0x1B26628", VA = "0x1B26628")]
		[Token(Token = "0x6002EDF")]
		public void method_14()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002EE0 RID: 12000 RVA: 0x0000306E File Offset: 0x0000126E
		[Token(Token = "0x6002EE0")]
		[Address(RVA = "0x1B26754", Offset = "0x1B26754", VA = "0x1B26754")]
		public HVRTeleporter method_15()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002EE1 RID: 12001 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002EE1")]
		[Address(RVA = "0x1B2675C", Offset = "0x1B2675C", VA = "0x1B2675C")]
		public void method_16()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002EE2 RID: 12002 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002EE2")]
		[Address(RVA = "0x1B268F0", Offset = "0x1B268F0", VA = "0x1B268F0")]
		public void method_17(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002EE3 RID: 12003 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B268F8", Offset = "0x1B268F8", VA = "0x1B268F8")]
		[Token(Token = "0x6002EE3")]
		public HVRTeleporter method_18()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002EE4 RID: 12004 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Token(Token = "0x6002EE4")]
		[Address(RVA = "0x1B26900", Offset = "0x1B26900", VA = "0x1B26900")]
		public void method_19()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002EE5 RID: 12005 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Token(Token = "0x6002EE5")]
		[Address(RVA = "0x1B26A2C", Offset = "0x1B26A2C", VA = "0x1B26A2C")]
		public void method_20()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002EE6 RID: 12006 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002EE6")]
		[Address(RVA = "0x1B26B58", Offset = "0x1B26B58", VA = "0x1B26B58")]
		public void method_21()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002EE7 RID: 12007 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B26CEC", Offset = "0x1B26CEC", VA = "0x1B26CEC")]
		[Token(Token = "0x6002EE7")]
		public void method_22()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002EE8 RID: 12008 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B26E18", Offset = "0x1B26E18", VA = "0x1B26E18")]
		[Token(Token = "0x6002EE8")]
		public void method_23(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002EE9 RID: 12009 RVA: 0x0005F304 File Offset: 0x0005D504
		[Token(Token = "0x6002EE9")]
		[Address(RVA = "0x1B26E20", Offset = "0x1B26E20", VA = "0x1B26E20")]
		public void method_24()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002EEA RID: 12010 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B26F4C", Offset = "0x1B26F4C", VA = "0x1B26F4C")]
		[Token(Token = "0x6002EEA")]
		public void method_25(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002EEB RID: 12011 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B26F54", Offset = "0x1B26F54", VA = "0x1B26F54")]
		[Token(Token = "0x6002EEB")]
		public HVRTeleporter method_26()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002EEC RID: 12012 RVA: 0x0000306E File Offset: 0x0000126E
		[Token(Token = "0x6002EEC")]
		[Address(RVA = "0x1B26F5C", Offset = "0x1B26F5C", VA = "0x1B26F5C")]
		public HVRTeleporter method_27()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002EED RID: 12013 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002EED")]
		[Address(RVA = "0x1B26F64", Offset = "0x1B26F64", VA = "0x1B26F64")]
		public void method_28(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002EEE RID: 12014 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B26F6C", Offset = "0x1B26F6C", VA = "0x1B26F6C")]
		[Token(Token = "0x6002EEE")]
		public void method_29()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002EEF RID: 12015 RVA: 0x0005F354 File Offset: 0x0005D554
		[Token(Token = "0x6002EEF")]
		[Address(RVA = "0x1B27100", Offset = "0x1B27100", VA = "0x1B27100")]
		public void method_30()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			this.transform_1;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002EF0 RID: 12016 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002EF0")]
		[Address(RVA = "0x1B2722C", Offset = "0x1B2722C", VA = "0x1B2722C")]
		public void method_31()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002EF1 RID: 12017 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B273C0", Offset = "0x1B273C0", VA = "0x1B273C0")]
		[Token(Token = "0x6002EF1")]
		public void method_32(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002EF2 RID: 12018 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x1B273C8", Offset = "0x1B273C8", VA = "0x1B273C8")]
		[Token(Token = "0x6002EF2")]
		public DemoManualTeleport()
		{
		}

		// Token: 0x06002EF3 RID: 12019 RVA: 0x0005F39C File Offset: 0x0005D59C
		[Address(RVA = "0x1B273D0", Offset = "0x1B273D0", VA = "0x1B273D0")]
		[Token(Token = "0x6002EF3")]
		public void method_33()
		{
			UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				Func<HVRTeleporter, bool> <>9__6_;
				DemoManualTeleport.<>c.<>9__6_0 = <>9__6_;
			}
			HVRTeleporter hvrteleporter;
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002EF4 RID: 12020 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B27564", Offset = "0x1B27564", VA = "0x1B27564")]
		[Token(Token = "0x6002EF4")]
		public void method_34()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002EF5 RID: 12021 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B27690", Offset = "0x1B27690", VA = "0x1B27690")]
		[Token(Token = "0x6002EF5")]
		public HVRTeleporter method_35()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002EF6 RID: 12022 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B27698", Offset = "0x1B27698", VA = "0x1B27698")]
		[Token(Token = "0x6002EF6")]
		public void method_36()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002EF7 RID: 12023 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B277C4", Offset = "0x1B277C4", VA = "0x1B277C4")]
		[Token(Token = "0x6002EF7")]
		public void method_37()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002EF8 RID: 12024 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B278F0", Offset = "0x1B278F0", VA = "0x1B278F0")]
		[Token(Token = "0x6002EF8")]
		public void method_38()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x06002EF9 RID: 12025 RVA: 0x0000306E File Offset: 0x0000126E
		// (set) Token: 0x06002F1E RID: 12062 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x1700007C")]
		public HVRTeleporter HVRTeleporter_0 { [Address(RVA = "0x1B27A84", Offset = "0x1B27A84", VA = "0x1B27A84")] [Token(Token = "0x6002EF9")] get; [Token(Token = "0x6002F1E")] [Address(RVA = "0x1B29B08", Offset = "0x1B29B08", VA = "0x1B29B08")] set; }

		// Token: 0x06002EFA RID: 12026 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B27A8C", Offset = "0x1B27A8C", VA = "0x1B27A8C")]
		[Token(Token = "0x6002EFA")]
		public HVRTeleporter method_39()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002EFB RID: 12027 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B27A94", Offset = "0x1B27A94", VA = "0x1B27A94")]
		[Token(Token = "0x6002EFB")]
		public void method_40()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002EFC RID: 12028 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B27C28", Offset = "0x1B27C28", VA = "0x1B27C28")]
		[Token(Token = "0x6002EFC")]
		public void method_41()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002EFD RID: 12029 RVA: 0x0005F240 File Offset: 0x0005D440
		[Address(RVA = "0x1B27D54", Offset = "0x1B27D54", VA = "0x1B27D54")]
		[Token(Token = "0x6002EFD")]
		public void method_42()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Vector3 position = this.transform_1.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002EFE RID: 12030 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B27E80", Offset = "0x1B27E80", VA = "0x1B27E80")]
		[Token(Token = "0x6002EFE")]
		public void method_43()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002EFF RID: 12031 RVA: 0x0005F3C4 File Offset: 0x0005D5C4
		[Address(RVA = "0x1B27FAC", Offset = "0x1B27FAC", VA = "0x1B27FAC")]
		[Token(Token = "0x6002EFF")]
		public void method_44()
		{
			long num = 1L;
			if (num != 0L)
			{
			}
			Transform exists = this.transform_1;
			if (num != 0L)
			{
			}
			exists;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F00 RID: 12032 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B280D8", Offset = "0x1B280D8", VA = "0x1B280D8")]
		[Token(Token = "0x6002F00")]
		public void method_45()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F01 RID: 12033 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x1B28204", Offset = "0x1B28204", VA = "0x1B28204")]
		[Token(Token = "0x6002F01")]
		public void method_46(HVRTeleporter hvrteleporter_1)
		{
		}

		// Token: 0x06002F02 RID: 12034 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B2820C", Offset = "0x1B2820C", VA = "0x1B2820C")]
		[Token(Token = "0x6002F02")]
		public void method_47()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F03 RID: 12035 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B28338", Offset = "0x1B28338", VA = "0x1B28338")]
		[Token(Token = "0x6002F03")]
		public void method_48(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F04 RID: 12036 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B28340", Offset = "0x1B28340", VA = "0x1B28340")]
		[Token(Token = "0x6002F04")]
		public void method_49()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F05 RID: 12037 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B2846C", Offset = "0x1B2846C", VA = "0x1B2846C")]
		[Token(Token = "0x6002F05")]
		public HVRTeleporter method_50()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F06 RID: 12038 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B28474", Offset = "0x1B28474", VA = "0x1B28474")]
		[Token(Token = "0x6002F06")]
		public void method_51()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F07 RID: 12039 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B285A0", Offset = "0x1B285A0", VA = "0x1B285A0")]
		[Token(Token = "0x6002F07")]
		public void method_52()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F08 RID: 12040 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B28734", Offset = "0x1B28734", VA = "0x1B28734")]
		[Token(Token = "0x6002F08")]
		public void method_53()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F09 RID: 12041 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B28860", Offset = "0x1B28860", VA = "0x1B28860")]
		[Token(Token = "0x6002F09")]
		public void method_54()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F0A RID: 12042 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B2898C", Offset = "0x1B2898C", VA = "0x1B2898C")]
		[Token(Token = "0x6002F0A")]
		public void method_55()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F0B RID: 12043 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B28AB8", Offset = "0x1B28AB8", VA = "0x1B28AB8")]
		[Token(Token = "0x6002F0B")]
		public HVRTeleporter method_56()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F0C RID: 12044 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Token(Token = "0x6002F0C")]
		[Address(RVA = "0x1B28AC0", Offset = "0x1B28AC0", VA = "0x1B28AC0")]
		public void method_57()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F0D RID: 12045 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002F0D")]
		[Address(RVA = "0x1B28BEC", Offset = "0x1B28BEC", VA = "0x1B28BEC")]
		public void method_58()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F0E RID: 12046 RVA: 0x0005F404 File Offset: 0x0005D604
		[Address(RVA = "0x1B28D80", Offset = "0x1B28D80", VA = "0x1B28D80")]
		[Token(Token = "0x6002F0E")]
		public void method_59()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			DemoManualTeleport.<>c.<>9__6_0 = func;
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F0F RID: 12047 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002F0F")]
		[Address(RVA = "0x1B28F14", Offset = "0x1B28F14", VA = "0x1B28F14")]
		public void method_60(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F10 RID: 12048 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Token(Token = "0x6002F10")]
		[Address(RVA = "0x1B28F1C", Offset = "0x1B28F1C", VA = "0x1B28F1C")]
		public void method_61()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F11 RID: 12049 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B29048", Offset = "0x1B29048", VA = "0x1B29048")]
		[Token(Token = "0x6002F11")]
		public void method_62()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F12 RID: 12050 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B29174", Offset = "0x1B29174", VA = "0x1B29174")]
		[Token(Token = "0x6002F12")]
		public void method_63()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F13 RID: 12051 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B292A0", Offset = "0x1B292A0", VA = "0x1B292A0")]
		[Token(Token = "0x6002F13")]
		public void method_64(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F14 RID: 12052 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Token(Token = "0x6002F14")]
		[Address(RVA = "0x1B292A8", Offset = "0x1B292A8", VA = "0x1B292A8")]
		public void method_65()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F15 RID: 12053 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B293D4", Offset = "0x1B293D4", VA = "0x1B293D4")]
		[Token(Token = "0x6002F15")]
		public void method_66()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F16 RID: 12054 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B29500", Offset = "0x1B29500", VA = "0x1B29500")]
		[Token(Token = "0x6002F16")]
		public void method_67()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F17 RID: 12055 RVA: 0x0005F42C File Offset: 0x0005D62C
		[Address(RVA = "0x1B29694", Offset = "0x1B29694", VA = "0x1B29694")]
		[Token(Token = "0x6002F17")]
		public void method_68()
		{
			long num = 1L;
			if (num != 0L)
			{
			}
			if (num != 0L)
			{
			}
		}

		// Token: 0x06002F18 RID: 12056 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B297C0", Offset = "0x1B297C0", VA = "0x1B297C0")]
		[Token(Token = "0x6002F18")]
		public void method_69()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002F19 RID: 12057 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B29954", Offset = "0x1B29954", VA = "0x1B29954")]
		[Token(Token = "0x6002F19")]
		public void method_70(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F1A RID: 12058 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B2995C", Offset = "0x1B2995C", VA = "0x1B2995C")]
		[Token(Token = "0x6002F1A")]
		public HVRTeleporter method_71()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F1B RID: 12059 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B29964", Offset = "0x1B29964", VA = "0x1B29964")]
		[Token(Token = "0x6002F1B")]
		public HVRTeleporter method_72()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F1C RID: 12060 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B2996C", Offset = "0x1B2996C", VA = "0x1B2996C")]
		[Token(Token = "0x6002F1C")]
		public HVRTeleporter method_73()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F1D RID: 12061 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B29974", Offset = "0x1B29974", VA = "0x1B29974")]
		[Token(Token = "0x6002F1D")]
		public void method_74()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F1F RID: 12063 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B29B10", Offset = "0x1B29B10", VA = "0x1B29B10")]
		[Token(Token = "0x6002F1F")]
		public void method_75()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F20 RID: 12064 RVA: 0x0005F304 File Offset: 0x0005D504
		[Token(Token = "0x6002F20")]
		[Address(RVA = "0x1B29C3C", Offset = "0x1B29C3C", VA = "0x1B29C3C")]
		public void method_76()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F21 RID: 12065 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002F21")]
		[Address(RVA = "0x1B29D68", Offset = "0x1B29D68", VA = "0x1B29D68")]
		public void method_77()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F22 RID: 12066 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B29EFC", Offset = "0x1B29EFC", VA = "0x1B29EFC")]
		[Token(Token = "0x6002F22")]
		public void method_78(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F23 RID: 12067 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B29F04", Offset = "0x1B29F04", VA = "0x1B29F04")]
		[Token(Token = "0x6002F23")]
		public void method_79()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F24 RID: 12068 RVA: 0x0000306E File Offset: 0x0000126E
		[Token(Token = "0x6002F24")]
		[Address(RVA = "0x1B2A030", Offset = "0x1B2A030", VA = "0x1B2A030")]
		public HVRTeleporter method_80()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F25 RID: 12069 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002F25")]
		[Address(RVA = "0x1B2A038", Offset = "0x1B2A038", VA = "0x1B2A038")]
		public void method_81()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F26 RID: 12070 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B2A1CC", Offset = "0x1B2A1CC", VA = "0x1B2A1CC")]
		[Token(Token = "0x6002F26")]
		public HVRTeleporter method_82()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F27 RID: 12071 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B2A1D4", Offset = "0x1B2A1D4", VA = "0x1B2A1D4")]
		[Token(Token = "0x6002F27")]
		public void method_83()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F28 RID: 12072 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002F28")]
		[Address(RVA = "0x1B2A300", Offset = "0x1B2A300", VA = "0x1B2A300")]
		public void method_84()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002F29 RID: 12073 RVA: 0x0000306E File Offset: 0x0000126E
		[Token(Token = "0x6002F29")]
		[Address(RVA = "0x1B2A494", Offset = "0x1B2A494", VA = "0x1B2A494")]
		public HVRTeleporter method_85()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F2A RID: 12074 RVA: 0x0005F444 File Offset: 0x0005D644
		[Token(Token = "0x6002F2A")]
		[Address(RVA = "0x1B2A49C", Offset = "0x1B2A49C", VA = "0x1B2A49C")]
		public void method_86()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			if (DemoManualTeleport.<>c.<>9__6_0 != null)
			{
			}
			Func<HVRTeleporter, bool> func;
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F2B RID: 12075 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B2A630", Offset = "0x1B2A630", VA = "0x1B2A630")]
		[Token(Token = "0x6002F2B")]
		public void method_87(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F2C RID: 12076 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002F2C")]
		[Address(RVA = "0x1B2A638", Offset = "0x1B2A638", VA = "0x1B2A638")]
		public void method_88(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F2D RID: 12077 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B2A640", Offset = "0x1B2A640", VA = "0x1B2A640")]
		[Token(Token = "0x6002F2D")]
		public void method_89(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F2E RID: 12078 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B2A648", Offset = "0x1B2A648", VA = "0x1B2A648")]
		[Token(Token = "0x6002F2E")]
		public void method_90()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F2F RID: 12079 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002F2F")]
		[Address(RVA = "0x1B2A774", Offset = "0x1B2A774", VA = "0x1B2A774")]
		public void method_91(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F30 RID: 12080 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B2A77C", Offset = "0x1B2A77C", VA = "0x1B2A77C")]
		[Token(Token = "0x6002F30")]
		public HVRTeleporter method_92()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F31 RID: 12081 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B2A784", Offset = "0x1B2A784", VA = "0x1B2A784")]
		[Token(Token = "0x6002F31")]
		public void method_93(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F32 RID: 12082 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002F32")]
		[Address(RVA = "0x1B2A78C", Offset = "0x1B2A78C", VA = "0x1B2A78C")]
		public void method_94(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F33 RID: 12083 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002F33")]
		[Address(RVA = "0x1B2A794", Offset = "0x1B2A794", VA = "0x1B2A794")]
		public void method_95(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F34 RID: 12084 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B2A79C", Offset = "0x1B2A79C", VA = "0x1B2A79C")]
		[Token(Token = "0x6002F34")]
		public HVRTeleporter method_96()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F35 RID: 12085 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002F35")]
		[Address(RVA = "0x1B2A7A4", Offset = "0x1B2A7A4", VA = "0x1B2A7A4")]
		public void method_97(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F36 RID: 12086 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B2A7AC", Offset = "0x1B2A7AC", VA = "0x1B2A7AC")]
		[Token(Token = "0x6002F36")]
		public void method_98()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F37 RID: 12087 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B2A8D8", Offset = "0x1B2A8D8", VA = "0x1B2A8D8")]
		[Token(Token = "0x6002F37")]
		public void method_99()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F38 RID: 12088 RVA: 0x0005F304 File Offset: 0x0005D504
		[Token(Token = "0x6002F38")]
		[Address(RVA = "0x1B2AA04", Offset = "0x1B2AA04", VA = "0x1B2AA04")]
		public void method_100()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F39 RID: 12089 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B2AB30", Offset = "0x1B2AB30", VA = "0x1B2AB30")]
		[Token(Token = "0x6002F39")]
		public void method_101()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F3A RID: 12090 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B2AC5C", Offset = "0x1B2AC5C", VA = "0x1B2AC5C")]
		[Token(Token = "0x6002F3A")]
		public void method_102()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F3B RID: 12091 RVA: 0x0005F304 File Offset: 0x0005D504
		[Address(RVA = "0x1B2ADF0", Offset = "0x1B2ADF0", VA = "0x1B2ADF0")]
		[Token(Token = "0x6002F3B")]
		public void method_103()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F3C RID: 12092 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B2AF1C", Offset = "0x1B2AF1C", VA = "0x1B2AF1C")]
		[Token(Token = "0x6002F3C")]
		public void method_104(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F3D RID: 12093 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B2AF24", Offset = "0x1B2AF24", VA = "0x1B2AF24")]
		[Token(Token = "0x6002F3D")]
		public void method_105()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F3E RID: 12094 RVA: 0x0000306E File Offset: 0x0000126E
		[Token(Token = "0x6002F3E")]
		[Address(RVA = "0x1B2B050", Offset = "0x1B2B050", VA = "0x1B2B050")]
		public HVRTeleporter method_106()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F3F RID: 12095 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B2B058", Offset = "0x1B2B058", VA = "0x1B2B058")]
		[Token(Token = "0x6002F3F")]
		public void method_107(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F40 RID: 12096 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B2B060", Offset = "0x1B2B060", VA = "0x1B2B060")]
		[Token(Token = "0x6002F40")]
		public HVRTeleporter method_108()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F41 RID: 12097 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B2B068", Offset = "0x1B2B068", VA = "0x1B2B068")]
		[Token(Token = "0x6002F41")]
		public void method_109()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F42 RID: 12098 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Token(Token = "0x6002F42")]
		[Address(RVA = "0x1B2B194", Offset = "0x1B2B194", VA = "0x1B2B194")]
		public void method_110()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F43 RID: 12099 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002F43")]
		[Address(RVA = "0x1B2B2C0", Offset = "0x1B2B2C0", VA = "0x1B2B2C0")]
		public void method_111(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F44 RID: 12100 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002F44")]
		[Address(RVA = "0x1B2B2C8", Offset = "0x1B2B2C8", VA = "0x1B2B2C8")]
		public void method_112(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F45 RID: 12101 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002F45")]
		[Address(RVA = "0x1B2B2D0", Offset = "0x1B2B2D0", VA = "0x1B2B2D0")]
		public void method_113()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F46 RID: 12102 RVA: 0x00003076 File Offset: 0x00001276
		[Token(Token = "0x6002F46")]
		[Address(RVA = "0x1B2B464", Offset = "0x1B2B464", VA = "0x1B2B464")]
		public void method_114(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F47 RID: 12103 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002F47")]
		[Address(RVA = "0x1B2B46C", Offset = "0x1B2B46C", VA = "0x1B2B46C")]
		public void method_115()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F48 RID: 12104 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B2B600", Offset = "0x1B2B600", VA = "0x1B2B600")]
		[Token(Token = "0x6002F48")]
		public void method_116()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F49 RID: 12105 RVA: 0x0000306E File Offset: 0x0000126E
		[Token(Token = "0x6002F49")]
		[Address(RVA = "0x1B2B794", Offset = "0x1B2B794", VA = "0x1B2B794")]
		public HVRTeleporter method_117()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F4A RID: 12106 RVA: 0x0000306E File Offset: 0x0000126E
		[Address(RVA = "0x1B2B79C", Offset = "0x1B2B79C", VA = "0x1B2B79C")]
		[Token(Token = "0x6002F4A")]
		public HVRTeleporter method_118()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F4B RID: 12107 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B2B7A4", Offset = "0x1B2B7A4", VA = "0x1B2B7A4")]
		[Token(Token = "0x6002F4B")]
		public void method_119()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F4C RID: 12108 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B2B938", Offset = "0x1B2B938", VA = "0x1B2B938")]
		[Token(Token = "0x6002F4C")]
		public void method_120(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F4D RID: 12109 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002F4D")]
		[Address(RVA = "0x1B2B940", Offset = "0x1B2B940", VA = "0x1B2B940")]
		public HVRTeleporter method_121()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002F4E RID: 12110 RVA: 0x0005F304 File Offset: 0x0005D504
		[Token(Token = "0x6002F4E")]
		[Address(RVA = "0x1B2B948", Offset = "0x1B2B948", VA = "0x1B2B948")]
		public void method_122()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_1;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F4F RID: 12111 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Token(Token = "0x6002F4F")]
		[Address(RVA = "0x1B2BA74", Offset = "0x1B2BA74", VA = "0x1B2BA74")]
		public void method_123()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F50 RID: 12112 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B2BBA0", Offset = "0x1B2BBA0", VA = "0x1B2BBA0")]
		[Token(Token = "0x6002F50")]
		public void method_124()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F51 RID: 12113 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B2BCCC", Offset = "0x1B2BCCC", VA = "0x1B2BCCC")]
		[Token(Token = "0x6002F51")]
		public void method_125(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F52 RID: 12114 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002F52")]
		[Address(RVA = "0x1B2BCD4", Offset = "0x1B2BCD4", VA = "0x1B2BCD4")]
		public void Start()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F53 RID: 12115 RVA: 0x0000306E File Offset: 0x0000126E
		[Token(Token = "0x6002F53")]
		[Address(RVA = "0x1B2BE68", Offset = "0x1B2BE68", VA = "0x1B2BE68")]
		public HVRTeleporter method_126()
		{
			return this.hvrteleporter_0;
		}

		// Token: 0x06002F54 RID: 12116 RVA: 0x0005F470 File Offset: 0x0005D670
		[Token(Token = "0x6002F54")]
		[Address(RVA = "0x1B2BE70", Offset = "0x1B2BE70", VA = "0x1B2BE70")]
		public void method_127()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			if (num != 0L)
			{
			}
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_1.forward;
		}

		// Token: 0x06002F55 RID: 12117 RVA: 0x0005F210 File Offset: 0x0005D410
		[Address(RVA = "0x1B2BF9C", Offset = "0x1B2BF9C", VA = "0x1B2BF9C")]
		[Token(Token = "0x6002F55")]
		public void method_128()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F56 RID: 12118 RVA: 0x0005F210 File Offset: 0x0005D410
		[Token(Token = "0x6002F56")]
		[Address(RVA = "0x1B2C130", Offset = "0x1B2C130", VA = "0x1B2C130")]
		public void method_129()
		{
			HVRTeleporter[] array = UnityEngine.Object.FindObjectsOfType<HVRTeleporter>();
			Func<HVRTeleporter, bool> func;
			if (DemoManualTeleport.<>c.<>9__6_0 == null)
			{
				DemoManualTeleport.<>c.<>9__6_0 = func;
			}
			HVRTeleporter hvrteleporter = Enumerable.FirstOrDefault<HVRTeleporter>(array, func);
			this.hvrteleporter_0 = hvrteleporter;
		}

		// Token: 0x06002F57 RID: 12119 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B2C2C4", Offset = "0x1B2C2C4", VA = "0x1B2C2C4")]
		[Token(Token = "0x6002F57")]
		public void method_130()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x06002F58 RID: 12120 RVA: 0x00003076 File Offset: 0x00001276
		[Address(RVA = "0x1B2C3F0", Offset = "0x1B2C3F0", VA = "0x1B2C3F0")]
		[Token(Token = "0x6002F58")]
		public void method_131(HVRTeleporter hvrteleporter_1)
		{
			this.hvrteleporter_0 = hvrteleporter_1;
		}

		// Token: 0x06002F59 RID: 12121 RVA: 0x0005F28C File Offset: 0x0005D48C
		[Address(RVA = "0x1B2C3F8", Offset = "0x1B2C3F8", VA = "0x1B2C3F8")]
		[Token(Token = "0x6002F59")]
		public void method_132()
		{
			long num = 1L;
			HVRTeleporter exists = this.hvrteleporter_0;
			if (num != 0L)
			{
			}
			exists;
			Transform exists2 = this.transform_0;
			if (num != 0L)
			{
			}
			exists2;
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Vector3 forward = this.transform_0.forward;
		}

		// Token: 0x040005C5 RID: 1477
		[Token(Token = "0x40005C5")]
		[FieldOffset(Offset = "0x18")]
		public Transform transform_0;

		// Token: 0x040005C6 RID: 1478
		[Token(Token = "0x40005C6")]
		[FieldOffset(Offset = "0x20")]
		public Transform transform_1;

		// Token: 0x040005C7 RID: 1479
		[FieldOffset(Offset = "0x28")]
		[CompilerGenerated]
		[Token(Token = "0x40005C7")]
		private HVRTeleporter hvrteleporter_0;
	}
}
