﻿using System;
using System.Linq;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core;
using HurricaneVR.Framework.Core.Grabbers;
using HurricaneVR.Framework.Core.HandPoser;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000116 RID: 278
	[Token(Token = "0x2000116")]
	public class DemoCodeGrabbing : MonoBehaviour
	{
		// Token: 0x060029EA RID: 10730 RVA: 0x0005A674 File Offset: 0x00058874
		[Token(Token = "0x60029EA")]
		[Address(RVA = "0x2A17100", Offset = "0x2A17100", VA = "0x2A17100")]
		public void method_0()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x060029EB RID: 10731 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x60029EB")]
		[Address(RVA = "0x2A17264", Offset = "0x2A17264", VA = "0x2A17264")]
		public void method_1(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x060029EC RID: 10732 RVA: 0x0005A6CC File Offset: 0x000588CC
		[Address(RVA = "0x2A1726C", Offset = "0x2A1726C", VA = "0x2A1726C")]
		[Token(Token = "0x60029EC")]
		public void method_2()
		{
			long num = 1L;
			if (num != 0L)
			{
			}
			if (num != 0L)
			{
			}
			if (num != 0L)
			{
			}
		}

		// Token: 0x060029ED RID: 10733 RVA: 0x0005A674 File Offset: 0x00058874
		[Address(RVA = "0x2A173D0", Offset = "0x2A173D0", VA = "0x2A173D0")]
		[Token(Token = "0x60029ED")]
		public void method_3()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x060029EE RID: 10734 RVA: 0x00002E1C File Offset: 0x0000101C
		[Token(Token = "0x60029EE")]
		[Address(RVA = "0x2A17534", Offset = "0x2A17534", VA = "0x2A17534")]
		public HVRHandGrabber method_4()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x060029EF RID: 10735 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x60029EF")]
		[Address(RVA = "0x2A1753C", Offset = "0x2A1753C", VA = "0x2A1753C")]
		public void method_5(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x060029F0 RID: 10736 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A17544", Offset = "0x2A17544", VA = "0x2A17544")]
		[Token(Token = "0x60029F0")]
		public HVRHandGrabber method_6()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x060029F1 RID: 10737 RVA: 0x0005A674 File Offset: 0x00058874
		[Token(Token = "0x60029F1")]
		[Address(RVA = "0x2A1754C", Offset = "0x2A1754C", VA = "0x2A1754C")]
		public void method_7()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x060029F2 RID: 10738 RVA: 0x0005A6E4 File Offset: 0x000588E4
		[Address(RVA = "0x2A176B0", Offset = "0x2A176B0", VA = "0x2A176B0")]
		[Token(Token = "0x60029F2")]
		public void method_8()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
		}

		// Token: 0x060029F3 RID: 10739 RVA: 0x0005A674 File Offset: 0x00058874
		[Token(Token = "0x60029F3")]
		[Address(RVA = "0x2A17844", Offset = "0x2A17844", VA = "0x2A17844")]
		public void method_9()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x060029F4 RID: 10740 RVA: 0x0005A674 File Offset: 0x00058874
		[Token(Token = "0x60029F4")]
		[Address(RVA = "0x2A179A8", Offset = "0x2A179A8", VA = "0x2A179A8")]
		public void method_10()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x060029F5 RID: 10741 RVA: 0x0005A674 File Offset: 0x00058874
		[Token(Token = "0x60029F5")]
		[Address(RVA = "0x2A17B0C", Offset = "0x2A17B0C", VA = "0x2A17B0C")]
		public void method_11()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x060029F6 RID: 10742 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A17C70", Offset = "0x2A17C70", VA = "0x2A17C70")]
		[Token(Token = "0x60029F6")]
		public HVRHandGrabber method_12()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x060029F7 RID: 10743 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A17C78", Offset = "0x2A17C78", VA = "0x2A17C78")]
		[Token(Token = "0x60029F7")]
		public void method_13(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x060029F8 RID: 10744 RVA: 0x00002E1C File Offset: 0x0000101C
		[Token(Token = "0x60029F8")]
		[Address(RVA = "0x2A17C80", Offset = "0x2A17C80", VA = "0x2A17C80")]
		public HVRHandGrabber method_14()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x060029F9 RID: 10745 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A17C88", Offset = "0x2A17C88", VA = "0x2A17C88")]
		[Token(Token = "0x60029F9")]
		public HVRHandGrabber method_15()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x060029FA RID: 10746 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A17C90", Offset = "0x2A17C90", VA = "0x2A17C90")]
		[Token(Token = "0x60029FA")]
		public HVRHandGrabber method_16()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x060029FB RID: 10747 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x60029FB")]
		[Address(RVA = "0x2A17C98", Offset = "0x2A17C98", VA = "0x2A17C98")]
		public void method_17(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x060029FC RID: 10748 RVA: 0x00002E1C File Offset: 0x0000101C
		[Token(Token = "0x60029FC")]
		[Address(RVA = "0x2A17CA0", Offset = "0x2A17CA0", VA = "0x2A17CA0")]
		public HVRHandGrabber method_18()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x060029FD RID: 10749 RVA: 0x0005A674 File Offset: 0x00058874
		[Address(RVA = "0x2A17CA8", Offset = "0x2A17CA8", VA = "0x2A17CA8")]
		[Token(Token = "0x60029FD")]
		public void method_19()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x060029FE RID: 10750 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A17E0C", Offset = "0x2A17E0C", VA = "0x2A17E0C")]
		[Token(Token = "0x60029FE")]
		public HVRHandGrabber method_20()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x060029FF RID: 10751 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A17E14", Offset = "0x2A17E14", VA = "0x2A17E14")]
		[Token(Token = "0x60029FF")]
		public HVRHandGrabber method_21()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A00 RID: 10752 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A17E1C", Offset = "0x2A17E1C", VA = "0x2A17E1C")]
		[Token(Token = "0x6002A00")]
		public HVRHandGrabber method_22()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A01 RID: 10753 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A17E24", Offset = "0x2A17E24", VA = "0x2A17E24")]
		[Token(Token = "0x6002A01")]
		public void method_23()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A02 RID: 10754 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A17FB8", Offset = "0x2A17FB8", VA = "0x2A17FB8")]
		[Token(Token = "0x6002A02")]
		public void method_24()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A03 RID: 10755 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A1814C", Offset = "0x2A1814C", VA = "0x2A1814C")]
		[Token(Token = "0x6002A03")]
		public void method_25(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A04 RID: 10756 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A18154", Offset = "0x2A18154", VA = "0x2A18154")]
		[Token(Token = "0x6002A04")]
		public void method_26()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A05 RID: 10757 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A182E8", Offset = "0x2A182E8", VA = "0x2A182E8")]
		[Token(Token = "0x6002A05")]
		public void method_27()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A06 RID: 10758 RVA: 0x0005A674 File Offset: 0x00058874
		[Address(RVA = "0x2A1847C", Offset = "0x2A1847C", VA = "0x2A1847C")]
		[Token(Token = "0x6002A06")]
		public void method_28()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A07 RID: 10759 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x6002A07")]
		[Address(RVA = "0x2A185E0", Offset = "0x2A185E0", VA = "0x2A185E0")]
		public void method_29(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A08 RID: 10760 RVA: 0x0005A674 File Offset: 0x00058874
		[Token(Token = "0x6002A08")]
		[Address(RVA = "0x2A185E8", Offset = "0x2A185E8", VA = "0x2A185E8")]
		public void method_30()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A09 RID: 10761 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A1874C", Offset = "0x2A1874C", VA = "0x2A1874C")]
		[Token(Token = "0x6002A09")]
		public void method_31()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A0A RID: 10762 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A188E0", Offset = "0x2A188E0", VA = "0x2A188E0")]
		[Token(Token = "0x6002A0A")]
		public HVRHandGrabber method_32()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A0B RID: 10763 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A188E8", Offset = "0x2A188E8", VA = "0x2A188E8")]
		[Token(Token = "0x6002A0B")]
		public void method_33()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A0C RID: 10764 RVA: 0x00002E1C File Offset: 0x0000101C
		[Token(Token = "0x6002A0C")]
		[Address(RVA = "0x2A18A7C", Offset = "0x2A18A7C", VA = "0x2A18A7C")]
		public HVRHandGrabber method_34()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A0D RID: 10765 RVA: 0x0005A674 File Offset: 0x00058874
		[Address(RVA = "0x2A18A84", Offset = "0x2A18A84", VA = "0x2A18A84")]
		[Token(Token = "0x6002A0D")]
		public void method_35()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A0E RID: 10766 RVA: 0x0005A73C File Offset: 0x0005893C
		[Token(Token = "0x6002A0E")]
		[Address(RVA = "0x2A18BE8", Offset = "0x2A18BE8", VA = "0x2A18BE8")]
		public void method_36()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> <>9__7_ = DemoCodeGrabbing.<>c.<>9__7_0;
			if (<>9__7_ == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = <>9__7_;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, <>9__7_);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A0F RID: 10767 RVA: 0x00002E1C File Offset: 0x0000101C
		[Token(Token = "0x6002A0F")]
		[Address(RVA = "0x2A18D7C", Offset = "0x2A18D7C", VA = "0x2A18D7C")]
		public HVRHandGrabber method_37()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A10 RID: 10768 RVA: 0x0005A70C File Offset: 0x0005890C
		[Token(Token = "0x6002A10")]
		[Address(RVA = "0x2A18D84", Offset = "0x2A18D84", VA = "0x2A18D84")]
		public void Start()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A11 RID: 10769 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A18F18", Offset = "0x2A18F18", VA = "0x2A18F18")]
		[Token(Token = "0x6002A11")]
		public void method_38()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A12 RID: 10770 RVA: 0x00002E1C File Offset: 0x0000101C
		[Token(Token = "0x6002A12")]
		[Address(RVA = "0x2A190AC", Offset = "0x2A190AC", VA = "0x2A190AC")]
		public HVRHandGrabber method_39()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A13 RID: 10771 RVA: 0x0005A770 File Offset: 0x00058970
		[Token(Token = "0x6002A13")]
		[Address(RVA = "0x2A190B4", Offset = "0x2A190B4", VA = "0x2A190B4")]
		public void method_40()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			if (this.ࢦ\u0702ࢡ\u058F_0 == ࢦ\u0702ࢡ\u058F.ࡈ\u07A9\u06D4\u0706)
			{
				HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
				HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
				HVRGrabbable y = this.hvrgrabbable_0;
				if (hvrhandGrabber != null)
				{
				}
				חࠀ_u0895_u == y;
				return;
			}
			if (!this.hvrhandGrabber_0.<\u0640Ԁ\u055Eݝ>k__BackingField)
			{
			}
		}

		// Token: 0x06002A14 RID: 10772 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A19214", Offset = "0x2A19214", VA = "0x2A19214")]
		[Token(Token = "0x6002A14")]
		public void method_41(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A15 RID: 10773 RVA: 0x0005A7E0 File Offset: 0x000589E0
		[Token(Token = "0x6002A15")]
		[Address(RVA = "0x2A1921C", Offset = "0x2A1921C", VA = "0x2A1921C")]
		public void method_42()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			if (DemoCodeGrabbing.<>c.<>9__7_0 != null)
			{
			}
			Func<HVRHandGrabber, bool> func;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A16 RID: 10774 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A193B0", Offset = "0x2A193B0", VA = "0x2A193B0")]
		[Token(Token = "0x6002A16")]
		public void method_43(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A17 RID: 10775 RVA: 0x0005A674 File Offset: 0x00058874
		[Token(Token = "0x6002A17")]
		[Address(RVA = "0x2A193B8", Offset = "0x2A193B8", VA = "0x2A193B8")]
		public void method_44()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A18 RID: 10776 RVA: 0x0005A70C File Offset: 0x0005890C
		[Token(Token = "0x6002A18")]
		[Address(RVA = "0x2A1951C", Offset = "0x2A1951C", VA = "0x2A1951C")]
		public void method_45()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A19 RID: 10777 RVA: 0x0005A80C File Offset: 0x00058A0C
		[Address(RVA = "0x2A196B0", Offset = "0x2A196B0", VA = "0x2A196B0")]
		[Token(Token = "0x6002A19")]
		public void method_46()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> <>9__7_ = DemoCodeGrabbing.<>c.<>9__7_0;
			if (<>9__7_ == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = <>9__7_;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, <>9__7_);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A1A RID: 10778 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A19844", Offset = "0x2A19844", VA = "0x2A19844")]
		[Token(Token = "0x6002A1A")]
		public void method_47()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A1B RID: 10779 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A199D8", Offset = "0x2A199D8", VA = "0x2A199D8")]
		[Token(Token = "0x6002A1B")]
		public HVRHandGrabber method_48()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A1C RID: 10780 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A199E0", Offset = "0x2A199E0", VA = "0x2A199E0")]
		[Token(Token = "0x6002A1C")]
		public HVRHandGrabber method_49()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A1D RID: 10781 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A199E8", Offset = "0x2A199E8", VA = "0x2A199E8")]
		[Token(Token = "0x6002A1D")]
		public void method_50(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A1E RID: 10782 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x6002A1E")]
		[Address(RVA = "0x2A199F0", Offset = "0x2A199F0", VA = "0x2A199F0")]
		public void method_51(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A1F RID: 10783 RVA: 0x0005A840 File Offset: 0x00058A40
		[Token(Token = "0x6002A1F")]
		[Address(RVA = "0x2A199F8", Offset = "0x2A199F8", VA = "0x2A199F8")]
		public void method_52()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A20 RID: 10784 RVA: 0x0005A674 File Offset: 0x00058874
		[Token(Token = "0x6002A20")]
		[Address(RVA = "0x2A19B5C", Offset = "0x2A19B5C", VA = "0x2A19B5C")]
		public void method_53()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A21 RID: 10785 RVA: 0x0005A898 File Offset: 0x00058A98
		[Address(RVA = "0x2A19CC0", Offset = "0x2A19CC0", VA = "0x2A19CC0")]
		[Token(Token = "0x6002A21")]
		public void method_54()
		{
			UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				Func<HVRHandGrabber, bool> <>9__7_;
				DemoCodeGrabbing.<>c.<>9__7_0 = <>9__7_;
			}
			HVRHandGrabber hvrhandGrabber;
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A22 RID: 10786 RVA: 0x0005A8C0 File Offset: 0x00058AC0
		[Address(RVA = "0x2A19E54", Offset = "0x2A19E54", VA = "0x2A19E54")]
		[Token(Token = "0x6002A22")]
		public void method_55()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			this.hvrhandGrabber_0;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A23 RID: 10787 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x2A19FB8", Offset = "0x2A19FB8", VA = "0x2A19FB8")]
		[Token(Token = "0x6002A23")]
		public DemoCodeGrabbing()
		{
		}

		// Token: 0x06002A24 RID: 10788 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A19FC0", Offset = "0x2A19FC0", VA = "0x2A19FC0")]
		[Token(Token = "0x6002A24")]
		public void method_56(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A25 RID: 10789 RVA: 0x0005A914 File Offset: 0x00058B14
		[Address(RVA = "0x2A19FC8", Offset = "0x2A19FC8", VA = "0x2A19FC8")]
		[Token(Token = "0x6002A25")]
		public void method_57()
		{
		}

		// Token: 0x06002A26 RID: 10790 RVA: 0x0005A674 File Offset: 0x00058874
		[Address(RVA = "0x2A1A12C", Offset = "0x2A1A12C", VA = "0x2A1A12C")]
		[Token(Token = "0x6002A26")]
		public void method_58()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A27 RID: 10791 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2A1A290", Offset = "0x2A1A290", VA = "0x2A1A290")]
		[Token(Token = "0x6002A27")]
		public void method_59(HVRHandGrabber hvrhandGrabber_1)
		{
		}

		// Token: 0x06002A28 RID: 10792 RVA: 0x0005A6E4 File Offset: 0x000588E4
		[Address(RVA = "0x2A1A298", Offset = "0x2A1A298", VA = "0x2A1A298")]
		[Token(Token = "0x6002A28")]
		public void method_60()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
		}

		// Token: 0x06002A29 RID: 10793 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A1A42C", Offset = "0x2A1A42C", VA = "0x2A1A42C")]
		[Token(Token = "0x6002A29")]
		public void method_61(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06002A2A RID: 10794 RVA: 0x00002E1C File Offset: 0x0000101C
		// (set) Token: 0x06002A3B RID: 10811 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x17000076")]
		public HVRHandGrabber HVRHandGrabber_0 { [Token(Token = "0x6002A2A")] [Address(RVA = "0x2A1A434", Offset = "0x2A1A434", VA = "0x2A1A434")] get; [Token(Token = "0x6002A3B")] [Address(RVA = "0x2A1B7AC", Offset = "0x2A1B7AC", VA = "0x2A1B7AC")] set; }

		// Token: 0x06002A2B RID: 10795 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002A2B")]
		[Address(RVA = "0x2A1A43C", Offset = "0x2A1A43C", VA = "0x2A1A43C")]
		public void method_62()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002A2C RID: 10796 RVA: 0x0005A674 File Offset: 0x00058874
		[Address(RVA = "0x2A1A5D0", Offset = "0x2A1A5D0", VA = "0x2A1A5D0")]
		[Token(Token = "0x6002A2C")]
		public void method_63()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A2D RID: 10797 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A1A734", Offset = "0x2A1A734", VA = "0x2A1A734")]
		[Token(Token = "0x6002A2D")]
		public void method_64()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A2E RID: 10798 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A1A8C8", Offset = "0x2A1A8C8", VA = "0x2A1A8C8")]
		[Token(Token = "0x6002A2E")]
		public void method_65()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A2F RID: 10799 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A1AA5C", Offset = "0x2A1AA5C", VA = "0x2A1AA5C")]
		[Token(Token = "0x6002A2F")]
		public void method_66(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A30 RID: 10800 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A1AA64", Offset = "0x2A1AA64", VA = "0x2A1AA64")]
		[Token(Token = "0x6002A30")]
		public void method_67(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A31 RID: 10801 RVA: 0x0005A674 File Offset: 0x00058874
		[Address(RVA = "0x2A1AA6C", Offset = "0x2A1AA6C", VA = "0x2A1AA6C")]
		[Token(Token = "0x6002A31")]
		public void method_68()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A32 RID: 10802 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A1ABD0", Offset = "0x2A1ABD0", VA = "0x2A1ABD0")]
		[Token(Token = "0x6002A32")]
		public void method_69()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A33 RID: 10803 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A1AD64", Offset = "0x2A1AD64", VA = "0x2A1AD64")]
		[Token(Token = "0x6002A33")]
		public void method_70()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A34 RID: 10804 RVA: 0x0005A924 File Offset: 0x00058B24
		[Address(RVA = "0x2A1AEF8", Offset = "0x2A1AEF8", VA = "0x2A1AEF8")]
		[Token(Token = "0x6002A34")]
		public void method_71()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			if (this.ࢦ\u0702ࢡ\u058F_0 == ࢦ\u0702ࢡ\u058F.ࡈ\u07A9\u06D4\u0706)
			{
				HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
				HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
				HVRGrabbable y = this.hvrgrabbable_0;
				if (hvrhandGrabber != null)
				{
				}
				חࠀ_u0895_u == y;
				return;
			}
			if (!this.hvrhandGrabber_0.<\u0640Ԁ\u055Eݝ>k__BackingField)
			{
			}
		}

		// Token: 0x06002A35 RID: 10805 RVA: 0x0005A994 File Offset: 0x00058B94
		[Token(Token = "0x6002A35")]
		[Address(RVA = "0x2A1B058", Offset = "0x2A1B058", VA = "0x2A1B058")]
		public void method_72()
		{
			long num = 1L;
			if (num != 0L)
			{
			}
			if (num != 0L)
			{
			}
			if (num == 0L)
			{
				if (num != 0L)
				{
				}
				return;
			}
		}

		// Token: 0x06002A36 RID: 10806 RVA: 0x0005A674 File Offset: 0x00058874
		[Address(RVA = "0x2A1B1B8", Offset = "0x2A1B1B8", VA = "0x2A1B1B8")]
		[Token(Token = "0x6002A36")]
		public void method_73()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A37 RID: 10807 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x6002A37")]
		[Address(RVA = "0x2A1B31C", Offset = "0x2A1B31C", VA = "0x2A1B31C")]
		public void method_74(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A38 RID: 10808 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A1B324", Offset = "0x2A1B324", VA = "0x2A1B324")]
		[Token(Token = "0x6002A38")]
		public void method_75()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A39 RID: 10809 RVA: 0x0005A924 File Offset: 0x00058B24
		[Token(Token = "0x6002A39")]
		[Address(RVA = "0x2A1B4B8", Offset = "0x2A1B4B8", VA = "0x2A1B4B8")]
		public void method_76()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			if (this.ࢦ\u0702ࢡ\u058F_0 == ࢦ\u0702ࢡ\u058F.ࡈ\u07A9\u06D4\u0706)
			{
				HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
				HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
				HVRGrabbable y = this.hvrgrabbable_0;
				if (hvrhandGrabber != null)
				{
				}
				חࠀ_u0895_u == y;
				return;
			}
			if (!this.hvrhandGrabber_0.<\u0640Ԁ\u055Eݝ>k__BackingField)
			{
			}
		}

		// Token: 0x06002A3A RID: 10810 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A1B618", Offset = "0x2A1B618", VA = "0x2A1B618")]
		[Token(Token = "0x6002A3A")]
		public void method_77()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A3C RID: 10812 RVA: 0x0005A70C File Offset: 0x0005890C
		[Token(Token = "0x6002A3C")]
		[Address(RVA = "0x2A1B7B4", Offset = "0x2A1B7B4", VA = "0x2A1B7B4")]
		public void method_78()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A3D RID: 10813 RVA: 0x00002E1C File Offset: 0x0000101C
		[Token(Token = "0x6002A3D")]
		[Address(RVA = "0x2A1B948", Offset = "0x2A1B948", VA = "0x2A1B948")]
		public HVRHandGrabber method_79()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A3E RID: 10814 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A1B950", Offset = "0x2A1B950", VA = "0x2A1B950")]
		[Token(Token = "0x6002A3E")]
		public void method_80(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A3F RID: 10815 RVA: 0x0005A7E0 File Offset: 0x000589E0
		[Token(Token = "0x6002A3F")]
		[Address(RVA = "0x2A1B958", Offset = "0x2A1B958", VA = "0x2A1B958")]
		public void method_81()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			if (DemoCodeGrabbing.<>c.<>9__7_0 != null)
			{
			}
			Func<HVRHandGrabber, bool> func;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A40 RID: 10816 RVA: 0x0005A674 File Offset: 0x00058874
		[Token(Token = "0x6002A40")]
		[Address(RVA = "0x2A1BAEC", Offset = "0x2A1BAEC", VA = "0x2A1BAEC")]
		public void method_82()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A41 RID: 10817 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x6002A41")]
		[Address(RVA = "0x2A1BC50", Offset = "0x2A1BC50", VA = "0x2A1BC50")]
		public void method_83(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A42 RID: 10818 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A1BC58", Offset = "0x2A1BC58", VA = "0x2A1BC58")]
		[Token(Token = "0x6002A42")]
		public void method_84(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A43 RID: 10819 RVA: 0x00002E1C File Offset: 0x0000101C
		[Token(Token = "0x6002A43")]
		[Address(RVA = "0x2A1BC60", Offset = "0x2A1BC60", VA = "0x2A1BC60")]
		public HVRHandGrabber method_85()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A44 RID: 10820 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x6002A44")]
		[Address(RVA = "0x2A1BC68", Offset = "0x2A1BC68", VA = "0x2A1BC68")]
		public void method_86(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A45 RID: 10821 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A1BC70", Offset = "0x2A1BC70", VA = "0x2A1BC70")]
		[Token(Token = "0x6002A45")]
		public void method_87()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A46 RID: 10822 RVA: 0x00002E1C File Offset: 0x0000101C
		[Token(Token = "0x6002A46")]
		[Address(RVA = "0x2A1BE04", Offset = "0x2A1BE04", VA = "0x2A1BE04")]
		public HVRHandGrabber method_88()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A47 RID: 10823 RVA: 0x0005A674 File Offset: 0x00058874
		[Address(RVA = "0x2A1BE0C", Offset = "0x2A1BE0C", VA = "0x2A1BE0C")]
		[Token(Token = "0x6002A47")]
		public void method_89()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A48 RID: 10824 RVA: 0x0005A9B0 File Offset: 0x00058BB0
		[Token(Token = "0x6002A48")]
		[Address(RVA = "0x2A1BF70", Offset = "0x2A1BF70", VA = "0x2A1BF70")]
		public void method_90()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			DemoCodeGrabbing.<>c.<>9__7_0 = func;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A49 RID: 10825 RVA: 0x0005A9D8 File Offset: 0x00058BD8
		[Address(RVA = "0x2A1C104", Offset = "0x2A1C104", VA = "0x2A1C104")]
		[Token(Token = "0x6002A49")]
		public void method_91()
		{
			UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> <>9__7_ = DemoCodeGrabbing.<>c.<>9__7_0;
			if (<>9__7_ == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = <>9__7_;
			}
			HVRHandGrabber hvrhandGrabber;
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A4A RID: 10826 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A1C298", Offset = "0x2A1C298", VA = "0x2A1C298")]
		[Token(Token = "0x6002A4A")]
		public void method_92()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A4B RID: 10827 RVA: 0x0005A70C File Offset: 0x0005890C
		[Token(Token = "0x6002A4B")]
		[Address(RVA = "0x2A1C42C", Offset = "0x2A1C42C", VA = "0x2A1C42C")]
		public void method_93()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A4C RID: 10828 RVA: 0x00002E1C File Offset: 0x0000101C
		[Token(Token = "0x6002A4C")]
		[Address(RVA = "0x2A1C5C0", Offset = "0x2A1C5C0", VA = "0x2A1C5C0")]
		public HVRHandGrabber method_94()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A4D RID: 10829 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x6002A4D")]
		[Address(RVA = "0x2A1C5C8", Offset = "0x2A1C5C8", VA = "0x2A1C5C8")]
		public void method_95(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A4E RID: 10830 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x6002A4E")]
		[Address(RVA = "0x2A1C5D0", Offset = "0x2A1C5D0", VA = "0x2A1C5D0")]
		public void method_96(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A4F RID: 10831 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A1C5D8", Offset = "0x2A1C5D8", VA = "0x2A1C5D8")]
		[Token(Token = "0x6002A4F")]
		public HVRHandGrabber method_97()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A50 RID: 10832 RVA: 0x0005A70C File Offset: 0x0005890C
		[Token(Token = "0x6002A50")]
		[Address(RVA = "0x2A1C5E0", Offset = "0x2A1C5E0", VA = "0x2A1C5E0")]
		public void method_98()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A51 RID: 10833 RVA: 0x00002E13 File Offset: 0x00001013
		[Address(RVA = "0x2A1C774", Offset = "0x2A1C774", VA = "0x2A1C774")]
		[Token(Token = "0x6002A51")]
		public void method_99(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A52 RID: 10834 RVA: 0x0005A70C File Offset: 0x0005890C
		[Token(Token = "0x6002A52")]
		[Address(RVA = "0x2A1C77C", Offset = "0x2A1C77C", VA = "0x2A1C77C")]
		public void method_100()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A53 RID: 10835 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A1C910", Offset = "0x2A1C910", VA = "0x2A1C910")]
		[Token(Token = "0x6002A53")]
		public HVRHandGrabber method_101()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A54 RID: 10836 RVA: 0x0005A70C File Offset: 0x0005890C
		[Token(Token = "0x6002A54")]
		[Address(RVA = "0x2A1C918", Offset = "0x2A1C918", VA = "0x2A1C918")]
		public void method_102()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A55 RID: 10837 RVA: 0x0005A7E0 File Offset: 0x000589E0
		[Token(Token = "0x6002A55")]
		[Address(RVA = "0x2A1CAAC", Offset = "0x2A1CAAC", VA = "0x2A1CAAC")]
		public void method_103()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			if (DemoCodeGrabbing.<>c.<>9__7_0 != null)
			{
			}
			Func<HVRHandGrabber, bool> func;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A56 RID: 10838 RVA: 0x0005A70C File Offset: 0x0005890C
		[Address(RVA = "0x2A1CC40", Offset = "0x2A1CC40", VA = "0x2A1CC40")]
		[Token(Token = "0x6002A56")]
		public void method_104()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A57 RID: 10839 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A1CDD4", Offset = "0x2A1CDD4", VA = "0x2A1CDD4")]
		[Token(Token = "0x6002A57")]
		public HVRHandGrabber method_105()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A58 RID: 10840 RVA: 0x00002E13 File Offset: 0x00001013
		[Token(Token = "0x6002A58")]
		[Address(RVA = "0x2A1CDDC", Offset = "0x2A1CDDC", VA = "0x2A1CDDC")]
		public void method_106(HVRHandGrabber hvrhandGrabber_1)
		{
			this.hvrhandGrabber_0 = hvrhandGrabber_1;
		}

		// Token: 0x06002A59 RID: 10841 RVA: 0x0005A70C File Offset: 0x0005890C
		[Token(Token = "0x6002A59")]
		[Address(RVA = "0x2A1CDE4", Offset = "0x2A1CDE4", VA = "0x2A1CDE4")]
		public void method_107()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A5A RID: 10842 RVA: 0x0005AA04 File Offset: 0x00058C04
		[Address(RVA = "0x2A1CF78", Offset = "0x2A1CF78", VA = "0x2A1CF78")]
		[Token(Token = "0x6002A5A")]
		public void method_108()
		{
		}

		// Token: 0x06002A5B RID: 10843 RVA: 0x0005A70C File Offset: 0x0005890C
		[Token(Token = "0x6002A5B")]
		[Address(RVA = "0x2A1D10C", Offset = "0x2A1D10C", VA = "0x2A1D10C")]
		public void method_109()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			Func<HVRHandGrabber, bool> func;
			if (DemoCodeGrabbing.<>c.<>9__7_0 == null)
			{
				DemoCodeGrabbing.<>c.<>9__7_0 = func;
			}
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A5C RID: 10844 RVA: 0x0005A924 File Offset: 0x00058B24
		[Address(RVA = "0x2A1D2A0", Offset = "0x2A1D2A0", VA = "0x2A1D2A0")]
		[Token(Token = "0x6002A5C")]
		public void method_110()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			if (this.ࢦ\u0702ࢡ\u058F_0 == ࢦ\u0702ࢡ\u058F.ࡈ\u07A9\u06D4\u0706)
			{
				HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
				HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
				HVRGrabbable y = this.hvrgrabbable_0;
				if (hvrhandGrabber != null)
				{
				}
				חࠀ_u0895_u == y;
				return;
			}
			if (!this.hvrhandGrabber_0.<\u0640Ԁ\u055Eݝ>k__BackingField)
			{
			}
		}

		// Token: 0x06002A5D RID: 10845 RVA: 0x0005AA14 File Offset: 0x00058C14
		[Token(Token = "0x6002A5D")]
		[Address(RVA = "0x2A1D400", Offset = "0x2A1D400", VA = "0x2A1D400")]
		public void method_111()
		{
			long num = 1L;
			HVRGrabbable exists = this.hvrgrabbable_0;
			if (num != 0L)
			{
			}
			exists;
			HVRHandGrabber exists2 = this.hvrhandGrabber_0;
			if (num != 0L)
			{
			}
			exists2;
			HVRHandGrabber hvrhandGrabber = this.hvrhandGrabber_0;
			HVRGrabbable חࠀ_u0895_u = hvrhandGrabber.חࠀ\u0895\u0880;
			HVRGrabbable y = this.hvrgrabbable_0;
			if (hvrhandGrabber != null)
			{
			}
			חࠀ_u0895_u == y;
		}

		// Token: 0x06002A5E RID: 10846 RVA: 0x0005AA6C File Offset: 0x00058C6C
		[Address(RVA = "0x2A1D564", Offset = "0x2A1D564", VA = "0x2A1D564")]
		[Token(Token = "0x6002A5E")]
		public void method_112()
		{
			UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			if (DemoCodeGrabbing.<>c.<>9__7_0 != null)
			{
			}
			HVRHandGrabber hvrhandGrabber;
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x06002A5F RID: 10847 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A1D6F8", Offset = "0x2A1D6F8", VA = "0x2A1D6F8")]
		[Token(Token = "0x6002A5F")]
		public HVRHandGrabber method_113()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A60 RID: 10848 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A1D700", Offset = "0x2A1D700", VA = "0x2A1D700")]
		[Token(Token = "0x6002A60")]
		public HVRHandGrabber method_114()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A61 RID: 10849 RVA: 0x00002E1C File Offset: 0x0000101C
		[Address(RVA = "0x2A1D708", Offset = "0x2A1D708", VA = "0x2A1D708")]
		[Token(Token = "0x6002A61")]
		public HVRHandGrabber method_115()
		{
			return this.hvrhandGrabber_0;
		}

		// Token: 0x06002A62 RID: 10850 RVA: 0x0005A7E0 File Offset: 0x000589E0
		[Address(RVA = "0x2A1D710", Offset = "0x2A1D710", VA = "0x2A1D710")]
		[Token(Token = "0x6002A62")]
		public void method_116()
		{
			HVRHandGrabber[] array = UnityEngine.Object.FindObjectsOfType<HVRHandGrabber>();
			if (DemoCodeGrabbing.<>c.<>9__7_0 != null)
			{
			}
			Func<HVRHandGrabber, bool> func;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array, func);
			this.hvrhandGrabber_0 = hvrhandGrabber;
		}

		// Token: 0x0400056F RID: 1391
		[Token(Token = "0x400056F")]
		[CompilerGenerated]
		[FieldOffset(Offset = "0x18")]
		private HVRHandGrabber hvrhandGrabber_0;

		// Token: 0x04000570 RID: 1392
		[Token(Token = "0x4000570")]
		[FieldOffset(Offset = "0x20")]
		public HVRGrabbable hvrgrabbable_0;

		// Token: 0x04000571 RID: 1393
		[Token(Token = "0x4000571")]
		[FieldOffset(Offset = "0x28")]
		public ࢦ\u0702ࢡ\u058F ࢦ\u0702ࢡ\u058F_0;

		// Token: 0x04000572 RID: 1394
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000572")]
		public HVRPosableGrabPoint hvrposableGrabPoint_0;
	}
}
