﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000125 RID: 293
	[Token(Token = "0x2000125")]
	public class DemoLeverDisplay : MonoBehaviour
	{
		// Token: 0x06002D63 RID: 11619 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B13924", Offset = "0x1B13924", VA = "0x1B13924")]
		[Token(Token = "0x6002D63")]
		private void method_0()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D64 RID: 11620 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B13980", Offset = "0x1B13980", VA = "0x1B13980")]
		[Token(Token = "0x6002D64")]
		public void method_1(float float_1, float float_2)
		{
		}

		// Token: 0x06002D65 RID: 11621 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B13A74", Offset = "0x1B13A74", VA = "0x1B13A74")]
		[Token(Token = "0x6002D65")]
		public void method_2(float float_1, float float_2)
		{
		}

		// Token: 0x06002D66 RID: 11622 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Token(Token = "0x6002D66")]
		[Address(RVA = "0x1B13B68", Offset = "0x1B13B68", VA = "0x1B13B68")]
		public void method_3(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D67 RID: 11623 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Token(Token = "0x6002D67")]
		[Address(RVA = "0x1B13C48", Offset = "0x1B13C48", VA = "0x1B13C48")]
		public void method_4(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D68 RID: 11624 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002D68")]
		[Address(RVA = "0x1B13D28", Offset = "0x1B13D28", VA = "0x1B13D28")]
		public void method_5(float float_1, float float_2)
		{
		}

		// Token: 0x06002D69 RID: 11625 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B13E1C", Offset = "0x1B13E1C", VA = "0x1B13E1C")]
		[Token(Token = "0x6002D69")]
		public void method_6(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D6A RID: 11626 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B13EFC", Offset = "0x1B13EFC", VA = "0x1B13EFC")]
		[Token(Token = "0x6002D6A")]
		private void method_7()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D6B RID: 11627 RVA: 0x0005D788 File Offset: 0x0005B988
		[Token(Token = "0x6002D6B")]
		[Address(RVA = "0x1B13F58", Offset = "0x1B13F58", VA = "0x1B13F58")]
		private void method_8()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D6C RID: 11628 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002D6C")]
		[Address(RVA = "0x1B13FB4", Offset = "0x1B13FB4", VA = "0x1B13FB4")]
		public void method_9(float float_1, float float_2)
		{
		}

		// Token: 0x06002D6D RID: 11629 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B140A8", Offset = "0x1B140A8", VA = "0x1B140A8")]
		[Token(Token = "0x6002D6D")]
		public void method_10(float float_1, float float_2)
		{
		}

		// Token: 0x06002D6E RID: 11630 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Token(Token = "0x6002D6E")]
		[Address(RVA = "0x1B1419C", Offset = "0x1B1419C", VA = "0x1B1419C")]
		public void method_11(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D6F RID: 11631 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B1427C", Offset = "0x1B1427C", VA = "0x1B1427C")]
		[Token(Token = "0x6002D6F")]
		public void method_12(float float_1, float float_2)
		{
		}

		// Token: 0x06002D70 RID: 11632 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B14370", Offset = "0x1B14370", VA = "0x1B14370")]
		[Token(Token = "0x6002D70")]
		public void method_13(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D71 RID: 11633 RVA: 0x0005D788 File Offset: 0x0005B988
		[Token(Token = "0x6002D71")]
		[Address(RVA = "0x1B14450", Offset = "0x1B14450", VA = "0x1B14450")]
		private void method_14()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D72 RID: 11634 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B144AC", Offset = "0x1B144AC", VA = "0x1B144AC")]
		[Token(Token = "0x6002D72")]
		public void method_15(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D73 RID: 11635 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Token(Token = "0x6002D73")]
		[Address(RVA = "0x1B1458C", Offset = "0x1B1458C", VA = "0x1B1458C")]
		public void method_16(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D74 RID: 11636 RVA: 0x0005D788 File Offset: 0x0005B988
		[Token(Token = "0x6002D74")]
		[Address(RVA = "0x1B1466C", Offset = "0x1B1466C", VA = "0x1B1466C")]
		private void method_17()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D75 RID: 11637 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002D75")]
		[Address(RVA = "0x1B146C8", Offset = "0x1B146C8", VA = "0x1B146C8")]
		public void method_18(float float_1, float float_2)
		{
		}

		// Token: 0x06002D76 RID: 11638 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B147BC", Offset = "0x1B147BC", VA = "0x1B147BC")]
		[Token(Token = "0x6002D76")]
		public void method_19(float float_1, float float_2)
		{
		}

		// Token: 0x06002D77 RID: 11639 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B148B0", Offset = "0x1B148B0", VA = "0x1B148B0")]
		[Token(Token = "0x6002D77")]
		public void method_20(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D78 RID: 11640 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B14990", Offset = "0x1B14990", VA = "0x1B14990")]
		[Token(Token = "0x6002D78")]
		private void method_21()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D79 RID: 11641 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002D79")]
		[Address(RVA = "0x1B149EC", Offset = "0x1B149EC", VA = "0x1B149EC")]
		private void method_22()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002D7A RID: 11642 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B14A48", Offset = "0x1B14A48", VA = "0x1B14A48")]
		[Token(Token = "0x6002D7A")]
		private void method_23()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D7B RID: 11643 RVA: 0x0005D788 File Offset: 0x0005B988
		[Token(Token = "0x6002D7B")]
		[Address(RVA = "0x1B14AA4", Offset = "0x1B14AA4", VA = "0x1B14AA4")]
		private void method_24()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D7C RID: 11644 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Token(Token = "0x6002D7C")]
		[Address(RVA = "0x1B14B00", Offset = "0x1B14B00", VA = "0x1B14B00")]
		public void method_25(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D7D RID: 11645 RVA: 0x0005D788 File Offset: 0x0005B988
		[Token(Token = "0x6002D7D")]
		[Address(RVA = "0x1B14BE0", Offset = "0x1B14BE0", VA = "0x1B14BE0")]
		private void method_26()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D7E RID: 11646 RVA: 0x0005D788 File Offset: 0x0005B988
		[Token(Token = "0x6002D7E")]
		[Address(RVA = "0x1B14C3C", Offset = "0x1B14C3C", VA = "0x1B14C3C")]
		private void method_27()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D7F RID: 11647 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B14C98", Offset = "0x1B14C98", VA = "0x1B14C98")]
		[Token(Token = "0x6002D7F")]
		public void method_28(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D80 RID: 11648 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B14D78", Offset = "0x1B14D78", VA = "0x1B14D78")]
		[Token(Token = "0x6002D80")]
		public void method_29(float float_1, float float_2)
		{
		}

		// Token: 0x06002D81 RID: 11649 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Token(Token = "0x6002D81")]
		[Address(RVA = "0x1B14E6C", Offset = "0x1B14E6C", VA = "0x1B14E6C")]
		public void method_30(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D82 RID: 11650 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B14F4C", Offset = "0x1B14F4C", VA = "0x1B14F4C")]
		[Token(Token = "0x6002D82")]
		public void method_31(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D83 RID: 11651 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B1502C", Offset = "0x1B1502C", VA = "0x1B1502C")]
		[Token(Token = "0x6002D83")]
		public void method_32(float float_1, float float_2)
		{
		}

		// Token: 0x06002D84 RID: 11652 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B15120", Offset = "0x1B15120", VA = "0x1B15120")]
		[Token(Token = "0x6002D84")]
		private void method_33()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D85 RID: 11653 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B1517C", Offset = "0x1B1517C", VA = "0x1B1517C")]
		[Token(Token = "0x6002D85")]
		private void method_34()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D86 RID: 11654 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Token(Token = "0x6002D86")]
		[Address(RVA = "0x1B151D8", Offset = "0x1B151D8", VA = "0x1B151D8")]
		public void method_35(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D87 RID: 11655 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B152B8", Offset = "0x1B152B8", VA = "0x1B152B8")]
		[Token(Token = "0x6002D87")]
		public void method_36(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D88 RID: 11656 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002D88")]
		[Address(RVA = "0x1B15398", Offset = "0x1B15398", VA = "0x1B15398")]
		public void method_37(float float_1, float float_2)
		{
		}

		// Token: 0x06002D89 RID: 11657 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B1548C", Offset = "0x1B1548C", VA = "0x1B1548C")]
		[Token(Token = "0x6002D89")]
		public void method_38(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D8A RID: 11658 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B1556C", Offset = "0x1B1556C", VA = "0x1B1556C")]
		[Token(Token = "0x6002D8A")]
		public void method_39(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D8B RID: 11659 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Token(Token = "0x6002D8B")]
		[Address(RVA = "0x1B1564C", Offset = "0x1B1564C", VA = "0x1B1564C")]
		public void method_40(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D8C RID: 11660 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x1B1572C", Offset = "0x1B1572C", VA = "0x1B1572C")]
		[Token(Token = "0x6002D8C")]
		public DemoLeverDisplay()
		{
		}

		// Token: 0x06002D8D RID: 11661 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B15734", Offset = "0x1B15734", VA = "0x1B15734")]
		[Token(Token = "0x6002D8D")]
		private void method_41()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D8E RID: 11662 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B15790", Offset = "0x1B15790", VA = "0x1B15790")]
		[Token(Token = "0x6002D8E")]
		public void method_42(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D8F RID: 11663 RVA: 0x0005D7C8 File Offset: 0x0005B9C8
		[Token(Token = "0x6002D8F")]
		[Address(RVA = "0x1B15870", Offset = "0x1B15870", VA = "0x1B15870")]
		public void method_43(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D90 RID: 11664 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B15950", Offset = "0x1B15950", VA = "0x1B15950")]
		[Token(Token = "0x6002D90")]
		public void method_44(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D91 RID: 11665 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002D91")]
		[Address(RVA = "0x1B15A30", Offset = "0x1B15A30", VA = "0x1B15A30")]
		public void method_45(float float_1, float float_2)
		{
		}

		// Token: 0x06002D92 RID: 11666 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002D92")]
		[Address(RVA = "0x1B15B24", Offset = "0x1B15B24", VA = "0x1B15B24")]
		public void method_46(float float_1, float float_2)
		{
		}

		// Token: 0x06002D93 RID: 11667 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B15C18", Offset = "0x1B15C18", VA = "0x1B15C18")]
		[Token(Token = "0x6002D93")]
		private void method_47()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D94 RID: 11668 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B15C74", Offset = "0x1B15C74", VA = "0x1B15C74")]
		[Token(Token = "0x6002D94")]
		private void method_48()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D95 RID: 11669 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B15CD0", Offset = "0x1B15CD0", VA = "0x1B15CD0")]
		[Token(Token = "0x6002D95")]
		public void method_49(float float_1, float float_2)
		{
		}

		// Token: 0x06002D96 RID: 11670 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B15DC4", Offset = "0x1B15DC4", VA = "0x1B15DC4")]
		[Token(Token = "0x6002D96")]
		public void method_50(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D97 RID: 11671 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B15EA4", Offset = "0x1B15EA4", VA = "0x1B15EA4")]
		[Token(Token = "0x6002D97")]
		public void method_51(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D98 RID: 11672 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B15F84", Offset = "0x1B15F84", VA = "0x1B15F84")]
		[Token(Token = "0x6002D98")]
		public void method_52(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D99 RID: 11673 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B16064", Offset = "0x1B16064", VA = "0x1B16064")]
		[Token(Token = "0x6002D99")]
		private void method_53()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D9A RID: 11674 RVA: 0x0005D7C8 File Offset: 0x0005B9C8
		[Token(Token = "0x6002D9A")]
		[Address(RVA = "0x1B160C0", Offset = "0x1B160C0", VA = "0x1B160C0")]
		public void method_54(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D9B RID: 11675 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B161A0", Offset = "0x1B161A0", VA = "0x1B161A0")]
		[Token(Token = "0x6002D9B")]
		private void method_55()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D9C RID: 11676 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B161FC", Offset = "0x1B161FC", VA = "0x1B161FC")]
		[Token(Token = "0x6002D9C")]
		private void method_56()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002D9D RID: 11677 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002D9D")]
		[Address(RVA = "0x1B16258", Offset = "0x1B16258", VA = "0x1B16258")]
		public void method_57(float float_1, float float_2)
		{
		}

		// Token: 0x06002D9E RID: 11678 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B1634C", Offset = "0x1B1634C", VA = "0x1B1634C")]
		[Token(Token = "0x6002D9E")]
		public void method_58(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002D9F RID: 11679 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B1642C", Offset = "0x1B1642C", VA = "0x1B1642C")]
		[Token(Token = "0x6002D9F")]
		public void method_59(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002DA0 RID: 11680 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002DA0")]
		[Address(RVA = "0x1B1650C", Offset = "0x1B1650C", VA = "0x1B1650C")]
		public void method_60(float float_1, float float_2)
		{
		}

		// Token: 0x06002DA1 RID: 11681 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B16600", Offset = "0x1B16600", VA = "0x1B16600")]
		[Token(Token = "0x6002DA1")]
		public void method_61(float float_1, float float_2)
		{
		}

		// Token: 0x06002DA2 RID: 11682 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B166F4", Offset = "0x1B166F4", VA = "0x1B166F4")]
		[Token(Token = "0x6002DA2")]
		public void method_62(float float_1, float float_2)
		{
		}

		// Token: 0x06002DA3 RID: 11683 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B167E8", Offset = "0x1B167E8", VA = "0x1B167E8")]
		[Token(Token = "0x6002DA3")]
		public void method_63(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002DA4 RID: 11684 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B168C8", Offset = "0x1B168C8", VA = "0x1B168C8")]
		[Token(Token = "0x6002DA4")]
		private void method_64()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002DA5 RID: 11685 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B16924", Offset = "0x1B16924", VA = "0x1B16924")]
		[Token(Token = "0x6002DA5")]
		public void method_65(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002DA6 RID: 11686 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B16A04", Offset = "0x1B16A04", VA = "0x1B16A04")]
		[Token(Token = "0x6002DA6")]
		public void method_66(float float_1, float float_2)
		{
		}

		// Token: 0x06002DA7 RID: 11687 RVA: 0x0005D788 File Offset: 0x0005B988
		[Token(Token = "0x6002DA7")]
		[Address(RVA = "0x1B16AF8", Offset = "0x1B16AF8", VA = "0x1B16AF8")]
		private void method_67()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002DA8 RID: 11688 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B16B54", Offset = "0x1B16B54", VA = "0x1B16B54")]
		[Token(Token = "0x6002DA8")]
		private void method_68()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002DA9 RID: 11689 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Token(Token = "0x6002DA9")]
		[Address(RVA = "0x1B16BB0", Offset = "0x1B16BB0", VA = "0x1B16BB0")]
		public void method_69(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06002DAA RID: 11690 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B16C90", Offset = "0x1B16C90", VA = "0x1B16C90")]
		[Token(Token = "0x6002DAA")]
		public void method_70(float float_1, float float_2)
		{
		}

		// Token: 0x06002DAB RID: 11691 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002DAB")]
		[Address(RVA = "0x1B16D84", Offset = "0x1B16D84", VA = "0x1B16D84")]
		public void method_71(float float_1, float float_2)
		{
		}

		// Token: 0x06002DAC RID: 11692 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B16E78", Offset = "0x1B16E78", VA = "0x1B16E78")]
		[Token(Token = "0x6002DAC")]
		private void method_72()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002DAD RID: 11693 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Address(RVA = "0x1B16ED4", Offset = "0x1B16ED4", VA = "0x1B16ED4")]
		[Token(Token = "0x6002DAD")]
		public void method_73(float float_1, float float_2)
		{
		}

		// Token: 0x06002DAE RID: 11694 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B16FC8", Offset = "0x1B16FC8", VA = "0x1B16FC8")]
		[Token(Token = "0x6002DAE")]
		private void method_74()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002DAF RID: 11695 RVA: 0x0005D788 File Offset: 0x0005B988
		[Token(Token = "0x6002DAF")]
		[Address(RVA = "0x1B17024", Offset = "0x1B17024", VA = "0x1B17024")]
		private void method_75()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002DB0 RID: 11696 RVA: 0x0005D788 File Offset: 0x0005B988
		[Token(Token = "0x6002DB0")]
		[Address(RVA = "0x1B17080", Offset = "0x1B17080", VA = "0x1B17080")]
		private void Awake()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002DB1 RID: 11697 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002DB1")]
		[Address(RVA = "0x1B170DC", Offset = "0x1B170DC", VA = "0x1B170DC")]
		public void method_76(float float_1, float float_2)
		{
		}

		// Token: 0x06002DB2 RID: 11698 RVA: 0x0005D788 File Offset: 0x0005B988
		[Address(RVA = "0x1B171D0", Offset = "0x1B171D0", VA = "0x1B171D0")]
		[Token(Token = "0x6002DB2")]
		private void method_77()
		{
			TextMeshPro component = base.GetComponent<TextMeshPro>();
			this.textMeshPro_0 = component;
		}

		// Token: 0x06002DB3 RID: 11699 RVA: 0x0005D7A4 File Offset: 0x0005B9A4
		[Token(Token = "0x6002DB3")]
		[Address(RVA = "0x1B1722C", Offset = "0x1B1722C", VA = "0x1B1722C")]
		public void method_78(float float_1, float float_2)
		{
		}

		// Token: 0x06002DB4 RID: 11700 RVA: 0x0005D7B4 File Offset: 0x0005B9B4
		[Address(RVA = "0x1B17320", Offset = "0x1B17320", VA = "0x1B17320")]
		[Token(Token = "0x6002DB4")]
		public void method_79(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x040005AC RID: 1452
		[Token(Token = "0x40005AC")]
		[FieldOffset(Offset = "0x18")]
		private int int_0;

		// Token: 0x040005AD RID: 1453
		[Token(Token = "0x40005AD")]
		[FieldOffset(Offset = "0x1C")]
		private float float_0;

		// Token: 0x040005AE RID: 1454
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40005AE")]
		private TextMeshPro textMeshPro_0;
	}
}
