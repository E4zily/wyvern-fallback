﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core;
using HurricaneVR.Framework.Core.Grabbers;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x0200011D RID: 285
	[Token(Token = "0x200011D")]
	public class DemoHelper : MonoBehaviour
	{
		// Token: 0x06002BD5 RID: 11221 RVA: 0x0005C8C0 File Offset: 0x0005AAC0
		[Address(RVA = "0x2112B9C", Offset = "0x2112B9C", VA = "0x2112B9C")]
		[Token(Token = "0x6002BD5")]
		private void method_0(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002BD6 RID: 11222 RVA: 0x0005C8C0 File Offset: 0x0005AAC0
		[Address(RVA = "0x2112D54", Offset = "0x2112D54", VA = "0x2112D54")]
		[Token(Token = "0x6002BD6")]
		private void method_1(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002BD7 RID: 11223 RVA: 0x0005C928 File Offset: 0x0005AB28
		[Address(RVA = "0x2112F0C", Offset = "0x2112F0C", VA = "0x2112F0C")]
		[Token(Token = "0x6002BD7")]
		private void method_2()
		{
			if (this.bool_0)
			{
				this.method_116();
				long num = 1L;
				this.bool_0 = (num != 0L);
			}
		}

		// Token: 0x06002BD8 RID: 11224 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x21135E0", Offset = "0x21135E0", VA = "0x21135E0")]
		[Token(Token = "0x6002BD8")]
		private void method_3()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002BD9 RID: 11225 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Address(RVA = "0x2113E18", Offset = "0x2113E18", VA = "0x2113E18")]
		[Token(Token = "0x6002BD9")]
		private void method_4(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002BDA RID: 11226 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Address(RVA = "0x2114394", Offset = "0x2114394", VA = "0x2114394")]
		[Token(Token = "0x6002BDA")]
		public void method_5(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002BDB RID: 11227 RVA: 0x0005C9AC File Offset: 0x0005ABAC
		[Address(RVA = "0x2114420", Offset = "0x2114420", VA = "0x2114420")]
		[Token(Token = "0x6002BDB")]
		public void method_6()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 1L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BDC RID: 11228 RVA: 0x0005C9EC File Offset: 0x0005ABEC
		[Address(RVA = "0x2114AC4", Offset = "0x2114AC4", VA = "0x2114AC4")]
		[Token(Token = "0x6002BDC")]
		public void method_7()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 1L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Transform transform2;
			Transform transform = transform2.transform;
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BDD RID: 11229 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x2115168", Offset = "0x2115168", VA = "0x2115168")]
		[Token(Token = "0x6002BDD")]
		private void method_8()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002BDE RID: 11230 RVA: 0x0005CA34 File Offset: 0x0005AC34
		[Address(RVA = "0x21159A0", Offset = "0x21159A0", VA = "0x21159A0")]
		[Token(Token = "0x6002BDE")]
		public void method_9()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 1L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BDF RID: 11231 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Address(RVA = "0x2116044", Offset = "0x2116044", VA = "0x2116044")]
		[Token(Token = "0x6002BDF")]
		private void method_10(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002BE0 RID: 11232 RVA: 0x0005CA74 File Offset: 0x0005AC74
		[Address(RVA = "0x21165C0", Offset = "0x21165C0", VA = "0x21165C0")]
		[Token(Token = "0x6002BE0")]
		private void method_11(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002BE1 RID: 11233 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x2116778", Offset = "0x2116778", VA = "0x2116778")]
		[Token(Token = "0x6002BE1")]
		private void method_12(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002BE2 RID: 11234 RVA: 0x0005CAE4 File Offset: 0x0005ACE4
		[Address(RVA = "0x21167DC", Offset = "0x21167DC", VA = "0x21167DC")]
		[Token(Token = "0x6002BE2")]
		public void method_13()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 1L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BE3 RID: 11235 RVA: 0x0005CB24 File Offset: 0x0005AD24
		[Address(RVA = "0x2116E80", Offset = "0x2116E80", VA = "0x2116E80")]
		[Token(Token = "0x6002BE3")]
		private void method_14()
		{
			if (this.bool_0)
			{
				this.method_120();
				long num = 1L;
				this.bool_0 = (num != 0L);
			}
		}

		// Token: 0x06002BE4 RID: 11236 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x2117554", Offset = "0x2117554", VA = "0x2117554")]
		[Token(Token = "0x6002BE4")]
		private void method_15()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002BE5 RID: 11237 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x2117D8C", Offset = "0x2117D8C", VA = "0x2117D8C")]
		[Token(Token = "0x6002BE5")]
		private void Start()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002BE6 RID: 11238 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x21185C4", Offset = "0x21185C4", VA = "0x21185C4")]
		[Token(Token = "0x6002BE6")]
		private void method_16()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002BE7 RID: 11239 RVA: 0x0005CAE4 File Offset: 0x0005ACE4
		[Address(RVA = "0x2118C44", Offset = "0x2118C44", VA = "0x2118C44")]
		[Token(Token = "0x6002BE7")]
		public void method_17()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 1L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BE8 RID: 11240 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Token(Token = "0x6002BE8")]
		[Address(RVA = "0x21192E8", Offset = "0x21192E8", VA = "0x21192E8")]
		public void method_18(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002BE9 RID: 11241 RVA: 0x0005CB48 File Offset: 0x0005AD48
		[Address(RVA = "0x2119374", Offset = "0x2119374", VA = "0x2119374")]
		[Token(Token = "0x6002BE9")]
		private void method_19(Transform transform_0)
		{
			if (new DemoHelper.Class38().<>9__0 != null)
			{
			}
		}

		// Token: 0x06002BEA RID: 11242 RVA: 0x0005CB64 File Offset: 0x0005AD64
		[Address(RVA = "0x2119738", Offset = "0x2119738", VA = "0x2119738")]
		[Token(Token = "0x6002BEA")]
		private void method_20(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002BEB RID: 11243 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[CompilerGenerated]
		[Token(Token = "0x6002BEB")]
		[Address(RVA = "0x21198F0", Offset = "0x21198F0", VA = "0x21198F0")]
		private void method_21(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002BEC RID: 11244 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Token(Token = "0x6002BEC")]
		[Address(RVA = "0x2119954", Offset = "0x2119954", VA = "0x2119954")]
		public void method_22(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002BED RID: 11245 RVA: 0x0005CBCC File Offset: 0x0005ADCC
		[Token(Token = "0x6002BED")]
		[Address(RVA = "0x21199E0", Offset = "0x21199E0", VA = "0x21199E0")]
		public void method_23()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 1L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 1L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BEE RID: 11246 RVA: 0x0005CC0C File Offset: 0x0005AE0C
		[Token(Token = "0x6002BEE")]
		[Address(RVA = "0x211A084", Offset = "0x211A084", VA = "0x211A084")]
		private void method_24()
		{
			if (this.bool_0)
			{
				this.method_9();
				long num = 1L;
				this.bool_0 = (num != 0L);
			}
		}

		// Token: 0x06002BEF RID: 11247 RVA: 0x0005CC30 File Offset: 0x0005AE30
		[Token(Token = "0x6002BEF")]
		[Address(RVA = "0x211A0B4", Offset = "0x211A0B4", VA = "0x211A0B4")]
		public void method_25()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BF0 RID: 11248 RVA: 0x00002E5B File Offset: 0x0000105B
		[Token(Token = "0x6002BF0")]
		[Address(RVA = "0x211A758", Offset = "0x211A758", VA = "0x211A758")]
		private void Update()
		{
			if (this.bool_0)
			{
				this.method_116();
			}
		}

		// Token: 0x06002BF1 RID: 11249 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Token(Token = "0x6002BF1")]
		[Address(RVA = "0x211A784", Offset = "0x211A784", VA = "0x211A784")]
		private void method_26(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002BF2 RID: 11250 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Address(RVA = "0x211AB48", Offset = "0x211AB48", VA = "0x211AB48")]
		[Token(Token = "0x6002BF2")]
		public void method_27(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002BF3 RID: 11251 RVA: 0x0005CC30 File Offset: 0x0005AE30
		[Token(Token = "0x6002BF3")]
		[Address(RVA = "0x211ABD4", Offset = "0x211ABD4", VA = "0x211ABD4")]
		public void method_28()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BF4 RID: 11252 RVA: 0x0005CC70 File Offset: 0x0005AE70
		[Token(Token = "0x6002BF4")]
		[Address(RVA = "0x211B278", Offset = "0x211B278", VA = "0x211B278")]
		public void method_29()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BF5 RID: 11253 RVA: 0x0005CC30 File Offset: 0x0005AE30
		[Token(Token = "0x6002BF5")]
		[Address(RVA = "0x211B91C", Offset = "0x211B91C", VA = "0x211B91C")]
		public void method_30()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BF6 RID: 11254 RVA: 0x0005CC70 File Offset: 0x0005AE70
		[Token(Token = "0x6002BF6")]
		[Address(RVA = "0x211BFC0", Offset = "0x211BFC0", VA = "0x211BFC0")]
		public void method_31()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BF7 RID: 11255 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002BF7")]
		[Address(RVA = "0x211C664", Offset = "0x211C664", VA = "0x211C664")]
		private void method_32(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002BF8 RID: 11256 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002BF8")]
		[Address(RVA = "0x211C6C8", Offset = "0x211C6C8", VA = "0x211C6C8")]
		private void method_33(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002BF9 RID: 11257 RVA: 0x0005C9AC File Offset: 0x0005ABAC
		[Address(RVA = "0x211C72C", Offset = "0x211C72C", VA = "0x211C72C")]
		[Token(Token = "0x6002BF9")]
		public void method_34()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 1L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002BFA RID: 11258 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002BFA")]
		[Address(RVA = "0x211CDD0", Offset = "0x211CDD0", VA = "0x211CDD0")]
		public void method_35(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002BFB RID: 11259 RVA: 0x0005CCB0 File Offset: 0x0005AEB0
		[Address(RVA = "0x211CE5C", Offset = "0x211CE5C", VA = "0x211CE5C")]
		[Token(Token = "0x6002BFB")]
		private void method_36()
		{
			if (this.bool_0)
			{
				this.method_31();
				long num = 1L;
				this.bool_0 = (num != 0L);
			}
		}

		// Token: 0x06002BFC RID: 11260 RVA: 0x00002E6B File Offset: 0x0000106B
		[Token(Token = "0x6002BFC")]
		[Address(RVA = "0x211CE8C", Offset = "0x211CE8C", VA = "0x211CE8C")]
		private void method_37()
		{
			if (this.bool_0)
			{
				this.method_41();
			}
		}

		// Token: 0x06002BFD RID: 11261 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002BFD")]
		[Address(RVA = "0x211D55C", Offset = "0x211D55C", VA = "0x211D55C")]
		private void method_38(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002BFE RID: 11262 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Address(RVA = "0x211D5C0", Offset = "0x211D5C0", VA = "0x211D5C0")]
		[Token(Token = "0x6002BFE")]
		public void method_39(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002BFF RID: 11263 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x211D64C", Offset = "0x211D64C", VA = "0x211D64C")]
		[Token(Token = "0x6002BFF")]
		private void method_40(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C00 RID: 11264 RVA: 0x0005C9AC File Offset: 0x0005ABAC
		[Token(Token = "0x6002C00")]
		[Address(RVA = "0x211CEB8", Offset = "0x211CEB8", VA = "0x211CEB8")]
		public void method_41()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 1L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002C01 RID: 11265 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x211D6B0", Offset = "0x211D6B0", VA = "0x211D6B0")]
		[Token(Token = "0x6002C01")]
		private void method_42(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C02 RID: 11266 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C02")]
		[Address(RVA = "0x211D714", Offset = "0x211D714", VA = "0x211D714")]
		private void method_43(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C03 RID: 11267 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C03")]
		[Address(RVA = "0x211D778", Offset = "0x211D778", VA = "0x211D778")]
		private void method_44(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C04 RID: 11268 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x211D7DC", Offset = "0x211D7DC", VA = "0x211D7DC")]
		[Token(Token = "0x6002C04")]
		private void method_45()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C05 RID: 11269 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Address(RVA = "0x211DE5C", Offset = "0x211DE5C", VA = "0x211DE5C")]
		[Token(Token = "0x6002C05")]
		public void method_46(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C06 RID: 11270 RVA: 0x0005CCD4 File Offset: 0x0005AED4
		[Address(RVA = "0x211DEE8", Offset = "0x211DEE8", VA = "0x211DEE8")]
		[Token(Token = "0x6002C06")]
		private void method_47()
		{
			if (this.bool_0)
			{
				this.method_74();
				long num = 1L;
				this.bool_0 = (num != 0L);
			}
		}

		// Token: 0x06002C07 RID: 11271 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Token(Token = "0x6002C07")]
		[Address(RVA = "0x211E5BC", Offset = "0x211E5BC", VA = "0x211E5BC")]
		public void method_48(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C08 RID: 11272 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Token(Token = "0x6002C08")]
		[Address(RVA = "0x211E648", Offset = "0x211E648", VA = "0x211E648")]
		private void method_49(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C09 RID: 11273 RVA: 0x00002E7B File Offset: 0x0000107B
		[Address(RVA = "0x211EA0C", Offset = "0x211EA0C", VA = "0x211EA0C")]
		[Token(Token = "0x6002C09")]
		private void method_50()
		{
			if (this.bool_0)
			{
				this.method_7();
			}
		}

		// Token: 0x06002C0A RID: 11274 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Address(RVA = "0x211EA38", Offset = "0x211EA38", VA = "0x211EA38")]
		[Token(Token = "0x6002C0A")]
		public void method_51(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C0B RID: 11275 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Token(Token = "0x6002C0B")]
		[Address(RVA = "0x211EAC4", Offset = "0x211EAC4", VA = "0x211EAC4")]
		private void method_52()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C0C RID: 11276 RVA: 0x0005CCF8 File Offset: 0x0005AEF8
		[Token(Token = "0x6002C0C")]
		[Address(RVA = "0x211ED80", Offset = "0x211ED80", VA = "0x211ED80")]
		private void method_53()
		{
			if (this.bool_0)
			{
				this.method_13();
				long num = 1L;
				this.bool_0 = (num != 0L);
			}
		}

		// Token: 0x06002C0D RID: 11277 RVA: 0x0005CD1C File Offset: 0x0005AF1C
		[Token(Token = "0x6002C0D")]
		[Address(RVA = "0x211DA98", Offset = "0x211DA98", VA = "0x211DA98")]
		private void method_54(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C0E RID: 11278 RVA: 0x0005CC30 File Offset: 0x0005AE30
		[Address(RVA = "0x211EDB0", Offset = "0x211EDB0", VA = "0x211EDB0")]
		[Token(Token = "0x6002C0E")]
		public void method_55()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002C0F RID: 11279 RVA: 0x0005CD48 File Offset: 0x0005AF48
		[Token(Token = "0x6002C0F")]
		[Address(RVA = "0x211F454", Offset = "0x211F454", VA = "0x211F454")]
		public void method_56()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002C10 RID: 11280 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C10")]
		[Address(RVA = "0x211FAF8", Offset = "0x211FAF8", VA = "0x211FAF8")]
		private void method_57(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C11 RID: 11281 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C11")]
		[Address(RVA = "0x211FB5C", Offset = "0x211FB5C", VA = "0x211FB5C")]
		private void method_58(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C12 RID: 11282 RVA: 0x0005CD88 File Offset: 0x0005AF88
		[Address(RVA = "0x2117810", Offset = "0x2117810", VA = "0x2117810")]
		[Token(Token = "0x6002C12")]
		private void method_59(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__;
			Func<HVRGrabbable, bool> <>9__0 = <>9__;
		}

		// Token: 0x06002C13 RID: 11283 RVA: 0x0005CDAC File Offset: 0x0005AFAC
		[Token(Token = "0x6002C13")]
		[Address(RVA = "0x211FBC0", Offset = "0x211FBC0", VA = "0x211FBC0")]
		private void method_60(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002C14 RID: 11284 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Token(Token = "0x6002C14")]
		[Address(RVA = "0x211FD78", Offset = "0x211FD78", VA = "0x211FD78")]
		public void method_61(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C15 RID: 11285 RVA: 0x0005CB64 File Offset: 0x0005AD64
		[Token(Token = "0x6002C15")]
		[Address(RVA = "0x211FE04", Offset = "0x211FE04", VA = "0x211FE04")]
		private void method_62(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002C16 RID: 11286 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C16")]
		[Address(RVA = "0x211FFBC", Offset = "0x211FFBC", VA = "0x211FFBC")]
		private void method_63(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C17 RID: 11287 RVA: 0x0005CB64 File Offset: 0x0005AD64
		[Address(RVA = "0x2120020", Offset = "0x2120020", VA = "0x2120020")]
		[Token(Token = "0x6002C17")]
		private void method_64(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002C18 RID: 11288 RVA: 0x0005CD88 File Offset: 0x0005AF88
		[Address(RVA = "0x2118048", Offset = "0x2118048", VA = "0x2118048")]
		[Token(Token = "0x6002C18")]
		private void method_65(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__;
			Func<HVRGrabbable, bool> <>9__0 = <>9__;
		}

		// Token: 0x06002C19 RID: 11289 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C19")]
		[Address(RVA = "0x21201D8", Offset = "0x21201D8", VA = "0x21201D8")]
		private void method_66(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C1A RID: 11290 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Token(Token = "0x6002C1A")]
		[Address(RVA = "0x212023C", Offset = "0x212023C", VA = "0x212023C")]
		public void method_67(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C1B RID: 11291 RVA: 0x0005CE04 File Offset: 0x0005B004
		[Token(Token = "0x6002C1B")]
		[Address(RVA = "0x21202C8", Offset = "0x21202C8", VA = "0x21202C8")]
		public DemoHelper()
		{
			List<Transform> list = new List();
			this.list_0 = list;
			List<HVRGrabbable> list2 = new List();
			this.list_1 = list2;
			List<DemoHelper.Class37> list3 = new List();
			this.list_2 = list3;
			List<HVRGrabbable> list4 = new List();
			this.list_3 = list4;
			base..ctor();
		}

		// Token: 0x06002C1C RID: 11292 RVA: 0x0005C9AC File Offset: 0x0005ABAC
		[Address(RVA = "0x2120410", Offset = "0x2120410", VA = "0x2120410")]
		[Token(Token = "0x6002C1C")]
		public void method_68()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 1L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002C1D RID: 11293 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Token(Token = "0x6002C1D")]
		[Address(RVA = "0x2120AB4", Offset = "0x2120AB4", VA = "0x2120AB4")]
		private void method_69()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C1E RID: 11294 RVA: 0x0005CE4C File Offset: 0x0005B04C
		[Address(RVA = "0x2121134", Offset = "0x2121134", VA = "0x2121134")]
		[Token(Token = "0x6002C1E")]
		public void method_70(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C1F RID: 11295 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Token(Token = "0x6002C1F")]
		[Address(RVA = "0x21211C0", Offset = "0x21211C0", VA = "0x21211C0")]
		public void method_71(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C20 RID: 11296 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x212124C", Offset = "0x212124C", VA = "0x212124C")]
		[Token(Token = "0x6002C20")]
		private void method_72(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C21 RID: 11297 RVA: 0x0005CE60 File Offset: 0x0005B060
		[Token(Token = "0x6002C21")]
		[Address(RVA = "0x21212B0", Offset = "0x21212B0", VA = "0x21212B0")]
		private void method_73()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C22 RID: 11298 RVA: 0x0005CAE4 File Offset: 0x0005ACE4
		[Address(RVA = "0x211DF18", Offset = "0x211DF18", VA = "0x211DF18")]
		[Token(Token = "0x6002C22")]
		public void method_74()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 1L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002C23 RID: 11299 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C23")]
		[Address(RVA = "0x2121930", Offset = "0x2121930", VA = "0x2121930")]
		private void method_75(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C24 RID: 11300 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Token(Token = "0x6002C24")]
		[Address(RVA = "0x2121994", Offset = "0x2121994", VA = "0x2121994")]
		private void method_76()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C25 RID: 11301 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C25")]
		[Address(RVA = "0x2121C50", Offset = "0x2121C50", VA = "0x2121C50")]
		private void method_77(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C26 RID: 11302 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x2121CB4", Offset = "0x2121CB4", VA = "0x2121CB4")]
		[Token(Token = "0x6002C26")]
		private void method_78(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C27 RID: 11303 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C27")]
		[Address(RVA = "0x2121D18", Offset = "0x2121D18", VA = "0x2121D18")]
		private void method_79(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C28 RID: 11304 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Token(Token = "0x6002C28")]
		[Address(RVA = "0x2121D7C", Offset = "0x2121D7C", VA = "0x2121D7C")]
		public void method_80(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C29 RID: 11305 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x2121E08", Offset = "0x2121E08", VA = "0x2121E08")]
		[Token(Token = "0x6002C29")]
		private void method_81()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C2A RID: 11306 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x212227C", Offset = "0x212227C", VA = "0x212227C")]
		[Token(Token = "0x6002C2A")]
		private void method_82()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C2B RID: 11307 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Token(Token = "0x6002C2B")]
		[Address(RVA = "0x2122538", Offset = "0x2122538", VA = "0x2122538")]
		private void method_83()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C2C RID: 11308 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x2122BB8", Offset = "0x2122BB8", VA = "0x2122BB8")]
		[Token(Token = "0x6002C2C")]
		private void method_84()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C2D RID: 11309 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x2122E74", Offset = "0x2122E74", VA = "0x2122E74")]
		[Token(Token = "0x6002C2D")]
		private void method_85(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C2E RID: 11310 RVA: 0x0005CE80 File Offset: 0x0005B080
		[Token(Token = "0x6002C2E")]
		[Address(RVA = "0x2122ED8", Offset = "0x2122ED8", VA = "0x2122ED8")]
		private void method_86(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
		}

		// Token: 0x06002C2F RID: 11311 RVA: 0x0005CB64 File Offset: 0x0005AD64
		[Address(RVA = "0x211840C", Offset = "0x211840C", VA = "0x211840C")]
		[Token(Token = "0x6002C2F")]
		private void method_87(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002C30 RID: 11312 RVA: 0x00002E8B File Offset: 0x0000108B
		[Address(RVA = "0x2123090", Offset = "0x2123090", VA = "0x2123090")]
		[Token(Token = "0x6002C30")]
		private void method_88()
		{
			if (this.bool_0)
			{
				this.method_30();
			}
		}

		// Token: 0x06002C31 RID: 11313 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Token(Token = "0x6002C31")]
		[Address(RVA = "0x21230BC", Offset = "0x21230BC", VA = "0x21230BC")]
		private void method_89()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C32 RID: 11314 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Address(RVA = "0x21227F4", Offset = "0x21227F4", VA = "0x21227F4")]
		[Token(Token = "0x6002C32")]
		private void method_90(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C33 RID: 11315 RVA: 0x0005CEE0 File Offset: 0x0005B0E0
		[Token(Token = "0x6002C33")]
		[Address(RVA = "0x2123378", Offset = "0x2123378", VA = "0x2123378")]
		private void method_91(Transform transform_0)
		{
		}

		// Token: 0x06002C34 RID: 11316 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x212373C", Offset = "0x212373C", VA = "0x212373C")]
		[Token(Token = "0x6002C34")]
		private void method_92(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C35 RID: 11317 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Address(RVA = "0x21237A0", Offset = "0x21237A0", VA = "0x21237A0")]
		[Token(Token = "0x6002C35")]
		public void method_93(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C36 RID: 11318 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Token(Token = "0x6002C36")]
		[Address(RVA = "0x2120D70", Offset = "0x2120D70", VA = "0x2120D70")]
		private void method_94(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C37 RID: 11319 RVA: 0x0005CA34 File Offset: 0x0005AC34
		[Address(RVA = "0x212382C", Offset = "0x212382C", VA = "0x212382C")]
		[Token(Token = "0x6002C37")]
		public void method_95()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 1L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002C38 RID: 11320 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x2123ED0", Offset = "0x2123ED0", VA = "0x2123ED0")]
		[Token(Token = "0x6002C38")]
		private void method_96()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C39 RID: 11321 RVA: 0x0005CEF0 File Offset: 0x0005B0F0
		[Token(Token = "0x6002C39")]
		[Address(RVA = "0x212418C", Offset = "0x212418C", VA = "0x212418C")]
		private void method_97()
		{
			this.method_31();
		}

		// Token: 0x06002C3A RID: 11322 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Token(Token = "0x6002C3A")]
		[Address(RVA = "0x211389C", Offset = "0x211389C", VA = "0x211389C")]
		private void method_98(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C3B RID: 11323 RVA: 0x0005CD1C File Offset: 0x0005AF1C
		[Address(RVA = "0x2115424", Offset = "0x2115424", VA = "0x2115424")]
		[Token(Token = "0x6002C3B")]
		private void method_99(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C3C RID: 11324 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x21241B8", Offset = "0x21241B8", VA = "0x21241B8")]
		[Token(Token = "0x6002C3C")]
		private void method_100()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C3D RID: 11325 RVA: 0x0005CF04 File Offset: 0x0005B104
		[Address(RVA = "0x2124474", Offset = "0x2124474", VA = "0x2124474")]
		[Token(Token = "0x6002C3D")]
		public void method_101(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
		}

		// Token: 0x06002C3E RID: 11326 RVA: 0x00002E9B File Offset: 0x0000109B
		[Token(Token = "0x6002C3E")]
		[Address(RVA = "0x2124500", Offset = "0x2124500", VA = "0x2124500")]
		private void method_102()
		{
			if (this.bool_0)
			{
				this.method_95();
			}
		}

		// Token: 0x06002C3F RID: 11327 RVA: 0x00002EAB File Offset: 0x000010AB
		[Address(RVA = "0x212452C", Offset = "0x212452C", VA = "0x212452C")]
		[Token(Token = "0x6002C3F")]
		private void method_103()
		{
			if (this.bool_0)
			{
				this.method_56();
			}
		}

		// Token: 0x06002C40 RID: 11328 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x2124558", Offset = "0x2124558", VA = "0x2124558")]
		[Token(Token = "0x6002C40")]
		private void method_104(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C41 RID: 11329 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x21245BC", Offset = "0x21245BC", VA = "0x21245BC")]
		[Token(Token = "0x6002C41")]
		private void method_105()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C42 RID: 11330 RVA: 0x0005CBCC File Offset: 0x0005ADCC
		[Address(RVA = "0x2124C3C", Offset = "0x2124C3C", VA = "0x2124C3C")]
		[Token(Token = "0x6002C42")]
		public void method_106()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 1L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 1L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002C43 RID: 11331 RVA: 0x0005CF14 File Offset: 0x0005B114
		[Address(RVA = "0x21252E0", Offset = "0x21252E0", VA = "0x21252E0")]
		[Token(Token = "0x6002C43")]
		private void method_107()
		{
			if (this.bool_0)
			{
				this.method_56();
				long num = 1L;
				this.bool_0 = (num != 0L);
			}
		}

		// Token: 0x06002C44 RID: 11332 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Address(RVA = "0x2118880", Offset = "0x2118880", VA = "0x2118880")]
		[Token(Token = "0x6002C44")]
		private void method_108(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C45 RID: 11333 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Token(Token = "0x6002C45")]
		[Address(RVA = "0x212156C", Offset = "0x212156C", VA = "0x212156C")]
		private void method_109(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C46 RID: 11334 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x2125310", Offset = "0x2125310", VA = "0x2125310")]
		[Token(Token = "0x6002C46")]
		private void method_110(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C47 RID: 11335 RVA: 0x0005CEE0 File Offset: 0x0005B0E0
		[Address(RVA = "0x2125374", Offset = "0x2125374", VA = "0x2125374")]
		[Token(Token = "0x6002C47")]
		private void method_111(Transform transform_0)
		{
		}

		// Token: 0x06002C48 RID: 11336 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Token(Token = "0x6002C48")]
		[Address(RVA = "0x2125738", Offset = "0x2125738", VA = "0x2125738")]
		private void method_112()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C49 RID: 11337 RVA: 0x0005C8C0 File Offset: 0x0005AAC0
		[Token(Token = "0x6002C49")]
		[Address(RVA = "0x2117BD4", Offset = "0x2117BD4", VA = "0x2117BD4")]
		private void method_113(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002C4A RID: 11338 RVA: 0x0005C8C0 File Offset: 0x0005AAC0
		[Token(Token = "0x6002C4A")]
		[Address(RVA = "0x21141DC", Offset = "0x21141DC", VA = "0x21141DC")]
		private void method_114(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002C4B RID: 11339 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Address(RVA = "0x21259F4", Offset = "0x21259F4", VA = "0x21259F4")]
		[Token(Token = "0x6002C4B")]
		private void method_115(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C4C RID: 11340 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2112F3C", Offset = "0x2112F3C", VA = "0x2112F3C")]
		[Token(Token = "0x6002C4C")]
		public void method_116()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002C4D RID: 11341 RVA: 0x0005CF38 File Offset: 0x0005B138
		[Address(RVA = "0x2125DB8", Offset = "0x2125DB8", VA = "0x2125DB8")]
		[Token(Token = "0x6002C4D")]
		private void method_117()
		{
			if (this.bool_0)
			{
				this.method_6();
				long num = 1L;
				this.bool_0 = (num != 0L);
			}
		}

		// Token: 0x06002C4E RID: 11342 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x2125DE8", Offset = "0x2125DE8", VA = "0x2125DE8")]
		[Token(Token = "0x6002C4E")]
		private void method_118(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C4F RID: 11343 RVA: 0x00002E9B File Offset: 0x0000109B
		[Token(Token = "0x6002C4F")]
		[Address(RVA = "0x2125E4C", Offset = "0x2125E4C", VA = "0x2125E4C")]
		private void method_119()
		{
			if (this.bool_0)
			{
				this.method_95();
			}
		}

		// Token: 0x06002C50 RID: 11344 RVA: 0x0005CC30 File Offset: 0x0005AE30
		[Token(Token = "0x6002C50")]
		[Address(RVA = "0x2116EB0", Offset = "0x2116EB0", VA = "0x2116EB0")]
		public void method_120()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 0L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002C51 RID: 11345 RVA: 0x0005CF5C File Offset: 0x0005B15C
		[Token(Token = "0x6002C51")]
		[Address(RVA = "0x2125E78", Offset = "0x2125E78", VA = "0x2125E78")]
		private void method_121()
		{
			if (this.bool_0)
			{
				this.method_41();
				long num = 1L;
				this.bool_0 = (num != 0L);
			}
		}

		// Token: 0x06002C52 RID: 11346 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C52")]
		[Address(RVA = "0x2125EA8", Offset = "0x2125EA8", VA = "0x2125EA8")]
		private void method_122(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C53 RID: 11347 RVA: 0x0005CA34 File Offset: 0x0005AC34
		[Token(Token = "0x6002C53")]
		[Address(RVA = "0x2125F0C", Offset = "0x2125F0C", VA = "0x2125F0C")]
		public void method_123()
		{
			this.list_2.GetEnumerator().MoveNext();
			long active = 1L;
			GameObject gameObject;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			GameObject gameObject2;
			gameObject2.SetActive(active2 != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06002C54 RID: 11348 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Token(Token = "0x6002C54")]
		[Address(RVA = "0x21265B0", Offset = "0x21265B0", VA = "0x21265B0")]
		public void method_124(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C55 RID: 11349 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x212663C", Offset = "0x212663C", VA = "0x212663C")]
		[Token(Token = "0x6002C55")]
		private void method_125(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C56 RID: 11350 RVA: 0x0005CF80 File Offset: 0x0005B180
		[Address(RVA = "0x21220C4", Offset = "0x21220C4", VA = "0x21220C4")]
		[Token(Token = "0x6002C56")]
		private void method_126(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002C57 RID: 11351 RVA: 0x0005C998 File Offset: 0x0005AB98
		[Token(Token = "0x6002C57")]
		[Address(RVA = "0x21266A0", Offset = "0x21266A0", VA = "0x21266A0")]
		public void method_127(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C58 RID: 11352 RVA: 0x00002E7B File Offset: 0x0000107B
		[Token(Token = "0x6002C58")]
		[Address(RVA = "0x212672C", Offset = "0x212672C", VA = "0x212672C")]
		private void method_128()
		{
			if (this.bool_0)
			{
				this.method_7();
			}
		}

		// Token: 0x06002C59 RID: 11353 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Token(Token = "0x6002C59")]
		[Address(RVA = "0x2126758", Offset = "0x2126758", VA = "0x2126758")]
		private void method_129(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C5A RID: 11354 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Token(Token = "0x6002C5A")]
		[Address(RVA = "0x21267BC", Offset = "0x21267BC", VA = "0x21267BC")]
		private void method_130()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C5B RID: 11355 RVA: 0x0005C8C0 File Offset: 0x0005AAC0
		[Token(Token = "0x6002C5B")]
		[Address(RVA = "0x2116408", Offset = "0x2116408", VA = "0x2116408")]
		private void method_131(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002C5C RID: 11356 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Token(Token = "0x6002C5C")]
		[Address(RVA = "0x2124878", Offset = "0x2124878", VA = "0x2124878")]
		private void method_132(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C5D RID: 11357 RVA: 0x0005C96C File Offset: 0x0005AB6C
		[Address(RVA = "0x2126A78", Offset = "0x2126A78", VA = "0x2126A78")]
		[Token(Token = "0x6002C5D")]
		private void method_133(Transform transform_0)
		{
			Func<HVRGrabbable, bool> <>9__0;
			if (<>9__0 == null)
			{
				Func<HVRGrabbable, bool> <>9__;
				<>9__0 = <>9__;
			}
		}

		// Token: 0x06002C5E RID: 11358 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
		[Address(RVA = "0x2126E3C", Offset = "0x2126E3C", VA = "0x2126E3C")]
		[Token(Token = "0x6002C5E")]
		private void method_134(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x06002C5F RID: 11359 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Token(Token = "0x6002C5F")]
		[Address(RVA = "0x2126EA0", Offset = "0x2126EA0", VA = "0x2126EA0")]
		private void method_135()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C60 RID: 11360 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Address(RVA = "0x212715C", Offset = "0x212715C", VA = "0x212715C")]
		[Token(Token = "0x6002C60")]
		private void method_136()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C61 RID: 11361 RVA: 0x0005C8C0 File Offset: 0x0005AAC0
		[Token(Token = "0x6002C61")]
		[Address(RVA = "0x2113C60", Offset = "0x2113C60", VA = "0x2113C60")]
		private void method_137(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x06002C62 RID: 11362 RVA: 0x0005CE4C File Offset: 0x0005B04C
		[Address(RVA = "0x2127418", Offset = "0x2127418", VA = "0x2127418")]
		[Token(Token = "0x6002C62")]
		public void method_138(HVRSocket hvrsocket_0, GameObject gameObject_0)
		{
			gameObject_0.GetComponent<HVRGrabbable>();
		}

		// Token: 0x06002C63 RID: 11363 RVA: 0x0005C94C File Offset: 0x0005AB4C
		[Token(Token = "0x6002C63")]
		[Address(RVA = "0x21274A4", Offset = "0x21274A4", VA = "0x21274A4")]
		private void method_139()
		{
			this.list_0.GetEnumerator().MoveNext();
		}

		// Token: 0x06002C64 RID: 11364 RVA: 0x0005C8C0 File Offset: 0x0005AAC0
		[Token(Token = "0x6002C64")]
		[Address(RVA = "0x21157E8", Offset = "0x21157E8", VA = "0x21157E8")]
		private void method_140(Transform transform_0, HVRGrabbable hvrgrabbable_0)
		{
			HVRGrabbable hvrgrabbable;
			GameObject gameObject = hvrgrabbable.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = hvrgrabbable.gameObject;
			DemoHelper.Class37 @class = new DemoHelper.Class37();
			@class.hvrgrabbable_0 = hvrgrabbable_0;
			@class.hvrgrabbable_1 = hvrgrabbable;
			Vector3 position = hvrgrabbable_0.transform.position;
			Quaternion rotation = hvrgrabbable_0.transform.rotation;
			Vector3 localScale = hvrgrabbable_0.transform.localScale;
			@class.transform_0 = transform_0;
		}

		// Token: 0x04000592 RID: 1426
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000592")]
		public List<Transform> list_0;

		// Token: 0x04000593 RID: 1427
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000593")]
		public List<HVRGrabbable> list_1;

		// Token: 0x04000594 RID: 1428
		[Token(Token = "0x4000594")]
		[FieldOffset(Offset = "0x28")]
		public bool bool_0;

		// Token: 0x04000595 RID: 1429
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000595")]
		private readonly List<DemoHelper.Class37> list_2;

		// Token: 0x04000596 RID: 1430
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000596")]
		private List<HVRGrabbable> list_3;

		// Token: 0x0200011E RID: 286
		[Token(Token = "0x200011E")]
		private class Class37
		{
			// Token: 0x06002C65 RID: 11365 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Token(Token = "0x6002C65")]
			[Address(RVA = "0x106FC3C", Offset = "0x106FC3C", VA = "0x106FC3C")]
			public Vector3 method_0()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x06002C66 RID: 11366 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Address(RVA = "0x106FC48", Offset = "0x106FC48", VA = "0x106FC48")]
			[Token(Token = "0x6002C66")]
			public Vector3 method_1()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x06002C67 RID: 11367 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Address(RVA = "0x106FC54", Offset = "0x106FC54", VA = "0x106FC54")]
			[Token(Token = "0x6002C67")]
			public Vector3 method_2()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x06002C68 RID: 11368 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Address(RVA = "0x106FC60", Offset = "0x106FC60", VA = "0x106FC60")]
			[Token(Token = "0x6002C68")]
			public Vector3 method_3()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x06002C69 RID: 11369 RVA: 0x00002083 File Offset: 0x00000283
			[Token(Token = "0x6002C69")]
			[Address(RVA = "0x106FC6C", Offset = "0x106FC6C", VA = "0x106FC6C")]
			public void method_4(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C6A RID: 11370 RVA: 0x00002083 File Offset: 0x00000283
			[Address(RVA = "0x106FC78", Offset = "0x106FC78", VA = "0x106FC78")]
			[Token(Token = "0x6002C6A")]
			public void method_5(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C6B RID: 11371 RVA: 0x00002083 File Offset: 0x00000283
			[Address(RVA = "0x106FC84", Offset = "0x106FC84", VA = "0x106FC84")]
			[Token(Token = "0x6002C6B")]
			public void method_6(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C6C RID: 11372 RVA: 0x00002083 File Offset: 0x00000283
			[Address(RVA = "0x106FC90", Offset = "0x106FC90", VA = "0x106FC90")]
			[Token(Token = "0x6002C6C")]
			public void method_7(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C6D RID: 11373 RVA: 0x00002083 File Offset: 0x00000283
			[Token(Token = "0x6002C6D")]
			[Address(RVA = "0x106FC9C", Offset = "0x106FC9C", VA = "0x106FC9C")]
			public void method_8(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C6E RID: 11374 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Address(RVA = "0x106FCA8", Offset = "0x106FCA8", VA = "0x106FCA8")]
			[Token(Token = "0x6002C6E")]
			public Vector3 method_9()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x06002C6F RID: 11375 RVA: 0x00002083 File Offset: 0x00000283
			[Token(Token = "0x6002C6F")]
			[Address(RVA = "0x106FCB4", Offset = "0x106FCB4", VA = "0x106FCB4")]
			public void method_10(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C70 RID: 11376 RVA: 0x00002083 File Offset: 0x00000283
			[Address(RVA = "0x106FCC0", Offset = "0x106FCC0", VA = "0x106FCC0")]
			[Token(Token = "0x6002C70")]
			public void method_11(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C71 RID: 11377 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Address(RVA = "0x106FCCC", Offset = "0x106FCCC", VA = "0x106FCCC")]
			[Token(Token = "0x6002C71")]
			public Vector3 method_12()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x06002C72 RID: 11378 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Address(RVA = "0x106FCD8", Offset = "0x106FCD8", VA = "0x106FCD8")]
			[Token(Token = "0x6002C72")]
			public Vector3 method_13()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x17000077 RID: 119
			// (get) Token: 0x06002C73 RID: 11379 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			// (set) Token: 0x06002C78 RID: 11384 RVA: 0x00002083 File Offset: 0x00000283
			[Token(Token = "0x17000077")]
			public Vector3 Vector3_0
			{
				[CompilerGenerated]
				[Address(RVA = "0x106FCE4", Offset = "0x106FCE4", VA = "0x106FCE4")]
				[Token(Token = "0x6002C73")]
				get
				{
					Vector3 result;
					return result;
				}
				[Token(Token = "0x6002C78")]
				[CompilerGenerated]
				[Address(RVA = "0x106FD20", Offset = "0x106FD20", VA = "0x106FD20")]
				set
				{
				}
			}

			// Token: 0x06002C74 RID: 11380 RVA: 0x00002083 File Offset: 0x00000283
			[Token(Token = "0x6002C74")]
			[Address(RVA = "0x106FCF0", Offset = "0x106FCF0", VA = "0x106FCF0")]
			public void method_14(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C75 RID: 11381 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Token(Token = "0x6002C75")]
			[Address(RVA = "0x106FCFC", Offset = "0x106FCFC", VA = "0x106FCFC")]
			public Vector3 method_15()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x06002C76 RID: 11382 RVA: 0x00002083 File Offset: 0x00000283
			[Token(Token = "0x6002C76")]
			[Address(RVA = "0x106FD08", Offset = "0x106FD08", VA = "0x106FD08")]
			public void method_16(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C77 RID: 11383 RVA: 0x00002083 File Offset: 0x00000283
			[Address(RVA = "0x106FD14", Offset = "0x106FD14", VA = "0x106FD14")]
			[Token(Token = "0x6002C77")]
			public void method_17(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C79 RID: 11385 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Token(Token = "0x6002C79")]
			[Address(RVA = "0x106FD2C", Offset = "0x106FD2C", VA = "0x106FD2C")]
			public Vector3 method_18()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x06002C7A RID: 11386 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Address(RVA = "0x106FD38", Offset = "0x106FD38", VA = "0x106FD38")]
			[Token(Token = "0x6002C7A")]
			public Vector3 method_19()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x06002C7B RID: 11387 RVA: 0x000020B4 File Offset: 0x000002B4
			[Address(RVA = "0x106FD44", Offset = "0x106FD44", VA = "0x106FD44")]
			[Token(Token = "0x6002C7B")]
			public Class37()
			{
			}

			// Token: 0x06002C7C RID: 11388 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
			[Address(RVA = "0x106FD4C", Offset = "0x106FD4C", VA = "0x106FD4C")]
			[Token(Token = "0x6002C7C")]
			public Vector3 method_20()
			{
				Vector3 result;
				return result;
			}

			// Token: 0x06002C7D RID: 11389 RVA: 0x00002083 File Offset: 0x00000283
			[Token(Token = "0x6002C7D")]
			[Address(RVA = "0x106FD58", Offset = "0x106FD58", VA = "0x106FD58")]
			public void method_21(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C7E RID: 11390 RVA: 0x00002083 File Offset: 0x00000283
			[Address(RVA = "0x106FD64", Offset = "0x106FD64", VA = "0x106FD64")]
			[Token(Token = "0x6002C7E")]
			public void method_22(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C7F RID: 11391 RVA: 0x00002083 File Offset: 0x00000283
			[Token(Token = "0x6002C7F")]
			[Address(RVA = "0x106FD70", Offset = "0x106FD70", VA = "0x106FD70")]
			public void method_23(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C80 RID: 11392 RVA: 0x00002083 File Offset: 0x00000283
			[Token(Token = "0x6002C80")]
			[Address(RVA = "0x106FD7C", Offset = "0x106FD7C", VA = "0x106FD7C")]
			public void method_24(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C81 RID: 11393 RVA: 0x00002083 File Offset: 0x00000283
			[Address(RVA = "0x106FD88", Offset = "0x106FD88", VA = "0x106FD88")]
			[Token(Token = "0x6002C81")]
			public void method_25(Vector3 vector3_2)
			{
			}

			// Token: 0x06002C82 RID: 11394 RVA: 0x00002083 File Offset: 0x00000283
			[Token(Token = "0x6002C82")]
			[Address(RVA = "0x106FD94", Offset = "0x106FD94", VA = "0x106FD94")]
			public void method_26(Vector3 vector3_2)
			{
			}

			// Token: 0x04000597 RID: 1431
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000597")]
			public HVRGrabbable hvrgrabbable_0;

			// Token: 0x04000598 RID: 1432
			[Token(Token = "0x4000598")]
			[FieldOffset(Offset = "0x18")]
			public HVRGrabbable hvrgrabbable_1;

			// Token: 0x04000599 RID: 1433
			[Token(Token = "0x4000599")]
			[FieldOffset(Offset = "0x20")]
			public Vector3 vector3_0;

			// Token: 0x0400059A RID: 1434
			[FieldOffset(Offset = "0x2C")]
			[Token(Token = "0x400059A")]
			public Quaternion quaternion_0;

			// Token: 0x0400059B RID: 1435
			[Token(Token = "0x400059B")]
			[FieldOffset(Offset = "0x3C")]
			[CompilerGenerated]
			private Vector3 vector3_1;

			// Token: 0x0400059C RID: 1436
			[FieldOffset(Offset = "0x48")]
			[Token(Token = "0x400059C")]
			public Transform transform_0;
		}

		// Token: 0x0200011F RID: 287
		[CompilerGenerated]
		[Token(Token = "0x200011F")]
		private sealed class Class38
		{
			// Token: 0x06002C83 RID: 11395 RVA: 0x000020B4 File Offset: 0x000002B4
			[Address(RVA = "0x106FB94", Offset = "0x106FB94", VA = "0x106FB94")]
			[Token(Token = "0x6002C83")]
			public Class38()
			{
			}

			// Token: 0x06002C84 RID: 11396 RVA: 0x0005CFF0 File Offset: 0x0005B1F0
			[Token(Token = "0x6002C84")]
			[Address(RVA = "0x106FB9C", Offset = "0x106FB9C", VA = "0x106FB9C")]
			internal bool method_0(HVRGrabbable e)
			{
				Transform x = e.transform.parent;
				Transform y = this.parent;
				return x == y;
			}

			// Token: 0x0400059D RID: 1437
			[Token(Token = "0x400059D")]
			[FieldOffset(Offset = "0x10")]
			public Transform parent;

			// Token: 0x0400059E RID: 1438
			[Token(Token = "0x400059E")]
			[FieldOffset(Offset = "0x18")]
			public Func<HVRGrabbable, bool> <>9__0;
		}
	}
}
