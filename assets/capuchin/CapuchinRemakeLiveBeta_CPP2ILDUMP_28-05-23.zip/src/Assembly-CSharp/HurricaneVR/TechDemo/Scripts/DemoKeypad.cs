﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Components;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000123 RID: 291
	[Token(Token = "0x2000123")]
	public class DemoKeypad : MonoBehaviour
	{
		// Token: 0x06002CF1 RID: 11505 RVA: 0x0005D0E8 File Offset: 0x0005B2E8
		[Address(RVA = "0x212B434", Offset = "0x212B434", VA = "0x212B434", Slot = "4")]
		[Token(Token = "0x6002CF1")]
		protected virtual void vmethod_0()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			long num = 1L;
			this.bool_1 = (num != 0L);
			Debug.Log("unlocked!");
		}

		// Token: 0x06002CF2 RID: 11506 RVA: 0x00002ED0 File Offset: 0x000010D0
		[Address(RVA = "0x212B4D0", Offset = "0x212B4D0", VA = "0x212B4D0", Slot = "5")]
		[Token(Token = "0x6002CF2")]
		protected virtual void vmethod_1()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("FingerTip");
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06002CF3 RID: 11507 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Token(Token = "0x17000078")]
		public int Int32_0
		{
			[Address(RVA = "0x212B568", Offset = "0x212B568", VA = "0x212B568")]
			[Token(Token = "0x6002CF3")]
			get
			{
				string text = this.string_1;
				if (text == null)
				{
				}
				return text.m_stringLength;
			}
		}

		// Token: 0x06002CF4 RID: 11508 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212B580", Offset = "0x212B580", VA = "0x212B580")]
		[Token(Token = "0x6002CF4")]
		public int method_0()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002CF5 RID: 11509 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212B598", Offset = "0x212B598", VA = "0x212B598")]
		[Token(Token = "0x6002CF5")]
		public int method_1()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002CF6 RID: 11510 RVA: 0x00002EEF File Offset: 0x000010EF
		[Address(RVA = "0x212B5B0", Offset = "0x212B5B0", VA = "0x212B5B0", Slot = "6")]
		[Token(Token = "0x6002CF6")]
		protected virtual void vmethod_2()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("typesOfTalk");
		}

		// Token: 0x06002CF7 RID: 11511 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x212B648", Offset = "0x212B648", VA = "0x212B648", Slot = "7")]
		[Token(Token = "0x6002CF7")]
		public virtual void vmethod_3()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002CF8 RID: 11512 RVA: 0x00002F0E File Offset: 0x0000110E
		[Address(RVA = "0x212B66C", Offset = "0x212B66C", VA = "0x212B66C", Slot = "8")]
		[Token(Token = "0x6002CF8")]
		public virtual void vmethod_4()
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002CF9 RID: 11513 RVA: 0x00002F19 File Offset: 0x00001119
		[Address(RVA = "0x212B68C", Offset = "0x212B68C", VA = "0x212B68C", Slot = "9")]
		[Token(Token = "0x6002CF9")]
		protected virtual void vmethod_5()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("_Tint");
		}

		// Token: 0x06002CFA RID: 11514 RVA: 0x0005D17C File Offset: 0x0005B37C
		[Address(RVA = "0x212B724", Offset = "0x212B724", VA = "0x212B724", Slot = "10")]
		[Token(Token = "0x6002CFA")]
		protected virtual void vmethod_6()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			long num = 1L;
			this.bool_1 = (num != 0L);
			Debug.Log("true");
		}

		// Token: 0x06002CFB RID: 11515 RVA: 0x0005D1B0 File Offset: 0x0005B3B0
		[Address(RVA = "0x212B7C0", Offset = "0x212B7C0", VA = "0x212B7C0", Slot = "11")]
		[Token(Token = "0x6002CFB")]
		protected virtual void vmethod_7()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002CFC RID: 11516 RVA: 0x00002F0E File Offset: 0x0000110E
		[Address(RVA = "0x212BB44", Offset = "0x212BB44", VA = "0x212BB44", Slot = "12")]
		[Token(Token = "0x6002CFC")]
		public virtual void vmethod_8()
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002CFD RID: 11517 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212BB64", Offset = "0x212BB64", VA = "0x212BB64")]
		[Token(Token = "0x6002CFD")]
		public int method_2()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002CFE RID: 11518 RVA: 0x0005D1E0 File Offset: 0x0005B3E0
		[Address(RVA = "0x212BB7C", Offset = "0x212BB7C", VA = "0x212BB7C", Slot = "13")]
		[Token(Token = "0x6002CFE")]
		protected virtual void Start()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002CFF RID: 11519 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212BEE0", Offset = "0x212BEE0", VA = "0x212BEE0")]
		[Token(Token = "0x6002CFF")]
		public int method_3()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D00 RID: 11520 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212BEF8", Offset = "0x212BEF8", VA = "0x212BEF8")]
		[Token(Token = "0x6002D00")]
		public int method_4()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D01 RID: 11521 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212BF10", Offset = "0x212BF10", VA = "0x212BF10")]
		[Token(Token = "0x6002D01")]
		public int method_5()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D02 RID: 11522 RVA: 0x0005D210 File Offset: 0x0005B410
		[Address(RVA = "0x212BF28", Offset = "0x212BF28", VA = "0x212BF28", Slot = "14")]
		[Token(Token = "0x6002D02")]
		protected virtual void vmethod_9()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			Collider[] componentsInChildren = base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
			long index = 1L;
			string text;
			char c = text[(int)index];
			componentsInChildren;
			this.string_1 = ".Please press the button if you would like to play alone";
			this;
			string text2 = this.string_0;
			string text3 = this.string_1;
			long totalWidth;
			if (text2 != null)
			{
				if (text3 == null)
				{
					return;
				}
			}
			else
			{
				totalWidth = 0L;
			}
			text3.PadLeft((int)totalWidth, 'ﾜ');
		}

		// Token: 0x06002D03 RID: 11523 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212C270", Offset = "0x212C270", VA = "0x212C270")]
		[Token(Token = "0x6002D03")]
		public int method_6()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D04 RID: 11524 RVA: 0x0005D290 File Offset: 0x0005B490
		[Address(RVA = "0x212C288", Offset = "0x212C288", VA = "0x212C288", Slot = "15")]
		[Token(Token = "0x6002D04")]
		protected virtual void vmethod_10(HVRPhysicsButton hvrphysicsButton_0)
		{
		}

		// Token: 0x06002D05 RID: 11525 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212C4B8", Offset = "0x212C4B8", VA = "0x212C4B8")]
		[Token(Token = "0x6002D05")]
		public int method_7()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D06 RID: 11526 RVA: 0x00002F38 File Offset: 0x00001138
		[Address(RVA = "0x212C4D0", Offset = "0x212C4D0", VA = "0x212C4D0", Slot = "16")]
		[Token(Token = "0x6002D06")]
		protected virtual void vmethod_11()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("Start Gamemode");
		}

		// Token: 0x06002D07 RID: 11527 RVA: 0x0005D2A0 File Offset: 0x0005B4A0
		[Address(RVA = "0x212C568", Offset = "0x212C568", VA = "0x212C568", Slot = "17")]
		[Token(Token = "0x6002D07")]
		protected virtual void vmethod_12()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
		}

		// Token: 0x06002D08 RID: 11528 RVA: 0x0005D2C4 File Offset: 0x0005B4C4
		[Address(RVA = "0x212C8BC", Offset = "0x212C8BC", VA = "0x212C8BC", Slot = "18")]
		[Token(Token = "0x6002D08")]
		protected virtual void vmethod_13(HVRPhysicsButton hvrphysicsButton_0)
		{
		}

		// Token: 0x06002D09 RID: 11529 RVA: 0x00002F57 File Offset: 0x00001157
		[Address(RVA = "0x212CA7C", Offset = "0x212CA7C", VA = "0x212CA7C", Slot = "19")]
		[Token(Token = "0x6002D09")]
		protected virtual void vmethod_14()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("ChangeToRegular");
		}

		// Token: 0x06002D0A RID: 11530 RVA: 0x00002F0E File Offset: 0x0000110E
		[Address(RVA = "0x212CB14", Offset = "0x212CB14", VA = "0x212CB14", Slot = "20")]
		[Token(Token = "0x6002D0A")]
		public virtual void vmethod_15()
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002D0B RID: 11531 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212C8A4", Offset = "0x212C8A4", VA = "0x212C8A4")]
		[Token(Token = "0x6002D0B")]
		public int method_8()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D0C RID: 11532 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212CB30", Offset = "0x212CB30", VA = "0x212CB30")]
		[Token(Token = "0x6002D0C")]
		public int method_9()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D0D RID: 11533 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x212CB48", Offset = "0x212CB48", VA = "0x212CB48", Slot = "21")]
		[Token(Token = "0x6002D0D")]
		public virtual void vmethod_16()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002D0E RID: 11534 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212CB68", Offset = "0x212CB68", VA = "0x212CB68")]
		[Token(Token = "0x6002D0E")]
		public int method_10()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D0F RID: 11535 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x212CB80", Offset = "0x212CB80", VA = "0x212CB80", Slot = "22")]
		[Token(Token = "0x6002D0F")]
		public virtual void vmethod_17()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002D10 RID: 11536 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212CBA4", Offset = "0x212CBA4", VA = "0x212CBA4")]
		[Token(Token = "0x6002D10")]
		public int method_11()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D11 RID: 11537 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212CBBC", Offset = "0x212CBBC", VA = "0x212CBBC")]
		[Token(Token = "0x6002D11")]
		public int method_12()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D12 RID: 11538 RVA: 0x0005D2D4 File Offset: 0x0005B4D4
		[Address(RVA = "0x212CBD4", Offset = "0x212CBD4", VA = "0x212CBD4")]
		[Token(Token = "0x6002D12")]
		public DemoKeypad()
		{
			UnityEvent unityEvent = new UnityEvent();
			unityEvent.m_PersistentCalls = unityEvent;
		}

		// Token: 0x06002D13 RID: 11539 RVA: 0x0005D2F0 File Offset: 0x0005B4F0
		[Address(RVA = "0x212CC68", Offset = "0x212CC68", VA = "0x212CC68", Slot = "23")]
		[Token(Token = "0x6002D13")]
		protected virtual void vmethod_18()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			Collider[] componentsInChildren = base.GetComponentsInChildren<Collider>();
			componentsInChildren.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002D14 RID: 11540 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212CF90", Offset = "0x212CF90", VA = "0x212CF90", Slot = "24")]
		[Token(Token = "0x6002D14")]
		protected virtual void vmethod_19()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002D15 RID: 11541 RVA: 0x0005D31C File Offset: 0x0005B51C
		[Address(RVA = "0x212D2C8", Offset = "0x212D2C8", VA = "0x212D2C8", Slot = "25")]
		[Token(Token = "0x6002D15")]
		protected virtual void vmethod_20()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			long num = 1L;
			this.bool_1 = (num != 0L);
			Debug.Log("Player was caught cheating");
		}

		// Token: 0x06002D16 RID: 11542 RVA: 0x0005D350 File Offset: 0x0005B550
		[Address(RVA = "0x212D364", Offset = "0x212D364", VA = "0x212D364", Slot = "26")]
		[Token(Token = "0x6002D16")]
		protected virtual void vmethod_21(HVRPhysicsButton hvrphysicsButton_0)
		{
			string a = this.string_0;
			string b = this.string_1;
			a == b;
		}

		// Token: 0x06002D17 RID: 11543 RVA: 0x0005D374 File Offset: 0x0005B574
		[Address(RVA = "0x212D548", Offset = "0x212D548", VA = "0x212D548", Slot = "27")]
		[Token(Token = "0x6002D17")]
		protected virtual void vmethod_22()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			long num = 1L;
			this.bool_1 = (num != 0L);
			Debug.Log("PRESS AGAIN TO CONFIRM");
		}

		// Token: 0x06002D18 RID: 11544 RVA: 0x0005D3A8 File Offset: 0x0005B5A8
		[Address(RVA = "0x212D5E4", Offset = "0x212D5E4", VA = "0x212D5E4", Slot = "28")]
		[Token(Token = "0x6002D18")]
		protected virtual void vmethod_23(HVRPhysicsButton hvrphysicsButton_0)
		{
		}

		// Token: 0x06002D19 RID: 11545 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212D7FC", Offset = "0x212D7FC", VA = "0x212D7FC")]
		[Token(Token = "0x6002D19")]
		public int method_13()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D1A RID: 11546 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212D2B0", Offset = "0x212D2B0", VA = "0x212D2B0")]
		[Token(Token = "0x6002D1A")]
		public int method_14()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D1B RID: 11547 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212C4A0", Offset = "0x212C4A0", VA = "0x212C4A0")]
		[Token(Token = "0x6002D1B")]
		public int method_15()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D1C RID: 11548 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212D814", Offset = "0x212D814", VA = "0x212D814")]
		[Token(Token = "0x6002D1C")]
		public int method_16()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D1D RID: 11549 RVA: 0x00002F0E File Offset: 0x0000110E
		[Address(RVA = "0x212D82C", Offset = "0x212D82C", VA = "0x212D82C", Slot = "29")]
		[Token(Token = "0x6002D1D")]
		public virtual void vmethod_24()
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002D1E RID: 11550 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212D84C", Offset = "0x212D84C", VA = "0x212D84C")]
		[Token(Token = "0x6002D1E")]
		public int method_17()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D1F RID: 11551 RVA: 0x0005D3B8 File Offset: 0x0005B5B8
		[Address(RVA = "0x212D864", Offset = "0x212D864", VA = "0x212D864", Slot = "30")]
		[Token(Token = "0x6002D1F")]
		protected virtual void vmethod_25(HVRPhysicsButton hvrphysicsButton_0)
		{
			string a = this.string_0;
			string b = this.string_1;
			a == b;
		}

		// Token: 0x06002D20 RID: 11552 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212DA14", Offset = "0x212DA14", VA = "0x212DA14")]
		[Token(Token = "0x6002D20")]
		public int method_18()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D21 RID: 11553 RVA: 0x0005D3DC File Offset: 0x0005B5DC
		[Address(RVA = "0x212DA2C", Offset = "0x212DA2C", VA = "0x212DA2C", Slot = "31")]
		[Token(Token = "0x6002D21")]
		protected virtual void vmethod_26(HVRPhysicsButton hvrphysicsButton_0)
		{
		}

		// Token: 0x06002D22 RID: 11554 RVA: 0x00002F76 File Offset: 0x00001176
		[Address(RVA = "0x212DC04", Offset = "0x212DC04", VA = "0x212DC04", Slot = "32")]
		[Token(Token = "0x6002D22")]
		protected virtual void vmethod_27()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("TurnAmount");
		}

		// Token: 0x06002D23 RID: 11555 RVA: 0x0005D3EC File Offset: 0x0005B5EC
		[Address(RVA = "0x212DC9C", Offset = "0x212DC9C", VA = "0x212DC9C", Slot = "33")]
		[Token(Token = "0x6002D23")]
		protected virtual void vmethod_28(HVRPhysicsButton hvrphysicsButton_0)
		{
			string text = this.string_1;
			if (text != null)
			{
				return;
			}
			if (this.string_0 == null)
			{
			}
			string str;
			text + str;
			hvrphysicsButton_0;
			string text2 = this.string_0;
			string text3 = this.string_1;
			long totalWidth;
			if (text2 != null)
			{
				if (text3 == null)
				{
					return;
				}
			}
			else
			{
				totalWidth = 0L;
			}
			text3.PadLeft((int)totalWidth, 'ﾷ');
		}

		// Token: 0x06002D24 RID: 11556 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x212DE10", Offset = "0x212DE10", VA = "0x212DE10", Slot = "34")]
		[Token(Token = "0x6002D24")]
		public virtual void vmethod_29()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002D25 RID: 11557 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212DE34", Offset = "0x212DE34", VA = "0x212DE34")]
		[Token(Token = "0x6002D25")]
		public int method_19()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D26 RID: 11558 RVA: 0x0005D44C File Offset: 0x0005B64C
		[Address(RVA = "0x212DE4C", Offset = "0x212DE4C", VA = "0x212DE4C", Slot = "35")]
		[Token(Token = "0x6002D26")]
		protected virtual void vmethod_30(HVRPhysicsButton hvrphysicsButton_0)
		{
			string text = this.string_1;
			if (text != null)
			{
				return;
			}
			string text2 = this.string_0;
			if (text2 != null)
			{
				return;
			}
			string str;
			text + str;
			TextMeshPro exists = this.textMeshPro_0;
			exists;
			string text3 = this.string_0;
			string text4 = this.string_1;
			long totalWidth;
			if (text3 != null)
			{
				if (text4 == null)
				{
					return;
				}
			}
			else
			{
				totalWidth = 1L;
			}
			text4.PadLeft((int)totalWidth, 'ￊ');
		}

		// Token: 0x06002D27 RID: 11559 RVA: 0x00002F0E File Offset: 0x0000110E
		[Address(RVA = "0x212DFCC", Offset = "0x212DFCC", VA = "0x212DFCC", Slot = "36")]
		[Token(Token = "0x6002D27")]
		public virtual void vmethod_31()
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002D28 RID: 11560 RVA: 0x00002F95 File Offset: 0x00001195
		[Address(RVA = "0x212DFEC", Offset = "0x212DFEC", VA = "0x212DFEC", Slot = "37")]
		[Token(Token = "0x6002D28")]
		protected virtual void vmethod_32()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("Vertical");
		}

		// Token: 0x06002D29 RID: 11561 RVA: 0x00002FB4 File Offset: 0x000011B4
		[Address(RVA = "0x212E084", Offset = "0x212E084", VA = "0x212E084", Slot = "38")]
		[Token(Token = "0x6002D29")]
		protected virtual void vmethod_33()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("This is the 2500 Bananas button, and it was just clicked");
		}

		// Token: 0x06002D2A RID: 11562 RVA: 0x0005D4B4 File Offset: 0x0005B6B4
		[Address(RVA = "0x212E11C", Offset = "0x212E11C", VA = "0x212E11C", Slot = "39")]
		[Token(Token = "0x6002D2A")]
		protected virtual void vmethod_34()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002D2B RID: 11563 RVA: 0x0005D4E4 File Offset: 0x0005B6E4
		[Address(RVA = "0x212E484", Offset = "0x212E484", VA = "0x212E484", Slot = "40")]
		[Token(Token = "0x6002D2B")]
		protected virtual void vmethod_35()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			long num = 1L;
			this.bool_1 = (num != 0L);
			Debug.Log("FingerTip");
		}

		// Token: 0x06002D2C RID: 11564 RVA: 0x0005D518 File Offset: 0x0005B718
		[Address(RVA = "0x212E520", Offset = "0x212E520", VA = "0x212E520", Slot = "41")]
		[Token(Token = "0x6002D2C")]
		protected virtual void vmethod_36(HVRPhysicsButton hvrphysicsButton_0)
		{
			string text = this.string_1;
			int stringLength = text.m_stringLength;
			long startIndex = 1L;
			text.Substring((int)startIndex, stringLength);
		}

		// Token: 0x06002D2D RID: 11565 RVA: 0x0005D3B8 File Offset: 0x0005B5B8
		[Token(Token = "0x6002D2D")]
		[Address(RVA = "0x212E720", Offset = "0x212E720", VA = "0x212E720", Slot = "42")]
		protected virtual void vmethod_37(HVRPhysicsButton hvrphysicsButton_0)
		{
			string a = this.string_0;
			string b = this.string_1;
			a == b;
		}

		// Token: 0x06002D2E RID: 11566 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x212E8C8", Offset = "0x212E8C8", VA = "0x212E8C8", Slot = "43")]
		[Token(Token = "0x6002D2E")]
		public virtual void vmethod_38()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002D2F RID: 11567 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Token(Token = "0x6002D2F")]
		[Address(RVA = "0x212E8E8", Offset = "0x212E8E8", VA = "0x212E8E8")]
		public int method_20()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D30 RID: 11568 RVA: 0x00002F0E File Offset: 0x0000110E
		[Token(Token = "0x6002D30")]
		[Address(RVA = "0x212E900", Offset = "0x212E900", VA = "0x212E900", Slot = "44")]
		public virtual void vmethod_39()
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002D31 RID: 11569 RVA: 0x00002F0E File Offset: 0x0000110E
		[Address(RVA = "0x212E920", Offset = "0x212E920", VA = "0x212E920", Slot = "45")]
		[Token(Token = "0x6002D31")]
		public virtual void vmethod_40()
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002D32 RID: 11570 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Token(Token = "0x6002D32")]
		[Address(RVA = "0x212CF78", Offset = "0x212CF78", VA = "0x212CF78")]
		public int method_21()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D33 RID: 11571 RVA: 0x00002FD3 File Offset: 0x000011D3
		[Token(Token = "0x6002D33")]
		[Address(RVA = "0x212E940", Offset = "0x212E940", VA = "0x212E940", Slot = "46")]
		protected virtual void vmethod_41()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("Name Changing Error. Error: ");
		}

		// Token: 0x06002D34 RID: 11572 RVA: 0x0005D540 File Offset: 0x0005B740
		[Address(RVA = "0x212E9D8", Offset = "0x212E9D8", VA = "0x212E9D8", Slot = "47")]
		[Token(Token = "0x6002D34")]
		protected virtual void vmethod_42()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			long num = 1L;
			this.bool_1 = (num != 0L);
			Debug.Log("SaveHeight");
		}

		// Token: 0x06002D35 RID: 11573 RVA: 0x0005D574 File Offset: 0x0005B774
		[Address(RVA = "0x212EA74", Offset = "0x212EA74", VA = "0x212EA74", Slot = "48")]
		[Token(Token = "0x6002D35")]
		protected virtual void vmethod_43()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			long num = 1L;
			this.bool_1 = (num != 0L);
			Debug.Log("M/d/yyyy");
		}

		// Token: 0x06002D36 RID: 11574 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212DBD4", Offset = "0x212DBD4", VA = "0x212DBD4")]
		[Token(Token = "0x6002D36")]
		public int method_22()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D37 RID: 11575 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212D518", Offset = "0x212D518", VA = "0x212D518")]
		[Token(Token = "0x6002D37")]
		public int method_23()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D38 RID: 11576 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x212EB10", Offset = "0x212EB10", VA = "0x212EB10", Slot = "49")]
		[Token(Token = "0x6002D38")]
		public virtual void vmethod_44()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002D39 RID: 11577 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212D530", Offset = "0x212D530", VA = "0x212D530")]
		[Token(Token = "0x6002D39")]
		public int method_24()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D3A RID: 11578 RVA: 0x0005D350 File Offset: 0x0005B550
		[Address(RVA = "0x212EB34", Offset = "0x212EB34", VA = "0x212EB34", Slot = "50")]
		[Token(Token = "0x6002D3A")]
		protected virtual void vmethod_45(HVRPhysicsButton hvrphysicsButton_0)
		{
			string a = this.string_0;
			string b = this.string_1;
			a == b;
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06002D3B RID: 11579 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Token(Token = "0x17000079")]
		public int Int32_1
		{
			[Address(RVA = "0x212BB2C", Offset = "0x212BB2C", VA = "0x212BB2C")]
			[Token(Token = "0x6002D3B")]
			get
			{
				string text = this.string_0;
				if (text == null)
				{
				}
				return text.m_stringLength;
			}
		}

		// Token: 0x06002D3C RID: 11580 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212C488", Offset = "0x212C488", VA = "0x212C488")]
		[Token(Token = "0x6002D3C")]
		public int method_25()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D3D RID: 11581 RVA: 0x0005D5A8 File Offset: 0x0005B7A8
		[Address(RVA = "0x212ED00", Offset = "0x212ED00", VA = "0x212ED00", Slot = "51")]
		[Token(Token = "0x6002D3D")]
		protected virtual void vmethod_46(HVRPhysicsButton hvrphysicsButton_0)
		{
		}

		// Token: 0x06002D3E RID: 11582 RVA: 0x0005D1E0 File Offset: 0x0005B3E0
		[Address(RVA = "0x212EEE4", Offset = "0x212EEE4", VA = "0x212EEE4", Slot = "52")]
		[Token(Token = "0x6002D3E")]
		protected virtual void vmethod_47()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002D3F RID: 11583 RVA: 0x00002F0E File Offset: 0x0000110E
		[Address(RVA = "0x212F24C", Offset = "0x212F24C", VA = "0x212F24C", Slot = "53")]
		[Token(Token = "0x6002D3F")]
		public virtual void vmethod_48()
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002D40 RID: 11584 RVA: 0x0005D5B8 File Offset: 0x0005B7B8
		[Address(RVA = "0x212F26C", Offset = "0x212F26C", VA = "0x212F26C", Slot = "54")]
		[Token(Token = "0x6002D40")]
		protected virtual void vmethod_49()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002D41 RID: 11585 RVA: 0x00002F0E File Offset: 0x0000110E
		[Address(RVA = "0x212F594", Offset = "0x212F594", VA = "0x212F594", Slot = "55")]
		[Token(Token = "0x6002D41")]
		public virtual void vmethod_50()
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002D42 RID: 11586 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x212F5B0", Offset = "0x212F5B0", VA = "0x212F5B0", Slot = "56")]
		[Token(Token = "0x6002D42")]
		public virtual void vmethod_51()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002D43 RID: 11587 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x212F5D4", Offset = "0x212F5D4", VA = "0x212F5D4", Slot = "57")]
		[Token(Token = "0x6002D43")]
		public virtual void vmethod_52()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002D44 RID: 11588 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x212F5F4", Offset = "0x212F5F4", VA = "0x212F5F4", Slot = "58")]
		[Token(Token = "0x6002D44")]
		public virtual void vmethod_53()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002D45 RID: 11589 RVA: 0x0005D5E8 File Offset: 0x0005B7E8
		[Address(RVA = "0x212F614", Offset = "0x212F614", VA = "0x212F614", Slot = "59")]
		[Token(Token = "0x6002D45")]
		protected virtual void vmethod_54()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002D46 RID: 11590 RVA: 0x0005D614 File Offset: 0x0005B814
		[Address(RVA = "0x212F958", Offset = "0x212F958", VA = "0x212F958", Slot = "60")]
		[Token(Token = "0x6002D46")]
		protected virtual void vmethod_55()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002D47 RID: 11591 RVA: 0x00002F0E File Offset: 0x0000110E
		[Address(RVA = "0x212FCBC", Offset = "0x212FCBC", VA = "0x212FCBC", Slot = "61")]
		[Token(Token = "0x6002D47")]
		public virtual void Update()
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002D48 RID: 11592 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212CA64", Offset = "0x212CA64", VA = "0x212CA64")]
		[Token(Token = "0x6002D48")]
		public int method_26()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D49 RID: 11593 RVA: 0x0005D644 File Offset: 0x0005B844
		[Address(RVA = "0x212FCD8", Offset = "0x212FCD8", VA = "0x212FCD8", Slot = "62")]
		[Token(Token = "0x6002D49")]
		protected virtual void vmethod_56(HVRPhysicsButton hvrphysicsButton_0)
		{
		}

		// Token: 0x06002D4A RID: 11594 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212F940", Offset = "0x212F940", VA = "0x212F940")]
		[Token(Token = "0x6002D4A")]
		public int method_27()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D4B RID: 11595 RVA: 0x0005D5B8 File Offset: 0x0005B7B8
		[Address(RVA = "0x212FF00", Offset = "0x212FF00", VA = "0x212FF00", Slot = "63")]
		[Token(Token = "0x6002D4B")]
		protected virtual void vmethod_57()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002D4C RID: 11596 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212C470", Offset = "0x212C470", VA = "0x212C470")]
		[Token(Token = "0x6002D4C")]
		public int method_28()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D4D RID: 11597 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x2130228", Offset = "0x2130228", VA = "0x2130228", Slot = "64")]
		[Token(Token = "0x6002D4D")]
		public virtual void vmethod_58()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002D4E RID: 11598 RVA: 0x0005D1E0 File Offset: 0x0005B3E0
		[Address(RVA = "0x213024C", Offset = "0x213024C", VA = "0x213024C", Slot = "65")]
		[Token(Token = "0x6002D4E")]
		protected virtual void vmethod_59()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002D4F RID: 11599 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Token(Token = "0x6002D4F")]
		[Address(RVA = "0x212DBEC", Offset = "0x212DBEC", VA = "0x212DBEC")]
		public int method_29()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D50 RID: 11600 RVA: 0x0005D654 File Offset: 0x0005B854
		[Address(RVA = "0x21305B4", Offset = "0x21305B4", VA = "0x21305B4", Slot = "66")]
		[Token(Token = "0x6002D50")]
		protected virtual void vmethod_60()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			long num = 1L;
			this.bool_1 = (num != 0L);
			if (num != 0L)
			{
			}
			Debug.Log("poweredup!");
		}

		// Token: 0x06002D51 RID: 11601 RVA: 0x00002FF2 File Offset: 0x000011F2
		[Address(RVA = "0x2130650", Offset = "0x2130650", VA = "0x2130650", Slot = "67")]
		[Token(Token = "0x6002D51")]
		protected virtual void vmethod_61()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("Skelechin");
		}

		// Token: 0x06002D52 RID: 11602 RVA: 0x0005D15C File Offset: 0x0005B35C
		[Address(RVA = "0x21306E8", Offset = "0x21306E8", VA = "0x21306E8", Slot = "68")]
		[Token(Token = "0x6002D52")]
		public virtual void vmethod_62()
		{
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				return;
			}
		}

		// Token: 0x06002D53 RID: 11603 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212ECE8", Offset = "0x212ECE8", VA = "0x212ECE8")]
		[Token(Token = "0x6002D53")]
		public int method_30()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D54 RID: 11604 RVA: 0x0005D68C File Offset: 0x0005B88C
		[Address(RVA = "0x213070C", Offset = "0x213070C", VA = "0x213070C", Slot = "69")]
		[Token(Token = "0x6002D54")]
		protected virtual void vmethod_63(HVRPhysicsButton hvrphysicsButton_0)
		{
		}

		// Token: 0x06002D55 RID: 11605 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212FED0", Offset = "0x212FED0", VA = "0x212FED0")]
		[Token(Token = "0x6002D55")]
		public int method_31()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D56 RID: 11606 RVA: 0x00003011 File Offset: 0x00001211
		[Address(RVA = "0x21308FC", Offset = "0x21308FC", VA = "0x21308FC", Slot = "70")]
		[Token(Token = "0x6002D56")]
		protected virtual void vmethod_64()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("true");
		}

		// Token: 0x06002D57 RID: 11607 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212E708", Offset = "0x212E708", VA = "0x212E708")]
		[Token(Token = "0x6002D57")]
		public int method_32()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D58 RID: 11608 RVA: 0x0005D69C File Offset: 0x0005B89C
		[Address(RVA = "0x2130994", Offset = "0x2130994", VA = "0x2130994", Slot = "71")]
		[Token(Token = "0x6002D58")]
		protected virtual void vmethod_65()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			long method = 0L;
			new UnityAction(this, (IntPtr)method);
		}

		// Token: 0x06002D59 RID: 11609 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212FEE8", Offset = "0x212FEE8", VA = "0x212FEE8")]
		[Token(Token = "0x6002D59")]
		public int method_33()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D5A RID: 11610 RVA: 0x0005D11C File Offset: 0x0005B31C
		[Address(RVA = "0x212D7CC", Offset = "0x212D7CC", VA = "0x212D7CC")]
		[Token(Token = "0x6002D5A")]
		public int method_34()
		{
			string text = this.string_1;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D5B RID: 11611 RVA: 0x0005D13C File Offset: 0x0005B33C
		[Address(RVA = "0x212D7E4", Offset = "0x212D7E4", VA = "0x212D7E4")]
		[Token(Token = "0x6002D5B")]
		public int method_35()
		{
			string text = this.string_0;
			if (text == null)
			{
			}
			return text.m_stringLength;
		}

		// Token: 0x06002D5C RID: 11612 RVA: 0x0005D2A0 File Offset: 0x0005B4A0
		[Address(RVA = "0x2130CE8", Offset = "0x2130CE8", VA = "0x2130CE8", Slot = "72")]
		[Token(Token = "0x6002D5C")]
		protected virtual void vmethod_66()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
		}

		// Token: 0x06002D5D RID: 11613 RVA: 0x00003030 File Offset: 0x00001230
		[Address(RVA = "0x2131020", Offset = "0x2131020", VA = "0x2131020", Slot = "73")]
		[Token(Token = "0x6002D5D")]
		protected virtual void vmethod_67()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("{0} ({1})");
		}

		// Token: 0x06002D5E RID: 11614 RVA: 0x0005D6CC File Offset: 0x0005B8CC
		[Address(RVA = "0x21310B8", Offset = "0x21310B8", VA = "0x21310B8", Slot = "74")]
		[Token(Token = "0x6002D5E")]
		protected virtual void vmethod_68()
		{
			base.GetComponentsInChildren<DemoKeypadButton>();
			Collider[] componentsInChildren = base.GetComponentsInChildren<Collider>();
			base.GetComponents<Collider>();
			componentsInChildren;
			this.string_1 = "Player";
			this;
			string text = this.string_0;
			string text2 = this.string_1;
			if (text != null)
			{
				return;
			}
			long totalWidth = 0L;
			text2.PadLeft((int)totalWidth, 'ￚ');
		}

		// Token: 0x06002D5F RID: 11615 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x21313C4", Offset = "0x21313C4", VA = "0x21313C4", Slot = "75")]
		[Token(Token = "0x6002D5F")]
		protected virtual void vmethod_69()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002D60 RID: 11616 RVA: 0x0005D730 File Offset: 0x0005B930
		[Address(RVA = "0x21316D0", Offset = "0x21316D0", VA = "0x21316D0", Slot = "76")]
		[Token(Token = "0x6002D60")]
		protected virtual void vmethod_70()
		{
			if (!this.bool_1)
			{
				this.unityEvent_0.Invoke();
			}
			Debug.Log("TurnAmount");
		}

		// Token: 0x040005A4 RID: 1444
		[Token(Token = "0x40005A4")]
		[FieldOffset(Offset = "0x18")]
		public UnityEvent unityEvent_0;

		// Token: 0x040005A5 RID: 1445
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40005A5")]
		public string string_0;

		// Token: 0x040005A6 RID: 1446
		[Token(Token = "0x40005A6")]
		[FieldOffset(Offset = "0x28")]
		public TextMeshPro textMeshPro_0;

		// Token: 0x040005A7 RID: 1447
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40005A7")]
		public string string_1;

		// Token: 0x040005A8 RID: 1448
		[Token(Token = "0x40005A8")]
		[FieldOffset(Offset = "0x38")]
		public bool bool_0;

		// Token: 0x040005A9 RID: 1449
		[Token(Token = "0x40005A9")]
		[FieldOffset(Offset = "0x39")]
		private bool bool_1;
	}
}
