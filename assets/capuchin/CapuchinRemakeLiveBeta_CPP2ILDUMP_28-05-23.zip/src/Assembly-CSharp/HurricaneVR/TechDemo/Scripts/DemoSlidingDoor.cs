﻿using System;
using System.Collections;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core.Utils;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000130 RID: 304
	[Token(Token = "0x2000130")]
	public class DemoSlidingDoor : MonoBehaviour
	{
		// Token: 0x06002FF1 RID: 12273 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AD2D4", Offset = "0x20AD2D4", VA = "0x20AD2D4")]
		[Token(Token = "0x6002FF1")]
		public void method_0()
		{
		}

		// Token: 0x06002FF2 RID: 12274 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AD2D8", Offset = "0x20AD2D8", VA = "0x20AD2D8")]
		[Token(Token = "0x6002FF2")]
		public void method_1()
		{
		}

		// Token: 0x06002FF3 RID: 12275 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AD2DC", Offset = "0x20AD2DC", VA = "0x20AD2DC")]
		[Token(Token = "0x6002FF3")]
		private IEnumerator method_2()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002FF4 RID: 12276 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AD354", Offset = "0x20AD354", VA = "0x20AD354")]
		[Token(Token = "0x6002FF4")]
		public void method_3()
		{
		}

		// Token: 0x06002FF5 RID: 12277 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AD358", Offset = "0x20AD358", VA = "0x20AD358")]
		[Token(Token = "0x6002FF5")]
		private IEnumerator method_4()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002FF6 RID: 12278 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x20AD3D0", Offset = "0x20AD3D0", VA = "0x20AD3D0")]
		[Token(Token = "0x6002FF6")]
		public DemoSlidingDoor()
		{
		}

		// Token: 0x06002FF7 RID: 12279 RVA: 0x0005FD50 File Offset: 0x0005DF50
		[Address(RVA = "0x20AD3E4", Offset = "0x20AD3E4", VA = "0x20AD3E4")]
		[Token(Token = "0x6002FF7")]
		public void method_5()
		{
			if (this.bool_0)
			{
				return;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			IEnumerator routine = this.method_4();
			base.StartCoroutine(routine);
		}

		// Token: 0x06002FF8 RID: 12280 RVA: 0x0005FD98 File Offset: 0x0005DF98
		[Address(RVA = "0x20AD518", Offset = "0x20AD518", VA = "0x20AD518")]
		[Token(Token = "0x6002FF8")]
		public void method_6()
		{
			if (this.bool_0)
			{
				return;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			IEnumerator routine = this.method_23();
			base.StartCoroutine(routine);
		}

		// Token: 0x06002FF9 RID: 12281 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AD6C4", Offset = "0x20AD6C4", VA = "0x20AD6C4")]
		[Token(Token = "0x6002FF9")]
		public void method_7()
		{
		}

		// Token: 0x06002FFA RID: 12282 RVA: 0x0005FDE0 File Offset: 0x0005DFE0
		[Address(RVA = "0x20AD6C8", Offset = "0x20AD6C8", VA = "0x20AD6C8")]
		[Token(Token = "0x6002FFA")]
		public void method_8()
		{
			if (this.bool_0)
			{
				return;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			IEnumerator routine = this.method_29();
			base.StartCoroutine(routine);
		}

		// Token: 0x06002FFB RID: 12283 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AD874", Offset = "0x20AD874", VA = "0x20AD874")]
		[Token(Token = "0x6002FFB")]
		private IEnumerator method_9()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002FFC RID: 12284 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AD8EC", Offset = "0x20AD8EC", VA = "0x20AD8EC")]
		[Token(Token = "0x6002FFC")]
		public void method_10()
		{
		}

		// Token: 0x06002FFD RID: 12285 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AD8F0", Offset = "0x20AD8F0", VA = "0x20AD8F0")]
		[Token(Token = "0x6002FFD")]
		private IEnumerator method_11()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06002FFE RID: 12286 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AD968", Offset = "0x20AD968", VA = "0x20AD968")]
		[Token(Token = "0x6002FFE")]
		public void method_12()
		{
		}

		// Token: 0x06002FFF RID: 12287 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AD96C", Offset = "0x20AD96C", VA = "0x20AD96C")]
		[Token(Token = "0x6002FFF")]
		private IEnumerator method_13()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003000 RID: 12288 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AD9E4", Offset = "0x20AD9E4", VA = "0x20AD9E4")]
		[Token(Token = "0x6003000")]
		private IEnumerator method_14()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003001 RID: 12289 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20ADA5C", Offset = "0x20ADA5C", VA = "0x20ADA5C")]
		[Token(Token = "0x6003001")]
		private IEnumerator method_15()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003002 RID: 12290 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20ADAD4", Offset = "0x20ADAD4", VA = "0x20ADAD4")]
		[Token(Token = "0x6003002")]
		private IEnumerator method_16()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003003 RID: 12291 RVA: 0x0005FE28 File Offset: 0x0005E028
		[Address(RVA = "0x20ADB4C", Offset = "0x20ADB4C", VA = "0x20ADB4C")]
		[Token(Token = "0x6003003")]
		public void method_17()
		{
			if (this.bool_0)
			{
				return;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
		}

		// Token: 0x06003004 RID: 12292 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20ADC80", Offset = "0x20ADC80", VA = "0x20ADC80")]
		[Token(Token = "0x6003004")]
		private IEnumerator method_18()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003005 RID: 12293 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20ADCF8", Offset = "0x20ADCF8", VA = "0x20ADCF8")]
		[Token(Token = "0x6003005")]
		private IEnumerator method_19()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003006 RID: 12294 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20ADD70", Offset = "0x20ADD70", VA = "0x20ADD70")]
		[Token(Token = "0x6003006")]
		public void method_20()
		{
		}

		// Token: 0x06003007 RID: 12295 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20ADD74", Offset = "0x20ADD74", VA = "0x20ADD74")]
		[Token(Token = "0x6003007")]
		private IEnumerator method_21()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003008 RID: 12296 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20ADDEC", Offset = "0x20ADDEC", VA = "0x20ADDEC")]
		[Token(Token = "0x6003008")]
		private IEnumerator method_22()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003009 RID: 12297 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AD64C", Offset = "0x20AD64C", VA = "0x20AD64C")]
		[Token(Token = "0x6003009")]
		private IEnumerator method_23()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x0600300A RID: 12298 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20ADE64", Offset = "0x20ADE64", VA = "0x20ADE64")]
		[Token(Token = "0x600300A")]
		public void Start()
		{
		}

		// Token: 0x0600300B RID: 12299 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20ADE68", Offset = "0x20ADE68", VA = "0x20ADE68")]
		[Token(Token = "0x600300B")]
		public void method_24()
		{
		}

		// Token: 0x0600300C RID: 12300 RVA: 0x0005FE70 File Offset: 0x0005E070
		[Address(RVA = "0x20ADE6C", Offset = "0x20ADE6C", VA = "0x20ADE6C")]
		[Token(Token = "0x600300C")]
		public void method_25()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			IEnumerator routine = this.method_29();
			base.StartCoroutine(routine);
		}

		// Token: 0x0600300D RID: 12301 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20ADFA0", Offset = "0x20ADFA0", VA = "0x20ADFA0")]
		[Token(Token = "0x600300D")]
		public void method_26()
		{
		}

		// Token: 0x0600300E RID: 12302 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20ADFA4", Offset = "0x20ADFA4", VA = "0x20ADFA4")]
		[Token(Token = "0x600300E")]
		private IEnumerator method_27()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x0600300F RID: 12303 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AE01C", Offset = "0x20AE01C", VA = "0x20AE01C")]
		[Token(Token = "0x600300F")]
		private IEnumerator method_28()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003010 RID: 12304 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AD7FC", Offset = "0x20AD7FC", VA = "0x20AD7FC")]
		[Token(Token = "0x6003010")]
		private IEnumerator method_29()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003011 RID: 12305 RVA: 0x0005FEB0 File Offset: 0x0005E0B0
		[Address(RVA = "0x20AE094", Offset = "0x20AE094", VA = "0x20AE094")]
		[Token(Token = "0x6003011")]
		public void method_30()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			IEnumerator routine = this.method_44();
			base.StartCoroutine(routine);
		}

		// Token: 0x06003012 RID: 12306 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AE240", Offset = "0x20AE240", VA = "0x20AE240")]
		[Token(Token = "0x6003012")]
		public void method_31()
		{
		}

		// Token: 0x06003013 RID: 12307 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AE244", Offset = "0x20AE244", VA = "0x20AE244")]
		[Token(Token = "0x6003013")]
		public void method_32()
		{
		}

		// Token: 0x06003014 RID: 12308 RVA: 0x0005FEF0 File Offset: 0x0005E0F0
		[Address(RVA = "0x20AE248", Offset = "0x20AE248", VA = "0x20AE248")]
		[Token(Token = "0x6003014")]
		public void method_33()
		{
			if (this.bool_0)
			{
				return;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			this.method_2();
		}

		// Token: 0x06003015 RID: 12309 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AE37C", Offset = "0x20AE37C", VA = "0x20AE37C")]
		[Token(Token = "0x6003015")]
		public void method_34()
		{
		}

		// Token: 0x06003016 RID: 12310 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AE380", Offset = "0x20AE380", VA = "0x20AE380")]
		[Token(Token = "0x6003016")]
		public void method_35()
		{
		}

		// Token: 0x06003017 RID: 12311 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AE384", Offset = "0x20AE384", VA = "0x20AE384")]
		[Token(Token = "0x6003017")]
		public void method_36()
		{
		}

		// Token: 0x06003018 RID: 12312 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AE388", Offset = "0x20AE388", VA = "0x20AE388")]
		[Token(Token = "0x6003018")]
		public void method_37()
		{
		}

		// Token: 0x06003019 RID: 12313 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AE38C", Offset = "0x20AE38C", VA = "0x20AE38C")]
		[Token(Token = "0x6003019")]
		public void method_38()
		{
		}

		// Token: 0x0600301A RID: 12314 RVA: 0x0005FF30 File Offset: 0x0005E130
		[Address(RVA = "0x20AE390", Offset = "0x20AE390", VA = "0x20AE390")]
		[Token(Token = "0x600301A")]
		public void method_39()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			IEnumerator routine = this.method_47();
			base.StartCoroutine(routine);
		}

		// Token: 0x0600301B RID: 12315 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AE53C", Offset = "0x20AE53C", VA = "0x20AE53C")]
		[Token(Token = "0x600301B")]
		public void method_40()
		{
		}

		// Token: 0x0600301C RID: 12316 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AE540", Offset = "0x20AE540", VA = "0x20AE540")]
		[Token(Token = "0x600301C")]
		public void method_41()
		{
		}

		// Token: 0x0600301D RID: 12317 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AE544", Offset = "0x20AE544", VA = "0x20AE544")]
		[Token(Token = "0x600301D")]
		private IEnumerator method_42()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x0600301E RID: 12318 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AE5BC", Offset = "0x20AE5BC", VA = "0x20AE5BC")]
		[Token(Token = "0x600301E")]
		private IEnumerator method_43()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x0600301F RID: 12319 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AE1C8", Offset = "0x20AE1C8", VA = "0x20AE1C8")]
		[Token(Token = "0x600301F")]
		private IEnumerator method_44()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003020 RID: 12320 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AE634", Offset = "0x20AE634", VA = "0x20AE634")]
		[Token(Token = "0x6003020")]
		private IEnumerator method_45()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003021 RID: 12321 RVA: 0x0005FF70 File Offset: 0x0005E170
		[Address(RVA = "0x20AE6AC", Offset = "0x20AE6AC", VA = "0x20AE6AC")]
		[Token(Token = "0x6003021")]
		public void method_46()
		{
			if (this.bool_0)
			{
				return;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			IEnumerator routine = this.method_27();
			base.StartCoroutine(routine);
		}

		// Token: 0x06003022 RID: 12322 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AE4C4", Offset = "0x20AE4C4", VA = "0x20AE4C4")]
		[Token(Token = "0x6003022")]
		private IEnumerator method_47()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003023 RID: 12323 RVA: 0x0005FFB8 File Offset: 0x0005E1B8
		[Address(RVA = "0x20AE7E0", Offset = "0x20AE7E0", VA = "0x20AE7E0")]
		[Token(Token = "0x6003023")]
		public void method_48()
		{
			if (this.bool_0)
			{
				return;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			IEnumerator routine = this.method_44();
			base.StartCoroutine(routine);
		}

		// Token: 0x06003024 RID: 12324 RVA: 0x0005FD28 File Offset: 0x0005DF28
		[Address(RVA = "0x20AE914", Offset = "0x20AE914", VA = "0x20AE914")]
		[Token(Token = "0x6003024")]
		private IEnumerator method_49()
		{
			DemoSlidingDoor.Class40 @class = new DemoSlidingDoor.Class40((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003025 RID: 12325 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20AE98C", Offset = "0x20AE98C", VA = "0x20AE98C")]
		[Token(Token = "0x6003025")]
		public void method_50()
		{
		}

		// Token: 0x06003026 RID: 12326 RVA: 0x00060000 File Offset: 0x0005E200
		[Address(RVA = "0x20AE990", Offset = "0x20AE990", VA = "0x20AE990")]
		[Token(Token = "0x6003026")]
		public void method_51()
		{
			if (this.bool_0)
			{
				return;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
			SFXPlayer.أ\u089Dࢮ\u0745;
			Vector3 position = base.transform.position;
			IEnumerator routine = this.method_2();
			base.StartCoroutine(routine);
		}

		// Token: 0x040005EA RID: 1514
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40005EA")]
		public Rigidbody rigidbody_0;

		// Token: 0x040005EB RID: 1515
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40005EB")]
		public Rigidbody rigidbody_1;

		// Token: 0x040005EC RID: 1516
		[Token(Token = "0x40005EC")]
		[FieldOffset(Offset = "0x28")]
		public Transform transform_0;

		// Token: 0x040005ED RID: 1517
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40005ED")]
		public float float_0;

		// Token: 0x040005EE RID: 1518
		[FieldOffset(Offset = "0x34")]
		[Token(Token = "0x40005EE")]
		public float float_1;

		// Token: 0x040005EF RID: 1519
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40005EF")]
		public float float_2;

		// Token: 0x040005F0 RID: 1520
		[Token(Token = "0x40005F0")]
		[FieldOffset(Offset = "0x3C")]
		public float float_3;

		// Token: 0x040005F1 RID: 1521
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40005F1")]
		public AudioClip audioClip_0;

		// Token: 0x040005F2 RID: 1522
		[Token(Token = "0x40005F2")]
		[FieldOffset(Offset = "0x48")]
		private bool bool_0;
	}
}
