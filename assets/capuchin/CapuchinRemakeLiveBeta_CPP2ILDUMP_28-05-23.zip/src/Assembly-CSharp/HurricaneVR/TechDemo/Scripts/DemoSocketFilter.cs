﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core.Sockets;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000132 RID: 306
	[Token(Token = "0x2000132")]
	public class DemoSocketFilter : HVREnumFlagsSocketFilter<GEnum14>
	{
		// Token: 0x0600302D RID: 12333 RVA: 0x000030DF File Offset: 0x000012DF
		[Address(RVA = "0x20AEAC4", Offset = "0x20AEAC4", VA = "0x20AEAC4")]
		[Token(Token = "0x600302D")]
		public DemoSocketFilter()
		{
		}
	}
}
