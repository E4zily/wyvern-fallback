﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core;
using HurricaneVR.Framework.Core.Grabbers;
using HurricaneVR.Framework.Core.HandPoser;
using UnityEngine;
using UnityEngine.Events;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000112 RID: 274
	[Token(Token = "0x2000112")]
	public class DemoPoseSqueeze : MonoBehaviour
	{
		// Token: 0x06002924 RID: 10532 RVA: 0x00059B00 File Offset: 0x00057D00
		[Address(RVA = "0x1B2C624", Offset = "0x1B2C624", VA = "0x1B2C624")]
		[Token(Token = "0x6002924")]
		private void method_0()
		{
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002925 RID: 10533 RVA: 0x00059B1C File Offset: 0x00057D1C
		[Token(Token = "0x6002925")]
		[Address(RVA = "0x1B2C728", Offset = "0x1B2C728", VA = "0x1B2C728")]
		private void method_1(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
		}

		// Token: 0x06002926 RID: 10534 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B2C7D4", Offset = "0x1B2C7D4", VA = "0x1B2C7D4")]
		[Token(Token = "0x6002926")]
		private void method_2()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002927 RID: 10535 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B2C8D8", Offset = "0x1B2C8D8", VA = "0x1B2C8D8")]
		[Token(Token = "0x6002927")]
		private void method_3()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002928 RID: 10536 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B2CA64", Offset = "0x1B2CA64", VA = "0x1B2CA64")]
		[Token(Token = "0x6002928")]
		private void method_4()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002929 RID: 10537 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B2CB68", Offset = "0x1B2CB68", VA = "0x1B2CB68")]
		[Token(Token = "0x6002929")]
		private void method_5()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600292A RID: 10538 RVA: 0x00059B58 File Offset: 0x00057D58
		[Address(RVA = "0x1B2CC6C", Offset = "0x1B2CC6C", VA = "0x1B2CC6C")]
		[Token(Token = "0x600292A")]
		private void method_6()
		{
		}

		// Token: 0x0600292B RID: 10539 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x600292B")]
		[Address(RVA = "0x1B2CD70", Offset = "0x1B2CD70", VA = "0x1B2CD70")]
		private void method_7()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600292C RID: 10540 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x600292C")]
		[Address(RVA = "0x1B2CE74", Offset = "0x1B2CE74", VA = "0x1B2CE74")]
		private void method_8()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600292D RID: 10541 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x600292D")]
		[Address(RVA = "0x1B2CF78", Offset = "0x1B2CF78", VA = "0x1B2CF78")]
		private void method_9()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600292E RID: 10542 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B2D104", Offset = "0x1B2D104", VA = "0x1B2D104")]
		[Token(Token = "0x600292E")]
		private void method_10()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600292F RID: 10543 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B2D290", Offset = "0x1B2D290", VA = "0x1B2D290")]
		[Token(Token = "0x600292F")]
		private void method_11()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002930 RID: 10544 RVA: 0x00059B68 File Offset: 0x00057D68
		[Address(RVA = "0x1B2D394", Offset = "0x1B2D394", VA = "0x1B2D394")]
		[Token(Token = "0x6002930")]
		private void method_12(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "button");
		}

		// Token: 0x06002931 RID: 10545 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B2D440", Offset = "0x1B2D440", VA = "0x1B2D440")]
		[Token(Token = "0x6002931")]
		private void method_13()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002932 RID: 10546 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002932")]
		[Address(RVA = "0x1B2D544", Offset = "0x1B2D544", VA = "0x1B2D544")]
		private void method_14()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002933 RID: 10547 RVA: 0x00059B88 File Offset: 0x00057D88
		[Address(RVA = "0x1B2D6D0", Offset = "0x1B2D6D0", VA = "0x1B2D6D0")]
		[Token(Token = "0x6002933")]
		private void method_15(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "PLAYER IS BANNED");
		}

		// Token: 0x06002934 RID: 10548 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x6002934")]
		[Address(RVA = "0x1B2D77C", Offset = "0x1B2D77C", VA = "0x1B2D77C")]
		private void method_16()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002935 RID: 10549 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x6002935")]
		[Address(RVA = "0x1B2D880", Offset = "0x1B2D880", VA = "0x1B2D880")]
		private void method_17()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002936 RID: 10550 RVA: 0x00059BA8 File Offset: 0x00057DA8
		[Address(RVA = "0x1B2D984", Offset = "0x1B2D984", VA = "0x1B2D984")]
		[Token(Token = "0x6002936")]
		private void method_18(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "openvr");
		}

		// Token: 0x06002937 RID: 10551 RVA: 0x00059BC8 File Offset: 0x00057DC8
		[Address(RVA = "0x1B2DA30", Offset = "0x1B2DA30", VA = "0x1B2DA30")]
		[Token(Token = "0x6002937")]
		private void method_19(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, ". Please update you game to the latest version");
		}

		// Token: 0x06002938 RID: 10552 RVA: 0x00059BE8 File Offset: 0x00057DE8
		[Token(Token = "0x6002938")]
		[Address(RVA = "0x1B2DADC", Offset = "0x1B2DADC", VA = "0x1B2DADC")]
		private void method_20(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "token");
		}

		// Token: 0x06002939 RID: 10553 RVA: 0x00059C08 File Offset: 0x00057E08
		[Address(RVA = "0x1B2DB88", Offset = "0x1B2DB88", VA = "0x1B2DB88")]
		[Token(Token = "0x6002939")]
		private void method_21(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "BLUTARG");
		}

		// Token: 0x0600293A RID: 10554 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x600293A")]
		[Address(RVA = "0x1B2DC34", Offset = "0x1B2DC34", VA = "0x1B2DC34")]
		private void method_22()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600293B RID: 10555 RVA: 0x00059C28 File Offset: 0x00057E28
		[Token(Token = "0x600293B")]
		[Address(RVA = "0x1B2DDC0", Offset = "0x1B2DDC0", VA = "0x1B2DDC0")]
		private void method_23(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "jump char false");
		}

		// Token: 0x0600293C RID: 10556 RVA: 0x00059C48 File Offset: 0x00057E48
		[Token(Token = "0x600293C")]
		[Address(RVA = "0x1B2DE6C", Offset = "0x1B2DE6C", VA = "0x1B2DE6C")]
		private void method_24(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Room Name: ");
		}

		// Token: 0x0600293D RID: 10557 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x600293D")]
		[Address(RVA = "0x1B2DF18", Offset = "0x1B2DF18", VA = "0x1B2DF18")]
		private void method_25()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600293E RID: 10558 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B2E01C", Offset = "0x1B2E01C", VA = "0x1B2E01C")]
		[Token(Token = "0x600293E")]
		private void method_26()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600293F RID: 10559 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x600293F")]
		[Address(RVA = "0x1B2E1A8", Offset = "0x1B2E1A8", VA = "0x1B2E1A8")]
		private void method_27()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002940 RID: 10560 RVA: 0x00059C68 File Offset: 0x00057E68
		[Token(Token = "0x6002940")]
		[Address(RVA = "0x1B2E2AC", Offset = "0x1B2E2AC", VA = "0x1B2E2AC")]
		private void method_28(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "hand 1");
		}

		// Token: 0x06002941 RID: 10561 RVA: 0x00059C88 File Offset: 0x00057E88
		[Token(Token = "0x6002941")]
		[Address(RVA = "0x1B2E358", Offset = "0x1B2E358", VA = "0x1B2E358")]
		private void method_29(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "FingerTip");
		}

		// Token: 0x06002942 RID: 10562 RVA: 0x00059CA8 File Offset: 0x00057EA8
		[Token(Token = "0x6002942")]
		[Address(RVA = "0x1B2E404", Offset = "0x1B2E404", VA = "0x1B2E404")]
		private void method_30(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
		}

		// Token: 0x06002943 RID: 10563 RVA: 0x00059CC8 File Offset: 0x00057EC8
		[Token(Token = "0x6002943")]
		[Address(RVA = "0x1B2E4B0", Offset = "0x1B2E4B0", VA = "0x1B2E4B0")]
		private void method_31(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "TurnAmount");
		}

		// Token: 0x06002944 RID: 10564 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B2E55C", Offset = "0x1B2E55C", VA = "0x1B2E55C")]
		[Token(Token = "0x6002944")]
		private void method_32()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002945 RID: 10565 RVA: 0x00059CE8 File Offset: 0x00057EE8
		[Token(Token = "0x6002945")]
		[Address(RVA = "0x1B2E6E8", Offset = "0x1B2E6E8", VA = "0x1B2E6E8")]
		private void method_33(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Try Connect To Server...");
		}

		// Token: 0x06002946 RID: 10566 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x6002946")]
		[Address(RVA = "0x1B2E794", Offset = "0x1B2E794", VA = "0x1B2E794")]
		private void method_34()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002947 RID: 10567 RVA: 0x00059D08 File Offset: 0x00057F08
		[Token(Token = "0x6002947")]
		[Address(RVA = "0x1B2E898", Offset = "0x1B2E898", VA = "0x1B2E898")]
		private void method_35(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "NoseAttachPoint");
		}

		// Token: 0x06002948 RID: 10568 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B2E944", Offset = "0x1B2E944", VA = "0x1B2E944")]
		[Token(Token = "0x6002948")]
		private void method_36()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002949 RID: 10569 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x6002949")]
		[Address(RVA = "0x1B2EA48", Offset = "0x1B2EA48", VA = "0x1B2EA48")]
		private void method_37()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600294A RID: 10570 RVA: 0x00059D28 File Offset: 0x00057F28
		[Token(Token = "0x600294A")]
		[Address(RVA = "0x1B2EB4C", Offset = "0x1B2EB4C", VA = "0x1B2EB4C")]
		private void method_38(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Player");
		}

		// Token: 0x0600294B RID: 10571 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B2EBF8", Offset = "0x1B2EBF8", VA = "0x1B2EBF8")]
		[Token(Token = "0x600294B")]
		private void method_39()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600294C RID: 10572 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B2ECFC", Offset = "0x1B2ECFC", VA = "0x1B2ECFC")]
		[Token(Token = "0x600294C")]
		private void method_40()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600294D RID: 10573 RVA: 0x00059D48 File Offset: 0x00057F48
		[Token(Token = "0x600294D")]
		[Address(RVA = "0x1B2EE00", Offset = "0x1B2EE00", VA = "0x1B2EE00")]
		private void method_41(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "typesOfTalk");
		}

		// Token: 0x0600294E RID: 10574 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x600294E")]
		[Address(RVA = "0x1B2EEAC", Offset = "0x1B2EEAC", VA = "0x1B2EEAC")]
		private void method_42()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600294F RID: 10575 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x600294F")]
		[Address(RVA = "0x1B2EFB0", Offset = "0x1B2EFB0", VA = "0x1B2EFB0")]
		private void method_43()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002950 RID: 10576 RVA: 0x00059D68 File Offset: 0x00057F68
		[Token(Token = "0x6002950")]
		[Address(RVA = "0x1B2F148", Offset = "0x1B2F148", VA = "0x1B2F148")]
		private void method_44(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "An error has occured while buying bananas, please restart your game and try again");
		}

		// Token: 0x06002951 RID: 10577 RVA: 0x00059D88 File Offset: 0x00057F88
		[Token(Token = "0x6002951")]
		[Address(RVA = "0x1B2F1F4", Offset = "0x1B2F1F4", VA = "0x1B2F1F4")]
		private void method_45(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "DisableCosmetic");
		}

		// Token: 0x06002952 RID: 10578 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002952")]
		[Address(RVA = "0x1B2F2A0", Offset = "0x1B2F2A0", VA = "0x1B2F2A0")]
		private void method_46()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002953 RID: 10579 RVA: 0x00059DA8 File Offset: 0x00057FA8
		[Address(RVA = "0x1B2F42C", Offset = "0x1B2F42C", VA = "0x1B2F42C")]
		[Token(Token = "0x6002953")]
		private void method_47(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "_Tint");
		}

		// Token: 0x06002954 RID: 10580 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x6002954")]
		[Address(RVA = "0x1B2F4D8", Offset = "0x1B2F4D8", VA = "0x1B2F4D8")]
		private void method_48()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002955 RID: 10581 RVA: 0x00059DC8 File Offset: 0x00057FC8
		[Address(RVA = "0x1B2F5DC", Offset = "0x1B2F5DC", VA = "0x1B2F5DC")]
		[Token(Token = "0x6002955")]
		private void method_49()
		{
		}

		// Token: 0x06002956 RID: 10582 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B2F768", Offset = "0x1B2F768", VA = "0x1B2F768")]
		[Token(Token = "0x6002956")]
		private void method_50()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002957 RID: 10583 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B2F900", Offset = "0x1B2F900", VA = "0x1B2F900")]
		[Token(Token = "0x6002957")]
		private void method_51()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002958 RID: 10584 RVA: 0x00059DD8 File Offset: 0x00057FD8
		[Address(RVA = "0x1B2FA04", Offset = "0x1B2FA04", VA = "0x1B2FA04")]
		[Token(Token = "0x6002958")]
		private void method_52(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "False");
		}

		// Token: 0x06002959 RID: 10585 RVA: 0x00059D48 File Offset: 0x00057F48
		[Address(RVA = "0x1B2FAB0", Offset = "0x1B2FAB0", VA = "0x1B2FAB0")]
		[Token(Token = "0x6002959")]
		private void method_53(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "typesOfTalk");
		}

		// Token: 0x0600295A RID: 10586 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B2FB5C", Offset = "0x1B2FB5C", VA = "0x1B2FB5C")]
		[Token(Token = "0x600295A")]
		private void method_54()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600295B RID: 10587 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B2FCE8", Offset = "0x1B2FCE8", VA = "0x1B2FCE8")]
		[Token(Token = "0x600295B")]
		private void method_55()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600295C RID: 10588 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x600295C")]
		[Address(RVA = "0x1B2FDEC", Offset = "0x1B2FDEC", VA = "0x1B2FDEC")]
		private void method_56()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600295D RID: 10589 RVA: 0x00059DC8 File Offset: 0x00057FC8
		[Address(RVA = "0x1B2FEF0", Offset = "0x1B2FEF0", VA = "0x1B2FEF0")]
		[Token(Token = "0x600295D")]
		private void method_57()
		{
		}

		// Token: 0x0600295E RID: 10590 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B3007C", Offset = "0x1B3007C", VA = "0x1B3007C")]
		[Token(Token = "0x600295E")]
		private void method_58()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600295F RID: 10591 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B30208", Offset = "0x1B30208", VA = "0x1B30208")]
		[Token(Token = "0x600295F")]
		private void method_59()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002960 RID: 10592 RVA: 0x00059DF8 File Offset: 0x00057FF8
		[Address(RVA = "0x1B3030C", Offset = "0x1B3030C", VA = "0x1B3030C")]
		[Token(Token = "0x6002960")]
		private void method_60(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
		}

		// Token: 0x06002961 RID: 10593 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B303B8", Offset = "0x1B303B8", VA = "0x1B303B8")]
		[Token(Token = "0x6002961")]
		private void method_61()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002962 RID: 10594 RVA: 0x00059E08 File Offset: 0x00058008
		[Token(Token = "0x6002962")]
		[Address(RVA = "0x1B30544", Offset = "0x1B30544", VA = "0x1B30544")]
		private void method_62(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "true");
		}

		// Token: 0x06002963 RID: 10595 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B305F0", Offset = "0x1B305F0", VA = "0x1B305F0")]
		[Token(Token = "0x6002963")]
		private void method_63()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002964 RID: 10596 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B3077C", Offset = "0x1B3077C", VA = "0x1B3077C")]
		[Token(Token = "0x6002964")]
		private void method_64()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002965 RID: 10597 RVA: 0x00059E28 File Offset: 0x00058028
		[Address(RVA = "0x1B30880", Offset = "0x1B30880", VA = "0x1B30880")]
		[Token(Token = "0x6002965")]
		private void method_65(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "liftoff failed!");
		}

		// Token: 0x06002966 RID: 10598 RVA: 0x00059DF8 File Offset: 0x00057FF8
		[Address(RVA = "0x1B3092C", Offset = "0x1B3092C", VA = "0x1B3092C")]
		[Token(Token = "0x6002966")]
		private void method_66(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
		}

		// Token: 0x06002967 RID: 10599 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B309D8", Offset = "0x1B309D8", VA = "0x1B309D8")]
		[Token(Token = "0x6002967")]
		private void method_67()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002968 RID: 10600 RVA: 0x00059E48 File Offset: 0x00058048
		[Token(Token = "0x6002968")]
		[Address(RVA = "0x1B30B64", Offset = "0x1B30B64", VA = "0x1B30B64")]
		private void method_68(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "DISABLE");
		}

		// Token: 0x06002969 RID: 10601 RVA: 0x00059E68 File Offset: 0x00058068
		[Address(RVA = "0x1B30C10", Offset = "0x1B30C10", VA = "0x1B30C10")]
		[Token(Token = "0x6002969")]
		private void method_69(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "StartGamemode");
		}

		// Token: 0x0600296A RID: 10602 RVA: 0x00059B00 File Offset: 0x00057D00
		[Address(RVA = "0x1B30CBC", Offset = "0x1B30CBC", VA = "0x1B30CBC")]
		[Token(Token = "0x600296A")]
		private void method_70()
		{
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600296B RID: 10603 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B30DC0", Offset = "0x1B30DC0", VA = "0x1B30DC0")]
		[Token(Token = "0x600296B")]
		private void method_71()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600296C RID: 10604 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B30EC4", Offset = "0x1B30EC4", VA = "0x1B30EC4")]
		[Token(Token = "0x600296C")]
		private void method_72()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600296D RID: 10605 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x1B31050", Offset = "0x1B31050", VA = "0x1B31050")]
		[Token(Token = "0x600296D")]
		public DemoPoseSqueeze()
		{
		}

		// Token: 0x0600296E RID: 10606 RVA: 0x00059E88 File Offset: 0x00058088
		[Address(RVA = "0x1B31058", Offset = "0x1B31058", VA = "0x1B31058")]
		[Token(Token = "0x600296E")]
		private void method_73(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Camera movement detected, calibrating height.");
		}

		// Token: 0x0600296F RID: 10607 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x600296F")]
		[Address(RVA = "0x1B31104", Offset = "0x1B31104", VA = "0x1B31104")]
		private void method_74()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002970 RID: 10608 RVA: 0x00059D48 File Offset: 0x00057F48
		[Address(RVA = "0x1B31290", Offset = "0x1B31290", VA = "0x1B31290")]
		[Token(Token = "0x6002970")]
		private void method_75(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "typesOfTalk");
		}

		// Token: 0x06002971 RID: 10609 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B3133C", Offset = "0x1B3133C", VA = "0x1B3133C")]
		[Token(Token = "0x6002971")]
		private void method_76()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002972 RID: 10610 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B31440", Offset = "0x1B31440", VA = "0x1B31440")]
		[Token(Token = "0x6002972")]
		private void method_77()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002973 RID: 10611 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B315CC", Offset = "0x1B315CC", VA = "0x1B315CC")]
		[Token(Token = "0x6002973")]
		private void method_78()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002974 RID: 10612 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B316D0", Offset = "0x1B316D0", VA = "0x1B316D0")]
		[Token(Token = "0x6002974")]
		private void method_79()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002975 RID: 10613 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B3185C", Offset = "0x1B3185C", VA = "0x1B3185C")]
		[Token(Token = "0x6002975")]
		private void method_80()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002976 RID: 10614 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B31960", Offset = "0x1B31960", VA = "0x1B31960")]
		[Token(Token = "0x6002976")]
		private void method_81()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002977 RID: 10615 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B31A64", Offset = "0x1B31A64", VA = "0x1B31A64")]
		[Token(Token = "0x6002977")]
		private void method_82()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002978 RID: 10616 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B31B68", Offset = "0x1B31B68", VA = "0x1B31B68")]
		[Token(Token = "0x6002978")]
		private void method_83()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002979 RID: 10617 RVA: 0x00059EA8 File Offset: 0x000580A8
		[Address(RVA = "0x1B31C6C", Offset = "0x1B31C6C", VA = "0x1B31C6C")]
		[Token(Token = "0x6002979")]
		private void method_84(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "retract broken");
		}

		// Token: 0x0600297A RID: 10618 RVA: 0x00059EC8 File Offset: 0x000580C8
		[Address(RVA = "0x1B31D18", Offset = "0x1B31D18", VA = "0x1B31D18")]
		[Token(Token = "0x600297A")]
		private void method_85(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Cannot access index {0}. Buffer size is {1}");
		}

		// Token: 0x0600297B RID: 10619 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x600297B")]
		[Address(RVA = "0x1B31DC4", Offset = "0x1B31DC4", VA = "0x1B31DC4")]
		private void method_86()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600297C RID: 10620 RVA: 0x00059EE8 File Offset: 0x000580E8
		[Address(RVA = "0x1B31F50", Offset = "0x1B31F50", VA = "0x1B31F50")]
		[Token(Token = "0x600297C")]
		private void method_87(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Error");
		}

		// Token: 0x0600297D RID: 10621 RVA: 0x00059F08 File Offset: 0x00058108
		[Address(RVA = "0x1B31FFC", Offset = "0x1B31FFC", VA = "0x1B31FFC")]
		[Token(Token = "0x600297D")]
		private void method_88(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "BN");
		}

		// Token: 0x0600297E RID: 10622 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B320A8", Offset = "0x1B320A8", VA = "0x1B320A8")]
		[Token(Token = "0x600297E")]
		private void method_89()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600297F RID: 10623 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B32234", Offset = "0x1B32234", VA = "0x1B32234")]
		[Token(Token = "0x600297F")]
		private void method_90()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002980 RID: 10624 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B32338", Offset = "0x1B32338", VA = "0x1B32338")]
		[Token(Token = "0x6002980")]
		private void method_91()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002981 RID: 10625 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B324D0", Offset = "0x1B324D0", VA = "0x1B324D0")]
		[Token(Token = "0x6002981")]
		private void method_92()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002982 RID: 10626 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B325D4", Offset = "0x1B325D4", VA = "0x1B325D4")]
		[Token(Token = "0x6002982")]
		private void method_93()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002983 RID: 10627 RVA: 0x00059D28 File Offset: 0x00057F28
		[Address(RVA = "0x1B32760", Offset = "0x1B32760", VA = "0x1B32760")]
		[Token(Token = "0x6002983")]
		private void method_94(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Player");
		}

		// Token: 0x06002984 RID: 10628 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B3280C", Offset = "0x1B3280C", VA = "0x1B3280C")]
		[Token(Token = "0x6002984")]
		private void method_95()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002985 RID: 10629 RVA: 0x00059F28 File Offset: 0x00058128
		[Address(RVA = "0x1B32910", Offset = "0x1B32910", VA = "0x1B32910")]
		[Token(Token = "0x6002985")]
		private void method_96(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Add/Remove Hat");
		}

		// Token: 0x06002986 RID: 10630 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B329BC", Offset = "0x1B329BC", VA = "0x1B329BC")]
		[Token(Token = "0x6002986")]
		private void method_97()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002987 RID: 10631 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B32AC0", Offset = "0x1B32AC0", VA = "0x1B32AC0")]
		[Token(Token = "0x6002987")]
		private void method_98()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002988 RID: 10632 RVA: 0x00059F48 File Offset: 0x00058148
		[Address(RVA = "0x1B32BC4", Offset = "0x1B32BC4", VA = "0x1B32BC4")]
		[Token(Token = "0x6002988")]
		private void method_99(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "tp 2");
		}

		// Token: 0x06002989 RID: 10633 RVA: 0x00059F68 File Offset: 0x00058168
		[Address(RVA = "0x1B32C70", Offset = "0x1B32C70", VA = "0x1B32C70")]
		[Token(Token = "0x6002989")]
		private void method_100(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Head");
		}

		// Token: 0x0600298A RID: 10634 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B32D1C", Offset = "0x1B32D1C", VA = "0x1B32D1C")]
		[Token(Token = "0x600298A")]
		private void method_101()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600298B RID: 10635 RVA: 0x00059F88 File Offset: 0x00058188
		[Address(RVA = "0x1B32EA8", Offset = "0x1B32EA8", VA = "0x1B32EA8")]
		[Token(Token = "0x600298B")]
		private void method_102(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "PlayerHead");
		}

		// Token: 0x0600298C RID: 10636 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B32F54", Offset = "0x1B32F54", VA = "0x1B32F54")]
		[Token(Token = "0x600298C")]
		private void method_103()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600298D RID: 10637 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x600298D")]
		[Address(RVA = "0x1B330E0", Offset = "0x1B330E0", VA = "0x1B330E0")]
		private void method_104()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600298E RID: 10638 RVA: 0x00059FA8 File Offset: 0x000581A8
		[Token(Token = "0x600298E")]
		[Address(RVA = "0x1B331E4", Offset = "0x1B331E4", VA = "0x1B331E4")]
		private void method_105(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "token");
		}

		// Token: 0x0600298F RID: 10639 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x600298F")]
		[Address(RVA = "0x1B33290", Offset = "0x1B33290", VA = "0x1B33290")]
		private void method_106()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002990 RID: 10640 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B33428", Offset = "0x1B33428", VA = "0x1B33428")]
		[Token(Token = "0x6002990")]
		private void method_107()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002991 RID: 10641 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002991")]
		[Address(RVA = "0x1B335B4", Offset = "0x1B335B4", VA = "0x1B335B4")]
		private void method_108()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002992 RID: 10642 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B3374C", Offset = "0x1B3374C", VA = "0x1B3374C")]
		[Token(Token = "0x6002992")]
		private void method_109()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002993 RID: 10643 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002993")]
		[Address(RVA = "0x1B338E4", Offset = "0x1B338E4", VA = "0x1B338E4")]
		private void method_110()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002994 RID: 10644 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002994")]
		[Address(RVA = "0x1B33A70", Offset = "0x1B33A70", VA = "0x1B33A70")]
		private void method_111()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002995 RID: 10645 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B33C08", Offset = "0x1B33C08", VA = "0x1B33C08")]
		[Token(Token = "0x6002995")]
		private void method_112()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x06002996 RID: 10646 RVA: 0x00059FC8 File Offset: 0x000581C8
		[Token(Token = "0x6002996")]
		[Address(RVA = "0x1B33D0C", Offset = "0x1B33D0C", VA = "0x1B33D0C")]
		private void method_113(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "A new Player joined a Room.");
		}

		// Token: 0x06002997 RID: 10647 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B33DB8", Offset = "0x1B33DB8", VA = "0x1B33DB8")]
		[Token(Token = "0x6002997")]
		private void method_114()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002998 RID: 10648 RVA: 0x00059DC8 File Offset: 0x00057FC8
		[Token(Token = "0x6002998")]
		[Address(RVA = "0x1B33F50", Offset = "0x1B33F50", VA = "0x1B33F50")]
		private void method_115()
		{
		}

		// Token: 0x06002999 RID: 10649 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B340DC", Offset = "0x1B340DC", VA = "0x1B340DC")]
		[Token(Token = "0x6002999")]
		private void method_116()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600299A RID: 10650 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B34268", Offset = "0x1B34268", VA = "0x1B34268")]
		[Token(Token = "0x600299A")]
		private void method_117()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600299B RID: 10651 RVA: 0x00059FE8 File Offset: 0x000581E8
		[Token(Token = "0x600299B")]
		[Address(RVA = "0x1B3436C", Offset = "0x1B3436C", VA = "0x1B3436C")]
		private void method_118(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Cannot take elements from an empty buffer.");
		}

		// Token: 0x0600299C RID: 10652 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Token(Token = "0x600299C")]
		[Address(RVA = "0x1B34418", Offset = "0x1B34418", VA = "0x1B34418")]
		private void method_119()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600299D RID: 10653 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B3451C", Offset = "0x1B3451C", VA = "0x1B3451C")]
		[Token(Token = "0x600299D")]
		private void Start()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x0600299E RID: 10654 RVA: 0x00059DC8 File Offset: 0x00057FC8
		[Token(Token = "0x600299E")]
		[Address(RVA = "0x1B34620", Offset = "0x1B34620", VA = "0x1B34620")]
		private void method_120()
		{
		}

		// Token: 0x0600299F RID: 10655 RVA: 0x0005A008 File Offset: 0x00058208
		[Token(Token = "0x600299F")]
		[Address(RVA = "0x1B347AC", Offset = "0x1B347AC", VA = "0x1B347AC")]
		private void method_121(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Squeeze");
		}

		// Token: 0x060029A0 RID: 10656 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B34858", Offset = "0x1B34858", VA = "0x1B34858")]
		[Token(Token = "0x60029A0")]
		private void method_122()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x060029A1 RID: 10657 RVA: 0x0005A028 File Offset: 0x00058228
		[Address(RVA = "0x1B3495C", Offset = "0x1B3495C", VA = "0x1B3495C")]
		[Token(Token = "0x60029A1")]
		private void method_123(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "HorrorAgreement");
		}

		// Token: 0x060029A2 RID: 10658 RVA: 0x0005A048 File Offset: 0x00058248
		[Token(Token = "0x60029A2")]
		[Address(RVA = "0x1B34A08", Offset = "0x1B34A08", VA = "0x1B34A08")]
		private void method_124(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "CapuchinStore");
		}

		// Token: 0x060029A3 RID: 10659 RVA: 0x0005A068 File Offset: 0x00058268
		[Address(RVA = "0x1B34AB4", Offset = "0x1B34AB4", VA = "0x1B34AB4")]
		[Token(Token = "0x60029A3")]
		private void method_125(HVRHandGrabber hvrhandGrabber_0, HVRGrabbable hvrgrabbable_1)
		{
			Ԫե\u081Cդ u0822_u060Cܠ_u061C = hvrhandGrabber_0.\u0822\u060Cܠ\u061C;
			HVRAnimationParameters.ࡐݜܮ\u0607(u0822_u060Cܠ_u061C, "Failed To Join Public Room Successfully. The error is: ");
		}

		// Token: 0x060029A4 RID: 10660 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B34B60", Offset = "0x1B34B60", VA = "0x1B34B60")]
		[Token(Token = "0x60029A4")]
		private void Update()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029A5 RID: 10661 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B34CEC", Offset = "0x1B34CEC", VA = "0x1B34CEC")]
		[Token(Token = "0x60029A5")]
		private void method_126()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x060029A6 RID: 10662 RVA: 0x00059B2C File Offset: 0x00057D2C
		[Address(RVA = "0x1B34DF0", Offset = "0x1B34DF0", VA = "0x1B34DF0")]
		[Token(Token = "0x60029A6")]
		private void method_127()
		{
			UnityAction<HVRHandGrabber, HVRGrabbable> unityAction;
			this.hvrgrabbable_0.ڻݦࢮ\u0837.AddListener(unityAction);
			Vector3 localScale = this.transform_0.localScale;
		}

		// Token: 0x04000565 RID: 1381
		[Token(Token = "0x4000565")]
		[FieldOffset(Offset = "0x18")]
		public Transform transform_0;

		// Token: 0x04000566 RID: 1382
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000566")]
		public Vector3 vector3_0;

		// Token: 0x04000567 RID: 1383
		[Token(Token = "0x4000567")]
		[FieldOffset(Offset = "0x30")]
		public HVRGrabbable hvrgrabbable_0;

		// Token: 0x04000568 RID: 1384
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000568")]
		private Vector3 vector3_1;
	}
}
