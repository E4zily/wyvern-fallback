﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Components;
using TMPro;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000124 RID: 292
	[Token(Token = "0x2000124")]
	public class DemoKeypadButton : HVRPhysicsButton
	{
		// Token: 0x06002D61 RID: 11617 RVA: 0x0000304F File Offset: 0x0000124F
		[Address(RVA = "0x1B13898", Offset = "0x1B13898", VA = "0x1B13898")]
		[Token(Token = "0x6002D61")]
		public DemoKeypadButton()
		{
		}

		// Token: 0x06002D62 RID: 11618 RVA: 0x0005D75C File Offset: 0x0005B95C
		[Address(RVA = "0x1B138A0", Offset = "0x1B138A0", VA = "0x1B138A0", Slot = "14")]
		[Token(Token = "0x6002D62")]
		protected override void Awake()
		{
			Rigidbody componentInParent = base.transform.parent.GetComponentInParent<Rigidbody>();
			this.\u05B8ࡨ\u066AӪ = componentInParent;
			base.Awake();
		}

		// Token: 0x040005AA RID: 1450
		[FieldOffset(Offset = "0xA0")]
		[Token(Token = "0x40005AA")]
		public char char_0;

		// Token: 0x040005AB RID: 1451
		[Token(Token = "0x40005AB")]
		[FieldOffset(Offset = "0xA8")]
		public TextMeshPro textMeshPro_0;
	}
}
