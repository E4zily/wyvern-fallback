﻿using System;
using System.Collections;
using System.Collections.Generic;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000113 RID: 275
	[Token(Token = "0x2000113")]
	public class DemoBackpack : MonoBehaviour
	{
		// Token: 0x060029A7 RID: 10663 RVA: 0x0005A088 File Offset: 0x00058288
		[Address(RVA = "0x2A0E5D0", Offset = "0x2A0E5D0", VA = "0x2A0E5D0")]
		[Token(Token = "0x60029A7")]
		private void method_0()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_8();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029A8 RID: 10664 RVA: 0x0005A0D4 File Offset: 0x000582D4
		[Token(Token = "0x60029A8")]
		[Address(RVA = "0x2A0E82C", Offset = "0x2A0E82C", VA = "0x2A0E82C")]
		private void method_1()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_25;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 != null)
			{
			}
			IL_25:
			IEnumerator routine = this.method_4();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029A9 RID: 10665 RVA: 0x0005A118 File Offset: 0x00058318
		[Address(RVA = "0x2A0EA88", Offset = "0x2A0EA88", VA = "0x2A0EA88")]
		[Token(Token = "0x60029A9")]
		private void method_2()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_16();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029AA RID: 10666 RVA: 0x0005A164 File Offset: 0x00058364
		[Address(RVA = "0x2A0ECE4", Offset = "0x2A0ECE4", VA = "0x2A0ECE4")]
		[Token(Token = "0x60029AA")]
		public IEnumerator method_3()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029AB RID: 10667 RVA: 0x0005A164 File Offset: 0x00058364
		[Address(RVA = "0x2A0EA10", Offset = "0x2A0EA10", VA = "0x2A0EA10")]
		[Token(Token = "0x60029AB")]
		public IEnumerator method_4()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029AC RID: 10668 RVA: 0x0005A18C File Offset: 0x0005838C
		[Address(RVA = "0x2A0ED5C", Offset = "0x2A0ED5C", VA = "0x2A0ED5C")]
		[Token(Token = "0x60029AC")]
		private void method_5()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_51();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029AD RID: 10669 RVA: 0x0005A164 File Offset: 0x00058364
		[Address(RVA = "0x2A0EFB8", Offset = "0x2A0EFB8", VA = "0x2A0EFB8")]
		[Token(Token = "0x60029AD")]
		public IEnumerator method_6()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029AE RID: 10670 RVA: 0x0005A1D8 File Offset: 0x000583D8
		[Address(RVA = "0x2A0F030", Offset = "0x2A0F030", VA = "0x2A0F030")]
		[Token(Token = "0x60029AE")]
		private void method_7()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_4();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029AF RID: 10671 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029AF")]
		[Address(RVA = "0x2A0E7B4", Offset = "0x2A0E7B4", VA = "0x2A0E7B4")]
		public IEnumerator method_8()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029B0 RID: 10672 RVA: 0x0005A224 File Offset: 0x00058424
		[Address(RVA = "0x2A0F214", Offset = "0x2A0F214", VA = "0x2A0F214")]
		[Token(Token = "0x60029B0")]
		private void method_9()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_50();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029B1 RID: 10673 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x60029B1")]
		[Address(RVA = "0x2A0F470", Offset = "0x2A0F470", VA = "0x2A0F470")]
		public void method_10(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029B2 RID: 10674 RVA: 0x0005A088 File Offset: 0x00058288
		[Address(RVA = "0x2A0F59C", Offset = "0x2A0F59C", VA = "0x2A0F59C")]
		[Token(Token = "0x60029B2")]
		private void method_11()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_8();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029B3 RID: 10675 RVA: 0x0005A270 File Offset: 0x00058470
		[Address(RVA = "0x2A0F780", Offset = "0x2A0F780", VA = "0x2A0F780")]
		[Token(Token = "0x60029B3")]
		private void method_12()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_20();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029B4 RID: 10676 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029B4")]
		[Address(RVA = "0x2A0F9DC", Offset = "0x2A0F9DC", VA = "0x2A0F9DC")]
		public IEnumerator method_13()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029B5 RID: 10677 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x60029B5")]
		[Address(RVA = "0x2A0FA54", Offset = "0x2A0FA54", VA = "0x2A0FA54")]
		public void method_14(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029B6 RID: 10678 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029B6")]
		[Address(RVA = "0x2A0FB7C", Offset = "0x2A0FB7C", VA = "0x2A0FB7C")]
		public IEnumerator method_15()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029B7 RID: 10679 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029B7")]
		[Address(RVA = "0x2A0EC6C", Offset = "0x2A0EC6C", VA = "0x2A0EC6C")]
		public IEnumerator method_16()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029B8 RID: 10680 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2A0FBF4", Offset = "0x2A0FBF4", VA = "0x2A0FBF4")]
		[Token(Token = "0x60029B8")]
		public void method_17(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029B9 RID: 10681 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2A0FCFC", Offset = "0x2A0FCFC", VA = "0x2A0FCFC")]
		[Token(Token = "0x60029B9")]
		public void method_18(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029BA RID: 10682 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2A0FE28", Offset = "0x2A0FE28", VA = "0x2A0FE28")]
		[Token(Token = "0x60029BA")]
		public void method_19(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029BB RID: 10683 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029BB")]
		[Address(RVA = "0x2A0F964", Offset = "0x2A0F964", VA = "0x2A0F964")]
		public IEnumerator method_20()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029BC RID: 10684 RVA: 0x0005A164 File Offset: 0x00058364
		[Address(RVA = "0x2A0FF30", Offset = "0x2A0FF30", VA = "0x2A0FF30")]
		[Token(Token = "0x60029BC")]
		public IEnumerator method_21()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029BD RID: 10685 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029BD")]
		[Address(RVA = "0x2A0FFA8", Offset = "0x2A0FFA8", VA = "0x2A0FFA8")]
		public IEnumerator method_22()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029BE RID: 10686 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029BE")]
		[Address(RVA = "0x2A10020", Offset = "0x2A10020", VA = "0x2A10020")]
		public IEnumerator method_23()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029BF RID: 10687 RVA: 0x0005A2BC File Offset: 0x000584BC
		[Address(RVA = "0x2A10098", Offset = "0x2A10098", VA = "0x2A10098")]
		[Token(Token = "0x60029BF")]
		private void method_24()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_47();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029C0 RID: 10688 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2A102F4", Offset = "0x2A102F4", VA = "0x2A102F4")]
		[Token(Token = "0x60029C0")]
		public void method_25(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029C1 RID: 10689 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2A10448", Offset = "0x2A10448", VA = "0x2A10448")]
		[Token(Token = "0x60029C1")]
		public void method_26(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029C2 RID: 10690 RVA: 0x0005A308 File Offset: 0x00058508
		[Address(RVA = "0x2A10550", Offset = "0x2A10550", VA = "0x2A10550")]
		[Token(Token = "0x60029C2")]
		private void method_27()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_38();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029C3 RID: 10691 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2A107AC", Offset = "0x2A107AC", VA = "0x2A107AC")]
		[Token(Token = "0x60029C3")]
		private void method_28()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029C4 RID: 10692 RVA: 0x0005A354 File Offset: 0x00058554
		[Token(Token = "0x60029C4")]
		[Address(RVA = "0x2A10990", Offset = "0x2A10990", VA = "0x2A10990")]
		private void method_29()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_23();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029C5 RID: 10693 RVA: 0x0005A3A0 File Offset: 0x000585A0
		[Token(Token = "0x60029C5")]
		[Address(RVA = "0x2A10B74", Offset = "0x2A10B74", VA = "0x2A10B74")]
		private void method_30()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_24;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			Func<Collider, bool> <>9__1_;
			DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			IL_24:
			IEnumerator routine = this.method_15();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029C6 RID: 10694 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029C6")]
		[Address(RVA = "0x2A10D58", Offset = "0x2A10D58", VA = "0x2A10D58")]
		public IEnumerator method_31()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029C7 RID: 10695 RVA: 0x0005A3E4 File Offset: 0x000585E4
		[Address(RVA = "0x2A10DD0", Offset = "0x2A10DD0", VA = "0x2A10DD0")]
		[Token(Token = "0x60029C7")]
		private void method_32()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_31();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029C8 RID: 10696 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2A10FB4", Offset = "0x2A10FB4", VA = "0x2A10FB4")]
		[Token(Token = "0x60029C8")]
		public void method_33(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029C9 RID: 10697 RVA: 0x0005A430 File Offset: 0x00058630
		[Token(Token = "0x60029C9")]
		[Address(RVA = "0x2A110BC", Offset = "0x2A110BC", VA = "0x2A110BC")]
		private void method_34()
		{
			List<Collider> list = this.list_0;
			if (list == null || list._size == 0)
			{
				base.GetComponentsInChildren<Collider>();
				if (DemoBackpack.<>c.<>9__1_0 == null)
				{
					Func<Collider, bool> <>9__1_;
					DemoBackpack.<>c.<>9__1_0 = <>9__1_;
				}
			}
			IEnumerator routine = this.method_22();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029CA RID: 10698 RVA: 0x0005A474 File Offset: 0x00058674
		[Address(RVA = "0x2A112A0", Offset = "0x2A112A0", VA = "0x2A112A0")]
		[Token(Token = "0x60029CA")]
		public DemoBackpack()
		{
			List<Collider> list = new List();
			this.list_0 = list;
			base..ctor();
		}

		// Token: 0x060029CB RID: 10699 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029CB")]
		[Address(RVA = "0x2A11324", Offset = "0x2A11324", VA = "0x2A11324")]
		public IEnumerator method_35()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029CC RID: 10700 RVA: 0x0005A494 File Offset: 0x00058694
		[Token(Token = "0x60029CC")]
		[Address(RVA = "0x2A1139C", Offset = "0x2A1139C", VA = "0x2A1139C")]
		private void method_36()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_22();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029CD RID: 10701 RVA: 0x0005A4E0 File Offset: 0x000586E0
		[Token(Token = "0x60029CD")]
		[Address(RVA = "0x2A11580", Offset = "0x2A11580", VA = "0x2A11580")]
		public void method_37(HVRGrabbable hvrgrabbable_0)
		{
		}

		// Token: 0x060029CE RID: 10702 RVA: 0x0005A164 File Offset: 0x00058364
		[Address(RVA = "0x2A10734", Offset = "0x2A10734", VA = "0x2A10734")]
		[Token(Token = "0x60029CE")]
		public IEnumerator method_38()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029CF RID: 10703 RVA: 0x0005A164 File Offset: 0x00058364
		[Address(RVA = "0x2A11688", Offset = "0x2A11688", VA = "0x2A11688")]
		[Token(Token = "0x60029CF")]
		public IEnumerator method_39()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029D0 RID: 10704 RVA: 0x0005A4F0 File Offset: 0x000586F0
		[Token(Token = "0x60029D0")]
		[Address(RVA = "0x2A11700", Offset = "0x2A11700", VA = "0x2A11700")]
		public IEnumerator method_40()
		{
			new DemoBackpack.Class36((int)0L);
			throw new NullReferenceException();
		}

		// Token: 0x060029D1 RID: 10705 RVA: 0x0005A514 File Offset: 0x00058714
		[Address(RVA = "0x2A11778", Offset = "0x2A11778", VA = "0x2A11778")]
		[Token(Token = "0x60029D1")]
		private void method_41()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_35();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029D2 RID: 10706 RVA: 0x0005A560 File Offset: 0x00058760
		[Address(RVA = "0x2A1195C", Offset = "0x2A1195C", VA = "0x2A1195C")]
		[Token(Token = "0x60029D2")]
		private void method_42()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_6();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029D3 RID: 10707 RVA: 0x0005A5AC File Offset: 0x000587AC
		[Token(Token = "0x60029D3")]
		[Address(RVA = "0x2A11B40", Offset = "0x2A11B40", VA = "0x2A11B40")]
		private void method_43()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_13();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029D4 RID: 10708 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2A11D24", Offset = "0x2A11D24", VA = "0x2A11D24")]
		[Token(Token = "0x60029D4")]
		public void method_44(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029D5 RID: 10709 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029D5")]
		[Address(RVA = "0x2A11E78", Offset = "0x2A11E78", VA = "0x2A11E78")]
		public IEnumerator method_45()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029D6 RID: 10710 RVA: 0x0005A5F8 File Offset: 0x000587F8
		[Address(RVA = "0x2A11EF0", Offset = "0x2A11EF0", VA = "0x2A11EF0")]
		[Token(Token = "0x60029D6")]
		private void method_46()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_26;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				return;
			}
			IL_26:
			IEnumerator routine = this.method_47();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029D7 RID: 10711 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029D7")]
		[Address(RVA = "0x2A1027C", Offset = "0x2A1027C", VA = "0x2A1027C")]
		public IEnumerator method_47()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029D8 RID: 10712 RVA: 0x0005A164 File Offset: 0x00058364
		[Address(RVA = "0x2A120D4", Offset = "0x2A120D4", VA = "0x2A120D4")]
		[Token(Token = "0x60029D8")]
		public IEnumerator method_48()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029D9 RID: 10713 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2A1214C", Offset = "0x2A1214C", VA = "0x2A1214C")]
		[Token(Token = "0x60029D9")]
		public void method_49(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029DA RID: 10714 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029DA")]
		[Address(RVA = "0x2A0F3F8", Offset = "0x2A0F3F8", VA = "0x2A0F3F8")]
		public IEnumerator method_50()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029DB RID: 10715 RVA: 0x0005A164 File Offset: 0x00058364
		[Token(Token = "0x60029DB")]
		[Address(RVA = "0x2A0EF40", Offset = "0x2A0EF40", VA = "0x2A0EF40")]
		public IEnumerator method_51()
		{
			DemoBackpack.Class36 @class = new DemoBackpack.Class36((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060029DC RID: 10716 RVA: 0x0005A18C File Offset: 0x0005838C
		[Token(Token = "0x60029DC")]
		[Address(RVA = "0x2A12274", Offset = "0x2A12274", VA = "0x2A12274")]
		private void method_52()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_51();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029DD RID: 10717 RVA: 0x0005A494 File Offset: 0x00058694
		[Token(Token = "0x60029DD")]
		[Address(RVA = "0x2A12458", Offset = "0x2A12458", VA = "0x2A12458")]
		private void Start()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_22();
			base.StartCoroutine(routine);
		}

		// Token: 0x060029DE RID: 10718 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x60029DE")]
		[Address(RVA = "0x2A1263C", Offset = "0x2A1263C", VA = "0x2A1263C")]
		public void method_53(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029DF RID: 10719 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2A12744", Offset = "0x2A12744", VA = "0x2A12744")]
		[Token(Token = "0x60029DF")]
		public void method_54(HVRGrabbable hvrgrabbable_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060029E0 RID: 10720 RVA: 0x0005A514 File Offset: 0x00058714
		[Address(RVA = "0x2A1286C", Offset = "0x2A1286C", VA = "0x2A1286C")]
		[Token(Token = "0x60029E0")]
		private void method_55()
		{
			List<Collider> list = this.list_0;
			int size;
			if (list != null)
			{
				size = list._size;
				if (size != 0)
				{
					goto IL_2B;
				}
			}
			base.GetComponentsInChildren<Collider>();
			if (size != 0)
			{
			}
			if (DemoBackpack.<>c.<>9__1_0 == null)
			{
				Func<Collider, bool> <>9__1_;
				DemoBackpack.<>c.<>9__1_0 = <>9__1_;
			}
			IL_2B:
			IEnumerator routine = this.method_35();
			base.StartCoroutine(routine);
		}

		// Token: 0x04000569 RID: 1385
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000569")]
		public List<Collider> list_0;
	}
}
