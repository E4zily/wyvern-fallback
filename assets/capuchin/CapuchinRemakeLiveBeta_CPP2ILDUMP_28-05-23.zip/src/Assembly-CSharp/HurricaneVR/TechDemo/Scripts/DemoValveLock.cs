﻿using System;
using System.Collections;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core;
using HurricaneVR.Framework.Core.Grabbers;
using UnityEngine;
using UnityEngine.Events;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000138 RID: 312
	[Token(Token = "0x2000138")]
	public class DemoValveLock : MonoBehaviour
	{
		// Token: 0x0600312C RID: 12588 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA2068", Offset = "0x2EA2068", VA = "0x2EA2068")]
		[Token(Token = "0x600312C")]
		private IEnumerator method_0(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600312D RID: 12589 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA20FC", Offset = "0x2EA20FC", VA = "0x2EA20FC")]
		[Token(Token = "0x600312D")]
		public void method_1()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x0600312E RID: 12590 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA21F0", Offset = "0x2EA21F0", VA = "0x2EA21F0")]
		[Token(Token = "0x600312E")]
		private IEnumerator method_2(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600312F RID: 12591 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA2284", Offset = "0x2EA2284", VA = "0x2EA2284")]
		[Token(Token = "0x600312F")]
		private IEnumerator method_3(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003130 RID: 12592 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA2318", Offset = "0x2EA2318", VA = "0x2EA2318")]
		[Token(Token = "0x6003130")]
		public void method_4()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003131 RID: 12593 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA240C", Offset = "0x2EA240C", VA = "0x2EA240C")]
		[Token(Token = "0x6003131")]
		private IEnumerator method_5(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003132 RID: 12594 RVA: 0x00061C80 File Offset: 0x0005FE80
		[Address(RVA = "0x2EA24A0", Offset = "0x2EA24A0", VA = "0x2EA24A0")]
		[Token(Token = "0x6003132")]
		private void method_6(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_88(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003133 RID: 12595 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA2564", Offset = "0x2EA2564", VA = "0x2EA2564")]
		[Token(Token = "0x6003133")]
		public void method_7()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003134 RID: 12596 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA2658", Offset = "0x2EA2658", VA = "0x2EA2658")]
		[Token(Token = "0x6003134")]
		private IEnumerator method_8(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003135 RID: 12597 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2EA26EC", Offset = "0x2EA26EC", VA = "0x2EA26EC")]
		[Token(Token = "0x6003135")]
		public void method_9()
		{
		}

		// Token: 0x06003136 RID: 12598 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA26F0", Offset = "0x2EA26F0", VA = "0x2EA26F0")]
		[Token(Token = "0x6003136")]
		public void method_10()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003137 RID: 12599 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA27E4", Offset = "0x2EA27E4", VA = "0x2EA27E4")]
		[Token(Token = "0x6003137")]
		public void method_11()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003138 RID: 12600 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA28D8", Offset = "0x2EA28D8", VA = "0x2EA28D8")]
		[Token(Token = "0x6003138")]
		private IEnumerator method_12(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003139 RID: 12601 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA296C", Offset = "0x2EA296C", VA = "0x2EA296C")]
		[Token(Token = "0x6003139")]
		private IEnumerator method_13(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600313A RID: 12602 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA2A00", Offset = "0x2EA2A00", VA = "0x2EA2A00")]
		[Token(Token = "0x600313A")]
		private IEnumerator method_14(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600313B RID: 12603 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2EA2A94", Offset = "0x2EA2A94", VA = "0x2EA2A94")]
		[Token(Token = "0x600313B")]
		public void method_15()
		{
		}

		// Token: 0x0600313C RID: 12604 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA2A98", Offset = "0x2EA2A98", VA = "0x2EA2A98")]
		[Token(Token = "0x600313C")]
		public void method_16()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x0600313D RID: 12605 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA2B8C", Offset = "0x2EA2B8C", VA = "0x2EA2B8C")]
		[Token(Token = "0x600313D")]
		public void method_17()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x0600313E RID: 12606 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA2C80", Offset = "0x2EA2C80", VA = "0x2EA2C80")]
		[Token(Token = "0x600313E")]
		private IEnumerator method_18(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600313F RID: 12607 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA2D14", Offset = "0x2EA2D14", VA = "0x2EA2D14")]
		[Token(Token = "0x600313F")]
		public void method_19()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003140 RID: 12608 RVA: 0x00061CA0 File Offset: 0x0005FEA0
		[Address(RVA = "0x2EA2E08", Offset = "0x2EA2E08", VA = "0x2EA2E08")]
		[Token(Token = "0x6003140")]
		private void method_20(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_49(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003141 RID: 12609 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA2ECC", Offset = "0x2EA2ECC", VA = "0x2EA2ECC")]
		[Token(Token = "0x6003141")]
		private IEnumerator method_21(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003142 RID: 12610 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2EA2F60", Offset = "0x2EA2F60", VA = "0x2EA2F60")]
		[Token(Token = "0x6003142")]
		public void method_22()
		{
		}

		// Token: 0x06003143 RID: 12611 RVA: 0x00061CC0 File Offset: 0x0005FEC0
		[Address(RVA = "0x2EA2F64", Offset = "0x2EA2F64", VA = "0x2EA2F64")]
		[Token(Token = "0x6003143")]
		private void method_23(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_64(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003144 RID: 12612 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA3028", Offset = "0x2EA3028", VA = "0x2EA3028")]
		[Token(Token = "0x6003144")]
		private IEnumerator method_24(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003145 RID: 12613 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA30BC", Offset = "0x2EA30BC", VA = "0x2EA30BC")]
		[Token(Token = "0x6003145")]
		private IEnumerator method_25(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003146 RID: 12614 RVA: 0x00061CC0 File Offset: 0x0005FEC0
		[Token(Token = "0x6003146")]
		[Address(RVA = "0x2EA3150", Offset = "0x2EA3150", VA = "0x2EA3150")]
		private void method_26(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_64(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003147 RID: 12615 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Token(Token = "0x6003147")]
		[Address(RVA = "0x2EA3180", Offset = "0x2EA3180", VA = "0x2EA3180")]
		private IEnumerator method_27(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003148 RID: 12616 RVA: 0x00061CE0 File Offset: 0x0005FEE0
		[Token(Token = "0x6003148")]
		[Address(RVA = "0x2EA3214", Offset = "0x2EA3214", VA = "0x2EA3214")]
		private void method_28(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_21(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003149 RID: 12617 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2EA3244", Offset = "0x2EA3244", VA = "0x2EA3244")]
		[Token(Token = "0x6003149")]
		public void Update()
		{
		}

		// Token: 0x0600314A RID: 12618 RVA: 0x00061C80 File Offset: 0x0005FE80
		[Token(Token = "0x600314A")]
		[Address(RVA = "0x2EA3248", Offset = "0x2EA3248", VA = "0x2EA3248")]
		private void method_29(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_88(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x0600314B RID: 12619 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600314B")]
		[Address(RVA = "0x2EA3278", Offset = "0x2EA3278", VA = "0x2EA3278")]
		public void method_30()
		{
		}

		// Token: 0x0600314C RID: 12620 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Token(Token = "0x600314C")]
		[Address(RVA = "0x2EA327C", Offset = "0x2EA327C", VA = "0x2EA327C")]
		public void method_31()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x0600314D RID: 12621 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Token(Token = "0x600314D")]
		[Address(RVA = "0x2EA3370", Offset = "0x2EA3370", VA = "0x2EA3370")]
		public void method_32()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x0600314E RID: 12622 RVA: 0x00061D00 File Offset: 0x0005FF00
		[Token(Token = "0x600314E")]
		[Address(RVA = "0x2EA3464", Offset = "0x2EA3464", VA = "0x2EA3464")]
		private void method_33(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_24(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x0600314F RID: 12623 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Token(Token = "0x600314F")]
		[Address(RVA = "0x2EA3494", Offset = "0x2EA3494", VA = "0x2EA3494")]
		public void method_34()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003150 RID: 12624 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Token(Token = "0x6003150")]
		[Address(RVA = "0x2EA3588", Offset = "0x2EA3588", VA = "0x2EA3588")]
		public void method_35()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003151 RID: 12625 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Token(Token = "0x6003151")]
		[Address(RVA = "0x2EA367C", Offset = "0x2EA367C", VA = "0x2EA367C")]
		private IEnumerator method_36(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003152 RID: 12626 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA3710", Offset = "0x2EA3710", VA = "0x2EA3710")]
		[Token(Token = "0x6003152")]
		public void method_37()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003153 RID: 12627 RVA: 0x00061CE0 File Offset: 0x0005FEE0
		[Address(RVA = "0x2EA3804", Offset = "0x2EA3804", VA = "0x2EA3804")]
		[Token(Token = "0x6003153")]
		private void method_38(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_21(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003154 RID: 12628 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Token(Token = "0x6003154")]
		[Address(RVA = "0x2EA3834", Offset = "0x2EA3834", VA = "0x2EA3834")]
		private IEnumerator method_39(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003155 RID: 12629 RVA: 0x00061CC0 File Offset: 0x0005FEC0
		[Address(RVA = "0x2EA38C8", Offset = "0x2EA38C8", VA = "0x2EA38C8")]
		[Token(Token = "0x6003155")]
		private void method_40(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_64(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003156 RID: 12630 RVA: 0x00061CC0 File Offset: 0x0005FEC0
		[Token(Token = "0x6003156")]
		[Address(RVA = "0x2EA38F8", Offset = "0x2EA38F8", VA = "0x2EA38F8")]
		private void method_41(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_64(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003157 RID: 12631 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Token(Token = "0x6003157")]
		[Address(RVA = "0x2EA3928", Offset = "0x2EA3928", VA = "0x2EA3928")]
		public void method_42()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003158 RID: 12632 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Token(Token = "0x6003158")]
		[Address(RVA = "0x2EA3A1C", Offset = "0x2EA3A1C", VA = "0x2EA3A1C")]
		private IEnumerator method_43(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003159 RID: 12633 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Token(Token = "0x6003159")]
		[Address(RVA = "0x2EA3AB0", Offset = "0x2EA3AB0", VA = "0x2EA3AB0")]
		public void method_44()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x0600315A RID: 12634 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA3BA4", Offset = "0x2EA3BA4", VA = "0x2EA3BA4")]
		[Token(Token = "0x600315A")]
		public void method_45()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x0600315B RID: 12635 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Token(Token = "0x600315B")]
		[Address(RVA = "0x2EA3C98", Offset = "0x2EA3C98", VA = "0x2EA3C98")]
		private IEnumerator method_46(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600315C RID: 12636 RVA: 0x00061D20 File Offset: 0x0005FF20
		[Address(RVA = "0x2EA3D2C", Offset = "0x2EA3D2C", VA = "0x2EA3D2C")]
		[Token(Token = "0x600315C")]
		private void method_47(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_54(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x0600315D RID: 12637 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600315D")]
		[Address(RVA = "0x2EA3DF0", Offset = "0x2EA3DF0", VA = "0x2EA3DF0")]
		public void method_48()
		{
		}

		// Token: 0x0600315E RID: 12638 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Token(Token = "0x600315E")]
		[Address(RVA = "0x2EA2E38", Offset = "0x2EA2E38", VA = "0x2EA2E38")]
		private IEnumerator method_49(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600315F RID: 12639 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Token(Token = "0x600315F")]
		[Address(RVA = "0x2EA3DF4", Offset = "0x2EA3DF4", VA = "0x2EA3DF4")]
		public void method_50()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003160 RID: 12640 RVA: 0x00061D40 File Offset: 0x0005FF40
		[Address(RVA = "0x2EA3EE8", Offset = "0x2EA3EE8", VA = "0x2EA3EE8")]
		[Token(Token = "0x6003160")]
		private void method_51(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_56(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003161 RID: 12641 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA3FAC", Offset = "0x2EA3FAC", VA = "0x2EA3FAC")]
		[Token(Token = "0x6003161")]
		public void method_52()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003162 RID: 12642 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA40A0", Offset = "0x2EA40A0", VA = "0x2EA40A0")]
		[Token(Token = "0x6003162")]
		private IEnumerator method_53(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003163 RID: 12643 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Token(Token = "0x6003163")]
		[Address(RVA = "0x2EA3D5C", Offset = "0x2EA3D5C", VA = "0x2EA3D5C")]
		private IEnumerator method_54(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003164 RID: 12644 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA4134", Offset = "0x2EA4134", VA = "0x2EA4134")]
		[Token(Token = "0x6003164")]
		public void method_55()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003165 RID: 12645 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA3F18", Offset = "0x2EA3F18", VA = "0x2EA3F18")]
		[Token(Token = "0x6003165")]
		private IEnumerator method_56(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003166 RID: 12646 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA4228", Offset = "0x2EA4228", VA = "0x2EA4228")]
		[Token(Token = "0x6003166")]
		public void method_57()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003167 RID: 12647 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA431C", Offset = "0x2EA431C", VA = "0x2EA431C")]
		[Token(Token = "0x6003167")]
		private IEnumerator method_58(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003168 RID: 12648 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA43B0", Offset = "0x2EA43B0", VA = "0x2EA43B0")]
		[Token(Token = "0x6003168")]
		public void method_59()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003169 RID: 12649 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Token(Token = "0x6003169")]
		[Address(RVA = "0x2EA44A4", Offset = "0x2EA44A4", VA = "0x2EA44A4")]
		public void method_60()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x0600316A RID: 12650 RVA: 0x00061D60 File Offset: 0x0005FF60
		[Token(Token = "0x600316A")]
		[Address(RVA = "0x2EA4598", Offset = "0x2EA4598", VA = "0x2EA4598")]
		private void method_61(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_53(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x0600316B RID: 12651 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA45C8", Offset = "0x2EA45C8", VA = "0x2EA45C8")]
		[Token(Token = "0x600316B")]
		private IEnumerator method_62(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600316C RID: 12652 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA465C", Offset = "0x2EA465C", VA = "0x2EA465C")]
		[Token(Token = "0x600316C")]
		public void method_63()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x0600316D RID: 12653 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA2F94", Offset = "0x2EA2F94", VA = "0x2EA2F94")]
		[Token(Token = "0x600316D")]
		private IEnumerator method_64(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600316E RID: 12654 RVA: 0x00061D80 File Offset: 0x0005FF80
		[Address(RVA = "0x2EA4750", Offset = "0x2EA4750", VA = "0x2EA4750")]
		[Token(Token = "0x600316E")]
		private void method_65(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_8(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x0600316F RID: 12655 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA4780", Offset = "0x2EA4780", VA = "0x2EA4780")]
		[Token(Token = "0x600316F")]
		private IEnumerator method_66(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003170 RID: 12656 RVA: 0x00061D40 File Offset: 0x0005FF40
		[Address(RVA = "0x2EA4814", Offset = "0x2EA4814", VA = "0x2EA4814")]
		[Token(Token = "0x6003170")]
		private void method_67(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_56(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003171 RID: 12657 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA4844", Offset = "0x2EA4844", VA = "0x2EA4844")]
		[Token(Token = "0x6003171")]
		public void method_68()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003172 RID: 12658 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA4938", Offset = "0x2EA4938", VA = "0x2EA4938")]
		[Token(Token = "0x6003172")]
		private IEnumerator method_69(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003173 RID: 12659 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA49CC", Offset = "0x2EA49CC", VA = "0x2EA49CC")]
		[Token(Token = "0x6003173")]
		public void Start()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003174 RID: 12660 RVA: 0x00061DA0 File Offset: 0x0005FFA0
		[Address(RVA = "0x2EA4AC0", Offset = "0x2EA4AC0", VA = "0x2EA4AC0")]
		[Token(Token = "0x6003174")]
		private void method_70(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_69(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003175 RID: 12661 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2EA4AF0", Offset = "0x2EA4AF0", VA = "0x2EA4AF0")]
		[Token(Token = "0x6003175")]
		public void method_71()
		{
		}

		// Token: 0x06003176 RID: 12662 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA4AF4", Offset = "0x2EA4AF4", VA = "0x2EA4AF4")]
		[Token(Token = "0x6003176")]
		private IEnumerator method_72(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003177 RID: 12663 RVA: 0x00061DC0 File Offset: 0x0005FFC0
		[Address(RVA = "0x2EA4B88", Offset = "0x2EA4B88", VA = "0x2EA4B88")]
		[Token(Token = "0x6003177")]
		public DemoValveLock()
		{
			long num = 1065353216L;
			this.float_0 = (float)num;
			base..ctor();
		}

		// Token: 0x06003178 RID: 12664 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA4B98", Offset = "0x2EA4B98", VA = "0x2EA4B98")]
		[Token(Token = "0x6003178")]
		public void method_73()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003179 RID: 12665 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA4C8C", Offset = "0x2EA4C8C", VA = "0x2EA4C8C")]
		[Token(Token = "0x6003179")]
		private IEnumerator method_74(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600317A RID: 12666 RVA: 0x00061DE0 File Offset: 0x0005FFE0
		[Address(RVA = "0x2EA4D20", Offset = "0x2EA4D20", VA = "0x2EA4D20")]
		[Token(Token = "0x600317A")]
		private void method_75(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_74(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x0600317B RID: 12667 RVA: 0x00061E00 File Offset: 0x00060000
		[Address(RVA = "0x2EA4D50", Offset = "0x2EA4D50", VA = "0x2EA4D50")]
		[Token(Token = "0x600317B")]
		public void method_76()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
		}

		// Token: 0x0600317C RID: 12668 RVA: 0x00061E1C File Offset: 0x0006001C
		[Address(RVA = "0x2EA4E44", Offset = "0x2EA4E44", VA = "0x2EA4E44")]
		[Token(Token = "0x600317C")]
		private void method_77(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_3(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x0600317D RID: 12669 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2EA4E74", Offset = "0x2EA4E74", VA = "0x2EA4E74")]
		[Token(Token = "0x600317D")]
		public void method_78()
		{
		}

		// Token: 0x0600317E RID: 12670 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2EA4E78", Offset = "0x2EA4E78", VA = "0x2EA4E78")]
		[Token(Token = "0x600317E")]
		public void method_79()
		{
		}

		// Token: 0x0600317F RID: 12671 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA4E7C", Offset = "0x2EA4E7C", VA = "0x2EA4E7C")]
		[Token(Token = "0x600317F")]
		public void method_80()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003180 RID: 12672 RVA: 0x00061E3C File Offset: 0x0006003C
		[Address(RVA = "0x2EA4F70", Offset = "0x2EA4F70", VA = "0x2EA4F70")]
		[Token(Token = "0x6003180")]
		private void method_81(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_13(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003181 RID: 12673 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA4FA0", Offset = "0x2EA4FA0", VA = "0x2EA4FA0")]
		[Token(Token = "0x6003181")]
		public void method_82()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003182 RID: 12674 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA5094", Offset = "0x2EA5094", VA = "0x2EA5094")]
		[Token(Token = "0x6003182")]
		public void method_83()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003183 RID: 12675 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA5188", Offset = "0x2EA5188", VA = "0x2EA5188")]
		[Token(Token = "0x6003183")]
		private IEnumerator method_84(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003184 RID: 12676 RVA: 0x00061E5C File Offset: 0x0006005C
		[Address(RVA = "0x2EA521C", Offset = "0x2EA521C", VA = "0x2EA521C")]
		[Token(Token = "0x6003184")]
		private void method_85(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_14(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06003185 RID: 12677 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA524C", Offset = "0x2EA524C", VA = "0x2EA524C")]
		[Token(Token = "0x6003185")]
		private IEnumerator method_86(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003186 RID: 12678 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Token(Token = "0x6003186")]
		[Address(RVA = "0x2EA52E0", Offset = "0x2EA52E0", VA = "0x2EA52E0")]
		public void method_87()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06003187 RID: 12679 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Address(RVA = "0x2EA24D0", Offset = "0x2EA24D0", VA = "0x2EA24D0")]
		[Token(Token = "0x6003187")]
		private IEnumerator method_88(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06003188 RID: 12680 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2EA53D4", Offset = "0x2EA53D4", VA = "0x2EA53D4")]
		[Token(Token = "0x6003188")]
		public void method_89()
		{
		}

		// Token: 0x06003189 RID: 12681 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003189")]
		[Address(RVA = "0x2EA53D8", Offset = "0x2EA53D8", VA = "0x2EA53D8")]
		public void method_90()
		{
		}

		// Token: 0x0600318A RID: 12682 RVA: 0x00061E7C File Offset: 0x0006007C
		[Address(RVA = "0x2EA53DC", Offset = "0x2EA53DC", VA = "0x2EA53DC")]
		[Token(Token = "0x600318A")]
		private void method_91(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_84(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x0600318B RID: 12683 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2EA540C", Offset = "0x2EA540C", VA = "0x2EA540C")]
		[Token(Token = "0x600318B")]
		public void method_92()
		{
		}

		// Token: 0x0600318C RID: 12684 RVA: 0x00061CE0 File Offset: 0x0005FEE0
		[Address(RVA = "0x2EA5410", Offset = "0x2EA5410", VA = "0x2EA5410")]
		[Token(Token = "0x600318C")]
		private void method_93(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_21(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x0600318D RID: 12685 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Address(RVA = "0x2EA5440", Offset = "0x2EA5440", VA = "0x2EA5440")]
		[Token(Token = "0x600318D")]
		public void method_94()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x0600318E RID: 12686 RVA: 0x00061C24 File Offset: 0x0005FE24
		[Token(Token = "0x600318E")]
		[Address(RVA = "0x2EA5534", Offset = "0x2EA5534", VA = "0x2EA5534")]
		private IEnumerator method_95(HVRGrabbable hvrgrabbable_1)
		{
			DemoValveLock.Class41 @class = new DemoValveLock.Class41((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x0600318F RID: 12687 RVA: 0x00061C54 File Offset: 0x0005FE54
		[Token(Token = "0x600318F")]
		[Address(RVA = "0x2EA55C8", Offset = "0x2EA55C8", VA = "0x2EA55C8")]
		public void method_96()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x04000628 RID: 1576
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000628")]
		public DemoPassthroughSocket demoPassthroughSocket_0;

		// Token: 0x04000629 RID: 1577
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000629")]
		public HVRGrabbable hvrgrabbable_0;

		// Token: 0x0400062A RID: 1578
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400062A")]
		public float float_0;
	}
}
