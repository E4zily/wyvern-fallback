﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core.Stabbing;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000119 RID: 281
	[Token(Token = "0x2000119")]
	public class DemoFullStabConfetti : MonoBehaviour
	{
		// Token: 0x06002AA4 RID: 10916 RVA: 0x0005B064 File Offset: 0x00059264
		[Address(RVA = "0x35F6390", Offset = "0x35F6390", VA = "0x35F6390")]
		[Token(Token = "0x6002AA4")]
		private void method_0(ݨ\u07BCոӉ ݨ\u07BCոӉ_0)
		{
			float z = ݨ\u07BCոӉ_0.ԇח\u05C0ߣ.z;
			HVRStabbable hvrstabbable = this.hvrstabbable_0;
			this.vector3_1.z = z;
			Transform transform = hvrstabbable.transform;
			float x = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.x;
			float y = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.y;
			float z2 = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.z;
			bool flag = this.bool_0;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z2;
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06002AA5 RID: 10917 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Address(RVA = "0x35F6560", Offset = "0x35F6560", VA = "0x35F6560")]
		[Token(Token = "0x6002AA5")]
		private void method_1(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AA6 RID: 10918 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35F66B0", Offset = "0x35F66B0", VA = "0x35F66B0")]
		[Token(Token = "0x6002AA6")]
		private void method_2(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AA7 RID: 10919 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Address(RVA = "0x35F66B4", Offset = "0x35F66B4", VA = "0x35F66B4")]
		[Token(Token = "0x6002AA7")]
		private void method_3(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AA8 RID: 10920 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002AA8")]
		[Address(RVA = "0x35F6804", Offset = "0x35F6804", VA = "0x35F6804")]
		private void method_4(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AA9 RID: 10921 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Address(RVA = "0x35F6808", Offset = "0x35F6808", VA = "0x35F6808")]
		[Token(Token = "0x6002AA9")]
		private void method_5(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AAA RID: 10922 RVA: 0x0005B15C File Offset: 0x0005935C
		[Token(Token = "0x6002AAA")]
		[Address(RVA = "0x35F6958", Offset = "0x35F6958", VA = "0x35F6958")]
		private void method_6(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AAB RID: 10923 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Address(RVA = "0x35F6AA8", Offset = "0x35F6AA8", VA = "0x35F6AA8")]
		[Token(Token = "0x6002AAB")]
		public void Start()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AAC RID: 10924 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Address(RVA = "0x35F6D08", Offset = "0x35F6D08", VA = "0x35F6D08")]
		[Token(Token = "0x6002AAC")]
		private void method_7(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AAD RID: 10925 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Address(RVA = "0x35F6E70", Offset = "0x35F6E70", VA = "0x35F6E70")]
		[Token(Token = "0x6002AAD")]
		public void method_8()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AAE RID: 10926 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Address(RVA = "0x35F70D0", Offset = "0x35F70D0", VA = "0x35F70D0")]
		[Token(Token = "0x6002AAE")]
		public void method_9()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AAF RID: 10927 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35F7330", Offset = "0x35F7330", VA = "0x35F7330")]
		[Token(Token = "0x6002AAF")]
		private void method_10(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AB0 RID: 10928 RVA: 0x0005B20C File Offset: 0x0005940C
		[Token(Token = "0x6002AB0")]
		[Address(RVA = "0x35F7334", Offset = "0x35F7334", VA = "0x35F7334")]
		private void method_11(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AB1 RID: 10929 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Token(Token = "0x6002AB1")]
		[Address(RVA = "0x35F749C", Offset = "0x35F749C", VA = "0x35F749C")]
		public void method_12()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AB2 RID: 10930 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Token(Token = "0x6002AB2")]
		[Address(RVA = "0x35F76FC", Offset = "0x35F76FC", VA = "0x35F76FC")]
		private void method_13(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AB3 RID: 10931 RVA: 0x0005B064 File Offset: 0x00059264
		[Address(RVA = "0x35F7864", Offset = "0x35F7864", VA = "0x35F7864")]
		[Token(Token = "0x6002AB3")]
		private void method_14(ݨ\u07BCոӉ ݨ\u07BCոӉ_0)
		{
			float z = ݨ\u07BCոӉ_0.ԇח\u05C0ߣ.z;
			HVRStabbable hvrstabbable = this.hvrstabbable_0;
			this.vector3_1.z = z;
			Transform transform = hvrstabbable.transform;
			float x = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.x;
			float y = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.y;
			float z2 = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.z;
			bool flag = this.bool_0;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z2;
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06002AB4 RID: 10932 RVA: 0x0005B21C File Offset: 0x0005941C
		[Address(RVA = "0x35F7A34", Offset = "0x35F7A34", VA = "0x35F7A34")]
		[Token(Token = "0x6002AB4")]
		public void method_15()
		{
			HVRStabbable hvrstabbable;
			this.hvrstabbable_0 = hvrstabbable;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AB5 RID: 10933 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Token(Token = "0x6002AB5")]
		[Address(RVA = "0x35F78E4", Offset = "0x35F78E4", VA = "0x35F78E4")]
		private void method_16(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AB6 RID: 10934 RVA: 0x0005B240 File Offset: 0x00059440
		[Token(Token = "0x6002AB6")]
		[Address(RVA = "0x35F7C94", Offset = "0x35F7C94", VA = "0x35F7C94")]
		private void method_17(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			ParticleSystem particleSystem = this.particleSystem_0;
			particleSystem.Stop();
			particleSystem.Play();
		}

		// Token: 0x06002AB7 RID: 10935 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Token(Token = "0x6002AB7")]
		[Address(RVA = "0x35F7DE4", Offset = "0x35F7DE4", VA = "0x35F7DE4")]
		private void method_18(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AB8 RID: 10936 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002AB8")]
		[Address(RVA = "0x35F7F4C", Offset = "0x35F7F4C", VA = "0x35F7F4C")]
		private void method_19(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AB9 RID: 10937 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Address(RVA = "0x35F7F50", Offset = "0x35F7F50", VA = "0x35F7F50")]
		[Token(Token = "0x6002AB9")]
		public void method_20()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002ABA RID: 10938 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Token(Token = "0x6002ABA")]
		[Address(RVA = "0x35F81B0", Offset = "0x35F81B0", VA = "0x35F81B0")]
		private void method_21(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002ABB RID: 10939 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Token(Token = "0x6002ABB")]
		[Address(RVA = "0x35F8300", Offset = "0x35F8300", VA = "0x35F8300")]
		private void method_22(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002ABC RID: 10940 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002ABC")]
		[Address(RVA = "0x35F8468", Offset = "0x35F8468", VA = "0x35F8468")]
		private void method_23(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002ABD RID: 10941 RVA: 0x0005B2AC File Offset: 0x000594AC
		[Address(RVA = "0x35F846C", Offset = "0x35F846C", VA = "0x35F846C")]
		[Token(Token = "0x6002ABD")]
		private void method_24(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002ABE RID: 10942 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Token(Token = "0x6002ABE")]
		[Address(RVA = "0x35F8484", Offset = "0x35F8484", VA = "0x35F8484")]
		private void method_25(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002ABF RID: 10943 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Address(RVA = "0x35F85EC", Offset = "0x35F85EC", VA = "0x35F85EC")]
		[Token(Token = "0x6002ABF")]
		public void method_26()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AC0 RID: 10944 RVA: 0x0005B064 File Offset: 0x00059264
		[Token(Token = "0x6002AC0")]
		[Address(RVA = "0x35F884C", Offset = "0x35F884C", VA = "0x35F884C")]
		private void method_27(ݨ\u07BCոӉ ݨ\u07BCոӉ_0)
		{
			float z = ݨ\u07BCոӉ_0.ԇח\u05C0ߣ.z;
			HVRStabbable hvrstabbable = this.hvrstabbable_0;
			this.vector3_1.z = z;
			Transform transform = hvrstabbable.transform;
			float x = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.x;
			float y = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.y;
			float z2 = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.z;
			bool flag = this.bool_0;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z2;
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06002AC1 RID: 10945 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Address(RVA = "0x35F849C", Offset = "0x35F849C", VA = "0x35F849C")]
		[Token(Token = "0x6002AC1")]
		private void method_28(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AC2 RID: 10946 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Address(RVA = "0x35F88CC", Offset = "0x35F88CC", VA = "0x35F88CC")]
		[Token(Token = "0x6002AC2")]
		private void method_29(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AC3 RID: 10947 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35F8A1C", Offset = "0x35F8A1C", VA = "0x35F8A1C")]
		[Token(Token = "0x6002AC3")]
		private void method_30(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AC4 RID: 10948 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Address(RVA = "0x35F8A20", Offset = "0x35F8A20", VA = "0x35F8A20")]
		[Token(Token = "0x6002AC4")]
		private void method_31(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AC5 RID: 10949 RVA: 0x0005B064 File Offset: 0x00059264
		[Address(RVA = "0x35F8B70", Offset = "0x35F8B70", VA = "0x35F8B70")]
		[Token(Token = "0x6002AC5")]
		private void method_32(ݨ\u07BCոӉ ݨ\u07BCոӉ_0)
		{
			float z = ݨ\u07BCոӉ_0.ԇח\u05C0ߣ.z;
			HVRStabbable hvrstabbable = this.hvrstabbable_0;
			this.vector3_1.z = z;
			Transform transform = hvrstabbable.transform;
			float x = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.x;
			float y = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.y;
			float z2 = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.z;
			bool flag = this.bool_0;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z2;
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06002AC6 RID: 10950 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Address(RVA = "0x35F8BF0", Offset = "0x35F8BF0", VA = "0x35F8BF0")]
		[Token(Token = "0x6002AC6")]
		private void method_33(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AC7 RID: 10951 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Token(Token = "0x6002AC7")]
		[Address(RVA = "0x35F8C08", Offset = "0x35F8C08", VA = "0x35F8C08")]
		private void method_34(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AC8 RID: 10952 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Address(RVA = "0x35F7714", Offset = "0x35F7714", VA = "0x35F7714")]
		[Token(Token = "0x6002AC8")]
		private void method_35(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AC9 RID: 10953 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Address(RVA = "0x35F8C20", Offset = "0x35F8C20", VA = "0x35F8C20")]
		[Token(Token = "0x6002AC9")]
		private void method_36(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002ACA RID: 10954 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Address(RVA = "0x35F8C38", Offset = "0x35F8C38", VA = "0x35F8C38")]
		[Token(Token = "0x6002ACA")]
		public void method_37()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002ACB RID: 10955 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Address(RVA = "0x35F8E98", Offset = "0x35F8E98", VA = "0x35F8E98")]
		[Token(Token = "0x6002ACB")]
		public void method_38()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002ACC RID: 10956 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Address(RVA = "0x35F90F8", Offset = "0x35F90F8", VA = "0x35F90F8")]
		[Token(Token = "0x6002ACC")]
		public void method_39()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002ACD RID: 10957 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Token(Token = "0x6002ACD")]
		[Address(RVA = "0x35F9358", Offset = "0x35F9358", VA = "0x35F9358")]
		private void method_40(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002ACE RID: 10958 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Token(Token = "0x6002ACE")]
		[Address(RVA = "0x35F94A8", Offset = "0x35F94A8", VA = "0x35F94A8")]
		public void method_41()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002ACF RID: 10959 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002ACF")]
		[Address(RVA = "0x35F9708", Offset = "0x35F9708", VA = "0x35F9708")]
		private void method_42(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AD0 RID: 10960 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Token(Token = "0x6002AD0")]
		[Address(RVA = "0x35F970C", Offset = "0x35F970C", VA = "0x35F970C")]
		public void method_43()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AD1 RID: 10961 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Address(RVA = "0x35F996C", Offset = "0x35F996C", VA = "0x35F996C")]
		[Token(Token = "0x6002AD1")]
		private void method_44(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AD2 RID: 10962 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002AD2")]
		[Address(RVA = "0x35F9984", Offset = "0x35F9984", VA = "0x35F9984")]
		private void method_45(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AD3 RID: 10963 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Token(Token = "0x6002AD3")]
		[Address(RVA = "0x35F9988", Offset = "0x35F9988", VA = "0x35F9988")]
		private void method_46(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AD4 RID: 10964 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Address(RVA = "0x35F99A0", Offset = "0x35F99A0", VA = "0x35F99A0")]
		[Token(Token = "0x6002AD4")]
		public void method_47()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AD5 RID: 10965 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Token(Token = "0x6002AD5")]
		[Address(RVA = "0x35F734C", Offset = "0x35F734C", VA = "0x35F734C")]
		private void method_48(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AD6 RID: 10966 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Token(Token = "0x6002AD6")]
		[Address(RVA = "0x35F9C00", Offset = "0x35F9C00", VA = "0x35F9C00")]
		public void method_49()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AD7 RID: 10967 RVA: 0x0005B2BC File Offset: 0x000594BC
		[Address(RVA = "0x35F9E60", Offset = "0x35F9E60", VA = "0x35F9E60")]
		[Token(Token = "0x6002AD7")]
		public void method_50()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AD8 RID: 10968 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Address(RVA = "0x35FA0C0", Offset = "0x35FA0C0", VA = "0x35FA0C0")]
		[Token(Token = "0x6002AD8")]
		private void method_51(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AD9 RID: 10969 RVA: 0x0005B064 File Offset: 0x00059264
		[Token(Token = "0x6002AD9")]
		[Address(RVA = "0x35FA0D8", Offset = "0x35FA0D8", VA = "0x35FA0D8")]
		private void method_52(ݨ\u07BCոӉ ݨ\u07BCոӉ_0)
		{
			float z = ݨ\u07BCոӉ_0.ԇח\u05C0ߣ.z;
			HVRStabbable hvrstabbable = this.hvrstabbable_0;
			this.vector3_1.z = z;
			Transform transform = hvrstabbable.transform;
			float x = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.x;
			float y = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.y;
			float z2 = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.z;
			bool flag = this.bool_0;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z2;
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06002ADA RID: 10970 RVA: 0x0005B2E8 File Offset: 0x000594E8
		[Token(Token = "0x6002ADA")]
		[Address(RVA = "0x35F6D20", Offset = "0x35F6D20", VA = "0x35F6D20")]
		private void method_53(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002ADB RID: 10971 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Token(Token = "0x6002ADB")]
		[Address(RVA = "0x35FA158", Offset = "0x35FA158", VA = "0x35FA158")]
		public void method_54()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002ADC RID: 10972 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FA3B8", Offset = "0x35FA3B8", VA = "0x35FA3B8")]
		[Token(Token = "0x6002ADC")]
		private void method_55(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002ADD RID: 10973 RVA: 0x0005B064 File Offset: 0x00059264
		[Token(Token = "0x6002ADD")]
		[Address(RVA = "0x35FA3BC", Offset = "0x35FA3BC", VA = "0x35FA3BC")]
		private void method_56(ݨ\u07BCոӉ ݨ\u07BCոӉ_0)
		{
			float z = ݨ\u07BCոӉ_0.ԇח\u05C0ߣ.z;
			HVRStabbable hvrstabbable = this.hvrstabbable_0;
			this.vector3_1.z = z;
			Transform transform = hvrstabbable.transform;
			float x = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.x;
			float y = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.y;
			float z2 = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.z;
			bool flag = this.bool_0;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z2;
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06002ADE RID: 10974 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Token(Token = "0x6002ADE")]
		[Address(RVA = "0x35FA43C", Offset = "0x35FA43C", VA = "0x35FA43C")]
		public void method_57()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002ADF RID: 10975 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Address(RVA = "0x35FA69C", Offset = "0x35FA69C", VA = "0x35FA69C")]
		[Token(Token = "0x6002ADF")]
		public void method_58()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AE0 RID: 10976 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Token(Token = "0x6002AE0")]
		[Address(RVA = "0x35FA8FC", Offset = "0x35FA8FC", VA = "0x35FA8FC")]
		public void method_59()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AE1 RID: 10977 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002AE1")]
		[Address(RVA = "0x35FAB5C", Offset = "0x35FAB5C", VA = "0x35FAB5C")]
		private void method_60(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AE2 RID: 10978 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FAB60", Offset = "0x35FAB60", VA = "0x35FAB60")]
		[Token(Token = "0x6002AE2")]
		private void method_61(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AE3 RID: 10979 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Token(Token = "0x6002AE3")]
		[Address(RVA = "0x35FAB64", Offset = "0x35FAB64", VA = "0x35FAB64")]
		private void method_62(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AE4 RID: 10980 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Address(RVA = "0x35FAB7C", Offset = "0x35FAB7C", VA = "0x35FAB7C")]
		[Token(Token = "0x6002AE4")]
		private void method_63(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AE5 RID: 10981 RVA: 0x0005B354 File Offset: 0x00059554
		[Token(Token = "0x6002AE5")]
		[Address(RVA = "0x35FAB94", Offset = "0x35FAB94", VA = "0x35FAB94")]
		private void method_64(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = transform.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AE6 RID: 10982 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Token(Token = "0x6002AE6")]
		[Address(RVA = "0x35FACE4", Offset = "0x35FACE4", VA = "0x35FACE4")]
		private void method_65(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AE7 RID: 10983 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FACFC", Offset = "0x35FACFC", VA = "0x35FACFC")]
		[Token(Token = "0x6002AE7")]
		private void method_66(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AE8 RID: 10984 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Token(Token = "0x6002AE8")]
		[Address(RVA = "0x35F7DFC", Offset = "0x35F7DFC", VA = "0x35F7DFC")]
		private void method_67(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AE9 RID: 10985 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002AE9")]
		[Address(RVA = "0x35FAD00", Offset = "0x35FAD00", VA = "0x35FAD00")]
		private void method_68(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AEA RID: 10986 RVA: 0x0005B064 File Offset: 0x00059264
		[Address(RVA = "0x35FAD04", Offset = "0x35FAD04", VA = "0x35FAD04")]
		[Token(Token = "0x6002AEA")]
		private void method_69(ݨ\u07BCոӉ ݨ\u07BCոӉ_0)
		{
			float z = ݨ\u07BCոӉ_0.ԇח\u05C0ߣ.z;
			HVRStabbable hvrstabbable = this.hvrstabbable_0;
			this.vector3_1.z = z;
			Transform transform = hvrstabbable.transform;
			float x = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.x;
			float y = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.y;
			float z2 = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.z;
			bool flag = this.bool_0;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z2;
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06002AEB RID: 10987 RVA: 0x0005B064 File Offset: 0x00059264
		[Token(Token = "0x6002AEB")]
		[Address(RVA = "0x35FAD84", Offset = "0x35FAD84", VA = "0x35FAD84")]
		private void method_70(ݨ\u07BCոӉ ݨ\u07BCոӉ_0)
		{
			float z = ݨ\u07BCոӉ_0.ԇח\u05C0ߣ.z;
			HVRStabbable hvrstabbable = this.hvrstabbable_0;
			this.vector3_1.z = z;
			Transform transform = hvrstabbable.transform;
			float x = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.x;
			float y = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.y;
			float z2 = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.z;
			bool flag = this.bool_0;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z2;
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06002AEC RID: 10988 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Address(RVA = "0x35F6410", Offset = "0x35F6410", VA = "0x35F6410")]
		[Token(Token = "0x6002AEC")]
		private void method_71(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x06002AED RID: 10989 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Address(RVA = "0x35FAE04", Offset = "0x35FAE04", VA = "0x35FAE04")]
		[Token(Token = "0x6002AED")]
		private void method_72(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AEE RID: 10990 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Token(Token = "0x6002AEE")]
		[Address(RVA = "0x35FAE1C", Offset = "0x35FAE1C", VA = "0x35FAE1C")]
		public void method_73()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AEF RID: 10991 RVA: 0x0005B064 File Offset: 0x00059264
		[Token(Token = "0x6002AEF")]
		[Address(RVA = "0x35FB07C", Offset = "0x35FB07C", VA = "0x35FB07C")]
		private void method_74(ݨ\u07BCոӉ ݨ\u07BCոӉ_0)
		{
			float z = ݨ\u07BCոӉ_0.ԇח\u05C0ߣ.z;
			HVRStabbable hvrstabbable = this.hvrstabbable_0;
			this.vector3_1.z = z;
			Transform transform = hvrstabbable.transform;
			float x = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.x;
			float y = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.y;
			float z2 = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.z;
			bool flag = this.bool_0;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z2;
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06002AF0 RID: 10992 RVA: 0x0005B3B8 File Offset: 0x000595B8
		[Token(Token = "0x6002AF0")]
		[Address(RVA = "0x35FB0FC", Offset = "0x35FB0FC", VA = "0x35FB0FC")]
		public void method_75()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
		}

		// Token: 0x06002AF1 RID: 10993 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002AF1")]
		[Address(RVA = "0x35FB35C", Offset = "0x35FB35C", VA = "0x35FB35C")]
		private void method_76(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AF2 RID: 10994 RVA: 0x0005B2BC File Offset: 0x000594BC
		[Address(RVA = "0x35FB360", Offset = "0x35FB360", VA = "0x35FB360")]
		[Token(Token = "0x6002AF2")]
		public void method_77()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AF3 RID: 10995 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Token(Token = "0x6002AF3")]
		[Address(RVA = "0x35FB5C0", Offset = "0x35FB5C0", VA = "0x35FB5C0")]
		public void method_78()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AF4 RID: 10996 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x35FB820", Offset = "0x35FB820", VA = "0x35FB820")]
		[Token(Token = "0x6002AF4")]
		public DemoFullStabConfetti()
		{
		}

		// Token: 0x06002AF5 RID: 10997 RVA: 0x0005B1C8 File Offset: 0x000593C8
		[Token(Token = "0x6002AF5")]
		[Address(RVA = "0x35FB828", Offset = "0x35FB828", VA = "0x35FB828")]
		public void method_79()
		{
			HVRStabbable componentInParent = base.GetComponentInParent<HVRStabbable>();
			this.hvrstabbable_0 = componentInParent;
			HVRStabbable exists = this.hvrstabbable_0;
			exists;
		}

		// Token: 0x06002AF6 RID: 10998 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FBA88", Offset = "0x35FBA88", VA = "0x35FBA88")]
		[Token(Token = "0x6002AF6")]
		private void method_80(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
		}

		// Token: 0x06002AF7 RID: 10999 RVA: 0x0005B064 File Offset: 0x00059264
		[Token(Token = "0x6002AF7")]
		[Address(RVA = "0x35FBA8C", Offset = "0x35FBA8C", VA = "0x35FBA8C")]
		private void method_81(ݨ\u07BCոӉ ݨ\u07BCոӉ_0)
		{
			float z = ݨ\u07BCոӉ_0.ԇח\u05C0ߣ.z;
			HVRStabbable hvrstabbable = this.hvrstabbable_0;
			this.vector3_1.z = z;
			Transform transform = hvrstabbable.transform;
			float x = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.x;
			float y = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.y;
			float z2 = ݨ\u07BCոӉ_0.ӓ\u083F\u05C3ܩ.z;
			bool flag = this.bool_0;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z2;
			if (flag)
			{
				return;
			}
		}

		// Token: 0x06002AF8 RID: 11000 RVA: 0x0005B1F4 File Offset: 0x000593F4
		[Token(Token = "0x6002AF8")]
		[Address(RVA = "0x35FBB0C", Offset = "0x35FBB0C", VA = "0x35FBB0C")]
		private void method_82(HVRStabber hvrstabber_0, HVRStabbable hvrstabbable_1)
		{
			if (this.bool_0)
			{
				return;
			}
		}

		// Token: 0x06002AF9 RID: 11001 RVA: 0x0005B0F0 File Offset: 0x000592F0
		[Token(Token = "0x6002AF9")]
		[Address(RVA = "0x35F8318", Offset = "0x35F8318", VA = "0x35F8318")]
		private void method_83(Vector3 vector3_2)
		{
			Transform transform = this.particleSystem_0.transform;
			Transform transform2 = this.hvrstabbable_0.transform;
			Transform transform3 = this.particleSystem_0.transform;
			Vector3 up = this.particleSystem_0.transform.up;
			Quaternion rotation = this.particleSystem_0.transform.rotation;
			this.particleSystem_0.Stop();
			this.particleSystem_0.Play();
		}

		// Token: 0x04000579 RID: 1401
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000579")]
		public HVRStabbable hvrstabbable_0;

		// Token: 0x0400057A RID: 1402
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400057A")]
		public ParticleSystem particleSystem_0;

		// Token: 0x0400057B RID: 1403
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400057B")]
		public bool bool_0;

		// Token: 0x0400057C RID: 1404
		[Token(Token = "0x400057C")]
		[FieldOffset(Offset = "0x2C")]
		private Vector3 vector3_0;

		// Token: 0x0400057D RID: 1405
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x400057D")]
		private Vector3 vector3_1;
	}
}
