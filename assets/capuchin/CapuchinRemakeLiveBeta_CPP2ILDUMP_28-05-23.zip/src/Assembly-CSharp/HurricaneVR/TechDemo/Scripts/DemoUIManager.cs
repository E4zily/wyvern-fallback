﻿using System;
using System.Linq;
using Cpp2IlInjected;
using HurricaneVR.Framework.ControllerInput;
using HurricaneVR.Framework.Core;
using HurricaneVR.Framework.Core.Grabbers;
using HurricaneVR.Framework.Core.Player;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000135 RID: 309
	[Token(Token = "0x2000135")]
	public class DemoUIManager : MonoBehaviour
	{
		// Token: 0x0600302F RID: 12335 RVA: 0x00060104 File Offset: 0x0005E304
		[Address(RVA = "0x20AEB5C", Offset = "0x20AEB5C", VA = "0x20AEB5C")]
		[Token(Token = "0x600302F")]
		public void method_0()
		{
			this.method_21();
		}

		// Token: 0x06003030 RID: 12336 RVA: 0x00060118 File Offset: 0x0005E318
		[Address(RVA = "0x20AEC4C", Offset = "0x20AEC4C", VA = "0x20AEC4C")]
		[Token(Token = "0x6003030")]
		public void method_1(float float_0)
		{
		}

		// Token: 0x06003031 RID: 12337 RVA: 0x00060104 File Offset: 0x0005E304
		[Address(RVA = "0x20AECA4", Offset = "0x20AECA4", VA = "0x20AECA4")]
		[Token(Token = "0x6003031")]
		public void method_2()
		{
			this.method_21();
		}

		// Token: 0x06003032 RID: 12338 RVA: 0x00060128 File Offset: 0x0005E328
		[Address(RVA = "0x20AECEC", Offset = "0x20AECEC", VA = "0x20AECEC")]
		[Token(Token = "0x6003032")]
		private void method_3()
		{
		}

		// Token: 0x06003033 RID: 12339 RVA: 0x00060138 File Offset: 0x0005E338
		[Address(RVA = "0x20AED98", Offset = "0x20AED98", VA = "0x20AED98")]
		[Token(Token = "0x6003033")]
		private void method_4()
		{
		}

		// Token: 0x06003034 RID: 12340 RVA: 0x00060148 File Offset: 0x0005E348
		[Address(RVA = "0x20AEE44", Offset = "0x20AEE44", VA = "0x20AEE44")]
		[Token(Token = "0x6003034")]
		public void method_5()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_1;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_1;
			\u06ED\u07ECڪ\u060E u0737ߊ_u07F3_u087E = hvrforceGrabber.\u0737ߊ\u07F3\u087E;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = u0737ߊ_u07F3_u087E;
			this.method_28();
		}

		// Token: 0x06003035 RID: 12341 RVA: 0x00060180 File Offset: 0x0005E380
		[Address(RVA = "0x20AEF8C", Offset = "0x20AEF8C", VA = "0x20AEF8C")]
		[Token(Token = "0x6003035")]
		public void method_6()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_1;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_1;
			long u0737ߊ_u07F3_u087E = 1L;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = (\u06ED\u07ECڪ\u060E)u0737ߊ_u07F3_u087E;
			this.method_147();
		}

		// Token: 0x06003036 RID: 12342 RVA: 0x000601B4 File Offset: 0x0005E3B4
		[Address(RVA = "0x20AF0CC", Offset = "0x20AF0CC", VA = "0x20AF0CC")]
		[Token(Token = "0x6003036")]
		public void method_7()
		{
			this.method_54();
		}

		// Token: 0x06003037 RID: 12343 RVA: 0x00060118 File Offset: 0x0005E318
		[Address(RVA = "0x20AF1BC", Offset = "0x20AF1BC", VA = "0x20AF1BC")]
		[Token(Token = "0x6003037")]
		public void method_8(float float_0)
		{
		}

		// Token: 0x06003038 RID: 12344 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20AF214", Offset = "0x20AF214", VA = "0x20AF214")]
		[Token(Token = "0x6003038")]
		public void method_9()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x06003039 RID: 12345 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20AF2A0", Offset = "0x20AF2A0", VA = "0x20AF2A0")]
		[Token(Token = "0x6003039")]
		public void method_10()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x0600303A RID: 12346 RVA: 0x000601F0 File Offset: 0x0005E3F0
		[Address(RVA = "0x20AF32C", Offset = "0x20AF32C", VA = "0x20AF32C")]
		[Token(Token = "0x600303A")]
		public void method_11()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
		}

		// Token: 0x0600303B RID: 12347 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20AF4EC", Offset = "0x20AF4EC", VA = "0x20AF4EC")]
		[Token(Token = "0x600303B")]
		public void method_12()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x0600303C RID: 12348 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20AF578", Offset = "0x20AF578", VA = "0x20AF578")]
		[Token(Token = "0x600303C")]
		private void method_13()
		{
		}

		// Token: 0x0600303D RID: 12349 RVA: 0x000602AC File Offset: 0x0005E4AC
		[Address(RVA = "0x20AF624", Offset = "0x20AF624", VA = "0x20AF624")]
		[Token(Token = "0x600303D")]
		public void method_14()
		{
			HVRPlayerInputs hvrplayerInputs = this.hvrplayerInputs_0;
			ࢭ٩աՏ u05EC_u06ECڹ_u064F = hvrplayerInputs.\u05EC\u06ECڹ\u064F;
			hvrplayerInputs.\u05EC\u06ECڹ\u064F = u05EC_u06ECڹ_u064F;
			this.method_26();
		}

		// Token: 0x0600303E RID: 12350 RVA: 0x000602D4 File Offset: 0x0005E4D4
		[Address(RVA = "0x20AF6FC", Offset = "0x20AF6FC", VA = "0x20AF6FC")]
		[Token(Token = "0x600303E")]
		private void method_15()
		{
			this.hvrplayerController_0;
			HVRPlayerController[] array = UnityEngine.Object.FindObjectsOfType<HVRPlayerController>();
			Func<HVRPlayerController, bool> func;
			if (DemoUIManager.<>c.<>9__21_0 == null)
			{
				DemoUIManager.<>c.<>9__21_0 = func;
			}
			Enumerable.FirstOrDefault<HVRPlayerController>(array, func);
			this.hvrcameraRig_0;
			this.hvrplayerInputs_0;
			this.hvrjointHand_0;
			Func<HVRHandGrabber, bool> func2;
			if (DemoUIManager.<>c.<>9__21_1 == null)
			{
				DemoUIManager.<>c.<>9__21_1 = func2;
			}
			HVRHandGrabber[] array2;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array2, func2);
			if (hvrhandGrabber != null)
			{
				hvrhandGrabber.GetComponent<HVRJointHand>();
				return;
			}
			this.hvrjointHand_1;
			Func<HVRHandGrabber, bool> func3;
			if (DemoUIManager.<>c.<>9__21_2 == null)
			{
				DemoUIManager.<>c.<>9__21_2 = func3;
			}
			HVRHandGrabber[] array3;
			HVRHandGrabber hvrhandGrabber2 = Enumerable.FirstOrDefault<HVRHandGrabber>(array3, func3);
			if (hvrhandGrabber2 != null)
			{
				hvrhandGrabber2.GetComponent<HVRJointHand>();
				return;
			}
			Transform transform;
			Transform parent = transform.parent;
			this.transform_0 = parent;
			this.hvrjointHand_1;
			Transform parent2 = this.hvrjointHand_1.transform.parent;
			this.transform_1 = parent2;
			this.method_133();
			this.method_141();
			Toggle toggle = this.toggle_1;
			bool lineGrabTriggerLoose = HVRSettings.Instance.LineGrabTriggerLoose;
			toggle.isOn = lineGrabTriggerLoose;
			UnityAction<bool> unityAction;
			this.toggle_0.onValueChanged.AddListener(unityAction);
			Transform transform2;
			HVRForceGrabber[] componentsInChildren = transform2.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func4;
			if (DemoUIManager.<>c.<>9__21_3 == null)
			{
				DemoUIManager.<>c.<>9__21_3 = func4;
			}
			HVRForceGrabber hvrforceGrabber = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren, func4);
			this.hvrforceGrabber_0 = hvrforceGrabber;
			HVRForceGrabber[] componentsInChildren2 = base.transform.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func5;
			if (DemoUIManager.<>c.<>9__21_4 == null)
			{
				DemoUIManager.<>c.<>9__21_4 = func5;
			}
			HVRForceGrabber hvrforceGrabber2 = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren2, func5);
			this.hvrforceGrabber_1 = hvrforceGrabber2;
			this.method_48();
			this.method_71();
		}

		// Token: 0x0600303F RID: 12351 RVA: 0x00060104 File Offset: 0x0005E304
		[Address(RVA = "0x20B04E8", Offset = "0x20B04E8", VA = "0x20B04E8")]
		[Token(Token = "0x600303F")]
		public void method_16()
		{
			this.method_21();
		}

		// Token: 0x06003040 RID: 12352 RVA: 0x00060464 File Offset: 0x0005E664
		[Address(RVA = "0x20B0530", Offset = "0x20B0530", VA = "0x20B0530")]
		[Token(Token = "0x6003040")]
		public void method_17()
		{
			HVRPlayerInputs hvrplayerInputs = this.hvrplayerInputs_0;
			ࢭ٩աՏ u05EC_u06ECڹ_u064F = hvrplayerInputs.\u05EC\u06ECڹ\u064F;
			hvrplayerInputs.\u05EC\u06ECڹ\u064F = u05EC_u06ECڹ_u064F;
			this.method_135();
		}

		// Token: 0x06003041 RID: 12353 RVA: 0x0006048C File Offset: 0x0005E68C
		[Address(RVA = "0x20B0600", Offset = "0x20B0600", VA = "0x20B0600")]
		[Token(Token = "0x6003041")]
		public void method_18()
		{
			this.method_3();
		}

		// Token: 0x06003042 RID: 12354 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B0640", Offset = "0x20B0640", VA = "0x20B0640")]
		[Token(Token = "0x6003042")]
		private void method_19()
		{
		}

		// Token: 0x06003043 RID: 12355 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B06EC", Offset = "0x20B06EC", VA = "0x20B06EC")]
		[Token(Token = "0x6003043")]
		private void method_20()
		{
		}

		// Token: 0x06003044 RID: 12356 RVA: 0x00060128 File Offset: 0x0005E328
		[Address(RVA = "0x20AEBA0", Offset = "0x20AEBA0", VA = "0x20AEBA0")]
		[Token(Token = "0x6003044")]
		private void method_21()
		{
		}

		// Token: 0x06003045 RID: 12357 RVA: 0x000604A0 File Offset: 0x0005E6A0
		[Address(RVA = "0x20B0798", Offset = "0x20B0798", VA = "0x20B0798")]
		[Token(Token = "0x6003045")]
		public void method_22()
		{
			HVRPlayerInputs hvrplayerInputs = this.hvrplayerInputs_0;
			ࢭ٩աՏ u05EC_u06ECڹ_u064F = hvrplayerInputs.\u05EC\u06ECڹ\u064F;
			hvrplayerInputs.\u05EC\u06ECڹ\u064F = u05EC_u06ECڹ_u064F;
			this.method_102();
		}

		// Token: 0x06003046 RID: 12358 RVA: 0x00060104 File Offset: 0x0005E304
		[Address(RVA = "0x20B0870", Offset = "0x20B0870", VA = "0x20B0870")]
		[Token(Token = "0x6003046")]
		public void method_23()
		{
			this.method_21();
		}

		// Token: 0x06003047 RID: 12359 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B08B8", Offset = "0x20B08B8", VA = "0x20B08B8")]
		[Token(Token = "0x6003047")]
		public void method_24(float float_0)
		{
		}

		// Token: 0x06003048 RID: 12360 RVA: 0x000604D8 File Offset: 0x0005E6D8
		[Address(RVA = "0x20B0910", Offset = "0x20B0910", VA = "0x20B0910")]
		[Token(Token = "0x6003048")]
		public void method_25()
		{
			this.method_133();
		}

		// Token: 0x06003049 RID: 12361 RVA: 0x00060138 File Offset: 0x0005E338
		[Address(RVA = "0x20AF650", Offset = "0x20AF650", VA = "0x20AF650")]
		[Token(Token = "0x6003049")]
		private void method_26()
		{
		}

		// Token: 0x0600304A RID: 12362 RVA: 0x000604EC File Offset: 0x0005E6EC
		[Address(RVA = "0x20B0950", Offset = "0x20B0950", VA = "0x20B0950")]
		[Token(Token = "0x600304A")]
		public void method_27()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_0;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_0;
			long u0737ߊ_u07F3_u087E = 1L;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = (\u06ED\u07ECڪ\u060E)u0737ߊ_u07F3_u087E;
			this.method_76();
		}

		// Token: 0x0600304B RID: 12363 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20AEEE0", Offset = "0x20AEEE0", VA = "0x20AEEE0")]
		[Token(Token = "0x600304B")]
		private void method_28()
		{
		}

		// Token: 0x0600304C RID: 12364 RVA: 0x00060104 File Offset: 0x0005E304
		[Address(RVA = "0x20B0A90", Offset = "0x20B0A90", VA = "0x20B0A90")]
		[Token(Token = "0x600304C")]
		public void method_29()
		{
			this.method_21();
		}

		// Token: 0x0600304D RID: 12365 RVA: 0x00060520 File Offset: 0x0005E720
		[Address(RVA = "0x20B0ACC", Offset = "0x20B0ACC", VA = "0x20B0ACC")]
		[Token(Token = "0x600304D")]
		private void method_30()
		{
			long num = 1L;
			HVRPlayerController exists = this.hvrplayerController_0;
			if (num != 0L)
			{
			}
			exists;
			if (num != 0L)
			{
			}
			HVRPlayerController[] array = UnityEngine.Object.FindObjectsOfType<HVRPlayerController>();
			Func<HVRPlayerController, bool> func;
			if (DemoUIManager.<>c.<>9__21_0 == null)
			{
				DemoUIManager.<>c.<>9__21_0 = func;
			}
			Enumerable.FirstOrDefault<HVRPlayerController>(array, func);
			this.hvrcameraRig_0;
			this.hvrplayerInputs_0;
			this.hvrjointHand_0;
			DemoUIManager.<>c <>;
			Func<HVRHandGrabber, bool> func2;
			if (DemoUIManager.<>c.<>9__21_1 == null)
			{
				<> = DemoUIManager.<>c.<>9;
				DemoUIManager.<>c.<>9__21_1 = func2;
			}
			HVRHandGrabber[] array2;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array2, func2);
			if (hvrhandGrabber != null)
			{
				hvrhandGrabber.GetComponent<HVRJointHand>();
				return;
			}
			this.hvrjointHand_1;
			Func<HVRHandGrabber, bool> func3;
			if (<> == null)
			{
				DemoUIManager.<>c.<>9__21_2 = func3;
			}
			HVRHandGrabber[] array3;
			HVRHandGrabber hvrhandGrabber2 = Enumerable.FirstOrDefault<HVRHandGrabber>(array3, func3);
			if (hvrhandGrabber2 != null)
			{
				hvrhandGrabber2.GetComponent<HVRJointHand>();
				return;
			}
			Transform transform;
			Transform parent = transform.parent;
			this.transform_0 = parent;
			this.hvrjointHand_1;
			Transform parent2 = this.hvrjointHand_1.transform.parent;
			this.transform_1 = parent2;
			this.method_154();
			this.method_141();
			Toggle toggle = this.toggle_1;
			bool lineGrabTriggerLoose = HVRSettings.Instance.LineGrabTriggerLoose;
			toggle.isOn = lineGrabTriggerLoose;
			UnityAction<bool> unityAction;
			this.toggle_0.onValueChanged.AddListener(unityAction);
			UnityAction<bool> unityAction2;
			this.toggle_1.onValueChanged.AddListener(unityAction2);
			Transform transform2;
			HVRForceGrabber[] componentsInChildren = transform2.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func4;
			if (DemoUIManager.<>c.<>9__21_3 == null)
			{
				DemoUIManager.<>c.<>9__21_3 = func4;
			}
			HVRForceGrabber hvrforceGrabber = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren, func4);
			this.hvrforceGrabber_0 = hvrforceGrabber;
			HVRForceGrabber[] componentsInChildren2 = base.transform.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func5;
			if (DemoUIManager.<>c.<>9__21_4 == null)
			{
				DemoUIManager.<>c.<>9__21_4 = func5;
			}
			Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren2, func5);
			this.method_20();
			this.method_57();
		}

		// Token: 0x0600304E RID: 12366 RVA: 0x000606CC File Offset: 0x0005E8CC
		[Address(RVA = "0x20B1760", Offset = "0x20B1760", VA = "0x20B1760")]
		[Token(Token = "0x600304E")]
		public void method_31()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
			bool flag = this.bool_0;
			this.bool_0 = flag;
		}

		// Token: 0x0600304F RID: 12367 RVA: 0x00060788 File Offset: 0x0005E988
		[Address(RVA = "0x20B1920", Offset = "0x20B1920", VA = "0x20B1920")]
		[Token(Token = "0x600304F")]
		private void method_32(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x06003050 RID: 12368 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x20B1954", Offset = "0x20B1954", VA = "0x20B1954")]
		[Token(Token = "0x6003050")]
		public DemoUIManager()
		{
		}

		// Token: 0x06003051 RID: 12369 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20B195C", Offset = "0x20B195C", VA = "0x20B195C")]
		[Token(Token = "0x6003051")]
		public void method_33()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x06003052 RID: 12370 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B19E8", Offset = "0x20B19E8", VA = "0x20B19E8")]
		[Token(Token = "0x6003052")]
		public void method_34(float float_0)
		{
		}

		// Token: 0x06003053 RID: 12371 RVA: 0x000606CC File Offset: 0x0005E8CC
		[Address(RVA = "0x20B1A40", Offset = "0x20B1A40", VA = "0x20B1A40")]
		[Token(Token = "0x6003053")]
		public void method_35()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
			bool flag = this.bool_0;
			this.bool_0 = flag;
		}

		// Token: 0x06003054 RID: 12372 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B1C00", Offset = "0x20B1C00", VA = "0x20B1C00")]
		[Token(Token = "0x6003054")]
		public void method_36(float float_0)
		{
		}

		// Token: 0x06003055 RID: 12373 RVA: 0x00060104 File Offset: 0x0005E304
		[Address(RVA = "0x20B1C58", Offset = "0x20B1C58", VA = "0x20B1C58")]
		[Token(Token = "0x6003055")]
		public void method_37()
		{
			this.method_21();
		}

		// Token: 0x06003056 RID: 12374 RVA: 0x00060788 File Offset: 0x0005E988
		[Address(RVA = "0x20B1C9C", Offset = "0x20B1C9C", VA = "0x20B1C9C")]
		[Token(Token = "0x6003056")]
		private void method_38(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x06003057 RID: 12375 RVA: 0x0006079C File Offset: 0x0005E99C
		[Address(RVA = "0x20B1CD0", Offset = "0x20B1CD0", VA = "0x20B1CD0")]
		[Token(Token = "0x6003057")]
		public void method_39(bool bool_1)
		{
		}

		// Token: 0x06003058 RID: 12376 RVA: 0x00060138 File Offset: 0x0005E338
		[Address(RVA = "0x20B1CF4", Offset = "0x20B1CF4", VA = "0x20B1CF4")]
		[Token(Token = "0x6003058")]
		private void method_40()
		{
		}

		// Token: 0x06003059 RID: 12377 RVA: 0x000601B4 File Offset: 0x0005E3B4
		[Address(RVA = "0x20B1DA0", Offset = "0x20B1DA0", VA = "0x20B1DA0")]
		[Token(Token = "0x6003059")]
		public void method_41()
		{
			this.method_54();
		}

		// Token: 0x0600305A RID: 12378 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20B1DE8", Offset = "0x20B1DE8", VA = "0x20B1DE8")]
		[Token(Token = "0x600305A")]
		public void method_42()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x0600305B RID: 12379 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20B1E74", Offset = "0x20B1E74", VA = "0x20B1E74")]
		[Token(Token = "0x600305B")]
		public void method_43()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x0600305C RID: 12380 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B1F00", Offset = "0x20B1F00", VA = "0x20B1F00")]
		[Token(Token = "0x600305C")]
		private void method_44()
		{
		}

		// Token: 0x0600305D RID: 12381 RVA: 0x00060788 File Offset: 0x0005E988
		[Address(RVA = "0x20B1FAC", Offset = "0x20B1FAC", VA = "0x20B1FAC")]
		[Token(Token = "0x600305D")]
		private void method_45(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x0600305E RID: 12382 RVA: 0x000607AC File Offset: 0x0005E9AC
		[Address(RVA = "0x20B1FE0", Offset = "0x20B1FE0", VA = "0x20B1FE0")]
		[Token(Token = "0x600305E")]
		private void Start()
		{
			long num = 1L;
			HVRPlayerController exists = this.hvrplayerController_0;
			if (num != 0L)
			{
			}
			exists;
			if (num != 0L)
			{
			}
			HVRPlayerController[] array = UnityEngine.Object.FindObjectsOfType<HVRPlayerController>();
			Func<HVRPlayerController, bool> func;
			if (DemoUIManager.<>c.<>9__21_0 == null)
			{
				DemoUIManager.<>c.<>9__21_0 = func;
			}
			Enumerable.FirstOrDefault<HVRPlayerController>(array, func);
			this.hvrcameraRig_0;
			this.hvrplayerInputs_0;
			this.hvrjointHand_0;
			Func<HVRHandGrabber, bool> func2;
			if (DemoUIManager.<>c.<>9__21_1 == null)
			{
				DemoUIManager.<>c.<>9__21_1 = func2;
			}
			HVRHandGrabber[] array2;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array2, func2);
			if (hvrhandGrabber != null)
			{
				hvrhandGrabber.GetComponent<HVRJointHand>();
				return;
			}
			this.hvrjointHand_1;
			Func<HVRHandGrabber, bool> func3;
			if (DemoUIManager.<>c.<>9__21_2 == null)
			{
				DemoUIManager.<>c.<>9__21_2 = func3;
			}
			HVRHandGrabber[] array3;
			HVRHandGrabber hvrhandGrabber2 = Enumerable.FirstOrDefault<HVRHandGrabber>(array3, func3);
			if (hvrhandGrabber2 != null)
			{
				hvrhandGrabber2.GetComponent<HVRJointHand>();
				return;
			}
			Transform transform;
			Transform parent = transform.parent;
			this.transform_0 = parent;
			this.hvrjointHand_1;
			Transform parent2 = this.hvrjointHand_1.transform.parent;
			this.transform_1 = parent2;
			this.method_21();
			this.method_26();
			Toggle toggle = this.toggle_1;
			bool lineGrabTriggerLoose = HVRSettings.Instance.LineGrabTriggerLoose;
			toggle.isOn = lineGrabTriggerLoose;
			UnityAction<bool> unityAction;
			this.toggle_0.onValueChanged.AddListener(unityAction);
			UnityAction<bool> unityAction2;
			this.toggle_1.onValueChanged.AddListener(unityAction2);
			Transform transform2;
			HVRForceGrabber[] componentsInChildren = transform2.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func4;
			if (DemoUIManager.<>c.<>9__21_3 == null)
			{
				DemoUIManager.<>c.<>9__21_3 = func4;
			}
			HVRForceGrabber hvrforceGrabber = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren, func4);
			this.hvrforceGrabber_0 = hvrforceGrabber;
			HVRForceGrabber[] componentsInChildren2 = base.transform.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func5;
			if (DemoUIManager.<>c.<>9__21_4 == null)
			{
				DemoUIManager.<>c.<>9__21_4 = func5;
			}
			HVRForceGrabber hvrforceGrabber2 = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren2, func5);
			this.hvrforceGrabber_1 = hvrforceGrabber2;
			this.method_160();
			this.method_28();
		}

		// Token: 0x0600305F RID: 12383 RVA: 0x00060788 File Offset: 0x0005E988
		[Address(RVA = "0x20B2BC8", Offset = "0x20B2BC8", VA = "0x20B2BC8")]
		[Token(Token = "0x600305F")]
		private void method_46(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x06003060 RID: 12384 RVA: 0x00060788 File Offset: 0x0005E988
		[Address(RVA = "0x20B2BFC", Offset = "0x20B2BFC", VA = "0x20B2BFC")]
		[Token(Token = "0x6003060")]
		private void method_47(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x06003061 RID: 12385 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B0390", Offset = "0x20B0390", VA = "0x20B0390")]
		[Token(Token = "0x6003061")]
		private void method_48()
		{
		}

		// Token: 0x06003062 RID: 12386 RVA: 0x0006095C File Offset: 0x0005EB5C
		[Address(RVA = "0x20B2C30", Offset = "0x20B2C30", VA = "0x20B2C30")]
		[Token(Token = "0x6003062")]
		public void method_49(bool bool_1)
		{
			HVRPlayerController hvrplayerController = this.hvrplayerController_0;
			long ۵٧Զ߉ = 1L;
			hvrplayerController.۵٧Զ߉ = (\u065AԎٶ\u0896)۵٧Զ߉;
		}

		// Token: 0x06003063 RID: 12387 RVA: 0x000606CC File Offset: 0x0005E8CC
		[Address(RVA = "0x20B2C50", Offset = "0x20B2C50", VA = "0x20B2C50")]
		[Token(Token = "0x6003063")]
		public void method_50()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
			bool flag = this.bool_0;
			this.bool_0 = flag;
		}

		// Token: 0x06003064 RID: 12388 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B2E10", Offset = "0x20B2E10", VA = "0x20B2E10")]
		[Token(Token = "0x6003064")]
		public void method_51(float float_0)
		{
		}

		// Token: 0x06003065 RID: 12389 RVA: 0x0006097C File Offset: 0x0005EB7C
		[Address(RVA = "0x20B2E68", Offset = "0x20B2E68", VA = "0x20B2E68")]
		[Token(Token = "0x6003065")]
		public void method_52()
		{
			this.method_137();
		}

		// Token: 0x06003066 RID: 12390 RVA: 0x00060990 File Offset: 0x0005EB90
		[Address(RVA = "0x20B2F58", Offset = "0x20B2F58", VA = "0x20B2F58")]
		[Token(Token = "0x6003066")]
		public void method_53()
		{
			HVRPlayerInputs hvrplayerInputs = this.hvrplayerInputs_0;
			ࢭ٩աՏ u05EC_u06ECڹ_u064F = hvrplayerInputs.\u05EC\u06ECڹ\u064F;
			hvrplayerInputs.\u05EC\u06ECڹ\u064F = u05EC_u06ECڹ_u064F;
			this.method_123();
		}

		// Token: 0x06003067 RID: 12391 RVA: 0x00060128 File Offset: 0x0005E328
		[Token(Token = "0x6003067")]
		[Address(RVA = "0x20AF110", Offset = "0x20AF110", VA = "0x20AF110")]
		private void method_54()
		{
		}

		// Token: 0x06003068 RID: 12392 RVA: 0x000604D8 File Offset: 0x0005E6D8
		[Token(Token = "0x6003068")]
		[Address(RVA = "0x20B302C", Offset = "0x20B302C", VA = "0x20B302C")]
		public void method_55()
		{
			this.method_133();
		}

		// Token: 0x06003069 RID: 12393 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20B306C", Offset = "0x20B306C", VA = "0x20B306C")]
		[Token(Token = "0x6003069")]
		public void method_56()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x0600306A RID: 12394 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x600306A")]
		[Address(RVA = "0x20B16B4", Offset = "0x20B16B4", VA = "0x20B16B4")]
		private void method_57()
		{
		}

		// Token: 0x0600306B RID: 12395 RVA: 0x000601F0 File Offset: 0x0005E3F0
		[Address(RVA = "0x20B30F8", Offset = "0x20B30F8", VA = "0x20B30F8")]
		[Token(Token = "0x600306B")]
		public void method_58()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
		}

		// Token: 0x0600306C RID: 12396 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B32B8", Offset = "0x20B32B8", VA = "0x20B32B8")]
		[Token(Token = "0x600306C")]
		private void method_59()
		{
		}

		// Token: 0x0600306D RID: 12397 RVA: 0x000609B8 File Offset: 0x0005EBB8
		[Token(Token = "0x600306D")]
		[Address(RVA = "0x20B3364", Offset = "0x20B3364", VA = "0x20B3364")]
		private void method_60()
		{
			long num = 1L;
			HVRPlayerController exists = this.hvrplayerController_0;
			if (num != 0L)
			{
			}
			exists;
			if (num != 0L)
			{
			}
			HVRPlayerController[] array = UnityEngine.Object.FindObjectsOfType<HVRPlayerController>();
			Func<HVRPlayerController, bool> func;
			if (DemoUIManager.<>c.<>9__21_0 == null)
			{
				DemoUIManager.<>c.<>9__21_0 = func;
			}
			Enumerable.FirstOrDefault<HVRPlayerController>(array, func);
			this.hvrcameraRig_0;
			this.hvrplayerInputs_0;
			this.hvrjointHand_0;
			Func<HVRHandGrabber, bool> func2;
			if (DemoUIManager.<>c.<>9__21_1 == null)
			{
				DemoUIManager.<>c.<>9__21_1 = func2;
			}
			HVRHandGrabber[] array2;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array2, func2);
			if (hvrhandGrabber != null)
			{
				hvrhandGrabber.GetComponent<HVRJointHand>();
				return;
			}
			this.hvrjointHand_1;
			Func<HVRHandGrabber, bool> func3;
			if (DemoUIManager.<>c.<>9__21_2 == null)
			{
				DemoUIManager.<>c.<>9__21_2 = func3;
			}
			HVRHandGrabber[] array3;
			HVRHandGrabber hvrhandGrabber2 = Enumerable.FirstOrDefault<HVRHandGrabber>(array3, func3);
			if (hvrhandGrabber2 != null)
			{
				hvrhandGrabber2.GetComponent<HVRJointHand>();
				return;
			}
			Transform transform;
			Transform parent = transform.parent;
			this.transform_0 = parent;
			this.hvrjointHand_1;
			Transform parent2 = this.hvrjointHand_1.transform.parent;
			this.transform_1 = parent2;
			this.method_133();
			this.method_141();
			Toggle toggle = this.toggle_1;
			bool lineGrabTriggerLoose = HVRSettings.Instance.LineGrabTriggerLoose;
			toggle.isOn = lineGrabTriggerLoose;
			UnityAction<bool> unityAction;
			this.toggle_0.onValueChanged.AddListener(unityAction);
			UnityAction<bool> unityAction2;
			this.toggle_1.onValueChanged.AddListener(unityAction2);
			Transform transform2;
			HVRForceGrabber[] componentsInChildren = transform2.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func4;
			if (DemoUIManager.<>c.<>9__21_3 == null)
			{
				DemoUIManager.<>c.<>9__21_3 = func4;
			}
			HVRForceGrabber hvrforceGrabber = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren, func4);
			this.hvrforceGrabber_0 = hvrforceGrabber;
			HVRForceGrabber[] componentsInChildren2 = base.transform.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func5;
			if (DemoUIManager.<>c.<>9__21_4 == null)
			{
				DemoUIManager.<>c.<>9__21_4 = func5;
			}
			HVRForceGrabber hvrforceGrabber2 = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren2, func5);
			this.hvrforceGrabber_1 = hvrforceGrabber2;
			this.method_20();
			this.method_13();
		}

		// Token: 0x0600306E RID: 12398 RVA: 0x000604D8 File Offset: 0x0005E6D8
		[Token(Token = "0x600306E")]
		[Address(RVA = "0x20B3EA0", Offset = "0x20B3EA0", VA = "0x20B3EA0")]
		public void method_61()
		{
			this.method_133();
		}

		// Token: 0x0600306F RID: 12399 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Token(Token = "0x600306F")]
		[Address(RVA = "0x20B3EE0", Offset = "0x20B3EE0", VA = "0x20B3EE0")]
		public void method_62(float float_0)
		{
		}

		// Token: 0x06003070 RID: 12400 RVA: 0x00060B68 File Offset: 0x0005ED68
		[Token(Token = "0x6003070")]
		[Address(RVA = "0x20B3F38", Offset = "0x20B3F38", VA = "0x20B3F38")]
		public void method_63()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_1;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_1;
			long u0737ߊ_u07F3_u087E = 1L;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = (\u06ED\u07ECڪ\u060E)u0737ߊ_u07F3_u087E;
			this.method_57();
		}

		// Token: 0x06003071 RID: 12401 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B3FCC", Offset = "0x20B3FCC", VA = "0x20B3FCC")]
		[Token(Token = "0x6003071")]
		public void method_64(float float_0)
		{
		}

		// Token: 0x06003072 RID: 12402 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20B4024", Offset = "0x20B4024", VA = "0x20B4024")]
		[Token(Token = "0x6003072")]
		public void method_65()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x06003073 RID: 12403 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Token(Token = "0x6003073")]
		[Address(RVA = "0x20B40B0", Offset = "0x20B40B0", VA = "0x20B40B0")]
		public void method_66(float float_0)
		{
		}

		// Token: 0x06003074 RID: 12404 RVA: 0x00060B9C File Offset: 0x0005ED9C
		[Token(Token = "0x6003074")]
		[Address(RVA = "0x20B4108", Offset = "0x20B4108", VA = "0x20B4108")]
		public void method_67()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_0;
			exists;
			this.method_128();
		}

		// Token: 0x06003075 RID: 12405 RVA: 0x00060BC0 File Offset: 0x0005EDC0
		[Address(RVA = "0x20B4244", Offset = "0x20B4244", VA = "0x20B4244")]
		[Token(Token = "0x6003075")]
		public void method_68()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_0;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_0;
			\u06ED\u07ECڪ\u060E u0737ߊ_u07F3_u087E = hvrforceGrabber.\u0737ߊ\u07F3\u087E;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = u0737ߊ_u07F3_u087E;
			this.method_89();
		}

		// Token: 0x06003076 RID: 12406 RVA: 0x000606CC File Offset: 0x0005E8CC
		[Token(Token = "0x6003076")]
		[Address(RVA = "0x20B438C", Offset = "0x20B438C", VA = "0x20B438C")]
		public void method_69()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
			bool flag = this.bool_0;
			this.bool_0 = flag;
		}

		// Token: 0x06003077 RID: 12407 RVA: 0x00060138 File Offset: 0x0005E338
		[Token(Token = "0x6003077")]
		[Address(RVA = "0x20B454C", Offset = "0x20B454C", VA = "0x20B454C")]
		private void method_70()
		{
		}

		// Token: 0x06003078 RID: 12408 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x6003078")]
		[Address(RVA = "0x20B043C", Offset = "0x20B043C", VA = "0x20B043C")]
		private void method_71()
		{
		}

		// Token: 0x06003079 RID: 12409 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x6003079")]
		[Address(RVA = "0x20B45F8", Offset = "0x20B45F8", VA = "0x20B45F8")]
		private void method_72()
		{
		}

		// Token: 0x0600307A RID: 12410 RVA: 0x00060148 File Offset: 0x0005E348
		[Address(RVA = "0x20B46A4", Offset = "0x20B46A4", VA = "0x20B46A4")]
		[Token(Token = "0x600307A")]
		public void method_73()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_1;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_1;
			\u06ED\u07ECڪ\u060E u0737ߊ_u07F3_u087E = hvrforceGrabber.\u0737ߊ\u07F3\u087E;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = u0737ߊ_u07F3_u087E;
			this.method_28();
		}

		// Token: 0x0600307B RID: 12411 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B4740", Offset = "0x20B4740", VA = "0x20B4740")]
		[Token(Token = "0x600307B")]
		public void method_74(float float_0)
		{
		}

		// Token: 0x0600307C RID: 12412 RVA: 0x000601F0 File Offset: 0x0005E3F0
		[Token(Token = "0x600307C")]
		[Address(RVA = "0x20B4798", Offset = "0x20B4798", VA = "0x20B4798")]
		public void method_75()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
		}

		// Token: 0x0600307D RID: 12413 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x600307D")]
		[Address(RVA = "0x20B09E4", Offset = "0x20B09E4", VA = "0x20B09E4")]
		private void method_76()
		{
		}

		// Token: 0x0600307E RID: 12414 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Token(Token = "0x600307E")]
		[Address(RVA = "0x20B4954", Offset = "0x20B4954", VA = "0x20B4954")]
		public void method_77(float float_0)
		{
		}

		// Token: 0x0600307F RID: 12415 RVA: 0x00060BF8 File Offset: 0x0005EDF8
		[Address(RVA = "0x20B49AC", Offset = "0x20B49AC", VA = "0x20B49AC")]
		[Token(Token = "0x600307F")]
		public void method_78()
		{
			HVRPlayerInputs hvrplayerInputs = this.hvrplayerInputs_0;
			ࢭ٩աՏ u05EC_u06ECڹ_u064F = hvrplayerInputs.\u05EC\u06ECڹ\u064F;
			hvrplayerInputs.\u05EC\u06ECڹ\u064F = u05EC_u06ECڹ_u064F;
			this.method_70();
		}

		// Token: 0x06003080 RID: 12416 RVA: 0x00060C20 File Offset: 0x0005EE20
		[Token(Token = "0x6003080")]
		[Address(RVA = "0x20B49D4", Offset = "0x20B49D4", VA = "0x20B49D4")]
		public void method_79()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_0;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_0;
			\u06ED\u07ECڪ\u060E u0737ߊ_u07F3_u087E = hvrforceGrabber.\u0737ߊ\u07F3\u087E;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = u0737ߊ_u07F3_u087E;
			this.method_160();
		}

		// Token: 0x06003081 RID: 12417 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Token(Token = "0x6003081")]
		[Address(RVA = "0x20B4A70", Offset = "0x20B4A70", VA = "0x20B4A70")]
		public void method_80(float float_0)
		{
		}

		// Token: 0x06003082 RID: 12418 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Token(Token = "0x6003082")]
		[Address(RVA = "0x20B4AC8", Offset = "0x20B4AC8", VA = "0x20B4AC8")]
		public void method_81()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x06003083 RID: 12419 RVA: 0x00060C58 File Offset: 0x0005EE58
		[Address(RVA = "0x20B4B54", Offset = "0x20B4B54", VA = "0x20B4B54")]
		[Token(Token = "0x6003083")]
		public void method_82()
		{
			HVRPlayerInputs hvrplayerInputs = this.hvrplayerInputs_0;
			ࢭ٩աՏ u05EC_u06ECڹ_u064F = hvrplayerInputs.\u05EC\u06ECڹ\u064F;
			hvrplayerInputs.\u05EC\u06ECڹ\u064F = u05EC_u06ECڹ_u064F;
			this.method_4();
		}

		// Token: 0x06003084 RID: 12420 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B4B84", Offset = "0x20B4B84", VA = "0x20B4B84")]
		[Token(Token = "0x6003084")]
		private void method_83()
		{
		}

		// Token: 0x06003085 RID: 12421 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B4C30", Offset = "0x20B4C30", VA = "0x20B4C30")]
		[Token(Token = "0x6003085")]
		private void method_84()
		{
		}

		// Token: 0x06003086 RID: 12422 RVA: 0x0006079C File Offset: 0x0005E99C
		[Address(RVA = "0x20B4CDC", Offset = "0x20B4CDC", VA = "0x20B4CDC")]
		[Token(Token = "0x6003086")]
		public void method_85(bool bool_1)
		{
		}

		// Token: 0x06003087 RID: 12423 RVA: 0x00060788 File Offset: 0x0005E988
		[Address(RVA = "0x20B4D00", Offset = "0x20B4D00", VA = "0x20B4D00")]
		[Token(Token = "0x6003087")]
		private void method_86(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x06003088 RID: 12424 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B4D34", Offset = "0x20B4D34", VA = "0x20B4D34")]
		[Token(Token = "0x6003088")]
		public void method_87(float float_0)
		{
		}

		// Token: 0x06003089 RID: 12425 RVA: 0x000601F0 File Offset: 0x0005E3F0
		[Token(Token = "0x6003089")]
		[Address(RVA = "0x20B4D8C", Offset = "0x20B4D8C", VA = "0x20B4D8C")]
		public void method_88()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
		}

		// Token: 0x0600308A RID: 12426 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x600308A")]
		[Address(RVA = "0x20B42E0", Offset = "0x20B42E0", VA = "0x20B42E0")]
		private void method_89()
		{
		}

		// Token: 0x0600308B RID: 12427 RVA: 0x00060C80 File Offset: 0x0005EE80
		[Token(Token = "0x600308B")]
		[Address(RVA = "0x20B4F4C", Offset = "0x20B4F4C", VA = "0x20B4F4C")]
		public void method_90()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			Transform transform3;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
			bool flag = this.bool_0;
			this.bool_0 = flag;
		}

		// Token: 0x0600308C RID: 12428 RVA: 0x00060D30 File Offset: 0x0005EF30
		[Address(RVA = "0x20B510C", Offset = "0x20B510C", VA = "0x20B510C")]
		[Token(Token = "0x600308C")]
		public void method_91()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_1;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_1;
			long u0737ߊ_u07F3_u087E = 1L;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = (\u06ED\u07ECڪ\u060E)u0737ߊ_u07F3_u087E;
			this.method_19();
		}

		// Token: 0x0600308D RID: 12429 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B51A0", Offset = "0x20B51A0", VA = "0x20B51A0")]
		[Token(Token = "0x600308D")]
		public void method_92(float float_0)
		{
		}

		// Token: 0x0600308E RID: 12430 RVA: 0x000601B4 File Offset: 0x0005E3B4
		[Address(RVA = "0x20B51F8", Offset = "0x20B51F8", VA = "0x20B51F8")]
		[Token(Token = "0x600308E")]
		public void method_93()
		{
			this.method_54();
		}

		// Token: 0x0600308F RID: 12431 RVA: 0x0006079C File Offset: 0x0005E99C
		[Address(RVA = "0x20B5238", Offset = "0x20B5238", VA = "0x20B5238")]
		[Token(Token = "0x600308F")]
		public void method_94(bool bool_1)
		{
		}

		// Token: 0x06003090 RID: 12432 RVA: 0x0006079C File Offset: 0x0005E99C
		[Address(RVA = "0x20B525C", Offset = "0x20B525C", VA = "0x20B525C")]
		[Token(Token = "0x6003090")]
		public void method_95(bool bool_1)
		{
		}

		// Token: 0x06003091 RID: 12433 RVA: 0x00060D64 File Offset: 0x0005EF64
		[Address(RVA = "0x20B5278", Offset = "0x20B5278", VA = "0x20B5278")]
		[Token(Token = "0x6003091")]
		private void method_96()
		{
			long num = 1L;
			HVRPlayerController exists = this.hvrplayerController_0;
			if (num != 0L)
			{
			}
			exists;
			if (num != 0L)
			{
			}
			HVRPlayerController[] array = UnityEngine.Object.FindObjectsOfType<HVRPlayerController>();
			Func<HVRPlayerController, bool> func;
			if (DemoUIManager.<>c.<>9__21_0 == null)
			{
				DemoUIManager.<>c.<>9__21_0 = func;
			}
			Enumerable.FirstOrDefault<HVRPlayerController>(array, func);
			this.hvrcameraRig_0;
			this.hvrplayerInputs_0;
			this.hvrjointHand_0;
			Func<HVRHandGrabber, bool> func2;
			if (DemoUIManager.<>c.<>9__21_1 == null)
			{
				DemoUIManager.<>c.<>9__21_1 = func2;
			}
			HVRHandGrabber[] array2;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array2, func2);
			if (hvrhandGrabber != null)
			{
				hvrhandGrabber.GetComponent<HVRJointHand>();
				return;
			}
			this.hvrjointHand_1;
			Func<HVRHandGrabber, bool> func3;
			if (DemoUIManager.<>c.<>9__21_2 == null)
			{
				DemoUIManager.<>c.<>9__21_2 = func3;
			}
			HVRHandGrabber[] array3;
			HVRHandGrabber hvrhandGrabber2 = Enumerable.FirstOrDefault<HVRHandGrabber>(array3, func3);
			if (hvrhandGrabber2 != null)
			{
				hvrhandGrabber2.GetComponent<HVRJointHand>();
				return;
			}
			Transform transform;
			Transform parent = transform.parent;
			this.transform_0 = parent;
			this.hvrjointHand_1;
			Transform parent2 = this.hvrjointHand_1.transform.parent;
			this.transform_1 = parent2;
			this.method_133();
			this.method_141();
			Toggle toggle = this.toggle_1;
			bool lineGrabTriggerLoose = HVRSettings.Instance.LineGrabTriggerLoose;
			toggle.isOn = lineGrabTriggerLoose;
			UnityAction<bool> unityAction;
			this.toggle_0.onValueChanged.AddListener(unityAction);
			UnityAction<bool> unityAction2;
			this.toggle_1.onValueChanged.AddListener(unityAction2);
			Transform transform2;
			HVRForceGrabber[] componentsInChildren = transform2.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func4;
			if (DemoUIManager.<>c.<>9__21_3 == null)
			{
				DemoUIManager.<>c.<>9__21_3 = func4;
			}
			HVRForceGrabber hvrforceGrabber = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren, func4);
			this.hvrforceGrabber_0 = hvrforceGrabber;
			HVRForceGrabber[] componentsInChildren2 = base.transform.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func5;
			if (DemoUIManager.<>c.<>9__21_4 == null)
			{
				DemoUIManager.<>c.<>9__21_4 = func5;
			}
			HVRForceGrabber hvrforceGrabber2 = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren2, func5);
			this.hvrforceGrabber_1 = hvrforceGrabber2;
			this.method_151();
			this.method_84();
		}

		// Token: 0x06003092 RID: 12434 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B5E60", Offset = "0x20B5E60", VA = "0x20B5E60")]
		[Token(Token = "0x6003092")]
		private void method_97()
		{
		}

		// Token: 0x06003093 RID: 12435 RVA: 0x00060F14 File Offset: 0x0005F114
		[Address(RVA = "0x20B5F0C", Offset = "0x20B5F0C", VA = "0x20B5F0C")]
		[Token(Token = "0x6003093")]
		public void method_98()
		{
			HVRPlayerInputs hvrplayerInputs = this.hvrplayerInputs_0;
			ࢭ٩աՏ u05EC_u06ECڹ_u064F = hvrplayerInputs.\u05EC\u06ECڹ\u064F;
			hvrplayerInputs.\u05EC\u06ECڹ\u064F = u05EC_u06ECڹ_u064F;
			this.method_138();
		}

		// Token: 0x06003094 RID: 12436 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B5FE0", Offset = "0x20B5FE0", VA = "0x20B5FE0")]
		[Token(Token = "0x6003094")]
		private void method_99()
		{
		}

		// Token: 0x06003095 RID: 12437 RVA: 0x000606CC File Offset: 0x0005E8CC
		[Address(RVA = "0x20B608C", Offset = "0x20B608C", VA = "0x20B608C")]
		[Token(Token = "0x6003095")]
		public void method_100()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
			bool flag = this.bool_0;
			this.bool_0 = flag;
		}

		// Token: 0x06003096 RID: 12438 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Token(Token = "0x6003096")]
		[Address(RVA = "0x20B624C", Offset = "0x20B624C", VA = "0x20B624C")]
		public void method_101()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x06003097 RID: 12439 RVA: 0x00060138 File Offset: 0x0005E338
		[Token(Token = "0x6003097")]
		[Address(RVA = "0x20B07C4", Offset = "0x20B07C4", VA = "0x20B07C4")]
		private void method_102()
		{
		}

		// Token: 0x06003098 RID: 12440 RVA: 0x00060F3C File Offset: 0x0005F13C
		[Token(Token = "0x6003098")]
		[Address(RVA = "0x20B62D8", Offset = "0x20B62D8", VA = "0x20B62D8")]
		private void method_103()
		{
			long num = 1L;
			HVRPlayerController exists = this.hvrplayerController_0;
			if (num != 0L)
			{
			}
			exists;
			if (num != 0L)
			{
			}
			HVRPlayerController[] array = UnityEngine.Object.FindObjectsOfType<HVRPlayerController>();
			Func<HVRPlayerController, bool> func;
			if (DemoUIManager.<>c.<>9__21_0 == null)
			{
				DemoUIManager.<>c.<>9__21_0 = func;
			}
			Enumerable.FirstOrDefault<HVRPlayerController>(array, func);
			this.hvrcameraRig_0;
			this.hvrplayerInputs_0;
			this.hvrjointHand_0;
			Func<HVRHandGrabber, bool> func2;
			if (DemoUIManager.<>c.<>9__21_1 == null)
			{
				DemoUIManager.<>c.<>9__21_1 = func2;
			}
			HVRHandGrabber[] array2;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array2, func2);
			if (hvrhandGrabber != null)
			{
				hvrhandGrabber.GetComponent<HVRJointHand>();
				return;
			}
			this.hvrjointHand_1;
			Func<HVRHandGrabber, bool> func3;
			if (DemoUIManager.<>c.<>9__21_2 == null)
			{
				DemoUIManager.<>c.<>9__21_2 = func3;
			}
			HVRHandGrabber[] array3;
			HVRHandGrabber hvrhandGrabber2 = Enumerable.FirstOrDefault<HVRHandGrabber>(array3, func3);
			if (hvrhandGrabber2 != null)
			{
				hvrhandGrabber2.GetComponent<HVRJointHand>();
				return;
			}
			Transform transform;
			Transform parent = transform.parent;
			this.transform_0 = parent;
			this.hvrjointHand_1;
			Transform parent2 = this.hvrjointHand_1.transform.parent;
			this.transform_1 = parent2;
			this.method_137();
			this.method_102();
			Toggle toggle = this.toggle_1;
			bool lineGrabTriggerLoose = HVRSettings.Instance.LineGrabTriggerLoose;
			toggle.isOn = lineGrabTriggerLoose;
			UnityAction<bool> unityAction;
			this.toggle_0.onValueChanged.AddListener(unityAction);
			UnityAction<bool> unityAction2;
			this.toggle_1.onValueChanged.AddListener(unityAction2);
			Transform transform2;
			HVRForceGrabber[] componentsInChildren = transform2.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func4;
			if (DemoUIManager.<>c.<>9__21_3 == null)
			{
				DemoUIManager.<>c.<>9__21_3 = func4;
			}
			HVRForceGrabber hvrforceGrabber = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren, func4);
			this.hvrforceGrabber_0 = hvrforceGrabber;
			HVRForceGrabber[] componentsInChildren2 = base.transform.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func5;
			if (DemoUIManager.<>c.<>9__21_4 == null)
			{
				DemoUIManager.<>c.<>9__21_4 = func5;
			}
			HVRForceGrabber hvrforceGrabber2 = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren2, func5);
			this.hvrforceGrabber_1 = hvrforceGrabber2;
			this.method_97();
			this.method_147();
		}

		// Token: 0x06003099 RID: 12441 RVA: 0x000602AC File Offset: 0x0005E4AC
		[Address(RVA = "0x20B6E14", Offset = "0x20B6E14", VA = "0x20B6E14")]
		[Token(Token = "0x6003099")]
		public void method_104()
		{
			HVRPlayerInputs hvrplayerInputs = this.hvrplayerInputs_0;
			ࢭ٩աՏ u05EC_u06ECڹ_u064F = hvrplayerInputs.\u05EC\u06ECڹ\u064F;
			hvrplayerInputs.\u05EC\u06ECڹ\u064F = u05EC_u06ECڹ_u064F;
			this.method_26();
		}

		// Token: 0x0600309A RID: 12442 RVA: 0x000610EC File Offset: 0x0005F2EC
		[Address(RVA = "0x20B6E44", Offset = "0x20B6E44", VA = "0x20B6E44")]
		[Token(Token = "0x600309A")]
		public void method_105()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			this.hvrjointHand_1;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
			bool flag = this.bool_0;
			this.bool_0 = flag;
		}

		// Token: 0x0600309B RID: 12443 RVA: 0x00060788 File Offset: 0x0005E988
		[Address(RVA = "0x20B7004", Offset = "0x20B7004", VA = "0x20B7004")]
		[Token(Token = "0x600309B")]
		private void method_106(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x0600309C RID: 12444 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x600309C")]
		[Address(RVA = "0x20B7038", Offset = "0x20B7038", VA = "0x20B7038")]
		private void method_107()
		{
		}

		// Token: 0x0600309D RID: 12445 RVA: 0x00060788 File Offset: 0x0005E988
		[Token(Token = "0x600309D")]
		[Address(RVA = "0x20B70E4", Offset = "0x20B70E4", VA = "0x20B70E4")]
		private void method_108(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x0600309E RID: 12446 RVA: 0x000611A4 File Offset: 0x0005F3A4
		[Address(RVA = "0x20B7118", Offset = "0x20B7118", VA = "0x20B7118")]
		[Token(Token = "0x600309E")]
		public void method_109()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_1;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_1;
			\u06ED\u07ECڪ\u060E u0737ߊ_u07F3_u087E = hvrforceGrabber.\u0737ߊ\u07F3\u087E;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = u0737ߊ_u07F3_u087E;
			this.method_19();
		}

		// Token: 0x0600309F RID: 12447 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Token(Token = "0x600309F")]
		[Address(RVA = "0x20B71B4", Offset = "0x20B71B4", VA = "0x20B71B4")]
		public void method_110(float float_0)
		{
		}

		// Token: 0x060030A0 RID: 12448 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Token(Token = "0x60030A0")]
		[Address(RVA = "0x20B720C", Offset = "0x20B720C", VA = "0x20B720C")]
		public void method_111(float float_0)
		{
		}

		// Token: 0x060030A1 RID: 12449 RVA: 0x0006079C File Offset: 0x0005E99C
		[Token(Token = "0x60030A1")]
		[Address(RVA = "0x20B7264", Offset = "0x20B7264", VA = "0x20B7264")]
		public void method_112(bool bool_1)
		{
		}

		// Token: 0x060030A2 RID: 12450 RVA: 0x000611DC File Offset: 0x0005F3DC
		[Address(RVA = "0x20B7284", Offset = "0x20B7284", VA = "0x20B7284")]
		[Token(Token = "0x60030A2")]
		private void method_113()
		{
			long num = 1L;
			HVRPlayerController exists = this.hvrplayerController_0;
			if (num != 0L)
			{
			}
			exists;
			if (num != 0L)
			{
			}
			HVRPlayerController[] array = UnityEngine.Object.FindObjectsOfType<HVRPlayerController>();
			Func<HVRPlayerController, bool> func;
			if (DemoUIManager.<>c.<>9__21_0 == null)
			{
				DemoUIManager.<>c.<>9__21_0 = func;
			}
			Enumerable.FirstOrDefault<HVRPlayerController>(array, func);
			this.hvrcameraRig_0;
			this.hvrplayerInputs_0;
			this.hvrjointHand_0;
			Func<HVRHandGrabber, bool> func2;
			if (DemoUIManager.<>c.<>9__21_1 == null)
			{
				DemoUIManager.<>c.<>9__21_1 = func2;
			}
			HVRHandGrabber[] array2;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array2, func2);
			if (hvrhandGrabber != null)
			{
				hvrhandGrabber.GetComponent<HVRJointHand>();
				return;
			}
			this.hvrjointHand_1;
			Func<HVRHandGrabber, bool> func3;
			if (DemoUIManager.<>c.<>9__21_2 == null)
			{
				DemoUIManager.<>c.<>9__21_2 = func3;
			}
			HVRHandGrabber[] array3;
			HVRHandGrabber hvrhandGrabber2 = Enumerable.FirstOrDefault<HVRHandGrabber>(array3, func3);
			if (hvrhandGrabber2 != null)
			{
				hvrhandGrabber2.GetComponent<HVRJointHand>();
				return;
			}
			Transform transform;
			Transform parent = transform.parent;
			this.transform_0 = parent;
			this.hvrjointHand_1;
			Transform parent2 = this.hvrjointHand_1.transform.parent;
			this.transform_1 = parent2;
			this.method_54();
			this.method_123();
			Toggle toggle = this.toggle_1;
			bool lineGrabTriggerLoose = HVRSettings.Instance.LineGrabTriggerLoose;
			toggle.isOn = lineGrabTriggerLoose;
			UnityAction<bool> unityAction;
			this.toggle_0.onValueChanged.AddListener(unityAction);
			UnityAction<bool> unityAction2;
			this.toggle_1.onValueChanged.AddListener(unityAction2);
			Transform transform2;
			HVRForceGrabber[] componentsInChildren = transform2.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func4;
			if (DemoUIManager.<>c.<>9__21_3 == null)
			{
				DemoUIManager.<>c.<>9__21_3 = func4;
			}
			HVRForceGrabber hvrforceGrabber = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren, func4);
			this.hvrforceGrabber_0 = hvrforceGrabber;
			HVRForceGrabber[] componentsInChildren2 = base.transform.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func5;
			if (DemoUIManager.<>c.<>9__21_4 == null)
			{
				DemoUIManager.<>c.<>9__21_4 = func5;
			}
			HVRForceGrabber hvrforceGrabber2 = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren2, func5);
			this.hvrforceGrabber_1 = hvrforceGrabber2;
			this.method_107();
			this.method_120();
		}

		// Token: 0x060030A3 RID: 12451 RVA: 0x00060C20 File Offset: 0x0005EE20
		[Token(Token = "0x60030A3")]
		[Address(RVA = "0x20B7E6C", Offset = "0x20B7E6C", VA = "0x20B7E6C")]
		public void method_114()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_0;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_0;
			\u06ED\u07ECڪ\u060E u0737ߊ_u07F3_u087E = hvrforceGrabber.\u0737ߊ\u07F3\u087E;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = u0737ߊ_u07F3_u087E;
			this.method_160();
		}

		// Token: 0x060030A4 RID: 12452 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x60030A4")]
		[Address(RVA = "0x20B7F08", Offset = "0x20B7F08", VA = "0x20B7F08")]
		private void method_115()
		{
		}

		// Token: 0x060030A5 RID: 12453 RVA: 0x0006138C File Offset: 0x0005F58C
		[Token(Token = "0x60030A5")]
		[Address(RVA = "0x20B7FB4", Offset = "0x20B7FB4", VA = "0x20B7FB4")]
		public void method_116()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_0;
			exists;
			this.method_48();
		}

		// Token: 0x060030A6 RID: 12454 RVA: 0x000613B0 File Offset: 0x0005F5B0
		[Token(Token = "0x60030A6")]
		[Address(RVA = "0x20B8044", Offset = "0x20B8044", VA = "0x20B8044")]
		private void method_117()
		{
			long num = 1L;
			HVRPlayerController exists = this.hvrplayerController_0;
			if (num != 0L)
			{
			}
			exists;
			if (num != 0L)
			{
			}
			HVRPlayerController[] array = UnityEngine.Object.FindObjectsOfType<HVRPlayerController>();
			Func<HVRPlayerController, bool> func;
			if (DemoUIManager.<>c.<>9__21_0 == null)
			{
				DemoUIManager.<>c.<>9__21_0 = func;
			}
			Enumerable.FirstOrDefault<HVRPlayerController>(array, func);
			this.hvrcameraRig_0;
			this.hvrplayerInputs_0;
			this.hvrjointHand_0;
			Func<HVRHandGrabber, bool> func2;
			if (DemoUIManager.<>c.<>9__21_1 == null)
			{
				DemoUIManager.<>c.<>9__21_1 = func2;
			}
			HVRHandGrabber[] array2;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array2, func2);
			if (hvrhandGrabber != null)
			{
				hvrhandGrabber.GetComponent<HVRJointHand>();
				return;
			}
			this.hvrjointHand_1;
			Func<HVRHandGrabber, bool> func3;
			if (DemoUIManager.<>c.<>9__21_2 == null)
			{
				DemoUIManager.<>c.<>9__21_2 = func3;
			}
			HVRHandGrabber[] array3;
			HVRHandGrabber hvrhandGrabber2 = Enumerable.FirstOrDefault<HVRHandGrabber>(array3, func3);
			if (hvrhandGrabber2 != null)
			{
				hvrhandGrabber2.GetComponent<HVRJointHand>();
				return;
			}
			Transform transform;
			Transform parent = transform.parent;
			this.transform_0 = parent;
			this.hvrjointHand_1;
			Transform parent2 = this.hvrjointHand_1.transform.parent;
			this.transform_1 = parent2;
			this.method_133();
			this.method_138();
			Toggle toggle = this.toggle_1;
			bool lineGrabTriggerLoose = HVRSettings.Instance.LineGrabTriggerLoose;
			toggle.isOn = lineGrabTriggerLoose;
			UnityAction<bool> unityAction;
			this.toggle_0.onValueChanged.AddListener(unityAction);
			UnityAction<bool> unityAction2;
			this.toggle_1.onValueChanged.AddListener(unityAction2);
			Transform transform2;
			HVRForceGrabber[] componentsInChildren = transform2.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func4;
			if (DemoUIManager.<>c.<>9__21_3 == null)
			{
				DemoUIManager.<>c.<>9__21_3 = func4;
			}
			HVRForceGrabber hvrforceGrabber = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren, func4);
			this.hvrforceGrabber_0 = hvrforceGrabber;
			HVRForceGrabber[] componentsInChildren2 = base.transform.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func5;
			if (DemoUIManager.<>c.<>9__21_4 == null)
			{
				DemoUIManager.<>c.<>9__21_4 = func5;
			}
			HVRForceGrabber hvrforceGrabber2 = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren2, func5);
			this.hvrforceGrabber_1 = hvrforceGrabber2;
			this.method_128();
			this.method_13();
		}

		// Token: 0x060030A7 RID: 12455 RVA: 0x00060104 File Offset: 0x0005E304
		[Token(Token = "0x60030A7")]
		[Address(RVA = "0x20B8B80", Offset = "0x20B8B80", VA = "0x20B8B80")]
		public void method_118()
		{
			this.method_21();
		}

		// Token: 0x060030A8 RID: 12456 RVA: 0x00060788 File Offset: 0x0005E988
		[Address(RVA = "0x20B8BC4", Offset = "0x20B8BC4", VA = "0x20B8BC4")]
		[Token(Token = "0x60030A8")]
		private void method_119(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x060030A9 RID: 12457 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x60030A9")]
		[Address(RVA = "0x20B7DC0", Offset = "0x20B7DC0", VA = "0x20B7DC0")]
		private void method_120()
		{
		}

		// Token: 0x060030AA RID: 12458 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20B8BF8", Offset = "0x20B8BF8", VA = "0x20B8BF8")]
		[Token(Token = "0x60030AA")]
		public void method_121()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x060030AB RID: 12459 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Token(Token = "0x60030AB")]
		[Address(RVA = "0x20B8C84", Offset = "0x20B8C84", VA = "0x20B8C84")]
		public void method_122(float float_0)
		{
		}

		// Token: 0x060030AC RID: 12460 RVA: 0x00060138 File Offset: 0x0005E338
		[Token(Token = "0x60030AC")]
		[Address(RVA = "0x20B2F80", Offset = "0x20B2F80", VA = "0x20B2F80")]
		private void method_123()
		{
		}

		// Token: 0x060030AD RID: 12461 RVA: 0x000601F0 File Offset: 0x0005E3F0
		[Token(Token = "0x60030AD")]
		[Address(RVA = "0x20B8CDC", Offset = "0x20B8CDC", VA = "0x20B8CDC")]
		public void method_124()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
		}

		// Token: 0x060030AE RID: 12462 RVA: 0x00061560 File Offset: 0x0005F760
		[Address(RVA = "0x20B8E9C", Offset = "0x20B8E9C", VA = "0x20B8E9C")]
		[Token(Token = "0x60030AE")]
		public void method_125()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_0;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_0;
			\u06ED\u07ECڪ\u060E u0737ߊ_u07F3_u087E = hvrforceGrabber.\u0737ߊ\u07F3\u087E;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = u0737ߊ_u07F3_u087E;
			this.method_97();
		}

		// Token: 0x060030AF RID: 12463 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x60030AF")]
		[Address(RVA = "0x20B8F38", Offset = "0x20B8F38", VA = "0x20B8F38")]
		private void method_126()
		{
		}

		// Token: 0x060030B0 RID: 12464 RVA: 0x0006097C File Offset: 0x0005EB7C
		[Token(Token = "0x60030B0")]
		[Address(RVA = "0x20B8FE4", Offset = "0x20B8FE4", VA = "0x20B8FE4")]
		public void method_127()
		{
			this.method_137();
		}

		// Token: 0x060030B1 RID: 12465 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B4198", Offset = "0x20B4198", VA = "0x20B4198")]
		[Token(Token = "0x60030B1")]
		private void method_128()
		{
		}

		// Token: 0x060030B2 RID: 12466 RVA: 0x00060BF8 File Offset: 0x0005EDF8
		[Address(RVA = "0x20B9020", Offset = "0x20B9020", VA = "0x20B9020")]
		[Token(Token = "0x60030B2")]
		public void method_129()
		{
			HVRPlayerInputs hvrplayerInputs = this.hvrplayerInputs_0;
			ࢭ٩աՏ u05EC_u06ECڹ_u064F = hvrplayerInputs.\u05EC\u06ECڹ\u064F;
			hvrplayerInputs.\u05EC\u06ECڹ\u064F = u05EC_u06ECڹ_u064F;
			this.method_70();
		}

		// Token: 0x060030B3 RID: 12467 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B9048", Offset = "0x20B9048", VA = "0x20B9048")]
		[Token(Token = "0x60030B3")]
		public void method_130(float float_0)
		{
		}

		// Token: 0x060030B4 RID: 12468 RVA: 0x00061598 File Offset: 0x0005F798
		[Address(RVA = "0x20B90A0", Offset = "0x20B90A0", VA = "0x20B90A0")]
		[Token(Token = "0x60030B4")]
		public void method_131()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_0;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_0;
			\u06ED\u07ECڪ\u060E u0737ߊ_u07F3_u087E = hvrforceGrabber.\u0737ߊ\u07F3\u087E;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = u0737ߊ_u07F3_u087E;
			this.method_20();
		}

		// Token: 0x060030B5 RID: 12469 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B913C", Offset = "0x20B913C", VA = "0x20B913C")]
		[Token(Token = "0x60030B5")]
		private void method_132()
		{
		}

		// Token: 0x060030B6 RID: 12470 RVA: 0x00060128 File Offset: 0x0005E328
		[Address(RVA = "0x20B0238", Offset = "0x20B0238", VA = "0x20B0238")]
		[Token(Token = "0x60030B6")]
		private void method_133()
		{
		}

		// Token: 0x060030B7 RID: 12471 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B91E8", Offset = "0x20B91E8", VA = "0x20B91E8")]
		[Token(Token = "0x60030B7")]
		public void method_134(float float_0)
		{
		}

		// Token: 0x060030B8 RID: 12472 RVA: 0x00060138 File Offset: 0x0005E338
		[Address(RVA = "0x20B0554", Offset = "0x20B0554", VA = "0x20B0554")]
		[Token(Token = "0x60030B8")]
		private void method_135()
		{
		}

		// Token: 0x060030B9 RID: 12473 RVA: 0x00060788 File Offset: 0x0005E988
		[Address(RVA = "0x20B9240", Offset = "0x20B9240", VA = "0x20B9240")]
		[Token(Token = "0x60030B9")]
		private void method_136(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x060030BA RID: 12474 RVA: 0x00060128 File Offset: 0x0005E328
		[Address(RVA = "0x20B2EAC", Offset = "0x20B2EAC", VA = "0x20B2EAC")]
		[Token(Token = "0x60030BA")]
		private void method_137()
		{
		}

		// Token: 0x060030BB RID: 12475 RVA: 0x00060138 File Offset: 0x0005E338
		[Address(RVA = "0x20B5F34", Offset = "0x20B5F34", VA = "0x20B5F34")]
		[Token(Token = "0x60030BB")]
		private void method_138()
		{
		}

		// Token: 0x060030BC RID: 12476 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B9274", Offset = "0x20B9274", VA = "0x20B9274")]
		[Token(Token = "0x60030BC")]
		private void method_139()
		{
		}

		// Token: 0x060030BD RID: 12477 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20B9320", Offset = "0x20B9320", VA = "0x20B9320")]
		[Token(Token = "0x60030BD")]
		public void method_140()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x060030BE RID: 12478 RVA: 0x00060138 File Offset: 0x0005E338
		[Address(RVA = "0x20B02E4", Offset = "0x20B02E4", VA = "0x20B02E4")]
		[Token(Token = "0x60030BE")]
		private void method_141()
		{
		}

		// Token: 0x060030BF RID: 12479 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B93AC", Offset = "0x20B93AC", VA = "0x20B93AC")]
		[Token(Token = "0x60030BF")]
		public void method_142(float float_0)
		{
		}

		// Token: 0x060030C0 RID: 12480 RVA: 0x000615D0 File Offset: 0x0005F7D0
		[Address(RVA = "0x20B9404", Offset = "0x20B9404", VA = "0x20B9404")]
		[Token(Token = "0x60030C0")]
		public void method_143()
		{
			this.method_154();
		}

		// Token: 0x060030C1 RID: 12481 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B9444", Offset = "0x20B9444", VA = "0x20B9444")]
		[Token(Token = "0x60030C1")]
		public void method_144(float float_0)
		{
		}

		// Token: 0x060030C2 RID: 12482 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20B949C", Offset = "0x20B949C", VA = "0x20B949C")]
		[Token(Token = "0x60030C2")]
		public void method_145()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x060030C3 RID: 12483 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20B9528", Offset = "0x20B9528", VA = "0x20B9528")]
		[Token(Token = "0x60030C3")]
		public void method_146(float float_0)
		{
		}

		// Token: 0x060030C4 RID: 12484 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x60030C4")]
		[Address(RVA = "0x20AF020", Offset = "0x20AF020", VA = "0x20AF020")]
		private void method_147()
		{
		}

		// Token: 0x060030C5 RID: 12485 RVA: 0x000606CC File Offset: 0x0005E8CC
		[Address(RVA = "0x20B9580", Offset = "0x20B9580", VA = "0x20B9580")]
		[Token(Token = "0x60030C5")]
		public void method_148()
		{
			long num = 1L;
			HVRJointHand exists = this.hvrjointHand_0;
			if (num != 0L)
			{
			}
			exists;
			HVRJointHand exists2 = this.hvrjointHand_1;
			if (num != 0L)
			{
			}
			exists2;
			if (this.bool_0)
			{
				Transform transform = this.hvrjointHand_0.transform;
				Transform parent = this.transform_0;
				transform.parent = parent;
				Transform transform2 = this.hvrjointHand_1.transform;
				return;
			}
			Transform transform3 = this.hvrjointHand_0.transform;
			Transform ԛ_u07F9ݶ_u07F = this.hvrjointHand_0.Ԛ\u07F9ݶ\u07F8;
			transform3.parent = ԛ_u07F9ݶ_u07F;
			Transform transform4 = this.hvrjointHand_1.transform;
			Transform ԛ_u07F9ݶ_u07F2 = this.hvrjointHand_1.Ԛ\u07F9ݶ\u07F8;
			transform4.parent = ԛ_u07F9ݶ_u07F2;
			bool flag = this.bool_0;
			this.bool_0 = flag;
		}

		// Token: 0x060030C6 RID: 12486 RVA: 0x00060104 File Offset: 0x0005E304
		[Address(RVA = "0x20B973C", Offset = "0x20B973C", VA = "0x20B973C")]
		[Token(Token = "0x60030C6")]
		public void method_149()
		{
			this.method_21();
		}

		// Token: 0x060030C7 RID: 12487 RVA: 0x000615E4 File Offset: 0x0005F7E4
		[Address(RVA = "0x20B977C", Offset = "0x20B977C", VA = "0x20B977C")]
		[Token(Token = "0x60030C7")]
		private void method_150()
		{
			long num = 1L;
			HVRPlayerController exists = this.hvrplayerController_0;
			if (num != 0L)
			{
			}
			exists;
			if (num != 0L)
			{
			}
			HVRPlayerController[] array = UnityEngine.Object.FindObjectsOfType<HVRPlayerController>();
			Func<HVRPlayerController, bool> func;
			if (DemoUIManager.<>c.<>9__21_0 == null)
			{
				DemoUIManager.<>c.<>9__21_0 = func;
			}
			Enumerable.FirstOrDefault<HVRPlayerController>(array, func);
			this.hvrcameraRig_0;
			this.hvrplayerInputs_0;
			this.hvrjointHand_0;
			Func<HVRHandGrabber, bool> func2;
			if (DemoUIManager.<>c.<>9__21_1 == null)
			{
				DemoUIManager.<>c.<>9__21_1 = func2;
			}
			HVRHandGrabber[] array2;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array2, func2);
			if (hvrhandGrabber != null)
			{
				hvrhandGrabber.GetComponent<HVRJointHand>();
				return;
			}
			this.hvrjointHand_1;
			Func<HVRHandGrabber, bool> func3;
			if (DemoUIManager.<>c.<>9__21_2 == null)
			{
				DemoUIManager.<>c.<>9__21_2 = func3;
			}
			HVRHandGrabber[] array3;
			HVRHandGrabber hvrhandGrabber2 = Enumerable.FirstOrDefault<HVRHandGrabber>(array3, func3);
			if (hvrhandGrabber2 != null)
			{
				hvrhandGrabber2.GetComponent<HVRJointHand>();
				return;
			}
			Transform transform;
			Transform parent = transform.parent;
			this.transform_0 = parent;
			this.hvrjointHand_1;
			Transform parent2 = this.hvrjointHand_1.transform.parent;
			this.transform_1 = parent2;
			this.method_133();
			this.method_102();
			Toggle toggle = this.toggle_1;
			bool lineGrabTriggerLoose = HVRSettings.Instance.LineGrabTriggerLoose;
			toggle.isOn = lineGrabTriggerLoose;
			UnityAction<bool> unityAction;
			this.toggle_0.onValueChanged.AddListener(unityAction);
			UnityAction<bool> unityAction2;
			this.toggle_1.onValueChanged.AddListener(unityAction2);
			Transform transform2;
			HVRForceGrabber[] componentsInChildren = transform2.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func4;
			if (DemoUIManager.<>c.<>9__21_3 == null)
			{
				DemoUIManager.<>c.<>9__21_3 = func4;
			}
			HVRForceGrabber hvrforceGrabber = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren, func4);
			this.hvrforceGrabber_0 = hvrforceGrabber;
			HVRForceGrabber[] componentsInChildren2 = base.transform.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func5;
			if (DemoUIManager.<>c.<>9__21_4 == null)
			{
				DemoUIManager.<>c.<>9__21_4 = func5;
			}
			HVRForceGrabber hvrforceGrabber2 = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren2, func5);
			this.hvrforceGrabber_1 = hvrforceGrabber2;
			this.method_20();
			this.method_115();
		}

		// Token: 0x060030C8 RID: 12488 RVA: 0x0006029C File Offset: 0x0005E49C
		[Address(RVA = "0x20B5DB4", Offset = "0x20B5DB4", VA = "0x20B5DB4")]
		[Token(Token = "0x60030C8")]
		private void method_151()
		{
		}

		// Token: 0x060030C9 RID: 12489 RVA: 0x00061794 File Offset: 0x0005F994
		[Address(RVA = "0x20BA2B8", Offset = "0x20BA2B8", VA = "0x20BA2B8")]
		[Token(Token = "0x60030C9")]
		private void method_152()
		{
			long num = 1L;
			HVRPlayerController exists = this.hvrplayerController_0;
			if (num != 0L)
			{
			}
			exists;
			if (num != 0L)
			{
			}
			HVRPlayerController[] array = UnityEngine.Object.FindObjectsOfType<HVRPlayerController>();
			Func<HVRPlayerController, bool> func;
			if (DemoUIManager.<>c.<>9__21_0 == null)
			{
				DemoUIManager.<>c.<>9__21_0 = func;
			}
			Enumerable.FirstOrDefault<HVRPlayerController>(array, func);
			this.hvrcameraRig_0;
			this.hvrplayerInputs_0;
			this.hvrjointHand_0;
			Func<HVRHandGrabber, bool> func2;
			if (DemoUIManager.<>c.<>9__21_1 == null)
			{
				DemoUIManager.<>c.<>9__21_1 = func2;
			}
			HVRHandGrabber[] array2;
			HVRHandGrabber hvrhandGrabber = Enumerable.FirstOrDefault<HVRHandGrabber>(array2, func2);
			if (hvrhandGrabber != null)
			{
				hvrhandGrabber.GetComponent<HVRJointHand>();
				return;
			}
			this.hvrjointHand_1;
			Func<HVRHandGrabber, bool> func3;
			if (DemoUIManager.<>c.<>9__21_2 == null)
			{
				DemoUIManager.<>c.<>9__21_2 = func3;
			}
			HVRHandGrabber[] array3;
			HVRHandGrabber hvrhandGrabber2 = Enumerable.FirstOrDefault<HVRHandGrabber>(array3, func3);
			if (hvrhandGrabber2 != null)
			{
				hvrhandGrabber2.GetComponent<HVRJointHand>();
				return;
			}
			Transform transform;
			Transform parent = transform.parent;
			this.transform_0 = parent;
			this.hvrjointHand_1;
			Transform parent2 = this.hvrjointHand_1.transform.parent;
			this.transform_1 = parent2;
			this.method_3();
			this.method_70();
			Toggle toggle = this.toggle_1;
			bool lineGrabTriggerLoose = HVRSettings.Instance.LineGrabTriggerLoose;
			toggle.isOn = lineGrabTriggerLoose;
			UnityAction<bool> unityAction;
			this.toggle_0.onValueChanged.AddListener(unityAction);
			UnityAction<bool> unityAction2;
			this.toggle_1.onValueChanged.AddListener(unityAction2);
			Transform transform2;
			HVRForceGrabber[] componentsInChildren = transform2.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func4;
			if (DemoUIManager.<>c.<>9__21_3 == null)
			{
				DemoUIManager.<>c.<>9__21_3 = func4;
			}
			HVRForceGrabber hvrforceGrabber = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren, func4);
			this.hvrforceGrabber_0 = hvrforceGrabber;
			HVRForceGrabber[] componentsInChildren2 = base.transform.root.GetComponentsInChildren<HVRForceGrabber>();
			Func<HVRForceGrabber, bool> func5;
			if (DemoUIManager.<>c.<>9__21_4 == null)
			{
				DemoUIManager.<>c.<>9__21_4 = func5;
			}
			HVRForceGrabber hvrforceGrabber2 = Enumerable.FirstOrDefault<HVRForceGrabber>(componentsInChildren2, func5);
			this.hvrforceGrabber_1 = hvrforceGrabber2;
			this.method_160();
			this.method_83();
		}

		// Token: 0x060030CA RID: 12490 RVA: 0x0006079C File Offset: 0x0005E99C
		[Address(RVA = "0x20BADF4", Offset = "0x20BADF4", VA = "0x20BADF4")]
		[Token(Token = "0x60030CA")]
		public void method_153(bool bool_1)
		{
		}

		// Token: 0x060030CB RID: 12491 RVA: 0x00060128 File Offset: 0x0005E328
		[Address(RVA = "0x20B1608", Offset = "0x20B1608", VA = "0x20B1608")]
		[Token(Token = "0x60030CB")]
		private void method_154()
		{
		}

		// Token: 0x060030CC RID: 12492 RVA: 0x00060104 File Offset: 0x0005E304
		[Address(RVA = "0x20BAE18", Offset = "0x20BAE18", VA = "0x20BAE18")]
		[Token(Token = "0x60030CC")]
		public void method_155()
		{
			this.method_21();
		}

		// Token: 0x060030CD RID: 12493 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Address(RVA = "0x20BAE58", Offset = "0x20BAE58", VA = "0x20BAE58")]
		[Token(Token = "0x60030CD")]
		public void method_156(float float_0)
		{
		}

		// Token: 0x060030CE RID: 12494 RVA: 0x00060148 File Offset: 0x0005E348
		[Address(RVA = "0x20BAEB0", Offset = "0x20BAEB0", VA = "0x20BAEB0")]
		[Token(Token = "0x60030CE")]
		public void method_157()
		{
			HVRForceGrabber exists = this.hvrforceGrabber_1;
			exists;
			HVRForceGrabber hvrforceGrabber = this.hvrforceGrabber_1;
			\u06ED\u07ECڪ\u060E u0737ߊ_u07F3_u087E = hvrforceGrabber.\u0737ߊ\u07F3\u087E;
			hvrforceGrabber.\u0737ߊ\u07F3\u087E = u0737ߊ_u07F3_u087E;
			this.method_28();
		}

		// Token: 0x060030CF RID: 12495 RVA: 0x00060788 File Offset: 0x0005E988
		[Address(RVA = "0x20BAF4C", Offset = "0x20BAF4C", VA = "0x20BAF4C")]
		[Token(Token = "0x60030CF")]
		private void method_158(bool bool_1)
		{
			HVRSettings instance = HVRSettings.Instance;
		}

		// Token: 0x060030D0 RID: 12496 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Address(RVA = "0x20BAF80", Offset = "0x20BAF80", VA = "0x20BAF80")]
		[Token(Token = "0x60030D0")]
		public void method_159()
		{
			HVRCameraRig exists = this.hvrcameraRig_0;
			exists;
			this.hvrcameraRig_0.ٷ\u0611ݩ\u0888();
		}

		// Token: 0x060030D1 RID: 12497 RVA: 0x0006029C File Offset: 0x0005E49C
		[Token(Token = "0x60030D1")]
		[Address(RVA = "0x20B2B1C", Offset = "0x20B2B1C", VA = "0x20B2B1C")]
		private void method_160()
		{
		}

		// Token: 0x04000607 RID: 1543
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000607")]
		public HVRPlayerController hvrplayerController_0;

		// Token: 0x04000608 RID: 1544
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000608")]
		public HVRCameraRig hvrcameraRig_0;

		// Token: 0x04000609 RID: 1545
		[Token(Token = "0x4000609")]
		[FieldOffset(Offset = "0x28")]
		public HVRPlayerInputs hvrplayerInputs_0;

		// Token: 0x0400060A RID: 1546
		[Token(Token = "0x400060A")]
		[FieldOffset(Offset = "0x30")]
		public TextMeshProUGUI textMeshProUGUI_0;

		// Token: 0x0400060B RID: 1547
		[Token(Token = "0x400060B")]
		[FieldOffset(Offset = "0x38")]
		public TextMeshProUGUI textMeshProUGUI_1;

		// Token: 0x0400060C RID: 1548
		[Token(Token = "0x400060C")]
		[FieldOffset(Offset = "0x40")]
		public TextMeshProUGUI textMeshProUGUI_2;

		// Token: 0x0400060D RID: 1549
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x400060D")]
		public TextMeshProUGUI textMeshProUGUI_3;

		// Token: 0x0400060E RID: 1550
		[Token(Token = "0x400060E")]
		[FieldOffset(Offset = "0x50")]
		public TextMeshProUGUI textMeshProUGUI_4;

		// Token: 0x0400060F RID: 1551
		[Token(Token = "0x400060F")]
		[FieldOffset(Offset = "0x58")]
		public Slider slider_0;

		// Token: 0x04000610 RID: 1552
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x4000610")]
		public Slider slider_1;

		// Token: 0x04000611 RID: 1553
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x4000611")]
		public TextMeshProUGUI textMeshProUGUI_5;

		// Token: 0x04000612 RID: 1554
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x4000612")]
		public TextMeshProUGUI textMeshProUGUI_6;

		// Token: 0x04000613 RID: 1555
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x4000613")]
		public Toggle toggle_0;

		// Token: 0x04000614 RID: 1556
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x4000614")]
		public Toggle toggle_1;

		// Token: 0x04000615 RID: 1557
		[Token(Token = "0x4000615")]
		[FieldOffset(Offset = "0x88")]
		public HVRForceGrabber hvrforceGrabber_0;

		// Token: 0x04000616 RID: 1558
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000616")]
		public HVRForceGrabber hvrforceGrabber_1;

		// Token: 0x04000617 RID: 1559
		[Token(Token = "0x4000617")]
		[FieldOffset(Offset = "0x98")]
		public HVRJointHand hvrjointHand_0;

		// Token: 0x04000618 RID: 1560
		[FieldOffset(Offset = "0xA0")]
		[Token(Token = "0x4000618")]
		public HVRJointHand hvrjointHand_1;

		// Token: 0x04000619 RID: 1561
		[FieldOffset(Offset = "0xA8")]
		[Token(Token = "0x4000619")]
		private Transform transform_0;

		// Token: 0x0400061A RID: 1562
		[Token(Token = "0x400061A")]
		[FieldOffset(Offset = "0xB0")]
		private Transform transform_1;

		// Token: 0x0400061B RID: 1563
		[FieldOffset(Offset = "0xB8")]
		[Token(Token = "0x400061B")]
		private bool bool_0;
	}
}
