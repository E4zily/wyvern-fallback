﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core.Utils;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x0200011A RID: 282
	[Token(Token = "0x200011A")]
	public class DemoGlassRotate : MonoBehaviour
	{
		// Token: 0x06002AFA RID: 11002 RVA: 0x0005B3D4 File Offset: 0x000595D4
		[Address(RVA = "0x35FBB24", Offset = "0x35FBB24", VA = "0x35FBB24")]
		[Token(Token = "0x6002AFA")]
		private void method_0()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002AFB RID: 11003 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002AFB")]
		[Address(RVA = "0x35FBC40", Offset = "0x35FBC40", VA = "0x35FBC40")]
		private void method_1()
		{
		}

		// Token: 0x06002AFC RID: 11004 RVA: 0x0005B41C File Offset: 0x0005961C
		[Token(Token = "0x6002AFC")]
		[Address(RVA = "0x35FBC44", Offset = "0x35FBC44", VA = "0x35FBC44")]
		private void method_2()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)40960;
			}
		}

		// Token: 0x06002AFD RID: 11005 RVA: 0x0005B464 File Offset: 0x00059664
		[Address(RVA = "0x35FBD60", Offset = "0x35FBD60", VA = "0x35FBD60")]
		[Token(Token = "0x6002AFD")]
		private void method_3()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)17478;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002AFE RID: 11006 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002AFE")]
		[Address(RVA = "0x35FBE7C", Offset = "0x35FBE7C", VA = "0x35FBE7C")]
		private void method_4()
		{
		}

		// Token: 0x06002AFF RID: 11007 RVA: 0x0005B4B8 File Offset: 0x000596B8
		[Token(Token = "0x6002AFF")]
		[Address(RVA = "0x35FBE80", Offset = "0x35FBE80", VA = "0x35FBE80")]
		private void method_5()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)32768;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B00 RID: 11008 RVA: 0x0005B50C File Offset: 0x0005970C
		[Address(RVA = "0x35FBFA0", Offset = "0x35FBFA0", VA = "0x35FBFA0")]
		[Token(Token = "0x6002B00")]
		public void method_6()
		{
			if (!this.bool_0)
			{
				return;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B01 RID: 11009 RVA: 0x0005B530 File Offset: 0x00059730
		[Address(RVA = "0x35FC0B4", Offset = "0x35FC0B4", VA = "0x35FC0B4")]
		[Token(Token = "0x6002B01")]
		private void method_7()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)16384;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B02 RID: 11010 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002B02")]
		[Address(RVA = "0x35FC1D4", Offset = "0x35FC1D4", VA = "0x35FC1D4")]
		private void method_8()
		{
		}

		// Token: 0x06002B03 RID: 11011 RVA: 0x0005B584 File Offset: 0x00059784
		[Token(Token = "0x6002B03")]
		[Address(RVA = "0x35FC1D8", Offset = "0x35FC1D8", VA = "0x35FC1D8")]
		private void method_9()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)40960;
			}
		}

		// Token: 0x06002B04 RID: 11012 RVA: 0x0005B5C4 File Offset: 0x000597C4
		[Token(Token = "0x6002B04")]
		[Address(RVA = "0x35FC2F4", Offset = "0x35FC2F4", VA = "0x35FC2F4")]
		private void method_10()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)16952;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B05 RID: 11013 RVA: 0x0005B530 File Offset: 0x00059730
		[Address(RVA = "0x35FC410", Offset = "0x35FC410", VA = "0x35FC410")]
		[Token(Token = "0x6002B05")]
		private void method_11()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)16384;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B06 RID: 11014 RVA: 0x0005B618 File Offset: 0x00059818
		[Token(Token = "0x6002B06")]
		[Address(RVA = "0x35FC530", Offset = "0x35FC530", VA = "0x35FC530")]
		public void method_12()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B07 RID: 11015 RVA: 0x0005B644 File Offset: 0x00059844
		[Token(Token = "0x6002B07")]
		[Address(RVA = "0x35FC640", Offset = "0x35FC640", VA = "0x35FC640")]
		private void method_13()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)40960;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B08 RID: 11016 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FC760", Offset = "0x35FC760", VA = "0x35FC760")]
		[Token(Token = "0x6002B08")]
		private void method_14()
		{
		}

		// Token: 0x06002B09 RID: 11017 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002B09")]
		[Address(RVA = "0x35FC764", Offset = "0x35FC764", VA = "0x35FC764")]
		private void method_15()
		{
		}

		// Token: 0x06002B0A RID: 11018 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FC768", Offset = "0x35FC768", VA = "0x35FC768")]
		[Token(Token = "0x6002B0A")]
		public void method_16()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B0B RID: 11019 RVA: 0x0005B618 File Offset: 0x00059818
		[Token(Token = "0x6002B0B")]
		[Address(RVA = "0x35FC87C", Offset = "0x35FC87C", VA = "0x35FC87C")]
		public void method_17()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B0C RID: 11020 RVA: 0x0005B618 File Offset: 0x00059818
		[Address(RVA = "0x35FC98C", Offset = "0x35FC98C", VA = "0x35FC98C")]
		[Token(Token = "0x6002B0C")]
		public void method_18()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B0D RID: 11021 RVA: 0x0005B6D0 File Offset: 0x000598D0
		[Token(Token = "0x6002B0D")]
		[Address(RVA = "0x35FCA9C", Offset = "0x35FCA9C", VA = "0x35FCA9C")]
		private void method_19()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)32768;
			}
		}

		// Token: 0x06002B0E RID: 11022 RVA: 0x0005B618 File Offset: 0x00059818
		[Token(Token = "0x6002B0E")]
		[Address(RVA = "0x35FCBB8", Offset = "0x35FCBB8", VA = "0x35FCBB8")]
		public void method_20()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B0F RID: 11023 RVA: 0x0005B718 File Offset: 0x00059918
		[Address(RVA = "0x35FCCCC", Offset = "0x35FCCCC", VA = "0x35FCCCC")]
		[Token(Token = "0x6002B0F")]
		private void method_21()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)17434;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B10 RID: 11024 RVA: 0x0005B76C File Offset: 0x0005996C
		[Token(Token = "0x6002B10")]
		[Address(RVA = "0x35FCDE8", Offset = "0x35FCDE8", VA = "0x35FCDE8")]
		private void method_22()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)17251;
			}
		}

		// Token: 0x06002B11 RID: 11025 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FCF00", Offset = "0x35FCF00", VA = "0x35FCF00")]
		[Token(Token = "0x6002B11")]
		public void method_23()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B12 RID: 11026 RVA: 0x0005B7B4 File Offset: 0x000599B4
		[Token(Token = "0x6002B12")]
		[Address(RVA = "0x35FD014", Offset = "0x35FD014", VA = "0x35FD014")]
		private void method_24()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)17267;
			}
		}

		// Token: 0x06002B13 RID: 11027 RVA: 0x0005B7FC File Offset: 0x000599FC
		[Address(RVA = "0x35FD12C", Offset = "0x35FD12C", VA = "0x35FD12C")]
		[Token(Token = "0x6002B13")]
		private void method_25()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)17467;
			}
		}

		// Token: 0x06002B14 RID: 11028 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FD244", Offset = "0x35FD244", VA = "0x35FD244")]
		[Token(Token = "0x6002B14")]
		private void method_26()
		{
		}

		// Token: 0x06002B15 RID: 11029 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FD248", Offset = "0x35FD248", VA = "0x35FD248")]
		[Token(Token = "0x6002B15")]
		public void method_27()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B16 RID: 11030 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FD35C", Offset = "0x35FD35C", VA = "0x35FD35C")]
		[Token(Token = "0x6002B16")]
		public void method_28()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B17 RID: 11031 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FD470", Offset = "0x35FD470", VA = "0x35FD470")]
		[Token(Token = "0x6002B17")]
		private void method_29()
		{
		}

		// Token: 0x06002B18 RID: 11032 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FD474", Offset = "0x35FD474", VA = "0x35FD474")]
		[Token(Token = "0x6002B18")]
		private void method_30()
		{
		}

		// Token: 0x06002B19 RID: 11033 RVA: 0x0005B844 File Offset: 0x00059A44
		[Address(RVA = "0x35FD478", Offset = "0x35FD478", VA = "0x35FD478")]
		[Token(Token = "0x6002B19")]
		private void method_31()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)16384;
			}
		}

		// Token: 0x06002B1A RID: 11034 RVA: 0x0005B88C File Offset: 0x00059A8C
		[Address(RVA = "0x35FD594", Offset = "0x35FD594", VA = "0x35FD594")]
		[Token(Token = "0x6002B1A")]
		private void method_32()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)17173;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B1B RID: 11035 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FD6B0", Offset = "0x35FD6B0", VA = "0x35FD6B0")]
		[Token(Token = "0x6002B1B")]
		public void method_33()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B1C RID: 11036 RVA: 0x0005B8E0 File Offset: 0x00059AE0
		[Address(RVA = "0x35FD7C4", Offset = "0x35FD7C4", VA = "0x35FD7C4")]
		[Token(Token = "0x6002B1C")]
		private void method_34()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)17154;
			}
		}

		// Token: 0x06002B1D RID: 11037 RVA: 0x0005B41C File Offset: 0x0005961C
		[Address(RVA = "0x35FD8DC", Offset = "0x35FD8DC", VA = "0x35FD8DC")]
		[Token(Token = "0x6002B1D")]
		private void method_35()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)40960;
			}
		}

		// Token: 0x06002B1E RID: 11038 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FD9F8", Offset = "0x35FD9F8", VA = "0x35FD9F8")]
		[Token(Token = "0x6002B1E")]
		private void method_36()
		{
		}

		// Token: 0x06002B1F RID: 11039 RVA: 0x0005B844 File Offset: 0x00059A44
		[Address(RVA = "0x35FD9FC", Offset = "0x35FD9FC", VA = "0x35FD9FC")]
		[Token(Token = "0x6002B1F")]
		private void method_37()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)16384;
			}
		}

		// Token: 0x06002B20 RID: 11040 RVA: 0x0005B618 File Offset: 0x00059818
		[Token(Token = "0x6002B20")]
		[Address(RVA = "0x35FDB18", Offset = "0x35FDB18", VA = "0x35FDB18")]
		public void method_38()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B21 RID: 11041 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FDC28", Offset = "0x35FDC28", VA = "0x35FDC28")]
		[Token(Token = "0x6002B21")]
		public void method_39()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B22 RID: 11042 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FDD3C", Offset = "0x35FDD3C", VA = "0x35FDD3C")]
		[Token(Token = "0x6002B22")]
		public void method_40()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B23 RID: 11043 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FDE50", Offset = "0x35FDE50", VA = "0x35FDE50")]
		[Token(Token = "0x6002B23")]
		private void method_41()
		{
		}

		// Token: 0x06002B24 RID: 11044 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FDE54", Offset = "0x35FDE54", VA = "0x35FDE54")]
		[Token(Token = "0x6002B24")]
		private void method_42()
		{
		}

		// Token: 0x06002B25 RID: 11045 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FDE58", Offset = "0x35FDE58", VA = "0x35FDE58")]
		[Token(Token = "0x6002B25")]
		private void method_43()
		{
		}

		// Token: 0x06002B26 RID: 11046 RVA: 0x0005B618 File Offset: 0x00059818
		[Address(RVA = "0x35FDE5C", Offset = "0x35FDE5C", VA = "0x35FDE5C")]
		[Token(Token = "0x6002B26")]
		public void method_44()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B27 RID: 11047 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FDF6C", Offset = "0x35FDF6C", VA = "0x35FDF6C")]
		[Token(Token = "0x6002B27")]
		private void method_45()
		{
		}

		// Token: 0x06002B28 RID: 11048 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FDF70", Offset = "0x35FDF70", VA = "0x35FDF70")]
		[Token(Token = "0x6002B28")]
		public void method_46()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B29 RID: 11049 RVA: 0x0005B928 File Offset: 0x00059B28
		[Address(RVA = "0x35FE084", Offset = "0x35FE084", VA = "0x35FE084")]
		[Token(Token = "0x6002B29")]
		public void method_47()
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B2A RID: 11050 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FE198", Offset = "0x35FE198", VA = "0x35FE198")]
		[Token(Token = "0x6002B2A")]
		public void method_48()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B2B RID: 11051 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002B2B")]
		[Address(RVA = "0x35FE2AC", Offset = "0x35FE2AC", VA = "0x35FE2AC")]
		private void method_49()
		{
		}

		// Token: 0x06002B2C RID: 11052 RVA: 0x0005B940 File Offset: 0x00059B40
		[Address(RVA = "0x35FE2B0", Offset = "0x35FE2B0", VA = "0x35FE2B0")]
		[Token(Token = "0x6002B2C")]
		private void method_50()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)24576;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B2D RID: 11053 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FE3D0", Offset = "0x35FE3D0", VA = "0x35FE3D0")]
		[Token(Token = "0x6002B2D")]
		private void method_51()
		{
		}

		// Token: 0x06002B2E RID: 11054 RVA: 0x0005B994 File Offset: 0x00059B94
		[Address(RVA = "0x35FE3D4", Offset = "0x35FE3D4", VA = "0x35FE3D4")]
		[Token(Token = "0x6002B2E")]
		private void method_52()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)16576;
			}
		}

		// Token: 0x06002B2F RID: 11055 RVA: 0x0005B9DC File Offset: 0x00059BDC
		[Token(Token = "0x6002B2F")]
		[Address(RVA = "0x35FE4EC", Offset = "0x35FE4EC", VA = "0x35FE4EC")]
		public void method_53()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B30 RID: 11056 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FE5FC", Offset = "0x35FE5FC", VA = "0x35FE5FC")]
		[Token(Token = "0x6002B30")]
		public void method_54()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B31 RID: 11057 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FE710", Offset = "0x35FE710", VA = "0x35FE710")]
		[Token(Token = "0x6002B31")]
		private void method_55()
		{
		}

		// Token: 0x06002B32 RID: 11058 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FE714", Offset = "0x35FE714", VA = "0x35FE714")]
		[Token(Token = "0x6002B32")]
		public void method_56()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B33 RID: 11059 RVA: 0x0005B618 File Offset: 0x00059818
		[Address(RVA = "0x35FE828", Offset = "0x35FE828", VA = "0x35FE828")]
		[Token(Token = "0x6002B33")]
		public void method_57()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B34 RID: 11060 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FE938", Offset = "0x35FE938", VA = "0x35FE938")]
		[Token(Token = "0x6002B34")]
		private void method_58()
		{
		}

		// Token: 0x06002B35 RID: 11061 RVA: 0x0005B3D4 File Offset: 0x000595D4
		[Address(RVA = "0x35FE93C", Offset = "0x35FE93C", VA = "0x35FE93C")]
		[Token(Token = "0x6002B35")]
		private void Update()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B36 RID: 11062 RVA: 0x0005B618 File Offset: 0x00059818
		[Address(RVA = "0x35FEA4C", Offset = "0x35FEA4C", VA = "0x35FEA4C")]
		[Token(Token = "0x6002B36")]
		public void method_59()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B37 RID: 11063 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FEB5C", Offset = "0x35FEB5C", VA = "0x35FEB5C")]
		[Token(Token = "0x6002B37")]
		private void method_60()
		{
		}

		// Token: 0x06002B38 RID: 11064 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x35FEB60", Offset = "0x35FEB60", VA = "0x35FEB60")]
		[Token(Token = "0x6002B38")]
		public DemoGlassRotate()
		{
		}

		// Token: 0x06002B39 RID: 11065 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002B39")]
		[Address(RVA = "0x35FEB74", Offset = "0x35FEB74", VA = "0x35FEB74")]
		private void method_61()
		{
		}

		// Token: 0x06002B3A RID: 11066 RVA: 0x0005BA08 File Offset: 0x00059C08
		[Address(RVA = "0x35FEB78", Offset = "0x35FEB78", VA = "0x35FEB78")]
		[Token(Token = "0x6002B3A")]
		private void method_62()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)57344;
			}
		}

		// Token: 0x06002B3B RID: 11067 RVA: 0x0005B698 File Offset: 0x00059898
		[Token(Token = "0x6002B3B")]
		[Address(RVA = "0x35FEC94", Offset = "0x35FEC94", VA = "0x35FEC94")]
		public void method_63()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B3C RID: 11068 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FEDA8", Offset = "0x35FEDA8", VA = "0x35FEDA8")]
		[Token(Token = "0x6002B3C")]
		private void method_64()
		{
		}

		// Token: 0x06002B3D RID: 11069 RVA: 0x0005BA50 File Offset: 0x00059C50
		[Token(Token = "0x6002B3D")]
		[Address(RVA = "0x35FEDAC", Offset = "0x35FEDAC", VA = "0x35FEDAC")]
		private void method_65()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)17580;
			}
		}

		// Token: 0x06002B3E RID: 11070 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FEEC4", Offset = "0x35FEEC4", VA = "0x35FEEC4")]
		[Token(Token = "0x6002B3E")]
		private void method_66()
		{
		}

		// Token: 0x06002B3F RID: 11071 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FEEC8", Offset = "0x35FEEC8", VA = "0x35FEEC8")]
		[Token(Token = "0x6002B3F")]
		public void method_67()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B40 RID: 11072 RVA: 0x0005BA98 File Offset: 0x00059C98
		[Address(RVA = "0x35FEFDC", Offset = "0x35FEFDC", VA = "0x35FEFDC")]
		[Token(Token = "0x6002B40")]
		private void method_68()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
			}
		}

		// Token: 0x06002B41 RID: 11073 RVA: 0x0005B530 File Offset: 0x00059730
		[Address(RVA = "0x35FF0F8", Offset = "0x35FF0F8", VA = "0x35FF0F8")]
		[Token(Token = "0x6002B41")]
		private void method_69()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)16384;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B42 RID: 11074 RVA: 0x0005B698 File Offset: 0x00059898
		[Token(Token = "0x6002B42")]
		[Address(RVA = "0x35FF218", Offset = "0x35FF218", VA = "0x35FF218")]
		public void method_70()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B43 RID: 11075 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FF32C", Offset = "0x35FF32C", VA = "0x35FF32C")]
		[Token(Token = "0x6002B43")]
		private void method_71()
		{
		}

		// Token: 0x06002B44 RID: 11076 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FF330", Offset = "0x35FF330", VA = "0x35FF330")]
		[Token(Token = "0x6002B44")]
		private void method_72()
		{
		}

		// Token: 0x06002B45 RID: 11077 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FF334", Offset = "0x35FF334", VA = "0x35FF334")]
		[Token(Token = "0x6002B45")]
		private void Start()
		{
		}

		// Token: 0x06002B46 RID: 11078 RVA: 0x0005BAD4 File Offset: 0x00059CD4
		[Token(Token = "0x6002B46")]
		[Address(RVA = "0x35FF338", Offset = "0x35FF338", VA = "0x35FF338")]
		private void method_73()
		{
			if (this.bool_0)
			{
				float deltaTime = Time.deltaTime;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)17621;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B47 RID: 11079 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x35FF454", Offset = "0x35FF454", VA = "0x35FF454")]
		[Token(Token = "0x6002B47")]
		public void method_74()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B48 RID: 11080 RVA: 0x0005BB18 File Offset: 0x00059D18
		[Address(RVA = "0x35FF568", Offset = "0x35FF568", VA = "0x35FF568")]
		[Token(Token = "0x6002B48")]
		private void method_75()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)17285;
			}
		}

		// Token: 0x06002B49 RID: 11081 RVA: 0x0005BB60 File Offset: 0x00059D60
		[Address(RVA = "0x35FF680", Offset = "0x35FF680", VA = "0x35FF680")]
		[Token(Token = "0x6002B49")]
		private void method_76()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)32768;
			}
		}

		// Token: 0x06002B4A RID: 11082 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35FF79C", Offset = "0x35FF79C", VA = "0x35FF79C")]
		[Token(Token = "0x6002B4A")]
		private void method_77()
		{
		}

		// Token: 0x06002B4B RID: 11083 RVA: 0x0005B618 File Offset: 0x00059818
		[Token(Token = "0x6002B4B")]
		[Address(RVA = "0x35FF7A0", Offset = "0x35FF7A0", VA = "0x35FF7A0")]
		public void method_78()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B4C RID: 11084 RVA: 0x0005B618 File Offset: 0x00059818
		[Address(RVA = "0x35FF8B0", Offset = "0x35FF8B0", VA = "0x35FF8B0")]
		[Token(Token = "0x6002B4C")]
		public void method_79()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B4D RID: 11085 RVA: 0x0005BBA8 File Offset: 0x00059DA8
		[Address(RVA = "0x35FF9C0", Offset = "0x35FF9C0", VA = "0x35FF9C0")]
		[Token(Token = "0x6002B4D")]
		private void method_80()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)32768;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B4E RID: 11086 RVA: 0x0005BB60 File Offset: 0x00059D60
		[Address(RVA = "0x35FFAE0", Offset = "0x35FFAE0", VA = "0x35FFAE0")]
		[Token(Token = "0x6002B4E")]
		private void method_81()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)32768;
			}
		}

		// Token: 0x06002B4F RID: 11087 RVA: 0x0005BBFC File Offset: 0x00059DFC
		[Token(Token = "0x6002B4F")]
		[Address(RVA = "0x35FFBFC", Offset = "0x35FFBFC", VA = "0x35FFBFC")]
		private void method_82()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)17489;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B50 RID: 11088 RVA: 0x0005B698 File Offset: 0x00059898
		[Token(Token = "0x6002B50")]
		[Address(RVA = "0x35FFD18", Offset = "0x35FFD18", VA = "0x35FFD18")]
		public void method_83()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B51 RID: 11089 RVA: 0x0005BC50 File Offset: 0x00059E50
		[Address(RVA = "0x35FFE2C", Offset = "0x35FFE2C", VA = "0x35FFE2C")]
		[Token(Token = "0x6002B51")]
		private void method_84()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)57344;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B52 RID: 11090 RVA: 0x0005B618 File Offset: 0x00059818
		[Token(Token = "0x6002B52")]
		[Address(RVA = "0x35FFF4C", Offset = "0x35FFF4C", VA = "0x35FFF4C")]
		public void method_85()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B53 RID: 11091 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x360005C", Offset = "0x360005C", VA = "0x360005C")]
		[Token(Token = "0x6002B53")]
		private void method_86()
		{
		}

		// Token: 0x06002B54 RID: 11092 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x3600060", Offset = "0x3600060", VA = "0x3600060")]
		[Token(Token = "0x6002B54")]
		public void method_87()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B55 RID: 11093 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002B55")]
		[Address(RVA = "0x3600174", Offset = "0x3600174", VA = "0x3600174")]
		private void method_88()
		{
		}

		// Token: 0x06002B56 RID: 11094 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3600178", Offset = "0x3600178", VA = "0x3600178")]
		[Token(Token = "0x6002B56")]
		private void method_89()
		{
		}

		// Token: 0x06002B57 RID: 11095 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x360017C", Offset = "0x360017C", VA = "0x360017C")]
		[Token(Token = "0x6002B57")]
		private void method_90()
		{
		}

		// Token: 0x06002B58 RID: 11096 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x3600180", Offset = "0x3600180", VA = "0x3600180")]
		[Token(Token = "0x6002B58")]
		public void method_91()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B59 RID: 11097 RVA: 0x0005B698 File Offset: 0x00059898
		[Address(RVA = "0x3600294", Offset = "0x3600294", VA = "0x3600294")]
		[Token(Token = "0x6002B59")]
		public void method_92()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x0400057E RID: 1406
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400057E")]
		public float float_0;

		// Token: 0x0400057F RID: 1407
		[Token(Token = "0x400057F")]
		[FieldOffset(Offset = "0x1C")]
		public float float_1;

		// Token: 0x04000580 RID: 1408
		[Token(Token = "0x4000580")]
		[FieldOffset(Offset = "0x20")]
		public bool bool_0;

		// Token: 0x04000581 RID: 1409
		[Token(Token = "0x4000581")]
		[FieldOffset(Offset = "0x21")]
		public bool bool_1;

		// Token: 0x04000582 RID: 1410
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000582")]
		public AudioClip audioClip_0;

		// Token: 0x04000583 RID: 1411
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000583")]
		private float float_2;
	}
}
