﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core.Sockets;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000133 RID: 307
	[Token(Token = "0x2000133")]
	public class DemoSocketables : HVREnumFlagsSocketable<GEnum14>
	{
		// Token: 0x0600302E RID: 12334 RVA: 0x000030E7 File Offset: 0x000012E7
		[Address(RVA = "0x20AEB10", Offset = "0x20AEB10", VA = "0x20AEB10")]
		[Token(Token = "0x600302E")]
		public DemoSocketables()
		{
		}
	}
}
