﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Components;
using HurricaneVR.Framework.Core;
using HurricaneVR.Framework.Core.Grabbers;
using HurricaneVR.Framework.Core.Utils;
using UnityEngine;
using UnityEngine.Events;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x0200012C RID: 300
	[Token(Token = "0x200012C")]
	public class DemoPowerUnit : MonoBehaviour
	{
		// Token: 0x06002F60 RID: 12128 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Address(RVA = "0x20A7784", Offset = "0x20A7784", VA = "0x20A7784")]
		[Token(Token = "0x6002F60")]
		private void method_0(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F61 RID: 12129 RVA: 0x0005F538 File Offset: 0x0005D738
		[Token(Token = "0x6002F61")]
		[Address(RVA = "0x20A782C", Offset = "0x20A782C", VA = "0x20A782C")]
		private void method_1(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F62 RID: 12130 RVA: 0x0005F570 File Offset: 0x0005D770
		[Address(RVA = "0x20A78C8", Offset = "0x20A78C8", VA = "0x20A78C8")]
		[Token(Token = "0x6002F62")]
		private void method_2()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			this.unityEvent_0.Invoke();
			Debug.Log("PRESS AGAIN TO CONFIRM");
		}

		// Token: 0x06002F63 RID: 12131 RVA: 0x0005F5BC File Offset: 0x0005D7BC
		[Token(Token = "0x6002F63")]
		[Address(RVA = "0x20A7A78", Offset = "0x20A7A78", VA = "0x20A7A78")]
		private void method_3(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_1;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F64 RID: 12132 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Address(RVA = "0x20A7B20", Offset = "0x20A7B20", VA = "0x20A7B20")]
		[Token(Token = "0x6002F64")]
		private void method_4(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F65 RID: 12133 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Token(Token = "0x6002F65")]
		[Address(RVA = "0x20A7BC8", Offset = "0x20A7BC8", VA = "0x20A7BC8")]
		private void method_5(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F66 RID: 12134 RVA: 0x0005F5BC File Offset: 0x0005D7BC
		[Address(RVA = "0x20A7C74", Offset = "0x20A7C74", VA = "0x20A7C74")]
		[Token(Token = "0x6002F66")]
		private void method_6(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_1;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F67 RID: 12135 RVA: 0x0005F538 File Offset: 0x0005D738
		[Token(Token = "0x6002F67")]
		[Address(RVA = "0x20A7D20", Offset = "0x20A7D20", VA = "0x20A7D20")]
		private void method_7(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F68 RID: 12136 RVA: 0x0005F538 File Offset: 0x0005D738
		[Address(RVA = "0x20A7DBC", Offset = "0x20A7DBC", VA = "0x20A7DBC")]
		[Token(Token = "0x6002F68")]
		private void method_8(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F69 RID: 12137 RVA: 0x0005F604 File Offset: 0x0005D804
		[Token(Token = "0x6002F69")]
		[Address(RVA = "0x20A7E58", Offset = "0x20A7E58", VA = "0x20A7E58")]
		private void method_9()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F6A RID: 12138 RVA: 0x0005F538 File Offset: 0x0005D738
		[Address(RVA = "0x20A7F74", Offset = "0x20A7F74", VA = "0x20A7F74")]
		[Token(Token = "0x6002F6A")]
		private void method_10(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F6B RID: 12139 RVA: 0x0005F634 File Offset: 0x0005D834
		[Token(Token = "0x6002F6B")]
		[Address(RVA = "0x20A8010", Offset = "0x20A8010", VA = "0x20A8010")]
		public bool method_11()
		{
		}

		// Token: 0x06002F6C RID: 12140 RVA: 0x0005F644 File Offset: 0x0005D844
		[Address(RVA = "0x20A8020", Offset = "0x20A8020", VA = "0x20A8020")]
		[Token(Token = "0x6002F6C")]
		private void method_12()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			this.unityEvent_0.Invoke();
			Debug.Log("EnableCosmetic");
		}

		// Token: 0x06002F6D RID: 12141 RVA: 0x0005F5BC File Offset: 0x0005D7BC
		[Address(RVA = "0x20A81D0", Offset = "0x20A81D0", VA = "0x20A81D0")]
		[Token(Token = "0x6002F6D")]
		private void method_13(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_1;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F6E RID: 12142 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Address(RVA = "0x20A8278", Offset = "0x20A8278", VA = "0x20A8278")]
		[Token(Token = "0x6002F6E")]
		private void method_14(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F6F RID: 12143 RVA: 0x0005F604 File Offset: 0x0005D804
		[Token(Token = "0x6002F6F")]
		[Address(RVA = "0x20A8324", Offset = "0x20A8324", VA = "0x20A8324")]
		private void method_15()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F70 RID: 12144 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Token(Token = "0x6002F70")]
		[Address(RVA = "0x20A8440", Offset = "0x20A8440", VA = "0x20A8440")]
		private void method_16(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F71 RID: 12145 RVA: 0x0005F5BC File Offset: 0x0005D7BC
		[Token(Token = "0x6002F71")]
		[Address(RVA = "0x20A84E8", Offset = "0x20A84E8", VA = "0x20A84E8")]
		private void method_17(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_1;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F72 RID: 12146 RVA: 0x0005F538 File Offset: 0x0005D738
		[Token(Token = "0x6002F72")]
		[Address(RVA = "0x20A8594", Offset = "0x20A8594", VA = "0x20A8594")]
		private void method_18(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F73 RID: 12147 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Token(Token = "0x6002F73")]
		[Address(RVA = "0x20A8634", Offset = "0x20A8634", VA = "0x20A8634")]
		private void method_19(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F74 RID: 12148 RVA: 0x0005F604 File Offset: 0x0005D804
		[Address(RVA = "0x20A86DC", Offset = "0x20A86DC", VA = "0x20A86DC")]
		[Token(Token = "0x6002F74")]
		private void method_20()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F75 RID: 12149 RVA: 0x0005F604 File Offset: 0x0005D804
		[Address(RVA = "0x20A87F8", Offset = "0x20A87F8", VA = "0x20A87F8")]
		[Token(Token = "0x6002F75")]
		private void method_21()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F76 RID: 12150 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Token(Token = "0x6002F76")]
		[Address(RVA = "0x20A8914", Offset = "0x20A8914", VA = "0x20A8914")]
		private void method_22(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F77 RID: 12151 RVA: 0x0005F634 File Offset: 0x0005D834
		[Address(RVA = "0x20A81C0", Offset = "0x20A81C0", VA = "0x20A81C0")]
		[Token(Token = "0x6002F77")]
		public bool method_23()
		{
		}

		// Token: 0x06002F78 RID: 12152 RVA: 0x0005F538 File Offset: 0x0005D738
		[Address(RVA = "0x20A89BC", Offset = "0x20A89BC", VA = "0x20A89BC")]
		[Token(Token = "0x6002F78")]
		private void method_24(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F79 RID: 12153 RVA: 0x0005F690 File Offset: 0x0005D890
		[Token(Token = "0x6002F79")]
		[Address(RVA = "0x20A8A5C", Offset = "0x20A8A5C", VA = "0x20A8A5C")]
		private void method_25(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_0.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F7A RID: 12154 RVA: 0x0005F604 File Offset: 0x0005D804
		[Address(RVA = "0x20A8AF8", Offset = "0x20A8AF8", VA = "0x20A8AF8")]
		[Token(Token = "0x6002F7A")]
		private void method_26()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F7B RID: 12155 RVA: 0x0005F6C8 File Offset: 0x0005D8C8
		[Address(RVA = "0x20A8C14", Offset = "0x20A8C14", VA = "0x20A8C14")]
		[Token(Token = "0x6002F7B")]
		private void method_27()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			UnityEvent unityEvent = this.unityEvent_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			unityEvent.Invoke();
			Debug.Log("tutorialCheck");
		}

		// Token: 0x06002F7C RID: 12156 RVA: 0x0005F538 File Offset: 0x0005D738
		[Address(RVA = "0x20A8DB8", Offset = "0x20A8DB8", VA = "0x20A8DB8")]
		[Token(Token = "0x6002F7C")]
		private void method_28(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F7D RID: 12157 RVA: 0x0005F604 File Offset: 0x0005D804
		[Token(Token = "0x6002F7D")]
		[Address(RVA = "0x20A8E54", Offset = "0x20A8E54", VA = "0x20A8E54")]
		private void method_29()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F7E RID: 12158 RVA: 0x0005F724 File Offset: 0x0005D924
		[Token(Token = "0x6002F7E")]
		[Address(RVA = "0x20A8F70", Offset = "0x20A8F70", VA = "0x20A8F70")]
		private void method_30()
		{
		}

		// Token: 0x06002F7F RID: 12159 RVA: 0x0005F690 File Offset: 0x0005D890
		[Address(RVA = "0x20A908C", Offset = "0x20A908C", VA = "0x20A908C")]
		[Token(Token = "0x6002F7F")]
		private void method_31(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_0.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F80 RID: 12160 RVA: 0x0005F634 File Offset: 0x0005D834
		[Token(Token = "0x6002F80")]
		[Address(RVA = "0x20A7A68", Offset = "0x20A7A68", VA = "0x20A7A68")]
		public bool method_32()
		{
		}

		// Token: 0x06002F81 RID: 12161 RVA: 0x0005F604 File Offset: 0x0005D804
		[Token(Token = "0x6002F81")]
		[Address(RVA = "0x20A9128", Offset = "0x20A9128", VA = "0x20A9128")]
		private void method_33()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F82 RID: 12162 RVA: 0x0005F5BC File Offset: 0x0005D7BC
		[Address(RVA = "0x20A9244", Offset = "0x20A9244", VA = "0x20A9244")]
		[Token(Token = "0x6002F82")]
		private void method_34(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_1;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F83 RID: 12163 RVA: 0x0005F734 File Offset: 0x0005D934
		[Address(RVA = "0x20A92F0", Offset = "0x20A92F0", VA = "0x20A92F0")]
		[Token(Token = "0x6002F83")]
		public DemoPowerUnit()
		{
			UnityEvent unityEvent = new UnityEvent();
			this.unityEvent_0 = unityEvent;
			long num = 2L;
			this.float_0 = (float)17199;
			this.int_0 = (int)num;
			base..ctor();
		}

		// Token: 0x06002F84 RID: 12164 RVA: 0x0005F768 File Offset: 0x0005D968
		[Address(RVA = "0x20A9370", Offset = "0x20A9370", VA = "0x20A9370")]
		[Token(Token = "0x6002F84")]
		private void method_35()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			this.unityEvent_0.Invoke();
			Debug.Log("RainAndThunderWeather");
		}

		// Token: 0x06002F85 RID: 12165 RVA: 0x0005F634 File Offset: 0x0005D834
		[Address(RVA = "0x20A9510", Offset = "0x20A9510", VA = "0x20A9510")]
		[Token(Token = "0x6002F85")]
		public bool method_36()
		{
		}

		// Token: 0x06002F86 RID: 12166 RVA: 0x0005F7B4 File Offset: 0x0005D9B4
		[Token(Token = "0x6002F86")]
		[Address(RVA = "0x20A9520", Offset = "0x20A9520", VA = "0x20A9520")]
		private void method_37()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002F87 RID: 12167 RVA: 0x0005F604 File Offset: 0x0005D804
		[Token(Token = "0x6002F87")]
		[Address(RVA = "0x20A963C", Offset = "0x20A963C", VA = "0x20A963C")]
		private void method_38()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F88 RID: 12168 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Address(RVA = "0x20A9758", Offset = "0x20A9758", VA = "0x20A9758")]
		[Token(Token = "0x6002F88")]
		private void method_39(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F89 RID: 12169 RVA: 0x0005F5BC File Offset: 0x0005D7BC
		[Token(Token = "0x6002F89")]
		[Address(RVA = "0x20A9800", Offset = "0x20A9800", VA = "0x20A9800")]
		private void method_40(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_1;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F8A RID: 12170 RVA: 0x0005F604 File Offset: 0x0005D804
		[Token(Token = "0x6002F8A")]
		[Address(RVA = "0x20A98A8", Offset = "0x20A98A8", VA = "0x20A98A8")]
		private void method_41()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F8B RID: 12171 RVA: 0x0005F690 File Offset: 0x0005D890
		[Address(RVA = "0x20A99C4", Offset = "0x20A99C4", VA = "0x20A99C4")]
		[Token(Token = "0x6002F8B")]
		private void method_42(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_0.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F8C RID: 12172 RVA: 0x0005F604 File Offset: 0x0005D804
		[Address(RVA = "0x20A9A64", Offset = "0x20A9A64", VA = "0x20A9A64")]
		[Token(Token = "0x6002F8C")]
		private void method_43()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x06002F8D RID: 12173 RVA: 0x0005F634 File Offset: 0x0005D834
		[Token(Token = "0x1700007D")]
		public bool Boolean_0
		{
			[Token(Token = "0x6002F8D")]
			[Address(RVA = "0x20A9B80", Offset = "0x20A9B80", VA = "0x20A9B80")]
			get
			{
			}
		}

		// Token: 0x06002F8E RID: 12174 RVA: 0x0005F7D4 File Offset: 0x0005D9D4
		[Address(RVA = "0x20A9B90", Offset = "0x20A9B90", VA = "0x20A9B90")]
		[Token(Token = "0x6002F8E")]
		private void method_44()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			this.unityEvent_0.Invoke();
			Debug.Log("ORGTARG");
		}

		// Token: 0x06002F8F RID: 12175 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Address(RVA = "0x20A9D30", Offset = "0x20A9D30", VA = "0x20A9D30")]
		[Token(Token = "0x6002F8F")]
		private void method_45(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F90 RID: 12176 RVA: 0x0005F820 File Offset: 0x0005DA20
		[Token(Token = "0x6002F90")]
		[Address(RVA = "0x20A9DDC", Offset = "0x20A9DDC", VA = "0x20A9DDC")]
		private void method_46(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_1;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}

		// Token: 0x06002F91 RID: 12177 RVA: 0x0005F538 File Offset: 0x0005D738
		[Address(RVA = "0x20A9E88", Offset = "0x20A9E88", VA = "0x20A9E88")]
		[Token(Token = "0x6002F91")]
		private void method_47(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F92 RID: 12178 RVA: 0x0005F634 File Offset: 0x0005D834
		[Address(RVA = "0x20A9F28", Offset = "0x20A9F28", VA = "0x20A9F28")]
		[Token(Token = "0x6002F92")]
		public bool method_48()
		{
		}

		// Token: 0x06002F93 RID: 12179 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Token(Token = "0x6002F93")]
		[Address(RVA = "0x20A9F38", Offset = "0x20A9F38", VA = "0x20A9F38")]
		private void method_49(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F94 RID: 12180 RVA: 0x0005F604 File Offset: 0x0005D804
		[Address(RVA = "0x20A9FE4", Offset = "0x20A9FE4", VA = "0x20A9FE4")]
		[Token(Token = "0x6002F94")]
		private void method_50()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F95 RID: 12181 RVA: 0x0005F690 File Offset: 0x0005D890
		[Address(RVA = "0x20AA100", Offset = "0x20AA100", VA = "0x20AA100")]
		[Token(Token = "0x6002F95")]
		private void method_51(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_0.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002F96 RID: 12182 RVA: 0x0005F85C File Offset: 0x0005DA5C
		[Token(Token = "0x6002F96")]
		[Address(RVA = "0x20AA19C", Offset = "0x20AA19C", VA = "0x20AA19C")]
		private void Start()
		{
			VRGrabberEvent u0747_u0608_u058Cզ = this.hvrsocket_0.\u0747\u0608\u058Cզ;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			u0747_u0608_u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			u0747_u0608_u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F97 RID: 12183 RVA: 0x0005F884 File Offset: 0x0005DA84
		[Token(Token = "0x6002F97")]
		[Address(RVA = "0x20AA2B8", Offset = "0x20AA2B8", VA = "0x20AA2B8")]
		private void method_52()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			UnityEvent unityEvent = this.unityEvent_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			unityEvent.Invoke();
			Debug.Log("2BN");
		}

		// Token: 0x06002F98 RID: 12184 RVA: 0x0005F5BC File Offset: 0x0005D7BC
		[Address(RVA = "0x20AA45C", Offset = "0x20AA45C", VA = "0x20AA45C")]
		[Token(Token = "0x6002F98")]
		private void method_53(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_1;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F99 RID: 12185 RVA: 0x0005F604 File Offset: 0x0005D804
		[Address(RVA = "0x20AA504", Offset = "0x20AA504", VA = "0x20AA504")]
		[Token(Token = "0x6002F99")]
		private void method_54()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F9A RID: 12186 RVA: 0x0005F604 File Offset: 0x0005D804
		[Address(RVA = "0x20AA620", Offset = "0x20AA620", VA = "0x20AA620")]
		[Token(Token = "0x6002F9A")]
		private void method_55()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002F9B RID: 12187 RVA: 0x0005F8E0 File Offset: 0x0005DAE0
		[Address(RVA = "0x20AA73C", Offset = "0x20AA73C", VA = "0x20AA73C")]
		[Token(Token = "0x6002F9B")]
		private void method_56()
		{
		}

		// Token: 0x06002F9C RID: 12188 RVA: 0x0005F8F0 File Offset: 0x0005DAF0
		[Token(Token = "0x6002F9C")]
		[Address(RVA = "0x20AA858", Offset = "0x20AA858", VA = "0x20AA858")]
		private void method_57()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			UnityEvent unityEvent = this.unityEvent_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			unityEvent.Invoke();
			Debug.Log("M/d/yyyy");
		}

		// Token: 0x06002F9D RID: 12189 RVA: 0x0005F94C File Offset: 0x0005DB4C
		[Address(RVA = "0x20AAA0C", Offset = "0x20AAA0C", VA = "0x20AAA0C")]
		[Token(Token = "0x6002F9D")]
		private void method_58()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			UnityEvent unityEvent = this.unityEvent_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			unityEvent.Invoke();
			Debug.Log("Cannot access index {0}. Buffer is empty");
		}

		// Token: 0x06002F9E RID: 12190 RVA: 0x0005F538 File Offset: 0x0005D738
		[Token(Token = "0x6002F9E")]
		[Address(RVA = "0x20AABB0", Offset = "0x20AABB0", VA = "0x20AABB0")]
		private void method_59(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002F9F RID: 12191 RVA: 0x0005F690 File Offset: 0x0005D890
		[Address(RVA = "0x20AAC50", Offset = "0x20AAC50", VA = "0x20AAC50")]
		[Token(Token = "0x6002F9F")]
		private void method_60(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_0.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002FA0 RID: 12192 RVA: 0x0005F9A8 File Offset: 0x0005DBA8
		[Token(Token = "0x6002FA0")]
		[Address(RVA = "0x20AACEC", Offset = "0x20AACEC", VA = "0x20AACEC")]
		private void method_61(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_1;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			if (this.material_0 == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002FA1 RID: 12193 RVA: 0x0005F538 File Offset: 0x0005D738
		[Address(RVA = "0x20AAD98", Offset = "0x20AAD98", VA = "0x20AAD98")]
		[Token(Token = "0x6002FA1")]
		private void method_62(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002FA2 RID: 12194 RVA: 0x0005F538 File Offset: 0x0005D738
		[Address(RVA = "0x20AAE38", Offset = "0x20AAE38", VA = "0x20AAE38")]
		[Token(Token = "0x6002FA2")]
		private void method_63(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002FA3 RID: 12195 RVA: 0x0005F604 File Offset: 0x0005D804
		[Token(Token = "0x6002FA3")]
		[Address(RVA = "0x20AAED4", Offset = "0x20AAED4", VA = "0x20AAED4")]
		private void method_64()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002FA4 RID: 12196 RVA: 0x0005F690 File Offset: 0x0005D890
		[Address(RVA = "0x20AAFF0", Offset = "0x20AAFF0", VA = "0x20AAFF0")]
		[Token(Token = "0x6002FA4")]
		private void method_65(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_0.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002FA5 RID: 12197 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Token(Token = "0x6002FA5")]
		[Address(RVA = "0x20AB090", Offset = "0x20AB090", VA = "0x20AB090")]
		private void method_66(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002FA6 RID: 12198 RVA: 0x0005F604 File Offset: 0x0005D804
		[Address(RVA = "0x20AB138", Offset = "0x20AB138", VA = "0x20AB138")]
		[Token(Token = "0x6002FA6")]
		private void method_67()
		{
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.hvrsocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction2;
			this.hvrsocket_1.\u0747\u0608\u058Cզ.AddListener(unityAction2);
		}

		// Token: 0x06002FA7 RID: 12199 RVA: 0x0005F634 File Offset: 0x0005D834
		[Address(RVA = "0x20AA9FC", Offset = "0x20AA9FC", VA = "0x20AA9FC")]
		[Token(Token = "0x6002FA7")]
		public bool method_68()
		{
		}

		// Token: 0x06002FA8 RID: 12200 RVA: 0x0005F9EC File Offset: 0x0005DBEC
		[Token(Token = "0x6002FA8")]
		[Address(RVA = "0x20AB254", Offset = "0x20AB254", VA = "0x20AB254")]
		private void Update()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			UnityEvent unityEvent = this.unityEvent_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			unityEvent.Invoke();
			Debug.Log("poweredup!");
		}

		// Token: 0x06002FA9 RID: 12201 RVA: 0x0005F634 File Offset: 0x0005D834
		[Address(RVA = "0x20AB3F8", Offset = "0x20AB3F8", VA = "0x20AB3F8")]
		[Token(Token = "0x6002FA9")]
		public bool method_69()
		{
		}

		// Token: 0x06002FAA RID: 12202 RVA: 0x0005F4F0 File Offset: 0x0005D6F0
		[Address(RVA = "0x20AB408", Offset = "0x20AB408", VA = "0x20AB408")]
		[Token(Token = "0x6002FAA")]
		private void method_70(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_0;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002FAB RID: 12203 RVA: 0x0005FA48 File Offset: 0x0005DC48
		[Token(Token = "0x6002FAB")]
		[Address(RVA = "0x20AB4B4", Offset = "0x20AB4B4", VA = "0x20AB4B4")]
		private void method_71()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			this.unityEvent_0.Invoke();
			Debug.Log("DisableCosmetic");
		}

		// Token: 0x06002FAC RID: 12204 RVA: 0x0005F634 File Offset: 0x0005D834
		[Address(RVA = "0x20AB654", Offset = "0x20AB654", VA = "0x20AB654")]
		[Token(Token = "0x6002FAC")]
		public bool method_72()
		{
		}

		// Token: 0x06002FAD RID: 12205 RVA: 0x0005FA94 File Offset: 0x0005DC94
		[Address(RVA = "0x20AB664", Offset = "0x20AB664", VA = "0x20AB664")]
		[Token(Token = "0x6002FAD")]
		private void method_73()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			this.unityEvent_0.Invoke();
			Debug.Log("META");
		}

		// Token: 0x06002FAE RID: 12206 RVA: 0x0005F538 File Offset: 0x0005D738
		[Address(RVA = "0x20AB804", Offset = "0x20AB804", VA = "0x20AB804")]
		[Token(Token = "0x6002FAE")]
		private void method_74(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_1.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002FAF RID: 12207 RVA: 0x0005FAE0 File Offset: 0x0005DCE0
		[Address(RVA = "0x20AB8A0", Offset = "0x20AB8A0", VA = "0x20AB8A0")]
		[Token(Token = "0x6002FAF")]
		private void method_75()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			UnityEvent unityEvent = this.unityEvent_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			unityEvent.Invoke();
			Debug.Log("BN");
		}

		// Token: 0x06002FB0 RID: 12208 RVA: 0x0005F5BC File Offset: 0x0005D7BC
		[Address(RVA = "0x20ABA44", Offset = "0x20ABA44", VA = "0x20ABA44")]
		[Token(Token = "0x6002FB0")]
		private void method_76(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			int num = this.int_1;
			MeshRenderer meshRenderer = this.meshRenderer_1;
			this.int_1 = num;
			Material[] materials = meshRenderer.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_1.materials = materials;
		}

		// Token: 0x06002FB1 RID: 12209 RVA: 0x0005F690 File Offset: 0x0005D890
		[Address(RVA = "0x20ABAEC", Offset = "0x20ABAEC", VA = "0x20ABAEC")]
		[Token(Token = "0x6002FB1")]
		private void method_77(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_0)
		{
			Material[] materials = this.meshRenderer_0.materials;
			Material material = this.material_0;
			if (material != null && material == null)
			{
				throw new ArrayTypeMismatchException();
			}
			this.meshRenderer_0.materials = materials;
		}

		// Token: 0x06002FB2 RID: 12210 RVA: 0x0005FB3C File Offset: 0x0005DD3C
		[Address(RVA = "0x20ABB88", Offset = "0x20ABB88", VA = "0x20ABB88")]
		[Token(Token = "0x6002FB2")]
		private void method_78()
		{
			if (this.bool_0)
			{
				return;
			}
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRSocket hvrsocket = this.hvrsocket_0;
			Vector3 position = hvrsocket.transform.position;
			UnityEvent unityEvent = this.unityEvent_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			unityEvent.Invoke();
			Debug.Log("Squeeze");
		}

		// Token: 0x040005CA RID: 1482
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40005CA")]
		public UnityEvent unityEvent_0;

		// Token: 0x040005CB RID: 1483
		[Token(Token = "0x40005CB")]
		[FieldOffset(Offset = "0x20")]
		public HVRSocket hvrsocket_0;

		// Token: 0x040005CC RID: 1484
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40005CC")]
		public HVRSocket hvrsocket_1;

		// Token: 0x040005CD RID: 1485
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40005CD")]
		public MeshRenderer meshRenderer_0;

		// Token: 0x040005CE RID: 1486
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40005CE")]
		public MeshRenderer meshRenderer_1;

		// Token: 0x040005CF RID: 1487
		[Token(Token = "0x40005CF")]
		[FieldOffset(Offset = "0x40")]
		public HVRRotationTracker hvrrotationTracker_0;

		// Token: 0x040005D0 RID: 1488
		[Token(Token = "0x40005D0")]
		[FieldOffset(Offset = "0x48")]
		public float float_0;

		// Token: 0x040005D1 RID: 1489
		[Token(Token = "0x40005D1")]
		[FieldOffset(Offset = "0x50")]
		public AudioClip audioClip_0;

		// Token: 0x040005D2 RID: 1490
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x40005D2")]
		public int int_0;

		// Token: 0x040005D3 RID: 1491
		[FieldOffset(Offset = "0x5C")]
		[Token(Token = "0x40005D3")]
		public int int_1;

		// Token: 0x040005D4 RID: 1492
		[Token(Token = "0x40005D4")]
		[FieldOffset(Offset = "0x60")]
		public bool bool_0;

		// Token: 0x040005D5 RID: 1493
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x40005D5")]
		public Material material_0;
	}
}
