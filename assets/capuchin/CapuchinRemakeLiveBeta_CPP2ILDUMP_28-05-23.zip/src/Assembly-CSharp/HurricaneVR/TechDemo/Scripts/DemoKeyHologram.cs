﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000122 RID: 290
	[Token(Token = "0x2000122")]
	public class DemoKeyHologram : MonoBehaviour
	{
		// Token: 0x06002C89 RID: 11401 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x2127970", Offset = "0x2127970", VA = "0x2127970")]
		[Token(Token = "0x6002C89")]
		public void method_0()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002C8A RID: 11402 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002C8A")]
		[Address(RVA = "0x21279E8", Offset = "0x21279E8", VA = "0x21279E8")]
		public void method_1()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002C8B RID: 11403 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002C8B")]
		[Address(RVA = "0x2127A60", Offset = "0x2127A60", VA = "0x2127A60")]
		private void method_2()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002C8C RID: 11404 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002C8C")]
		[Address(RVA = "0x2127B74", Offset = "0x2127B74", VA = "0x2127B74")]
		public void method_3()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002C8D RID: 11405 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2127BEC", Offset = "0x2127BEC", VA = "0x2127BEC")]
		[Token(Token = "0x6002C8D")]
		private void method_4()
		{
		}

		// Token: 0x06002C8E RID: 11406 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002C8E")]
		[Address(RVA = "0x2127BF0", Offset = "0x2127BF0", VA = "0x2127BF0")]
		private void method_5()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002C8F RID: 11407 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002C8F")]
		[Address(RVA = "0x2127CF8", Offset = "0x2127CF8", VA = "0x2127CF8")]
		private void method_6()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002C90 RID: 11408 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002C90")]
		[Address(RVA = "0x2127E0C", Offset = "0x2127E0C", VA = "0x2127E0C")]
		public void method_7()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002C91 RID: 11409 RVA: 0x0005D088 File Offset: 0x0005B288
		[Token(Token = "0x6002C91")]
		[Address(RVA = "0x2127E84", Offset = "0x2127E84", VA = "0x2127E84")]
		public void method_8()
		{
			GameObject obj;
			UnityEngine.Object.Destroy(obj);
		}

		// Token: 0x06002C92 RID: 11410 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2127EFC", Offset = "0x2127EFC", VA = "0x2127EFC")]
		[Token(Token = "0x6002C92")]
		private void method_9()
		{
		}

		// Token: 0x06002C93 RID: 11411 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002C93")]
		[Address(RVA = "0x2127F00", Offset = "0x2127F00", VA = "0x2127F00")]
		private void method_10()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002C94 RID: 11412 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002C94")]
		[Address(RVA = "0x2128014", Offset = "0x2128014", VA = "0x2128014")]
		private void method_11()
		{
		}

		// Token: 0x06002C95 RID: 11413 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002C95")]
		[Address(RVA = "0x2128018", Offset = "0x2128018", VA = "0x2128018")]
		public void method_12()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002C96 RID: 11414 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x2128090", Offset = "0x2128090", VA = "0x2128090")]
		[Token(Token = "0x6002C96")]
		public void method_13()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002C97 RID: 11415 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002C97")]
		[Address(RVA = "0x2128108", Offset = "0x2128108", VA = "0x2128108")]
		public void method_14()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002C98 RID: 11416 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002C98")]
		[Address(RVA = "0x2128180", Offset = "0x2128180", VA = "0x2128180")]
		private void method_15()
		{
		}

		// Token: 0x06002C99 RID: 11417 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002C99")]
		[Address(RVA = "0x2128184", Offset = "0x2128184", VA = "0x2128184")]
		private void Start()
		{
		}

		// Token: 0x06002C9A RID: 11418 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002C9A")]
		[Address(RVA = "0x2128188", Offset = "0x2128188", VA = "0x2128188")]
		private void method_16()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002C9B RID: 11419 RVA: 0x0005D088 File Offset: 0x0005B288
		[Address(RVA = "0x212828C", Offset = "0x212828C", VA = "0x212828C")]
		[Token(Token = "0x6002C9B")]
		public void method_17()
		{
			GameObject obj;
			UnityEngine.Object.Destroy(obj);
		}

		// Token: 0x06002C9C RID: 11420 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2128304", Offset = "0x2128304", VA = "0x2128304")]
		[Token(Token = "0x6002C9C")]
		private void method_18()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002C9D RID: 11421 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x2128414", Offset = "0x2128414", VA = "0x2128414")]
		[Token(Token = "0x6002C9D")]
		public void method_19()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002C9E RID: 11422 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002C9E")]
		[Address(RVA = "0x212848C", Offset = "0x212848C", VA = "0x212848C")]
		public void method_20()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002C9F RID: 11423 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002C9F")]
		[Address(RVA = "0x2128504", Offset = "0x2128504", VA = "0x2128504")]
		private void method_21()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CA0 RID: 11424 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212860C", Offset = "0x212860C", VA = "0x212860C")]
		[Token(Token = "0x6002CA0")]
		private void method_22()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CA1 RID: 11425 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002CA1")]
		[Address(RVA = "0x2128720", Offset = "0x2128720", VA = "0x2128720")]
		private void method_23()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CA2 RID: 11426 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CA2")]
		[Address(RVA = "0x2128830", Offset = "0x2128830", VA = "0x2128830")]
		private void method_24()
		{
		}

		// Token: 0x06002CA3 RID: 11427 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CA3")]
		[Address(RVA = "0x2128834", Offset = "0x2128834", VA = "0x2128834")]
		public void method_25()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CA4 RID: 11428 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002CA4")]
		[Address(RVA = "0x21288AC", Offset = "0x21288AC", VA = "0x21288AC")]
		private void method_26()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CA5 RID: 11429 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x21289B0", Offset = "0x21289B0", VA = "0x21289B0")]
		[Token(Token = "0x6002CA5")]
		public void method_27()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CA6 RID: 11430 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CA6")]
		[Address(RVA = "0x2128A28", Offset = "0x2128A28", VA = "0x2128A28")]
		private void method_28()
		{
		}

		// Token: 0x06002CA7 RID: 11431 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CA7")]
		[Address(RVA = "0x2128A2C", Offset = "0x2128A2C", VA = "0x2128A2C")]
		private void method_29()
		{
		}

		// Token: 0x06002CA8 RID: 11432 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x2128A30", Offset = "0x2128A30", VA = "0x2128A30")]
		[Token(Token = "0x6002CA8")]
		public void method_30()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CA9 RID: 11433 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2128AA8", Offset = "0x2128AA8", VA = "0x2128AA8")]
		[Token(Token = "0x6002CA9")]
		private void method_31()
		{
		}

		// Token: 0x06002CAA RID: 11434 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CAA")]
		[Address(RVA = "0x2128AAC", Offset = "0x2128AAC", VA = "0x2128AAC")]
		public void method_32()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CAB RID: 11435 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CAB")]
		[Address(RVA = "0x2128B24", Offset = "0x2128B24", VA = "0x2128B24")]
		public void method_33()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CAC RID: 11436 RVA: 0x0005D09C File Offset: 0x0005B29C
		[Token(Token = "0x6002CAC")]
		[Address(RVA = "0x2128B9C", Offset = "0x2128B9C", VA = "0x2128B9C")]
		public DemoKeyHologram()
		{
			List<Vector3> list;
			this.list_0 = list;
			base..ctor();
		}

		// Token: 0x06002CAD RID: 11437 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CAD")]
		[Address(RVA = "0x2128C2C", Offset = "0x2128C2C", VA = "0x2128C2C")]
		public void method_34()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CAE RID: 11438 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2128CA4", Offset = "0x2128CA4", VA = "0x2128CA4")]
		[Token(Token = "0x6002CAE")]
		private void method_35()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CAF RID: 11439 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CAF")]
		[Address(RVA = "0x2128DA8", Offset = "0x2128DA8", VA = "0x2128DA8")]
		public void method_36()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CB0 RID: 11440 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2128E20", Offset = "0x2128E20", VA = "0x2128E20")]
		[Token(Token = "0x6002CB0")]
		private void method_37()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CB1 RID: 11441 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2128F24", Offset = "0x2128F24", VA = "0x2128F24")]
		[Token(Token = "0x6002CB1")]
		private void method_38()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CB2 RID: 11442 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CB2")]
		[Address(RVA = "0x212902C", Offset = "0x212902C", VA = "0x212902C")]
		private void method_39()
		{
		}

		// Token: 0x06002CB3 RID: 11443 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CB3")]
		[Address(RVA = "0x2129030", Offset = "0x2129030", VA = "0x2129030")]
		private void method_40()
		{
		}

		// Token: 0x06002CB4 RID: 11444 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002CB4")]
		[Address(RVA = "0x2129034", Offset = "0x2129034", VA = "0x2129034")]
		private void method_41()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CB5 RID: 11445 RVA: 0x0005D0C4 File Offset: 0x0005B2C4
		[Token(Token = "0x6002CB5")]
		[Address(RVA = "0x2129144", Offset = "0x2129144", VA = "0x2129144")]
		private void method_42()
		{
			float time = Time.time;
			float time2 = Time.time;
			ThrowHelper.ThrowArgumentOutOfRangeException();
			float time3 = Time.time;
		}

		// Token: 0x06002CB6 RID: 11446 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x2129248", Offset = "0x2129248", VA = "0x2129248")]
		[Token(Token = "0x6002CB6")]
		public void method_43()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CB7 RID: 11447 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002CB7")]
		[Address(RVA = "0x21292C0", Offset = "0x21292C0", VA = "0x21292C0")]
		private void method_44()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CB8 RID: 11448 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002CB8")]
		[Address(RVA = "0x21293C8", Offset = "0x21293C8", VA = "0x21293C8")]
		private void method_45()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CB9 RID: 11449 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CB9")]
		[Address(RVA = "0x21294DC", Offset = "0x21294DC", VA = "0x21294DC")]
		public void method_46()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CBA RID: 11450 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CBA")]
		[Address(RVA = "0x2129554", Offset = "0x2129554", VA = "0x2129554")]
		private void method_47()
		{
		}

		// Token: 0x06002CBB RID: 11451 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x2129558", Offset = "0x2129558", VA = "0x2129558")]
		[Token(Token = "0x6002CBB")]
		public void method_48()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CBC RID: 11452 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x21295D0", Offset = "0x21295D0", VA = "0x21295D0")]
		[Token(Token = "0x6002CBC")]
		public void method_49()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CBD RID: 11453 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CBD")]
		[Address(RVA = "0x2129648", Offset = "0x2129648", VA = "0x2129648")]
		private void method_50()
		{
		}

		// Token: 0x06002CBE RID: 11454 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CBE")]
		[Address(RVA = "0x212964C", Offset = "0x212964C", VA = "0x212964C")]
		public void method_51()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CBF RID: 11455 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x21296C4", Offset = "0x21296C4", VA = "0x21296C4")]
		[Token(Token = "0x6002CBF")]
		public void method_52()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CC0 RID: 11456 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002CC0")]
		[Address(RVA = "0x212973C", Offset = "0x212973C", VA = "0x212973C")]
		private void method_53()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CC1 RID: 11457 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CC1")]
		[Address(RVA = "0x2129850", Offset = "0x2129850", VA = "0x2129850")]
		private void method_54()
		{
		}

		// Token: 0x06002CC2 RID: 11458 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002CC2")]
		[Address(RVA = "0x2129854", Offset = "0x2129854", VA = "0x2129854")]
		private void method_55()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CC3 RID: 11459 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002CC3")]
		[Address(RVA = "0x2129968", Offset = "0x2129968", VA = "0x2129968")]
		private void method_56()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CC4 RID: 11460 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x2129A78", Offset = "0x2129A78", VA = "0x2129A78")]
		[Token(Token = "0x6002CC4")]
		public void method_57()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CC5 RID: 11461 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2129AF0", Offset = "0x2129AF0", VA = "0x2129AF0")]
		[Token(Token = "0x6002CC5")]
		private void method_58()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CC6 RID: 11462 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2129C00", Offset = "0x2129C00", VA = "0x2129C00")]
		[Token(Token = "0x6002CC6")]
		private void method_59()
		{
		}

		// Token: 0x06002CC7 RID: 11463 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2129C04", Offset = "0x2129C04", VA = "0x2129C04")]
		[Token(Token = "0x6002CC7")]
		private void method_60()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CC8 RID: 11464 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CC8")]
		[Address(RVA = "0x2129D14", Offset = "0x2129D14", VA = "0x2129D14")]
		public void method_61()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CC9 RID: 11465 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CC9")]
		[Address(RVA = "0x2129D8C", Offset = "0x2129D8C", VA = "0x2129D8C")]
		public void method_62()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CCA RID: 11466 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x2129E04", Offset = "0x2129E04", VA = "0x2129E04")]
		[Token(Token = "0x6002CCA")]
		public void method_63()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CCB RID: 11467 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CCB")]
		[Address(RVA = "0x2129E7C", Offset = "0x2129E7C", VA = "0x2129E7C")]
		private void method_64()
		{
		}

		// Token: 0x06002CCC RID: 11468 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002CCC")]
		[Address(RVA = "0x2129E80", Offset = "0x2129E80", VA = "0x2129E80")]
		private void method_65()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CCD RID: 11469 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CCD")]
		[Address(RVA = "0x2129F90", Offset = "0x2129F90", VA = "0x2129F90")]
		public void method_66()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CCE RID: 11470 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x212A008", Offset = "0x212A008", VA = "0x212A008")]
		[Token(Token = "0x6002CCE")]
		public void method_67()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CCF RID: 11471 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x212A080", Offset = "0x212A080", VA = "0x212A080")]
		[Token(Token = "0x6002CCF")]
		private void method_68()
		{
		}

		// Token: 0x06002CD0 RID: 11472 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CD0")]
		[Address(RVA = "0x212A084", Offset = "0x212A084", VA = "0x212A084")]
		public void method_69()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CD1 RID: 11473 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CD1")]
		[Address(RVA = "0x212A0FC", Offset = "0x212A0FC", VA = "0x212A0FC")]
		private void method_70()
		{
		}

		// Token: 0x06002CD2 RID: 11474 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x212A100", Offset = "0x212A100", VA = "0x212A100")]
		[Token(Token = "0x6002CD2")]
		public void method_71()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CD3 RID: 11475 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002CD3")]
		[Address(RVA = "0x212A178", Offset = "0x212A178", VA = "0x212A178")]
		private void method_72()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CD4 RID: 11476 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CD4")]
		[Address(RVA = "0x212A280", Offset = "0x212A280", VA = "0x212A280")]
		private void method_73()
		{
		}

		// Token: 0x06002CD5 RID: 11477 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CD5")]
		[Address(RVA = "0x212A284", Offset = "0x212A284", VA = "0x212A284")]
		private void method_74()
		{
		}

		// Token: 0x06002CD6 RID: 11478 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CD6")]
		[Address(RVA = "0x212A288", Offset = "0x212A288", VA = "0x212A288")]
		public void method_75()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CD7 RID: 11479 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6002CD7")]
		[Address(RVA = "0x212A300", Offset = "0x212A300", VA = "0x212A300")]
		private void method_76()
		{
		}

		// Token: 0x06002CD8 RID: 11480 RVA: 0x0005D0C4 File Offset: 0x0005B2C4
		[Token(Token = "0x6002CD8")]
		[Address(RVA = "0x212A304", Offset = "0x212A304", VA = "0x212A304")]
		private void method_77()
		{
			float time = Time.time;
			float time2 = Time.time;
			ThrowHelper.ThrowArgumentOutOfRangeException();
			float time3 = Time.time;
		}

		// Token: 0x06002CD9 RID: 11481 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6002CD9")]
		[Address(RVA = "0x212A408", Offset = "0x212A408", VA = "0x212A408")]
		public void method_78()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CDA RID: 11482 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x212A480", Offset = "0x212A480", VA = "0x212A480")]
		[Token(Token = "0x6002CDA")]
		private void method_79()
		{
		}

		// Token: 0x06002CDB RID: 11483 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212A484", Offset = "0x212A484", VA = "0x212A484")]
		[Token(Token = "0x6002CDB")]
		private void method_80()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CDC RID: 11484 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212A598", Offset = "0x212A598", VA = "0x212A598")]
		[Token(Token = "0x6002CDC")]
		private void method_81()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CDD RID: 11485 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212A69C", Offset = "0x212A69C", VA = "0x212A69C")]
		[Token(Token = "0x6002CDD")]
		private void method_82()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CDE RID: 11486 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x212A7A0", Offset = "0x212A7A0", VA = "0x212A7A0")]
		[Token(Token = "0x6002CDE")]
		public void method_83()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CDF RID: 11487 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212A818", Offset = "0x212A818", VA = "0x212A818")]
		[Token(Token = "0x6002CDF")]
		private void method_84()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CE0 RID: 11488 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x212A92C", Offset = "0x212A92C", VA = "0x212A92C")]
		[Token(Token = "0x6002CE0")]
		private void method_85()
		{
		}

		// Token: 0x06002CE1 RID: 11489 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x212A930", Offset = "0x212A930", VA = "0x212A930")]
		[Token(Token = "0x6002CE1")]
		private void method_86()
		{
		}

		// Token: 0x06002CE2 RID: 11490 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x212A934", Offset = "0x212A934", VA = "0x212A934")]
		[Token(Token = "0x6002CE2")]
		private void method_87()
		{
		}

		// Token: 0x06002CE3 RID: 11491 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x212A938", Offset = "0x212A938", VA = "0x212A938")]
		[Token(Token = "0x6002CE3")]
		public void method_88()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CE4 RID: 11492 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212A9B0", Offset = "0x212A9B0", VA = "0x212A9B0")]
		[Token(Token = "0x6002CE4")]
		private void method_89()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CE5 RID: 11493 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212AAC4", Offset = "0x212AAC4", VA = "0x212AAC4")]
		[Token(Token = "0x6002CE5")]
		private void Update()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CE6 RID: 11494 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212ABD4", Offset = "0x212ABD4", VA = "0x212ABD4")]
		[Token(Token = "0x6002CE6")]
		private void method_90()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CE7 RID: 11495 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212ACE4", Offset = "0x212ACE4", VA = "0x212ACE4")]
		[Token(Token = "0x6002CE7")]
		private void method_91()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CE8 RID: 11496 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212ADF4", Offset = "0x212ADF4", VA = "0x212ADF4")]
		[Token(Token = "0x6002CE8")]
		private void method_92()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CE9 RID: 11497 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x212AF04", Offset = "0x212AF04", VA = "0x212AF04")]
		[Token(Token = "0x6002CE9")]
		private void method_93()
		{
		}

		// Token: 0x06002CEA RID: 11498 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x212AF08", Offset = "0x212AF08", VA = "0x212AF08")]
		[Token(Token = "0x6002CEA")]
		private void method_94()
		{
		}

		// Token: 0x06002CEB RID: 11499 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212AF0C", Offset = "0x212AF0C", VA = "0x212AF0C")]
		[Token(Token = "0x6002CEB")]
		private void method_95()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CEC RID: 11500 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x212B01C", Offset = "0x212B01C", VA = "0x212B01C")]
		[Token(Token = "0x6002CEC")]
		public void method_96()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06002CED RID: 11501 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212B094", Offset = "0x212B094", VA = "0x212B094")]
		[Token(Token = "0x6002CED")]
		private void method_97()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CEE RID: 11502 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212B1A4", Offset = "0x212B1A4", VA = "0x212B1A4")]
		[Token(Token = "0x6002CEE")]
		private void method_98()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CEF RID: 11503 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x212B2A8", Offset = "0x212B2A8", VA = "0x212B2A8")]
		[Token(Token = "0x6002CEF")]
		private void method_99()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002CF0 RID: 11504 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x212B3BC", Offset = "0x212B3BC", VA = "0x212B3BC")]
		[Token(Token = "0x6002CF0")]
		public void method_100()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x040005A0 RID: 1440
		[Token(Token = "0x40005A0")]
		[FieldOffset(Offset = "0x18")]
		public float float_0 = (float)52429;

		// Token: 0x040005A1 RID: 1441
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x40005A1")]
		public float float_1;

		// Token: 0x040005A2 RID: 1442
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40005A2")]
		public List<Vector3> list_0;

		// Token: 0x040005A3 RID: 1443
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40005A3")]
		public int int_0;
	}
}
