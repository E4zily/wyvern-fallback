﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Components;
using TMPro;
using UnityEngine.Events;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x0200012E RID: 302
	[Token(Token = "0x200012E")]
	public class DemoSafeDial : HVRRotationTracker
	{
		// Token: 0x1700007E RID: 126
		// (get) Token: 0x06002FB3 RID: 12211 RVA: 0x0000308B File Offset: 0x0000128B
		// (set) Token: 0x06002FB4 RID: 12212 RVA: 0x00003093 File Offset: 0x00001293
		[Token(Token = "0x1700007E")]
		public GEnum13 GEnum13_0
		{
			[Address(RVA = "0x20ABD2C", Offset = "0x20ABD2C", VA = "0x20ABD2C")]
			[Token(Token = "0x6002FB3")]
			get
			{
				return this.genum13_0;
			}
			[Address(RVA = "0x20ABD34", Offset = "0x20ABD34", VA = "0x20ABD34")]
			[Token(Token = "0x6002FB4")]
			set
			{
				this.genum13_0 = value;
				this.method_14();
			}
		}

		// Token: 0x06002FB5 RID: 12213 RVA: 0x0000308B File Offset: 0x0000128B
		[Token(Token = "0x6002FB5")]
		[Address(RVA = "0x20ABDE8", Offset = "0x20ABDE8", VA = "0x20ABDE8")]
		public GEnum13 method_0()
		{
			return this.genum13_0;
		}

		// Token: 0x06002FB6 RID: 12214 RVA: 0x000030A2 File Offset: 0x000012A2
		[Address(RVA = "0x20ABDF0", Offset = "0x20ABDF0", VA = "0x20ABDF0")]
		[Token(Token = "0x6002FB6")]
		public void method_1(GEnum13 genum13_1)
		{
			this.genum13_0 = genum13_1;
			this.method_17();
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06002FB7 RID: 12215 RVA: 0x0005FB98 File Offset: 0x0005DD98
		[Token(Token = "0x17000082")]
		public bool Boolean_2
		{
			[Token(Token = "0x6002FB7")]
			[Address(RVA = "0x20ABEC0", Offset = "0x20ABEC0", VA = "0x20ABEC0")]
			get
			{
			}
		}

		// Token: 0x06002FB8 RID: 12216 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x6002FB8")]
		[Address(RVA = "0x20ABEE8", Offset = "0x20ABEE8", VA = "0x20ABEE8")]
		public int method_2()
		{
		}

		// Token: 0x06002FB9 RID: 12217 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x6002FB9")]
		[Address(RVA = "0x20ABF2C", Offset = "0x20ABF2C", VA = "0x20ABF2C")]
		public int method_3()
		{
		}

		// Token: 0x06002FBA RID: 12218 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20ABF70", Offset = "0x20ABF70", VA = "0x20ABF70")]
		[Token(Token = "0x6002FBA")]
		public bool method_4()
		{
		}

		// Token: 0x06002FBB RID: 12219 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x6002FBB")]
		[Address(RVA = "0x20ABF9C", Offset = "0x20ABF9C", VA = "0x20ABF9C")]
		public int method_5()
		{
		}

		// Token: 0x06002FBC RID: 12220 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20ABFDC", Offset = "0x20ABFDC", VA = "0x20ABFDC")]
		[Token(Token = "0x6002FBC")]
		public bool method_6()
		{
		}

		// Token: 0x06002FBD RID: 12221 RVA: 0x0000308B File Offset: 0x0000128B
		[Token(Token = "0x6002FBD")]
		[Address(RVA = "0x20AC008", Offset = "0x20AC008", VA = "0x20AC008")]
		public GEnum13 method_7()
		{
			return this.genum13_0;
		}

		// Token: 0x06002FBE RID: 12222 RVA: 0x0005FB98 File Offset: 0x0005DD98
		[Address(RVA = "0x20AC010", Offset = "0x20AC010", VA = "0x20AC010")]
		[Token(Token = "0x6002FBE")]
		public bool method_8()
		{
		}

		// Token: 0x06002FBF RID: 12223 RVA: 0x0005FB98 File Offset: 0x0005DD98
		[Token(Token = "0x6002FBF")]
		[Address(RVA = "0x20AC038", Offset = "0x20AC038", VA = "0x20AC038")]
		public bool method_9()
		{
		}

		// Token: 0x06002FC0 RID: 12224 RVA: 0x0005FBB8 File Offset: 0x0005DDB8
		[Address(RVA = "0x20AC060", Offset = "0x20AC060", VA = "0x20AC060", Slot = "36")]
		[Token(Token = "0x6002FC0")]
		protected override void \u06DFڴ٦Ԭ(float float_5, float float_6)
		{
			float num = this.float_0;
			this.float_0 = num;
			this.method_14();
		}

		// Token: 0x06002FC1 RID: 12225 RVA: 0x000030B1 File Offset: 0x000012B1
		[Token(Token = "0x6002FC1")]
		[Address(RVA = "0x20AC2D0", Offset = "0x20AC2D0", VA = "0x20AC2D0")]
		public void method_10(GEnum13 genum13_1)
		{
			this.genum13_0 = genum13_1;
			this.method_20();
		}

		// Token: 0x06002FC2 RID: 12226 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AC308", Offset = "0x20AC308", VA = "0x20AC308")]
		[Token(Token = "0x6002FC2")]
		public bool method_11()
		{
		}

		// Token: 0x06002FC3 RID: 12227 RVA: 0x00003093 File Offset: 0x00001293
		[Token(Token = "0x6002FC3")]
		[Address(RVA = "0x20AC334", Offset = "0x20AC334", VA = "0x20AC334")]
		public void method_12(GEnum13 genum13_1)
		{
			this.genum13_0 = genum13_1;
			this.method_14();
		}

		// Token: 0x06002FC4 RID: 12228 RVA: 0x0005FB98 File Offset: 0x0005DD98
		[Address(RVA = "0x20AC364", Offset = "0x20AC364", VA = "0x20AC364")]
		[Token(Token = "0x6002FC4")]
		public bool method_13()
		{
		}

		// Token: 0x06002FC5 RID: 12229 RVA: 0x0005FBDC File Offset: 0x0005DDDC
		[Address(RVA = "0x20ABD3C", Offset = "0x20ABD3C", VA = "0x20ABD3C")]
		[Token(Token = "0x6002FC5")]
		private void method_14()
		{
			if (this.genum13_0 != GEnum13.const_0)
			{
				float ԕࡧ_u05F3_u061D = this.ԕࡧ\u05F3\u061D;
				this.float_4 = ԕࡧ_u05F3_u061D;
				return;
			}
		}

		// Token: 0x06002FC6 RID: 12230 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AC38C", Offset = "0x20AC38C", VA = "0x20AC38C")]
		[Token(Token = "0x6002FC6")]
		public bool method_15()
		{
		}

		// Token: 0x06002FC7 RID: 12231 RVA: 0x0005FC00 File Offset: 0x0005DE00
		[Address(RVA = "0x20AC3B8", Offset = "0x20AC3B8", VA = "0x20AC3B8")]
		[Token(Token = "0x6002FC7")]
		private void method_16()
		{
			if (this.genum13_0 != GEnum13.const_0)
			{
				float ԕࡧ_u05F3_u061D = this.ԕࡧ\u05F3\u061D;
				this.float_4 = ԕࡧ_u05F3_u061D;
				this.float_3 = (float)32768;
				return;
			}
		}

		// Token: 0x06002FC8 RID: 12232 RVA: 0x0005FC30 File Offset: 0x0005DE30
		[Address(RVA = "0x20ABDF8", Offset = "0x20ABDF8", VA = "0x20ABDF8")]
		[Token(Token = "0x6002FC8")]
		private void method_17()
		{
			if (this.genum13_0 != GEnum13.const_0)
			{
				float ԕࡧ_u05F3_u061D = this.ԕࡧ\u05F3\u061D;
				this.float_4 = ԕࡧ_u05F3_u061D;
				this.float_3 = (float)16976;
				return;
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06002FC9 RID: 12233 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x1700007F")]
		public int Int32_0
		{
			[Address(RVA = "0x20AC238", Offset = "0x20AC238", VA = "0x20AC238")]
			[Token(Token = "0x6002FC9")]
			get
			{
			}
		}

		// Token: 0x06002FCA RID: 12234 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AC484", Offset = "0x20AC484", VA = "0x20AC484")]
		[Token(Token = "0x6002FCA")]
		public bool method_18()
		{
		}

		// Token: 0x06002FCB RID: 12235 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AC4B0", Offset = "0x20AC4B0", VA = "0x20AC4B0")]
		[Token(Token = "0x6002FCB")]
		public bool method_19()
		{
		}

		// Token: 0x06002FCC RID: 12236 RVA: 0x0005FC60 File Offset: 0x0005DE60
		[Address(RVA = "0x20AC4DC", Offset = "0x20AC4DC", VA = "0x20AC4DC")]
		[Token(Token = "0x6002FCC")]
		public DemoSafeDial()
		{
			long num = 1L;
			this.int_2 = (int)num;
			this.float_2 = (float)16928;
			this.int_4 = (int)num;
			UnityEvent unityEvent = new UnityEvent();
			this.unityEvent_0 = unityEvent;
			base..ctor();
		}

		// Token: 0x06002FCD RID: 12237 RVA: 0x0005FC00 File Offset: 0x0005DE00
		[Address(RVA = "0x20AC56C", Offset = "0x20AC56C", VA = "0x20AC56C")]
		[Token(Token = "0x6002FCD")]
		private void method_20()
		{
			if (this.genum13_0 != GEnum13.const_0)
			{
				float ԕࡧ_u05F3_u061D = this.ԕࡧ\u05F3\u061D;
				this.float_4 = ԕࡧ_u05F3_u061D;
				this.float_3 = (float)32768;
				return;
			}
		}

		// Token: 0x06002FCE RID: 12238 RVA: 0x0005FB98 File Offset: 0x0005DD98
		[Address(RVA = "0x20AC634", Offset = "0x20AC634", VA = "0x20AC634")]
		[Token(Token = "0x6002FCE")]
		public bool method_21()
		{
		}

		// Token: 0x06002FCF RID: 12239 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AC65C", Offset = "0x20AC65C", VA = "0x20AC65C")]
		[Token(Token = "0x6002FCF")]
		public bool method_22()
		{
		}

		// Token: 0x06002FD0 RID: 12240 RVA: 0x000030C0 File Offset: 0x000012C0
		[Address(RVA = "0x20AC688", Offset = "0x20AC688", VA = "0x20AC688", Slot = "14")]
		[Token(Token = "0x6002FD0")]
		protected override void Update()
		{
			base.Update();
		}

		// Token: 0x06002FD1 RID: 12241 RVA: 0x0005FC9C File Offset: 0x0005DE9C
		[Address(RVA = "0x20AC690", Offset = "0x20AC690", VA = "0x20AC690", Slot = "27")]
		[Token(Token = "0x6002FD1")]
		protected override void Start()
		{
			base.Start();
			this.method_14();
			TextMeshPro exists = this.textMeshPro_1;
			exists;
			object[] args = new object[8];
			string.Format("Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}", args);
		}

		// Token: 0x06002FD2 RID: 12242 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x20ACA54", Offset = "0x20ACA54", VA = "0x20ACA54")]
		[Token(Token = "0x6002FD2")]
		public int method_23()
		{
		}

		// Token: 0x06002FD3 RID: 12243 RVA: 0x0000308B File Offset: 0x0000128B
		[Address(RVA = "0x20ACA94", Offset = "0x20ACA94", VA = "0x20ACA94")]
		[Token(Token = "0x6002FD3")]
		public GEnum13 method_24()
		{
			return this.genum13_0;
		}

		// Token: 0x06002FD4 RID: 12244 RVA: 0x00003093 File Offset: 0x00001293
		[Address(RVA = "0x20ACA9C", Offset = "0x20ACA9C", VA = "0x20ACA9C")]
		[Token(Token = "0x6002FD4")]
		public void method_25(GEnum13 genum13_1)
		{
			this.genum13_0 = genum13_1;
			this.method_14();
		}

		// Token: 0x06002FD5 RID: 12245 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20ACACC", Offset = "0x20ACACC", VA = "0x20ACACC")]
		[Token(Token = "0x6002FD5")]
		public bool method_26()
		{
		}

		// Token: 0x06002FD6 RID: 12246 RVA: 0x000030A2 File Offset: 0x000012A2
		[Address(RVA = "0x20ACAF8", Offset = "0x20ACAF8", VA = "0x20ACAF8")]
		[Token(Token = "0x6002FD6")]
		public void method_27(GEnum13 genum13_1)
		{
			this.genum13_0 = genum13_1;
			this.method_17();
		}

		// Token: 0x06002FD7 RID: 12247 RVA: 0x0005FCD8 File Offset: 0x0005DED8
		[Address(RVA = "0x20ACB28", Offset = "0x20ACB28", VA = "0x20ACB28", Slot = "20")]
		[Token(Token = "0x6002FD7")]
		protected override void ݓדٸࡀ(int int_5, bool bool_1)
		{
			object[] args = new object[8];
			string.Format("Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}", args);
		}

		// Token: 0x06002FD8 RID: 12248 RVA: 0x0000308B File Offset: 0x0000128B
		[Address(RVA = "0x20ACF64", Offset = "0x20ACF64", VA = "0x20ACF64")]
		[Token(Token = "0x6002FD8")]
		public GEnum13 method_28()
		{
			return this.genum13_0;
		}

		// Token: 0x06002FD9 RID: 12249 RVA: 0x0000308B File Offset: 0x0000128B
		[Address(RVA = "0x20ACF6C", Offset = "0x20ACF6C", VA = "0x20ACF6C")]
		[Token(Token = "0x6002FD9")]
		public GEnum13 method_29()
		{
			return this.genum13_0;
		}

		// Token: 0x06002FDA RID: 12250 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20ACF74", Offset = "0x20ACF74", VA = "0x20ACF74")]
		[Token(Token = "0x6002FDA")]
		public bool method_30()
		{
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06002FDB RID: 12251 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Token(Token = "0x17000081")]
		public bool Boolean_1
		{
			[Address(RVA = "0x20AC2A4", Offset = "0x20AC2A4", VA = "0x20AC2A4")]
			[Token(Token = "0x6002FDB")]
			get
			{
			}
		}

		// Token: 0x06002FDC RID: 12252 RVA: 0x000030B1 File Offset: 0x000012B1
		[Address(RVA = "0x20AC300", Offset = "0x20AC300", VA = "0x20AC300")]
		[Token(Token = "0x6002FDC")]
		public void method_31(GEnum13 genum13_1)
		{
			this.genum13_0 = genum13_1;
			this.method_20();
		}

		// Token: 0x06002FDD RID: 12253 RVA: 0x000030A2 File Offset: 0x000012A2
		[Address(RVA = "0x20ACFA0", Offset = "0x20ACFA0", VA = "0x20ACFA0")]
		[Token(Token = "0x6002FDD")]
		public void method_32(GEnum13 genum13_1)
		{
			this.genum13_0 = genum13_1;
			this.method_17();
		}

		// Token: 0x06002FDE RID: 12254 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20ACFA8", Offset = "0x20ACFA8", VA = "0x20ACFA8")]
		[Token(Token = "0x6002FDE")]
		public bool method_33()
		{
		}

		// Token: 0x06002FDF RID: 12255 RVA: 0x0000308B File Offset: 0x0000128B
		[Address(RVA = "0x20ACFD4", Offset = "0x20ACFD4", VA = "0x20ACFD4")]
		[Token(Token = "0x6002FDF")]
		public GEnum13 method_34()
		{
			return this.genum13_0;
		}

		// Token: 0x06002FE0 RID: 12256 RVA: 0x00003093 File Offset: 0x00001293
		[Address(RVA = "0x20ACFDC", Offset = "0x20ACFDC", VA = "0x20ACFDC")]
		[Token(Token = "0x6002FE0")]
		public void method_35(GEnum13 genum13_1)
		{
			this.genum13_0 = genum13_1;
			this.method_14();
		}

		// Token: 0x06002FE1 RID: 12257 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x20AD00C", Offset = "0x20AD00C", VA = "0x20AD00C")]
		[Token(Token = "0x6002FE1")]
		public int method_36()
		{
		}

		// Token: 0x06002FE2 RID: 12258 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AD050", Offset = "0x20AD050", VA = "0x20AD050")]
		[Token(Token = "0x6002FE2")]
		public bool method_37()
		{
		}

		// Token: 0x06002FE3 RID: 12259 RVA: 0x0000308B File Offset: 0x0000128B
		[Address(RVA = "0x20AD07C", Offset = "0x20AD07C", VA = "0x20AD07C")]
		[Token(Token = "0x6002FE3")]
		public GEnum13 method_38()
		{
			return this.genum13_0;
		}

		// Token: 0x06002FE4 RID: 12260 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AD084", Offset = "0x20AD084", VA = "0x20AD084")]
		[Token(Token = "0x6002FE4")]
		public bool method_39()
		{
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06002FE5 RID: 12261 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Token(Token = "0x17000080")]
		public bool Boolean_0
		{
			[Address(RVA = "0x20AC278", Offset = "0x20AC278", VA = "0x20AC278")]
			[Token(Token = "0x6002FE5")]
			get
			{
			}
		}

		// Token: 0x06002FE6 RID: 12262 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AD0B0", Offset = "0x20AD0B0", VA = "0x20AD0B0")]
		[Token(Token = "0x6002FE6")]
		public bool method_40()
		{
		}

		// Token: 0x06002FE7 RID: 12263 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AD0DC", Offset = "0x20AD0DC", VA = "0x20AD0DC")]
		[Token(Token = "0x6002FE7")]
		public bool method_41()
		{
		}

		// Token: 0x06002FE8 RID: 12264 RVA: 0x00003093 File Offset: 0x00001293
		[Address(RVA = "0x20AC210", Offset = "0x20AC210", VA = "0x20AC210")]
		[Token(Token = "0x6002FE8")]
		public void method_42(GEnum13 genum13_1)
		{
			this.genum13_0 = genum13_1;
			this.method_14();
		}

		// Token: 0x06002FE9 RID: 12265 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AD108", Offset = "0x20AD108", VA = "0x20AD108")]
		[Token(Token = "0x6002FE9")]
		public bool method_43()
		{
		}

		// Token: 0x06002FEA RID: 12266 RVA: 0x000030B1 File Offset: 0x000012B1
		[Address(RVA = "0x20AD134", Offset = "0x20AD134", VA = "0x20AD134")]
		[Token(Token = "0x6002FEA")]
		public void method_44(GEnum13 genum13_1)
		{
			this.genum13_0 = genum13_1;
			this.method_20();
		}

		// Token: 0x06002FEB RID: 12267 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x20AD164", Offset = "0x20AD164", VA = "0x20AD164")]
		[Token(Token = "0x6002FEB")]
		public int method_45()
		{
		}

		// Token: 0x06002FEC RID: 12268 RVA: 0x0005FBA8 File Offset: 0x0005DDA8
		[Address(RVA = "0x20AD1A4", Offset = "0x20AD1A4", VA = "0x20AD1A4")]
		[Token(Token = "0x6002FEC")]
		public bool method_46()
		{
		}

		// Token: 0x06002FED RID: 12269 RVA: 0x0005FCF8 File Offset: 0x0005DEF8
		[Address(RVA = "0x20AD1D0", Offset = "0x20AD1D0", VA = "0x20AD1D0")]
		[Token(Token = "0x6002FED")]
		private void method_47()
		{
			if (this.genum13_0 != GEnum13.const_0)
			{
				float ԕࡧ_u05F3_u061D = this.ԕࡧ\u05F3\u061D;
				this.float_4 = ԕࡧ_u05F3_u061D;
				this.float_3 = (float)49152;
				return;
			}
		}

		// Token: 0x06002FEE RID: 12270 RVA: 0x0000308B File Offset: 0x0000128B
		[Address(RVA = "0x20AD29C", Offset = "0x20AD29C", VA = "0x20AD29C")]
		[Token(Token = "0x6002FEE")]
		public GEnum13 method_48()
		{
			return this.genum13_0;
		}

		// Token: 0x06002FEF RID: 12271 RVA: 0x0005FB98 File Offset: 0x0005DD98
		[Address(RVA = "0x20AD2A4", Offset = "0x20AD2A4", VA = "0x20AD2A4")]
		[Token(Token = "0x6002FEF")]
		public bool method_49()
		{
		}

		// Token: 0x040005DB RID: 1499
		[FieldOffset(Offset = "0x88")]
		[Token(Token = "0x40005DB")]
		public TextMeshPro textMeshPro_0;

		// Token: 0x040005DC RID: 1500
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x40005DC")]
		public TextMeshPro textMeshPro_1;

		// Token: 0x040005DD RID: 1501
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x40005DD")]
		public bool bool_0;

		// Token: 0x040005DE RID: 1502
		[Token(Token = "0x40005DE")]
		[FieldOffset(Offset = "0x9C")]
		public int int_0;

		// Token: 0x040005DF RID: 1503
		[FieldOffset(Offset = "0xA0")]
		[Token(Token = "0x40005DF")]
		public int int_1;

		// Token: 0x040005E0 RID: 1504
		[FieldOffset(Offset = "0xA4")]
		[Token(Token = "0x40005E0")]
		public int int_2;

		// Token: 0x040005E1 RID: 1505
		[Token(Token = "0x40005E1")]
		[FieldOffset(Offset = "0xA8")]
		public int int_3;

		// Token: 0x040005E2 RID: 1506
		[FieldOffset(Offset = "0xAC")]
		[Token(Token = "0x40005E2")]
		public float float_0;

		// Token: 0x040005E3 RID: 1507
		[Token(Token = "0x40005E3")]
		[FieldOffset(Offset = "0xB0")]
		public float float_1;

		// Token: 0x040005E4 RID: 1508
		[Token(Token = "0x40005E4")]
		[FieldOffset(Offset = "0xB4")]
		public float float_2;

		// Token: 0x040005E5 RID: 1509
		[FieldOffset(Offset = "0xB8")]
		[Token(Token = "0x40005E5")]
		public float float_3;

		// Token: 0x040005E6 RID: 1510
		[Token(Token = "0x40005E6")]
		[FieldOffset(Offset = "0xBC")]
		public float float_4;

		// Token: 0x040005E7 RID: 1511
		[FieldOffset(Offset = "0xC0")]
		[Token(Token = "0x40005E7")]
		public int int_4;

		// Token: 0x040005E8 RID: 1512
		[Token(Token = "0x40005E8")]
		[FieldOffset(Offset = "0xC8")]
		public UnityEvent unityEvent_0;

		// Token: 0x040005E9 RID: 1513
		[FieldOffset(Offset = "0xD0")]
		[Token(Token = "0x40005E9")]
		private GEnum13 genum13_0;
	}
}
