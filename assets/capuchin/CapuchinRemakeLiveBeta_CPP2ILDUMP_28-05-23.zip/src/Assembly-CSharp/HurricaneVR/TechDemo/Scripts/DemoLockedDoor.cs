﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000128 RID: 296
	[Token(Token = "0x2000128")]
	public class DemoLockedDoor : MonoBehaviour
	{
		// Token: 0x06002E48 RID: 11848 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B1F38C", Offset = "0x1B1F38C", VA = "0x1B1F38C")]
		[Token(Token = "0x6002E48")]
		private void method_0()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E49 RID: 11849 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E49")]
		[Address(RVA = "0x1B1F454", Offset = "0x1B1F454", VA = "0x1B1F454")]
		public void method_1()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E4A RID: 11850 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B1F514", Offset = "0x1B1F514", VA = "0x1B1F514")]
		[Token(Token = "0x6002E4A")]
		private void method_2()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E4B RID: 11851 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B1F5DC", Offset = "0x1B1F5DC", VA = "0x1B1F5DC")]
		[Token(Token = "0x6002E4B")]
		private void method_3()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E4C RID: 11852 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B1F6A4", Offset = "0x1B1F6A4", VA = "0x1B1F6A4")]
		[Token(Token = "0x6002E4C")]
		public void method_4()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E4D RID: 11853 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E4D")]
		[Address(RVA = "0x1B1F764", Offset = "0x1B1F764", VA = "0x1B1F764")]
		private void method_5()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E4E RID: 11854 RVA: 0x0005EB80 File Offset: 0x0005CD80
		[Token(Token = "0x6002E4E")]
		[Address(RVA = "0x1B1F82C", Offset = "0x1B1F82C", VA = "0x1B1F82C")]
		private void method_6()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_113();
				return;
			}
		}

		// Token: 0x06002E4F RID: 11855 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B1F99C", Offset = "0x1B1F99C", VA = "0x1B1F99C")]
		[Token(Token = "0x6002E4F")]
		public void method_7()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E50 RID: 11856 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B1FA5C", Offset = "0x1B1FA5C", VA = "0x1B1FA5C")]
		[Token(Token = "0x6002E50")]
		public void method_8()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E51 RID: 11857 RVA: 0x0005EBB8 File Offset: 0x0005CDB8
		[Address(RVA = "0x1B1FB1C", Offset = "0x1B1FB1C", VA = "0x1B1FB1C")]
		[Token(Token = "0x6002E51")]
		private void method_9()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = component.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_53();
				return;
			}
		}

		// Token: 0x06002E52 RID: 11858 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E52")]
		[Address(RVA = "0x1B1FC8C", Offset = "0x1B1FC8C", VA = "0x1B1FC8C")]
		public void method_10()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E53 RID: 11859 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E53")]
		[Address(RVA = "0x1B1FD4C", Offset = "0x1B1FD4C", VA = "0x1B1FD4C")]
		public void method_11()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E54 RID: 11860 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B1FE0C", Offset = "0x1B1FE0C", VA = "0x1B1FE0C")]
		[Token(Token = "0x6002E54")]
		private void method_12()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E55 RID: 11861 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B1FED4", Offset = "0x1B1FED4", VA = "0x1B1FED4")]
		[Token(Token = "0x6002E55")]
		private void method_13()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E56 RID: 11862 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B1FF9C", Offset = "0x1B1FF9C", VA = "0x1B1FF9C")]
		[Token(Token = "0x6002E56")]
		private void method_14()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002E57 RID: 11863 RVA: 0x0005EBF0 File Offset: 0x0005CDF0
		[Address(RVA = "0x1B2010C", Offset = "0x1B2010C", VA = "0x1B2010C")]
		[Token(Token = "0x6002E57")]
		private void method_15()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_77();
				return;
			}
		}

		// Token: 0x06002E58 RID: 11864 RVA: 0x0005EC28 File Offset: 0x0005CE28
		[Token(Token = "0x6002E58")]
		[Address(RVA = "0x1B2027C", Offset = "0x1B2027C", VA = "0x1B2027C")]
		private void method_16()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_0();
				return;
			}
		}

		// Token: 0x06002E59 RID: 11865 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B20324", Offset = "0x1B20324", VA = "0x1B20324")]
		[Token(Token = "0x6002E59")]
		public void method_17()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E5A RID: 11866 RVA: 0x0005EC60 File Offset: 0x0005CE60
		[Token(Token = "0x6002E5A")]
		[Address(RVA = "0x1B203E4", Offset = "0x1B203E4", VA = "0x1B203E4")]
		private void method_18()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_60();
				return;
			}
		}

		// Token: 0x06002E5B RID: 11867 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B20554", Offset = "0x1B20554", VA = "0x1B20554")]
		[Token(Token = "0x6002E5B")]
		public void method_19()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E5C RID: 11868 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B20614", Offset = "0x1B20614", VA = "0x1B20614")]
		[Token(Token = "0x6002E5C")]
		private void method_20()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E5D RID: 11869 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B206DC", Offset = "0x1B206DC", VA = "0x1B206DC")]
		[Token(Token = "0x6002E5D")]
		public void method_21()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E5E RID: 11870 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E5E")]
		[Address(RVA = "0x1B2079C", Offset = "0x1B2079C", VA = "0x1B2079C")]
		public void method_22()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E5F RID: 11871 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E5F")]
		[Address(RVA = "0x1B2085C", Offset = "0x1B2085C", VA = "0x1B2085C")]
		private void method_23()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E60 RID: 11872 RVA: 0x0005EC98 File Offset: 0x0005CE98
		[Token(Token = "0x6002E60")]
		[Address(RVA = "0x1B20924", Offset = "0x1B20924", VA = "0x1B20924")]
		private void method_24()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_111();
				return;
			}
		}

		// Token: 0x06002E61 RID: 11873 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E61")]
		[Address(RVA = "0x1B20A94", Offset = "0x1B20A94", VA = "0x1B20A94")]
		private void method_25()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E62 RID: 11874 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E62")]
		[Address(RVA = "0x1B20B5C", Offset = "0x1B20B5C", VA = "0x1B20B5C")]
		public void method_26()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E63 RID: 11875 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E63")]
		[Address(RVA = "0x1B20C1C", Offset = "0x1B20C1C", VA = "0x1B20C1C")]
		private void method_27()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E64 RID: 11876 RVA: 0x0005ECD0 File Offset: 0x0005CED0
		[Address(RVA = "0x1B20CE4", Offset = "0x1B20CE4", VA = "0x1B20CE4")]
		[Token(Token = "0x6002E64")]
		private void method_28()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_117();
				return;
			}
		}

		// Token: 0x06002E65 RID: 11877 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E65")]
		[Address(RVA = "0x1B20E54", Offset = "0x1B20E54", VA = "0x1B20E54")]
		public void method_29()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E66 RID: 11878 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E66")]
		[Address(RVA = "0x1B20F14", Offset = "0x1B20F14", VA = "0x1B20F14")]
		public void method_30()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E67 RID: 11879 RVA: 0x0005ED08 File Offset: 0x0005CF08
		[Token(Token = "0x6002E67")]
		[Address(RVA = "0x1B20FD4", Offset = "0x1B20FD4", VA = "0x1B20FD4")]
		private void method_31()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_131();
				return;
			}
		}

		// Token: 0x06002E68 RID: 11880 RVA: 0x0005ED40 File Offset: 0x0005CF40
		[Token(Token = "0x6002E68")]
		[Address(RVA = "0x1B2113C", Offset = "0x1B2113C", VA = "0x1B2113C")]
		public DemoLockedDoor()
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
			base..ctor();
		}

		// Token: 0x06002E69 RID: 11881 RVA: 0x0005ED5C File Offset: 0x0005CF5C
		[Token(Token = "0x6002E69")]
		[Address(RVA = "0x1B2114C", Offset = "0x1B2114C", VA = "0x1B2114C")]
		private void method_32()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_12();
				return;
			}
		}

		// Token: 0x06002E6A RID: 11882 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E6A")]
		[Address(RVA = "0x1B211F4", Offset = "0x1B211F4", VA = "0x1B211F4")]
		private void method_33()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E6B RID: 11883 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E6B")]
		[Address(RVA = "0x1B212BC", Offset = "0x1B212BC", VA = "0x1B212BC")]
		public void method_34()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E6C RID: 11884 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E6C")]
		[Address(RVA = "0x1B2137C", Offset = "0x1B2137C", VA = "0x1B2137C")]
		private void method_35()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E6D RID: 11885 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E6D")]
		[Address(RVA = "0x1B21444", Offset = "0x1B21444", VA = "0x1B21444")]
		private void method_36()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E6E RID: 11886 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B2150C", Offset = "0x1B2150C", VA = "0x1B2150C")]
		[Token(Token = "0x6002E6E")]
		private void method_37()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E6F RID: 11887 RVA: 0x0005ED94 File Offset: 0x0005CF94
		[Address(RVA = "0x1B215D4", Offset = "0x1B215D4", VA = "0x1B215D4")]
		[Token(Token = "0x6002E6F")]
		private void method_38()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_107();
				return;
			}
		}

		// Token: 0x06002E70 RID: 11888 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E70")]
		[Address(RVA = "0x1B21740", Offset = "0x1B21740", VA = "0x1B21740")]
		public void method_39()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E71 RID: 11889 RVA: 0x0005EDCC File Offset: 0x0005CFCC
		[Token(Token = "0x6002E71")]
		[Address(RVA = "0x1B21800", Offset = "0x1B21800", VA = "0x1B21800")]
		private void method_40()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_3();
				return;
			}
		}

		// Token: 0x06002E72 RID: 11890 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E72")]
		[Address(RVA = "0x1B218A8", Offset = "0x1B218A8", VA = "0x1B218A8")]
		private void method_41()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E73 RID: 11891 RVA: 0x0005EE04 File Offset: 0x0005D004
		[Token(Token = "0x6002E73")]
		[Address(RVA = "0x1B21970", Offset = "0x1B21970", VA = "0x1B21970")]
		private void method_42()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_36();
				return;
			}
		}

		// Token: 0x06002E74 RID: 11892 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E74")]
		[Address(RVA = "0x1B21A18", Offset = "0x1B21A18", VA = "0x1B21A18")]
		private void method_43()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E75 RID: 11893 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B21AE0", Offset = "0x1B21AE0", VA = "0x1B21AE0")]
		[Token(Token = "0x6002E75")]
		public void method_44()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E76 RID: 11894 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002E76")]
		[Address(RVA = "0x1B21BA0", Offset = "0x1B21BA0", VA = "0x1B21BA0")]
		private void method_45()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002E77 RID: 11895 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E77")]
		[Address(RVA = "0x1B21C48", Offset = "0x1B21C48", VA = "0x1B21C48")]
		private void method_46()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E78 RID: 11896 RVA: 0x0005EE3C File Offset: 0x0005D03C
		[Token(Token = "0x6002E78")]
		[Address(RVA = "0x1B21D10", Offset = "0x1B21D10", VA = "0x1B21D10")]
		private void method_47()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			base.GetComponent<Rigidbody>();
			if (this.bool_0)
			{
				this.method_23();
				return;
			}
		}

		// Token: 0x06002E79 RID: 11897 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B21DB8", Offset = "0x1B21DB8", VA = "0x1B21DB8")]
		[Token(Token = "0x6002E79")]
		public void method_48()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E7A RID: 11898 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B21E78", Offset = "0x1B21E78", VA = "0x1B21E78")]
		[Token(Token = "0x6002E7A")]
		public void method_49()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E7B RID: 11899 RVA: 0x0005EE70 File Offset: 0x0005D070
		[Token(Token = "0x6002E7B")]
		[Address(RVA = "0x1B21F38", Offset = "0x1B21F38", VA = "0x1B21F38")]
		private void method_50()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_96();
				return;
			}
		}

		// Token: 0x06002E7C RID: 11900 RVA: 0x0005ED08 File Offset: 0x0005CF08
		[Address(RVA = "0x1B220A8", Offset = "0x1B220A8", VA = "0x1B220A8")]
		[Token(Token = "0x6002E7C")]
		private void Start()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_131();
				return;
			}
		}

		// Token: 0x06002E7D RID: 11901 RVA: 0x0005EE04 File Offset: 0x0005D004
		[Address(RVA = "0x1B22150", Offset = "0x1B22150", VA = "0x1B22150")]
		[Token(Token = "0x6002E7D")]
		private void method_51()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_36();
				return;
			}
		}

		// Token: 0x06002E7E RID: 11902 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B221F8", Offset = "0x1B221F8", VA = "0x1B221F8")]
		[Token(Token = "0x6002E7E")]
		public void method_52()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E7F RID: 11903 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B1FBC4", Offset = "0x1B1FBC4", VA = "0x1B1FBC4")]
		[Token(Token = "0x6002E7F")]
		private void method_53()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E80 RID: 11904 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E80")]
		[Address(RVA = "0x1B222B8", Offset = "0x1B222B8", VA = "0x1B222B8")]
		public void method_54()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E81 RID: 11905 RVA: 0x0005EEA8 File Offset: 0x0005D0A8
		[Address(RVA = "0x1B22378", Offset = "0x1B22378", VA = "0x1B22378")]
		[Token(Token = "0x6002E81")]
		private void method_55()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_87();
				return;
			}
		}

		// Token: 0x06002E82 RID: 11906 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E82")]
		[Address(RVA = "0x1B224E8", Offset = "0x1B224E8", VA = "0x1B224E8")]
		public void method_56()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E83 RID: 11907 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E83")]
		[Address(RVA = "0x1B225A8", Offset = "0x1B225A8", VA = "0x1B225A8")]
		public void method_57()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E84 RID: 11908 RVA: 0x0005EEE0 File Offset: 0x0005D0E0
		[Address(RVA = "0x1B22668", Offset = "0x1B22668", VA = "0x1B22668")]
		[Token(Token = "0x6002E84")]
		public void method_58()
		{
		}

		// Token: 0x06002E85 RID: 11909 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E85")]
		[Address(RVA = "0x1B22728", Offset = "0x1B22728", VA = "0x1B22728")]
		private void method_59()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E86 RID: 11910 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E86")]
		[Address(RVA = "0x1B2048C", Offset = "0x1B2048C", VA = "0x1B2048C")]
		private void method_60()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E87 RID: 11911 RVA: 0x0005EEF0 File Offset: 0x0005D0F0
		[Address(RVA = "0x1B227F0", Offset = "0x1B227F0", VA = "0x1B227F0")]
		[Token(Token = "0x6002E87")]
		private void method_61()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_79();
				return;
			}
		}

		// Token: 0x06002E88 RID: 11912 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B22960", Offset = "0x1B22960", VA = "0x1B22960")]
		[Token(Token = "0x6002E88")]
		private void method_62()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E89 RID: 11913 RVA: 0x0005EF28 File Offset: 0x0005D128
		[Address(RVA = "0x1B22A28", Offset = "0x1B22A28", VA = "0x1B22A28")]
		[Token(Token = "0x6002E89")]
		public void method_63()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E8A RID: 11914 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E8A")]
		[Address(RVA = "0x1B22AE8", Offset = "0x1B22AE8", VA = "0x1B22AE8")]
		private void method_64()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E8B RID: 11915 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002E8B")]
		[Address(RVA = "0x1B22BAC", Offset = "0x1B22BAC", VA = "0x1B22BAC")]
		private void method_65()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002E8C RID: 11916 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E8C")]
		[Address(RVA = "0x1B20044", Offset = "0x1B20044", VA = "0x1B20044")]
		private void method_66()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E8D RID: 11917 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E8D")]
		[Address(RVA = "0x1B22C54", Offset = "0x1B22C54", VA = "0x1B22C54")]
		public void method_67()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E8E RID: 11918 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E8E")]
		[Address(RVA = "0x1B22D14", Offset = "0x1B22D14", VA = "0x1B22D14")]
		public void method_68()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E8F RID: 11919 RVA: 0x0005EC60 File Offset: 0x0005CE60
		[Token(Token = "0x6002E8F")]
		[Address(RVA = "0x1B22DD4", Offset = "0x1B22DD4", VA = "0x1B22DD4")]
		private void method_69()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_60();
				return;
			}
		}

		// Token: 0x06002E90 RID: 11920 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E90")]
		[Address(RVA = "0x1B22E7C", Offset = "0x1B22E7C", VA = "0x1B22E7C")]
		private void method_70()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E91 RID: 11921 RVA: 0x0005EF44 File Offset: 0x0005D144
		[Token(Token = "0x6002E91")]
		[Address(RVA = "0x1B22F44", Offset = "0x1B22F44", VA = "0x1B22F44")]
		private void method_71()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_88();
				return;
			}
		}

		// Token: 0x06002E92 RID: 11922 RVA: 0x0005EF7C File Offset: 0x0005D17C
		[Address(RVA = "0x1B230B4", Offset = "0x1B230B4", VA = "0x1B230B4")]
		[Token(Token = "0x6002E92")]
		private void method_72()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_25();
				return;
			}
		}

		// Token: 0x06002E93 RID: 11923 RVA: 0x0005EFB4 File Offset: 0x0005D1B4
		[Address(RVA = "0x1B2315C", Offset = "0x1B2315C", VA = "0x1B2315C")]
		[Token(Token = "0x6002E93")]
		private void method_73()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_118();
				return;
			}
		}

		// Token: 0x06002E94 RID: 11924 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E94")]
		[Address(RVA = "0x1B232CC", Offset = "0x1B232CC", VA = "0x1B232CC")]
		public void method_74()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E95 RID: 11925 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E95")]
		[Address(RVA = "0x1B2338C", Offset = "0x1B2338C", VA = "0x1B2338C")]
		public void method_75()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E96 RID: 11926 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B2344C", Offset = "0x1B2344C", VA = "0x1B2344C")]
		[Token(Token = "0x6002E96")]
		private void method_76()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002E97 RID: 11927 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E97")]
		[Address(RVA = "0x1B201B4", Offset = "0x1B201B4", VA = "0x1B201B4")]
		private void method_77()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E98 RID: 11928 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002E98")]
		[Address(RVA = "0x1B234F4", Offset = "0x1B234F4", VA = "0x1B234F4")]
		private void method_78()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E99 RID: 11929 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B22898", Offset = "0x1B22898", VA = "0x1B22898")]
		[Token(Token = "0x6002E99")]
		private void method_79()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E9A RID: 11930 RVA: 0x0005EBF0 File Offset: 0x0005CDF0
		[Token(Token = "0x6002E9A")]
		[Address(RVA = "0x1B235BC", Offset = "0x1B235BC", VA = "0x1B235BC")]
		private void method_80()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_77();
				return;
			}
		}

		// Token: 0x06002E9B RID: 11931 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E9B")]
		[Address(RVA = "0x1B23664", Offset = "0x1B23664", VA = "0x1B23664")]
		public void method_81()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E9C RID: 11932 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B23724", Offset = "0x1B23724", VA = "0x1B23724")]
		[Token(Token = "0x6002E9C")]
		public void method_82()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E9D RID: 11933 RVA: 0x0005EDCC File Offset: 0x0005CFCC
		[Token(Token = "0x6002E9D")]
		[Address(RVA = "0x1B237E4", Offset = "0x1B237E4", VA = "0x1B237E4")]
		private void method_83()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_3();
				return;
			}
		}

		// Token: 0x06002E9E RID: 11934 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E9E")]
		[Address(RVA = "0x1B2388C", Offset = "0x1B2388C", VA = "0x1B2388C")]
		public void method_84()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002E9F RID: 11935 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002E9F")]
		[Address(RVA = "0x1B2394C", Offset = "0x1B2394C", VA = "0x1B2394C")]
		public void method_85()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EA0 RID: 11936 RVA: 0x0005EFEC File Offset: 0x0005D1EC
		[Address(RVA = "0x1B23A0C", Offset = "0x1B23A0C", VA = "0x1B23A0C")]
		[Token(Token = "0x6002EA0")]
		private void method_86()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_129();
				return;
			}
		}

		// Token: 0x06002EA1 RID: 11937 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B22420", Offset = "0x1B22420", VA = "0x1B22420")]
		[Token(Token = "0x6002EA1")]
		private void method_87()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EA2 RID: 11938 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002EA2")]
		[Address(RVA = "0x1B22FEC", Offset = "0x1B22FEC", VA = "0x1B22FEC")]
		private void method_88()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EA3 RID: 11939 RVA: 0x0005EDCC File Offset: 0x0005CFCC
		[Token(Token = "0x6002EA3")]
		[Address(RVA = "0x1B23B7C", Offset = "0x1B23B7C", VA = "0x1B23B7C")]
		private void method_89()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_3();
				return;
			}
		}

		// Token: 0x06002EA4 RID: 11940 RVA: 0x0005F024 File Offset: 0x0005D224
		[Address(RVA = "0x1B23C24", Offset = "0x1B23C24", VA = "0x1B23C24")]
		[Token(Token = "0x6002EA4")]
		private void method_90()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_5();
				return;
			}
		}

		// Token: 0x06002EA5 RID: 11941 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EA5")]
		[Address(RVA = "0x1B23CCC", Offset = "0x1B23CCC", VA = "0x1B23CCC")]
		public void method_91()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EA6 RID: 11942 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EA6")]
		[Address(RVA = "0x1B23D8C", Offset = "0x1B23D8C", VA = "0x1B23D8C")]
		public void method_92()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EA7 RID: 11943 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Address(RVA = "0x1B23E4C", Offset = "0x1B23E4C", VA = "0x1B23E4C")]
		[Token(Token = "0x6002EA7")]
		public void method_93()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EA8 RID: 11944 RVA: 0x0005F05C File Offset: 0x0005D25C
		[Token(Token = "0x6002EA8")]
		[Address(RVA = "0x1B23F0C", Offset = "0x1B23F0C", VA = "0x1B23F0C")]
		public void method_94()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EA9 RID: 11945 RVA: 0x0005F078 File Offset: 0x0005D278
		[Token(Token = "0x6002EA9")]
		[Address(RVA = "0x1B23FCC", Offset = "0x1B23FCC", VA = "0x1B23FCC")]
		private void method_95()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_20();
				return;
			}
		}

		// Token: 0x06002EAA RID: 11946 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B21FE0", Offset = "0x1B21FE0", VA = "0x1B21FE0")]
		[Token(Token = "0x6002EAA")]
		private void method_96()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EAB RID: 11947 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EAB")]
		[Address(RVA = "0x1B24074", Offset = "0x1B24074", VA = "0x1B24074")]
		public void method_97()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EAC RID: 11948 RVA: 0x0005EC28 File Offset: 0x0005CE28
		[Token(Token = "0x6002EAC")]
		[Address(RVA = "0x1B24134", Offset = "0x1B24134", VA = "0x1B24134")]
		private void method_98()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_0();
				return;
			}
		}

		// Token: 0x06002EAD RID: 11949 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002EAD")]
		[Address(RVA = "0x1B241DC", Offset = "0x1B241DC", VA = "0x1B241DC")]
		private void method_99()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EAE RID: 11950 RVA: 0x0005F0B0 File Offset: 0x0005D2B0
		[Token(Token = "0x6002EAE")]
		[Address(RVA = "0x1B242A4", Offset = "0x1B242A4", VA = "0x1B242A4")]
		private void method_100()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			base.GetComponent<Rigidbody>();
			if (this.bool_0)
			{
				this.method_60();
				return;
			}
		}

		// Token: 0x06002EAF RID: 11951 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EAF")]
		[Address(RVA = "0x1B2434C", Offset = "0x1B2434C", VA = "0x1B2434C")]
		public void method_101()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EB0 RID: 11952 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EB0")]
		[Address(RVA = "0x1B2440C", Offset = "0x1B2440C", VA = "0x1B2440C")]
		public void method_102()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EB1 RID: 11953 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B244CC", Offset = "0x1B244CC", VA = "0x1B244CC")]
		[Token(Token = "0x6002EB1")]
		private void method_103()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EB2 RID: 11954 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EB2")]
		[Address(RVA = "0x1B24594", Offset = "0x1B24594", VA = "0x1B24594")]
		public void method_104()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EB3 RID: 11955 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002EB3")]
		[Address(RVA = "0x1B24654", Offset = "0x1B24654", VA = "0x1B24654")]
		private void method_105()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EB4 RID: 11956 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002EB4")]
		[Address(RVA = "0x1B2471C", Offset = "0x1B2471C", VA = "0x1B2471C")]
		private void method_106()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EB5 RID: 11957 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B2167C", Offset = "0x1B2167C", VA = "0x1B2167C")]
		[Token(Token = "0x6002EB5")]
		private void method_107()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EB6 RID: 11958 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002EB6")]
		[Address(RVA = "0x1B247E4", Offset = "0x1B247E4", VA = "0x1B247E4")]
		private void method_108()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EB7 RID: 11959 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EB7")]
		[Address(RVA = "0x1B248AC", Offset = "0x1B248AC", VA = "0x1B248AC")]
		public void method_109()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EB8 RID: 11960 RVA: 0x0005F0E4 File Offset: 0x0005D2E4
		[Address(RVA = "0x1B2496C", Offset = "0x1B2496C", VA = "0x1B2496C")]
		[Token(Token = "0x6002EB8")]
		private void method_110()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_99();
				return;
			}
		}

		// Token: 0x06002EB9 RID: 11961 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002EB9")]
		[Address(RVA = "0x1B209CC", Offset = "0x1B209CC", VA = "0x1B209CC")]
		private void method_111()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EBA RID: 11962 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EBA")]
		[Address(RVA = "0x1B24A14", Offset = "0x1B24A14", VA = "0x1B24A14")]
		public void method_112()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EBB RID: 11963 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B1F8D4", Offset = "0x1B1F8D4", VA = "0x1B1F8D4")]
		[Token(Token = "0x6002EBB")]
		private void method_113()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EBC RID: 11964 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EBC")]
		[Address(RVA = "0x1B24AD4", Offset = "0x1B24AD4", VA = "0x1B24AD4")]
		public void method_114()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EBD RID: 11965 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002EBD")]
		[Address(RVA = "0x1B24B94", Offset = "0x1B24B94", VA = "0x1B24B94")]
		private void method_115()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EBE RID: 11966 RVA: 0x0005F11C File Offset: 0x0005D31C
		[Token(Token = "0x6002EBE")]
		[Address(RVA = "0x1B24C5C", Offset = "0x1B24C5C", VA = "0x1B24C5C")]
		private void method_116()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EBF RID: 11967 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B20D8C", Offset = "0x1B20D8C", VA = "0x1B20D8C")]
		[Token(Token = "0x6002EBF")]
		private void method_117()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EC0 RID: 11968 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B23204", Offset = "0x1B23204", VA = "0x1B23204")]
		[Token(Token = "0x6002EC0")]
		private void method_118()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EC1 RID: 11969 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EC1")]
		[Address(RVA = "0x1B24D24", Offset = "0x1B24D24", VA = "0x1B24D24")]
		public void method_119()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EC2 RID: 11970 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EC2")]
		[Address(RVA = "0x1B24DE4", Offset = "0x1B24DE4", VA = "0x1B24DE4")]
		public void method_120()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EC3 RID: 11971 RVA: 0x0005F138 File Offset: 0x0005D338
		[Address(RVA = "0x1B24EA4", Offset = "0x1B24EA4", VA = "0x1B24EA4")]
		[Token(Token = "0x6002EC3")]
		public void method_121()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EC4 RID: 11972 RVA: 0x0005ED5C File Offset: 0x0005CF5C
		[Token(Token = "0x6002EC4")]
		[Address(RVA = "0x1B24F64", Offset = "0x1B24F64", VA = "0x1B24F64")]
		private void method_122()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_12();
				return;
			}
		}

		// Token: 0x06002EC5 RID: 11973 RVA: 0x0005F154 File Offset: 0x0005D354
		[Token(Token = "0x6002EC5")]
		[Address(RVA = "0x1B2500C", Offset = "0x1B2500C", VA = "0x1B2500C")]
		private void method_123()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_105();
				return;
			}
		}

		// Token: 0x06002EC6 RID: 11974 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002EC6")]
		[Address(RVA = "0x1B250B4", Offset = "0x1B250B4", VA = "0x1B250B4")]
		public void method_124()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002EC7 RID: 11975 RVA: 0x0005F18C File Offset: 0x0005D38C
		[Address(RVA = "0x1B25174", Offset = "0x1B25174", VA = "0x1B25174")]
		[Token(Token = "0x6002EC7")]
		private void method_125()
		{
			HingeJoint hingeJoint;
			hingeJoint.GetComponent<Rigidbody>();
		}

		// Token: 0x06002EC8 RID: 11976 RVA: 0x0005ED08 File Offset: 0x0005CF08
		[Token(Token = "0x6002EC8")]
		[Address(RVA = "0x1B2521C", Offset = "0x1B2521C", VA = "0x1B2521C")]
		private void method_126()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_131();
				return;
			}
		}

		// Token: 0x06002EC9 RID: 11977 RVA: 0x0005F1A0 File Offset: 0x0005D3A0
		[Token(Token = "0x6002EC9")]
		[Address(RVA = "0x1B252C4", Offset = "0x1B252C4", VA = "0x1B252C4")]
		private void method_127()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_59();
				return;
			}
		}

		// Token: 0x06002ECA RID: 11978 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002ECA")]
		[Address(RVA = "0x1B2536C", Offset = "0x1B2536C", VA = "0x1B2536C")]
		public void method_128()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002ECB RID: 11979 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B23AB4", Offset = "0x1B23AB4", VA = "0x1B23AB4")]
		[Token(Token = "0x6002ECB")]
		private void method_129()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002ECC RID: 11980 RVA: 0x0005EB64 File Offset: 0x0005CD64
		[Token(Token = "0x6002ECC")]
		[Address(RVA = "0x1B2542C", Offset = "0x1B2542C", VA = "0x1B2542C")]
		public void method_130()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002ECD RID: 11981 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Address(RVA = "0x1B2107C", Offset = "0x1B2107C", VA = "0x1B2107C")]
		[Token(Token = "0x6002ECD")]
		private void method_131()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002ECE RID: 11982 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002ECE")]
		[Address(RVA = "0x1B254EC", Offset = "0x1B254EC", VA = "0x1B254EC")]
		private void method_132()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002ECF RID: 11983 RVA: 0x0005EB48 File Offset: 0x0005CD48
		[Token(Token = "0x6002ECF")]
		[Address(RVA = "0x1B255B4", Offset = "0x1B255B4", VA = "0x1B255B4")]
		private void method_133()
		{
			JointLimits limits = this.hingeJoint_0.limits;
		}

		// Token: 0x06002ED0 RID: 11984 RVA: 0x0005F1D8 File Offset: 0x0005D3D8
		[Token(Token = "0x6002ED0")]
		[Address(RVA = "0x1B2567C", Offset = "0x1B2567C", VA = "0x1B2567C")]
		private void method_134()
		{
			HingeJoint component = base.GetComponent<HingeJoint>();
			this.hingeJoint_0 = component;
			Rigidbody component2 = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component2;
			if (this.bool_0)
			{
				this.method_78();
				return;
			}
		}

		// Token: 0x040005C0 RID: 1472
		[Token(Token = "0x40005C0")]
		[FieldOffset(Offset = "0x18")]
		private HingeJoint hingeJoint_0;

		// Token: 0x040005C1 RID: 1473
		[Token(Token = "0x40005C1")]
		[FieldOffset(Offset = "0x20")]
		private Rigidbody rigidbody_0;

		// Token: 0x040005C2 RID: 1474
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40005C2")]
		public float float_0;

		// Token: 0x040005C3 RID: 1475
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x40005C3")]
		public float float_1;

		// Token: 0x040005C4 RID: 1476
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40005C4")]
		public bool bool_0;
	}
}
