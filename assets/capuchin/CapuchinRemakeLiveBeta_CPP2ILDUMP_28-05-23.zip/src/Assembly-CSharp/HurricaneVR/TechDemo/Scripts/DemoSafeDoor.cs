﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x0200012F RID: 303
	[Token(Token = "0x200012F")]
	public class DemoSafeDoor : MonoBehaviour
	{
		// Token: 0x06002FF0 RID: 12272 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x20AD2CC", Offset = "0x20AD2CC", VA = "0x20AD2CC")]
		[Token(Token = "0x6002FF0")]
		public DemoSafeDoor()
		{
		}
	}
}
