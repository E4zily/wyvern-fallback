﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core.Grabbers;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x0200012B RID: 299
	[Token(Token = "0x200012B")]
	public class DemoPassthroughSocket : HVRSocket
	{
		// Token: 0x06002F5D RID: 12125 RVA: 0x0005F4B0 File Offset: 0x0005D6B0
		[Address(RVA = "0x1B2C524", Offset = "0x1B2C524", VA = "0x1B2C524", Slot = "26")]
		[Token(Token = "0x6002F5D")]
		protected override void Start()
		{
			base.Start();
			long u07B3_u0640ןء = 1L;
			this.ڠܔݞڈ = (257 != 0);
			this.\u07B3\u0640ןء = (u07B3_u0640ןء != 0L);
		}

		// Token: 0x06002F5E RID: 12126 RVA: 0x0005F4D8 File Offset: 0x0005D6D8
		[Address(RVA = "0x1B2C55C", Offset = "0x1B2C55C", VA = "0x1B2C55C", Slot = "43")]
		[Token(Token = "0x6002F5E")]
		protected override void \u0611\u05B7ࡪױ(ڠהࢴۇ ڠהࢴۇ_0)
		{
			long u07EF_u088DԪܛ = 1L;
			ڠהࢴۇ_0.\u07EF\u088DԪܛ = (u07EF_u088DԪܛ != 0L);
		}

		// Token: 0x06002F5F RID: 12127 RVA: 0x00002EBB File Offset: 0x000010BB
		[Address(RVA = "0x1B2C61C", Offset = "0x1B2C61C", VA = "0x1B2C61C")]
		[Token(Token = "0x6002F5F")]
		public DemoPassthroughSocket()
		{
		}
	}
}
