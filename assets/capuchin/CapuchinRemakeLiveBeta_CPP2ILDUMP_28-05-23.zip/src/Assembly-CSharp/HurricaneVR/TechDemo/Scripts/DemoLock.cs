﻿using System;
using System.Collections;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core;
using HurricaneVR.Framework.Core.Grabbers;
using HurricaneVR.Framework.Core.Utils;
using UnityEngine;
using UnityEngine.Events;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000126 RID: 294
	[Token(Token = "0x2000126")]
	public class DemoLock : MonoBehaviour
	{
		// Token: 0x06002DB5 RID: 11701 RVA: 0x0005D7DC File Offset: 0x0005B9DC
		[Token(Token = "0x6002DB5")]
		[Address(RVA = "0x1B17400", Offset = "0x1B17400", VA = "0x1B17400")]
		public void method_0()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("Bruh i cannot go here you stupid L bozo");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				long <ԣա_u059C_u06E9>k__BackingField = 1L;
				hvrgrabbable.<ԣա\u059C\u06E9>k__BackingField = (<ԣա_u059C_u06E9>k__BackingField != 0L);
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable2 = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable2.transform.position;
			}
		}

		// Token: 0x06002DB6 RID: 11702 RVA: 0x0005D868 File Offset: 0x0005BA68
		[Address(RVA = "0x1B17638", Offset = "0x1B17638", VA = "0x1B17638")]
		[Token(Token = "0x6002DB6")]
		public void method_1()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("_WobbleX");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002DB7 RID: 11703 RVA: 0x0005D8EC File Offset: 0x0005BAEC
		[Token(Token = "0x6002DB7")]
		[Address(RVA = "0x1B17870", Offset = "0x1B17870", VA = "0x1B17870")]
		private void method_2(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_134(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DB8 RID: 11704 RVA: 0x0005D90C File Offset: 0x0005BB0C
		[Address(RVA = "0x1B17934", Offset = "0x1B17934", VA = "0x1B17934")]
		[Token(Token = "0x6002DB8")]
		private void method_3(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_136(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DB9 RID: 11705 RVA: 0x0005D92C File Offset: 0x0005BB2C
		[Token(Token = "0x6002DB9")]
		[Address(RVA = "0x1B179F8", Offset = "0x1B179F8", VA = "0x1B179F8")]
		private void method_4(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_48(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DBA RID: 11706 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DBA")]
		[Address(RVA = "0x1B17ABC", Offset = "0x1B17ABC", VA = "0x1B17ABC")]
		private IEnumerator method_5(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DBB RID: 11707 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002DBB")]
		[Address(RVA = "0x1B17B50", Offset = "0x1B17B50", VA = "0x1B17B50")]
		public void method_6()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DBC RID: 11708 RVA: 0x0005D9A8 File Offset: 0x0005BBA8
		[Address(RVA = "0x1B17C44", Offset = "0x1B17C44", VA = "0x1B17C44")]
		[Token(Token = "0x6002DBC")]
		private void method_7(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_22(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DBD RID: 11709 RVA: 0x0005D9C8 File Offset: 0x0005BBC8
		[Token(Token = "0x6002DBD")]
		[Address(RVA = "0x1B17D08", Offset = "0x1B17D08", VA = "0x1B17D08")]
		private void method_8(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_124(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DBE RID: 11710 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B17DCC", Offset = "0x1B17DCC", VA = "0x1B17DCC")]
		[Token(Token = "0x6002DBE")]
		public void method_9()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DBF RID: 11711 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DBF")]
		[Address(RVA = "0x1B17EC0", Offset = "0x1B17EC0", VA = "0x1B17EC0")]
		private IEnumerator method_10(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DC0 RID: 11712 RVA: 0x00009500 File Offset: 0x00007700
		[Address(RVA = "0x1B17F54", Offset = "0x1B17F54", VA = "0x1B17F54")]
		[Token(Token = "0x6002DC0")]
		private IEnumerator method_11(HVRGrabbable hvrgrabbable_1)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06002DC1 RID: 11713 RVA: 0x0005D9E8 File Offset: 0x0005BBE8
		[Address(RVA = "0x1B17FE8", Offset = "0x1B17FE8", VA = "0x1B17FE8")]
		[Token(Token = "0x6002DC1")]
		private void method_12(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_38(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DC2 RID: 11714 RVA: 0x0005DA08 File Offset: 0x0005BC08
		[Token(Token = "0x6002DC2")]
		[Address(RVA = "0x1B180AC", Offset = "0x1B180AC", VA = "0x1B180AC")]
		private void method_13(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_81(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DC3 RID: 11715 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B18170", Offset = "0x1B18170", VA = "0x1B18170")]
		[Token(Token = "0x6002DC3")]
		public void method_14()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DC4 RID: 11716 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002DC4")]
		[Address(RVA = "0x1B18264", Offset = "0x1B18264", VA = "0x1B18264")]
		public void method_15()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DC5 RID: 11717 RVA: 0x0005DA28 File Offset: 0x0005BC28
		[Token(Token = "0x6002DC5")]
		[Address(RVA = "0x1B18358", Offset = "0x1B18358", VA = "0x1B18358")]
		public void method_16()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("CapuchinRemade");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				long <ԣա_u059C_u06E9>k__BackingField = 1L;
				hvrgrabbable.<ԣա\u059C\u06E9>k__BackingField = (<ԣա_u059C_u06E9>k__BackingField != 0L);
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable2 = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable2.transform.position;
			}
		}

		// Token: 0x06002DC6 RID: 11718 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DC6")]
		[Address(RVA = "0x1B18590", Offset = "0x1B18590", VA = "0x1B18590")]
		private IEnumerator method_17(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DC7 RID: 11719 RVA: 0x0005DAB4 File Offset: 0x0005BCB4
		[Address(RVA = "0x1B18624", Offset = "0x1B18624", VA = "0x1B18624")]
		[Token(Token = "0x6002DC7")]
		public void method_18()
		{
			base.GetComponent<DemoPassthroughSocket>();
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DC8 RID: 11720 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DC8")]
		[Address(RVA = "0x1B18718", Offset = "0x1B18718", VA = "0x1B18718")]
		private IEnumerator method_19(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DC9 RID: 11721 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DC9")]
		[Address(RVA = "0x1B187AC", Offset = "0x1B187AC", VA = "0x1B187AC")]
		private IEnumerator method_20(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DCA RID: 11722 RVA: 0x0005DADC File Offset: 0x0005BCDC
		[Token(Token = "0x6002DCA")]
		[Address(RVA = "0x1B18840", Offset = "0x1B18840", VA = "0x1B18840")]
		public void method_21()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("Players: ");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				long <ԣա_u059C_u06E9>k__BackingField = 1L;
				hvrgrabbable.<ԣա\u059C\u06E9>k__BackingField = (<ԣա_u059C_u06E9>k__BackingField != 0L);
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable2 = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable2.transform.position;
			}
		}

		// Token: 0x06002DCB RID: 11723 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DCB")]
		[Address(RVA = "0x1B17C74", Offset = "0x1B17C74", VA = "0x1B17C74")]
		private IEnumerator method_22(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DCC RID: 11724 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B18A74", Offset = "0x1B18A74", VA = "0x1B18A74")]
		[Token(Token = "0x6002DCC")]
		private IEnumerator method_23(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DCD RID: 11725 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DCD")]
		[Address(RVA = "0x1B18B08", Offset = "0x1B18B08", VA = "0x1B18B08")]
		private IEnumerator method_24(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DCE RID: 11726 RVA: 0x0005DB68 File Offset: 0x0005BD68
		[Address(RVA = "0x1B18B9C", Offset = "0x1B18B9C", VA = "0x1B18B9C")]
		[Token(Token = "0x6002DCE")]
		public void method_25()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log(" and for the price of ");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002DCF RID: 11727 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002DCF")]
		[Address(RVA = "0x1B18DD4", Offset = "0x1B18DD4", VA = "0x1B18DD4")]
		public void Start()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DD0 RID: 11728 RVA: 0x0005D92C File Offset: 0x0005BB2C
		[Token(Token = "0x6002DD0")]
		[Address(RVA = "0x1B18EC8", Offset = "0x1B18EC8", VA = "0x1B18EC8")]
		private void method_26(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_48(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DD1 RID: 11729 RVA: 0x0005D92C File Offset: 0x0005BB2C
		[Token(Token = "0x6002DD1")]
		[Address(RVA = "0x1B18EF8", Offset = "0x1B18EF8", VA = "0x1B18EF8")]
		private void method_27(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_48(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DD2 RID: 11730 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DD2")]
		[Address(RVA = "0x1B18F28", Offset = "0x1B18F28", VA = "0x1B18F28")]
		private IEnumerator method_28(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DD3 RID: 11731 RVA: 0x0005DBEC File Offset: 0x0005BDEC
		[Address(RVA = "0x1B18FBC", Offset = "0x1B18FBC", VA = "0x1B18FBC")]
		[Token(Token = "0x6002DD3")]
		public void method_29()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("Players: ");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002DD4 RID: 11732 RVA: 0x0005DA08 File Offset: 0x0005BC08
		[Address(RVA = "0x1B191F4", Offset = "0x1B191F4", VA = "0x1B191F4")]
		[Token(Token = "0x6002DD4")]
		private void method_30(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_81(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DD5 RID: 11733 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002DD5")]
		[Address(RVA = "0x1B19224", Offset = "0x1B19224", VA = "0x1B19224")]
		public void method_31()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DD6 RID: 11734 RVA: 0x0005DC70 File Offset: 0x0005BE70
		[Token(Token = "0x6002DD6")]
		[Address(RVA = "0x1B19318", Offset = "0x1B19318", VA = "0x1B19318")]
		private void method_32(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_53(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DD7 RID: 11735 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B193DC", Offset = "0x1B193DC", VA = "0x1B193DC")]
		[Token(Token = "0x6002DD7")]
		public void method_33()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DD8 RID: 11736 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002DD8")]
		[Address(RVA = "0x1B194D0", Offset = "0x1B194D0", VA = "0x1B194D0")]
		public void method_34()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DD9 RID: 11737 RVA: 0x0005DC90 File Offset: 0x0005BE90
		[Token(Token = "0x6002DD9")]
		[Address(RVA = "0x1B195C4", Offset = "0x1B195C4", VA = "0x1B195C4")]
		public void method_35()
		{
			Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
			UnityEvent unityEvent = this.unityEvent_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			unityEvent.Invoke();
			Debug.Log("{0}/{1:f0}");
			this.hvrgrabbable_0.ރԀҿ\u0611();
			this.hvrgrabbable_0.\u07AEٳשܨ.constraints = (RigidbodyConstraints)85;
			Transform transform = this.hvrgrabbable_0.transform;
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
			Vector3 position = hvrgrabbable.transform.position;
		}

		// Token: 0x06002DDA RID: 11738 RVA: 0x0005DD20 File Offset: 0x0005BF20
		[Address(RVA = "0x1B197FC", Offset = "0x1B197FC", VA = "0x1B197FC")]
		[Token(Token = "0x6002DDA")]
		private void method_36(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_99(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DDB RID: 11739 RVA: 0x0005DD40 File Offset: 0x0005BF40
		[Address(RVA = "0x1B198C0", Offset = "0x1B198C0", VA = "0x1B198C0")]
		[Token(Token = "0x6002DDB")]
		private void method_37(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_68(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DDC RID: 11740 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B18018", Offset = "0x1B18018", VA = "0x1B18018")]
		[Token(Token = "0x6002DDC")]
		private IEnumerator method_38(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DDD RID: 11741 RVA: 0x0005DD60 File Offset: 0x0005BF60
		[Address(RVA = "0x1B19984", Offset = "0x1B19984", VA = "0x1B19984")]
		[Token(Token = "0x6002DDD")]
		private void method_39(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_58(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DDE RID: 11742 RVA: 0x0005DD80 File Offset: 0x0005BF80
		[Address(RVA = "0x1B19A48", Offset = "0x1B19A48", VA = "0x1B19A48")]
		[Token(Token = "0x6002DDE")]
		private IEnumerator method_40(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DDF RID: 11743 RVA: 0x0005DDA8 File Offset: 0x0005BFA8
		[Address(RVA = "0x1B19ADC", Offset = "0x1B19ADC", VA = "0x1B19ADC")]
		[Token(Token = "0x6002DDF")]
		public void method_41()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("You are not the master of the server, you cannot start the game.");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				this.hvrgrabbable_0.\u07AEٳשܨ.constraints = (RigidbodyConstraints)87;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				long <ԣա_u059C_u06E9>k__BackingField = 1L;
				hvrgrabbable.<ԣա\u059C\u06E9>k__BackingField = (<ԣա_u059C_u06E9>k__BackingField != 0L);
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable2 = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable2.transform.position;
			}
		}

		// Token: 0x06002DE0 RID: 11744 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B19D14", Offset = "0x1B19D14", VA = "0x1B19D14")]
		[Token(Token = "0x6002DE0")]
		private IEnumerator method_42(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DE1 RID: 11745 RVA: 0x0005D92C File Offset: 0x0005BB2C
		[Address(RVA = "0x1B19DA8", Offset = "0x1B19DA8", VA = "0x1B19DA8")]
		[Token(Token = "0x6002DE1")]
		private void method_43(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_48(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DE2 RID: 11746 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B19DD8", Offset = "0x1B19DD8", VA = "0x1B19DD8")]
		[Token(Token = "0x6002DE2")]
		private IEnumerator method_44(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DE3 RID: 11747 RVA: 0x0005DE44 File Offset: 0x0005C044
		[Address(RVA = "0x1B19E6C", Offset = "0x1B19E6C", VA = "0x1B19E6C")]
		[Token(Token = "0x6002DE3")]
		public void method_45()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("True");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				long <ԣա_u059C_u06E9>k__BackingField = 1L;
				hvrgrabbable.<ԣա\u059C\u06E9>k__BackingField = (<ԣա_u059C_u06E9>k__BackingField != 0L);
				Transform transform = this.hvrgrabbable_0.transform;
				return;
			}
		}

		// Token: 0x06002DE4 RID: 11748 RVA: 0x0005DEBC File Offset: 0x0005C0BC
		[Token(Token = "0x6002DE4")]
		[Address(RVA = "0x1B1A0A8", Offset = "0x1B1A0A8", VA = "0x1B1A0A8")]
		public void method_46()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("hand 2");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				this.hvrgrabbable_0.\u07AEٳשܨ.constraints = (RigidbodyConstraints)43;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				long <ԣա_u059C_u06E9>k__BackingField = 1L;
				hvrgrabbable.<ԣա\u059C\u06E9>k__BackingField = (<ԣա_u059C_u06E9>k__BackingField != 0L);
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable2 = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable2.transform.position;
			}
		}

		// Token: 0x06002DE5 RID: 11749 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DE5")]
		[Address(RVA = "0x1B1A2E0", Offset = "0x1B1A2E0", VA = "0x1B1A2E0")]
		private IEnumerator method_47(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DE6 RID: 11750 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DE6")]
		[Address(RVA = "0x1B17A28", Offset = "0x1B17A28", VA = "0x1B17A28")]
		private IEnumerator method_48(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DE7 RID: 11751 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B1A374", Offset = "0x1B1A374", VA = "0x1B1A374")]
		[Token(Token = "0x6002DE7")]
		public void method_49()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DE8 RID: 11752 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DE8")]
		[Address(RVA = "0x1B1A468", Offset = "0x1B1A468", VA = "0x1B1A468")]
		private IEnumerator method_50(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DE9 RID: 11753 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002DE9")]
		[Address(RVA = "0x1B1A4FC", Offset = "0x1B1A4FC", VA = "0x1B1A4FC")]
		public void method_51()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DEA RID: 11754 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DEA")]
		[Address(RVA = "0x1B1A5F0", Offset = "0x1B1A5F0", VA = "0x1B1A5F0")]
		private IEnumerator method_52(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DEB RID: 11755 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B19348", Offset = "0x1B19348", VA = "0x1B19348")]
		[Token(Token = "0x6002DEB")]
		private IEnumerator method_53(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DEC RID: 11756 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B1A684", Offset = "0x1B1A684", VA = "0x1B1A684")]
		[Token(Token = "0x6002DEC")]
		public void method_54()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DED RID: 11757 RVA: 0x0005D8EC File Offset: 0x0005BAEC
		[Address(RVA = "0x1B1A778", Offset = "0x1B1A778", VA = "0x1B1A778")]
		[Token(Token = "0x6002DED")]
		private void method_55(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_134(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DEE RID: 11758 RVA: 0x0005DF58 File Offset: 0x0005C158
		[Token(Token = "0x6002DEE")]
		[Address(RVA = "0x1B1A7A8", Offset = "0x1B1A7A8", VA = "0x1B1A7A8")]
		public void method_56()
		{
			DemoPassthroughSocket demoPassthroughSocket;
			this.demoPassthroughSocket_0 = demoPassthroughSocket;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DEF RID: 11759 RVA: 0x0005DF58 File Offset: 0x0005C158
		[Address(RVA = "0x1B1A89C", Offset = "0x1B1A89C", VA = "0x1B1A89C")]
		[Token(Token = "0x6002DEF")]
		public void method_57()
		{
			DemoPassthroughSocket demoPassthroughSocket;
			this.demoPassthroughSocket_0 = demoPassthroughSocket;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DF0 RID: 11760 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DF0")]
		[Address(RVA = "0x1B199B4", Offset = "0x1B199B4", VA = "0x1B199B4")]
		private IEnumerator method_58(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DF1 RID: 11761 RVA: 0x0005DD60 File Offset: 0x0005BF60
		[Token(Token = "0x6002DF1")]
		[Address(RVA = "0x1B1A990", Offset = "0x1B1A990", VA = "0x1B1A990")]
		private void method_59(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_58(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DF2 RID: 11762 RVA: 0x0005DF80 File Offset: 0x0005C180
		[Token(Token = "0x6002DF2")]
		[Address(RVA = "0x1B1A9C0", Offset = "0x1B1A9C0", VA = "0x1B1A9C0")]
		public void method_60()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("TurnAmount");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002DF3 RID: 11763 RVA: 0x0005DA08 File Offset: 0x0005BC08
		[Address(RVA = "0x1B1ABF8", Offset = "0x1B1ABF8", VA = "0x1B1ABF8")]
		[Token(Token = "0x6002DF3")]
		private void method_61(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_81(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DF4 RID: 11764 RVA: 0x0005E004 File Offset: 0x0005C204
		[Address(RVA = "0x1B1AC28", Offset = "0x1B1AC28", VA = "0x1B1AC28")]
		[Token(Token = "0x6002DF4")]
		public void method_62()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("You are not the master of the server, you cannot start the game.");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				this.hvrgrabbable_0.\u07AEٳשܨ.constraints = (RigidbodyConstraints)51;
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002DF5 RID: 11765 RVA: 0x0005E098 File Offset: 0x0005C298
		[Token(Token = "0x6002DF5")]
		[Address(RVA = "0x1B1AE5C", Offset = "0x1B1AE5C", VA = "0x1B1AE5C")]
		public void method_63()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
		}

		// Token: 0x06002DF6 RID: 11766 RVA: 0x0005DA08 File Offset: 0x0005BC08
		[Address(RVA = "0x1B1AF50", Offset = "0x1B1AF50", VA = "0x1B1AF50")]
		[Token(Token = "0x6002DF6")]
		private void method_64(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_81(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DF7 RID: 11767 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002DF7")]
		[Address(RVA = "0x1B1AF80", Offset = "0x1B1AF80", VA = "0x1B1AF80")]
		public void method_65()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002DF8 RID: 11768 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B1B074", Offset = "0x1B1B074", VA = "0x1B1B074")]
		[Token(Token = "0x6002DF8")]
		private IEnumerator method_66(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DF9 RID: 11769 RVA: 0x0005E0B4 File Offset: 0x0005C2B4
		[Token(Token = "0x6002DF9")]
		[Address(RVA = "0x1B1B108", Offset = "0x1B1B108", VA = "0x1B1B108")]
		public DemoLock()
		{
			long num = 1065353216L;
			this.float_0 = (float)num;
			this.float_1 = (float)17074;
			UnityEvent unityEvent = new UnityEvent();
			this.unityEvent_0 = unityEvent;
			base..ctor();
		}

		// Token: 0x06002DFA RID: 11770 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DFA")]
		[Address(RVA = "0x1B1B188", Offset = "0x1B1B188", VA = "0x1B1B188")]
		private IEnumerator method_67(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DFB RID: 11771 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DFB")]
		[Address(RVA = "0x1B198F0", Offset = "0x1B198F0", VA = "0x1B198F0")]
		private IEnumerator method_68(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DFC RID: 11772 RVA: 0x0005DB68 File Offset: 0x0005BD68
		[Token(Token = "0x6002DFC")]
		[Address(RVA = "0x1B1B21C", Offset = "0x1B1B21C", VA = "0x1B1B21C")]
		public void method_69()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log(" and for the price of ");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002DFD RID: 11773 RVA: 0x0005E0EC File Offset: 0x0005C2EC
		[Token(Token = "0x6002DFD")]
		[Address(RVA = "0x1B1B454", Offset = "0x1B1B454", VA = "0x1B1B454")]
		private void method_70(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_20(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002DFE RID: 11774 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002DFE")]
		[Address(RVA = "0x1B1B484", Offset = "0x1B1B484", VA = "0x1B1B484")]
		private IEnumerator method_71(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002DFF RID: 11775 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B1B518", Offset = "0x1B1B518", VA = "0x1B1B518")]
		[Token(Token = "0x6002DFF")]
		private IEnumerator method_72(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E00 RID: 11776 RVA: 0x0005E10C File Offset: 0x0005C30C
		[Address(RVA = "0x1B1B5AC", Offset = "0x1B1B5AC", VA = "0x1B1B5AC")]
		[Token(Token = "0x6002E00")]
		private void method_73(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_17(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E01 RID: 11777 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B1B5DC", Offset = "0x1B1B5DC", VA = "0x1B1B5DC")]
		[Token(Token = "0x6002E01")]
		public void method_74()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E02 RID: 11778 RVA: 0x0005E12C File Offset: 0x0005C32C
		[Token(Token = "0x6002E02")]
		[Address(RVA = "0x1B1B6D0", Offset = "0x1B1B6D0", VA = "0x1B1B6D0")]
		public void method_75()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("BLUTARG");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				this.hvrgrabbable_0.\u07AEٳשܨ.constraints = (RigidbodyConstraints)116;
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E03 RID: 11779 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002E03")]
		[Address(RVA = "0x1B1B904", Offset = "0x1B1B904", VA = "0x1B1B904")]
		public void method_76()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E04 RID: 11780 RVA: 0x0005E1B8 File Offset: 0x0005C3B8
		[Address(RVA = "0x1B1B9F8", Offset = "0x1B1B9F8", VA = "0x1B1B9F8")]
		[Token(Token = "0x6002E04")]
		public void method_77()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("Found Gameobject: ");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				long <ԣա_u059C_u06E9>k__BackingField = 1L;
				hvrgrabbable.<ԣա\u059C\u06E9>k__BackingField = (<ԣա_u059C_u06E9>k__BackingField != 0L);
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable2 = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable2.transform.position;
			}
		}

		// Token: 0x06002E05 RID: 11781 RVA: 0x0005E244 File Offset: 0x0005C444
		[Token(Token = "0x6002E05")]
		[Address(RVA = "0x1B1BC30", Offset = "0x1B1BC30", VA = "0x1B1BC30")]
		private void method_78(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_108(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E06 RID: 11782 RVA: 0x0005E264 File Offset: 0x0005C464
		[Token(Token = "0x6002E06")]
		[Address(RVA = "0x1B1BCF4", Offset = "0x1B1BCF4", VA = "0x1B1BCF4")]
		public void method_79()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("vive");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E07 RID: 11783 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002E07")]
		[Address(RVA = "0x1B1BF28", Offset = "0x1B1BF28", VA = "0x1B1BF28")]
		public void method_80()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E08 RID: 11784 RVA: 0x0005E2DC File Offset: 0x0005C4DC
		[Address(RVA = "0x1B180DC", Offset = "0x1B180DC", VA = "0x1B180DC")]
		[Token(Token = "0x6002E08")]
		private IEnumerator method_81(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class;
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E09 RID: 11785 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002E09")]
		[Address(RVA = "0x1B1C01C", Offset = "0x1B1C01C", VA = "0x1B1C01C")]
		private IEnumerator method_82(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E0A RID: 11786 RVA: 0x0005E2FC File Offset: 0x0005C4FC
		[Address(RVA = "0x1B1C0B0", Offset = "0x1B1C0B0", VA = "0x1B1C0B0")]
		[Token(Token = "0x6002E0A")]
		private void method_83(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			this.method_47(hvrgrabbable_1);
		}

		// Token: 0x06002E0B RID: 11787 RVA: 0x0005E244 File Offset: 0x0005C444
		[Address(RVA = "0x1B1C0E0", Offset = "0x1B1C0E0", VA = "0x1B1C0E0")]
		[Token(Token = "0x6002E0B")]
		private void method_84(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_108(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E0C RID: 11788 RVA: 0x0005E314 File Offset: 0x0005C514
		[Token(Token = "0x6002E0C")]
		[Address(RVA = "0x1B1C110", Offset = "0x1B1C110", VA = "0x1B1C110")]
		public void method_85()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				if (num != 0L)
				{
				}
				Debug.Log("username");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				this.hvrgrabbable_0.\u07AEٳשܨ.constraints = (RigidbodyConstraints)82;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				long <ԣա_u059C_u06E9>k__BackingField = 1L;
				hvrgrabbable.<ԣա\u059C\u06E9>k__BackingField = (<ԣա_u059C_u06E9>k__BackingField != 0L);
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable2 = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable2.transform.position;
			}
		}

		// Token: 0x06002E0D RID: 11789 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B1C34C", Offset = "0x1B1C34C", VA = "0x1B1C34C")]
		[Token(Token = "0x6002E0D")]
		public void method_86()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E0E RID: 11790 RVA: 0x0005E3C4 File Offset: 0x0005C5C4
		[Token(Token = "0x6002E0E")]
		[Address(RVA = "0x1B1C440", Offset = "0x1B1C440", VA = "0x1B1C440")]
		public void Update()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("lock unlocked!");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E0F RID: 11791 RVA: 0x0005E0EC File Offset: 0x0005C2EC
		[Token(Token = "0x6002E0F")]
		[Address(RVA = "0x1B1C670", Offset = "0x1B1C670", VA = "0x1B1C670")]
		private void method_87(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_20(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E10 RID: 11792 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002E10")]
		[Address(RVA = "0x1B1C6A0", Offset = "0x1B1C6A0", VA = "0x1B1C6A0")]
		public void method_88()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E11 RID: 11793 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B1C794", Offset = "0x1B1C794", VA = "0x1B1C794")]
		[Token(Token = "0x6002E11")]
		public void method_89()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E12 RID: 11794 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002E12")]
		[Address(RVA = "0x1B1C888", Offset = "0x1B1C888", VA = "0x1B1C888")]
		private IEnumerator method_90(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E13 RID: 11795 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002E13")]
		[Address(RVA = "0x1B1C91C", Offset = "0x1B1C91C", VA = "0x1B1C91C")]
		public void method_91()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E14 RID: 11796 RVA: 0x0005E448 File Offset: 0x0005C648
		[Token(Token = "0x6002E14")]
		[Address(RVA = "0x1B1CA10", Offset = "0x1B1CA10", VA = "0x1B1CA10")]
		private void method_92(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_128(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E15 RID: 11797 RVA: 0x0005E468 File Offset: 0x0005C668
		[Address(RVA = "0x1B1CAD4", Offset = "0x1B1CAD4", VA = "0x1B1CAD4")]
		[Token(Token = "0x6002E15")]
		public void method_93()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("username");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E16 RID: 11798 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002E16")]
		[Address(RVA = "0x1B1CD08", Offset = "0x1B1CD08", VA = "0x1B1CD08")]
		public void method_94()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E17 RID: 11799 RVA: 0x0005DD60 File Offset: 0x0005BF60
		[Address(RVA = "0x1B1CDFC", Offset = "0x1B1CDFC", VA = "0x1B1CDFC")]
		[Token(Token = "0x6002E17")]
		private void method_95(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_58(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E18 RID: 11800 RVA: 0x0005E4E0 File Offset: 0x0005C6E0
		[Address(RVA = "0x1B1CE2C", Offset = "0x1B1CE2C", VA = "0x1B1CE2C")]
		[Token(Token = "0x6002E18")]
		public void method_96()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("Cheating");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E19 RID: 11801 RVA: 0x0005E564 File Offset: 0x0005C764
		[Token(Token = "0x6002E19")]
		[Address(RVA = "0x1B1D064", Offset = "0x1B1D064", VA = "0x1B1D064")]
		public void method_97()
		{
			Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
			UnityEvent unityEvent = this.unityEvent_0;
			long num = 1L;
			this.bool_0 = (num != 0L);
			unityEvent.Invoke();
			Debug.Log("Player");
			this.hvrgrabbable_0.ރԀҿ\u0611();
			Transform transform = this.hvrgrabbable_0.transform;
			SFXPlayer.أ\u089Dࢮ\u0745;
			HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
			Vector3 position = hvrgrabbable.transform.position;
		}

		// Token: 0x06002E1A RID: 11802 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002E1A")]
		[Address(RVA = "0x1B1D29C", Offset = "0x1B1D29C", VA = "0x1B1D29C")]
		public void method_98()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E1B RID: 11803 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002E1B")]
		[Address(RVA = "0x1B1982C", Offset = "0x1B1982C", VA = "0x1B1982C")]
		private IEnumerator method_99(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E1C RID: 11804 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B1D390", Offset = "0x1B1D390", VA = "0x1B1D390")]
		[Token(Token = "0x6002E1C")]
		private IEnumerator method_100(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E1D RID: 11805 RVA: 0x0005E244 File Offset: 0x0005C444
		[Address(RVA = "0x1B1D424", Offset = "0x1B1D424", VA = "0x1B1D424")]
		[Token(Token = "0x6002E1D")]
		private void method_101(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_108(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E1E RID: 11806 RVA: 0x0005E5E0 File Offset: 0x0005C7E0
		[Address(RVA = "0x1B1D454", Offset = "0x1B1D454", VA = "0x1B1D454")]
		[Token(Token = "0x6002E1E")]
		private void method_102(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_50(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E1F RID: 11807 RVA: 0x0005DF58 File Offset: 0x0005C158
		[Address(RVA = "0x1B1D484", Offset = "0x1B1D484", VA = "0x1B1D484")]
		[Token(Token = "0x6002E1F")]
		public void method_103()
		{
			DemoPassthroughSocket demoPassthroughSocket;
			this.demoPassthroughSocket_0 = demoPassthroughSocket;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E20 RID: 11808 RVA: 0x0005E600 File Offset: 0x0005C800
		[Address(RVA = "0x1B1D578", Offset = "0x1B1D578", VA = "0x1B1D578")]
		[Token(Token = "0x6002E20")]
		public void method_104()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("spooky guy true");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E21 RID: 11809 RVA: 0x0005E678 File Offset: 0x0005C878
		[Address(RVA = "0x1B1D7A8", Offset = "0x1B1D7A8", VA = "0x1B1D7A8")]
		[Token(Token = "0x6002E21")]
		private void method_105(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_66(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E22 RID: 11810 RVA: 0x0005E698 File Offset: 0x0005C898
		[Address(RVA = "0x1B1D7D8", Offset = "0x1B1D7D8", VA = "0x1B1D7D8")]
		[Token(Token = "0x6002E22")]
		public void method_106()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("On");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				this.hvrgrabbable_0.\u07AEٳשܨ.constraints = (RigidbodyConstraints)102;
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E23 RID: 11811 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B1DA10", Offset = "0x1B1DA10", VA = "0x1B1DA10")]
		[Token(Token = "0x6002E23")]
		public void method_107()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E24 RID: 11812 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002E24")]
		[Address(RVA = "0x1B1BC60", Offset = "0x1B1BC60", VA = "0x1B1BC60")]
		private IEnumerator method_108(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E25 RID: 11813 RVA: 0x0005E72C File Offset: 0x0005C92C
		[Token(Token = "0x6002E25")]
		[Address(RVA = "0x1B1DB04", Offset = "0x1B1DB04", VA = "0x1B1DB04")]
		private void method_109(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_40(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E26 RID: 11814 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B1DB34", Offset = "0x1B1DB34", VA = "0x1B1DB34")]
		[Token(Token = "0x6002E26")]
		public void method_110()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E27 RID: 11815 RVA: 0x0005E74C File Offset: 0x0005C94C
		[Address(RVA = "0x1B1DC28", Offset = "0x1B1DC28", VA = "0x1B1DC28")]
		[Token(Token = "0x6002E27")]
		public void method_111()
		{
			bool flag;
			if (!(flag = this.bool_0))
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				this.bool_0 = flag;
				unityEvent.Invoke();
				Debug.Log("hh:mmtt");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E28 RID: 11816 RVA: 0x0005E7D0 File Offset: 0x0005C9D0
		[Address(RVA = "0x1B1DE60", Offset = "0x1B1DE60", VA = "0x1B1DE60")]
		[Token(Token = "0x6002E28")]
		public void method_112()
		{
			base.GetComponent<DemoPassthroughSocket>();
		}

		// Token: 0x06002E29 RID: 11817 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B1DF54", Offset = "0x1B1DF54", VA = "0x1B1DF54")]
		[Token(Token = "0x6002E29")]
		private IEnumerator method_113(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E2A RID: 11818 RVA: 0x0005E7E4 File Offset: 0x0005C9E4
		[Address(RVA = "0x1B1DFE8", Offset = "0x1B1DFE8", VA = "0x1B1DFE8")]
		[Token(Token = "0x6002E2A")]
		private void method_114(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_19(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E2B RID: 11819 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B1E018", Offset = "0x1B1E018", VA = "0x1B1E018")]
		[Token(Token = "0x6002E2B")]
		public void method_115()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E2C RID: 11820 RVA: 0x0005DD60 File Offset: 0x0005BF60
		[Address(RVA = "0x1B1E10C", Offset = "0x1B1E10C", VA = "0x1B1E10C")]
		[Token(Token = "0x6002E2C")]
		private void method_116(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_58(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E2D RID: 11821 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x1B1E13C", Offset = "0x1B1E13C", VA = "0x1B1E13C")]
		[Token(Token = "0x6002E2D")]
		public void method_117()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002E2E RID: 11822 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6002E2E")]
		[Address(RVA = "0x1B1E230", Offset = "0x1B1E230", VA = "0x1B1E230")]
		public void method_118()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06002E2F RID: 11823 RVA: 0x0005E804 File Offset: 0x0005CA04
		[Address(RVA = "0x1B1E324", Offset = "0x1B1E324", VA = "0x1B1E324")]
		[Token(Token = "0x6002E2F")]
		public void method_119()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("ORGTARG");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				this.hvrgrabbable_0.\u07AEٳשܨ.constraints = (RigidbodyConstraints)110;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				long <ԣա_u059C_u06E9>k__BackingField = 1L;
				hvrgrabbable.<ԣա\u059C\u06E9>k__BackingField = (<ԣա_u059C_u06E9>k__BackingField != 0L);
				Transform transform = this.hvrgrabbable_0.transform;
				transform;
				HVRGrabbable hvrgrabbable2 = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable2.transform.position;
			}
		}

		// Token: 0x06002E30 RID: 11824 RVA: 0x0005E8B0 File Offset: 0x0005CAB0
		[Token(Token = "0x6002E30")]
		[Address(RVA = "0x1B1E560", Offset = "0x1B1E560", VA = "0x1B1E560")]
		public void method_120()
		{
		}

		// Token: 0x06002E31 RID: 11825 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Token(Token = "0x6002E31")]
		[Address(RVA = "0x1B1E798", Offset = "0x1B1E798", VA = "0x1B1E798")]
		private IEnumerator method_121(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E32 RID: 11826 RVA: 0x0005E8C0 File Offset: 0x0005CAC0
		[Token(Token = "0x6002E32")]
		[Address(RVA = "0x1B1E82C", Offset = "0x1B1E82C", VA = "0x1B1E82C")]
		private void method_122(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_113(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E33 RID: 11827 RVA: 0x0005DD60 File Offset: 0x0005BF60
		[Token(Token = "0x6002E33")]
		[Address(RVA = "0x1B1E85C", Offset = "0x1B1E85C", VA = "0x1B1E85C")]
		private void method_123(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_58(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E34 RID: 11828 RVA: 0x00009500 File Offset: 0x00007700
		[Address(RVA = "0x1B17D38", Offset = "0x1B17D38", VA = "0x1B17D38")]
		[Token(Token = "0x6002E34")]
		private IEnumerator method_124(HVRGrabbable hvrgrabbable_1)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06002E35 RID: 11829 RVA: 0x0005E8E0 File Offset: 0x0005CAE0
		[Token(Token = "0x6002E35")]
		[Address(RVA = "0x1B1E88C", Offset = "0x1B1E88C", VA = "0x1B1E88C")]
		private void method_125(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			this.method_68(hvrgrabbable_1);
		}

		// Token: 0x06002E36 RID: 11830 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002E36")]
		[Address(RVA = "0x1B1E8BC", Offset = "0x1B1E8BC", VA = "0x1B1E8BC")]
		public void method_126()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E37 RID: 11831 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B1E9B0", Offset = "0x1B1E9B0", VA = "0x1B1E9B0")]
		[Token(Token = "0x6002E37")]
		public void method_127()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E38 RID: 11832 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B1CA40", Offset = "0x1B1CA40", VA = "0x1B1CA40")]
		[Token(Token = "0x6002E38")]
		private IEnumerator method_128(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E39 RID: 11833 RVA: 0x0005E8F8 File Offset: 0x0005CAF8
		[Token(Token = "0x6002E39")]
		[Address(RVA = "0x1B1EAA4", Offset = "0x1B1EAA4", VA = "0x1B1EAA4")]
		public void method_129()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("True");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				this.hvrgrabbable_0.\u07AEٳשܨ.constraints = (RigidbodyConstraints)47;
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E3A RID: 11834 RVA: 0x0005E98C File Offset: 0x0005CB8C
		[Address(RVA = "0x1B1ECD8", Offset = "0x1B1ECD8", VA = "0x1B1ECD8")]
		[Token(Token = "0x6002E3A")]
		public void method_130()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				this.unityEvent_0.Invoke();
				Debug.Log("true");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				this.hvrgrabbable_0.\u07AEٳשܨ.constraints = (RigidbodyConstraints)19;
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E3B RID: 11835 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Token(Token = "0x6002E3B")]
		[Address(RVA = "0x1B1EF0C", Offset = "0x1B1EF0C", VA = "0x1B1EF0C")]
		public void method_131()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E3C RID: 11836 RVA: 0x0005DF80 File Offset: 0x0005C180
		[Token(Token = "0x6002E3C")]
		[Address(RVA = "0x1B1F000", Offset = "0x1B1F000", VA = "0x1B1F000")]
		public void method_132()
		{
			if (!this.bool_0)
			{
				Vector3 eulerAngles = this.hvrgrabbable_0.transform.localRotation.eulerAngles;
				UnityEvent unityEvent = this.unityEvent_0;
				long num = 1L;
				this.bool_0 = (num != 0L);
				unityEvent.Invoke();
				Debug.Log("TurnAmount");
				this.hvrgrabbable_0.ރԀҿ\u0611();
				Transform transform = this.hvrgrabbable_0.transform;
				SFXPlayer.أ\u089Dࢮ\u0745;
				HVRGrabbable hvrgrabbable = this.hvrgrabbable_0;
				Vector3 position = hvrgrabbable.transform.position;
			}
		}

		// Token: 0x06002E3D RID: 11837 RVA: 0x0005D97C File Offset: 0x0005BB7C
		[Address(RVA = "0x1B1F238", Offset = "0x1B1F238", VA = "0x1B1F238")]
		[Token(Token = "0x6002E3D")]
		public void method_133()
		{
			DemoPassthroughSocket component = base.GetComponent<DemoPassthroughSocket>();
			this.demoPassthroughSocket_0 = component;
			UnityAction<HVRGrabberBase, HVRGrabbable> unityAction;
			this.demoPassthroughSocket_0.\u0747\u0608\u058Cզ.AddListener(unityAction);
		}

		// Token: 0x06002E3E RID: 11838 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B178A0", Offset = "0x1B178A0", VA = "0x1B178A0")]
		[Token(Token = "0x6002E3E")]
		private IEnumerator method_134(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E3F RID: 11839 RVA: 0x0005EA18 File Offset: 0x0005CC18
		[Token(Token = "0x6002E3F")]
		[Address(RVA = "0x1B1F32C", Offset = "0x1B1F32C", VA = "0x1B1F32C")]
		private void method_135(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_11(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x06002E40 RID: 11840 RVA: 0x0005D94C File Offset: 0x0005BB4C
		[Address(RVA = "0x1B17964", Offset = "0x1B17964", VA = "0x1B17964")]
		[Token(Token = "0x6002E40")]
		private IEnumerator method_136(HVRGrabbable hvrgrabbable_1)
		{
			DemoLock.Class39 @class = new DemoLock.Class39((int)0L);
			@class.<>4__this = this;
			@class.key = hvrgrabbable_1;
			throw new NullReferenceException();
		}

		// Token: 0x06002E41 RID: 11841 RVA: 0x0005EA38 File Offset: 0x0005CC38
		[Token(Token = "0x6002E41")]
		[Address(RVA = "0x1B1F35C", Offset = "0x1B1F35C", VA = "0x1B1F35C")]
		private void method_137(HVRGrabberBase hvrgrabberBase_0, HVRGrabbable hvrgrabbable_1)
		{
			IEnumerator routine = this.method_52(hvrgrabbable_1);
			base.StartCoroutine(routine);
		}

		// Token: 0x040005AF RID: 1455
		[Token(Token = "0x40005AF")]
		[FieldOffset(Offset = "0x18")]
		public DemoPassthroughSocket demoPassthroughSocket_0;

		// Token: 0x040005B0 RID: 1456
		[Token(Token = "0x40005B0")]
		[FieldOffset(Offset = "0x20")]
		public HVRGrabbable hvrgrabbable_0;

		// Token: 0x040005B1 RID: 1457
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40005B1")]
		public GameObject gameObject_0;

		// Token: 0x040005B2 RID: 1458
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40005B2")]
		public Transform transform_0;

		// Token: 0x040005B3 RID: 1459
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40005B3")]
		public float float_0;

		// Token: 0x040005B4 RID: 1460
		[Token(Token = "0x40005B4")]
		[FieldOffset(Offset = "0x40")]
		public AudioClip audioClip_0;

		// Token: 0x040005B5 RID: 1461
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x40005B5")]
		public AudioClip audioClip_1;

		// Token: 0x040005B6 RID: 1462
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x40005B6")]
		public float float_1;

		// Token: 0x040005B7 RID: 1463
		[Token(Token = "0x40005B7")]
		[FieldOffset(Offset = "0x58")]
		public UnityEvent unityEvent_0;

		// Token: 0x040005B8 RID: 1464
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x40005B8")]
		private bool bool_0;
	}
}
