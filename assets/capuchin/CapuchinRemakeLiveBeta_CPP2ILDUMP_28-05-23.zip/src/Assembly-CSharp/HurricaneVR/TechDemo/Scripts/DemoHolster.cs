﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core;
using HurricaneVR.Framework.Core.Grabbers;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000120 RID: 288
	[Token(Token = "0x2000120")]
	public class DemoHolster : HVRSocket
	{
		// Token: 0x06002C85 RID: 11397 RVA: 0x0005D018 File Offset: 0x0005B218
		[Address(RVA = "0x2127760", Offset = "0x2127760", VA = "0x2127760", Slot = "131")]
		[Token(Token = "0x6002C85")]
		protected override Quaternion \u089F\u05FCժԛ(HVRGrabbable hvrgrabbable_0)
		{
			DemoHolsterOrientation component = hvrgrabbable_0.GetComponent<DemoHolsterOrientation>();
			component;
			Transform transform_ = component.transform_0;
			transform_;
			return component.transform_0.localRotation;
		}

		// Token: 0x06002C86 RID: 11398 RVA: 0x00002EBB File Offset: 0x000010BB
		[Address(RVA = "0x2127860", Offset = "0x2127860", VA = "0x2127860")]
		[Token(Token = "0x6002C86")]
		public DemoHolster()
		{
		}

		// Token: 0x06002C87 RID: 11399 RVA: 0x0005D04C File Offset: 0x0005B24C
		[Address(RVA = "0x2127868", Offset = "0x2127868", VA = "0x2127868", Slot = "70")]
		[Token(Token = "0x6002C87")]
		protected override Vector3 ۴Ԕ\u0705٨(HVRGrabbable hvrgrabbable_0)
		{
			DemoHolsterOrientation component = hvrgrabbable_0.GetComponent<DemoHolsterOrientation>();
			component;
			Transform transform_ = component.transform_0;
			transform_;
			Vector3 localPosition = component.transform_0.localPosition;
			return typeof(UnityEngine.Object).TypeHandle;
		}
	}
}
