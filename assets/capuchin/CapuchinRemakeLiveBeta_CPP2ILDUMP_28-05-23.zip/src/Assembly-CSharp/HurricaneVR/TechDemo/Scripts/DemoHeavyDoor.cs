﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Components;
using HurricaneVR.Framework.Core.Utils;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x0200011C RID: 284
	[Token(Token = "0x200011C")]
	public class DemoHeavyDoor : MonoBehaviour
	{
		// Token: 0x06002B95 RID: 11157 RVA: 0x0005C4F8 File Offset: 0x0005A6F8
		[Token(Token = "0x6002B95")]
		[Address(RVA = "0x36042F4", Offset = "0x36042F4", VA = "0x36042F4")]
		private void method_0()
		{
			UnityEngine.Random.Range(0, 0);
			SFXPlayer.أ\u089Dࢮ\u0745;
			Transform transform;
			Vector3 position = transform.position;
		}

		// Token: 0x06002B96 RID: 11158 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3604534", Offset = "0x3604534", VA = "0x3604534")]
		[Token(Token = "0x6002B96")]
		private void method_1()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002B97 RID: 11159 RVA: 0x0005C520 File Offset: 0x0005A720
		[Token(Token = "0x6002B97")]
		[Address(RVA = "0x3604578", Offset = "0x3604578", VA = "0x3604578")]
		private void method_2()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002B98 RID: 11160 RVA: 0x0005C540 File Offset: 0x0005A740
		[Address(RVA = "0x36045BC", Offset = "0x36045BC", VA = "0x36045BC")]
		[Token(Token = "0x6002B98")]
		private void method_3()
		{
			if (this.audioClip_0.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002B99 RID: 11161 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x36047FC", Offset = "0x36047FC", VA = "0x36047FC")]
		[Token(Token = "0x6002B99")]
		private void method_4()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002B9A RID: 11162 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3604A3C", Offset = "0x3604A3C", VA = "0x3604A3C")]
		[Token(Token = "0x6002B9A")]
		private void method_5()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002B9B RID: 11163 RVA: 0x0005C588 File Offset: 0x0005A788
		[Token(Token = "0x6002B9B")]
		[Address(RVA = "0x3604A80", Offset = "0x3604A80", VA = "0x3604A80")]
		private void method_6()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002B9C RID: 11164 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3604CC0", Offset = "0x3604CC0", VA = "0x3604CC0")]
		[Token(Token = "0x6002B9C")]
		private void method_7()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002B9D RID: 11165 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x3604D04", Offset = "0x3604D04", VA = "0x3604D04")]
		[Token(Token = "0x6002B9D")]
		private void method_8()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002B9E RID: 11166 RVA: 0x0005C588 File Offset: 0x0005A788
		[Token(Token = "0x6002B9E")]
		[Address(RVA = "0x3604F40", Offset = "0x3604F40", VA = "0x3604F40")]
		private void method_9()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002B9F RID: 11167 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x3605180", Offset = "0x3605180", VA = "0x3605180")]
		[Token(Token = "0x6002B9F")]
		private void method_10()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BA0 RID: 11168 RVA: 0x0005C520 File Offset: 0x0005A720
		[Token(Token = "0x6002BA0")]
		[Address(RVA = "0x36053C0", Offset = "0x36053C0", VA = "0x36053C0")]
		private void method_11()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BA1 RID: 11169 RVA: 0x0005C5D8 File Offset: 0x0005A7D8
		[Token(Token = "0x6002BA1")]
		[Address(RVA = "0x3605404", Offset = "0x3605404", VA = "0x3605404")]
		private void method_12()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BA2 RID: 11170 RVA: 0x0005C588 File Offset: 0x0005A788
		[Token(Token = "0x6002BA2")]
		[Address(RVA = "0x3605644", Offset = "0x3605644", VA = "0x3605644")]
		private void method_13()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BA3 RID: 11171 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x3605884", Offset = "0x3605884", VA = "0x3605884")]
		[Token(Token = "0x6002BA3")]
		private void method_14()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BA4 RID: 11172 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3605AC4", Offset = "0x3605AC4", VA = "0x3605AC4")]
		[Token(Token = "0x6002BA4")]
		private void method_15()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BA5 RID: 11173 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3605B08", Offset = "0x3605B08", VA = "0x3605B08")]
		[Token(Token = "0x6002BA5")]
		private void method_16()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BA6 RID: 11174 RVA: 0x0005C588 File Offset: 0x0005A788
		[Token(Token = "0x6002BA6")]
		[Address(RVA = "0x3605B4C", Offset = "0x3605B4C", VA = "0x3605B4C")]
		private void method_17()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BA7 RID: 11175 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3605D8C", Offset = "0x3605D8C", VA = "0x3605D8C")]
		[Token(Token = "0x6002BA7")]
		private void method_18()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BA8 RID: 11176 RVA: 0x0005C628 File Offset: 0x0005A828
		[Address(RVA = "0x3605DD0", Offset = "0x3605DD0", VA = "0x3605DD0")]
		[Token(Token = "0x6002BA8")]
		private void method_19()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				HVRRotationTracker hvrrotationTracker = this.hvrrotationTracker_0;
				this.float_2 = hvrrotationTracker;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BA9 RID: 11177 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3606010", Offset = "0x3606010", VA = "0x3606010")]
		[Token(Token = "0x6002BA9")]
		private void method_20()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BAA RID: 11178 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3606054", Offset = "0x3606054", VA = "0x3606054")]
		[Token(Token = "0x6002BAA")]
		private void method_21()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BAB RID: 11179 RVA: 0x0005C588 File Offset: 0x0005A788
		[Token(Token = "0x6002BAB")]
		[Address(RVA = "0x3606098", Offset = "0x3606098", VA = "0x3606098")]
		private void method_22()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BAC RID: 11180 RVA: 0x0005C588 File Offset: 0x0005A788
		[Token(Token = "0x6002BAC")]
		[Address(RVA = "0x36062D8", Offset = "0x36062D8", VA = "0x36062D8")]
		private void method_23()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BAD RID: 11181 RVA: 0x0005C520 File Offset: 0x0005A720
		[Token(Token = "0x6002BAD")]
		[Address(RVA = "0x3606518", Offset = "0x3606518", VA = "0x3606518")]
		private void method_24()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BAE RID: 11182 RVA: 0x0005C588 File Offset: 0x0005A788
		[Token(Token = "0x6002BAE")]
		[Address(RVA = "0x360655C", Offset = "0x360655C", VA = "0x360655C")]
		private void method_25()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BAF RID: 11183 RVA: 0x0005C520 File Offset: 0x0005A720
		[Token(Token = "0x6002BAF")]
		[Address(RVA = "0x360679C", Offset = "0x360679C", VA = "0x360679C")]
		private void Start()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BB0 RID: 11184 RVA: 0x0005C674 File Offset: 0x0005A874
		[Address(RVA = "0x36067E0", Offset = "0x36067E0", VA = "0x36067E0")]
		[Token(Token = "0x6002BB0")]
		private void FixedUpdate()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BB1 RID: 11185 RVA: 0x0005C520 File Offset: 0x0005A720
		[Token(Token = "0x6002BB1")]
		[Address(RVA = "0x3606A14", Offset = "0x3606A14", VA = "0x3606A14")]
		private void method_26()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BB2 RID: 11186 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x3606A58", Offset = "0x3606A58", VA = "0x3606A58")]
		[Token(Token = "0x6002BB2")]
		private void method_27()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BB3 RID: 11187 RVA: 0x0005C520 File Offset: 0x0005A720
		[Token(Token = "0x6002BB3")]
		[Address(RVA = "0x3606C98", Offset = "0x3606C98", VA = "0x3606C98")]
		private void method_28()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BB4 RID: 11188 RVA: 0x0005C6C4 File Offset: 0x0005A8C4
		[Address(RVA = "0x3606CDC", Offset = "0x3606CDC", VA = "0x3606CDC")]
		[Token(Token = "0x6002BB4")]
		private void method_29()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BB5 RID: 11189 RVA: 0x0005C714 File Offset: 0x0005A914
		[Address(RVA = "0x3606F18", Offset = "0x3606F18", VA = "0x3606F18")]
		[Token(Token = "0x6002BB5")]
		private void method_30()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BB6 RID: 11190 RVA: 0x0005C588 File Offset: 0x0005A788
		[Token(Token = "0x6002BB6")]
		[Address(RVA = "0x3607158", Offset = "0x3607158", VA = "0x3607158")]
		private void method_31()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BB7 RID: 11191 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3607398", Offset = "0x3607398", VA = "0x3607398")]
		[Token(Token = "0x6002BB7")]
		private void method_32()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BB8 RID: 11192 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x36073DC", Offset = "0x36073DC", VA = "0x36073DC")]
		[Token(Token = "0x6002BB8")]
		private void method_33()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BB9 RID: 11193 RVA: 0x0005C714 File Offset: 0x0005A914
		[Address(RVA = "0x3607420", Offset = "0x3607420", VA = "0x3607420")]
		[Token(Token = "0x6002BB9")]
		private void method_34()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BBA RID: 11194 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3607660", Offset = "0x3607660", VA = "0x3607660")]
		[Token(Token = "0x6002BBA")]
		private void method_35()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BBB RID: 11195 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x36076A4", Offset = "0x36076A4", VA = "0x36076A4")]
		[Token(Token = "0x6002BBB")]
		private void method_36()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BBC RID: 11196 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x36076E8", Offset = "0x36076E8", VA = "0x36076E8")]
		[Token(Token = "0x6002BBC")]
		private void method_37()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BBD RID: 11197 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x360772C", Offset = "0x360772C", VA = "0x360772C")]
		[Token(Token = "0x6002BBD")]
		private void method_38()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BBE RID: 11198 RVA: 0x0005C764 File Offset: 0x0005A964
		[Address(RVA = "0x360796C", Offset = "0x360796C", VA = "0x360796C")]
		[Token(Token = "0x6002BBE")]
		private void method_39()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BBF RID: 11199 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x3607BAC", Offset = "0x3607BAC", VA = "0x3607BAC")]
		[Token(Token = "0x6002BBF")]
		private void method_40()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BC0 RID: 11200 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3607DEC", Offset = "0x3607DEC", VA = "0x3607DEC")]
		[Token(Token = "0x6002BC0")]
		private void method_41()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BC1 RID: 11201 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x3607E30", Offset = "0x3607E30", VA = "0x3607E30")]
		[Token(Token = "0x6002BC1")]
		private void method_42()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BC2 RID: 11202 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3608070", Offset = "0x3608070", VA = "0x3608070")]
		[Token(Token = "0x6002BC2")]
		private void method_43()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BC3 RID: 11203 RVA: 0x00002E3D File Offset: 0x0000103D
		[Address(RVA = "0x36080B4", Offset = "0x36080B4", VA = "0x36080B4")]
		[Token(Token = "0x6002BC3")]
		public DemoHeavyDoor()
		{
		}

		// Token: 0x06002BC4 RID: 11204 RVA: 0x0005C7B4 File Offset: 0x0005A9B4
		[Address(RVA = "0x36080CC", Offset = "0x36080CC", VA = "0x36080CC")]
		[Token(Token = "0x6002BC4")]
		private void method_44()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Transform transform;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06002BC5 RID: 11205 RVA: 0x0005C800 File Offset: 0x0005AA00
		[Token(Token = "0x6002BC5")]
		[Address(RVA = "0x360830C", Offset = "0x360830C", VA = "0x360830C")]
		private void method_45()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BC6 RID: 11206 RVA: 0x0005C850 File Offset: 0x0005AA50
		[Address(RVA = "0x360854C", Offset = "0x360854C", VA = "0x360854C")]
		[Token(Token = "0x6002BC6")]
		private void method_46()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				AudioClip[] array2 = this.audioClip_0;
				AudioClip.PCMReaderCallback pcmreaderCallback = array2.m_PCMReaderCallback;
				this.float_2 = pcmreaderCallback;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BC7 RID: 11207 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x360878C", Offset = "0x360878C", VA = "0x360878C")]
		[Token(Token = "0x6002BC7")]
		private void method_47()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BC8 RID: 11208 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x36087D0", Offset = "0x36087D0", VA = "0x36087D0")]
		[Token(Token = "0x6002BC8")]
		private void method_48()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BC9 RID: 11209 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x3608A10", Offset = "0x3608A10", VA = "0x3608A10")]
		[Token(Token = "0x6002BC9")]
		private void method_49()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BCA RID: 11210 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3608C50", Offset = "0x3608C50", VA = "0x3608C50")]
		[Token(Token = "0x6002BCA")]
		private void method_50()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BCB RID: 11211 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3608C94", Offset = "0x3608C94", VA = "0x3608C94")]
		[Token(Token = "0x6002BCB")]
		private void method_51()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BCC RID: 11212 RVA: 0x0005C8A4 File Offset: 0x0005AAA4
		[Address(RVA = "0x3608CD8", Offset = "0x3608CD8", VA = "0x3608CD8")]
		[Token(Token = "0x6002BCC")]
		private void method_52()
		{
			Quaternion rotation = base.transform.rotation;
		}

		// Token: 0x06002BCD RID: 11213 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3608D1C", Offset = "0x3608D1C", VA = "0x3608D1C")]
		[Token(Token = "0x6002BCD")]
		private void method_53()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BCE RID: 11214 RVA: 0x0005C520 File Offset: 0x0005A720
		[Token(Token = "0x6002BCE")]
		[Address(RVA = "0x3608D60", Offset = "0x3608D60", VA = "0x3608D60")]
		private void method_54()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BCF RID: 11215 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3608DA4", Offset = "0x3608DA4", VA = "0x3608DA4")]
		[Token(Token = "0x6002BCF")]
		private void method_55()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BD0 RID: 11216 RVA: 0x0005C520 File Offset: 0x0005A720
		[Token(Token = "0x6002BD0")]
		[Address(RVA = "0x3608DE8", Offset = "0x3608DE8", VA = "0x3608DE8")]
		private void method_56()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BD1 RID: 11217 RVA: 0x0005C520 File Offset: 0x0005A720
		[Address(RVA = "0x3608E2C", Offset = "0x3608E2C", VA = "0x3608E2C")]
		[Token(Token = "0x6002BD1")]
		private void method_57()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BD2 RID: 11218 RVA: 0x0005C520 File Offset: 0x0005A720
		[Token(Token = "0x6002BD2")]
		[Address(RVA = "0x3608E70", Offset = "0x3608E70", VA = "0x3608E70")]
		private void method_58()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x06002BD3 RID: 11219 RVA: 0x0005C588 File Offset: 0x0005A788
		[Address(RVA = "0x3608EB4", Offset = "0x3608EB4", VA = "0x3608EB4")]
		[Token(Token = "0x6002BD3")]
		private void method_59()
		{
			AudioClip[] array = this.audioClip_0;
			if (array != null && array.m_PCMReaderCallback != null)
			{
				float <_u070D_u07BA_u082Aע>k__BackingField = this.hvrrotationTracker_0.<\u070D\u07BA\u082Aע>k__BackingField;
				this.float_2 = <_u070D_u07BA_u082Aע>k__BackingField;
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
				return;
			}
		}

		// Token: 0x06002BD4 RID: 11220 RVA: 0x0005C520 File Offset: 0x0005A720
		[Token(Token = "0x6002BD4")]
		[Address(RVA = "0x36090F4", Offset = "0x36090F4", VA = "0x36090F4")]
		private void method_60()
		{
			Quaternion rotation = this.rigidbody_0.transform.rotation;
		}

		// Token: 0x0400058A RID: 1418
		[Token(Token = "0x400058A")]
		[FieldOffset(Offset = "0x18")]
		public Rigidbody rigidbody_0;

		// Token: 0x0400058B RID: 1419
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400058B")]
		public HVRRotationTracker hvrrotationTracker_0;

		// Token: 0x0400058C RID: 1420
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400058C")]
		public HVRRotationLimiter hvrrotationLimiter_0;

		// Token: 0x0400058D RID: 1421
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400058D")]
		public float float_0 = (float)17154;

		// Token: 0x0400058E RID: 1422
		[Token(Token = "0x400058E")]
		[FieldOffset(Offset = "0x38")]
		public AudioClip[] audioClip_0;

		// Token: 0x0400058F RID: 1423
		[Token(Token = "0x400058F")]
		[FieldOffset(Offset = "0x40")]
		public float float_1 = (float)16672;

		// Token: 0x04000590 RID: 1424
		[FieldOffset(Offset = "0x44")]
		[Token(Token = "0x4000590")]
		public float float_2;

		// Token: 0x04000591 RID: 1425
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000591")]
		private Quaternion quaternion_0;
	}
}
