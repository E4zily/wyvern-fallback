﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000137 RID: 311
	[Token(Token = "0x2000137")]
	public class DemoValveHologram : MonoBehaviour
	{
		// Token: 0x060030D9 RID: 12505 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB00C", Offset = "0x20BB00C", VA = "0x20BB00C")]
		[Token(Token = "0x60030D9")]
		private void method_0()
		{
		}

		// Token: 0x060030DA RID: 12506 RVA: 0x00061974 File Offset: 0x0005FB74
		[Address(RVA = "0x20BB020", Offset = "0x20BB020", VA = "0x20BB020")]
		[Token(Token = "0x60030DA")]
		private void method_1()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)16384;
			Transform transform = base.transform;
		}

		// Token: 0x060030DB RID: 12507 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB0D0", Offset = "0x20BB0D0", VA = "0x20BB0D0")]
		[Token(Token = "0x60030DB")]
		private void method_2()
		{
		}

		// Token: 0x060030DC RID: 12508 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x60030DC")]
		[Address(RVA = "0x20BB0E4", Offset = "0x20BB0E4", VA = "0x20BB0E4")]
		private void method_3()
		{
		}

		// Token: 0x060030DD RID: 12509 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB0F8", Offset = "0x20BB0F8", VA = "0x20BB0F8")]
		[Token(Token = "0x60030DD")]
		private void method_4()
		{
		}

		// Token: 0x060030DE RID: 12510 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x60030DE")]
		[Address(RVA = "0x20BB10C", Offset = "0x20BB10C", VA = "0x20BB10C")]
		private void method_5()
		{
		}

		// Token: 0x060030DF RID: 12511 RVA: 0x0006199C File Offset: 0x0005FB9C
		[Address(RVA = "0x20BB120", Offset = "0x20BB120", VA = "0x20BB120")]
		[Token(Token = "0x60030DF")]
		private void method_6()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)32768;
			Transform transform = base.transform;
		}

		// Token: 0x060030E0 RID: 12512 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BB1D0", Offset = "0x20BB1D0", VA = "0x20BB1D0")]
		[Token(Token = "0x60030E0")]
		public void method_7()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x060030E1 RID: 12513 RVA: 0x000619C4 File Offset: 0x0005FBC4
		[Address(RVA = "0x20BB248", Offset = "0x20BB248", VA = "0x20BB248")]
		[Token(Token = "0x60030E1")]
		private void method_8()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)17268;
			Transform transform = base.transform;
		}

		// Token: 0x060030E2 RID: 12514 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB2F4", Offset = "0x20BB2F4", VA = "0x20BB2F4")]
		[Token(Token = "0x60030E2")]
		private void method_9()
		{
		}

		// Token: 0x060030E3 RID: 12515 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB308", Offset = "0x20BB308", VA = "0x20BB308")]
		[Token(Token = "0x60030E3")]
		private void method_10()
		{
		}

		// Token: 0x060030E4 RID: 12516 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB31C", Offset = "0x20BB31C", VA = "0x20BB31C")]
		[Token(Token = "0x60030E4")]
		private void method_11()
		{
		}

		// Token: 0x060030E5 RID: 12517 RVA: 0x000619EC File Offset: 0x0005FBEC
		[Address(RVA = "0x20BB330", Offset = "0x20BB330", VA = "0x20BB330")]
		[Token(Token = "0x60030E5")]
		private void method_12()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)8192;
			Transform transform = base.transform;
		}

		// Token: 0x060030E6 RID: 12518 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB3E0", Offset = "0x20BB3E0", VA = "0x20BB3E0")]
		[Token(Token = "0x60030E6")]
		private void method_13()
		{
		}

		// Token: 0x060030E7 RID: 12519 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB3F4", Offset = "0x20BB3F4", VA = "0x20BB3F4")]
		[Token(Token = "0x60030E7")]
		private void method_14()
		{
		}

		// Token: 0x060030E8 RID: 12520 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BB408", Offset = "0x20BB408", VA = "0x20BB408")]
		[Token(Token = "0x60030E8")]
		public void method_15()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x060030E9 RID: 12521 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BB480", Offset = "0x20BB480", VA = "0x20BB480")]
		[Token(Token = "0x60030E9")]
		public void method_16()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x060030EA RID: 12522 RVA: 0x00061A14 File Offset: 0x0005FC14
		[Address(RVA = "0x20BB4F8", Offset = "0x20BB4F8", VA = "0x20BB4F8")]
		[Token(Token = "0x60030EA")]
		private void method_17()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)57344;
			Transform transform = base.transform;
		}

		// Token: 0x060030EB RID: 12523 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB5A8", Offset = "0x20BB5A8", VA = "0x20BB5A8")]
		[Token(Token = "0x60030EB")]
		private void Start()
		{
		}

		// Token: 0x060030EC RID: 12524 RVA: 0x000030FB File Offset: 0x000012FB
		[Address(RVA = "0x20BB5BC", Offset = "0x20BB5BC", VA = "0x20BB5BC")]
		[Token(Token = "0x60030EC")]
		public DemoValveHologram()
		{
		}

		// Token: 0x060030ED RID: 12525 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BB5D0", Offset = "0x20BB5D0", VA = "0x20BB5D0")]
		[Token(Token = "0x60030ED")]
		public void method_18()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x060030EE RID: 12526 RVA: 0x00061974 File Offset: 0x0005FB74
		[Address(RVA = "0x20BB648", Offset = "0x20BB648", VA = "0x20BB648")]
		[Token(Token = "0x60030EE")]
		private void method_19()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)16384;
			Transform transform = base.transform;
		}

		// Token: 0x060030EF RID: 12527 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB6F8", Offset = "0x20BB6F8", VA = "0x20BB6F8")]
		[Token(Token = "0x60030EF")]
		private void method_20()
		{
		}

		// Token: 0x060030F0 RID: 12528 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BB70C", Offset = "0x20BB70C", VA = "0x20BB70C")]
		[Token(Token = "0x60030F0")]
		private void method_21()
		{
		}

		// Token: 0x060030F1 RID: 12529 RVA: 0x00061A3C File Offset: 0x0005FC3C
		[Address(RVA = "0x20BB720", Offset = "0x20BB720", VA = "0x20BB720")]
		[Token(Token = "0x60030F1")]
		private void method_22()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)17452;
			Transform transform = base.transform;
		}

		// Token: 0x060030F2 RID: 12530 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BB7CC", Offset = "0x20BB7CC", VA = "0x20BB7CC")]
		[Token(Token = "0x60030F2")]
		public void method_23()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x060030F3 RID: 12531 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BB844", Offset = "0x20BB844", VA = "0x20BB844")]
		[Token(Token = "0x60030F3")]
		public void method_24()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x060030F4 RID: 12532 RVA: 0x00061A64 File Offset: 0x0005FC64
		[Address(RVA = "0x20BB8BC", Offset = "0x20BB8BC", VA = "0x20BB8BC")]
		[Token(Token = "0x60030F4")]
		private void method_25()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)24576;
			Transform transform = base.transform;
		}

		// Token: 0x060030F5 RID: 12533 RVA: 0x0006199C File Offset: 0x0005FB9C
		[Address(RVA = "0x20BB96C", Offset = "0x20BB96C", VA = "0x20BB96C")]
		[Token(Token = "0x60030F5")]
		private void method_26()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)32768;
			Transform transform = base.transform;
		}

		// Token: 0x060030F6 RID: 12534 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BBA1C", Offset = "0x20BBA1C", VA = "0x20BBA1C")]
		[Token(Token = "0x60030F6")]
		public void method_27()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x060030F7 RID: 12535 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BBA94", Offset = "0x20BBA94", VA = "0x20BBA94")]
		[Token(Token = "0x60030F7")]
		public void method_28()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x060030F8 RID: 12536 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BBB0C", Offset = "0x20BBB0C", VA = "0x20BBB0C")]
		[Token(Token = "0x60030F8")]
		public void method_29()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x060030F9 RID: 12537 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BBB84", Offset = "0x20BBB84", VA = "0x20BBB84")]
		[Token(Token = "0x60030F9")]
		private void method_30()
		{
		}

		// Token: 0x060030FA RID: 12538 RVA: 0x00061A8C File Offset: 0x0005FC8C
		[Address(RVA = "0x20BBB98", Offset = "0x20BBB98", VA = "0x20BBB98")]
		[Token(Token = "0x60030FA")]
		private void method_31()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)17108;
			Transform transform = base.transform;
		}

		// Token: 0x060030FB RID: 12539 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BBC44", Offset = "0x20BBC44", VA = "0x20BBC44")]
		[Token(Token = "0x60030FB")]
		private void method_32()
		{
		}

		// Token: 0x060030FC RID: 12540 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BBC58", Offset = "0x20BBC58", VA = "0x20BBC58")]
		[Token(Token = "0x60030FC")]
		private void method_33()
		{
		}

		// Token: 0x060030FD RID: 12541 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BBC6C", Offset = "0x20BBC6C", VA = "0x20BBC6C")]
		[Token(Token = "0x60030FD")]
		public void method_34()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x060030FE RID: 12542 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BBCE4", Offset = "0x20BBCE4", VA = "0x20BBCE4")]
		[Token(Token = "0x60030FE")]
		private void method_35()
		{
		}

		// Token: 0x060030FF RID: 12543 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BBCF8", Offset = "0x20BBCF8", VA = "0x20BBCF8")]
		[Token(Token = "0x60030FF")]
		public void method_36()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003100 RID: 12544 RVA: 0x00061974 File Offset: 0x0005FB74
		[Address(RVA = "0x20BBD70", Offset = "0x20BBD70", VA = "0x20BBD70")]
		[Token(Token = "0x6003100")]
		private void method_37()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)16384;
			Transform transform = base.transform;
		}

		// Token: 0x06003101 RID: 12545 RVA: 0x00061AB4 File Offset: 0x0005FCB4
		[Address(RVA = "0x20BBE20", Offset = "0x20BBE20", VA = "0x20BBE20")]
		[Token(Token = "0x6003101")]
		private void Update()
		{
			float deltaTime = Time.deltaTime;
			Transform transform = base.transform;
		}

		// Token: 0x06003102 RID: 12546 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BBEC8", Offset = "0x20BBEC8", VA = "0x20BBEC8")]
		[Token(Token = "0x6003102")]
		public void method_38()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003103 RID: 12547 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BBF40", Offset = "0x20BBF40", VA = "0x20BBF40")]
		[Token(Token = "0x6003103")]
		private void method_39()
		{
		}

		// Token: 0x06003104 RID: 12548 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BBF54", Offset = "0x20BBF54", VA = "0x20BBF54")]
		[Token(Token = "0x6003104")]
		private void method_40()
		{
		}

		// Token: 0x06003105 RID: 12549 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BBF68", Offset = "0x20BBF68", VA = "0x20BBF68")]
		[Token(Token = "0x6003105")]
		public void method_41()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003106 RID: 12550 RVA: 0x0006199C File Offset: 0x0005FB9C
		[Address(RVA = "0x20BBFE0", Offset = "0x20BBFE0", VA = "0x20BBFE0")]
		[Token(Token = "0x6003106")]
		private void method_42()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)32768;
			Transform transform = base.transform;
		}

		// Token: 0x06003107 RID: 12551 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BC090", Offset = "0x20BC090", VA = "0x20BC090")]
		[Token(Token = "0x6003107")]
		public void method_43()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003108 RID: 12552 RVA: 0x00061AD0 File Offset: 0x0005FCD0
		[Address(RVA = "0x20BC108", Offset = "0x20BC108", VA = "0x20BC108")]
		[Token(Token = "0x6003108")]
		private void method_44()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)40960;
			Transform transform = base.transform;
		}

		// Token: 0x06003109 RID: 12553 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BC1B8", Offset = "0x20BC1B8", VA = "0x20BC1B8")]
		[Token(Token = "0x6003109")]
		private void method_45()
		{
		}

		// Token: 0x0600310A RID: 12554 RVA: 0x00061AD0 File Offset: 0x0005FCD0
		[Address(RVA = "0x20BC1CC", Offset = "0x20BC1CC", VA = "0x20BC1CC")]
		[Token(Token = "0x600310A")]
		private void method_46()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)40960;
			Transform transform = base.transform;
		}

		// Token: 0x0600310B RID: 12555 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BC27C", Offset = "0x20BC27C", VA = "0x20BC27C")]
		[Token(Token = "0x600310B")]
		private void method_47()
		{
		}

		// Token: 0x0600310C RID: 12556 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BC290", Offset = "0x20BC290", VA = "0x20BC290")]
		[Token(Token = "0x600310C")]
		private void method_48()
		{
		}

		// Token: 0x0600310D RID: 12557 RVA: 0x000619EC File Offset: 0x0005FBEC
		[Address(RVA = "0x20BC2A4", Offset = "0x20BC2A4", VA = "0x20BC2A4")]
		[Token(Token = "0x600310D")]
		private void method_49()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)8192;
			Transform transform = base.transform;
		}

		// Token: 0x0600310E RID: 12558 RVA: 0x00061AF8 File Offset: 0x0005FCF8
		[Address(RVA = "0x20BC354", Offset = "0x20BC354", VA = "0x20BC354")]
		[Token(Token = "0x600310E")]
		private void method_50()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)17646;
			Transform transform = base.transform;
		}

		// Token: 0x0600310F RID: 12559 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x600310F")]
		[Address(RVA = "0x20BC400", Offset = "0x20BC400", VA = "0x20BC400")]
		public void method_51()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003110 RID: 12560 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BC478", Offset = "0x20BC478", VA = "0x20BC478")]
		[Token(Token = "0x6003110")]
		private void method_52()
		{
		}

		// Token: 0x06003111 RID: 12561 RVA: 0x00061B20 File Offset: 0x0005FD20
		[Token(Token = "0x6003111")]
		[Address(RVA = "0x20BC48C", Offset = "0x20BC48C", VA = "0x20BC48C")]
		private void method_53()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)17512;
			Transform transform = base.transform;
		}

		// Token: 0x06003112 RID: 12562 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BC538", Offset = "0x20BC538", VA = "0x20BC538")]
		[Token(Token = "0x6003112")]
		private void method_54()
		{
		}

		// Token: 0x06003113 RID: 12563 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BC54C", Offset = "0x20BC54C", VA = "0x20BC54C")]
		[Token(Token = "0x6003113")]
		private void method_55()
		{
		}

		// Token: 0x06003114 RID: 12564 RVA: 0x000619EC File Offset: 0x0005FBEC
		[Token(Token = "0x6003114")]
		[Address(RVA = "0x20BC560", Offset = "0x20BC560", VA = "0x20BC560")]
		private void method_56()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)8192;
			Transform transform = base.transform;
		}

		// Token: 0x06003115 RID: 12565 RVA: 0x00061B48 File Offset: 0x0005FD48
		[Token(Token = "0x6003115")]
		[Address(RVA = "0x20BC610", Offset = "0x20BC610", VA = "0x20BC610")]
		private void method_57()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)17406;
			Transform transform = base.transform;
		}

		// Token: 0x06003116 RID: 12566 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BC6BC", Offset = "0x20BC6BC", VA = "0x20BC6BC")]
		[Token(Token = "0x6003116")]
		private void method_58()
		{
		}

		// Token: 0x06003117 RID: 12567 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BC6D0", Offset = "0x20BC6D0", VA = "0x20BC6D0")]
		[Token(Token = "0x6003117")]
		private void method_59()
		{
		}

		// Token: 0x06003118 RID: 12568 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6003118")]
		[Address(RVA = "0x20BC6E4", Offset = "0x20BC6E4", VA = "0x20BC6E4")]
		public void method_60()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003119 RID: 12569 RVA: 0x0006199C File Offset: 0x0005FB9C
		[Address(RVA = "0x20BC75C", Offset = "0x20BC75C", VA = "0x20BC75C")]
		[Token(Token = "0x6003119")]
		private void method_61()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)32768;
			Transform transform = base.transform;
		}

		// Token: 0x0600311A RID: 12570 RVA: 0x0006199C File Offset: 0x0005FB9C
		[Address(RVA = "0x20BC80C", Offset = "0x20BC80C", VA = "0x20BC80C")]
		[Token(Token = "0x600311A")]
		private void method_62()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)32768;
			Transform transform = base.transform;
		}

		// Token: 0x0600311B RID: 12571 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x600311B")]
		[Address(RVA = "0x20BC8BC", Offset = "0x20BC8BC", VA = "0x20BC8BC")]
		public void method_63()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x0600311C RID: 12572 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x600311C")]
		[Address(RVA = "0x20BC934", Offset = "0x20BC934", VA = "0x20BC934")]
		public void method_64()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x0600311D RID: 12573 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BC9AC", Offset = "0x20BC9AC", VA = "0x20BC9AC")]
		[Token(Token = "0x600311D")]
		private void method_65()
		{
		}

		// Token: 0x0600311E RID: 12574 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BC9C0", Offset = "0x20BC9C0", VA = "0x20BC9C0")]
		[Token(Token = "0x600311E")]
		private void method_66()
		{
		}

		// Token: 0x0600311F RID: 12575 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x600311F")]
		[Address(RVA = "0x20BC9D4", Offset = "0x20BC9D4", VA = "0x20BC9D4")]
		public void method_67()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003120 RID: 12576 RVA: 0x00061B70 File Offset: 0x0005FD70
		[Token(Token = "0x6003120")]
		[Address(RVA = "0x20BCA4C", Offset = "0x20BCA4C", VA = "0x20BCA4C")]
		private void method_68()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)17416;
			Transform transform = base.transform;
		}

		// Token: 0x06003121 RID: 12577 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x20BCAF8", Offset = "0x20BCAF8", VA = "0x20BCAF8")]
		[Token(Token = "0x6003121")]
		private void method_69()
		{
		}

		// Token: 0x06003122 RID: 12578 RVA: 0x00061B98 File Offset: 0x0005FD98
		[Address(RVA = "0x20BCB0C", Offset = "0x20BCB0C", VA = "0x20BCB0C")]
		[Token(Token = "0x6003122")]
		private void method_70()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)49152;
			Transform transform = base.transform;
		}

		// Token: 0x06003123 RID: 12579 RVA: 0x00061BC0 File Offset: 0x0005FDC0
		[Token(Token = "0x6003123")]
		[Address(RVA = "0x20BCBBC", Offset = "0x20BCBBC", VA = "0x20BCBBC")]
		private void method_71()
		{
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x06003124 RID: 12580 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6003124")]
		[Address(RVA = "0x20BCC6C", Offset = "0x20BCC6C", VA = "0x20BCC6C")]
		public void method_72()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003125 RID: 12581 RVA: 0x00061BD4 File Offset: 0x0005FDD4
		[Address(RVA = "0x20BCCE4", Offset = "0x20BCCE4", VA = "0x20BCCE4")]
		[Token(Token = "0x6003125")]
		private void method_73()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)17464;
			Transform transform = base.transform;
		}

		// Token: 0x06003126 RID: 12582 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BCD90", Offset = "0x20BCD90", VA = "0x20BCD90")]
		[Token(Token = "0x6003126")]
		public void method_74()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003127 RID: 12583 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Address(RVA = "0x20BCE08", Offset = "0x20BCE08", VA = "0x20BCE08")]
		[Token(Token = "0x6003127")]
		public void method_75()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003128 RID: 12584 RVA: 0x00002EC3 File Offset: 0x000010C3
		[Token(Token = "0x6003128")]
		[Address(RVA = "0x20BCE80", Offset = "0x20BCE80", VA = "0x20BCE80")]
		public void method_76()
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06003129 RID: 12585 RVA: 0x0006199C File Offset: 0x0005FB9C
		[Address(RVA = "0x20BCEF8", Offset = "0x20BCEF8", VA = "0x20BCEF8")]
		[Token(Token = "0x6003129")]
		private void method_77()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)32768;
			Transform transform = base.transform;
		}

		// Token: 0x0600312A RID: 12586 RVA: 0x00061BFC File Offset: 0x0005FDFC
		[Token(Token = "0x600312A")]
		[Address(RVA = "0x20BCFA8", Offset = "0x20BCFA8", VA = "0x20BCFA8")]
		private void method_78()
		{
			float deltaTime = Time.deltaTime;
			this.float_1 = (float)17290;
			Transform transform = base.transform;
		}

		// Token: 0x0600312B RID: 12587 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600312B")]
		[Address(RVA = "0x20BD054", Offset = "0x20BD054", VA = "0x20BD054")]
		private void method_79()
		{
		}

		// Token: 0x04000622 RID: 1570
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000622")]
		public float float_0 = (float)52429;

		// Token: 0x04000623 RID: 1571
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000623")]
		public Quaternion quaternion_0;

		// Token: 0x04000624 RID: 1572
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000624")]
		public Quaternion quaternion_1;

		// Token: 0x04000625 RID: 1573
		[Token(Token = "0x4000625")]
		[FieldOffset(Offset = "0x3C")]
		private Quaternion quaternion_2;

		// Token: 0x04000626 RID: 1574
		[FieldOffset(Offset = "0x4C")]
		[Token(Token = "0x4000626")]
		private Quaternion quaternion_3;

		// Token: 0x04000627 RID: 1575
		[FieldOffset(Offset = "0x5C")]
		[Token(Token = "0x4000627")]
		private float float_1;
	}
}
