﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000118 RID: 280
	[Token(Token = "0x2000118")]
	public class DemoDummyArm : MonoBehaviour
	{
		// Token: 0x06002A66 RID: 10854 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Token(Token = "0x6002A66")]
		[Address(RVA = "0x2A1D8A4", Offset = "0x2A1D8A4", VA = "0x2A1D8A4")]
		private void method_0()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A67 RID: 10855 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1D910", Offset = "0x2A1D910", VA = "0x2A1D910")]
		[Token(Token = "0x6002A67")]
		private void method_1()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A68 RID: 10856 RVA: 0x0005AABC File Offset: 0x00058CBC
		[Address(RVA = "0x2A1D97C", Offset = "0x2A1D97C", VA = "0x2A1D97C")]
		[Token(Token = "0x6002A68")]
		private void method_2()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 3L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A69 RID: 10857 RVA: 0x0005AB08 File Offset: 0x00058D08
		[Token(Token = "0x6002A69")]
		[Address(RVA = "0x2A1DA4C", Offset = "0x2A1DA4C", VA = "0x2A1DA4C")]
		private void method_3()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 2L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A6A RID: 10858 RVA: 0x0005AB48 File Offset: 0x00058D48
		[Token(Token = "0x6002A6A")]
		[Address(RVA = "0x2A1DB1C", Offset = "0x2A1DB1C", VA = "0x2A1DB1C")]
		private void method_4()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 8L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A6B RID: 10859 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1DBEC", Offset = "0x2A1DBEC", VA = "0x2A1DBEC")]
		[Token(Token = "0x6002A6B")]
		private void method_5()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A6C RID: 10860 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1DC58", Offset = "0x2A1DC58", VA = "0x2A1DC58")]
		[Token(Token = "0x6002A6C")]
		private void method_6()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A6D RID: 10861 RVA: 0x0005AB94 File Offset: 0x00058D94
		[Address(RVA = "0x2A1DCC4", Offset = "0x2A1DCC4", VA = "0x2A1DCC4")]
		[Token(Token = "0x6002A6D")]
		private void method_7()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 1L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A6E RID: 10862 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Token(Token = "0x6002A6E")]
		[Address(RVA = "0x2A1DD94", Offset = "0x2A1DD94", VA = "0x2A1DD94")]
		private void method_8()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A6F RID: 10863 RVA: 0x0005ABE0 File Offset: 0x00058DE0
		[Token(Token = "0x6002A6F")]
		[Address(RVA = "0x2A1DE00", Offset = "0x2A1DE00", VA = "0x2A1DE00")]
		private void method_9()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			this.lineRenderer_0.positionCount = 5;
		}

		// Token: 0x06002A70 RID: 10864 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Token(Token = "0x6002A70")]
		[Address(RVA = "0x2A1DED0", Offset = "0x2A1DED0", VA = "0x2A1DED0")]
		private void method_10()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A71 RID: 10865 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Token(Token = "0x6002A71")]
		[Address(RVA = "0x2A1DF3C", Offset = "0x2A1DF3C", VA = "0x2A1DF3C")]
		private void Update()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A72 RID: 10866 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1DFA8", Offset = "0x2A1DFA8", VA = "0x2A1DFA8")]
		[Token(Token = "0x6002A72")]
		private void method_11()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A73 RID: 10867 RVA: 0x0005AB94 File Offset: 0x00058D94
		[Address(RVA = "0x2A1E014", Offset = "0x2A1E014", VA = "0x2A1E014")]
		[Token(Token = "0x6002A73")]
		private void method_12()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 1L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A74 RID: 10868 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Token(Token = "0x6002A74")]
		[Address(RVA = "0x2A1E0E4", Offset = "0x2A1E0E4", VA = "0x2A1E0E4")]
		private void method_13()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A75 RID: 10869 RVA: 0x0005AC24 File Offset: 0x00058E24
		[Token(Token = "0x6002A75")]
		[Address(RVA = "0x2A1E150", Offset = "0x2A1E150", VA = "0x2A1E150")]
		private void method_14()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 4L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A76 RID: 10870 RVA: 0x0005AC70 File Offset: 0x00058E70
		[Address(RVA = "0x2A1E220", Offset = "0x2A1E220", VA = "0x2A1E220")]
		[Token(Token = "0x6002A76")]
		private void method_15()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
		}

		// Token: 0x06002A77 RID: 10871 RVA: 0x0005ACA8 File Offset: 0x00058EA8
		[Token(Token = "0x6002A77")]
		[Address(RVA = "0x2A1E2F0", Offset = "0x2A1E2F0", VA = "0x2A1E2F0")]
		private void method_16()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 6L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A78 RID: 10872 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1E3C0", Offset = "0x2A1E3C0", VA = "0x2A1E3C0")]
		[Token(Token = "0x6002A78")]
		private void method_17()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A79 RID: 10873 RVA: 0x0005ABE0 File Offset: 0x00058DE0
		[Address(RVA = "0x2A1E42C", Offset = "0x2A1E42C", VA = "0x2A1E42C")]
		[Token(Token = "0x6002A79")]
		private void method_18()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			this.lineRenderer_0.positionCount = 5;
		}

		// Token: 0x06002A7A RID: 10874 RVA: 0x0005AABC File Offset: 0x00058CBC
		[Address(RVA = "0x2A1E4FC", Offset = "0x2A1E4FC", VA = "0x2A1E4FC")]
		[Token(Token = "0x6002A7A")]
		private void method_19()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 3L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A7B RID: 10875 RVA: 0x0005ACF4 File Offset: 0x00058EF4
		[Address(RVA = "0x2A1E5CC", Offset = "0x2A1E5CC", VA = "0x2A1E5CC")]
		[Token(Token = "0x6002A7B")]
		private void method_20()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 2L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A7C RID: 10876 RVA: 0x0005AD40 File Offset: 0x00058F40
		[Token(Token = "0x6002A7C")]
		[Address(RVA = "0x2A1E69C", Offset = "0x2A1E69C", VA = "0x2A1E69C")]
		private void method_21()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 0L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A7D RID: 10877 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Token(Token = "0x6002A7D")]
		[Address(RVA = "0x2A1E76C", Offset = "0x2A1E76C", VA = "0x2A1E76C")]
		private void method_22()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A7E RID: 10878 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1E7D8", Offset = "0x2A1E7D8", VA = "0x2A1E7D8")]
		[Token(Token = "0x6002A7E")]
		private void method_23()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A7F RID: 10879 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Token(Token = "0x6002A7F")]
		[Address(RVA = "0x2A1E844", Offset = "0x2A1E844", VA = "0x2A1E844")]
		private void method_24()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A80 RID: 10880 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1E8B0", Offset = "0x2A1E8B0", VA = "0x2A1E8B0")]
		[Token(Token = "0x6002A80")]
		private void method_25()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A81 RID: 10881 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Token(Token = "0x6002A81")]
		[Address(RVA = "0x2A1E91C", Offset = "0x2A1E91C", VA = "0x2A1E91C")]
		private void method_26()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A82 RID: 10882 RVA: 0x0005ACF4 File Offset: 0x00058EF4
		[Address(RVA = "0x2A1E988", Offset = "0x2A1E988", VA = "0x2A1E988")]
		[Token(Token = "0x6002A82")]
		private void method_27()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 2L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A83 RID: 10883 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1EA58", Offset = "0x2A1EA58", VA = "0x2A1EA58")]
		[Token(Token = "0x6002A83")]
		private void method_28()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A84 RID: 10884 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1EAC4", Offset = "0x2A1EAC4", VA = "0x2A1EAC4")]
		[Token(Token = "0x6002A84")]
		private void method_29()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A85 RID: 10885 RVA: 0x0005AD8C File Offset: 0x00058F8C
		[Address(RVA = "0x2A1EB30", Offset = "0x2A1EB30", VA = "0x2A1EB30")]
		[Token(Token = "0x6002A85")]
		private void method_30()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 8L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A86 RID: 10886 RVA: 0x0005ADD8 File Offset: 0x00058FD8
		[Address(RVA = "0x2A1EC00", Offset = "0x2A1EC00", VA = "0x2A1EC00")]
		[Token(Token = "0x6002A86")]
		private void method_31()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 6L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A87 RID: 10887 RVA: 0x0005ABE0 File Offset: 0x00058DE0
		[Token(Token = "0x6002A87")]
		[Address(RVA = "0x2A1ECD0", Offset = "0x2A1ECD0", VA = "0x2A1ECD0")]
		private void method_32()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			this.lineRenderer_0.positionCount = 5;
		}

		// Token: 0x06002A88 RID: 10888 RVA: 0x0005AE24 File Offset: 0x00059024
		[Token(Token = "0x6002A88")]
		[Address(RVA = "0x2A1EDA0", Offset = "0x2A1EDA0", VA = "0x2A1EDA0")]
		private void method_33()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 7L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A89 RID: 10889 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Token(Token = "0x6002A89")]
		[Address(RVA = "0x2A1EE70", Offset = "0x2A1EE70", VA = "0x2A1EE70")]
		private void method_34()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A8A RID: 10890 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Token(Token = "0x6002A8A")]
		[Address(RVA = "0x2A1EEDC", Offset = "0x2A1EEDC", VA = "0x2A1EEDC")]
		private void method_35()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A8B RID: 10891 RVA: 0x0005AE70 File Offset: 0x00059070
		[Address(RVA = "0x2A1EF48", Offset = "0x2A1EF48", VA = "0x2A1EF48")]
		[Token(Token = "0x6002A8B")]
		private void method_36()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 3L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A8C RID: 10892 RVA: 0x0005AEBC File Offset: 0x000590BC
		[Token(Token = "0x6002A8C")]
		[Address(RVA = "0x2A1F018", Offset = "0x2A1F018", VA = "0x2A1F018")]
		private void method_37()
		{
			base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 7L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A8D RID: 10893 RVA: 0x0005AEF0 File Offset: 0x000590F0
		[Address(RVA = "0x2A1F0E8", Offset = "0x2A1F0E8", VA = "0x2A1F0E8")]
		[Token(Token = "0x6002A8D")]
		private void method_38()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 2L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A8E RID: 10894 RVA: 0x0005AF3C File Offset: 0x0005913C
		[Address(RVA = "0x2A1F1B8", Offset = "0x2A1F1B8", VA = "0x2A1F1B8")]
		[Token(Token = "0x6002A8E")]
		private void method_39()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 1L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A8F RID: 10895 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1F288", Offset = "0x2A1F288", VA = "0x2A1F288")]
		[Token(Token = "0x6002A8F")]
		private void method_40()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A90 RID: 10896 RVA: 0x0005AF7C File Offset: 0x0005917C
		[Token(Token = "0x6002A90")]
		[Address(RVA = "0x2A1F2F4", Offset = "0x2A1F2F4", VA = "0x2A1F2F4")]
		private void method_41()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			this.lineRenderer_0.positionCount = 5;
		}

		// Token: 0x06002A91 RID: 10897 RVA: 0x0005AFC0 File Offset: 0x000591C0
		[Address(RVA = "0x2A1F3C4", Offset = "0x2A1F3C4", VA = "0x2A1F3C4")]
		[Token(Token = "0x6002A91")]
		private void method_42()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 4L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A92 RID: 10898 RVA: 0x0005AD8C File Offset: 0x00058F8C
		[Address(RVA = "0x2A1F494", Offset = "0x2A1F494", VA = "0x2A1F494")]
		[Token(Token = "0x6002A92")]
		private void method_43()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 8L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A93 RID: 10899 RVA: 0x0005AC24 File Offset: 0x00058E24
		[Token(Token = "0x6002A93")]
		[Address(RVA = "0x2A1F564", Offset = "0x2A1F564", VA = "0x2A1F564")]
		private void method_44()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 4L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A94 RID: 10900 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1F634", Offset = "0x2A1F634", VA = "0x2A1F634")]
		[Token(Token = "0x6002A94")]
		private void method_45()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A95 RID: 10901 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1F6A0", Offset = "0x2A1F6A0", VA = "0x2A1F6A0")]
		[Token(Token = "0x6002A95")]
		private void method_46()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A96 RID: 10902 RVA: 0x0005B00C File Offset: 0x0005920C
		[Address(RVA = "0x2A1F70C", Offset = "0x2A1F70C", VA = "0x2A1F70C")]
		[Token(Token = "0x6002A96")]
		public DemoDummyArm()
		{
			long num = 1056964608L;
			this.float_0 = (float)num;
			base..ctor();
		}

		// Token: 0x06002A97 RID: 10903 RVA: 0x0005ACF4 File Offset: 0x00058EF4
		[Token(Token = "0x6002A97")]
		[Address(RVA = "0x2A1F71C", Offset = "0x2A1F71C", VA = "0x2A1F71C")]
		private void Start()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 2L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A98 RID: 10904 RVA: 0x0005AABC File Offset: 0x00058CBC
		[Address(RVA = "0x2A1F7E8", Offset = "0x2A1F7E8", VA = "0x2A1F7E8")]
		[Token(Token = "0x6002A98")]
		private void method_47()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 3L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A99 RID: 10905 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1F8B8", Offset = "0x2A1F8B8", VA = "0x2A1F8B8")]
		[Token(Token = "0x6002A99")]
		private void method_48()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A9A RID: 10906 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1F924", Offset = "0x2A1F924", VA = "0x2A1F924")]
		[Token(Token = "0x6002A9A")]
		private void method_49()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A9B RID: 10907 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1F990", Offset = "0x2A1F990", VA = "0x2A1F990")]
		[Token(Token = "0x6002A9B")]
		private void method_50()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A9C RID: 10908 RVA: 0x0005AC24 File Offset: 0x00058E24
		[Address(RVA = "0x2A1F9FC", Offset = "0x2A1F9FC", VA = "0x2A1F9FC")]
		[Token(Token = "0x6002A9C")]
		private void method_51()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 4L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002A9D RID: 10909 RVA: 0x0005B02C File Offset: 0x0005922C
		[Address(RVA = "0x2A1FACC", Offset = "0x2A1FACC", VA = "0x2A1FACC")]
		[Token(Token = "0x6002A9D")]
		private void method_52()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
		}

		// Token: 0x06002A9E RID: 10910 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1FB9C", Offset = "0x2A1FB9C", VA = "0x2A1FB9C")]
		[Token(Token = "0x6002A9E")]
		private void method_53()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002A9F RID: 10911 RVA: 0x0005ACF4 File Offset: 0x00058EF4
		[Address(RVA = "0x2A1FC08", Offset = "0x2A1FC08", VA = "0x2A1FC08")]
		[Token(Token = "0x6002A9F")]
		private void method_54()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 0L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 2L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x06002AA0 RID: 10912 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1FCD8", Offset = "0x2A1FCD8", VA = "0x2A1FCD8")]
		[Token(Token = "0x6002AA0")]
		private void method_55()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002AA1 RID: 10913 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1FD44", Offset = "0x2A1FD44", VA = "0x2A1FD44")]
		[Token(Token = "0x6002AA1")]
		private void method_56()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002AA2 RID: 10914 RVA: 0x0005AA90 File Offset: 0x00058C90
		[Address(RVA = "0x2A1FDB0", Offset = "0x2A1FDB0", VA = "0x2A1FDB0")]
		[Token(Token = "0x6002AA2")]
		private void method_57()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_1;
			Vector3 position2 = transform2.position;
		}

		// Token: 0x06002AA3 RID: 10915 RVA: 0x0005AD8C File Offset: 0x00058F8C
		[Address(RVA = "0x2A1FE1C", Offset = "0x2A1FE1C", VA = "0x2A1FE1C")]
		[Token(Token = "0x6002AA3")]
		private void method_58()
		{
			ConfigurableJoint component = base.GetComponent<ConfigurableJoint>();
			Vector3 localPosition = this.transform_1.localPosition;
			long autoConfigureConnectedAnchor = 1L;
			component.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 position = this.transform_0.position;
			LineRenderer lineRenderer = this.lineRenderer_0;
			long positionCount = 8L;
			lineRenderer.positionCount = (int)positionCount;
		}

		// Token: 0x04000575 RID: 1397
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000575")]
		public Transform transform_0;

		// Token: 0x04000576 RID: 1398
		[Token(Token = "0x4000576")]
		[FieldOffset(Offset = "0x20")]
		public float float_0;

		// Token: 0x04000577 RID: 1399
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000577")]
		public LineRenderer lineRenderer_0;

		// Token: 0x04000578 RID: 1400
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000578")]
		public Transform transform_1;
	}
}
