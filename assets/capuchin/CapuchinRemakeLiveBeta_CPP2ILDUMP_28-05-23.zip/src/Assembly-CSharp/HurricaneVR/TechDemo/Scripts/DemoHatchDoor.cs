﻿using System;
using Cpp2IlInjected;
using HurricaneVR.Framework.Core.Utils;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x0200011B RID: 283
	[Token(Token = "0x200011B")]
	public class DemoHatchDoor : MonoBehaviour
	{
		// Token: 0x06002B5A RID: 11098 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Address(RVA = "0x36003A8", Offset = "0x36003A8", VA = "0x36003A8")]
		[Token(Token = "0x6002B5A")]
		public void method_0()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B5B RID: 11099 RVA: 0x0005BCD0 File Offset: 0x00059ED0
		[Address(RVA = "0x36004B8", Offset = "0x36004B8", VA = "0x36004B8")]
		[Token(Token = "0x6002B5B")]
		public void method_1()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B5C RID: 11100 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Address(RVA = "0x36005CC", Offset = "0x36005CC", VA = "0x36005CC")]
		[Token(Token = "0x6002B5C")]
		public void method_2()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B5D RID: 11101 RVA: 0x0005BD08 File Offset: 0x00059F08
		[Token(Token = "0x6002B5D")]
		[Address(RVA = "0x36006DC", Offset = "0x36006DC", VA = "0x36006DC")]
		private void method_3()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)40960;
			}
		}

		// Token: 0x06002B5E RID: 11102 RVA: 0x0005BD50 File Offset: 0x00059F50
		[Address(RVA = "0x36007F8", Offset = "0x36007F8", VA = "0x36007F8")]
		[Token(Token = "0x6002B5E")]
		public void method_4()
		{
			bool flag;
			if (!(flag = this.bool_0))
			{
				if (flag)
				{
				}
				SFXPlayer.أ\u089Dࢮ\u0745;
				Transform transform;
				Vector3 position = transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B5F RID: 11103 RVA: 0x0005BD88 File Offset: 0x00059F88
		[Address(RVA = "0x360090C", Offset = "0x360090C", VA = "0x360090C")]
		[Token(Token = "0x6002B5F")]
		public void method_5()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B60 RID: 11104 RVA: 0x0005BDC0 File Offset: 0x00059FC0
		[Address(RVA = "0x3600A20", Offset = "0x3600A20", VA = "0x3600A20")]
		[Token(Token = "0x6002B60")]
		private void method_6()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)24576;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B61 RID: 11105 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Address(RVA = "0x3600B40", Offset = "0x3600B40", VA = "0x3600B40")]
		[Token(Token = "0x6002B61")]
		public void method_7()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B62 RID: 11106 RVA: 0x0005BE0C File Offset: 0x0005A00C
		[Address(RVA = "0x3600C50", Offset = "0x3600C50", VA = "0x3600C50")]
		[Token(Token = "0x6002B62")]
		public void method_8()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B63 RID: 11107 RVA: 0x0005BE38 File Offset: 0x0005A038
		[Address(RVA = "0x3600D60", Offset = "0x3600D60", VA = "0x3600D60")]
		[Token(Token = "0x6002B63")]
		private void method_9()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)32768;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B64 RID: 11108 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Address(RVA = "0x3600E80", Offset = "0x3600E80", VA = "0x3600E80")]
		[Token(Token = "0x6002B64")]
		public void method_10()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B65 RID: 11109 RVA: 0x0005BE8C File Offset: 0x0005A08C
		[Address(RVA = "0x3600F90", Offset = "0x3600F90", VA = "0x3600F90")]
		[Token(Token = "0x6002B65")]
		public void method_11()
		{
		}

		// Token: 0x06002B66 RID: 11110 RVA: 0x0005BE9C File Offset: 0x0005A09C
		[Address(RVA = "0x36010A0", Offset = "0x36010A0", VA = "0x36010A0")]
		[Token(Token = "0x6002B66")]
		private void method_12()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)8192;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B67 RID: 11111 RVA: 0x0005BE38 File Offset: 0x0005A038
		[Address(RVA = "0x36011C0", Offset = "0x36011C0", VA = "0x36011C0")]
		[Token(Token = "0x6002B67")]
		private void method_13()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)32768;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B68 RID: 11112 RVA: 0x0005BEF0 File Offset: 0x0005A0F0
		[Address(RVA = "0x36012E0", Offset = "0x36012E0", VA = "0x36012E0")]
		[Token(Token = "0x6002B68")]
		private void method_14()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)49152;
			}
		}

		// Token: 0x06002B69 RID: 11113 RVA: 0x0005BF38 File Offset: 0x0005A138
		[Token(Token = "0x6002B69")]
		[Address(RVA = "0x36013FC", Offset = "0x36013FC", VA = "0x36013FC")]
		private void method_15()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)57344;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B6A RID: 11114 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x360151C", Offset = "0x360151C", VA = "0x360151C")]
		[Token(Token = "0x6002B6A")]
		public DemoHatchDoor()
		{
		}

		// Token: 0x06002B6B RID: 11115 RVA: 0x0005BF8C File Offset: 0x0005A18C
		[Address(RVA = "0x3601530", Offset = "0x3601530", VA = "0x3601530")]
		[Token(Token = "0x6002B6B")]
		private void method_16()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)17177;
			}
		}

		// Token: 0x06002B6C RID: 11116 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Address(RVA = "0x3601648", Offset = "0x3601648", VA = "0x3601648")]
		[Token(Token = "0x6002B6C")]
		public void method_17()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B6D RID: 11117 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Address(RVA = "0x3601758", Offset = "0x3601758", VA = "0x3601758")]
		[Token(Token = "0x6002B6D")]
		public void method_18()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B6E RID: 11118 RVA: 0x0005BFD4 File Offset: 0x0005A1D4
		[Token(Token = "0x6002B6E")]
		[Address(RVA = "0x3601868", Offset = "0x3601868", VA = "0x3601868")]
		private void method_19()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)16384;
			}
		}

		// Token: 0x06002B6F RID: 11119 RVA: 0x0005C01C File Offset: 0x0005A21C
		[Token(Token = "0x6002B6F")]
		[Address(RVA = "0x3601984", Offset = "0x3601984", VA = "0x3601984")]
		private void method_20()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)16384;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B70 RID: 11120 RVA: 0x0005BF38 File Offset: 0x0005A138
		[Address(RVA = "0x3601AA4", Offset = "0x3601AA4", VA = "0x3601AA4")]
		[Token(Token = "0x6002B70")]
		private void method_21()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)57344;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B71 RID: 11121 RVA: 0x0005BEF0 File Offset: 0x0005A0F0
		[Address(RVA = "0x3601BC4", Offset = "0x3601BC4", VA = "0x3601BC4")]
		[Token(Token = "0x6002B71")]
		private void method_22()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)49152;
			}
		}

		// Token: 0x06002B72 RID: 11122 RVA: 0x0005C070 File Offset: 0x0005A270
		[Token(Token = "0x6002B72")]
		[Address(RVA = "0x3601CE0", Offset = "0x3601CE0", VA = "0x3601CE0")]
		private void method_23()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)17092;
			}
		}

		// Token: 0x06002B73 RID: 11123 RVA: 0x0005BCD0 File Offset: 0x00059ED0
		[Token(Token = "0x6002B73")]
		[Address(RVA = "0x3601DFC", Offset = "0x3601DFC", VA = "0x3601DFC")]
		public void method_24()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B74 RID: 11124 RVA: 0x0005C0B8 File Offset: 0x0005A2B8
		[Address(RVA = "0x3601F10", Offset = "0x3601F10", VA = "0x3601F10")]
		[Token(Token = "0x6002B74")]
		public void method_25()
		{
			if (!this.bool_0)
			{
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B75 RID: 11125 RVA: 0x0005BCD0 File Offset: 0x00059ED0
		[Address(RVA = "0x3602020", Offset = "0x3602020", VA = "0x3602020")]
		[Token(Token = "0x6002B75")]
		public void method_26()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B76 RID: 11126 RVA: 0x0005BD08 File Offset: 0x00059F08
		[Token(Token = "0x6002B76")]
		[Address(RVA = "0x3602134", Offset = "0x3602134", VA = "0x3602134")]
		private void method_27()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)40960;
			}
		}

		// Token: 0x06002B77 RID: 11127 RVA: 0x0005C0DC File Offset: 0x0005A2DC
		[Address(RVA = "0x3602250", Offset = "0x3602250", VA = "0x3602250")]
		[Token(Token = "0x6002B77")]
		private void method_28()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)16948;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B78 RID: 11128 RVA: 0x0005C130 File Offset: 0x0005A330
		[Address(RVA = "0x360236C", Offset = "0x360236C", VA = "0x360236C")]
		[Token(Token = "0x6002B78")]
		private void method_29()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)17032;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B79 RID: 11129 RVA: 0x0005C184 File Offset: 0x0005A384
		[Address(RVA = "0x3602488", Offset = "0x3602488", VA = "0x3602488")]
		[Token(Token = "0x6002B79")]
		private void method_30()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)17164;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B7A RID: 11130 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Address(RVA = "0x36025A0", Offset = "0x36025A0", VA = "0x36025A0")]
		[Token(Token = "0x6002B7A")]
		public void method_31()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B7B RID: 11131 RVA: 0x0005C1D8 File Offset: 0x0005A3D8
		[Token(Token = "0x6002B7B")]
		[Address(RVA = "0x36026B0", Offset = "0x36026B0", VA = "0x36026B0")]
		private void method_32()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)16608;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B7C RID: 11132 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Address(RVA = "0x36027CC", Offset = "0x36027CC", VA = "0x36027CC")]
		[Token(Token = "0x6002B7C")]
		public void method_33()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B7D RID: 11133 RVA: 0x0005BCD0 File Offset: 0x00059ED0
		[Token(Token = "0x6002B7D")]
		[Address(RVA = "0x36028DC", Offset = "0x36028DC", VA = "0x36028DC")]
		public void method_34()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B7E RID: 11134 RVA: 0x0005BFD4 File Offset: 0x0005A1D4
		[Address(RVA = "0x36029F0", Offset = "0x36029F0", VA = "0x36029F0")]
		[Token(Token = "0x6002B7E")]
		private void method_35()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)16384;
			}
		}

		// Token: 0x06002B7F RID: 11135 RVA: 0x0005C22C File Offset: 0x0005A42C
		[Token(Token = "0x6002B7F")]
		[Address(RVA = "0x3602B0C", Offset = "0x3602B0C", VA = "0x3602B0C")]
		private void method_36()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)24576;
			}
		}

		// Token: 0x06002B80 RID: 11136 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Address(RVA = "0x3602C28", Offset = "0x3602C28", VA = "0x3602C28")]
		[Token(Token = "0x6002B80")]
		public void method_37()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B81 RID: 11137 RVA: 0x0005C274 File Offset: 0x0005A474
		[Token(Token = "0x6002B81")]
		[Address(RVA = "0x3602D38", Offset = "0x3602D38", VA = "0x3602D38")]
		private void Update()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B82 RID: 11138 RVA: 0x0005C2BC File Offset: 0x0005A4BC
		[Token(Token = "0x6002B82")]
		[Address(RVA = "0x3602E48", Offset = "0x3602E48", VA = "0x3602E48")]
		private void method_38()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)32768;
			}
		}

		// Token: 0x06002B83 RID: 11139 RVA: 0x0005C304 File Offset: 0x0005A504
		[Token(Token = "0x6002B83")]
		[Address(RVA = "0x3602F64", Offset = "0x3602F64", VA = "0x3602F64")]
		private void method_39()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Quaternion localRotation = base.transform.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)8192;
			}
		}

		// Token: 0x06002B84 RID: 11140 RVA: 0x0005C34C File Offset: 0x0005A54C
		[Address(RVA = "0x3603080", Offset = "0x3603080", VA = "0x3603080")]
		[Token(Token = "0x6002B84")]
		private void method_40()
		{
			if (!this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)8192;
			}
		}

		// Token: 0x06002B85 RID: 11141 RVA: 0x0005C38C File Offset: 0x0005A58C
		[Token(Token = "0x6002B85")]
		[Address(RVA = "0x360319C", Offset = "0x360319C", VA = "0x360319C")]
		private void method_41()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)49152;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B86 RID: 11142 RVA: 0x0005BE0C File Offset: 0x0005A00C
		[Address(RVA = "0x36032BC", Offset = "0x36032BC", VA = "0x36032BC")]
		[Token(Token = "0x6002B86")]
		public void method_42()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B87 RID: 11143 RVA: 0x0005BCD0 File Offset: 0x00059ED0
		[Token(Token = "0x6002B87")]
		[Address(RVA = "0x36033CC", Offset = "0x36033CC", VA = "0x36033CC")]
		public void method_43()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B88 RID: 11144 RVA: 0x0005BCD0 File Offset: 0x00059ED0
		[Address(RVA = "0x36034E0", Offset = "0x36034E0", VA = "0x36034E0")]
		[Token(Token = "0x6002B88")]
		public void method_44()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B89 RID: 11145 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Address(RVA = "0x36035F4", Offset = "0x36035F4", VA = "0x36035F4")]
		[Token(Token = "0x6002B89")]
		public void method_45()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B8A RID: 11146 RVA: 0x0005BCD0 File Offset: 0x00059ED0
		[Token(Token = "0x6002B8A")]
		[Address(RVA = "0x3603704", Offset = "0x3603704", VA = "0x3603704")]
		public void method_46()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B8B RID: 11147 RVA: 0x0005BCD0 File Offset: 0x00059ED0
		[Token(Token = "0x6002B8B")]
		[Address(RVA = "0x3603818", Offset = "0x3603818", VA = "0x3603818")]
		public void method_47()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B8C RID: 11148 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Token(Token = "0x6002B8C")]
		[Address(RVA = "0x360392C", Offset = "0x360392C", VA = "0x360392C")]
		public void method_48()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B8D RID: 11149 RVA: 0x0005C3E0 File Offset: 0x0005A5E0
		[Address(RVA = "0x3603A3C", Offset = "0x3603A3C", VA = "0x3603A3C")]
		[Token(Token = "0x6002B8D")]
		private void method_49()
		{
			bool flag;
			if ((flag = this.bool_0) && !flag)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				this.float_2 = (float)17163;
			}
		}

		// Token: 0x06002B8E RID: 11150 RVA: 0x0005C424 File Offset: 0x0005A624
		[Token(Token = "0x6002B8E")]
		[Address(RVA = "0x3603B54", Offset = "0x3603B54", VA = "0x3603B54")]
		private void method_50()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)17028;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B8F RID: 11151 RVA: 0x0005BCA4 File Offset: 0x00059EA4
		[Token(Token = "0x6002B8F")]
		[Address(RVA = "0x3603C70", Offset = "0x3603C70", VA = "0x3603C70")]
		public void method_51()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B90 RID: 11152 RVA: 0x0005BE38 File Offset: 0x0005A038
		[Token(Token = "0x6002B90")]
		[Address(RVA = "0x3603D80", Offset = "0x3603D80", VA = "0x3603D80")]
		private void method_52()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)32768;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B91 RID: 11153 RVA: 0x0005BCD0 File Offset: 0x00059ED0
		[Token(Token = "0x6002B91")]
		[Address(RVA = "0x3603EA0", Offset = "0x3603EA0", VA = "0x3603EA0")]
		public void method_53()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x06002B92 RID: 11154 RVA: 0x0005C470 File Offset: 0x0005A670
		[Token(Token = "0x6002B92")]
		[Address(RVA = "0x3603FB4", Offset = "0x3603FB4", VA = "0x3603FB4")]
		public void method_54()
		{
			bool flag;
			if (!(flag = this.bool_0))
			{
				if (flag)
				{
				}
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
		}

		// Token: 0x06002B93 RID: 11155 RVA: 0x0005C4A4 File Offset: 0x0005A6A4
		[Token(Token = "0x6002B93")]
		[Address(RVA = "0x36040C4", Offset = "0x36040C4", VA = "0x36040C4")]
		private void method_55()
		{
			if (this.bool_0 && !this.bool_1)
			{
				float deltaTime = Time.deltaTime;
				Transform transform = base.transform;
				Quaternion localRotation = base.transform.localRotation;
				float deltaTime2 = Time.deltaTime;
				long num = 1L;
				this.float_2 = (float)17222;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06002B94 RID: 11156 RVA: 0x0005BCD0 File Offset: 0x00059ED0
		[Token(Token = "0x6002B94")]
		[Address(RVA = "0x36041E0", Offset = "0x36041E0", VA = "0x36041E0")]
		public void method_56()
		{
			if (!this.bool_0)
			{
				SFXPlayer.أ\u089Dࢮ\u0745;
				Vector3 position = base.transform.position;
			}
			long num = 1L;
			this.bool_0 = (num != 0L);
		}

		// Token: 0x04000584 RID: 1412
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000584")]
		public float float_0;

		// Token: 0x04000585 RID: 1413
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000585")]
		public float float_1;

		// Token: 0x04000586 RID: 1414
		[Token(Token = "0x4000586")]
		[FieldOffset(Offset = "0x20")]
		public bool bool_0;

		// Token: 0x04000587 RID: 1415
		[FieldOffset(Offset = "0x21")]
		[Token(Token = "0x4000587")]
		public bool bool_1;

		// Token: 0x04000588 RID: 1416
		[Token(Token = "0x4000588")]
		[FieldOffset(Offset = "0x28")]
		public AudioClip audioClip_0;

		// Token: 0x04000589 RID: 1417
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000589")]
		private float float_2;
	}
}
