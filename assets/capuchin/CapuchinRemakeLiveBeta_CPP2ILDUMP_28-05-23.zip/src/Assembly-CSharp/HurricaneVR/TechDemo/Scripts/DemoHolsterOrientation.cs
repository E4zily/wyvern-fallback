﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HurricaneVR.TechDemo.Scripts
{
	// Token: 0x02000121 RID: 289
	[Token(Token = "0x2000121")]
	public class DemoHolsterOrientation : MonoBehaviour
	{
		// Token: 0x06002C88 RID: 11400 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x6002C88")]
		[Address(RVA = "0x2127968", Offset = "0x2127968", VA = "0x2127968")]
		public DemoHolsterOrientation()
		{
		}

		// Token: 0x0400059F RID: 1439
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400059F")]
		public Transform transform_0;
	}
}
