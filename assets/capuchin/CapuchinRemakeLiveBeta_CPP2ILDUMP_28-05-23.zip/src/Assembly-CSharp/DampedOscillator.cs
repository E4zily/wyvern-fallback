﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200005A RID: 90
[Token(Token = "0x200005A")]
public class DampedOscillator : MonoBehaviour
{
	// Token: 0x06000C9B RID: 3227 RVA: 0x0001AB78 File Offset: 0x00018D78
	[Address(RVA = "0x2A6E0E4", Offset = "0x2A6E0E4", VA = "0x2A6E0E4")]
	[Token(Token = "0x6000C9B")]
	private void method_0()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000C9C RID: 3228 RVA: 0x0001AC04 File Offset: 0x00018E04
	[Address(RVA = "0x2A6E2BC", Offset = "0x2A6E2BC", VA = "0x2A6E2BC")]
	[Token(Token = "0x6000C9C")]
	private void method_1()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform = base.transform;
			Quaternion rotation = transform.rotation;
		}
		if (this.bool_2)
		{
			Transform transform2 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000C9D RID: 3229 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A6E494", Offset = "0x2A6E494", VA = "0x2A6E494")]
	[Token(Token = "0x6000C9D")]
	private void method_2()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000C9E RID: 3230 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A6E66C", Offset = "0x2A6E66C", VA = "0x2A6E66C")]
	[Token(Token = "0x6000C9E")]
	private void method_3()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000C9F RID: 3231 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A6E844", Offset = "0x2A6E844", VA = "0x2A6E844")]
	[Token(Token = "0x6000C9F")]
	private void method_4()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CA0 RID: 3232 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A6EA1C", Offset = "0x2A6EA1C", VA = "0x2A6EA1C")]
	[Token(Token = "0x6000CA0")]
	private void method_5()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CA1 RID: 3233 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A6EBF4", Offset = "0x2A6EBF4", VA = "0x2A6EBF4")]
	[Token(Token = "0x6000CA1")]
	private void method_6()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CA2 RID: 3234 RVA: 0x0001AD14 File Offset: 0x00018F14
	[Address(RVA = "0x2A6EDCC", Offset = "0x2A6EDCC", VA = "0x2A6EDCC")]
	[Token(Token = "0x6000CA2")]
	private void method_7()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CA3 RID: 3235 RVA: 0x0001ADA0 File Offset: 0x00018FA0
	[Address(RVA = "0x2A6EFA4", Offset = "0x2A6EFA4", VA = "0x2A6EFA4")]
	[Token(Token = "0x6000CA3")]
	private void method_8()
	{
		float num = this.float_3;
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CA4 RID: 3236 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A6F17C", Offset = "0x2A6F17C", VA = "0x2A6F17C")]
	[Token(Token = "0x6000CA4")]
	public DampedOscillator()
	{
	}

	// Token: 0x06000CA5 RID: 3237 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A6F184", Offset = "0x2A6F184", VA = "0x2A6F184")]
	[Token(Token = "0x6000CA5")]
	private void method_9()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CA6 RID: 3238 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A6F35C", Offset = "0x2A6F35C", VA = "0x2A6F35C")]
	[Token(Token = "0x6000CA6")]
	private void method_10()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CA7 RID: 3239 RVA: 0x0001AE20 File Offset: 0x00019020
	[Address(RVA = "0x2A6F534", Offset = "0x2A6F534", VA = "0x2A6F534")]
	[Token(Token = "0x6000CA7")]
	private void method_11()
	{
		float deltaTime = Time.deltaTime;
		float deltaTime2 = Time.deltaTime;
		Transform transform;
		Vector3 position = transform.position;
		Transform transform2 = transform.transform;
		Quaternion rotation = transform2.rotation;
		Vector3 localScale = transform2.transform.localScale;
	}

	// Token: 0x06000CA8 RID: 3240 RVA: 0x0001AE60 File Offset: 0x00019060
	[Address(RVA = "0x2A6F70C", Offset = "0x2A6F70C", VA = "0x2A6F70C")]
	[Token(Token = "0x6000CA8")]
	private void method_12()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CA9 RID: 3241 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A6F8E4", Offset = "0x2A6F8E4", VA = "0x2A6F8E4")]
	[Token(Token = "0x6000CA9")]
	private void method_13()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CAA RID: 3242 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A6FABC", Offset = "0x2A6FABC", VA = "0x2A6FABC")]
	[Token(Token = "0x6000CAA")]
	private void method_14()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CAB RID: 3243 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A6FC94", Offset = "0x2A6FC94", VA = "0x2A6FC94")]
	[Token(Token = "0x6000CAB")]
	private void method_15()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CAC RID: 3244 RVA: 0x0001AB78 File Offset: 0x00018D78
	[Address(RVA = "0x2A6FE6C", Offset = "0x2A6FE6C", VA = "0x2A6FE6C")]
	[Token(Token = "0x6000CAC")]
	private void method_16()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CAD RID: 3245 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A70044", Offset = "0x2A70044", VA = "0x2A70044")]
	[Token(Token = "0x6000CAD")]
	private void method_17()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CAE RID: 3246 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A7021C", Offset = "0x2A7021C", VA = "0x2A7021C")]
	[Token(Token = "0x6000CAE")]
	private void method_18()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CAF RID: 3247 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A703F4", Offset = "0x2A703F4", VA = "0x2A703F4")]
	[Token(Token = "0x6000CAF")]
	private void method_19()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CB0 RID: 3248 RVA: 0x0001AEEC File Offset: 0x000190EC
	[Address(RVA = "0x2A705CC", Offset = "0x2A705CC", VA = "0x2A705CC")]
	[Token(Token = "0x6000CB0")]
	private void method_20()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CB1 RID: 3249 RVA: 0x0001AC88 File Offset: 0x00018E88
	[Address(RVA = "0x2A707A4", Offset = "0x2A707A4", VA = "0x2A707A4")]
	[Token(Token = "0x6000CB1")]
	private void method_21()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x06000CB2 RID: 3250 RVA: 0x0001AF6C File Offset: 0x0001916C
	[Address(RVA = "0x2A7097C", Offset = "0x2A7097C", VA = "0x2A7097C")]
	[Token(Token = "0x6000CB2")]
	private void Update()
	{
		float num = this.float_3;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_0;
		this.float_3 = num;
		if (flag)
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
		}
		if (this.bool_1)
		{
			Transform transform2 = base.transform;
			Quaternion rotation = this.transform_0.rotation;
		}
		if (this.bool_2)
		{
			Transform transform3 = base.transform;
			Vector3 localScale = this.transform_0.localScale;
			return;
		}
	}

	// Token: 0x040001CD RID: 461
	[Token(Token = "0x40001CD")]
	[FieldOffset(Offset = "0x18")]
	public float float_0;

	// Token: 0x040001CE RID: 462
	[Token(Token = "0x40001CE")]
	[FieldOffset(Offset = "0x1C")]
	public float float_1;

	// Token: 0x040001CF RID: 463
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40001CF")]
	public float float_2;

	// Token: 0x040001D0 RID: 464
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001D0")]
	public Transform transform_0;

	// Token: 0x040001D1 RID: 465
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40001D1")]
	public Vector3 vector3_0;

	// Token: 0x040001D2 RID: 466
	[Token(Token = "0x40001D2")]
	[FieldOffset(Offset = "0x3C")]
	public bool bool_0;

	// Token: 0x040001D3 RID: 467
	[FieldOffset(Offset = "0x3D")]
	[Token(Token = "0x40001D3")]
	public bool bool_1;

	// Token: 0x040001D4 RID: 468
	[FieldOffset(Offset = "0x3E")]
	[Token(Token = "0x40001D4")]
	public bool bool_2;

	// Token: 0x040001D5 RID: 469
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40001D5")]
	private float float_3;
}
