﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200009D RID: 157
[Token(Token = "0x200009D")]
public class QueueSelect : MonoBehaviour
{
	// Token: 0x06001743 RID: 5955 RVA: 0x0002D5B0 File Offset: 0x0002B7B0
	[Token(Token = "0x6001743")]
	[Address(RVA = "0x3473F10", Offset = "0x3473F10", VA = "0x3473F10")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001744 RID: 5956 RVA: 0x0002D5CC File Offset: 0x0002B7CC
	[Address(RVA = "0x3474308", Offset = "0x3474308", VA = "0x3474308")]
	[Token(Token = "0x6001744")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("NoseAttachPoint", "back");
			this.createRoom_0.queue = "NetworkPlayer";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			this.createRoom_0.queue = "Fire Stick Is Lighting...";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("HandL", "_Tint");
			this.createRoom_0.queue = "ChangeToTagged";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001745 RID: 5957 RVA: 0x0002D6FC File Offset: 0x0002B8FC
	[Address(RVA = "0x3474700", Offset = "0x3474700", VA = "0x3474700")]
	[Token(Token = "0x6001745")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("HandL", "_Tint");
			this.createRoom_0.queue = "typesOfTalk";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("cosmos", "QuickStatic");
			this.createRoom_0.queue = "Try Connect To Server...";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			this.createRoom_0.queue = "Regular";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001746 RID: 5958 RVA: 0x0002D82C File Offset: 0x0002BA2C
	[Address(RVA = "0x3474AF8", Offset = "0x3474AF8", VA = "0x3474AF8")]
	[Token(Token = "0x6001746")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("This is the 5000 Bananas button, and it was just clicked", "HandR");
			this.createRoom_0.queue = "Body";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("CASUAL", "Player");
			this.createRoom_0.queue = "On";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("_BaseColor", "Vector1_d371bd24217449349bd747533d51af6b");
			this.createRoom_0.queue = "Stopped Colliding";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001747 RID: 5959 RVA: 0x0002D968 File Offset: 0x0002BB68
	[Address(RVA = "0x3474EF0", Offset = "0x3474EF0", VA = "0x3474EF0")]
	[Token(Token = "0x6001747")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06001748 RID: 5960 RVA: 0x0002D988 File Offset: 0x0002BB88
	[Address(RVA = "0x34752C8", Offset = "0x34752C8", VA = "0x34752C8")]
	[Token(Token = "0x6001748")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("Player", "windowsmr");
			this.createRoom_0.queue = "PlayerDeath";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("Bruh i cannot go here you stupid L bozo", "back");
			this.createRoom_0.queue = "Skelechin";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			this.createRoom_0.queue = "BN";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001749 RID: 5961 RVA: 0x0002DAB8 File Offset: 0x0002BCB8
	[Address(RVA = "0x34756C0", Offset = "0x34756C0", VA = "0x34756C0")]
	[Token(Token = "0x6001749")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("ENABLE", "typesOfTalk");
			this.createRoom_0.queue = "PRESS AGAIN TO CONFIRM";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("\n Time: ", "INSIGNIFICANT CURRENCY");
			Material material3 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material4 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material5 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("FingerTip", "Try Connect To Server...");
			this.createRoom_0.queue = "Cannot access index {0}. Buffer is empty";
			Material material6 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material7 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material8 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x0600174A RID: 5962 RVA: 0x0002DBD8 File Offset: 0x0002BDD8
	[Address(RVA = "0x3475AB8", Offset = "0x3475AB8", VA = "0x3475AB8")]
	[Token(Token = "0x600174A")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("ORGTARG", "HandL");
			this.createRoom_0.queue = "Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Color white = Color.white;
			Material material2 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		PlayerPrefs.SetString("character limit reached", "HandR");
		this.createRoom_0.queue = "monke is not my monke";
		Material material3 = base.GetComponent<MeshRenderer>().material;
		Color red2 = Color.red;
		Material material4 = this.meshRenderer_0.material;
		Color white3 = Color.white;
		Material material5 = this.meshRenderer_1.material;
		Color white4 = Color.white;
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Not connected to room", "username");
			this.createRoom_0.queue = "Added Winner Money";
			Material material6 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material7 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material8 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x0600174B RID: 5963 RVA: 0x0002DD00 File Offset: 0x0002BF00
	[Address(RVA = "0x3475EB0", Offset = "0x3475EB0", VA = "0x3475EB0")]
	[Token(Token = "0x600174B")]
	public void method_8(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("Version", "/");
			this.createRoom_0.queue = "ORGTARG";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("BN", "Vector1_d371bd24217449349bd747533d51af6b");
			this.createRoom_0.queue = "oculus";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Song Index: ", "n0");
			this.createRoom_0.queue = "username";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x0600174C RID: 5964 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34762A8", Offset = "0x34762A8", VA = "0x34762A8")]
	[Token(Token = "0x600174C")]
	public void method_9(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600174D RID: 5965 RVA: 0x0002DE38 File Offset: 0x0002C038
	[Address(RVA = "0x34766A0", Offset = "0x34766A0", VA = "0x34766A0")]
	[Token(Token = "0x600174D")]
	public void method_10(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("/", "Downloading image");
			this.createRoom_0.queue = "hh:mmtt";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		PlayerPrefs.SetString("Queue", "Removing ");
		this.createRoom_0.queue = "waited for your bullshit unity grrr";
		Material material4 = base.GetComponent<MeshRenderer>().material;
		Color red2 = Color.red;
		Material material5 = this.meshRenderer_0.material;
		Color white3 = Color.white;
		Material material6 = this.meshRenderer_1.material;
		Color white4 = Color.white;
		if (this.bool_2)
		{
			this.createRoom_0.queue = "Add/Remove Glasses";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x0600174E RID: 5966 RVA: 0x0002DF58 File Offset: 0x0002C158
	[Address(RVA = "0x3476A98", Offset = "0x3476A98", VA = "0x3476A98")]
	[Token(Token = "0x600174E")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("User has been reported for: ", "Platform failed to initialize due to exception.");
			this.createRoom_0.queue = "hh:mmtt";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("ChangeMaterialToNormal", "username");
			this.createRoom_0.queue = "isLava";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("NormalWeather", "Player");
			this.createRoom_0.queue = "/";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x0600174F RID: 5967 RVA: 0x0002E094 File Offset: 0x0002C294
	[Address(RVA = "0x3476E90", Offset = "0x3476E90", VA = "0x3476E90")]
	[Token(Token = "0x600174F")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("HorrorAgreement", "Connected to Server.");
			this.createRoom_0.queue = "You Already Own This Item";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("Cannot access index {0}. Buffer is empty", "Open");
			this.createRoom_0.queue = "Queue";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("trol", "Count of rooms ");
			this.createRoom_0.queue = "Try Connect To Server...";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001750 RID: 5968 RVA: 0x0002E1D0 File Offset: 0x0002C3D0
	[Token(Token = "0x6001750")]
	[Address(RVA = "0x3477288", Offset = "0x3477288", VA = "0x3477288")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			this.createRoom_0.queue = "username";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("SaveHeight", "TurnAmount");
			this.createRoom_0.queue = "Player";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("PLAYER IS BANNED", "Vector1_d371bd24217449349bd747533d51af6b");
			this.createRoom_0.queue = "retract broken";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001751 RID: 5969 RVA: 0x0002E300 File Offset: 0x0002C500
	[Token(Token = "0x6001751")]
	[Address(RVA = "0x3477680", Offset = "0x3477680", VA = "0x3477680")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("A Player has left the Room.", "Player");
			this.createRoom_0.queue = "\n Time: ";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			this.createRoom_0.queue = "true";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Tagging", "BN");
			this.createRoom_0.queue = "typesOfTalk";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001752 RID: 5970 RVA: 0x0002E430 File Offset: 0x0002C630
	[Address(RVA = "0x3477A78", Offset = "0x3477A78", VA = "0x3477A78")]
	[Token(Token = "0x6001752")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("_BaseColor", "Regular");
			this.createRoom_0.queue = "Tagging";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("Starting to bake textures on frame ", "Regular");
			this.createRoom_0.queue = "Players Online: ";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			this.createRoom_0.queue = "casual";
			Material material6 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Color white5 = Color.white;
			Material material7 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001753 RID: 5971 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3477E64", Offset = "0x3477E64", VA = "0x3477E64")]
	[Token(Token = "0x6001753")]
	public void method_16(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001754 RID: 5972 RVA: 0x0002E548 File Offset: 0x0002C748
	[Token(Token = "0x6001754")]
	[Address(RVA = "0x347825C", Offset = "0x347825C", VA = "0x347825C")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("SaveHeight", "Connected to Server.");
			this.createRoom_0.queue = "typesOfTalk";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("DisableCosmetic", "On");
			this.createRoom_0.queue = "Cannot access index {0}. Buffer is empty";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Vertical", "Charging...");
			this.createRoom_0.queue = "Squeeze";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001755 RID: 5973 RVA: 0x0002E684 File Offset: 0x0002C884
	[Token(Token = "0x6001755")]
	[Address(RVA = "0x3478654", Offset = "0x3478654", VA = "0x3478654")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("DISABLE", "hh:mmtt");
			this.createRoom_0.queue = "HandL";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("Left a room", "betaAgree");
			this.createRoom_0.queue = "Player";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Player", "DisableCosmetic");
			this.createRoom_0.queue = "liftoff failed!";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001756 RID: 5974 RVA: 0x0002E7C0 File Offset: 0x0002C9C0
	[Token(Token = "0x6001756")]
	[Address(RVA = "0x3478A40", Offset = "0x3478A40", VA = "0x3478A40")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("Joined a Room.", "procedural animation script required on ");
			this.createRoom_0.queue = "A new Player joined a Room.";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("FingerTip", "StartSong");
			this.createRoom_0.queue = "PlayerHead";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			this.createRoom_0.queue = "EnableCosmetic";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001757 RID: 5975 RVA: 0x0002E8F0 File Offset: 0x0002CAF0
	[Address(RVA = "0x3478E2C", Offset = "0x3478E2C", VA = "0x3478E2C")]
	[Token(Token = "0x6001757")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("Muted", "BLUPORT");
			this.createRoom_0.queue = "On";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("Right Hand", "EnableCosmetic");
			this.createRoom_0.queue = "On";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Joined Public Room Successfully", "Player");
			this.createRoom_0.queue = "'s Grabber is not assigned.";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Color white5 = Color.white;
			Material material8 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001758 RID: 5976 RVA: 0x0002EA20 File Offset: 0x0002CC20
	[Address(RVA = "0x3479218", Offset = "0x3479218", VA = "0x3479218")]
	[Token(Token = "0x6001758")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("FingerTip", "windowsmr");
			this.createRoom_0.queue = "PlayerHead";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("Cannot access an empty buffer.", "typesOfTalk");
			this.createRoom_0.queue = "Combine textures & build combined mesh all at once";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("This is the 2500 Bananas button, and it was just clicked", "PlayWave");
			this.createRoom_0.queue = "true";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001759 RID: 5977 RVA: 0x0002EB5C File Offset: 0x0002CD5C
	[Token(Token = "0x6001759")]
	[Address(RVA = "0x3479610", Offset = "0x3479610", VA = "0x3479610")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("TurnAmount", "casual");
			this.createRoom_0.queue = "forced knee";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("FingerTip", "Purchase For ");
			this.createRoom_0.queue = "Agreed";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("True", "containsStaff");
			this.createRoom_0.queue = "Added Winner Money";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x0600175A RID: 5978 RVA: 0x0002EC98 File Offset: 0x0002CE98
	[Token(Token = "0x600175A")]
	[Address(RVA = "0x3479A08", Offset = "0x3479A08", VA = "0x3479A08")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("NoseAttachPoint", "\tExpires: ");
			this.createRoom_0.queue = "Regular";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("_WobbleZ", "Joined a Room.");
			this.createRoom_0.queue = "FingerTip";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Cannot access an empty buffer.", "Starting to bake textures on frame ");
			this.createRoom_0.queue = "Cheating";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x0600175B RID: 5979 RVA: 0x0002EDD4 File Offset: 0x0002CFD4
	[Address(RVA = "0x3479E00", Offset = "0x3479E00", VA = "0x3479E00")]
	[Token(Token = "0x600175B")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			this.createRoom_0.queue = "Meta Platform entitlement error: ";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("hh:mmtt", "You struck apon an error. ");
			this.createRoom_0.queue = "EnableCosmetic";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("containsStaff", "Trying Getting Entilement...");
			this.createRoom_0.queue = "Player";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x0600175C RID: 5980 RVA: 0x0002EF04 File Offset: 0x0002D104
	[Address(RVA = "0x347A1F8", Offset = "0x347A1F8", VA = "0x347A1F8")]
	[Token(Token = "0x600175C")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			this.createRoom_0.queue = "Connected to Server.";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("CapuchinStore", "goUpRPC");
			this.createRoom_0.queue = "FLSPTLT";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString(". Please update you game to the latest version", "Head");
			this.createRoom_0.queue = "On";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x0600175D RID: 5981 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600175D")]
	[Address(RVA = "0x347A5F0", Offset = "0x347A5F0", VA = "0x347A5F0")]
	public void method_26(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600175E RID: 5982 RVA: 0x0002F034 File Offset: 0x0002D234
	[Token(Token = "0x600175E")]
	[Address(RVA = "0x347A9DC", Offset = "0x347A9DC", VA = "0x347A9DC")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("Creating and loadingtexture", "");
			this.createRoom_0.queue = "Joined a Room.";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("retract broken", "Add/Remove Hat");
			this.createRoom_0.queue = "Add/Remove Sword";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Color white4 = Color.white;
		}
		PlayerPrefs.SetString("Player", "trol");
		this.createRoom_0.queue = "Player was caught cheating";
		Material material6 = base.GetComponent<MeshRenderer>().material;
		Color red3 = Color.red;
		Material material7 = this.meshRenderer_0.material;
		Color white5 = Color.white;
		Material material8 = this.meshRenderer_1.material;
		Color white6 = Color.white;
	}

	// Token: 0x0600175F RID: 5983 RVA: 0x0002F15C File Offset: 0x0002D35C
	[Token(Token = "0x600175F")]
	[Address(RVA = "0x347ADD4", Offset = "0x347ADD4", VA = "0x347ADD4")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("FingerTip", "A new Player joined a Room.");
			this.createRoom_0.queue = "containsStaff";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("Player", "Adding ");
			this.createRoom_0.queue = "A Player has left the Room.";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("M/d/yyyy", "META");
			this.createRoom_0.queue = "Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001760 RID: 5984 RVA: 0x0002F298 File Offset: 0x0002D498
	[Token(Token = "0x6001760")]
	[Address(RVA = "0x347B1CC", Offset = "0x347B1CC", VA = "0x347B1CC")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("Did Hit", "Not connected to room");
			this.createRoom_0.queue = "lava";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("next", "PlayWave");
			this.createRoom_0.queue = "Push To Talk";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Date: ", "");
			this.createRoom_0.queue = "closeToObject";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001761 RID: 5985 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001761")]
	[Address(RVA = "0x347B5C4", Offset = "0x347B5C4", VA = "0x347B5C4")]
	public void method_30(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001762 RID: 5986 RVA: 0x0002F3D4 File Offset: 0x0002D5D4
	[Address(RVA = "0x347B9B0", Offset = "0x347B9B0", VA = "0x347B9B0")]
	[Token(Token = "0x6001762")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("Name Changing Error. Error: ", "NetworkGunShoot");
			this.createRoom_0.queue = "hh:mmtt";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		PlayerPrefs.SetString("CapuchinStore", "hh:mm:sstt");
		this.createRoom_0.queue = "Player";
		Material material4 = base.GetComponent<MeshRenderer>().material;
		Color red2 = Color.red;
		Material material5 = this.meshRenderer_0.material;
		Color white3 = Color.white;
		Material material6 = this.meshRenderer_1.material;
		Color white4 = Color.white;
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Round end", "Player");
			this.createRoom_0.queue = "tutorialCheck";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001763 RID: 5987 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001763")]
	[Address(RVA = "0x347BD9C", Offset = "0x347BD9C", VA = "0x347BD9C")]
	public void method_32(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001764 RID: 5988 RVA: 0x0002F508 File Offset: 0x0002D708
	[Address(RVA = "0x347C188", Offset = "0x347C188", VA = "0x347C188")]
	[Token(Token = "0x6001764")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("forced knee retract", "Tagged");
			this.createRoom_0.queue = "CASUAL";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("lava", "Player");
			this.createRoom_0.queue = "True";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("_BumpMap", "TurnAmount");
			this.createRoom_0.queue = "Joined a Room.";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001765 RID: 5989 RVA: 0x0002F644 File Offset: 0x0002D844
	[Token(Token = "0x6001765")]
	[Address(RVA = "0x347C580", Offset = "0x347C580", VA = "0x347C580")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("Queue", "casual");
			this.createRoom_0.queue = "casual";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("Queue", "cheeseTouch");
			this.createRoom_0.queue = "cheese";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Queue", "lava");
			this.createRoom_0.queue = "lava";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001766 RID: 5990 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x347C938", Offset = "0x347C938", VA = "0x347C938")]
	[Token(Token = "0x6001766")]
	public void method_34(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001767 RID: 5991 RVA: 0x0002F780 File Offset: 0x0002D980
	[Token(Token = "0x6001767")]
	[Address(RVA = "0x347CD30", Offset = "0x347CD30", VA = "0x347CD30")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("htc", "liftoff failed!");
			this.createRoom_0.queue = "forced knee retract";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("_Tint", "Right Hand");
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("PLAYER IS BANNED", "Purchased: ");
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001768 RID: 5992 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6001768")]
	[Address(RVA = "0x347D128", Offset = "0x347D128", VA = "0x347D128")]
	public void method_36(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001769 RID: 5993 RVA: 0x0002F89C File Offset: 0x0002DA9C
	[Token(Token = "0x6001769")]
	[Address(RVA = "0x347D514", Offset = "0x347D514", VA = "0x347D514")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		PlayerPrefs.SetString("character limit reached", "Vector1_d371bd24217449349bd747533d51af6b");
		MeshRenderer meshRenderer;
		Material material = meshRenderer.material;
		Color red = Color.red;
		Color white = Color.white;
		Color white2 = Color.white;
		PlayerPrefs.SetString("", "MetaAuth");
		MeshRenderer meshRenderer2;
		Material material2 = meshRenderer2.material;
		Color red2 = Color.red;
		Color white3 = Color.white;
		Color white4 = Color.white;
		PlayerPrefs.SetString("A new Player joined a Room.", "Bare Torso");
		MeshRenderer meshRenderer3;
		Material material3 = meshRenderer3.material;
		Color red3 = Color.red;
		Color white5 = Color.white;
		Color white6 = Color.white;
	}

	// Token: 0x0600176A RID: 5994 RVA: 0x0002F93C File Offset: 0x0002DB3C
	[Token(Token = "0x600176A")]
	[Address(RVA = "0x347D90C", Offset = "0x347D90C", VA = "0x347D90C")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("Player", "CapuchinRemade");
			this.createRoom_0.queue = "_WobbleZ";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("windowsmr", "button");
			this.createRoom_0.queue = "unlocked!";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Start Gamemode", "HandL");
			this.createRoom_0.queue = "A new Player joined a Room.";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x0600176B RID: 5995 RVA: 0x0002FA78 File Offset: 0x0002DC78
	[Token(Token = "0x600176B")]
	[Address(RVA = "0x347DD04", Offset = "0x347DD04", VA = "0x347DD04")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("CapuchinStore", "friend");
			this.createRoom_0.queue = "jump char false";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("Player", "NetworkGunShoot");
			this.createRoom_0.queue = "A new Player joined a Room.";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			throw new MissingMethodException();
		}
	}

	// Token: 0x0600176C RID: 5996 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600176C")]
	[Address(RVA = "0x347E0E4", Offset = "0x347E0E4", VA = "0x347E0E4")]
	public void method_40(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600176D RID: 5997 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600176D")]
	[Address(RVA = "0x347E4C8", Offset = "0x347E4C8", VA = "0x347E4C8")]
	public void method_41(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600176E RID: 5998 RVA: 0x0002FB64 File Offset: 0x0002DD64
	[Address(RVA = "0x347E8C0", Offset = "0x347E8C0", VA = "0x347E8C0")]
	[Token(Token = "0x600176E")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		PlayerPrefs.SetString("DisableCosmetic", "Downloading image");
		MeshRenderer meshRenderer;
		Material material = meshRenderer.material;
		Color red = Color.red;
		Color white = Color.white;
		Color white2 = Color.white;
		PlayerPrefs.SetString("", "\n Time: ");
		MeshRenderer meshRenderer2;
		Material material2 = meshRenderer2.material;
		Color red2 = Color.red;
		Color white3 = Color.white;
		Color white4 = Color.white;
		PlayerPrefs.SetString("\tExpires: ", "KeyPos");
		MeshRenderer meshRenderer3;
		Material material3 = meshRenderer3.material;
		Color red3 = Color.red;
		Color white5 = Color.white;
		Color white6 = Color.white;
	}

	// Token: 0x0600176F RID: 5999 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600176F")]
	[Address(RVA = "0x347ECB8", Offset = "0x347ECB8", VA = "0x347ECB8")]
	public void method_43(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001770 RID: 6000 RVA: 0x0002FC04 File Offset: 0x0002DE04
	[Address(RVA = "0x347F0B0", Offset = "0x347F0B0", VA = "0x347F0B0")]
	[Token(Token = "0x6001770")]
	public void method_44(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			this.createRoom_0.queue = "Applying to material";
			Material material3 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material4 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material5 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			this.createRoom_0.queue = "Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}";
			Material material6 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material7 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material8 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001771 RID: 6001 RVA: 0x0002FCF8 File Offset: 0x0002DEF8
	[Token(Token = "0x6001771")]
	[Address(RVA = "0x347F4A8", Offset = "0x347F4A8", VA = "0x347F4A8")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("username", "Completed baking textures on frame ");
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			this.createRoom_0.queue = "deathScream";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("liftoff failed!", "Hats");
			this.createRoom_0.queue = "jump char false";
			Material material6 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material7 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material8 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001772 RID: 6002 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6001772")]
	[Address(RVA = "0x347F8A0", Offset = "0x347F8A0", VA = "0x347F8A0")]
	public QueueSelect()
	{
	}

	// Token: 0x06001773 RID: 6003 RVA: 0x0002FE0C File Offset: 0x0002E00C
	[Address(RVA = "0x347F8A8", Offset = "0x347F8A8", VA = "0x347F8A8")]
	[Token(Token = "0x6001773")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("PRESS AGAIN TO CONFIRM", "True");
			this.createRoom_0.queue = "username";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			PlayerPrefs.SetString("[InputHelpers.IsPressed] The value of <button> is out or the supported range.", "Player");
			this.createRoom_0.queue = "DisableCosmetic";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("HandL", "Cannot access index {0}. Buffer size is {1}");
			this.createRoom_0.queue = "oculus";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x06001774 RID: 6004 RVA: 0x0002FF48 File Offset: 0x0002E148
	[Address(RVA = "0x347FCA0", Offset = "0x347FCA0", VA = "0x347FCA0")]
	[Token(Token = "0x6001774")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		bool inRoom = PhotonNetwork.InRoom;
		if (this.bool_0)
		{
			PlayerPrefs.SetString("closeToObject", "User has been reported for: ");
			this.createRoom_0.queue = "Cannot access index {0}. Buffer size is {1}";
			Material material = base.GetComponent<MeshRenderer>().material;
			Color red = Color.red;
			Material material2 = this.meshRenderer_0.material;
			Color white = Color.white;
			Material material3 = this.meshRenderer_1.material;
			Color white2 = Color.white;
		}
		if (this.bool_1)
		{
			this.createRoom_0.queue = "CASUAL";
			Material material4 = base.GetComponent<MeshRenderer>().material;
			Color red2 = Color.red;
			Material material5 = this.meshRenderer_0.material;
			Color white3 = Color.white;
			Material material6 = this.meshRenderer_1.material;
			Color white4 = Color.white;
		}
		if (this.bool_2)
		{
			PlayerPrefs.SetString("Tagging", "deathScream");
			this.createRoom_0.queue = "FLSPTLT";
			Material material7 = base.GetComponent<MeshRenderer>().material;
			Color red3 = Color.red;
			Material material8 = this.meshRenderer_0.material;
			Color white5 = Color.white;
			Material material9 = this.meshRenderer_1.material;
			Color white6 = Color.white;
			return;
		}
	}

	// Token: 0x040002FF RID: 767
	[Token(Token = "0x40002FF")]
	[FieldOffset(Offset = "0x18")]
	public bool bool_0;

	// Token: 0x04000300 RID: 768
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x4000300")]
	public bool bool_1;

	// Token: 0x04000301 RID: 769
	[Token(Token = "0x4000301")]
	[FieldOffset(Offset = "0x1A")]
	public bool bool_2;

	// Token: 0x04000302 RID: 770
	[Token(Token = "0x4000302")]
	[FieldOffset(Offset = "0x20")]
	public CreateRoom createRoom_0;

	// Token: 0x04000303 RID: 771
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000303")]
	public MeshRenderer meshRenderer_0;

	// Token: 0x04000304 RID: 772
	[Token(Token = "0x4000304")]
	[FieldOffset(Offset = "0x30")]
	public MeshRenderer meshRenderer_1;
}
