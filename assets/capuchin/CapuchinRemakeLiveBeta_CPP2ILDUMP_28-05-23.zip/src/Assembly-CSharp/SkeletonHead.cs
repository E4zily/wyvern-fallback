﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000F7 RID: 247
[Token(Token = "0x20000F7")]
public class SkeletonHead : MonoBehaviour
{
	// Token: 0x06002528 RID: 9512 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B952A0", Offset = "0x2B952A0", VA = "0x2B952A0")]
	[Token(Token = "0x6002528")]
	public void method_0()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002529 RID: 9513 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95378", Offset = "0x2B95378", VA = "0x2B95378")]
	[Token(Token = "0x6002529")]
	public void LateUpdate()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600252A RID: 9514 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95438", Offset = "0x2B95438", VA = "0x2B95438")]
	[Token(Token = "0x600252A")]
	public void method_1()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600252B RID: 9515 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B9550C", Offset = "0x2B9550C", VA = "0x2B9550C")]
	[Token(Token = "0x600252B")]
	public void method_2()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600252C RID: 9516 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B955E4", Offset = "0x2B955E4", VA = "0x2B955E4")]
	[Token(Token = "0x600252C")]
	public void method_3()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600252D RID: 9517 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B956B8", Offset = "0x2B956B8", VA = "0x2B956B8")]
	[Token(Token = "0x600252D")]
	public void method_4()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600252E RID: 9518 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95790", Offset = "0x2B95790", VA = "0x2B95790")]
	[Token(Token = "0x600252E")]
	public void method_5()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600252F RID: 9519 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95868", Offset = "0x2B95868", VA = "0x2B95868")]
	[Token(Token = "0x600252F")]
	public void method_6()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002530 RID: 9520 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95940", Offset = "0x2B95940", VA = "0x2B95940")]
	[Token(Token = "0x6002530")]
	public void method_7()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002531 RID: 9521 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95A18", Offset = "0x2B95A18", VA = "0x2B95A18")]
	[Token(Token = "0x6002531")]
	public void method_8()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002532 RID: 9522 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95AEC", Offset = "0x2B95AEC", VA = "0x2B95AEC")]
	[Token(Token = "0x6002532")]
	public void method_9()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002533 RID: 9523 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95BC4", Offset = "0x2B95BC4", VA = "0x2B95BC4")]
	[Token(Token = "0x6002533")]
	public void method_10()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002534 RID: 9524 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95C9C", Offset = "0x2B95C9C", VA = "0x2B95C9C")]
	[Token(Token = "0x6002534")]
	public void method_11()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002535 RID: 9525 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95D74", Offset = "0x2B95D74", VA = "0x2B95D74")]
	[Token(Token = "0x6002535")]
	public void method_12()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002536 RID: 9526 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95E4C", Offset = "0x2B95E4C", VA = "0x2B95E4C")]
	[Token(Token = "0x6002536")]
	public void method_13()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002537 RID: 9527 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95F24", Offset = "0x2B95F24", VA = "0x2B95F24")]
	[Token(Token = "0x6002537")]
	public void method_14()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002538 RID: 9528 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B95FFC", Offset = "0x2B95FFC", VA = "0x2B95FFC")]
	[Token(Token = "0x6002538")]
	public void method_15()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002539 RID: 9529 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B960D4", Offset = "0x2B960D4", VA = "0x2B960D4")]
	[Token(Token = "0x6002539")]
	public void method_16()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600253A RID: 9530 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B961AC", Offset = "0x2B961AC", VA = "0x2B961AC")]
	[Token(Token = "0x600253A")]
	public void method_17()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600253B RID: 9531 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B96284", Offset = "0x2B96284", VA = "0x2B96284")]
	[Token(Token = "0x600253B")]
	public void method_18()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600253C RID: 9532 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B9635C", Offset = "0x2B9635C", VA = "0x2B9635C")]
	[Token(Token = "0x600253C")]
	public void method_19()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600253D RID: 9533 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B96434", Offset = "0x2B96434", VA = "0x2B96434")]
	[Token(Token = "0x600253D")]
	public void method_20()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600253E RID: 9534 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B9650C", Offset = "0x2B9650C", VA = "0x2B9650C")]
	[Token(Token = "0x600253E")]
	public void method_21()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600253F RID: 9535 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B965E4", Offset = "0x2B965E4", VA = "0x2B965E4")]
	[Token(Token = "0x600253F")]
	public void method_22()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002540 RID: 9536 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B966BC", Offset = "0x2B966BC", VA = "0x2B966BC")]
	[Token(Token = "0x6002540")]
	public void method_23()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002541 RID: 9537 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B96794", Offset = "0x2B96794", VA = "0x2B96794")]
	[Token(Token = "0x6002541")]
	public void method_24()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002542 RID: 9538 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B9686C", Offset = "0x2B9686C", VA = "0x2B9686C")]
	[Token(Token = "0x6002542")]
	public void method_25()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002543 RID: 9539 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B96944", Offset = "0x2B96944", VA = "0x2B96944")]
	[Token(Token = "0x6002543")]
	public void method_26()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002544 RID: 9540 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B96A1C", Offset = "0x2B96A1C", VA = "0x2B96A1C")]
	[Token(Token = "0x6002544")]
	public void method_27()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002545 RID: 9541 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B96AF4", Offset = "0x2B96AF4", VA = "0x2B96AF4")]
	[Token(Token = "0x6002545")]
	public void method_28()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002546 RID: 9542 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B96BCC", Offset = "0x2B96BCC", VA = "0x2B96BCC")]
	[Token(Token = "0x6002546")]
	public void method_29()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002547 RID: 9543 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B96CA4", Offset = "0x2B96CA4", VA = "0x2B96CA4")]
	[Token(Token = "0x6002547")]
	public void method_30()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002548 RID: 9544 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B96D7C", Offset = "0x2B96D7C", VA = "0x2B96D7C")]
	[Token(Token = "0x6002548")]
	public void method_31()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06002549 RID: 9545 RVA: 0x00045E1C File Offset: 0x0004401C
	[Address(RVA = "0x2B96E54", Offset = "0x2B96E54", VA = "0x2B96E54")]
	[Token(Token = "0x6002549")]
	public void method_32()
	{
		bool inRoom = PhotonNetwork.InRoom;
	}

	// Token: 0x0600254A RID: 9546 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B96F2C", Offset = "0x2B96F2C", VA = "0x2B96F2C")]
	[Token(Token = "0x600254A")]
	public void method_33()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600254B RID: 9547 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2B97004", Offset = "0x2B97004", VA = "0x2B97004")]
	[Token(Token = "0x600254B")]
	public SkeletonHead()
	{
	}

	// Token: 0x0600254C RID: 9548 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B9700C", Offset = "0x2B9700C", VA = "0x2B9700C")]
	[Token(Token = "0x600254C")]
	public void method_34()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600254D RID: 9549 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B970E4", Offset = "0x2B970E4", VA = "0x2B970E4")]
	[Token(Token = "0x600254D")]
	public void method_35()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600254E RID: 9550 RVA: 0x00045DE4 File Offset: 0x00043FE4
	[Address(RVA = "0x2B971BC", Offset = "0x2B971BC", VA = "0x2B971BC")]
	[Token(Token = "0x600254E")]
	public void method_36()
	{
		bool inRoom = PhotonNetwork.InRoom;
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		Transform transform = gameObject.transform;
		if (<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x040004D3 RID: 1235
	[Token(Token = "0x40004D3")]
	[FieldOffset(Offset = "0x18")]
	public PhotonView photonView_0;

	// Token: 0x040004D4 RID: 1236
	[Token(Token = "0x40004D4")]
	[FieldOffset(Offset = "0x20")]
	public GameObject gameObject_0;
}
