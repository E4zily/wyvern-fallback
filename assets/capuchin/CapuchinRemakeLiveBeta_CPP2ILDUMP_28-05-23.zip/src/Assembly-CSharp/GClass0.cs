﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Utilities;

// Token: 0x02000069 RID: 105
[Token(Token = "0x2000069")]
public class GClass0 : IEnumerable<InputAction>, IDisposable, IInputActionCollection2, IInputActionCollection, IEnumerable
{
	// Token: 0x06000E5F RID: 3679 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000E5F")]
	[Address(RVA = "0x218C4B4", Offset = "0x218C4B4", VA = "0x218C4B4")]
	public GClass0.GStruct1 method_0()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E60 RID: 3680 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218C4E0", Offset = "0x218C4E0", VA = "0x218C4E0")]
	[Token(Token = "0x6000E60")]
	public GClass0.GStruct1 method_1()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E61 RID: 3681 RVA: 0x000024FC File Offset: 0x000006FC
	[Address(RVA = "0x218C50C", Offset = "0x218C50C", VA = "0x218C50C", Slot = "18")]
	[Token(Token = "0x6000E61")]
	public void vmethod_0()
	{
		this.inputActionAsset_0.Enable();
	}

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x06000E62 RID: 3682 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x17000021")]
	public GClass0.GStruct0 GStruct0_0
	{
		[Token(Token = "0x6000E62")]
		[Address(RVA = "0x218C528", Offset = "0x218C528", VA = "0x218C528")]
		get
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}
	}

	// Token: 0x06000E63 RID: 3683 RVA: 0x00002509 File Offset: 0x00000709
	[Address(RVA = "0x218C554", Offset = "0x218C554", VA = "0x218C554", Slot = "19")]
	[Token(Token = "0x6000E63")]
	public ReadOnlyArray<InputDevice>? vmethod_1()
	{
		return this.inputActionAsset_0.devices;
	}

	// Token: 0x06000E64 RID: 3684 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218C5A0", Offset = "0x218C5A0", VA = "0x218C5A0")]
	[Token(Token = "0x6000E64")]
	public GClass0.GStruct3 method_2()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E65 RID: 3685 RVA: 0x000024FC File Offset: 0x000006FC
	[Address(RVA = "0x218C5CC", Offset = "0x218C5CC", VA = "0x218C5CC", Slot = "13")]
	[Token(Token = "0x6000E65")]
	public void Enable()
	{
		this.inputActionAsset_0.Enable();
	}

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x06000E66 RID: 3686 RVA: 0x0001EDE8 File Offset: 0x0001CFE8
	// (set) Token: 0x06000E81 RID: 3713 RVA: 0x00002549 File Offset: 0x00000749
	[Token(Token = "0x1700001D")]
	public InputBinding? bindingMask
	{
		[Address(RVA = "0x218C5E8", Offset = "0x218C5E8", VA = "0x218C5E8", Slot = "7")]
		[Token(Token = "0x6000E66")]
		get
		{
			throw new NullReferenceException();
		}
		[Address(RVA = "0x218D670", Offset = "0x218D670", VA = "0x218D670", Slot = "8")]
		[Token(Token = "0x6000E81")]
		set
		{
			this.inputActionAsset_0.bindingMask = value;
		}
	}

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x06000E67 RID: 3687 RVA: 0x00002516 File Offset: 0x00000716
	[Token(Token = "0x17000020")]
	public IEnumerable<InputBinding> bindings
	{
		[Address(RVA = "0x218C614", Offset = "0x218C614", VA = "0x218C614", Slot = "4")]
		[Token(Token = "0x6000E67")]
		get
		{
			return this.inputActionAsset_0.bindings;
		}
	}

	// Token: 0x06000E68 RID: 3688 RVA: 0x0001EDE8 File Offset: 0x0001CFE8
	[Token(Token = "0x6000E68")]
	[Address(RVA = "0x218C630", Offset = "0x218C630", VA = "0x218C630", Slot = "20")]
	public InputBinding? vmethod_2()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06000E69 RID: 3689 RVA: 0x00002523 File Offset: 0x00000723
	[Token(Token = "0x6000E69")]
	[Address(RVA = "0x218C65C", Offset = "0x218C65C", VA = "0x218C65C")]
	public InputActionAsset method_3()
	{
		return this.inputActionAsset_0;
	}

	// Token: 0x06000E6A RID: 3690 RVA: 0x0000252B File Offset: 0x0000072B
	[Token(Token = "0x6000E6A")]
	[Address(RVA = "0x218C664", Offset = "0x218C664", VA = "0x218C664", Slot = "21")]
	public InputAction vmethod_3(string string_0, bool bool_0 = false)
	{
		return this.inputActionAsset_0.FindAction(string_0, bool_0);
	}

	// Token: 0x06000E6B RID: 3691 RVA: 0x0000253A File Offset: 0x0000073A
	[Address(RVA = "0x218C684", Offset = "0x218C684", VA = "0x218C684", Slot = "22")]
	[Token(Token = "0x6000E6B")]
	public int vmethod_4(InputBinding inputBinding_0, out InputAction inputAction_45)
	{
		return this.inputActionAsset_0.FindBinding(inputBinding_0, out inputAction_45);
	}

	// Token: 0x06000E6C RID: 3692 RVA: 0x00002549 File Offset: 0x00000749
	[Address(RVA = "0x218C6E4", Offset = "0x218C6E4", VA = "0x218C6E4", Slot = "23")]
	[Token(Token = "0x6000E6C")]
	public void vmethod_5(InputBinding? nullable_0)
	{
		this.inputActionAsset_0.bindingMask = nullable_0;
	}

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x06000E6D RID: 3693 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x17000023")]
	public GClass0.GStruct2 GStruct2_0
	{
		[Address(RVA = "0x218C73C", Offset = "0x218C73C", VA = "0x218C73C")]
		[Token(Token = "0x6000E6D")]
		get
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}
	}

	// Token: 0x06000E6E RID: 3694 RVA: 0x00002557 File Offset: 0x00000757
	[Token(Token = "0x6000E6E")]
	[Address(RVA = "0x218C768", Offset = "0x218C768", VA = "0x218C768", Slot = "14")]
	public void Disable()
	{
		this.inputActionAsset_0.Disable();
	}

	// Token: 0x06000E6F RID: 3695 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000E6F")]
	[Address(RVA = "0x218C784", Offset = "0x218C784", VA = "0x218C784")]
	public GClass0.GStruct3 method_4()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E70 RID: 3696 RVA: 0x00002549 File Offset: 0x00000749
	[Token(Token = "0x6000E70")]
	[Address(RVA = "0x218C7B0", Offset = "0x218C7B0", VA = "0x218C7B0", Slot = "24")]
	public void vmethod_6(InputBinding? nullable_0)
	{
		this.inputActionAsset_0.bindingMask = nullable_0;
	}

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x06000E71 RID: 3697 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x17000024")]
	public GClass0.GStruct3 GStruct3_0
	{
		[Token(Token = "0x6000E71")]
		[Address(RVA = "0x218C808", Offset = "0x218C808", VA = "0x218C808")]
		get
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}
	}

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x06000E72 RID: 3698 RVA: 0x00002523 File Offset: 0x00000723
	[Token(Token = "0x1700001C")]
	public InputActionAsset InputActionAsset_0 { [Token(Token = "0x6000E72")] [Address(RVA = "0x218C834", Offset = "0x218C834", VA = "0x218C834")] get; }

	// Token: 0x06000E73 RID: 3699 RVA: 0x00002564 File Offset: 0x00000764
	[Address(RVA = "0x218C83C", Offset = "0x218C83C", VA = "0x218C83C", Slot = "12")]
	[Token(Token = "0x6000E73")]
	public bool Contains(InputAction action)
	{
		return this.inputActionAsset_0.Contains(action);
	}

	// Token: 0x06000E74 RID: 3700 RVA: 0x0001EDFC File Offset: 0x0001CFFC
	[Token(Token = "0x6000E74")]
	[Address(RVA = "0x218C858", Offset = "0x218C858", VA = "0x218C858")]
	public GClass0()
	{
		long num = 1L;
		this.int_0 = (int)num;
		base..ctor();
		InputActionAsset inputActionAsset = InputActionAsset.FromJson("{\n    \"name\": \"HVRInputActions\",\n    \"maps\": [\n        {\n            \"name\": \"LeftHand\",\n            \"id\": \"272f6d14-89ba-496f-b7ff-215263d3219f\",\n            \"actions\": [\n                {\n                    \"name\": \"TriggerPress\",\n                    \"type\": \"Button\",\n                    \"id\": \"578a0cd6-f388-4fa3-92f3-c09338bdf6fc\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"Trigger\",\n                    \"type\": \"Value\",\n                    \"id\": \"5c8cf249-a01c-4b19-8eea-152b951f6a5a\",\n                    \"expectedControlType\": \"Analog\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": true\n                },\n                {\n                    \"name\": \"PrimaryButton\",\n                    \"type\": \"Button\",\n                    \"id\": \"204073bf-582e-48f4-a392-6eaf1e637387\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"PrimaryTouch\",\n                    \"type\": \"Button\",\n                    \"id\": \"48a4f982-c501-412c-a715-b9201cb08c37\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"Menu\",\n                    \"type\": \"Button\",\n                    \"id\": \"e91ffee7-ec69-40fb-8663-4ebf07153bfe\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"Primary2DAxis\",\n                    \"type\": \"Value\",\n                    \"id\": \"0e72db49-759e-4b56-853f-a5e3b9bf0e04\",\n                    \"expectedControlType\": \"Vector2\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": true\n                },\n                {\n                    \"name\": \"Primary2DAxisClick\",\n                    \"type\": \"Button\",\n                    \"id\": \"d36e4b01-3a25-4dc6-8094-179ddb10bd71\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"Primary2DAxisTouch\",\n                    \"type\": \"Button\",\n                    \"id\": \"416d6df4-7244-4b5c-986c-11881e0eac57\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"Secondary2DAxis\",\n                    \"type\": \"Value\",\n                    \"id\": \"344eec1c-660f-4d4a-8b5b-1a2362d9b2de\",\n                    \"expectedControlType\": \"Vector2\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": true\n                },\n                {\n                    \"name\": \"Secondary2DAxisClick\",\n                    \"type\": \"Button\",\n                    \"id\": \"927e0cfe-b2ed-4a00-8048-3cd36742a8e3\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"Secondary2DAxisTouch\",\n                    \"type\": \"Button\",\n                    \"id\": \"28bf5850-459e-4b46-af7a-24a5a64fdf99\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"Grip\",\n                    \"type\": \"Value\",\n                    \"id\": \"26a9b492-9ead-4e86-9484-d69dc44c512e\",\n                    \"expectedControlType\": \"Axis\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": true\n                },\n                {\n                    \"name\": \"GripPress\",\n                    \"type\": \"Button\",\n                    \"id\": \"e91897d7-06ef-41b9-aaa2-b14ae7540fca\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"GripForce\",\n                    \"type\": \"Value\",\n                    \"id\": \"36b1a84c-21c8-4826-8ecc-bfd5fea14c7b\",\n                    \"expectedControlType\": \"Analog\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": true\n                },\n                {\n                    \"name\": \"SecondaryButton\",\n                    \"type\": \"Button\",\n                    \"id\": \"1414e4ef-05d7-40b1-b759-aa2c2c9cee56\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"SecondaryTouch\",\n                    \"type\": \"Button\",\n                    \"id\": \"83a06fa6-147b-41c5-9841-1fd2bbb33c31\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"TriggerTouch\",\n                    \"type\": \"Button\",\n                    \"id\": \"a2c3edea-193d-4944-91ba-2e2630b711d2\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"ControllerPosition\",\n                    \"type\": \"Value\",\n                    \"id\": \"4ac0bda8-e0c1-4d35-9125-d1a86167ce4c\",\n                    \"expectedControlType\": \"Vector3\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": true\n                },\n                {\n                    \"name\": \"ControllerRotation\",\n                    \"type\": \"Value\",\n                    \"id\": \"5c60ec11-4989-4ca5-8c81-a31ee8afad7f\",\n                    \"expectedControlType\": \"Quaternion\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": true\n                },\n                {\n                    \"name\": \"Haptics\",\n                    \"type\": \"PassThrough\",\n                    \"id\": \"c2bd3cd6-8deb-46c4-95a9-93eaa08c44b3\",\n                    \"expectedControlType\": \"Haptic\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                }\n            ],\n            \"bindings\": [\n                {\n                    \"name\": \"\",\n                    \"id\": \"b9c19907-3b5c-4207-ad18-5a86655f688c\",\n                    \"path\": \"<XRController>{LeftHand}/{triggerButton}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"TriggerPress\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"ec353a5a-6a7a-4ee6-a33e-d12a8c0b705a\",\n                    \"path\": \"<XRController>{LeftHand}/{trigger}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Trigger\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"1a98fe1d-5477-4473-9ed1-05d2decb2c15\",\n                    \"path\": \"<XRController>{LeftHand}/{primaryButton}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"PrimaryButton\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"3dfde460-9bef-4bd9-943d-170adc171ff8\",\n                    \"path\": \"<XRController>{LeftHand}/{primaryTouch}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"PrimaryTouch\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"9603ae96-fef3-432c-88a0-282232c1368d\",\n                    \"path\": \"<XRController>{LeftHand}/{menu}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Menu\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"6f261d50-7cf3-4d07-9fe5-f57d21751d4d\",\n                    \"path\": \"<ViveController>{LeftHand}/menu\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Menu\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"54ac7ab0-8ca9-4cbc-a6d1-da5ee0b055cb\",\n                    \"path\": \"<XRController>{LeftHand}/{primary2DAxis}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Primary2DAxis\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"85d45408-e658-4df8-ab60-de9273ceb30c\",\n                    \"path\": \"<XRController>{LeftHand}/{primary2DAxisClick}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Primary2DAxisClick\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"a07f0bb7-9d68-4288-b0f1-78c62a995fa4\",\n                    \"path\": \"<XRController>{LeftHand}/{primary2DAxisTouch}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Primary2DAxisTouch\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"cb03eabc-18e2-447a-a308-dc36cf9ec38e\",\n                    \"path\": \"<XRController>{LeftHand}/{secondary2DAxis}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Secondary2DAxis\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"d8e6dbb2-9e0e-453c-aaa5-5967f2fab6f6\",\n                    \"path\": \"<ViveController>{LeftHand}/trackpad\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"XR Usage\",\n                    \"action\": \"Secondary2DAxis\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"fadeed58-e6fc-4cc4-9fdc-5cfae044209c\",\n                    \"path\": \"<XRController>{LeftHand}/{secondary2DAxisClick}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Secondary2DAxisClick\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"366ac51f-3093-4ead-8dba-662fe2cbb81f\",\n                    \"path\": \"<ViveController>{LeftHand}/trackpadClicked\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"XR Usage\",\n                    \"action\": \"Secondary2DAxisClick\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"b74594f8-e87a-43ae-82ec-47612e07bfb3\",\n                    \"path\": \"<XRController>{LeftHand}/{secondary2DAxisTouch}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Secondary2DAxisTouch\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"72eeb177-b210-4a4a-8a29-1db62419451d\",\n                    \"path\": \"<ViveController>{LeftHand}/trackpadTouched\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"XR Usage\",\n                    \"action\": \"Secondary2DAxisTouch\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"26245d74-dc1a-4fce-a7e1-1d4688ef73b1\",\n                    \"path\": \"<XRController>{LeftHand}/{grip}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Grip\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"42d65f44-8e82-44cd-b3c4-a5d6cea301c6\",\n                    \"path\": \"<OculusTouchController>{LeftHand}/grip\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"Grip\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"1458d4ea-a188-4ad0-9215-0e48997da150\",\n                    \"path\": \"<XRController>{LeftHand}/{gripButton}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"GripPress\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"0c3f7ce0-b62f-44e2-a1e1-11f143de72d7\",\n                    \"path\": \"<XRController>{LeftHand}/{secondaryButton}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"SecondaryButton\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"6cfe2a5d-28c1-425b-998e-810968e19292\",\n                    \"path\": \"<XRController>{LeftHand}/{secondaryTouch}\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"SecondaryTouch\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"c8114404-e28d-455e-b8a6-393da81c4ace\",\n                    \"path\": \"<XRController>{LeftHand}/triggerTouched\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"\",\n                    \"action\": \"TriggerTouch\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"0a25f7f9-be46-4a4a-b346-a0d2c02c2817\",\n                    \"path\": \"<ValveIndexController>{LeftHand}/gripForce\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"XR Usage\",\n                    \"action\": \"GripForce\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"cfa3aaa8-78b6-48e7-8002-beb9903fe613\",\n                    \"path\": \"<XRController>{LeftHand}/pointerPosition\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"XR Usage\",\n                    \"action\": \"ControllerPosition\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"61b858cd-a94a-42be-b4ea-566b0502fec7\",\n                    \"path\": \"<XRController>{LeftHand}/pointerRotation\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"XR Usage\",\n                    \"action\": \"ControllerRotation\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                },\n                {\n                    \"name\": \"\",\n                    \"id\": \"e719282e-3d03-4d88-aa13-873641db842a\",\n                    \"path\": \"<XRController>{LeftHand}/haptic\",\n                    \"interactions\": \"\",\n                    \"processors\": \"\",\n                    \"groups\": \"XR Usage\",\n                    \"action\": \"Haptics\",\n                    \"isComposite\": false,\n                    \"isPartOfComposite\": false\n                }\n            ]\n        },\n        {\n            \"name\": \"RightHand\",\n            \"id\": \"fd87d126-5dc2-445c-82df-1abc6c9f8076\",\n            \"actions\": [\n                {\n                    \"name\": \"TriggerPress\",\n                    \"type\": \"Button\",\n                    \"id\": \"bc163c5e-01a5-48ae-83b3-87e68f24f888\",\n                    \"expectedControlType\": \"Button\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": false\n                },\n                {\n                    \"name\": \"Trigger\",\n                    \"type\": \"Value\",\n                    \"id\": \"2fccaf18-d578-4ac9-9d0b-08db4a2e1dc7\",\n                    \"expectedControlType\": \"Axis\",\n                    \"processors\": \"\",\n                    \"interactions\": \"\",\n                    \"initialStateCheck\": true\n                },\n                {\n                    \"name\": \"PrimaryButton\",\n                    \"type\": \"Button\",\n                    \"id\": \"b87d0657-0e2f-41f9-92ee-6c7f0b0fa4f8\",\n                    \"expectedControlType\": \"Button\",\n                   [...string is too long...]");
		this.InputActionAsset_0 = inputActionAsset;
		InputActionAsset inputActionAsset2 = this.inputActionAsset_0;
		long throwIfNotFound = 1L;
		InputActionMap inputActionMap = inputActionAsset2.FindActionMap("LeftHand", throwIfNotFound != 0L);
		this.inputActionMap_0 = inputActionMap;
		InputAction inputAction;
		this.inputAction_0 = inputAction;
		InputAction inputAction2;
		this.inputAction_1 = inputAction2;
		InputAction inputAction3;
		this.inputAction_2 = inputAction3;
		InputAction inputAction4;
		this.inputAction_3 = inputAction4;
		InputAction inputAction5;
		this.inputAction_4 = inputAction5;
		InputAction inputAction6;
		this.inputAction_5 = inputAction6;
		InputAction inputAction7;
		this.inputAction_6 = inputAction7;
		InputAction inputAction8;
		this.inputAction_7 = inputAction8;
		InputAction inputAction9;
		this.inputAction_8 = inputAction9;
		InputAction inputAction10;
		this.inputAction_9 = inputAction10;
		InputAction inputAction11;
		this.inputAction_10 = inputAction11;
		InputAction inputAction12;
		this.inputAction_11 = inputAction12;
		InputAction inputAction13;
		this.inputAction_12 = inputAction13;
		InputAction inputAction14;
		this.inputAction_13 = inputAction14;
		InputAction inputAction15;
		this.inputAction_14 = inputAction15;
		InputAction inputAction16;
		this.inputAction_15 = inputAction16;
		InputAction inputAction17;
		this.inputAction_16 = inputAction17;
		InputAction inputAction18;
		this.inputAction_17 = inputAction18;
		InputAction inputAction19;
		this.inputAction_18 = inputAction19;
		InputAction inputAction20;
		this.inputAction_19 = inputAction20;
		InputAction inputAction21;
		this.inputAction_20 = inputAction21;
		InputAction inputAction22;
		this.inputAction_21 = inputAction22;
		InputAction inputAction23;
		this.inputAction_22 = inputAction23;
		InputAction inputAction24;
		this.inputAction_23 = inputAction24;
		InputAction inputAction25;
		this.inputAction_24 = inputAction25;
		InputAction inputAction26;
		this.inputAction_25 = inputAction26;
		InputAction inputAction27;
		this.inputAction_26 = inputAction27;
		InputActionMap inputActionMap2 = this.inputActionMap_1;
		long throwIfNotFound2 = 1L;
		InputAction inputAction28 = inputActionMap2.FindAction("Primary2DAxisTouch", throwIfNotFound2 != 0L);
		this.inputAction_27 = inputAction28;
		InputActionMap inputActionMap3 = this.inputActionMap_1;
		long throwIfNotFound3 = 1L;
		InputAction inputAction29 = inputActionMap3.FindAction("Secondary2DAxis", throwIfNotFound3 != 0L);
		this.inputAction_28 = inputAction29;
		InputActionMap inputActionMap4 = this.inputActionMap_1;
		long throwIfNotFound4 = 1L;
		InputAction inputAction30 = inputActionMap4.FindAction("Secondary2DAxisClick", throwIfNotFound4 != 0L);
		this.inputAction_29 = inputAction30;
		InputActionMap inputActionMap5 = this.inputActionMap_1;
		long throwIfNotFound5 = 1L;
		InputAction inputAction31 = inputActionMap5.FindAction("Secondary2DAxisTouch", throwIfNotFound5 != 0L);
		this.inputAction_30 = inputAction31;
		InputActionMap inputActionMap6 = this.inputActionMap_1;
		long throwIfNotFound6 = 1L;
		InputAction inputAction32 = inputActionMap6.FindAction("Grip", throwIfNotFound6 != 0L);
		this.inputAction_31 = inputAction32;
		InputActionMap inputActionMap7 = this.inputActionMap_1;
		long throwIfNotFound7 = 1L;
		InputAction inputAction33 = inputActionMap7.FindAction("GripPress", throwIfNotFound7 != 0L);
		this.inputAction_32 = inputAction33;
		InputActionMap inputActionMap8 = this.inputActionMap_1;
		long throwIfNotFound8 = 1L;
		InputAction inputAction34 = inputActionMap8.FindAction("GripForce", throwIfNotFound8 != 0L);
		this.inputAction_33 = inputAction34;
		InputActionMap inputActionMap9 = this.inputActionMap_1;
		long throwIfNotFound9 = 1L;
		InputAction inputAction35 = inputActionMap9.FindAction("SecondaryButton", throwIfNotFound9 != 0L);
		this.inputAction_34 = inputAction35;
		InputActionMap inputActionMap10 = this.inputActionMap_1;
		long throwIfNotFound10 = 1L;
		InputAction inputAction36 = inputActionMap10.FindAction("SecondaryTouch", throwIfNotFound10 != 0L);
		this.inputAction_35 = inputAction36;
		InputActionMap inputActionMap11 = this.inputActionMap_1;
		long throwIfNotFound11 = 1L;
		InputAction inputAction37 = inputActionMap11.FindAction("TriggerTouch", throwIfNotFound11 != 0L);
		this.inputAction_36 = inputAction37;
		InputActionMap inputActionMap12 = this.inputActionMap_1;
		long throwIfNotFound12 = 1L;
		InputAction inputAction38 = inputActionMap12.FindAction("ControllerPosition", throwIfNotFound12 != 0L);
		this.inputAction_37 = inputAction38;
		InputActionMap inputActionMap13 = this.inputActionMap_1;
		long throwIfNotFound13 = 1L;
		inputActionMap13.FindAction("ControllerRotation", throwIfNotFound13 != 0L);
		this.inputAction_38 = "ControllerRotation";
		InputActionMap inputActionMap14 = this.inputActionMap_1;
		long throwIfNotFound14 = 1L;
		InputAction inputAction39 = inputActionMap14.FindAction("Haptics", throwIfNotFound14 != 0L);
		this.inputAction_39 = inputAction39;
		InputActionAsset inputActionAsset3 = this.inputActionAsset_0;
		long throwIfNotFound15 = 1L;
		InputActionMap inputActionMap15 = inputActionAsset3.FindActionMap("HMD", throwIfNotFound15 != 0L);
		this.inputActionMap_2 = inputActionMap15;
		InputActionMap inputActionMap16 = this.inputActionMap_2;
		long throwIfNotFound16 = 1L;
		InputAction inputAction40 = inputActionMap16.FindAction("hmdPosition", throwIfNotFound16 != 0L);
		this.inputAction_40 = inputAction40;
		InputAction inputAction41;
		this.inputAction_41 = inputAction41;
		InputActionAsset inputActionAsset4 = this.inputActionAsset_0;
		long throwIfNotFound17 = 1L;
		InputActionMap inputActionMap17 = inputActionAsset4.FindActionMap("UI", throwIfNotFound17 != 0L);
		this.inputActionMap_3 = inputActionMap17;
		InputActionMap inputActionMap18 = this.inputActionMap_3;
		long throwIfNotFound18 = 1L;
		InputAction inputAction42 = inputActionMap18.FindAction("Click", throwIfNotFound18 != 0L);
		this.inputAction_42 = inputAction42;
		InputActionMap inputActionMap19 = this.inputActionMap_3;
		long throwIfNotFound19 = 1L;
		InputAction inputAction43 = inputActionMap19.FindAction("pointerPosition", throwIfNotFound19 != 0L);
		this.inputAction_43 = inputAction43;
		InputActionMap inputActionMap20 = this.inputActionMap_3;
		long throwIfNotFound20 = 1L;
		InputAction inputAction44 = inputActionMap20.FindAction("pointerRotation", throwIfNotFound20 != 0L);
		this.inputAction_44 = inputAction44;
	}

	// Token: 0x06000E75 RID: 3701 RVA: 0x0001EDE8 File Offset: 0x0001CFE8
	[Token(Token = "0x6000E75")]
	[Address(RVA = "0x218D3A4", Offset = "0x218D3A4", VA = "0x218D3A4", Slot = "25")]
	public InputBinding? vmethod_7()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06000E76 RID: 3702 RVA: 0x0001F1C4 File Offset: 0x0001D3C4
	[Token(Token = "0x6000E76")]
	[Address(RVA = "0x218D3D0", Offset = "0x218D3D0", VA = "0x218D3D0", Slot = "26")]
	public void vmethod_8(ReadOnlyArray<InputDevice>? nullable_0)
	{
		InputActionAsset inputActionAsset = this.inputActionAsset_0;
		inputActionAsset.devices = nullable_0;
	}

	// Token: 0x06000E77 RID: 3703 RVA: 0x0001F1C4 File Offset: 0x0001D3C4
	[Token(Token = "0x6000E77")]
	[Address(RVA = "0x218D420", Offset = "0x218D420", VA = "0x218D420", Slot = "27")]
	public void vmethod_9(ReadOnlyArray<InputDevice>? nullable_0)
	{
		InputActionAsset inputActionAsset = this.inputActionAsset_0;
		inputActionAsset.devices = nullable_0;
	}

	// Token: 0x06000E78 RID: 3704 RVA: 0x00002549 File Offset: 0x00000749
	[Token(Token = "0x6000E78")]
	[Address(RVA = "0x218D470", Offset = "0x218D470", VA = "0x218D470", Slot = "28")]
	public void vmethod_10(InputBinding? nullable_0)
	{
		this.inputActionAsset_0.bindingMask = nullable_0;
	}

	// Token: 0x06000E79 RID: 3705 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000E79")]
	[Address(RVA = "0x218D4C8", Offset = "0x218D4C8", VA = "0x218D4C8")]
	public GClass0.GStruct0 method_5()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E7A RID: 3706 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218D4F4", Offset = "0x218D4F4", VA = "0x218D4F4")]
	[Token(Token = "0x6000E7A")]
	public GClass0.GStruct1 method_6()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E7B RID: 3707 RVA: 0x0001F1E0 File Offset: 0x0001D3E0
	[Address(RVA = "0x218D520", Offset = "0x218D520", VA = "0x218D520", Slot = "29")]
	[Token(Token = "0x6000E7B")]
	public void vmethod_11()
	{
		InputActionAsset obj = this.inputActionAsset_0;
		UnityEngine.Object.Destroy(obj);
	}

	// Token: 0x06000E7C RID: 3708 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218D588", Offset = "0x218D588", VA = "0x218D588")]
	[Token(Token = "0x6000E7C")]
	public GClass0.GStruct0 method_7()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E7D RID: 3709 RVA: 0x00002523 File Offset: 0x00000723
	[Token(Token = "0x6000E7D")]
	[Address(RVA = "0x218D5B4", Offset = "0x218D5B4", VA = "0x218D5B4")]
	public InputActionAsset method_8()
	{
		return this.inputActionAsset_0;
	}

	// Token: 0x06000E7E RID: 3710 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000E7E")]
	[Address(RVA = "0x218D5BC", Offset = "0x218D5BC", VA = "0x218D5BC")]
	public GClass0.GStruct2 method_9()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E7F RID: 3711 RVA: 0x0001F1FC File Offset: 0x0001D3FC
	[Token(Token = "0x6000E7F")]
	[Address(RVA = "0x218D5E8", Offset = "0x218D5E8", VA = "0x218D5E8", Slot = "30")]
	private IEnumerator vmethod_12()
	{
		this.inputActionAsset_0.GetEnumerator();
		throw new NullReferenceException();
	}

	// Token: 0x06000E80 RID: 3712 RVA: 0x0001F1C4 File Offset: 0x0001D3C4
	[Token(Token = "0x6000E80")]
	[Address(RVA = "0x218D620", Offset = "0x218D620", VA = "0x218D620", Slot = "31")]
	public void vmethod_13(ReadOnlyArray<InputDevice>? nullable_0)
	{
		InputActionAsset inputActionAsset = this.inputActionAsset_0;
		inputActionAsset.devices = nullable_0;
	}

	// Token: 0x06000E82 RID: 3714 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000E82")]
	[Address(RVA = "0x218D6C8", Offset = "0x218D6C8", VA = "0x218D6C8")]
	public GClass0.GStruct1 method_10()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x06000E83 RID: 3715 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x17000022")]
	public GClass0.GStruct1 GStruct1_0
	{
		[Token(Token = "0x6000E83")]
		[Address(RVA = "0x218D6F4", Offset = "0x218D6F4", VA = "0x218D6F4")]
		get
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}
	}

	// Token: 0x06000E84 RID: 3716 RVA: 0x00002572 File Offset: 0x00000772
	[Address(RVA = "0x218D720", Offset = "0x218D720", VA = "0x218D720", Slot = "32")]
	[Token(Token = "0x6000E84")]
	public IEnumerator<InputAction> vmethod_14()
	{
		return this.inputActionAsset_0.GetEnumerator();
	}

	// Token: 0x06000E85 RID: 3717 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218D73C", Offset = "0x218D73C", VA = "0x218D73C")]
	[Token(Token = "0x6000E85")]
	public GClass0.GStruct0 method_11()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E86 RID: 3718 RVA: 0x00002549 File Offset: 0x00000749
	[Token(Token = "0x6000E86")]
	[Address(RVA = "0x218D768", Offset = "0x218D768", VA = "0x218D768", Slot = "33")]
	public void vmethod_15(InputBinding? nullable_0)
	{
		this.inputActionAsset_0.bindingMask = nullable_0;
	}

	// Token: 0x06000E87 RID: 3719 RVA: 0x00002516 File Offset: 0x00000716
	[Token(Token = "0x6000E87")]
	[Address(RVA = "0x218D7C0", Offset = "0x218D7C0", VA = "0x218D7C0", Slot = "34")]
	public IEnumerable<InputBinding> vmethod_16()
	{
		return this.inputActionAsset_0.bindings;
	}

	// Token: 0x06000E88 RID: 3720 RVA: 0x0001F21C File Offset: 0x0001D41C
	[Token(Token = "0x6000E88")]
	[Address(RVA = "0x218D7DC", Offset = "0x218D7DC", VA = "0x218D7DC")]
	public InputControlScheme method_12()
	{
		int num = this.inputActionAsset_0.FindControlSchemeIndex("Queue");
		this.int_0 = num;
		ReadOnlyArray controlSchemes = this.inputActionAsset_0.controlSchemes;
		throw new NullReferenceException();
	}

	// Token: 0x06000E89 RID: 3721 RVA: 0x00002549 File Offset: 0x00000749
	[Address(RVA = "0x218D8AC", Offset = "0x218D8AC", VA = "0x218D8AC", Slot = "35")]
	[Token(Token = "0x6000E89")]
	public void vmethod_17(InputBinding? nullable_0)
	{
		this.inputActionAsset_0.bindingMask = nullable_0;
	}

	// Token: 0x06000E8A RID: 3722 RVA: 0x00002549 File Offset: 0x00000749
	[Address(RVA = "0x218D904", Offset = "0x218D904", VA = "0x218D904", Slot = "36")]
	[Token(Token = "0x6000E8A")]
	public void vmethod_18(InputBinding? nullable_0)
	{
		this.inputActionAsset_0.bindingMask = nullable_0;
	}

	// Token: 0x06000E8B RID: 3723 RVA: 0x0001F1E0 File Offset: 0x0001D3E0
	[Token(Token = "0x6000E8B")]
	[Address(RVA = "0x218D95C", Offset = "0x218D95C", VA = "0x218D95C", Slot = "17")]
	public void Dispose()
	{
		InputActionAsset obj = this.inputActionAsset_0;
		UnityEngine.Object.Destroy(obj);
	}

	// Token: 0x06000E8C RID: 3724 RVA: 0x00002557 File Offset: 0x00000757
	[Address(RVA = "0x218D9C4", Offset = "0x218D9C4", VA = "0x218D9C4", Slot = "37")]
	[Token(Token = "0x6000E8C")]
	public void vmethod_19()
	{
		this.inputActionAsset_0.Disable();
	}

	// Token: 0x06000E8D RID: 3725 RVA: 0x0000253A File Offset: 0x0000073A
	[Address(RVA = "0x218D9E0", Offset = "0x218D9E0", VA = "0x218D9E0", Slot = "38")]
	[Token(Token = "0x6000E8D")]
	public int vmethod_20(InputBinding inputBinding_0, out InputAction inputAction_45)
	{
		return this.inputActionAsset_0.FindBinding(inputBinding_0, out inputAction_45);
	}

	// Token: 0x06000E8E RID: 3726 RVA: 0x0000252B File Offset: 0x0000072B
	[Token(Token = "0x6000E8E")]
	[Address(RVA = "0x218DA40", Offset = "0x218DA40", VA = "0x218DA40", Slot = "5")]
	public InputAction FindAction(string actionNameOrId, bool throwIfNotFound = false)
	{
		return this.inputActionAsset_0.FindAction(actionNameOrId, throwIfNotFound);
	}

	// Token: 0x06000E8F RID: 3727 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000E8F")]
	[Address(RVA = "0x218DA60", Offset = "0x218DA60", VA = "0x218DA60")]
	public GClass0.GStruct3 method_13()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E90 RID: 3728 RVA: 0x0000252B File Offset: 0x0000072B
	[Address(RVA = "0x218DA8C", Offset = "0x218DA8C", VA = "0x218DA8C", Slot = "39")]
	[Token(Token = "0x6000E90")]
	public InputAction vmethod_21(string string_0, bool bool_0 = false)
	{
		return this.inputActionAsset_0.FindAction(string_0, bool_0);
	}

	// Token: 0x06000E91 RID: 3729 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218DAAC", Offset = "0x218DAAC", VA = "0x218DAAC")]
	[Token(Token = "0x6000E91")]
	public GClass0.GStruct2 method_14()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E92 RID: 3730 RVA: 0x0000253A File Offset: 0x0000073A
	[Address(RVA = "0x218DAD8", Offset = "0x218DAD8", VA = "0x218DAD8", Slot = "40")]
	[Token(Token = "0x6000E92")]
	public int vmethod_22(InputBinding inputBinding_0, out InputAction inputAction_45)
	{
		return this.inputActionAsset_0.FindBinding(inputBinding_0, out inputAction_45);
	}

	// Token: 0x06000E93 RID: 3731 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218DB38", Offset = "0x218DB38", VA = "0x218DB38")]
	[Token(Token = "0x6000E93")]
	public GClass0.GStruct3 method_15()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E94 RID: 3732 RVA: 0x0001F1FC File Offset: 0x0001D3FC
	[Address(RVA = "0x218DB64", Offset = "0x218DB64", VA = "0x218DB64", Slot = "16")]
	[Token(Token = "0x6000E94")]
	IEnumerator IEnumerable.GetEnumerator()
	{
		this.inputActionAsset_0.GetEnumerator();
		throw new NullReferenceException();
	}

	// Token: 0x06000E95 RID: 3733 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x218DB80", Offset = "0x218DB80", VA = "0x218DB80")]
	[Token(Token = "0x6000E95")]
	public GClass0.GStruct2 method_16()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E96 RID: 3734 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000E96")]
	[Address(RVA = "0x218DBAC", Offset = "0x218DBAC", VA = "0x218DBAC")]
	public GClass0.GStruct1 method_17()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000E97 RID: 3735 RVA: 0x00002549 File Offset: 0x00000749
	[Address(RVA = "0x218DBD8", Offset = "0x218DBD8", VA = "0x218DBD8", Slot = "41")]
	[Token(Token = "0x6000E97")]
	public void vmethod_23(InputBinding? nullable_0)
	{
		this.inputActionAsset_0.bindingMask = nullable_0;
	}

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000E98 RID: 3736 RVA: 0x0001F254 File Offset: 0x0001D454
	[Token(Token = "0x17000025")]
	public InputControlScheme InputControlScheme_0
	{
		[Address(RVA = "0x218DC30", Offset = "0x218DC30", VA = "0x218DC30")]
		[Token(Token = "0x6000E98")]
		get
		{
			int num = this.inputActionAsset_0.FindControlSchemeIndex("XR Usage");
			this.int_0 = num;
			ReadOnlyArray controlSchemes = this.inputActionAsset_0.controlSchemes;
			throw new NullReferenceException();
		}
	}

	// Token: 0x06000E99 RID: 3737 RVA: 0x00002572 File Offset: 0x00000772
	[Token(Token = "0x6000E99")]
	[Address(RVA = "0x218D604", Offset = "0x218D604", VA = "0x218D604", Slot = "15")]
	public IEnumerator<InputAction> GetEnumerator()
	{
		return this.inputActionAsset_0.GetEnumerator();
	}

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x06000E9A RID: 3738 RVA: 0x0000257F File Offset: 0x0000077F
	[Token(Token = "0x1700001F")]
	public ReadOnlyArray<InputControlScheme> controlSchemes
	{
		[Address(RVA = "0x218DD00", Offset = "0x218DD00", VA = "0x218DD00", Slot = "11")]
		[Token(Token = "0x6000E9A")]
		get
		{
			return this.inputActionAsset_0.controlSchemes;
		}
	}

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x06000E9B RID: 3739 RVA: 0x00002509 File Offset: 0x00000709
	// (set) Token: 0x06000E9C RID: 3740 RVA: 0x0001F1C4 File Offset: 0x0001D3C4
	[Token(Token = "0x1700001E")]
	public ReadOnlyArray<InputDevice>? devices
	{
		[Token(Token = "0x6000E9B")]
		[Address(RVA = "0x218DD1C", Offset = "0x218DD1C", VA = "0x218DD1C", Slot = "9")]
		get
		{
			return this.inputActionAsset_0.devices;
		}
		[Token(Token = "0x6000E9C")]
		[Address(RVA = "0x218DD68", Offset = "0x218DD68", VA = "0x218DD68", Slot = "10")]
		set
		{
			InputActionAsset inputActionAsset = this.inputActionAsset_0;
			inputActionAsset.devices = value;
		}
	}

	// Token: 0x06000E9D RID: 3741 RVA: 0x0000253A File Offset: 0x0000073A
	[Address(RVA = "0x218DDB8", Offset = "0x218DDB8", VA = "0x218DDB8", Slot = "6")]
	[Token(Token = "0x6000E9D")]
	public int FindBinding(InputBinding mask, out InputAction action)
	{
		return this.inputActionAsset_0.FindBinding(mask, out action);
	}

	// Token: 0x04000225 RID: 549
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000225")]
	[CompilerGenerated]
	private readonly InputActionAsset inputActionAsset_0;

	// Token: 0x04000226 RID: 550
	[Token(Token = "0x4000226")]
	[FieldOffset(Offset = "0x18")]
	private readonly InputActionMap inputActionMap_0;

	// Token: 0x04000227 RID: 551
	[Token(Token = "0x4000227")]
	[FieldOffset(Offset = "0x20")]
	private GClass0.GInterface0 ginterface0_0;

	// Token: 0x04000228 RID: 552
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000228")]
	private readonly InputAction inputAction_0;

	// Token: 0x04000229 RID: 553
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000229")]
	private readonly InputAction inputAction_1;

	// Token: 0x0400022A RID: 554
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400022A")]
	private readonly InputAction inputAction_2;

	// Token: 0x0400022B RID: 555
	[Token(Token = "0x400022B")]
	[FieldOffset(Offset = "0x40")]
	private readonly InputAction inputAction_3;

	// Token: 0x0400022C RID: 556
	[Token(Token = "0x400022C")]
	[FieldOffset(Offset = "0x48")]
	private readonly InputAction inputAction_4;

	// Token: 0x0400022D RID: 557
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400022D")]
	private readonly InputAction inputAction_5;

	// Token: 0x0400022E RID: 558
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400022E")]
	private readonly InputAction inputAction_6;

	// Token: 0x0400022F RID: 559
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400022F")]
	private readonly InputAction inputAction_7;

	// Token: 0x04000230 RID: 560
	[Token(Token = "0x4000230")]
	[FieldOffset(Offset = "0x68")]
	private readonly InputAction inputAction_8;

	// Token: 0x04000231 RID: 561
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4000231")]
	private readonly InputAction inputAction_9;

	// Token: 0x04000232 RID: 562
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000232")]
	private readonly InputAction inputAction_10;

	// Token: 0x04000233 RID: 563
	[Token(Token = "0x4000233")]
	[FieldOffset(Offset = "0x80")]
	private readonly InputAction inputAction_11;

	// Token: 0x04000234 RID: 564
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x4000234")]
	private readonly InputAction inputAction_12;

	// Token: 0x04000235 RID: 565
	[Token(Token = "0x4000235")]
	[FieldOffset(Offset = "0x90")]
	private readonly InputAction inputAction_13;

	// Token: 0x04000236 RID: 566
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x4000236")]
	private readonly InputAction inputAction_14;

	// Token: 0x04000237 RID: 567
	[Token(Token = "0x4000237")]
	[FieldOffset(Offset = "0xA0")]
	private readonly InputAction inputAction_15;

	// Token: 0x04000238 RID: 568
	[Token(Token = "0x4000238")]
	[FieldOffset(Offset = "0xA8")]
	private readonly InputAction inputAction_16;

	// Token: 0x04000239 RID: 569
	[FieldOffset(Offset = "0xB0")]
	[Token(Token = "0x4000239")]
	private readonly InputAction inputAction_17;

	// Token: 0x0400023A RID: 570
	[Token(Token = "0x400023A")]
	[FieldOffset(Offset = "0xB8")]
	private readonly InputAction inputAction_18;

	// Token: 0x0400023B RID: 571
	[FieldOffset(Offset = "0xC0")]
	[Token(Token = "0x400023B")]
	private readonly InputAction inputAction_19;

	// Token: 0x0400023C RID: 572
	[FieldOffset(Offset = "0xC8")]
	[Token(Token = "0x400023C")]
	private readonly InputActionMap inputActionMap_1;

	// Token: 0x0400023D RID: 573
	[FieldOffset(Offset = "0xD0")]
	[Token(Token = "0x400023D")]
	private GClass0.GInterface1 ginterface1_0;

	// Token: 0x0400023E RID: 574
	[Token(Token = "0x400023E")]
	[FieldOffset(Offset = "0xD8")]
	private readonly InputAction inputAction_20;

	// Token: 0x0400023F RID: 575
	[Token(Token = "0x400023F")]
	[FieldOffset(Offset = "0xE0")]
	private readonly InputAction inputAction_21;

	// Token: 0x04000240 RID: 576
	[FieldOffset(Offset = "0xE8")]
	[Token(Token = "0x4000240")]
	private readonly InputAction inputAction_22;

	// Token: 0x04000241 RID: 577
	[FieldOffset(Offset = "0xF0")]
	[Token(Token = "0x4000241")]
	private readonly InputAction inputAction_23;

	// Token: 0x04000242 RID: 578
	[Token(Token = "0x4000242")]
	[FieldOffset(Offset = "0xF8")]
	private readonly InputAction inputAction_24;

	// Token: 0x04000243 RID: 579
	[FieldOffset(Offset = "0x100")]
	[Token(Token = "0x4000243")]
	private readonly InputAction inputAction_25;

	// Token: 0x04000244 RID: 580
	[FieldOffset(Offset = "0x108")]
	[Token(Token = "0x4000244")]
	private readonly InputAction inputAction_26;

	// Token: 0x04000245 RID: 581
	[Token(Token = "0x4000245")]
	[FieldOffset(Offset = "0x110")]
	private readonly InputAction inputAction_27;

	// Token: 0x04000246 RID: 582
	[Token(Token = "0x4000246")]
	[FieldOffset(Offset = "0x118")]
	private readonly InputAction inputAction_28;

	// Token: 0x04000247 RID: 583
	[FieldOffset(Offset = "0x120")]
	[Token(Token = "0x4000247")]
	private readonly InputAction inputAction_29;

	// Token: 0x04000248 RID: 584
	[FieldOffset(Offset = "0x128")]
	[Token(Token = "0x4000248")]
	private readonly InputAction inputAction_30;

	// Token: 0x04000249 RID: 585
	[FieldOffset(Offset = "0x130")]
	[Token(Token = "0x4000249")]
	private readonly InputAction inputAction_31;

	// Token: 0x0400024A RID: 586
	[Token(Token = "0x400024A")]
	[FieldOffset(Offset = "0x138")]
	private readonly InputAction inputAction_32;

	// Token: 0x0400024B RID: 587
	[Token(Token = "0x400024B")]
	[FieldOffset(Offset = "0x140")]
	private readonly InputAction inputAction_33;

	// Token: 0x0400024C RID: 588
	[Token(Token = "0x400024C")]
	[FieldOffset(Offset = "0x148")]
	private readonly InputAction inputAction_34;

	// Token: 0x0400024D RID: 589
	[Token(Token = "0x400024D")]
	[FieldOffset(Offset = "0x150")]
	private readonly InputAction inputAction_35;

	// Token: 0x0400024E RID: 590
	[FieldOffset(Offset = "0x158")]
	[Token(Token = "0x400024E")]
	private readonly InputAction inputAction_36;

	// Token: 0x0400024F RID: 591
	[FieldOffset(Offset = "0x160")]
	[Token(Token = "0x400024F")]
	private readonly InputAction inputAction_37;

	// Token: 0x04000250 RID: 592
	[FieldOffset(Offset = "0x168")]
	[Token(Token = "0x4000250")]
	private readonly InputAction inputAction_38;

	// Token: 0x04000251 RID: 593
	[Token(Token = "0x4000251")]
	[FieldOffset(Offset = "0x170")]
	private readonly InputAction inputAction_39;

	// Token: 0x04000252 RID: 594
	[Token(Token = "0x4000252")]
	[FieldOffset(Offset = "0x178")]
	private readonly InputActionMap inputActionMap_2;

	// Token: 0x04000253 RID: 595
	[Token(Token = "0x4000253")]
	[FieldOffset(Offset = "0x180")]
	private GClass0.GInterface2 ginterface2_0;

	// Token: 0x04000254 RID: 596
	[Token(Token = "0x4000254")]
	[FieldOffset(Offset = "0x188")]
	private readonly InputAction inputAction_40;

	// Token: 0x04000255 RID: 597
	[Token(Token = "0x4000255")]
	[FieldOffset(Offset = "0x190")]
	private readonly InputAction inputAction_41;

	// Token: 0x04000256 RID: 598
	[FieldOffset(Offset = "0x198")]
	[Token(Token = "0x4000256")]
	private readonly InputActionMap inputActionMap_3;

	// Token: 0x04000257 RID: 599
	[FieldOffset(Offset = "0x1A0")]
	[Token(Token = "0x4000257")]
	private GClass0.GInterface3 ginterface3_0;

	// Token: 0x04000258 RID: 600
	[Token(Token = "0x4000258")]
	[FieldOffset(Offset = "0x1A8")]
	private readonly InputAction inputAction_42;

	// Token: 0x04000259 RID: 601
	[Token(Token = "0x4000259")]
	[FieldOffset(Offset = "0x1B0")]
	private readonly InputAction inputAction_43;

	// Token: 0x0400025A RID: 602
	[FieldOffset(Offset = "0x1B8")]
	[Token(Token = "0x400025A")]
	private readonly InputAction inputAction_44;

	// Token: 0x0400025B RID: 603
	[FieldOffset(Offset = "0x1C0")]
	[Token(Token = "0x400025B")]
	private int int_0;

	// Token: 0x0200006A RID: 106
	[Token(Token = "0x200006A")]
	public struct GStruct0
	{
		// Token: 0x06000E9E RID: 3742 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077764", Offset = "0x1077764", VA = "0x1077764")]
		[Token(Token = "0x6000E9E")]
		public static InputActionMap smethod_0(GClass0.GStruct0 gstruct0_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000E9F RID: 3743 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077798", Offset = "0x1077798", VA = "0x1077798")]
		[Token(Token = "0x6000E9F")]
		public InputAction method_0()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EA0 RID: 3744 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EA0")]
		[Address(RVA = "0x10777B4", Offset = "0x10777B4", VA = "0x10777B4")]
		public InputAction method_1()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EA1 RID: 3745 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EA1")]
		[Address(RVA = "0x10777D0", Offset = "0x10777D0", VA = "0x10777D0")]
		public InputAction method_2()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EA2 RID: 3746 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x10777EC", Offset = "0x10777EC", VA = "0x10777EC")]
		[Token(Token = "0x6000EA2")]
		public InputAction method_3()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EA3 RID: 3747 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EA3")]
		[Address(RVA = "0x1077808", Offset = "0x1077808", VA = "0x1077808")]
		public InputActionMap method_4()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EA4 RID: 3748 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077824", Offset = "0x1077824", VA = "0x1077824")]
		[Token(Token = "0x6000EA4")]
		public InputAction method_5()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EA5 RID: 3749 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EA5")]
		[Address(RVA = "0x1077840", Offset = "0x1077840", VA = "0x1077840")]
		public InputAction method_6()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EA6 RID: 3750 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107785C", Offset = "0x107785C", VA = "0x107785C")]
		[Token(Token = "0x6000EA6")]
		public InputAction method_7()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EA7 RID: 3751 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077878", Offset = "0x1077878", VA = "0x1077878")]
		[Token(Token = "0x6000EA7")]
		public InputAction method_8()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000EA8 RID: 3752 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000033")]
		public InputAction InputAction_13
		{
			[Token(Token = "0x6000EA8")]
			[Address(RVA = "0x1077894", Offset = "0x1077894", VA = "0x1077894")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000EA9 RID: 3753 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000032")]
		public InputAction InputAction_12
		{
			[Address(RVA = "0x10778B0", Offset = "0x10778B0", VA = "0x10778B0")]
			[Token(Token = "0x6000EA9")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000EAA RID: 3754 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x6000EAA")]
		[Address(RVA = "0x10778CC", Offset = "0x10778CC", VA = "0x10778CC")]
		public bool method_9()
		{
			return false;
		}

		// Token: 0x06000EAB RID: 3755 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EAB")]
		[Address(RVA = "0x1077910", Offset = "0x1077910", VA = "0x1077910")]
		public InputAction method_10()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EAC RID: 3756 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107792C", Offset = "0x107792C", VA = "0x107792C")]
		[Token(Token = "0x6000EAC")]
		public InputAction method_11()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EAD RID: 3757 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EAD")]
		[Address(RVA = "0x1077948", Offset = "0x1077948", VA = "0x1077948")]
		public InputAction method_12()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EAE RID: 3758 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EAE")]
		[Address(RVA = "0x1077964", Offset = "0x1077964", VA = "0x1077964")]
		public static InputActionMap smethod_1(GClass0.GStruct0 gstruct0_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EAF RID: 3759 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x1077998", Offset = "0x1077998", VA = "0x1077998")]
		[Token(Token = "0x6000EAF")]
		public void method_13()
		{
		}

		// Token: 0x06000EB0 RID: 3760 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EB0")]
		[Address(RVA = "0x10779C0", Offset = "0x10779C0", VA = "0x10779C0")]
		public static InputActionMap smethod_2(GClass0.GStruct0 gstruct0_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EB1 RID: 3761 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EB1")]
		[Address(RVA = "0x10779D8", Offset = "0x10779D8", VA = "0x10779D8")]
		public static InputActionMap smethod_3(GClass0.GStruct0 gstruct0_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EB2 RID: 3762 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x10779F0", Offset = "0x10779F0", VA = "0x10779F0")]
		[Token(Token = "0x6000EB2")]
		public static InputActionMap smethod_4(GClass0.GStruct0 gstruct0_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EB3 RID: 3763 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077A08", Offset = "0x1077A08", VA = "0x1077A08")]
		[Token(Token = "0x6000EB3")]
		public InputAction method_14()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EB4 RID: 3764 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077A24", Offset = "0x1077A24", VA = "0x1077A24")]
		[Token(Token = "0x6000EB4")]
		public InputAction method_15()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EB5 RID: 3765 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077A40", Offset = "0x1077A40", VA = "0x1077A40")]
		[Token(Token = "0x6000EB5")]
		public InputAction method_16()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EB6 RID: 3766 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077A5C", Offset = "0x1077A5C", VA = "0x1077A5C")]
		[Token(Token = "0x6000EB6")]
		public InputAction method_17()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EB7 RID: 3767 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EB7")]
		[Address(RVA = "0x1077A78", Offset = "0x1077A78", VA = "0x1077A78")]
		public InputAction method_18()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EB8 RID: 3768 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EB8")]
		[Address(RVA = "0x1077A94", Offset = "0x1077A94", VA = "0x1077A94")]
		public InputAction method_19()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EB9 RID: 3769 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077AB0", Offset = "0x1077AB0", VA = "0x1077AB0")]
		[Token(Token = "0x6000EB9")]
		public InputAction method_20()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EBA RID: 3770 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077ACC", Offset = "0x1077ACC", VA = "0x1077ACC")]
		[Token(Token = "0x6000EBA")]
		public InputAction method_21()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EBB RID: 3771 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077AE8", Offset = "0x1077AE8", VA = "0x1077AE8")]
		[Token(Token = "0x6000EBB")]
		public InputAction method_22()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EBC RID: 3772 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EBC")]
		[Address(RVA = "0x1077B04", Offset = "0x1077B04", VA = "0x1077B04")]
		public InputAction method_23()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EBD RID: 3773 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EBD")]
		[Address(RVA = "0x1077B20", Offset = "0x1077B20", VA = "0x1077B20")]
		public InputAction method_24()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EBE RID: 3774 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EBE")]
		[Address(RVA = "0x1077B3C", Offset = "0x1077B3C", VA = "0x1077B3C")]
		public InputAction method_25()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EBF RID: 3775 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EBF")]
		[Address(RVA = "0x1077B58", Offset = "0x1077B58", VA = "0x1077B58")]
		public InputAction method_26()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EC0 RID: 3776 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077B74", Offset = "0x1077B74", VA = "0x1077B74")]
		[Token(Token = "0x6000EC0")]
		public InputAction method_27()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EC1 RID: 3777 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000EC1")]
		[Address(RVA = "0x1077B90", Offset = "0x1077B90", VA = "0x1077B90")]
		public void method_28()
		{
		}

		// Token: 0x06000EC2 RID: 3778 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EC2")]
		[Address(RVA = "0x1077BB8", Offset = "0x1077BB8", VA = "0x1077BB8")]
		public InputAction method_29()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EC3 RID: 3779 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EC3")]
		[Address(RVA = "0x1077BD4", Offset = "0x1077BD4", VA = "0x1077BD4")]
		public InputAction method_30()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EC4 RID: 3780 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077BF0", Offset = "0x1077BF0", VA = "0x1077BF0")]
		[Token(Token = "0x6000EC4")]
		public InputAction method_31()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EC5 RID: 3781 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1077C0C", Offset = "0x1077C0C", VA = "0x1077C0C")]
		[Token(Token = "0x6000EC5")]
		public InputAction method_32()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EC6 RID: 3782 RVA: 0x0001F29C File Offset: 0x0001D49C
		[Token(Token = "0x6000EC6")]
		[Address(RVA = "0x1077C28", Offset = "0x1077C28", VA = "0x1077C28")]
		public void method_33(GClass0.GInterface0 ginterface0_0)
		{
		}

		// Token: 0x06000EC7 RID: 3783 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EC7")]
		[Address(RVA = "0x107CBE8", Offset = "0x107CBE8", VA = "0x107CBE8")]
		public InputAction method_34()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EC8 RID: 3784 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EC8")]
		[Address(RVA = "0x107C99C", Offset = "0x107C99C", VA = "0x107C99C")]
		public InputAction method_35()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000EC9 RID: 3785 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000028")]
		public InputAction InputAction_2
		{
			[Token(Token = "0x6000EC9")]
			[Address(RVA = "0x107CC04", Offset = "0x107CC04", VA = "0x107CC04")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000ECA RID: 3786 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x6000ECA")]
		[Address(RVA = "0x107CC20", Offset = "0x107CC20", VA = "0x107CC20")]
		public bool method_36()
		{
			return false;
		}

		// Token: 0x06000ECB RID: 3787 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x107CC48", Offset = "0x107CC48", VA = "0x107CC48")]
		[Token(Token = "0x6000ECB")]
		public void method_37()
		{
		}

		// Token: 0x06000ECC RID: 3788 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000ECC")]
		[Address(RVA = "0x107C9F0", Offset = "0x107C9F0", VA = "0x107C9F0")]
		public InputAction method_38()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000ECD RID: 3789 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000ECD")]
		[Address(RVA = "0x107C868", Offset = "0x107C868", VA = "0x107C868")]
		public InputAction method_39()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000ECE RID: 3790 RVA: 0x0001F2AC File Offset: 0x0001D4AC
		[Address(RVA = "0x107CC70", Offset = "0x107CC70", VA = "0x107CC70")]
		[Token(Token = "0x6000ECE")]
		public void method_40(GClass0.GInterface0 ginterface0_0)
		{
		}

		// Token: 0x06000ECF RID: 3791 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C92C", Offset = "0x107C92C", VA = "0x107C92C")]
		[Token(Token = "0x6000ECF")]
		public InputAction method_41()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000ED0 RID: 3792 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000ED0")]
		[Address(RVA = "0x107C980", Offset = "0x107C980", VA = "0x107C980")]
		public InputAction method_42()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000ED1 RID: 3793 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x1081808", Offset = "0x1081808", VA = "0x1081808")]
		[Token(Token = "0x6000ED1")]
		public void method_43()
		{
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x06000ED2 RID: 3794 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000035")]
		public InputAction InputAction_15
		{
			[Token(Token = "0x6000ED2")]
			[Address(RVA = "0x107C8D8", Offset = "0x107C8D8", VA = "0x107C8D8")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000ED3 RID: 3795 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000ED3")]
		[Address(RVA = "0x107CA28", Offset = "0x107CA28", VA = "0x107CA28")]
		public InputAction method_44()
		{
			throw new NullReferenceException();
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x06000ED4 RID: 3796 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700002E")]
		public InputAction InputAction_8
		{
			[Address(RVA = "0x108169C", Offset = "0x108169C", VA = "0x108169C")]
			[Token(Token = "0x6000ED4")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000ED5 RID: 3797 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000037")]
		public InputAction InputAction_17
		{
			[Address(RVA = "0x107C948", Offset = "0x107C948", VA = "0x107C948")]
			[Token(Token = "0x6000ED5")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000ED6 RID: 3798 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1081830", Offset = "0x1081830", VA = "0x1081830")]
		[Token(Token = "0x6000ED6")]
		public InputAction method_45()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000ED7 RID: 3799 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x108184C", Offset = "0x108184C", VA = "0x108184C")]
		[Token(Token = "0x6000ED7")]
		public InputAction method_46()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000ED8 RID: 3800 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000ED8")]
		[Address(RVA = "0x1081760", Offset = "0x1081760", VA = "0x1081760")]
		public InputAction method_47()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000ED9 RID: 3801 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C830", Offset = "0x107C830", VA = "0x107C830")]
		[Token(Token = "0x6000ED9")]
		public InputAction method_48()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EDA RID: 3802 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107CA98", Offset = "0x107CA98", VA = "0x107CA98")]
		[Token(Token = "0x6000EDA")]
		public InputAction method_49()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EDB RID: 3803 RVA: 0x00002593 File Offset: 0x00000793
		[Address(RVA = "0x1081868", Offset = "0x1081868", VA = "0x1081868")]
		[Token(Token = "0x6000EDB")]
		public GStruct0(GClass0 gclass0_1)
		{
			this.gclass0_0 = gclass0_1;
		}

		// Token: 0x06000EDC RID: 3804 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000EDC")]
		[Address(RVA = "0x1081870", Offset = "0x1081870", VA = "0x1081870")]
		public void method_50()
		{
		}

		// Token: 0x06000EDD RID: 3805 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x10818B4", Offset = "0x10818B4", VA = "0x10818B4")]
		[Token(Token = "0x6000EDD")]
		public InputAction method_51()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EDE RID: 3806 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107CAB4", Offset = "0x107CAB4", VA = "0x107CAB4")]
		[Token(Token = "0x6000EDE")]
		public InputAction method_52()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EDF RID: 3807 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EDF")]
		[Address(RVA = "0x107C6A8", Offset = "0x107C6A8", VA = "0x107C6A8")]
		public InputAction method_53()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EE0 RID: 3808 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EE0")]
		[Address(RVA = "0x107C750", Offset = "0x107C750", VA = "0x107C750")]
		public InputAction method_54()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EE1 RID: 3809 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x10817EC", Offset = "0x10817EC", VA = "0x10817EC")]
		[Token(Token = "0x6000EE1")]
		public InputAction method_55()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EE2 RID: 3810 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x10818D0", Offset = "0x10818D0", VA = "0x10818D0")]
		[Token(Token = "0x6000EE2")]
		public void method_56()
		{
		}

		// Token: 0x06000EE3 RID: 3811 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C964", Offset = "0x107C964", VA = "0x107C964")]
		[Token(Token = "0x6000EE3")]
		public InputAction method_57()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EE4 RID: 3812 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C84C", Offset = "0x107C84C", VA = "0x107C84C")]
		[Token(Token = "0x6000EE4")]
		public InputAction method_58()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EE5 RID: 3813 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107CBCC", Offset = "0x107CBCC", VA = "0x107CBCC")]
		[Token(Token = "0x6000EE5")]
		public InputAction method_59()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EE6 RID: 3814 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Address(RVA = "0x10818F8", Offset = "0x10818F8", VA = "0x10818F8")]
		[Token(Token = "0x6000EE6")]
		public bool method_60()
		{
			return false;
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x06000EE7 RID: 3815 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000034")]
		public InputAction InputAction_14
		{
			[Address(RVA = "0x1081920", Offset = "0x1081920", VA = "0x1081920")]
			[Token(Token = "0x6000EE7")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x06000EE8 RID: 3816 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700002A")]
		public InputAction InputAction_4
		{
			[Token(Token = "0x6000EE8")]
			[Address(RVA = "0x1081680", Offset = "0x1081680", VA = "0x1081680")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000EE9 RID: 3817 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C654", Offset = "0x107C654", VA = "0x107C654")]
		[Token(Token = "0x6000EE9")]
		public InputAction method_61()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EEA RID: 3818 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EEA")]
		[Address(RVA = "0x1081664", Offset = "0x1081664", VA = "0x1081664")]
		public InputAction method_62()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EEB RID: 3819 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EEB")]
		[Address(RVA = "0x107C6FC", Offset = "0x107C6FC", VA = "0x107C6FC")]
		public InputAction method_63()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EEC RID: 3820 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C670", Offset = "0x107C670", VA = "0x107C670")]
		[Token(Token = "0x6000EEC")]
		public InputAction method_64()
		{
			throw new NullReferenceException();
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000EED RID: 3821 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x1700003A")]
		public bool Boolean_0
		{
			[Address(RVA = "0x108193C", Offset = "0x108193C", VA = "0x108193C")]
			[Token(Token = "0x6000EED")]
			get
			{
				return false;
			}
		}

		// Token: 0x06000EEE RID: 3822 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EEE")]
		[Address(RVA = "0x1081648", Offset = "0x1081648", VA = "0x1081648")]
		public InputAction method_65()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EEF RID: 3823 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EEF")]
		[Address(RVA = "0x107CA60", Offset = "0x107CA60", VA = "0x107CA60")]
		public InputAction method_66()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EF0 RID: 3824 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000EF0")]
		[Address(RVA = "0x1081964", Offset = "0x1081964", VA = "0x1081964")]
		public void method_67()
		{
		}

		// Token: 0x06000EF1 RID: 3825 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EF1")]
		[Address(RVA = "0x108198C", Offset = "0x108198C", VA = "0x108198C")]
		public InputAction method_68()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EF2 RID: 3826 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107CB08", Offset = "0x107CB08", VA = "0x107CB08")]
		[Token(Token = "0x6000EF2")]
		public InputAction method_69()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EF3 RID: 3827 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x108177C", Offset = "0x108177C", VA = "0x108177C")]
		[Token(Token = "0x6000EF3")]
		public InputAction method_70()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EF4 RID: 3828 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x10817B4", Offset = "0x10817B4", VA = "0x10817B4")]
		[Token(Token = "0x6000EF4")]
		public InputAction method_71()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EF5 RID: 3829 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107CA0C", Offset = "0x107CA0C", VA = "0x107CA0C")]
		[Token(Token = "0x6000EF5")]
		public InputAction method_72()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EF6 RID: 3830 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EF6")]
		[Address(RVA = "0x10817D0", Offset = "0x10817D0", VA = "0x10817D0")]
		public InputAction method_73()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000EF7 RID: 3831 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000038")]
		public InputAction InputAction_18
		{
			[Token(Token = "0x6000EF7")]
			[Address(RVA = "0x10819A8", Offset = "0x10819A8", VA = "0x10819A8")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000EF8 RID: 3832 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C7DC", Offset = "0x107C7DC", VA = "0x107C7DC")]
		[Token(Token = "0x6000EF8")]
		public InputAction method_74()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000EF9 RID: 3833 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000031")]
		public InputAction InputAction_11
		{
			[Address(RVA = "0x108170C", Offset = "0x108170C", VA = "0x108170C")]
			[Token(Token = "0x6000EF9")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000EFA RID: 3834 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700002C")]
		public InputAction InputAction_6
		{
			[Token(Token = "0x6000EFA")]
			[Address(RVA = "0x107C734", Offset = "0x107C734", VA = "0x107C734")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000EFB RID: 3835 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EFB")]
		[Address(RVA = "0x107C6E0", Offset = "0x107C6E0", VA = "0x107C6E0")]
		public InputAction method_75()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EFC RID: 3836 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000EFC")]
		[Address(RVA = "0x1081728", Offset = "0x1081728", VA = "0x1081728")]
		public InputAction method_76()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EFD RID: 3837 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C8A0", Offset = "0x107C8A0", VA = "0x107C8A0")]
		[Token(Token = "0x6000EFD")]
		public InputAction method_77()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000EFE RID: 3838 RVA: 0x0001F2BC File Offset: 0x0001D4BC
		[Token(Token = "0x6000EFE")]
		[Address(RVA = "0x10819C4", Offset = "0x10819C4", VA = "0x10819C4")]
		public void method_78(GClass0.GInterface0 ginterface0_0)
		{
		}

		// Token: 0x06000EFF RID: 3839 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C7F8", Offset = "0x107C7F8", VA = "0x107C7F8")]
		[Token(Token = "0x6000EFF")]
		public InputAction method_79()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F00 RID: 3840 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F00")]
		[Address(RVA = "0x107CAD0", Offset = "0x107CAD0", VA = "0x107CAD0")]
		public InputAction method_80()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F01 RID: 3841 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F01")]
		[Address(RVA = "0x10816D4", Offset = "0x10816D4", VA = "0x10816D4")]
		public InputAction method_81()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F02 RID: 3842 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x10778F4", Offset = "0x10778F4", VA = "0x10778F4")]
		[Token(Token = "0x6000F02")]
		public InputActionMap method_82()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F03 RID: 3843 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C910", Offset = "0x107C910", VA = "0x107C910")]
		[Token(Token = "0x6000F03")]
		public InputAction method_83()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x06000F04 RID: 3844 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000029")]
		public InputAction InputAction_3
		{
			[Token(Token = "0x6000F04")]
			[Address(RVA = "0x1081744", Offset = "0x1081744", VA = "0x1081744")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F05 RID: 3845 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C788", Offset = "0x107C788", VA = "0x107C788")]
		[Token(Token = "0x6000F05")]
		public InputAction method_84()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000F06 RID: 3846 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000026")]
		public InputAction InputAction_0
		{
			[Token(Token = "0x6000F06")]
			[Address(RVA = "0x107C61C", Offset = "0x107C61C", VA = "0x107C61C")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F07 RID: 3847 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x10863B8", Offset = "0x10863B8", VA = "0x10863B8")]
		[Token(Token = "0x6000F07")]
		public InputAction method_85()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F08 RID: 3848 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x6000F08")]
		[Address(RVA = "0x10863D4", Offset = "0x10863D4", VA = "0x10863D4")]
		public bool method_86()
		{
			return false;
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000F09 RID: 3849 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000027")]
		public InputAction InputAction_1
		{
			[Token(Token = "0x6000F09")]
			[Address(RVA = "0x107C638", Offset = "0x107C638", VA = "0x107C638")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F0A RID: 3850 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x10863FC", Offset = "0x10863FC", VA = "0x10863FC")]
		[Token(Token = "0x6000F0A")]
		public void method_87()
		{
		}

		// Token: 0x06000F0B RID: 3851 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x1086424", Offset = "0x1086424", VA = "0x1086424")]
		[Token(Token = "0x6000F0B")]
		public void method_88()
		{
		}

		// Token: 0x06000F0C RID: 3852 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107CA7C", Offset = "0x107CA7C", VA = "0x107CA7C")]
		[Token(Token = "0x6000F0C")]
		public InputAction method_89()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000F0D RID: 3853 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000030")]
		public InputAction InputAction_10
		{
			[Address(RVA = "0x10816F0", Offset = "0x10816F0", VA = "0x10816F0")]
			[Token(Token = "0x6000F0D")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F0E RID: 3854 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F0E")]
		[Address(RVA = "0x107797C", Offset = "0x107797C", VA = "0x107797C")]
		public InputActionMap method_90()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F0F RID: 3855 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x10816B8", Offset = "0x10816B8", VA = "0x10816B8")]
		[Token(Token = "0x6000F0F")]
		public InputAction method_91()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F10 RID: 3856 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F10")]
		[Address(RVA = "0x107CAEC", Offset = "0x107CAEC", VA = "0x107CAEC")]
		public InputAction method_92()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F11 RID: 3857 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F11")]
		[Address(RVA = "0x107C9B8", Offset = "0x107C9B8", VA = "0x107C9B8")]
		public InputAction method_93()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F12 RID: 3858 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C884", Offset = "0x107C884", VA = "0x107C884")]
		[Token(Token = "0x6000F12")]
		public InputAction method_94()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F13 RID: 3859 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F13")]
		[Address(RVA = "0x107C6C4", Offset = "0x107C6C4", VA = "0x107C6C4")]
		public InputAction method_95()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000F14 RID: 3860 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000039")]
		public InputAction InputAction_19
		{
			[Address(RVA = "0x107CBB0", Offset = "0x107CBB0", VA = "0x107CBB0")]
			[Token(Token = "0x6000F14")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F15 RID: 3861 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x108644C", Offset = "0x108644C", VA = "0x108644C")]
		[Token(Token = "0x6000F15")]
		public void method_96()
		{
		}

		// Token: 0x06000F16 RID: 3862 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F16")]
		[Address(RVA = "0x107CB5C", Offset = "0x107CB5C", VA = "0x107CB5C")]
		public InputAction method_97()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F17 RID: 3863 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C68C", Offset = "0x107C68C", VA = "0x107C68C")]
		[Token(Token = "0x6000F17")]
		public InputAction method_98()
		{
			throw new NullReferenceException();
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000F18 RID: 3864 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700002D")]
		public InputAction InputAction_7
		{
			[Token(Token = "0x6000F18")]
			[Address(RVA = "0x107C76C", Offset = "0x107C76C", VA = "0x107C76C")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x06000F19 RID: 3865 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700002B")]
		public InputAction InputAction_5
		{
			[Address(RVA = "0x107C718", Offset = "0x107C718", VA = "0x107C718")]
			[Token(Token = "0x6000F19")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F1A RID: 3866 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000F1A")]
		[Address(RVA = "0x1086474", Offset = "0x1086474", VA = "0x1086474")]
		public void method_99()
		{
		}

		// Token: 0x06000F1B RID: 3867 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x108649C", Offset = "0x108649C", VA = "0x108649C")]
		[Token(Token = "0x6000F1B")]
		public InputAction method_100()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F1C RID: 3868 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F1C")]
		[Address(RVA = "0x107C814", Offset = "0x107C814", VA = "0x107C814")]
		public InputAction method_101()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F1D RID: 3869 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F1D")]
		[Address(RVA = "0x108639C", Offset = "0x108639C", VA = "0x108639C")]
		public InputAction method_102()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F1E RID: 3870 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F1E")]
		[Address(RVA = "0x107CB78", Offset = "0x107CB78", VA = "0x107CB78")]
		public InputAction method_103()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F1F RID: 3871 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F1F")]
		[Address(RVA = "0x107C600", Offset = "0x107C600", VA = "0x107C600")]
		public InputAction method_104()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F20 RID: 3872 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F20")]
		[Address(RVA = "0x107C7A4", Offset = "0x107C7A4", VA = "0x107C7A4")]
		public InputAction method_105()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F21 RID: 3873 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000F21")]
		[Address(RVA = "0x10864B8", Offset = "0x10864B8", VA = "0x10864B8")]
		public void method_106()
		{
		}

		// Token: 0x06000F22 RID: 3874 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F22")]
		[Address(RVA = "0x107CA44", Offset = "0x107CA44", VA = "0x107CA44")]
		public InputAction method_107()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F23 RID: 3875 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1081898", Offset = "0x1081898", VA = "0x1081898")]
		[Token(Token = "0x6000F23")]
		public InputActionMap method_108()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F24 RID: 3876 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x1081798", Offset = "0x1081798", VA = "0x1081798")]
		[Token(Token = "0x6000F24")]
		public InputAction method_109()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F25 RID: 3877 RVA: 0x0001F2CC File Offset: 0x0001D4CC
		[Token(Token = "0x6000F25")]
		[Address(RVA = "0x10864E0", Offset = "0x10864E0", VA = "0x10864E0")]
		public void method_110(GClass0.GInterface0 ginterface0_0)
		{
		}

		// Token: 0x06000F26 RID: 3878 RVA: 0x0001F2DC File Offset: 0x0001D4DC
		[Address(RVA = "0x108AEB8", Offset = "0x108AEB8", VA = "0x108AEB8")]
		[Token(Token = "0x6000F26")]
		public void method_111(GClass0.GInterface0 ginterface0_0)
		{
		}

		// Token: 0x06000F27 RID: 3879 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107CB94", Offset = "0x107CB94", VA = "0x107CB94")]
		[Token(Token = "0x6000F27")]
		public InputAction method_112()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F28 RID: 3880 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F28")]
		[Address(RVA = "0x107C8BC", Offset = "0x107C8BC", VA = "0x107C8BC")]
		public InputAction method_113()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F29 RID: 3881 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107777C", Offset = "0x107777C", VA = "0x107777C")]
		[Token(Token = "0x6000F29")]
		public InputActionMap method_114()
		{
			throw new NullReferenceException();
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000F2A RID: 3882 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700002F")]
		public InputAction InputAction_9
		{
			[Address(RVA = "0x107C7C0", Offset = "0x107C7C0", VA = "0x107C7C0")]
			[Token(Token = "0x6000F2A")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000F2B RID: 3883 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000036")]
		public InputAction InputAction_16
		{
			[Token(Token = "0x6000F2B")]
			[Address(RVA = "0x107C8F4", Offset = "0x107C8F4", VA = "0x107C8F4")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F2C RID: 3884 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F2C")]
		[Address(RVA = "0x107CB40", Offset = "0x107CB40", VA = "0x107CB40")]
		public InputAction method_115()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F2D RID: 3885 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107C9D4", Offset = "0x107C9D4", VA = "0x107C9D4")]
		[Token(Token = "0x6000F2D")]
		public InputAction method_116()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F2E RID: 3886 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x107CB24", Offset = "0x107CB24", VA = "0x107CB24")]
		[Token(Token = "0x6000F2E")]
		public InputAction method_117()
		{
			throw new NullReferenceException();
		}

		// Token: 0x0400025C RID: 604
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400025C")]
		private GClass0 gclass0_0;
	}

	// Token: 0x0200006B RID: 107
	[Token(Token = "0x200006B")]
	public struct GStruct1
	{
		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000F2F RID: 3887 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700003C")]
		public InputAction InputAction_1
		{
			[Token(Token = "0x6000F2F")]
			[Address(RVA = "0x3575FE8", Offset = "0x3575FE8", VA = "0x3575FE8")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000F30 RID: 3888 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000042")]
		public InputAction InputAction_7
		{
			[Token(Token = "0x6000F30")]
			[Address(RVA = "0x3576004", Offset = "0x3576004", VA = "0x3576004")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F31 RID: 3889 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3576020", Offset = "0x3576020", VA = "0x3576020")]
		[Token(Token = "0x6000F31")]
		public InputActionMap method_0()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F32 RID: 3890 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357603C", Offset = "0x357603C", VA = "0x357603C")]
		[Token(Token = "0x6000F32")]
		public InputAction method_1()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F33 RID: 3891 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3576058", Offset = "0x3576058", VA = "0x3576058")]
		[Token(Token = "0x6000F33")]
		public InputAction method_2()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F34 RID: 3892 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F34")]
		[Address(RVA = "0x3576074", Offset = "0x3576074", VA = "0x3576074")]
		public InputAction method_3()
		{
			throw new NullReferenceException();
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000F35 RID: 3893 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700004E")]
		public InputAction InputAction_19
		{
			[Address(RVA = "0x3576090", Offset = "0x3576090", VA = "0x3576090")]
			[Token(Token = "0x6000F35")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F36 RID: 3894 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x35760AC", Offset = "0x35760AC", VA = "0x35760AC")]
		[Token(Token = "0x6000F36")]
		public InputAction method_4()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F37 RID: 3895 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F37")]
		[Address(RVA = "0x35760C8", Offset = "0x35760C8", VA = "0x35760C8")]
		public InputAction method_5()
		{
			throw new NullReferenceException();
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000F38 RID: 3896 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700003B")]
		public InputAction InputAction_0
		{
			[Address(RVA = "0x35760E4", Offset = "0x35760E4", VA = "0x35760E4")]
			[Token(Token = "0x6000F38")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F39 RID: 3897 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F39")]
		[Address(RVA = "0x3576100", Offset = "0x3576100", VA = "0x3576100")]
		public InputAction method_6()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000F3A RID: 3898 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000041")]
		public InputAction InputAction_6
		{
			[Address(RVA = "0x357611C", Offset = "0x357611C", VA = "0x357611C")]
			[Token(Token = "0x6000F3A")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F3B RID: 3899 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F3B")]
		[Address(RVA = "0x3576138", Offset = "0x3576138", VA = "0x3576138")]
		public InputAction method_7()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F3C RID: 3900 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F3C")]
		[Address(RVA = "0x3576154", Offset = "0x3576154", VA = "0x3576154")]
		public InputAction method_8()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F3D RID: 3901 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F3D")]
		[Address(RVA = "0x3576170", Offset = "0x3576170", VA = "0x3576170")]
		public InputAction method_9()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F3E RID: 3902 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F3E")]
		[Address(RVA = "0x357618C", Offset = "0x357618C", VA = "0x357618C")]
		public InputAction method_10()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F3F RID: 3903 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F3F")]
		[Address(RVA = "0x35761A8", Offset = "0x35761A8", VA = "0x35761A8")]
		public InputAction method_11()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F40 RID: 3904 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x35761C4", Offset = "0x35761C4", VA = "0x35761C4")]
		[Token(Token = "0x6000F40")]
		public InputAction method_12()
		{
			throw new NullReferenceException();
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000F41 RID: 3905 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700003F")]
		public InputAction InputAction_4
		{
			[Token(Token = "0x6000F41")]
			[Address(RVA = "0x35761E0", Offset = "0x35761E0", VA = "0x35761E0")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000F42 RID: 3906 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000040")]
		public InputAction InputAction_5
		{
			[Address(RVA = "0x35761FC", Offset = "0x35761FC", VA = "0x35761FC")]
			[Token(Token = "0x6000F42")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F43 RID: 3907 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3576218", Offset = "0x3576218", VA = "0x3576218")]
		[Token(Token = "0x6000F43")]
		public InputAction method_13()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F44 RID: 3908 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3576234", Offset = "0x3576234", VA = "0x3576234")]
		[Token(Token = "0x6000F44")]
		public InputAction method_14()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F45 RID: 3909 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F45")]
		[Address(RVA = "0x3576250", Offset = "0x3576250", VA = "0x3576250")]
		public InputAction method_15()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F46 RID: 3910 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357626C", Offset = "0x357626C", VA = "0x357626C")]
		[Token(Token = "0x6000F46")]
		public InputAction method_16()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F47 RID: 3911 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F47")]
		[Address(RVA = "0x3576288", Offset = "0x3576288", VA = "0x3576288")]
		public InputAction method_17()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000F48 RID: 3912 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000043")]
		public InputAction InputAction_8
		{
			[Token(Token = "0x6000F48")]
			[Address(RVA = "0x35762A4", Offset = "0x35762A4", VA = "0x35762A4")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000F49 RID: 3913 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700004D")]
		public InputAction InputAction_18
		{
			[Address(RVA = "0x35762C0", Offset = "0x35762C0", VA = "0x35762C0")]
			[Token(Token = "0x6000F49")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F4A RID: 3914 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x35762DC", Offset = "0x35762DC", VA = "0x35762DC")]
		[Token(Token = "0x6000F4A")]
		public InputAction method_18()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F4B RID: 3915 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F4B")]
		[Address(RVA = "0x35762F8", Offset = "0x35762F8", VA = "0x35762F8")]
		public InputAction method_19()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000F4C RID: 3916 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000047")]
		public InputAction InputAction_12
		{
			[Address(RVA = "0x3576314", Offset = "0x3576314", VA = "0x3576314")]
			[Token(Token = "0x6000F4C")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000F4D RID: 3917 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000044")]
		public InputAction InputAction_9
		{
			[Address(RVA = "0x3576330", Offset = "0x3576330", VA = "0x3576330")]
			[Token(Token = "0x6000F4D")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000F4E RID: 3918 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000048")]
		public InputAction InputAction_13
		{
			[Token(Token = "0x6000F4E")]
			[Address(RVA = "0x357634C", Offset = "0x357634C", VA = "0x357634C")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F4F RID: 3919 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F4F")]
		[Address(RVA = "0x3576368", Offset = "0x3576368", VA = "0x3576368")]
		public InputAction method_20()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F50 RID: 3920 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3576384", Offset = "0x3576384", VA = "0x3576384")]
		[Token(Token = "0x6000F50")]
		public InputAction method_21()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F51 RID: 3921 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x35763A0", Offset = "0x35763A0", VA = "0x35763A0")]
		[Token(Token = "0x6000F51")]
		public InputAction method_22()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F52 RID: 3922 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F52")]
		[Address(RVA = "0x35763BC", Offset = "0x35763BC", VA = "0x35763BC")]
		public InputAction method_23()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F53 RID: 3923 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x35763D8", Offset = "0x35763D8", VA = "0x35763D8")]
		[Token(Token = "0x6000F53")]
		public void method_24()
		{
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000F54 RID: 3924 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700004A")]
		public InputAction InputAction_15
		{
			[Address(RVA = "0x3576400", Offset = "0x3576400", VA = "0x3576400")]
			[Token(Token = "0x6000F54")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F55 RID: 3925 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000F55")]
		[Address(RVA = "0x357641C", Offset = "0x357641C", VA = "0x357641C")]
		public void method_25()
		{
		}

		// Token: 0x06000F56 RID: 3926 RVA: 0x0001F2AC File Offset: 0x0001D4AC
		[Token(Token = "0x6000F56")]
		[Address(RVA = "0x3576460", Offset = "0x3576460", VA = "0x3576460")]
		public void method_26(GClass0.GInterface1 ginterface1_0)
		{
		}

		// Token: 0x06000F57 RID: 3927 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Address(RVA = "0x357B030", Offset = "0x357B030", VA = "0x357B030")]
		[Token(Token = "0x6000F57")]
		public bool method_27()
		{
			return false;
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000F58 RID: 3928 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700003D")]
		public InputAction InputAction_2
		{
			[Address(RVA = "0x357AE54", Offset = "0x357AE54", VA = "0x357AE54")]
			[Token(Token = "0x6000F58")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F59 RID: 3929 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F59")]
		[Address(RVA = "0x357AEC4", Offset = "0x357AEC4", VA = "0x357AEC4")]
		public InputAction method_28()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F5A RID: 3930 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x357B058", Offset = "0x357B058", VA = "0x357B058")]
		[Token(Token = "0x6000F5A")]
		public void method_29()
		{
		}

		// Token: 0x06000F5B RID: 3931 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x6000F5B")]
		[Address(RVA = "0x357B080", Offset = "0x357B080", VA = "0x357B080")]
		public bool method_30()
		{
			return false;
		}

		// Token: 0x06000F5C RID: 3932 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F5C")]
		[Address(RVA = "0x357AF6C", Offset = "0x357AF6C", VA = "0x357AF6C")]
		public InputAction method_31()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F5D RID: 3933 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3576444", Offset = "0x3576444", VA = "0x3576444")]
		[Token(Token = "0x6000F5D")]
		public InputActionMap method_32()
		{
			throw new NullReferenceException();
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000F5E RID: 3934 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x1700004F")]
		public bool Boolean_0
		{
			[Address(RVA = "0x357B0A8", Offset = "0x357B0A8", VA = "0x357B0A8")]
			[Token(Token = "0x6000F5E")]
			get
			{
				return false;
			}
		}

		// Token: 0x06000F5F RID: 3935 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F5F")]
		[Address(RVA = "0x357AFC0", Offset = "0x357AFC0", VA = "0x357AFC0")]
		public InputAction method_33()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F60 RID: 3936 RVA: 0x0001F2EC File Offset: 0x0001D4EC
		[Token(Token = "0x6000F60")]
		[Address(RVA = "0x357B0D0", Offset = "0x357B0D0", VA = "0x357B0D0")]
		public void method_34(GClass0.GInterface1 ginterface1_0)
		{
		}

		// Token: 0x06000F61 RID: 3937 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F61")]
		[Address(RVA = "0x357AEFC", Offset = "0x357AEFC", VA = "0x357AEFC")]
		public InputAction method_35()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F62 RID: 3938 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F62")]
		[Address(RVA = "0x357FAE0", Offset = "0x357FAE0", VA = "0x357FAE0")]
		public static InputActionMap smethod_0(GClass0.GStruct1 gstruct1_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000F63 RID: 3939 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700004C")]
		public InputAction InputAction_17
		{
			[Token(Token = "0x6000F63")]
			[Address(RVA = "0x357B014", Offset = "0x357B014", VA = "0x357B014")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F64 RID: 3940 RVA: 0x0000259C File Offset: 0x0000079C
		[Address(RVA = "0x357FAF8", Offset = "0x357FAF8", VA = "0x357FAF8")]
		[Token(Token = "0x6000F64")]
		public GStruct1(GClass0 gclass0_1)
		{
			this.gclass0_0 = gclass0_1;
		}

		// Token: 0x06000F65 RID: 3941 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357FB00", Offset = "0x357FB00", VA = "0x357FB00")]
		[Token(Token = "0x6000F65")]
		public static InputActionMap smethod_1(GClass0.GStruct1 gstruct1_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000F66 RID: 3942 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000046")]
		public InputAction InputAction_11
		{
			[Token(Token = "0x6000F66")]
			[Address(RVA = "0x357AF50", Offset = "0x357AF50", VA = "0x357AF50")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F67 RID: 3943 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F67")]
		[Address(RVA = "0x357AEA8", Offset = "0x357AEA8", VA = "0x357AEA8")]
		public InputAction method_36()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F68 RID: 3944 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357FB18", Offset = "0x357FB18", VA = "0x357FB18")]
		[Token(Token = "0x6000F68")]
		public InputAction method_37()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F69 RID: 3945 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357AE38", Offset = "0x357AE38", VA = "0x357AE38")]
		[Token(Token = "0x6000F69")]
		public InputAction method_38()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F6A RID: 3946 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357AEE0", Offset = "0x357AEE0", VA = "0x357AEE0")]
		[Token(Token = "0x6000F6A")]
		public InputAction method_39()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F6B RID: 3947 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357AFDC", Offset = "0x357AFDC", VA = "0x357AFDC")]
		[Token(Token = "0x6000F6B")]
		public InputAction method_40()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F6C RID: 3948 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F6C")]
		[Address(RVA = "0x357AF88", Offset = "0x357AF88", VA = "0x357AF88")]
		public InputAction method_41()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F6D RID: 3949 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000F6D")]
		[Address(RVA = "0x357FB34", Offset = "0x357FB34", VA = "0x357FB34")]
		public void method_42()
		{
		}

		// Token: 0x06000F6E RID: 3950 RVA: 0x0001F2FC File Offset: 0x0001D4FC
		[Address(RVA = "0x357FB5C", Offset = "0x357FB5C", VA = "0x357FB5C")]
		[Token(Token = "0x6000F6E")]
		public void method_43(GClass0.GInterface1 ginterface1_0)
		{
		}

		// Token: 0x06000F6F RID: 3951 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357AE8C", Offset = "0x357AE8C", VA = "0x357AE8C")]
		[Token(Token = "0x6000F6F")]
		public InputAction method_44()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F70 RID: 3952 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357FAA8", Offset = "0x357FAA8", VA = "0x357FAA8")]
		[Token(Token = "0x6000F70")]
		public InputAction method_45()
		{
			throw new NullReferenceException();
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000F71 RID: 3953 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700004B")]
		public InputAction InputAction_16
		{
			[Token(Token = "0x6000F71")]
			[Address(RVA = "0x357AFF8", Offset = "0x357AFF8", VA = "0x357AFF8")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F72 RID: 3954 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F72")]
		[Address(RVA = "0x357FAC4", Offset = "0x357FAC4", VA = "0x357FAC4")]
		public InputAction method_46()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F73 RID: 3955 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357AF18", Offset = "0x357AF18", VA = "0x357AF18")]
		[Token(Token = "0x6000F73")]
		public InputAction method_47()
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000F74 RID: 3956 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000045")]
		public InputAction InputAction_10
		{
			[Address(RVA = "0x357AF34", Offset = "0x357AF34", VA = "0x357AF34")]
			[Token(Token = "0x6000F74")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000F75 RID: 3957 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x1700003E")]
		public InputAction InputAction_3
		{
			[Address(RVA = "0x357AE70", Offset = "0x357AE70", VA = "0x357AE70")]
			[Token(Token = "0x6000F75")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x06000F76 RID: 3958 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000049")]
		public InputAction InputAction_14
		{
			[Token(Token = "0x6000F76")]
			[Address(RVA = "0x357AFA4", Offset = "0x357AFA4", VA = "0x357AFA4")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x0400025D RID: 605
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400025D")]
		private GClass0 gclass0_0;
	}

	// Token: 0x0200006C RID: 108
	[Token(Token = "0x200006C")]
	public struct GStruct2
	{
		// Token: 0x06000F77 RID: 3959 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3573358", Offset = "0x3573358", VA = "0x3573358")]
		[Token(Token = "0x6000F77")]
		public InputAction method_0()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F78 RID: 3960 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F78")]
		[Address(RVA = "0x3573374", Offset = "0x3573374", VA = "0x3573374")]
		public static InputActionMap smethod_0(GClass0.GStruct2 gstruct2_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F79 RID: 3961 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000F79")]
		[Address(RVA = "0x35733A8", Offset = "0x35733A8", VA = "0x35733A8")]
		public void method_1()
		{
		}

		// Token: 0x06000F7A RID: 3962 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000F7A")]
		[Address(RVA = "0x35733EC", Offset = "0x35733EC", VA = "0x35733EC")]
		public void method_2()
		{
		}

		// Token: 0x06000F7B RID: 3963 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F7B")]
		[Address(RVA = "0x3573430", Offset = "0x3573430", VA = "0x3573430")]
		public InputAction method_3()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F7C RID: 3964 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000F7C")]
		[Address(RVA = "0x357344C", Offset = "0x357344C", VA = "0x357344C")]
		public void method_4()
		{
		}

		// Token: 0x06000F7D RID: 3965 RVA: 0x0001F30C File Offset: 0x0001D50C
		[Token(Token = "0x6000F7D")]
		[Address(RVA = "0x3573490", Offset = "0x3573490", VA = "0x3573490")]
		public void method_5(GClass0.GInterface2 ginterface2_0)
		{
		}

		// Token: 0x06000F7E RID: 3966 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3573D04", Offset = "0x3573D04", VA = "0x3573D04")]
		[Token(Token = "0x6000F7E")]
		public void method_6()
		{
		}

		// Token: 0x06000F7F RID: 3967 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F7F")]
		[Address(RVA = "0x3573CE8", Offset = "0x3573CE8", VA = "0x3573CE8")]
		public InputAction method_7()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F80 RID: 3968 RVA: 0x0001F30C File Offset: 0x0001D50C
		[Token(Token = "0x6000F80")]
		[Address(RVA = "0x3573D2C", Offset = "0x3573D2C", VA = "0x3573D2C")]
		public void method_8(GClass0.GInterface2 ginterface2_0)
		{
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000F81 RID: 3969 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x17000052")]
		public bool Boolean_0
		{
			[Token(Token = "0x6000F81")]
			[Address(RVA = "0x3574530", Offset = "0x3574530", VA = "0x3574530")]
			get
			{
				return false;
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x06000F82 RID: 3970 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000050")]
		public InputAction InputAction_0
		{
			[Token(Token = "0x6000F82")]
			[Address(RVA = "0x3573C94", Offset = "0x3573C94", VA = "0x3573C94")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F83 RID: 3971 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3574558", Offset = "0x3574558", VA = "0x3574558")]
		[Token(Token = "0x6000F83")]
		public void method_9()
		{
		}

		// Token: 0x06000F84 RID: 3972 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000F84")]
		[Address(RVA = "0x3574580", Offset = "0x3574580", VA = "0x3574580")]
		public void method_10()
		{
		}

		// Token: 0x06000F85 RID: 3973 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F85")]
		[Address(RVA = "0x35745A8", Offset = "0x35745A8", VA = "0x35745A8")]
		public static InputActionMap smethod_1(GClass0.GStruct2 gstruct2_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F86 RID: 3974 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x35745C0", Offset = "0x35745C0", VA = "0x35745C0")]
		[Token(Token = "0x6000F86")]
		public static InputActionMap smethod_2(GClass0.GStruct2 gstruct2_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F87 RID: 3975 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x6000F87")]
		[Address(RVA = "0x35745D8", Offset = "0x35745D8", VA = "0x35745D8")]
		public bool method_11()
		{
			return false;
		}

		// Token: 0x06000F88 RID: 3976 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x6000F88")]
		[Address(RVA = "0x357461C", Offset = "0x357461C", VA = "0x357461C")]
		public bool method_12()
		{
			return false;
		}

		// Token: 0x06000F89 RID: 3977 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F89")]
		[Address(RVA = "0x35733D0", Offset = "0x35733D0", VA = "0x35733D0")]
		public InputActionMap method_13()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F8A RID: 3978 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F8A")]
		[Address(RVA = "0x3574600", Offset = "0x3574600", VA = "0x3574600")]
		public InputActionMap method_14()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F8B RID: 3979 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3574644", Offset = "0x3574644", VA = "0x3574644")]
		[Token(Token = "0x6000F8B")]
		public void method_15()
		{
		}

		// Token: 0x06000F8C RID: 3980 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F8C")]
		[Address(RVA = "0x3573474", Offset = "0x3573474", VA = "0x3573474")]
		public InputActionMap method_16()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F8D RID: 3981 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F8D")]
		[Address(RVA = "0x357466C", Offset = "0x357466C", VA = "0x357466C")]
		public static InputActionMap smethod_3(GClass0.GStruct2 gstruct2_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F8E RID: 3982 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F8E")]
		[Address(RVA = "0x3574684", Offset = "0x3574684", VA = "0x3574684")]
		public static InputActionMap smethod_4(GClass0.GStruct2 gstruct2_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F8F RID: 3983 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x357469C", Offset = "0x357469C", VA = "0x357469C")]
		[Token(Token = "0x6000F8F")]
		public void method_17()
		{
		}

		// Token: 0x06000F90 RID: 3984 RVA: 0x000025A5 File Offset: 0x000007A5
		[Token(Token = "0x6000F90")]
		[Address(RVA = "0x35746C4", Offset = "0x35746C4", VA = "0x35746C4")]
		public GStruct2(GClass0 gclass0_1)
		{
			this.gclass0_0 = gclass0_1;
		}

		// Token: 0x06000F91 RID: 3985 RVA: 0x0001F30C File Offset: 0x0001D50C
		[Token(Token = "0x6000F91")]
		[Address(RVA = "0x35746CC", Offset = "0x35746CC", VA = "0x35746CC")]
		public void method_18(GClass0.GInterface2 ginterface2_0)
		{
		}

		// Token: 0x06000F92 RID: 3986 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Address(RVA = "0x3574ED0", Offset = "0x3574ED0", VA = "0x3574ED0")]
		[Token(Token = "0x6000F92")]
		public bool method_19()
		{
			return false;
		}

		// Token: 0x06000F93 RID: 3987 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3574EF8", Offset = "0x3574EF8", VA = "0x3574EF8")]
		[Token(Token = "0x6000F93")]
		public void method_20()
		{
		}

		// Token: 0x06000F94 RID: 3988 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Address(RVA = "0x3574F20", Offset = "0x3574F20", VA = "0x3574F20")]
		[Token(Token = "0x6000F94")]
		public bool method_21()
		{
			return false;
		}

		// Token: 0x06000F95 RID: 3989 RVA: 0x0001F30C File Offset: 0x0001D50C
		[Token(Token = "0x6000F95")]
		[Address(RVA = "0x3574F48", Offset = "0x3574F48", VA = "0x3574F48")]
		public void method_22(GClass0.GInterface2 ginterface2_0)
		{
		}

		// Token: 0x06000F96 RID: 3990 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x6000F96")]
		[Address(RVA = "0x357574C", Offset = "0x357574C", VA = "0x357574C")]
		public bool method_23()
		{
			return false;
		}

		// Token: 0x06000F97 RID: 3991 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3573CCC", Offset = "0x3573CCC", VA = "0x3573CCC")]
		[Token(Token = "0x6000F97")]
		public InputAction method_24()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F98 RID: 3992 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3575774", Offset = "0x3575774", VA = "0x3575774")]
		[Token(Token = "0x6000F98")]
		public static InputActionMap smethod_5(GClass0.GStruct2 gstruct2_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F99 RID: 3993 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357578C", Offset = "0x357578C", VA = "0x357578C")]
		[Token(Token = "0x6000F99")]
		public static InputActionMap smethod_6(GClass0.GStruct2 gstruct2_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F9A RID: 3994 RVA: 0x0001F30C File Offset: 0x0001D50C
		[Address(RVA = "0x35757A4", Offset = "0x35757A4", VA = "0x35757A4")]
		[Token(Token = "0x6000F9A")]
		public void method_25(GClass0.GInterface2 ginterface2_0)
		{
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x06000F9B RID: 3995 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000051")]
		public InputAction InputAction_1
		{
			[Address(RVA = "0x3573CB0", Offset = "0x3573CB0", VA = "0x3573CB0")]
			[Token(Token = "0x6000F9B")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000F9C RID: 3996 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3575FA8", Offset = "0x3575FA8", VA = "0x3575FA8")]
		[Token(Token = "0x6000F9C")]
		public void method_26()
		{
		}

		// Token: 0x06000F9D RID: 3997 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000F9D")]
		[Address(RVA = "0x357338C", Offset = "0x357338C", VA = "0x357338C")]
		public InputActionMap method_27()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F9E RID: 3998 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3573414", Offset = "0x3573414", VA = "0x3573414")]
		[Token(Token = "0x6000F9E")]
		public InputActionMap method_28()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000F9F RID: 3999 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3575FD0", Offset = "0x3575FD0", VA = "0x3575FD0")]
		[Token(Token = "0x6000F9F")]
		public static InputActionMap smethod_7(GClass0.GStruct2 gstruct2_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x0400025E RID: 606
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400025E")]
		private GClass0 gclass0_0;
	}

	// Token: 0x0200006D RID: 109
	[Token(Token = "0x200006D")]
	public struct GStruct3
	{
		// Token: 0x06000FA0 RID: 4000 RVA: 0x0001F31C File Offset: 0x0001D51C
		[Address(RVA = "0x356DB6C", Offset = "0x356DB6C", VA = "0x356DB6C")]
		[Token(Token = "0x6000FA0")]
		public void method_0(GClass0.GInterface3 ginterface3_0)
		{
		}

		// Token: 0x06000FA1 RID: 4001 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000FA1")]
		[Address(RVA = "0x356E884", Offset = "0x356E884", VA = "0x356E884")]
		public InputAction method_1()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FA2 RID: 4002 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x356E8A0", Offset = "0x356E8A0", VA = "0x356E8A0")]
		[Token(Token = "0x6000FA2")]
		public void method_2()
		{
		}

		// Token: 0x06000FA3 RID: 4003 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Address(RVA = "0x356E8E4", Offset = "0x356E8E4", VA = "0x356E8E4")]
		[Token(Token = "0x6000FA3")]
		public bool method_3()
		{
			return false;
		}

		// Token: 0x06000FA4 RID: 4004 RVA: 0x0001F31C File Offset: 0x0001D51C
		[Address(RVA = "0x356E928", Offset = "0x356E928", VA = "0x356E928")]
		[Token(Token = "0x6000FA4")]
		public void method_4(GClass0.GInterface3 ginterface3_0)
		{
		}

		// Token: 0x06000FA5 RID: 4005 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356E830", Offset = "0x356E830", VA = "0x356E830")]
		[Token(Token = "0x6000FA5")]
		public InputAction method_5()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FA6 RID: 4006 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000FA6")]
		[Address(RVA = "0x356F50C", Offset = "0x356F50C", VA = "0x356F50C")]
		public void method_6()
		{
		}

		// Token: 0x06000FA7 RID: 4007 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356E76C", Offset = "0x356E76C", VA = "0x356E76C")]
		[Token(Token = "0x6000FA7")]
		public InputAction method_7()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FA8 RID: 4008 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x356F534", Offset = "0x356F534", VA = "0x356F534")]
		[Token(Token = "0x6000FA8")]
		public void method_8()
		{
		}

		// Token: 0x06000FA9 RID: 4009 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356E750", Offset = "0x356E750", VA = "0x356E750")]
		[Token(Token = "0x6000FA9")]
		public InputAction method_9()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FAA RID: 4010 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000FAA")]
		[Address(RVA = "0x356F578", Offset = "0x356F578", VA = "0x356F578")]
		public void method_10()
		{
		}

		// Token: 0x06000FAB RID: 4011 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000FAB")]
		[Address(RVA = "0x356F5A0", Offset = "0x356F5A0", VA = "0x356F5A0")]
		public static InputActionMap smethod_0(GClass0.GStruct3 gstruct3_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FAC RID: 4012 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000FAC")]
		[Address(RVA = "0x356F5B8", Offset = "0x356F5B8", VA = "0x356F5B8")]
		public void method_11()
		{
		}

		// Token: 0x06000FAD RID: 4013 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356F4D4", Offset = "0x356F4D4", VA = "0x356F4D4")]
		[Token(Token = "0x6000FAD")]
		public InputAction method_12()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FAE RID: 4014 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000FAE")]
		[Address(RVA = "0x356E90C", Offset = "0x356E90C", VA = "0x356E90C")]
		public InputActionMap method_13()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FAF RID: 4015 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x356F5E0", Offset = "0x356F5E0", VA = "0x356F5E0")]
		[Token(Token = "0x6000FAF")]
		public void method_14()
		{
		}

		// Token: 0x06000FB0 RID: 4016 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x356F608", Offset = "0x356F608", VA = "0x356F608")]
		[Token(Token = "0x6000FB0")]
		public void method_15()
		{
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x06000FB1 RID: 4017 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000054")]
		public InputAction InputAction_1
		{
			[Address(RVA = "0x356F4F0", Offset = "0x356F4F0", VA = "0x356F4F0")]
			[Token(Token = "0x6000FB1")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000FB2 RID: 4018 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356F630", Offset = "0x356F630", VA = "0x356F630")]
		[Token(Token = "0x6000FB2")]
		public InputAction method_16()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FB3 RID: 4019 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000FB3")]
		[Address(RVA = "0x356F64C", Offset = "0x356F64C", VA = "0x356F64C")]
		public static InputActionMap smethod_1(GClass0.GStruct3 gstruct3_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FB4 RID: 4020 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356F664", Offset = "0x356F664", VA = "0x356F664")]
		[Token(Token = "0x6000FB4")]
		public InputActionMap method_17()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FB5 RID: 4021 RVA: 0x0001F31C File Offset: 0x0001D51C
		[Address(RVA = "0x356F680", Offset = "0x356F680", VA = "0x356F680")]
		[Token(Token = "0x6000FB5")]
		public void method_18(GClass0.GInterface3 ginterface3_0)
		{
		}

		// Token: 0x06000FB6 RID: 4022 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356E718", Offset = "0x356E718", VA = "0x356E718")]
		[Token(Token = "0x6000FB6")]
		public InputAction method_19()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FB7 RID: 4023 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356E7C0", Offset = "0x356E7C0", VA = "0x356E7C0")]
		[Token(Token = "0x6000FB7")]
		public InputAction method_20()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FB8 RID: 4024 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356E7F8", Offset = "0x356E7F8", VA = "0x356E7F8")]
		[Token(Token = "0x6000FB8")]
		public InputAction method_21()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FB9 RID: 4025 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x357022C", Offset = "0x357022C", VA = "0x357022C")]
		[Token(Token = "0x6000FB9")]
		public InputAction method_22()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FBA RID: 4026 RVA: 0x0001F31C File Offset: 0x0001D51C
		[Address(RVA = "0x3570248", Offset = "0x3570248", VA = "0x3570248")]
		[Token(Token = "0x6000FBA")]
		public void method_23(GClass0.GInterface3 ginterface3_0)
		{
		}

		// Token: 0x06000FBB RID: 4027 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3570E10", Offset = "0x3570E10", VA = "0x3570E10")]
		[Token(Token = "0x6000FBB")]
		public void method_24()
		{
		}

		// Token: 0x06000FBC RID: 4028 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3570E38", Offset = "0x3570E38", VA = "0x3570E38")]
		[Token(Token = "0x6000FBC")]
		public static InputActionMap smethod_2(GClass0.GStruct3 gstruct3_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FBD RID: 4029 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3570E50", Offset = "0x3570E50", VA = "0x3570E50")]
		[Token(Token = "0x6000FBD")]
		public static InputActionMap smethod_3(GClass0.GStruct3 gstruct3_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FBE RID: 4030 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3570E68", Offset = "0x3570E68", VA = "0x3570E68")]
		[Token(Token = "0x6000FBE")]
		public void method_25()
		{
		}

		// Token: 0x06000FBF RID: 4031 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3570E90", Offset = "0x3570E90", VA = "0x3570E90")]
		[Token(Token = "0x6000FBF")]
		public void method_26()
		{
		}

		// Token: 0x06000FC0 RID: 4032 RVA: 0x0001F31C File Offset: 0x0001D51C
		[Address(RVA = "0x3570EB8", Offset = "0x3570EB8", VA = "0x3570EB8")]
		[Token(Token = "0x6000FC0")]
		public void method_27(GClass0.GInterface3 ginterface3_0)
		{
		}

		// Token: 0x06000FC1 RID: 4033 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356F55C", Offset = "0x356F55C", VA = "0x356F55C")]
		[Token(Token = "0x6000FC1")]
		public InputActionMap method_28()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FC2 RID: 4034 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356E868", Offset = "0x356E868", VA = "0x356E868")]
		[Token(Token = "0x6000FC2")]
		public InputAction method_29()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FC3 RID: 4035 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3571A64", Offset = "0x3571A64", VA = "0x3571A64")]
		[Token(Token = "0x6000FC3")]
		public static InputActionMap smethod_4(GClass0.GStruct3 gstruct3_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FC4 RID: 4036 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356E8C8", Offset = "0x356E8C8", VA = "0x356E8C8")]
		[Token(Token = "0x6000FC4")]
		public InputActionMap method_30()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FC5 RID: 4037 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000FC5")]
		[Address(RVA = "0x3571A7C", Offset = "0x3571A7C", VA = "0x3571A7C")]
		public void method_31()
		{
		}

		// Token: 0x06000FC6 RID: 4038 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000FC6")]
		[Address(RVA = "0x356E7DC", Offset = "0x356E7DC", VA = "0x356E7DC")]
		public InputAction method_32()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FC7 RID: 4039 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000FC7")]
		[Address(RVA = "0x356E814", Offset = "0x356E814", VA = "0x356E814")]
		public InputAction method_33()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FC8 RID: 4040 RVA: 0x0001F31C File Offset: 0x0001D51C
		[Address(RVA = "0x3571AA4", Offset = "0x3571AA4", VA = "0x3571AA4")]
		[Token(Token = "0x6000FC8")]
		public void method_34(GClass0.GInterface3 ginterface3_0)
		{
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000FC9 RID: 4041 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000055")]
		public InputAction InputAction_2
		{
			[Token(Token = "0x6000FC9")]
			[Address(RVA = "0x3570DF4", Offset = "0x3570DF4", VA = "0x3570DF4")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000FCA RID: 4042 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000FCA")]
		[Address(RVA = "0x357266C", Offset = "0x357266C", VA = "0x357266C")]
		public static InputActionMap smethod_5(GClass0.GStruct3 gstruct3_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FCB RID: 4043 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000FCB")]
		[Address(RVA = "0x356E84C", Offset = "0x356E84C", VA = "0x356E84C")]
		public InputAction method_35()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FCC RID: 4044 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000FCC")]
		[Address(RVA = "0x3572684", Offset = "0x3572684", VA = "0x3572684")]
		public static InputActionMap smethod_6(GClass0.GStruct3 gstruct3_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000FCD RID: 4045 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x17000053")]
		public InputAction InputAction_0
		{
			[Address(RVA = "0x356E734", Offset = "0x356E734", VA = "0x356E734")]
			[Token(Token = "0x6000FCD")]
			get
			{
				throw new NullReferenceException();
			}
		}

		// Token: 0x06000FCE RID: 4046 RVA: 0x0000258C File Offset: 0x0000078C
		[Token(Token = "0x6000FCE")]
		[Address(RVA = "0x356E788", Offset = "0x356E788", VA = "0x356E788")]
		public InputAction method_36()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FCF RID: 4047 RVA: 0x0001F32C File Offset: 0x0001D52C
		[Address(RVA = "0x357269C", Offset = "0x357269C", VA = "0x357269C")]
		[Token(Token = "0x6000FCF")]
		public void method_37(GClass0.GInterface3 ginterface3_0)
		{
		}

		// Token: 0x06000FD0 RID: 4048 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3573248", Offset = "0x3573248", VA = "0x3573248")]
		[Token(Token = "0x6000FD0")]
		public static InputActionMap smethod_7(GClass0.GStruct3 gstruct3_0)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FD1 RID: 4049 RVA: 0x000025AE File Offset: 0x000007AE
		[Token(Token = "0x6000FD1")]
		[Address(RVA = "0x3573260", Offset = "0x3573260", VA = "0x3573260")]
		public GStruct3(GClass0 gclass0_1)
		{
			this.gclass0_0 = gclass0_1;
		}

		// Token: 0x06000FD2 RID: 4050 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Address(RVA = "0x3573268", Offset = "0x3573268", VA = "0x3573268")]
		[Token(Token = "0x6000FD2")]
		public bool method_38()
		{
			return false;
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06000FD3 RID: 4051 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Token(Token = "0x17000056")]
		public bool Boolean_0
		{
			[Token(Token = "0x6000FD3")]
			[Address(RVA = "0x3573290", Offset = "0x3573290", VA = "0x3573290")]
			get
			{
				return false;
			}
		}

		// Token: 0x06000FD4 RID: 4052 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Address(RVA = "0x35732B8", Offset = "0x35732B8", VA = "0x35732B8")]
		[Token(Token = "0x6000FD4")]
		public bool method_39()
		{
			return false;
		}

		// Token: 0x06000FD5 RID: 4053 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x3572650", Offset = "0x3572650", VA = "0x3572650")]
		[Token(Token = "0x6000FD5")]
		public InputAction method_40()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FD6 RID: 4054 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000FD6")]
		[Address(RVA = "0x35732E0", Offset = "0x35732E0", VA = "0x35732E0")]
		public void method_41()
		{
		}

		// Token: 0x06000FD7 RID: 4055 RVA: 0x0000258C File Offset: 0x0000078C
		[Address(RVA = "0x356E7A4", Offset = "0x356E7A4", VA = "0x356E7A4")]
		[Token(Token = "0x6000FD7")]
		public InputAction method_42()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06000FD8 RID: 4056 RVA: 0x0001F28C File Offset: 0x0001D48C
		[Address(RVA = "0x3573308", Offset = "0x3573308", VA = "0x3573308")]
		[Token(Token = "0x6000FD8")]
		public bool method_43()
		{
			return false;
		}

		// Token: 0x06000FD9 RID: 4057 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6000FD9")]
		[Address(RVA = "0x3573330", Offset = "0x3573330", VA = "0x3573330")]
		public void method_44()
		{
		}

		// Token: 0x0400025F RID: 607
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400025F")]
		private GClass0 gclass0_0;
	}

	// Token: 0x0200006E RID: 110
	[Token(Token = "0x200006E")]
	public interface GInterface0
	{
		// Token: 0x06000FDA RID: 4058
		[Address(Slot = "0")]
		[Token(Token = "0x6000FDA")]
		void imethod_0(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FDB RID: 4059
		[Token(Token = "0x6000FDB")]
		[Address(Slot = "1")]
		void imethod_1(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FDC RID: 4060
		[Token(Token = "0x6000FDC")]
		[Address(Slot = "2")]
		void imethod_2(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FDD RID: 4061
		[Address(Slot = "3")]
		[Token(Token = "0x6000FDD")]
		void imethod_3(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FDE RID: 4062
		[Token(Token = "0x6000FDE")]
		[Address(Slot = "4")]
		void imethod_4(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FDF RID: 4063
		[Address(Slot = "5")]
		[Token(Token = "0x6000FDF")]
		void imethod_5(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FE0 RID: 4064
		[Address(Slot = "6")]
		[Token(Token = "0x6000FE0")]
		void imethod_6(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FE1 RID: 4065
		[Token(Token = "0x6000FE1")]
		[Address(Slot = "7")]
		void imethod_7(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FE2 RID: 4066
		[Address(Slot = "8")]
		[Token(Token = "0x6000FE2")]
		void imethod_8(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FE3 RID: 4067
		[Token(Token = "0x6000FE3")]
		[Address(Slot = "9")]
		void imethod_9(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FE4 RID: 4068
		[Address(Slot = "10")]
		[Token(Token = "0x6000FE4")]
		void imethod_10(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FE5 RID: 4069
		[Token(Token = "0x6000FE5")]
		[Address(Slot = "11")]
		void imethod_11(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FE6 RID: 4070
		[Address(Slot = "12")]
		[Token(Token = "0x6000FE6")]
		void imethod_12(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FE7 RID: 4071
		[Token(Token = "0x6000FE7")]
		[Address(Slot = "13")]
		void imethod_13(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FE8 RID: 4072
		[Token(Token = "0x6000FE8")]
		[Address(Slot = "14")]
		void imethod_14(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FE9 RID: 4073
		[Address(Slot = "15")]
		[Token(Token = "0x6000FE9")]
		void imethod_15(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FEA RID: 4074
		[Address(Slot = "16")]
		[Token(Token = "0x6000FEA")]
		void imethod_16(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FEB RID: 4075
		[Token(Token = "0x6000FEB")]
		[Address(Slot = "17")]
		void imethod_17(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FEC RID: 4076
		[Token(Token = "0x6000FEC")]
		[Address(Slot = "18")]
		void imethod_18(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FED RID: 4077
		[Token(Token = "0x6000FED")]
		[Address(Slot = "19")]
		void imethod_19(InputAction.CallbackContext callbackContext_0);
	}

	// Token: 0x0200006F RID: 111
	[Token(Token = "0x200006F")]
	public interface GInterface1
	{
		// Token: 0x06000FEE RID: 4078
		[Token(Token = "0x6000FEE")]
		[Address(Slot = "0")]
		void imethod_0(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FEF RID: 4079
		[Token(Token = "0x6000FEF")]
		[Address(Slot = "1")]
		void imethod_1(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FF0 RID: 4080
		[Address(Slot = "2")]
		[Token(Token = "0x6000FF0")]
		void imethod_2(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FF1 RID: 4081
		[Address(Slot = "3")]
		[Token(Token = "0x6000FF1")]
		void imethod_3(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FF2 RID: 4082
		[Token(Token = "0x6000FF2")]
		[Address(Slot = "4")]
		void imethod_4(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FF3 RID: 4083
		[Address(Slot = "5")]
		[Token(Token = "0x6000FF3")]
		void imethod_5(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FF4 RID: 4084
		[Address(Slot = "6")]
		[Token(Token = "0x6000FF4")]
		void imethod_6(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FF5 RID: 4085
		[Address(Slot = "7")]
		[Token(Token = "0x6000FF5")]
		void imethod_7(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FF6 RID: 4086
		[Address(Slot = "8")]
		[Token(Token = "0x6000FF6")]
		void imethod_8(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FF7 RID: 4087
		[Token(Token = "0x6000FF7")]
		[Address(Slot = "9")]
		void imethod_9(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FF8 RID: 4088
		[Address(Slot = "10")]
		[Token(Token = "0x6000FF8")]
		void imethod_10(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FF9 RID: 4089
		[Token(Token = "0x6000FF9")]
		[Address(Slot = "11")]
		void imethod_11(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FFA RID: 4090
		[Address(Slot = "12")]
		[Token(Token = "0x6000FFA")]
		void imethod_12(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FFB RID: 4091
		[Address(Slot = "13")]
		[Token(Token = "0x6000FFB")]
		void imethod_13(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FFC RID: 4092
		[Address(Slot = "14")]
		[Token(Token = "0x6000FFC")]
		void imethod_14(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FFD RID: 4093
		[Address(Slot = "15")]
		[Token(Token = "0x6000FFD")]
		void imethod_15(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FFE RID: 4094
		[Address(Slot = "16")]
		[Token(Token = "0x6000FFE")]
		void imethod_16(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06000FFF RID: 4095
		[Address(Slot = "17")]
		[Token(Token = "0x6000FFF")]
		void imethod_17(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06001000 RID: 4096
		[Address(Slot = "18")]
		[Token(Token = "0x6001000")]
		void imethod_18(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06001001 RID: 4097
		[Address(Slot = "19")]
		[Token(Token = "0x6001001")]
		void imethod_19(InputAction.CallbackContext callbackContext_0);
	}

	// Token: 0x02000070 RID: 112
	[Token(Token = "0x2000070")]
	public interface GInterface2
	{
		// Token: 0x06001002 RID: 4098
		[Address(Slot = "0")]
		[Token(Token = "0x6001002")]
		void imethod_0(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06001003 RID: 4099
		[Address(Slot = "1")]
		[Token(Token = "0x6001003")]
		void imethod_1(InputAction.CallbackContext callbackContext_0);
	}

	// Token: 0x02000071 RID: 113
	[Token(Token = "0x2000071")]
	public interface GInterface3
	{
		// Token: 0x06001004 RID: 4100
		[Address(Slot = "0")]
		[Token(Token = "0x6001004")]
		void imethod_0(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06001005 RID: 4101
		[Token(Token = "0x6001005")]
		[Address(Slot = "1")]
		void imethod_1(InputAction.CallbackContext callbackContext_0);

		// Token: 0x06001006 RID: 4102
		[Address(Slot = "2")]
		[Token(Token = "0x6001006")]
		void imethod_2(InputAction.CallbackContext callbackContext_0);
	}
}
